/*     */ package com.infomedia.comm;
/*     */ 
/*     */ import com.infomedia.utils.ReflectUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClienteBaseCNX
/*     */   implements InterfaceClienteCNX
/*     */ {
/*  16 */   protected boolean gbDebug = false;
/*     */   
/*  18 */   protected ServerVO goServer = new ServerVO();
/*     */   
/*  20 */   protected String gsRespuesta = "";
/*  21 */   protected String gsError = "";
/*     */   
/*  23 */   protected boolean gbRespuesta = false;
/*  24 */   protected boolean gbError = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteBaseCNX(Properties poProperties)
/*     */   {
/*  36 */     this.goServer.setHST(StringUtils.NVL(poProperties.getProperty("server.host")));
/*  37 */     this.goServer.setPRT(Integer.parseInt(StringUtils.NVL(poProperties.getProperty("server.port"), "0")));
/*  38 */     this.goServer.setUSR(StringUtils.NVL(poProperties.getProperty("server.user")));
/*  39 */     this.goServer.setPWD(StringUtils.NVL(poProperties.getProperty("server.password")));
/*  40 */     this.gbDebug = Boolean.parseBoolean(StringUtils.NVL(poProperties.getProperty("server.debug"), "false"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteBaseCNX(ServerVO poServer, boolean pbDebug)
/*     */   {
/*  53 */     this.goServer = poServer;
/*  54 */     this.gbDebug = pbDebug;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteBaseCNX(ServerVO poServer)
/*     */   {
/*  66 */     this(poServer, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbError()
/*     */   {
/*  77 */     return this.gbError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getError()
/*     */   {
/*  87 */     return this.gsError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbRespuesta()
/*     */   {
/*  97 */     return this.gbRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRespuesta()
/*     */   {
/* 107 */     return this.gsRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServidor(ServerVO poServer)
/*     */   {
/* 117 */     this.goServer = poServer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerVO getServidor()
/*     */   {
/* 127 */     return this.goServer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean fncbConecta();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean fncbLogin();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbLogin(String psUsuario, String psContrasenia)
/*     */   {
/* 160 */     this.goServer.setUSR(psUsuario);
/* 161 */     this.goServer.setPWD(psContrasenia);
/* 162 */     return fncbLogin();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void prcLogout();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object fncoAccion(String psAccion, Object[] poParametros)
/*     */   {
/* 185 */     return ReflectUtils.fncoEjecuta(psAccion, poParametros, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcLimpiar()
/*     */   {
/* 196 */     this.gbRespuesta = false;
/* 197 */     this.gbError = false;
/* 198 */     this.gsRespuesta = "";
/* 199 */     this.gsError = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcRegistraError(String psError)
/*     */   {
/* 211 */     this.gbError = true;
/* 212 */     this.gsError = psError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcRegistraRespuesta(String psRespuesta)
/*     */   {
/* 224 */     this.gbRespuesta = true;
/* 225 */     this.gsRespuesta = psRespuesta;
/*     */   }
/*     */   
/*     */   protected abstract boolean fncbError(String paramString);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ClienteBaseCNX.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */