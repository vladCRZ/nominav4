/*    */ package com.infomedia.comm;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClienteCNX
/*    */   extends SocketBasedClienteCNX
/*    */ {
/*    */   public ClienteCNX(Properties poProperties)
/*    */   {
/* 24 */     super(poProperties);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteCNX(ServerVO poServer, boolean pbDebug)
/*    */   {
/* 37 */     super(poServer, pbDebug);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClienteCNX(ServerVO poServer)
/*    */   {
/* 49 */     this(poServer, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ClienteCNX.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */