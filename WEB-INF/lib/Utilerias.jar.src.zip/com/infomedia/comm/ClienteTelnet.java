/*     */ package com.infomedia.comm;
/*     */ 
/*     */ import com.infomedia.utils.DateUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import org.apache.commons.net.SocketClient;
/*     */ import org.apache.commons.net.telnet.TelnetClient;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClienteTelnet
/*     */   extends ClienteCNX
/*     */ {
/*  22 */   private static Logger log = null;
/*     */   
/*  24 */   private String gsComando = "";
/*  25 */   protected BufferedReader goEntrada = null;
/*  26 */   protected PrintStream goSalida = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteTelnet(ServerVO poServer, boolean pbDebug)
/*     */   {
/*  37 */     super(poServer, pbDebug);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteTelnet(ServerVO poServer)
/*     */   {
/*  48 */     this(poServer, false);
/*     */   }
/*     */   
/*     */   public static void setLogger(Logger logger) {
/*  52 */     log = logger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComando()
/*     */   {
/*  64 */     return this.gsComando;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean fncbAbreIO()
/*     */   {
/*  75 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/*  78 */       this.goEntrada = new BufferedReader(new InputStreamReader(((TelnetClient)this.goCliente).getInputStream()));
/*  79 */       this.goSalida = new PrintStream(((TelnetClient)this.goCliente).getOutputStream());
/*  80 */       vbRetorno = true;
/*     */     } catch (Exception EXC) {
/*  82 */       log.error(EXC);
/*  83 */       prcRegistraRespuesta("prcAbreIO:" + EXC.getMessage());
/*  84 */       prcCierraIO();
/*     */     }
/*     */     
/*  87 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcCierraIO()
/*     */   {
/*  97 */     if (this.goEntrada != null) {
/*     */       try {
/*  99 */         this.goEntrada.close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/* 102 */       this.goEntrada = null;
/*     */     }
/* 104 */     if (this.goSalida != null) {
/*     */       try {
/* 106 */         this.goSalida.flush();
/* 107 */         this.goSalida.close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/* 110 */       this.goSalida = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbConecta()
/*     */   {
/* 123 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 126 */       prcLimpiar();
/* 127 */       if (!this.goServer.getHST().equals("")) {
/* 128 */         log.debug(this.goServer);
/* 129 */         this.goCliente = new TelnetClient();
/* 130 */         this.goCliente.connect(this.goServer.getHST());
/* 131 */         if (this.goServer.getTOUT() > 0) {
/* 132 */           this.goCliente.setSoTimeout(this.goServer.getTOUT() * 1000);
/*     */         }
/*     */       }
/*     */       
/* 136 */       if ((fncbConectado()) && (fncbAbreIO())) {
/* 137 */         vbRetorno = true;
/*     */       } else {
/* 139 */         prcDesconecta();
/* 140 */         prcRegistraError("CONNECTION REFUSED");
/*     */       }
/*     */     } catch (Exception EXC) {
/* 143 */       log.error(EXC);
/* 144 */       prcRegistraError(EXC.getMessage());
/*     */     }
/*     */     
/* 147 */     return vbRetorno;
/*     */   }
/*     */   
/*     */   private boolean timeout(long vlTimeout) throws Exception {
/* 151 */     if ((this.goServer.getTOUT() > 0) && (Calendar.getInstance().getTimeInMillis() > vlTimeout)) {
/* 152 */       throw new Exception("TIMEOUT");
/*     */     }
/* 154 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean fncbEspera()
/*     */     throws Exception
/*     */   {
/* 167 */     boolean vbRetorno = false;
/* 168 */     long vlTimeout = Calendar.getInstance().getTimeInMillis() + this.goServer.getTOUT() * 1000;
/*     */     
/* 170 */     log.debug(this.goServer.getHST() + "::Timeout deadline " + DateUtils.fncsFormat("dd/MM/yyyy HH:mm:ss", DateUtils.fncoCalendar(vlTimeout)));
/* 171 */     while (fncbConectado()) {
/*     */       try {
/* 173 */         if (this.goEntrada.ready()) {
/* 174 */           vbRetorno = true;
/*     */         }
/* 176 */         else if (!timeout(vlTimeout)) {
/* 177 */           Thread.sleep(100L);
/*     */         }
/*     */       } catch (SocketTimeoutException voSTE) {
/* 180 */         log.debug(this.goServer.getHST() + "::Port's BufferedReader not ready " + DateUtils.fncsFormat("dd/MM/yyyy HH:mm:ss", Calendar.getInstance()));
/* 181 */         if (!timeout(vlTimeout)) {
/* 182 */           Thread.sleep(100L);
/*     */         }
/*     */       }
/*     */       catch (Exception TOE) {
/* 186 */         log.error(TOE);
/* 187 */         log.debug(this.goServer.getHST() + "::EXIT");
/* 188 */         throw TOE;
/*     */       }
/*     */     }
/*     */     
/* 192 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcEscribeRenglon(String psLinea)
/*     */     throws Exception
/*     */   {
/* 205 */     this.goSalida.println(psLinea);
/* 206 */     this.goSalida.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fncsLeeRenglon()
/*     */     throws Exception
/*     */   {
/* 219 */     return fncbEspera() ? StringUtils.fncsCleanUnprintable(this.goEntrada.readLine()) : "";
/*     */   }
/*     */   
/*     */   private boolean responseMatches(List<String> respuestasEsperadas, String respuestaActual) {
/* 223 */     if (StringUtils.isNVL(respuestaActual.trim())) {
/* 224 */       return false;
/*     */     }
/* 226 */     for (String respuesta : respuestasEsperadas) {
/* 227 */       log.debug(this.goServer.getHST() + "::Comparando " + respuesta.trim().toUpperCase() + " vs " + respuestaActual.trim().toUpperCase());
/* 228 */       if (respuestaActual.trim().toUpperCase().indexOf(respuesta.trim().toUpperCase()) >= 0) {
/* 229 */         return true;
/*     */       }
/*     */     }
/* 232 */     return false;
/*     */   }
/*     */   
/*     */   public boolean fncbRecibeRespuesta(List<String> respuestasEsperadas) {
/* 236 */     boolean vbRetorno = false;
/* 237 */     String vsRenglon = "";
/* 238 */     StringBuffer vsBuffer = new StringBuffer();
/*     */     try
/*     */     {
/*     */       do {
/* 242 */         log.debug(this.goServer.getHST() + "::Esperando " + respuestasEsperadas);
/* 243 */         vsRenglon = fncsLeeRenglon();
/* 244 */         log.debug(this.goServer.getHST() + "::Recibido<<" + vsRenglon);
/* 245 */         if (fncbError(vsRenglon)) {
/* 246 */           prcRegistraError(vsRenglon);
/* 247 */           throw new Exception(vsRenglon); }
/* 248 */         if (vsRenglon.length() > 0) {
/* 249 */           vsBuffer.append("\n").append(vsRenglon);
/*     */         }
/* 251 */       } while (!responseMatches(respuestasEsperadas, vsRenglon));
/*     */       
/* 253 */       vbRetorno = true;
/* 254 */       prcRegistraRespuesta(vsBuffer.toString());
/*     */     } catch (Exception EXC) {
/* 256 */       log.error(EXC);
/*     */     } finally {
/* 258 */       if (vsBuffer != null) {
/* 259 */         vsBuffer = null;
/*     */       }
/*     */     }
/*     */     
/* 263 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbRecibeRespuesta(String psBandera)
/*     */   {
/* 276 */     boolean vbRetorno = false;
/* 277 */     String vsRenglon = "";
/* 278 */     StringBuffer vsBuffer = new StringBuffer();
/*     */     try
/*     */     {
/*     */       do {
/* 282 */         log.debug(this.goServer.getHST() + "::Esperando " + psBandera);
/* 283 */         vsRenglon = fncsLeeRenglon();
/* 284 */         log.debug(this.goServer.getHST() + "::Recibido<<" + vsRenglon);
/* 285 */         if (fncbError(vsRenglon)) {
/* 286 */           prcRegistraError(vsRenglon);
/* 287 */           throw new Exception(vsRenglon); }
/* 288 */         if (vsRenglon.length() > 0) {
/* 289 */           vsBuffer.append("\n").append(vsRenglon);
/*     */         }
/* 291 */       } while (vsRenglon.toUpperCase().indexOf(psBandera.toUpperCase()) < 0);
/*     */       
/* 293 */       vbRetorno = true;
/* 294 */       prcRegistraRespuesta(vsBuffer.toString());
/*     */     } catch (Exception EXC) {
/* 296 */       log.error(EXC);
/*     */     } finally {
/* 298 */       if (vsBuffer != null) {
/* 299 */         vsBuffer = null;
/*     */       }
/*     */     }
/*     */     
/* 303 */     return vbRetorno;
/*     */   }
/*     */   
/*     */   public boolean fncbRecibeRespuesta() {
/* 307 */     return fncbRecibeRespuesta("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbEnviaComando(String psComando)
/*     */   {
/* 320 */     boolean vbRetorno = false;
/*     */     try {
/* 322 */       prcLimpiar();
/* 323 */       log.debug(this.goServer.getHST() + "::Enviado>>" + psComando);
/* 324 */       prcEscribeRenglon(psComando);
/* 325 */       vbRetorno = true;
/*     */     } catch (Exception EXC) {
/* 327 */       log.error(EXC);
/* 328 */       prcRegistraError("fncbEnvia:" + EXC.getMessage());
/*     */     }
/* 330 */     return vbRetorno;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ClienteTelnet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */