/*     */ package com.infomedia.comm;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Calendar;
/*     */ import org.apache.commons.net.telnet.TelnetClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClienteTelnetV1
/*     */ {
/*     */   public static final String CONN_REFUSED = "CONNECTION REFUSED";
/*  23 */   private int giTimeout = 0;
/*     */   
/*  25 */   private boolean gbRespuesta = false;
/*  26 */   private boolean gbError = false;
/*     */   
/*  28 */   private String gsComando = "";
/*  29 */   private String gsRespuesta = "";
/*  30 */   private String gsError = "";
/*     */   
/*  32 */   protected boolean gbDebug = false;
/*     */   
/*  34 */   protected TelnetClient goCliente = null;
/*  35 */   protected BufferedReader goEntrada = null;
/*  36 */   protected PrintStream goSalida = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteTelnetV1(boolean pbDebug)
/*     */   {
/*  46 */     this.gbDebug = pbDebug;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteTelnetV1()
/*     */   {
/*  56 */     this(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/*  67 */     return this.giTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(int piTimeout)
/*     */   {
/*  77 */     this.giTimeout = piTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbError()
/*     */   {
/*  87 */     return this.gbError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbRespuesta()
/*     */   {
/*  97 */     return this.gbRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComando()
/*     */   {
/* 107 */     return this.gsComando;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRespuesta()
/*     */   {
/* 117 */     return this.gsRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getError()
/*     */   {
/* 127 */     return this.gsError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcLimpiar()
/*     */   {
/* 137 */     this.gbRespuesta = false;
/* 138 */     this.gbError = false;
/* 139 */     this.gsComando = "";
/* 140 */     this.gsRespuesta = "";
/* 141 */     this.gsError = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcRegistraError(String psError)
/*     */   {
/* 153 */     this.gbError = true;
/* 154 */     this.gsError = psError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcRegistraRespuesta(String psRespuesta)
/*     */   {
/* 166 */     this.gbRespuesta = true;
/* 167 */     this.gsRespuesta = psRespuesta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean fncbAbreIO()
/*     */   {
/* 179 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 182 */       this.goEntrada = new BufferedReader(new InputStreamReader(this.goCliente.getInputStream()));
/* 183 */       this.goSalida = new PrintStream(this.goCliente.getOutputStream());
/* 184 */       vbRetorno = true;
/*     */     } catch (Exception voEXC) {
/* 186 */       prcRegistraRespuesta("prcAbreIO:" + voEXC.getMessage());
/* 187 */       prcCierraIO();
/*     */     }
/*     */     
/* 190 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcCierraIO()
/*     */   {
/* 201 */     if (this.goEntrada != null) {
/* 202 */       try { this.goEntrada.close(); } catch (Exception voIgnorar) {}
/* 203 */       this.goEntrada = null;
/*     */     }
/* 205 */     if (this.goSalida != null) {
/*     */       try {
/* 207 */         this.goSalida.flush();
/* 208 */         this.goSalida.close();
/*     */       } catch (Exception voIgnorar) {}
/* 210 */       this.goSalida = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbAbrir(String psServidor)
/*     */   {
/* 224 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 227 */       prcLimpiar();
/* 228 */       this.goCliente = new TelnetClient();
/* 229 */       this.goCliente.connect(psServidor);
/* 230 */       if ((fncbConectado()) && (fncbAbreIO())) {
/* 231 */         vbRetorno = true;
/*     */       } else {
/* 233 */         prcCerrar();
/* 234 */         prcRegistraError("CONNECTION REFUSED");
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 237 */       prcRegistraError(voEXC.getMessage());
/*     */     }
/*     */     
/* 240 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcCerrar()
/*     */   {
/*     */     try
/*     */     {
/* 252 */       prcCierraIO();
/*     */       
/* 254 */       if (this.goCliente != null) {
/* 255 */         try { this.goCliente.disconnect(); } catch (Exception voIgnorar) {}
/* 256 */         this.goCliente = null;
/*     */       }
/*     */     }
/*     */     catch (Exception voEXC) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbConectado()
/*     */   {
/* 271 */     return (this.goCliente != null) && (this.goCliente.isConnected());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean fncbEspera()
/*     */     throws Exception
/*     */   {
/* 284 */     boolean vbRetorno = false;
/* 285 */     long vlTimeout = Calendar.getInstance().getTimeInMillis() + this.giTimeout * 1000;
/*     */     
/*     */ 
/* 288 */     while (fncbConectado()) {
/* 289 */       if (this.goEntrada.ready()) {
/* 290 */         vbRetorno = true;
/* 291 */         break;
/*     */       }
/* 293 */       if ((this.giTimeout > 0) && (Calendar.getInstance().getTimeInMillis() > vlTimeout)) throw new Exception("TIMEOUT");
/* 294 */       Thread.sleep(100L);
/*     */     }
/*     */     
/* 297 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcEscribeRenglon(String psLinea)
/*     */     throws Exception
/*     */   {
/* 310 */     this.goSalida.println(psLinea);
/* 311 */     this.goSalida.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fncsLeeRenglon()
/*     */     throws Exception
/*     */   {
/* 324 */     return fncbEspera() ? StringUtils.fncsCleanUnprintable(this.goEntrada.readLine()) : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbRecibeRespuesta(String psBandera)
/*     */   {
/* 337 */     boolean vbRetorno = false;
/* 338 */     String vsRenglon = "";
/* 339 */     StringBuffer vsBuffer = new StringBuffer();
/*     */     try
/*     */     {
/*     */       do {
/* 343 */         vsRenglon = fncsLeeRenglon();
/* 344 */         if (this.gbDebug) System.out.println("Recibido<<" + vsRenglon);
/* 345 */         if (fncbErrorRegistrado(vsRenglon)) {
/* 346 */           prcRegistraError(vsRenglon);
/* 347 */           throw new Exception(vsRenglon); }
/* 348 */         if (vsRenglon.length() > 0) {
/* 349 */           vsBuffer.append("\n" + vsRenglon);
/*     */         }
/* 351 */       } while (vsRenglon.toUpperCase().indexOf(psBandera.toUpperCase()) < 0);
/*     */       
/* 353 */       vbRetorno = true;
/* 354 */       prcRegistraRespuesta(vsBuffer.toString());
/*     */     }
/*     */     catch (Exception voEXC) {}finally {
/* 357 */       if (vsBuffer != null) { vsBuffer = null;
/*     */       }
/*     */     }
/* 360 */     return vbRetorno;
/*     */   }
/*     */   
/* 363 */   public boolean fncbRecibeRespuesta() { return fncbRecibeRespuesta(""); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbEnviaComando(String psComando)
/*     */   {
/* 376 */     boolean vbRetorno = false;
/*     */     try {
/* 378 */       prcLimpiar();
/* 379 */       if (this.gbDebug) System.out.println("Enviado>>" + psComando);
/* 380 */       prcEscribeRenglon(psComando);
/* 381 */       vbRetorno = true;
/*     */     } catch (Exception voEXC) {
/* 383 */       prcRegistraError("fncbEnvia:" + voEXC.getMessage());
/*     */     }
/* 385 */     return vbRetorno;
/*     */   }
/*     */   
/*     */   protected abstract boolean fncbErrorRegistrado(String paramString);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ClienteTelnetV1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */