package com.infomedia.comm;

public abstract interface CommClientInterface
{
  public abstract void setServer(ServerVO paramServerVO);
  
  public abstract ServerVO getServer();
  
  public abstract boolean connect()
    throws Exception;
  
  public abstract boolean isConnected();
  
  public abstract void disconnect();
  
  public abstract boolean login()
    throws Exception;
  
  public abstract boolean login(String paramString1, String paramString2)
    throws Exception;
  
  public abstract void logout();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\CommClientInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */