/*    */ package com.infomedia.comm;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GenericCommClient
/*    */   implements CommClientInterface
/*    */ {
/*    */   public static final String CONN_REFUSED = "CONNECTION REFUSED";
/* 26 */   protected ServerVO goServer = new ServerVO();
/*    */   
/*    */   public GenericCommClient(ServerVO poServer) {
/* 29 */     this.goServer = poServer;
/*    */   }
/*    */   
/*    */   public GenericCommClient(Properties poProperties) throws Exception {
/* 33 */     this(ServerVO.parse(poProperties));
/*    */   }
/*    */   
/* 36 */   public void setServer(ServerVO poServer) { this.goServer = poServer; }
/* 37 */   public ServerVO getServer() { return this.goServer; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\GenericCommClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */