package com.infomedia.comm;

public abstract interface InterfaceClienteCNX
{
  public static final String CNX_HST = "server.host";
  public static final String CNX_PRT = "server.port";
  public static final String CNX_USR = "server.user";
  public static final String CNX_PWD = "server.password";
  public static final String CNX_DBG = "server.debug";
  public static final String CONN_REFUSED = "CONNECTION REFUSED";
  
  public abstract boolean fncbError();
  
  public abstract String getError();
  
  public abstract boolean fncbRespuesta();
  
  public abstract String getRespuesta();
  
  public abstract void setServidor(ServerVO paramServerVO);
  
  public abstract ServerVO getServidor();
  
  public abstract boolean fncbConecta();
  
  public abstract boolean fncbConectado();
  
  public abstract void prcDesconecta();
  
  public abstract boolean fncbLogin();
  
  public abstract boolean fncbLogin(String paramString1, String paramString2);
  
  public abstract void prcLogout();
  
  public abstract Object fncoAccion(String paramString, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\InterfaceClienteCNX.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */