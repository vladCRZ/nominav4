/*     */ package com.infomedia.comm;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import java.io.Serializable;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String SRV_HST = "server.host";
/*     */   public static final String SRV_PRT = "server.port";
/*     */   public static final String SRV_USR = "server.user";
/*     */   public static final String SRV_PWD = "server.password";
/*     */   public static final String SRV_TOUT = "server.timeout";
/*     */   public static final String SRV_TRY = "server.retry";
/*     */   public static final String SRV_HOME = "env.home";
/*     */   public static final int RETRY = 3;
/*     */   public static final int TIMEOUT = 0;
/*  28 */   private String gsHST = "";
/*  29 */   private String gsUSR = "";
/*  30 */   private transient String gsPWD = "";
/*  31 */   private String gsHOME = "";
/*     */   
/*  33 */   private int giPRT = 0;
/*     */   
/*  35 */   private int giTOUT = 0;
/*  36 */   private int giTRY = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerVO() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerVO(String psHST, String psUSR, String psPWD, int piPRT, int piTOUT, int piTRY)
/*     */   {
/*  59 */     this.gsHST = psHST;
/*  60 */     this.gsUSR = psUSR;
/*  61 */     this.gsPWD = psPWD;
/*  62 */     this.giPRT = piPRT;
/*  63 */     this.giTOUT = piTOUT;
/*  64 */     this.giTRY = piTRY;
/*     */   }
/*     */   
/*  67 */   public ServerVO(String psHST, String psUSR, String psPWD, int piPRT, int piTOUT) { this(psHST, psUSR, psPWD, piPRT, piTOUT, 3); }
/*     */   
/*     */   public ServerVO(String psHST, String psUSR, String psPWD, int piPRT) {
/*  70 */     this(psHST, psUSR, psPWD, piPRT, 0);
/*     */   }
/*     */   
/*  73 */   public ServerVO(String psHST, int piPRT, int piTOUT, int piTRY) { this(psHST, "", "", piPRT, piTOUT, piTRY); }
/*     */   
/*     */   public ServerVO(String psHST, int piPRT, int piTOUT) {
/*  76 */     this(psHST, piPRT, piTOUT, 3);
/*     */   }
/*     */   
/*  79 */   public ServerVO(String psHST, int piPRT) { this(psHST, piPRT, 0); }
/*     */   
/*     */ 
/*     */   @Deprecated
/*  83 */   public String getEQP() { return getHST(); }
/*     */   
/*     */   @Deprecated
/*  86 */   public void setEQP(String psEQP) { setHST(psEQP); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHST()
/*     */   {
/*  95 */     return this.gsHST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHST(String psHST)
/*     */   {
/* 104 */     this.gsHST = psHST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUSR()
/*     */   {
/* 113 */     return this.gsUSR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUSR(String psUSR)
/*     */   {
/* 122 */     this.gsUSR = psUSR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPWD()
/*     */   {
/* 131 */     return this.gsPWD;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPWD(String psPWD)
/*     */   {
/* 140 */     this.gsPWD = psPWD;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHOME(String psHOME)
/*     */   {
/* 150 */     this.gsHOME = psHOME;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHOME()
/*     */   {
/* 160 */     return this.gsHOME;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPRT()
/*     */   {
/* 170 */     return this.giPRT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPRT(int piPRT)
/*     */   {
/* 179 */     this.giPRT = piPRT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTRY(int piTRY)
/*     */   {
/* 188 */     this.giTRY = piTRY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTRY()
/*     */   {
/* 198 */     return this.giTRY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTOUT(int piTOUT)
/*     */   {
/* 207 */     this.giTOUT = piTOUT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */   public int getTOUT() { return this.giTOUT; }
/*     */   
/*     */   public static ServerVO parse(Properties poProperties) throws Exception {
/* 220 */     ServerVO voServer = new ServerVO();
/* 221 */     if ((!poProperties.containsKey("server.host")) || (!poProperties.contains("server.port")) || (!poProperties.containsKey("server.user")) || (!poProperties.containsKey("server.password")))
/*     */     {
/*     */ 
/* 224 */       throw new Exception("Server is not defined"); }
/* 225 */     voServer.setHST(poProperties.getProperty("server.host"));
/* 226 */     voServer.setUSR(poProperties.getProperty("server.user"));
/* 227 */     voServer.setPWD(poProperties.getProperty("server.password"));
/* 228 */     voServer.setPRT(Integer.parseInt(poProperties.getProperty("server.port")));
/* 229 */     voServer.setTOUT(poProperties.containsKey("server.timeout") ? Integer.parseInt(poProperties.getProperty("server.timeout")) : 0);
/* 230 */     voServer.setTRY(poProperties.containsKey("server.retry") ? Integer.parseInt(poProperties.getProperty("server.retry")) : 3);
/* 231 */     voServer.setHOME(poProperties.getProperty(poProperties.containsKey("env.home") ? "env.home" : FileUtils.fncsUserHome()));
/* 232 */     return voServer;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 236 */     return "HST=" + this.gsHST + "\nUSR=" + this.gsUSR + "\nPWD=" + this.gsPWD + "\nHOME=" + this.gsHOME + "\nPRT=" + this.giPRT + "\nTOUT=" + this.giTOUT + "\nTRY=" + this.giTRY;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ServerVO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */