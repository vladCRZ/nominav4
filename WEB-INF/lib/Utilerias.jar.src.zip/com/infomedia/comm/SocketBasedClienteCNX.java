/*    */ package com.infomedia.comm;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.net.SocketClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SocketBasedClienteCNX
/*    */   extends ClienteBaseCNX
/*    */ {
/*    */   protected SocketClient goCliente;
/*    */   
/*    */   public SocketBasedClienteCNX(Properties poProperties)
/*    */   {
/* 27 */     super(poProperties);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SocketBasedClienteCNX(ServerVO poServer, boolean pbDebug)
/*    */   {
/* 40 */     super(poServer, pbDebug);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SocketBasedClienteCNX(ServerVO poServer)
/*    */   {
/* 52 */     this(poServer, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean fncbConectado()
/*    */   {
/* 64 */     return (this.goCliente != null) && (this.goCliente.isConnected());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void prcDesconecta()
/*    */   {
/*    */     try
/*    */     {
/* 75 */       if (this.gbDebug) System.out.println("Desconectado...");
/* 76 */       if (fncbConectado()) this.goCliente.disconnect();
/*    */     }
/*    */     catch (Exception voIgnorar) {}finally {
/* 79 */       this.goCliente = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\SocketBasedClienteCNX.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */