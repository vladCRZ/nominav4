/*    */ package com.infomedia.comm;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.Socket;
/*    */ 
/*    */ public class SocketServer
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 12 */     java.net.ServerSocket voSS = null;
/* 13 */     Socket voRequest = null;
/* 14 */     PrintWriter voOut = null;
/* 15 */     BufferedReader voIn = null;
/* 16 */     String vsInput = "";
/* 17 */     String vsOutput = "000236169|08/01/2014|20:08|5|1|6974|b4c207ff-87f2-4d93-dd2c-b838ec393752";
/*    */     try
/*    */     {
/* 20 */       voSS = new java.net.ServerSocket(2231);
/*    */       try
/*    */       {
/*    */         for (;;) {
/* 24 */           System.out.println("Waiting connection");
/* 25 */           voRequest = voSS.accept();
/* 26 */           System.out.println("Request accepted");
/* 27 */           voOut = new PrintWriter(voRequest.getOutputStream());
/* 28 */           voIn = new BufferedReader(new java.io.InputStreamReader(voRequest.getInputStream()));
/* 29 */           System.out.println("IO created\n waiting data");
/* 30 */           if ((vsInput = voIn.readLine()) != null) {
/* 31 */             System.out.println(vsInput);
/*    */           }
/*    */           
/* 34 */           System.out.println("Data received");
/* 35 */           voOut.println(vsOutput);
/* 36 */           voOut.flush();
/*    */           
/*    */ 
/*    */ 
/* 40 */           if (voRequest != null)
/*    */             try {
/* 42 */               voRequest.close();
/* 43 */               voRequest = null;
/*    */             } catch (Exception voIgnore) {}
/* 45 */           if (voOut != null)
/*    */             try {
/* 47 */               voOut.close();
/* 48 */               voOut = null;
/*    */             } catch (Exception voIgnore) {}
/* 50 */           if (voIn != null) {
/*    */             try {
/* 52 */               voIn.close();
/* 53 */               voIn = null;
/*    */             }
/*    */             catch (Exception voIgnore) {}
/*    */           }
/*    */         }
/*    */       }
/*    */       catch (Exception voIO)
/*    */       {
/* 38 */         voIO.printStackTrace();
/*    */       } finally {
/* 40 */         if (voRequest != null)
/*    */           try {
/* 42 */             voRequest.close();
/* 43 */             voRequest = null;
/*    */           } catch (Exception voIgnore) {}
/* 45 */         if (voOut != null)
/*    */           try {
/* 47 */             voOut.close();
/* 48 */             voOut = null;
/*    */           } catch (Exception voIgnore) {}
/* 50 */         if (voIn != null) {
/*    */           try {
/* 52 */             voIn.close();
/* 53 */             voIn = null;
/*    */           }
/*    */           catch (Exception voIgnore) {}
/*    */         }
/*    */       }
/*    */     } catch (Exception voEXC) {
/* 59 */       voEXC.printStackTrace();
/*    */     } finally {
/* 61 */       if (voSS != null) try { voSS.close();
/*    */         }
/*    */         catch (Exception voIgnore) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\SocketServer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */