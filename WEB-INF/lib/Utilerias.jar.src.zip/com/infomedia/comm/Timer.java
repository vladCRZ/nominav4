/*    */ package com.infomedia.comm;
/*    */ 
/*    */ public class Timer extends Thread {
/*  4 */   protected int giRate = 100;
/*  5 */   private int giTimeout = 0;
/*    */   private int giTimeElapsed;
/*  7 */   private boolean gbRunning = true;
/*    */   
/*    */   public Timer(int piTimeout) {
/* 10 */     this.giTimeout = piTimeout;
/*    */   }
/*    */   
/*    */   public synchronized void reset() {
/* 14 */     this.giTimeElapsed = 0;
/*    */   }
/*    */   
/*    */   public void run() {
/* 18 */     while (this.gbRunning) {
/* 19 */       try { Thread.sleep(this.giRate); } catch (InterruptedException ioe) {}
/*    */       continue; synchronized (this) {
/* 21 */         if (this.giTimeElapsed += this.giRate > this.giTimeout) {
/* 22 */           timeout();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void timeout() {
/* 29 */     this.gbRunning = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\Timer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */