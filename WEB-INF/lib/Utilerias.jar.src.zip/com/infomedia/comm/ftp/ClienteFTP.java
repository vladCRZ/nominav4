/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import com.infomedia.comm.ClienteCNX;
/*     */ import com.infomedia.comm.ServerVO;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.net.SocketClient;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.commons.net.ftp.FTPFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClienteFTP
/*     */   extends ClienteCNX
/*     */   implements FTPClientActions
/*     */ {
/*     */   public static final ClienteFTP getInstance(FTPServerVO poServer, boolean pbDebug)
/*     */     throws Exception
/*     */   {
/*  41 */     ClienteFTP voRetorno = new ClienteFTP(poServer, pbDebug);
/*  42 */     if ((!voRetorno.fncbConecta()) || (!voRetorno.fncbLogin())) throw new Exception("Error al iniciar conexión");
/*  43 */     poServer.setHOME(voRetorno.fncsDirectorioActual());
/*  44 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final ClienteFTP getInstance(FTPServerVO poServer)
/*     */     throws Exception
/*     */   {
/*  57 */     return getInstance(poServer, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ClienteFTP(FTPServerVO poServer, boolean pbDebug)
/*     */   {
/*  69 */     super(poServer, pbDebug);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbError(String psError)
/*     */   {
/*  81 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbConecta()
/*     */   {
/*  91 */     boolean vbRetorno = false;
/*  92 */     int viTimeOut = ((FTPServerVO)this.goServer).getTOUT() * 1000;
/*     */     try
/*     */     {
/*  95 */       if (this.goServer.getHST().equals("")) throw new Exception("No se ha definido el equipo");
/*  96 */       prcDesconecta();
/*  97 */       prcLimpiar();
/*  98 */       this.goCliente = new FTPClient();
/*  99 */       ((FTPClient)this.goCliente).setDefaultTimeout(viTimeOut);
/* 100 */       this.goCliente.connect(this.goServer.getHST(), this.goServer.getPRT());
/* 101 */       if ((vbRetorno = this.goCliente.isConnected())) {
/* 102 */         ((FTPClient)this.goCliente).setSoTimeout(0);
/* 103 */         if (this.gbDebug) System.out.println("Conectado con " + this.goServer.getHST() + ":" + this.goServer.getPRT());
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 106 */       prcRegistraError(ClienteFTP.class + ".fncbConecta:" + voEXC.getMessage());
/* 107 */       this.goCliente = null;
/*     */     }
/*     */     
/* 110 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbLogin()
/*     */   {
/* 122 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 125 */       prcLimpiar();
/* 126 */       vbRetorno = ((FTPClient)this.goCliente).login(this.goServer.getUSR(), this.goServer.getPWD());
/* 127 */       if (this.gbDebug) System.out.println("Usuario registrado " + this.goServer.getUSR());
/*     */     } catch (Exception voEXC) {
/* 129 */       prcRegistraError(getClass().getName() + ".fncbLogin:" + voEXC.getMessage());
/*     */     }
/*     */     
/* 132 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcLogout()
/*     */   {
/*     */     try
/*     */     {
/* 143 */       prcLimpiar();
/* 144 */       if (fncbConectado()) ((FTPClient)this.goCliente).logout();
/* 145 */       if (this.gbDebug) System.out.println("Finaliza sesión...");
/*     */     } catch (Exception voEXC) {
/* 147 */       prcRegistraError(getClass().getName() + ".fncbLogout:" + voEXC.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbResume()
/*     */   {
/*     */     try
/*     */     {
/* 159 */       Thread.sleep(1000L); } catch (InterruptedException voIgnorar) {}
/* 160 */     return (fncbConecta()) && (fncbLogin());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcPassive()
/*     */   {
/*     */     try
/*     */     {
/* 170 */       ((FTPClient)this.goCliente).enterLocalPassiveMode();
/*     */     }
/*     */     catch (Exception poIgnorar) {}
/*     */   }
/*     */   
/*     */ 
/*     */   public void prcActive()
/*     */   {
/*     */     try
/*     */     {
/* 180 */       ((FTPClient)this.goCliente).enterLocalActiveMode();
/*     */     }
/*     */     catch (Exception poIgnorar) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String fncsRespuesta()
/*     */   {
/* 191 */     return ((FTPClient)this.goCliente).getReplyString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbCreaDirectorio(String psDirectorio)
/*     */   {
/* 203 */     boolean vbRetorno = false;
/*     */     try {
/* 205 */       vbRetorno = ((FTPClient)this.goCliente).makeDirectory(psDirectorio);
/*     */     } catch (Exception voEXC) {
/* 207 */       prcRegistraError(getClass().getName() + ".fncbCreaDirectorio:" + voEXC.getMessage());
/*     */     }
/* 209 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String fncsDirectorioActual()
/*     */   {
/* 220 */     String vsActual = "";
/*     */     try {
/* 222 */       vsActual = ((FTPClient)this.goCliente).printWorkingDirectory();
/*     */     } catch (Exception voEXC) {
/* 224 */       prcRegistraError(getClass().getName() + ".fncsDirectorioActual:" + voEXC.getMessage());
/*     */     }
/* 226 */     return vsActual;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean esDirectorioActual(String psDirectorio)
/*     */   {
/* 238 */     return (psDirectorio.equals(".")) || (psDirectorio.equals(fncsDirectorioActual()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbCambiaDirectorio(String psDirectorio)
/*     */   {
/* 250 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 253 */       if (esDirectorioActual(psDirectorio)) vbRetorno = true; else
/* 254 */         vbRetorno = ((FTPClient)this.goCliente).changeWorkingDirectory(psDirectorio);
/* 255 */       if (this.gbDebug) System.out.println("Cambiado a " + psDirectorio);
/*     */     } catch (Exception voEXC) {
/* 257 */       prcRegistraError(getClass().getName() + ".fncbCambiaDirectorio:" + voEXC.getMessage());
/*     */     }
/*     */     
/* 260 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<FTPFile> fncoListaFiles(String psDirectorio)
/*     */   {
/* 272 */     FTPFile[] voRetorno = new FTPFile[0];
/*     */     try
/*     */     {
/* 275 */       if (this.gbDebug) System.out.println("Listing " + psDirectorio);
/* 276 */       if (fncbCambiaDirectorio(psDirectorio)) voRetorno = ((FTPClient)this.goCliente).listFiles();
/*     */     } catch (Exception voEXC) {
/* 278 */       prcRegistraError(getClass().getName() + ".fncoListaFiles:" + voEXC.getMessage());
/*     */     }
/*     */     
/* 281 */     return Arrays.asList(voRetorno);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPFile fncoArchivoRemoto(String psDirectorio, String psFileName)
/*     */   {
/* 294 */     FTPFile voRetorno = null;
/*     */     try {
/* 296 */       if (fncbCambiaDirectorio(psDirectorio)) voRetorno = ((FTPClient)this.goCliente).listFiles(psFileName)[0];
/*     */     } catch (Exception voEXC) {
/* 298 */       prcRegistraError(getClass().getName() + ".fncoArchivoRemoto:" + voEXC.getMessage());
/*     */     }
/* 300 */     return voRetorno;
/*     */   }
/*     */   
/* 303 */   public FTPFile fncoArchivoRemoto(String psFileName) { return fncoArchivoRemoto(".", psFileName); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcModifyTime(FTPFile poFile, long piTime)
/*     */   {
/* 316 */     Calendar voModificado = Calendar.getInstance();
/* 317 */     voModificado.setTime(new Date(piTime));
/* 318 */     if (poFile.isFile()) { poFile.setTimestamp((Calendar)voModificado.clone());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcModifyTime(String psFile, long piTime)
/*     */   {
/* 331 */     prcModifyTime(fncoArchivoRemoto(psFile), piTime);
/*     */   }
/*     */   
/*     */   public InputStream getInputStream(String psPath, String psFile) throws IOException {
/* 335 */     InputStream voIS = null;
/*     */     try {
/* 337 */       if (fncbCambiaDirectorio(psPath)) {
/* 338 */         ((FTPClient)this.goCliente).setFileType(((FTPServerVO)this.goServer).getTTR());
/* 339 */         voIS = ((FTPClient)this.goCliente).retrieveFileStream(psFile);
/*     */       }
/*     */     } catch (IOException voIO) {
/* 342 */       throw voIO;
/*     */     }
/* 344 */     return voIS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int fnciRecupera(FTPTransferFile poFile, byte[] poBuffer)
/*     */   {
/* 356 */     InputStream voInput = null;
/* 357 */     byte[] voBuffer = new byte['Ѐ'];
/* 358 */     int viBytes = 0;
/* 359 */     int viTotales = 0;
/*     */     try
/*     */     {
/* 362 */       voInput = getInputStream(poFile.getSourcePath(), poFile.getSourceFile());
/* 363 */       if (voInput != null) {
/* 364 */         poBuffer = new byte[voInput.available()];
/*     */         do
/*     */         {
/* 367 */           viBytes = voInput.read(voBuffer);
/* 368 */           System.arraycopy(voBuffer, 0, poBuffer, viTotales, viBytes);
/* 369 */           viTotales += viBytes;
/* 370 */         } while (viBytes > 0);
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 373 */       voEXC.printStackTrace();
/* 374 */       prcRegistraError(getClass().getName() + ".fncbRecupera:" + voEXC.getMessage());
/*     */     } finally {
/* 376 */       if (voInput != null) try { voInput.close(); } catch (Exception voIgnorar) {}
/* 377 */       voInput = null;
/*     */     }
/*     */     
/* 380 */     return viBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbRecupera(FTPTransferFile poFile)
/*     */   {
/* 393 */     FileOutputStream voOutput = null;
/* 394 */     File voLocal = null;
/* 395 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 398 */       if (this.gbDebug) System.out.println("Transferring file " + poFile);
/* 399 */       if (fncbCambiaDirectorio(poFile.getSourcePath())) {
/* 400 */         voLocal = new File(poFile.getTargetPath(), poFile.getTargetFile());
/* 401 */         voOutput = new FileOutputStream(voLocal);
/* 402 */         ((FTPClient)this.goCliente).setFileType(((FTPServerVO)this.goServer).getTTR());
/* 403 */         vbRetorno = ((FTPClient)this.goCliente).retrieveFile(poFile.getSourceFile(), voOutput);
/* 404 */         voOutput.flush();
/* 405 */         voOutput.close();
/*     */         
/* 407 */         voLocal.setLastModified(poFile.getModificado());
/* 408 */         if (this.gbDebug) System.out.println("Recuperado " + voLocal.getAbsolutePath());
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 411 */       voEXC.printStackTrace();
/* 412 */       prcRegistraError(getClass().getName() + ".fncbRecupera:" + voEXC.getMessage());
/*     */     } finally {
/* 414 */       voOutput = null;
/* 415 */       voLocal = null;
/*     */     }
/*     */     
/* 418 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbEnviaBytes(FTPTransferFile poFile)
/*     */   {
/* 431 */     FileInputStream voInput = null;
/* 432 */     OutputStream voOutput = null;
/* 433 */     File voLocal = null;
/* 434 */     byte[] voBuffer = new byte['Ѐ'];
/* 435 */     boolean vbRetorno = false;
/* 436 */     int viBytes = 0;
/*     */     try
/*     */     {
/* 439 */       if (fncbCambiaDirectorio(poFile.getTargetPath())) {
/* 440 */         voLocal = new File(poFile.getSourcePath(), poFile.getSourceFile());
/* 441 */         voInput = new FileInputStream(voLocal);
/* 442 */         voOutput = ((FTPClient)this.goCliente).storeFileStream(poFile.getTargetFile());
/* 443 */         ((FTPClient)this.goCliente).setFileType(((FTPServerVO)this.goServer).getTTR());
/*     */         do
/*     */         {
/* 446 */           viBytes = voInput.read(voBuffer);
/* 447 */           voOutput.write(voBuffer, 0, viBytes);
/* 448 */           voOutput.flush();
/* 449 */         } while (viBytes > 0);
/*     */         
/* 451 */         voOutput.close();
/* 452 */         voInput.close();
/*     */         
/* 454 */         prcModifyTime(poFile.getTargetFile(), voLocal.lastModified());
/* 455 */         if (this.gbDebug) System.out.println("Enviado " + voLocal.getAbsolutePath());
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 458 */       prcRegistraError(getClass().getName() + ".fncbEnvia:" + voEXC.getMessage());
/*     */     } finally {
/* 460 */       voInput = null;
/* 461 */       voOutput = null;
/* 462 */       voLocal = null;
/*     */     }
/*     */     
/* 465 */     return vbRetorno;
/*     */   }
/*     */   
/*     */   public void send(String psFileName, byte[] poBuffer) throws IOException {
/* 469 */     OutputStream voOutput = null;
/* 470 */     voOutput = ((FTPClient)this.goCliente).storeFileStream(psFileName);
/* 471 */     ((FTPClient)this.goCliente).setFileType(((FTPServerVO)this.goServer).getTTR());
/*     */     
/* 473 */     voOutput.write(poBuffer, 0, poBuffer.length);
/* 474 */     voOutput.flush();
/* 475 */     voOutput.close();
/*     */   }
/*     */   
/*     */   public boolean rename(String psSourcePath, String psSourceFile, String psTargetPath, String psTargetFile) throws IOException {
/* 479 */     return ((FTPClient)this.goCliente).rename(psTargetPath + "/" + psSourceFile, psSourcePath + "/" + psTargetFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbEnvia(FTPTransferFile poFile)
/*     */   {
/* 492 */     FileInputStream voInput = null;
/* 493 */     File voLocal = null;
/* 494 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 497 */       if (fncbCambiaDirectorio(poFile.getTargetPath())) {
/* 498 */         voLocal = new File(poFile.getSourcePath(), poFile.getSourceFile());
/* 499 */         System.out.println("LocalFile:" + voLocal + "::" + voLocal.exists());
/* 500 */         voInput = new FileInputStream(voLocal);
/* 501 */         ((FTPClient)this.goCliente).setFileType(((FTPServerVO)this.goServer).getTTR());
/* 502 */         System.out.println("Writing to :" + poFile.getTargetFile());
/* 503 */         vbRetorno = ((FTPClient)this.goCliente).storeFile(poFile.getTargetFile(), voInput);
/* 504 */         prcModifyTime(poFile.getTargetFile(), voLocal.lastModified());
/* 505 */         if (this.gbDebug) System.out.println("Enviado " + voLocal.getAbsolutePath());
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 508 */       prcRegistraError(getClass().getName() + ".fncbEnvia:" + voEXC.getMessage());
/*     */     } finally {
/* 510 */       if (voInput != null) try { voInput.close(); } catch (Exception e) {}
/* 511 */       voInput = null;
/* 512 */       voLocal = null;
/*     */     }
/*     */     
/* 515 */     return vbRetorno;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\ClienteFTP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */