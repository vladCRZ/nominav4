/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import ch.ethz.ssh2.Connection;
/*     */ import ch.ethz.ssh2.ConnectionMonitor;
/*     */ import ch.ethz.ssh2.SFTPv3Client;
/*     */ import ch.ethz.ssh2.SFTPv3DirectoryEntry;
/*     */ import ch.ethz.ssh2.SFTPv3FileAttributes;
/*     */ import ch.ethz.ssh2.SFTPv3FileHandle;
/*     */ import com.infomedia.comm.ClienteBaseCNX;
/*     */ import com.infomedia.comm.ServerVO;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.http.util.ByteArrayBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClienteSFTP
/*     */   extends ClienteBaseCNX
/*     */   implements FTPClientActions
/*     */ {
/*     */   public class ClienteSFTPMonitor
/*     */     implements ConnectionMonitor
/*     */   {
/*  35 */     private ClienteSFTP goMonitor = null;
/*     */     
/*  37 */     public ClienteSFTPMonitor(ClienteSFTP voCliente) { this.goMonitor = voCliente; }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void connectionLost(Throwable reason)
/*     */     {
/*  51 */       this.goMonitor.setConnected(false);
/*     */     }
/*     */   }
/*     */   
/*  55 */   protected SFTPv3Client goCliente = null;
/*  56 */   protected Connection goConnection = null;
/*  57 */   protected String gsCurrentPath = "";
/*  58 */   protected boolean gbConnected = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClienteSFTP getInstance(SFTPServerVO poServer, boolean pbDebug)
/*     */     throws Exception
/*     */   {
/*  71 */     ClienteSFTP voRetorno = new ClienteSFTP(poServer, pbDebug);
/*  72 */     if ((!voRetorno.fncbConecta()) || (!voRetorno.fncbLogin())) throw new Exception("Error al iniciar conexión");
/*  73 */     poServer.setHOME(voRetorno.fncsDirectorioActual());
/*  74 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final ClienteSFTP getInstance(SFTPServerVO poServer)
/*     */     throws Exception
/*     */   {
/*  87 */     return getInstance(poServer, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ClienteSFTP(FTPServerVO poServer, boolean pbDebug)
/*     */   {
/*  99 */     super(poServer, pbDebug);
/*     */   }
/*     */   
/*     */   public SFTPv3Client getCliente() {
/* 103 */     return this.goCliente;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbError(String psError)
/*     */   {
/* 115 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbConecta()
/*     */   {
/* 125 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 128 */       if (this.goServer.getHST().equals("")) throw new Exception("No se ha definido el equipo");
/* 129 */       prcDesconecta();
/* 130 */       prcLimpiar();
/* 131 */       if (this.gbDebug) System.out.println("Conectando con " + this.goServer.getHST() + ":" + this.goServer.getPRT());
/* 132 */       this.goConnection = new Connection(this.goServer.getHST(), this.goServer.getPRT());
/* 133 */       this.goConnection.addConnectionMonitor(new ClienteSFTPMonitor(this));
/* 134 */       this.goConnection.connect();
/* 135 */       this.gbConnected = true;
/* 136 */       vbRetorno = true;
/* 137 */       if (this.gbDebug) System.out.println("Conectado con " + this.goServer.getHST() + ":" + this.goServer.getPRT());
/*     */     } catch (Exception voEXC) {
/* 139 */       voEXC.printStackTrace();
/* 140 */       prcRegistraError(ClienteSFTP.class + ".fncbConecta:" + voEXC.getMessage());
/* 141 */       this.goCliente = null;
/*     */     }
/*     */     
/* 144 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbLogin()
/*     */   {
/* 156 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 159 */       prcLimpiar();
/* 160 */       if (this.gbDebug) System.out.println("Registrando con usuario " + this.goServer.getUSR());
/* 161 */       if (!this.goConnection.authenticateWithPassword(this.goServer.getUSR(), this.goServer.getPWD())) throw new Exception("Authentication failed!");
/* 162 */       this.goCliente = new SFTPv3Client(this.goConnection);
/* 163 */       this.gsCurrentPath = this.goCliente.canonicalPath(".");
/* 164 */       vbRetorno = true;
/* 165 */       if (this.gbDebug) System.out.println("Usuario registrado " + this.goServer.getUSR());
/*     */     } catch (Exception voEXC) {
/* 167 */       voEXC.printStackTrace();
/* 168 */       prcRegistraError(getClass().getName() + ".fncbLogin:" + voEXC.getMessage());
/*     */     }
/*     */     
/* 171 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcLogout()
/*     */   {
/*     */     try
/*     */     {
/* 182 */       prcLimpiar();
/* 183 */       if (fncbConectado()) prcDesconecta();
/* 184 */       if (this.gbDebug) System.out.println("Finaliza sesión...");
/*     */     } catch (Exception voEXC) {
/* 186 */       prcRegistraError(getClass().getName() + ".fncbLogout:" + voEXC.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbResume()
/*     */   {
/*     */     try
/*     */     {
/* 198 */       Thread.sleep(1000L); } catch (InterruptedException voIgnorar) {}
/* 199 */     return (fncbConecta()) && (fncbLogin());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbCreaDirectorio(String psDirectorio)
/*     */   {
/* 211 */     boolean vbRetorno = false;
/*     */     try {
/* 213 */       this.goCliente.mkdir(psDirectorio, 511);
/* 214 */       vbRetorno = true;
/*     */     } catch (Exception voEXC) {
/* 216 */       prcRegistraError(getClass().getName() + ".fncbCreaDirectorio:" + voEXC.getMessage());
/*     */     }
/* 218 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String fncsDirectorioActual()
/*     */   {
/* 229 */     return this.gsCurrentPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean esDirectorioActual(String psDirectorio)
/*     */   {
/* 241 */     return psDirectorio.equals(".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbCambiaDirectorio(String psDirectorio)
/*     */   {
/* 253 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 256 */       if (!esDirectorioActual(psDirectorio)) {
/* 257 */         if (psDirectorio.equals("..")) {
/* 258 */           this.gsCurrentPath = this.gsCurrentPath.substring(0, this.gsCurrentPath.lastIndexOf("/"));
/*     */         } else {
/* 260 */           this.gsCurrentPath = (this.gsCurrentPath + "/" + psDirectorio);
/*     */         }
/* 262 */         if (this.gbDebug) System.out.println("Cambiado a " + this.gsCurrentPath);
/*     */       }
/* 264 */       vbRetorno = true;
/*     */     } catch (Exception voEXC) {
/* 266 */       prcRegistraError(getClass().getName() + ".fncbCambiaDirectorio:" + voEXC.getMessage());
/*     */     }
/*     */     
/* 269 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<SFTPv3DirectoryEntry> fncoListaFiles(String psDirectorio)
/*     */   {
/* 281 */     List<SFTPv3DirectoryEntry> voRetorno = new ArrayList();
/*     */     try
/*     */     {
/* 284 */       if (fncbCambiaDirectorio(psDirectorio)) {
/* 285 */         for (Object voEntry : this.goCliente.ls(fncsDirectorioActual())) {
/* 286 */           voRetorno.add((SFTPv3DirectoryEntry)voEntry);
/*     */         }
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 290 */       prcRegistraError(getClass().getName() + ".fncoListaFiles:" + voEXC.getMessage());
/*     */     }
/*     */     
/* 293 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SFTPv3FileAttributes fncoArchivoRemoto(String psDirectorio, String psFileName)
/*     */   {
/* 306 */     SFTPv3FileAttributes voRetorno = null;
/*     */     try {
/* 308 */       if (fncbCambiaDirectorio(psDirectorio)) {
/* 309 */         voRetorno = this.goCliente.lstat(fncsDirectorioActual() + "/" + psFileName);
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 312 */       prcRegistraError(getClass().getName() + ".fncoArchivoRemoto:" + voEXC.getMessage());
/*     */     }
/* 314 */     return voRetorno;
/*     */   }
/*     */   
/* 317 */   public SFTPv3FileAttributes fncoArchivoRemoto(String psFileName) { return fncoArchivoRemoto(".", psFileName); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcModifyTime(SFTPv3FileAttributes poFile, long piTime)
/*     */   {
/* 330 */     Calendar voModificado = Calendar.getInstance();
/* 331 */     voModificado.setTime(new Date(piTime));
/* 332 */     if (poFile.isRegularFile()) { poFile.atime = Integer.valueOf((int)voModificado.getTimeInMillis());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcModifyTime(String psFile, long piTime)
/*     */   {
/* 345 */     prcModifyTime(fncoArchivoRemoto(psFile), piTime);
/*     */   }
/*     */   
/*     */   public InputStream getInputStream(String psPath, String psFile) throws IOException {
/* 349 */     SFTPv3FileHandle voFileHandler = null;
/* 350 */     ByteArrayBuffer voContent = new ByteArrayBuffer(1024);
/* 351 */     InputStream voIS = null;
/* 352 */     byte[] voBuffer = new byte['Ѐ'];
/* 353 */     int viReaded = 0;
/* 354 */     int viTotales = 0;
/*     */     try
/*     */     {
/* 357 */       if (fncbCambiaDirectorio(psPath)) {
/* 358 */         voFileHandler = this.goCliente.openFileRO(fncsDirectorioActual() + "/" + psFile);
/* 359 */         while ((viReaded = this.goCliente.read(voFileHandler, viTotales, voBuffer, 0, voBuffer.length)) > 0) {
/* 360 */           viTotales += viReaded;
/* 361 */           voContent.append(voBuffer, 0, viReaded);
/*     */         }
/* 363 */         voIS = new BufferedInputStream(new ByteArrayInputStream(voContent.toByteArray()));
/*     */       }
/*     */     } catch (IOException voEXC) {
/* 366 */       prcRegistraError(getClass().getName() + ".fncbRecupera:" + voEXC.getMessage() + "\n" + fncsDirectorioActual() + "/" + psFile);
/* 367 */       throw voEXC;
/*     */     }
/* 369 */     return voIS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int fnciRecupera(FTPTransferFile poFile, byte[] poBuffer)
/*     */   {
/* 382 */     SFTPv3FileHandle voFileHandler = null;
/* 383 */     ByteArrayBuffer voBufferArray = new ByteArrayBuffer(0);
/* 384 */     byte[] voBuffer = new byte['Ѐ'];
/* 385 */     int viBytes = 0;
/* 386 */     int viTotales = 0;
/*     */     try
/*     */     {
/* 389 */       if (fncbCambiaDirectorio(poFile.getSourcePath())) {
/* 390 */         voFileHandler = this.goCliente.openFileRO(fncsDirectorioActual() + "/" + poFile.getSourceFile());
/*     */         do
/*     */         {
/* 393 */           viBytes = this.goCliente.read(voFileHandler, viTotales, voBuffer, viTotales, voBuffer.length);
/* 394 */           voBufferArray.append(voBuffer, 0, viBytes);
/* 395 */           viTotales += viBytes;
/* 396 */         } while (viBytes > 0);
/*     */       }
/*     */     }
/*     */     catch (Exception voEXC) {
/* 400 */       voEXC.printStackTrace();
/* 401 */       prcRegistraError(getClass().getName() + ".fncbRecupera:" + voEXC.getMessage());
/*     */     } finally {
/* 403 */       poBuffer = voBufferArray.buffer();
/*     */     }
/*     */     
/* 406 */     return viBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbRecupera(FTPTransferFile poFile)
/*     */   {
/* 419 */     FileOutputStream voOutput = null;
/* 420 */     File voLocal = null;
/* 421 */     byte[] voBuffer = null;
/* 422 */     boolean vbRetorno = false;
/*     */     try
/*     */     {
/* 425 */       if (fncbCambiaDirectorio(poFile.getSourcePath())) {
/* 426 */         voLocal = new File(poFile.getTargetPath(), poFile.getTargetFile());
/* 427 */         voOutput = new FileOutputStream(voLocal);
/* 428 */         if (fnciRecupera(poFile, voBuffer) > 0) {
/* 429 */           voOutput.write(voBuffer);
/* 430 */           voOutput.flush();
/* 431 */           voOutput.close();
/*     */         }
/*     */         
/* 434 */         voLocal.setLastModified(poFile.getModificado());
/* 435 */         if (this.gbDebug) System.out.println("Recuperado " + voLocal.getAbsolutePath());
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 438 */       voEXC.printStackTrace();
/* 439 */       prcRegistraError(getClass().getName() + ".fncbRecupera:" + voEXC.getMessage());
/*     */     } finally {
/* 441 */       voOutput = null;
/* 442 */       voLocal = null;
/*     */     }
/*     */     
/* 445 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbEnviaBytes(FTPTransferFile poFile)
/*     */   {
/* 458 */     SFTPv3FileHandle voFileHandler = null;
/* 459 */     FileInputStream voInput = null;
/* 460 */     File voLocal = null;
/* 461 */     byte[] voBuffer = new byte['Ѐ'];
/* 462 */     boolean vbRetorno = false;
/* 463 */     int viBytes = 0;
/* 464 */     int viTotales = 0;
/*     */     try
/*     */     {
/* 467 */       if (this.gbDebug) System.out.println("Enviando " + poFile);
/* 468 */       if (fncbCambiaDirectorio(poFile.getTargetPath())) {
/* 469 */         voFileHandler = this.goCliente.createFile(poFile.getTargetPath() + "/" + poFile.getTargetFile());
/* 470 */         voLocal = new File(poFile.getSourcePath(), poFile.getSourceFile());
/* 471 */         voInput = new FileInputStream(voLocal);
/*     */         do
/*     */         {
/* 474 */           viBytes = voInput.read(voBuffer);
/* 475 */           this.goCliente.write(voFileHandler, viTotales, voBuffer, 0, viBytes);
/* 476 */           viTotales += viBytes;
/* 477 */         } while (viBytes > 0);
/*     */         
/* 479 */         prcModifyTime(poFile.getTargetFile(), voLocal.lastModified());
/* 480 */         if (this.gbDebug) System.out.println("Enviado " + voLocal.getAbsolutePath());
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 483 */       voEXC.printStackTrace();
/* 484 */       prcRegistraError(getClass().getName() + ".fncbEnvia:" + voEXC.getMessage());
/*     */     } finally {
/* 486 */       try { voInput.close(); } catch (Exception poEXC) {}
/* 487 */       voInput = null;
/* 488 */       voLocal = null;
/*     */     }
/*     */     
/* 491 */     return vbRetorno;
/*     */   }
/*     */   
/*     */   public void send(String psFileName, byte[] poBuffer) throws IOException {
/* 495 */     SFTPv3FileHandle voFileHandler = this.goCliente.createFile(psFileName);
/* 496 */     this.goCliente.write(voFileHandler, 0L, poBuffer, 0, poBuffer.length);
/*     */   }
/*     */   
/*     */   public boolean rename(String psSourcePath, String psSourceFile, String psTargetPath, String psTargetFile) throws IOException {
/* 500 */     this.goCliente.mv(psSourcePath + "/" + psSourceFile, psTargetPath + "/" + psTargetFile);
/* 501 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbEnvia(FTPTransferFile poFile)
/*     */   {
/* 514 */     return fncbEnviaBytes(poFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbConectado()
/*     */   {
/* 528 */     return this.gbConnected;
/*     */   }
/*     */   
/*     */   public void setConnected(boolean vbConected) {
/* 532 */     this.gbConnected = vbConected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcDesconecta()
/*     */   {
/*     */     try
/*     */     {
/* 546 */       if (this.goCliente != null) this.goCliente.close();
/* 547 */       if (this.goConnection != null) this.goConnection.close();
/*     */     } catch (Exception poEXC) {
/* 549 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\ClienteSFTP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */