package com.infomedia.comm.ftp;

public abstract interface FTPClientActions
{
  public static final String ACCION_CURRENT_DIR = "fncsDirectorioActual";
  public static final String ACCION_GET_RESP = "fncsRespuesta";
  public static final String ACCION_LIST_FILES = "fncoListaFiles";
  public static final String ACCION_MAKE_DIR = "fncbCreaDirectorio";
  public static final String ACCION_SEND_FILE = "fncbEnvia";
  public static final String ACCION_SET_SERVER = "setServidor";
  public static final String ACCION_SET_TRANSFER = "setTipoTransferencia";
  public static final String ACCION_SET_TRIES = "setIntentos";
  public static final String ACCION_SET_DIR = "fncbCambiaDirectorio";
  public static final String ACCION_RESUME = "fncbResume";
  public static final String ACCION_RETRIEVE_BUFFER = "fnciRecupera";
  public static final String ACCION_RETRIEVE = "fncbRecupera";
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPClientActions.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */