/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FTPMannager
/*     */ {
/*  13 */   protected FTPServerVO goServer = null;
/*  14 */   protected String gsLocalHome = "";
/*  15 */   protected String gsRemoteHome = "";
/*  16 */   protected boolean gbDebug = false;
/*     */   
/*  18 */   protected FTPTransferSchedule goSchedule = new FTPTransferSchedule();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPMannager(FTPServerVO poServer, boolean pbDebug)
/*     */     throws Exception
/*     */   {
/*  30 */     this.gbDebug = pbDebug;
/*  31 */     this.gsLocalHome = FileUtils.fncsUserHome();
/*  32 */     this.goServer = poServer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPMannager() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalHome(String psLocalHome)
/*     */   {
/*  53 */     this.gsLocalHome = psLocalHome;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalHome()
/*     */   {
/*  63 */     return this.gsLocalHome;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteHome(String psRemoteHome)
/*     */   {
/*  73 */     this.gsRemoteHome = psRemoteHome;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRemoteHome()
/*     */   {
/*  83 */     return this.gsRemoteHome;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void prcConnect();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void prcDisconnect();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void prcListing(FTPTransferFile paramFTPTransferFile, boolean paramBoolean, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcListing(String psDir, boolean pbLocal)
/*     */   {
/* 125 */     String vsTarget = (pbLocal ? this.gsRemoteHome : this.gsLocalHome) + "/" + psDir;
/* 126 */     prcListing(new FTPTransferFile(psDir, "", vsTarget, "", 0L, 0L, pbLocal), true, ".*");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void prcTransferring();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void prcProcessDirectorio(String paramString1, String paramString2, boolean paramBoolean1, String paramString3, boolean paramBoolean2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcRecuperaDirectorio(String psSource, String psTarget, boolean pbRecursive, String psRegex)
/*     */   {
/* 166 */     prcProcessDirectorio(psSource, psTarget, pbRecursive, psRegex, false);
/*     */   }
/*     */   
/* 169 */   public void prcRecuperaDirectorio(String psSource, String psTarget, boolean pbRecursive) { prcRecuperaDirectorio(psSource, psTarget, pbRecursive, ".*"); }
/*     */   
/*     */   public void prcRecuperaDirectorio(String psSource, String psTarget) {
/* 172 */     prcRecuperaDirectorio(psSource, psTarget, true);
/*     */   }
/*     */   
/* 175 */   public void prcRecuperaDirectorio(String psSource) { prcRecuperaDirectorio(psSource, this.gsLocalHome + "/" + psSource); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcEnviaDirectorio(String psSource, String psTarget, boolean pbRecursive, String psRegex)
/*     */   {
/* 190 */     prcProcessDirectorio(psSource, psTarget, pbRecursive, psRegex, true);
/*     */   }
/*     */   
/* 193 */   public void prcEnviaDirectorio(String psSource, String psTarget, boolean pbRecursive) { prcEnviaDirectorio(psSource, psTarget, pbRecursive, ".*"); }
/*     */   
/*     */   public void prcEnviaDirectorio(String psSource, String psTarget) {
/* 196 */     prcEnviaDirectorio(psSource, psTarget, true);
/*     */   }
/*     */   
/* 199 */   public void prcEnviaDirectorio(String psSource) { prcEnviaDirectorio(psSource, this.gsRemoteHome + "/" + psSource); }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPMannager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */