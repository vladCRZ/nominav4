/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FTPPool
/*     */ {
/*     */   public static final int MAX_CONNECTIONS = 5;
/*  17 */   protected List<FTPThread> goConnections = new ArrayList();
/*  18 */   protected FTPServerVO goServer = null;
/*  19 */   protected int giConnections = 1;
/*  20 */   protected boolean gbDebug = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPPool(FTPServerVO poServer, int piConnections, boolean pbDebug)
/*     */   {
/*  32 */     this.goServer = poServer;
/*  33 */     this.giConnections = (piConnections > 0 ? piConnections : piConnections > 5 ? 5 : 1);
/*  34 */     this.gbDebug = pbDebug;
/*  35 */     connect();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPPool() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/*  58 */     disconnect();
/*  59 */     super.finalize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void connect()
/*     */   {
/*  69 */     for (int viCont = 0; viCont < this.giConnections; viCont++) {
/*  70 */       try { this.goConnections.add(new FTPThread(ClienteFTP.getInstance(this.goServer, this.gbDebug), this.goConnections.size() + 1));
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/*  81 */     Iterator<FTPThread> voConexiones = this.goConnections.iterator();
/*  82 */     if (this.gbDebug) System.out.println("Finalizando conexiones...");
/*  83 */     while (voConexiones.hasNext()) { ((FTPThread)voConexiones.next()).stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPThread getAvailable()
/*     */   {
/*  95 */     Iterator<FTPThread> voConexiones = this.goConnections.iterator();
/*  96 */     FTPThread voConnection = null;
/*  97 */     FTPThread voReturn = null;
/*     */     do {
/*  99 */       while (voConexiones.hasNext()) {
/* 100 */         voConnection = (FTPThread)voConexiones.next();
/* 101 */         if (voConnection.reserve()) {
/* 102 */           voReturn = voConnection;
/*     */         }
/*     */       }
/*     */       try {
/* 106 */         Thread.sleep(10L);
/* 107 */       } catch (Exception voIgnorar) {} } while (voReturn == null);
/*     */     
/* 109 */     return voReturn;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPPool.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */