/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.net.ftp.FTPFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FTPProcess
/*     */ {
/*     */   private static boolean fncbVerifyRemote(ClienteFTP poClient, String psDirectory)
/*     */   {
/*  30 */     Iterator<String> voPath = Arrays.asList(psDirectory.split("/")).iterator();
/*  31 */     String vsSub = "";
/*  32 */     boolean vbRetorno = false;
/*     */     
/*  34 */     while (voPath.hasNext()) {
/*  35 */       vsSub = (String)voPath.next();
/*  36 */       if (!(vbRetorno = poClient.fncbCambiaDirectorio(vsSub))) {
/*  37 */         vbRetorno = (poClient.fncbCreaDirectorio(vsSub)) && (poClient.fncbCambiaDirectorio(vsSub));
/*     */       }
/*     */     }
/*     */     
/*  41 */     return vbRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean fncbRemote(ClienteFTP poClient, FTPTransferFile poFile)
/*     */     throws Exception
/*     */   {
/*  56 */     return (FileUtils.fncbVerificaDirectorio(poFile.getTargetPath())) && (poClient.fncbRecupera(poFile));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean fncbLocal(ClienteFTP poClient, FTPTransferFile poFile)
/*     */     throws Exception
/*     */   {
/*  72 */     return (FileUtils.fncbExiste(poFile.getSourcePath() + "/" + poFile.getSourceFile())) && (fncbVerifyRemote(poClient, poFile.getTargetPath())) && (poClient.fncbEnvia(poFile));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbTransfer(ClienteFTP poClient, FTPTransferFile poFile)
/*     */     throws Exception
/*     */   {
/*  89 */     return poFile.isLocal() ? fncbLocal(poClient, poFile) : fncbRemote(poClient, poFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<FTPFile> fncoListing(ClienteFTP poClient, String psDirectory)
/*     */   {
/* 103 */     return poClient.fncoListaFiles(psDirectory);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPProcess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */