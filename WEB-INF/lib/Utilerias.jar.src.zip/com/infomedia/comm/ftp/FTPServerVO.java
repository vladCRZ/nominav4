/*    */ package com.infomedia.comm.ftp;
/*    */ 
/*    */ import com.infomedia.comm.ServerVO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FTPServerVO
/*    */   extends ServerVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final int BINARY_TRANSFER = 2;
/*    */   public static final int ASCII_TRANSFER = 0;
/*    */   public static final int DEFAULT_PORT = 21;
/* 24 */   private int giTTR = 2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FTPServerVO() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT, int piTRY, int piTOUT, int piTTR)
/*    */   {
/* 49 */     super(psEQP, psUSR, psPWD, piPRT, piTRY, piTOUT);
/* 50 */     this.giTTR = piTTR;
/*    */   }
/*    */   
/* 53 */   public FTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT, int piTRY, int piTOUT) { this(psEQP, psUSR, psPWD, piPRT, piTRY, piTOUT, 2); }
/*    */   
/*    */   public FTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT, int piTOUT) {
/* 56 */     this(psEQP, psUSR, psPWD, piPRT, piTOUT, 3);
/*    */   }
/*    */   
/* 59 */   public FTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT) { this(psEQP, psUSR, psPWD, piPRT, 0); }
/*    */   
/*    */   public FTPServerVO(String psEQP, String psUSR, String psPWD) {
/* 62 */     this(psEQP, psUSR, psPWD, 21);
/*    */   }
/*    */   
/* 65 */   public FTPServerVO(String psEQP, int piPRT, int piTOUT, int piTRY) { this(psEQP, "", "", piPRT, piTOUT, piTRY); }
/*    */   
/*    */   public FTPServerVO(String psEQP, int piPRT, int piTOUT) {
/* 68 */     this(psEQP, piPRT, piTOUT, 3);
/*    */   }
/*    */   
/* 71 */   public FTPServerVO(String psEQP, int piPRT) { this(psEQP, piPRT, 0); }
/*    */   
/*    */   public FTPServerVO(String psEQP) {
/* 74 */     this(psEQP, 21);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setTTR(int piTTR)
/*    */   {
/* 86 */     this.giTTR = piTTR;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getTTR()
/*    */   {
/* 97 */     return this.giTTR;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPServerVO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */