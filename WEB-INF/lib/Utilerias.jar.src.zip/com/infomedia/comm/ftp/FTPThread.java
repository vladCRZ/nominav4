/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ 
/*     */ public class FTPThread
/*     */   implements Runnable
/*     */ {
/*     */   public static final int DONE = 1;
/*     */   
/*     */   public static final int LISTING = 2;
/*     */   
/*     */   public static final int PASSIVE = 3;
/*     */   
/*     */   public static final int RESERVED = 4;
/*     */   
/*     */   public static final int STOPPED = 5;
/*     */   
/*     */   public static final int TANSFERING = 6;
/*     */   
/*     */   public static final int WAIT = 7;
/*  20 */   private FTPTransferFile goSource = null;
/*  21 */   private Object goListing = null;
/*     */   
/*  23 */   private Thread goProcess = null;
/*  24 */   private ClienteFTP goClient = null;
/*     */   
/*  26 */   private int giID = -1;
/*  27 */   private int giStatus = 7;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPThread(ClienteFTP poClient, int piID)
/*     */   {
/*  38 */     this.goClient = poClient;
/*  39 */     this.giID = piID;
/*  40 */     start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/*  50 */     this.goProcess = new Thread(this, "FTPThread " + this.giID);
/*  51 */     this.goProcess.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/*  60 */     setStatus(5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAvaliable()
/*     */   {
/*  70 */     return (this.giStatus == 3) || (this.giStatus == 7);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean reserve()
/*     */   {
/*  80 */     boolean pbReserved = false;
/*  81 */     synchronized (this) { if ((pbReserved = isAvaliable())) setStatus(4); }
/*  82 */     return pbReserved;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void free()
/*     */   {
/*  92 */     this.goSource = null;
/*  93 */     this.goListing = null;
/*  94 */     setStatus(7);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBusy()
/*     */   {
/* 104 */     return this.giStatus != 7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStopped()
/*     */   {
/* 114 */     return this.giStatus == 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Thread getThread()
/*     */   {
/* 123 */     return this.goProcess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClienteFTP getClient()
/*     */   {
/* 132 */     return this.goClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 141 */     return this.giStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int piStatus)
/*     */   {
/* 151 */     if (!isStopped()) {
/* 152 */       if (piStatus == 3) { this.goClient.prcPassive();
/* 153 */       } else if (this.giStatus == 3) this.goClient.prcActive();
/* 154 */       this.giStatus = piStatus;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSource(FTPTransferFile poSource)
/*     */   {
/* 166 */     this.goSource = poSource;
/* 167 */     setStatus(poSource.isDirectory() ? 2 : 6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferFile getSource()
/*     */   {
/* 177 */     return this.goSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setListing(FTPTransferFile poListing)
/*     */   {
/* 187 */     this.goSource = poListing;
/* 188 */     setStatus(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getListing()
/*     */   {
/* 198 */     return this.goListing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean connectionOK()
/*     */   {
/* 209 */     boolean vbReturn = false;
/*     */     
/* 211 */     if (!(vbReturn = this.goClient.fncbConectado())) {
/* 212 */       try { Thread.sleep(100L); } catch (Exception voIgnorar) {}
/* 213 */       vbReturn = this.goClient.fncbResume();
/*     */     }
/*     */     
/* 216 */     return vbReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 228 */       if (this.goProcess == null) throw new Exception("Error starting thread");
/*     */       do {
/* 230 */         switch (this.giStatus) {
/*     */         case 6: 
/*     */           try {
/* 233 */             if (FTPProcess.fncbTransfer(this.goClient, this.goSource)) this.goSource.transferred(); else
/* 234 */               this.goSource.error();
/*     */           } catch (Exception voTransferError) {
/* 236 */             this.goSource.error();
/*     */           }
/* 238 */           this.giStatus = 1;
/* 239 */           break;
/*     */         case 2: 
/* 241 */           this.goListing = FTPProcess.fncoListing(this.goClient, this.goSource.getSourcePath());
/* 242 */           this.goSource.transferred();
/* 243 */           this.giStatus = 1;
/* 244 */           break;
/*     */         default:  try {
/* 246 */             Thread.sleep(10L);
/*     */           } catch (Exception voIgnorar) {} }
/* 248 */         if (isStopped()) break; } while (connectionOK());
/*     */     } catch (Exception voEXC) {
/* 250 */       this.giStatus = 5;
/*     */     } finally {
/* 252 */       if (this.goClient != null) this.goClient.prcDesconecta();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPThread.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */