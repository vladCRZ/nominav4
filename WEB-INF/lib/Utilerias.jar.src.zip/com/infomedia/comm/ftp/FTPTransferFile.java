/*    */ package com.infomedia.comm.ftp;
/*    */ 
/*    */ import com.infomedia.utils.FileUtils;
/*    */ import com.infomedia.utils.StringUtils;
/*    */ import com.infomedia.utils.WinSOUtils;
/*    */ import java.io.File;
/*    */ import java.util.Calendar;
/*    */ import org.apache.commons.net.ftp.FTPFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FTPTransferFile
/*    */ {
/*    */   public static final int SHEDULLED = 0;
/*    */   public static final int TRANSFERRED = 1;
/*    */   public static final int ERROR = 2;
/* 23 */   private String gsSourcePath = "";
/* 24 */   private String gsSourceFile = "";
/* 25 */   private String gsTargetPath = "";
/* 26 */   private String gsTargetFile = "";
/*    */   
/* 28 */   private long giTamanio = 0L;
/* 29 */   private long giModificado = 0L;
/*    */   
/* 31 */   private int giStatus = 0;
/* 32 */   private boolean gbLocal = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FTPTransferFile(String psSourcePath, String psSourceFile, String psTargetPath, String psTargetFile, long piTamanio, long plModificado, boolean pbLocal)
/*    */   {
/* 49 */     this.gsSourcePath = psSourcePath.replaceAll("\\\\", "/").replaceAll("//", "/");
/* 50 */     this.gsSourceFile = psSourceFile;
/* 51 */     this.gsTargetPath = psTargetPath.replaceAll("\\\\", "/").replaceAll("//", "/");
/* 52 */     this.gsTargetFile = psTargetFile;
/* 53 */     this.giTamanio = piTamanio;
/* 54 */     this.giModificado = plModificado;
/* 55 */     this.gbLocal = pbLocal;
/*    */   }
/*    */   
/* 58 */   public String getSourcePath() { return this.gsSourcePath; }
/* 59 */   public String getSourceFile() { return this.gsSourceFile; }
/* 60 */   public String getTargetPath() { return this.gsTargetPath; }
/* 61 */   public String getTargetFile() { return this.gsTargetFile; }
/* 62 */   public long getTamanio() { return this.giTamanio; }
/* 63 */   public long getModificado() { return this.giModificado; }
/*    */   
/* 65 */   public void transferred() { this.giStatus = 1; }
/* 66 */   public void error() { this.giStatus = 2; }
/* 67 */   public boolean isTransferred() { return this.giStatus == 1; }
/* 68 */   public boolean isError() { return this.giStatus == 2; }
/*    */   
/* 70 */   public boolean isRemote() { return !this.gbLocal; }
/* 71 */   public boolean isLocal() { return this.gbLocal; }
/* 72 */   public boolean isDirectory() { return (this.gsSourceFile.length() == 0) && (this.gsTargetFile.length() == 0); }
/* 73 */   public boolean isFile() { return (this.gsSourceFile.length() > 0) && (this.gsTargetFile.length() > 0); }
/*    */   
/* 75 */   private static boolean isValid(String psName) { return StringUtils.fncbMatches("[\\x20-\\x7E]+", psName); }
/*    */   
/* 77 */   private static FTPTransferFile parse(File poFile, String psSource, String psTarget) throws Exception { if (!isValid(poFile.getName())) throw new Exception("Invalid file name");
/* 78 */     return new FTPTransferFile(psSource, poFile.getName(), psTarget, poFile.getName(), FileUtils.fnciTamanioArchivo(poFile), poFile.lastModified(), true);
/*    */   }
/*    */   
/* 81 */   private static FTPTransferFile parse(FTPFile poFile, String psSource, String psTarget) throws Exception { if (!isValid(poFile.getName())) throw new Exception("Invalid file name");
/* 82 */     if (poFile.isDirectory()) return new FTPTransferFile(psSource + "/" + poFile.getName(), "", psTarget + "/" + WinSOUtils.fncsValidFileName(poFile.getName()), "", 0L, 0L, false);
/* 83 */     return new FTPTransferFile(psSource, poFile.getName(), psTarget, WinSOUtils.fncsValidFileName(poFile.getName()), poFile.getSize(), poFile.getTimestamp().getTimeInMillis(), false);
/*    */   }
/*    */   
/* 86 */   public static FTPTransferFile parse(Object poFile, String psSource, String psTarget) throws Exception { if ((poFile instanceof File)) return parse((File)poFile, psSource, psTarget);
/* 87 */     if ((poFile instanceof FTPFile)) return parse((FTPFile)poFile, psSource, psTarget);
/* 88 */     throw new Exception("Invalid file type " + poFile.getClass().getName() + " or invalid file");
/*    */   }
/*    */   
/* 91 */   public String toString() { return "\nSourcePath=" + this.gsSourcePath + "\nSourceFile=" + this.gsSourceFile + "\nTargetPath=" + this.gsTargetPath + "\nTargetFile=" + this.gsTargetFile + "\nTamaño=" + this.giTamanio + "\nModificado=" + this.giModificado; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPTransferFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */