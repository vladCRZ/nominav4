/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FTPTransferProgress
/*     */ {
/*  11 */   private long giTotalBytes = 0L;
/*  12 */   private long giTotalFiles = 0L;
/*  13 */   private long giTransferBytes = 0L;
/*  14 */   private long giTransferFiles = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferProgress(long piTotalBytes, long piTotalFiles, long piTransferBytes, long piTransferFiles)
/*     */   {
/*  28 */     this.giTotalBytes = piTotalBytes;
/*  29 */     this.giTotalFiles = piTotalFiles;
/*  30 */     this.giTransferBytes = piTransferBytes;
/*  31 */     this.giTransferFiles = piTransferFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferProgress() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/*  52 */     this.giTotalBytes = 0L;
/*  53 */     this.giTotalFiles = 0L;
/*  54 */     this.giTransferBytes = 0L;
/*  55 */     this.giTransferFiles = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTotalBytes()
/*     */   {
/*  66 */     return this.giTotalBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTotalBytes(long piTotalBytes)
/*     */   {
/*  76 */     this.giTotalBytes = piTotalBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTotalBytes(long piBytes)
/*     */   {
/*  86 */     this.giTotalBytes += piBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTotalFiles()
/*     */   {
/*  96 */     return this.giTotalFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTotalFiles(long piTotalFiles)
/*     */   {
/* 106 */     this.giTotalFiles = piTotalFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTotalFiles(long piFiles)
/*     */   {
/* 116 */     this.giTotalFiles += piFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void incTotalFiles()
/*     */   {
/* 125 */     this.giTotalFiles += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTransferBytes()
/*     */   {
/* 135 */     return this.giTransferBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransferBytes(long piTransferBytes)
/*     */   {
/* 145 */     this.giTransferBytes = piTransferBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransferBytes(long piBytes)
/*     */   {
/* 155 */     this.giTransferBytes += piBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTransferFiles()
/*     */   {
/* 165 */     return this.giTransferFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransferFiles(long piTransferFiles)
/*     */   {
/* 175 */     this.giTransferFiles = piTransferFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTransferFiles(long piFiles)
/*     */   {
/* 185 */     this.giTransferFiles += piFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void incTransferFiles()
/*     */   {
/* 194 */     this.giTransferFiles += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getProgressFiles()
/*     */   {
/* 204 */     return this.giTransferFiles * 100.0D / this.giTotalFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getProgressBytes()
/*     */   {
/* 214 */     return this.giTransferBytes * 100.0D / this.giTotalBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copy(FTPTransferProgress poProgress)
/*     */   {
/* 225 */     this.giTotalBytes = poProgress.getTotalBytes();
/* 226 */     this.giTotalFiles = poProgress.getTotalFiles();
/* 227 */     this.giTransferBytes = poProgress.getTransferBytes();
/* 228 */     this.giTransferFiles = poProgress.getTransferFiles();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPTransferProgress.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */