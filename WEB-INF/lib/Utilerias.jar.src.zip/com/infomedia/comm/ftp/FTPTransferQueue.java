/*    */ package com.infomedia.comm.ftp;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FTPTransferQueue
/*    */   extends ArrayList<FTPTransferFile>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 15 */   private long giTransferSize = 0L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isEmpty()
/*    */   {
/* 35 */     return size() == 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public long transferSize()
/*    */   {
/* 45 */     return this.giTransferSize;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean add(FTPTransferFile poFile)
/*    */   {
/* 57 */     boolean vbReturn = false;
/* 58 */     this.giTransferSize += poFile.getTamanio();
/* 59 */     vbReturn = super.add(poFile);
/* 60 */     return vbReturn;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void clear()
/*    */   {
/* 71 */     this.giTransferSize = 0L;
/* 72 */     super.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPTransferQueue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */