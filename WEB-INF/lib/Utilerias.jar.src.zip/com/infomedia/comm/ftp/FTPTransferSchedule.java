/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FTPTransferSchedule
/*     */ {
/*     */   public static final int QUEUE_LISTING = 1;
/*     */   public static final int QUEUE_LISTED = 2;
/*     */   public static final int QUEUE_TRANSFER = 3;
/*     */   public static final int QUEUE_TRANSFERRED = 4;
/*     */   public static final int QUEUE_ERROR = 5;
/*  22 */   private FTPTransferQueue goListing = new FTPTransferQueue();
/*  23 */   private FTPTransferQueue goListed = new FTPTransferQueue();
/*  24 */   private FTPTransferQueue goTransfering = new FTPTransferQueue();
/*  25 */   private FTPTransferQueue goTransferred = new FTPTransferQueue();
/*  26 */   private FTPTransferQueue goError = new FTPTransferQueue();
/*     */   
/*  28 */   private String gsFilter = ".*";
/*  29 */   private boolean gbRecursive = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilter(String psFilter)
/*     */   {
/*  39 */     this.gsFilter = psFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilter()
/*     */   {
/*  49 */     return this.gsFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecursive(boolean pbRecursive)
/*     */   {
/*  59 */     this.gbRecursive = pbRecursive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRecursive()
/*     */   {
/*  69 */     return this.gbRecursive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  79 */     this.goListing.clear();
/*  80 */     this.goListed.clear();
/*  81 */     this.goTransferred.clear();
/*  82 */     this.goTransfering.clear();
/*  83 */     this.goError.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  94 */     return (this.goListing.isEmpty()) && (this.goTransfering.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTransferingTask()
/*     */   {
/* 104 */     return !this.goTransfering.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasListingTask()
/*     */   {
/* 114 */     return !this.goListing.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTask()
/*     */   {
/* 124 */     return (hasListingTask()) || (hasTransferingTask());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferProgress getProgress()
/*     */   {
/* 135 */     return new FTPTransferProgress(this.goTransfering.transferSize(), this.goTransfering.size(), this.goTransferred.transferSize(), this.goTransferred.size());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferQueue getError()
/*     */   {
/* 146 */     return this.goError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enqueue(FTPTransferFile poFile, int piQueue)
/*     */   {
/* 158 */     switch (piQueue) {
/* 159 */     case 5:  this.goError.add(poFile); break;
/* 160 */     case 2:  this.goListed.add(poFile); break;
/* 161 */     case 1:  this.goListing.add(poFile); break;
/* 162 */     case 3:  this.goTransfering.add(poFile); break;
/* 163 */     case 4:  this.goTransferred.add(poFile);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enqueue(FTPTransferFile poFile)
/*     */   {
/* 175 */     enqueue(poFile, poFile.isDirectory() ? 1 : 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferFile dequeue(int piQueue)
/*     */   {
/* 187 */     FTPTransferFile voFile = null;
/* 188 */     switch (piQueue) {
/* 189 */     case 1:  voFile = (FTPTransferFile)this.goListing.remove(0); break;
/* 190 */     case 3:  voFile = (FTPTransferFile)this.goTransfering.remove(0);
/*     */     }
/* 192 */     return voFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enqueueAll(List<?> poFiles, String psSource, String psTarget)
/*     */   {
/* 206 */     Iterator<?> voFiles = poFiles.iterator();
/* 207 */     while (voFiles.hasNext()) {
/*     */       try {
/* 209 */         FTPTransferFile voFile = FTPTransferFile.parse(voFiles.next(), psSource, psTarget);
/* 210 */         if (voFile.isDirectory()) enqueue(voFile, 1); else {
/* 211 */           enqueue(voFile, 3);
/*     */         }
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enqueueAll(List<?> poFiles, FTPTransferFile poDirectory)
/*     */   {
/* 226 */     enqueueAll(poFiles, poDirectory.getSourcePath(), poDirectory.getTargetPath());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcResults(FTPTransferFile poFile, Object poResult)
/*     */   {
/* 239 */     if (poFile.isDirectory()) {
/* 240 */       enqueue(poFile, 2);
/* 241 */       enqueueAll((List)poResult, poFile);
/* 242 */     } else if (poFile.isTransferred()) {
/* 243 */       enqueue(poFile, 4);
/* 244 */     } else if (poFile.isError()) {
/* 245 */       enqueue(poFile, 5);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\FTPTransferSchedule.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */