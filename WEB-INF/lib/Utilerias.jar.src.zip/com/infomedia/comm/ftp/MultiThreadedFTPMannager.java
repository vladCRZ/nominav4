/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiThreadedFTPMannager
/*     */   extends FTPMannager
/*     */ {
/*     */   private class FTPTransferPool
/*     */     extends FTPPool
/*     */     implements Runnable
/*     */   {
/*     */     public static final int PROCESS_LISTING = 1;
/*     */     public static final int PROCESS_TRANFER = 2;
/*     */     public static final int PROCESS_WAITING = 3;
/*  23 */     private Thread goThread = null;
/*     */     
/*  25 */     private int giProcess = 3;
/*  26 */     private int giActive = 0;
/*     */     
/*  28 */     private boolean gbRunning = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected FTPTransferPool(FTPServerVO poServer, int piConnections, boolean pbDebug)
/*     */     {
/*  40 */       super(piConnections, pbDebug);
/*  41 */       start();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void start()
/*     */     {
/*  51 */       this.goThread = new Thread(this);
/*  52 */       this.goThread.start();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void prcStop()
/*     */     {
/*  63 */       if (this.gbDebug) System.out.println("Stopping...");
/*  64 */       this.gbRunning = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void setProcess(int piProcess)
/*     */     {
/*  75 */       this.giProcess = piProcess;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean hasActiveProcess()
/*     */     {
/*  85 */       return this.giActive > 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isListing()
/*     */     {
/*  95 */       return (this.giProcess == 1) && (MultiThreadedFTPMannager.this.goSchedule.hasListingTask());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isTransferring()
/*     */     {
/* 105 */       return (this.giProcess == 2) && (MultiThreadedFTPMannager.this.goSchedule.hasTransferingTask());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isWaiting()
/*     */     {
/* 115 */       return this.giProcess == 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isConnected()
/*     */     {
/* 124 */       return this.goConnections.size() > 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean isRunning()
/*     */     {
/* 133 */       return this.gbRunning;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private FTPTransferFile fncoDequeue()
/*     */     {
/* 144 */       return isListing() ? MultiThreadedFTPMannager.this.goSchedule.dequeue(1) : MultiThreadedFTPMannager.this.goSchedule.dequeue(3);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void prcAssign(FTPThread poConnection)
/*     */     {
/* 156 */       if (((isListing()) && (poConnection.reserve())) || ((isTransferring()) && (poConnection.reserve())))
/*     */       {
/* 158 */         poConnection.setSource(fncoDequeue());
/* 159 */         this.giActive += 1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void prcDone(FTPThread poConnection)
/*     */     {
/* 172 */       MultiThreadedFTPMannager.this.goSchedule.prcResults(poConnection.getSource(), poConnection.getListing());
/* 173 */       poConnection.free();
/* 174 */       this.giActive -= 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void prcStatusConnection(FTPThread poConnection)
/*     */     {
/* 186 */       switch (poConnection.getStatus()) {
/*     */       case 1: 
/* 188 */         prcDone(poConnection);
/* 189 */         break;
/*     */       case 7: 
/* 191 */         prcAssign(poConnection);
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void run()
/*     */     {
/* 204 */       Iterator<FTPThread> voConnectiones = null;
/* 205 */       FTPThread voThread = null;
/*     */       try {
/*     */         do {
/* 208 */           voConnectiones = this.goConnections.iterator();
/* 209 */           while (voConnectiones.hasNext()) {
/* 210 */             voThread = (FTPThread)voConnectiones.next();
/* 211 */             if (voThread.isStopped()) voConnectiones.remove(); else
/* 212 */               prcStatusConnection(voThread);
/*     */           }
/* 214 */           try { Thread.sleep(10L); } catch (InterruptedException voIgnorar) {}
/* 215 */           if (!isRunning()) break; } while (isConnected());
/*     */       }
/*     */       catch (Exception voIgnorar) {}finally {
/* 218 */         disconnect();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 223 */   private FTPTransferPool goTransfer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultiThreadedFTPMannager(FTPServerVO poServer, boolean pbDebug)
/*     */     throws Exception
/*     */   {
/* 235 */     super(poServer, pbDebug);
/* 236 */     prcConnect();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultiThreadedFTPMannager(FTPServerVO poServer)
/*     */     throws Exception
/*     */   {
/* 248 */     this(poServer, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcConnect()
/*     */   {
/* 259 */     this.goTransfer = new FTPTransferPool(this.goServer, 5, this.gbDebug);
/* 260 */     this.gsRemoteHome = this.goServer.getHOME();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcDisconnect()
/*     */   {
/* 272 */     this.goTransfer.prcStop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTransfering()
/*     */   {
/* 283 */     return (this.goTransfer.isTransferring()) || (this.goTransfer.hasActiveProcess());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isListing()
/*     */   {
/* 293 */     return (this.goTransfer.isListing()) || (this.goTransfer.hasActiveProcess());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isProcessing()
/*     */   {
/* 303 */     return (isListing()) || (isTransfering()) || (this.goTransfer.hasActiveProcess());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWaiting()
/*     */   {
/* 313 */     return this.goTransfer.isWaiting();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferProgress getProgress()
/*     */   {
/* 323 */     return this.goSchedule.getProgress();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPTransferQueue getError()
/*     */   {
/* 333 */     return this.goSchedule.getError();
/*     */   }
/*     */   
/*     */ 
/*     */   public void prcWaitProcess()
/*     */   {
/*     */     do
/*     */     {
/*     */       try
/*     */       {
/* 343 */         Thread.sleep(1000L); } catch (Exception voIgnorar) {} } while (isProcessing());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcRemoteListing(FTPTransferFile poFile, boolean pbRecursive, String psRegex)
/*     */   {
/* 357 */     this.goSchedule.setFilter(psRegex);
/* 358 */     this.goSchedule.setRecursive(pbRecursive);
/* 359 */     this.goTransfer.setProcess(1);
/* 360 */     this.goSchedule.enqueue(poFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcLocalListing(FTPTransferFile poFile, boolean pbRecursive, String psRegex)
/*     */   {
/* 374 */     List<File> voFiles = null;
/* 375 */     Iterator<File> voSubdirectorios = null;
/*     */     try
/*     */     {
/* 378 */       voFiles = FileUtils.fncoListaArchivos(poFile.getSourcePath());
/* 379 */       this.goSchedule.setFilter(psRegex);
/* 380 */       this.goSchedule.enqueueAll(FileUtils.fncoFiltroNombre(voFiles, psRegex), poFile.getSourcePath(), poFile.getTargetPath());
/* 381 */       if (pbRecursive) {
/* 382 */         voSubdirectorios = FileUtils.fncoFiltroTipo(voFiles, 2).iterator();
/* 383 */         while (voSubdirectorios.hasNext()) {
/* 384 */           File voFile = (File)voSubdirectorios.next();
/* 385 */           prcLocalListing(new FTPTransferFile(poFile.getSourcePath() + "/" + voFile.getName(), "", poFile.getTargetPath() + "/" + voFile.getName(), "", 0L, 0L, true), pbRecursive, psRegex);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception voEXC) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcListing(FTPTransferFile poFile, boolean pbRecursive, String psRegex)
/*     */   {
/* 403 */     if (poFile.isLocal()) prcLocalListing(poFile, pbRecursive, psRegex); else {
/* 404 */       prcRemoteListing(poFile, pbRecursive, psRegex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcTransferring()
/*     */   {
/* 415 */     this.goTransfer.setProcess(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcProcessDirectorio(String psSource, String psTarget, boolean pbRecursive, String psRegex, boolean pbLocal)
/*     */   {
/* 431 */     prcListing(new FTPTransferFile(psSource, "", psTarget, "", 0L, 0L, pbLocal), pbRecursive, psRegex);
/* 432 */     prcWaitProcess();
/* 433 */     prcTransferring();
/* 434 */     prcWaitProcess();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] psParametros)
/*     */   {
/* 446 */     MultiThreadedFTPMannager voFTP = null;
/*     */     try
/*     */     {
/* 449 */       voFTP = new MultiThreadedFTPMannager(new FTPServerVO("10.160.2.29", "administrator", "plzmg2", 21, 5), true);
/* 450 */       voFTP.prcRecuperaDirectorio("/d");
/*     */     } catch (Exception poEXC) {
/* 452 */       poEXC.printStackTrace();
/*     */     } finally {
/* 454 */       if (voFTP != null) {
/* 455 */         voFTP.prcDisconnect();
/* 456 */         voFTP = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\MultiThreadedFTPMannager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */