/*    */ package com.infomedia.comm.ftp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SFTPServerVO
/*    */   extends FTPServerVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int DEFAULT_SFTP_PORT = 22;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SFTPServerVO() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SFTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT, int piTRY, int piTOUT, int piTTR)
/*    */   {
/* 38 */     super(psEQP, psUSR, psPWD, piPRT, piTRY, piTOUT);
/* 39 */     setTTR(piTTR);
/*    */   }
/*    */   
/* 42 */   public SFTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT, int piTRY, int piTOUT) { this(psEQP, psUSR, psPWD, piPRT, piTRY, piTOUT, 2); }
/*    */   
/*    */   public SFTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT, int piTOUT) {
/* 45 */     this(psEQP, psUSR, psPWD, piPRT, piTOUT, 3);
/*    */   }
/*    */   
/* 48 */   public SFTPServerVO(String psEQP, String psUSR, String psPWD, int piPRT) { this(psEQP, psUSR, psPWD, piPRT, 0); }
/*    */   
/*    */   public SFTPServerVO(String psEQP, String psUSR, String psPWD) {
/* 51 */     this(psEQP, psUSR, psPWD, 22);
/*    */   }
/*    */   
/* 54 */   public SFTPServerVO(String psEQP, int piPRT, int piTOUT, int piTRY) { this(psEQP, "", "", piPRT, piTOUT, piTRY); }
/*    */   
/*    */   public SFTPServerVO(String psEQP, int piPRT, int piTOUT) {
/* 57 */     this(psEQP, piPRT, piTOUT, 3);
/*    */   }
/*    */   
/* 60 */   public SFTPServerVO(String psEQP, int piPRT) { this(psEQP, piPRT, 0); }
/*    */   
/*    */   public SFTPServerVO(String psEQP) {
/* 63 */     this(psEQP, 22);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\SFTPServerVO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */