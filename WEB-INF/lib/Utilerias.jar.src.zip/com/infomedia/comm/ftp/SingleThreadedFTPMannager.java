/*     */ package com.infomedia.comm.ftp;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleThreadedFTPMannager
/*     */   extends FTPMannager
/*     */ {
/*  15 */   private ClienteFTP goTransfer = null;
/*  16 */   private FTPTransferProgress goProgress = new FTPTransferProgress();
/*  17 */   private boolean gbListing = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SingleThreadedFTPMannager(FTPServerVO poServidor, boolean pbDebug)
/*     */     throws Exception
/*     */   {
/*  29 */     super(poServidor, pbDebug);
/*  30 */     prcConnect();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SingleThreadedFTPMannager(FTPServerVO poServidor)
/*     */     throws Exception
/*     */   {
/*  42 */     this(poServidor, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTransfering()
/*     */   {
/*  53 */     return !this.gbListing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isListing()
/*     */   {
/*  63 */     return this.gbListing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProgress(FTPTransferProgress poProgress)
/*     */   {
/*  73 */     this.goProgress = poProgress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcConnect()
/*     */   {
/*     */     try
/*     */     {
/*  84 */       this.goTransfer = ClienteFTP.getInstance(this.goServer, this.gbDebug);
/*  85 */       this.gsRemoteHome = this.goServer.getHOME();
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcDisconnect()
/*     */   {
/*  98 */     this.goTransfer.prcDesconecta();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcListing(FTPTransferFile poFile, boolean pbRecursive, String psRegex)
/*     */   {
/* 113 */     FTPTransferFile voFile = null;
/* 114 */     Iterator<?> voFiles = null;
/*     */     try {
/* 116 */       if (poFile.isDirectory()) {
/* 117 */         this.gbListing = true;
/* 118 */         this.goSchedule.setFilter(psRegex);
/* 119 */         voFiles = poFile.isLocal() ? FileUtils.fncoListaArchivos(poFile.getSourcePath()).iterator() : this.goTransfer.fncoListaFiles(poFile.getSourcePath()).iterator();
/* 120 */         while (voFiles.hasNext()) {
/*     */           try {
/* 122 */             voFile = FTPTransferFile.parse(voFiles.next(), poFile.getSourcePath(), poFile.getTargetPath());
/* 123 */             if (voFile.isFile()) { this.goSchedule.enqueue(voFile);
/* 124 */             } else if (pbRecursive) prcListing(voFile, pbRecursive, psRegex);
/* 125 */             this.goProgress.copy(this.goSchedule.getProgress());
/*     */           }
/*     */           catch (Exception voEXC) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception voEXC) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbTransfer(FTPTransferFile poFile)
/*     */   {
/* 142 */     return poFile.isLocal() ? this.goTransfer.fncbEnvia(poFile) : this.goTransfer.fncbRecupera(poFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcTransferring()
/*     */   {
/* 153 */     if (this.goSchedule.hasTransferingTask()) this.gbListing = false;
/* 154 */     while (this.goSchedule.hasTransferingTask()) {
/* 155 */       FTPTransferFile voFile = this.goSchedule.dequeue(3);
/* 156 */       if (fncbTransfer(voFile)) voFile.transferred(); else
/* 157 */         voFile.error();
/* 158 */       this.goSchedule.prcResults(voFile, null);
/* 159 */       this.goProgress.copy(this.goSchedule.getProgress());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prcProcessDirectorio(String psSource, String psTarget, boolean pbRecursive, String psRegex, boolean pbLocal)
/*     */   {
/* 176 */     prcListing(new FTPTransferFile(psSource, "", psTarget, "", 0L, 0L, pbLocal), pbRecursive, psRegex);
/* 177 */     prcTransferring();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] psParametros)
/*     */   {
/* 189 */     SingleThreadedFTPMannager voFTP = null;
/*     */     try
/*     */     {
/* 192 */       voFTP = new SingleThreadedFTPMannager(new FTPServerVO("10.163.2.53", "administrator", "vjzmg3"), true);
/* 193 */       voFTP.prcRecuperaDirectorio("/c");
/*     */     } catch (Exception poEXC) {
/* 195 */       poEXC.printStackTrace();
/*     */     } finally {
/* 197 */       if (voFTP != null) {
/* 198 */         voFTP = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\comm\ftp\SingleThreadedFTPMannager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */