/*    */ package com.infomedia.context;
/*    */ 
/*    */ import com.infomedia.utils.PropertyLoader;
/*    */ import java.util.Hashtable;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Properties;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import javax.naming.Reference;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class APPContext
/*    */ {
/* 26 */   private static final Logger log = Logger.getLogger(APPContext.class);
/* 27 */   private static final APPContext INSTANCE = new APPContext();
/* 28 */   private Properties goProperties = new Properties();
/* 29 */   private Context goContext = null;
/*    */   
/*    */ 
/*    */ 
/*    */   private static void init()
/*    */     throws NamingException
/*    */   {
/* 36 */     Hashtable<Object, Object> voEnviroment = new Hashtable();
/* 37 */     INSTANCE.goContext = new InitialContext(voEnviroment);
/*    */   }
/*    */   
/*    */   public static void clear() {
/* 41 */     getInstance().goProperties.clear();
/*    */   }
/*    */   
/*    */   public static void config(String psConfigurationFile) {
/* 45 */     getInstance().goProperties = PropertyLoader.load(psConfigurationFile);
/*    */   }
/*    */   
/*    */   public static void config(Properties poProperties) {
/* 49 */     for (Map.Entry<Object, Object> voEntry : poProperties.entrySet()) {
/* 50 */       getInstance().goProperties.setProperty((String)voEntry.getKey(), (String)voEntry.getValue());
/*    */     }
/*    */   }
/*    */   
/*    */   public static APPContext getInstance() {
/* 55 */     synchronized (INSTANCE) {
/* 56 */       if (INSTANCE.goContext == null) {
/*    */         try {
/* 58 */           init();
/*    */         } catch (NamingException NE) {
/* 60 */           log.error(NE);
/*    */         }
/*    */       }
/*    */     }
/* 64 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   public Context getContext() {
/* 68 */     return this.goContext;
/*    */   }
/*    */   
/*    */   public Properties getProperties() {
/* 72 */     return this.goProperties;
/*    */   }
/*    */   
/*    */   public static boolean hasInitParameter(String psParameter) {
/* 76 */     return getInstance().goProperties.containsKey(psParameter);
/*    */   }
/*    */   
/*    */   public static void setENV(String psKey, String psValue) throws NamingException {
/* 80 */     getInstance().getContext().removeFromEnvironment(psKey);
/* 81 */     getInstance().getContext().addToEnvironment(psKey, psValue);
/*    */   }
/*    */   
/*    */   public static String getInitParameter(String psParameter) {
/* 85 */     return (String)getInstance().goProperties.get(psParameter);
/*    */   }
/*    */   
/*    */   public static void setInitParameter(String psParameter, String psValue) {
/* 89 */     getInstance().goProperties.put(psParameter, psValue);
/*    */   }
/*    */   
/*    */   public static void addReference(String psName, Reference poReference) throws NamingException {
/* 93 */     getInstance().getContext().rebind(psName, poReference);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\context\APPContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */