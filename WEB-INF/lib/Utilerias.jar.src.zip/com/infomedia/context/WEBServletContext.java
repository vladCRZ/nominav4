/*    */ package com.infomedia.context;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WEBServletContext
/*    */ {
/* 15 */   private static final WEBServletContext INSTANCE = new WEBServletContext();
/* 16 */   private ServletContext goContext = null;
/*    */   
/*    */ 
/* 19 */   public static WEBServletContext getInstance() { return INSTANCE; }
/* 20 */   public ServletContext getContext() { return this.goContext; }
/* 21 */   public void setContext(ServletContext poContext) { if (!isInitialized()) this.goContext = poContext; }
/* 22 */   public static String getInitParameter(String psParameter) { return INSTANCE.goContext.getInitParameter(psParameter); }
/* 23 */   public static boolean isInitialized() { return INSTANCE.goContext != null; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\context\WEBServletContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */