/*    */ package com.infomedia.database;
/*    */ 
/*    */ import javax.sql.ConnectionPoolDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionPoolMannager
/*    */ {
/* 24 */   private ConnectionPoolDataSource goDataSource = null;
/* 25 */   private int giMaxConnections = 1;
/* 26 */   private int giActiveConnections = 0;
/* 27 */   private int giTimeout = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConnectionPoolMannager(ConnectionPoolDataSource poDataSource, int piMaxConnections, int piTimeout)
/*    */   {
/* 40 */     this.goDataSource = poDataSource;
/* 41 */     this.giActiveConnections = piMaxConnections;
/* 42 */     this.giTimeout = piTimeout;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\ConnectionPoolMannager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */