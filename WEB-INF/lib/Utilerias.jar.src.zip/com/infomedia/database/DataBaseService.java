/*    */ package com.infomedia.database;
/*    */ 
/*    */ import com.infomedia.context.APPContext;
/*    */ import com.infomedia.integration.Service;
/*    */ import javax.naming.Reference;
/*    */ import javax.naming.StringRefAddr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataBaseService
/*    */   implements Service
/*    */ {
/*    */   public Reference getReference()
/*    */   {
/* 20 */     Reference voDataBaseReference = new Reference("javax.sql.DataSource", "org.apache.commons.dbcp.BasicDataSourceFactory", null);
/* 21 */     voDataBaseReference.add(new StringRefAddr("driverClassName", APPContext.getInitParameter("database.driverClassName")));
/* 22 */     voDataBaseReference.add(new StringRefAddr("url", APPContext.getInitParameter("database.url")));
/* 23 */     voDataBaseReference.add(new StringRefAddr("username", APPContext.getInitParameter("database.username")));
/* 24 */     voDataBaseReference.add(new StringRefAddr("password", APPContext.getInitParameter("database.password")));
/* 25 */     return voDataBaseReference;
/*    */   }
/*    */   
/* 28 */   public boolean isDefined() { return (APPContext.hasInitParameter("database.driverClassName")) && (APPContext.hasInitParameter("database.url")) && (APPContext.hasInitParameter("database.username")) && (APPContext.hasInitParameter("database.password")); }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\DataBaseService.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */