/*    */ package com.infomedia.database;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.ConnectionPoolDataSource;
/*    */ import oracle.jdbc.pool.OracleConnectionPoolDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DataSourceFactory
/*    */ {
/*    */   static enum SupportedDataBases
/*    */   {
/* 17 */     ORA;
/*    */     
/*    */     private SupportedDataBases() {} }
/* 20 */   public ConnectionPoolDataSource createDataSource(SupportedDataBases poDB) throws SQLException { ConnectionPoolDataSource voDS = null;
/* 21 */     switch (poDB) {
/*    */     case ORA: 
/* 23 */       voDS = new OracleConnectionPoolDataSource();
/* 24 */       break;
/*    */     }
/*    */     
/*    */     
/*    */ 
/* 29 */     return voDS;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\DataSourceFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */