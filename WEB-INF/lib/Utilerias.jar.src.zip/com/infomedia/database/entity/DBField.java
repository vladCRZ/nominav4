/*     */ package com.infomedia.database.entity;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DBField
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int PRIMARY_KEY = 1;
/*     */   public static final int FOREIGN_KEY = 2;
/*     */   public static final int NULLABLE = 4;
/*  21 */   private DBMapping ENTITY = null;
/*  22 */   private DBField REFERENCE = null;
/*     */   
/*  24 */   private String DEFAULT = "";
/*  25 */   private String FIELD = "";
/*  26 */   private int FLAGS = 0;
/*  27 */   private int TYPE = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBField(DBMapping P_ENTITY, String P_FIELD, String P_DEFAULT, int P_TYPE, int P_FLAGS)
/*     */   {
/*  43 */     this.ENTITY = P_ENTITY;
/*  44 */     this.FIELD = P_FIELD;
/*  45 */     this.DEFAULT = P_DEFAULT;
/*  46 */     this.FLAGS = P_FLAGS;
/*  47 */     this.TYPE = P_TYPE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBField(DBMapping P_ENTITY, String P_FIELD, int P_TYPE, int P_FLAGS)
/*     */   {
/*  63 */     this(P_ENTITY, P_FIELD, "", P_TYPE, P_FLAGS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(DBField P_REFERENCE)
/*     */   {
/*  75 */     this.REFERENCE = P_REFERENCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBMapping getEntity()
/*     */   {
/*  86 */     return this.ENTITY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBField getReference()
/*     */   {
/*  97 */     return isForeignKey() ? this.REFERENCE : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getField()
/*     */   {
/* 108 */     return this.FIELD;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefault()
/*     */   {
/* 119 */     return this.DEFAULT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getType()
/*     */   {
/* 130 */     return this.TYPE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNullable()
/*     */   {
/* 141 */     return (this.FLAGS & 0x4) > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrimaryKey()
/*     */   {
/* 152 */     return (this.FLAGS & 0x1) > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isForeignKey()
/*     */   {
/* 163 */     return (this.FLAGS & 0x2) > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 176 */     return "ENTITY:" + this.ENTITY.getEntity() + "\nFIELD:" + this.FIELD + "\nDEFAULT:" + this.DEFAULT + "\nFLAGS:" + this.FLAGS + "\nTYPE:" + this.TYPE;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\entity\DBField.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */