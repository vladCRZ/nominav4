/*     */ package com.infomedia.database.entity;
/*     */ 
/*     */ import com.infomedia.utils.CollectionsUtils;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DBMapping
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  23 */   private List<String> FIELD_NAMES = null;
/*  24 */   private Map<String, DBField> FIELDS = null;
/*  25 */   private String ENTITY = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DBMapping(String PS_ENTITY)
/*     */   {
/*  37 */     this.ENTITY = PS_ENTITY;
/*  38 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBMapping(String PS_ENTITY, String[] PO_FIELDS, String[] PO_DEFAULTS, int[] PO_TYPES, int[] PO_FLAGS)
/*     */   {
/*  55 */     this(PS_ENTITY);
/*     */     
/*  57 */     if ((PO_FIELDS.length == PO_FLAGS.length) && (PO_FIELDS.length == PO_TYPES.length) && ((PO_DEFAULTS == null) || (PO_FIELDS.length == PO_DEFAULTS.length))) {
/*  58 */       this.ENTITY = PS_ENTITY;
/*  59 */       for (String vsField : PO_FIELDS) {
/*  60 */         this.FIELD_NAMES.add(vsField);
/*  61 */         this.FIELDS.put(vsField, new DBField(this, vsField, PO_DEFAULTS == null ? "" : PO_DEFAULTS[(this.FIELD_NAMES.size() - 1)], PO_TYPES[(this.FIELD_NAMES.size() - 1)], PO_FLAGS[(this.FIELD_NAMES.size() - 1)]));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBMapping(String PS_ENTITY, String[] PO_FIELDS, int[] PO_TYPES, int[] PO_FLAGS)
/*     */   {
/*  79 */     this(PS_ENTITY, PO_FIELDS, null, PO_TYPES, PO_FLAGS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBMapping(String PS_ENTITY, Class<?> PO_FIELDS, String[] PO_DEFAULTS, int[] PO_TYPES, int[] PO_FLAGS)
/*     */   {
/*  96 */     this(PS_ENTITY, CollectionsUtils.fncsEnumAsArray(PO_FIELDS), PO_DEFAULTS, PO_TYPES, PO_FLAGS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBMapping(String PS_ENTITY, Class<?> PO_FIELDS, int[] PO_TYPES, int[] PO_FLAGS)
/*     */   {
/* 112 */     this(PS_ENTITY, CollectionsUtils.fncsEnumAsArray(PO_FIELDS), PO_TYPES, PO_FLAGS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init()
/*     */   {
/* 124 */     this.FIELD_NAMES = new ArrayList();
/* 125 */     this.FIELDS = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DBField getField(String psFieldName)
/*     */   {
/* 139 */     return this.FIELD_NAMES.contains(psFieldName) ? (DBField)this.FIELDS.get(psFieldName) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getFieldNames()
/*     */   {
/* 152 */     return this.FIELD_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldString()
/*     */   {
/* 165 */     return CollectionsUtils.fncsListAsString(getFieldNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getKeyNames()
/*     */   {
/* 178 */     List<String> voKeyNames = new ArrayList();
/* 179 */     for (String vsField : this.FIELD_NAMES) if (((DBField)this.FIELDS.get(vsField)).isPrimaryKey()) voKeyNames.add(vsField);
/* 180 */     return voKeyNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFieldArray()
/*     */   {
/* 192 */     return CollectionsUtils.toArray(getFieldNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getKeyArray()
/*     */   {
/* 203 */     return CollectionsUtils.toArray(getKeyNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEntity()
/*     */   {
/* 214 */     return this.ENTITY;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\entity\DBMapping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */