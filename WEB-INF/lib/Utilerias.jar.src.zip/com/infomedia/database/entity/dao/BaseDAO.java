/*      */ package com.infomedia.database.entity.dao;
/*      */ 
/*      */ import com.infomedia.database.DBException;
/*      */ import com.infomedia.database.entity.DBField;
/*      */ import com.infomedia.database.entity.DBMapping;
/*      */ import com.infomedia.database.entity.vo.BaseVO;
/*      */ import com.infomedia.integration.ServiceLocator;
/*      */ import com.infomedia.utils.CollectionsUtils;
/*      */ import com.infomedia.utils.DateUtils;
/*      */ import com.infomedia.utils.DinamicVO;
/*      */ import com.infomedia.utils.FileUtils;
/*      */ import com.infomedia.utils.StringUtils;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.ParseException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.logging.Level;
/*      */ import javax.sql.DataSource;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.sql.BLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BaseDAO
/*      */   implements DAOObject
/*      */ {
/*      */   public static final String TODAY = "<today>";
/*   46 */   private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(BaseDAO.class);
/*      */   
/*   48 */   protected DataSource goDataSource = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BaseDAO(String psDataSourceName)
/*      */   {
/*   59 */     this.goDataSource = ServiceLocator.getInstance().getDataSource(psDataSourceName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BaseDAO()
/*      */   {
/*   70 */     this("dataSourceName");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Connection getConnection(String psDataSourceName)
/*      */     throws SQLException
/*      */   {
/*   84 */     return ServiceLocator.getInstance().getDataSource(psDataSourceName).getConnection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Connection getConnection()
/*      */     throws SQLException
/*      */   {
/*   97 */     return getConnection("dataSourceName");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void release(Connection voConnection)
/*      */   {
/*      */     try
/*      */     {
/*  110 */       if (voConnection != null) {
/*  111 */         voConnection.close();
/*      */       }
/*      */     }
/*      */     catch (SQLException voIgnorar) {}
/*      */   }
/*      */   
/*      */   public static boolean setTerritory(Connection poConnection, String psTerritory) throws SQLException {
/*  118 */     Statement voStatement = null;
/*  119 */     vbSetted = false;
/*      */     try {
/*  121 */       voStatement = poConnection.createStatement();
/*  122 */       voStatement.execute("alter session set nls_territory='" + psTerritory + "'");
/*  123 */       return true;
/*      */     } catch (SQLException poEXC) {
/*  125 */       throw poEXC;
/*      */     } finally {
/*  127 */       if (voStatement != null) {
/*      */         try {
/*  129 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean setTerritory(String psDataSource, String psTerritory) throws SQLException
/*      */   {
/*  138 */     Connection voConnection = null;
/*  139 */     boolean vbSetted = false;
/*      */     try
/*      */     {
/*  142 */       voConnection = getConnection(psDataSource);
/*  143 */       vbSetted = setTerritory(voConnection, psTerritory);
/*      */     } catch (SQLException poEXC) {
/*  145 */       throw poEXC;
/*      */     } finally {
/*  147 */       release(voConnection);
/*      */     }
/*  149 */     return vbSetted;
/*      */   }
/*      */   
/*      */   public static boolean setTerritory(String psTerritory) throws SQLException {
/*  153 */     return setTerritory("dataSourceName", psTerritory);
/*      */   }
/*      */   
/*      */   public static boolean setTerritory() throws SQLException {
/*  157 */     return setTerritory("MEXICO");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int nextValue(Connection poConnection, String psSequence)
/*      */     throws SQLException
/*      */   {
/*  172 */     Statement voStatement = null;
/*  173 */     ResultSet voRS = null;
/*  174 */     viNextValue = 0;
/*      */     try {
/*  176 */       voStatement = poConnection.createStatement();
/*  177 */       voRS = voStatement.executeQuery("SELECT " + psSequence + ".nextval AS NEXT FROM dual");
/*  178 */       if (voRS.next()) {}
/*  179 */       return voRS.getInt("NEXT");
/*      */     }
/*      */     catch (SQLException voSQLException) {
/*  182 */       throw voSQLException;
/*      */     } finally {
/*  184 */       if (voRS != null) {
/*      */         try {
/*  186 */           voRS.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*  190 */       if (voStatement != null) {
/*      */         try {
/*  192 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int maxValue(Connection poConnection, String psEntity, String psField, String[] psConditionalFields)
/*      */     throws SQLException
/*      */   {
/*  214 */     Statement voStatement = null;
/*  215 */     ResultSet voRS = null;
/*  216 */     String vsSQL = "";
/*  217 */     viNextValue = 0;
/*      */     try {
/*  219 */       vsSQL = vsSQL + "SELECT nvl(max(" + psField + "),0)+1 AS NEXT";
/*  220 */       vsSQL = vsSQL + " FROM " + psEntity;
/*  221 */       vsSQL = vsSQL + ((psConditionalFields == null) || (psConditionalFields.length == 0) ? "" : new StringBuilder().append(" WHERE ").append(CollectionsUtils.fncsArrayAsString(psConditionalFields).replaceAll(",", " AND ")).toString());
/*  222 */       voStatement = poConnection.createStatement();
/*  223 */       voRS = voStatement.executeQuery(vsSQL);
/*  224 */       if (voRS.next()) {}
/*  225 */       return voRS.getInt("NEXT");
/*      */     }
/*      */     catch (SQLException voSQLException) {
/*  228 */       throw voSQLException;
/*      */     } finally {
/*  230 */       if (voRS != null) {
/*      */         try {
/*  232 */           voRS.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*  236 */       if (voStatement != null) {
/*      */         try {
/*  238 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static int maxValue(Connection poConnection, String psEntity, Object poField, String[] psConditionalFields) throws SQLException
/*      */   {
/*  247 */     return maxValue(poConnection, psEntity, poField.toString(), psConditionalFields);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int maxValue(Connection poConnection, String psEntity, String psField)
/*      */     throws SQLException
/*      */   {
/*  263 */     return maxValue(poConnection, psEntity, psField, null);
/*      */   }
/*      */   
/*      */   public static int maxValue(Connection poConnection, String psEntity, Object poField) throws SQLException {
/*  267 */     return maxValue(poConnection, psEntity, poField.toString());
/*      */   }
/*      */   
/*      */   public static int maxValue(String psEntity, String psField, String[] psConditionalFields) throws SQLException {
/*  271 */     Connection voConnection = null;
/*  272 */     int viMaxValue = 0;
/*      */     try {
/*  274 */       voConnection = getConnection();
/*  275 */       viMaxValue = maxValue(voConnection, psEntity, psField, psConditionalFields);
/*      */     } catch (SQLException poEXC) {
/*  277 */       throw poEXC;
/*      */     } finally {
/*  279 */       release(voConnection);
/*      */     }
/*  281 */     return viMaxValue;
/*      */   }
/*      */   
/*      */   public static int maxValue(String psDataSource, String psEntity, String psField, String[] psConditionalFields) throws SQLException {
/*  285 */     Connection voConnection = null;
/*  286 */     int viMaxValue = 0;
/*      */     try {
/*  288 */       voConnection = getConnection(psDataSource);
/*  289 */       viMaxValue = maxValue(voConnection, psEntity, psField, psConditionalFields);
/*      */     } catch (SQLException poEXC) {
/*  291 */       throw poEXC;
/*      */     } finally {
/*  293 */       release(voConnection);
/*      */     }
/*  295 */     return viMaxValue;
/*      */   }
/*      */   
/*      */   public static int maxValue(String psEntity, String psField) throws SQLException {
/*  299 */     return maxValue(psEntity, psField, null);
/*      */   }
/*      */   
/*      */   public static int maxValue(String psEntity, Object poField) throws SQLException {
/*  303 */     return maxValue(psEntity, poField.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void fillPreparedStatement(PreparedStatement poPreparedStatement, String[] poFields, BaseVO poVO)
/*      */     throws SQLException
/*      */   {
/*  318 */     int viFieldIndex = 1;
/*      */     
/*  320 */     for (String vsField : poFields) {
/*  321 */       int viType = poVO.getMapping().getField(vsField).getType();
/*  322 */       if (poVO.isNVL(vsField)) {
/*  323 */         poPreparedStatement.setNull(viFieldIndex++, viType);
/*      */       } else {
/*  325 */         poVO.setCampo(vsField, poVO.NVL(vsField));
/*  326 */         switch (viType) {
/*      */         case 3: 
/*  328 */           poPreparedStatement.setBigDecimal(viFieldIndex++, poVO.getCampoAsDecimal(vsField));
/*  329 */           break;
/*      */         case 6: 
/*      */         case 8: 
/*  332 */           poPreparedStatement.setDouble(viFieldIndex++, poVO.getCampoAsDouble(vsField));
/*  333 */           break;
/*      */         case 2: 
/*      */         case 4: 
/*  336 */           poPreparedStatement.setInt(viFieldIndex++, poVO.getCampoAsInt(vsField));
/*  337 */           break;
/*      */         case 92: 
/*  339 */           if (poVO.NVL(vsField).equals("<today>")) {
/*  340 */             poVO.setCampo(vsField, DateUtils.fncsFormat("HH:mm:ss"));
/*      */           }
/*      */           try
/*      */           {
/*  344 */             poPreparedStatement.setTime(viFieldIndex++, new Time(new SimpleDateFormat("HH:mm:ss").parse(poVO.NVL(vsField)).getTime()));
/*      */           } catch (ParseException PE) {
/*  346 */             throw new SQLException(PE.getMessage());
/*      */           }
/*      */         
/*      */         case 91: 
/*      */         case 93: 
/*  351 */           if (poVO.NVL(vsField).equals("<today>")) {
/*  352 */             poVO.setCampo(vsField, DateUtils.fncsFormat("dd/MM/yyyy HH:mm:ss"));
/*      */           }
/*  354 */           poPreparedStatement.setTimestamp(viFieldIndex++, new Timestamp(poVO.getCampoAsCalendar(vsField).getTimeInMillis()));
/*  355 */           break;
/*      */         case 12: 
/*  357 */           poPreparedStatement.setString(viFieldIndex++, poVO.NVL(vsField));
/*  358 */           break;
/*      */         default: 
/*  360 */           throw new SQLException("Unimplemented DataType " + viType + " (" + vsField + ")");
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean insert(Connection poConnection, BaseVO poVO)
/*      */     throws DBException
/*      */   {
/*  378 */     PreparedStatement voPreparedStatement = null;
/*  379 */     String SQL_INSERT = "";
/*  380 */     vbCreated = false;
/*      */     
/*      */ 
/*  383 */     poVO.validateKeys();
/*      */     
/*  385 */     SQL_INSERT = SQL_INSERT + "INSERT INTO " + poVO.getEntity();
/*  386 */     SQL_INSERT = SQL_INSERT + "(" + poVO.getFieldString() + ")";
/*  387 */     SQL_INSERT = SQL_INSERT + " VALUES (" + StringUtils.fncsRepeat(",?", poVO.getFields().length).substring(1) + ")";
/*      */     try
/*      */     {
/*  390 */       if (!poVO.validateKeys()) {
/*  391 */         throw new DBException("ERROR VALIDANDO LAS LLAVES DE " + poVO);
/*      */       }
/*  393 */       voPreparedStatement = poConnection.prepareStatement(SQL_INSERT);
/*  394 */       fillPreparedStatement(voPreparedStatement, poVO.getFields(), poVO);
/*  395 */       int viCreated = voPreparedStatement.executeUpdate();
/*  396 */       return viCreated > 0;
/*      */     } catch (SQLException voSQLException) {
/*  398 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  400 */       if (voPreparedStatement != null) {
/*      */         try {
/*  402 */           voPreparedStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnorar) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean insert(String psDataSource, BaseVO poVO)
/*      */     throws DBException
/*      */   {
/*  412 */     Connection voConnection = null;
/*  413 */     boolean vbInserted = false;
/*      */     try {
/*  415 */       voConnection = getConnection(psDataSource);
/*  416 */       vbInserted = insert(voConnection, poVO);
/*      */     } catch (SQLException poEXC) {
/*  418 */       throw new DBException(poEXC);
/*      */     } finally {
/*  420 */       release(voConnection);
/*      */     }
/*  422 */     return vbInserted;
/*      */   }
/*      */   
/*      */   public static boolean insert(BaseVO poVO) throws DBException {
/*  426 */     Connection voConnection = null;
/*  427 */     boolean vbInserted = false;
/*      */     try {
/*  429 */       voConnection = getConnection();
/*  430 */       vbInserted = insert(voConnection, poVO);
/*      */     } catch (SQLException poEXC) {
/*  432 */       throw new DBException(poEXC);
/*      */     } finally {
/*  434 */       release(voConnection);
/*      */     }
/*  436 */     return vbInserted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String getColumnValue(ResultSet poResultSet, int piColumnIndex)
/*      */     throws SQLException
/*      */   {
/*  451 */     String vsColumnValue = "";
/*      */     
/*  453 */     if (!StringUtils.isNVL(poResultSet.getString(piColumnIndex))) {
/*  454 */       switch (poResultSet.getMetaData().getColumnType(piColumnIndex)) {
/*      */       case 91: 
/*  456 */         vsColumnValue = DateUtils.fncsFormat("dd/MM/yyyy HH:mm", DateUtils.fncoCalendar(poResultSet.getDate(piColumnIndex).getTime()));
/*  457 */         break;
/*      */       case 93: 
/*  459 */         vsColumnValue = DateUtils.fncsFormat("dd/MM/yyyy HH:mm", DateUtils.fncoCalendar(poResultSet.getTimestamp(piColumnIndex).getTime()));
/*  460 */         break;
/*      */       default: 
/*  462 */         vsColumnValue = poResultSet.getString(piColumnIndex);
/*      */       }
/*      */       
/*      */     }
/*  466 */     return vsColumnValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static DinamicVO getRow(ResultSet poResultSet)
/*      */     throws SQLException
/*      */   {
/*  480 */     DinamicVO voVO = new DinamicVO(true);
/*      */     
/*      */ 
/*      */ 
/*  484 */     for (int viIndex = 1; viIndex <= poResultSet.getMetaData().getColumnCount(); viIndex++) {
/*  485 */       String vsColumnName = poResultSet.getMetaData().getColumnName(viIndex);
/*  486 */       voVO.setCampo(vsColumnName, getColumnValue(poResultSet, viIndex));
/*      */     }
/*      */     
/*  489 */     return voVO;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<DinamicVO> getFetch(ResultSet poResultSet)
/*      */     throws SQLException
/*      */   {
/*  503 */     ArrayList<DinamicVO> voFetch = new ArrayList();
/*  504 */     while (poResultSet.next()) {
/*  505 */       voFetch.add(getRow(poResultSet));
/*      */     }
/*  507 */     voFetch.trimToSize();
/*  508 */     return voFetch;
/*      */   }
/*      */   
/*      */   public static void getFetch(ResultSet poResultSet, Collection<DinamicVO> poFetch) throws SQLException {
/*  512 */     while (poResultSet.next()) {
/*  513 */       poFetch.add(getRow(poResultSet));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<DinamicVO> executeQuery(Connection poConnection, String psSQL)
/*      */     throws DBException
/*      */   {
/*  529 */     Statement voStatement = null;
/*  530 */     ResultSet voResultSet = null;
/*  531 */     voFetch = new ArrayList();
/*      */     try
/*      */     {
/*  534 */       if ((!psSQL.trim().toUpperCase().startsWith("SELECT")) && (!psSQL.trim().toUpperCase().startsWith("WITH"))) {
/*  535 */         throw new DBException(psSQL + " isn't a select statement");
/*      */       }
/*  537 */       voStatement = poConnection.createStatement();
/*  538 */       voResultSet = voStatement.executeQuery(psSQL);
/*  539 */       return getFetch(voResultSet);
/*      */     } catch (SQLException voSQLException) {
/*  541 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  543 */       if (voResultSet != null) {
/*      */         try {
/*  545 */           voResultSet.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*  549 */       if (voStatement != null) {
/*      */         try {
/*  551 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static List<DinamicVO> executeQuery(String psDataSource, String psSQL)
/*      */     throws DBException
/*      */   {
/*  561 */     Connection voConnection = null;
/*  562 */     List<DinamicVO> voFetch = new ArrayList();
/*      */     try
/*      */     {
/*  565 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/*  566 */       voFetch = executeQuery(voConnection, psSQL);
/*      */     } catch (SQLException voSQLException) {
/*  568 */       log.error(voSQLException);
/*  569 */       System.out.println(voSQLException);
/*  570 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  572 */       release(voConnection);
/*      */     }
/*      */     
/*  575 */     return voFetch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<DinamicVO> executeQuery(String psSQL)
/*      */     throws DBException
/*      */   {
/*  589 */     return executeQuery("", psSQL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<DinamicVO> executeQuery(Connection poConnection, String psSQL, String[] poFields, BaseVO poVO)
/*      */     throws DBException
/*      */   {
/*  607 */     PreparedStatement voPreparedStatement = null;
/*  608 */     ResultSet voResultSet = null;
/*  609 */     voFetch = new ArrayList();
/*      */     
/*      */     try
/*      */     {
/*  613 */       if ((!psSQL.trim().toUpperCase().startsWith("SELECT")) && (!psSQL.trim().toUpperCase().startsWith("WITH"))) {
/*  614 */         throw new DBException(psSQL + " isn't a select statement");
/*      */       }
/*  616 */       voPreparedStatement = poConnection.prepareStatement(psSQL);
/*  617 */       fillPreparedStatement(voPreparedStatement, poFields, poVO);
/*  618 */       voResultSet = voPreparedStatement.executeQuery();
/*  619 */       return getFetch(voResultSet);
/*      */     } catch (SQLException voSQLException) {
/*  621 */       throw new DBException(voSQLException);
/*      */     } finally {
/*      */       try {
/*  624 */         if (null != voResultSet) {
/*  625 */           voResultSet.close();
/*      */         }
/*      */       }
/*      */       catch (SQLException voIgnore) {}
/*      */       try {
/*  630 */         if (null != voPreparedStatement) {
/*  631 */           voPreparedStatement.close();
/*      */         }
/*      */       }
/*      */       catch (SQLException voIgnore) {}
/*      */     }
/*      */   }
/*      */   
/*      */   public static String selectValue(Connection poConnection, String psQuery, String psName)
/*      */     throws DBException
/*      */   {
/*  641 */     Statement voStatement = null;
/*  642 */     ResultSet voRS = null;
/*  643 */     vsValue = "";
/*      */     try
/*      */     {
/*  646 */       if ((!psQuery.toUpperCase().startsWith("SELECT")) && (!psQuery.toUpperCase().startsWith("WITH"))) {
/*  647 */         throw new DBException(psQuery + " isn't a select statement");
/*      */       }
/*  649 */       voStatement = poConnection.createStatement();
/*  650 */       voRS = voStatement.executeQuery(psQuery);
/*      */       
/*  652 */       if (voRS.next()) {}
/*  653 */       return voRS.getString(psName);
/*      */     }
/*      */     catch (SQLException voSQLException) {
/*  656 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  658 */       if (voRS != null) {
/*      */         try {
/*  660 */           voRS.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*  664 */       if (voStatement != null) {
/*      */         try {
/*  666 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static String selectValue(String psDataSource, String psQuery, String psName) throws DBException
/*      */   {
/*  675 */     Connection voConnection = null;
/*  676 */     String vsValue = "";
/*      */     try {
/*  678 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/*  679 */       vsValue = selectValue(voConnection, psQuery, psName);
/*      */     } catch (SQLException voSQLException) {
/*  681 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  683 */       release(voConnection);
/*      */     }
/*  685 */     return vsValue;
/*      */   }
/*      */   
/*      */   public static String selectValue(String psQuery, String psName) throws DBException {
/*  689 */     return selectValue("", psQuery, psName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean execute(Connection poConnection, String psSQL)
/*      */     throws DBException
/*      */   {
/*  706 */     Statement voStatement = null;
/*  707 */     vbExecuted = false;
/*      */     try
/*      */     {
/*  710 */       if ((!psSQL.trim().toUpperCase().startsWith("DELETE")) && (!psSQL.trim().toUpperCase().startsWith("UPDATE")) && (!psSQL.trim().toUpperCase().startsWith("INSERT")))
/*      */       {
/*      */ 
/*  713 */         throw new DBException(psSQL + " isn't a delete, insert nor update statement");
/*      */       }
/*  715 */       voStatement = poConnection.createStatement();
/*  716 */       return voStatement.executeUpdate(psSQL) > 0;
/*      */     }
/*      */     catch (SQLException voSQLException) {
/*  719 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  721 */       if (voStatement != null) {
/*      */         try {
/*  723 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean execute(String psDataSource, String psSQL)
/*      */     throws DBException
/*      */   {
/*  733 */     Connection voConnection = null;
/*  734 */     boolean vbExecuted = false;
/*      */     try
/*      */     {
/*  737 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/*  738 */       vbExecuted = execute(voConnection, psSQL);
/*      */     } catch (SQLException voSQLException) {
/*  740 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  742 */       release(voConnection);
/*      */     }
/*      */     
/*  745 */     return vbExecuted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean execute(String psSQL)
/*      */     throws DBException
/*      */   {
/*  761 */     Connection voConnection = null;
/*  762 */     boolean vbExecuted = false;
/*      */     try
/*      */     {
/*  765 */       voConnection = getConnection();
/*  766 */       vbExecuted = execute(voConnection, psSQL);
/*      */     } catch (SQLException voSQLException) {
/*  768 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  770 */       release(voConnection);
/*      */     }
/*      */     
/*  773 */     return vbExecuted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int executeUpdate(Connection poConnection, String psSQL)
/*      */     throws DBException
/*      */   {
/*  790 */     Statement voStatement = null;
/*  791 */     viUpdated = 0;
/*      */     try
/*      */     {
/*  794 */       if ((!psSQL.trim().toUpperCase().startsWith("DELETE")) && (!psSQL.trim().toUpperCase().startsWith("UPDATE")) && (!psSQL.trim().toUpperCase().startsWith("INSERT")))
/*      */       {
/*      */ 
/*  797 */         throw new DBException(psSQL + " isn't a delete, insert nor update statement");
/*      */       }
/*  799 */       voStatement = poConnection.createStatement();
/*  800 */       voStatement.executeUpdate(psSQL);
/*  801 */       return voStatement.getUpdateCount();
/*      */     } catch (SQLException voSQLException) {
/*  803 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  805 */       if (voStatement != null) {
/*      */         try {
/*  807 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean execute(Connection poConnection, String psSQL, String[] poFields, BaseVO poVO)
/*      */     throws DBException
/*      */   {
/*  833 */     PreparedStatement voPreparedStatement = null;
/*  834 */     vbExecuted = false;
/*      */     try
/*      */     {
/*  837 */       if ((!psSQL.trim().toUpperCase().startsWith("DELETE")) && (!psSQL.trim().toUpperCase().startsWith("UPDATE"))) {
/*  838 */         throw new DBException(psSQL + " isn't a delete nor update statement");
/*      */       }
/*  840 */       voPreparedStatement = poConnection.prepareStatement(psSQL);
/*  841 */       fillPreparedStatement(voPreparedStatement, poFields, poVO);
/*  842 */       voPreparedStatement.executeUpdate();
/*  843 */       return true;
/*      */     } catch (SQLException voSQLException) {
/*  845 */       throw new DBException(voSQLException);
/*      */     } finally {
/*      */       try {
/*  848 */         if (null != voPreparedStatement) {
/*  849 */           voPreparedStatement.close();
/*      */         }
/*      */       }
/*      */       catch (SQLException voIgnore) {}
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean forceExecute(Connection poConnection, String psSQL)
/*      */     throws DBException
/*      */   {
/*  859 */     Statement voStatement = null;
/*  860 */     vbExecuted = false;
/*      */     try
/*      */     {
/*  863 */       voStatement = poConnection.createStatement();
/*  864 */       voStatement.executeUpdate(psSQL);
/*  865 */       return true;
/*      */     } catch (SQLException voSQLException) {
/*  867 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  869 */       if (voStatement != null) {
/*      */         try {
/*  871 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean forceExecute(String psDataSource, String psSQL)
/*      */     throws DBException
/*      */   {
/*  881 */     Connection voConnection = null;
/*  882 */     boolean vbExecuted = false;
/*      */     try
/*      */     {
/*  885 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/*  886 */       vbExecuted = forceExecute(voConnection, psSQL);
/*      */     } catch (SQLException voSQLException) {
/*  888 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  890 */       release(voConnection);
/*      */     }
/*      */     
/*  893 */     return vbExecuted;
/*      */   }
/*      */   
/*      */   public static String loadSQLSentenceAsResource(Object poCaller, String psSQLFile) throws Exception {
/*  897 */     StringBuilder voSQLBuffer = new StringBuilder();
/*      */     
/*  899 */     for (String vsLine : FileUtils.loadFileAsResource(poCaller, psSQLFile).split("\n"))
/*      */     {
/*  901 */       if (!vsLine.trim().startsWith("--")) {
/*  902 */         voSQLBuffer.append(vsLine);
/*  903 */         voSQLBuffer.append("\n");
/*      */       }
/*      */     }
/*  906 */     return voSQLBuffer.toString();
/*      */   }
/*      */   
/*      */   public static BLOB getBlob(String psDataSource, String psEntity, String psField, String psConditionalString) throws DBException {
/*  910 */     StringBuilder sql = new StringBuilder();
/*  911 */     Connection voConnection = null;
/*  912 */     Statement voStatement = null;
/*  913 */     ResultSet voResultSet = null;
/*  914 */     BLOB blobField = null;
/*      */     
/*  916 */     sql.append("SELECT ").append(psField).append("\n");
/*  917 */     sql.append("FROM ").append(psEntity).append("\n");
/*  918 */     sql.append("WHERE ").append(psConditionalString).append("\n");
/*      */     try
/*      */     {
/*  921 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/*  922 */       voStatement = voConnection.createStatement();
/*  923 */       voResultSet = voStatement.executeQuery(sql.toString());
/*  924 */       if (voResultSet.next()) {
/*  925 */         blobField = ((OracleResultSet)voResultSet).getBLOB(psField);
/*      */       }
/*      */     } catch (SQLException voSQLException) {
/*  928 */       throw new DBException(voSQLException);
/*      */     } finally {
/*  930 */       if (null != voResultSet) {
/*      */         try {
/*  932 */           voResultSet.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*  936 */       if (null != voStatement) {
/*      */         try {
/*  938 */           voStatement.close();
/*      */         }
/*      */         catch (SQLException voIgnore) {}
/*      */       }
/*  942 */       release(voConnection);
/*      */     }
/*  944 */     return blobField;
/*      */   }
/*      */   
/*  947 */   public static boolean setBlob(String psDataSource, String psEntity, String psField, String psConditionalString, byte[] poBuffer) throws DBException { ByteArrayInputStream input = new ByteArrayInputStream(poBuffer);
/*  948 */     OutputStream blob = null;
/*  949 */     StringBuilder sql = new StringBuilder();
/*  950 */     Connection voConnection = null;
/*  951 */     Statement voStatement = null;
/*  952 */     ResultSet voResultSet = null;
/*      */     
/*      */ 
/*  955 */     boolean autocommit = false;
/*  956 */     byte[] binaryBuffer = new byte['Ѐ'];
/*      */     
/*  958 */     sql.append("SELECT ").append(psField).append("\n");
/*  959 */     sql.append("FROM ").append(psEntity).append("\n");
/*  960 */     sql.append("WHERE ").append(psConditionalString).append("\n");
/*  961 */     sql.append("FOR UPDATE");
/*      */     try
/*      */     {
/*  964 */       log.debug(sql);
/*  965 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/*  966 */       autocommit = voConnection.getAutoCommit();
/*  967 */       voConnection.setAutoCommit(false);
/*  968 */       voStatement = voConnection.createStatement();
/*  969 */       voResultSet = voStatement.executeQuery(sql.toString());
/*  970 */       if (voResultSet.next()) {
/*  971 */         log.info("Escribiendo contenido en BD " + poBuffer.length);
/*  972 */         Blob blobField = voResultSet.getBlob(psField);
/*  973 */         log.info("Readed Blob " + blobField);
/*  974 */         blob = ((BLOB)blobField).getBinaryOutputStream();
/*  975 */         log.info("Parsed into " + blob);
/*  976 */         int bytesRead; while ((bytesRead = input.read(binaryBuffer)) != -1) {
/*  977 */           log.info("writing " + bytesRead + " bytes");
/*  978 */           blob.write(binaryBuffer, 0, bytesRead);
/*      */         }
/*  980 */         log.debug("done");
/*      */       }
/*      */     } catch (SQLException voSQLException) {
/*  983 */       log.debug(voSQLException);
/*  984 */       throw new DBException(voSQLException);
/*      */     } catch (IOException IOE) {
/*  986 */       log.debug(IOE);
/*  987 */       throw new DBException(IOE.getMessage());
/*      */     } finally {
/*      */       try {
/*  990 */         if (null != blob) {
/*  991 */           blob.flush();
/*  992 */           blob.close();
/*      */         }
/*      */       } catch (IOException ex) {
/*  995 */         log.error(ex);
/*      */       }
/*      */       try {
/*  998 */         input.close();
/*      */       } catch (IOException voIgnore) {
/* 1000 */         log.error(voIgnore);
/*      */       }
/* 1002 */       if (null != voResultSet) {
/*      */         try {
/* 1004 */           voResultSet.close();
/*      */         } catch (SQLException voIgnore) {
/* 1006 */           log.error(voIgnore);
/*      */         }
/*      */       }
/* 1009 */       if (null != voStatement) {
/*      */         try {
/* 1011 */           voStatement.close();
/*      */         } catch (SQLException voIgnore) {
/* 1013 */           log.error(voIgnore);
/*      */         }
/*      */       }
/*      */       try {
/* 1017 */         if (null != voConnection) {
/* 1018 */           voConnection.commit();
/* 1019 */           voConnection.setAutoCommit(autocommit);
/*      */         }
/*      */       } catch (SQLException ex) {
/* 1022 */         log.error(ex);
/*      */       }
/* 1024 */       release(voConnection);
/*      */     }
/* 1026 */     return true;
/*      */   }
/*      */   
/* 1029 */   public static boolean readBlob(String psDataSource, String psEntity, String psField, String psConditionalString, OutputStream output) throws DBException { InputStream input = null;
/* 1030 */     StringBuilder sql = new StringBuilder();
/* 1031 */     Connection voConnection = null;
/* 1032 */     Statement voStatement = null;
/* 1033 */     ResultSet voResultSet = null;
/* 1034 */     byte[] binaryBuffer = new byte['Ѐ'];
/*      */     
/*      */ 
/* 1037 */     sql.append("SELECT ").append(psField).append("\n");
/* 1038 */     sql.append("FROM ").append(psEntity).append("\n");
/* 1039 */     sql.append("WHERE ").append(psConditionalString).append("\n");
/*      */     try
/*      */     {
/* 1042 */       log.debug(sql);
/* 1043 */       voConnection = StringUtils.isNVL(psDataSource) ? getConnection() : getConnection(psDataSource);
/* 1044 */       voStatement = voConnection.createStatement();
/* 1045 */       voResultSet = voStatement.executeQuery(sql.toString());
/* 1046 */       if (voResultSet.next()) {
/* 1047 */         input = voResultSet.getBinaryStream(psField);
/* 1048 */         log.info("Obtenido InputStream " + input.available());
/* 1049 */         int bytesRead; while ((bytesRead = input.read(binaryBuffer)) != -1) {
/* 1050 */           log.info("Enviando " + bytesRead + " bytes");
/* 1051 */           output.write(binaryBuffer, 0, bytesRead);
/*      */         }
/*      */       }
/*      */     } catch (SQLException voSQLException) {
/* 1055 */       throw new DBException(voSQLException);
/*      */     } catch (IOException IOE) {
/* 1057 */       throw new DBException(IOE.getMessage());
/*      */     } finally {
/*      */       try {
/* 1060 */         if (null != input) {
/* 1061 */           input.close();
/*      */         }
/*      */       } catch (IOException ex) {
/* 1064 */         java.util.logging.Logger.getLogger(BaseDAO.class.getName()).log(Level.SEVERE, null, ex);
/*      */       }
/*      */       try {
/* 1067 */         if (null != input) {
/* 1068 */           input.close();
/*      */         }
/*      */       }
/*      */       catch (IOException voIgnore) {}
/* 1072 */       if (null != voResultSet) {
/*      */         try {
/* 1074 */           voResultSet.close();
/*      */         } catch (SQLException eIgnored) {
/* 1076 */           log.error(eIgnored);
/*      */         }
/*      */       }
/* 1079 */       if (null != voStatement) {
/*      */         try {
/* 1081 */           voStatement.close();
/*      */         } catch (SQLException eIgnored) {
/* 1083 */           log.error(eIgnored);
/*      */         }
/*      */       }
/* 1086 */       release(voConnection);
/*      */     }
/* 1088 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\entity\dao\BaseDAO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */