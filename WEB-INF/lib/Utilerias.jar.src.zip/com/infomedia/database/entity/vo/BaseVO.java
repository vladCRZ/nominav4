/*     */ package com.infomedia.database.entity.vo;
/*     */ 
/*     */ import com.infomedia.database.DBException;
/*     */ import com.infomedia.database.entity.DBField;
/*     */ import com.infomedia.database.entity.DBMapping;
/*     */ import com.infomedia.utils.CollectionsUtils;
/*     */ import com.infomedia.utils.DinamicVO;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseVO
/*     */   extends DinamicVO
/*     */   implements VOObject
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public BaseVO()
/*     */   {
/*  28 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseVO(DinamicVO poVO)
/*     */   {
/*  40 */     super(poVO.getCampos(), true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseVO(Map<String, String> poFields)
/*     */   {
/*  52 */     super(poFields, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isDataBaseVO(Object poVO)
/*     */   {
/*  66 */     return BaseVO.class.isAssignableFrom(poVO.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFields()
/*     */   {
/*  79 */     return (String[])getMapping().getFieldNames().toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getKeys()
/*     */   {
/*  92 */     return (String[])getMapping().getKeyNames().toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFieldValues()
/*     */   {
/* 105 */     String vsValues = "";
/* 106 */     for (String vsField : getFields()) {
/* 107 */       vsValues = vsValues + (vsValues.equals("") ? "" : ",");
/* 108 */       vsValues = vsValues + NVL(vsField);
/*     */     }
/* 110 */     return vsValues.split(",");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getKeyValues()
/*     */   {
/* 123 */     String vsValues = "";
/* 124 */     for (String vsKey : getKeys()) {
/* 125 */       vsValues = vsValues + (vsValues.equals("") ? "" : ",");
/* 126 */       vsValues = vsValues + NVL(vsKey);
/*     */     }
/* 128 */     return vsValues.split(",");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldString()
/*     */   {
/* 141 */     return CollectionsUtils.fncsListAsString(getMapping().getFieldNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getKeyString()
/*     */   {
/* 154 */     return CollectionsUtils.fncsListAsString(getMapping().getKeyNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldValuesString()
/*     */   {
/* 167 */     return CollectionsUtils.fncsArrayAsString(getFieldValues());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getKeyValuesString()
/*     */   {
/* 180 */     return CollectionsUtils.fncsArrayAsString(getKeyValues());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getKeyConditionalStatement()
/*     */   {
/* 194 */     String vsConditionalStatement = "";
/* 195 */     for (String vsKey : getKeys()) {
/* 196 */       vsConditionalStatement = vsConditionalStatement + (vsConditionalStatement.equals("") ? "" : " AND ");
/* 197 */       vsConditionalStatement = vsConditionalStatement + (isNVL(vsKey) ? "" : new StringBuilder().append(vsKey).append("=").append(NVL(vsKey)).toString());
/*     */     }
/* 199 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean validateKeys()
/*     */     throws DBException
/*     */   {
/* 213 */     for (String vsKey : getKeys()) {
/* 214 */       if (isNVL(vsKey)) {
/* 215 */         throw new DBException(vsKey + " can't be null");
/*     */       }
/*     */     }
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   public boolean hasDefault(String psFieldID) {
/* 222 */     return (getMapping().getField(psFieldID) != null) && (!StringUtils.isNVL(getMapping().getField(psFieldID).getDefault()));
/*     */   }
/*     */   
/*     */   public boolean hasDefault(Object poFieldID) {
/* 226 */     return hasDefault(poFieldID.toString());
/*     */   }
/*     */   
/*     */   public String NVL(String psFieldID, String psDefault)
/*     */   {
/* 231 */     return super.isNVL(psFieldID) ? psDefault : hasDefault(psFieldID) ? getMapping().getField(psFieldID).getDefault() : getCampo(psFieldID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String NVL(String psFieldID)
/*     */   {
/* 246 */     return NVL(psFieldID, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String NVL(Object poFieldID)
/*     */   {
/* 259 */     return super.NVL(poFieldID.toString(), "");
/*     */   }
/*     */   
/*     */   public String NVL(Object poFieldID, String psDefault) {
/* 263 */     return super.NVL(poFieldID.toString(), psDefault);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNVL(String psFieldID)
/*     */   {
/* 278 */     return (super.isNVL(psFieldID)) && ((getMapping().getField(psFieldID) == null) || (StringUtils.isNVL(getMapping().getField(psFieldID).getDefault())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNVL(Object poFieldID)
/*     */   {
/* 291 */     return isNVL(poFieldID.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setField(Object poFieldID, String psValue)
/*     */   {
/* 304 */     super.setCampo(poFieldID.toString(), psValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\entity\vo\BaseVO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */