package com.infomedia.database.entity.vo;

import com.infomedia.database.DBException;
import com.infomedia.database.entity.DBMapping;

public abstract interface VOObject
{
  public abstract String getEntity();
  
  public abstract String[] getFields();
  
  public abstract String[] getKeys();
  
  public abstract String[] getFieldValues();
  
  public abstract String[] getKeyValues();
  
  public abstract String getFieldString();
  
  public abstract String getKeyString();
  
  public abstract String getFieldValuesString();
  
  public abstract String getKeyValuesString();
  
  public abstract String getKeyConditionalStatement();
  
  public abstract boolean validateKeys()
    throws DBException;
  
  public abstract DBMapping getMapping();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\database\entity\vo\VOObject.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */