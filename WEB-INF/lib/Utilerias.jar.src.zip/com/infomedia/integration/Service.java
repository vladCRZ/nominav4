package com.infomedia.integration;

import javax.naming.Reference;

public abstract interface Service
{
  public abstract Reference getReference();
  
  public abstract boolean isDefined();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\integration\Service.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */