/*    */ package com.infomedia.integration;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceFactory
/*    */ {
/*    */   public static Service create(Class<?> poService)
/*    */     throws Exception
/*    */   {
/* 14 */     if (!Service.class.isAssignableFrom(poService)) throw new Exception(poService.getName() + " doesn't implement Service interface");
/* 15 */     return (Service)poService.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\integration\ServiceFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */