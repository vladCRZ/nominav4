/*    */ package com.infomedia.integration;
/*    */ 
/*    */ import com.infomedia.context.APPContext;
/*    */ import com.infomedia.context.WEBServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceLoader
/*    */ {
/*    */   public static void loadService(String psClass, String psName, String psLookup)
/*    */     throws Exception
/*    */   {
/* 30 */     Service voService = null;
/* 31 */     if (WEBServletContext.isInitialized()) throw new Exception("Can´t load a new service in a WEBAPP context");
/* 32 */     unloadService(psName);
/* 33 */     voService = ServiceFactory.create(Class.forName(psClass));
/* 34 */     if (!voService.isDefined()) throw new Exception("Can´t load service " + psName + " cause " + psClass + " parameters are not defined in this context");
/* 35 */     APPContext.addReference(psLookup, voService.getReference());
/* 36 */     APPContext.setInitParameter(psName, psLookup);
/*    */   }
/*    */   
/*    */   public static void loadService(Class<?> poClass, String psName, String psLookup) throws Exception {
/* 40 */     Service voService = null;
/* 41 */     if (WEBServletContext.isInitialized()) throw new Exception("Can´t load a new service in a WEBAPP context");
/* 42 */     unloadService(psName);
/* 43 */     voService = ServiceFactory.create(poClass);
/* 44 */     if (!voService.isDefined()) throw new Exception("Can´t load service " + psName + " cause " + poClass.getName() + " parameters are not defined in this context");
/* 45 */     APPContext.addReference(psLookup, voService.getReference());
/* 46 */     APPContext.setInitParameter(psName, psLookup);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static void unloadService(String psName)
/*    */     throws Exception
/*    */   {
/* 60 */     if (APPContext.hasInitParameter(psName)) ServiceLocator.getInstance().removeService(psName);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\integration\ServiceLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */