/*     */ package com.infomedia.integration;
/*     */ 
/*     */ import com.infomedia.context.APPContext;
/*     */ import com.infomedia.context.WEBServletContext;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceLocator
/*     */ {
/*  29 */   static Logger logger = Logger.getLogger(ServiceLocator.class);
/*     */   
/*  31 */   private static final ServiceLocator INSTANCE = new ServiceLocator();
/*     */   
/*     */   public static final String DATASOURCE_NAME = "dataSourceName";
/*     */   
/*  35 */   private Context goContext = null;
/*  36 */   private Map<String, Object> goServices = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ServiceLocator()
/*     */   {
/*     */     try
/*     */     {
/*  49 */       if (isWEBApp()) {
/*  50 */         this.goContext = new InitialContext();
/*     */       } else {
/*  52 */         this.goContext = APPContext.getInstance().getContext();
/*     */       }
/*     */     } catch (Exception EXC) {
/*  55 */       logger.error("Initing context", EXC);
/*     */     }
/*  57 */     this.goServices = Collections.synchronizedMap(new HashMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServiceLocator getInstance()
/*     */   {
/*  71 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isWEBApp()
/*     */   {
/*  85 */     return WEBServletContext.isInitialized();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSource getDataSource(String psDataSourceName)
/*     */   {
/* 100 */     return (DataSource)getService(psDataSourceName);
/*     */   }
/*     */   
/*     */   public static String getInitParameter(String parameter) {
/* 104 */     return isWEBApp() ? WEBServletContext.getInitParameter(parameter) : APPContext.getInitParameter(parameter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getService(String psService)
/*     */   {
/* 118 */     Object voService = null;
/* 119 */     String vsServiceName = getInitParameter(psService);
/*     */     try
/*     */     {
/* 122 */       if (this.goServices.containsKey(vsServiceName)) {
/* 123 */         voService = this.goServices.get(vsServiceName);
/*     */       } else {
/* 125 */         voService = this.goContext.lookup(vsServiceName);
/* 126 */         this.goServices.put(vsServiceName, voService);
/*     */       }
/*     */     } catch (NamingException NE) {
/* 129 */       logger.error("Getting Service", NE);
/*     */     }
/*     */     
/* 132 */     return voService;
/*     */   }
/*     */   
/*     */   protected void removeService(String psService) throws NamingException {
/* 136 */     if (this.goServices.containsKey(psService)) {
/* 137 */       this.goContext.unbind(psService);
/*     */     }
/* 139 */     this.goServices.remove(psService);
/*     */   }
/*     */   
/*     */   public static Context getContext() {
/* 143 */     return INSTANCE.goContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\integration\ServiceLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */