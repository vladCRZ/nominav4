/*    */ package com.infomedia.messaging.mail;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseMailbox
/*    */   implements Mailbox, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   protected List<Message> goMessages = new ArrayList();
/*    */   
/*    */   public List<Message> getMessages() {
/* 22 */     return this.goMessages;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\messaging\mail\BaseMailbox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */