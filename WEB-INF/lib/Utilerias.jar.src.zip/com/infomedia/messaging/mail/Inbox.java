/*     */ package com.infomedia.messaging.mail;
/*     */ 
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.NoSuchProviderException;
/*     */ import javax.mail.Store;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Inbox
/*     */   extends BaseMailbox
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String INBOX = "INBOX";
/*     */   private Store goStore;
/*     */   private Folder goFolder;
/*     */   
/*     */   public Inbox(javax.mail.Session poSession)
/*     */   {
/*     */     try
/*     */     {
/*  38 */       this.goStore = poSession.getStore();
/*     */     }
/*     */     catch (NoSuchProviderException poIgnorar) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Inbox()
/*     */   {
/*  52 */     this(Session.getSession());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean open(javax.mail.Session poSession)
/*     */   {
/*  67 */     boolean vbOpenned = false;
/*     */     try
/*     */     {
/*  70 */       this.goStore.connect();
/*  71 */       this.goFolder = this.goStore.getFolder("INBOX");
/*  72 */       this.goFolder.open(2);
/*  73 */       vbOpenned = true;
/*     */     } catch (MessagingException voME) {
/*  75 */       voME.printStackTrace();
/*     */     }
/*     */     
/*  78 */     return vbOpenned;
/*     */   }
/*     */   
/*  81 */   public boolean open() { return open(Session.getSession()); }
/*     */   
/*     */   public void askForMessages()
/*     */   {
/*     */     try {
/*  86 */       this.goFolder.getMessages();
/*     */     } catch (MessagingException voME) {
/*  88 */       voME.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/*     */     try
/*     */     {
/* 102 */       this.goStore.close();
/*     */     }
/*     */     catch (MessagingException voIgnore) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\messaging\mail\Inbox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */