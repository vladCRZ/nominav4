package com.infomedia.messaging.mail;

public abstract interface Mailbox
{
  public static final String MAILBOX_PROVIDER_POP3 = "pop3";
  public static final String MAILBOX_PROVIDER_IMAP = "imap";
  public static final String MAILBOX_PROVIDER_SMTP = "smtp";
  public static final String MAILBOX_HST = "mail.host";
  public static final String MAILBOX_USR = "mail.user";
  public static final String MAILBOX_PWD = "mail.password";
  public static final String MAILBOX_PTCL = "mail.transport.protocol";
  public static final String MAILBOX_AUTH = "mail.smtp.auth";
  
  public abstract boolean open();
  
  public abstract void close();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\messaging\mail\Mailbox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */