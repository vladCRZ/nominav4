/*     */ package com.infomedia.messaging.mail;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.FileDataSource;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Message
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public static class Attachment
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*  47 */     File goFile = null;
/*  48 */     String gsReference = "";
/*  49 */     boolean gbInline = false;
/*     */     
/*     */     public Attachment(File poFile, boolean pbInline) {
/*  52 */       this.goFile = poFile;
/*  53 */       this.gbInline = pbInline;
/*     */     }
/*     */     
/*     */     public Attachment(File poFile) {
/*  57 */       this(poFile, false);
/*     */     }
/*     */     
/*  60 */     public boolean isInline() { return this.gbInline; }
/*  61 */     public File getFileName() { return this.goFile; }
/*  62 */     public String getReference() { return this.gsReference; }
/*  63 */     public void setReference(String psReference) { this.gsReference = psReference; }
/*     */     
/*     */     public MimeBodyPart toBodyPart() throws MessagingException {
/*  66 */       FileDataSource voDataSource = null;
/*  67 */       MimeBodyPart voBodyPart = new MimeBodyPart();
/*     */       
/*  69 */       if (this.goFile.exists()) {
/*     */         try {
/*  71 */           voDataSource = new FileDataSource(this.goFile.getAbsolutePath());
/*  72 */           voBodyPart.setDataHandler(new DataHandler(voDataSource));
/*  73 */           voBodyPart.setFileName(voDataSource.getName());
/*  74 */           if (isInline()) {
/*  75 */             voBodyPart.setHeader("Content-ID", "<" + voDataSource.getName() + ">");
/*  76 */             voBodyPart.setDisposition("inline");
/*     */           }
/*     */         } catch (MessagingException voMessagingException) {
/*  79 */           throw voMessagingException;
/*     */         }
/*     */       }
/*     */       
/*  83 */       return voBodyPart;
/*     */     }
/*     */   }
/*     */   
/*  87 */   protected static String HOME = "";
/*     */   
/*  89 */   private List<String> TO = new ArrayList();
/*  90 */   private List<String> CC = new ArrayList();
/*  91 */   private List<String> BCC = new ArrayList();
/*  92 */   private List<Attachment> goAttachments = new ArrayList();
/*     */   
/*  94 */   private StringBuffer goHTML = new StringBuffer();
/*  95 */   private StringBuffer goText = new StringBuffer();
/*  96 */   private String gsSender = "";
/*  97 */   private String gsSubject = "";
/*     */   
/*     */ 
/*     */   public static void setWorkingDirectory(String psWorkingDirectory)
/*     */   {
/* 102 */     HOME = psWorkingDirectory;
/*     */   }
/*     */   
/*     */   public void addTO(List<String> poTORecipients) {
/* 106 */     if ((poTORecipients != null) && (poTORecipients.size() > 0)) this.TO.addAll(poTORecipients);
/*     */   }
/*     */   
/*     */   public void addTO(String psTORecipient) {
/* 110 */     if (!StringUtils.isNVL(psTORecipient)) this.TO.add(psTORecipient);
/*     */   }
/*     */   
/*     */   public void addCC(List<String> poCCRecipients) {
/* 114 */     if ((poCCRecipients != null) && (poCCRecipients.size() > 0)) this.CC.addAll(poCCRecipients);
/*     */   }
/*     */   
/*     */   public void addCC(String psCCRecipient) {
/* 118 */     if (!StringUtils.isNVL(psCCRecipient)) this.CC.add(psCCRecipient);
/*     */   }
/*     */   
/*     */   public void addBCC(List<String> poBCCRecipients) {
/* 122 */     if ((poBCCRecipients != null) && (poBCCRecipients.size() > 0)) this.BCC.addAll(poBCCRecipients);
/*     */   }
/*     */   
/*     */   public void addBCC(String psBCCRecipient) {
/* 126 */     if (!StringUtils.isNVL(psBCCRecipient)) this.BCC.add(psBCCRecipient);
/*     */   }
/*     */   
/*     */   public void setSender(String psSender) {
/* 130 */     this.gsSender = psSender;
/*     */   }
/*     */   
/*     */   public void setSubject(String psSubject) {
/* 134 */     this.gsSubject = psSubject;
/*     */   }
/*     */   
/*     */   public void addAttachment(File poFile) {
/* 138 */     this.goAttachments.add(new Attachment(poFile));
/*     */   }
/*     */   
/*     */   public void addInlineAttachment(File poFile) {
/* 142 */     Attachment voAttachment = new Attachment(poFile, true);
/* 143 */     voAttachment.setReference("attachment" + this.goAttachments.size());
/* 144 */     this.goAttachments.add(voAttachment);
/* 145 */     addHTML("<br/><img src=\"cid:" + poFile.getName() + "\">");
/*     */   }
/*     */   
/*     */   public void addHTML(String psHTML) {
/* 149 */     this.goHTML.append(psHTML);
/*     */   }
/*     */   
/*     */   public void addText(String psText) {
/* 153 */     this.goText.append(psText);
/*     */   }
/*     */   
/*     */   public static InternetAddress getInetAddress(String psRecipient) throws AddressException {
/* 157 */     return new InternetAddress(psRecipient);
/*     */   }
/*     */   
/* 160 */   private boolean hasText() { return this.goText.length() > 0; }
/* 161 */   private boolean hasHtml() { return this.goHTML.length() > 0; }
/* 162 */   private boolean hasAttachments() { return this.goAttachments.size() > 0; }
/* 163 */   private boolean hasTORecipients() { return this.TO.size() > 0; }
/* 164 */   private boolean hasCCRecipients() { return this.CC.size() > 0; }
/* 165 */   private boolean hasBCCRecipients() { return this.BCC.size() > 0; }
/*     */   
/*     */   private MimeBodyPart getTextMimeBodyPart() throws MessagingException {
/* 168 */     MimeBodyPart voBodyPart = new MimeBodyPart();
/* 169 */     voBodyPart.setContent(this.goText.toString(), "text/plain");
/* 170 */     return voBodyPart;
/*     */   }
/*     */   
/*     */   private MimeBodyPart getHtmlMimeBodyPart() throws MessagingException {
/* 174 */     MimeBodyPart voBodyPart = new MimeBodyPart();
/* 175 */     String vsHTMLHeader = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"><HTML><HEAD><META http-equiv=Content-Type content=\"text/html; charset=iso-8859-1\"><META content=\"MSHTML 6.00.6000.16481\" name=GENERATOR></HEAD><BODY>";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 180 */     String vsHTMLFooter = "</BODY></HTML>";
/* 181 */     voBodyPart.setContent(vsHTMLHeader + this.goHTML.toString() + vsHTMLFooter, "text/html");
/* 182 */     return voBodyPart;
/*     */   }
/*     */   
/*     */   public InternetAddress[] getRecipients(List<String> poRecipients) throws AddressException {
/* 186 */     List<InternetAddress> voRecipients = new ArrayList();
/* 187 */     String vsRecipient; for (Iterator i$ = poRecipients.iterator(); i$.hasNext(); voRecipients.add(getInetAddress(vsRecipient))) vsRecipient = (String)i$.next();
/* 188 */     return (InternetAddress[])voRecipients.toArray(new InternetAddress[0]);
/*     */   }
/*     */   
/*     */   public MimeMessage toMessage() throws MessagingException {
/* 192 */     MimeMessage voMessage = new MimeMessage(Session.getSession());
/* 193 */     Multipart voMultipart = new MimeMultipart();
/*     */     
/* 195 */     if (!hasTORecipients()) { throw new MessagingException("At least one TO recipient must be especified");
/*     */     }
/* 197 */     if (hasText()) voMultipart.addBodyPart(getTextMimeBodyPart());
/* 198 */     if (hasHtml()) voMultipart.addBodyPart(getHtmlMimeBodyPart());
/* 199 */     if (hasAttachments()) { Attachment voAttachment; for (Iterator i$ = this.goAttachments.iterator(); i$.hasNext(); voMultipart.addBodyPart(voAttachment.toBodyPart())) voAttachment = (Attachment)i$.next();
/*     */     }
/* 201 */     voMessage.setContent(voMultipart);
/* 202 */     voMessage.setContentLanguage(new String[] { "ISO-8859-1" });
/*     */     
/* 204 */     if (hasTORecipients()) voMessage.setRecipients(Message.RecipientType.TO, getRecipients(this.TO));
/* 205 */     if (hasCCRecipients()) voMessage.setRecipients(Message.RecipientType.CC, getRecipients(this.CC));
/* 206 */     if (hasBCCRecipients()) { voMessage.setRecipients(Message.RecipientType.BCC, getRecipients(this.BCC));
/*     */     }
/* 208 */     voMessage.setFrom(getInetAddress(this.gsSender));
/*     */     
/* 210 */     voMessage.setSubject(this.gsSubject);
/*     */     
/* 212 */     return voMessage;
/*     */   }
/*     */   
/*     */   public Message parse(javax.mail.Message poMessage) {
/* 216 */     Message voMessage = new Message();
/*     */     try {
/* 218 */       for (Address voIA : poMessage.getRecipients(Message.RecipientType.TO)) voMessage.addTO(voIA.toString());
/* 219 */       for (Address voIA : poMessage.getRecipients(Message.RecipientType.CC)) voMessage.addCC(voIA.toString());
/* 220 */       for (Address voIA : poMessage.getRecipients(Message.RecipientType.BCC)) voMessage.addBCC(voIA.toString());
/*     */     } catch (MessagingException voME) {
/* 222 */       voME.printStackTrace();
/*     */     }
/* 224 */     return voMessage;
/*     */   }
/*     */   
/*     */   public void send() throws MessagingException {
/* 228 */     Transport.send(toMessage());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\messaging\mail\Message.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */