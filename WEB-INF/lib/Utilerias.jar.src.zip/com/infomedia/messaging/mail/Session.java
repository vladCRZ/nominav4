/*    */ package com.infomedia.messaging.mail;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.mail.Authenticator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Session
/*    */ {
/* 15 */   private static final Session INSTANCE = new Session();
/* 16 */   private javax.mail.Session session = null;
/*    */   
/*    */   public void config(Properties properties)
/*    */   {
/* 20 */     INSTANCE.session = javax.mail.Session.getInstance(properties);
/*    */   }
/*    */   
/* 23 */   public void config(Properties properties, Authenticator authenticator) { INSTANCE.session = javax.mail.Session.getInstance(properties, authenticator); }
/*    */   
/* 25 */   public static Session getInstance() { return INSTANCE; }
/* 26 */   public static javax.mail.Session getSession() { return INSTANCE.session; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\messaging\mail\Session.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */