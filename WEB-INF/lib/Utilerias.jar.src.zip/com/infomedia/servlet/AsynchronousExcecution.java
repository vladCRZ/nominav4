/*     */ package com.infomedia.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import org.apache.jasper.runtime.JspWriterImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsynchronousExcecution
/*     */ {
/*     */   public static final String EXECUTION = "execute";
/*     */   
/*     */   private String getClass(String psURI)
/*     */     throws Exception
/*     */   {
/*  49 */     return psURI.substring(psURI.lastIndexOf("/") + 1, psURI.indexOf(".asyn"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doExecution(HttpServletRequest poRequest, JspWriter poWriter)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  67 */       Class<?> voClass = Class.forName(getClass(poRequest.getRequestURI()));
/*  68 */       if (!AsynchronousProcess.class.isAssignableFrom(voClass)) throw new Exception("ERROR:" + voClass.getName() + " doesn't implement AsynchronousProcess interface");
/*  69 */       Object voInstance = voClass.newInstance();
/*  70 */       Method voExecute = voClass.getDeclaredMethod("execute", new Class[] { ServletUtils.HttpRequestParameters.class, JspWriter.class });
/*  71 */       voExecute.invoke(voInstance, new Object[] { ServletUtils.getParameters(poRequest), poWriter });
/*     */     } catch (Exception voEXC) {
/*  73 */       throw voEXC;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doProcess(HttpServletRequest poRequest, HttpServletResponse poResponse)
/*     */     throws IOException, ServletException
/*     */   {
/*  89 */     JspWriter voOut = null;
/*     */     
/*  91 */     synchronized (this)
/*     */     {
/*     */       try {
/*  94 */         poResponse.setHeader("Expires", "0");
/*     */         
/*  96 */         voOut = new JspWriterImpl(poResponse);
/*     */         
/*  98 */         doExecution(poRequest, voOut);
/*     */       } catch (Exception voIgnorar) {
/* 100 */         voIgnorar.printStackTrace();
/* 101 */         if (voIgnorar.getCause() != null) voIgnorar.getCause().printStackTrace();
/*     */       }
/*     */       finally {
/* 104 */         if (voOut != null) {
/* 105 */           voOut.flush();
/* 106 */           voOut.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\AsynchronousExcecution.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */