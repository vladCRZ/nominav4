package com.infomedia.servlet;

import javax.servlet.jsp.JspWriter;

public abstract interface AsynchronousProcess
{
  public abstract void execute(ServletUtils.HttpRequestParameters paramHttpRequestParameters, JspWriter paramJspWriter)
    throws Exception;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\AsynchronousProcess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */