/*    */ package com.infomedia.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsynchronousRequest
/*    */   extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void init(ServletConfig poConfig)
/*    */     throws ServletException
/*    */   {
/* 40 */     super.init(poConfig);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doPost(HttpServletRequest poRequest, HttpServletResponse poResponse)
/*    */     throws IOException, ServletException
/*    */   {
/* 54 */     AsynchronousExcecution voExecution = new AsynchronousExcecution();
/* 55 */     voExecution.doProcess(poRequest, poResponse);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doGet(HttpServletRequest poRequest, HttpServletResponse poResponse)
/*    */     throws IOException, ServletException
/*    */   {
/* 69 */     doPost(poRequest, poResponse);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\AsynchronousRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */