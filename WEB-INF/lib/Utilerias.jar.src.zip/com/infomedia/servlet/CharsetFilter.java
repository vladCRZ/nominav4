/*    */ package com.infomedia.servlet;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintStream;
/*    */ import java.nio.charset.Charset;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharsetFilter
/*    */   implements Filter
/*    */ {
/*    */   public void init(FilterConfig config)
/*    */     throws ServletException
/*    */   {}
/*    */   
/*    */   private static String getDefaultCharSet()
/*    */   {
/* 34 */     OutputStreamWriter writer = new OutputStreamWriter(new ByteArrayOutputStream());
/* 35 */     String enc = writer.getEncoding();
/* 36 */     return enc;
/*    */   }
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 40 */     System.out.println("Seting filter");
/* 41 */     System.out.println("Default Charset=" + Charset.defaultCharset());
/* 42 */     System.out.println("Default Charset in Use=" + getDefaultCharSet());
/* 43 */     request.setCharacterEncoding("UTF-8");
/* 44 */     response.setCharacterEncoding("UTF-8");
/* 45 */     System.out.println("Default Charset=" + Charset.defaultCharset());
/* 46 */     System.out.println("Default Charset in Use=" + getDefaultCharSet());
/* 47 */     chain.doFilter(request, response);
/*    */   }
/*    */   
/*    */   public void destroy() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\CharsetFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */