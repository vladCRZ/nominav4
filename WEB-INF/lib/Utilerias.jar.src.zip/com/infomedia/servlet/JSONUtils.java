/*     */ package com.infomedia.servlet;
/*     */ 
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JSONUtils
/*     */ {
/*     */   public static Map<String, String> getJSONParameters(JsonElement poJSONElement)
/*     */   {
/*  35 */     Map<String, String> voParameters = new HashMap();
/*  36 */     JsonObject voObject = poJSONElement.getAsJsonObject();
/*  37 */     Iterator<Map.Entry<String, JsonElement>> voJSONElements = voObject.entrySet().iterator();
/*     */     
/*     */ 
/*  40 */     while (voJSONElements.hasNext()) {
/*  41 */       Map.Entry<String, JsonElement> voJSONElement = (Map.Entry)voJSONElements.next();
/*  42 */       if (((JsonElement)voJSONElement.getValue()).isJsonObject()) {
/*  43 */         voParameters.putAll(getJSONParameters((JsonElement)voJSONElement.getValue()));
/*     */       } else {
/*  45 */         voParameters.put(voJSONElement.getKey(), ((JsonElement)voJSONElement.getValue()).getAsString());
/*     */       }
/*     */     }
/*  48 */     return voParameters;
/*     */   }
/*     */   
/*     */   public static String parseString(String psString) {
/*  52 */     return psString.replaceAll("%7B", "{").replaceAll("%22", "\"").replaceAll("%7D", "}").replaceAll("%20", " ").replaceAll("%0A", "").replaceAll("%C1", "Á").replaceAll("%C9", "É").replaceAll("%CD", "Í").replaceAll("%C1", "Ó").replaceAll("%D3", "Ú").replaceAll("%E1", "á").replaceAll("%E9", "é").replaceAll("%ED", "í").replaceAll("%F3", "ó").replaceAll("%FA", "ú").replaceAll("%D1", "Ñ").replaceAll("%F1", "ñ").replaceAll("%C3%80", "À").replaceAll("%C3%81", "Á").replaceAll("%C3%82", "Â").replaceAll("%C3%83", "Ã").replaceAll("%C3%84", "Ä").replaceAll("%C3%85", "Å").replaceAll("%C3%86", "Æ").replaceAll("%C3%87", "Ç").replaceAll("%C3%88", "È").replaceAll("%C3%89", "É").replaceAll("%C3%8A", "Ê").replaceAll("%C3%8B", "Ë").replaceAll("%C3%8C", "Ì").replaceAll("%C3%8D", "Í").replaceAll("%C3%8E", "Î").replaceAll("%C3%8F", "Ï").replaceAll("%C3%90", "Ð").replaceAll("%C3%91", "Ñ").replaceAll("%C3%92", "Ò").replaceAll("%C3%93", "Ó").replaceAll("%C3%94", "Ô").replaceAll("%C3%95", "Õ").replaceAll("%C3%96", "Ö").replaceAll("%C3%97", "×").replaceAll("%C3%98", "Ø").replaceAll("%C3%99", "Ù").replaceAll("%C3%9A", "Ú").replaceAll("%C3%9B", "Û").replaceAll("%C3%9C", "Ü").replaceAll("%C3%9D", "Ý").replaceAll("%C3%9E", "Þ").replaceAll("%C3%9F", "ß").replaceAll("%C3%A0", "à").replaceAll("%C3%A1", "á").replaceAll("%C3%A2", "â").replaceAll("%C3%A3", "ã").replaceAll("%C3%A4", "ä").replaceAll("%C3%A5", "å").replaceAll("%C3%A6", "æ").replaceAll("%C3%A7", "ç").replaceAll("%C3%A8", "è").replaceAll("%C3%A9", "é").replaceAll("%C3%AA", "ê").replaceAll("%C3%AB", "ë").replaceAll("%C3%AC", "ì").replaceAll("%C3%AD", "í").replaceAll("%C3%AE", "î").replaceAll("%C3%AF", "ï").replaceAll("%C3%B0", "ð").replaceAll("%C3%B1", "ñ").replaceAll("%C3%B2", "ò").replaceAll("%C3%B3", "ó").replaceAll("%C3%B4", "ô").replaceAll("%C3%B5", "õ").replaceAll("%C3%B6", "ö").replaceAll("%C3%B7", "÷").replaceAll("%C3%B8", "ø").replaceAll("%C3%B9", "ù").replaceAll("%C3%BA", "ú").replaceAll("%C3%BB", "û").replaceAll("%C3%BC", "ü");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String encodeString(String psString)
/*     */   {
/* 133 */     return psString.replaceAll("À", "%C3%80").replaceAll("Á", "%C3%81").replaceAll("Â", "%C3%82").replaceAll("Ã", "%C3%83").replaceAll("Ä", "%C3%84").replaceAll("Å", "%C3%85").replaceAll("Æ", "%C3%86").replaceAll("Ç", "%C3%87").replaceAll("È", "%C3%88").replaceAll("É", "%C3%89").replaceAll("Ê", "%C3%8A").replaceAll("Ë", "%C3%8B").replaceAll("Ì", "%C3%8C").replaceAll("Í", "%C3%8D").replaceAll("Î", "%C3%8E").replaceAll("Ï", "%C3%8F").replaceAll("Ð", "%C3%90").replaceAll("Ñ", "%C3%91").replaceAll("Ò", "%C3%92").replaceAll("Ó", "%C3%93").replaceAll("Ô", "%C3%94").replaceAll("Õ", "%C3%95").replaceAll("Ö", "%C3%96").replaceAll("×", "%C3%97").replaceAll("Ø", "%C3%98").replaceAll("Ù", "%C3%99").replaceAll("Ú", "%C3%9A").replaceAll("Û", "%C3%9B").replaceAll("Ü", "%C3%9C").replaceAll("Ý", "%C3%9D").replaceAll("Þ", "%C3%9E").replaceAll("ß", "%C3%9F").replaceAll("à", "%C3%A0").replaceAll("á", "%C3%A1").replaceAll("â", "%C3%A2").replaceAll("ã", "%C3%A3").replaceAll("ä", "%C3%A4").replaceAll("å", "%C3%A5").replaceAll("æ", "%C3%A6").replaceAll("ç", "%C3%A7").replaceAll("è", "%C3%A8").replaceAll("é", "%C3%A9").replaceAll("ê", "%C3%AA").replaceAll("ë", "%C3%AB").replaceAll("ì", "%C3%AC").replaceAll("í", "%C3%AD").replaceAll("î", "%C3%AE").replaceAll("ï", "%C3%AF").replaceAll("ð", "%C3%B0").replaceAll("ñ", "%C3%B1").replaceAll("ò", "%C3%B2").replaceAll("ó", "%C3%B3").replaceAll("ô", "%C3%B4").replaceAll("õ", "%C3%B5").replaceAll("ö", "%C3%B6").replaceAll("÷", "%C3%B7").replaceAll("ø", "%C3%B8").replaceAll("ù", "%C3%B9").replaceAll("ú", "%C3%BA").replaceAll("û", "%C3%BB").replaceAll("ü", "%C3%BC");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonElement parseJSONElement(String psString)
/*     */   {
/* 198 */     JsonParser voParser = new JsonParser();
/* 199 */     JsonElement voJSONObject = null;
/* 200 */     String vsString = parseString(psString);
/*     */     try {
/* 202 */       voJSONObject = voParser.parse(vsString);
/* 203 */       voParser.parse(psString);
/*     */     }
/*     */     catch (JsonSyntaxException JSONE) {}
/* 206 */     return voJSONObject;
/*     */   }
/*     */   
/*     */   public static boolean isJSONString(String psString) {
/* 210 */     boolean isJSON = false;
/* 211 */     JsonParser voParser = new JsonParser();
/*     */     
/* 213 */     String vsString = parseString(psString);
/*     */     try
/*     */     {
/* 216 */       JsonElement voJSONObject = voParser.parse(vsString);
/* 217 */       isJSON = (voJSONObject.isJsonArray()) || (voJSONObject.isJsonObject());
/*     */     }
/*     */     catch (JsonSyntaxException JSONE) {}
/* 220 */     return isJSON;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\JSONUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */