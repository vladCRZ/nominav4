/*     */ package com.infomedia.servlet;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServletUtils
/*     */ {
/*  26 */   private static final Logger log = Logger.getLogger(ServletUtils.class);
/*     */   
/*     */   public static final String HTTP_SCHEME = "http";
/*     */   public static final String HTTPS_SCHEME = "https";
/*     */   public static final int HTTP_DEFAULT_PORT = 80;
/*     */   public static final int HTTPS_DEFAULT_PORT = 443;
/*     */   
/*     */   public static class HttpRequestParameters
/*     */   {
/*     */     private final Map<String, String> goParameters;
/*     */     private final Map<String, UploadFile> goAttachments;
/*     */     
/*     */     public HttpRequestParameters()
/*     */     {
/*  40 */       this.goAttachments = new HashMap();
/*  41 */       this.goParameters = new HashMap();
/*     */     }
/*     */     
/*     */     public void setParameter(String psParameterName, String psParameterValue) {
/*  45 */       this.goParameters.put(psParameterName, psParameterValue);
/*     */     }
/*     */     
/*     */     public Map<String, String> getParameters() {
/*  49 */       return this.goParameters;
/*     */     }
/*     */     
/*  52 */     public void setParameters(Map<String, String> poParameterValues) { this.goParameters.putAll(poParameterValues); }
/*     */     
/*     */     public void setAttachment(String psAttachmentName, UploadFile poAttachment)
/*     */     {
/*  56 */       this.goAttachments.put(psAttachmentName, poAttachment);
/*     */     }
/*     */     
/*     */     public Iterable<String> parameterNames() {
/*  60 */       return this.goParameters.keySet();
/*     */     }
/*     */     
/*     */     public Iterable<String> attachmentNames() {
/*  64 */       return this.goAttachments.keySet();
/*     */     }
/*     */     
/*     */     public String getParameter(String psParameterName) {
/*  68 */       return this.goParameters.containsKey(psParameterName) ? (String)this.goParameters.get(psParameterName) : "";
/*     */     }
/*     */     
/*     */     public UploadFile getAttachment(String psAttachmentName) {
/*  72 */       return this.goAttachments.containsKey(psAttachmentName) ? (UploadFile)this.goAttachments.get(psAttachmentName) : null;
/*     */     }
/*     */     
/*     */     public boolean hasParameter(String psParameterName) {
/*  76 */       return !StringUtils.isNVL((String)this.goParameters.get(psParameterName));
/*     */     }
/*     */     
/*     */     public boolean hasAttachment(String psAttachmentName) {
/*  80 */       return this.goAttachments.get(psAttachmentName) != null;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  84 */       StringBuilder str = new StringBuilder(getClass().getName());
/*     */       
/*  86 */       for (String parameter : parameterNames()) {
/*  87 */         str.append("\nPRM: ").append(parameter).append("=").append(getParameter(parameter));
/*     */       }
/*  89 */       for (String attachment : attachmentNames()) {
/*  90 */         str.append("\nATT: ").append(attachment).append("=").append(getAttachment(attachment).getFileName());
/*     */       }
/*  92 */       ServletUtils.log.debug(str);
/*  93 */       return str.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getContextURL(HttpServletRequest poRequest) {
/*  98 */     StringBuilder voURL = new StringBuilder();
/*     */     
/* 100 */     voURL.append(poRequest.getScheme());
/* 101 */     voURL.append("://");
/* 102 */     voURL.append(poRequest.getServerName());
/* 103 */     voURL.append(":");
/* 104 */     voURL.append(poRequest.getServerPort());
/* 105 */     voURL.append("/");
/*     */     
/* 107 */     return voURL.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getRealPath(HttpServletRequest poRequest, String psPath)
/*     */   {
/* 121 */     return poRequest.getSession().getServletContext().getRealPath(psPath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpRequestParameters getSinglePartParameters(HttpServletRequest poRequest)
/*     */   {
/* 134 */     Enumeration voParametros = poRequest.getParameterNames();
/* 135 */     HttpRequestParameters voRetorno = new HttpRequestParameters();
/*     */     
/*     */ 
/*     */ 
/* 139 */     log.info("Reading Singlepart Parameters");
/* 140 */     while (voParametros.hasMoreElements()) {
/* 141 */       String vsParametro = (String)voParametros.nextElement();
/* 142 */       String vsValor = poRequest.getParameter(vsParametro);
/* 143 */       log.debug(vsParametro + ":" + vsValor);
/* 144 */       if (JSONUtils.isJSONString(vsValor)) {
/* 145 */         voRetorno.setParameters(JSONUtils.getJSONParameters(JSONUtils.parseJSONElement(vsValor)));
/*     */       } else {
/* 147 */         voRetorno.setParameter(vsParametro, vsValor);
/*     */       }
/*     */     }
/* 150 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpRequestParameters getMultiPartParameters(HttpServletRequest poRequest)
/*     */   {
/* 163 */     ServletFileUpload voFileUpload = new ServletFileUpload(new DiskFileItemFactory());
/* 164 */     HttpRequestParameters voParametros = new HttpRequestParameters();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 169 */       log.info("Reading Multipart Parameters");
/* 170 */       List<FileItem> items = voFileUpload.parseRequest(poRequest);
/* 171 */       log.info(items);
/* 172 */       for (FileItem voItem : items) {
/* 173 */         log.debug("Reading field");
/* 174 */         FileItem voFileItem = voItem;
/* 175 */         String vsFieldName = voFileItem.getFieldName();
/* 176 */         log.debug("Reading field " + vsFieldName);
/* 177 */         if (voFileItem.isFormField()) {
/* 178 */           log.debug("Reading form field " + vsFieldName + "=" + voFileItem.getString());
/* 179 */           if (!StringUtils.isNVL(voFileItem.getString())) {
/* 180 */             if (JSONUtils.isJSONString(voFileItem.getString())) {
/* 181 */               voParametros.setParameters(JSONUtils.getJSONParameters(JSONUtils.parseJSONElement(voFileItem.getString())));
/*     */             } else {
/* 183 */               voParametros.setParameter(vsFieldName, voFileItem.getString());
/*     */             }
/*     */           }
/*     */         } else {
/* 187 */           log.debug("Reading file attachment " + vsFieldName + "=" + voFileItem);
/* 188 */           vsFieldName = vsFieldName.replaceAll(":moduleFormPage:moduleFormSection", "");
/* 189 */           voParametros.setAttachment(vsFieldName, UploadFile.parse(voFileItem));
/*     */         }
/*     */       }
/* 192 */       System.out.println("Al FileItems readed");
/*     */     } catch (FileUploadException FUE) {
/* 194 */       log.error(FUE);
/*     */     } catch (Exception E) {
/* 196 */       log.error(E);
/*     */     }
/*     */     
/* 199 */     System.out.println("Reading parameters done");
/* 200 */     return voParametros;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpRequestParameters getParameters(HttpServletRequest poRequest)
/*     */   {
/* 213 */     return ServletFileUpload.isMultipartContent(poRequest) ? getMultiPartParameters(poRequest) : getSinglePartParameters(poRequest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getHTTPBasicAuthenticator(HttpServletRequest poRequest)
/*     */   {
/* 226 */     String vsHeader = poRequest.getHeader("authorization");
/*     */     
/* 228 */     assert (vsHeader != null);
/* 229 */     assert (vsHeader.substring(0, 6).equals("Basic "));
/* 230 */     return new String(new Base64().decode(vsHeader.substring(6).getBytes()));
/*     */   }
/*     */   
/*     */   public static boolean isHttpDefaultPort(HttpServletRequest poRequest) {
/* 234 */     return poRequest.getServerPort() == 80;
/*     */   }
/*     */   
/*     */   public static boolean isHttpsDefaultPort(HttpServletRequest poRequest) {
/* 238 */     return poRequest.getServerPort() == 443;
/*     */   }
/*     */   
/*     */   public static boolean isHttp(HttpServletRequest poRequest) {
/* 242 */     return "http".equals(poRequest.getScheme());
/*     */   }
/*     */   
/*     */   public static boolean isHttps(HttpServletRequest poRequest) {
/* 246 */     return "https".equals(poRequest.getScheme());
/*     */   }
/*     */   
/*     */   public static boolean isDefaultPort(HttpServletRequest poRequest) {
/* 250 */     return ((isHttp(poRequest)) && (isHttpDefaultPort(poRequest))) || ((isHttps(poRequest)) && (isHttpsDefaultPort(poRequest)));
/*     */   }
/*     */   
/*     */   public static String getRequestURI(HttpServletRequest poRequest)
/*     */   {
/* 255 */     return poRequest.getScheme() + "://" + poRequest.getServerName() + (isDefaultPort(poRequest) ? "" : new StringBuilder().append(":").append(poRequest.getServerPort()).toString()) + poRequest.getRequestURI();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\ServletUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */