/*     */ package com.infomedia.servlet;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UploadFile
/*     */ {
/*  23 */   private String gsFileName = "";
/*  24 */   private String gsFileType = "";
/*  25 */   private byte[] goBuffer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private UploadFile(String psFileName, String psFileType, byte[] poBuffer)
/*     */   {
/*  38 */     this.gsFileName = psFileName;
/*  39 */     this.gsFileType = psFileType;
/*  40 */     this.goBuffer = poBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileName()
/*     */   {
/*  51 */     return this.gsFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileType()
/*     */   {
/*  61 */     return this.gsFileType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBuffer()
/*     */   {
/*  71 */     return this.goBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] fncoGetBytes(FileItem poFileItem)
/*     */   {
/*  83 */     InputStream voInput = null;
/*  84 */     byte[] voRetorno = null;
/*     */     try
/*     */     {
/*  87 */       voInput = poFileItem.getInputStream();
/*  88 */       voRetorno = new byte[voInput.available()];
/*  89 */       if (voInput.read(voRetorno) <= 0) throw new Exception("No es posible leer el archivo");
/*     */     } catch (Exception voException) {
/*  91 */       voRetorno = null;
/*     */     }
/*  93 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UploadFile parse(FileItem poFileItem)
/*     */   {
/* 106 */     return new UploadFile(poFileItem.getName(), poFileItem.getContentType(), fncoGetBytes(poFileItem));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\UploadFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */