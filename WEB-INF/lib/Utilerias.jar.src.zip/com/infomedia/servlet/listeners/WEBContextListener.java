/*    */ package com.infomedia.servlet.listeners;
/*    */ 
/*    */ import com.infomedia.context.WEBServletContext;
/*    */ import java.io.PrintStream;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WEBContextListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   public void contextDestroyed(ServletContextEvent poSCE) {}
/*    */   
/*    */   public void contextInitialized(ServletContextEvent poSCE)
/*    */   {
/*    */     try
/*    */     {
/* 44 */       System.out.println("Contexto inicializado");
/* 45 */       ServletContext voContext = poSCE.getServletContext();
/* 46 */       WEBServletContext.getInstance().setContext(voContext);
/* 47 */       voContext.log("WEBContextListener.contextInitialized:Iniciatializing WEBContext");
/*    */     } catch (Exception voEXC) {
/* 49 */       voEXC.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedia\servlet\listeners\WEBContextListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */