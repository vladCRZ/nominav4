/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BeanUtils
/*     */ {
/*     */   public static final String GETTER_PREFIX = "get";
/*     */   public static final String SETTER_PREFIX = "set";
/*     */   public static final String GET_CLASS_METHOD = "getClass";
/*     */   
/*     */   public static boolean isGetter(Method poMetodo)
/*     */   {
/*  40 */     return (poMetodo.getName().startsWith("get")) && (poMetodo.getParameterTypes().length == 0) && (!poMetodo.getName().equals("getClass")) && (!poMetodo.getReturnType().getClass().equals(Void.TYPE));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isSetter(Method poMetodo)
/*     */   {
/*  56 */     return (poMetodo.getName().startsWith("set")) && (poMetodo.getParameterTypes().length == 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<Method> listGetters(Class<?> poClase)
/*     */   {
/*  70 */     Iterator<Method> poMetodos = Arrays.asList(poClase.getMethods()).iterator();
/*  71 */     List<Method> voGetters = new ArrayList();
/*  72 */     Method voMetodo = null;
/*     */     
/*  74 */     while (poMetodos.hasNext()) {
/*  75 */       voMetodo = (Method)poMetodos.next();
/*  76 */       if (isGetter(voMetodo)) { voGetters.add(voMetodo);
/*     */       }
/*     */     }
/*  79 */     return voGetters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<Method> listSetters(Class<?> poClase)
/*     */   {
/*  92 */     Iterator<Method> poMetodos = Arrays.asList(poClase.getMethods()).iterator();
/*  93 */     List<Method> voSetters = new ArrayList();
/*  94 */     Method voMetodo = null;
/*     */     
/*  96 */     while (poMetodos.hasNext()) {
/*  97 */       voMetodo = (Method)poMetodos.next();
/*  98 */       if (isSetter(voMetodo)) { voSetters.add(voMetodo);
/*     */       }
/*     */     }
/* 101 */     return voSetters;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\BeanUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */