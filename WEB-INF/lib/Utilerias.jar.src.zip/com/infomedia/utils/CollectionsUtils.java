/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.text.ParseException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionsUtils
/*     */ {
/*     */   public static class StrIntComparator
/*     */     implements Comparator<String>
/*     */   {
/*     */     public int compare(String psKey1, String psKey2)
/*     */     {
/*  46 */       int viKey1 = Integer.parseInt(psKey1);
/*  47 */       int viKey2 = Integer.parseInt(psKey2);
/*  48 */       return viKey1 < viKey2 ? -1 : viKey1 > viKey2 ? 1 : 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class CalendarComparator
/*     */     implements Comparator<String>
/*     */   {
/*     */     public int compare(String psKey1, String psKey2)
/*     */     {
/*  63 */       Calendar voKey1 = DateUtils.fncoCalendar(psKey1);
/*  64 */       Calendar voKey2 = DateUtils.fncoCalendar(psKey2);
/*  65 */       return DateUtils.fncbCompare(voKey1, voKey2, 2) ? -1 : DateUtils.fncbCompare(voKey1, voKey2, 4) ? 1 : 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class IntegerComparator
/*     */     implements Comparator<Integer>
/*     */   {
/*     */     public int compare(Integer psKey1, Integer psKey2)
/*     */     {
/*  80 */       int viKey1 = psKey1.intValue();
/*  81 */       int viKey2 = psKey2.intValue();
/*  82 */       return viKey1 < viKey2 ? -1 : viKey1 > viKey2 ? 1 : 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcParseMap(Map<String, String> poParsed, String psMapString, String psSeparator, String psAssign)
/*     */     throws ParseException
/*     */   {
/* 100 */     Iterator<String> voEntries = Arrays.asList(psMapString.split("[" + psSeparator + "]")).iterator();
/*     */     
/*     */ 
/* 103 */     while (voEntries.hasNext()) {
/* 104 */       String vsEntryString = (String)voEntries.next();
/* 105 */       String[] voEntry = vsEntryString.split("[" + psAssign + "]");
/* 106 */       if (voEntry.length != 2) throw new ParseException("Error parseando la cadena como Mapa", psMapString.indexOf(vsEntryString));
/* 107 */       poParsed.put(voEntry[0], voEntry[1]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> fncoParseMap(String psMapString, String psSeparator, String psAssign)
/*     */     throws ParseException
/*     */   {
/* 125 */     Map<String, String> voParsed = new HashMap();
/* 126 */     prcParseMap(voParsed, psMapString, psSeparator, psAssign);
/* 127 */     return voParsed;
/*     */   }
/*     */   
/* 130 */   public static Map<String, String> fncoParseMap(String psMapString, String psSeparator) throws ParseException { return fncoParseMap(psMapString, psSeparator, "="); }
/*     */   
/*     */   public static Map<String, String> fncoParseMap(String psMapString) throws ParseException {
/* 133 */     return fncoParseMap(psMapString, "|");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<String, String> fncoParseSortedMap(String psMapString, String psSeparator, String psAssign)
/*     */     throws ParseException
/*     */   {
/* 150 */     Map<String, String> voParsed = new TreeMap();
/* 151 */     prcParseMap(voParsed, psMapString, psSeparator, psAssign);
/* 152 */     return voParsed;
/*     */   }
/*     */   
/* 155 */   public static Map<String, String> fncoParseSortedMap(String psMapString, String psSeparator) throws ParseException { return fncoParseSortedMap(psMapString, psSeparator, "="); }
/*     */   
/*     */   public static Map<String, String> fncoParseSortedMap(String psMapString) throws ParseException {
/* 158 */     return fncoParseSortedMap(psMapString, "|");
/*     */   }
/*     */   
/*     */   public static List<String> fncoParseList(String psListString, String psSeparator) {
/* 162 */     return Arrays.asList(psListString.split(psSeparator));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsIterableAsString(Iterable<String> poIterable, String psSeparator)
/*     */   {
/* 177 */     String vsString = "";
/*     */     
/* 179 */     for (String vsValue : poIterable) {
/* 180 */       vsString = vsString + (vsString.equals("") ? "" : psSeparator);
/* 181 */       vsString = vsString + vsValue;
/*     */     }
/*     */     
/* 184 */     return vsString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsListAsString(Collection<String> poCollection, String psSeparator)
/*     */   {
/* 199 */     return fncsIterableAsString(poCollection, psSeparator);
/*     */   }
/*     */   
/* 202 */   public static String fncsListAsString(Collection<String> poCollection) { return fncsListAsString(poCollection, ","); }
/*     */   
/*     */   public static String[] toArray(Collection<String> poCollection)
/*     */   {
/* 206 */     return (String[])poCollection.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsArrayAsString(String[] poArray, String psSeparator)
/*     */   {
/* 221 */     String vsString = "";
/*     */     
/* 223 */     for (String vsValue : poArray) {
/* 224 */       vsString = vsString + (vsString.equals("") ? "" : psSeparator);
/* 225 */       vsString = vsString + vsValue;
/*     */     }
/*     */     
/* 228 */     return vsString;
/*     */   }
/*     */   
/* 231 */   public static String fncsArrayAsString(String[] poArray) { return fncsArrayAsString(poArray, ","); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsEnumAsString(Class<?> poClass, String psSeparator)
/*     */   {
/* 246 */     String vsEnumValues = "";
/* 247 */     if (poClass.isEnum()) {
/* 248 */       for (Field voField : poClass.getDeclaredFields()) {
/* 249 */         if (Modifier.isPublic(voField.getModifiers())) {
/* 250 */           vsEnumValues = vsEnumValues + (vsEnumValues.equals("") ? "" : psSeparator);
/* 251 */           vsEnumValues = vsEnumValues + voField.getName();
/*     */         }
/*     */       }
/*     */     }
/* 255 */     return vsEnumValues;
/*     */   }
/*     */   
/* 258 */   public static String fncsEnumAsString(Class<?> poClass) { return fncsEnumAsString(poClass, ","); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] fncsEnumAsArray(Class<?> poClass, String psSeparator)
/*     */   {
/* 273 */     return fncsEnumAsString(poClass, psSeparator).split(psSeparator);
/*     */   }
/*     */   
/* 276 */   public static String[] fncsEnumAsArray(Class<?> poClass) { return fncsEnumAsArray(poClass, ","); }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\CollectionsUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */