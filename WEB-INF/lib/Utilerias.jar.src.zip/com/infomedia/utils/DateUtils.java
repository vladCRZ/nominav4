/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DateUtils
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(DateUtils.class);
/*     */   
/*  23 */   public static final String[] DIAS_SEMANA = { "DOMINGO", "LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO" };
/*     */   
/*  25 */   public static final String[] MESES_ANIO = { "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE" };
/*     */   
/*     */   public static final int MILIS_POR_SEGUNDO = 1000;
/*     */   
/*     */   public static final int MILIS_POR_MINUTO = 60000;
/*     */   
/*     */   public static final int MILIS_POR_HORA = 3600000;
/*     */   
/*     */   public static final int MILIS_POR_DIA = 86400000;
/*     */   public static final int SEGUNDOS_POR_MINUTO = 60;
/*     */   public static final int SEGUNDOS_POR_HORA = 3600;
/*     */   public static final int SEGUNDOS_POR_DIA = 86400;
/*     */   public static final int MINUTOS_POR_HORA = 60;
/*     */   public static final int MINUTOS_POR_DIA = 1440;
/*     */   public static final int MASK_EQUAL = 1;
/*     */   public static final int MASK_MINOR = 2;
/*     */   public static final int MASK_GREATER = 4;
/*  42 */   public static final Locale REGIONAL_MEXICO = new Locale("es", "MX");
/*  43 */   public static final TimeZone TIMEZONE_MEXICO = TimeZone.getTimeZone("GMT-6");
/*  44 */   public static final TimeZone TIMEZONE_GREENWICH = TimeZone.getTimeZone("GMT-0");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int fnciFirstDayOfYear(int piYear)
/*     */   {
/*  64 */     Calendar voFecha = Calendar.getInstance();
/*     */     
/*  66 */     voFecha.set(1, piYear);
/*  67 */     voFecha.set(6, 1);
/*     */     
/*  69 */     return voFecha.get(7);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int monthsSince(Calendar poReference, Calendar poTest)
/*     */   {
/*  86 */     return (poTest.get(1) - poReference.get(1)) * 12 + (poTest.get(2) - poReference.get(2));
/*     */   }
/*     */   
/*     */   public static int monthsSince(Calendar poReference) {
/*  90 */     return monthsSince(poReference, Calendar.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int quincenasSince(Calendar poReference, Calendar poTest)
/*     */   {
/* 107 */     int viQuincenas = monthsSince(poReference, poTest) * 2;
/* 108 */     viQuincenas += ((poReference.get(5) < 16) && (poTest.get(5) > 15) ? 1 : 0);
/* 109 */     viQuincenas -= ((poReference.get(5) > 15) && (poTest.get(5) < 16) ? 1 : 0);
/* 110 */     return viQuincenas;
/*     */   }
/*     */   
/*     */   public static int quincensSince(Calendar poReference) {
/* 114 */     return quincenasSince(poReference, Calendar.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addQuincena(Calendar poDate, int piAdd)
/*     */   {
/* 131 */     int viAdd = 0;
/*     */     
/* 133 */     while (viAdd++ < piAdd) {
/* 134 */       int viCurrentDay = poDate.get(5);
/* 135 */       boolean vbFirst = viCurrentDay < 16;
/* 136 */       int viDiasQuincena = vbFirst ? 15 : lastDayOfMonth(poDate) - 15;
/* 137 */       if ((vbFirst) || (poDate.isLenient())) {
/* 138 */         poDate.add(5, viDiasQuincena);
/*     */       } else {
/* 140 */         poDate.add(2, 1);
/* 141 */         poDate.set(5, viCurrentDay - 15);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int lastDayOfMonth(Calendar poDate)
/*     */   {
/* 158 */     Calendar voDate = fncoCalendar(poDate.getTimeInMillis());
/* 159 */     voDate.add(2, 1);
/* 160 */     voDate.set(5, 0);
/* 161 */     return voDate.get(5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int weeksInMonth(Calendar poDate)
/*     */   {
/* 176 */     Calendar voDate = fncoCalendar(poDate.getTimeInMillis());
/* 177 */     voDate.set(5, lastDayOfMonth(poDate));
/* 178 */     return voDate.get(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int dayOfWeekInMonth(Calendar poReference, int piDayOfWeek, int piDay)
/*     */   {
/* 197 */     Calendar voFecha = Calendar.getInstance();
/*     */     
/* 199 */     voFecha.setTimeInMillis(poReference.getTimeInMillis());
/* 200 */     voFecha.set(7, piDayOfWeek);
/* 201 */     voFecha.set(8, piDay);
/*     */     
/* 203 */     return poReference.get(2) == voFecha.get(2) ? voFecha.get(5) : 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int fnciSemana(Calendar poFecha, boolean pbISO)
/*     */   {
/* 216 */     Calendar voFecha = Calendar.getInstance();
/*     */     
/* 218 */     voFecha.setTimeInMillis(poFecha.getTimeInMillis());
/* 219 */     if (pbISO) {
/* 220 */       voFecha.setFirstDayOfWeek(2);
/* 221 */       voFecha.setMinimalDaysInFirstWeek(7);
/*     */     } else {
/* 223 */       voFecha.setFirstDayOfWeek(fnciFirstDayOfYear(voFecha.get(1)));
/*     */     }
/*     */     
/* 226 */     return voFecha.get(3);
/*     */   }
/*     */   
/*     */   public static int fnciSemana(Calendar poFecha) {
/* 230 */     return fnciSemana(poFecha, false);
/*     */   }
/*     */   
/*     */   public static int fnciSemana(boolean pbISO) {
/* 234 */     return fnciSemana(Calendar.getInstance(), pbISO);
/*     */   }
/*     */   
/*     */   public static int fnciSemana() {
/* 238 */     return fnciSemana(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsAnioSemana(Calendar poFecha, boolean pbISO)
/*     */   {
/* 252 */     int viSemana = fnciSemana(poFecha, pbISO);
/*     */     String vsRetorno;
/* 254 */     String vsRetorno; if ((viSemana == 52) && (poFecha.get(2) == 0) && (!pbISO)) {
/* 255 */       vsRetorno = poFecha.get(1) - 1 + "-" + viSemana;
/*     */     } else {
/* 257 */       vsRetorno = poFecha.get(1) + "-" + viSemana;
/*     */     }
/*     */     
/* 260 */     return vsRetorno;
/*     */   }
/*     */   
/*     */   public static String fncsAnioSemana(Calendar poFecha) {
/* 264 */     return fncsAnioSemana(poFecha, false);
/*     */   }
/*     */   
/*     */   public static String fncsAnioSemana(boolean pbISO) {
/* 268 */     return fncsAnioSemana(Calendar.getInstance(), pbISO);
/*     */   }
/*     */   
/*     */   public static String fncsAnioSemana() {
/* 272 */     return fncsAnioSemana(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoInicioSemana(String psSemana, boolean pbISO)
/*     */   {
/* 286 */     SimpleDateFormat voFormat = new SimpleDateFormat("yyyy-ww", REGIONAL_MEXICO);
/* 287 */     Calendar voFecha = Calendar.getInstance(REGIONAL_MEXICO);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 292 */       voFecha.setTime(voFormat.parse(psSemana));
/* 293 */       int viSemana = fnciSemana(voFecha, pbISO);
/* 294 */       if (viSemana != voFecha.get(3)) {
/* 295 */         if (pbISO) {
/* 296 */           voFecha.setFirstDayOfWeek(fnciFirstDayOfYear(Integer.parseInt(psSemana.substring(0, psSemana.indexOf("-")))));
/* 297 */           voFecha.add(6, 7 - fnciFirstDayOfYear(voFecha.getFirstDayOfWeek() - voFecha.get(7)));
/*     */         } else {
/* 299 */           voFecha.setFirstDayOfWeek(2);
/* 300 */           voFecha.setMinimalDaysInFirstWeek(7);
/* 301 */           voFecha.add(6, 7);
/*     */         }
/*     */       }
/*     */     } catch (ParseException poIgnorar) {
/* 305 */       log.error(poIgnorar);
/*     */     } catch (NumberFormatException poIgnorar) {
/* 307 */       log.error(poIgnorar);
/*     */     }
/*     */     
/* 310 */     return voFecha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsFormat(String psFmtOrigen, String psFmtDestino, String psFecha, Locale poLocal)
/*     */   {
/* 326 */     SimpleDateFormat voOrigen = new SimpleDateFormat(psFmtOrigen, poLocal);
/* 327 */     SimpleDateFormat voDestino = new SimpleDateFormat(psFmtDestino, poLocal);
/* 328 */     String vsRetorno = psFecha;
/*     */     try
/*     */     {
/* 331 */       vsRetorno = voDestino.format(voOrigen.parse(vsRetorno));
/*     */     }
/*     */     catch (Exception poIgnorar) {}
/*     */     
/* 335 */     return vsRetorno;
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFmtOrigen, String psFmtDestino, String psFecha) {
/* 339 */     return fncsFormat(psFmtOrigen, psFmtDestino, psFecha, REGIONAL_MEXICO);
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFmtDestino, String psFecha) {
/* 343 */     return fncsFormat(decodeDateFormat(psFecha), psFmtDestino, psFecha);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsFormat(String psFormato, Calendar poFecha, Locale poLocal, TimeZone poZona)
/*     */   {
/* 359 */     SimpleDateFormat voFormato = new SimpleDateFormat(psFormato, poLocal);
/* 360 */     String vsRetorno = "";
/*     */     try
/*     */     {
/* 363 */       voFormato.getCalendar().setTimeZone(poZona);
/* 364 */       vsRetorno = voFormato.format(poFecha.getTime());
/*     */     }
/*     */     catch (Exception poIgnorar) {}
/*     */     
/* 368 */     return vsRetorno;
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFormato, Calendar poFecha, Locale poLocal) {
/* 372 */     return fncsFormat(psFormato, poFecha, poLocal, TimeZone.getDefault());
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFormato, Calendar poFecha) {
/* 376 */     return fncsFormat(psFormato, poFecha, REGIONAL_MEXICO);
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFormato) {
/* 380 */     return fncsFormat(psFormato, Calendar.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoCalendar(String psFormato, String psFecha, Locale poLocal, boolean pbLenient)
/*     */   {
/* 396 */     Calendar voRetorno = Calendar.getInstance(poLocal);
/*     */     try
/*     */     {
/* 399 */       SimpleDateFormat voFormato = new SimpleDateFormat(psFormato, poLocal);
/* 400 */       voFormato.setLenient(pbLenient);
/* 401 */       voRetorno.setTime(voFormato.parse(psFecha));
/*     */     } catch (Exception poIgnorar) {
/* 403 */       voRetorno = null;
/*     */     }
/*     */     
/* 406 */     return voRetorno;
/*     */   }
/*     */   
/*     */   public static Calendar fncoCalendar(String psFormato, String psFecha, Locale poLocal) {
/* 410 */     return fncoCalendar(psFormato, psFecha, poLocal, true);
/*     */   }
/*     */   
/*     */   public static Calendar fncoCalendar(String psFormato, String psFecha, boolean pbLenient) {
/* 414 */     return fncoCalendar(psFormato, psFecha, REGIONAL_MEXICO, pbLenient);
/*     */   }
/*     */   
/*     */   public static Calendar fncoCalendar(String psFormato, String psFecha) {
/* 418 */     return fncoCalendar(psFormato, psFecha, REGIONAL_MEXICO);
/*     */   }
/*     */   
/*     */   public static Calendar fncoCalendar(String psFecha) {
/* 422 */     return fncoCalendar(decodeDateFormat(psFecha), psFecha);
/*     */   }
/*     */   
/*     */   public static Calendar fncoAdd(Calendar poBase, int piField, int piValue) {
/* 426 */     Calendar voResult = fncoCalendar(poBase);
/* 427 */     voResult.add(piField, piValue);
/* 428 */     return voResult;
/*     */   }
/*     */   
/*     */   public static Calendar fncoAdd(int piField, int piValue) {
/* 432 */     return fncoAdd(Calendar.getInstance(), piField, piValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoCalendar(long piTimeInMillis)
/*     */   {
/* 445 */     Calendar voRetorno = Calendar.getInstance();
/* 446 */     voRetorno.setTimeInMillis(piTimeInMillis);
/* 447 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoCalendar(Calendar poCalendar)
/*     */   {
/* 462 */     return fncoCalendar(poCalendar.getTimeInMillis());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String decodeDateFormat(String psDateValue)
/*     */   {
/* 477 */     String[] vsDateFormats = { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy HH:mm", "dd/MM/yyyy", "dd/MM/yy HH:mm:ss", "dd/MM/yy HH:mm", "dd/MM/yy", "MM/dd/yyyy HH:mm:ss", "MM/dd/yyyy HH:mm", "MM/dd/yyyy", "MM/dd/yy HH:mm:ss", "MM/dd/yy HH:mm", "MM/dd/yy" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 489 */     String vsDateFormat = "";
/*     */     
/* 491 */     for (String vsFormat : vsDateFormats) {
/* 492 */       if (matchesDateFormat(psDateValue, vsFormat)) {
/* 493 */         vsDateFormat = vsFormat;
/* 494 */         break;
/*     */       }
/*     */     }
/*     */     
/* 498 */     return vsDateFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoTrucado(Calendar poFecha, int viCampo)
/*     */   {
/* 512 */     Calendar voRetorno = fncoCalendar(poFecha);
/*     */     try {
/* 514 */       switch (viCampo) {
/*     */       case 1: 
/* 516 */         voRetorno.set(2, 0);
/*     */       case 2: 
/* 518 */         voRetorno.set(5, 1);
/*     */       case 5: 
/*     */       case 6: 
/* 521 */         voRetorno.set(11, 0);
/*     */       case 11: 
/* 523 */         voRetorno.set(12, 0);
/*     */       case 12: 
/* 525 */         voRetorno.set(13, 0);
/* 526 */         voRetorno.set(14, 0);
/*     */       }
/*     */     }
/*     */     catch (Exception poIgnorar) {}
/* 530 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbCompare(Calendar poFecha, Calendar poCompare, int piMask)
/*     */   {
/* 544 */     return (((piMask & 0x2) > 0) && (poFecha.getTimeInMillis() < poCompare.getTimeInMillis())) || (((piMask & 0x4) > 0) && (poFecha.getTimeInMillis() > poCompare.getTimeInMillis())) || (((piMask & 0x1) > 0) && (poFecha.getTimeInMillis() == poCompare.getTimeInMillis()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoDiferencia(Calendar poInicio, Calendar poFin)
/*     */   {
/* 560 */     return fncoCalendar(poFin.getTimeInMillis() - poInicio.getTimeInMillis());
/*     */   }
/*     */   
/*     */   public static Calendar fncoDiferencia(Calendar poInicio) {
/* 564 */     return fncoDiferencia(poInicio, Calendar.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar getZeroCalendar()
/*     */   {
/* 576 */     Calendar voRetorno = Calendar.getInstance(TIMEZONE_GREENWICH);
/* 577 */     voRetorno.setTimeInMillis(0L);
/* 578 */     voRetorno.set(1, 1);
/* 579 */     voRetorno.set(2, 0);
/* 580 */     voRetorno.set(6, 1);
/* 581 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matchesDateFormat(String psDate, String psFormato, Locale poLocal, boolean pbLenient)
/*     */   {
/* 599 */     return fncoCalendar(psFormato, psDate, REGIONAL_MEXICO, pbLenient) != null;
/*     */   }
/*     */   
/*     */   public static boolean matchesDateFormat(String psDate, String psFormato, Locale poLocal) {
/* 603 */     return matchesDateFormat(psDate, psFormato, poLocal, false);
/*     */   }
/*     */   
/*     */   public static boolean matchesDateFormat(String psDate, String psFormato) {
/* 607 */     return matchesDateFormat(psDate, psFormato, REGIONAL_MEXICO);
/*     */   }
/*     */   
/*     */   public static boolean isCalendar(String psDate) {
/* 611 */     return fncoCalendar(psDate) != null;
/*     */   }
/*     */   
/*     */   public static Calendar getWeekStart(int piWeek) {
/* 615 */     Calendar voDate = Calendar.getInstance();
/* 616 */     voDate.set(3, piWeek);
/* 617 */     voDate.set(7, voDate.get(7) - voDate.getFirstDayOfWeek());
/* 618 */     return voDate;
/*     */   }
/*     */   
/*     */   public static Calendar getWeekStart() {
/* 622 */     return getWeekStart(fnciSemana());
/*     */   }
/*     */   
/*     */   public static Calendar dateToCalendar(Date date) {
/* 626 */     Calendar calendar = Calendar.getInstance();
/* 627 */     calendar.setTime(date);
/* 628 */     return calendar;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\DateUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */