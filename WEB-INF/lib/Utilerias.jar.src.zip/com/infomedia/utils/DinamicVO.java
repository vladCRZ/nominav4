/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DinamicVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  23 */   protected String gsID = "";
/*  24 */   protected Map<String, String> goCampos = new HashMap();
/*  25 */   protected boolean gbIgnoreCase = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(String psID, Map<String, String> poCampos, boolean pbIgnoreCase)
/*     */   {
/*  37 */     this.gsID = psID;
/*  38 */     this.gbIgnoreCase = pbIgnoreCase;
/*  39 */     setCampos(poCampos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(String psID, Map<String, String> poCampos)
/*     */   {
/*  51 */     this(psID, poCampos, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(String psID)
/*     */   {
/*  63 */     this(psID, new HashMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(Map<String, String> poCampos, boolean pbIgnoreCase)
/*     */   {
/*  75 */     this("", poCampos, pbIgnoreCase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(Map<String, String> poCampos)
/*     */   {
/*  86 */     this(poCampos, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(DinamicVO poVO)
/*     */   {
/*  97 */     this(poVO.getID(), poVO.getCampos());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO(boolean pbIgnoreCase)
/*     */   {
/* 110 */     this("", new HashMap(), pbIgnoreCase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVO()
/*     */   {
/* 121 */     this(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setID(String psID)
/*     */   {
/* 132 */     this.gsID = psID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getID()
/*     */   {
/* 142 */     return this.gsID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getIgnoreCase()
/*     */   {
/* 152 */     return this.gbIgnoreCase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreCase(boolean pbIgnoreCase)
/*     */   {
/* 162 */     this.gbIgnoreCase = pbIgnoreCase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean fncbKeyEquals(String psKey, String psTestKey)
/*     */   {
/* 175 */     return this.gbIgnoreCase ? psKey.equalsIgnoreCase(psTestKey) : psKey.equals(psTestKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map.Entry<String, String> fncoGetEntry(String psCampo)
/*     */   {
/* 188 */     Iterator<Map.Entry<String, String>> voCampos = this.goCampos.entrySet().iterator();
/* 189 */     Map.Entry<String, String> voCampo = null;
/*     */     
/*     */ 
/* 192 */     while (voCampos.hasNext()) {
/* 193 */       voCampo = (Map.Entry)voCampos.next();
/* 194 */       if (fncbKeyEquals((String)voCampo.getKey(), psCampo)) return voCampo;
/*     */     }
/* 196 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbContiene(String psCampo)
/*     */   {
/* 209 */     return fncoGetEntry(psCampo) != null;
/*     */   }
/*     */   
/*     */   public boolean containsField(String psField) {
/* 213 */     return fncoGetEntry(psField) != null;
/*     */   }
/*     */   
/*     */   public boolean containsAllFields(Collection<String> poFields) {
/* 217 */     Iterator<String> voFields = poFields.iterator();
/* 218 */     while (voFields.hasNext()) if (!containsField((String)voFields.next())) return false;
/* 219 */     return true;
/*     */   }
/*     */   
/*     */   public boolean hasFieldValue(String psField) {
/* 223 */     return (containsField(psField)) && (!getCampo(psField).trim().equals(""));
/*     */   }
/*     */   
/*     */   public boolean hasAllFieldValues(Collection<String> poFields) {
/* 227 */     Iterator<String> voFields = poFields.iterator();
/* 228 */     while (voFields.hasNext()) if (!hasFieldValue((String)voFields.next())) return false;
/* 229 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNVL(String psFieldID)
/*     */   {
/* 243 */     return (!containsField(psFieldID)) || (StringUtils.isNVL(getCampo(psFieldID)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 256 */     boolean vbVoid = this.goCampos.size() == 0;
/* 257 */     for (String vsKey : this.goCampos.keySet()) {
/* 258 */       if (!isNVL(vsKey)) {
/* 259 */         vbVoid = false;
/* 260 */         break;
/*     */       }
/*     */     }
/* 263 */     return vbVoid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCampo(String psCampo, String psValor)
/*     */   {
/* 276 */     Map.Entry<String, String> voCampo = fncoGetEntry(psCampo);
/* 277 */     if (voCampo == null) this.goCampos.put(psCampo, psValor); else {
/* 278 */       voCampo.setValue(psValor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCampos(Map<String, String> poCampos)
/*     */   {
/* 290 */     Iterator<Map.Entry<String, String>> voEntradas = poCampos.entrySet().iterator();
/* 291 */     Map.Entry<String, String> voEntrada = null;
/*     */     
/*     */ 
/* 294 */     while (voEntradas.hasNext()) {
/* 295 */       voEntrada = (Map.Entry)voEntradas.next();
/* 296 */       setCampo((String)voEntrada.getKey(), (String)voEntrada.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCampos(DinamicVO poVO)
/*     */   {
/* 309 */     setCampos(poVO.getCampos());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> getCampos()
/*     */   {
/* 320 */     return this.goCampos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCampo(String psCampo)
/*     */   {
/* 332 */     Map.Entry<String, String> voCampo = fncoGetEntry(psCampo);
/* 333 */     return voCampo == null ? "" : (String)voCampo.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String NVL(String psFieldID, String psDefault)
/*     */   {
/* 348 */     return isNVL(psFieldID) ? psDefault : getCampo(psFieldID);
/*     */   }
/*     */   
/* 351 */   public String NVL(String psFieldID) { return NVL(psFieldID, ""); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dropCampo(String psCampo)
/*     */   {
/* 363 */     this.goCampos.entrySet().remove(fncoGetEntry(psCampo));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 374 */     this.goCampos.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCampoAsInt(String psCampo)
/*     */   {
/* 387 */     int viRetorno = 0;
/*     */     try {
/* 389 */       viRetorno = new Double(getCampo(psCampo)).intValue();
/*     */     } catch (Exception poIgnorar) {}
/* 391 */     return viRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getCampoAsDouble(String psCampo)
/*     */   {
/* 404 */     double vdRetorno = 0.0D;
/*     */     try {
/* 406 */       vdRetorno = Double.parseDouble(NVL(psCampo));
/*     */     } catch (Exception poIgnorar) {}
/* 408 */     return vdRetorno;
/*     */   }
/*     */   
/*     */   public BigDecimal getCampoAsDecimal(String psCampo) {
/* 412 */     BigDecimal voRetorno = new BigDecimal(getCampoAsDouble(psCampo));
/* 413 */     voRetorno.setScale(2);
/* 414 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar getCampoAsCalendar(String psFieldID)
/*     */   {
/* 427 */     return isNVL(psFieldID) ? null : DateUtils.fncoCalendar(getCampo(psFieldID));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCalendar(String psFieldID)
/*     */   {
/* 441 */     return getCampoAsCalendar(psFieldID) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInteger(String psFieldID)
/*     */   {
/*     */     try
/*     */     {
/* 456 */       Integer.parseInt(NVL(psFieldID));
/* 457 */       return true;
/*     */     } catch (NumberFormatException voNFE) {}
/* 459 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDouble(String psFieldID)
/*     */   {
/*     */     try
/*     */     {
/* 475 */       Double.parseDouble(NVL(psFieldID));
/* 476 */       return true;
/*     */     } catch (NumberFormatException voNFE) {}
/* 478 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean fncbContiene(DinamicVO poVO)
/*     */   {
/* 492 */     Iterator<Map.Entry<String, String>> voIterator = poVO.getCampos().entrySet().iterator();
/* 493 */     Map.Entry<String, String> voCampo = null;
/* 494 */     Map.Entry<String, String> voEntrada = null;
/* 496 */     for (; 
/* 496 */         voIterator.hasNext(); 
/*     */         
/*     */ 
/* 499 */         return false)
/*     */     {
/*     */       label20:
/* 497 */       voCampo = (Map.Entry)voIterator.next();
/* 498 */       voEntrada = fncoGetEntry((String)voCampo.getKey());
/* 499 */       if ((voEntrada != null) && (((String)voEntrada.getValue()).equals(voCampo.getValue()))) break label20;
/*     */     }
/* 501 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fncsEntryString(Map.Entry<String, String> poCampo)
/*     */   {
/* 514 */     return "\n" + (String)poCampo.getKey() + "=" + (String)poCampo.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fncsEntryXML(Map.Entry<String, String> poCampo)
/*     */   {
/* 527 */     return XMLUtils.fncsStartTag((String)poCampo.getKey()) + (String)poCampo.getValue() + XMLUtils.fncsEndTag((String)poCampo.getKey());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fncsEntryTD(Map.Entry<String, String> poCampo, Map<String, String> poAtributos)
/*     */   {
/* 541 */     return XMLUtils.fncsStartTag("td", poAtributos) + (String)poCampo.getValue() + XMLUtils.fncsEndTag("td");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 553 */     Iterator<Map.Entry<String, String>> voCampos = this.goCampos.entrySet().iterator();
/* 554 */     String vsReturn = getClass().getName();
/*     */     
/* 556 */     while (voCampos.hasNext()) {
/* 557 */       vsReturn = vsReturn + fncsEntryString((Map.Entry)voCampos.next());
/*     */     }
/* 559 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toXML()
/*     */   {
/* 571 */     Iterator<Map.Entry<String, String>> voCampos = this.goCampos.entrySet().iterator();
/* 572 */     String vsRetorno = "";
/*     */     
/* 574 */     vsRetorno = vsRetorno + (this.gsID.length() > 0 ? XMLUtils.fncsStartTag(this.gsID) : "");
/* 575 */     while (voCampos.hasNext()) vsRetorno = vsRetorno + fncsEntryXML((Map.Entry)voCampos.next());
/* 576 */     vsRetorno = vsRetorno + (this.gsID.length() > 0 ? XMLUtils.fncsEndTag(this.gsID) : "");
/*     */     
/* 578 */     return vsRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toXHTMLCells(Map<String, String> voAtributos)
/*     */   {
/* 591 */     Iterator<Map.Entry<String, String>> voCampos = this.goCampos.entrySet().iterator();
/* 592 */     String vsRetorno = "";
/*     */     
/* 594 */     while (voCampos.hasNext()) {
/* 595 */       vsRetorno = vsRetorno + fncsEntryTD((Map.Entry)voCampos.next(), voAtributos);
/*     */     }
/* 597 */     return vsRetorno;
/*     */   }
/*     */   
/* 600 */   public String toXHTMLCells() { return toXHTMLCells(null); }
/*     */   
/*     */   public String toXHTMLRow(Map<String, String> poAtributosRow, Map<String, String> poAtributosCell)
/*     */   {
/* 604 */     return XMLUtils.fncsStartTag("tr", poAtributosRow) + toXHTMLCells(poAtributosCell) + XMLUtils.fncsEndTag("tr");
/*     */   }
/*     */   
/* 607 */   public String toXHTMLRow() { return toXHTMLRow(null, null); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object fncoTOVO(Class<?> poClaseVO)
/*     */     throws Exception
/*     */   {
/* 621 */     Object voInstancia = null;
/* 622 */     Iterator<Method> voSetters = null;
/* 623 */     Method voSetter = null;
/* 624 */     String vsNombreCampo = "";
/*     */     
/* 626 */     voInstancia = poClaseVO.newInstance();
/* 627 */     voSetters = BeanUtils.listSetters(poClaseVO).iterator();
/*     */     
/* 629 */     while (voSetters.hasNext()) {
/* 630 */       voSetter = (Method)voSetters.next();
/* 631 */       vsNombreCampo = voSetter.getName().replaceFirst("set", "");
/* 632 */       voSetter.invoke(voInstancia, new Object[] { getCampo(vsNombreCampo) });
/*     */     }
/* 634 */     return voInstancia;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\DinamicVO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */