/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DinamicVector
/*     */   extends Vector<DinamicVO>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public DinamicVector fncoFiltro(DinamicVO poVO)
/*     */   {
/*  40 */     Iterator<DinamicVO> voValores = iterator();
/*  41 */     DinamicVector voRetorno = new DinamicVector();
/*  42 */     DinamicVO voVO = null;
/*  44 */     for (; 
/*  44 */         voValores.hasNext(); 
/*     */         
/*  46 */         voRetorno.add(voVO))
/*     */     {
/*     */       label16:
/*  45 */       voVO = (DinamicVO)voValores.next();
/*  46 */       if ((!voVO.fncbContiene(poVO)) && (poVO.getCampos().size() != 0)) break label16;
/*     */     }
/*  48 */     return voRetorno;
/*     */   }
/*     */   
/*     */   public DinamicVector filterByDate(String psField, String psFormat, String psDate) {
/*  52 */     DinamicVector voFiltered = new DinamicVector();
/*  53 */     for (DinamicVO voVO : this) {
/*  54 */       if ((voVO.isCalendar(psField)) && 
/*  55 */         (DateUtils.fncsFormat(psFormat, voVO.getCampoAsCalendar(psField)).equals(psDate))) { voFiltered.add(voVO);
/*     */       }
/*     */     }
/*  58 */     return voFiltered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVector fncoSubVector(int piSize)
/*     */   {
/*  71 */     DinamicVector voSubVector = new DinamicVector();
/*  72 */     int viCont = 0;
/*     */     
/*  74 */     for (viCont = 0; viCont < piSize; viCont++) {
/*  75 */       if (viCont < size()) voSubVector.add(get(viCont)); else {
/*  76 */         voSubVector.add(new DinamicVO());
/*     */       }
/*     */     }
/*  79 */     return voSubVector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DinamicVector fncoFiltro(String psCampo, String psLlave)
/*     */   {
/*  93 */     DinamicVO voAux = new DinamicVO();
/*  94 */     try { voAux = new DinamicVO(CollectionsUtils.fncoParseMap(psCampo + "=" + psLlave)); } catch (Exception voIgnorar) {}
/*  95 */     return fncoFiltro(voAux);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double fncdGetSuma(String psCampo, DinamicVO poVO)
/*     */   {
/* 109 */     Iterator<DinamicVO> voValores = fncoFiltro(poVO).iterator();
/* 110 */     DinamicVO voVO = null;
/* 111 */     double vdRetorno = 0.0D;
/* 112 */     while (voValores.hasNext()) {
/* 113 */       voVO = (DinamicVO)voValores.next();
/* 114 */       vdRetorno += voVO.getCampoAsDouble(psCampo);
/*     */     }
/* 116 */     return vdRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double fncdGetSuma(String psCampo, String psCampoFiltro, String psValorFiltro)
/*     */   {
/* 131 */     DinamicVO voAux = new DinamicVO();
/* 132 */     try { voAux = new DinamicVO(CollectionsUtils.fncoParseMap(psCampoFiltro + "=" + psValorFiltro)); } catch (Exception voIgnorar) {}
/* 133 */     return fncdGetSuma(psCampo, voAux);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double fncdGetSuma(String psCampo)
/*     */   {
/* 146 */     return fncdGetSuma(psCampo, new DinamicVO());
/*     */   }
/*     */   
/*     */   public Calendar maxDate(String psField) {
/* 150 */     Calendar voMaxDate = null;
/* 151 */     for (DinamicVO voVO : this) {
/* 152 */       if ((voVO.isCalendar(psField)) && (
/* 153 */         (voMaxDate == null) || (DateUtils.fncbCompare(voVO.getCampoAsCalendar(psField), voMaxDate, 4)))) {
/* 154 */         voMaxDate = DateUtils.fncoCalendar(voVO.getCampoAsCalendar(psField));
/*     */       }
/*     */     }
/*     */     
/* 158 */     return voMaxDate;
/*     */   }
/*     */   
/*     */   public Calendar minDate(String psField) {
/* 162 */     Calendar voMaxDate = null;
/* 163 */     for (DinamicVO voVO : this) {
/* 164 */       if ((voVO.isCalendar(psField)) && (
/* 165 */         (voMaxDate == null) || (DateUtils.fncbCompare(voVO.getCampoAsCalendar(psField), voMaxDate, 2)))) {
/* 166 */         voMaxDate = DateUtils.fncoCalendar(voVO.getCampoAsCalendar(psField));
/*     */       }
/*     */     }
/*     */     
/* 170 */     return voMaxDate;
/*     */   }
/*     */   
/*     */   public List<String> distinct(String psField) {
/* 174 */     List<String> voDistinct = new ArrayList();
/* 175 */     DinamicVO voVO; for (Iterator i$ = iterator(); i$.hasNext(); 
/* 176 */         voDistinct.add(voVO.NVL(psField)))
/*     */     {
/* 175 */       voVO = (DinamicVO)i$.next();
/* 176 */       if ((voVO.isNVL(psField)) || (voDistinct.contains(voVO.NVL(psField)))) {}
/*     */     }
/* 178 */     return voDistinct;
/*     */   }
/*     */   
/*     */   public double max(String psField) {
/* 182 */     double vdMax = 0.0D;
/* 183 */     for (DinamicVO voVO : this) {
/* 184 */       if (((voVO.isInteger(psField)) || (voVO.isDouble(psField))) && 
/* 185 */         (voVO.getCampoAsDouble(psField) > vdMax)) { vdMax = voVO.getCampoAsDouble(psField);
/*     */       }
/*     */     }
/* 188 */     return vdMax;
/*     */   }
/*     */   
/*     */   public double min(String psField) {
/* 192 */     double vdMax = 0.0D;
/* 193 */     for (DinamicVO voVO : this) {
/* 194 */       if (((voVO.isInteger(psField)) || (voVO.isDouble(psField))) && 
/* 195 */         (voVO.getCampoAsDouble(psField) < vdMax)) { vdMax = voVO.getCampoAsDouble(psField);
/*     */       }
/*     */     }
/* 198 */     return vdMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcAddToAll(String psCampo, String psValor)
/*     */   {
/* 211 */     Iterator<DinamicVO> voElementos = iterator();
/* 212 */     DinamicVO voVO = null;
/* 213 */     while (voElementos.hasNext()) {
/* 214 */       voVO = (DinamicVO)voElementos.next();
/* 215 */       voVO.setCampo(psCampo, psValor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prcAddToAll(DinamicVO poVO)
/*     */   {
/* 228 */     Iterator<String> voCampos = poVO.getCampos().keySet().iterator();
/* 229 */     String vsCampo = "";
/* 230 */     while (voCampos.hasNext()) {
/* 231 */       vsCampo = (String)voCampos.next();
/* 232 */       prcAddToAll(vsCampo, poVO.getCampo(vsCampo));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 245 */     Iterator<DinamicVO> voElementos = iterator();
/* 246 */     DinamicVO voVO = null;
/* 247 */     String vsReturn = "";
/*     */     try
/*     */     {
/* 250 */       vsReturn = vsReturn + getClass().getName();
/* 251 */       while (voElementos.hasNext()) {
/* 252 */         voVO = (DinamicVO)voElementos.next();
/* 253 */         vsReturn = vsReturn + voVO.toString();
/*     */       }
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/* 257 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toXML()
/*     */   {
/* 269 */     Iterator<DinamicVO> voElementos = iterator();
/* 270 */     DinamicVO voVO = null;
/* 271 */     String vsReturn = "";
/*     */     try
/*     */     {
/* 274 */       while (voElementos.hasNext()) {
/* 275 */         voVO = (DinamicVO)voElementos.next();
/* 276 */         vsReturn = vsReturn + voVO.toXML();
/*     */       }
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/* 280 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<List<String>> toListArray(List<String> poFields, boolean pbHeader)
/*     */   {
/* 295 */     List<List<String>> voListArray = new ArrayList();
/* 296 */     List<String> voRow = null;
/*     */     
/* 298 */     if (pbHeader) voListArray.add(poFields);
/* 299 */     for (DinamicVO voVO : this) {
/* 300 */       voRow = new ArrayList();
/* 301 */       String psField; for (Iterator i$ = poFields.iterator(); i$.hasNext(); voRow.add(voVO.NVL(psField))) psField = (String)i$.next();
/* 302 */       voListArray.add(voRow);
/*     */     }
/* 304 */     return voListArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<List<String>> toListArray(String[] poFields, boolean pbHeader)
/*     */   {
/* 319 */     return toListArray(Arrays.asList(poFields), pbHeader);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\DinamicVector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */