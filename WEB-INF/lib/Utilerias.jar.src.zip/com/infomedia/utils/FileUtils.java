/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileUtils
/*     */ {
/*     */   public static final String ALL_FILES = ".*";
/*     */   public static final String CURRENT = ".";
/*     */   public static final String PARENT = "..";
/*     */   public static final int FLAG_ALL = 0;
/*     */   public static final int FLAG_FIL = 1;
/*     */   public static final int FLAG_DIR = 2;
/*     */   
/*     */   public static String fncsUserHome()
/*     */   {
/*  53 */     return System.getProperty("user.home", ".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbVerificaDirectorio(String psDirectorio)
/*     */     throws Exception
/*     */   {
/*  67 */     File voDir = new File(psDirectorio);
/*  68 */     if (!voDir.exists()) {
/*  69 */       voDir.mkdirs();
/*     */     }
/*  71 */     if (!voDir.isDirectory()) {
/*  72 */       throw new Exception("No es un Directorio " + psDirectorio);
/*     */     }
/*  74 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbExiste(String psNombre)
/*     */     throws Exception
/*     */   {
/*  88 */     File voDir = new File(psNombre);
/*  89 */     return voDir.exists();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbExisteDirectorio(String psNombre)
/*     */     throws Exception
/*     */   {
/* 103 */     File voDir = new File(psNombre);
/* 104 */     return (voDir.exists()) && (voDir.isDirectory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar fncoFechaModificacion(File poArchivo)
/*     */   {
/* 117 */     return DateUtils.fncoCalendar(poArchivo.lastModified());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String saveFile(String psParent, String psFileName, byte[] poBuffer)
/*     */     throws Exception
/*     */   {
/* 135 */     FileOutputStream voFOS = null;
/* 136 */     File voFile = null;
/* 137 */     vsAbsolutePath = "";
/*     */     try {
/* 139 */       if (fncbVerificaDirectorio(psParent)) {
/* 140 */         voFile = new File(psParent, psFileName);
/* 141 */         voFOS = new FileOutputStream(voFile);
/* 142 */         voFOS.write(poBuffer);
/* 143 */         voFOS.flush(); }
/* 144 */       return voFile.getAbsolutePath();
/*     */     }
/*     */     catch (Exception voEXC) {
/* 147 */       throw voEXC;
/*     */     } finally {
/*     */       try {
/* 150 */         voFOS.close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcEliminaArchivo(File poFile)
/*     */   {
/* 166 */     if (poFile.exists()) {
/* 167 */       poFile.delete();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void prcEliminaArchivo(String psFileName) {
/* 172 */     prcEliminaArchivo(new File(psFileName));
/*     */   }
/*     */   
/*     */   public static void prcEliminaArchivo(String psParent, String psFileName) {
/* 176 */     prcEliminaArchivo(new File(psParent, psFileName));
/*     */   }
/*     */   
/*     */   public static void prcRenombraArchivo(File poOrigen, File poDestino) {
/* 180 */     if (poOrigen.exists()) {
/* 181 */       poOrigen.renameTo(poDestino);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void prcRenombraArchivo(String psPathOrigen, String psOrigen, String psPathDestino, String psDestino) throws Exception {
/* 186 */     if ((fncbVerificaDirectorio(psPathOrigen)) && (fncbVerificaDirectorio(psPathDestino))) {
/* 187 */       prcRenombraArchivo(new File(psPathOrigen, psOrigen), new File(psPathDestino, psDestino));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void prcRenombraArchivo(String psPath, String psOrigen, String psDestino) throws Exception {
/* 192 */     prcRenombraArchivo(psPath, psOrigen, psPath, psDestino);
/*     */   }
/*     */   
/*     */   public static void prcRenombraArchivo(String psOrigen, String psDestino) throws Exception {
/* 196 */     prcRenombraArchivo(".", psOrigen, psDestino);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcEliminaArchivos(List<File> poArchivos)
/*     */     throws Exception
/*     */   {
/* 209 */     Iterator<File> voArchivos = poArchivos.iterator();
/* 210 */     File voArchivo = null;
/* 211 */     while (voArchivos.hasNext()) {
/* 212 */       voArchivo = (File)voArchivos.next();
/* 213 */       if (voArchivo.isDirectory()) {
/* 214 */         prcEliminaArchivos(Arrays.asList(voArchivo.listFiles()));
/*     */       }
/* 216 */       prcEliminaArchivo(voArchivo);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<File> fncoFiltroFecha(List<File> poArchivos, Calendar poFiltro, int viFlag)
/*     */   {
/* 232 */     List<File> voRetorno = new ArrayList();
/* 233 */     Iterator<File> voArchivos = poArchivos.iterator();
/* 234 */     Calendar voFiltro = DateUtils.fncoTrucado(poFiltro, 5);
/* 235 */     Calendar voModificado = null;
/* 236 */     File voFile = null;
/*     */     
/* 238 */     while (voArchivos.hasNext()) {
/* 239 */       voFile = (File)voArchivos.next();
/* 240 */       voModificado = DateUtils.fncoTrucado(fncoFechaModificacion(voFile), 5);
/* 241 */       if ((voFile.exists()) && (voFile.isFile()) && (DateUtils.fncbCompare(voModificado, voFiltro, viFlag)))
/*     */       {
/*     */ 
/* 244 */         voRetorno.add(voFile);
/*     */       }
/*     */     }
/*     */     
/* 248 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<File> fncoFiltroPeriodo(List<File> poArchivos, Calendar poInicio, Calendar poFin)
/*     */   {
/* 263 */     List<File> voRetorno = new ArrayList();
/*     */     
/* 265 */     for (File voFile : poArchivos) {
/* 266 */       if ((voFile.exists()) && (voFile.isFile()) && (DateUtils.fncbCompare(fncoFechaModificacion(voFile), poInicio, 5)) && (DateUtils.fncbCompare(fncoFechaModificacion(voFile), poFin, 3)))
/*     */       {
/*     */ 
/*     */ 
/* 270 */         voRetorno.add(voFile);
/*     */       }
/*     */     }
/*     */     
/* 274 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<File> fncoFiltroNombre(List<File> poArchivos, String psFiltro)
/*     */   {
/* 288 */     List<File> voRetorno = new ArrayList();
/* 289 */     Iterator<File> voArchivos = poArchivos.iterator();
/* 290 */     File voFile = null;
/*     */     
/* 292 */     while (voArchivos.hasNext()) {
/* 293 */       voFile = (File)voArchivos.next();
/* 294 */       if ((voFile.exists()) && (voFile.isFile()) && (StringUtils.fncbFind(psFiltro, voFile.getName()))) {
/* 295 */         voRetorno.add(voFile);
/*     */       }
/*     */     }
/*     */     
/* 299 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<File> fncoFiltroTipo(List<File> poArchivos, int piTipo)
/*     */   {
/* 313 */     List<File> voRetorno = new ArrayList();
/* 314 */     Iterator<File> voArchivos = poArchivos.iterator();
/* 315 */     File voFile = null;
/*     */     
/* 317 */     while (voArchivos.hasNext()) {
/* 318 */       voFile = (File)voArchivos.next();
/* 319 */       if ((piTipo == 0) || ((piTipo == 1) && (voFile.isFile())) || ((piTipo == 2) && (voFile.isDirectory())))
/*     */       {
/*     */ 
/* 322 */         voRetorno.add(voFile);
/*     */       }
/*     */     }
/*     */     
/* 326 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<File> fncoListaArchivos(File poDirectorio)
/*     */     throws Exception
/*     */   {
/* 340 */     List<File> voRetorno = new ArrayList();
/* 341 */     if ((poDirectorio.exists()) && (poDirectorio.isDirectory())) {
/* 342 */       voRetorno.addAll(Arrays.asList(poDirectorio.listFiles()));
/*     */     }
/* 344 */     return voRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<File> fncoListaArchivos(String psDirectorio)
/*     */     throws Exception
/*     */   {
/* 358 */     return fncoListaArchivos(new File(psDirectorio));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> fncoListaNombres(String psDirectorio, int piTipo, boolean pbAbsolute)
/*     */     throws Exception
/*     */   {
/* 374 */     List<String> voRetorno = new ArrayList();
/* 375 */     Iterator<File> voFiles = null;
/* 376 */     File voFile = null;
/*     */     try
/*     */     {
/* 379 */       voFiles = fncoListaArchivos(psDirectorio).iterator();
/*     */       
/* 381 */       while (voFiles.hasNext()) {
/* 382 */         voFile = (File)voFiles.next();
/* 383 */         if ((piTipo == 0) || ((piTipo == 2) && (voFile.isDirectory())) || ((piTipo == 1) && (voFile.isFile())))
/*     */         {
/*     */ 
/* 386 */           voRetorno.add(pbAbsolute ? voFile.getAbsolutePath() : voFile.getName());
/*     */         }
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 390 */       throw voEXC;
/*     */     }
/* 392 */     return voRetorno;
/*     */   }
/*     */   
/*     */   public static List<String> fncoListaNombres(String psDirectorio, int piTipo) throws Exception {
/* 396 */     return fncoListaNombres(psDirectorio, piTipo, false);
/*     */   }
/*     */   
/*     */   public static List<String> fncoListaNombres() throws Exception {
/* 400 */     return fncoListaNombres(".", 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> fncoListaDirectorios(String psDirectorio, boolean pbAbsolute)
/*     */     throws Exception
/*     */   {
/* 415 */     return fncoListaNombres(psDirectorio, 2, pbAbsolute);
/*     */   }
/*     */   
/*     */   public static List<String> fncoListaDirectorios(boolean pbAbsolute) throws Exception {
/* 419 */     return fncoListaDirectorios(".", pbAbsolute);
/*     */   }
/*     */   
/*     */   public static List<String> fncoListaDirectorios(String psDirectorio) throws Exception {
/* 423 */     return fncoListaDirectorios(psDirectorio, false);
/*     */   }
/*     */   
/*     */   public static List<String> fncoListaDirectorios() throws Exception {
/* 427 */     return fncoListaDirectorios(".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int fnciNumeroArchivos(String psDirectorio, int poTipo)
/*     */     throws Exception
/*     */   {
/* 442 */     return fncoListaNombres(psDirectorio, poTipo).size();
/*     */   }
/*     */   
/*     */   public static int fnciNumeroArchivos(String psDirectorio) throws Exception {
/* 446 */     return fnciNumeroArchivos(psDirectorio, 0);
/*     */   }
/*     */   
/*     */   public static int fnciNumeroArchivos() throws Exception {
/* 450 */     return fnciNumeroArchivos(".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int fnciTamanioArchivo(File poArchivo)
/*     */   {
/* 463 */     InputStream voInput = null;
/* 464 */     viRetorno = 0;
/*     */     try
/*     */     {
/* 467 */       if ((poArchivo.exists()) && (poArchivo.isFile()))
/* 468 */         voInput = new FileInputStream(poArchivo);
/* 469 */       return voInput.available();
/*     */     }
/*     */     catch (Exception poEXC) {}finally
/*     */     {
/* 473 */       if (voInput != null) {
/*     */         try {
/* 475 */           voInput.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getFileName(String psAbsolutePath)
/*     */   {
/* 496 */     return StringUtils.isNVL(psAbsolutePath) ? psAbsolutePath : psAbsolutePath.substring(psAbsolutePath.replace('\\', '/').lastIndexOf("/") + 1).trim();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCurrentPath()
/*     */   {
/* 510 */     File voCurrent = new File("");
/* 511 */     return voCurrent.getAbsolutePath();
/*     */   }
/*     */   
/*     */   public static String loadFileAsResource(Object poCaller, String psResourceName) throws Exception {
/* 515 */     voSQL = new StringBuilder();
/* 516 */     BufferedReader voBR = null;
/* 517 */     String vsLine = "";
/*     */     try
/*     */     {
/* 520 */       poCaller.getClass().getClassLoader().clearAssertionStatus();
/* 521 */       voBR = new BufferedReader(new InputStreamReader(poCaller.getClass().getClassLoader().getResourceAsStream(psResourceName)));
/* 522 */       while (null != (vsLine = voBR.readLine())) {
/* 523 */         voSQL.append(vsLine);
/* 524 */         voSQL.append("\n");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 536 */       return voSQL.toString();
/*     */     }
/*     */     catch (IOException voEXC)
/*     */     {
/* 527 */       throw voEXC;
/*     */     } finally {
/*     */       try {
/* 530 */         if (null != voBR) {
/* 531 */           voBR.close();
/*     */         }
/*     */       }
/*     */       catch (IOException voIgnore) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public static String decodeFileSize(long size)
/*     */   {
/* 540 */     int unit = 1024;
/* 541 */     if (size < unit) {
/* 542 */       return size + " Bytes";
/*     */     }
/* 544 */     int exp = (int)(Math.log(size) / Math.log(unit));
/* 545 */     String pre = String.valueOf("kMGTPE".charAt(exp - 1));
/* 546 */     return String.format("%.1f %sB", new Object[] { Double.valueOf(size / Math.pow(unit, exp)), pre });
/*     */   }
/*     */   
/*     */   public static String getUnixStyleFilePath(String filePath) {
/* 550 */     String unixStyleFilePath = filePath.replaceAll("\\/", "/");
/* 551 */     return unixStyleFilePath + (unixStyleFilePath.endsWith("/") ? "" : "");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\FileUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */