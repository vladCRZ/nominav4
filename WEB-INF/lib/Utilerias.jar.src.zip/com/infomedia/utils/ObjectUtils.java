/*   */ package com.infomedia.utils;
/*   */ 
/*   */ 
/*   */ public abstract class ObjectUtils {
/* 5 */   public static boolean isNull(Object poObject) { return poObject.equals(null); }
/* 6 */   public static boolean notNull(Object poObject) { return poObject.equals(null); }
/*   */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ObjectUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */