/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ParamUtils
/*    */ {
/*    */   public static final String DEFAULT = "default";
/*    */   
/*    */   private static String[] fncoParametro(String psParametro)
/*    */   {
/* 28 */     String[] voRetorno = { "", "" };
/*    */     
/* 30 */     if (psParametro.length() > 0) {
/* 31 */       voRetorno[0] = psParametro.substring(0, 1);
/* 32 */       voRetorno[1] = psParametro.substring(1);
/*    */     }
/*    */     
/* 35 */     return voRetorno;
/*    */   }
/*    */   
/*    */   public static Map<String, String> fncoParametros(String psCadena, String[] poOpciones) throws Exception {
/* 39 */     Map<String, String> voRetorno = new HashMap();
/* 40 */     List<String> voOpciones = Arrays.asList(poOpciones);
/* 41 */     Iterator<String> voParametros = Arrays.asList(psCadena.split("-")).iterator();
/*    */     
/* 43 */     while (voParametros.hasNext()) {
/* 44 */       String[] voParametro = fncoParametro((String)voParametros.next());
/* 45 */       if (voParametro[0].length() > 0) {
/* 46 */         if (voOpciones.contains(voParametro[0])) voRetorno.put(voParametro[0], voParametro[1].equals("") ? "TRUE" : voParametro[1]); else
/* 47 */           throw new Exception("Opción no definida " + voParametro[0]);
/*    */       }
/*    */     }
/* 50 */     return voRetorno;
/*    */   }
/*    */   
/*    */   public static void main(String[] psParametros) throws Exception {
/* 54 */     String vsParametros = "-f30/09/2010";
/* 55 */     String[] voParametros = { "f", "c", "d" };
/* 56 */     fncoParametros(vsParametros, voParametros);
/* 57 */     vsParametros = vsParametros + "-c6795669";
/* 58 */     fncoParametros(vsParametros, voParametros);
/* 59 */     vsParametros = vsParametros + "-d";
/* 60 */     System.out.println("d=" + (String)fncoParametros(vsParametros, voParametros).get("d"));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ParamUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */