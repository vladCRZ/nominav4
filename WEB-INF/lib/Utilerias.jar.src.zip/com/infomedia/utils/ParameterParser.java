/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class ParameterParser
/*    */ {
/*    */   private static String[] parseParameter(String psParameter)
/*    */   {
/* 12 */     String[] voParameter = { "", "" };
/*    */     
/* 14 */     if (psParameter.length() > 0) {
/* 15 */       voParameter[0] = psParameter.substring(0, 1);
/* 16 */       voParameter[1] = psParameter.substring(1).trim();
/*    */     }
/*    */     
/* 19 */     return voParameter;
/*    */   }
/*    */   
/*    */   public static Parameters parse(String psCadena, String[] poValidOptions) throws Exception {
/* 23 */     Map<String, String> voRetorno = new java.util.HashMap();
/* 24 */     List<String> voOpciones = Arrays.asList(poValidOptions);
/* 25 */     Iterator<String> voParametros = Arrays.asList(psCadena.split("-")).iterator();
/*    */     
/* 27 */     while (voParametros.hasNext()) {
/* 28 */       String[] voParametro = parseParameter((String)voParametros.next());
/* 29 */       if (voParametro[0].length() > 0) {
/* 30 */         if (voOpciones.contains(voParametro[0])) voRetorno.put(voParametro[0], voParametro[1].equals("") ? "TRUE" : voParametro[1]); else
/* 31 */           throw new Exception("Illegal option " + voParametro[0]);
/*    */       }
/*    */     }
/* 34 */     return new Parameters(voRetorno);
/*    */   }
/*    */   
/*    */   public static Parameters parse(String[] psParameters, String[] poValidOptions) throws Exception {
/* 38 */     String vsParameterString = "";
/* 39 */     for (String vsParameter : psParameters) {
/* 40 */       vsParameterString = vsParameterString + (vsParameterString.equals("") ? "" : " ");
/* 41 */       vsParameterString = vsParameterString + vsParameter.trim();
/*    */     }
/* 43 */     return parse(vsParameterString, poValidOptions);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ParameterParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */