/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Parameters
/*    */   extends DinamicVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*  9 */   public static String PRMTR_DEBUG = "d";
/* 10 */   public static String PRMTR_HELP = "h";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Parameters() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Parameters(Map<String, String> poParameters)
/*    */   {
/* 35 */     super(poParameters);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean is(String psParameter)
/*    */   {
/* 48 */     return NVL(psParameter).toUpperCase().equals("TRUE");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isHelp()
/*    */   {
/* 59 */     return is(PRMTR_HELP);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isDebug()
/*    */   {
/* 70 */     return is(PRMTR_DEBUG);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\Parameters.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */