/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Locale;
/*    */ import java.util.Properties;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ public abstract class PropertyLoader
/*    */ {
/* 15 */   public static boolean THROW_ON_LOAD_FAILURE = true;
/* 16 */   public static boolean LOAD_AS_RESOURCE_BUNDLE = false;
/* 17 */   public static boolean LOAD_AS_RESOURCE = true;
/*    */   private static final String SUFFIX = ".properties";
/*    */   
/*    */   public static Properties load(String psPropertiesFileName, ClassLoader poLoader)
/*    */   {
/* 22 */     Properties voLoadedProperties = null;
/* 23 */     InputStream voInputStream = null;
/*    */     
/* 25 */     if (StringUtils.isNVL(psPropertiesFileName)) {
/* 26 */       throw new IllegalArgumentException("null input: name");
/*    */     }
/* 28 */     if (psPropertiesFileName.startsWith("/")) {
/* 29 */       psPropertiesFileName = psPropertiesFileName.substring(1);
/*    */     }
/* 31 */     if (psPropertiesFileName.endsWith(".properties")) {
/* 32 */       psPropertiesFileName = psPropertiesFileName.substring(0, psPropertiesFileName.length() - ".properties".length());
/*    */     }
/*    */     try
/*    */     {
/* 36 */       if (poLoader == null)
/* 37 */         poLoader = ClassLoader.getSystemClassLoader();
/*    */       ResourceBundle rb;
/*    */       Enumeration<String> keys;
/* 40 */       if (LOAD_AS_RESOURCE_BUNDLE) {
/* 41 */         psPropertiesFileName = psPropertiesFileName.replace('/', '.');
/* 42 */         rb = ResourceBundle.getBundle(psPropertiesFileName, Locale.getDefault(), poLoader);
/* 43 */         voLoadedProperties = new Properties();
/* 44 */         for (keys = rb.getKeys(); keys.hasMoreElements();) {
/* 45 */           String key = (String)keys.nextElement();
/* 46 */           String value = rb.getString(key);
/* 47 */           voLoadedProperties.put(key, value);
/*    */         }
/* 49 */       } else if (LOAD_AS_RESOURCE) {
/* 50 */         psPropertiesFileName = psPropertiesFileName.replace('.', '/');
/* 51 */         if (!psPropertiesFileName.endsWith(".properties")) {
/* 52 */           psPropertiesFileName = psPropertiesFileName + ".properties";
/*    */         }
/* 54 */         voInputStream = poLoader.getResourceAsStream(psPropertiesFileName);
/* 55 */         if (voInputStream != null) {
/* 56 */           voLoadedProperties = new Properties();
/* 57 */           voLoadedProperties.load(voInputStream);
/*    */         }
/*    */       } else {
/* 60 */         URL[] urls = ((URLClassLoader)poLoader).getURLs();
/*    */         
/* 62 */         psPropertiesFileName = psPropertiesFileName.replace('.', '/');
/* 63 */         if (!psPropertiesFileName.endsWith(".properties")) {
/* 64 */           psPropertiesFileName = psPropertiesFileName + ".properties";
/*    */         }
/* 66 */         for (URL url : urls) {
/* 67 */           File propertyFile = new File(url.getFile() + psPropertiesFileName);
/* 68 */           if (propertyFile.exists()) {
/* 69 */             voInputStream = new FileInputStream(propertyFile);
/* 70 */             voLoadedProperties = new Properties();
/* 71 */             voLoadedProperties.load(voInputStream);
/* 72 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 79 */       if (voInputStream != null) {
/*    */         try {
/* 81 */           voInputStream.close();
/*    */         }
/*    */         catch (Throwable ignore) {}
/*    */       }
/*    */       
/*    */ 
/* 87 */       if (!THROW_ON_LOAD_FAILURE) {
/*    */         return voLoadedProperties;
/*    */       }
/*    */     }
/*    */     catch (Exception voEXC)
/*    */     {
/* 77 */       voLoadedProperties = null;
/*    */     } finally {
/* 79 */       if (voInputStream != null) {
/*    */         try {
/* 81 */           voInputStream.close();
/*    */         }
/*    */         catch (Throwable ignore) {}
/*    */       }
/*    */     }
/*    */     
/* 87 */     if (voLoadedProperties == null) {
/* 88 */       throw new IllegalArgumentException("could not load [" + psPropertiesFileName + "] as " + (LOAD_AS_RESOURCE_BUNDLE ? "a resource bundle" : "a classloader resource"));
/*    */     }
/*    */     
/* 91 */     return voLoadedProperties;
/*    */   }
/*    */   
/*    */   public static Properties load(String name) {
/* 95 */     return load(name, Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\PropertyLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */