/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ReflectUtils
/*    */ {
/*    */   public static Class<?>[] fncoGetClassArray(Object[] poArgumentos)
/*    */   {
/* 37 */     Iterator<Object> voArgumentos = Arrays.asList(poArgumentos).iterator();
/* 38 */     List<Class<?>> voRetorno = new ArrayList();
/*    */     try
/*    */     {
/* 41 */       while (voArgumentos.hasNext()) {
/* 42 */         voRetorno.add(voArgumentos.next().getClass());
/*    */       }
/*    */     } catch (Exception poIgnorar) {
/* 45 */       voRetorno.clear();
/*    */     }
/*    */     
/* 48 */     return (Class[])voRetorno.toArray(new Class[0]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Object fncoEjecuta(String psMetodo, Object[] poParametros, Object poInstancia)
/*    */   {
/* 63 */     Method voAccion = null;
/* 64 */     Object voRetorno = null;
/*    */     try
/*    */     {
/* 67 */       voAccion = poInstancia.getClass().getDeclaredMethod(psMetodo, fncoGetClassArray(poParametros));
/* 68 */       voRetorno = voAccion.invoke(poInstancia, poParametros);
/*    */     }
/*    */     catch (Exception poEXC) {}
/*    */     
/* 72 */     return voRetorno;
/*    */   }
/*    */   
/*    */   public static boolean isA(Object poObject, Class<?> poTestClass) {
/* 76 */     return poTestClass.isAssignableFrom(poObject.getClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ReflectUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */