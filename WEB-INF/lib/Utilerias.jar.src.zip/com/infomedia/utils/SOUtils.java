/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ public abstract class SOUtils
/*    */ {
/*    */   public static String getHost() {
/*    */     try {
/*  9 */       return java.net.InetAddress.getLocalHost().getHostName();
/*    */     } catch (UnknownHostException voEXC) {
/* 11 */       voEXC.printStackTrace();
/*    */     }
/* 13 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\SOUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */