/*    */ package com.infomedia.utils;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpanishGrammarUtils
/*    */ {
/* 26 */   public static final List<String> PREPOSICIONES = Arrays.asList(new String[] { "a", "ante", "bajo", "con", "contra", "de", "desde", "durante", "en", "entre", "hacia", "hasta", "mediante", "para", "por", "pro", "segun", "sin", "sobre", "tras", "via" });
/* 27 */   public static final List<String> ARTICULOS = Arrays.asList(new String[] { "el", "la", "los", "las", "un", "una", "unos", "unas" });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String cleanStressMarks(String psString)
/*    */   {
/* 40 */     return psString.replaceAll("á", "a").replaceAll("é", "e").replaceAll("í", "i").replaceAll("ó", "o").replaceAll("ú", "u").replaceAll("Á", "A").replaceAll("É", "E").replaceAll("Í", "I").replaceAll("Ó", "O").replaceAll("Ú", "U").replaceAll("ä", "a").replaceAll("ë", "e").replaceAll("ï", "i").replaceAll("ö", "o").replaceAll("ü", "u").replaceAll("Ä", "A").replaceAll("Ë", "E").replaceAll("Ï", "I").replaceAll("Ö", "O").replaceAll("Ü", "U").trim();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String cleanArticulos(String psDirty, String psSeparator)
/*    */   {
/* 64 */     Iterator<String> voTokens = Arrays.asList(psDirty.split(psSeparator)).iterator();
/* 65 */     String vsClean = "";
/* 66 */     String vsToken = "";
/*    */     
/* 68 */     while (voTokens.hasNext()) {
/* 69 */       vsToken = (String)voTokens.next();
/* 70 */       if (!ARTICULOS.contains(cleanStressMarks(vsToken.trim()).toLowerCase())) {
/* 71 */         vsClean = vsClean + (vsClean.trim().equals("") ? "" : " ");
/* 72 */         vsClean = vsClean + vsToken;
/*    */       }
/*    */     }
/*    */     
/* 76 */     return vsClean;
/*    */   }
/*    */   
/*    */   public static String cleanPreposisiones(String psDirty, String psSeparator) {
/* 80 */     Iterator<String> voTokens = Arrays.asList(psDirty.split(psSeparator)).iterator();
/* 81 */     String vsClean = "";
/* 82 */     String vsToken = "";
/*    */     
/* 84 */     while (voTokens.hasNext()) {
/* 85 */       vsToken = (String)voTokens.next();
/* 86 */       if (!PREPOSICIONES.contains(cleanStressMarks(vsToken.trim()).toLowerCase())) {
/* 87 */         vsClean = vsClean + (vsClean.trim().equals("") ? "" : " ");
/* 88 */         vsClean = vsClean + vsToken;
/*    */       }
/*    */     }
/*    */     
/* 92 */     return vsClean;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\SpanishGrammarUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */