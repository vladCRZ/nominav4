/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StringUtils
/*     */ {
/*     */   public static final String NULL_VALUE = "null";
/*     */   
/*     */   public static String fncsExponentialParse(String psNumero)
/*     */   {
/*  41 */     NumberFormat voFormat = new DecimalFormat("#.0000000000");
/*  42 */     String vsReturn = "0";
/*     */     try
/*     */     {
/*  45 */       vsReturn = voFormat.format(Double.parseDouble(psNumero));
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/*     */     
/*  49 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsFormat(String psFormato, double pdValor)
/*     */   {
/*  63 */     DecimalFormatSymbols voDFS = new DecimalFormatSymbols();
/*     */     
/*     */ 
/*  66 */     voDFS.setDecimalSeparator('.');
/*  67 */     NumberFormat voFormat = new DecimalFormat(psFormato, voDFS);
/*     */     
/*  69 */     String vsReturn = "0";
/*     */     try
/*     */     {
/*  72 */       vsReturn = voFormat.format(pdValor);
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/*     */     
/*  76 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsDecimalFormat(double vdValor, int viPrecision)
/*     */   {
/*  89 */     String vsRetorno = "";
/*     */     try {
/*  91 */       vsRetorno = String.valueOf(new BigDecimal(vdValor).setScale(viPrecision, 4).doubleValue());
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/*  94 */     return vsRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsGetPercentage(double pdDouble)
/*     */   {
/* 106 */     NumberFormat voFormat = new DecimalFormat("00.00 %");
/* 107 */     String vsReturn = "0";
/*     */     try
/*     */     {
/* 110 */       vsReturn = voFormat.format(new BigDecimal(pdDouble).setScale(4, 2).doubleValue());
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/*     */     
/* 114 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsGetPercentage(String psDouble)
/*     */   {
/* 125 */     NumberFormat voFormat = new DecimalFormat("00.00 %");
/* 126 */     String vsReturn = "0";
/*     */     try
/*     */     {
/* 129 */       vsReturn = voFormat.format(new BigDecimal(psDouble).setScale(4, 2).doubleValue());
/*     */     }
/*     */     catch (Exception voIgnorar) {}
/*     */     
/* 133 */     return vsReturn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsCleanUnprintable(String psCadena)
/*     */   {
/* 146 */     byte[] voBytes = psCadena.getBytes();
/*     */     
/*     */ 
/* 149 */     for (int i = 0; i < voBytes.length; i++) {
/* 150 */       if (voBytes[i] < 32) voBytes[i] = 32;
/*     */     }
/* 152 */     return new String(voBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsToHexString(int piValor, int piTamanio)
/*     */   {
/* 166 */     String vsRetorno = "";
/*     */     try
/*     */     {
/* 169 */       vsRetorno = Integer.toHexString(piValor).toUpperCase();
/* 170 */       while (vsRetorno.length() < piTamanio)
/* 171 */         vsRetorno = "0" + vsRetorno;
/* 172 */       vsRetorno = "0x" + vsRetorno;
/*     */     }
/*     */     catch (Exception poIgnorar) {}
/* 175 */     return vsRetorno;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsGetString(byte[] poBuffer, int piSize)
/*     */   {
/* 189 */     for (int i = 0; i < piSize; i++) {
/* 190 */       if (Integer.toHexString(poBuffer[i]).toUpperCase().equals("0")) {
/* 191 */         poBuffer[i] = 32;
/*     */       }
/*     */     }
/* 194 */     return new String(poBuffer).substring(0, piSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbMatches(List<String> poPatterns, String psTest, boolean pbIgnoreCase)
/*     */   {
/* 211 */     Iterator<String> voPatterns = poPatterns.iterator();
/* 212 */     String vsPattern = "";
/*     */     
/* 214 */     while (voPatterns.hasNext()) {
/* 215 */       vsPattern = vsPattern + (vsPattern.length() > 0 ? "|" : "");
/* 216 */       vsPattern = vsPattern + (String)voPatterns.next(); }
/*     */     Pattern voPattern;
/*     */     Pattern voPattern;
/* 219 */     if (pbIgnoreCase) voPattern = Pattern.compile(vsPattern, 2); else {
/* 220 */       voPattern = Pattern.compile(vsPattern);
/*     */     }
/* 222 */     Matcher voMatch = voPattern.matcher(psTest);
/*     */     
/* 224 */     return voMatch.matches();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbMatches(String psPattern, String psTest, boolean pbIgnoreCase)
/*     */   {
/* 239 */     return fncbMatches(Arrays.asList(new String[] { psPattern }), psTest, pbIgnoreCase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbMatches(String psPattern, String psTest)
/*     */   {
/* 253 */     return fncbMatches(psPattern, psTest, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNumber(String psTest)
/*     */   {
/* 267 */     return fncbMatches("[0-9]+", psTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNAN(String psTest)
/*     */   {
/* 281 */     return !fncbMatches("[0-9]+", psTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbFind(List<String> poPatterns, String psTest, boolean pbIgnoreCase)
/*     */   {
/* 298 */     Iterator<String> voPatterns = poPatterns.iterator();
/* 299 */     String vsPattern = "";
/*     */     
/* 301 */     while (voPatterns.hasNext()) {
/* 302 */       vsPattern = vsPattern + (vsPattern.length() > 0 ? "|" : "");
/* 303 */       vsPattern = vsPattern + (String)voPatterns.next(); }
/*     */     Pattern voPattern;
/*     */     Pattern voPattern;
/* 306 */     if (pbIgnoreCase) voPattern = Pattern.compile(vsPattern, 2); else {
/* 307 */       voPattern = Pattern.compile(vsPattern);
/*     */     }
/* 309 */     Matcher voMatch = voPattern.matcher(psTest);
/*     */     
/* 311 */     return voMatch.find();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbFind(String psPattern, String psTest, boolean pbIgnoreCase)
/*     */   {
/* 326 */     return fncbFind(Arrays.asList(new String[] { psPattern }), psTest, pbIgnoreCase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean fncbFind(String psPattern, String psTest)
/*     */   {
/* 340 */     return fncbFind(psPattern, psTest, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsRepeat(String psCadena, int piRepeticiones)
/*     */   {
/* 355 */     String repeat = "";
/* 356 */     for (int i = 0; i < piRepeticiones; i++) {
/* 357 */       repeat = repeat + psCadena;
/*     */     }
/*     */     
/* 360 */     return repeat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsLeftPadding(String psString, char piPadding, int piMinSize)
/*     */   {
/* 376 */     return String.format("%" + String.valueOf(piMinSize) + "s", new Object[] { psString }).replace(' ', piPadding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsCapitalize(String psCadena)
/*     */   {
/* 390 */     String vsCadena = psCadena.toLowerCase();
/* 391 */     return vsCadena.substring(0, 1).toUpperCase() + vsCadena.substring(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNVL(String psString)
/*     */   {
/* 405 */     return (psString == null) || (psString.toLowerCase().trim().equals("null")) || (psString.trim().equals(""));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NVL(String psValue, String psDefault)
/*     */   {
/* 420 */     return isNVL(psValue) ? psDefault : psValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String NVL(String psValue)
/*     */   {
/* 434 */     return NVL(psValue, "");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 438 */     System.out.println(fncsRepeat(",?", 10));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\StringUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */