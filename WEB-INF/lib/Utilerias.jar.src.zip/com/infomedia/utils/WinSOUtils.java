/*    */ package com.infomedia.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WinSOUtils
/*    */ {
/*    */   public static final String WIN_OS_NAME = "WINDOWS";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String fncsWinFileName(String psFileName)
/*    */   {
/* 33 */     String vsValidFileName = "";
/*    */     try {
/* 35 */       vsValidFileName = psFileName.replaceAll(":", "").replaceAll("[*]", "").replaceAll("[?]", "").replaceAll("\"", "").replaceAll("<", "").replaceAll(">", "").replaceAll("[|]", "");
/*    */     }
/*    */     catch (Exception poEXC) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */     return vsValidFileName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String fncsValidFileName(String psFileName)
/*    */   {
/* 57 */     return isWindows() ? fncsWinFileName(psFileName) : psFileName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isWindows()
/*    */   {
/* 69 */     return System.getProperty("os.name").toUpperCase().indexOf("WINDOWS") >= 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\WinSOUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */