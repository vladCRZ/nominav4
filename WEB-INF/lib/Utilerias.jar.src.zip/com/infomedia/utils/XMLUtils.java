/*     */ package com.infomedia.utils;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XMLUtils
/*     */ {
/*     */   public static final String OPEN_TAG = "<";
/*     */   public static final String OPEN_FINAL_TAG = "</";
/*     */   public static final String CLOSE_TAG = ">";
/*     */   public static final String CLOSE_VOID_TAG = "/>";
/*     */   
/*     */   public static String fncsGetHeader(String psVersion, String psEncoding)
/*     */   {
/*  34 */     String vsRetorno = "";
/*     */     
/*  36 */     vsRetorno = vsRetorno + "<?xml version=\"" + psVersion + "\"";
/*  37 */     vsRetorno = vsRetorno + (psEncoding.trim().length() > 0 ? " encoding=\"" + psEncoding + "\"" : "");
/*  38 */     vsRetorno = vsRetorno + "?>";
/*     */     
/*  40 */     return vsRetorno;
/*     */   }
/*     */   
/*  43 */   public static String fncsGetHeader(String psVersion) { return fncsGetHeader(psVersion, ""); }
/*     */   
/*     */   public static String fncsGetHeader() {
/*  46 */     return fncsGetHeader("1.0");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsAttribute(String psName, String psValue)
/*     */   {
/*  60 */     return " " + psName + "=\"" + psValue + "\"";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsStartTag(String psTagName, Map<String, String> poTagAttributes, boolean pbVoidTag)
/*     */   {
/*  75 */     Iterator<Map.Entry<String, String>> voAtributos = null;
/*  76 */     Map.Entry<String, String> voAtributo = null;
/*  77 */     String vsTag = "";
/*     */     try
/*     */     {
/*  80 */       vsTag = vsTag + "<" + psTagName;
/*  81 */       if (poTagAttributes != null) {
/*  82 */         voAtributos = poTagAttributes.entrySet().iterator();
/*  83 */         while (voAtributos.hasNext()) {
/*  84 */           voAtributo = (Map.Entry)voAtributos.next();
/*  85 */           vsTag = vsTag + fncsAttribute((String)voAtributo.getKey(), (String)voAtributo.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception voIgnorar) {}finally {
/*  90 */       vsTag = vsTag + (pbVoidTag ? "/>" : ">");
/*     */     }
/*     */     
/*  93 */     return vsTag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsStartTag(String psTagName, Map<String, String> poTagAttributes)
/*     */   {
/* 107 */     return fncsStartTag(psTagName, poTagAttributes, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsStartTag(String psTagName)
/*     */   {
/* 120 */     return fncsStartTag(psTagName, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String fncsEndTag(String psTagName)
/*     */   {
/* 133 */     return "</" + psTagName + ">";
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\XMLUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */