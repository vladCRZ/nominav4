/*    */ package com.infomedia.utils.files;
/*    */ 
/*    */ import com.infomedia.utils.DateUtils;
/*    */ import java.io.File;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateFileFilter
/*    */ {
/*    */   public static enum PRECISION
/*    */   {
/* 26 */     YEAR, 
/* 27 */     MONTH, 
/* 28 */     DAY, 
/* 29 */     HOUR, 
/* 30 */     MINUTE, 
/* 31 */     SECOND;
/*    */     private PRECISION() {} }
/* 33 */   private PRECISION goPrecision = PRECISION.DAY;
/* 34 */   private Calendar goFrom = null;
/* 35 */   private Calendar goTo = null;
/*    */   
/*    */   public void setPrecision(PRECISION precision) {
/* 38 */     this.goPrecision = precision;
/*    */   }
/*    */   
/*    */   private boolean compare(Calendar value, int field) {
/* 42 */     if (null == this.goFrom) {
/* 43 */       return false;
/*    */     }
/* 45 */     if (null == this.goTo) {
/* 46 */       return (this.goFrom.get(field) <= value.get(field)) && (this.goTo.get(field) >= value.get(field));
/*    */     }
/*    */     
/* 49 */     return this.goFrom.get(field) == value.get(field);
/*    */   }
/*    */   
/*    */   public boolean accept(File poFile)
/*    */   {
/* 54 */     Calendar voLastModified = DateUtils.fncoCalendar(poFile.lastModified());
/* 55 */     boolean accepted = false;
/* 56 */     switch (this.goPrecision) {
/*    */     case SECOND: 
/* 58 */       accepted = compare(voLastModified, 13);
/*    */     case MINUTE: 
/* 60 */       accepted = compare(voLastModified, 12);
/*    */     case HOUR: 
/* 62 */       accepted = compare(voLastModified, 11);
/*    */     case DAY: 
/* 64 */       accepted = compare(voLastModified, 6);
/*    */     case MONTH: 
/* 66 */       accepted = compare(voLastModified, 2);
/* 67 */     case YEAR:  accepted = accepted = compare(voLastModified, 1);
/*    */     }
/*    */     
/* 70 */     return accepted;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\files\DateFileFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */