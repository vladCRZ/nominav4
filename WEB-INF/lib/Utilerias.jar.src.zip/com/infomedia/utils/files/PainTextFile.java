package com.infomedia.utils.files;

public class PainTextFile {}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\files\PainTextFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */