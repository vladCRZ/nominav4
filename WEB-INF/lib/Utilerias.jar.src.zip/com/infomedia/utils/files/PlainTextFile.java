/*    */ package com.infomedia.utils.files;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlainTextFile
/*    */ {
/*    */   public static StringBuffer read(String psParent, String psFileName)
/*    */   {
/* 17 */     voContent = new StringBuffer();
/* 18 */     FileInputStream voFIS = null;
/* 19 */     byte[] voBuffer = null;
/*    */     try
/*    */     {
/* 22 */       voFIS = new FileInputStream(new File(psParent, psFileName));
/* 23 */       voBuffer = new byte[voFIS.available()];
/* 24 */       voFIS.read(voBuffer);
/* 25 */       voContent.append(new String(voBuffer));
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 31 */       return voContent;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 27 */       e.printStackTrace();
/*    */     } finally {
/* 29 */       try { voFIS.close();
/*    */       }
/*    */       catch (Exception voIgnore) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\files\PlainTextFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */