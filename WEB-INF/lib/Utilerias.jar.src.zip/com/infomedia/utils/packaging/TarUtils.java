/*     */ package com.infomedia.utils.packaging;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.tools.tar.TarEntry;
/*     */ import org.apache.tools.tar.TarInputStream;
/*     */ import org.apache.tools.tar.TarOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TarUtils
/*     */ {
/*     */   public static final String EXTENSION = ".tar";
/*     */   
/*     */   private static void prcTarArchivo(File poArchivo, File poRaiz, TarOutputStream poTarOutput, boolean pbRelativo)
/*     */   {
/*  48 */     String vsRutaArchivo = poArchivo.getAbsolutePath();
/*  49 */     String vsRutaRaiz = poRaiz.getAbsolutePath();
/*  50 */     BufferedInputStream voInput = null;
/*  51 */     TarEntry voTarEntry = null;
/*  52 */     byte[] voBuffer = new byte['Ѐ'];
/*  53 */     int viLeidos = 0;
/*     */     try
/*     */     {
/*  56 */       if (pbRelativo) vsRutaArchivo = vsRutaArchivo.substring(vsRutaRaiz.length() + 1);
/*  57 */       voInput = new BufferedInputStream(new FileInputStream(poArchivo));
/*  58 */       voTarEntry = new TarEntry(vsRutaArchivo);
/*  59 */       voTarEntry.setSize(voInput.available());
/*  60 */       poTarOutput.putNextEntry(voTarEntry);
/*     */       
/*  62 */       while ((viLeidos = voInput.read(voBuffer)) != -1) {
/*  63 */         poTarOutput.write(voBuffer, 0, viLeidos);
/*     */       }
/*  65 */       voInput.close();
/*     */       
/*  67 */       poTarOutput.closeEntry();
/*     */     } catch (Exception poEXC) {
/*  69 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int fnciTarDirectorio(File poDirectorio, File poRaiz, String psFiltro, TarOutputStream poTarOutput, boolean pbRelativo)
/*     */   {
/*  87 */     Iterator<String> voArchivos = null;
/*  88 */     File voFile = null;
/*  89 */     int viContador = 0;
/*     */     
/*     */     try
/*     */     {
/*  93 */       if (poDirectorio.isDirectory()) {
/*  94 */         voArchivos = Arrays.asList(poDirectorio.list()).iterator();
/*     */         
/*  96 */         while (voArchivos.hasNext()) {
/*  97 */           voFile = new File(poDirectorio.getAbsolutePath() + File.separator + (String)voArchivos.next());
/*  98 */           if (voFile.isDirectory()) {
/*  99 */             viContador += fnciTarDirectorio(voFile, poRaiz, psFiltro, poTarOutput, pbRelativo);
/* 100 */           } else if (StringUtils.fncbFind(psFiltro, voFile.getName())) {
/* 101 */             prcTarArchivo(voFile, poRaiz, poTarOutput, pbRelativo);
/* 102 */             viContador++;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 107 */       poEXC.printStackTrace();
/*     */     }
/*     */     
/* 110 */     return viContador;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void prcVacio(TarOutputStream poTarOutput)
/*     */   {
/* 122 */     byte[] voSinInformacion = "No se encontraron archivos que coincidan con la búsqueda.".getBytes();
/*     */     try
/*     */     {
/* 125 */       poTarOutput.putNextEntry(new TarEntry("ERROR.txt"));
/* 126 */       poTarOutput.write(voSinInformacion, 0, voSinInformacion.length);
/* 127 */       poTarOutput.closeEntry();
/*     */     } catch (Exception poEXC) {
/* 129 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcTAR(File[] poEntradas, String psFiltro, OutputStream poSalida, boolean pbRelativo)
/*     */   {
/* 145 */     Iterator<File> voEntradas = Arrays.asList(poEntradas).iterator();
/* 146 */     TarOutputStream voTarOutput = null;
/* 147 */     File voArchivo = null;
/* 148 */     String vsFiltro = psFiltro.length() == 0 ? ".*" : psFiltro;
/* 149 */     int viContador = 0;
/*     */     try
/*     */     {
/* 152 */       voTarOutput = new TarOutputStream(poSalida);
/* 153 */       while (voEntradas.hasNext()) {
/* 154 */         voArchivo = (File)voEntradas.next();
/* 155 */         if (voArchivo.exists()) {
/* 156 */           if (voArchivo.isDirectory()) {
/* 157 */             viContador += fnciTarDirectorio(voArchivo, voArchivo.getParentFile(), vsFiltro, voTarOutput, pbRelativo);
/* 158 */           } else if (StringUtils.fncbFind(psFiltro, voArchivo.getName())) {
/* 159 */             prcTarArchivo(voArchivo, voArchivo.getParentFile(), voTarOutput, pbRelativo);
/* 160 */             viContador++;
/*     */           }
/*     */         }
/*     */       }
/* 164 */       if (viContador == 0) prcVacio(voTarOutput);
/*     */       return;
/* 166 */     } catch (Exception poEXC) { poEXC.printStackTrace();
/*     */     } finally {
/* 168 */       if (voTarOutput != null) { try { voTarOutput.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcTAR(File[] poEntradas, String psNombre, boolean pbRelativo)
/*     */   {
/* 183 */     BufferedOutputStream voSalida = null;
/*     */     try
/*     */     {
/* 186 */       voSalida = new BufferedOutputStream(new FileOutputStream(psNombre));
/* 187 */       prcTAR(poEntradas, "", voSalida, pbRelativo);
/* 188 */       voSalida.flush(); return;
/*     */     } catch (Exception poEXC) {
/* 190 */       poEXC.printStackTrace();
/*     */     } finally {
/* 192 */       if (voSalida != null) {
/* 193 */         try { voSalida.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcTAR(File[] poEntradas, String psNombre)
/*     */   {
/* 208 */     String vsNombre = "archivo.tar";
/*     */     
/* 210 */     if ((psNombre != null) && (psNombre.length() > 0))
/* 211 */       vsNombre = psNombre;
/* 212 */     prcTAR(poEntradas, vsNombre, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcTAR(File poEntrada)
/*     */   {
/* 225 */     String vsNombre = "";
/*     */     try
/*     */     {
/* 228 */       if (poEntrada.exists()) {
/* 229 */         if (poEntrada.isDirectory()) {
/* 230 */           vsNombre = poEntrada.getAbsolutePath() + ".tar";
/*     */         } else {
/* 232 */           vsNombre = poEntrada.getAbsolutePath().lastIndexOf(".") >= 0 ? poEntrada.getAbsolutePath().substring(0, poEntrada.getAbsolutePath().lastIndexOf(".")) : poEntrada.getAbsolutePath();
/* 233 */           vsNombre = vsNombre + ".tar";
/*     */         }
/* 235 */         prcTAR(new File[] { poEntrada }, vsNombre);
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 238 */       poEXC.printStackTrace();
/*     */     }
/* 240 */     return vsNombre;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final void prcUntarArchivo(File poArchivo, File poRaiz)
/*     */   {
/* 253 */     BufferedOutputStream voSalida = null;
/* 254 */     TarInputStream voStream = null;
/* 255 */     TarEntry voElemento = null;
/* 256 */     File voArchivoSalida = null;
/* 257 */     String vsAbsolutePath = "";
/* 258 */     String vsNombreEntrada = "";
/* 259 */     byte[] voBuffer = new byte['Ѐ'];
/* 260 */     int viLeidos = 0;
/*     */     try
/*     */     {
/* 263 */       if ((poArchivo.isFile()) && (poRaiz.isDirectory())) {
/* 264 */         voStream = new TarInputStream(new BufferedInputStream(new FileInputStream(poArchivo)));
/* 265 */         for (;;) { if ((voElemento = voStream.getNextEntry()) != null) {
/* 266 */             vsAbsolutePath = "";
/* 267 */             voArchivoSalida = null;
/* 268 */             voSalida = null;
/*     */             try {
/* 270 */               vsNombreEntrada = voElemento.getName();
/* 271 */               if (vsNombreEntrada.startsWith(".")) vsNombreEntrada = vsNombreEntrada.substring(1);
/* 272 */               vsAbsolutePath = poRaiz.getAbsolutePath() + File.separator + vsNombreEntrada;
/* 273 */               voArchivoSalida = new File(vsAbsolutePath);
/* 274 */               FileUtils.fncbVerificaDirectorio(voArchivoSalida.getParentFile().getAbsolutePath());
/*     */               
/* 276 */               voSalida = new BufferedOutputStream(new FileOutputStream(voArchivoSalida));
/* 277 */               while ((viLeidos = voStream.read(voBuffer)) != -1) {
/* 278 */                 voSalida.write(voBuffer, 0, viLeidos);
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 283 */               if (voSalida != null) {
/*     */                 try {
/* 285 */                   voSalida.flush();
/* 286 */                   voSalida.close();
/*     */                 }
/*     */                 catch (Exception voIgnorar) {}
/*     */               }
/*     */             }
/*     */             catch (Exception poEXC)
/*     */             {
/* 281 */               poEXC.printStackTrace();
/*     */             } finally {
/* 283 */               if (voSalida != null)
/*     */                 try {
/* 285 */                   voSalida.flush();
/* 286 */                   voSalida.close();
/*     */                 } catch (Exception voIgnorar) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 293 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcUNTAR(File poEntrada, File poSalida)
/*     */   {
/* 308 */     String vsNombre = "";
/*     */     try
/*     */     {
/* 311 */       if ((poEntrada.exists()) && 
/* 312 */         (poEntrada.isFile()) && (StringUtils.fncbFind(".tar", poEntrada.getName())) && 
/* 313 */         (FileUtils.fncbVerificaDirectorio(poSalida.getAbsolutePath()))) {
/* 314 */         prcUntarArchivo(poEntrada, poSalida);
/* 315 */         vsNombre = poSalida.getAbsolutePath();
/*     */       }
/*     */     }
/*     */     catch (Exception poEXC)
/*     */     {
/* 320 */       poEXC.printStackTrace();
/*     */     }
/* 322 */     return vsNombre;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcUNTAR(File poEntrada)
/*     */   {
/* 335 */     String vsSalida = poEntrada.getAbsolutePath().substring(0, poEntrada.getAbsolutePath().lastIndexOf("."));
/* 336 */     return prcUNTAR(poEntrada, new File(vsSalida));
/*     */   }
/*     */   
/*     */   public static void main(String[] psParametros) {
/* 340 */     String vsRuta = "";
/* 341 */     String vsRutaSalida = "";
/*     */     
/* 343 */     vsRuta = "C:/Users/infomedia/Documents/INVENTARIO_MGW.tar";
/* 344 */     vsRutaSalida = "C:/Users/infomedia/Documents/INVENTARIO_MGW";
/*     */     
/* 346 */     prcUNTAR(new File(vsRuta), new File(vsRutaSalida));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\packaging\TarUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */