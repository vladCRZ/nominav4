/*     */ package com.infomedia.utils.packaging;
/*     */ 
/*     */ import com.infomedia.utils.DateUtils;
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Zip
/*     */ {
/*     */   public static final String EXTENSION = ".zip";
/*     */   
/*     */   private static final void prcZipArchivo(File poArchivo, File poRaiz, ZipOutputStream poZipOutput, boolean pbRelativo)
/*     */   {
/*  40 */     String vsRutaArchivo = poArchivo.getAbsolutePath();
/*  41 */     String vsRutaRaiz = poRaiz.getAbsolutePath();
/*  42 */     BufferedInputStream voInput = null;
/*  43 */     byte[] voBuffer = new byte['Ѐ'];
/*  44 */     int viLeidos = 0;
/*     */     try
/*     */     {
/*  47 */       if (pbRelativo) {
/*  48 */         vsRutaArchivo = vsRutaArchivo.substring(vsRutaRaiz.length() + 1);
/*     */       }
/*  50 */       voInput = new BufferedInputStream(new FileInputStream(poArchivo));
/*  51 */       poZipOutput.putNextEntry(new ZipEntry(vsRutaArchivo));
/*     */       
/*  53 */       while ((viLeidos = voInput.read(voBuffer)) != -1) {
/*  54 */         poZipOutput.write(voBuffer, 0, viLeidos);
/*     */       }
/*     */       
/*  57 */       voInput.close();
/*     */       
/*  59 */       poZipOutput.closeEntry();
/*     */     } catch (Exception poEXC) {
/*  61 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int fnciZipDirectorio(File poDirectorio, File poRaiz, String psFiltro, Calendar poFrom, Calendar poTo, ZipOutputStream poZipOutput, boolean pbRelativo)
/*     */   {
/*  79 */     Iterator<String> voArchivos = null;
/*  80 */     File voFile = null;
/*  81 */     int viContador = 0;
/*     */     
/*     */     try
/*     */     {
/*  85 */       if (poDirectorio.isDirectory()) {
/*  86 */         voArchivos = Arrays.asList(poDirectorio.list()).iterator();
/*     */         
/*  88 */         while (voArchivos.hasNext()) {
/*  89 */           voFile = new File(poDirectorio.getAbsolutePath() + File.separator + (String)voArchivos.next());
/*  90 */           if (voFile.isDirectory()) {
/*  91 */             viContador += fnciZipDirectorio(voFile, poRaiz, psFiltro, poZipOutput, pbRelativo);
/*  92 */           } else if (StringUtils.fncbFind(psFiltro, voFile.getName())) {
/*  93 */             prcZipArchivo(voFile, poRaiz, poZipOutput, pbRelativo);
/*  94 */             viContador++;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception poEXC) {
/*  99 */       poEXC.printStackTrace();
/*     */     }
/*     */     
/* 102 */     return viContador;
/*     */   }
/*     */   
/*     */   private static int fnciZipDirectorio(File poDirectorio, File poRaiz, String psFiltro, ZipOutputStream poZipOutput, boolean pbRelativo) {
/* 106 */     return fnciZipDirectorio(poDirectorio, poRaiz, psFiltro, null, null, poZipOutput, pbRelativo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void prcVacio(ZipOutputStream poZipOutput)
/*     */   {
/* 117 */     byte[] voSinInformacion = "No se encontraron archivos que coincidan con la búsqueda.".getBytes();
/*     */     try
/*     */     {
/* 120 */       poZipOutput.putNextEntry(new ZipEntry("ERROR.txt"));
/* 121 */       poZipOutput.write(voSinInformacion, 0, voSinInformacion.length);
/* 122 */       poZipOutput.closeEntry();
/*     */     } catch (Exception poEXC) {
/* 124 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File[] poEntradas, String psFiltro, Calendar poFrom, Calendar poTo, OutputStream poSalida, boolean pbRelativo)
/*     */   {
/* 140 */     Iterator<File> voEntradas = Arrays.asList(poEntradas).iterator();
/* 141 */     Calendar voFileDate = Calendar.getInstance();
/* 142 */     ZipOutputStream voZipOutput = null;
/* 143 */     File voArchivo = null;
/* 144 */     String vsFiltro = psFiltro.length() == 0 ? ".*" : psFiltro;
/* 145 */     int viContador = 0;
/*     */     try
/*     */     {
/* 148 */       voZipOutput = new ZipOutputStream(poSalida);
/* 149 */       while (voEntradas.hasNext()) {
/* 150 */         voArchivo = (File)voEntradas.next();
/* 151 */         if (voArchivo.exists()) {
/* 152 */           if (voArchivo.isDirectory()) {
/* 153 */             viContador += fnciZipDirectorio(voArchivo, voArchivo.getParentFile(), vsFiltro, voZipOutput, pbRelativo);
/* 154 */           } else if (StringUtils.fncbFind(psFiltro, voArchivo.getName())) {
/* 155 */             voFileDate.setTimeInMillis(voArchivo.lastModified());
/* 156 */             if (null != poFrom) {
/* 157 */               if ((DateUtils.fncbCompare(DateUtils.fncoTrucado(voFileDate, 6), DateUtils.fncoTrucado(poFrom, 6), 5)) && (DateUtils.fncbCompare(DateUtils.fncoTrucado(voFileDate, 6), DateUtils.fncoTrucado(poTo, 6), 3)))
/*     */               {
/* 159 */                 prcZipArchivo(voArchivo, voArchivo.getParentFile(), voZipOutput, pbRelativo);
/* 160 */                 viContador++;
/*     */               }
/* 162 */               if ((null == poTo) && 
/*     */               
/* 164 */                 (DateUtils.fncbCompare(DateUtils.fncoTrucado(voFileDate, 6), DateUtils.fncoTrucado(poFrom, 6), 1))) {
/* 165 */                 prcZipArchivo(voArchivo, voArchivo.getParentFile(), voZipOutput, pbRelativo);
/* 166 */                 viContador++;
/*     */               }
/*     */             }
/*     */             else {
/* 170 */               prcZipArchivo(voArchivo, voArchivo.getParentFile(), voZipOutput, pbRelativo);
/* 171 */               viContador++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 176 */       if (viContador == 0)
/* 177 */         prcVacio(voZipOutput);
/*     */       return;
/*     */     } catch (Exception poEXC) {
/* 180 */       poEXC.printStackTrace();
/*     */     } finally {
/* 182 */       if (voZipOutput != null) {
/*     */         try {
/* 184 */           voZipOutput.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void prcZIP(File[] poEntradas, String psFiltro, OutputStream poSalida, boolean pbRelativo) {
/* 192 */     prcZIP(poEntradas, psFiltro, null, null, poSalida, pbRelativo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File[] poEntradas, String psNombre, boolean pbRelativo)
/*     */   {
/* 206 */     BufferedOutputStream voSalida = null;
/*     */     try
/*     */     {
/* 209 */       voSalida = new BufferedOutputStream(new FileOutputStream(psNombre));
/* 210 */       prcZIP(poEntradas, "", voSalida, pbRelativo);
/* 211 */       voSalida.flush(); return;
/*     */     } catch (Exception poEXC) {
/* 213 */       poEXC.printStackTrace();
/*     */     } finally {
/* 215 */       if (voSalida != null) {
/*     */         try {
/* 217 */           voSalida.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File[] poEntradas, String psNombre)
/*     */   {
/* 234 */     String vsNombre = "archivo.zip";
/*     */     
/* 236 */     if ((psNombre != null) && (psNombre.length() > 0)) {
/* 237 */       vsNombre = psNombre;
/*     */     }
/* 239 */     prcZIP(poEntradas, vsNombre, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File poEntrada)
/*     */   {
/* 250 */     String vsNombre = "";
/*     */     try
/*     */     {
/* 253 */       if (poEntrada.exists()) {
/* 254 */         if (poEntrada.isDirectory()) {
/* 255 */           vsNombre = poEntrada.getAbsolutePath() + ".zip";
/*     */         } else {
/* 257 */           vsNombre = poEntrada.getAbsolutePath().lastIndexOf(".") >= 0 ? poEntrada.getAbsolutePath().substring(0, poEntrada.getAbsolutePath().lastIndexOf(".")) : poEntrada.getAbsolutePath();
/* 258 */           vsNombre = vsNombre + ".zip";
/*     */         }
/* 260 */         prcZIP(new File[] { poEntrada }, vsNombre);
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 263 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final void prcUnzipArchivo(File poArchivo, File poRaiz)
/*     */   {
/* 277 */     BufferedOutputStream voSalida = null;
/* 278 */     ZipInputStream voStream = null;
/* 279 */     ZipEntry voElemento = null;
/* 280 */     File voArchivoSalida = null;
/* 281 */     String vsAbsolutePath = "";
/* 282 */     String vsNombreEntrada = "";
/* 283 */     byte[] voBuffer = new byte['Ѐ'];
/* 284 */     int viLeidos = 0;
/*     */     try
/*     */     {
/* 287 */       if ((poArchivo.isFile()) && (poRaiz.isDirectory())) {
/* 288 */         voStream = new ZipInputStream(new BufferedInputStream(new FileInputStream(poArchivo)));
/* 289 */         for (;;) { if ((voElemento = voStream.getNextEntry()) != null) {
/* 290 */             vsAbsolutePath = "";
/* 291 */             voArchivoSalida = null;
/* 292 */             voSalida = null;
/*     */             try {
/* 294 */               vsNombreEntrada = voElemento.getName();
/* 295 */               if (vsNombreEntrada.startsWith(".")) {
/* 296 */                 vsNombreEntrada = vsNombreEntrada.substring(1);
/*     */               }
/* 298 */               vsAbsolutePath = poRaiz.getAbsolutePath() + File.separator + vsNombreEntrada;
/* 299 */               voArchivoSalida = new File(vsAbsolutePath);
/* 300 */               FileUtils.fncbVerificaDirectorio(voArchivoSalida.getParentFile().getAbsolutePath());
/*     */               
/* 302 */               voSalida = new BufferedOutputStream(new FileOutputStream(voArchivoSalida));
/* 303 */               while ((viLeidos = voStream.read(voBuffer)) != -1) {
/* 304 */                 voSalida.write(voBuffer, 0, viLeidos);
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 309 */               if (voSalida != null) {
/*     */                 try {
/* 311 */                   voSalida.flush();
/* 312 */                   voSalida.close();
/*     */                 }
/*     */                 catch (Exception voIgnorar) {}
/*     */               }
/*     */             }
/*     */             catch (Exception poEXC)
/*     */             {
/* 307 */               poEXC.printStackTrace();
/*     */             } finally {
/* 309 */               if (voSalida != null) {
/*     */                 try {
/* 311 */                   voSalida.flush();
/* 312 */                   voSalida.close();
/*     */                 } catch (Exception voIgnorar) {}
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 320 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcUNZIP(File poEntrada, File poSalida)
/*     */   {
/* 334 */     String vsNombre = "";
/*     */     try
/*     */     {
/* 337 */       if ((poEntrada.exists()) && 
/* 338 */         (poEntrada.isFile()) && (StringUtils.fncbFind(".zip", poEntrada.getName()))) {
/* 339 */         vsNombre = poSalida.getAbsolutePath();
/* 340 */         if (FileUtils.fncbVerificaDirectorio(vsNombre)) {
/* 341 */           prcUnzipArchivo(poEntrada, new File(vsNombre));
/* 342 */           vsNombre = poSalida.getAbsolutePath();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception poEXC) {
/* 347 */       poEXC.printStackTrace();
/*     */     }
/* 349 */     return vsNombre;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcUNZIP(File poEntrada)
/*     */   {
/* 361 */     String vsSalida = poEntrada.getAbsolutePath().substring(0, poEntrada.getAbsolutePath().lastIndexOf("."));
/* 362 */     return prcUNZIP(poEntrada, new File(vsSalida));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\packaging\Zip.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */