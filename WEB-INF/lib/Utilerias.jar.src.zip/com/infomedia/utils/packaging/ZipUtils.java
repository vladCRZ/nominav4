/*     */ package com.infomedia.utils.packaging;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ZipUtils
/*     */ {
/*     */   public static final String EXTENSION = ".zip";
/*     */   
/*     */   private static final void prcZipArchivo(File poArchivo, File poRaiz, ZipOutputStream poZipOutput, boolean pbRelativo)
/*     */   {
/*  48 */     String vsRutaArchivo = poArchivo.getAbsolutePath();
/*  49 */     String vsRutaRaiz = poRaiz.getAbsolutePath();
/*  50 */     BufferedInputStream voInput = null;
/*  51 */     byte[] voBuffer = new byte['Ѐ'];
/*  52 */     int viLeidos = 0;
/*     */     try
/*     */     {
/*  55 */       if (pbRelativo) vsRutaArchivo = vsRutaArchivo.substring(vsRutaRaiz.length() + 1);
/*  56 */       voInput = new BufferedInputStream(new FileInputStream(poArchivo));
/*  57 */       poZipOutput.putNextEntry(new ZipEntry(vsRutaArchivo));
/*     */       
/*  59 */       while ((viLeidos = voInput.read(voBuffer)) != -1) {
/*  60 */         poZipOutput.write(voBuffer, 0, viLeidos);
/*     */       }
/*  62 */       voInput.close();
/*     */       
/*  64 */       poZipOutput.closeEntry();
/*     */     } catch (Exception poEXC) {
/*  66 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int fnciZipDirectorio(File poDirectorio, File poRaiz, String psFiltro, ZipOutputStream poZipOutput, boolean pbRelativo)
/*     */   {
/*  84 */     Iterator<String> voArchivos = null;
/*  85 */     File voFile = null;
/*  86 */     int viContador = 0;
/*     */     
/*     */     try
/*     */     {
/*  90 */       if (poDirectorio.isDirectory()) {
/*  91 */         voArchivos = Arrays.asList(poDirectorio.list()).iterator();
/*     */         
/*  93 */         while (voArchivos.hasNext()) {
/*  94 */           voFile = new File(poDirectorio.getAbsolutePath() + File.separator + (String)voArchivos.next());
/*  95 */           if (voFile.isDirectory()) {
/*  96 */             viContador += fnciZipDirectorio(voFile, poRaiz, psFiltro, poZipOutput, pbRelativo);
/*  97 */           } else if (StringUtils.fncbFind(psFiltro, voFile.getName())) {
/*  98 */             prcZipArchivo(voFile, poRaiz, poZipOutput, pbRelativo);
/*  99 */             viContador++;
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 104 */       poEXC.printStackTrace();
/*     */     }
/*     */     
/* 107 */     return viContador;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void prcVacio(ZipOutputStream poZipOutput)
/*     */   {
/* 119 */     byte[] voSinInformacion = "No se encontraron archivos que coincidan con la búsqueda.".getBytes();
/*     */     try
/*     */     {
/* 122 */       poZipOutput.putNextEntry(new ZipEntry("ERROR.txt"));
/* 123 */       poZipOutput.write(voSinInformacion, 0, voSinInformacion.length);
/* 124 */       poZipOutput.closeEntry();
/*     */     } catch (Exception poEXC) {
/* 126 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File[] poEntradas, String psFiltro, OutputStream poSalida, boolean pbRelativo)
/*     */   {
/* 142 */     Iterator<File> voEntradas = Arrays.asList(poEntradas).iterator();
/* 143 */     ZipOutputStream voZipOutput = null;
/* 144 */     File voArchivo = null;
/* 145 */     String vsFiltro = psFiltro.length() == 0 ? ".*" : psFiltro;
/* 146 */     int viContador = 0;
/*     */     try
/*     */     {
/* 149 */       voZipOutput = new ZipOutputStream(poSalida);
/* 150 */       while (voEntradas.hasNext()) {
/* 151 */         voArchivo = (File)voEntradas.next();
/* 152 */         if (voArchivo.exists()) {
/* 153 */           if (voArchivo.isDirectory()) {
/* 154 */             viContador += fnciZipDirectorio(voArchivo, voArchivo.getParentFile(), vsFiltro, voZipOutput, pbRelativo);
/* 155 */           } else if (StringUtils.fncbFind(psFiltro, voArchivo.getName())) {
/* 156 */             prcZipArchivo(voArchivo, voArchivo.getParentFile(), voZipOutput, pbRelativo);
/* 157 */             viContador++;
/*     */           }
/*     */         }
/*     */       }
/* 161 */       if (viContador == 0) prcVacio(voZipOutput);
/*     */       return;
/* 163 */     } catch (Exception poEXC) { poEXC.printStackTrace();
/*     */     } finally {
/* 165 */       if (voZipOutput != null) { try { voZipOutput.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File[] poEntradas, String psNombre, boolean pbRelativo)
/*     */   {
/* 180 */     BufferedOutputStream voSalida = null;
/*     */     try
/*     */     {
/* 183 */       voSalida = new BufferedOutputStream(new FileOutputStream(psNombre));
/* 184 */       prcZIP(poEntradas, "", voSalida, pbRelativo);
/* 185 */       voSalida.flush(); return;
/*     */     } catch (Exception poEXC) {
/* 187 */       poEXC.printStackTrace();
/*     */     } finally {
/* 189 */       if (voSalida != null) {
/* 190 */         try { voSalida.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File[] poEntradas, String psNombre)
/*     */   {
/* 205 */     String vsNombre = "archivo.zip";
/*     */     
/* 207 */     if ((psNombre != null) && (psNombre.length() > 0))
/* 208 */       vsNombre = psNombre;
/* 209 */     prcZIP(poEntradas, vsNombre, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void prcZIP(File poEntrada)
/*     */   {
/* 221 */     String vsNombre = "";
/*     */     try
/*     */     {
/* 224 */       if (poEntrada.exists()) {
/* 225 */         if (poEntrada.isDirectory()) {
/* 226 */           vsNombre = poEntrada.getAbsolutePath() + ".zip";
/*     */         } else {
/* 228 */           vsNombre = poEntrada.getAbsolutePath().lastIndexOf(".") >= 0 ? poEntrada.getAbsolutePath().substring(0, poEntrada.getAbsolutePath().lastIndexOf(".")) : poEntrada.getAbsolutePath();
/* 229 */           vsNombre = vsNombre + ".zip";
/*     */         }
/* 231 */         prcZIP(new File[] { poEntrada }, vsNombre);
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 234 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final void prcUnzipArchivo(File poArchivo, File poRaiz)
/*     */   {
/* 248 */     BufferedOutputStream voSalida = null;
/* 249 */     ZipInputStream voStream = null;
/* 250 */     ZipEntry voElemento = null;
/* 251 */     File voArchivoSalida = null;
/* 252 */     String vsAbsolutePath = "";
/* 253 */     String vsNombreEntrada = "";
/* 254 */     byte[] voBuffer = new byte['Ѐ'];
/* 255 */     int viLeidos = 0;
/*     */     try
/*     */     {
/* 258 */       if ((poArchivo.isFile()) && (poRaiz.isDirectory())) {
/* 259 */         voStream = new ZipInputStream(new BufferedInputStream(new FileInputStream(poArchivo)));
/* 260 */         for (;;) { if ((voElemento = voStream.getNextEntry()) != null) {
/* 261 */             vsAbsolutePath = "";
/* 262 */             voArchivoSalida = null;
/* 263 */             voSalida = null;
/*     */             try {
/* 265 */               vsNombreEntrada = voElemento.getName();
/* 266 */               if (vsNombreEntrada.startsWith(".")) vsNombreEntrada = vsNombreEntrada.substring(1);
/* 267 */               vsAbsolutePath = poRaiz.getAbsolutePath() + File.separator + vsNombreEntrada;
/* 268 */               voArchivoSalida = new File(vsAbsolutePath);
/* 269 */               FileUtils.fncbVerificaDirectorio(voArchivoSalida.getParentFile().getAbsolutePath());
/*     */               
/* 271 */               voSalida = new BufferedOutputStream(new FileOutputStream(voArchivoSalida));
/* 272 */               while ((viLeidos = voStream.read(voBuffer)) != -1) {
/* 273 */                 voSalida.write(voBuffer, 0, viLeidos);
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 278 */               if (voSalida != null) {
/*     */                 try {
/* 280 */                   voSalida.flush();
/* 281 */                   voSalida.close();
/*     */                 }
/*     */                 catch (Exception voIgnorar) {}
/*     */               }
/*     */             }
/*     */             catch (Exception poEXC)
/*     */             {
/* 276 */               poEXC.printStackTrace();
/*     */             } finally {
/* 278 */               if (voSalida != null)
/*     */                 try {
/* 280 */                   voSalida.flush();
/* 281 */                   voSalida.close();
/*     */                 } catch (Exception voIgnorar) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception poEXC) {
/* 288 */       poEXC.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcUNZIP(File poEntrada, File poSalida)
/*     */   {
/* 303 */     String vsNombre = "";
/*     */     try
/*     */     {
/* 306 */       if ((poEntrada.exists()) && 
/* 307 */         (poEntrada.isFile()) && (StringUtils.fncbFind(".zip", poEntrada.getName()))) {
/* 308 */         vsNombre = poSalida.getAbsolutePath();
/* 309 */         if (FileUtils.fncbVerificaDirectorio(vsNombre)) {
/* 310 */           prcUnzipArchivo(poEntrada, new File(vsNombre));
/* 311 */           vsNombre = poSalida.getAbsolutePath();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception poEXC) {
/* 316 */       poEXC.printStackTrace();
/*     */     }
/* 318 */     return vsNombre;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String prcUNZIP(File poEntrada)
/*     */   {
/* 331 */     String vsSalida = poEntrada.getAbsolutePath().substring(0, poEntrada.getAbsolutePath().lastIndexOf("."));
/* 332 */     return prcUNZIP(poEntrada, new File(vsSalida));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\packaging\ZipUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */