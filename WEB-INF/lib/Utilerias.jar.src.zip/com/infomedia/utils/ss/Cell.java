/*    */ package com.infomedia.utils.ss;
/*    */ 
/*    */ import com.infomedia.utils.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cell
/*    */ {
/* 14 */   private CellPosition goPosition = null;
/* 15 */   private String gsValue = "";
/* 16 */   private String gsFormat = "";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Cell getVoidCell()
/*    */   {
/* 27 */     return new Cell("", "");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Cell(String psValue, String psFormat)
/*    */   {
/* 39 */     byte[] voBytes = psFormat.getBytes();
/* 40 */     StringBuffer hexString = new StringBuffer();
/* 41 */     for (int i = 0; i < voBytes.length; i++) {
/* 42 */       hexString.append(Integer.toHexString(0xFF & voBytes[i]));
/*    */     }
/*    */     
/* 45 */     this.gsValue = psValue;
/* 46 */     this.gsFormat = psFormat;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Cell(String psValue)
/*    */   {
/* 57 */     this(psValue, "");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 68 */     return this.gsValue;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 78 */   public String getFormat() { return this.gsFormat; }
/*    */   
/* 80 */   public CellPosition getPosition() { return this.goPosition; }
/* 81 */   public void setPosition(CellPosition poPosition) { this.goPosition = poPosition; }
/*    */   
/* 83 */   public boolean isVoid() { return StringUtils.isNVL(this.gsValue); }
/*    */   
/* 85 */   public String toString() { return "Cell" + this.goPosition + "[Value:" + this.gsValue + ";" + "Format:" + this.gsFormat + "]"; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\Cell.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */