/*    */ package com.infomedia.utils.ss;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CellPosition
/*    */ {
/*    */   public static class PositionComparator
/*    */     implements Comparator<CellPosition>
/*    */   {
/*    */     public int compare(CellPosition poPosition1, CellPosition poPosition2)
/*    */     {
/* 34 */       int viRetorno = poPosition1.getRow() - poPosition2.getRow();
/* 35 */       if (viRetorno == 0) viRetorno = poPosition1.getColumn() - poPosition2.getColumn();
/* 36 */       return viRetorno;
/*    */     }
/*    */   }
/*    */   
/* 40 */   public int giColumn = 0;
/* 41 */   public int giRow = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CellPosition(int piColumn, int piRrow)
/*    */   {
/* 53 */     this.giColumn = piColumn;
/* 54 */     this.giRow = piRrow;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getColumn()
/*    */   {
/* 65 */     return this.giColumn;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getRow()
/*    */   {
/* 75 */     return this.giRow;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 86 */     return "[" + this.giColumn + "," + this.giRow + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\CellPosition.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */