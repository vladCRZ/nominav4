/*     */ package com.infomedia.utils.ss;
/*     */ 
/*     */ import com.infomedia.utils.DinamicVO;
/*     */ import com.infomedia.utils.DinamicVector;
/*     */ import com.infomedia.utils.SpanishGrammarUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpreadSheet
/*     */ {
/*  23 */   private String gsName = "";
/*  24 */   private SortedMap<CellPosition, Cell> goContent = new TreeMap(new CellPosition.PositionComparator());
/*  25 */   private int giMaxCol = 0;
/*  26 */   private int giMaxRow = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpreadSheet(String psName)
/*     */   {
/*  36 */     this.gsName = psName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  48 */     return this.gsName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCell(CellPosition poPosition, Cell poValue)
/*     */   {
/*  59 */     this.giMaxCol = (poPosition.getColumn() > this.giMaxCol ? poPosition.getColumn() : this.giMaxCol);
/*  60 */     this.giMaxRow = (poPosition.getRow() > this.giMaxRow ? poPosition.getRow() : this.giMaxRow);
/*  61 */     poValue.setPosition(poPosition);
/*  62 */     this.goContent.put(poPosition, poValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell getCell(CellPosition poPosition)
/*     */   {
/*  74 */     Cell voCell = this.goContent.containsKey(poPosition) ? (Cell)this.goContent.get(poPosition) : Cell.getVoidCell();
/*  75 */     if (voCell.isVoid()) voCell.setPosition(poPosition);
/*  76 */     return voCell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellPosition getMaxPosition()
/*     */   {
/*  86 */     return new CellPosition(this.giMaxCol, this.giMaxRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxRow()
/*     */   {
/*  95 */     return getMaxPosition().getRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxCol()
/*     */   {
/* 104 */     return getMaxPosition().getColumn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 116 */     return this.goContent.size() == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Cell> getRow(int piRowNumber)
/*     */   {
/* 128 */     List<Cell> voRow = new ArrayList();
/* 129 */     if (piRowNumber <= getMaxRow()) {
/* 130 */       for (int viColumnIndex = 0; viColumnIndex <= getMaxCol(); viColumnIndex++) {
/* 131 */         voRow.add(getCell(new CellPosition(viColumnIndex, piRowNumber)));
/*     */       }
/*     */     }
/* 134 */     return voRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Cell> getColumn(int piColumnNumber)
/*     */   {
/* 146 */     List<Cell> voColumn = new ArrayList();
/* 147 */     if (piColumnNumber <= getMaxRow()) {
/* 148 */       for (int viRowIndex = 0; viRowIndex <= getMaxCol(); viRowIndex++) {
/* 149 */         voColumn.add(getCell(new CellPosition(piColumnNumber, viRowIndex)));
/*     */       }
/*     */     }
/* 152 */     return voColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DinamicVector parseHeadedSheet(SpreadSheet poSpreadSheet, int piHeaderRow, int piHeaderCol, int piMaxData, int piDataOffset)
/*     */   {
/* 170 */     List<String> voHeaders = new ArrayList();
/* 171 */     DinamicVector voParsedVOS = new DinamicVector();
/* 172 */     DinamicVO voParsedVO = null;
/*     */     
/* 174 */     int viDataRowIndex = piHeaderRow + piDataOffset + 1;
/*     */     
/* 176 */     int viRowIndex = 1;
/* 177 */     int viColumnIndex = 0;
/*     */     
/* 179 */     if (!poSpreadSheet.isVoid())
/*     */     {
/* 181 */       for (Cell voCell : poSpreadSheet.getRow(piHeaderRow)) {
/* 182 */         if (voCell.getPosition().getColumn() >= piHeaderCol) { voHeaders.add(SpanishGrammarUtils.cleanStressMarks(voCell.getValue().trim()));
/*     */         }
/*     */       }
/* 185 */       for (viRowIndex = viDataRowIndex; viRowIndex <= poSpreadSheet.getMaxRow(); viRowIndex++) {
/* 186 */         voParsedVO = new DinamicVO(true);
/* 187 */         viColumnIndex = piHeaderCol;
/* 188 */         for (String vsHeader : voHeaders) {
/* 189 */           if (!StringUtils.isNVL(vsHeader)) voParsedVO.setCampo(vsHeader, poSpreadSheet.getCell(new CellPosition(viColumnIndex, viRowIndex)).getValue().trim());
/* 190 */           viColumnIndex++;
/*     */         }
/* 192 */         voParsedVOS.add(voParsedVO);
/* 193 */         if ((piMaxData > 0) && (voParsedVOS.size() >= piMaxData))
/*     */           break;
/*     */       }
/*     */     }
/* 197 */     return voParsedVOS;
/*     */   }
/*     */   
/* 200 */   public static DinamicVector parseHeadedSheet(SpreadSheet poSpreadSheet, int piHeaderIndex, int piOffset) { return parseHeadedSheet(poSpreadSheet, piHeaderIndex, 0, 0, piOffset); }
/*     */   
/*     */   public static DinamicVector parseHeadedSheet(SpreadSheet poSpreadSheet, int piHeaderIndex) {
/* 203 */     return parseHeadedSheet(poSpreadSheet, piHeaderIndex, 1);
/*     */   }
/*     */   
/* 206 */   public static DinamicVector parseHeadedSheet(SpreadSheet poSpreadSheet) { return parseHeadedSheet(poSpreadSheet, 0); }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\SpreadSheet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */