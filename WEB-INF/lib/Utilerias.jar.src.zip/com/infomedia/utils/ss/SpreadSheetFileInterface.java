package com.infomedia.utils.ss;

public abstract interface SpreadSheetFileInterface
{
  public abstract boolean openFile();
  
  public abstract boolean closeFile();
  
  public abstract boolean readFile();
  
  public abstract boolean saveFile();
  
  public abstract int getNumberOfSheets();
  
  public abstract SpreadSheetInterface getSheetAt(int paramInt);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\SpreadSheetFileInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */