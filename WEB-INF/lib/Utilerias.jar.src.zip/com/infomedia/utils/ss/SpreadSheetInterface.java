package com.infomedia.utils.ss;

import java.util.List;

public abstract interface SpreadSheetInterface
{
  public abstract int getNumberOfRows();
  
  public abstract int getNumberOfCells(int paramInt);
  
  public abstract String getCellAsString(int paramInt1, int paramInt2);
  
  public abstract List<String> getRow(int paramInt);
  
  public abstract List<String> getRow(int paramInt1, int paramInt2);
  
  public abstract List<String> getRow(int paramInt1, int paramInt2, int paramInt3);
  
  public abstract List<String> getColumn(int paramInt);
  
  public abstract List<String> getColumn(int paramInt1, int paramInt2);
  
  public abstract List<String> getColumn(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\SpreadSheetInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */