package com.infomedia.utils.ss;

import java.io.InputStream;

public abstract interface SpreadSheetParser
{
  public abstract WorkBook parse(String paramString);
  
  public abstract WorkBook parse(InputStream paramInputStream);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\SpreadSheetParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */