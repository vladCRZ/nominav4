/*    */ package com.infomedia.utils.ss;
/*    */ 
/*    */ import com.infomedia.utils.ss.csv.CSVParser;
/*    */ import com.infomedia.utils.ss.xls.XLSParser;
/*    */ import com.infomedia.utils.ss.xls.XLSXParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SpreadSheetParserFactory
/*    */ {
/*    */   public static enum SS_TYPE
/*    */   {
/* 26 */     CSV,  XLS,  XLSX;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     private SS_TYPE() {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static SpreadSheetParser getParser(SS_TYPE poType)
/*    */     throws Exception
/*    */   {
/* 40 */     switch (poType) {
/*    */     case CSV: 
/* 42 */       return CSVParser.getInstance();
/*    */     case XLS: 
/* 44 */       return XLSParser.getInstance();
/*    */     case XLSX: 
/* 46 */       return XLSXParser.getInstance();
/*    */     }
/* 48 */     throw new Exception("Unexpected file type");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static SS_TYPE getType(String psFileName)
/*    */     throws Exception
/*    */   {
/* 64 */     if (CSVParser.isCSVFile(psFileName)) return SS_TYPE.CSV;
/* 65 */     if (XLSParser.isXLSFile(psFileName)) return SS_TYPE.XLS;
/* 66 */     if (XLSXParser.isXLSXFile(psFileName)) return SS_TYPE.XLSX;
/* 67 */     throw new Exception("Unexpected file type");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\SpreadSheetParserFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */