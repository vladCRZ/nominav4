/*    */ package com.infomedia.utils.ss;
/*    */ 
/*    */ import java.util.SortedMap;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkBook
/*    */ {
/* 16 */   private boolean gb1904 = false;
/* 17 */   private SortedMap<Integer, SpreadSheet> goSpreadSheets = new TreeMap();
/* 18 */   public int getNumberOfSheets() { return this.goSpreadSheets.size(); }
/* 19 */   public SortedMap<Integer, SpreadSheet> getSpreadSheets() { return this.goSpreadSheets; }
/* 20 */   public boolean is1904() { return this.gb1904; }
/* 21 */   public void set1904(boolean pb1904) { this.gb1904 = pb1904; }
/*    */   
/* 23 */   public void addSpreadSheet(SpreadSheet poSpreadSheet) { this.goSpreadSheets.put(new Integer(getNumberOfSheets()), poSpreadSheet); }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\WorkBook.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */