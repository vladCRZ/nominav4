/*     */ package com.infomedia.utils.ss.csv;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.infomedia.utils.ss.Cell;
/*     */ import com.infomedia.utils.ss.CellPosition;
/*     */ import com.infomedia.utils.ss.SpreadSheet;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSVFileReader
/*     */ {
/*     */   public static final class CSVValue
/*     */   {
/*     */     public static final String SEPARATOR = ",";
/*     */     public static final String QUOTATION = "\"";
/*     */     public static final String NEWLINE = "\n";
/*     */     public static final String CR = "\r";
/*     */     public static final String INNER_QUOT_BEGIN = "";
/*     */     public static final String INNER_QUOT_END = "";
/*  34 */     StringBuffer gsValue = new StringBuffer();
/*  35 */     boolean isQuotatedValue = false;
/*     */     private String gsSeparator;
/*     */     
/*     */     public CSVValue(String psSeparator)
/*     */     {
/*  40 */       this.gsSeparator = (StringUtils.isNVL(psSeparator) ? "," : psSeparator);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  54 */       return this.isQuotatedValue ? this.gsValue.toString().replaceAll(this.gsSeparator + "\"", "").replaceAll("\"" + this.gsSeparator, "") : this.gsValue.toString().replace(this.gsSeparator, "");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addValue(String psValue)
/*     */     {
/*  70 */       if (this.gsValue.toString().equals(this.gsSeparator))
/*  71 */         this.isQuotatedValue = psValue.startsWith("\"");
/*  72 */       this.gsValue.append(psValue);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isComplete()
/*     */     {
/*  85 */       return (this.gsValue.toString().startsWith(this.gsSeparator + "\"")) && (this.gsValue.toString().endsWith("\"" + this.gsSeparator));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean needsLastSeparator()
/*     */     {
/*  98 */       return this.isQuotatedValue ? false : (this.gsValue.toString().startsWith(this.gsSeparator + "\"")) && (this.gsValue.toString().endsWith("\"")) ? true : this.gsValue.toString().startsWith(this.gsSeparator);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isVoid()
/*     */     {
/* 112 */       return this.gsValue.length() == 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SpreadSheet separateCells(String rowString, String psSeparator)
/*     */   {
/* 127 */     SpreadSheet voSpredSheet = new SpreadSheet("DEFAULT");
/* 128 */     StringTokenizer voSeparatedTokens = new StringTokenizer(rowString, psSeparator, true);
/* 129 */     StringTokenizer voNLTokens = null;
/*     */     
/* 131 */     CSVValue voValue = new CSVValue(psSeparator);
/*     */     
/* 133 */     String vsCommaToken = "";
/* 134 */     String vsNLToken = "";
/*     */     
/* 136 */     int viRowIndex = 0;
/* 137 */     int viColIndex = 0;
/*     */     
/* 139 */     boolean vbNewLine = false;
/*     */     
/* 141 */     while (voSeparatedTokens.hasMoreTokens()) {
/* 142 */       vsCommaToken = voSeparatedTokens.nextToken();
/* 143 */       voNLTokens = new StringTokenizer(vsCommaToken, "\n", true);
/* 144 */       while (voNLTokens.hasMoreTokens()) {
/* 145 */         vsNLToken = voNLTokens.nextToken();
/* 146 */         vsNLToken = vsNLToken.replaceAll("\r", "");
/*     */         
/* 148 */         if ((vsNLToken.equals("\n")) && 
/* 149 */           (voValue.needsLastSeparator())) {
/* 150 */           voValue.addValue(psSeparator);
/* 151 */           vbNewLine = true;
/*     */         }
/*     */         
/*     */ 
/* 155 */         if (voValue.isComplete()) {
/* 156 */           voSpredSheet.setCell(new CellPosition(viColIndex, viRowIndex), new Cell(voValue.toString()));
/* 157 */           voValue = new CSVValue(psSeparator);
/* 158 */           viColIndex++;
/*     */         }
/* 160 */         if (!vbNewLine) {
/* 161 */           if (voValue.isVoid()) voValue.addValue(psSeparator);
/* 162 */           voValue.addValue(vsNLToken);
/*     */         } else {
/* 164 */           vbNewLine = false;
/* 165 */           viColIndex = 0;
/* 166 */           viRowIndex++;
/*     */         }
/* 168 */         if ((!voSeparatedTokens.hasMoreElements()) && (voValue.needsLastSeparator())) {
/* 169 */           voSpredSheet.setCell(new CellPosition(viColIndex, viRowIndex), new Cell(voValue.toString()));
/* 170 */           voValue = new CSVValue(psSeparator);
/* 171 */           viColIndex++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 176 */     return voSpredSheet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SpreadSheet separateCells(String rowString)
/*     */   {
/* 190 */     return separateCells(rowString, ",");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StringBuffer readFile(String psFileName)
/*     */   {
/* 204 */     BufferedReader voFileReader = null;
/* 205 */     voStringBuffer = new StringBuffer(1000);
/* 206 */     char[] voBuffer = new char['Ѐ'];
/* 207 */     int viReaded = 0;
/*     */     try
/*     */     {
/* 210 */       voFileReader = new BufferedReader(new FileReader(psFileName));
/* 211 */       while ((viReaded = voFileReader.read(voBuffer)) != -1) {
/* 212 */         voStringBuffer.append(String.valueOf(voBuffer, 0, viReaded));
/* 213 */         voBuffer = new char['Ѐ'];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */       return voStringBuffer;
/*     */     }
/*     */     catch (Exception voIgnorar) {}finally
/*     */     {
/*     */       try
/*     */       {
/* 217 */         voFileReader.close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public static StringBuffer readStream(InputStream poInputStream) {
/* 224 */     BufferedReader voFileReader = null;
/* 225 */     voStringBuffer = new StringBuffer(1000);
/* 226 */     char[] voBuffer = new char['Ѐ'];
/* 227 */     int viReaded = 0;
/*     */     try
/*     */     {
/* 230 */       voFileReader = new BufferedReader(new InputStreamReader(poInputStream));
/* 231 */       while ((viReaded = voFileReader.read(voBuffer)) != -1) {
/* 232 */         voStringBuffer.append(String.valueOf(voBuffer, 0, viReaded));
/* 233 */         voBuffer = new char['Ѐ'];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */       return voStringBuffer;
/*     */     }
/*     */     catch (Exception voIgnorar) {}finally
/*     */     {
/*     */       try
/*     */       {
/* 237 */         voFileReader.close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SpreadSheet parseFile(StringBuffer poContent, String psSeparator)
/*     */   {
/* 255 */     SpreadSheet voSpreadSheet = new SpreadSheet("DEFAULT");
/*     */     try
/*     */     {
/* 258 */       voSpreadSheet = separateCells(poContent.toString(), psSeparator);
/*     */     }
/*     */     catch (Exception e) {}
/* 261 */     return voSpreadSheet;
/*     */   }
/*     */   
/* 264 */   public static SpreadSheet parseFile(String psFileName, String psSeparator) { return parseFile(readFile(psFileName), psSeparator); }
/*     */   
/*     */   public static SpreadSheet parseFile(String psFileName) {
/* 267 */     return parseFile(psFileName, ",");
/*     */   }
/*     */   
/* 270 */   public static SpreadSheet parseFile(InputStream poInputStream, String psSeparator) { return parseFile(readStream(poInputStream), psSeparator); }
/*     */   
/*     */   public static SpreadSheet parseFile(InputStream poInputStream) {
/* 273 */     return parseFile(poInputStream, ",");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\csv\CSVFileReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */