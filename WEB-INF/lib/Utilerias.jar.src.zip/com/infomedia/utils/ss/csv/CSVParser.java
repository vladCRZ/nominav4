/*    */ package com.infomedia.utils.ss.csv;
/*    */ 
/*    */ import com.infomedia.utils.ss.SpreadSheetParser;
/*    */ import com.infomedia.utils.ss.WorkBook;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSVParser
/*    */   implements SpreadSheetParser
/*    */ {
/*    */   public static final String EXT = ".csv";
/*    */   
/*    */   public static CSVParser getInstance()
/*    */   {
/* 37 */     return new CSVParser();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isCSVFile(String psFileName)
/*    */   {
/* 49 */     return psFileName.toLowerCase().endsWith(".csv");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized WorkBook parse(InputStream poInputStream)
/*    */   {
/* 63 */     WorkBook voWorkBook = new WorkBook();
/* 64 */     voWorkBook.addSpreadSheet(CSVFileReader.parseFile(poInputStream));
/* 65 */     return voWorkBook;
/*    */   }
/*    */   
/* 68 */   public synchronized WorkBook parse(String psCSVFileName) { WorkBook voWorkBook = new WorkBook();
/* 69 */     voWorkBook.addSpreadSheet(CSVFileReader.parseFile(psCSVFileName));
/* 70 */     return voWorkBook;
/*    */   }
/*    */   
/* 73 */   public synchronized WorkBook parse(String psCSVFileName, String psSeparator) { WorkBook voWorkBook = new WorkBook();
/* 74 */     voWorkBook.addSpreadSheet(CSVFileReader.parseFile(psCSVFileName, psSeparator));
/* 75 */     return voWorkBook;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\csv\CSVParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */