/*    */ package com.infomedia.utils.ss.csv;
/*    */ 
/*    */ import com.infomedia.utils.FileUtils;
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSVWriter
/*    */ {
/*    */   private static String escapeDoubleQuotes(String psQuotedText)
/*    */   {
/* 22 */     String vsEscapeQuotedText = psQuotedText;
/* 23 */     boolean openQuote = false;
/* 24 */     for (int viIdx = 0; viIdx < vsEscapeQuotedText.length(); viIdx++) {
/* 25 */       if ((vsEscapeQuotedText.charAt(viIdx) == '"') && (openQuote)) {
/* 26 */         vsEscapeQuotedText = vsEscapeQuotedText.replaceFirst("\"", "");
/* 27 */         openQuote = false;
/* 28 */       } else if (vsEscapeQuotedText.charAt(viIdx) == '"') {
/* 29 */         vsEscapeQuotedText = vsEscapeQuotedText.replaceFirst("\"", "");
/* 30 */         openQuote = true;
/*    */       }
/*    */     }
/* 33 */     return vsEscapeQuotedText;
/*    */   }
/*    */   
/*    */   public static String getCSVString(List<List<String>> poContent) {
/* 37 */     StringBuffer voCSVContent = new StringBuffer();
/* 38 */     String vsRow = "";
/*    */     
/* 40 */     for (List<String> voRow : poContent) {
/* 41 */       vsRow = "";
/* 42 */       for (String vsCell : voRow) {
/* 43 */         vsRow = vsRow + (vsRow.trim().equals("") ? "" : ",");
/* 44 */         vsRow = vsRow + "\"" + escapeDoubleQuotes(vsCell) + "\"";
/*    */       }
/* 46 */       voCSVContent.append(vsRow);
/* 47 */       voCSVContent.append("\n");
/*    */     }
/* 49 */     return voCSVContent.toString();
/*    */   }
/*    */   
/*    */   public static void write(OutputStream poFOS, List<List<String>> poContent) throws Exception {
/* 53 */     poFOS.write(getCSVString(poContent).getBytes());
/* 54 */     poFOS.flush();
/*    */   }
/*    */   
/*    */   public static void write(File poFile, List<List<String>> poContent) throws Exception {
/* 58 */     FileOutputStream voFOS = null;
/*    */     try
/*    */     {
/* 61 */       if (FileUtils.fncbVerificaDirectorio(poFile.getParent())) {
/* 62 */         voFOS = new FileOutputStream(poFile);
/* 63 */         write(voFOS, poContent);
/*    */       }
/*    */       return;
/* 66 */     } catch (Exception voEXC) { throw voEXC;
/*    */     } finally {
/*    */       try {
/* 69 */         voFOS.close();
/* 70 */         voFOS = null;
/*    */       } catch (Exception voIgnorar) {}
/*    */     }
/*    */   }
/*    */   
/*    */   public static void write(String psFilePath, String psFileName, List<List<String>> poContent) throws Exception {
/* 76 */     write(new File(psFilePath, psFileName), poContent);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\csv\CSVWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */