/*     */ package com.infomedia.utils.ss.csv;
/*     */ 
/*     */ import com.infomedia.utils.ss.SpreadSheetFileInterface;
/*     */ import com.infomedia.utils.ss.SpreadSheetInterface;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class csvFile
/*     */   implements SpreadSheetFileInterface
/*     */ {
/*  22 */   private String fileName = null;
/*  23 */   private BufferedReader br = null;
/*  24 */   private BufferedWriter bw = null;
/*  25 */   private SpreadSheetInterface csvSheet = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public csvFile(String psFileName)
/*     */   {
/*  35 */     this.fileName = psFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean openFile()
/*     */   {
/*     */     try
/*     */     {
/*  47 */       this.br = new BufferedReader(new FileReader(this.fileName));
/*  48 */       return true;
/*     */     } catch (Exception e) {}
/*  50 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean closeFile()
/*     */   {
/*  61 */     boolean _vbClose = true;
/*     */     try {
/*  63 */       this.br.close(); } catch (Exception e) { _vbClose = false; }
/*  64 */     this.csvSheet = null;
/*  65 */     System.gc();
/*     */     
/*  67 */     return _vbClose;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readFile()
/*     */   {
/*  77 */     List<String> rows = new ArrayList();
/*  78 */     String row = null;
/*     */     
/*     */     try
/*     */     {
/*  82 */       while ((row = this.br.readLine()) != null) {
/*  83 */         rows.add(row);
/*     */       }
/*  85 */       this.csvSheet = new csvSheet((String[])rows.toArray(new String[0]));
/*  86 */       return true;
/*     */     } catch (Exception e) {}
/*  88 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean saveFile()
/*     */   {
/*  99 */     vbSave = false;
/*     */     try {
/* 101 */       this.bw = new BufferedWriter(new FileWriter(this.fileName));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       return vbSave;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 103 */       vbSave = true;
/*     */     } finally {
/* 105 */       try { this.bw.close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfSheets()
/*     */   {
/* 117 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpreadSheetInterface getSheetAt(int sheetIndex)
/*     */   {
/* 128 */     return this.csvSheet;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\csv\csvFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */