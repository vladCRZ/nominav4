/*     */ package com.infomedia.utils.ss.csv;
/*     */ 
/*     */ import com.infomedia.utils.ss.SpreadSheetInterface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class csvSheet
/*     */   implements SpreadSheetInterface
/*     */ {
/*  19 */   private List<List<String>> rows = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public csvSheet(String[] rowArray)
/*     */   {
/*  29 */     Iterator<String> itr = Arrays.asList(rowArray).iterator();
/*  30 */     while (itr.hasNext()) {
/*  31 */       this.rows.add(csvUtils.separateCells((String)itr.next()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfRows()
/*     */   {
/*  41 */     return this.rows.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfCells(int row)
/*     */   {
/*  52 */     return ((List)this.rows.get(row)).size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCellAsString(int column, int row)
/*     */   {
/*  64 */     return (String)((List)this.rows.get(row)).get(column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getRow(int row, int length, int offset)
/*     */   {
/*  77 */     List<String> renglon = (List)this.rows.get(row);
/*  78 */     List<String> celdas = new ArrayList();
/*     */     
/*  80 */     for (int i = 0; i < renglon.size(); i++)
/*  81 */       celdas.add(renglon.get(i + offset));
/*  82 */     return celdas;
/*     */   }
/*     */   
/*  85 */   public List<String> getRow(int row, int length) { return getRow(row, length, 0); }
/*     */   
/*     */   public List<String> getRow(int row) {
/*  88 */     return getRow(row, getNumberOfCells(row), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getColumn(int column, int length, int offset)
/*     */   {
/* 102 */     List<String> cellArray = new ArrayList();
/*     */     
/* 104 */     for (int i = 0; (i < getNumberOfRows()) && (i < length); i++) {
/* 105 */       cellArray.add(getCellAsString(column, i + offset));
/*     */     }
/* 107 */     return cellArray;
/*     */   }
/*     */   
/* 110 */   public List<String> getColumn(int column, int length) { return getColumn(column, length, 0); }
/*     */   
/*     */   public List<String> getColumn(int column) {
/* 113 */     return getColumn(column, getNumberOfRows(), 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\csv\csvSheet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */