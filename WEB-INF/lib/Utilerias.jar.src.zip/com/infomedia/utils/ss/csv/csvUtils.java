/*     */ package com.infomedia.utils.ss.csv;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class csvUtils
/*     */ {
/*     */   public static final class csvCell
/*     */   {
/*  24 */     private boolean complete = false;
/*  25 */     private String textSeparator = "";
/*  26 */     private String valor = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void addValor(String psValor)
/*     */     {
/*  37 */       if ((psValor.equals(",")) && ((this.textSeparator.equals("")) || (this.valor.equals("")) || ((this.valor.startsWith(this.textSeparator)) && (this.valor.endsWith(this.textSeparator + ",")))))
/*     */       {
/*     */ 
/*     */ 
/*  41 */         this.complete = true;
/*     */       } else {
/*  43 */         this.valor += psValor;
/*  44 */         setTextSeparator();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getValor()
/*     */     {
/*  55 */       return this.valor.equals(",") ? "" : cleanValor(this.valor);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isComplete()
/*     */     {
/*  65 */       return this.complete;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void setTextSeparator()
/*     */     {
/*  74 */       if (this.valor.startsWith("'")) {
/*  75 */         this.textSeparator = "'";
/*  76 */       } else if (this.valor.startsWith("\"")) {
/*  77 */         this.textSeparator = "\"";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private String cleanScapeQuotes(String dirty)
/*     */     {
/*  88 */       if (dirty.indexOf("''") >= 0) {
/*  89 */         while (dirty.indexOf("''") >= 0)
/*  90 */           dirty = dirty.substring(0, dirty.indexOf("''")) + "'" + dirty.substring(dirty.indexOf("''") + 2);
/*     */       }
/*  92 */       return dirty;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private String cleanXlsDblQuotes(String dirty)
/*     */     {
/* 103 */       byte[] bytes = dirty.getBytes();
/* 104 */       for (int i = 0; i < bytes.length; i++)
/* 105 */         if ((bytes[i] == -109) || (bytes[i] == -108))
/* 106 */           bytes[i] = 34;
/* 107 */       return new String(bytes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private String cleanValor(String dirty)
/*     */     {
/* 119 */       if (!this.textSeparator.equals(""))
/* 120 */         dirty = dirty.substring(1, dirty.length() - 1);
/* 121 */       if (this.textSeparator.equals("'")) {
/* 122 */         dirty = cleanScapeQuotes(dirty);
/*     */       }
/* 124 */       return cleanXlsDblQuotes(dirty);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> separateCells(String rowString)
/*     */   {
/* 137 */     List<String> celdas = new ArrayList();
/* 138 */     StringTokenizer tokens = new StringTokenizer(rowString, ",", true);
/* 139 */     csvCell celda = new csvCell();
/*     */     
/* 141 */     while (tokens.hasMoreTokens()) {
/* 142 */       celda.addValor(tokens.nextToken());
/* 143 */       if ((celda.isComplete()) || (!tokens.hasMoreTokens())) {
/* 144 */         celdas.add(celda.getValor());
/* 145 */         celda = new csvCell();
/*     */       }
/*     */     }
/*     */     
/* 149 */     return celdas;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\csv\csvUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */