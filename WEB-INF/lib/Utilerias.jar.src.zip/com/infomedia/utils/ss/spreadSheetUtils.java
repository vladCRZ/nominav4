/*     */ package com.infomedia.utils.ss;
/*     */ 
/*     */ import com.infomedia.utils.ss.csv.csvSheet;
/*     */ import com.infomedia.utils.ss.xls.xlsSheet;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRichTextString;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class spreadSheetUtils
/*     */ {
/*     */   private static List<String> xls2CsvRowArray(SpreadSheetInterface ss)
/*     */   {
/*  34 */     List<String> rows = new ArrayList();
/*  35 */     Iterator<String> itr = null;
/*  36 */     String csvString = "";
/*     */     
/*  38 */     if (!(ss instanceof xlsSheet)) {
/*  39 */       return null;
/*     */     }
/*  41 */     for (int i = 0; i < ss.getNumberOfRows(); i++) {
/*  42 */       itr = ss.getRow(i).iterator();
/*  43 */       while (itr.hasNext()) csvString = csvString + "\"" + (String)itr.next() + "\",";
/*  44 */       rows.add(csvString);
/*     */     }
/*  46 */     return rows;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HSSFWorkbook csv2HSSFSheet(SpreadSheetInterface ss)
/*     */   {
/*  57 */     HSSFWorkbook book = new HSSFWorkbook();
/*  58 */     HSSFSheet sheet = book.createSheet();
/*     */     
/*  60 */     if (!(ss instanceof csvSheet)) {
/*  61 */       return null;
/*     */     }
/*  63 */     for (int i = 0; i < ss.getNumberOfRows(); i++) {
/*  64 */       HSSFRow row = sheet.createRow(i);
/*  65 */       for (int j = 0; j < ss.getNumberOfCells(i); j++) {
/*  66 */         HSSFCell cell = row.createCell(j, 1);
/*  67 */         cell.setCellValue(new HSSFRichTextString(ss.getCellAsString(j, i)));
/*     */       }
/*     */     }
/*     */     
/*  71 */     return book;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SpreadSheetInterface xls2csv(SpreadSheetInterface ss)
/*     */   {
/*  82 */     List<String> rows = xls2CsvRowArray(ss);
/*  83 */     return new csvSheet((String[])rows.toArray(new String[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SpreadSheetInterface csv2xls(SpreadSheetInterface ss)
/*     */   {
/*  94 */     return new xlsSheet(csv2HSSFSheet(ss).getSheetAt(0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean saveCsvAsXlsFile(String fileName, SpreadSheetInterface ss)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       FileOutputStream csvFile = new FileOutputStream(fileName);
/* 108 */       HSSFWorkbook book = csv2HSSFSheet(ss);
/* 109 */       book.write(csvFile);
/* 110 */       csvFile.flush();
/* 111 */       csvFile.close();
/* 112 */       return true;
/*     */     } catch (Exception e) {}
/* 114 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean saveXlsAsCsvFile(String fileName, SpreadSheetInterface ss)
/*     */   {
/* 127 */     Iterator<String> itrRows = xls2CsvRowArray(ss).iterator();
/* 128 */     String csvString = "";
/*     */     
/* 130 */     while (itrRows.hasNext()) csvString = csvString + (String)itrRows.next() + "\n";
/*     */     try {
/* 132 */       FileOutputStream csvFile = new FileOutputStream(fileName);
/* 133 */       csvFile.write(csvString.getBytes());
/* 134 */       csvFile.flush();
/* 135 */       csvFile.close();
/* 136 */       return true;
/*     */     } catch (Exception e) {}
/* 138 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\spreadSheetUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */