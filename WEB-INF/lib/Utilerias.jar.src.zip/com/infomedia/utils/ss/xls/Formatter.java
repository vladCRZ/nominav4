/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.DateUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Formatter
/*     */ {
/*  24 */   private Format goFormatter = null;
/*     */   
/*     */   public static class XLSDate {
/*  27 */     public static double minutes2Seconds(double vdMinutes) { return vdMinutes * 60.0D; }
/*  28 */     public static double hours2Seconds(double vdHours) { return minutes2Seconds(hours2Minutes(vdHours)); }
/*  29 */     public static double hours2Minutes(double vdHours) { return vdHours * 60.0D; }
/*  30 */     public static double days2Seconds(double vdDays) { return minutes2Seconds(days2Minutes(vdDays)); }
/*  31 */     public static double days2Minutes(double vdDays) { return hours2Minutes(days2Hours(vdDays)); }
/*  32 */     public static double days2Hours(double vdDays) { return vdDays * 24.0D; }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class AccumulativeTimeFormat
/*     */   {
/*     */     public static final String REGEX_HOURS = "[h]+";
/*     */     
/*     */     public static final String REGEX_MINUTES = "[m]+";
/*     */     public static final String REGEX_SECONDS = "[s]+";
/*     */     public static final String MATCHER_HOURS = ".*\\[[h]+\\].*";
/*     */     public static final String MATCHER_MINUTES = ".*\\[[m]+\\].*";
/*     */     public static final String MATCHER_SECONDS = ".*\\[[s]+\\].*";
/*     */     public static final String MATCHER_ACCUMULATIVE = "(.*\\[[h]+\\].*)|(.*\\[[m]+\\].*)|(.*\\[[s]+\\].*)";
/*     */     
/*  47 */     public static boolean isAccumulativeFormat(String vsFormat) { return StringUtils.fncbMatches("(.*\\[[h]+\\].*)|(.*\\[[m]+\\].*)|(.*\\[[s]+\\].*)", vsFormat); }
/*  48 */     public static boolean accumulateHours(String vsFormat) { return StringUtils.fncbMatches(".*\\[[h]+\\].*", vsFormat); }
/*  49 */     public static boolean accumulateMinutes(String vsFormat) { return StringUtils.fncbMatches(".*\\[[m]+\\].*", vsFormat); }
/*  50 */     public static boolean accumulateSeconds(String vsFormat) { return StringUtils.fncbMatches(".*\\[[s]+\\].*", vsFormat); }
/*  51 */     public static boolean hasHours(String vsFormat) { return StringUtils.fncbFind("[h]+", vsFormat); }
/*  52 */     public static boolean hasMinutes(String vsFormat) { return StringUtils.fncbFind("[m]+", vsFormat); }
/*  53 */     public static boolean hasSeconds(String vsFormat) { return StringUtils.fncbFind("[s]+", vsFormat); }
/*     */     
/*  55 */     public static String format(String psFormat, String psValue) { String vsRetorno = isAccumulativeFormat(psFormat) ? psFormat : psValue;
/*  56 */       double vdDate = Double.parseDouble(psValue);
/*  57 */       double vdHours = Formatter.XLSDate.days2Hours(vdDate);
/*  58 */       double vdMinutes = Formatter.XLSDate.hours2Minutes(vdHours % 1.0D);
/*  59 */       double vdSeconds = Formatter.XLSDate.minutes2Seconds(vdMinutes % 1.0D);
/*     */       
/*  61 */       if (accumulateHours(psFormat)) vsRetorno = vsRetorno.replaceAll("\\[[h]+\\]", String.valueOf((int)vdHours)); else
/*  62 */         vdMinutes += vdHours * 60.0D;
/*  63 */       if (accumulateMinutes(psFormat)) { vsRetorno = vsRetorno.replaceAll("\\[[m]+\\]", String.valueOf((int)vdMinutes));
/*  64 */       } else if (hasMinutes(psFormat)) vsRetorno = vsRetorno.replaceAll("[m]+", String.valueOf((int)vdMinutes)); else
/*  65 */         vdSeconds += vdMinutes * 60.0D;
/*  66 */       if (accumulateSeconds(psFormat)) { vsRetorno = vsRetorno.replaceAll("\\[[s]+\\]", String.valueOf((int)vdSeconds));
/*  67 */       } else if (hasSeconds(psFormat)) { vsRetorno = vsRetorno.replaceAll("[s]+", String.valueOf((int)vdSeconds));
/*     */       }
/*  69 */       return vsRetorno;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar toJavaCalendar(String psValue)
/*     */   {
/*  82 */     Calendar voFecha = DateUtils.getZeroCalendar();
/*     */     
/*     */     try
/*     */     {
/*  86 */       if (StringUtils.isNVL(psValue)) { throw new NullPointerException("Can't parse a null value");
/*     */       }
/*  88 */       int viDate = (int)Double.parseDouble(psValue);
/*  89 */       int viTime = (int)((Double.parseDouble(psValue) - viDate) * 8.64E7D);
/*     */       
/*  91 */       voFecha.set(1, 1900);
/*  92 */       voFecha.set(14, viTime);
/*  93 */       voFecha.add(6, viDate);
/*     */     } catch (Exception e) {
/*  95 */       voFecha = null;
/*     */     }
/*  97 */     return voFecha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar toJavaTime(String psValue)
/*     */   {
/* 111 */     Calendar voFecha = DateUtils.getZeroCalendar();
/*     */     
/*     */     try
/*     */     {
/* 115 */       if (StringUtils.isNVL(psValue)) { throw new NullPointerException("Can't parse a null value");
/*     */       }
/* 117 */       int viDate = (int)Double.parseDouble(psValue);
/* 118 */       int viTime = (int)((Double.parseDouble(psValue) - viDate) * 8.64E7D);
/* 119 */       voFecha.set(1, 1900);
/* 120 */       voFecha.set(14, viTime);
/* 121 */       voFecha.add(6, viDate);
/*     */     } catch (Exception e) {
/* 123 */       voFecha = null;
/*     */     }
/* 125 */     return voFecha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class AnotherFormat
/*     */     extends Format
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */ 
/*     */ 
/* 138 */     private String gsFormat = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AnotherFormat(String psFormat)
/*     */     {
/* 148 */       this.gsFormat = psFormat;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String format(String value)
/*     */     {
/* 160 */       DecimalFormat goDecimalFormat = new DecimalFormat("##########");
/* 161 */       goDecimalFormat.setParseIntegerOnly(true);
/* 162 */       String sNumber = goDecimalFormat.format(Double.parseDouble(value));
/* 163 */       String result = "";
/*     */       
/*     */ 
/*     */ 
/* 167 */       int formatPos = this.gsFormat.length() - 1; for (int numberPos = sNumber.length() - 1; formatPos >= 0; formatPos--) {
/* 168 */         String SFormat = this.gsFormat.substring(formatPos, formatPos + 1);
/* 169 */         String SNumber = numberPos >= 0 ? sNumber.substring(numberPos, numberPos + 1) : "";
/*     */         
/*     */         String SResult;
/* 172 */         if (SFormat.equals("0")) {
/* 173 */           String SResult = numberPos >= 0 ? SNumber : "0";
/* 174 */           numberPos--;
/* 175 */         } else if (SFormat.equals("#")) {
/* 176 */           String SResult = numberPos >= 0 ? SNumber : "";
/* 177 */           numberPos--;
/*     */         }
/*     */         else {
/* 180 */           if (SFormat.equals("\\"))
/* 181 */             SFormat.substring(numberPos--, numberPos + 1);
/* 182 */           SResult = SFormat;
/*     */         }
/*     */         
/* 185 */         result = SResult + result;
/*     */       }
/*     */       
/* 188 */       return result;
/*     */     }
/*     */     
/*     */     public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
/* 192 */       toAppendTo.append(format((String)obj));
/* 193 */       return toAppendTo;
/*     */     }
/*     */     
/*     */     public Object parseObject(String source, ParsePosition pos) {
/* 197 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Formatter(String format)
/*     */   {
/* 210 */     String xlsFormat = cleanFormat(format);
/* 211 */     if (canSetToDateFormat(xlsFormat)) return;
/* 212 */     if (canSetToNumericFormat(xlsFormat)) return;
/* 213 */     if (canSetToAnotherFormat(xlsFormat)) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String format(String value)
/*     */   {
/* 224 */     if (value.trim().equals("NaN")) return "";
/* 225 */     if ((isDateFormat()) || (isNumericFormat()) || (isAnotherFormat()))
/*     */     {
/* 227 */       return this.goFormatter.format(value);
/*     */     }
/* 229 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String cleanFormat(String format)
/*     */   {
/* 241 */     return format.replaceAll("\" ", " '").replaceAll(" \"", "' ").replaceAll("Y", "y").replaceAll("D", "d").replaceAll("\\[H\\]", "H").replaceAll("\\[HH\\]", "HH").replaceAll("H", "h").replaceAll("HH", "hh").replaceAll(":MM", ":mm").replaceAll(":SS", ":ss").replaceAll(";@", "").replaceAll("\\[\\S+\\]", "").replaceAll("\\\\,", ",").replaceAll("\\\\ ", " ").replaceAll("\\\\-", "-");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isDateFormat()
/*     */   {
/* 265 */     return this.goFormatter instanceof SimpleDateFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isNumericFormat()
/*     */   {
/* 274 */     return this.goFormatter instanceof NumberFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isAnotherFormat()
/*     */   {
/* 283 */     return this.goFormatter instanceof AnotherFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canSetToDateFormat(String xlsFormat)
/*     */   {
/*     */     try
/*     */     {
/* 295 */       this.goFormatter = new SimpleDateFormat(xlsFormat);
/* 296 */       if (format("1").equals(xlsFormat)) throw new Exception("");
/* 297 */       return true;
/*     */     } catch (Exception e) {
/* 299 */       this.goFormatter = null; }
/* 300 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canSetToNumericFormat(String xlsFormat)
/*     */   {
/*     */     try
/*     */     {
/* 314 */       this.goFormatter = new DecimalFormat(xlsFormat);
/* 315 */       Double.parseDouble(format("1"));
/* 316 */       return true;
/*     */     } catch (Exception e) {
/* 318 */       this.goFormatter = null; }
/* 319 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canSetToAnotherFormat(String xlsFormat)
/*     */   {
/* 331 */     this.goFormatter = new AnotherFormat(xlsFormat);
/* 332 */     return true;
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFormat, String psValue) {
/* 336 */     Formatter voFormatter = new Formatter(psFormat);
/* 337 */     return StringUtils.isNVL(psValue) ? "" : voFormatter.format(psValue);
/*     */   }
/*     */   
/*     */   public static void main(String[] psParametros) {
/* 341 */     Calendar voFecha = toJavaCalendar("40807.0");
/* 342 */     System.out.println(DateUtils.fncsFormat("dd/MM/yyyy", voFecha, DateUtils.REGIONAL_MEXICO, TimeZone.getTimeZone("GMT+0")));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\Formatter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */