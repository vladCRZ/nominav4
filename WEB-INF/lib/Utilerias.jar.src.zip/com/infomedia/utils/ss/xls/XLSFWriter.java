/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*     */ import org.apache.poi.hssf.usermodel.HSSFPalette;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.hssf.util.HSSFColor;
/*     */ import org.apache.poi.ss.usermodel.CellStyle;
/*     */ import org.apache.poi.ss.usermodel.ClientAnchor;
/*     */ import org.apache.poi.ss.usermodel.CreationHelper;
/*     */ import org.apache.poi.ss.usermodel.Drawing;
/*     */ import org.apache.poi.ss.usermodel.Font;
/*     */ import org.apache.poi.ss.usermodel.Picture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XLSFWriter
/*     */ {
/*  42 */   public static int BORDER_BOTTOM = 1;
/*  43 */   public static int BORDER_TOP = 2;
/*  44 */   public static int BORDER_LEFT = 4;
/*  45 */   public static int BORDER_RIGHT = 8;
/*  46 */   public static int BORDER_ALL = 16;
/*     */   
/*  48 */   public static enum ALIGN { CENTER,  LEFT,  RIGHT;
/*  49 */     private ALIGN() {} } public static enum IMG { JPG,  PNG;
/*     */     private IMG() {} }
/*  51 */   private HSSFWorkbook goWorkbook = null;
/*     */   
/*  53 */   private Map<String, CellStyle> goStyles = new HashMap();
/*  54 */   private Map<String, HSSFColor> goColors = new HashMap();
/*  55 */   private HSSFSheet goSheet = null;
/*     */   
/*     */   public XLSFWriter() {
/*  58 */     this.goWorkbook = new HSSFWorkbook();
/*  59 */     this.goSheet = this.goWorkbook.createSheet();
/*     */   }
/*     */   
/*     */   private short decodeAlign(ALIGN poAlign) {
/*  63 */     switch (poAlign) {
/*  64 */     case CENTER:  return 2;
/*  65 */     case LEFT:  return 1;
/*  66 */     case RIGHT:  return 3; }
/*  67 */     return 2;
/*     */   }
/*     */   
/*     */   private HSSFColor decodeColor(String psColor)
/*     */   {
/*  72 */     HSSFPalette voPalette = this.goWorkbook.getCustomPalette();
/*  73 */     Color voRGBColor = new Color(Integer.parseInt(psColor, 16));
/*  74 */     HSSFColor voOverColor = voPalette.findSimilarColor((byte)voRGBColor.getRed(), (byte)voRGBColor.getGreen(), (byte)voRGBColor.getBlue());
/*  75 */     HSSFColor voColor = voPalette.findColor((byte)voRGBColor.getRed(), (byte)voRGBColor.getGreen(), (byte)voRGBColor.getBlue());
/*  76 */     if (voColor == null) {
/*  77 */       voPalette.setColorAtIndex(voOverColor.getIndex(), (byte)voRGBColor.getRed(), (byte)voRGBColor.getGreen(), (byte)voRGBColor.getBlue());
/*  78 */       voColor = voPalette.getColor(voOverColor.getIndex());
/*     */     }
/*  80 */     return voColor;
/*     */   }
/*     */   
/*     */   public void registerColor(String psID, String psColor) {
/*  84 */     this.goColors.put(psID, decodeColor(psColor));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerStyle(String psID, String psFont, String psColorID, String psFontColorID, String psBorderColorID, boolean bold, boolean italic, int piBorder, ALIGN pbAlign)
/*     */   {
/*  96 */     CellStyle voStyle = this.goWorkbook.createCellStyle();
/*  97 */     Font voFont = this.goWorkbook.createFont();
/*     */     
/*  99 */     voFont.setFontName(psFont);
/* 100 */     voFont.setBoldweight((short)(bold ? 700 : 400));
/* 101 */     voFont.setItalic(italic);
/* 102 */     if (this.goColors.containsKey(psFontColorID)) {
/* 103 */       voFont.setColor(((HSSFColor)this.goColors.get(psFontColorID)).getIndex());
/*     */     }
/*     */     
/* 106 */     if (((piBorder & BORDER_BOTTOM) > 0) || ((piBorder & BORDER_ALL) > 0)) {
/* 107 */       voStyle.setBorderBottom((short)2);
/* 108 */       if ((!StringUtils.isNVL(psBorderColorID)) && (this.goColors.containsKey(psBorderColorID))) voStyle.setBottomBorderColor(((HSSFColor)this.goColors.get(psBorderColorID)).getIndex());
/*     */     }
/* 110 */     if (((piBorder & BORDER_TOP) > 0) || ((piBorder & BORDER_ALL) > 0)) {
/* 111 */       voStyle.setBorderTop((short)2);
/* 112 */       if ((!StringUtils.isNVL(psBorderColorID)) && (this.goColors.containsKey(psBorderColorID))) voStyle.setTopBorderColor(((HSSFColor)this.goColors.get(psBorderColorID)).getIndex());
/*     */     }
/* 114 */     if (((piBorder & BORDER_LEFT) > 0) || ((piBorder & BORDER_ALL) > 0)) {
/* 115 */       voStyle.setBorderLeft((short)2);
/* 116 */       if ((!StringUtils.isNVL(psBorderColorID)) && (this.goColors.containsKey(psBorderColorID))) voStyle.setLeftBorderColor(((HSSFColor)this.goColors.get(psBorderColorID)).getIndex());
/*     */     }
/* 118 */     if (((piBorder & BORDER_RIGHT) > 0) || ((piBorder & BORDER_ALL) > 0)) {
/* 119 */       voStyle.setBorderRight((short)2);
/* 120 */       if ((!StringUtils.isNVL(psBorderColorID)) && (this.goColors.containsKey(psBorderColorID))) { voStyle.setRightBorderColor(((HSSFColor)this.goColors.get(psBorderColorID)).getIndex());
/*     */       }
/*     */     }
/* 123 */     voStyle.setAlignment(decodeAlign(pbAlign));
/* 124 */     voStyle.setFont(voFont);
/* 125 */     if (this.goColors.containsKey(psColorID)) {
/* 126 */       voStyle.setFillBackgroundColor(((HSSFColor)this.goColors.get(psColorID)).getIndex());
/* 127 */       voStyle.setFillForegroundColor(((HSSFColor)this.goColors.get(psColorID)).getIndex());
/* 128 */       voStyle.setFillPattern((short)1);
/*     */     }
/* 130 */     voStyle.setWrapText(false);
/* 131 */     this.goStyles.put(psID, voStyle);
/*     */   }
/*     */   
/*     */   public void addRow(int piIndex, String psStyle) {
/* 135 */     HSSFRow row = this.goSheet.createRow(piIndex);
/* 136 */     if ((!StringUtils.isNVL(psStyle)) && (this.goStyles.containsKey(psStyle))) row.setRowStyle((HSSFCellStyle)this.goStyles.get(psStyle));
/*     */   }
/*     */   
/*     */   public void addRow(int piIndex) {
/* 140 */     this.goSheet.createRow(piIndex);
/*     */   }
/*     */   
/*     */   public HSSFCell newCell(int piRowIndex, int piColIndex) {
/* 144 */     if (this.goSheet.getRow(piRowIndex) == null) addRow(piRowIndex);
/* 145 */     return this.goSheet.getRow(piRowIndex).createCell(piColIndex, 1);
/*     */   }
/*     */   
/*     */   public void addTextCell(int piRowIndex, int piColumnIndex, String psValue, String psStyle) {
/* 149 */     HSSFCell voNewCell = newCell(piRowIndex, piColumnIndex);
/* 150 */     voNewCell.setCellValue(psValue);
/* 151 */     if ((!StringUtils.isNVL(psStyle)) && (this.goStyles.containsKey(psStyle))) voNewCell.setCellStyle((CellStyle)this.goStyles.get(psStyle));
/* 152 */     this.goSheet.autoSizeColumn(piColumnIndex);
/*     */   }
/*     */   
/*     */   public void addDateCell(int piRowIndex, int piColumnIndex, Date poValue, String psStyle) {
/* 156 */     HSSFCell voNewCell = newCell(piRowIndex, piColumnIndex);
/* 157 */     voNewCell.setCellValue(poValue);
/* 158 */     if ((!StringUtils.isNVL(psStyle)) && (this.goStyles.containsKey(psStyle))) voNewCell.setCellStyle((CellStyle)this.goStyles.get(psStyle));
/*     */   }
/*     */   
/*     */   public void addCalendarCell(int piRowIndex, int piColumnIndex, Calendar poValue, String psStyle) {
/* 162 */     HSSFCell voNewCell = newCell(piRowIndex, piColumnIndex);
/* 163 */     voNewCell.setCellValue(poValue);
/* 164 */     if ((!StringUtils.isNVL(psStyle)) && (this.goStyles.containsKey(psStyle))) voNewCell.setCellStyle((CellStyle)this.goStyles.get(psStyle));
/*     */   }
/*     */   
/*     */   public void addDoubleCell(int piRowIndex, int piColumnIndex, double poValue, String psStyle) {
/* 168 */     HSSFCell voNewCell = newCell(piRowIndex, piColumnIndex);
/* 169 */     voNewCell.setCellValue(poValue);
/* 170 */     if ((!StringUtils.isNVL(psStyle)) && (this.goStyles.containsKey(psStyle))) voNewCell.setCellStyle((CellStyle)this.goStyles.get(psStyle));
/*     */   }
/*     */   
/*     */   public void addImageCell(int piRowIndex, int piColumnIndex, byte[] poImage, int piFormat) {
/* 174 */     CreationHelper voHelper = this.goWorkbook.getCreationHelper();
/* 175 */     Drawing voDrawing = this.goSheet.createDrawingPatriarch();
/* 176 */     ClientAnchor voAnchor = voHelper.createClientAnchor();
/* 177 */     Picture voPicture = null;
/*     */     
/* 179 */     int voImageIndex = this.goWorkbook.addPicture(poImage, piFormat);
/*     */     
/* 181 */     voAnchor.setCol1(piColumnIndex);
/* 182 */     voAnchor.setRow1(piRowIndex);
/*     */     
/* 184 */     voPicture = voDrawing.createPicture(voAnchor, voImageIndex);
/* 185 */     voPicture.resize();
/*     */   }
/*     */   
/* 188 */   public void addImageCell(int piRowIndex, int piColumnIndex, InputStream poImageInput, int piFormat) throws IOException { addImageCell(piRowIndex, piColumnIndex, IOUtils.toByteArray(poImageInput), piFormat); }
/*     */   
/*     */   public void addJPG(int piRowIndex, int piColumnIndex, InputStream poImageInput) throws IOException {
/* 191 */     addImageCell(piRowIndex, piColumnIndex, poImageInput, 5);
/*     */   }
/*     */   
/* 194 */   public void addJPG(int piRowIndex, int piColumnIndex, byte[] poImage) { addImageCell(piRowIndex, piColumnIndex, poImage, 5); }
/*     */   
/*     */   public void addPNG(int piRowIndex, int piColumnIndex, InputStream poImageInput) throws IOException
/*     */   {
/* 198 */     addImageCell(piRowIndex, piColumnIndex, poImageInput, 6);
/*     */   }
/*     */   
/* 201 */   public void addPNG(int piRowIndex, int piColumnIndex, byte[] poImage) { addImageCell(piRowIndex, piColumnIndex, poImage, 6); }
/*     */   
/*     */   public void write(OutputStream poOutput) throws IOException
/*     */   {
/* 205 */     this.goWorkbook.write(poOutput);
/*     */   }
/*     */   
/*     */   public byte[] getBytes() {
/* 209 */     return this.goWorkbook.getBytes();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\XLSFWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */