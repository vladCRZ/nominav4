/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.ss.Cell;
/*     */ import com.infomedia.utils.ss.CellPosition;
/*     */ import com.infomedia.utils.ss.SpreadSheet;
/*     */ import com.infomedia.utils.ss.SpreadSheetParser;
/*     */ import com.infomedia.utils.ss.WorkBook;
/*     */ import java.io.InputStream;
/*     */ import org.apache.poi.openxml4j.opc.OPCPackage;
/*     */ import org.apache.poi.openxml4j.opc.PackageAccess;
/*     */ import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
/*     */ import org.apache.poi.xssf.eventusermodel.XSSFReader;
/*     */ import org.apache.poi.xssf.eventusermodel.XSSFReader.SheetIterator;
/*     */ import org.apache.poi.xssf.extractor.XSSFEventBasedExcelExtractor;
/*     */ import org.apache.poi.xssf.model.StylesTable;
/*     */ 
/*     */ public class XLSLParser
/*     */   implements SpreadSheetParser
/*     */ {
/*     */   public static final String EXT = ".xlsx";
/*  21 */   private static XLSLParser INSTANCE = new XLSLParser();
/*     */   public static final String FILE_WORKBOOK = "Workbook";
/*     */   
/*  24 */   public static XLSLParser getInstance() { return INSTANCE; }
/*  25 */   public static boolean isXLSFile(String psFileName) { return psFileName.toLowerCase().endsWith(".xlsx"); }
/*     */   
/*     */ 
/*     */ 
/*     */   private SpreadSheet parseSpreadSheet(String psSSName, int piRowIndex, String psSSContent)
/*     */   {
/*  31 */     SpreadSheet voSS = new SpreadSheet(psSSName);
/*  32 */     String[] voRows = psSSContent.split("\n");
/*  33 */     String[] voCells = null;
/*  34 */     int viColIndex = 0;
/*     */     
/*  36 */     for (String vsRowContent : voRows) {
/*  37 */       voCells = vsRowContent.split("\t");
/*  38 */       for (String vsCellContent : voCells) {
/*  39 */         voSS.setCell(new CellPosition(viColIndex++, piRowIndex), new Cell(vsCellContent));
/*     */       }
/*     */     }
/*     */     
/*  43 */     return voSS;
/*     */   }
/*     */   
/*     */   public synchronized WorkBook parse(String psXLSLFileName) {
/*  47 */     OPCPackage voXLSXPackage = null;
/*  48 */     ReadOnlySharedStringsTable voStringsTable = null;
/*  49 */     XSSFReader.SheetIterator voSheets = null;
/*  50 */     StylesTable voStylesTable = null;
/*  51 */     StringBuffer voSheetTextContent = null;
/*  52 */     XSSFEventBasedExcelExtractor voTextExtractor = null;
/*  53 */     XSSFReader voXSSFFReader = null;
/*  54 */     InputStream voInput = null;
/*     */     
/*  56 */     WorkBook voWorkBook = new WorkBook();
/*  57 */     int viRowIndex = 0;
/*     */     try
/*     */     {
/*  60 */       voXLSXPackage = OPCPackage.open(psXLSLFileName, PackageAccess.READ);
/*  61 */       voTextExtractor = new XSSFEventBasedExcelExtractor(voXLSXPackage);
/*  62 */       voStringsTable = new ReadOnlySharedStringsTable(voXLSXPackage);
/*  63 */       voXSSFFReader = new XSSFReader(voXLSXPackage);
/*  64 */       voStylesTable = voXSSFFReader.getStylesTable();
/*  65 */       voSheets = (XSSFReader.SheetIterator)voXSSFFReader.getSheetsData();
/*  66 */       while (voSheets.hasNext()) {
/*  67 */         voInput = voSheets.next();
/*  68 */         voSheetTextContent = new StringBuffer();
/*  69 */         voTextExtractor.processSheet(voSheetTextContent, voStylesTable, voStringsTable, voInput);
/*  70 */         voWorkBook.addSpreadSheet(parseSpreadSheet(voSheets.getSheetName(), viRowIndex++, voSheetTextContent.toString()));
/*     */       }
/*     */     } catch (Exception voEXC) {
/*  73 */       voEXC.printStackTrace();
/*     */     }
/*     */     
/*  76 */     return voWorkBook;
/*     */   }
/*     */   
/*     */   public synchronized WorkBook parse(InputStream poInputStream) {
/*  80 */     OPCPackage voXLSXPackage = null;
/*  81 */     ReadOnlySharedStringsTable voStringsTable = null;
/*  82 */     XSSFReader.SheetIterator voSheets = null;
/*  83 */     StylesTable voStylesTable = null;
/*  84 */     StringBuffer voSheetTextContent = null;
/*  85 */     XSSFEventBasedExcelExtractor voTextExtractor = null;
/*  86 */     XSSFReader voXSSFFReader = null;
/*  87 */     InputStream voInput = null;
/*     */     
/*  89 */     WorkBook voWorkBook = new WorkBook();
/*  90 */     int viRowIndex = 0;
/*     */     try
/*     */     {
/*  93 */       voXLSXPackage = OPCPackage.open(poInputStream);
/*  94 */       voTextExtractor = new XSSFEventBasedExcelExtractor(voXLSXPackage);
/*  95 */       voStringsTable = new ReadOnlySharedStringsTable(voXLSXPackage);
/*  96 */       voXSSFFReader = new XSSFReader(voXLSXPackage);
/*  97 */       voStylesTable = voXSSFFReader.getStylesTable();
/*  98 */       voSheets = (XSSFReader.SheetIterator)voXSSFFReader.getSheetsData();
/*  99 */       while (voSheets.hasNext()) {
/* 100 */         voInput = voSheets.next();
/* 101 */         voSheetTextContent = new StringBuffer();
/* 102 */         voTextExtractor.processSheet(voSheetTextContent, voStylesTable, voStringsTable, voInput);
/* 103 */         voWorkBook.addSpreadSheet(parseSpreadSheet(voSheets.getSheetName(), viRowIndex++, voSheetTextContent.toString()));
/*     */       }
/*     */     } catch (Exception voEXC) {
/* 106 */       voEXC.printStackTrace();
/*     */     }
/*     */     
/* 109 */     return voWorkBook;
/*     */   }
/*     */   
/*     */   public static void main(String[] psParametros) {
/* 113 */     getInstance().parse("C:\\Users\\Rolando\\Documents\\Rolando\\Virtual NTFS Partition @ 15770583040\\Users\\infomedia\\Documents\\Backup\\Documentos\\Paleta de Colores.XLSX");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\XLSLParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */