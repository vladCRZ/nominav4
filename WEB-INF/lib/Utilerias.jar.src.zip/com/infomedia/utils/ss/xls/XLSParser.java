/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.ss.Cell;
/*     */ import com.infomedia.utils.ss.CellPosition;
/*     */ import com.infomedia.utils.ss.SpreadSheet;
/*     */ import com.infomedia.utils.ss.WorkBook;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import org.apache.poi.hssf.eventusermodel.FormatTrackingHSSFListener;
/*     */ import org.apache.poi.hssf.eventusermodel.HSSFEventFactory;
/*     */ import org.apache.poi.hssf.eventusermodel.HSSFRequest;
/*     */ import org.apache.poi.hssf.record.BOFRecord;
/*     */ import org.apache.poi.hssf.record.BoundSheetRecord;
/*     */ import org.apache.poi.hssf.record.DateWindow1904Record;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.LabelRecord;
/*     */ import org.apache.poi.hssf.record.LabelSSTRecord;
/*     */ import org.apache.poi.hssf.record.NumberRecord;
/*     */ import org.apache.poi.hssf.record.RKRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.SSTRecord;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ 
/*     */ public class XLSParser implements org.apache.poi.hssf.eventusermodel.HSSFListener, com.infomedia.utils.ss.SpreadSheetParser
/*     */ {
/*     */   public static final String EXT = ".xls";
/*  27 */   private static XLSParser INSTANCE = new XLSParser();
/*     */   
/*     */   public static final String FILE_WORKBOOK = "Workbook";
/*  30 */   private HSSFRequest goRequest = null;
/*  31 */   private FormatTrackingHSSFListener goListener = null;
/*     */   
/*  33 */   private SSTRecord goSSTRecord = null;
/*     */   
/*  35 */   private java.util.List<String> goSheetNames = null;
/*  36 */   private WorkBook goWorkbook = null;
/*  37 */   private SpreadSheet goCurrentSheet = null;
/*     */   
/*  39 */   private int giSheetIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static XLSParser getInstance()
/*     */   {
/*  48 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isXLSFile(String psFileName)
/*     */   {
/*  60 */     return psFileName.toLowerCase().endsWith(".xls");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XLSParser()
/*     */   {
/*  71 */     this.goRequest = new HSSFRequest();
/*  72 */     this.goListener = new FormatTrackingHSSFListener(this);
/*  73 */     prcAddListeners();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcAddListeners()
/*     */   {
/*  85 */     this.goRequest.addListener(this.goListener, (short)2057);
/*  86 */     this.goRequest.addListener(this.goListener, (short)10);
/*  87 */     this.goRequest.addListener(this.goListener, (short)34);
/*  88 */     this.goRequest.addListener(this.goListener, (short)140);
/*  89 */     this.goRequest.addListener(this.goListener, (short)133);
/*  90 */     this.goRequest.addListener(this.goListener, (short)252);
/*  91 */     this.goRequest.addListener(this.goListener, (short)6);
/*  92 */     this.goRequest.addListener(this.goListener, (short)516);
/*  93 */     this.goRequest.addListener(this.goListener, (short)253);
/*  94 */     this.goRequest.addListener(this.goListener, (short)515);
/*  95 */     this.goRequest.addListener(this.goListener, (short)638);
/*  96 */     this.goRequest.addListener(this.goListener, (short)440);
/*  97 */     this.goRequest.addListener(this.goListener, (short)438);
/*  98 */     this.goRequest.addListener(this.goListener, (short)1054);
/*  99 */     this.goRequest.addListener(this.goListener, (short)224);
/* 100 */     this.goRequest.addListener(this.goListener, (short)34);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prcFinalize()
/*     */   {
/* 112 */     this.goSSTRecord = null;
/* 113 */     this.goSheetNames = null;
/* 114 */     this.goCurrentSheet = null;
/* 115 */     this.giSheetIndex = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized WorkBook parse(String psXLSFileName)
/*     */   {
/* 130 */     HSSFEventFactory voEventFactory = null;
/* 131 */     FileInputStream voFileInput = null;
/* 132 */     POIFSFileSystem voFile = null;
/* 133 */     InputStream voInput = null;
/*     */     try
/*     */     {
/* 136 */       this.goWorkbook = null;
/* 137 */       voFileInput = new FileInputStream(psXLSFileName);
/* 138 */       voFile = new POIFSFileSystem(voFileInput);
/* 139 */       voInput = voFile.createDocumentInputStream("Workbook");
/* 140 */       voEventFactory = new HSSFEventFactory();
/* 141 */       voEventFactory.processEvents(this.goRequest, voInput);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */       return this.goWorkbook;
/*     */     }
/*     */     catch (Exception poEXC)
/*     */     {
/* 143 */       poEXC.printStackTrace();
/*     */     } finally {
/* 145 */       prcFinalize();
/* 146 */       if (voFileInput != null) try { voFileInput.close(); } catch (Exception voIgnorar) {}
/* 147 */       if (voInput != null) try { voInput.close();
/*     */         } catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized WorkBook parse(InputStream poInputStream) {
/* 153 */     HSSFEventFactory voEventFactory = null;
/* 154 */     FileInputStream voFileInput = null;
/* 155 */     POIFSFileSystem voFile = null;
/* 156 */     InputStream voInput = null;
/*     */     try
/*     */     {
/* 159 */       this.goWorkbook = null;
/* 160 */       voFile = new POIFSFileSystem(poInputStream);
/* 161 */       voInput = voFile.createDocumentInputStream("Workbook");
/* 162 */       voEventFactory = new HSSFEventFactory();
/* 163 */       voEventFactory.processEvents(this.goRequest, voInput);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */       return this.goWorkbook;
/*     */     }
/*     */     catch (Exception poEXC)
/*     */     {
/* 165 */       poEXC.printStackTrace();
/*     */     } finally {
/* 167 */       prcFinalize();
/* 168 */       if (voFileInput != null) { try { voFileInput.close();
/*     */         }
/*     */         catch (Exception voIgnorar) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processRecord(Record poRecord)
/*     */   {
/* 184 */     switch (poRecord.getSid()) {
/*     */     case 2057: 
/* 186 */       BOFRecord bof = (BOFRecord)poRecord;
/* 187 */       if (bof.getType() == 5) {
/* 188 */         this.goSheetNames = new java.util.ArrayList();
/* 189 */         this.goWorkbook = new WorkBook();
/* 190 */       } else if (bof.getType() == 16) {
/* 191 */         this.giSheetIndex += 1;
/* 192 */         this.goCurrentSheet = new SpreadSheet((String)this.goSheetNames.get(this.giSheetIndex));
/*     */       }
/*     */       
/*     */       break;
/*     */     case 10: 
/* 197 */       if (this.goCurrentSheet != null) { this.goWorkbook.addSpreadSheet(this.goCurrentSheet);
/*     */       }
/*     */       break;
/*     */     case 133: 
/* 201 */       BoundSheetRecord boundSheetRecord = (BoundSheetRecord)poRecord;
/* 202 */       this.goSheetNames.add(boundSheetRecord.getSheetname());
/* 203 */       break;
/*     */     
/*     */     case 252: 
/* 206 */       this.goSSTRecord = ((SSTRecord)poRecord);
/* 207 */       break;
/*     */     
/*     */     case 6: 
/* 210 */       FormulaRecord voFormula = (FormulaRecord)poRecord;
/* 211 */       this.goCurrentSheet.setCell(new CellPosition(voFormula.getColumn(), voFormula.getRow()), new Cell(String.valueOf(voFormula.getValue()), this.goListener.getFormatString(voFormula)));
/*     */       
/* 213 */       break;
/*     */     
/*     */     case 516: 
/* 216 */       LabelRecord voLabel = (LabelRecord)poRecord;
/* 217 */       this.goCurrentSheet.setCell(new CellPosition(voLabel.getColumn(), voLabel.getRow()), new Cell(voLabel.getValue()));
/*     */       
/* 219 */       break;
/*     */     
/*     */     case 253: 
/* 222 */       LabelSSTRecord voLabelRecord = (LabelSSTRecord)poRecord;
/* 223 */       this.goCurrentSheet.setCell(new CellPosition(voLabelRecord.getColumn(), voLabelRecord.getRow()), new Cell(this.goSSTRecord.getString(voLabelRecord.getSSTIndex()).getString()));
/*     */       
/* 225 */       break;
/*     */     
/*     */     case 515: 
/* 228 */       NumberRecord voNumber = (NumberRecord)poRecord;
/* 229 */       this.goCurrentSheet.setCell(new CellPosition(voNumber.getColumn(), voNumber.getRow()), new Cell(String.valueOf(voNumber.getValue()), this.goListener.getFormatString(voNumber)));
/*     */       
/* 231 */       break;
/*     */     
/*     */     case 638: 
/* 234 */       RKRecord voRKRecord = (RKRecord)poRecord;
/* 235 */       this.goCurrentSheet.setCell(new CellPosition(voRKRecord.getColumn(), voRKRecord.getRow()), new Cell(String.valueOf(voRKRecord.getRKNumber())));
/*     */       
/* 237 */       break;
/*     */     
/*     */     case 438: 
/* 240 */       System.out.println("TOR:" + poRecord);
/* 241 */       break;
/*     */     
/*     */     case 34: 
/* 244 */       DateWindow1904Record date1904Record = (DateWindow1904Record)poRecord;
/* 245 */       this.goWorkbook.set1904(date1904Record.getWindowing() == 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\XLSParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */