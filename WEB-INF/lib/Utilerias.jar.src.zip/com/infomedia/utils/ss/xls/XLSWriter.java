/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRichTextString;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XLSWriter
/*     */ {
/*     */   public static void addRow(HSSFSheet poSpreadSheet, List<String> poItems, int piRowIndex)
/*     */   {
/*  41 */     HSSFRow voRow = poSpreadSheet.createRow(piRowIndex);
/*  42 */     HSSFCell voCell = null;
/*  43 */     Iterator<String> voItems = poItems.iterator();
/*  44 */     int viCellIndex = 0;
/*     */     
/*  46 */     while (voItems.hasNext()) {
/*  47 */       voCell = voRow.createCell(viCellIndex++, 1);
/*  48 */       voCell.setCellValue(new HSSFRichTextString((String)voItems.next()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void write(OutputStream poFOS, List<List<String>> poContent)
/*     */     throws Exception
/*     */   {
/*  64 */     Iterator<List<String>> voContentRow = null;
/*  65 */     HSSFWorkbook voWB = null;
/*  66 */     HSSFSheet voSpreadSheet = null;
/*  67 */     int viRowIndex = 0;
/*     */     
/*  69 */     voWB = new HSSFWorkbook();
/*  70 */     voSpreadSheet = voWB.createSheet("1");
/*  71 */     voContentRow = poContent.iterator();
/*  72 */     while (voContentRow.hasNext()) {
/*  73 */       addRow(voSpreadSheet, (List)voContentRow.next(), viRowIndex++);
/*     */     }
/*  75 */     voWB.write(poFOS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void write(File poFile, List<List<String>> poContent)
/*     */     throws Exception
/*     */   {
/*  90 */     FileOutputStream voFOS = null;
/*     */     try
/*     */     {
/*  93 */       if (FileUtils.fncbVerificaDirectorio(poFile.getParent())) {
/*  94 */         voFOS = new FileOutputStream(poFile);
/*  95 */         write(voFOS, poContent);
/*     */       }
/*     */       return;
/*  98 */     } catch (Exception voEXC) { throw voEXC;
/*     */     } finally {
/*     */       try {
/* 101 */         voFOS.flush();
/* 102 */         voFOS.close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void write(String psFilePath, String psFileName, List<List<String>> poContent)
/*     */     throws Exception
/*     */   {
/* 120 */     write(new File(psFilePath, psFileName), poContent);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\XLSWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */