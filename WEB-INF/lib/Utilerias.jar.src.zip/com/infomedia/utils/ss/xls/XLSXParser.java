/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.ss.CellPosition;
/*     */ import com.infomedia.utils.ss.SpreadSheet;
/*     */ import com.infomedia.utils.ss.SpreadSheetParser;
/*     */ import com.infomedia.utils.ss.WorkBook;
/*     */ import java.io.InputStream;
/*     */ import org.apache.poi.openxml4j.opc.OPCPackage;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XLSXParser
/*     */   implements SpreadSheetParser
/*     */ {
/*     */   public static final String EXT = ".xlsx";
/*  26 */   private static XLSXParser INSTANCE = new XLSXParser();
/*     */   public static final String FILE_WORKBOOK = "Workbook";
/*     */   
/*  29 */   public static XLSXParser getInstance() { return INSTANCE; }
/*  30 */   public static boolean isXLSXFile(String psFileName) { return psFileName.toLowerCase().endsWith(".xlsx"); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SpreadSheet parseSpreadSheet(Sheet poSheet)
/*     */   {
/*  44 */     SpreadSheet voSS = new SpreadSheet(poSheet.getSheetName());
/*  45 */     String vsCellValue = "";
/*  46 */     int viColIndex = 0;
/*     */     
/*  48 */     for (Row voRow : poSheet) {
/*  49 */       viColIndex = 0;
/*  50 */       for (org.apache.poi.ss.usermodel.Cell voCell : voRow) {
/*  51 */         while (viColIndex != voCell.getColumnIndex()) {
/*  52 */           voSS.setCell(new CellPosition(viColIndex, voRow.getRowNum()), new com.infomedia.utils.ss.Cell(""));
/*  53 */           viColIndex++;
/*     */         }
/*  55 */         switch (voCell.getCellType()) {
/*     */         case 0: 
/*  57 */           vsCellValue = String.valueOf(voCell.getNumericCellValue());
/*  58 */           break;
/*     */         default: 
/*  60 */           vsCellValue = String.valueOf(voCell.toString());
/*     */         }
/*     */         
/*  63 */         voSS.setCell(new CellPosition(voCell.getColumnIndex(), voRow.getRowNum()), new com.infomedia.utils.ss.Cell(vsCellValue));
/*  64 */         viColIndex++;
/*     */       }
/*  66 */       viColIndex++;
/*     */     }
/*  68 */     return voSS;
/*     */   }
/*     */   
/*     */   public synchronized WorkBook parse(InputStream poInputStream) {
/*  72 */     voParsedWorkBook = new WorkBook();
/*  73 */     XSSFWorkbook voWorkBook = null;
/*  74 */     int viSheetIndex = 0;
/*     */     try
/*     */     {
/*  77 */       voWorkBook = new XSSFWorkbook(poInputStream);
/*  78 */       for (viSheetIndex = 0; viSheetIndex < voWorkBook.getNumberOfSheets(); viSheetIndex++) {
/*  79 */         voParsedWorkBook.addSpreadSheet(parseSpreadSheet(voWorkBook.getSheetAt(viSheetIndex)));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */       return voParsedWorkBook;
/*     */     }
/*     */     catch (Exception poEXC)
/*     */     {
/*  82 */       poEXC.printStackTrace();
/*     */     } finally {
/*     */       try {
/*  85 */         voWorkBook.getPackage().close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized WorkBook parse(String psXLSLFileName) {
/*  92 */     voParsedWorkBook = new WorkBook();
/*  93 */     XSSFWorkbook voWorkBook = null;
/*  94 */     int viSheetIndex = 0;
/*     */     try
/*     */     {
/*  97 */       voWorkBook = new XSSFWorkbook(psXLSLFileName);
/*  98 */       for (viSheetIndex = 0; viSheetIndex < voWorkBook.getNumberOfSheets(); viSheetIndex++) {
/*  99 */         voParsedWorkBook.addSpreadSheet(parseSpreadSheet(voWorkBook.getSheetAt(viSheetIndex)));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */       return voParsedWorkBook;
/*     */     }
/*     */     catch (Exception poEXC)
/*     */     {
/* 102 */       poEXC.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 105 */         voWorkBook.getPackage().close();
/*     */       }
/*     */       catch (Exception voIgnorar) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\XLSXParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */