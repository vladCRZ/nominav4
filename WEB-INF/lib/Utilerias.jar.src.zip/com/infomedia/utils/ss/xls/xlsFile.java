/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.ss.SpreadSheetFileInterface;
/*     */ import com.infomedia.utils.ss.SpreadSheetInterface;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class xlsFile
/*     */   implements SpreadSheetFileInterface
/*     */ {
/*     */   private String fileName;
/*  20 */   private HSSFWorkbook xlsBook = null;
/*  21 */   private FileInputStream isXls = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public xlsFile(String psFileName)
/*     */   {
/*  31 */     this.fileName = psFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean openFile()
/*     */   {
/*     */     try
/*     */     {
/*  42 */       this.isXls = new FileInputStream(this.fileName);
/*  43 */       return true;
/*     */     } catch (Exception e) {}
/*  45 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean closeFile()
/*     */   {
/*     */     try
/*     */     {
/*  57 */       this.isXls.close();
/*  58 */       this.xlsBook = null;
/*  59 */       System.gc();
/*  60 */       return true;
/*     */     } catch (Exception e) {}
/*  62 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readFile()
/*     */   {
/*     */     try
/*     */     {
/*  74 */       this.xlsBook = new HSSFWorkbook(this.isXls, false);
/*  75 */       return true;
/*     */     } catch (Exception e) {}
/*  77 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean saveFile()
/*     */   {
/*     */     try
/*     */     {
/*  89 */       FileOutputStream fos = new FileOutputStream(this.fileName);
/*  90 */       this.xlsBook.write(fos);
/*  91 */       fos.close();
/*  92 */       return true;
/*     */     } catch (Exception e) {}
/*  94 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfSheets()
/*     */   {
/* 105 */     return this.xlsBook.getNumberOfSheets();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpreadSheetInterface getSheetAt(int sheetIndex)
/*     */   {
/* 116 */     return new xlsSheet(this.xlsBook.getSheetAt(sheetIndex));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\xlsFile.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */