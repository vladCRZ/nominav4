/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class xlsFormatter
/*     */ {
/*  20 */   private Format goFormatter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class AnotherFormat
/*     */     extends Format
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */ 
/*     */ 
/*  32 */     private String gsFormat = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AnotherFormat(String psFormat)
/*     */     {
/*  42 */       this.gsFormat = psFormat;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String format(String value)
/*     */     {
/*  54 */       DecimalFormat goDecimalFormat = new DecimalFormat("##########");
/*  55 */       goDecimalFormat.setParseIntegerOnly(true);
/*  56 */       String sNumber = goDecimalFormat.format(Double.parseDouble(value));
/*  57 */       String result = "";
/*     */       
/*     */ 
/*     */ 
/*  61 */       int formatPos = this.gsFormat.length() - 1; for (int numberPos = sNumber.length() - 1; formatPos >= 0; formatPos--) {
/*  62 */         String SFormat = this.gsFormat.substring(formatPos, formatPos + 1);
/*  63 */         String SNumber = numberPos >= 0 ? sNumber.substring(numberPos, numberPos + 1) : "";
/*     */         
/*     */         String SResult;
/*  66 */         if (SFormat.equals("0")) {
/*  67 */           String SResult = numberPos >= 0 ? SNumber : "0";
/*  68 */           numberPos--;
/*  69 */         } else if (SFormat.equals("#")) {
/*  70 */           String SResult = numberPos >= 0 ? SNumber : "";
/*  71 */           numberPos--;
/*     */         }
/*     */         else {
/*  74 */           if (SFormat.equals("\\"))
/*  75 */             SFormat.substring(numberPos--, numberPos + 1);
/*  76 */           SResult = SFormat;
/*     */         }
/*     */         
/*  79 */         result = SResult + result;
/*     */       }
/*     */       
/*  82 */       return result;
/*     */     }
/*     */     
/*     */     public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
/*  86 */       toAppendTo.append(format((String)obj));
/*  87 */       return toAppendTo;
/*     */     }
/*     */     
/*     */     public Object parseObject(String source, ParsePosition pos) {
/*  91 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public xlsFormatter(String format)
/*     */   {
/* 103 */     String xlsFormat = cleanFormat(format);
/* 104 */     if (canSetToDateFormat(xlsFormat)) return;
/* 105 */     if (canSetToNumericFormat(xlsFormat)) return;
/* 106 */     if (canSetToAnotherFormat(xlsFormat)) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String format(String value)
/*     */   {
/* 117 */     if (value.trim().equals("NaN")) return "";
/* 118 */     if ((isDateFormat()) || (isNumericFormat()) || (isAnotherFormat()))
/*     */     {
/* 120 */       return this.goFormatter.format(value);
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date toJavaDate(String value)
/*     */   {
/*     */     try
/*     */     {
/* 135 */       Calendar calendar = Calendar.getInstance();
/* 136 */       double dateValue = Double.parseDouble(value);
/* 137 */       double timeValue = Double.parseDouble(value) % 1.0D;
/*     */       
/*     */ 
/* 140 */       calendar.setTimeInMillis((8.64E7D * timeValue));
/*     */       
/* 142 */       calendar.set(5, 0);
/* 143 */       calendar.set(2, 0);
/* 144 */       calendar.set(1, 1900);
/* 145 */       calendar.add(5, (int)dateValue - 1);
/*     */       
/* 147 */       return calendar.getTime();
/*     */     } catch (Exception e) {}
/* 149 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String cleanFormat(String format)
/*     */   {
/* 161 */     return format.replaceAll("\" ", " '").replaceAll(" \"", "' ").replaceAll("Y", "y").replaceAll("D", "d").replaceAll("\\[H\\]", "H").replaceAll("\\[HH\\]", "HH").replaceAll("H", "h").replaceAll("HH", "hh").replaceAll(":MM", ":mm").replaceAll(":SS", ":ss").replaceAll(";@", "").replaceAll("\\[\\S+\\]", "").replaceAll("\\\\,", ",").replaceAll("\\\\ ", " ").replaceAll("\\\\-", "-");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isDateFormat()
/*     */   {
/* 185 */     return this.goFormatter instanceof SimpleDateFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isNumericFormat()
/*     */   {
/* 194 */     return this.goFormatter instanceof NumberFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isAnotherFormat()
/*     */   {
/* 203 */     return this.goFormatter instanceof AnotherFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canSetToDateFormat(String xlsFormat)
/*     */   {
/*     */     try
/*     */     {
/* 215 */       this.goFormatter = new SimpleDateFormat(xlsFormat);
/* 216 */       if (format("1").equals(xlsFormat)) throw new Exception("");
/* 217 */       return true;
/*     */     } catch (Exception e) {
/* 219 */       this.goFormatter = null; }
/* 220 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canSetToNumericFormat(String xlsFormat)
/*     */   {
/*     */     try
/*     */     {
/* 234 */       this.goFormatter = new DecimalFormat(xlsFormat);
/* 235 */       Double.parseDouble(format("1"));
/* 236 */       return true;
/*     */     } catch (Exception e) {
/* 238 */       this.goFormatter = null; }
/* 239 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean canSetToAnotherFormat(String xlsFormat)
/*     */   {
/* 251 */     this.goFormatter = new AnotherFormat(xlsFormat);
/* 252 */     return true;
/*     */   }
/*     */   
/*     */   public static String fncsFormat(String psFormat, String psValue) {
/* 256 */     xlsFormatter voFormatter = new xlsFormatter(psFormat);
/* 257 */     return voFormatter.format(psValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\xlsFormatter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */