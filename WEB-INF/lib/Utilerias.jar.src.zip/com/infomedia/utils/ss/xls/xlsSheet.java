/*     */ package com.infomedia.utils.ss.xls;
/*     */ 
/*     */ import com.infomedia.utils.ss.SpreadSheetInterface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRichTextString;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class xlsSheet
/*     */   implements SpreadSheetInterface
/*     */ {
/*  22 */   private HSSFSheet sheet = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public xlsSheet(HSSFSheet poSheet)
/*     */   {
/*  32 */     this.sheet = poSheet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfRows()
/*     */   {
/*  42 */     return this.sheet.getLastRowNum() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfCells(int row)
/*     */   {
/*     */     try
/*     */     {
/*  54 */       return this.sheet.getRow(row).getLastCellNum();
/*     */     } catch (Exception e) {}
/*  56 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCellAsString(int column, int row)
/*     */   {
/*  69 */     HSSFCell celda = getCellAt(column, row);
/*  70 */     return celda == null ? "" : getFormattedString(celda);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getRow(int row, int length, int offset)
/*     */   {
/*  83 */     List<String> cellArray = new ArrayList();
/*  84 */     int numCeldas = getNumberOfCells(row);
/*     */     
/*  86 */     for (int i = 0; (i < numCeldas) && (i < length); i++) {
/*  87 */       cellArray.add(getCellAsString(i + offset, row));
/*     */     }
/*  89 */     return cellArray;
/*     */   }
/*     */   
/*  92 */   public List<String> getRow(int row, int length) { return getRow(row, length, 0); }
/*     */   
/*     */   public List<String> getRow(int row) {
/*  95 */     return getRow(row, getNumberOfCells(row), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getColumn(int column, int length, int offset)
/*     */   {
/* 109 */     List<String> cellArray = new ArrayList();
/*     */     
/* 111 */     for (int i = 0; (i < getNumberOfRows()) && (i < length); i++) {
/* 112 */       cellArray.add(getCellAsString(column, i + offset));
/*     */     }
/* 114 */     return cellArray;
/*     */   }
/*     */   
/* 117 */   public List<String> getColumn(int column, int length) { return getColumn(column, length, 0); }
/*     */   
/*     */   public List<String> getColumn(int column) {
/* 120 */     return getColumn(column, getNumberOfRows(), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellValueAsString(HSSFCell xlsCell)
/*     */   {
/* 132 */     switch (xlsCell.getCellType()) {
/* 133 */     case 3:  return "";
/* 134 */     case 4:  return "" + xlsCell.getBooleanCellValue();
/* 135 */     case 5:  return "" + xlsCell.getErrorCellValue();
/* 136 */     case 2:  return "" + xlsCell.getNumericCellValue();
/* 137 */     case 0:  return "" + xlsCell.getNumericCellValue();
/* 138 */     case 1:  return xlsCell.getRichStringCellValue().getString(); }
/* 139 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getFormattedString(HSSFCell xlsCell)
/*     */   {
/* 151 */     HSSFCellStyle xlsCellStyle = xlsCell.getCellStyle();
/* 152 */     String xlsStringValue = getCellValueAsString(xlsCell).replaceAll("\n", "");
/* 153 */     String xlsFormat = xlsCellStyle.getDataFormatString();
/*     */     
/* 155 */     if ((xlsFormat.equals("GENERAL")) || (xlsStringValue.trim().equals(""))) {
/* 156 */       return xlsStringValue;
/*     */     }
/* 158 */     xlsFormatter sf = new xlsFormatter(xlsFormat);
/* 159 */     return sf.format(xlsStringValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HSSFCell getCellAt(int column, int row)
/*     */   {
/* 171 */     return this.sheet.getRow(row).getCell(column);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\infomedi\\utils\ss\xls\xlsSheet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */