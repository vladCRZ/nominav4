/*     */ package com.softcoatl.cforms.xml;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XMLUtils
/*     */ {
/*     */   public static Document newDocument()
/*     */     throws ParserConfigurationException
/*     */   {
/*  52 */     DocumentBuilder voDB = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  53 */     return voDB.newDocument();
/*     */   }
/*     */   
/*     */   public static Transformer getTransformer(boolean pbOmitXMLDeclaration, boolean pbIndent) throws TransformerConfigurationException {
/*  57 */     TransformerFactory voTF = null;
/*  58 */     Transformer voTransformer = null;
/*     */     
/*  60 */     voTF = TransformerFactory.newInstance();
/*  61 */     voTransformer = voTF.newTransformer();
/*  62 */     voTransformer.setOutputProperty("omit-xml-declaration", pbOmitXMLDeclaration ? "yes" : "no");
/*  63 */     voTransformer.setOutputProperty("indent", pbIndent ? "yes" : "no");
/*  64 */     return voTransformer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Transformer getTransformer()
/*     */     throws TransformerConfigurationException
/*     */   {
/*  78 */     return getTransformer(true, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Node createNode(Document poDocument, String psTag, Map<String, String> poAttributes)
/*     */   {
/*  94 */     Element voNode = poDocument.createElement(psTag);
/*     */     
/*  96 */     if ((poAttributes != null) && (poAttributes.size() > 0)) {
/*  97 */       for (String psAttr : poAttributes.keySet()) {
/*  98 */         voNode.setAttribute(psAttr, (String)poAttributes.get(psAttr));
/*     */       }
/*     */     }
/*     */     
/* 102 */     return voNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Node createTextNode(Document poDocument, String psText)
/*     */   {
/* 117 */     return poDocument.createTextNode(psText);
/*     */   }
/*     */   
/*     */   public static String xmlToString(Node poXMLNode, boolean pbOmitXMLDeclaration, boolean pbIndent) throws TransformerException {
/* 121 */     DOMSource voDOM = new DOMSource(poXMLNode);
/* 122 */     StringWriter voWriter = new StringWriter();
/* 123 */     StreamResult voResult = new StreamResult(voWriter);
/* 124 */     System.out.println(voDOM);
/* 125 */     getTransformer(pbOmitXMLDeclaration, pbIndent).transform(voDOM, voResult);
/* 126 */     return voWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String xmlToString(Node poXMLNode)
/*     */     throws TransformerException
/*     */   {
/* 142 */     return xmlToString(poXMLNode, true, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\cforms\xml\XMLUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */