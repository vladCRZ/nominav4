/*    */ package com.softcoatl.comm;
/*    */ 
/*    */ import com.infomedia.utils.StringUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BasicConnection
/*    */   implements ConnectionInterface
/*    */ {
/* 18 */   protected static Logger log = Logger.getLogger(BasicConnection.class);
/* 19 */   protected String error = "";
/* 20 */   protected String response = "";
/*    */   protected Host host;
/*    */   
/*    */   public BasicConnection(Host host) {
/* 24 */     this.host = host;
/*    */   }
/*    */   
/*    */   public boolean hasError() {
/* 28 */     return !StringUtils.isNVL(this.error);
/*    */   }
/*    */   
/*    */   public String getError() {
/* 32 */     return this.error;
/*    */   }
/*    */   
/*    */   public boolean hasResponse() {
/* 36 */     return !StringUtils.isNVL(this.response);
/*    */   }
/*    */   
/*    */ 
/* 40 */   public String getResponse() { return this.response; }
/*    */   
/*    */   protected void cleanMessages() {
/* 43 */     this.error = "";
/* 44 */     this.response = "";
/*    */   }
/*    */   
/* 47 */   protected void processException(Throwable cause) { log.error(cause);
/* 48 */     this.error = cause.getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\BasicConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */