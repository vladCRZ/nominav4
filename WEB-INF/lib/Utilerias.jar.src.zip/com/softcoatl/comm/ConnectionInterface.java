package com.softcoatl.comm;

public abstract interface ConnectionInterface
{
  public static final String CNX_HST = "server.host";
  public static final String CNX_PRT = "server.port";
  public static final String CNX_USR = "server.user";
  public static final String CNX_PWD = "server.password";
  public static final String CNX_DBG = "server.debug";
  public static final String CONN_REFUSED = "CONNECTION REFUSED";
  
  public abstract void setHost(Host paramHost);
  
  public abstract Host getHost();
  
  public abstract boolean hasError();
  
  public abstract String getError();
  
  public abstract boolean hasResponse();
  
  public abstract String getResponse();
  
  public abstract boolean connect();
  
  public abstract boolean isConnected();
  
  public abstract void disconnect();
  
  public abstract boolean login();
  
  public abstract boolean login(String paramString1, String paramString2);
  
  public abstract void logout();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\ConnectionInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */