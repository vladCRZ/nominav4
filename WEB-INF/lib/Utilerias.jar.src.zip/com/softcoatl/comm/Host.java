/*     */ package com.softcoatl.comm;
/*     */ 
/*     */ import com.infomedia.utils.FileUtils;
/*     */ import java.io.Serializable;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class Host
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String SRV_HST = "server.host";
/*     */   public static final String SRV_PRT = "server.port";
/*     */   public static final String SRV_USR = "server.user";
/*     */   public static final String SRV_PWD = "server.password";
/*     */   public static final String SRV_TOUT = "server.timeout";
/*     */   public static final String SRV_TRY = "server.retry";
/*     */   public static final String SRV_LOCALE = "server.locale";
/*     */   public static final String SRV_HOME = "env.home";
/*     */   public static final int RETRY = 3;
/*     */   public static final int TIMEOUT = 0;
/*     */   public static final String LOCALE = "es_MX";
/*  22 */   private String gsHST = "";
/*  23 */   private String gsUSR = "";
/*  24 */   private transient String gsPWD = "";
/*  25 */   private String gsHOME = "";
/*  26 */   private String gsLOCALE = "";
/*     */   
/*  28 */   private int giPRT = 0;
/*     */   
/*  30 */   private int giTOUT = 0;
/*  31 */   private int giTRY = 3;
/*     */   
/*     */   public Host() {}
/*     */   
/*  35 */   public Host(String psHST, String psUSR, String psPWD, int piPRT, int piTOUT, int piTRY, String psLOCALE) { this.gsHST = psHST;
/*  36 */     this.gsUSR = psUSR;
/*  37 */     this.gsPWD = psPWD;
/*  38 */     this.giPRT = piPRT;
/*  39 */     this.giTOUT = piTOUT;
/*  40 */     this.giTRY = piTRY;
/*  41 */     this.gsLOCALE = psLOCALE;
/*     */   }
/*     */   
/*  44 */   public Host(String psHST, String psUSR, String psPWD, int piPRT, int piTOUT, int piTRY) { this(psHST, psUSR, psPWD, piPRT, piTOUT, 3, "es_MX"); }
/*     */   
/*     */   public Host(String psHST, String psUSR, String psPWD, int piPRT, int piTOUT) {
/*  47 */     this(psHST, psUSR, psPWD, piPRT, piTOUT, 3);
/*     */   }
/*     */   
/*  50 */   public Host(String psHST, String psUSR, String psPWD, int piPRT) { this(psHST, psUSR, psPWD, piPRT, 0); }
/*     */   
/*     */   public Host(String psHST, int piPRT, int piTOUT, int piTRY) {
/*  53 */     this(psHST, "", "", piPRT, piTOUT, piTRY);
/*     */   }
/*     */   
/*  56 */   public Host(String psHST, int piPRT, int piTOUT) { this(psHST, piPRT, piTOUT, 3); }
/*     */   
/*     */   public Host(String psHST, int piPRT) {
/*  59 */     this(psHST, piPRT, 0);
/*     */   }
/*     */   
/*  62 */   public String getHST() { return this.gsHST; }
/*  63 */   public void setHST(String psHST) { this.gsHST = psHST; }
/*     */   
/*  65 */   public String getUSR() { return this.gsUSR; }
/*  66 */   public void setUSR(String psUSR) { this.gsUSR = psUSR; }
/*     */   
/*  68 */   public String getPWD() { return this.gsPWD; }
/*  69 */   public void setPWD(String psPWD) { this.gsPWD = psPWD; }
/*     */   
/*  71 */   public void setHOME(String psHOME) { this.gsHOME = psHOME; }
/*  72 */   public String getHOME() { return this.gsHOME; }
/*     */   
/*  74 */   public int getPRT() { return this.giPRT; }
/*  75 */   public void setPRT(int piPRT) { this.giPRT = piPRT; }
/*     */   
/*  77 */   public void setTRY(int piTRY) { this.giTRY = piTRY; }
/*  78 */   public int getTRY() { return this.giTRY; }
/*     */   
/*  80 */   public void setTOUT(int piTOUT) { this.giTOUT = piTOUT; }
/*  81 */   public int getTOUT() { return this.giTOUT; }
/*     */   
/*  83 */   public void setLOCALE(String psLolcale) { this.gsLOCALE = psLolcale; }
/*  84 */   public String getLocale() { return this.gsLOCALE; }
/*     */   
/*     */   public static Host parse(Properties poProperties) throws Exception {
/*  87 */     Host voServer = new Host();
/*  88 */     if ((!poProperties.containsKey("server.host")) || (!poProperties.contains("server.port")) || (!poProperties.containsKey("server.user")) || (!poProperties.containsKey("server.password")))
/*     */     {
/*     */ 
/*  91 */       throw new Exception("Server is not defined"); }
/*  92 */     voServer.setHST(poProperties.getProperty("server.host"));
/*  93 */     voServer.setUSR(poProperties.getProperty("server.user"));
/*  94 */     voServer.setPWD(poProperties.getProperty("server.password"));
/*  95 */     voServer.setPRT(Integer.parseInt(poProperties.getProperty("server.port")));
/*  96 */     voServer.setTOUT(poProperties.containsKey("server.timeout") ? Integer.parseInt(poProperties.getProperty("server.timeout")) : 0);
/*  97 */     voServer.setTRY(poProperties.containsKey("server.retry") ? Integer.parseInt(poProperties.getProperty("server.retry")) : 3);
/*  98 */     voServer.setHOME(poProperties.containsKey("env.home") ? poProperties.getProperty("env.home") : FileUtils.fncsUserHome());
/*  99 */     voServer.setLOCALE(poProperties.containsKey("server.locale") ? poProperties.getProperty("server.locale") : "server.locale");
/* 100 */     return voServer;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 105 */     return "HST=" + this.gsHST + "\nUSR=" + this.gsUSR + "\nPWD=" + this.gsPWD + "\nHOME=" + this.gsHOME + "\nPRT=" + this.giPRT + "\nTOUT=" + this.giTOUT + "\nTRY=" + this.giTRY + "\nLOCALE=" + this.gsLOCALE;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\Host.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */