/*     */ package com.softcoatl.comm.ftp;
/*     */ 
/*     */ import com.softcoatl.comm.BasicConnection;
/*     */ import com.softcoatl.comm.Host;
/*     */ import com.softcoatl.comm.ftp.filter.FTPNameFileFilter;
/*     */ import com.softcoatl.utils.file.FileCommon;
/*     */ import com.softcoatl.utils.file.FileMannager;
/*     */ import com.softcoatl.utils.file.FileMannagerException;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.commons.net.ftp.FTPFile;
/*     */ import org.apache.commons.net.ftp.FTPFileFilter;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class FTPConnection
/*     */   extends BasicConnection implements FileMannager
/*     */ {
/*     */   public static final int FILE_NOT_FOUND_CODE = 550;
/*  26 */   private FTPClient client = null;
/*     */   
/*     */   public static final FTPConnection getInstance(Host host) throws Exception {
/*  29 */     FTPConnection connection = new FTPConnection(host);
/*  30 */     if ((!connection.connect()) || (!connection.login())) {
/*  31 */       throw new Exception("Error establishing a FTP connection");
/*     */     }
/*  33 */     host.setHOME(connection.client.printWorkingDirectory());
/*  34 */     return connection;
/*     */   }
/*     */   
/*     */   private FTPConnection(Host host) {
/*  38 */     super(host);
/*     */   }
/*     */   
/*     */   public boolean connect() {
/*  42 */     boolean connected = false;
/*  43 */     int viTimeOut = this.host.getTOUT() * 1000;
/*     */     try
/*     */     {
/*  46 */       disconnect();
/*  47 */       cleanMessages();
/*  48 */       if (this.host.getHST().equals("")) {
/*  49 */         throw new Exception("Host not defined");
/*     */       }
/*  51 */       this.client = new FTPClient();
/*  52 */       this.client.setDefaultTimeout(viTimeOut);
/*  53 */       this.client.connect(this.host.getHST(), this.host.getPRT());
/*  54 */       if ((connected = this.client.isConnected())) {
/*  55 */         this.client.setSoTimeout(0);
/*     */       }
/*     */     } catch (Exception EXC) {
/*  58 */       processException(EXC);
/*  59 */       this.client = null;
/*     */     }
/*     */     
/*  62 */     return connected;
/*     */   }
/*     */   
/*     */   public void logout() {
/*     */     try {
/*  67 */       if (isConnected()) {
/*  68 */         this.client.logout();
/*     */       }
/*  70 */       log.info("FTO Loggedout");
/*     */     } catch (IOException IOE) {
/*  72 */       processException(IOE);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setHost(Host host) {
/*  77 */     this.host = host;
/*     */   }
/*     */   
/*     */   public Host getHost() {
/*  81 */     return this.host;
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/*  85 */     return (null != this.client) && (this.client.isConnected());
/*     */   }
/*     */   
/*     */   public void disconnect() {
/*     */     try {
/*  90 */       log.info("Disconnecting...");
/*  91 */       if (isConnected()) {
/*  92 */         this.client.disconnect();
/*     */       }
/*     */     } catch (IOException IOE) {
/*  95 */       processException(IOE);
/*     */     } finally {
/*  97 */       cleanMessages();
/*  98 */       this.client = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean login(String user, String password) {
/* 103 */     boolean logged = false;
/*     */     try
/*     */     {
/* 106 */       logged = this.client.login(user, password);
/* 107 */       log.info("Usr logged " + user);
/*     */     } catch (IOException IOE) {
/* 109 */       processException(IOE);
/*     */     }
/*     */     
/* 112 */     return logged;
/*     */   }
/*     */   
/*     */   public boolean login() {
/* 116 */     return login(this.host.getUSR(), this.host.getPWD());
/*     */   }
/*     */   
/*     */   public String getUserHome() {
/* 120 */     return this.host.getHOME();
/*     */   }
/*     */   
/*     */   public void setUserHome(String home) {
/* 124 */     this.host.setHOME(home);
/*     */   }
/*     */   
/*     */   public String getCurrentPath() {
/* 128 */     String currentPath = "";
/*     */     try {
/* 130 */       currentPath = this.client.printWorkingDirectory();
/*     */     } catch (IOException IOE) {
/* 132 */       processException(IOE);
/*     */     }
/* 134 */     return currentPath;
/*     */   }
/*     */   
/*     */   public boolean changeDir(String dir) {
/*     */     try {
/* 139 */       return this.client.changeWorkingDirectory(dir);
/*     */     } catch (IOException IOE) {
/* 141 */       processException(IOE);
/*     */     }
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDirectory(String dir) {
/* 147 */     String current = getCurrentPath();
/* 148 */     boolean isDir = changeDir(dir);
/* 149 */     changeDir(current);
/* 150 */     return isDir;
/*     */   }
/*     */   
/*     */   private List<FTPFile> listFiles(String path, FTPFileFilter filter) {
/* 154 */     String current = getCurrentPath();
/* 155 */     List<FTPFile> files = new ArrayList();
/*     */     try {
/* 157 */       changeDir(path);
/* 158 */       files.addAll(Arrays.asList(this.client.listFiles(path, filter)));
/*     */     } catch (IOException IOE) {
/* 160 */       processException(IOE);
/*     */     } finally {
/* 162 */       changeDir(current);
/*     */     }
/* 164 */     return files;
/*     */   }
/*     */   
/*     */   private FTPFile getFTPFIle(String path, String file) {
/* 168 */     FTPNameFileFilter filter = new FTPNameFileFilter();
/* 169 */     filter.setFilterName(file);
/* 170 */     for (FTPFile ftpFile : listFiles(path, filter)) {
/* 171 */       if (ftpFile.getName().equals(file)) {
/* 172 */         return ftpFile;
/*     */       }
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */   
/*     */   public boolean directoryExists(String dir, boolean create) {
/* 179 */     String current = getCurrentPath();
/* 180 */     boolean exists = false;
/*     */     try {
/* 182 */       exists = changeDir(dir);
/*     */     } catch (Exception FME) {
/* 184 */       processException(FME);
/* 185 */       if (550 == this.client.getReplyCode()) {
/*     */         try {
/* 187 */           this.client.makeDirectory(dir);
/* 188 */           exists = changeDir(dir);
/*     */         } catch (IOException IOE) {
/* 190 */           processException(IOE);
/*     */         }
/*     */       }
/*     */     } finally {
/* 194 */       changeDir(current);
/*     */     }
/* 196 */     return exists;
/*     */   }
/*     */   
/*     */   private boolean fileExists(String name) {
/* 200 */     FTPFileFilter filter = new FTPNameFileFilter();
/* 201 */     ((FTPNameFileFilter)filter).setFilterName(name);
/*     */     try {
/* 203 */       return this.client.listFiles(this.response, filter).length > 0;
/*     */     } catch (IOException IOE) {
/* 205 */       log.error(IOE);
/*     */     }
/* 207 */     return false;
/*     */   }
/*     */   
/*     */   public boolean exists(String name) {
/* 211 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public Calendar getModifiedDateAsCalendar(String file) throws FileMannagerException {
/* 215 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public int fileSize(String path, String file) throws FileMannagerException {
/* 219 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public String extractFileName(String absoluteName) throws FileMannagerException {
/* 223 */     String name = FileCommon.fixSeparatorChar(absoluteName.trim());
/* 224 */     if (name.endsWith(File.pathSeparator)) {
/* 225 */       name = name.substring(0, name.length() - 1);
/*     */     }
/* 227 */     return new String(absoluteName.substring(name.lastIndexOf(File.pathSeparator) + 1));
/*     */   }
/*     */   
/*     */   public String extractPath(String absoluteName) throws FileMannagerException {
/* 231 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public InputStream getInputStream(String path, String fileName) throws FileMannagerException {
/* 235 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public InputStream getInputStream(String fileName) throws FileMannagerException {
/* 239 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public byte[] readFile(String path, String fileName) throws FileMannagerException {
/* 243 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public byte[] readFile(String fileName) throws FileMannagerException {
/* 247 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public String saveFile(String path, String fileName, InputStream content) throws FileMannagerException {
/* 251 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public String saveFile(String path, String fileName, byte[] content) throws FileMannagerException {
/* 255 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public boolean delete(String path, String file) throws FileMannagerException {
/* 259 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public boolean delete(String file) throws FileMannagerException {
/* 263 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public boolean rename(String fromPath, String from, String toPath, String to) throws FileMannagerException {
/* 267 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public boolean rename(String path, String from, String to) throws FileMannagerException {
/* 271 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public boolean rename(String from, String to) throws FileMannagerException {
/* 275 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public boolean recursiveDeletion(String path) throws FileMannagerException {
/* 279 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public List<String> listFiles(String path, boolean absolute, FileFilter fileFilter) throws FileMannagerException {
/* 283 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public List<String> listFiles(String path, FileFilter fileFilter) throws FileMannagerException {
/* 287 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   public List<String> listFiles(String path) throws FileMannagerException {
/* 291 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\ftp\FTPConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */