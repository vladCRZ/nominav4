/*    */ package com.softcoatl.comm.ftp.filter;
/*    */ 
/*    */ import com.infomedia.utils.DateUtils;
/*    */ import java.util.Calendar;
/*    */ import org.apache.commons.net.ftp.FTPFile;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FTPDateFileFilter
/*    */   extends FTPFileFilterDecorator
/*    */ {
/* 19 */   private Calendar filterDate = null;
/* 20 */   private int filteringLevel = 6;
/*    */   
/*    */   public void setDate(Calendar date) {
/* 23 */     this.filterDate = date;
/*    */   }
/*    */   
/* 26 */   public Calendar getDate() { return this.filterDate; }
/*    */   
/*    */   public void setLevel(int level)
/*    */   {
/* 30 */     this.filteringLevel = level;
/*    */   }
/*    */   
/* 33 */   public int getLevel() { return this.filteringLevel; }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean customAccept(FTPFile file)
/*    */   {
/* 39 */     Calendar truncateDate = DateUtils.fncoTrucado(this.filterDate, this.filteringLevel);
/* 40 */     Calendar modifiedDate = DateUtils.fncoTrucado(file.getTimestamp(), this.filteringLevel);
/* 41 */     this.log.debug(file.getName());
/* 42 */     this.log.debug(DateUtils.fncsFormat("dd/MM/yyyy", truncateDate));
/* 43 */     this.log.debug(DateUtils.fncsFormat("dd/MM/yyyy", modifiedDate));
/* 44 */     this.log.debug(Long.valueOf(truncateDate.getTimeInMillis()));
/* 45 */     this.log.debug(Long.valueOf(modifiedDate.getTimeInMillis()));
/* 46 */     return ((isRecursive()) && (file.isDirectory())) || (DateUtils.fncbCompare(truncateDate, modifiedDate, 1));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\ftp\filter\FTPDateFileFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */