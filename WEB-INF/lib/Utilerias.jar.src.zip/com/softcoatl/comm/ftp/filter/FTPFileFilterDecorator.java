/*    */ package com.softcoatl.comm.ftp.filter;
/*    */ 
/*    */ import org.apache.commons.net.ftp.FTPFile;
/*    */ import org.apache.commons.net.ftp.FTPFileFilter;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FTPFileFilterDecorator
/*    */   implements FTPFileFilter
/*    */ {
/* 19 */   protected Logger log = Logger.getLogger(FTPFileFilterDecorator.class);
/* 20 */   protected FTPFileFilter fileFilterDelegate = null;
/* 21 */   protected boolean recursive = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setDelegate(FTPFileFilter fileFilter)
/*    */   {
/* 28 */     this.fileFilterDelegate = fileFilter;
/*    */   }
/*    */   
/*    */   public void setRecursive(boolean flag) {
/* 32 */     this.recursive = flag;
/*    */   }
/*    */   
/* 35 */   public boolean isRecursive() { return this.recursive; }
/*    */   
/*    */   public abstract boolean customAccept(FTPFile paramFTPFile);
/*    */   
/*    */   public boolean delegateAccept(FTPFile file) {
/* 40 */     return (null == this.fileFilterDelegate) || (this.fileFilterDelegate.accept(file));
/*    */   }
/*    */   
/*    */   public boolean accept(FTPFile file) {
/* 44 */     return (customAccept(file)) && (delegateAccept(file));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\ftp\filter\FTPFileFilterDecorator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */