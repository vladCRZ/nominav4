/*    */ package com.softcoatl.comm.ftp.filter;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.net.ftp.FTPFile;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FTPNameFileFilter
/*    */   extends FTPFileFilterDecorator
/*    */ {
/*    */   private String filterName;
/*    */   private Pattern pattern;
/*    */   
/*    */   public void setFilterName(String filter)
/*    */   {
/* 21 */     this.filterName = filter;
/* 22 */     this.pattern = Pattern.compile(filter, 2);
/*    */   }
/*    */   
/*    */   public boolean customAccept(FTPFile file) {
/* 26 */     this.log.debug(this.filterName);
/* 27 */     this.log.debug(file.getName());
/* 28 */     this.log.debug(Boolean.valueOf(this.pattern.matcher(file.getName()).matches()));
/* 29 */     return ((isRecursive()) && (file.isDirectory())) || (this.pattern.matcher(file.getName()).matches());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\comm\ftp\filter\FTPNameFileFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */