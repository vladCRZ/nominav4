/*    */ package com.softcoatl.commons;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpanishNTLConverter
/*    */   implements NumberToLetterConverter
/*    */ {
/*    */   public static final double LIMIT = 1.0E18D;
/* 16 */   private static final String[] UNIDADES = { "", "UN ", "DOS ", "TRES ", "CUATRO ", "CINCO ", "SEIS ", "SIETE ", "OCHO ", "NUEVE ", "DIEZ ", "ONCE ", "DOCE ", "TRECE ", "CATORCE ", "QUINCE ", "DIECISEIS", "DIECISIETE", "DIECIOCHO", "DIECINUEVE", "VEINTE" };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 21 */   private static final String[] DECENAS = { "", "", "VENTI", "TREINTA ", "CUARENTA ", "CINCUENTA ", "SESENTA ", "SETENTA ", "OCHENTA ", "NOVENTA " };
/*    */   
/*    */ 
/* 24 */   private static final String[] CENTENAS = { "", "CIENTO ", "DOSCIENTOS ", "TRESCIENTOS ", "CUATROCIENTOS ", "QUINIENTOS ", "SEISCIENTOS ", "SETECIENTOS ", "OCHOCIENTOS ", "NOVECIENTOS " };
/*    */   
/*    */ 
/*    */   private String convertTriad(int number)
/*    */   {
/* 29 */     StringBuilder letter = new StringBuilder();
/*    */     
/* 31 */     System.out.println(number + ":" + number / 100);
/*    */     
/* 33 */     if ((number / 100 == 1) && (number % 100 == 0)) letter.append("CIEN "); else {
/* 34 */       letter.append(CENTENAS[(number / 100)]);
/*    */     }
/* 36 */     if (number % 100 > 20) { letter.append(DECENAS[(number % 100 / 10)]);
/*    */     }
/* 38 */     if (number % 100 <= 20) {
/* 39 */       letter.append(UNIDADES[(number % 100)]);
/*    */     } else {
/* 41 */       if ((number % 100 > 30) && (number % 10 > 0)) letter.append("Y ");
/* 42 */       letter.append(UNIDADES[(number % 10)]);
/*    */     }
/* 44 */     return letter.toString();
/*    */   }
/*    */   
/*    */   public String convertNumberToLetter(double number) throws NumberToLetterConvertionException
/*    */   {
/* 49 */     StringBuilder letter = new StringBuilder();
/*    */     
/* 51 */     double b = number;
/* 52 */     double index = 1.0E18D;
/*    */     
/*    */ 
/* 55 */     if (1.0E18D < number) { throw new NumberToLetterConvertionException("El mayor número que puede convertirse es 999, 999, 999, 999.999");
/*    */     }
/* 57 */     while (index > 1.0D) {
/* 58 */       index /= 1000.0D;
/*    */       
/* 60 */       double a = b / index;
/* 61 */       b %= index;
/*    */       
/* 63 */       String formatedTriad = convertTriad((int)a);
/*    */       String posfix;
/* 65 */       String posfix; if (index == 1.0E15D) { posfix = "MIL "; } else { String posfix;
/* 66 */         if (index == 1.0E12D) { posfix = ((int)a == 1 ? "MILLÓN" : "MILLONES") + " DE MILLONES "; } else { String posfix;
/* 67 */           if (index == 1.0E9D) { posfix = "MIL "; } else { String posfix;
/* 68 */             if (index == 1000000.0D) { posfix = (int)a == 1 ? "MILLÓN " : "MILLONES "; } else { String posfix;
/* 69 */               if (index == 1000.0D) posfix = "MIL "; else
/* 70 */                 posfix = "";
/*    */             } } } }
/* 72 */       letter.append(formatedTriad + posfix);
/*    */     }
/*    */     
/* 75 */     return letter.toString();
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws NumberToLetterConvertionException {
/* 79 */     NumberToLetterConverter ntlc = new SpanishNTLConverter();
/* 80 */     double t = 139.0D;
/* 81 */     System.out.println(ntlc.convertNumberToLetter(t));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\commons\SpanishNTLConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */