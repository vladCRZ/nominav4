/*     */ package com.softcoatl.context.services;
/*     */ 
/*     */ import com.infomedia.context.APPContext;
/*     */ import com.softcoatl.integration.Service;
/*     */ import com.softcoatl.integration.ServiceLocator;
/*     */ import java.sql.SQLException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.dbcp.BasicDataSource;
/*     */ import org.apache.commons.dbcp.BasicDataSourceFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataBaseService
/*     */   implements Service
/*     */ {
/*     */   public static final String DOT = ".";
/*     */   public static final String DBS_PREFIX = "database";
/*     */   public static final String DBS_PPRTY_DRV = "driverClassName";
/*     */   public static final String DBS_PPRTY_URL = "url";
/*     */   public static final String DBS_PPRTY_USR = "username";
/*     */   public static final String DBS_PPRTY_PWD = "password";
/*     */   public static final String DBS_PPRTY_VALIDATION_QUERY = "validationQuery";
/*     */   public static final String DBS_PPRTY_TEST_WHILE_IDLE = "testWhileIdle";
/*     */   public static final String DBS_PPRTY_TEST_ON_BORROW = "testOnBorrow";
/*     */   public static final String DBS_PPRTY_REMOVE_ABANDONED_TIMEOUT = "removeAbandonedTimeout";
/*     */   public static final String DBS_PPRTY_REMOVE_ABANDONED = "removeAbandoned";
/*     */   public static final String DBS_PPRTY_LOG_ABANDONED = "logAbandoned";
/*     */   public static final String DBS_PPRTY_TIME_BETWEEN_EVICTION_RUNS_MILLIS = "timeBetweenEvictionRunsMillis";
/*     */   public static final String DBS_PPRTY_MIN_EVICTABLE_IDLE_TIME_MILLIS = "minEvictableIdleTimeMillis";
/*     */   public static final String DBS_PPRTY_MAX_AGE = "maxAge";
/*     */   public static final String DBS_PPRTY_VALIDATION_INTERVAL = "validationInterval";
/*     */   
/*     */   public static String getPropertyName(String psServiceName, String psPropertyName)
/*     */   {
/*  53 */     return "database." + psServiceName + "." + psPropertyName;
/*     */   }
/*     */   
/*     */   public static synchronized DataSource getDataSource(String psServiceName) {
/*  57 */     return (DataSource)ServiceLocator.getInstance().getService(psServiceName);
/*     */   }
/*     */   
/*     */   public String getPropertyStandarName(String psServiceName, String psPropertyName) {
/*  61 */     return getPropertyName(psServiceName, psPropertyName);
/*     */   }
/*     */   
/*     */   private StringRefAddr newReference(String serviceName, String propertie) {
/*  65 */     return new StringRefAddr(propertie, APPContext.getInitParameter(getPropertyStandarName(serviceName, propertie)));
/*     */   }
/*     */   
/*     */   public Reference getReference(String psServiceName) {
/*  69 */     Reference voDataBaseReference = new Reference("javax.sql.DataSource", BasicDataSourceFactory.class.getName(), null);
/*     */     
/*  71 */     voDataBaseReference.add(newReference(psServiceName, "driverClassName"));
/*  72 */     voDataBaseReference.add(newReference(psServiceName, "url"));
/*  73 */     voDataBaseReference.add(newReference(psServiceName, "username"));
/*  74 */     voDataBaseReference.add(newReference(psServiceName, "password"));
/*     */     
/*  76 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "validationQuery"))) {
/*  77 */       voDataBaseReference.add(newReference(psServiceName, "validationQuery"));
/*     */     }
/*  79 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "testWhileIdle"))) {
/*  80 */       voDataBaseReference.add(newReference(psServiceName, "testWhileIdle"));
/*     */     }
/*  82 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "testOnBorrow"))) {
/*  83 */       voDataBaseReference.add(newReference(psServiceName, "testOnBorrow"));
/*     */     }
/*  85 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "removeAbandonedTimeout"))) {
/*  86 */       voDataBaseReference.add(newReference(psServiceName, "validationQuery"));
/*     */     }
/*  88 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "removeAbandoned"))) {
/*  89 */       voDataBaseReference.add(newReference(psServiceName, "removeAbandoned"));
/*     */     }
/*  91 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "logAbandoned"))) {
/*  92 */       voDataBaseReference.add(newReference(psServiceName, "logAbandoned"));
/*     */     }
/*  94 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "timeBetweenEvictionRunsMillis"))) {
/*  95 */       voDataBaseReference.add(newReference(psServiceName, "timeBetweenEvictionRunsMillis"));
/*     */     }
/*  97 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "minEvictableIdleTimeMillis"))) {
/*  98 */       voDataBaseReference.add(newReference(psServiceName, "minEvictableIdleTimeMillis"));
/*     */     }
/* 100 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "maxAge"))) {
/* 101 */       voDataBaseReference.add(newReference(psServiceName, "maxAge"));
/*     */     }
/* 103 */     if (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "validationInterval"))) {
/* 104 */       voDataBaseReference.add(newReference(psServiceName, "validationQuery"));
/*     */     }
/* 106 */     return voDataBaseReference;
/*     */   }
/*     */   
/*     */   public boolean isDefined(String psServiceName) {
/* 110 */     return (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "driverClassName"))) && (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "url"))) && (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "username"))) && (APPContext.hasInitParameter(getPropertyStandarName(psServiceName, "password")));
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean endService(String psReferenceName)
/*     */   {
/*     */     try
/*     */     {
/* 118 */       ((BasicDataSource)getDataSource(psReferenceName)).close();
/* 119 */       return true;
/*     */     } catch (SQLException SQLE) {
/* 121 */       Logger.getRootLogger().error(SQLE);
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\context\services\DataBaseService.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */