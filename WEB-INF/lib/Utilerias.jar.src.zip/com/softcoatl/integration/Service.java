package com.softcoatl.integration;

import javax.naming.Reference;

public abstract interface Service
{
  public abstract Reference getReference(String paramString);
  
  public abstract String getPropertyStandarName(String paramString1, String paramString2);
  
  public abstract boolean isDefined(String paramString);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\integration\Service.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */