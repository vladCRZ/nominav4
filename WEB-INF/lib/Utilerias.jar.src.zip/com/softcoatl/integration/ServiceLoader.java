/*    */ package com.softcoatl.integration;
/*    */ 
/*    */ import com.infomedia.context.APPContext;
/*    */ import com.infomedia.context.WEBServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceLoader
/*    */ {
/*    */   public static String getInitParameterName(String psPrefix, String psParameterName)
/*    */   {
/* 19 */     return psPrefix + "." + psParameterName.trim();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void loadService(Class<?> poClass, String psName, String psLookup)
/*    */     throws Exception
/*    */   {
/* 38 */     Service voService = null;
/* 39 */     if (WEBServletContext.isInitialized()) throw new Exception("Can´t load a new service in a WEBAPP context");
/* 40 */     unloadService(psName);
/* 41 */     voService = ServiceFactory.create(poClass);
/* 42 */     if (!voService.isDefined(psName)) throw new Exception("Can´t load service " + psName + " cause " + poClass.getName() + " parameters are not defined in this context");
/* 43 */     APPContext.addReference(psLookup, voService.getReference(psName));
/* 44 */     APPContext.setInitParameter(psName, psLookup);
/*    */   }
/*    */   
/* 47 */   public static void loadService(String psClass, String psName, String psLookup) throws Exception { loadService(Class.forName(psClass), psName, psLookup); }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static void unloadService(String psName)
/*    */     throws Exception
/*    */   {
/* 61 */     if (APPContext.hasInitParameter(psName)) ServiceLocator.getInstance().removeService(psName);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\integration\ServiceLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */