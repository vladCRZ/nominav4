/*     */ package com.softcoatl.integration;
/*     */ 
/*     */ import com.infomedia.context.APPContext;
/*     */ import com.infomedia.context.WEBServletContext;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceLocator
/*     */ {
/*  26 */   private static final ServiceLocator INSTANCE = new ServiceLocator();
/*     */   
/*  28 */   private Context goContext = null;
/*  29 */   private Map<String, Object> goServices = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ServiceLocator()
/*     */   {
/*     */     try
/*     */     {
/*  41 */       if (isWEBApp()) this.goContext = new InitialContext(); else
/*  42 */         this.goContext = APPContext.getInstance().getContext();
/*     */     } catch (Exception voIgnorar) {}
/*  44 */     this.goServices = Collections.synchronizedMap(new HashMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServiceLocator getInstance()
/*     */   {
/*  56 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isWEBApp()
/*     */   {
/*  67 */     return WEBServletContext.isInitialized();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSource getDataSource(String psDataSourceName)
/*     */   {
/*  80 */     return (DataSource)getService(psDataSourceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getService(String psService)
/*     */   {
/*  94 */     Object voService = null;
/*  95 */     String vsServiceName = isWEBApp() ? WEBServletContext.getInitParameter(psService) : APPContext.getInitParameter(psService);
/*     */     try
/*     */     {
/*  98 */       if (this.goServices.containsKey(vsServiceName)) {
/*  99 */         voService = this.goServices.get(vsServiceName);
/*     */       } else {
/* 101 */         voService = this.goContext.lookup(vsServiceName);
/* 102 */         this.goServices.put(vsServiceName, voService);
/*     */       }
/*     */     } catch (NamingException voEXC) {
/* 105 */       voEXC.printStackTrace();
/*     */     }
/*     */     
/* 108 */     return voService;
/*     */   }
/*     */   
/*     */   protected void removeService(String psService) throws NamingException {
/* 112 */     if (this.goServices.containsKey(psService)) this.goContext.unbind(psService);
/* 113 */     this.goServices.remove(psService);
/*     */   }
/*     */   
/*     */   public static Context getContext() {
/* 117 */     return INSTANCE.goContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\integration\ServiceLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */