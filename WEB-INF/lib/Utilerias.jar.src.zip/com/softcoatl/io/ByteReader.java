/*    */ package com.softcoatl.io;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteReader
/*    */ {
/*    */   public static byte[] readBytes(InputStream poInput)
/*    */     throws IOException
/*    */   {
/* 24 */     BufferedInputStream voBIS = new BufferedInputStream(poInput);
/* 25 */     ByteArrayOutputStream voBAOS = new ByteArrayOutputStream();
/* 26 */     byte[] readingBuffer = new byte['Ѐ'];
/* 27 */     int viReaded = 0;
/* 28 */     while ((viReaded = voBIS.read(readingBuffer)) != -1) {
/* 29 */       voBAOS.write(readingBuffer, 0, viReaded);
/*    */     }
/* 31 */     return voBAOS.toByteArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\io\ByteReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */