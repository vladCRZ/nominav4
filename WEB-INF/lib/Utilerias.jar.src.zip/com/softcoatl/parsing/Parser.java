package com.softcoatl.parsing;

import com.infomedia.utils.DinamicVO;
import java.io.InputStream;
import java.util.List;

public abstract interface Parser
{
  public abstract List<DinamicVO> parse(InputStream paramInputStream);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\parsing\Parser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */