/*     */ package com.softcoatl.project.parsing;
/*     */ 
/*     */ import com.infomedia.utils.DateUtils;
/*     */ import com.infomedia.utils.DinamicVO;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.sf.mpxj.Duration;
/*     */ import net.sf.mpxj.ProjectHeader;
/*     */ import net.sf.mpxj.Relation;
/*     */ import net.sf.mpxj.Resource;
/*     */ import net.sf.mpxj.ResourceAssignment;
/*     */ import net.sf.mpxj.Task;
/*     */ import net.sf.mpxj.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PRJTaskVO
/*     */   extends DinamicVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String TASK_ID = "ID";
/*     */   public static final String TASK_NAME = "NAME";
/*     */   public static final String TASK_DURATION = "DURATION";
/*     */   public static final String TASK_COMPLETE = "COMPLETE";
/*     */   public static final String TASK_START = "INI";
/*     */   public static final String TASK_FINISH = "END";
/*     */   public static final String TASK_PARENT = "PARENT";
/*     */   public static final String TASK_SOURCE = "SOURCE";
/*     */   public static final String TASK_TAGET = "TARGET";
/*     */   public static final String TASK_RESOURCE = "RESOURCE";
/*     */   
/*  55 */   public String getTaskID() { return NVL("ID"); }
/*  56 */   public String getName() { return NVL("NAME"); }
/*  57 */   public String getStart() { return NVL("INI"); }
/*  58 */   public String getFinish() { return NVL("END"); }
/*  59 */   public String getParentTask() { return NVL("PARENT"); }
/*  60 */   public String getSourceTask() { return NVL("SOURCE"); }
/*  61 */   public String getTargetTask() { return NVL("TARGET"); }
/*  62 */   public String getResource() { return NVL("RESOURCE"); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DinamicVO parse(Task poTask, ProjectHeader poHeader)
/*     */   {
/*  76 */     DinamicVO voTask = new PRJTaskVO();
/*     */     
/*  78 */     voTask.setCampo("ID", String.valueOf(poTask.getID()));
/*  79 */     voTask.setCampo("NAME", poTask.getName());
/*     */     
/*  81 */     if (poTask.getStart() != null) voTask.setCampo("INI", DateUtils.fncsFormat("dd/MM/yyyy HH:mm", DateUtils.fncoCalendar(poTask.getStart().getTime())));
/*  82 */     if (poTask.getFinish() != null) { voTask.setCampo("END", DateUtils.fncsFormat("dd/MM/yyyy HH:mm", DateUtils.fncoCalendar(poTask.getFinish().getTime())));
/*     */     }
/*  84 */     if (poTask.getResourceAssignments() != null) {
/*  85 */       for (ResourceAssignment voResourceAssignment : poTask.getResourceAssignments()) {
/*  86 */         if (voResourceAssignment.getResource() != null) { voTask.setCampo("RESOURCE", voResourceAssignment.getResource().getName());
/*     */         }
/*     */       }
/*     */     }
/*  90 */     if (poTask.getParentTask() != null) voTask.setCampo("PARENT", String.valueOf(poTask.getParentTask().getID()));
/*  91 */     voTask.setCampo("COMPLETE", poTask.getPercentageComplete() == null ? "0.0" : String.valueOf(poTask.getPercentageComplete().doubleValue()));
/*  92 */     voTask.setCampo("DURATION", poTask.getDuration() == null ? "0.0" : String.valueOf(poTask.getDuration().convertUnits(TimeUnit.HOURS, poHeader).getDuration()));
/*     */     
/*  94 */     if (poTask.getPredecessors() != null) { Relation voRelation;
/*  95 */       for (Iterator i$ = poTask.getPredecessors().iterator(); i$.hasNext(); 
/*     */           
/*  97 */           voTask.setCampo("SOURCE", String.valueOf(voRelation.getSourceTask().getID())))
/*     */       {
/*  95 */         voRelation = (Relation)i$.next();
/*  96 */         if ((voRelation != null) && (voRelation.getTargetTask() != null)) voTask.setCampo("TARGET", String.valueOf(voRelation.getTargetTask().getID()));
/*  97 */         if ((voRelation == null) || (voRelation.getSourceTask() == null)) {}
/*     */       }
/*     */     }
/*     */     
/* 101 */     return voTask;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\project\parsing\PRJTaskVO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */