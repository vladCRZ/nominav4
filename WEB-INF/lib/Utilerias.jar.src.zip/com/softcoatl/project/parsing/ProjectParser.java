/*    */ package com.softcoatl.project.parsing;
/*    */ 
/*    */ import com.infomedia.utils.DinamicVO;
/*    */ import com.softcoatl.parsing.Parser;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.sf.mpxj.MPXJException;
/*    */ import net.sf.mpxj.ProjectFile;
/*    */ import net.sf.mpxj.Task;
/*    */ import net.sf.mpxj.mpp.MPPReader;
/*    */ import net.sf.mpxj.reader.ProjectReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProjectParser
/*    */   implements Parser
/*    */ {
/*    */   public static ProjectParser newInstance()
/*    */   {
/* 40 */     return new ProjectParser();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<DinamicVO> parse(InputStream poInput)
/*    */   {
/* 67 */     List<DinamicVO> voTaskItems = new ArrayList();
/* 68 */     ProjectReader voReader = new MPPReader();
/* 69 */     ProjectFile voProject = null;
/*    */     try
/*    */     {
/* 72 */       voProject = voReader.read(poInput);
/* 73 */       Task voTask; for (Iterator i$ = voProject.getAllTasks().iterator(); i$.hasNext(); voTaskItems.add(PRJTaskVO.parse(voTask, voProject.getProjectHeader()))) voTask = (Task)i$.next();
/*    */     } catch (MPXJException poEXC) {
/* 75 */       poEXC.printStackTrace();
/*    */     }
/* 77 */     return voTaskItems;
/*    */   }
/*    */   
/*    */   public static void main(String[] psParametros) throws FileNotFoundException {
/* 81 */     for (DinamicVO voTask : newInstance().parse(new FileInputStream(new File("C:\\Users\\Rolando\\Documents\\Workspace3.5\\Remedy", "Plan de Trabajo RM.mpp")))) {
/* 82 */       System.out.println(voTask);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\project\parsing\ProjectParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */