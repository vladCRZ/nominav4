/*    */ package com.softcoatl.ss.parser;
/*    */ 
/*    */ import com.infomedia.utils.ss.WorkBook;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSVParser
/*    */   implements SSParser
/*    */ {
/* 27 */   private CSVReader goReader = new CSVReader();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static CSVParser getInstance()
/*    */   {
/* 38 */     return new CSVParser();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WorkBook parse(InputStream poInput)
/*    */     throws Exception
/*    */   {
/* 55 */     WorkBook voWorkBook = new WorkBook();
/* 56 */     voWorkBook.addSpreadSheet(this.goReader.read(poInput));
/* 57 */     return voWorkBook;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\ss\parser\CSVParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */