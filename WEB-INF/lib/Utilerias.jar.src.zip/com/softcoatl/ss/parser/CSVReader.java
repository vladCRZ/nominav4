/*     */ package com.softcoatl.ss.parser;
/*     */ 
/*     */ import com.infomedia.utils.ss.Cell;
/*     */ import com.infomedia.utils.ss.CellPosition;
/*     */ import com.infomedia.utils.ss.SpreadSheet;
/*     */ import com.softcoatl.io.ByteReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSVReader
/*     */ {
/*     */   public SpreadSheet separateCSVCells(String psCSVString)
/*     */   {
/*  46 */     SpreadSheet voSpredSheet = new SpreadSheet("DEFAULT");
/*  47 */     StringTokenizer voCommaTokens = new StringTokenizer(psCSVString, ",", true);
/*  48 */     StringTokenizer voNLTokens = null;
/*     */     
/*  50 */     CSVValue voValue = new CSVValue();
/*  51 */     String vsCommaToken = "";
/*  52 */     String vsNLToken = "";
/*     */     
/*  54 */     int viRowIndex = 0;
/*  55 */     int viColIndex = 0;
/*     */     
/*  57 */     boolean vbNewLine = false;
/*     */     
/*  59 */     while (voCommaTokens.hasMoreTokens()) {
/*  60 */       vsCommaToken = voCommaTokens.nextToken();
/*  61 */       voNLTokens = new StringTokenizer(vsCommaToken, "\n", true);
/*  62 */       while (voNLTokens.hasMoreTokens()) {
/*  63 */         vsNLToken = voNLTokens.nextToken();
/*  64 */         vsNLToken = vsNLToken.replaceAll("\r", "");
/*  65 */         if (vsNLToken.equals("\n")) {
/*  66 */           if (voValue.needsLastSeparator()) voValue.addValue(",");
/*  67 */           vbNewLine = true;
/*     */         }
/*     */         
/*  70 */         if (voValue.isComplete()) {
/*  71 */           voSpredSheet.setCell(new CellPosition(viColIndex, viRowIndex), new Cell(voValue.toString()));
/*  72 */           voValue = new CSVValue();
/*  73 */           viColIndex++;
/*     */         }
/*  75 */         if (!vbNewLine) {
/*  76 */           if (voValue.isVoid()) voValue.addValue(",");
/*  77 */           voValue.addValue(vsNLToken);
/*     */         } else {
/*  79 */           vbNewLine = false;
/*  80 */           viColIndex = 0;
/*  81 */           viRowIndex++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  86 */     return voSpredSheet;
/*     */   }
/*     */   
/*     */   public SpreadSheet read(InputStream poInput) throws IOException {
/*  90 */     return separateCSVCells(new String(ByteReader.readBytes(poInput)));
/*     */   }
/*     */   
/*     */   public SpreadSheet read(StringBuffer poInput) {
/*  94 */     return separateCSVCells(poInput.toString());
/*     */   }
/*     */   
/*     */   public SpreadSheet read(String psInput) {
/*  98 */     return separateCSVCells(psInput);
/*     */   }
/*     */   
/*     */   public SpreadSheet readFile(String psFileName) throws FileNotFoundException, IOException {
/* 102 */     return read(new FileInputStream(psFileName));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\ss\parser\CSVReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */