/*     */ package com.softcoatl.ss.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSVValue
/*     */ {
/*     */   public static final String SEPARATOR = ",";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String QUOTATION = "\"";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String NEWLINE = "\n";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String CR = "\r";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String INNER_QUOT_BEGIN = "";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String INNER_QUOT_END = "";
/*     */   
/*     */ 
/*  31 */   StringBuffer gsValue = new StringBuffer();
/*  32 */   boolean isQuotatedValue = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  45 */     return this.isQuotatedValue ? this.gsValue.toString().replaceAll(",\"", "").replaceAll("\",", "") : this.gsValue.toString().replace(",", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValue(String psValue)
/*     */   {
/*  60 */     if (this.gsValue.toString().equals(","))
/*  61 */       this.isQuotatedValue = psValue.startsWith("\"");
/*  62 */     this.gsValue.append(psValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isComplete()
/*     */   {
/*  75 */     return (this.gsValue.toString().startsWith(",\"")) && (this.gsValue.toString().endsWith("\","));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean needsLastSeparator()
/*     */   {
/*  88 */     return this.isQuotatedValue ? false : (this.gsValue.toString().startsWith(",\"")) && (this.gsValue.toString().endsWith("\"")) ? true : this.gsValue.toString().startsWith(",");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 102 */     return this.gsValue.length() == 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoatl\ss\parser\CSVValue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */