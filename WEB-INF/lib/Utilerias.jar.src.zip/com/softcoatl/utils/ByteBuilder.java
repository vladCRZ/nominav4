/*    */ package com.softcoatl.utils;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteBuilder
/*    */   extends ByteArrayOutputStream
/*    */ {
/*    */   public ByteBuilder() {}
/*    */   
/*    */   public ByteBuilder(byte[] data)
/*    */   {
/* 25 */     this();
/* 26 */     init(data);
/*    */   }
/*    */   
/*    */   private void init(byte[] data) {
/* 30 */     try { write(data);
/*    */     } catch (IOException ex) {}
/*    */   }
/*    */   
/*    */   public ByteBuilder append(byte[] data) {
/* 35 */     if (null != data) {
/*    */       try {
/* 37 */         write(data);
/*    */       } catch (IOException ex) {}
/*    */     }
/* 40 */     return this;
/*    */   }
/*    */   
/*    */   public ByteBuilder append(byte b) {
/* 44 */     write(b);
/* 45 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\ByteBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */