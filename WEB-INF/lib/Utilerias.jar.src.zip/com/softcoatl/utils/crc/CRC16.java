/*    */ package com.softcoatl.utils.crc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRC16
/*    */ {
/*    */   public static enum TYPE
/*    */   {
/* 19 */     HEX, 
/* 20 */     BIN;
/*    */     
/*    */     private TYPE() {} }
/* 23 */   public static enum ALG { CRC_16, 
/* 24 */     CRC_16_MODBUS, 
/* 25 */     CRC_DNP, 
/* 26 */     CRC_SICK, 
/* 27 */     CRC_CCITT_0000, 
/* 28 */     CRC_CCITT_FFFF, 
/* 29 */     CRC_CCITT_1D0F, 
/* 30 */     CRC_KERMIT;
/*    */     
/*    */     private ALG() {} }
/* 33 */   private int getInitValue(ALG algorithm) throws CRCException { switch (algorithm) {
/* 34 */     case CRC_16:  return 0;
/* 35 */     case CRC_16_MODBUS:  return 65535;
/* 36 */     case CRC_DNP:  return 0;
/* 37 */     case CRC_SICK:  return 0;
/* 38 */     case CRC_CCITT_0000:  return 0;
/* 39 */     case CRC_CCITT_FFFF:  return 65535;
/* 40 */     case CRC_CCITT_1D0F:  return 7664;
/* 41 */     case CRC_KERMIT:  return 0; }
/* 42 */     throw new CRCException("Unknown algorithm " + algorithm.name());
/*    */   }
/*    */   
/*    */   private int getPolynomial(ALG algorithm) throws CRCException {
/* 46 */     switch (algorithm) {
/*    */     case CRC_16: case CRC_16_MODBUS: 
/* 48 */       return 40961;
/* 49 */     case CRC_DNP:  return 42684;
/* 50 */     case CRC_SICK:  return 32773;
/* 51 */     case CRC_KERMIT:  return 33800;
/*    */     case CRC_CCITT_0000: case CRC_CCITT_FFFF: 
/*    */     case CRC_CCITT_1D0F: 
/* 54 */       return 4129; }
/* 55 */     throw new CRCException("Unknown algorithm " + algorithm.name());
/*    */   }
/*    */   
/*    */   public int calculate(int current, int polynomial, byte b) {
/* 59 */     int crc = current;
/* 60 */     for (int j = 0; j < 8; j++) {
/* 61 */       boolean bit = (b >> 7 - j & 0x1) == 1;
/* 62 */       boolean c15 = (crc >> 15 & 0x1) == 1;
/* 63 */       crc <<= 1;
/* 64 */       if ((c15 ^ bit)) {
/* 65 */         crc ^= polynomial;
/*    */       }
/*    */     }
/* 68 */     crc &= 0xFFFF;
/* 69 */     return crc;
/*    */   }
/*    */   
/* 72 */   public int calculate(TYPE type, ALG algorithm, byte[] input, int offset, int length) throws CRCException { int crc = getInitValue(algorithm);
/* 73 */     int polynomial = getPolynomial(algorithm);
/*    */     
/*    */ 
/* 76 */     for (int i = offset; i < (length == 0 ? input.length : length); i++) {
/* 77 */       crc = calculate(crc, polynomial, input[i]);
/*    */     }
/*    */     
/* 80 */     return crc;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\crc\CRC16.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */