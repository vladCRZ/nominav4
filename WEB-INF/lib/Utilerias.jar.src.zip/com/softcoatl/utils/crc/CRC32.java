/*    */ package com.softcoatl.utils.crc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRC32
/*    */ {
/*    */   public int calculate(byte[] input, int offset, int length)
/*    */   {
/* 20 */     int crc = -1;
/* 21 */     int poly = -306674912;
/*    */     
/* 23 */     for (int i = offset; i < length; i++) {
/* 24 */       int temp = (crc ^ input[i]) & 0xFF;
/*    */       
/* 26 */       for (int j = 0; j < 8; j++) {
/* 27 */         if ((temp & 0x1) == 1) temp = temp >>> 1 ^ poly; else
/* 28 */           temp >>>= 1;
/*    */       }
/* 30 */       crc = crc >>> 8 ^ temp;
/*    */     }
/*    */     
/*    */ 
/* 34 */     return crc ^ 0xFFFFFFFF;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\crc\CRC32.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */