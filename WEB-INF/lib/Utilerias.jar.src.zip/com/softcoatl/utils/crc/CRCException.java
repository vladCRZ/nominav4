/*    */ package com.softcoatl.utils.crc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRCException
/*    */   extends Throwable
/*    */ {
/*    */   public CRCException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CRCException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */   
/*    */   public CRCException(Throwable cause) {
/* 28 */     super(cause);
/*    */   }
/*    */   
/*    */   public CRCException(String message, Throwable cause) {
/* 32 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\crc\CRCException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */