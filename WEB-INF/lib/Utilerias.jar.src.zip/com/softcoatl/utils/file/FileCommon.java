/*     */ package com.softcoatl.utils.file;
/*     */ 
/*     */ import com.infomedia.utils.DateUtils;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.softcoatl.utils.file.filter.TypeFileFilter;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileCommon
/*     */ {
/*  29 */   private static final Logger log = Logger.getLogger(FileCommon.class);
/*     */   
/*     */ 
/*     */   public static final String ALL_FILES = ".*";
/*     */   
/*     */ 
/*     */   public static final String CURRENT = ".";
/*     */   
/*     */ 
/*     */   public static final String PARENT = "..";
/*     */   
/*     */ 
/*     */   public static final int FLAG_ALL = 0;
/*     */   
/*     */ 
/*     */   public static final int FLAG_FIL = 1;
/*     */   
/*     */ 
/*     */   public static final int FLAG_DIR = 2;
/*     */   
/*     */ 
/*     */   public static String getUserHome()
/*     */   {
/*  52 */     return System.getProperty("user.home", ".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean directoryExists(String psDirectory, boolean create)
/*     */     throws Exception
/*     */   {
/*  62 */     File voDir = new File(psDirectory);
/*     */     
/*  64 */     if (!voDir.exists()) {
/*  65 */       if (!create) {
/*  66 */         return false;
/*     */       }
/*  68 */       voDir.mkdirs();
/*     */     }
/*     */     
/*  71 */     return voDir.isDirectory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean exists(String name)
/*     */   {
/*  79 */     return (!StringUtils.isNVL(name)) && (new File(name).exists());
/*     */   }
/*     */   
/*     */   public static Calendar getModifiedDateAsCalendar(File poArchivo) {
/*  83 */     return DateUtils.fncoCalendar(poArchivo.lastModified());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String saveFile(String parentPath, String fileName, byte[] content)
/*     */     throws Exception
/*     */   {
/*  94 */     FileOutputStream fos = null;
/*     */     
/*     */     try
/*     */     {
/*  98 */       if (directoryExists(parentPath, true)) {
/*  99 */         File file = new File(parentPath, fileName);
/* 100 */         fos = new FileOutputStream(file);
/* 101 */         fos.write(content);
/* 102 */         fos.flush();
/* 103 */         return file.getAbsolutePath();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */       return null;
/*     */     }
/*     */     catch (IOException IOE)
/*     */     {
/* 106 */       log.error(IOE);
/* 107 */       throw IOE;
/*     */     } finally {
/*     */       try {
/* 110 */         if (null != fos) {
/* 111 */           fos.close();
/*     */         }
/*     */       } catch (IOException ignore) {
/* 114 */         log.error(ignore);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void delete(File deleted)
/*     */   {
/* 124 */     if (deleted.exists()) {
/* 125 */       deleted.delete();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void delete(String deleted) {
/* 130 */     delete(new File(deleted));
/*     */   }
/*     */   
/*     */   public static void delete(String parentPath, String fileName) {
/* 134 */     delete(new File(parentPath, fileName));
/*     */   }
/*     */   
/*     */   public static void rename(File from, File to) {
/* 138 */     if (from.exists()) {
/* 139 */       from.renameTo(to);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void rename(String fromPath, String from, String toPath, String to) throws Exception {
/* 144 */     if ((directoryExists(fromPath, false)) && (directoryExists(toPath, true))) {
/* 145 */       rename(new File(fromPath, from), new File(toPath, to));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void rename(String path, String from, String to) throws Exception {
/* 150 */     rename(path, from, path, to);
/*     */   }
/*     */   
/*     */   public static void rename(String from, String to) throws Exception {
/* 154 */     rename(".", from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void recursiveDeletion(Iterable<File> fileList)
/*     */     throws Exception
/*     */   {
/* 162 */     for (File file : fileList) {
/* 163 */       if (file.isDirectory()) {
/* 164 */         recursiveDeletion(Arrays.asList(file.listFiles()));
/*     */       }
/* 166 */       delete(file);
/*     */     }
/*     */   }
/*     */   
/*     */   public static List<File> listFiles(File directory, FileFilter fileFilter) throws Exception {
/* 171 */     List<File> voRetorno = new ArrayList();
/* 172 */     if ((directory.exists()) && (directory.isDirectory())) {
/* 173 */       voRetorno.addAll(Arrays.asList(directory.listFiles(fileFilter)));
/*     */     }
/* 175 */     return voRetorno;
/*     */   }
/*     */   
/*     */   public static List<File> listFiles(String psDirectorio, FileFilter fileFilter) throws Exception {
/* 179 */     return listFiles(new File(psDirectorio), fileFilter);
/*     */   }
/*     */   
/*     */   public static List<String> listNames(String directory, FileFilter fileFilter, boolean absolute) throws Exception {
/* 183 */     List<String> voRetorno = new ArrayList();
/*     */     try
/*     */     {
/* 186 */       for (File voFile : listFiles(directory, fileFilter)) {
/* 187 */         voRetorno.add(absolute ? voFile.getAbsolutePath() : voFile.getName());
/*     */       }
/*     */     } catch (Exception EXC) {
/* 190 */       log.error(EXC);
/* 191 */       throw EXC;
/*     */     }
/* 193 */     return voRetorno;
/*     */   }
/*     */   
/*     */   public static List<String> listNames(String directory, FileFilter fileFilter) throws Exception {
/* 197 */     return listNames(directory, fileFilter, false);
/*     */   }
/*     */   
/*     */   public static List<String> listNames(String directory) throws Exception {
/* 201 */     return listNames(".", null);
/*     */   }
/*     */   
/*     */   public static List<String> listNames() throws Exception {
/* 205 */     return listNames(".");
/*     */   }
/*     */   
/*     */   public static List<String> listDirectories(String directory, boolean pbAbsolute) throws Exception {
/* 209 */     TypeFileFilter fileFilter = new TypeFileFilter();
/* 210 */     fileFilter.setType(2);
/* 211 */     return listNames(directory, fileFilter, pbAbsolute);
/*     */   }
/*     */   
/*     */   public static List<String> listDirectories(boolean pbAbsolute) throws Exception {
/* 215 */     return listDirectories(".", pbAbsolute);
/*     */   }
/*     */   
/*     */   public static List<String> listDirectories(String psDirectorio) throws Exception {
/* 219 */     return listDirectories(psDirectorio, false);
/*     */   }
/*     */   
/*     */   public static List<String> listDirectories() throws Exception {
/* 223 */     return listDirectories(".");
/*     */   }
/*     */   
/*     */   public static int fileSize(File poArchivo) {
/* 227 */     InputStream voInput = null;
/* 228 */     viRetorno = 0;
/*     */     try
/*     */     {
/* 231 */       if ((poArchivo.exists()) && (poArchivo.isFile()))
/* 232 */         voInput = new FileInputStream(poArchivo);
/* 233 */       return voInput.available();
/*     */     }
/*     */     catch (IOException IOE) {
/* 236 */       log.error(IOE);
/*     */     } finally {
/* 238 */       if (voInput != null) {
/*     */         try {
/* 240 */           voInput.close();
/*     */         } catch (IOException ignore) {
/* 242 */           log.error(ignore);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static String fixSeparatorChar(String path)
/*     */   {
/* 251 */     return path.replaceAll("\\\\|/", File.pathSeparator);
/*     */   }
/*     */   
/*     */   public static String extractFileName(String absoluteName) {
/* 255 */     String name = fixSeparatorChar(absoluteName.trim());
/* 256 */     if (name.endsWith(File.pathSeparator)) {
/* 257 */       name = name.substring(0, name.length() - 1);
/*     */     }
/* 259 */     return new String(absoluteName.substring(name.lastIndexOf(File.pathSeparator) + 1));
/*     */   }
/*     */   
/*     */   public static String getCurrentPath() {
/* 263 */     return new File("").getAbsolutePath();
/*     */   }
/*     */   
/*     */   public static String loadFileAsResource(Object poCaller, String psResourceName) throws Exception {
/* 267 */     voSQL = new StringBuilder();
/* 268 */     BufferedReader voBR = null;
/* 269 */     String vsLine = "";
/*     */     try
/*     */     {
/* 272 */       voBR = new BufferedReader(new InputStreamReader(poCaller.getClass().getClassLoader().getResourceAsStream(psResourceName)));
/* 273 */       while (null != (vsLine = voBR.readLine())) {
/* 274 */         voSQL.append(vsLine);
/* 275 */         voSQL.append("\n");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 289 */       return voSQL.toString();
/*     */     }
/*     */     catch (IOException IOE)
/*     */     {
/* 278 */       log.error(IOE);
/* 279 */       throw IOE;
/*     */     } finally {
/*     */       try {
/* 282 */         if (null != voBR) {
/* 283 */           voBR.close();
/*     */         }
/*     */       } catch (IOException ignore) {
/* 286 */         log.error(ignore);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\FileCommon.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */