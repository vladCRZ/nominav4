package com.softcoatl.utils.file;

import java.io.FileFilter;
import java.io.InputStream;
import java.util.Calendar;
import java.util.List;

public abstract interface FileMannager
{
  public static final String ALL_FILES = ".*";
  public static final String CURRENT = ".";
  public static final String PARENT = "..";
  public static final int FLAG_ALL = 0;
  public static final int FLAG_FIL = 1;
  public static final int FLAG_DIR = 2;
  
  public abstract String getUserHome();
  
  public abstract void setUserHome(String paramString);
  
  public abstract String getCurrentPath();
  
  public abstract boolean changeDir(String paramString);
  
  public abstract boolean isDirectory(String paramString);
  
  public abstract boolean directoryExists(String paramString, boolean paramBoolean);
  
  public abstract boolean exists(String paramString);
  
  public abstract Calendar getModifiedDateAsCalendar(String paramString)
    throws FileMannagerException;
  
  public abstract int fileSize(String paramString1, String paramString2)
    throws FileMannagerException;
  
  public abstract String extractFileName(String paramString)
    throws FileMannagerException;
  
  public abstract String extractPath(String paramString)
    throws FileMannagerException;
  
  public abstract InputStream getInputStream(String paramString1, String paramString2)
    throws FileMannagerException;
  
  public abstract InputStream getInputStream(String paramString)
    throws FileMannagerException;
  
  public abstract byte[] readFile(String paramString1, String paramString2)
    throws FileMannagerException;
  
  public abstract byte[] readFile(String paramString)
    throws FileMannagerException;
  
  public abstract String saveFile(String paramString1, String paramString2, InputStream paramInputStream)
    throws FileMannagerException;
  
  public abstract String saveFile(String paramString1, String paramString2, byte[] paramArrayOfByte)
    throws FileMannagerException;
  
  public abstract boolean delete(String paramString1, String paramString2)
    throws FileMannagerException;
  
  public abstract boolean delete(String paramString)
    throws FileMannagerException;
  
  public abstract boolean rename(String paramString1, String paramString2, String paramString3, String paramString4)
    throws FileMannagerException;
  
  public abstract boolean rename(String paramString1, String paramString2, String paramString3)
    throws FileMannagerException;
  
  public abstract boolean rename(String paramString1, String paramString2)
    throws FileMannagerException;
  
  public abstract boolean recursiveDeletion(String paramString)
    throws FileMannagerException;
  
  public abstract List<String> listFiles(String paramString, boolean paramBoolean, FileFilter paramFileFilter)
    throws FileMannagerException;
  
  public abstract List<String> listFiles(String paramString, FileFilter paramFileFilter)
    throws FileMannagerException;
  
  public abstract List<String> listFiles(String paramString)
    throws FileMannagerException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\FileMannager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */