/*    */ package com.softcoatl.utils.file;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileMannagerException
/*    */   extends Throwable
/*    */ {
/*    */   public FileMannagerException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FileMannagerException(String message)
/*    */   {
/* 19 */     super(message);
/*    */   }
/*    */   
/* 22 */   public FileMannagerException(Throwable cause) { super(cause); }
/*    */   
/*    */   public FileMannagerException(String message, Throwable cause) {
/* 25 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\FileMannagerException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */