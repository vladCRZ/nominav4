/*    */ package com.softcoatl.utils.file;
/*    */ 
/*    */ import com.infomedia.utils.StringUtils;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class Shell
/*    */ {
/* 12 */   private static final Logger log = Logger.getLogger(Shell.class);
/*    */   
/* 14 */   private StringBuilder error = new StringBuilder();
/* 15 */   private StringBuilder result = new StringBuilder();
/*    */   
/*    */   private StringBuilder readStream(InputStream is)
/*    */     throws IOException
/*    */   {
/* 20 */     StringBuilder sb = new StringBuilder();
/* 21 */     BufferedReader br = new BufferedReader(new InputStreamReader(is));
/*    */     String line;
/* 23 */     while ((line = br.readLine()) != null) {
/* 24 */       if (sb.length() > 0) sb.append("\n");
/* 25 */       sb.append(line);
/*    */     }
/* 27 */     is.close();
/*    */     
/* 29 */     return sb;
/*    */   }
/*    */   
/* 32 */   public String error() { return this.error.toString(); }
/*    */   
/*    */   public String result() {
/* 35 */     return this.result.toString();
/*    */   }
/*    */   
/*    */   public void exec(String command) {
/* 39 */     Process process = null;
/*    */     try
/*    */     {
/* 42 */       this.error = new StringBuilder();
/* 43 */       this.result = new StringBuilder();
/* 44 */       if (!StringUtils.isNVL(command)) {
/* 45 */         Runtime rt = Runtime.getRuntime();
/* 46 */         process = rt.exec(command);
/* 47 */         process.waitFor();
/* 48 */         log.info("Command " + command + " executed with code " + process.exitValue());
/* 49 */         this.error.append(readStream(process.getErrorStream()));
/* 50 */         this.result.append(readStream(process.getInputStream()));
/*    */       }
/*    */     } catch (IOException E) {
/* 53 */       log.error(E);
/*    */     } catch (InterruptedException E) {
/* 55 */       log.error(E);
/*    */     } finally {
/* 57 */       if (null != process) {
/* 58 */         process.destroy();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\Shell.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */