/*    */ package com.softcoatl.utils.file.filter;
/*    */ 
/*    */ import com.infomedia.utils.DateUtils;
/*    */ import com.softcoatl.utils.file.FileCommon;
/*    */ import java.io.File;
/*    */ import java.util.Calendar;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateFileFilter
/*    */   extends FileFilterDecorator
/*    */ {
/* 20 */   private Calendar filterDate = null;
/* 21 */   private int filteringLevel = 6;
/*    */   
/*    */   public void setDate(Calendar date) {
/* 24 */     this.filterDate = date;
/*    */   }
/*    */   
/* 27 */   public Calendar getDate() { return this.filterDate; }
/*    */   
/*    */   public void setLevel(int level)
/*    */   {
/* 31 */     this.filteringLevel = level;
/*    */   }
/*    */   
/* 34 */   public int getLevel() { return this.filteringLevel; }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean customAccept(File file)
/*    */   {
/* 40 */     Calendar truncateDate = DateUtils.fncoTrucado(this.filterDate, this.filteringLevel);
/* 41 */     Calendar modifiedDate = DateUtils.fncoTrucado(FileCommon.getModifiedDateAsCalendar(file), this.filteringLevel);
/* 42 */     this.log.debug(file.getAbsolutePath());
/* 43 */     this.log.debug(DateUtils.fncsFormat("dd/MM/yyyy", truncateDate));
/* 44 */     this.log.debug(DateUtils.fncsFormat("dd/MM/yyyy", modifiedDate));
/* 45 */     this.log.debug(Long.valueOf(truncateDate.getTimeInMillis()));
/* 46 */     this.log.debug(Long.valueOf(modifiedDate.getTimeInMillis()));
/* 47 */     return ((isRecursive()) && (file.isDirectory())) || (DateUtils.fncbCompare(truncateDate, modifiedDate, 1));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\filter\DateFileFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */