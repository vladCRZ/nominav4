/*    */ package com.softcoatl.utils.file.filter;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileFilter;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FileFilterDecorator
/*    */   implements FileFilter
/*    */ {
/* 19 */   protected Logger log = Logger.getLogger(FileFilterDecorator.class);
/* 20 */   protected FileFilter fileFilterDelegate = null;
/* 21 */   protected boolean recursive = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setDelegate(FileFilter fileFilter)
/*    */   {
/* 28 */     this.fileFilterDelegate = fileFilter;
/*    */   }
/*    */   
/*    */   public void setRecursive(boolean flag) {
/* 32 */     this.recursive = flag;
/*    */   }
/*    */   
/* 35 */   public boolean isRecursive() { return this.recursive; }
/*    */   
/*    */   public abstract boolean customAccept(File paramFile);
/*    */   
/*    */   public boolean delegateAccept(File file) {
/* 40 */     return (null == this.fileFilterDelegate) || (this.fileFilterDelegate.accept(file));
/*    */   }
/*    */   
/*    */   public boolean accept(File file) {
/* 44 */     return (customAccept(file)) && (delegateAccept(file));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\filter\FileFilterDecorator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */