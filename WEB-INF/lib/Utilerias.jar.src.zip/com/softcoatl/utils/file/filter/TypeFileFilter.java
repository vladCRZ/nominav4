/*    */ package com.softcoatl.utils.file.filter;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeFileFilter
/*    */   extends FileFilterDecorator
/*    */ {
/*    */   public static final int FLAG_ALL = 0;
/*    */   public static final int FLAG_FIL = 1;
/*    */   public static final int FLAG_DIR = 2;
/* 21 */   private int fileType = 0;
/*    */   
/*    */   public void setType(int type) {
/* 24 */     this.fileType = type;
/*    */   }
/*    */   
/* 27 */   public int getType() { return this.fileType; }
/*    */   
/*    */ 
/*    */   public boolean customAccept(File file)
/*    */   {
/* 32 */     return (this.fileType == 0) || ((this.fileType == 1) && (file.isFile())) || ((this.fileType == 2) && (file.isDirectory()));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\file\filter\TypeFileFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */