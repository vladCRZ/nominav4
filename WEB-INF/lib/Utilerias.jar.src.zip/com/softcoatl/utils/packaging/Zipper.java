/*     */ package com.softcoatl.utils.packaging;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.softcoatl.utils.file.FileCommon;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public abstract class Zipper
/*     */ {
/*  22 */   private static final Logger log = Logger.getLogger(Zipper.class);
/*     */   public static final String EXTENSION = ".zip";
/*     */   
/*     */   private static boolean addToZip(ZipOutputStream zip, InputStream input, String name)
/*     */   {
/*  27 */     byte[] voBuffer = new byte['Ѐ'];
/*  28 */     int writed = 0;
/*     */     
/*     */     try
/*     */     {
/*  32 */       if ((null != input) && (input.available() > 0)) {
/*  33 */         zip.putNextEntry(new ZipEntry(name));
/*  34 */         int readed; while ((readed = input.read(voBuffer)) != -1) {
/*  35 */           zip.write(voBuffer, 0, readed);
/*  36 */           writed += readed;
/*     */         }
/*  38 */         zip.closeEntry();
/*     */       }
/*     */     } catch (IOException IOE) {
/*  41 */       log.error(IOE);
/*     */     }
/*  43 */     return 0 < writed;
/*     */   }
/*     */   
/*     */   private static boolean addFileToZip(ZipOutputStream zip, File file, String rootPath, boolean absolute) {
/*  47 */     FileInputStream fis = null;
/*     */     try
/*     */     {
/*  50 */       if (file.exists()) {
/*  51 */         fis = new FileInputStream(file);
/*  52 */         String zippedName = absolute ? file.getAbsolutePath() : file.getAbsolutePath().replaceAll(rootPath, "");
/*  53 */         addToZip(zip, fis, zippedName);
/*  54 */         return true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */       return false;
/*     */     }
/*     */     catch (FileNotFoundException FNFE)
/*     */     {
/*  57 */       log.error(FNFE);
/*     */     } finally {
/*  59 */       if (fis != null) {
/*  60 */         try { fis.close(); } catch (IOException IOE) { log.error(IOE);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static int addDirectoryToZip(ZipOutputStream zip, File directory, FileFilter fileFilter, String rootPath, boolean absolute) {
/*  67 */     int added = 0;
/*     */     try
/*     */     {
/*  70 */       if (directory.isDirectory()) {
/*  71 */         for (File file : directory.listFiles(fileFilter)) {
/*  72 */           log.debug(file.getAbsolutePath() + ". Existe? " + file.exists() + ". Directorio? " + file.isDirectory());
/*  73 */           if (file.exists()) {
/*  74 */             if (file.isDirectory()) {
/*  75 */               added += addDirectoryToZip(zip, file, fileFilter, rootPath, absolute);
/*  76 */             } else if (addFileToZip(zip, file, rootPath, absolute)) {
/*  77 */               added++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception EXC) {
/*  83 */       log.error(EXC);
/*     */     }
/*     */     
/*  86 */     return added;
/*     */   }
/*     */   
/*     */   private static void addVoidMessage(ZipOutputStream poZipOutput) {
/*  90 */     byte[] voSinInformacion = "No se encontraron archivos que coincidan con la búsqueda.".getBytes();
/*     */     try
/*     */     {
/*  93 */       poZipOutput.putNextEntry(new ZipEntry("ERROR.txt"));
/*  94 */       poZipOutput.write(voSinInformacion, 0, voSinInformacion.length);
/*  95 */       poZipOutput.closeEntry();
/*     */     } catch (IOException IOE) {
/*  97 */       log.error(IOE);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void zip(File[] fileList, FileFilter fileFilter, OutputStream output, String rootPath, boolean absolute) {
/* 102 */     ZipOutputStream zipOutput = null;
/* 103 */     int zipped = 0;
/*     */     try
/*     */     {
/* 106 */       zipOutput = new ZipOutputStream(output);
/* 107 */       for (File file : fileList) {
/* 108 */         log.debug(file.getAbsolutePath() + ". Existe? " + file.exists() + ". Directorio? " + file.isDirectory());
/* 109 */         if (file.exists()) {
/* 110 */           if (file.isDirectory()) {
/* 111 */             zipped += addDirectoryToZip(zipOutput, file, fileFilter, rootPath, absolute);
/* 112 */           } else if (addFileToZip(zipOutput, file, rootPath, absolute)) {
/* 113 */             zipped++;
/*     */           }
/*     */         }
/*     */       }
/* 117 */       if (zipped == 0)
/* 118 */         addVoidMessage(zipOutput);
/*     */       return;
/*     */     } catch (Exception EXC) {
/* 121 */       log.error(EXC);
/*     */     } finally {
/* 123 */       if (zipOutput != null) {
/*     */         try {
/* 125 */           zipOutput.close();
/*     */         } catch (IOException ignore) {
/* 127 */           log.error(ignore);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void zip(File[] fileList, FileFilter fileFilter, String rootPath, String zipName, boolean absolute) {
/* 134 */     BufferedOutputStream output = null;
/*     */     try
/*     */     {
/* 137 */       output = new BufferedOutputStream(new FileOutputStream(zipName));
/* 138 */       zip(fileList, fileFilter, output, rootPath, absolute); return;
/*     */     } catch (FileNotFoundException FNFE) {
/* 140 */       log.error(FNFE);
/*     */     } finally {
/* 142 */       if (output != null) {
/*     */         try {
/* 144 */           output.flush();
/* 145 */           output.close();
/*     */         } catch (IOException ignore) {
/* 147 */           log.error(ignore);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void zip(File[] fileList, String zipName) {
/* 154 */     zip(fileList, null, "", StringUtils.NVL(zipName, "file.zip"), true);
/*     */   }
/*     */   
/*     */   public static void zip(File file)
/*     */   {
/*     */     try
/*     */     {
/* 161 */       if (file.exists()) { String zipName;
/* 162 */         String zipName; if (file.isDirectory()) {
/* 163 */           zipName = file.getName() + ".zip";
/*     */         } else {
/* 165 */           zipName = file.getAbsolutePath().lastIndexOf(".") >= 0 ? file.getAbsolutePath().substring(0, file.getAbsolutePath().lastIndexOf(".")) : file.getAbsolutePath();
/* 166 */           zipName = zipName + ".zip";
/*     */         }
/* 168 */         zip(new File[] { file }, zipName);
/*     */       }
/*     */     } catch (Exception EXC) {
/* 171 */       log.error(EXC);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void unzipTo(File zipFile, File target) {
/* 176 */     BufferedOutputStream output = null;
/* 177 */     ZipInputStream zipStream = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 182 */     byte[] buffer = new byte['Ѐ'];
/*     */     
/*     */     try
/*     */     {
/* 186 */       if ((zipFile.isFile()) && (target.isDirectory())) {
/* 187 */         zipStream = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)));
/* 188 */         for (;;) { ZipEntry zipElement; if ((zipElement = zipStream.getNextEntry()) != null) {
/* 189 */             output = null;
/*     */             try {
/* 191 */               String fileName = zipElement.getName();
/* 192 */               if (fileName.startsWith(".")) {
/* 193 */                 fileName = fileName.substring(1);
/*     */               }
/* 195 */               String absolutePath = target.getAbsolutePath() + File.separator + fileName;
/* 196 */               File outputFile = new File(absolutePath);
/* 197 */               FileCommon.directoryExists(outputFile.getParentFile().getAbsolutePath(), true);
/*     */               
/* 199 */               output = new BufferedOutputStream(new FileOutputStream(outputFile));
/* 200 */               int readed; while ((readed = zipStream.read(buffer)) != -1) {
/* 201 */                 output.write(buffer, 0, readed);
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 206 */               if (output != null) {
/*     */                 try {
/* 208 */                   output.flush();
/* 209 */                   output.close();
/*     */                 } catch (IOException ignore) {
/* 211 */                   log.error(ignore);
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (Exception EXC)
/*     */             {
/* 204 */               log.error(EXC);
/*     */             } finally {
/* 206 */               if (output != null)
/*     */                 try {
/* 208 */                   output.flush();
/* 209 */                   output.close();
/*     */                 } catch (IOException ignore) {
/* 211 */                   log.error(ignore);
/*     */                 }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (IOException IOE) {
/* 218 */       log.error(IOE);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String unzip(File zipFile, File output) {
/* 223 */     String fileName = "";
/*     */     try
/*     */     {
/* 226 */       if ((zipFile.exists()) && 
/* 227 */         (zipFile.isFile()) && (StringUtils.fncbFind(".zip", zipFile.getName()))) {
/* 228 */         fileName = output.getAbsolutePath();
/* 229 */         if (FileCommon.directoryExists(fileName, true)) {
/* 230 */           unzipTo(zipFile, new File(fileName));
/* 231 */           fileName = output.getAbsolutePath();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception EXC) {
/* 236 */       log.error(EXC);
/*     */     }
/* 238 */     return fileName;
/*     */   }
/*     */   
/*     */   public static String unzip(File zipFile) {
/* 242 */     String outputName = zipFile.getAbsolutePath().substring(0, zipFile.getAbsolutePath().lastIndexOf("."));
/* 243 */     return unzip(zipFile, new File(outputName));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\packaging\Zipper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */