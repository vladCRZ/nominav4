/*     */ package com.softcoatl.utils.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLHelper
/*     */ {
/*     */   public Document newDocument()
/*     */     throws ParserConfigurationException
/*     */   {
/*  58 */     DocumentBuilder voDB = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  59 */     return voDB.newDocument();
/*     */   }
/*     */   
/*     */ 
/*     */   public Transformer getTransformer(boolean pbOmitXMLDeclaration, boolean pbIndent)
/*     */     throws TransformerConfigurationException
/*     */   {
/*  66 */     TransformerFactory voTF = TransformerFactory.newInstance();
/*  67 */     Transformer voTransformer = voTF.newTransformer();
/*  68 */     voTransformer.setOutputProperty("omit-xml-declaration", pbOmitXMLDeclaration ? "yes" : "no");
/*  69 */     voTransformer.setOutputProperty("indent", pbIndent ? "yes" : "no");
/*     */     
/*  71 */     return voTransformer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transformer getTransformer()
/*     */     throws TransformerConfigurationException
/*     */   {
/*  85 */     return getTransformer(true, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node createNode(Document poDocument, String psTag, Map<String, String> poAttributes)
/*     */   {
/* 101 */     Element voNode = poDocument.createElement(psTag);
/*     */     
/* 103 */     if ((poAttributes != null) && (poAttributes.size() > 0)) {
/* 104 */       for (String psAttr : poAttributes.keySet()) {
/* 105 */         voNode.setAttribute(psAttr, (String)poAttributes.get(psAttr));
/*     */       }
/*     */     }
/*     */     
/* 109 */     return voNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node createTextNode(Document poDocument, String psText)
/*     */   {
/* 124 */     return poDocument.createTextNode(psText);
/*     */   }
/*     */   
/*     */   public String xmlToString(Node poXMLNode, boolean pbOmitXMLDeclaration, boolean pbIndent) throws TransformerException {
/* 128 */     DOMSource voDOM = new DOMSource(poXMLNode);
/* 129 */     StringWriter voWriter = new StringWriter();
/* 130 */     StreamResult voResult = new StreamResult(voWriter);
/* 131 */     System.out.println(voDOM);
/* 132 */     getTransformer(pbOmitXMLDeclaration, pbIndent).transform(voDOM, voResult);
/* 133 */     return voWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String xmlToString(Node poXMLNode)
/*     */     throws TransformerException
/*     */   {
/* 149 */     return xmlToString(poXMLNode, true, true);
/*     */   }
/*     */   
/*     */   public Document parse(InputStream xmlString) throws SAXException, ParserConfigurationException, IOException {
/* 153 */     DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
/* 154 */     DocumentBuilder domBuilder = domFactory.newDocumentBuilder();
/* 155 */     return domBuilder.parse(xmlString);
/*     */   }
/*     */   
/* 158 */   public Document parse(String xmlString) throws SAXException, ParserConfigurationException, IOException { DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
/* 159 */     DocumentBuilder domBuilder = domFactory.newDocumentBuilder();
/* 160 */     return domBuilder.parse(xmlString);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\Utilerias.jar!\com\softcoat\\utils\xml\XMLHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */