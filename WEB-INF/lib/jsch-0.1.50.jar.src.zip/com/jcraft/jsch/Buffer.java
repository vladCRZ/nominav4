/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Buffer
/*     */ {
/*  33 */   final byte[] tmp = new byte[4];
/*     */   byte[] buffer;
/*     */   int index;
/*     */   int s;
/*     */   
/*  38 */   public Buffer(int size) { this.buffer = new byte[size];
/*  39 */     this.index = 0;
/*  40 */     this.s = 0;
/*     */   }
/*     */   
/*  43 */   public Buffer(byte[] buffer) { this.buffer = buffer;
/*  44 */     this.index = 0;
/*  45 */     this.s = 0; }
/*     */   
/*  47 */   public Buffer() { this(20480); }
/*     */   
/*  49 */   public void putByte(byte foo) { this.buffer[(this.index++)] = foo; }
/*     */   
/*     */ 
/*  52 */   public void putByte(byte[] foo) { putByte(foo, 0, foo.length); }
/*     */   
/*     */   public void putByte(byte[] foo, int begin, int length) {
/*  55 */     System.arraycopy(foo, begin, this.buffer, this.index, length);
/*  56 */     this.index += length;
/*     */   }
/*     */   
/*  59 */   public void putString(byte[] foo) { putString(foo, 0, foo.length); }
/*     */   
/*     */   public void putString(byte[] foo, int begin, int length) {
/*  62 */     putInt(length);
/*  63 */     putByte(foo, begin, length);
/*     */   }
/*     */   
/*  66 */   public void putInt(int val) { this.tmp[0] = ((byte)(val >>> 24));
/*  67 */     this.tmp[1] = ((byte)(val >>> 16));
/*  68 */     this.tmp[2] = ((byte)(val >>> 8));
/*  69 */     this.tmp[3] = ((byte)val);
/*  70 */     System.arraycopy(this.tmp, 0, this.buffer, this.index, 4);
/*  71 */     this.index += 4;
/*     */   }
/*     */   
/*  74 */   public void putLong(long val) { this.tmp[0] = ((byte)(int)(val >>> 56));
/*  75 */     this.tmp[1] = ((byte)(int)(val >>> 48));
/*  76 */     this.tmp[2] = ((byte)(int)(val >>> 40));
/*  77 */     this.tmp[3] = ((byte)(int)(val >>> 32));
/*  78 */     System.arraycopy(this.tmp, 0, this.buffer, this.index, 4);
/*  79 */     this.tmp[0] = ((byte)(int)(val >>> 24));
/*  80 */     this.tmp[1] = ((byte)(int)(val >>> 16));
/*  81 */     this.tmp[2] = ((byte)(int)(val >>> 8));
/*  82 */     this.tmp[3] = ((byte)(int)val);
/*  83 */     System.arraycopy(this.tmp, 0, this.buffer, this.index + 4, 4);
/*  84 */     this.index += 8;
/*     */   }
/*     */   
/*  87 */   void skip(int n) { this.index += n; }
/*     */   
/*     */   void putPad(int n) {
/*  90 */     while (n > 0) {
/*  91 */       this.buffer[(this.index++)] = 0;
/*  92 */       n--;
/*     */     }
/*     */   }
/*     */   
/*  96 */   public void putMPInt(byte[] foo) { int i = foo.length;
/*  97 */     if ((foo[0] & 0x80) != 0) {
/*  98 */       i++;
/*  99 */       putInt(i);
/* 100 */       putByte((byte)0);
/*     */     }
/*     */     else {
/* 103 */       putInt(i);
/*     */     }
/* 105 */     putByte(foo);
/*     */   }
/*     */   
/* 108 */   public int getLength() { return this.index - this.s; }
/*     */   
/*     */   public int getOffSet() {
/* 111 */     return this.s;
/*     */   }
/*     */   
/* 114 */   public void setOffSet(int s) { this.s = s; }
/*     */   
/*     */   public long getLong() {
/* 117 */     long foo = getInt() & 0xFFFFFFFF;
/* 118 */     foo = foo << 32 | getInt() & 0xFFFFFFFF;
/* 119 */     return foo;
/*     */   }
/*     */   
/* 122 */   public int getInt() { int foo = getShort();
/* 123 */     foo = foo << 16 & 0xFFFF0000 | getShort() & 0xFFFF;
/* 124 */     return foo;
/*     */   }
/*     */   
/* 127 */   public long getUInt() { long foo = 0L;
/* 128 */     long bar = 0L;
/* 129 */     foo = getByte();
/* 130 */     foo = foo << 8 & 0xFF00 | getByte() & 0xFF;
/* 131 */     bar = getByte();
/* 132 */     bar = bar << 8 & 0xFF00 | getByte() & 0xFF;
/* 133 */     foo = foo << 16 & 0xFFFFFFFFFFFF0000 | bar & 0xFFFF;
/* 134 */     return foo;
/*     */   }
/*     */   
/* 137 */   int getShort() { int foo = getByte();
/* 138 */     foo = foo << 8 & 0xFF00 | getByte() & 0xFF;
/* 139 */     return foo;
/*     */   }
/*     */   
/* 142 */   public int getByte() { return this.buffer[(this.s++)] & 0xFF; }
/*     */   
/*     */ 
/* 145 */   public void getByte(byte[] foo) { getByte(foo, 0, foo.length); }
/*     */   
/*     */   void getByte(byte[] foo, int start, int len) {
/* 148 */     System.arraycopy(this.buffer, this.s, foo, start, len);
/* 149 */     this.s += len;
/*     */   }
/*     */   
/* 152 */   public int getByte(int len) { int foo = this.s;
/* 153 */     this.s += len;
/* 154 */     return foo;
/*     */   }
/*     */   
/* 157 */   public byte[] getMPInt() { int i = getInt();
/* 158 */     if ((i < 0) || (i > 8192))
/*     */     {
/*     */ 
/* 161 */       i = 8192;
/*     */     }
/* 163 */     byte[] foo = new byte[i];
/* 164 */     getByte(foo, 0, i);
/* 165 */     return foo;
/*     */   }
/*     */   
/* 168 */   public byte[] getMPIntBits() { int bits = getInt();
/* 169 */     int bytes = (bits + 7) / 8;
/* 170 */     byte[] foo = new byte[bytes];
/* 171 */     getByte(foo, 0, bytes);
/* 172 */     if ((foo[0] & 0x80) != 0) {
/* 173 */       byte[] bar = new byte[foo.length + 1];
/* 174 */       bar[0] = 0;
/* 175 */       System.arraycopy(foo, 0, bar, 1, foo.length);
/* 176 */       foo = bar;
/*     */     }
/* 178 */     return foo;
/*     */   }
/*     */   
/* 181 */   public byte[] getString() { int i = getInt();
/* 182 */     if ((i < 0) || (i > 262144))
/*     */     {
/*     */ 
/* 185 */       i = 262144;
/*     */     }
/* 187 */     byte[] foo = new byte[i];
/* 188 */     getByte(foo, 0, i);
/* 189 */     return foo;
/*     */   }
/*     */   
/* 192 */   byte[] getString(int[] start, int[] len) { int i = getInt();
/* 193 */     start[0] = getByte(i);
/* 194 */     len[0] = i;
/* 195 */     return this.buffer;
/*     */   }
/*     */   
/* 198 */   public void reset() { this.index = 0;
/* 199 */     this.s = 0;
/*     */   }
/*     */   
/* 202 */   public void shift() { if (this.s == 0) return;
/* 203 */     System.arraycopy(this.buffer, this.s, this.buffer, 0, this.index - this.s);
/* 204 */     this.index -= this.s;
/* 205 */     this.s = 0;
/*     */   }
/*     */   
/* 208 */   void rewind() { this.s = 0; }
/*     */   
/*     */   byte getCommand()
/*     */   {
/* 212 */     return this.buffer[5];
/*     */   }
/*     */   
/*     */   void checkFreeSize(int n) {
/* 216 */     if (this.buffer.length < this.index + n) {
/* 217 */       byte[] tmp = new byte[this.buffer.length * 2];
/* 218 */       System.arraycopy(this.buffer, 0, tmp, 0, this.index);
/* 219 */       this.buffer = tmp;
/*     */     }
/*     */   }
/*     */   
/*     */   byte[][] getBytes(int n, String msg) throws JSchException {
/* 224 */     byte[][] tmp = new byte[n][];
/* 225 */     for (int i = 0; i < n; i++) {
/* 226 */       int j = getInt();
/* 227 */       if (getLength() < j) {
/* 228 */         throw new JSchException(msg);
/*     */       }
/* 230 */       tmp[i] = new byte[j];
/* 231 */       getByte(tmp[i]);
/*     */     }
/* 233 */     return tmp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Buffer fromBytes(byte[][] args)
/*     */   {
/* 251 */     int length = args.length * 4;
/* 252 */     for (int i = 0; i < args.length; i++) {
/* 253 */       length += args[i].length;
/*     */     }
/* 255 */     Buffer buf = new Buffer(length);
/* 256 */     for (int i = 0; i < args.length; i++) {
/* 257 */       buf.putString(args[i]);
/*     */     }
/* 259 */     return buf;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\Buffer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */