/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PipedInputStream;
/*     */ import java.io.PipedOutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Channel
/*     */   implements Runnable
/*     */ {
/*     */   static final int SSH_MSG_CHANNEL_OPEN_CONFIRMATION = 91;
/*     */   static final int SSH_MSG_CHANNEL_OPEN_FAILURE = 92;
/*     */   static final int SSH_MSG_CHANNEL_WINDOW_ADJUST = 93;
/*     */   static final int SSH_OPEN_ADMINISTRATIVELY_PROHIBITED = 1;
/*     */   static final int SSH_OPEN_CONNECT_FAILED = 2;
/*     */   static final int SSH_OPEN_UNKNOWN_CHANNEL_TYPE = 3;
/*     */   static final int SSH_OPEN_RESOURCE_SHORTAGE = 4;
/*  50 */   static int index = 0;
/*  51 */   private static Vector pool = new Vector();
/*     */   
/*  53 */   static Channel getChannel(String type) { if (type.equals("session")) {
/*  54 */       return new ChannelSession();
/*     */     }
/*  56 */     if (type.equals("shell")) {
/*  57 */       return new ChannelShell();
/*     */     }
/*  59 */     if (type.equals("exec")) {
/*  60 */       return new ChannelExec();
/*     */     }
/*  62 */     if (type.equals("x11")) {
/*  63 */       return new ChannelX11();
/*     */     }
/*  65 */     if (type.equals("auth-agent@openssh.com")) {
/*  66 */       return new ChannelAgentForwarding();
/*     */     }
/*  68 */     if (type.equals("direct-tcpip")) {
/*  69 */       return new ChannelDirectTCPIP();
/*     */     }
/*  71 */     if (type.equals("forwarded-tcpip")) {
/*  72 */       return new ChannelForwardedTCPIP();
/*     */     }
/*  74 */     if (type.equals("sftp")) {
/*  75 */       return new ChannelSftp();
/*     */     }
/*  77 */     if (type.equals("subsystem")) {
/*  78 */       return new ChannelSubsystem();
/*     */     }
/*  80 */     return null;
/*     */   }
/*     */   
/*  83 */   static Channel getChannel(int id, Session session) { synchronized (pool) {
/*  84 */       for (int i = 0; i < pool.size(); i++) {
/*  85 */         Channel c = (Channel)pool.elementAt(i);
/*  86 */         if ((c.id == id) && (c.session == session)) return c;
/*     */       }
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */   
/*  92 */   static void del(Channel c) { synchronized (pool) {
/*  93 */       pool.removeElement(c);
/*     */     }
/*     */   }
/*     */   
/*     */   int id;
/*  98 */   volatile int recipient = -1;
/*  99 */   protected byte[] type = Util.str2byte("foo");
/* 100 */   volatile int lwsize_max = 1048576;
/* 101 */   volatile int lwsize = this.lwsize_max;
/* 102 */   volatile int lmpsize = 16384;
/*     */   
/* 104 */   volatile long rwsize = 0L;
/* 105 */   volatile int rmpsize = 0;
/*     */   
/* 107 */   IO io = null;
/* 108 */   Thread thread = null;
/*     */   
/* 110 */   volatile boolean eof_local = false;
/* 111 */   volatile boolean eof_remote = false;
/*     */   
/* 113 */   volatile boolean close = false;
/* 114 */   volatile boolean connected = false;
/* 115 */   volatile boolean open_confirmation = false;
/*     */   
/* 117 */   volatile int exitstatus = -1;
/*     */   
/* 119 */   volatile int reply = 0;
/* 120 */   volatile int connectTimeout = 0;
/*     */   
/*     */   private Session session;
/*     */   
/* 124 */   int notifyme = 0;
/*     */   
/*     */   Channel() {
/* 127 */     synchronized (pool) {
/* 128 */       this.id = (index++);
/* 129 */       pool.addElement(this);
/*     */     }
/*     */   }
/*     */   
/* 133 */   synchronized void setRecipient(int foo) { this.recipient = foo;
/* 134 */     if (this.notifyme > 0)
/* 135 */       notifyAll();
/*     */   }
/*     */   
/* 138 */   int getRecipient() { return this.recipient; }
/*     */   
/*     */   void init() throws JSchException
/*     */   {}
/*     */   
/*     */   public void connect() throws JSchException
/*     */   {
/* 145 */     connect(0);
/*     */   }
/*     */   
/*     */   public void connect(int connectTimeout) throws JSchException {
/* 149 */     this.connectTimeout = connectTimeout;
/*     */     try {
/* 151 */       sendChannelOpen();
/* 152 */       start();
/*     */     }
/*     */     catch (Exception e) {
/* 155 */       this.connected = false;
/* 156 */       disconnect();
/* 157 */       if ((e instanceof JSchException))
/* 158 */         throw ((JSchException)e);
/* 159 */       throw new JSchException(e.toString(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setXForwarding(boolean foo) {}
/*     */   
/*     */   public void start() throws JSchException
/*     */   {}
/*     */   
/* 168 */   public boolean isEOF() { return this.eof_remote; }
/*     */   
/*     */   void getData(Buffer buf) {
/* 171 */     setRecipient(buf.getInt());
/* 172 */     setRemoteWindowSize(buf.getUInt());
/* 173 */     setRemotePacketSize(buf.getInt());
/*     */   }
/*     */   
/*     */   public void setInputStream(InputStream in) {
/* 177 */     this.io.setInputStream(in, false);
/*     */   }
/*     */   
/* 180 */   public void setInputStream(InputStream in, boolean dontclose) { this.io.setInputStream(in, dontclose); }
/*     */   
/*     */   public void setOutputStream(OutputStream out) {
/* 183 */     this.io.setOutputStream(out, false);
/*     */   }
/*     */   
/* 186 */   public void setOutputStream(OutputStream out, boolean dontclose) { this.io.setOutputStream(out, dontclose); }
/*     */   
/*     */   public void setExtOutputStream(OutputStream out) {
/* 189 */     this.io.setExtOutputStream(out, false);
/*     */   }
/*     */   
/* 192 */   public void setExtOutputStream(OutputStream out, boolean dontclose) { this.io.setExtOutputStream(out, dontclose); }
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 195 */     PipedInputStream in = new MyPipedInputStream(32768);
/*     */     
/*     */ 
/*     */ 
/* 199 */     this.io.setOutputStream(new PassiveOutputStream(in), false);
/* 200 */     return in;
/*     */   }
/*     */   
/* 203 */   public InputStream getExtInputStream() throws IOException { PipedInputStream in = new MyPipedInputStream(32768);
/*     */     
/*     */ 
/*     */ 
/* 207 */     this.io.setExtOutputStream(new PassiveOutputStream(in), false);
/* 208 */     return in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 219 */     final Channel channel = this;
/* 220 */     OutputStream out = new OutputStream() {
/* 221 */       private int dataLen = 0;
/* 222 */       private Buffer buffer = null;
/* 223 */       private Packet packet = null;
/* 224 */       private boolean closed = false;
/*     */       
/* 226 */       private synchronized void init() throws IOException { this.buffer = new Buffer(Channel.this.rmpsize);
/* 227 */         this.packet = new Packet(this.buffer);
/*     */         
/* 229 */         byte[] _buf = this.buffer.buffer;
/* 230 */         if (_buf.length - 14 - 84 <= 0) {
/* 231 */           this.buffer = null;
/* 232 */           this.packet = null;
/* 233 */           throw new IOException("failed to initialize the channel.");
/*     */         }
/*     */       }
/*     */       
/* 237 */       byte[] b = new byte[1];
/*     */       
/* 239 */       public void write(int w) throws IOException { this.b[0] = ((byte)w);
/* 240 */         write(this.b, 0, 1);
/*     */       }
/*     */       
/* 243 */       public void write(byte[] buf, int s, int l) throws IOException { if (this.packet == null) {
/* 244 */           init();
/*     */         }
/*     */         
/* 247 */         if (this.closed) {
/* 248 */           throw new IOException("Already closed");
/*     */         }
/*     */         
/* 251 */         byte[] _buf = this.buffer.buffer;
/* 252 */         int _bufl = _buf.length;
/* 253 */         while (l > 0) {
/* 254 */           int _l = l;
/* 255 */           if (l > _bufl - (14 + this.dataLen) - 84) {
/* 256 */             _l = _bufl - (14 + this.dataLen) - 84;
/*     */           }
/*     */           
/* 259 */           if (_l <= 0) {
/* 260 */             flush();
/*     */           }
/*     */           else
/*     */           {
/* 264 */             System.arraycopy(buf, s, _buf, 14 + this.dataLen, _l);
/* 265 */             this.dataLen += _l;
/* 266 */             s += _l;
/* 267 */             l -= _l;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 272 */       public void flush() throws IOException { if (this.closed) {
/* 273 */           throw new IOException("Already closed");
/*     */         }
/* 275 */         if (this.dataLen == 0)
/* 276 */           return;
/* 277 */         this.packet.reset();
/* 278 */         this.buffer.putByte((byte)94);
/* 279 */         this.buffer.putInt(Channel.this.recipient);
/* 280 */         this.buffer.putInt(this.dataLen);
/* 281 */         this.buffer.skip(this.dataLen);
/*     */         try {
/* 283 */           int foo = this.dataLen;
/* 284 */           this.dataLen = 0;
/* 285 */           synchronized (channel) {
/* 286 */             if (!channel.close) {
/* 287 */               Channel.this.getSession().write(this.packet, channel, foo);
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {
/* 291 */           close();
/* 292 */           throw new IOException(e.toString());
/*     */         }
/*     */       }
/*     */       
/*     */       public void close() throws IOException {
/* 297 */         if (this.packet == null) {
/*     */           try {
/* 299 */             init();
/*     */           }
/*     */           catch (IOException e)
/*     */           {
/* 303 */             return;
/*     */           }
/*     */         }
/* 306 */         if (this.closed) {
/* 307 */           return;
/*     */         }
/* 309 */         if (this.dataLen > 0) {
/* 310 */           flush();
/*     */         }
/* 312 */         channel.eof();
/* 313 */         this.closed = true;
/*     */       }
/* 315 */     };
/* 316 */     return out;
/*     */   }
/*     */   
/*     */   class MyPipedInputStream extends PipedInputStream {
/*     */     MyPipedInputStream() throws IOException
/*     */     {}
/*     */     
/* 323 */     MyPipedInputStream(int size) throws IOException { this.buffer = new byte[size]; }
/*     */     
/* 325 */     MyPipedInputStream(PipedOutputStream out) throws IOException { super(); }
/*     */     
/* 327 */     MyPipedInputStream(PipedOutputStream out, int size) throws IOException { super();
/* 328 */       this.buffer = new byte[size];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized void updateReadSide()
/*     */       throws IOException
/*     */     {
/* 338 */       if (available() != 0) {
/* 339 */         return;
/*     */       }
/* 341 */       this.in = 0;
/* 342 */       this.out = 0;
/* 343 */       this.buffer[(this.in++)] = 0;
/* 344 */       read();
/*     */     } }
/*     */   
/* 347 */   void setLocalWindowSizeMax(int foo) { this.lwsize_max = foo; }
/* 348 */   void setLocalWindowSize(int foo) { this.lwsize = foo; }
/* 349 */   void setLocalPacketSize(int foo) { this.lmpsize = foo; }
/* 350 */   synchronized void setRemoteWindowSize(long foo) { this.rwsize = foo; }
/*     */   
/* 352 */   synchronized void addRemoteWindowSize(int foo) { this.rwsize += foo;
/* 353 */     if (this.notifyme > 0)
/* 354 */       notifyAll(); }
/*     */   
/* 356 */   void setRemotePacketSize(int foo) { this.rmpsize = foo; }
/*     */   
/*     */ 
/*     */   public void run() {}
/*     */   
/*     */ 
/* 362 */   void write(byte[] foo) throws IOException { write(foo, 0, foo.length); }
/*     */   
/*     */   void write(byte[] foo, int s, int l) throws IOException {
/*     */     try {
/* 366 */       this.io.put(foo, s, l);
/*     */     } catch (NullPointerException e) {}
/*     */   }
/*     */   
/*     */   void write_ext(byte[] foo, int s, int l) throws IOException {
/* 371 */     try { this.io.put_ext(foo, s, l);
/*     */     } catch (NullPointerException e) {}
/*     */   }
/*     */   
/*     */   void eof_remote() {
/* 376 */     this.eof_remote = true;
/*     */     try {
/* 378 */       this.io.out_close();
/*     */     }
/*     */     catch (NullPointerException e) {}
/*     */   }
/*     */   
/*     */   void eof() {
/* 384 */     if (this.eof_local) return;
/* 385 */     this.eof_local = true;
/*     */     try
/*     */     {
/* 388 */       Buffer buf = new Buffer(100);
/* 389 */       Packet packet = new Packet(buf);
/* 390 */       packet.reset();
/* 391 */       buf.putByte((byte)96);
/* 392 */       buf.putInt(getRecipient());
/* 393 */       synchronized (this) {
/* 394 */         if (!this.close) {
/* 395 */           getSession().write(packet);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void close()
/*     */   {
/* 444 */     if (this.close) return;
/* 445 */     this.close = true;
/* 446 */     this.eof_local = (this.eof_remote = 1);
/*     */     try
/*     */     {
/* 449 */       Buffer buf = new Buffer(100);
/* 450 */       Packet packet = new Packet(buf);
/* 451 */       packet.reset();
/* 452 */       buf.putByte((byte)97);
/* 453 */       buf.putInt(getRecipient());
/* 454 */       synchronized (this) {
/* 455 */         getSession().write(packet);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 463 */   public boolean isClosed() { return this.close; }
/*     */   
/*     */   static void disconnect(Session session) {
/* 466 */     Channel[] channels = null;
/* 467 */     int count = 0;
/* 468 */     synchronized (pool) {
/* 469 */       channels = new Channel[pool.size()];
/* 470 */       for (int i = 0; i < pool.size(); i++) {
/*     */         try {
/* 472 */           Channel c = (Channel)pool.elementAt(i);
/* 473 */           if (c.session == session) {
/* 474 */             channels[(count++)] = c;
/*     */           }
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */     
/* 481 */     for (int i = 0; i < count; i++) {
/* 482 */       channels[i].disconnect();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/*     */     try
/*     */     {
/* 492 */       synchronized (this) {
/* 493 */         if (!this.connected) {
/*     */           return;
/*     */         }
/* 496 */         this.connected = false;
/*     */       }
/*     */       
/* 499 */       close();
/*     */       
/* 501 */       this.eof_remote = (this.eof_local = 1);
/*     */       
/* 503 */       this.thread = null;
/*     */       try
/*     */       {
/* 506 */         if (this.io != null) {
/* 507 */           this.io.close();
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     finally
/*     */     {
/* 516 */       del(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 521 */     Session _session = this.session;
/* 522 */     if (_session != null) {
/* 523 */       return (_session.isConnected()) && (this.connected);
/*     */     }
/* 525 */     return false;
/*     */   }
/*     */   
/*     */   public void sendSignal(String signal) throws Exception {
/* 529 */     RequestSignal request = new RequestSignal();
/* 530 */     request.setSignal(signal);
/* 531 */     request.request(getSession(), this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class PassiveInputStream
/*     */     extends Channel.MyPipedInputStream
/*     */   {
/*     */     PipedOutputStream out;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     PassiveInputStream(PipedOutputStream out, int size)
/*     */       throws IOException
/*     */     {
/* 549 */       super(out, size);
/* 550 */       this.out = out;
/*     */     }
/*     */     
/* 553 */     PassiveInputStream(PipedOutputStream out) throws IOException { super(out);
/* 554 */       this.out = out;
/*     */     }
/*     */     
/* 557 */     public void close() throws IOException { if (this.out != null) {
/* 558 */         this.out.close();
/*     */       }
/* 560 */       this.out = null;
/*     */     }
/*     */   }
/*     */   
/*     */   class PassiveOutputStream extends PipedOutputStream {
/* 565 */     PassiveOutputStream(PipedInputStream in) throws IOException { super(); }
/*     */   }
/*     */   
/*     */ 
/* 569 */   void setExitStatus(int status) { this.exitstatus = status; }
/* 570 */   public int getExitStatus() { return this.exitstatus; }
/*     */   
/*     */   void setSession(Session session) {
/* 573 */     this.session = session;
/*     */   }
/*     */   
/*     */   public Session getSession() throws JSchException {
/* 577 */     Session _session = this.session;
/* 578 */     if (_session == null) {
/* 579 */       throw new JSchException("session is not available");
/*     */     }
/* 581 */     return _session; }
/*     */   
/* 583 */   public int getId() { return this.id; }
/*     */   
/*     */   protected void sendOpenConfirmation() throws Exception {
/* 586 */     Buffer buf = new Buffer(100);
/* 587 */     Packet packet = new Packet(buf);
/* 588 */     packet.reset();
/* 589 */     buf.putByte((byte)91);
/* 590 */     buf.putInt(getRecipient());
/* 591 */     buf.putInt(this.id);
/* 592 */     buf.putInt(this.lwsize);
/* 593 */     buf.putInt(this.lmpsize);
/* 594 */     getSession().write(packet);
/*     */   }
/*     */   
/*     */   protected void sendOpenFailure(int reasoncode) {
/*     */     try {
/* 599 */       Buffer buf = new Buffer(100);
/* 600 */       Packet packet = new Packet(buf);
/* 601 */       packet.reset();
/* 602 */       buf.putByte((byte)92);
/* 603 */       buf.putInt(getRecipient());
/* 604 */       buf.putInt(reasoncode);
/* 605 */       buf.putString(Util.str2byte("open failed"));
/* 606 */       buf.putString(Util.empty);
/* 607 */       getSession().write(packet);
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   protected Packet genChannelOpenPacket()
/*     */   {
/* 614 */     Buffer buf = new Buffer(100);
/* 615 */     Packet packet = new Packet(buf);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 621 */     packet.reset();
/* 622 */     buf.putByte((byte)90);
/* 623 */     buf.putString(this.type);
/* 624 */     buf.putInt(this.id);
/* 625 */     buf.putInt(this.lwsize);
/* 626 */     buf.putInt(this.lmpsize);
/* 627 */     return packet;
/*     */   }
/*     */   
/*     */   protected void sendChannelOpen() throws Exception {
/* 631 */     Session _session = getSession();
/* 632 */     if (!_session.isConnected()) {
/* 633 */       throw new JSchException("session is down");
/*     */     }
/*     */     
/* 636 */     Packet packet = genChannelOpenPacket();
/* 637 */     _session.write(packet);
/*     */     
/* 639 */     int retry = 10;
/* 640 */     long start = System.currentTimeMillis();
/* 641 */     long timeout = this.connectTimeout;
/* 642 */     if (timeout != 0L) retry = 1;
/* 643 */     synchronized (this)
/*     */     {
/*     */ 
/* 646 */       while ((getRecipient() == -1) && (_session.isConnected()) && (retry > 0))
/* 647 */         if ((timeout > 0L) && 
/* 648 */           (System.currentTimeMillis() - start > timeout)) {
/* 649 */           retry = 0;
/*     */         }
/*     */         else
/*     */         {
/*     */           try {
/* 654 */             long t = timeout == 0L ? 5000L : timeout;
/* 655 */             this.notifyme = 1;
/* 656 */             wait(t);
/*     */ 
/*     */           }
/*     */           catch (InterruptedException e) {}finally
/*     */           {
/* 661 */             this.notifyme = 0;
/*     */           }
/* 663 */           retry--;
/*     */         }
/*     */     }
/* 666 */     if (!_session.isConnected()) {
/* 667 */       throw new JSchException("session is down");
/*     */     }
/* 669 */     if (getRecipient() == -1) {
/* 670 */       throw new JSchException("channel is not opened.");
/*     */     }
/* 672 */     if (!this.open_confirmation) {
/* 673 */       throw new JSchException("channel is not opened.");
/*     */     }
/* 675 */     this.connected = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\Channel.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */