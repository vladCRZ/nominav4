/*      */ package com.jcraft.jsch;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PipedInputStream;
/*      */ import java.io.PipedOutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ChannelSftp
/*      */   extends ChannelSession
/*      */ {
/*      */   private static final int LOCAL_MAXIMUM_PACKET_SIZE = 32768;
/*      */   private static final int LOCAL_WINDOW_SIZE_MAX = 2097152;
/*      */   private static final byte SSH_FXP_INIT = 1;
/*      */   private static final byte SSH_FXP_VERSION = 2;
/*      */   private static final byte SSH_FXP_OPEN = 3;
/*      */   private static final byte SSH_FXP_CLOSE = 4;
/*      */   private static final byte SSH_FXP_READ = 5;
/*      */   private static final byte SSH_FXP_WRITE = 6;
/*      */   private static final byte SSH_FXP_LSTAT = 7;
/*      */   private static final byte SSH_FXP_FSTAT = 8;
/*      */   private static final byte SSH_FXP_SETSTAT = 9;
/*      */   private static final byte SSH_FXP_FSETSTAT = 10;
/*      */   private static final byte SSH_FXP_OPENDIR = 11;
/*      */   private static final byte SSH_FXP_READDIR = 12;
/*      */   private static final byte SSH_FXP_REMOVE = 13;
/*      */   private static final byte SSH_FXP_MKDIR = 14;
/*      */   private static final byte SSH_FXP_RMDIR = 15;
/*      */   private static final byte SSH_FXP_REALPATH = 16;
/*      */   private static final byte SSH_FXP_STAT = 17;
/*      */   private static final byte SSH_FXP_RENAME = 18;
/*      */   private static final byte SSH_FXP_READLINK = 19;
/*      */   private static final byte SSH_FXP_SYMLINK = 20;
/*      */   private static final byte SSH_FXP_STATUS = 101;
/*      */   private static final byte SSH_FXP_HANDLE = 102;
/*      */   private static final byte SSH_FXP_DATA = 103;
/*      */   private static final byte SSH_FXP_NAME = 104;
/*      */   private static final byte SSH_FXP_ATTRS = 105;
/*      */   private static final byte SSH_FXP_EXTENDED = -56;
/*      */   private static final byte SSH_FXP_EXTENDED_REPLY = -55;
/*      */   private static final int SSH_FXF_READ = 1;
/*      */   private static final int SSH_FXF_WRITE = 2;
/*      */   private static final int SSH_FXF_APPEND = 4;
/*      */   private static final int SSH_FXF_CREAT = 8;
/*      */   private static final int SSH_FXF_TRUNC = 16;
/*      */   private static final int SSH_FXF_EXCL = 32;
/*      */   private static final int SSH_FILEXFER_ATTR_SIZE = 1;
/*      */   private static final int SSH_FILEXFER_ATTR_UIDGID = 2;
/*      */   private static final int SSH_FILEXFER_ATTR_PERMISSIONS = 4;
/*      */   private static final int SSH_FILEXFER_ATTR_ACMODTIME = 8;
/*      */   private static final int SSH_FILEXFER_ATTR_EXTENDED = Integer.MIN_VALUE;
/*      */   public static final int SSH_FX_OK = 0;
/*      */   public static final int SSH_FX_EOF = 1;
/*      */   public static final int SSH_FX_NO_SUCH_FILE = 2;
/*      */   public static final int SSH_FX_PERMISSION_DENIED = 3;
/*      */   public static final int SSH_FX_FAILURE = 4;
/*      */   public static final int SSH_FX_BAD_MESSAGE = 5;
/*      */   public static final int SSH_FX_NO_CONNECTION = 6;
/*      */   public static final int SSH_FX_CONNECTION_LOST = 7;
/*      */   public static final int SSH_FX_OP_UNSUPPORTED = 8;
/*      */   private static final int MAX_MSG_LENGTH = 262144;
/*      */   public static final int OVERWRITE = 0;
/*      */   public static final int RESUME = 1;
/*      */   public static final int APPEND = 2;
/*  134 */   private boolean interactive = false;
/*  135 */   private int seq = 1;
/*  136 */   private int[] ackid = new int[1];
/*      */   
/*      */   private Buffer buf;
/*      */   
/*      */   private Packet packet;
/*      */   
/*      */   private Buffer obuf;
/*      */   
/*      */   private Packet opacket;
/*  145 */   private int client_version = 3;
/*  146 */   private int server_version = 3;
/*  147 */   private String version = String.valueOf(this.client_version);
/*      */   
/*  149 */   private Hashtable extensions = null;
/*  150 */   private InputStream io_in = null;
/*      */   
/*  152 */   private boolean extension_posix_rename = false;
/*  153 */   private boolean extension_statvfs = false;
/*      */   
/*  155 */   private boolean extension_hardlink = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   private static final String file_separator = File.separator;
/*  174 */   private static final char file_separatorc = File.separatorChar;
/*  175 */   private static boolean fs_is_bs = (byte)File.separatorChar == 92;
/*      */   
/*      */   private String cwd;
/*      */   
/*      */   private String home;
/*      */   private String lcwd;
/*      */   private static final String UTF8 = "UTF-8";
/*  182 */   private String fEncoding = "UTF-8";
/*  183 */   private boolean fEncoding_is_utf8 = true;
/*      */   
/*  185 */   private RequestQueue rq = new RequestQueue(16);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBulkRequests(int bulk_requests)
/*      */     throws JSchException
/*      */   {
/*  195 */     if (bulk_requests > 0) {
/*  196 */       this.rq = new RequestQueue(bulk_requests);
/*      */     } else {
/*  198 */       throw new JSchException("setBulkRequests: " + bulk_requests + " must be greater than 0.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getBulkRequests()
/*      */   {
/*  209 */     return this.rq.size();
/*      */   }
/*      */   
/*      */   public ChannelSftp()
/*      */   {
/*  214 */     setLocalWindowSizeMax(2097152);
/*  215 */     setLocalWindowSize(2097152);
/*  216 */     setLocalPacketSize(32768);
/*      */   }
/*      */   
/*      */   void init() {}
/*      */   
/*      */   public void start() throws JSchException
/*      */   {
/*      */     try
/*      */     {
/*  225 */       PipedOutputStream pos = new PipedOutputStream();
/*  226 */       this.io.setOutputStream(pos);
/*  227 */       PipedInputStream pis = new Channel.MyPipedInputStream(this, pos, this.rmpsize);
/*  228 */       this.io.setInputStream(pis);
/*      */       
/*  230 */       this.io_in = this.io.in;
/*      */       
/*  232 */       if (this.io_in == null) {
/*  233 */         throw new JSchException("channel is down");
/*      */       }
/*      */       
/*  236 */       Request request = new RequestSftp();
/*  237 */       request.request(getSession(), this);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */       this.buf = new Buffer(this.lmpsize);
/*  247 */       this.packet = new Packet(this.buf);
/*      */       
/*  249 */       this.obuf = new Buffer(this.rmpsize);
/*  250 */       this.opacket = new Packet(this.obuf);
/*      */       
/*  252 */       int i = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  258 */       sendINIT();
/*      */       
/*      */ 
/*  261 */       Header header = new Header();
/*  262 */       header = header(this.buf, header);
/*  263 */       int length = header.length;
/*  264 */       if (length > 262144) {
/*  265 */         throw new SftpException(4, "Received message is too long: " + length);
/*      */       }
/*      */       
/*  268 */       int type = header.type;
/*  269 */       this.server_version = header.rid;
/*      */       
/*  271 */       this.extensions = new Hashtable();
/*  272 */       if (length > 0)
/*      */       {
/*  274 */         fill(this.buf, length);
/*  275 */         byte[] extension_name = null;
/*  276 */         byte[] extension_data = null;
/*  277 */         while (length > 0) {
/*  278 */           extension_name = this.buf.getString();
/*  279 */           length -= 4 + extension_name.length;
/*  280 */           extension_data = this.buf.getString();
/*  281 */           length -= 4 + extension_data.length;
/*  282 */           this.extensions.put(Util.byte2str(extension_name), Util.byte2str(extension_data));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  287 */       if ((this.extensions.get("posix-rename@openssh.com") != null) && (this.extensions.get("posix-rename@openssh.com").equals("1")))
/*      */       {
/*  289 */         this.extension_posix_rename = true;
/*      */       }
/*      */       
/*  292 */       if ((this.extensions.get("statvfs@openssh.com") != null) && (this.extensions.get("statvfs@openssh.com").equals("2")))
/*      */       {
/*  294 */         this.extension_statvfs = true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  304 */       if ((this.extensions.get("hardlink@openssh.com") != null) && (this.extensions.get("hardlink@openssh.com").equals("1")))
/*      */       {
/*  306 */         this.extension_hardlink = true;
/*      */       }
/*      */       
/*  309 */       this.lcwd = new File(".").getCanonicalPath();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  313 */       if ((e instanceof JSchException)) throw ((JSchException)e);
/*  314 */       if ((e instanceof Throwable))
/*  315 */         throw new JSchException(e.toString(), e);
/*  316 */       throw new JSchException(e.toString());
/*      */     }
/*      */   }
/*      */   
/*  320 */   public void quit() { disconnect(); }
/*  321 */   public void exit() { disconnect(); }
/*      */   
/*  323 */   public void lcd(String path) throws SftpException { path = localAbsolutePath(path);
/*  324 */     if (new File(path).isDirectory()) {
/*      */       try {
/*  326 */         path = new File(path).getCanonicalPath();
/*      */       }
/*      */       catch (Exception e) {}
/*  329 */       this.lcwd = path;
/*  330 */       return;
/*      */     }
/*  332 */     throw new SftpException(2, "No such directory");
/*      */   }
/*      */   
/*      */   public void cd(String path) throws SftpException {
/*      */     try {
/*  337 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  339 */       path = remoteAbsolutePath(path);
/*  340 */       path = isUnique(path);
/*      */       
/*  342 */       byte[] str = _realpath(path);
/*  343 */       SftpATTRS attr = _stat(str);
/*      */       
/*  345 */       if ((attr.getFlags() & 0x4) == 0) {
/*  346 */         throw new SftpException(4, "Can't change directory: " + path);
/*      */       }
/*      */       
/*  349 */       if (!attr.isDir()) {
/*  350 */         throw new SftpException(4, "Can't change directory: " + path);
/*      */       }
/*      */       
/*      */ 
/*  354 */       setCwd(Util.byte2str(str, this.fEncoding));
/*      */     }
/*      */     catch (Exception e) {
/*  357 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/*  358 */       if ((e instanceof Throwable))
/*  359 */         throw new SftpException(4, "", e);
/*  360 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void put(String src, String dst) throws SftpException {
/*  365 */     put(src, dst, null, 0);
/*      */   }
/*      */   
/*  368 */   public void put(String src, String dst, int mode) throws SftpException { put(src, dst, null, mode); }
/*      */   
/*      */   public void put(String src, String dst, SftpProgressMonitor monitor) throws SftpException
/*      */   {
/*  372 */     put(src, dst, monitor, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void put(String src, String dst, SftpProgressMonitor monitor, int mode)
/*      */     throws SftpException
/*      */   {
/*      */     try
/*      */     {
/*  389 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  391 */       src = localAbsolutePath(src);
/*  392 */       dst = remoteAbsolutePath(dst);
/*      */       
/*  394 */       Vector v = glob_remote(dst);
/*  395 */       int vsize = v.size();
/*  396 */       if (vsize != 1) {
/*  397 */         if (vsize == 0) {
/*  398 */           if (isPattern(dst)) {
/*  399 */             throw new SftpException(4, dst);
/*      */           }
/*  401 */           dst = Util.unquote(dst);
/*      */         }
/*  403 */         throw new SftpException(4, v.toString());
/*      */       }
/*      */       
/*  406 */       dst = (String)v.elementAt(0);
/*      */       
/*      */ 
/*  409 */       boolean isRemoteDir = isRemoteDir(dst);
/*      */       
/*  411 */       v = glob_local(src);
/*  412 */       vsize = v.size();
/*      */       
/*  414 */       StringBuffer dstsb = null;
/*  415 */       if (isRemoteDir) {
/*  416 */         if (!dst.endsWith("/")) {
/*  417 */           dst = dst + "/";
/*      */         }
/*  419 */         dstsb = new StringBuffer(dst);
/*      */       }
/*  421 */       else if (vsize > 1) {
/*  422 */         throw new SftpException(4, "Copying multiple files, but the destination is missing or a file.");
/*      */       }
/*      */       
/*      */ 
/*  426 */       for (int j = 0; j < vsize; j++) {
/*  427 */         String _src = (String)v.elementAt(j);
/*  428 */         String _dst = null;
/*  429 */         if (isRemoteDir) {
/*  430 */           int i = _src.lastIndexOf(file_separatorc);
/*  431 */           if (fs_is_bs) {
/*  432 */             int ii = _src.lastIndexOf('/');
/*  433 */             if ((ii != -1) && (ii > i))
/*  434 */               i = ii;
/*      */           }
/*  436 */           if (i == -1) dstsb.append(_src); else
/*  437 */             dstsb.append(_src.substring(i + 1));
/*  438 */           _dst = dstsb.toString();
/*  439 */           dstsb.delete(dst.length(), _dst.length());
/*      */         }
/*      */         else {
/*  442 */           _dst = dst;
/*      */         }
/*      */         
/*      */ 
/*  446 */         long size_of_dst = 0L;
/*  447 */         if (mode == 1) {
/*      */           try {
/*  449 */             SftpATTRS attr = _stat(_dst);
/*  450 */             size_of_dst = attr.getSize();
/*      */           }
/*      */           catch (Exception eee) {}
/*      */           
/*      */ 
/*  455 */           long size_of_src = new File(_src).length();
/*  456 */           if (size_of_src < size_of_dst) {
/*  457 */             throw new SftpException(4, "failed to resume for " + _dst);
/*      */           }
/*      */           
/*  460 */           if (size_of_src == size_of_dst) {
/*  461 */             return;
/*      */           }
/*      */         }
/*      */         
/*  465 */         if (monitor != null) {
/*  466 */           monitor.init(0, _src, _dst, new File(_src).length());
/*      */           
/*  468 */           if (mode == 1) {
/*  469 */             monitor.count(size_of_dst);
/*      */           }
/*      */         }
/*  472 */         FileInputStream fis = null;
/*      */         try {
/*  474 */           fis = new FileInputStream(_src);
/*  475 */           _put(fis, _dst, monitor, mode);
/*      */         }
/*      */         finally {
/*  478 */           if (fis != null) {
/*  479 */             fis.close();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  485 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/*  486 */       if ((e instanceof Throwable))
/*  487 */         throw new SftpException(4, e.toString(), e);
/*  488 */       throw new SftpException(4, e.toString());
/*      */     }
/*      */   }
/*      */   
/*  492 */   public void put(InputStream src, String dst) throws SftpException { put(src, dst, null, 0); }
/*      */   
/*      */   public void put(InputStream src, String dst, int mode) throws SftpException {
/*  495 */     put(src, dst, null, mode);
/*      */   }
/*      */   
/*      */   public void put(InputStream src, String dst, SftpProgressMonitor monitor) throws SftpException {
/*  499 */     put(src, dst, monitor, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void put(InputStream src, String dst, SftpProgressMonitor monitor, int mode)
/*      */     throws SftpException
/*      */   {
/*      */     try
/*      */     {
/*  515 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  517 */       dst = remoteAbsolutePath(dst);
/*      */       
/*  519 */       Vector v = glob_remote(dst);
/*  520 */       int vsize = v.size();
/*  521 */       if (vsize != 1) {
/*  522 */         if (vsize == 0) {
/*  523 */           if (isPattern(dst)) {
/*  524 */             throw new SftpException(4, dst);
/*      */           }
/*  526 */           dst = Util.unquote(dst);
/*      */         }
/*  528 */         throw new SftpException(4, v.toString());
/*      */       }
/*      */       
/*  531 */       dst = (String)v.elementAt(0);
/*      */       
/*      */ 
/*  534 */       if (monitor != null) {
/*  535 */         monitor.init(0, "-", dst, -1L);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  540 */       _put(src, dst, monitor, mode);
/*      */     }
/*      */     catch (Exception e) {
/*  543 */       if ((e instanceof SftpException)) {
/*  544 */         if ((((SftpException)e).id == 4) && (isRemoteDir(dst)))
/*      */         {
/*  546 */           throw new SftpException(4, dst + " is a directory");
/*      */         }
/*  548 */         throw ((SftpException)e);
/*      */       }
/*  550 */       if ((e instanceof Throwable))
/*  551 */         throw new SftpException(4, e.toString(), e);
/*  552 */       throw new SftpException(4, e.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   public void _put(InputStream src, String dst, SftpProgressMonitor monitor, int mode) throws SftpException
/*      */   {
/*      */     try {
/*  559 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  561 */       byte[] dstb = Util.str2byte(dst, this.fEncoding);
/*  562 */       long skip = 0L;
/*  563 */       if ((mode == 1) || (mode == 2)) {
/*      */         try {
/*  565 */           SftpATTRS attr = _stat(dstb);
/*  566 */           skip = attr.getSize();
/*      */         }
/*      */         catch (Exception eee) {}
/*      */       }
/*      */       
/*      */ 
/*  572 */       if ((mode == 1) && (skip > 0L)) {
/*  573 */         long skipped = src.skip(skip);
/*  574 */         if (skipped < skip) {
/*  575 */           throw new SftpException(4, "failed to resume for " + dst);
/*      */         }
/*      */       }
/*      */       
/*  579 */       if (mode == 0) sendOPENW(dstb); else {
/*  580 */         sendOPENA(dstb);
/*      */       }
/*  582 */       Header header = new Header();
/*  583 */       header = header(this.buf, header);
/*  584 */       int length = header.length;
/*  585 */       int type = header.type;
/*      */       
/*  587 */       fill(this.buf, length);
/*      */       
/*  589 */       if ((type != 101) && (type != 102)) {
/*  590 */         throw new SftpException(4, "invalid type=" + type);
/*      */       }
/*  592 */       if (type == 101) {
/*  593 */         int i = this.buf.getInt();
/*  594 */         throwStatusError(this.buf, i);
/*      */       }
/*  596 */       byte[] handle = this.buf.getString();
/*  597 */       byte[] data = null;
/*      */       
/*  599 */       boolean dontcopy = true;
/*      */       
/*  601 */       if (!dontcopy) {
/*  602 */         data = new byte[this.obuf.buffer.length - (39 + handle.length + 84)];
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  608 */       long offset = 0L;
/*  609 */       if ((mode == 1) || (mode == 2)) {
/*  610 */         offset += skip;
/*      */       }
/*      */       
/*  613 */       int startid = this.seq;
/*  614 */       int ackcount = 0;
/*  615 */       int _s = 0;
/*  616 */       int _datalen = 0;
/*      */       
/*  618 */       if (!dontcopy) {
/*  619 */         _datalen = data.length;
/*      */       }
/*      */       else {
/*  622 */         data = this.obuf.buffer;
/*  623 */         _s = 39 + handle.length;
/*  624 */         _datalen = this.obuf.buffer.length - _s - 84;
/*      */       }
/*      */       
/*  627 */       int bulk_requests = this.rq.size();
/*      */       for (;;)
/*      */       {
/*  630 */         int nread = 0;
/*  631 */         int count = 0;
/*  632 */         int s = _s;
/*  633 */         int datalen = _datalen;
/*      */         do
/*      */         {
/*  636 */           nread = src.read(data, s, datalen);
/*  637 */           if (nread > 0) {
/*  638 */             s += nread;
/*  639 */             datalen -= nread;
/*  640 */             count += nread;
/*      */           }
/*      */           
/*  643 */         } while ((datalen > 0) && (nread > 0));
/*  644 */         if (count <= 0)
/*      */           break;
/*  646 */         int foo = count;
/*  647 */         while (foo > 0) {
/*  648 */           if ((this.seq - 1 == startid) || (this.seq - startid - ackcount >= bulk_requests))
/*      */           {
/*  650 */             while ((this.seq - startid - ackcount >= bulk_requests) && 
/*  651 */               (this.rwsize < foo) && 
/*  652 */               (checkStatus(this.ackid, header))) {
/*  653 */               int _ackid = this.ackid[0];
/*  654 */               if ((startid > _ackid) || (_ackid > this.seq - 1)) {
/*  655 */                 if (_ackid == this.seq) {
/*  656 */                   System.err.println("ack error: startid=" + startid + " seq=" + this.seq + " _ackid=" + _ackid);
/*      */                 }
/*      */                 else {
/*  659 */                   throw new SftpException(4, "ack error: startid=" + startid + " seq=" + this.seq + " _ackid=" + _ackid);
/*      */                 }
/*      */               }
/*  662 */               ackcount++;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  669 */           foo -= sendWRITE(handle, offset, data, 0, foo);
/*      */         }
/*  671 */         offset += count;
/*  672 */         if ((monitor != null) && (!monitor.count(count))) {
/*      */           break;
/*      */         }
/*      */       }
/*  676 */       int _ackcount = this.seq - startid;
/*  677 */       while ((_ackcount > ackcount) && 
/*  678 */         (checkStatus(null, header)))
/*      */       {
/*      */ 
/*  681 */         ackcount++;
/*      */       }
/*  683 */       if (monitor != null) monitor.end();
/*  684 */       _sendCLOSE(handle, header);
/*      */     }
/*      */     catch (Exception e) {
/*  687 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/*  688 */       if ((e instanceof Throwable))
/*  689 */         throw new SftpException(4, e.toString(), e);
/*  690 */       throw new SftpException(4, e.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   public OutputStream put(String dst) throws SftpException {
/*  695 */     return put(dst, (SftpProgressMonitor)null, 0);
/*      */   }
/*      */   
/*  698 */   public OutputStream put(String dst, int mode) throws SftpException { return put(dst, (SftpProgressMonitor)null, mode); }
/*      */   
/*      */   public OutputStream put(String dst, SftpProgressMonitor monitor, int mode) throws SftpException {
/*  701 */     return put(dst, monitor, mode, 0L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStream put(String dst, final SftpProgressMonitor monitor, int mode, long offset)
/*      */     throws SftpException
/*      */   {
/*      */     try
/*      */     {
/*  717 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  719 */       dst = remoteAbsolutePath(dst);
/*  720 */       dst = isUnique(dst);
/*      */       
/*  722 */       if (isRemoteDir(dst)) {
/*  723 */         throw new SftpException(4, dst + " is a directory");
/*      */       }
/*      */       
/*  726 */       byte[] dstb = Util.str2byte(dst, this.fEncoding);
/*      */       
/*  728 */       long skip = 0L;
/*  729 */       if ((mode == 1) || (mode == 2)) {
/*      */         try {
/*  731 */           SftpATTRS attr = _stat(dstb);
/*  732 */           skip = attr.getSize();
/*      */         }
/*      */         catch (Exception eee) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  739 */       if (mode == 0) sendOPENW(dstb); else {
/*  740 */         sendOPENA(dstb);
/*      */       }
/*  742 */       Header header = new Header();
/*  743 */       header = header(this.buf, header);
/*  744 */       int length = header.length;
/*  745 */       int type = header.type;
/*      */       
/*  747 */       fill(this.buf, length);
/*      */       
/*  749 */       if ((type != 101) && (type != 102)) {
/*  750 */         throw new SftpException(4, "");
/*      */       }
/*  752 */       if (type == 101) {
/*  753 */         int i = this.buf.getInt();
/*  754 */         throwStatusError(this.buf, i);
/*      */       }
/*  756 */       final byte[] handle = this.buf.getString();
/*      */       
/*  758 */       if ((mode == 1) || (mode == 2)) {
/*  759 */         offset += skip;
/*      */       }
/*      */       
/*  762 */       final long[] _offset = new long[1];
/*  763 */       _offset[0] = offset;
/*  764 */       new OutputStream() {
/*  765 */         private boolean init = true;
/*  766 */         private boolean isClosed = false;
/*  767 */         private int[] ackid = new int[1];
/*  768 */         private int startid = 0;
/*  769 */         private int _ackid = 0;
/*  770 */         private int ackcount = 0;
/*  771 */         private int writecount = 0;
/*  772 */         private ChannelSftp.Header header = new ChannelSftp.Header(ChannelSftp.this);
/*      */         
/*      */         public void write(byte[] d) throws IOException {
/*  775 */           write(d, 0, d.length);
/*      */         }
/*      */         
/*      */         public void write(byte[] d, int s, int len) throws IOException {
/*  779 */           if (this.init) {
/*  780 */             this.startid = ChannelSftp.this.seq;
/*  781 */             this._ackid = ChannelSftp.this.seq;
/*  782 */             this.init = false;
/*      */           }
/*      */           
/*  785 */           if (this.isClosed) {
/*  786 */             throw new IOException("stream already closed");
/*      */           }
/*      */           try
/*      */           {
/*  790 */             int _len = len;
/*  791 */             for (; _len > 0; 
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  805 */                 goto 148)
/*      */             {
/*  792 */               int sent = ChannelSftp.this.sendWRITE(handle, _offset[0], d, s, _len);
/*  793 */               this.writecount += 1;
/*  794 */               _offset[0] += sent;
/*  795 */               s += sent;
/*  796 */               _len -= sent;
/*  797 */               if ((ChannelSftp.this.seq - 1 == this.startid) || (ChannelSftp.this.io_in.available() >= 1024))
/*      */               {
/*  799 */                 if ((ChannelSftp.this.io_in.available() > 0) && 
/*  800 */                   (ChannelSftp.this.checkStatus(this.ackid, this.header))) {
/*  801 */                   this._ackid = this.ackid[0];
/*  802 */                   if ((this.startid > this._ackid) || (this._ackid > ChannelSftp.this.seq - 1)) {
/*  803 */                     throw new SftpException(4, "");
/*      */                   }
/*  805 */                   this.ackcount += 1;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  813 */             if ((monitor != null) && (!monitor.count(len))) {
/*  814 */               close();
/*  815 */               throw new IOException("canceled");
/*      */             }
/*      */           } catch (IOException e) {
/*  818 */             throw e;
/*  819 */           } catch (Exception e) { throw new IOException(e.toString());
/*      */           } }
/*      */         
/*  822 */         byte[] _data = new byte[1];
/*      */         
/*  824 */         public void write(int foo) throws IOException { this._data[0] = ((byte)foo);
/*  825 */           write(this._data, 0, 1);
/*      */         }
/*      */         
/*      */         public void flush() throws IOException
/*      */         {
/*  830 */           if (this.isClosed) {
/*  831 */             throw new IOException("stream already closed");
/*      */           }
/*      */           
/*  834 */           if (!this.init) {
/*      */             try {
/*  836 */               while ((this.writecount > this.ackcount) && 
/*  837 */                 (ChannelSftp.this.checkStatus(null, this.header)))
/*      */               {
/*      */ 
/*  840 */                 this.ackcount += 1;
/*      */               }
/*      */             }
/*      */             catch (SftpException e) {
/*  844 */               throw new IOException(e.toString());
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */         public void close() throws IOException {
/*  850 */           if (this.isClosed) {
/*  851 */             return;
/*      */           }
/*  853 */           flush();
/*  854 */           if (monitor != null) monitor.end();
/*  855 */           try { ChannelSftp.this._sendCLOSE(handle, this.header);
/*  856 */           } catch (IOException e) { throw e;
/*      */           } catch (Exception e) {
/*  858 */             throw new IOException(e.toString());
/*      */           }
/*  860 */           this.isClosed = true;
/*      */         }
/*      */       };
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  866 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/*  867 */       if ((e instanceof Throwable))
/*  868 */         throw new SftpException(4, "", e);
/*  869 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void get(String src, String dst) throws SftpException {
/*  874 */     get(src, dst, null, 0);
/*      */   }
/*      */   
/*      */   public void get(String src, String dst, SftpProgressMonitor monitor) throws SftpException {
/*  878 */     get(src, dst, monitor, 0);
/*      */   }
/*      */   
/*      */   public void get(String src, String dst, SftpProgressMonitor monitor, int mode)
/*      */     throws SftpException
/*      */   {
/*  884 */     boolean _dstExist = false;
/*  885 */     String _dst = null;
/*      */     try {
/*  887 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  889 */       src = remoteAbsolutePath(src);
/*  890 */       dst = localAbsolutePath(dst);
/*      */       
/*  892 */       Vector v = glob_remote(src);
/*  893 */       int vsize = v.size();
/*  894 */       if (vsize == 0) {
/*  895 */         throw new SftpException(2, "No such file");
/*      */       }
/*      */       
/*  898 */       File dstFile = new File(dst);
/*  899 */       boolean isDstDir = dstFile.isDirectory();
/*  900 */       StringBuffer dstsb = null;
/*  901 */       if (isDstDir) {
/*  902 */         if (!dst.endsWith(file_separator)) {
/*  903 */           dst = dst + file_separator;
/*      */         }
/*  905 */         dstsb = new StringBuffer(dst);
/*      */       }
/*  907 */       else if (vsize > 1) {
/*  908 */         throw new SftpException(4, "Copying multiple files, but destination is missing or a file.");
/*      */       }
/*      */       
/*      */ 
/*  912 */       for (int j = 0; j < vsize; j++) {
/*  913 */         String _src = (String)v.elementAt(j);
/*  914 */         SftpATTRS attr = _stat(_src);
/*  915 */         if (attr.isDir()) {
/*  916 */           throw new SftpException(4, "not supported to get directory " + _src);
/*      */         }
/*      */         
/*      */ 
/*  920 */         _dst = null;
/*  921 */         if (isDstDir) {
/*  922 */           int i = _src.lastIndexOf('/');
/*  923 */           if (i == -1) dstsb.append(_src); else
/*  924 */             dstsb.append(_src.substring(i + 1));
/*  925 */           _dst = dstsb.toString();
/*  926 */           dstsb.delete(dst.length(), _dst.length());
/*      */         }
/*      */         else {
/*  929 */           _dst = dst;
/*      */         }
/*      */         
/*  932 */         File _dstFile = new File(_dst);
/*  933 */         if (mode == 1) {
/*  934 */           long size_of_src = attr.getSize();
/*  935 */           long size_of_dst = _dstFile.length();
/*  936 */           if (size_of_dst > size_of_src) {
/*  937 */             throw new SftpException(4, "failed to resume for " + _dst);
/*      */           }
/*      */           
/*  940 */           if (size_of_dst == size_of_src) {
/*  941 */             return;
/*      */           }
/*      */         }
/*      */         
/*  945 */         if (monitor != null) {
/*  946 */           monitor.init(1, _src, _dst, attr.getSize());
/*  947 */           if (mode == 1) {
/*  948 */             monitor.count(_dstFile.length());
/*      */           }
/*      */         }
/*      */         
/*  952 */         FileOutputStream fos = null;
/*  953 */         _dstExist = _dstFile.exists();
/*      */         try {
/*  955 */           if (mode == 0) {
/*  956 */             fos = new FileOutputStream(_dst);
/*      */           }
/*      */           else {
/*  959 */             fos = new FileOutputStream(_dst, true);
/*      */           }
/*      */           
/*  962 */           _get(_src, fos, monitor, mode, new File(_dst).length());
/*      */         }
/*      */         finally {
/*  965 */           if (fos != null) {
/*  966 */             fos.close();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  972 */       if ((!_dstExist) && (_dst != null)) {
/*  973 */         File _dstFile = new File(_dst);
/*  974 */         if ((_dstFile.exists()) && (_dstFile.length() == 0L)) {
/*  975 */           _dstFile.delete();
/*      */         }
/*      */       }
/*  978 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/*  979 */       if ((e instanceof Throwable))
/*  980 */         throw new SftpException(4, "", e);
/*  981 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*  985 */   public void get(String src, OutputStream dst) throws SftpException { get(src, dst, null, 0, 0L); }
/*      */   
/*      */   public void get(String src, OutputStream dst, SftpProgressMonitor monitor) throws SftpException
/*      */   {
/*  989 */     get(src, dst, monitor, 0, 0L);
/*      */   }
/*      */   
/*      */   public void get(String src, OutputStream dst, SftpProgressMonitor monitor, int mode, long skip) throws SftpException
/*      */   {
/*      */     try {
/*  995 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/*  997 */       src = remoteAbsolutePath(src);
/*  998 */       src = isUnique(src);
/*      */       
/* 1000 */       if (monitor != null) {
/* 1001 */         SftpATTRS attr = _stat(src);
/* 1002 */         monitor.init(1, src, "??", attr.getSize());
/* 1003 */         if (mode == 1) {
/* 1004 */           monitor.count(skip);
/*      */         }
/*      */       }
/* 1007 */       _get(src, dst, monitor, mode, skip);
/*      */     }
/*      */     catch (Exception e) {
/* 1010 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1011 */       if ((e instanceof Throwable))
/* 1012 */         throw new SftpException(4, "", e);
/* 1013 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void _get(String src, OutputStream dst, SftpProgressMonitor monitor, int mode, long skip)
/*      */     throws SftpException
/*      */   {
/* 1021 */     byte[] srcb = Util.str2byte(src, this.fEncoding);
/*      */     try {
/* 1023 */       sendOPENR(srcb);
/*      */       
/* 1025 */       Header header = new Header();
/* 1026 */       header = header(this.buf, header);
/* 1027 */       int length = header.length;
/* 1028 */       int type = header.type;
/*      */       
/* 1030 */       fill(this.buf, length);
/*      */       
/* 1032 */       if ((type != 101) && (type != 102)) {
/* 1033 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1036 */       if (type == 101) {
/* 1037 */         int i = this.buf.getInt();
/* 1038 */         throwStatusError(this.buf, i);
/*      */       }
/*      */       
/* 1041 */       byte[] handle = this.buf.getString();
/*      */       
/* 1043 */       long offset = 0L;
/* 1044 */       if (mode == 1) {
/* 1045 */         offset += skip;
/*      */       }
/*      */       
/* 1048 */       int request_max = 1;
/* 1049 */       this.rq.init();
/* 1050 */       long request_offset = offset;
/*      */       
/* 1052 */       int request_len = this.buf.buffer.length - 13;
/* 1053 */       if (this.server_version == 0) { request_len = 1024;
/*      */       }
/*      */       
/*      */       for (;;)
/*      */       {
/* 1058 */         if (this.rq.count() < request_max) {
/* 1059 */           sendREAD(handle, request_offset, request_len, this.rq);
/* 1060 */           request_offset += request_len;
/*      */         }
/*      */         else {
/* 1063 */           header = header(this.buf, header);
/* 1064 */           length = header.length;
/* 1065 */           type = header.type;
/*      */           
/* 1067 */           ChannelSftp.RequestQueue.Request rr = null;
/*      */           try {
/* 1069 */             rr = this.rq.get(header.rid);
/*      */           }
/*      */           catch (ChannelSftp.RequestQueue.OutOfOrderException e) {
/* 1072 */             request_offset = e.offset;
/* 1073 */             skip(header.length);
/* 1074 */             this.rq.cancel(header, this.buf); }
/* 1075 */           continue;
/*      */           
/*      */ 
/* 1078 */           if (type == 101) {
/* 1079 */             fill(this.buf, length);
/* 1080 */             int i = this.buf.getInt();
/* 1081 */             if (i == 1) {
/*      */               break;
/*      */             }
/* 1084 */             throwStatusError(this.buf, i);
/*      */           }
/*      */           
/* 1087 */           if (type != 103) {
/*      */             break;
/*      */           }
/*      */           
/* 1091 */           this.buf.rewind();
/* 1092 */           fill(this.buf.buffer, 0, 4);length -= 4;
/* 1093 */           int length_of_data = this.buf.getInt();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1105 */           int optional_data = length - length_of_data;
/*      */           
/* 1107 */           int foo = length_of_data;
/* 1108 */           for (; foo > 0; 
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1127 */               goto 620)
/*      */           {
/* 1109 */             int bar = foo;
/* 1110 */             if (bar > this.buf.buffer.length) {
/* 1111 */               bar = this.buf.buffer.length;
/*      */             }
/* 1113 */             int data_len = this.io_in.read(this.buf.buffer, 0, bar);
/* 1114 */             if (data_len < 0) {
/*      */               break label620;
/*      */             }
/*      */             
/* 1118 */             dst.write(this.buf.buffer, 0, data_len);
/*      */             
/* 1120 */             offset += data_len;
/* 1121 */             foo -= data_len;
/*      */             
/* 1123 */             if ((monitor != null) && 
/* 1124 */               (!monitor.count(data_len))) {
/* 1125 */               skip(foo);
/* 1126 */               if (optional_data <= 0) break label620;
/* 1127 */               skip(optional_data);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1136 */           if (optional_data > 0) {
/* 1137 */             skip(optional_data);
/*      */           }
/*      */           
/* 1140 */           if (length_of_data < rr.length) {
/* 1141 */             this.rq.cancel(header, this.buf);
/* 1142 */             sendREAD(handle, rr.offset + length_of_data, (int)(rr.length - length_of_data), this.rq);
/* 1143 */             request_offset = rr.offset + rr.length;
/*      */           }
/*      */           
/* 1146 */           if (request_max < this.rq.size())
/* 1147 */             request_max++;
/*      */         } }
/*      */       label620:
/* 1150 */       dst.flush();
/*      */       
/* 1152 */       if (monitor != null) { monitor.end();
/*      */       }
/* 1154 */       this.rq.cancel(header, this.buf);
/*      */       
/* 1156 */       _sendCLOSE(handle, header);
/*      */     }
/*      */     catch (Exception e) {
/* 1159 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1160 */       if ((e instanceof Throwable))
/* 1161 */         throw new SftpException(4, "", e);
/* 1162 */       throw new SftpException(4, "");
/*      */     } }
/*      */   
/*      */   private class RequestQueue { class Request { int id;
/*      */       long offset;
/*      */       long length;
/*      */       
/*      */       Request() {} }
/*      */     
/* 1171 */     class OutOfOrderException extends Exception { OutOfOrderException(long offset) { this.offset = offset; }
/*      */       
/*      */ 
/*      */ 
/*      */       long offset;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1180 */     Request[] rrq = null;
/*      */     int head;
/*      */     
/* 1183 */     RequestQueue(int size) { this.rrq = new Request[size];
/* 1184 */       for (int i = 0; i < this.rrq.length; i++) {
/* 1185 */         this.rrq[i] = new Request();
/*      */       }
/* 1187 */       init();
/*      */     }
/*      */     
/*      */     int count;
/* 1191 */     void init() { this.head = (this.count = 0); }
/*      */     
/*      */     void add(int id, long offset, int length)
/*      */     {
/* 1195 */       if (this.count == 0) this.head = 0;
/* 1196 */       int tail = this.head + this.count;
/* 1197 */       if (tail >= this.rrq.length) tail -= this.rrq.length;
/* 1198 */       this.rrq[tail].id = id;
/* 1199 */       this.rrq[tail].offset = offset;
/* 1200 */       this.rrq[tail].length = length;
/* 1201 */       this.count += 1;
/*      */     }
/*      */     
/*      */     Request get(int id) throws ChannelSftp.RequestQueue.OutOfOrderException, SftpException {
/* 1205 */       this.count -= 1;
/* 1206 */       int i = this.head;
/* 1207 */       this.head += 1;
/* 1208 */       if (this.head == this.rrq.length) this.head = 0;
/* 1209 */       if (this.rrq[i].id != id) {
/* 1210 */         long offset = getOffset();
/* 1211 */         boolean find = false;
/* 1212 */         for (int j = 0; j < this.rrq.length; j++) {
/* 1213 */           if (this.rrq[j].id == id) {
/* 1214 */             find = true;
/* 1215 */             this.rrq[j].id = 0;
/* 1216 */             break;
/*      */           }
/*      */         }
/* 1219 */         if (find)
/* 1220 */           throw new OutOfOrderException(offset);
/* 1221 */         throw new SftpException(4, "RequestQueue: unknown request id " + id);
/*      */       }
/*      */       
/* 1224 */       this.rrq[i].id = 0;
/* 1225 */       return this.rrq[i];
/*      */     }
/*      */     
/*      */     int count() {
/* 1229 */       return this.count;
/*      */     }
/*      */     
/*      */     int size() {
/* 1233 */       return this.rrq.length;
/*      */     }
/*      */     
/*      */     void cancel(ChannelSftp.Header header, Buffer buf) throws IOException {
/* 1237 */       int _count = this.count;
/* 1238 */       for (int i = 0; i < _count; i++) {
/* 1239 */         header = ChannelSftp.this.header(buf, header);
/* 1240 */         int length = header.length;
/* 1241 */         for (int j = 0; j < this.rrq.length; j++) {
/* 1242 */           if (this.rrq[j].id == header.rid) {
/* 1243 */             this.rrq[j].id = 0;
/* 1244 */             break;
/*      */           }
/*      */         }
/* 1247 */         ChannelSftp.this.skip(length);
/*      */       }
/* 1249 */       init();
/*      */     }
/*      */     
/*      */     long getOffset() {
/* 1253 */       long result = Long.MAX_VALUE;
/*      */       
/* 1255 */       for (int i = 0; i < this.rrq.length; i++) {
/* 1256 */         if (this.rrq[i].id != 0)
/*      */         {
/* 1258 */           if (result > this.rrq[i].offset)
/* 1259 */             result = this.rrq[i].offset;
/*      */         }
/*      */       }
/* 1262 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   public InputStream get(String src) throws SftpException {
/* 1267 */     return get(src, null, 0L);
/*      */   }
/*      */   
/* 1270 */   public InputStream get(String src, SftpProgressMonitor monitor) throws SftpException { return get(src, monitor, 0L); }
/*      */   
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public InputStream get(String src, int mode) throws SftpException
/*      */   {
/* 1277 */     return get(src, null, 0L);
/*      */   }
/*      */   
/*      */   /**
/*      */    * @deprecated
/*      */    */
/* 1283 */   public InputStream get(String src, SftpProgressMonitor monitor, int mode) throws SftpException { return get(src, monitor, 0L); }
/*      */   
/*      */   public InputStream get(String src, SftpProgressMonitor monitor, final long skip) throws SftpException
/*      */   {
/*      */     try {
/* 1288 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1290 */       src = remoteAbsolutePath(src);
/* 1291 */       src = isUnique(src);
/*      */       
/* 1293 */       byte[] srcb = Util.str2byte(src, this.fEncoding);
/*      */       
/* 1295 */       SftpATTRS attr = _stat(srcb);
/* 1296 */       if (monitor != null) {
/* 1297 */         monitor.init(1, src, "??", attr.getSize());
/*      */       }
/*      */       
/* 1300 */       sendOPENR(srcb);
/*      */       
/* 1302 */       Header header = new Header();
/* 1303 */       header = header(this.buf, header);
/* 1304 */       int length = header.length;
/* 1305 */       int type = header.type;
/*      */       
/* 1307 */       fill(this.buf, length);
/*      */       
/* 1309 */       if ((type != 101) && (type != 102)) {
/* 1310 */         throw new SftpException(4, "");
/*      */       }
/* 1312 */       if (type == 101) {
/* 1313 */         int i = this.buf.getInt();
/* 1314 */         throwStatusError(this.buf, i);
/*      */       }
/*      */       
/* 1317 */       final byte[] handle = this.buf.getString();
/*      */       
/* 1319 */       this.rq.init();
/*      */       
/* 1321 */       new InputStream() {
/* 1322 */         long offset = skip;
/* 1323 */         boolean closed = false;
/* 1324 */         int rest_length = 0;
/* 1325 */         byte[] _data = new byte[1];
/* 1326 */         byte[] rest_byte = new byte['Ѐ'];
/* 1327 */         ChannelSftp.Header header = new ChannelSftp.Header(ChannelSftp.this);
/* 1328 */         int request_max = 1;
/* 1329 */         long request_offset = this.offset;
/*      */         
/*      */         public int read() throws IOException {
/* 1332 */           if (this.closed) return -1;
/* 1333 */           int i = read(this._data, 0, 1);
/* 1334 */           if (i == -1) { return -1;
/*      */           }
/* 1336 */           return this._data[0] & 0xFF;
/*      */         }
/*      */         
/*      */         public int read(byte[] d) throws IOException {
/* 1340 */           if (this.closed) return -1;
/* 1341 */           return read(d, 0, d.length);
/*      */         }
/*      */         
/* 1344 */         public int read(byte[] d, int s, int len) throws IOException { if (this.closed) return -1;
/* 1345 */           if (d == null) throw new NullPointerException();
/* 1346 */           if ((s < 0) || (len < 0) || (s + len > d.length)) {
/* 1347 */             throw new IndexOutOfBoundsException();
/*      */           }
/* 1349 */           if (len == 0) { return 0;
/*      */           }
/* 1351 */           if (this.rest_length > 0) {
/* 1352 */             int foo = this.rest_length;
/* 1353 */             if (foo > len) foo = len;
/* 1354 */             System.arraycopy(this.rest_byte, 0, d, s, foo);
/* 1355 */             if (foo != this.rest_length) {
/* 1356 */               System.arraycopy(this.rest_byte, foo, this.rest_byte, 0, this.rest_length - foo);
/*      */             }
/*      */             
/*      */ 
/* 1360 */             if ((handle != null) && 
/* 1361 */               (!handle.count(foo))) {
/* 1362 */               close();
/* 1363 */               return -1;
/*      */             }
/*      */             
/*      */ 
/* 1367 */             this.rest_length -= foo;
/* 1368 */             return foo;
/*      */           }
/*      */           
/* 1371 */           if (ChannelSftp.this.buf.buffer.length - 13 < len) {
/* 1372 */             len = ChannelSftp.this.buf.buffer.length - 13;
/*      */           }
/* 1374 */           if ((ChannelSftp.this.server_version == 0) && (len > 1024)) {
/* 1375 */             len = 1024;
/*      */           }
/*      */           
/* 1378 */           if (ChannelSftp.this.rq.count() == 0) {
/* 1379 */             int request_len = ChannelSftp.this.buf.buffer.length - 13;
/* 1380 */             if (ChannelSftp.this.server_version == 0) { request_len = 1024;
/*      */             }
/* 1382 */             while (ChannelSftp.this.rq.count() < this.request_max) {
/*      */               try {
/* 1384 */                 ChannelSftp.this.sendREAD(this.val$handle, this.request_offset, request_len, ChannelSftp.this.rq);
/*      */               } catch (Exception e) {
/* 1386 */                 throw new IOException("error"); }
/* 1387 */               this.request_offset += request_len;
/*      */             }
/*      */           }
/*      */           
/* 1391 */           this.header = ChannelSftp.this.header(ChannelSftp.this.buf, this.header);
/* 1392 */           this.rest_length = this.header.length;
/* 1393 */           int type = this.header.type;
/* 1394 */           int id = this.header.rid;
/*      */           
/* 1396 */           ChannelSftp.RequestQueue.Request rr = null;
/*      */           try {
/* 1398 */             rr = ChannelSftp.this.rq.get(this.header.rid);
/*      */           }
/*      */           catch (ChannelSftp.RequestQueue.OutOfOrderException e) {
/* 1401 */             this.request_offset = e.offset;
/* 1402 */             skip(this.header.length);
/* 1403 */             ChannelSftp.this.rq.cancel(this.header, ChannelSftp.this.buf);
/* 1404 */             return 0;
/*      */           }
/*      */           catch (SftpException e) {
/* 1407 */             throw new IOException("error: " + e.toString());
/*      */           }
/*      */           
/* 1410 */           if ((type != 101) && (type != 103)) {
/* 1411 */             throw new IOException("error");
/*      */           }
/* 1413 */           if (type == 101) {
/* 1414 */             ChannelSftp.this.fill(ChannelSftp.this.buf, this.rest_length);
/* 1415 */             int i = ChannelSftp.this.buf.getInt();
/* 1416 */             this.rest_length = 0;
/* 1417 */             if (i == 1) {
/* 1418 */               close();
/* 1419 */               return -1;
/*      */             }
/*      */             
/* 1422 */             throw new IOException("error");
/*      */           }
/*      */           
/* 1425 */           ChannelSftp.this.buf.rewind();
/* 1426 */           ChannelSftp.this.fill(ChannelSftp.this.buf.buffer, 0, 4);
/* 1427 */           int length_of_data = ChannelSftp.this.buf.getInt();this.rest_length -= 4;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1439 */           int optional_data = this.rest_length - length_of_data;
/*      */           
/* 1441 */           this.offset += length_of_data;
/* 1442 */           int foo = length_of_data;
/* 1443 */           if (foo > 0) {
/* 1444 */             int bar = foo;
/* 1445 */             if (bar > len) {
/* 1446 */               bar = len;
/*      */             }
/* 1448 */             int i = ChannelSftp.this.io_in.read(d, s, bar);
/* 1449 */             if (i < 0) {
/* 1450 */               return -1;
/*      */             }
/* 1452 */             foo -= i;
/* 1453 */             this.rest_length = foo;
/*      */             
/* 1455 */             if (foo > 0) {
/* 1456 */               if (this.rest_byte.length < foo) {
/* 1457 */                 this.rest_byte = new byte[foo];
/*      */               }
/* 1459 */               int _s = 0;
/* 1460 */               int _len = foo;
/*      */               
/* 1462 */               while (_len > 0) {
/* 1463 */                 int j = ChannelSftp.this.io_in.read(this.rest_byte, _s, _len);
/* 1464 */                 if (j <= 0) break;
/* 1465 */                 _s += j;
/* 1466 */                 _len -= j;
/*      */               }
/*      */             }
/*      */             
/* 1470 */             if (optional_data > 0) {
/* 1471 */               ChannelSftp.this.io_in.skip(optional_data);
/*      */             }
/*      */             
/* 1474 */             if (length_of_data < rr.length) {
/* 1475 */               ChannelSftp.this.rq.cancel(this.header, ChannelSftp.this.buf);
/*      */               try {
/* 1477 */                 ChannelSftp.this.sendREAD(this.val$handle, rr.offset + length_of_data, (int)(rr.length - length_of_data), ChannelSftp.this.rq);
/*      */               }
/*      */               catch (Exception e)
/*      */               {
/* 1481 */                 throw new IOException("error"); }
/* 1482 */               this.request_offset = (rr.offset + rr.length);
/*      */             }
/*      */             
/* 1485 */             if (this.request_max < ChannelSftp.this.rq.size()) {
/* 1486 */               this.request_max += 1;
/*      */             }
/*      */             
/* 1489 */             if ((handle != null) && 
/* 1490 */               (!handle.count(i))) {
/* 1491 */               close();
/* 1492 */               return -1;
/*      */             }
/*      */             
/*      */ 
/* 1496 */             return i;
/*      */           }
/* 1498 */           return 0;
/*      */         }
/*      */         
/* 1501 */         public void close() throws IOException { if (this.closed) return;
/* 1502 */           this.closed = true;
/* 1503 */           if (handle != null) handle.end();
/* 1504 */           ChannelSftp.this.rq.cancel(this.header, ChannelSftp.this.buf);
/* 1505 */           try { ChannelSftp.this._sendCLOSE(this.val$handle, this.header);
/* 1506 */           } catch (Exception e) { throw new IOException("error");
/*      */           }
/*      */         }
/*      */       };
/*      */     }
/*      */     catch (Exception e) {
/* 1512 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1513 */       if ((e instanceof Throwable))
/* 1514 */         throw new SftpException(4, "", e);
/* 1515 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public Vector ls(String path) throws SftpException {
/* 1520 */     final Vector v = new Vector();
/* 1521 */     LsEntrySelector selector = new LsEntrySelector() {
/*      */       public int select(ChannelSftp.LsEntry entry) {
/* 1523 */         v.addElement(entry);
/* 1524 */         return 0;
/*      */       }
/* 1526 */     };
/* 1527 */     ls(path, selector);
/* 1528 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ls(String path, LsEntrySelector selector)
/*      */     throws SftpException
/*      */   {
/*      */     try
/*      */     {
/* 1544 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1546 */       path = remoteAbsolutePath(path);
/* 1547 */       byte[] pattern = null;
/* 1548 */       Vector v = new Vector();
/*      */       
/* 1550 */       int foo = path.lastIndexOf('/');
/* 1551 */       String dir = path.substring(0, foo == 0 ? 1 : foo);
/* 1552 */       String _pattern = path.substring(foo + 1);
/* 1553 */       dir = Util.unquote(dir);
/*      */       
/*      */ 
/*      */ 
/* 1557 */       byte[][] _pattern_utf8 = new byte[1][];
/* 1558 */       boolean pattern_has_wildcard = isPattern(_pattern, _pattern_utf8);
/*      */       
/* 1560 */       if (pattern_has_wildcard) {
/* 1561 */         pattern = _pattern_utf8[0];
/*      */       }
/*      */       else {
/* 1564 */         String upath = Util.unquote(path);
/*      */         
/* 1566 */         SftpATTRS attr = _stat(upath);
/* 1567 */         if (attr.isDir()) {
/* 1568 */           pattern = null;
/* 1569 */           dir = upath;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1581 */         else if (this.fEncoding_is_utf8) {
/* 1582 */           pattern = _pattern_utf8[0];
/* 1583 */           pattern = Util.unquote(pattern);
/*      */         }
/*      */         else {
/* 1586 */           _pattern = Util.unquote(_pattern);
/* 1587 */           pattern = Util.str2byte(_pattern, this.fEncoding);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1593 */       sendOPENDIR(Util.str2byte(dir, this.fEncoding));
/*      */       
/* 1595 */       Header header = new Header();
/* 1596 */       header = header(this.buf, header);
/* 1597 */       int length = header.length;
/* 1598 */       int type = header.type;
/*      */       
/* 1600 */       fill(this.buf, length);
/*      */       
/* 1602 */       if ((type != 101) && (type != 102)) {
/* 1603 */         throw new SftpException(4, "");
/*      */       }
/* 1605 */       if (type == 101) {
/* 1606 */         int i = this.buf.getInt();
/* 1607 */         throwStatusError(this.buf, i);
/*      */       }
/*      */       
/* 1610 */       int cancel = 0;
/* 1611 */       byte[] handle = this.buf.getString();
/*      */       
/* 1613 */       while (cancel == 0)
/*      */       {
/* 1615 */         sendREADDIR(handle);
/*      */         
/* 1617 */         header = header(this.buf, header);
/* 1618 */         length = header.length;
/* 1619 */         type = header.type;
/* 1620 */         if ((type != 101) && (type != 104)) {
/* 1621 */           throw new SftpException(4, "");
/*      */         }
/* 1623 */         if (type == 101) {
/* 1624 */           fill(this.buf, length);
/* 1625 */           int i = this.buf.getInt();
/* 1626 */           if (i == 1)
/*      */             break;
/* 1628 */           throwStatusError(this.buf, i);
/*      */         }
/*      */         
/* 1631 */         this.buf.rewind();
/* 1632 */         fill(this.buf.buffer, 0, 4);length -= 4;
/* 1633 */         int count = this.buf.getInt();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1638 */         this.buf.reset();
/* 1639 */         while (count > 0) {
/* 1640 */           if (length > 0) {
/* 1641 */             this.buf.shift();
/* 1642 */             int j = this.buf.buffer.length > this.buf.index + length ? length : this.buf.buffer.length - this.buf.index;
/*      */             
/*      */ 
/* 1645 */             int i = fill(this.buf.buffer, this.buf.index, j);
/* 1646 */             this.buf.index += i;
/* 1647 */             length -= i;
/*      */           }
/* 1649 */           byte[] filename = this.buf.getString();
/* 1650 */           byte[] longname = null;
/* 1651 */           if (this.server_version <= 3) {
/* 1652 */             longname = this.buf.getString();
/*      */           }
/* 1654 */           SftpATTRS attrs = SftpATTRS.getATTR(this.buf);
/*      */           
/* 1656 */           if (cancel == 1) {
/* 1657 */             count--;
/*      */           }
/*      */           else
/*      */           {
/* 1661 */             boolean find = false;
/* 1662 */             String f = null;
/* 1663 */             if (pattern == null) {
/* 1664 */               find = true;
/*      */             }
/* 1666 */             else if (!pattern_has_wildcard) {
/* 1667 */               find = Util.array_equals(pattern, filename);
/*      */             }
/*      */             else {
/* 1670 */               byte[] _filename = filename;
/* 1671 */               if (!this.fEncoding_is_utf8) {
/* 1672 */                 f = Util.byte2str(_filename, this.fEncoding);
/* 1673 */                 _filename = Util.str2byte(f, "UTF-8");
/*      */               }
/* 1675 */               find = Util.glob(pattern, _filename);
/*      */             }
/*      */             
/* 1678 */             if (find) {
/* 1679 */               if (f == null) {
/* 1680 */                 f = Util.byte2str(filename, this.fEncoding);
/*      */               }
/* 1682 */               String l = null;
/* 1683 */               if (longname == null)
/*      */               {
/*      */ 
/* 1686 */                 l = attrs.toString() + " " + f;
/*      */               }
/*      */               else {
/* 1689 */                 l = Util.byte2str(longname, this.fEncoding);
/*      */               }
/*      */               
/* 1692 */               cancel = selector.select(new LsEntry(f, l, attrs));
/*      */             }
/*      */             
/* 1695 */             count--;
/*      */           }
/*      */         } }
/* 1698 */       _sendCLOSE(handle, header);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1719 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1720 */       if ((e instanceof Throwable))
/* 1721 */         throw new SftpException(4, "", e);
/* 1722 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public String readlink(String path) throws SftpException {
/*      */     try {
/* 1728 */       if (this.server_version < 3) {
/* 1729 */         throw new SftpException(8, "The remote sshd is too old to support symlink operation.");
/*      */       }
/*      */       
/*      */ 
/* 1733 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1735 */       path = remoteAbsolutePath(path);
/*      */       
/* 1737 */       path = isUnique(path);
/*      */       
/* 1739 */       sendREADLINK(Util.str2byte(path, this.fEncoding));
/*      */       
/* 1741 */       Header header = new Header();
/* 1742 */       header = header(this.buf, header);
/* 1743 */       int length = header.length;
/* 1744 */       int type = header.type;
/*      */       
/* 1746 */       fill(this.buf, length);
/*      */       
/* 1748 */       if ((type != 101) && (type != 104)) {
/* 1749 */         throw new SftpException(4, "");
/*      */       }
/* 1751 */       if (type == 104) {
/* 1752 */         int count = this.buf.getInt();
/* 1753 */         byte[] filename = null;
/* 1754 */         for (int i = 0; i < count; i++) {
/* 1755 */           filename = this.buf.getString();
/* 1756 */           byte[] longname; if (this.server_version <= 3) {
/* 1757 */             longname = this.buf.getString();
/*      */           }
/* 1759 */           SftpATTRS.getATTR(this.buf);
/*      */         }
/* 1761 */         return Util.byte2str(filename, this.fEncoding);
/*      */       }
/*      */       
/* 1764 */       int i = this.buf.getInt();
/* 1765 */       throwStatusError(this.buf, i);
/*      */     }
/*      */     catch (Exception e) {
/* 1768 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1769 */       if ((e instanceof Throwable))
/* 1770 */         throw new SftpException(4, "", e);
/* 1771 */       throw new SftpException(4, "");
/*      */     }
/* 1773 */     return null;
/*      */   }
/*      */   
/*      */   public void symlink(String oldpath, String newpath) throws SftpException {
/* 1777 */     if (this.server_version < 3) {
/* 1778 */       throw new SftpException(8, "The remote sshd is too old to support symlink operation.");
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1783 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1785 */       oldpath = remoteAbsolutePath(oldpath);
/* 1786 */       newpath = remoteAbsolutePath(newpath);
/*      */       
/* 1788 */       oldpath = isUnique(oldpath);
/*      */       
/* 1790 */       if (isPattern(newpath)) {
/* 1791 */         throw new SftpException(4, newpath);
/*      */       }
/* 1793 */       newpath = Util.unquote(newpath);
/*      */       
/* 1795 */       sendSYMLINK(Util.str2byte(oldpath, this.fEncoding), Util.str2byte(newpath, this.fEncoding));
/*      */       
/*      */ 
/* 1798 */       Header header = new Header();
/* 1799 */       header = header(this.buf, header);
/* 1800 */       int length = header.length;
/* 1801 */       int type = header.type;
/*      */       
/* 1803 */       fill(this.buf, length);
/*      */       
/* 1805 */       if (type != 101) {
/* 1806 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1809 */       int i = this.buf.getInt();
/* 1810 */       if (i == 0) return;
/* 1811 */       throwStatusError(this.buf, i);
/*      */     }
/*      */     catch (Exception e) {
/* 1814 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1815 */       if ((e instanceof Throwable))
/* 1816 */         throw new SftpException(4, "", e);
/* 1817 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void hardlink(String oldpath, String newpath) throws SftpException {
/* 1822 */     if (!this.extension_hardlink) {
/* 1823 */       throw new SftpException(8, "hardlink@openssh.com is not supported");
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1828 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1830 */       oldpath = remoteAbsolutePath(oldpath);
/* 1831 */       newpath = remoteAbsolutePath(newpath);
/*      */       
/* 1833 */       oldpath = isUnique(oldpath);
/*      */       
/* 1835 */       if (isPattern(newpath)) {
/* 1836 */         throw new SftpException(4, newpath);
/*      */       }
/* 1838 */       newpath = Util.unquote(newpath);
/*      */       
/* 1840 */       sendHARDLINK(Util.str2byte(oldpath, this.fEncoding), Util.str2byte(newpath, this.fEncoding));
/*      */       
/*      */ 
/* 1843 */       Header header = new Header();
/* 1844 */       header = header(this.buf, header);
/* 1845 */       int length = header.length;
/* 1846 */       int type = header.type;
/*      */       
/* 1848 */       fill(this.buf, length);
/*      */       
/* 1850 */       if (type != 101) {
/* 1851 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1854 */       int i = this.buf.getInt();
/* 1855 */       if (i == 0) return;
/* 1856 */       throwStatusError(this.buf, i);
/*      */     }
/*      */     catch (Exception e) {
/* 1859 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1860 */       if ((e instanceof Throwable))
/* 1861 */         throw new SftpException(4, "", e);
/* 1862 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void rename(String oldpath, String newpath) throws SftpException {
/* 1867 */     if (this.server_version < 2) {
/* 1868 */       throw new SftpException(8, "The remote sshd is too old to support rename operation.");
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1873 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1875 */       oldpath = remoteAbsolutePath(oldpath);
/* 1876 */       newpath = remoteAbsolutePath(newpath);
/*      */       
/* 1878 */       oldpath = isUnique(oldpath);
/*      */       
/* 1880 */       Vector v = glob_remote(newpath);
/* 1881 */       int vsize = v.size();
/* 1882 */       if (vsize >= 2) {
/* 1883 */         throw new SftpException(4, v.toString());
/*      */       }
/* 1885 */       if (vsize == 1) {
/* 1886 */         newpath = (String)v.elementAt(0);
/*      */       }
/*      */       else {
/* 1889 */         if (isPattern(newpath))
/* 1890 */           throw new SftpException(4, newpath);
/* 1891 */         newpath = Util.unquote(newpath);
/*      */       }
/*      */       
/* 1894 */       sendRENAME(Util.str2byte(oldpath, this.fEncoding), Util.str2byte(newpath, this.fEncoding));
/*      */       
/*      */ 
/* 1897 */       Header header = new Header();
/* 1898 */       header = header(this.buf, header);
/* 1899 */       int length = header.length;
/* 1900 */       int type = header.type;
/*      */       
/* 1902 */       fill(this.buf, length);
/*      */       
/* 1904 */       if (type != 101) {
/* 1905 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1908 */       int i = this.buf.getInt();
/* 1909 */       if (i == 0) return;
/* 1910 */       throwStatusError(this.buf, i);
/*      */     }
/*      */     catch (Exception e) {
/* 1913 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1914 */       if ((e instanceof Throwable))
/* 1915 */         throw new SftpException(4, "", e);
/* 1916 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void rm(String path) throws SftpException {
/* 1921 */     try { ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1923 */       path = remoteAbsolutePath(path);
/*      */       
/* 1925 */       Vector v = glob_remote(path);
/* 1926 */       int vsize = v.size();
/*      */       
/* 1928 */       Header header = new Header();
/*      */       
/* 1930 */       for (int j = 0; j < vsize; j++) {
/* 1931 */         path = (String)v.elementAt(j);
/* 1932 */         sendREMOVE(Util.str2byte(path, this.fEncoding));
/*      */         
/* 1934 */         header = header(this.buf, header);
/* 1935 */         int length = header.length;
/* 1936 */         int type = header.type;
/*      */         
/* 1938 */         fill(this.buf, length);
/*      */         
/* 1940 */         if (type != 101) {
/* 1941 */           throw new SftpException(4, "");
/*      */         }
/* 1943 */         int i = this.buf.getInt();
/* 1944 */         if (i != 0) {
/* 1945 */           throwStatusError(this.buf, i);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1950 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1951 */       if ((e instanceof Throwable))
/* 1952 */         throw new SftpException(4, "", e);
/* 1953 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isRemoteDir(String path) {
/*      */     try {
/* 1959 */       sendSTAT(Util.str2byte(path, this.fEncoding));
/*      */       
/* 1961 */       Header header = new Header();
/* 1962 */       header = header(this.buf, header);
/* 1963 */       int length = header.length;
/* 1964 */       int type = header.type;
/*      */       
/* 1966 */       fill(this.buf, length);
/*      */       
/* 1968 */       if (type != 105) {
/* 1969 */         return false;
/*      */       }
/* 1971 */       SftpATTRS attr = SftpATTRS.getATTR(this.buf);
/* 1972 */       return attr.isDir();
/*      */     }
/*      */     catch (Exception e) {}
/* 1975 */     return false;
/*      */   }
/*      */   
/*      */   public void chgrp(int gid, String path) throws SftpException {
/*      */     try {
/* 1980 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 1982 */       path = remoteAbsolutePath(path);
/*      */       
/* 1984 */       Vector v = glob_remote(path);
/* 1985 */       int vsize = v.size();
/* 1986 */       for (int j = 0; j < vsize; j++) {
/* 1987 */         path = (String)v.elementAt(j);
/*      */         
/* 1989 */         SftpATTRS attr = _stat(path);
/*      */         
/* 1991 */         attr.setFLAGS(0);
/* 1992 */         attr.setUIDGID(attr.uid, gid);
/* 1993 */         _setStat(path, attr);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1997 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 1998 */       if ((e instanceof Throwable))
/* 1999 */         throw new SftpException(4, "", e);
/* 2000 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void chown(int uid, String path) throws SftpException {
/*      */     try {
/* 2006 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2008 */       path = remoteAbsolutePath(path);
/*      */       
/* 2010 */       Vector v = glob_remote(path);
/* 2011 */       int vsize = v.size();
/* 2012 */       for (int j = 0; j < vsize; j++) {
/* 2013 */         path = (String)v.elementAt(j);
/*      */         
/* 2015 */         SftpATTRS attr = _stat(path);
/*      */         
/* 2017 */         attr.setFLAGS(0);
/* 2018 */         attr.setUIDGID(uid, attr.gid);
/* 2019 */         _setStat(path, attr);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2023 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2024 */       if ((e instanceof Throwable))
/* 2025 */         throw new SftpException(4, "", e);
/* 2026 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void chmod(int permissions, String path) throws SftpException {
/*      */     try {
/* 2032 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2034 */       path = remoteAbsolutePath(path);
/*      */       
/* 2036 */       Vector v = glob_remote(path);
/* 2037 */       int vsize = v.size();
/* 2038 */       for (int j = 0; j < vsize; j++) {
/* 2039 */         path = (String)v.elementAt(j);
/*      */         
/* 2041 */         SftpATTRS attr = _stat(path);
/*      */         
/* 2043 */         attr.setFLAGS(0);
/* 2044 */         attr.setPERMISSIONS(permissions);
/* 2045 */         _setStat(path, attr);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2049 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2050 */       if ((e instanceof Throwable))
/* 2051 */         throw new SftpException(4, "", e);
/* 2052 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMtime(String path, int mtime) throws SftpException {
/*      */     try {
/* 2058 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2060 */       path = remoteAbsolutePath(path);
/*      */       
/* 2062 */       Vector v = glob_remote(path);
/* 2063 */       int vsize = v.size();
/* 2064 */       for (int j = 0; j < vsize; j++) {
/* 2065 */         path = (String)v.elementAt(j);
/*      */         
/* 2067 */         SftpATTRS attr = _stat(path);
/*      */         
/* 2069 */         attr.setFLAGS(0);
/* 2070 */         attr.setACMODTIME(attr.getATime(), mtime);
/* 2071 */         _setStat(path, attr);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2075 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2076 */       if ((e instanceof Throwable))
/* 2077 */         throw new SftpException(4, "", e);
/* 2078 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void rmdir(String path) throws SftpException {
/*      */     try {
/* 2084 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2086 */       path = remoteAbsolutePath(path);
/*      */       
/* 2088 */       Vector v = glob_remote(path);
/* 2089 */       int vsize = v.size();
/*      */       
/* 2091 */       Header header = new Header();
/*      */       
/* 2093 */       for (int j = 0; j < vsize; j++) {
/* 2094 */         path = (String)v.elementAt(j);
/* 2095 */         sendRMDIR(Util.str2byte(path, this.fEncoding));
/*      */         
/* 2097 */         header = header(this.buf, header);
/* 2098 */         int length = header.length;
/* 2099 */         int type = header.type;
/*      */         
/* 2101 */         fill(this.buf, length);
/*      */         
/* 2103 */         if (type != 101) {
/* 2104 */           throw new SftpException(4, "");
/*      */         }
/*      */         
/* 2107 */         int i = this.buf.getInt();
/* 2108 */         if (i != 0) {
/* 2109 */           throwStatusError(this.buf, i);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2114 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2115 */       if ((e instanceof Throwable))
/* 2116 */         throw new SftpException(4, "", e);
/* 2117 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public void mkdir(String path) throws SftpException {
/*      */     try {
/* 2123 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2125 */       path = remoteAbsolutePath(path);
/*      */       
/* 2127 */       sendMKDIR(Util.str2byte(path, this.fEncoding), null);
/*      */       
/* 2129 */       Header header = new Header();
/* 2130 */       header = header(this.buf, header);
/* 2131 */       int length = header.length;
/* 2132 */       int type = header.type;
/*      */       
/* 2134 */       fill(this.buf, length);
/*      */       
/* 2136 */       if (type != 101) {
/* 2137 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 2140 */       int i = this.buf.getInt();
/* 2141 */       if (i == 0) return;
/* 2142 */       throwStatusError(this.buf, i);
/*      */     }
/*      */     catch (Exception e) {
/* 2145 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2146 */       if ((e instanceof Throwable))
/* 2147 */         throw new SftpException(4, "", e);
/* 2148 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   public SftpATTRS stat(String path) throws SftpException {
/*      */     try {
/* 2154 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2156 */       path = remoteAbsolutePath(path);
/* 2157 */       path = isUnique(path);
/*      */       
/* 2159 */       return _stat(path);
/*      */     }
/*      */     catch (Exception e) {
/* 2162 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2163 */       if ((e instanceof Throwable))
/* 2164 */         throw new SftpException(4, "", e);
/* 2165 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private SftpATTRS _stat(byte[] path) throws SftpException
/*      */   {
/*      */     try
/*      */     {
/* 2173 */       sendSTAT(path);
/*      */       
/* 2175 */       Header header = new Header();
/* 2176 */       header = header(this.buf, header);
/* 2177 */       int length = header.length;
/* 2178 */       int type = header.type;
/*      */       
/* 2180 */       fill(this.buf, length);
/*      */       
/* 2182 */       if (type != 105) {
/* 2183 */         if (type == 101) {
/* 2184 */           int i = this.buf.getInt();
/* 2185 */           throwStatusError(this.buf, i);
/*      */         }
/* 2187 */         throw new SftpException(4, "");
/*      */       }
/* 2189 */       return SftpATTRS.getATTR(this.buf);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2193 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2194 */       if ((e instanceof Throwable))
/* 2195 */         throw new SftpException(4, "", e);
/* 2196 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private SftpATTRS _stat(String path) throws SftpException
/*      */   {
/* 2202 */     return _stat(Util.str2byte(path, this.fEncoding));
/*      */   }
/*      */   
/*      */   public SftpStatVFS statVFS(String path) throws SftpException {
/*      */     try {
/* 2207 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2209 */       path = remoteAbsolutePath(path);
/* 2210 */       path = isUnique(path);
/*      */       
/* 2212 */       return _statVFS(path);
/*      */     }
/*      */     catch (Exception e) {
/* 2215 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2216 */       if ((e instanceof Throwable))
/* 2217 */         throw new SftpException(4, "", e);
/* 2218 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private SftpStatVFS _statVFS(byte[] path) throws SftpException
/*      */   {
/* 2224 */     if (!this.extension_statvfs) {
/* 2225 */       throw new SftpException(8, "statvfs@openssh.com is not supported");
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2231 */       sendSTATVFS(path);
/*      */       
/* 2233 */       Header header = new Header();
/* 2234 */       header = header(this.buf, header);
/* 2235 */       int length = header.length;
/* 2236 */       int type = header.type;
/*      */       
/* 2238 */       fill(this.buf, length);
/*      */       
/* 2240 */       if (type != 201) {
/* 2241 */         if (type == 101) {
/* 2242 */           int i = this.buf.getInt();
/* 2243 */           throwStatusError(this.buf, i);
/*      */         }
/* 2245 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 2248 */       return SftpStatVFS.getStatVFS(this.buf);
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2253 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2254 */       if ((e instanceof Throwable))
/* 2255 */         throw new SftpException(4, "", e);
/* 2256 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private SftpStatVFS _statVFS(String path) throws SftpException
/*      */   {
/* 2262 */     return _statVFS(Util.str2byte(path, this.fEncoding));
/*      */   }
/*      */   
/*      */   public SftpATTRS lstat(String path) throws SftpException {
/*      */     try {
/* 2267 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2269 */       path = remoteAbsolutePath(path);
/* 2270 */       path = isUnique(path);
/*      */       
/* 2272 */       return _lstat(path);
/*      */     }
/*      */     catch (Exception e) {
/* 2275 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2276 */       if ((e instanceof Throwable))
/* 2277 */         throw new SftpException(4, "", e);
/* 2278 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private SftpATTRS _lstat(String path) throws SftpException {
/*      */     try {
/* 2284 */       sendLSTAT(Util.str2byte(path, this.fEncoding));
/*      */       
/* 2286 */       Header header = new Header();
/* 2287 */       header = header(this.buf, header);
/* 2288 */       int length = header.length;
/* 2289 */       int type = header.type;
/*      */       
/* 2291 */       fill(this.buf, length);
/*      */       
/* 2293 */       if (type != 105) {
/* 2294 */         if (type == 101) {
/* 2295 */           int i = this.buf.getInt();
/* 2296 */           throwStatusError(this.buf, i);
/*      */         }
/* 2298 */         throw new SftpException(4, "");
/*      */       }
/* 2300 */       return SftpATTRS.getATTR(this.buf);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2304 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2305 */       if ((e instanceof Throwable))
/* 2306 */         throw new SftpException(4, "", e);
/* 2307 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private byte[] _realpath(String path) throws SftpException, IOException, Exception {
/* 2312 */     sendREALPATH(Util.str2byte(path, this.fEncoding));
/*      */     
/* 2314 */     Header header = new Header();
/* 2315 */     header = header(this.buf, header);
/* 2316 */     int length = header.length;
/* 2317 */     int type = header.type;
/*      */     
/* 2319 */     fill(this.buf, length);
/*      */     
/* 2321 */     if ((type != 101) && (type != 104)) {
/* 2322 */       throw new SftpException(4, "");
/*      */     }
/*      */     
/* 2325 */     if (type == 101) {
/* 2326 */       int i = this.buf.getInt();
/* 2327 */       throwStatusError(this.buf, i);
/*      */     }
/* 2329 */     int i = this.buf.getInt();
/*      */     
/* 2331 */     byte[] str = null;
/* 2332 */     SftpATTRS attr; while (i-- > 0) {
/* 2333 */       str = this.buf.getString();
/* 2334 */       byte[] lname; if (this.server_version <= 3) {
/* 2335 */         lname = this.buf.getString();
/*      */       }
/* 2337 */       attr = SftpATTRS.getATTR(this.buf);
/*      */     }
/* 2339 */     return str;
/*      */   }
/*      */   
/*      */   public void setStat(String path, SftpATTRS attr) throws SftpException {
/*      */     try {
/* 2344 */       ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */       
/* 2346 */       path = remoteAbsolutePath(path);
/*      */       
/* 2348 */       Vector v = glob_remote(path);
/* 2349 */       int vsize = v.size();
/* 2350 */       for (int j = 0; j < vsize; j++) {
/* 2351 */         path = (String)v.elementAt(j);
/* 2352 */         _setStat(path, attr);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2356 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2357 */       if ((e instanceof Throwable))
/* 2358 */         throw new SftpException(4, "", e);
/* 2359 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/*      */   private void _setStat(String path, SftpATTRS attr) throws SftpException {
/* 2364 */     try { sendSETSTAT(Util.str2byte(path, this.fEncoding), attr);
/*      */       
/* 2366 */       Header header = new Header();
/* 2367 */       header = header(this.buf, header);
/* 2368 */       int length = header.length;
/* 2369 */       int type = header.type;
/*      */       
/* 2371 */       fill(this.buf, length);
/*      */       
/* 2373 */       if (type != 101) {
/* 2374 */         throw new SftpException(4, "");
/*      */       }
/* 2376 */       int i = this.buf.getInt();
/* 2377 */       if (i != 0) {
/* 2378 */         throwStatusError(this.buf, i);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 2382 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2383 */       if ((e instanceof Throwable))
/* 2384 */         throw new SftpException(4, "", e);
/* 2385 */       throw new SftpException(4, "");
/*      */     }
/*      */   }
/*      */   
/* 2389 */   public String pwd() throws SftpException { return getCwd(); }
/* 2390 */   public String lpwd() { return this.lcwd; }
/* 2391 */   public String version() { return this.version; }
/*      */   
/* 2393 */   public String getHome() throws SftpException { if (this.home == null) {
/*      */       try {
/* 2395 */         ((Channel.MyPipedInputStream)this.io_in).updateReadSide();
/*      */         
/* 2397 */         byte[] _home = _realpath("");
/* 2398 */         this.home = Util.byte2str(_home, this.fEncoding);
/*      */       }
/*      */       catch (Exception e) {
/* 2401 */         if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2402 */         if ((e instanceof Throwable))
/* 2403 */           throw new SftpException(4, "", e);
/* 2404 */         throw new SftpException(4, "");
/*      */       }
/*      */     }
/* 2407 */     return this.home;
/*      */   }
/*      */   
/*      */   private String getCwd() throws SftpException {
/* 2411 */     if (this.cwd == null)
/* 2412 */       this.cwd = getHome();
/* 2413 */     return this.cwd;
/*      */   }
/*      */   
/*      */   private void setCwd(String cwd) {
/* 2417 */     this.cwd = cwd;
/*      */   }
/*      */   
/*      */   private void read(byte[] buf, int s, int l) throws IOException, SftpException {
/* 2421 */     int i = 0;
/* 2422 */     while (l > 0) {
/* 2423 */       i = this.io_in.read(buf, s, l);
/* 2424 */       if (i <= 0) {
/* 2425 */         throw new SftpException(4, "");
/*      */       }
/* 2427 */       s += i;
/* 2428 */       l -= i;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean checkStatus(int[] ackid, Header header) throws IOException, SftpException {
/* 2433 */     header = header(this.buf, header);
/* 2434 */     int length = header.length;
/* 2435 */     int type = header.type;
/* 2436 */     if (ackid != null) {
/* 2437 */       ackid[0] = header.rid;
/*      */     }
/* 2439 */     fill(this.buf, length);
/*      */     
/* 2441 */     if (type != 101) {
/* 2442 */       throw new SftpException(4, "");
/*      */     }
/* 2444 */     int i = this.buf.getInt();
/* 2445 */     if (i != 0) {
/* 2446 */       throwStatusError(this.buf, i);
/*      */     }
/* 2448 */     return true;
/*      */   }
/*      */   
/* 2451 */   private boolean _sendCLOSE(byte[] handle, Header header) throws Exception { sendCLOSE(handle);
/* 2452 */     return checkStatus(null, header);
/*      */   }
/*      */   
/*      */   private void sendINIT() throws Exception {
/* 2456 */     this.packet.reset();
/* 2457 */     putHEAD((byte)1, 5);
/* 2458 */     this.buf.putInt(3);
/* 2459 */     getSession().write(this.packet, this, 9);
/*      */   }
/*      */   
/*      */   private void sendREALPATH(byte[] path) throws Exception {
/* 2463 */     sendPacketPath((byte)16, path);
/*      */   }
/*      */   
/* 2466 */   private void sendSTAT(byte[] path) throws Exception { sendPacketPath((byte)17, path); }
/*      */   
/*      */   private void sendSTATVFS(byte[] path) throws Exception {
/* 2469 */     sendPacketPath((byte)0, path, "statvfs@openssh.com");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void sendLSTAT(byte[] path)
/*      */     throws Exception
/*      */   {
/* 2477 */     sendPacketPath((byte)7, path);
/*      */   }
/*      */   
/* 2480 */   private void sendFSTAT(byte[] handle) throws Exception { sendPacketPath((byte)8, handle); }
/*      */   
/*      */   private void sendSETSTAT(byte[] path, SftpATTRS attr) throws Exception {
/* 2483 */     this.packet.reset();
/* 2484 */     putHEAD((byte)9, 9 + path.length + attr.length());
/* 2485 */     this.buf.putInt(this.seq++);
/* 2486 */     this.buf.putString(path);
/* 2487 */     attr.dump(this.buf);
/* 2488 */     getSession().write(this.packet, this, 9 + path.length + attr.length() + 4);
/*      */   }
/*      */   
/* 2491 */   private void sendREMOVE(byte[] path) throws Exception { sendPacketPath((byte)13, path); }
/*      */   
/*      */   private void sendMKDIR(byte[] path, SftpATTRS attr) throws Exception {
/* 2494 */     this.packet.reset();
/* 2495 */     putHEAD((byte)14, 9 + path.length + (attr != null ? attr.length() : 4));
/* 2496 */     this.buf.putInt(this.seq++);
/* 2497 */     this.buf.putString(path);
/* 2498 */     if (attr != null) attr.dump(this.buf); else
/* 2499 */       this.buf.putInt(0);
/* 2500 */     getSession().write(this.packet, this, 9 + path.length + (attr != null ? attr.length() : 4) + 4);
/*      */   }
/*      */   
/* 2503 */   private void sendRMDIR(byte[] path) throws Exception { sendPacketPath((byte)15, path); }
/*      */   
/*      */   private void sendSYMLINK(byte[] p1, byte[] p2) throws Exception {
/* 2506 */     sendPacketPath((byte)20, p1, p2);
/*      */   }
/*      */   
/* 2509 */   private void sendHARDLINK(byte[] p1, byte[] p2) throws Exception { sendPacketPath((byte)0, p1, p2, "hardlink@openssh.com"); }
/*      */   
/*      */   private void sendREADLINK(byte[] path) throws Exception {
/* 2512 */     sendPacketPath((byte)19, path);
/*      */   }
/*      */   
/* 2515 */   private void sendOPENDIR(byte[] path) throws Exception { sendPacketPath((byte)11, path); }
/*      */   
/*      */   private void sendREADDIR(byte[] path) throws Exception {
/* 2518 */     sendPacketPath((byte)12, path);
/*      */   }
/*      */   
/* 2521 */   private void sendRENAME(byte[] p1, byte[] p2) throws Exception { sendPacketPath((byte)18, p1, p2, this.extension_posix_rename ? "posix-rename@openssh.com" : null); }
/*      */   
/*      */   private void sendCLOSE(byte[] path) throws Exception
/*      */   {
/* 2525 */     sendPacketPath((byte)4, path);
/*      */   }
/*      */   
/* 2528 */   private void sendOPENR(byte[] path) throws Exception { sendOPEN(path, 1); }
/*      */   
/*      */   private void sendOPENW(byte[] path) throws Exception {
/* 2531 */     sendOPEN(path, 26);
/*      */   }
/*      */   
/* 2534 */   private void sendOPENA(byte[] path) throws Exception { sendOPEN(path, 10); }
/*      */   
/*      */   private void sendOPEN(byte[] path, int mode) throws Exception {
/* 2537 */     this.packet.reset();
/* 2538 */     putHEAD((byte)3, 17 + path.length);
/* 2539 */     this.buf.putInt(this.seq++);
/* 2540 */     this.buf.putString(path);
/* 2541 */     this.buf.putInt(mode);
/* 2542 */     this.buf.putInt(0);
/* 2543 */     getSession().write(this.packet, this, 17 + path.length + 4);
/*      */   }
/*      */   
/* 2546 */   private void sendPacketPath(byte fxp, byte[] path) throws Exception { sendPacketPath(fxp, path, (String)null); }
/*      */   
/*      */   private void sendPacketPath(byte fxp, byte[] path, String extension) throws Exception {
/* 2549 */     this.packet.reset();
/* 2550 */     int len = 9 + path.length;
/* 2551 */     if (extension == null) {
/* 2552 */       putHEAD(fxp, len);
/* 2553 */       this.buf.putInt(this.seq++);
/*      */     }
/*      */     else {
/* 2556 */       len += 4 + extension.length();
/* 2557 */       putHEAD((byte)-56, len);
/* 2558 */       this.buf.putInt(this.seq++);
/* 2559 */       this.buf.putString(Util.str2byte(extension));
/*      */     }
/* 2561 */     this.buf.putString(path);
/* 2562 */     getSession().write(this.packet, this, len + 4);
/*      */   }
/*      */   
/*      */ 
/* 2566 */   private void sendPacketPath(byte fxp, byte[] p1, byte[] p2) throws Exception { sendPacketPath(fxp, p1, p2, null); }
/*      */   
/*      */   private void sendPacketPath(byte fxp, byte[] p1, byte[] p2, String extension) throws Exception {
/* 2569 */     this.packet.reset();
/* 2570 */     int len = 13 + p1.length + p2.length;
/* 2571 */     if (extension == null) {
/* 2572 */       putHEAD(fxp, len);
/* 2573 */       this.buf.putInt(this.seq++);
/*      */     }
/*      */     else {
/* 2576 */       len += 4 + extension.length();
/* 2577 */       putHEAD((byte)-56, len);
/* 2578 */       this.buf.putInt(this.seq++);
/* 2579 */       this.buf.putString(Util.str2byte(extension));
/*      */     }
/* 2581 */     this.buf.putString(p1);
/* 2582 */     this.buf.putString(p2);
/* 2583 */     getSession().write(this.packet, this, len + 4);
/*      */   }
/*      */   
/*      */   private int sendWRITE(byte[] handle, long offset, byte[] data, int start, int length) throws Exception
/*      */   {
/* 2588 */     int _length = length;
/* 2589 */     this.opacket.reset();
/* 2590 */     if (this.obuf.buffer.length < this.obuf.index + 13 + 21 + handle.length + length + 84) {
/* 2591 */       _length = this.obuf.buffer.length - (this.obuf.index + 13 + 21 + handle.length + 84);
/*      */     }
/*      */     
/*      */ 
/* 2595 */     putHEAD(this.obuf, (byte)6, 21 + handle.length + _length);
/* 2596 */     this.obuf.putInt(this.seq++);
/* 2597 */     this.obuf.putString(handle);
/* 2598 */     this.obuf.putLong(offset);
/* 2599 */     if (this.obuf.buffer != data) {
/* 2600 */       this.obuf.putString(data, start, _length);
/*      */     }
/*      */     else {
/* 2603 */       this.obuf.putInt(_length);
/* 2604 */       this.obuf.skip(_length);
/*      */     }
/* 2606 */     getSession().write(this.opacket, this, 21 + handle.length + _length + 4);
/* 2607 */     return _length;
/*      */   }
/*      */   
/* 2610 */   private void sendREAD(byte[] handle, long offset, int length) throws Exception { sendREAD(handle, offset, length, null); }
/*      */   
/*      */   private void sendREAD(byte[] handle, long offset, int length, RequestQueue rrq) throws Exception
/*      */   {
/* 2614 */     this.packet.reset();
/* 2615 */     putHEAD((byte)5, 21 + handle.length);
/* 2616 */     this.buf.putInt(this.seq++);
/* 2617 */     this.buf.putString(handle);
/* 2618 */     this.buf.putLong(offset);
/* 2619 */     this.buf.putInt(length);
/* 2620 */     getSession().write(this.packet, this, 21 + handle.length + 4);
/* 2621 */     if (rrq != null) {
/* 2622 */       rrq.add(this.seq - 1, offset, length);
/*      */     }
/*      */   }
/*      */   
/*      */   private void putHEAD(Buffer buf, byte type, int length) throws Exception {
/* 2627 */     buf.putByte((byte)94);
/* 2628 */     buf.putInt(this.recipient);
/* 2629 */     buf.putInt(length + 4);
/* 2630 */     buf.putInt(length);
/* 2631 */     buf.putByte(type);
/*      */   }
/*      */   
/*      */   private void putHEAD(byte type, int length) throws Exception {
/* 2635 */     putHEAD(this.buf, type, length);
/*      */   }
/*      */   
/*      */   private Vector glob_remote(String _path) throws Exception {
/* 2639 */     Vector v = new Vector();
/* 2640 */     int i = 0;
/*      */     
/* 2642 */     int foo = _path.lastIndexOf('/');
/* 2643 */     if (foo < 0) {
/* 2644 */       v.addElement(Util.unquote(_path));
/* 2645 */       return v;
/*      */     }
/*      */     
/* 2648 */     String dir = _path.substring(0, foo == 0 ? 1 : foo);
/* 2649 */     String _pattern = _path.substring(foo + 1);
/*      */     
/* 2651 */     dir = Util.unquote(dir);
/*      */     
/* 2653 */     byte[] pattern = null;
/* 2654 */     byte[][] _pattern_utf8 = new byte[1][];
/* 2655 */     boolean pattern_has_wildcard = isPattern(_pattern, _pattern_utf8);
/*      */     
/* 2657 */     if (!pattern_has_wildcard) {
/* 2658 */       if (!dir.equals("/"))
/* 2659 */         dir = dir + "/";
/* 2660 */       v.addElement(dir + Util.unquote(_pattern));
/* 2661 */       return v;
/*      */     }
/*      */     
/* 2664 */     pattern = _pattern_utf8[0];
/*      */     
/* 2666 */     sendOPENDIR(Util.str2byte(dir, this.fEncoding));
/*      */     
/* 2668 */     Header header = new Header();
/* 2669 */     header = header(this.buf, header);
/* 2670 */     int length = header.length;
/* 2671 */     int type = header.type;
/*      */     
/* 2673 */     fill(this.buf, length);
/*      */     
/* 2675 */     if ((type != 101) && (type != 102)) {
/* 2676 */       throw new SftpException(4, "");
/*      */     }
/* 2678 */     if (type == 101) {
/* 2679 */       i = this.buf.getInt();
/* 2680 */       throwStatusError(this.buf, i);
/*      */     }
/*      */     
/* 2683 */     byte[] handle = this.buf.getString();
/* 2684 */     String pdir = null;
/*      */     for (;;)
/*      */     {
/* 2687 */       sendREADDIR(handle);
/* 2688 */       header = header(this.buf, header);
/* 2689 */       length = header.length;
/* 2690 */       type = header.type;
/*      */       
/* 2692 */       if ((type != 101) && (type != 104)) {
/* 2693 */         throw new SftpException(4, "");
/*      */       }
/* 2695 */       if (type == 101) {
/* 2696 */         fill(this.buf, length);
/* 2697 */         break;
/*      */       }
/*      */       
/* 2700 */       this.buf.rewind();
/* 2701 */       fill(this.buf.buffer, 0, 4);length -= 4;
/* 2702 */       int count = this.buf.getInt();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2707 */       this.buf.reset();
/* 2708 */       while (count > 0) {
/* 2709 */         if (length > 0) {
/* 2710 */           this.buf.shift();
/* 2711 */           int j = this.buf.buffer.length > this.buf.index + length ? length : this.buf.buffer.length - this.buf.index;
/* 2712 */           i = this.io_in.read(this.buf.buffer, this.buf.index, j);
/* 2713 */           if (i <= 0) break;
/* 2714 */           this.buf.index += i;
/* 2715 */           length -= i;
/*      */         }
/*      */         
/* 2718 */         byte[] filename = this.buf.getString();
/*      */         
/* 2720 */         if (this.server_version <= 3) {
/* 2721 */           byte[] arrayOfByte1 = this.buf.getString();
/*      */         }
/* 2723 */         SftpATTRS attrs = SftpATTRS.getATTR(this.buf);
/*      */         
/* 2725 */         byte[] _filename = filename;
/* 2726 */         String f = null;
/* 2727 */         boolean found = false;
/*      */         
/* 2729 */         if (!this.fEncoding_is_utf8) {
/* 2730 */           f = Util.byte2str(filename, this.fEncoding);
/* 2731 */           _filename = Util.str2byte(f, "UTF-8");
/*      */         }
/* 2733 */         found = Util.glob(pattern, _filename);
/*      */         
/* 2735 */         if (found) {
/* 2736 */           if (f == null) {
/* 2737 */             f = Util.byte2str(filename, this.fEncoding);
/*      */           }
/* 2739 */           if (pdir == null) {
/* 2740 */             pdir = dir;
/* 2741 */             if (!pdir.endsWith("/")) {
/* 2742 */               pdir = pdir + "/";
/*      */             }
/*      */           }
/* 2745 */           v.addElement(pdir + f);
/*      */         }
/* 2747 */         count--;
/*      */       }
/*      */     }
/* 2750 */     if (_sendCLOSE(handle, header))
/* 2751 */       return v;
/* 2752 */     return null;
/*      */   }
/*      */   
/*      */   private boolean isPattern(byte[] path) {
/* 2756 */     int length = path.length;
/* 2757 */     int i = 0;
/* 2758 */     while (i < length) {
/* 2759 */       if ((path[i] == 42) || (path[i] == 63))
/* 2760 */         return true;
/* 2761 */       if ((path[i] == 92) && (i + 1 < length))
/* 2762 */         i++;
/* 2763 */       i++;
/*      */     }
/* 2765 */     return false;
/*      */   }
/*      */   
/*      */   private Vector glob_local(String _path) throws Exception
/*      */   {
/* 2770 */     Vector v = new Vector();
/* 2771 */     byte[] path = Util.str2byte(_path, "UTF-8");
/* 2772 */     int i = path.length - 1;
/* 2773 */     while (i >= 0) {
/* 2774 */       if ((path[i] != 42) && (path[i] != 63)) {
/* 2775 */         i--;
/*      */       }
/*      */       else {
/* 2778 */         if ((fs_is_bs) || (i <= 0) || (path[(i - 1)] != 92))
/*      */           break;
/* 2780 */         i--;
/* 2781 */         if ((i <= 0) || (path[(i - 1)] != 92)) break;
/* 2782 */         i--;
/* 2783 */         i--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2790 */     if (i < 0) { v.addElement(fs_is_bs ? _path : Util.unquote(_path));return v;
/*      */     }
/* 2792 */     while ((i >= 0) && 
/* 2793 */       (path[i] != file_separatorc) && ((!fs_is_bs) || (path[i] != 47)))
/*      */     {
/*      */ 
/*      */ 
/* 2797 */       i--;
/*      */     }
/*      */     
/* 2800 */     if (i < 0) { v.addElement(fs_is_bs ? _path : Util.unquote(_path));return v; }
/*      */     byte[] dir;
/*      */     byte[] dir;
/* 2803 */     if (i == 0) { dir = new byte[] { (byte)file_separatorc };
/*      */     } else {
/* 2805 */       dir = new byte[i];
/* 2806 */       System.arraycopy(path, 0, dir, 0, i);
/*      */     }
/*      */     
/* 2809 */     byte[] pattern = new byte[path.length - i - 1];
/* 2810 */     System.arraycopy(path, i + 1, pattern, 0, pattern.length);
/*      */     
/*      */     try
/*      */     {
/* 2814 */       String[] children = new File(Util.byte2str(dir, "UTF-8")).list();
/* 2815 */       String pdir = Util.byte2str(dir) + file_separator;
/* 2816 */       for (int j = 0; j < children.length; j++)
/*      */       {
/* 2818 */         if (Util.glob(pattern, Util.str2byte(children[j], "UTF-8"))) {
/* 2819 */           v.addElement(pdir + children[j]);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/* 2825 */     return v;
/*      */   }
/*      */   
/*      */   private void throwStatusError(Buffer buf, int i) throws SftpException {
/* 2829 */     if ((this.server_version >= 3) && (buf.getLength() >= 4))
/*      */     {
/* 2831 */       byte[] str = buf.getString();
/*      */       
/* 2833 */       throw new SftpException(i, Util.byte2str(str, "UTF-8"));
/*      */     }
/*      */     
/* 2836 */     throw new SftpException(i, "Failure");
/*      */   }
/*      */   
/*      */   private static boolean isLocalAbsolutePath(String path)
/*      */   {
/* 2841 */     return new File(path).isAbsolute();
/*      */   }
/*      */   
/*      */   public void disconnect() {
/* 2845 */     super.disconnect();
/*      */   }
/*      */   
/*      */   private boolean isPattern(String path, byte[][] utf8) {
/* 2849 */     byte[] _path = Util.str2byte(path, "UTF-8");
/* 2850 */     if (utf8 != null)
/* 2851 */       utf8[0] = _path;
/* 2852 */     return isPattern(_path);
/*      */   }
/*      */   
/*      */   private boolean isPattern(String path) {
/* 2856 */     return isPattern(path, (byte[][])null);
/*      */   }
/*      */   
/*      */   private void fill(Buffer buf, int len) throws IOException {
/* 2860 */     buf.reset();
/* 2861 */     fill(buf.buffer, 0, len);
/* 2862 */     buf.skip(len);
/*      */   }
/*      */   
/*      */   private int fill(byte[] buf, int s, int len) throws IOException {
/* 2866 */     int i = 0;
/* 2867 */     int foo = s;
/* 2868 */     while (len > 0) {
/* 2869 */       i = this.io_in.read(buf, s, len);
/* 2870 */       if (i <= 0) {
/* 2871 */         throw new IOException("inputstream is closed");
/*      */       }
/*      */       
/* 2874 */       s += i;
/* 2875 */       len -= i;
/*      */     }
/* 2877 */     return s - foo;
/*      */   }
/*      */   
/* 2880 */   private void skip(long foo) throws IOException { while (foo > 0L) {
/* 2881 */       long bar = this.io_in.skip(foo);
/* 2882 */       if (bar <= 0L)
/*      */         break;
/* 2884 */       foo -= bar;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Header header(Buffer buf, Header header)
/*      */     throws IOException
/*      */   {
/* 2894 */     buf.rewind();
/* 2895 */     int i = fill(buf.buffer, 0, 9);
/* 2896 */     header.length = (buf.getInt() - 5);
/* 2897 */     header.type = (buf.getByte() & 0xFF);
/* 2898 */     header.rid = buf.getInt();
/* 2899 */     return header;
/*      */   }
/*      */   
/*      */   private String remoteAbsolutePath(String path) throws SftpException {
/* 2903 */     if (path.charAt(0) == '/') return path;
/* 2904 */     String cwd = getCwd();
/*      */     
/* 2906 */     if (cwd.endsWith("/")) return cwd + path;
/* 2907 */     return cwd + "/" + path;
/*      */   }
/*      */   
/*      */   private String localAbsolutePath(String path) {
/* 2911 */     if (isLocalAbsolutePath(path)) return path;
/* 2912 */     if (this.lcwd.endsWith(file_separator)) return this.lcwd + path;
/* 2913 */     return this.lcwd + file_separator + path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String isUnique(String path)
/*      */     throws SftpException, Exception
/*      */   {
/* 2923 */     Vector v = glob_remote(path);
/* 2924 */     if (v.size() != 1) {
/* 2925 */       throw new SftpException(4, path + " is not unique: " + v.toString());
/*      */     }
/* 2927 */     return (String)v.elementAt(0);
/*      */   }
/*      */   
/*      */   public int getServerVersion() throws SftpException {
/* 2931 */     if (!isConnected()) {
/* 2932 */       throw new SftpException(4, "The channel is not connected.");
/*      */     }
/* 2934 */     return this.server_version;
/*      */   }
/*      */   
/*      */   public void setFilenameEncoding(String encoding) throws SftpException {
/* 2938 */     int sversion = getServerVersion();
/* 2939 */     if ((3 <= sversion) && (sversion <= 5) && (!encoding.equals("UTF-8")))
/*      */     {
/* 2941 */       throw new SftpException(4, "The encoding can not be changed for this sftp server.");
/*      */     }
/*      */     
/* 2944 */     if (encoding.equals("UTF-8")) {
/* 2945 */       encoding = "UTF-8";
/*      */     }
/* 2947 */     this.fEncoding = encoding;
/* 2948 */     this.fEncoding_is_utf8 = this.fEncoding.equals("UTF-8");
/*      */   }
/*      */   
/*      */   public String getExtension(String key) {
/* 2952 */     if (this.extensions == null)
/* 2953 */       return null;
/* 2954 */     return (String)this.extensions.get(key);
/*      */   }
/*      */   
/*      */   public String realpath(String path) throws SftpException {
/*      */     try {
/* 2959 */       byte[] _path = _realpath(remoteAbsolutePath(path));
/* 2960 */       return Util.byte2str(_path, this.fEncoding);
/*      */     }
/*      */     catch (Exception e) {
/* 2963 */       if ((e instanceof SftpException)) throw ((SftpException)e);
/* 2964 */       if ((e instanceof Throwable))
/* 2965 */         throw new SftpException(4, "", e);
/* 2966 */       throw new SftpException(4, "");
/*      */     } }
/*      */   
/*      */   class Header { int length;
/*      */     int type;
/*      */     int rid;
/*      */     
/*      */     Header() {} }
/*      */   
/* 2975 */   public class LsEntry implements Comparable { LsEntry(String filename, String longname, SftpATTRS attrs) { setFilename(filename);
/* 2976 */       setLongname(longname);
/* 2977 */       setAttrs(attrs); }
/*      */     
/* 2979 */     public String getFilename() { return this.filename; }
/* 2980 */     void setFilename(String filename) { this.filename = filename; }
/* 2981 */     public String getLongname() { return this.longname; }
/* 2982 */     void setLongname(String longname) { this.longname = longname; }
/* 2983 */     public SftpATTRS getAttrs() { return this.attrs; }
/* 2984 */     void setAttrs(SftpATTRS attrs) { this.attrs = attrs; }
/* 2985 */     public String toString() { return this.longname; }
/*      */     
/* 2987 */     public int compareTo(Object o) throws ClassCastException { if ((o instanceof LsEntry)) {
/* 2988 */         return this.filename.compareTo(((LsEntry)o).getFilename());
/*      */       }
/* 2990 */       throw new ClassCastException("a decendent of LsEntry must be given.");
/*      */     }
/*      */     
/*      */     private String filename;
/*      */     private String longname;
/*      */     private SftpATTRS attrs;
/*      */   }
/*      */   
/*      */   public static abstract interface LsEntrySelector
/*      */   {
/*      */     public static final int CONTINUE = 0;
/*      */     public static final int BREAK = 1;
/*      */     
/*      */     public abstract int select(ChannelSftp.LsEntry paramLsEntry);
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\ChannelSftp.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */