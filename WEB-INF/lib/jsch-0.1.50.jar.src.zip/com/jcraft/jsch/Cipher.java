package com.jcraft.jsch;

public abstract interface Cipher
{
  public static final int ENCRYPT_MODE = 0;
  public static final int DECRYPT_MODE = 1;
  
  public abstract int getIVSize();
  
  public abstract int getBlockSize();
  
  public abstract void init(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws Exception;
  
  public abstract void update(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws Exception;
  
  public abstract boolean isCBC();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\Cipher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */