/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CipherNone
/*    */   implements Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final int bsize = 16;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 35 */   public int getIVSize() { return 8; }
/* 36 */   public int getBlockSize() { return 16; }
/*    */   public void init(int mode, byte[] key, byte[] iv) throws Exception
/*    */   {}
/*    */   public void update(byte[] foo, int s1, int len, byte[] bar, int s2) throws Exception
/*    */   {}
/* 41 */   public boolean isCBC() { return false; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\CipherNone.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */