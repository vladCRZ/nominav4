/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DHG14
/*     */   extends KeyExchange
/*     */ {
/*  34 */   static final byte[] g = { 2 };
/*  35 */   static final byte[] p = { 0, -1, -1, -1, -1, -1, -1, -1, -1, -55, 15, -38, -94, 33, 104, -62, 52, -60, -58, 98, -117, Byte.MIN_VALUE, -36, 28, -47, 41, 2, 78, 8, -118, 103, -52, 116, 2, 11, -66, -90, 59, 19, -101, 34, 81, 74, 8, 121, -114, 52, 4, -35, -17, -107, 25, -77, -51, 58, 67, 27, 48, 43, 10, 109, -14, 95, 20, 55, 79, -31, 53, 109, 109, 81, -62, 69, -28, -123, -75, 118, 98, 94, 126, -58, -12, 76, 66, -23, -90, 55, -19, 107, 11, -1, 92, -74, -12, 6, -73, -19, -18, 56, 107, -5, 90, -119, -97, -91, -82, -97, 36, 17, 124, 75, 31, -26, 73, 40, 102, 81, -20, -28, 91, 61, -62, 0, 124, -72, -95, 99, -65, 5, -104, -38, 72, 54, 28, 85, -45, -102, 105, 22, 63, -88, -3, 36, -49, 95, -125, 101, 93, 35, -36, -93, -83, -106, 28, 98, -13, 86, 32, -123, 82, -69, -98, -43, 41, 7, 112, -106, -106, 109, 103, 12, 53, 78, 74, -68, -104, 4, -15, 116, 108, 8, -54, 24, 33, 124, 50, -112, 94, 70, 46, 54, -50, 59, -29, -98, 119, 44, 24, 14, -122, 3, -101, 39, -125, -94, -20, 7, -94, -113, -75, -59, 93, -16, 111, 76, 82, -55, -34, 43, -53, -10, -107, 88, 23, 24, 57, -107, 73, 124, -22, -107, 106, -27, 21, -46, 38, 24, -104, -6, 5, 16, 21, 114, -114, 90, -118, -84, -86, 104, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int SSH_MSG_KEXDH_INIT = 30;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int SSH_MSG_KEXDH_REPLY = 31;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int RSA = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int DSS = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private int type = 0;
/*     */   
/*     */   private int state;
/*     */   
/*     */   DH dh;
/*     */   
/*     */   byte[] V_S;
/*     */   
/*     */   byte[] V_C;
/*     */   byte[] I_S;
/*     */   byte[] I_C;
/*     */   byte[] e;
/*     */   private Buffer buf;
/*     */   private Packet packet;
/*     */   
/*     */   public void init(Session session, byte[] V_S, byte[] V_C, byte[] I_S, byte[] I_C)
/*     */     throws Exception
/*     */   {
/*  94 */     this.session = session;
/*  95 */     this.V_S = V_S;
/*  96 */     this.V_C = V_C;
/*  97 */     this.I_S = I_S;
/*  98 */     this.I_C = I_C;
/*     */     try
/*     */     {
/* 101 */       Class c = Class.forName(session.getConfig("sha-1"));
/* 102 */       this.sha = ((HASH)c.newInstance());
/* 103 */       this.sha.init();
/*     */     }
/*     */     catch (Exception e) {
/* 106 */       System.err.println(e);
/*     */     }
/*     */     
/* 109 */     this.buf = new Buffer();
/* 110 */     this.packet = new Packet(this.buf);
/*     */     try
/*     */     {
/* 113 */       Class c = Class.forName(session.getConfig("dh"));
/* 114 */       this.dh = ((DH)c.newInstance());
/* 115 */       this.dh.init();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 119 */       throw e;
/*     */     }
/*     */     
/* 122 */     this.dh.setP(p);
/* 123 */     this.dh.setG(g);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     this.e = this.dh.getE();
/* 130 */     this.packet.reset();
/* 131 */     this.buf.putByte((byte)30);
/* 132 */     this.buf.putMPInt(this.e);
/*     */     
/* 134 */     if (V_S == null) {
/* 135 */       return;
/*     */     }
/*     */     
/* 138 */     session.write(this.packet);
/*     */     
/* 140 */     if (JSch.getLogger().isEnabled(1)) {
/* 141 */       JSch.getLogger().log(1, "SSH_MSG_KEXDH_INIT sent");
/*     */       
/* 143 */       JSch.getLogger().log(1, "expecting SSH_MSG_KEXDH_REPLY");
/*     */     }
/*     */     
/*     */ 
/* 147 */     this.state = 31;
/*     */   }
/*     */   
/*     */   public boolean next(Buffer _buf)
/*     */     throws Exception
/*     */   {
/* 153 */     switch (this.state)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 31: 
/* 160 */       int j = _buf.getInt();
/* 161 */       j = _buf.getByte();
/* 162 */       j = _buf.getByte();
/* 163 */       if (j != 31) {
/* 164 */         System.err.println("type: must be 31 " + j);
/* 165 */         return false;
/*     */       }
/*     */       
/* 168 */       this.K_S = _buf.getString();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */       byte[] f = _buf.getMPInt();
/* 177 */       byte[] sig_of_H = _buf.getString();
/*     */       
/* 179 */       this.dh.setF(f);
/* 180 */       this.K = normalize(this.dh.getK());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */       this.buf.reset();
/* 195 */       this.buf.putString(this.V_C);this.buf.putString(this.V_S);
/* 196 */       this.buf.putString(this.I_C);this.buf.putString(this.I_S);
/* 197 */       this.buf.putString(this.K_S);
/* 198 */       this.buf.putMPInt(this.e);this.buf.putMPInt(f);
/* 199 */       this.buf.putMPInt(this.K);
/* 200 */       byte[] foo = new byte[this.buf.getLength()];
/* 201 */       this.buf.getByte(foo);
/* 202 */       this.sha.update(foo, 0, foo.length);
/* 203 */       this.H = this.sha.digest();
/*     */       
/*     */ 
/* 206 */       int i = 0;
/* 207 */       j = 0;
/* 208 */       j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */       
/* 210 */       String alg = Util.byte2str(this.K_S, i, j);
/* 211 */       i += j;
/*     */       
/* 213 */       boolean result = false;
/*     */       
/* 215 */       if (alg.equals("ssh-rsa"))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 220 */         this.type = 0;
/*     */         
/* 222 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 224 */         byte[] tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 225 */         byte[] ee = tmp;
/* 226 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 228 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 229 */         byte[] n = tmp;
/*     */         
/* 231 */         SignatureRSA sig = null;
/*     */         try {
/* 233 */           Class c = Class.forName(this.session.getConfig("signature.rsa"));
/* 234 */           sig = (SignatureRSA)c.newInstance();
/* 235 */           sig.init();
/*     */         }
/*     */         catch (Exception e) {
/* 238 */           System.err.println(e);
/*     */         }
/*     */         
/* 241 */         sig.setPubKey(ee, n);
/* 242 */         sig.update(this.H);
/* 243 */         result = sig.verify(sig_of_H);
/*     */         
/* 245 */         if (JSch.getLogger().isEnabled(1)) {
/* 246 */           JSch.getLogger().log(1, "ssh_rsa_verify: signature " + result);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 251 */       else if (alg.equals("ssh-dss")) {
/* 252 */         byte[] q = null;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 257 */         this.type = 1;
/*     */         
/* 259 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 261 */         byte[] tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 262 */         byte[] p = tmp;
/* 263 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 265 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 266 */         q = tmp;
/* 267 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 269 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 270 */         byte[] g = tmp;
/* 271 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 273 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 274 */         f = tmp;
/*     */         
/* 276 */         SignatureDSA sig = null;
/*     */         try {
/* 278 */           Class c = Class.forName(this.session.getConfig("signature.dss"));
/* 279 */           sig = (SignatureDSA)c.newInstance();
/* 280 */           sig.init();
/*     */         }
/*     */         catch (Exception e) {
/* 283 */           System.err.println(e);
/*     */         }
/* 285 */         sig.setPubKey(f, p, q, g);
/* 286 */         sig.update(this.H);
/* 287 */         result = sig.verify(sig_of_H);
/*     */         
/* 289 */         if (JSch.getLogger().isEnabled(1)) {
/* 290 */           JSch.getLogger().log(1, "ssh_dss_verify: signature " + result);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 296 */         System.err.println("unknown alg");
/*     */       }
/* 298 */       this.state = 0;
/* 299 */       return result; }
/*     */     
/* 301 */     return false;
/*     */   }
/*     */   
/*     */   public String getKeyType() {
/* 305 */     if (this.type == 1) return "DSA";
/* 306 */     return "RSA";
/*     */   }
/*     */   
/* 309 */   public int getState() { return this.state; }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\DHG14.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */