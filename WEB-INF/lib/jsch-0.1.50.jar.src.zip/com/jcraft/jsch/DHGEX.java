/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DHGEX
/*     */   extends KeyExchange
/*     */ {
/*     */   private static final int SSH_MSG_KEX_DH_GEX_GROUP = 31;
/*     */   private static final int SSH_MSG_KEX_DH_GEX_INIT = 32;
/*     */   private static final int SSH_MSG_KEX_DH_GEX_REPLY = 33;
/*     */   private static final int SSH_MSG_KEX_DH_GEX_REQUEST = 34;
/*  39 */   static int min = 1024;
/*     */   
/*     */ 
/*  42 */   static int preferred = 1024;
/*  43 */   static int max = 1024;
/*     */   
/*     */ 
/*     */   static final int RSA = 0;
/*     */   
/*     */   static final int DSS = 1;
/*     */   
/*  50 */   private int type = 0;
/*     */   
/*     */   private int state;
/*     */   
/*     */   DH dh;
/*     */   
/*     */   byte[] V_S;
/*     */   
/*     */   byte[] V_C;
/*     */   
/*     */   byte[] I_S;
/*     */   
/*     */   byte[] I_C;
/*     */   private Buffer buf;
/*     */   private Packet packet;
/*     */   private byte[] p;
/*     */   private byte[] g;
/*     */   private byte[] e;
/*     */   
/*     */   public void init(Session session, byte[] V_S, byte[] V_C, byte[] I_S, byte[] I_C)
/*     */     throws Exception
/*     */   {
/*  72 */     this.session = session;
/*  73 */     this.V_S = V_S;
/*  74 */     this.V_C = V_C;
/*  75 */     this.I_S = I_S;
/*  76 */     this.I_C = I_C;
/*     */     try
/*     */     {
/*  79 */       Class c = Class.forName(session.getConfig("sha-1"));
/*  80 */       this.sha = ((HASH)c.newInstance());
/*  81 */       this.sha.init();
/*     */     }
/*     */     catch (Exception e) {
/*  84 */       System.err.println(e);
/*     */     }
/*     */     
/*  87 */     this.buf = new Buffer();
/*  88 */     this.packet = new Packet(this.buf);
/*     */     try
/*     */     {
/*  91 */       Class c = Class.forName(session.getConfig("dh"));
/*  92 */       this.dh = ((DH)c.newInstance());
/*  93 */       this.dh.init();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  97 */       throw e;
/*     */     }
/*     */     
/* 100 */     this.packet.reset();
/* 101 */     this.buf.putByte((byte)34);
/* 102 */     this.buf.putInt(min);
/* 103 */     this.buf.putInt(preferred);
/* 104 */     this.buf.putInt(max);
/* 105 */     session.write(this.packet);
/*     */     
/* 107 */     if (JSch.getLogger().isEnabled(1)) {
/* 108 */       JSch.getLogger().log(1, "SSH_MSG_KEX_DH_GEX_REQUEST(" + min + "<" + preferred + "<" + max + ") sent");
/*     */       
/* 110 */       JSch.getLogger().log(1, "expecting SSH_MSG_KEX_DH_GEX_GROUP");
/*     */     }
/*     */     
/*     */ 
/* 114 */     this.state = 31;
/*     */   }
/*     */   
/*     */   public boolean next(Buffer _buf) throws Exception {
/*     */     int j;
/* 119 */     switch (this.state)
/*     */     {
/*     */ 
/*     */ 
/*     */     case 31: 
/* 124 */       _buf.getInt();
/* 125 */       _buf.getByte();
/* 126 */       j = _buf.getByte();
/* 127 */       if (j != 31) {
/* 128 */         System.err.println("type: must be SSH_MSG_KEX_DH_GEX_GROUP " + j);
/* 129 */         return false;
/*     */       }
/*     */       
/* 132 */       this.p = _buf.getMPInt();
/* 133 */       this.g = _buf.getMPInt();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */       this.dh.setP(this.p);
/* 144 */       this.dh.setG(this.g);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */       this.e = this.dh.getE();
/*     */       
/* 153 */       this.packet.reset();
/* 154 */       this.buf.putByte((byte)32);
/* 155 */       this.buf.putMPInt(this.e);
/* 156 */       this.session.write(this.packet);
/*     */       
/* 158 */       if (JSch.getLogger().isEnabled(1)) {
/* 159 */         JSch.getLogger().log(1, "SSH_MSG_KEX_DH_GEX_INIT sent");
/*     */         
/* 161 */         JSch.getLogger().log(1, "expecting SSH_MSG_KEX_DH_GEX_REPLY");
/*     */       }
/*     */       
/*     */ 
/* 165 */       this.state = 33;
/* 166 */       return true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 33: 
/* 175 */       j = _buf.getInt();
/* 176 */       j = _buf.getByte();
/* 177 */       j = _buf.getByte();
/* 178 */       if (j != 33) {
/* 179 */         System.err.println("type: must be SSH_MSG_KEX_DH_GEX_REPLY " + j);
/* 180 */         return false;
/*     */       }
/*     */       
/* 183 */       this.K_S = _buf.getString();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */       byte[] f = _buf.getMPInt();
/* 193 */       byte[] sig_of_H = _buf.getString();
/*     */       
/* 195 */       this.dh.setF(f);
/* 196 */       this.K = normalize(this.dh.getK());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 216 */       this.buf.reset();
/* 217 */       this.buf.putString(this.V_C);this.buf.putString(this.V_S);
/* 218 */       this.buf.putString(this.I_C);this.buf.putString(this.I_S);
/* 219 */       this.buf.putString(this.K_S);
/* 220 */       this.buf.putInt(min);this.buf.putInt(preferred);this.buf.putInt(max);
/* 221 */       this.buf.putMPInt(this.p);this.buf.putMPInt(this.g);this.buf.putMPInt(this.e);this.buf.putMPInt(f);
/* 222 */       this.buf.putMPInt(this.K);
/*     */       
/* 224 */       byte[] foo = new byte[this.buf.getLength()];
/* 225 */       this.buf.getByte(foo);
/* 226 */       this.sha.update(foo, 0, foo.length);
/*     */       
/* 228 */       this.H = this.sha.digest();
/*     */       
/*     */ 
/*     */ 
/* 232 */       int i = 0;
/* 233 */       j = 0;
/* 234 */       j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */       
/* 236 */       String alg = Util.byte2str(this.K_S, i, j);
/* 237 */       i += j;
/*     */       
/* 239 */       boolean result = false;
/* 240 */       if (alg.equals("ssh-rsa"))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 245 */         this.type = 0;
/*     */         
/* 247 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 249 */         byte[] tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 250 */         byte[] ee = tmp;
/* 251 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 253 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 254 */         byte[] n = tmp;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 259 */         SignatureRSA sig = null;
/*     */         try {
/* 261 */           Class c = Class.forName(this.session.getConfig("signature.rsa"));
/* 262 */           sig = (SignatureRSA)c.newInstance();
/* 263 */           sig.init();
/*     */         }
/*     */         catch (Exception e) {
/* 266 */           System.err.println(e);
/*     */         }
/*     */         
/* 269 */         sig.setPubKey(ee, n);
/* 270 */         sig.update(this.H);
/* 271 */         result = sig.verify(sig_of_H);
/*     */         
/* 273 */         if (JSch.getLogger().isEnabled(1)) {
/* 274 */           JSch.getLogger().log(1, "ssh_rsa_verify: signature " + result);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 279 */       else if (alg.equals("ssh-dss")) {
/* 280 */         byte[] q = null;
/*     */         
/*     */ 
/* 283 */         this.type = 1;
/*     */         
/* 285 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 287 */         byte[] tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 288 */         this.p = tmp;
/* 289 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 291 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 292 */         q = tmp;
/* 293 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 295 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 296 */         this.g = tmp;
/* 297 */         j = this.K_S[(i++)] << 24 & 0xFF000000 | this.K_S[(i++)] << 16 & 0xFF0000 | this.K_S[(i++)] << 8 & 0xFF00 | this.K_S[(i++)] & 0xFF;
/*     */         
/* 299 */         tmp = new byte[j];System.arraycopy(this.K_S, i, tmp, 0, j);i += j;
/* 300 */         f = tmp;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 305 */         SignatureDSA sig = null;
/*     */         try {
/* 307 */           Class c = Class.forName(this.session.getConfig("signature.dss"));
/* 308 */           sig = (SignatureDSA)c.newInstance();
/* 309 */           sig.init();
/*     */         }
/*     */         catch (Exception e) {
/* 312 */           System.err.println(e);
/*     */         }
/*     */         
/* 315 */         sig.setPubKey(f, this.p, q, this.g);
/* 316 */         sig.update(this.H);
/* 317 */         result = sig.verify(sig_of_H);
/*     */         
/* 319 */         if (JSch.getLogger().isEnabled(1)) {
/* 320 */           JSch.getLogger().log(1, "ssh_dss_verify: signature " + result);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 326 */         System.err.println("unknown alg");
/*     */       }
/* 328 */       this.state = 0;
/* 329 */       return result; }
/*     */     
/* 331 */     return false;
/*     */   }
/*     */   
/*     */   public String getKeyType() {
/* 335 */     if (this.type == 1) return "DSA";
/* 336 */     return "RSA";
/*     */   }
/*     */   
/* 339 */   public int getState() { return this.state; }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\DHGEX.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */