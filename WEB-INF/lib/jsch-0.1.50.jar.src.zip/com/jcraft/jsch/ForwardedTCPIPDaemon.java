package com.jcraft.jsch;

import java.io.InputStream;
import java.io.OutputStream;

public abstract interface ForwardedTCPIPDaemon
  extends Runnable
{
  public abstract void setChannel(ChannelForwardedTCPIP paramChannelForwardedTCPIP, InputStream paramInputStream, OutputStream paramOutputStream);
  
  public abstract void setArg(Object[] paramArrayOfObject);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\ForwardedTCPIPDaemon.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */