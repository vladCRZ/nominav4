package com.jcraft.jsch;

public abstract interface HASH
{
  public abstract void init()
    throws Exception;
  
  public abstract int getBlockSize();
  
  public abstract void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws Exception;
  
  public abstract byte[] digest()
    throws Exception;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\HASH.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */