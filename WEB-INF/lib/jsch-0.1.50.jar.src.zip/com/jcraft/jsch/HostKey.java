/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostKey
/*     */ {
/*  33 */   private static final byte[] sshdss = Util.str2byte("ssh-dss");
/*  34 */   private static final byte[] sshrsa = Util.str2byte("ssh-rsa");
/*     */   protected static final int GUESS = 0;
/*     */   public static final int SSHDSS = 1;
/*     */   public static final int SSHRSA = 2;
/*     */   static final int UNKNOWN = 3;
/*     */   protected String marker;
/*     */   protected String host;
/*     */   protected int type;
/*     */   protected byte[] key;
/*     */   protected String comment;
/*     */   
/*     */   public HostKey(String host, byte[] key)
/*     */     throws JSchException
/*     */   {
/*  48 */     this(host, 0, key);
/*     */   }
/*     */   
/*     */   public HostKey(String host, int type, byte[] key) throws JSchException {
/*  52 */     this(host, type, key, null);
/*     */   }
/*     */   
/*  55 */   public HostKey(String host, int type, byte[] key, String comment) throws JSchException { this("", host, type, key, comment); }
/*     */   
/*     */   public HostKey(String marker, String host, int type, byte[] key, String comment) throws JSchException {
/*  58 */     this.marker = marker;
/*  59 */     this.host = host;
/*  60 */     if (type == 0) {
/*  61 */       if (key[8] == 100) { this.type = 1;
/*  62 */       } else if (key[8] == 114) this.type = 2; else {
/*  63 */         throw new JSchException("invalid key type");
/*     */       }
/*     */     } else {
/*  66 */       this.type = type;
/*     */     }
/*  68 */     this.key = key;
/*  69 */     this.comment = comment;
/*     */   }
/*     */   
/*  72 */   public String getHost() { return this.host; }
/*     */   
/*  74 */   public String getType() { if (this.type == 1) return Util.byte2str(sshdss);
/*  75 */     if (this.type == 2) return Util.byte2str(sshrsa);
/*  76 */     return "UNKNOWN";
/*     */   }
/*     */   
/*  79 */   public String getKey() { return Util.byte2str(Util.toBase64(this.key, 0, this.key.length)); }
/*     */   
/*     */   public String getFingerPrint(JSch jsch) {
/*  82 */     HASH hash = null;
/*     */     try {
/*  84 */       Class c = Class.forName(JSch.getConfig("md5"));
/*  85 */       hash = (HASH)c.newInstance();
/*     */     } catch (Exception e) {
/*  87 */       System.err.println("getFingerPrint: " + e); }
/*  88 */     return Util.getFingerPrint(hash, this.key); }
/*     */   
/*  90 */   public String getComment() { return this.comment; }
/*  91 */   public String getMarker() { return this.marker; }
/*     */   
/*     */   boolean isMatched(String _host) {
/*  94 */     return isIncluded(_host);
/*     */   }
/*     */   
/*     */   private boolean isIncluded(String _host) {
/*  98 */     int i = 0;
/*  99 */     String hosts = this.host;
/* 100 */     int hostslen = hosts.length();
/* 101 */     int hostlen = _host.length();
/*     */     
/* 103 */     while (i < hostslen) {
/* 104 */       int j = hosts.indexOf(',', i);
/* 105 */       if (j == -1) {
/* 106 */         if (hostlen != hostslen - i) return false;
/* 107 */         return hosts.regionMatches(true, i, _host, 0, hostlen);
/*     */       }
/* 109 */       if ((hostlen == j - i) && 
/* 110 */         (hosts.regionMatches(true, i, _host, 0, hostlen))) { return true;
/*     */       }
/* 112 */       i = j + 1;
/*     */     }
/* 114 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\HostKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */