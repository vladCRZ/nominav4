package com.jcraft.jsch;

public abstract interface HostKeyRepository
{
  public static final int OK = 0;
  public static final int NOT_INCLUDED = 1;
  public static final int CHANGED = 2;
  
  public abstract int check(String paramString, byte[] paramArrayOfByte);
  
  public abstract void add(HostKey paramHostKey, UserInfo paramUserInfo);
  
  public abstract void remove(String paramString1, String paramString2);
  
  public abstract void remove(String paramString1, String paramString2, byte[] paramArrayOfByte);
  
  public abstract String getKnownHostsRepositoryID();
  
  public abstract HostKey[] getHostKey();
  
  public abstract HostKey[] getHostKey(String paramString1, String paramString2);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\HostKeyRepository.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */