/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.SocketException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IO
/*     */ {
/*     */   InputStream in;
/*     */   OutputStream out;
/*     */   OutputStream out_ext;
/*  39 */   private boolean in_dontclose = false;
/*  40 */   private boolean out_dontclose = false;
/*  41 */   private boolean out_ext_dontclose = false;
/*     */   
/*  43 */   void setOutputStream(OutputStream out) { this.out = out; }
/*     */   
/*  45 */   void setOutputStream(OutputStream out, boolean dontclose) { this.out_dontclose = dontclose;
/*  46 */     setOutputStream(out); }
/*     */   
/*  48 */   void setExtOutputStream(OutputStream out) { this.out_ext = out; }
/*     */   
/*  50 */   void setExtOutputStream(OutputStream out, boolean dontclose) { this.out_ext_dontclose = dontclose;
/*  51 */     setExtOutputStream(out); }
/*     */   
/*  53 */   void setInputStream(InputStream in) { this.in = in; }
/*     */   
/*  55 */   void setInputStream(InputStream in, boolean dontclose) { this.in_dontclose = dontclose;
/*  56 */     setInputStream(in);
/*     */   }
/*     */   
/*     */   public void put(Packet p) throws IOException, SocketException {
/*  60 */     this.out.write(p.buffer.buffer, 0, p.buffer.index);
/*  61 */     this.out.flush();
/*     */   }
/*     */   
/*  64 */   void put(byte[] array, int begin, int length) throws IOException { this.out.write(array, begin, length);
/*  65 */     this.out.flush();
/*     */   }
/*     */   
/*  68 */   void put_ext(byte[] array, int begin, int length) throws IOException { this.out_ext.write(array, begin, length);
/*  69 */     this.out_ext.flush();
/*     */   }
/*     */   
/*     */   int getByte() throws IOException {
/*  73 */     return this.in.read();
/*     */   }
/*     */   
/*     */   void getByte(byte[] array) throws IOException {
/*  77 */     getByte(array, 0, array.length);
/*     */   }
/*     */   
/*     */   void getByte(byte[] array, int begin, int length) throws IOException {
/*     */     do {
/*  82 */       int completed = this.in.read(array, begin, length);
/*  83 */       if (completed < 0) {
/*  84 */         throw new IOException("End of IO Stream Read");
/*     */       }
/*  86 */       begin += completed;
/*  87 */       length -= completed;
/*     */     }
/*  89 */     while (length > 0);
/*     */   }
/*     */   
/*     */   void out_close() {
/*     */     try {
/*  94 */       if ((this.out != null) && (!this.out_dontclose)) this.out.close();
/*  95 */       this.out = null;
/*     */     }
/*     */     catch (Exception ee) {}
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 102 */       if ((this.in != null) && (!this.in_dontclose)) this.in.close();
/* 103 */       this.in = null;
/*     */     }
/*     */     catch (Exception ee) {}
/*     */     
/* 107 */     out_close();
/*     */     try
/*     */     {
/* 110 */       if ((this.out_ext != null) && (!this.out_ext_dontclose)) this.out_ext.close();
/* 111 */       this.out_ext = null;
/*     */     }
/*     */     catch (Exception ee) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\IO.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */