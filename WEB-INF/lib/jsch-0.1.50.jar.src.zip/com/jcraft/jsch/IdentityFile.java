/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IdentityFile
/*     */   implements Identity
/*     */ {
/*     */   private JSch jsch;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private KeyPair kpair;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String identity;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static IdentityFile newInstance(String prvfile, String pubfile, JSch jsch)
/*     */     throws JSchException
/*     */   {
/*  40 */     KeyPair kpair = KeyPair.load(jsch, prvfile, pubfile);
/*  41 */     return new IdentityFile(jsch, prvfile, kpair);
/*     */   }
/*     */   
/*     */   static IdentityFile newInstance(String name, byte[] prvkey, byte[] pubkey, JSch jsch) throws JSchException {
/*  45 */     KeyPair kpair = KeyPair.load(jsch, prvkey, pubkey);
/*  46 */     return new IdentityFile(jsch, name, kpair);
/*     */   }
/*     */   
/*     */   private IdentityFile(JSch jsch, String name, KeyPair kpair) throws JSchException {
/*  50 */     this.jsch = jsch;
/*  51 */     this.identity = name;
/*  52 */     this.kpair = kpair;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setPassphrase(byte[] passphrase)
/*     */     throws JSchException
/*     */   {
/*  62 */     return this.kpair.decrypt(passphrase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getPublicKeyBlob()
/*     */   {
/*  70 */     return this.kpair.getPublicKeyBlob();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSignature(byte[] data)
/*     */   {
/*  79 */     return this.kpair.getSignature(data);
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public boolean decrypt()
/*     */   {
/*  87 */     throw new RuntimeException("not implemented");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAlgName()
/*     */   {
/*  95 */     return new String(this.kpair.getKeyTypeName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 103 */     return this.identity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEncrypted()
/*     */   {
/* 111 */     return this.kpair.isEncrypted();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 118 */     this.kpair.dispose();
/* 119 */     this.kpair = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyPair getKeyPair()
/*     */   {
/* 127 */     return this.kpair;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\IdentityFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */