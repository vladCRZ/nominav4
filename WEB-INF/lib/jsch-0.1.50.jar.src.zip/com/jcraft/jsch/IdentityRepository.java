/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface IdentityRepository
/*     */ {
/*     */   public static final int UNAVAILABLE = 0;
/*     */   public static final int NOTRUNNING = 1;
/*     */   public static final int RUNNING = 2;
/*     */   
/*     */   public abstract String getName();
/*     */   
/*     */   public abstract int getStatus();
/*     */   
/*     */   public abstract Vector getIdentities();
/*     */   
/*     */   public abstract boolean add(byte[] paramArrayOfByte);
/*     */   
/*     */   public abstract boolean remove(byte[] paramArrayOfByte);
/*     */   
/*     */   public abstract void removeAll();
/*     */   
/*     */   public static class Wrapper
/*     */     implements IdentityRepository
/*     */   {
/*     */     private IdentityRepository ir;
/*  54 */     private Vector cache = new Vector();
/*  55 */     private boolean keep_in_cache = false;
/*     */     
/*  57 */     Wrapper(IdentityRepository ir) { this(ir, false); }
/*     */     
/*     */     Wrapper(IdentityRepository ir, boolean keep_in_cache) {
/*  60 */       this.ir = ir;
/*  61 */       this.keep_in_cache = keep_in_cache;
/*     */     }
/*     */     
/*  64 */     public String getName() { return this.ir.getName(); }
/*     */     
/*     */     public int getStatus() {
/*  67 */       return this.ir.getStatus();
/*     */     }
/*     */     
/*  70 */     public boolean add(byte[] identity) { return this.ir.add(identity); }
/*     */     
/*     */ 
/*  73 */     public boolean remove(byte[] blob) { return this.ir.remove(blob); }
/*     */     
/*     */     public void removeAll() {
/*  76 */       this.cache.removeAllElements();
/*  77 */       this.ir.removeAll();
/*     */     }
/*     */     
/*  80 */     public Vector getIdentities() { Vector result = new Vector();
/*  81 */       for (int i = 0; i < this.cache.size(); i++) {
/*  82 */         Identity identity = (Identity)this.cache.elementAt(i);
/*  83 */         result.add(identity);
/*     */       }
/*  85 */       Vector tmp = this.ir.getIdentities();
/*  86 */       for (int i = 0; i < tmp.size(); i++) {
/*  87 */         result.add(tmp.elementAt(i));
/*     */       }
/*  89 */       return result;
/*     */     }
/*     */     
/*  92 */     void add(Identity identity) { if ((!this.keep_in_cache) && (!identity.isEncrypted()) && ((identity instanceof IdentityFile))) {
/*     */         try
/*     */         {
/*  95 */           this.ir.add(((IdentityFile)identity).getKeyPair().forSSHAgent());
/*     */ 
/*     */         }
/*     */         catch (JSchException e) {}
/*     */       }
/*     */       else
/*     */       {
/* 102 */         this.cache.addElement(identity); }
/*     */     }
/*     */     
/* 105 */     void check() { if (this.cache.size() > 0) {
/* 106 */         Object[] identities = this.cache.toArray();
/* 107 */         for (int i = 0; i < identities.length; i++) {
/* 108 */           Identity identity = (Identity)identities[i];
/* 109 */           this.cache.removeElement(identity);
/* 110 */           add(identity);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\IdentityRepository.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */