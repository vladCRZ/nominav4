/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSch
/*     */ {
/*     */   public static final String VERSION = "0.1.50";
/*  41 */   static Hashtable config = new Hashtable();
/*     */   
/*  43 */   static { config.put("kex", "diffie-hellman-group1-sha1,diffie-hellman-group14-sha1,diffie-hellman-group-exchange-sha1");
/*  44 */     config.put("server_host_key", "ssh-rsa,ssh-dss");
/*     */     
/*  46 */     config.put("cipher.s2c", "aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-cbc,aes256-cbc");
/*     */     
/*  48 */     config.put("cipher.c2s", "aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-cbc,aes256-cbc");
/*     */     
/*     */ 
/*  51 */     config.put("mac.s2c", "hmac-md5,hmac-sha1,hmac-sha2-256,hmac-sha1-96,hmac-md5-96");
/*  52 */     config.put("mac.c2s", "hmac-md5,hmac-sha1,hmac-sha2-256,hmac-sha1-96,hmac-md5-96");
/*  53 */     config.put("compression.s2c", "none");
/*  54 */     config.put("compression.c2s", "none");
/*     */     
/*  56 */     config.put("lang.s2c", "");
/*  57 */     config.put("lang.c2s", "");
/*     */     
/*  59 */     config.put("compression_level", "6");
/*     */     
/*  61 */     config.put("diffie-hellman-group-exchange-sha1", "com.jcraft.jsch.DHGEX");
/*     */     
/*  63 */     config.put("diffie-hellman-group1-sha1", "com.jcraft.jsch.DHG1");
/*     */     
/*  65 */     config.put("diffie-hellman-group14-sha1", "com.jcraft.jsch.DHG14");
/*     */     
/*  67 */     config.put("diffie-hellman-group-exchange-sha256", "com.jcraft.jsch.DHGEX256");
/*     */     
/*     */ 
/*  70 */     config.put("dh", "com.jcraft.jsch.jce.DH");
/*  71 */     config.put("3des-cbc", "com.jcraft.jsch.jce.TripleDESCBC");
/*  72 */     config.put("blowfish-cbc", "com.jcraft.jsch.jce.BlowfishCBC");
/*  73 */     config.put("hmac-sha1", "com.jcraft.jsch.jce.HMACSHA1");
/*  74 */     config.put("hmac-sha1-96", "com.jcraft.jsch.jce.HMACSHA196");
/*  75 */     config.put("hmac-sha2-256", "com.jcraft.jsch.jce.HMACSHA256");
/*     */     
/*     */ 
/*     */ 
/*  79 */     config.put("hmac-md5", "com.jcraft.jsch.jce.HMACMD5");
/*  80 */     config.put("hmac-md5-96", "com.jcraft.jsch.jce.HMACMD596");
/*  81 */     config.put("sha-1", "com.jcraft.jsch.jce.SHA1");
/*  82 */     config.put("sha-256", "com.jcraft.jsch.jce.SHA256");
/*  83 */     config.put("md5", "com.jcraft.jsch.jce.MD5");
/*  84 */     config.put("signature.dss", "com.jcraft.jsch.jce.SignatureDSA");
/*  85 */     config.put("signature.rsa", "com.jcraft.jsch.jce.SignatureRSA");
/*  86 */     config.put("keypairgen.dsa", "com.jcraft.jsch.jce.KeyPairGenDSA");
/*  87 */     config.put("keypairgen.rsa", "com.jcraft.jsch.jce.KeyPairGenRSA");
/*  88 */     config.put("random", "com.jcraft.jsch.jce.Random");
/*     */     
/*  90 */     config.put("none", "com.jcraft.jsch.CipherNone");
/*     */     
/*  92 */     config.put("aes128-cbc", "com.jcraft.jsch.jce.AES128CBC");
/*  93 */     config.put("aes192-cbc", "com.jcraft.jsch.jce.AES192CBC");
/*  94 */     config.put("aes256-cbc", "com.jcraft.jsch.jce.AES256CBC");
/*     */     
/*  96 */     config.put("aes128-ctr", "com.jcraft.jsch.jce.AES128CTR");
/*  97 */     config.put("aes192-ctr", "com.jcraft.jsch.jce.AES192CTR");
/*  98 */     config.put("aes256-ctr", "com.jcraft.jsch.jce.AES256CTR");
/*  99 */     config.put("3des-ctr", "com.jcraft.jsch.jce.TripleDESCTR");
/* 100 */     config.put("arcfour", "com.jcraft.jsch.jce.ARCFOUR");
/* 101 */     config.put("arcfour128", "com.jcraft.jsch.jce.ARCFOUR128");
/* 102 */     config.put("arcfour256", "com.jcraft.jsch.jce.ARCFOUR256");
/*     */     
/* 104 */     config.put("userauth.none", "com.jcraft.jsch.UserAuthNone");
/* 105 */     config.put("userauth.password", "com.jcraft.jsch.UserAuthPassword");
/* 106 */     config.put("userauth.keyboard-interactive", "com.jcraft.jsch.UserAuthKeyboardInteractive");
/* 107 */     config.put("userauth.publickey", "com.jcraft.jsch.UserAuthPublicKey");
/* 108 */     config.put("userauth.gssapi-with-mic", "com.jcraft.jsch.UserAuthGSSAPIWithMIC");
/* 109 */     config.put("gssapi-with-mic.krb5", "com.jcraft.jsch.jgss.GSSContextKrb5");
/*     */     
/* 111 */     config.put("zlib", "com.jcraft.jsch.jcraft.Compression");
/* 112 */     config.put("zlib@openssh.com", "com.jcraft.jsch.jcraft.Compression");
/*     */     
/* 114 */     config.put("StrictHostKeyChecking", "ask");
/* 115 */     config.put("HashKnownHosts", "no");
/*     */     
/* 117 */     config.put("PreferredAuthentications", "gssapi-with-mic,publickey,keyboard-interactive,password");
/*     */     
/* 119 */     config.put("CheckCiphers", "aes256-ctr,aes192-ctr,aes128-ctr,aes256-cbc,aes192-cbc,aes128-cbc,3des-ctr,arcfour,arcfour128,arcfour256");
/* 120 */     config.put("CheckKexes", "diffie-hellman-group14-sha1");
/*     */     
/* 122 */     config.put("MaxAuthTries", "6");
/* 123 */     config.put("ClearAllForwardings", "no");
/*     */   }
/*     */   
/* 126 */   private Vector sessionPool = new Vector();
/*     */   
/* 128 */   private IdentityRepository defaultIdentityRepository = new LocalIdentityRepository(this);
/*     */   
/*     */ 
/* 131 */   private IdentityRepository identityRepository = this.defaultIdentityRepository;
/*     */   
/* 133 */   private ConfigRepository configRepository = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setIdentityRepository(IdentityRepository identityRepository)
/*     */   {
/* 145 */     if (identityRepository == null) {
/* 146 */       this.identityRepository = this.defaultIdentityRepository;
/*     */     }
/*     */     else {
/* 149 */       this.identityRepository = identityRepository;
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized IdentityRepository getIdentityRepository() {
/* 154 */     return this.identityRepository;
/*     */   }
/*     */   
/*     */   public ConfigRepository getConfigRepository() {
/* 158 */     return this.configRepository;
/*     */   }
/*     */   
/*     */   public void setConfigRepository(ConfigRepository configRepository) {
/* 162 */     this.configRepository = configRepository;
/*     */   }
/*     */   
/* 165 */   private HostKeyRepository known_hosts = null;
/*     */   
/* 167 */   private static final Logger DEVNULL = new Logger() {
/* 168 */     public boolean isEnabled(int level) { return false; }
/*     */     
/*     */     public void log(int level, String message) {} };
/* 171 */   static Logger logger = DEVNULL;
/*     */   
/*     */   public JSch()
/*     */   {
/*     */     try {
/* 176 */       String osname = (String)System.getProperties().get("os.name");
/* 177 */       if ((osname != null) && (osname.equals("Mac OS X"))) {
/* 178 */         config.put("hmac-sha1", "com.jcraft.jsch.jcraft.HMACSHA1");
/* 179 */         config.put("hmac-md5", "com.jcraft.jsch.jcraft.HMACMD5");
/* 180 */         config.put("hmac-md5-96", "com.jcraft.jsch.jcraft.HMACMD596");
/* 181 */         config.put("hmac-sha1-96", "com.jcraft.jsch.jcraft.HMACSHA196");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getSession(String host)
/*     */     throws JSchException
/*     */   {
/* 208 */     return getSession(null, host, 22);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getSession(String username, String host)
/*     */     throws JSchException
/*     */   {
/* 231 */     return getSession(username, host, 22);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getSession(String username, String host, int port)
/*     */     throws JSchException
/*     */   {
/* 253 */     if (host == null) {
/* 254 */       throw new JSchException("host must not be null.");
/*     */     }
/* 256 */     Session s = new Session(this, username, host, port);
/* 257 */     return s;
/*     */   }
/*     */   
/*     */   protected void addSession(Session session) {
/* 261 */     synchronized (this.sessionPool) {
/* 262 */       this.sessionPool.addElement(session);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHostKeyRepository(HostKeyRepository hkrepo)
/*     */   {
/* 281 */     this.known_hosts = hkrepo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKnownHosts(String filename)
/*     */     throws JSchException
/*     */   {
/* 296 */     if (this.known_hosts == null) this.known_hosts = new KnownHosts(this);
/* 297 */     if ((this.known_hosts instanceof KnownHosts)) {
/* 298 */       synchronized (this.known_hosts) {
/* 299 */         ((KnownHosts)this.known_hosts).setKnownHosts(filename);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKnownHosts(InputStream stream)
/*     */     throws JSchException
/*     */   {
/* 316 */     if (this.known_hosts == null) this.known_hosts = new KnownHosts(this);
/* 317 */     if ((this.known_hosts instanceof KnownHosts)) {
/* 318 */       synchronized (this.known_hosts) {
/* 319 */         ((KnownHosts)this.known_hosts).setKnownHosts(stream);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HostKeyRepository getHostKeyRepository()
/*     */   {
/* 334 */     if (this.known_hosts == null) this.known_hosts = new KnownHosts(this);
/* 335 */     return this.known_hosts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIdentity(String prvkey)
/*     */     throws JSchException
/*     */   {
/* 349 */     addIdentity(prvkey, (byte[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIdentity(String prvkey, String passphrase)
/*     */     throws JSchException
/*     */   {
/* 366 */     byte[] _passphrase = null;
/* 367 */     if (passphrase != null) {
/* 368 */       _passphrase = Util.str2byte(passphrase);
/*     */     }
/* 370 */     addIdentity(prvkey, _passphrase);
/* 371 */     if (_passphrase != null) {
/* 372 */       Util.bzero(_passphrase);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIdentity(String prvkey, byte[] passphrase)
/*     */     throws JSchException
/*     */   {
/* 389 */     Identity identity = IdentityFile.newInstance(prvkey, null, this);
/* 390 */     addIdentity(identity, passphrase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIdentity(String prvkey, String pubkey, byte[] passphrase)
/*     */     throws JSchException
/*     */   {
/* 406 */     Identity identity = IdentityFile.newInstance(prvkey, pubkey, this);
/* 407 */     addIdentity(identity, passphrase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIdentity(String name, byte[] prvkey, byte[] pubkey, byte[] passphrase)
/*     */     throws JSchException
/*     */   {
/* 424 */     Identity identity = IdentityFile.newInstance(name, prvkey, pubkey, this);
/* 425 */     addIdentity(identity, passphrase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIdentity(Identity identity, byte[] passphrase)
/*     */     throws JSchException
/*     */   {
/* 440 */     if (passphrase != null) {
/*     */       try {
/* 442 */         byte[] goo = new byte[passphrase.length];
/* 443 */         System.arraycopy(passphrase, 0, goo, 0, passphrase.length);
/* 444 */         passphrase = goo;
/* 445 */         identity.setPassphrase(passphrase);
/*     */       }
/*     */       finally {
/* 448 */         Util.bzero(passphrase);
/*     */       }
/*     */     }
/*     */     
/* 452 */     if ((this.identityRepository instanceof LocalIdentityRepository)) {
/* 453 */       ((LocalIdentityRepository)this.identityRepository).add(identity);
/*     */     }
/* 455 */     else if (((identity instanceof IdentityFile)) && (!identity.isEncrypted())) {
/* 456 */       this.identityRepository.add(((IdentityFile)identity).getKeyPair().forSSHAgent());
/*     */     }
/*     */     else {
/* 459 */       synchronized (this) {
/* 460 */         if (!(this.identityRepository instanceof IdentityRepository.Wrapper)) {
/* 461 */           setIdentityRepository(new IdentityRepository.Wrapper(this.identityRepository));
/*     */         }
/*     */       }
/* 464 */       ((IdentityRepository.Wrapper)this.identityRepository).add(identity);
/*     */     }
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void removeIdentity(String name) throws JSchException {
/* 472 */     Vector identities = this.identityRepository.getIdentities();
/* 473 */     for (int i = 0; i < identities.size(); i++) {
/* 474 */       Identity identity = (Identity)identities.elementAt(i);
/* 475 */       if (identity.getName().equals(name))
/*     */       {
/* 477 */         if ((this.identityRepository instanceof LocalIdentityRepository)) {
/* 478 */           ((LocalIdentityRepository)this.identityRepository).remove(identity);
/*     */         }
/*     */         else {
/* 481 */           this.identityRepository.remove(identity.getPublicKeyBlob());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeIdentity(Identity identity)
/*     */     throws JSchException
/*     */   {
/* 493 */     this.identityRepository.remove(identity.getPublicKeyBlob());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector getIdentityNames()
/*     */     throws JSchException
/*     */   {
/* 504 */     Vector foo = new Vector();
/* 505 */     Vector identities = this.identityRepository.getIdentities();
/* 506 */     for (int i = 0; i < identities.size(); i++) {
/* 507 */       Identity identity = (Identity)identities.elementAt(i);
/* 508 */       foo.addElement(identity.getName());
/*     */     }
/* 510 */     return foo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAllIdentity()
/*     */     throws JSchException
/*     */   {
/* 519 */     this.identityRepository.removeAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setConfig(Hashtable newconf)
/*     */   {
/*     */     Enumeration e;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 540 */     synchronized (config) {
/* 541 */       for (e = newconf.keys(); e.hasMoreElements();) {
/* 542 */         String key = (String)e.nextElement();
/* 543 */         config.put(key, (String)newconf.get(key));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setConfig(String key, String value)
/*     */   {
/* 555 */     config.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setLogger(Logger logger)
/*     */   {
/* 566 */     if (logger == null) logger = DEVNULL;
/* 567 */     logger = logger;
/*     */   }
/*     */   
/*     */   static Logger getLogger() {
/* 571 */     return logger;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected boolean removeSession(Session session)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	com/jcraft/jsch/JSch:sessionPool	Ljava/util/Vector;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 7	com/jcraft/jsch/JSch:sessionPool	Ljava/util/Vector;
/*     */     //   11: aload_1
/*     */     //   12: invokevirtual 35	java/util/Vector:remove	(Ljava/lang/Object;)Z
/*     */     //   15: aload_2
/*     */     //   16: monitorexit
/*     */     //   17: ireturn
/*     */     //   18: astore_3
/*     */     //   19: aload_2
/*     */     //   20: monitorexit
/*     */     //   21: aload_3
/*     */     //   22: athrow
/*     */     // Line number table:
/*     */     //   Java source line #267	-> byte code offset #0
/*     */     //   Java source line #268	-> byte code offset #7
/*     */     //   Java source line #269	-> byte code offset #18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	23	0	this	JSch
/*     */     //   0	23	1	session	Session
/*     */     //   5	15	2	Ljava/lang/Object;	Object
/*     */     //   18	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	17	18	finally
/*     */     //   18	21	18	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static String getConfig(String key)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 17	com/jcraft/jsch/JSch:config	Ljava/util/Hashtable;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: monitorenter
/*     */     //   6: getstatic 17	com/jcraft/jsch/JSch:config	Ljava/util/Hashtable;
/*     */     //   9: aload_0
/*     */     //   10: invokevirtual 68	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   13: checkcast 14	java/lang/String
/*     */     //   16: checkcast 14	java/lang/String
/*     */     //   19: aload_1
/*     */     //   20: monitorexit
/*     */     //   21: areturn
/*     */     //   22: astore_2
/*     */     //   23: aload_1
/*     */     //   24: monitorexit
/*     */     //   25: aload_2
/*     */     //   26: athrow
/*     */     // Line number table:
/*     */     //   Java source line #529	-> byte code offset #0
/*     */     //   Java source line #530	-> byte code offset #6
/*     */     //   Java source line #531	-> byte code offset #22
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	27	0	key	String
/*     */     //   4	20	1	Ljava/lang/Object;	Object
/*     */     //   22	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	21	22	finally
/*     */     //   22	25	22	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\JSch.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */