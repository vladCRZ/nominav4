/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JSchAuthCancelException
/*    */   extends JSchException
/*    */ {
/*    */   String method;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   JSchAuthCancelException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   JSchAuthCancelException(String s)
/*    */   {
/* 39 */     super(s);
/* 40 */     this.method = s;
/*    */   }
/*    */   
/* 43 */   public String getMethod() { return this.method; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\JSchAuthCancelException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */