/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyExchange
/*     */ {
/*     */   static final int PROPOSAL_KEX_ALGS = 0;
/*     */   static final int PROPOSAL_SERVER_HOST_KEY_ALGS = 1;
/*     */   static final int PROPOSAL_ENC_ALGS_CTOS = 2;
/*     */   static final int PROPOSAL_ENC_ALGS_STOC = 3;
/*     */   static final int PROPOSAL_MAC_ALGS_CTOS = 4;
/*     */   static final int PROPOSAL_MAC_ALGS_STOC = 5;
/*     */   static final int PROPOSAL_COMP_ALGS_CTOS = 6;
/*     */   static final int PROPOSAL_COMP_ALGS_STOC = 7;
/*     */   static final int PROPOSAL_LANG_CTOS = 8;
/*     */   static final int PROPOSAL_LANG_STOC = 9;
/*     */   static final int PROPOSAL_MAX = 10;
/*  50 */   static String kex = "diffie-hellman-group1-sha1";
/*  51 */   static String server_host_key = "ssh-rsa,ssh-dss";
/*  52 */   static String enc_c2s = "blowfish-cbc";
/*  53 */   static String enc_s2c = "blowfish-cbc";
/*  54 */   static String mac_c2s = "hmac-md5";
/*     */   
/*  56 */   static String mac_s2c = "hmac-md5";
/*     */   
/*     */ 
/*  59 */   static String lang_c2s = "";
/*  60 */   static String lang_s2c = "";
/*     */   
/*     */   public static final int STATE_END = 0;
/*     */   
/*  64 */   protected Session session = null;
/*  65 */   protected HASH sha = null;
/*  66 */   protected byte[] K = null;
/*  67 */   protected byte[] H = null;
/*  68 */   protected byte[] K_S = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void init(Session paramSession, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */   public abstract boolean next(Buffer paramBuffer)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */   public abstract String getKeyType();
/*     */   
/*     */ 
/*     */   public abstract int getState();
/*     */   
/*     */ 
/*     */   protected static String[] guess(byte[] I_S, byte[] I_C)
/*     */   {
/*  88 */     String[] guess = new String[10];
/*  89 */     Buffer sb = new Buffer(I_S);sb.setOffSet(17);
/*  90 */     Buffer cb = new Buffer(I_C);cb.setOffSet(17);
/*     */     
/*  92 */     if (JSch.getLogger().isEnabled(1)) {
/*  93 */       for (int i = 0; i < 10; i++) {
/*  94 */         JSch.getLogger().log(1, "kex: server: " + Util.byte2str(sb.getString()));
/*     */       }
/*     */       
/*  97 */       for (int i = 0; i < 10; i++) {
/*  98 */         JSch.getLogger().log(1, "kex: client: " + Util.byte2str(cb.getString()));
/*     */       }
/*     */       
/* 101 */       sb.setOffSet(17);
/* 102 */       cb.setOffSet(17);
/*     */     }
/*     */     
/* 105 */     for (int i = 0; i < 10; i++) {
/* 106 */       byte[] sp = sb.getString();
/* 107 */       byte[] cp = cb.getString();
/* 108 */       int j = 0;
/* 109 */       int k = 0;
/*     */       
/*     */ 
/* 112 */       while (j < cp.length) {
/* 113 */         while ((j < cp.length) && (cp[j] != 44)) j++;
/* 114 */         if (k == j) return null;
/* 115 */         String algorithm = Util.byte2str(cp, k, j - k);
/* 116 */         int l = 0;
/* 117 */         int m = 0;
/* 118 */         while (l < sp.length) {
/* 119 */           while ((l < sp.length) && (sp[l] != 44)) l++;
/* 120 */           if (m == l) return null;
/* 121 */           if (algorithm.equals(Util.byte2str(sp, m, l - m))) {
/* 122 */             guess[i] = algorithm;
/*     */             break label344;
/*     */           }
/* 125 */           l++;
/* 126 */           m = l;
/*     */         }
/* 128 */         j++;
/* 129 */         k = j; }
/*     */       label344:
/* 131 */       if (j == 0) {
/* 132 */         guess[i] = "";
/*     */       }
/* 134 */       else if (guess[i] == null) {
/* 135 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 139 */     if (JSch.getLogger().isEnabled(1)) {
/* 140 */       JSch.getLogger().log(1, "kex: server->client " + guess[3] + " " + guess[5] + " " + guess[7]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 145 */       JSch.getLogger().log(1, "kex: client->server " + guess[2] + " " + guess[4] + " " + guess[6]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */     return guess;
/*     */   }
/*     */   
/*     */   public String getFingerPrint() {
/* 156 */     HASH hash = null;
/*     */     try {
/* 158 */       Class c = Class.forName(this.session.getConfig("md5"));
/* 159 */       hash = (HASH)c.newInstance();
/*     */     } catch (Exception e) {
/* 161 */       System.err.println("getFingerPrint: " + e); }
/* 162 */     return Util.getFingerPrint(hash, getHostKey()); }
/*     */   
/* 164 */   byte[] getK() { return this.K; }
/* 165 */   byte[] getH() { return this.H; }
/* 166 */   HASH getHash() { return this.sha; }
/* 167 */   byte[] getHostKey() { return this.K_S; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] normalize(byte[] secret)
/*     */   {
/* 175 */     if ((secret.length > 1) && (secret[0] == 0) && ((secret[1] & 0x80) == 0))
/*     */     {
/* 177 */       byte[] tmp = new byte[secret.length - 1];
/* 178 */       System.arraycopy(secret, 1, tmp, 0, tmp.length);
/* 179 */       secret = tmp;
/*     */     }
/* 181 */     return secret;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\KeyExchange.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */