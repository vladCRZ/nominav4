/*      */ package com.jcraft.jsch;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class KeyPair
/*      */ {
/*      */   public static final int ERROR = 0;
/*      */   public static final int DSA = 1;
/*      */   public static final int RSA = 2;
/*      */   public static final int UNKNOWN = 3;
/*      */   static final int VENDOR_OPENSSH = 0;
/*      */   static final int VENDOR_FSECURE = 1;
/*      */   static final int VENDOR_PUTTY = 2;
/*   47 */   int vendor = 0;
/*      */   
/*   49 */   private static final byte[] cr = Util.str2byte("\n");
/*      */   
/*      */ 
/*   52 */   public static KeyPair genKeyPair(JSch jsch, int type) throws JSchException { return genKeyPair(jsch, type, 1024); }
/*      */   
/*      */   public static KeyPair genKeyPair(JSch jsch, int type, int key_size) throws JSchException {
/*   55 */     KeyPair kpair = null;
/*   56 */     if (type == 1) { kpair = new KeyPairDSA(jsch);
/*   57 */     } else if (type == 2) kpair = new KeyPairRSA(jsch);
/*   58 */     if (kpair != null) {
/*   59 */       kpair.generate(key_size);
/*      */     }
/*   61 */     return kpair; }
/*      */   
/*      */   abstract void generate(int paramInt) throws JSchException;
/*      */   
/*      */   abstract byte[] getBegin();
/*      */   
/*      */   abstract byte[] getEnd();
/*      */   
/*      */   abstract int getKeySize();
/*      */   
/*      */   public abstract byte[] getSignature(byte[] paramArrayOfByte);
/*      */   
/*      */   public abstract Signature getVerifier();
/*      */   
/*      */   public abstract byte[] forSSHAgent() throws JSchException;
/*   76 */   public String getPublicKeyComment() { return this.publicKeyComment; }
/*      */   
/*      */   public void setPublicKeyComment(String publicKeyComment)
/*      */   {
/*   80 */     this.publicKeyComment = publicKeyComment;
/*      */   }
/*      */   
/*   83 */   protected String publicKeyComment = "no comment";
/*      */   
/*   85 */   JSch jsch = null;
/*      */   private Cipher cipher;
/*      */   private HASH hash;
/*      */   private Random random;
/*      */   private byte[] passphrase;
/*      */   
/*      */   public KeyPair(JSch jsch)
/*      */   {
/*   93 */     this.jsch = jsch;
/*      */   }
/*      */   
/*   96 */   static byte[][] header = { Util.str2byte("Proc-Type: 4,ENCRYPTED"), Util.str2byte("DEK-Info: DES-EDE3-CBC,") };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract byte[] getPrivateKey();
/*      */   
/*      */ 
/*      */ 
/*      */   public void writePrivateKey(OutputStream out)
/*      */   {
/*  107 */     writePrivateKey(out, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writePrivateKey(OutputStream out, byte[] passphrase)
/*      */   {
/*  116 */     if (passphrase == null) {
/*  117 */       passphrase = this.passphrase;
/*      */     }
/*  119 */     byte[] plain = getPrivateKey();
/*  120 */     byte[][] _iv = new byte[1][];
/*  121 */     byte[] encoded = encrypt(plain, _iv, passphrase);
/*  122 */     if (encoded != plain)
/*  123 */       Util.bzero(plain);
/*  124 */     byte[] iv = _iv[0];
/*  125 */     byte[] prv = Util.toBase64(encoded, 0, encoded.length);
/*      */     try
/*      */     {
/*  128 */       out.write(getBegin());out.write(cr);
/*  129 */       if (passphrase != null) {
/*  130 */         out.write(header[0]);out.write(cr);
/*  131 */         out.write(header[1]);
/*  132 */         for (int i = 0; i < iv.length; i++) {
/*  133 */           out.write(b2a((byte)(iv[i] >>> 4 & 0xF)));
/*  134 */           out.write(b2a((byte)(iv[i] & 0xF)));
/*      */         }
/*  136 */         out.write(cr);
/*  137 */         out.write(cr);
/*      */       }
/*  139 */       int i = 0;
/*  140 */       while (i < prv.length) {
/*  141 */         if (i + 64 < prv.length) {
/*  142 */           out.write(prv, i, 64);
/*  143 */           out.write(cr);
/*  144 */           i += 64;
/*      */         }
/*      */         else {
/*  147 */           out.write(prv, i, prv.length - i);
/*  148 */           out.write(cr);
/*      */         }
/*      */       }
/*  151 */       out.write(getEnd());out.write(cr);
/*      */     }
/*      */     catch (Exception e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  158 */   private static byte[] space = Util.str2byte(" ");
/*      */   
/*      */ 
/*      */ 
/*      */   abstract byte[] getKeyTypeName();
/*      */   
/*      */ 
/*      */ 
/*      */   public abstract int getKeyType();
/*      */   
/*      */ 
/*      */   public byte[] getPublicKeyBlob()
/*      */   {
/*  171 */     return this.publickeyblob;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writePublicKey(OutputStream out, String comment)
/*      */   {
/*  180 */     byte[] pubblob = getPublicKeyBlob();
/*  181 */     byte[] pub = Util.toBase64(pubblob, 0, pubblob.length);
/*      */     try {
/*  183 */       out.write(getKeyTypeName());out.write(space);
/*  184 */       out.write(pub, 0, pub.length);out.write(space);
/*  185 */       out.write(Util.str2byte(comment));
/*  186 */       out.write(cr);
/*      */     }
/*      */     catch (Exception e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writePublicKey(String name, String comment)
/*      */     throws FileNotFoundException, IOException
/*      */   {
/*  199 */     FileOutputStream fos = new FileOutputStream(name);
/*  200 */     writePublicKey(fos, comment);
/*  201 */     fos.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeSECSHPublicKey(OutputStream out, String comment)
/*      */   {
/*  211 */     byte[] pubblob = getPublicKeyBlob();
/*  212 */     byte[] pub = Util.toBase64(pubblob, 0, pubblob.length);
/*      */     try {
/*  214 */       out.write(Util.str2byte("---- BEGIN SSH2 PUBLIC KEY ----"));out.write(cr);
/*  215 */       out.write(Util.str2byte("Comment: \"" + comment + "\""));out.write(cr);
/*  216 */       int index = 0;
/*  217 */       while (index < pub.length) {
/*  218 */         int len = 70;
/*  219 */         if (pub.length - index < len) len = pub.length - index;
/*  220 */         out.write(pub, index, len);out.write(cr);
/*  221 */         index += len;
/*      */       }
/*  223 */       out.write(Util.str2byte("---- END SSH2 PUBLIC KEY ----"));out.write(cr);
/*      */     }
/*      */     catch (Exception e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeSECSHPublicKey(String name, String comment)
/*      */     throws FileNotFoundException, IOException
/*      */   {
/*  237 */     FileOutputStream fos = new FileOutputStream(name);
/*  238 */     writeSECSHPublicKey(fos, comment);
/*  239 */     fos.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writePrivateKey(String name)
/*      */     throws FileNotFoundException, IOException
/*      */   {
/*  248 */     writePrivateKey(name, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writePrivateKey(String name, byte[] passphrase)
/*      */     throws FileNotFoundException, IOException
/*      */   {
/*  258 */     FileOutputStream fos = new FileOutputStream(name);
/*  259 */     writePrivateKey(fos, passphrase);
/*  260 */     fos.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFingerPrint()
/*      */   {
/*  268 */     if (this.hash == null) this.hash = genHash();
/*  269 */     byte[] kblob = getPublicKeyBlob();
/*  270 */     if (kblob == null) return null;
/*  271 */     return Util.getFingerPrint(this.hash, kblob);
/*      */   }
/*      */   
/*      */   private byte[] encrypt(byte[] plain, byte[][] _iv, byte[] passphrase) {
/*  275 */     if (passphrase == null) { return plain;
/*      */     }
/*  277 */     if (this.cipher == null) this.cipher = genCipher();
/*  278 */     byte[] iv = _iv[0] = new byte[this.cipher.getIVSize()];
/*      */     
/*  280 */     if (this.random == null) this.random = genRandom();
/*  281 */     this.random.fill(iv, 0, iv.length);
/*      */     
/*  283 */     byte[] key = genKey(passphrase, iv);
/*  284 */     byte[] encoded = plain;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  289 */     int bsize = this.cipher.getIVSize();
/*  290 */     byte[] foo = new byte[(encoded.length / bsize + 1) * bsize];
/*  291 */     System.arraycopy(encoded, 0, foo, 0, encoded.length);
/*  292 */     int padding = bsize - encoded.length % bsize;
/*  293 */     for (int i = foo.length - 1; foo.length - padding <= i; i--) {
/*  294 */       foo[i] = ((byte)padding);
/*      */     }
/*  296 */     encoded = foo;
/*      */     
/*      */     try
/*      */     {
/*  300 */       this.cipher.init(0, key, iv);
/*  301 */       this.cipher.update(encoded, 0, encoded.length, encoded, 0);
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/*  306 */     Util.bzero(key);
/*  307 */     return encoded;
/*      */   }
/*      */   
/*      */   abstract boolean parse(byte[] paramArrayOfByte);
/*      */   
/*      */   private byte[] decrypt(byte[] data, byte[] passphrase, byte[] iv)
/*      */   {
/*      */     try {
/*  315 */       byte[] key = genKey(passphrase, iv);
/*  316 */       this.cipher.init(1, key, iv);
/*  317 */       Util.bzero(key);
/*  318 */       byte[] plain = new byte[data.length];
/*  319 */       this.cipher.update(data, 0, data.length, plain, 0);
/*  320 */       return plain;
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/*  325 */     return null;
/*      */   }
/*      */   
/*      */   int writeSEQUENCE(byte[] buf, int index, int len) {
/*  329 */     buf[(index++)] = 48;
/*  330 */     index = writeLength(buf, index, len);
/*  331 */     return index;
/*      */   }
/*      */   
/*  334 */   int writeINTEGER(byte[] buf, int index, byte[] data) { buf[(index++)] = 2;
/*  335 */     index = writeLength(buf, index, data.length);
/*  336 */     System.arraycopy(data, 0, buf, index, data.length);
/*  337 */     index += data.length;
/*  338 */     return index;
/*      */   }
/*      */   
/*      */   int countLength(int len) {
/*  342 */     int i = 1;
/*  343 */     if (len <= 127) return i;
/*  344 */     while (len > 0) {
/*  345 */       len >>>= 8;
/*  346 */       i++;
/*      */     }
/*  348 */     return i;
/*      */   }
/*      */   
/*      */   int writeLength(byte[] data, int index, int len) {
/*  352 */     int i = countLength(len) - 1;
/*  353 */     if (i == 0) {
/*  354 */       data[(index++)] = ((byte)len);
/*  355 */       return index;
/*      */     }
/*  357 */     data[(index++)] = ((byte)(0x80 | i));
/*  358 */     int j = index + i;
/*  359 */     while (i > 0) {
/*  360 */       data[(index + i - 1)] = ((byte)(len & 0xFF));
/*  361 */       len >>>= 8;
/*  362 */       i--;
/*      */     }
/*  364 */     return j;
/*      */   }
/*      */   
/*      */   private Random genRandom() {
/*  368 */     if (this.random == null)
/*      */       try {
/*  370 */         Class c = Class.forName(JSch.getConfig("random"));
/*  371 */         this.random = ((Random)c.newInstance());
/*      */       } catch (Exception e) {
/*  373 */         System.err.println("connect: random " + e);
/*      */       }
/*  375 */     return this.random;
/*      */   }
/*      */   
/*      */   private HASH genHash() {
/*      */     try {
/*  380 */       Class c = Class.forName(JSch.getConfig("md5"));
/*  381 */       this.hash = ((HASH)c.newInstance());
/*  382 */       this.hash.init();
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*  386 */     return this.hash;
/*      */   }
/*      */   
/*      */   private Cipher genCipher() {
/*      */     try {
/*  391 */       Class c = Class.forName(JSch.getConfig("3des-cbc"));
/*  392 */       this.cipher = ((Cipher)c.newInstance());
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*  396 */     return this.cipher;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized byte[] genKey(byte[] passphrase, byte[] iv)
/*      */   {
/*  406 */     if (this.cipher == null) this.cipher = genCipher();
/*  407 */     if (this.hash == null) { this.hash = genHash();
/*      */     }
/*  409 */     byte[] key = new byte[this.cipher.getBlockSize()];
/*  410 */     int hsize = this.hash.getBlockSize();
/*  411 */     byte[] hn = new byte[key.length / hsize * hsize + (key.length % hsize == 0 ? 0 : hsize)];
/*      */     try
/*      */     {
/*  414 */       byte[] tmp = null;
/*  415 */       if (this.vendor == 0) {
/*  416 */         for (int index = 0; index + hsize <= hn.length;) {
/*  417 */           if (tmp != null) this.hash.update(tmp, 0, tmp.length);
/*  418 */           this.hash.update(passphrase, 0, passphrase.length);
/*  419 */           this.hash.update(iv, 0, iv.length > 8 ? 8 : iv.length);
/*  420 */           tmp = this.hash.digest();
/*  421 */           System.arraycopy(tmp, 0, hn, index, tmp.length);
/*  422 */           index += tmp.length;
/*      */         }
/*  424 */         System.arraycopy(hn, 0, key, 0, key.length);
/*      */       }
/*  426 */       else if (this.vendor == 1) {
/*  427 */         for (int index = 0; index + hsize <= hn.length;) {
/*  428 */           if (tmp != null) this.hash.update(tmp, 0, tmp.length);
/*  429 */           this.hash.update(passphrase, 0, passphrase.length);
/*  430 */           tmp = this.hash.digest();
/*  431 */           System.arraycopy(tmp, 0, hn, index, tmp.length);
/*  432 */           index += tmp.length;
/*      */         }
/*  434 */         System.arraycopy(hn, 0, key, 0, key.length);
/*      */       }
/*  436 */       else if (this.vendor == 2) {
/*  437 */         Class c = Class.forName(JSch.getConfig("sha-1"));
/*  438 */         HASH sha1 = (HASH)c.newInstance();
/*  439 */         tmp = new byte[4];
/*  440 */         key = new byte[40];
/*  441 */         for (int i = 0; i < 2; i++) {
/*  442 */           sha1.init();
/*  443 */           tmp[3] = ((byte)i);
/*  444 */           sha1.update(tmp, 0, tmp.length);
/*  445 */           sha1.update(passphrase, 0, passphrase.length);
/*  446 */           System.arraycopy(sha1.digest(), 0, key, i * 20, 20);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  451 */       System.err.println(e);
/*      */     }
/*  453 */     return key;
/*      */   }
/*      */   
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setPassphrase(String passphrase) {
/*  460 */     if ((passphrase == null) || (passphrase.length() == 0)) {
/*  461 */       setPassphrase((byte[])null);
/*      */     }
/*      */     else {
/*  464 */       setPassphrase(Util.str2byte(passphrase));
/*      */     }
/*      */   }
/*      */   
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setPassphrase(byte[] passphrase) {
/*  472 */     if ((passphrase != null) && (passphrase.length == 0))
/*  473 */       passphrase = null;
/*  474 */     this.passphrase = passphrase;
/*      */   }
/*      */   
/*  477 */   private boolean encrypted = false;
/*  478 */   private byte[] data = null;
/*  479 */   private byte[] iv = null;
/*  480 */   private byte[] publickeyblob = null;
/*      */   
/*  482 */   public boolean isEncrypted() { return this.encrypted; }
/*      */   
/*  484 */   public boolean decrypt(String _passphrase) { if ((_passphrase == null) || (_passphrase.length() == 0)) {
/*  485 */       return !this.encrypted;
/*      */     }
/*  487 */     return decrypt(Util.str2byte(_passphrase));
/*      */   }
/*      */   
/*      */   public boolean decrypt(byte[] _passphrase) {
/*  491 */     if (!this.encrypted) {
/*  492 */       return true;
/*      */     }
/*  494 */     if (_passphrase == null) {
/*  495 */       return !this.encrypted;
/*      */     }
/*  497 */     byte[] bar = new byte[_passphrase.length];
/*  498 */     System.arraycopy(_passphrase, 0, bar, 0, bar.length);
/*  499 */     _passphrase = bar;
/*  500 */     byte[] foo = decrypt(this.data, _passphrase, this.iv);
/*  501 */     Util.bzero(_passphrase);
/*  502 */     if (parse(foo)) {
/*  503 */       this.encrypted = false;
/*      */     }
/*  505 */     return !this.encrypted;
/*      */   }
/*      */   
/*      */   public static KeyPair load(JSch jsch, String prvkey) throws JSchException {
/*  509 */     String pubkey = prvkey + ".pub";
/*  510 */     if (!new File(pubkey).exists()) {
/*  511 */       pubkey = null;
/*      */     }
/*  513 */     return load(jsch, prvkey, pubkey);
/*      */   }
/*      */   
/*      */   public static KeyPair load(JSch jsch, String prvfile, String pubfile) throws JSchException {
/*  517 */     byte[] prvkey = null;
/*  518 */     byte[] pubkey = null;
/*      */     try
/*      */     {
/*  521 */       prvkey = Util.fromFile(prvfile);
/*      */     }
/*      */     catch (IOException e) {
/*  524 */       throw new JSchException(e.toString(), e);
/*      */     }
/*      */     
/*  527 */     String _pubfile = pubfile;
/*  528 */     if (pubfile == null) {
/*  529 */       _pubfile = prvfile + ".pub";
/*      */     }
/*      */     try
/*      */     {
/*  533 */       pubkey = Util.fromFile(_pubfile);
/*      */     }
/*      */     catch (IOException e) {
/*  536 */       if (pubfile != null) {
/*  537 */         throw new JSchException(e.toString(), e);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  542 */       return load(jsch, prvkey, pubkey);
/*      */     }
/*      */     finally {
/*  545 */       Util.bzero(prvkey);
/*      */     }
/*      */   }
/*      */   
/*      */   public static KeyPair load(JSch jsch, byte[] prvkey, byte[] pubkey) throws JSchException
/*      */   {
/*  551 */     byte[] iv = new byte[8];
/*  552 */     boolean encrypted = true;
/*  553 */     byte[] data = null;
/*      */     
/*  555 */     byte[] publickeyblob = null;
/*      */     
/*  557 */     int type = 0;
/*  558 */     int vendor = 0;
/*  559 */     String publicKeyComment = "";
/*  560 */     Cipher cipher = null;
/*      */     
/*      */ 
/*  563 */     if ((pubkey == null) && (prvkey != null) && (prvkey.length > 11) && (prvkey[0] == 0) && (prvkey[1] == 0) && (prvkey[2] == 0) && (prvkey[3] == 7))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  568 */       Buffer buf = new Buffer(prvkey);
/*  569 */       buf.skip(prvkey.length);
/*  570 */       String _type = new String(buf.getString());
/*  571 */       buf.rewind();
/*      */       
/*  573 */       KeyPair kpair = null;
/*  574 */       if (_type.equals("ssh-rsa")) {
/*  575 */         kpair = KeyPairRSA.fromSSHAgent(jsch, buf);
/*      */       }
/*  577 */       else if (_type.equals("ssh-dss")) {
/*  578 */         kpair = KeyPairDSA.fromSSHAgent(jsch, buf);
/*      */       }
/*      */       else {
/*  581 */         throw new JSchException("privatekey: invalid key " + new String(prvkey, 4, 7));
/*      */       }
/*  583 */       return kpair;
/*      */     }
/*      */     try
/*      */     {
/*  587 */       byte[] buf = prvkey;
/*      */       
/*  589 */       if (buf != null) {
/*  590 */         KeyPair ppk = loadPPK(jsch, buf);
/*  591 */         if (ppk != null) {
/*  592 */           return ppk;
/*      */         }
/*      */       }
/*  595 */       int len = buf != null ? buf.length : 0;
/*  596 */       int i = 0;
/*      */       
/*      */ 
/*  599 */       while ((i < len) && (
/*  600 */         (buf[i] != 45) || (i + 4 >= len) || (buf[(i + 1)] != 45) || (buf[(i + 2)] != 45) || (buf[(i + 3)] != 45) || (buf[(i + 4)] != 45)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  605 */         i++;
/*      */       }
/*      */       
/*  608 */       while (i < len) {
/*  609 */         if ((buf[i] == 66) && (i + 3 < len) && (buf[(i + 1)] == 69) && (buf[(i + 2)] == 71) && (buf[(i + 3)] == 73)) {
/*  610 */           i += 6;
/*  611 */           if (i + 2 >= len)
/*  612 */             throw new JSchException("invalid privatekey: " + prvkey);
/*  613 */           if ((buf[i] == 68) && (buf[(i + 1)] == 83) && (buf[(i + 2)] == 65)) { type = 1;
/*  614 */           } else if ((buf[i] == 82) && (buf[(i + 1)] == 83) && (buf[(i + 2)] == 65)) { type = 2;
/*  615 */           } else if ((buf[i] == 83) && (buf[(i + 1)] == 83) && (buf[(i + 2)] == 72)) {
/*  616 */             type = 3;
/*  617 */             vendor = 1;
/*      */           }
/*      */           else {
/*  620 */             throw new JSchException("invalid privatekey: " + prvkey);
/*      */           }
/*  622 */           i += 3;
/*      */ 
/*      */         }
/*  625 */         else if ((buf[i] == 65) && (i + 7 < len) && (buf[(i + 1)] == 69) && (buf[(i + 2)] == 83) && (buf[(i + 3)] == 45) && (buf[(i + 4)] == 50) && (buf[(i + 5)] == 53) && (buf[(i + 6)] == 54) && (buf[(i + 7)] == 45))
/*      */         {
/*  627 */           i += 8;
/*  628 */           if (Session.checkCipher(JSch.getConfig("aes256-cbc"))) {
/*  629 */             Class c = Class.forName(JSch.getConfig("aes256-cbc"));
/*  630 */             cipher = (Cipher)c.newInstance();
/*      */             
/*  632 */             iv = new byte[cipher.getIVSize()];
/*      */           }
/*      */           else {
/*  635 */             throw new JSchException("privatekey: aes256-cbc is not available " + prvkey);
/*      */           }
/*      */           
/*      */         }
/*  639 */         else if ((buf[i] == 65) && (i + 7 < len) && (buf[(i + 1)] == 69) && (buf[(i + 2)] == 83) && (buf[(i + 3)] == 45) && (buf[(i + 4)] == 49) && (buf[(i + 5)] == 57) && (buf[(i + 6)] == 50) && (buf[(i + 7)] == 45))
/*      */         {
/*  641 */           i += 8;
/*  642 */           if (Session.checkCipher(JSch.getConfig("aes192-cbc"))) {
/*  643 */             Class c = Class.forName(JSch.getConfig("aes192-cbc"));
/*  644 */             cipher = (Cipher)c.newInstance();
/*      */             
/*  646 */             iv = new byte[cipher.getIVSize()];
/*      */           }
/*      */           else {
/*  649 */             throw new JSchException("privatekey: aes192-cbc is not available " + prvkey);
/*      */           }
/*      */           
/*      */         }
/*  653 */         else if ((buf[i] == 65) && (i + 7 < len) && (buf[(i + 1)] == 69) && (buf[(i + 2)] == 83) && (buf[(i + 3)] == 45) && (buf[(i + 4)] == 49) && (buf[(i + 5)] == 50) && (buf[(i + 6)] == 56) && (buf[(i + 7)] == 45))
/*      */         {
/*  655 */           i += 8;
/*  656 */           if (Session.checkCipher(JSch.getConfig("aes128-cbc"))) {
/*  657 */             Class c = Class.forName(JSch.getConfig("aes128-cbc"));
/*  658 */             cipher = (Cipher)c.newInstance();
/*      */             
/*  660 */             iv = new byte[cipher.getIVSize()];
/*      */           }
/*      */           else {
/*  663 */             throw new JSchException("privatekey: aes128-cbc is not available " + prvkey);
/*      */           }
/*      */           
/*      */         }
/*  667 */         else if ((buf[i] == 67) && (i + 3 < len) && (buf[(i + 1)] == 66) && (buf[(i + 2)] == 67) && (buf[(i + 3)] == 44)) {
/*  668 */           i += 4;
/*  669 */           for (int ii = 0; ii < iv.length; ii++) {
/*  670 */             iv[ii] = ((byte)((a2b(buf[(i++)]) << 4 & 0xF0) + (a2b(buf[(i++)]) & 0xF)));
/*      */           }
/*      */           
/*      */         }
/*  674 */         else if ((buf[i] == 13) && (i + 1 < buf.length) && (buf[(i + 1)] == 10)) {
/*  675 */           i++;
/*      */         }
/*      */         else {
/*  678 */           if ((buf[i] == 10) && (i + 1 < buf.length)) {
/*  679 */             if (buf[(i + 1)] == 10) { i += 2; break; }
/*  680 */             if ((buf[(i + 1)] == 13) && (i + 2 < buf.length) && (buf[(i + 2)] == 10))
/*      */             {
/*  682 */               i += 3; break;
/*      */             }
/*  684 */             boolean inheader = false;
/*  685 */             for (int j = i + 1; j < buf.length; j++) {
/*  686 */               if (buf[j] == 10)
/*      */                 break;
/*  688 */               if (buf[j] == 58) { inheader = true; break;
/*      */               } }
/*  690 */             if (!inheader) {
/*  691 */               i++;
/*  692 */               encrypted = false;
/*  693 */               break;
/*      */             }
/*      */           }
/*  696 */           i++;
/*      */         }
/*      */       }
/*  699 */       if (buf != null)
/*      */       {
/*  701 */         if (type == 0) {
/*  702 */           throw new JSchException("invalid privatekey: " + prvkey);
/*      */         }
/*      */         
/*  705 */         int start = i;
/*  706 */         while ((i < len) && 
/*  707 */           (buf[i] != 45)) {
/*  708 */           i++;
/*      */         }
/*      */         
/*  711 */         if ((len - i == 0) || (i - start == 0)) {
/*  712 */           throw new JSchException("invalid privatekey: " + prvkey);
/*      */         }
/*      */         
/*      */ 
/*  716 */         byte[] tmp = new byte[i - start];
/*  717 */         System.arraycopy(buf, start, tmp, 0, tmp.length);
/*  718 */         byte[] _buf = tmp;
/*      */         
/*  720 */         start = 0;
/*  721 */         i = 0;
/*      */         
/*  723 */         int _len = _buf.length;
/*  724 */         while (i < _len) {
/*  725 */           if (_buf[i] == 10) {
/*  726 */             boolean xd = _buf[(i - 1)] == 13;
/*      */             
/*  728 */             System.arraycopy(_buf, i + 1, _buf, i - (xd ? 1 : 0), _len - i - 1 - (xd ? 1 : 0));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  733 */             if (xd) _len--;
/*  734 */             _len--;
/*      */           }
/*      */           else {
/*  737 */             if (_buf[i] == 45) break;
/*  738 */             i++;
/*      */           }
/*      */         }
/*  741 */         if (i - start > 0) {
/*  742 */           data = Util.fromBase64(_buf, start, i - start);
/*      */         }
/*  744 */         Util.bzero(_buf);
/*      */       }
/*      */       
/*  747 */       if ((data != null) && (data.length > 4) && (data[0] == 63) && (data[1] == 111) && (data[2] == -7) && (data[3] == -21))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  754 */         Buffer _buf = new Buffer(data);
/*  755 */         _buf.getInt();
/*  756 */         _buf.getInt();
/*  757 */         byte[] _type = _buf.getString();
/*      */         
/*  759 */         String _cipher = Util.byte2str(_buf.getString());
/*      */         
/*  761 */         if (_cipher.equals("3des-cbc")) {
/*  762 */           _buf.getInt();
/*  763 */           byte[] foo = new byte[data.length - _buf.getOffSet()];
/*  764 */           _buf.getByte(foo);
/*  765 */           data = foo;
/*  766 */           encrypted = true;
/*  767 */           throw new JSchException("unknown privatekey format: " + prvkey);
/*      */         }
/*  769 */         if (_cipher.equals("none")) {
/*  770 */           _buf.getInt();
/*  771 */           _buf.getInt();
/*      */           
/*  773 */           encrypted = false;
/*      */           
/*  775 */           byte[] foo = new byte[data.length - _buf.getOffSet()];
/*  776 */           _buf.getByte(foo);
/*  777 */           data = foo;
/*      */         }
/*      */       }
/*      */       
/*  781 */       if (pubkey != null) {
/*      */         try {
/*  783 */           buf = pubkey;
/*  784 */           len = buf.length;
/*  785 */           if ((buf.length > 4) && (buf[0] == 45) && (buf[1] == 45) && (buf[2] == 45) && (buf[3] == 45))
/*      */           {
/*      */ 
/*  788 */             boolean valid = true;
/*  789 */             i = 0;
/*  790 */             do { i++; } while ((buf.length > i) && (buf[i] != 10));
/*  791 */             if (buf.length <= i) { valid = false;
/*      */             }
/*  793 */             while (valid) {
/*  794 */               if (buf[i] == 10) {
/*  795 */                 boolean inheader = false;
/*  796 */                 for (int j = i + 1; j < buf.length; j++) {
/*  797 */                   if (buf[j] == 10) break;
/*  798 */                   if (buf[j] == 58) { inheader = true; break;
/*      */                   } }
/*  800 */                 if (!inheader) {
/*  801 */                   i++;
/*  802 */                   break;
/*      */                 }
/*      */               }
/*  805 */               i++;
/*      */             }
/*  807 */             if (buf.length <= i) { valid = false;
/*      */             }
/*  809 */             int start = i;
/*  810 */             while ((valid) && (i < len))
/*  811 */               if (buf[i] == 10) {
/*  812 */                 System.arraycopy(buf, i + 1, buf, i, len - i - 1);
/*  813 */                 len--;
/*      */               }
/*      */               else {
/*  816 */                 if (buf[i] == 45) break;
/*  817 */                 i++;
/*      */               }
/*  819 */             if (valid) {
/*  820 */               publickeyblob = Util.fromBase64(buf, start, i - start);
/*  821 */               if ((prvkey == null) || (type == 3)) {
/*  822 */                 if (publickeyblob[8] == 100) { type = 1;
/*  823 */                 } else if (publickeyblob[8] == 114) { type = 2;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  828 */           else if ((buf[0] == 115) && (buf[1] == 115) && (buf[2] == 104) && (buf[3] == 45)) {
/*  829 */             if ((prvkey == null) && (buf.length > 7))
/*      */             {
/*  831 */               if (buf[4] == 100) { type = 1;
/*  832 */               } else if (buf[4] == 114) type = 2;
/*      */             }
/*  834 */             i = 0;
/*  835 */             while ((i < len) && (buf[i] != 32)) i++; i++;
/*  836 */             if (i < len) {
/*  837 */               int start = i;
/*  838 */               while ((i < len) && (buf[i] != 32)) i++;
/*  839 */               publickeyblob = Util.fromBase64(buf, start, i - start);
/*      */             }
/*  841 */             if (i++ < len) {
/*  842 */               int start = i;
/*  843 */               while ((i < len) && (buf[i] != 10)) i++;
/*  844 */               if (i < len) {
/*  845 */                 publicKeyComment = new String(buf, start, i - start);
/*      */               }
/*      */               
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (Exception ee) {}
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  856 */       if ((e instanceof JSchException)) throw ((JSchException)e);
/*  857 */       if ((e instanceof Throwable))
/*  858 */         throw new JSchException(e.toString(), e);
/*  859 */       throw new JSchException(e.toString());
/*      */     }
/*      */     
/*  862 */     KeyPair kpair = null;
/*  863 */     if (type == 1) { kpair = new KeyPairDSA(jsch);
/*  864 */     } else if (type == 2) { kpair = new KeyPairRSA(jsch);
/*      */     }
/*  866 */     if (kpair != null) {
/*  867 */       kpair.encrypted = encrypted;
/*  868 */       kpair.publickeyblob = publickeyblob;
/*  869 */       kpair.vendor = vendor;
/*  870 */       kpair.publicKeyComment = publicKeyComment;
/*  871 */       kpair.cipher = cipher;
/*      */       
/*  873 */       if (encrypted) {
/*  874 */         kpair.encrypted = true;
/*  875 */         kpair.iv = iv;
/*  876 */         kpair.data = data;
/*      */       }
/*      */       else {
/*  879 */         if (kpair.parse(data)) {
/*  880 */           kpair.encrypted = false;
/*  881 */           return kpair;
/*      */         }
/*      */         
/*  884 */         throw new JSchException("invalid privatekey: " + prvkey);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  889 */     return kpair;
/*      */   }
/*      */   
/*      */   private static byte a2b(byte c) {
/*  893 */     if ((48 <= c) && (c <= 57)) return (byte)(c - 48);
/*  894 */     return (byte)(c - 97 + 10);
/*      */   }
/*      */   
/*  897 */   private static byte b2a(byte c) { if ((0 <= c) && (c <= 9)) return (byte)(c + 48);
/*  898 */     return (byte)(c - 10 + 65);
/*      */   }
/*      */   
/*      */   public void dispose() {
/*  902 */     Util.bzero(this.passphrase);
/*      */   }
/*      */   
/*      */   public void finalize() {
/*  906 */     dispose();
/*      */   }
/*      */   
/*  909 */   private static final String[] header1 = { "PuTTY-User-Key-File-2: ", "Encryption: ", "Comment: ", "Public-Lines: " };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  916 */   private static final String[] header2 = { "Private-Lines: " };
/*      */   
/*      */ 
/*      */ 
/*  920 */   private static final String[] header3 = { "Private-MAC: " };
/*      */   
/*      */   static KeyPair loadPPK(JSch jsch, byte[] buf)
/*      */     throws JSchException
/*      */   {
/*  925 */     byte[] pubkey = null;
/*  926 */     byte[] prvkey = null;
/*  927 */     int lines = 0;
/*      */     
/*  929 */     Buffer buffer = new Buffer(buf);
/*  930 */     Hashtable v = new Hashtable();
/*      */     for (;;)
/*      */     {
/*  933 */       if (!parseHeader(buffer, v)) {
/*      */         break;
/*      */       }
/*      */     }
/*  937 */     String typ = (String)v.get("PuTTY-User-Key-File-2");
/*  938 */     if (typ == null) {
/*  939 */       return null;
/*      */     }
/*      */     
/*  942 */     lines = Integer.parseInt((String)v.get("Public-Lines"));
/*  943 */     pubkey = parseLines(buffer, lines);
/*      */     for (;;)
/*      */     {
/*  946 */       if (!parseHeader(buffer, v)) {
/*      */         break;
/*      */       }
/*      */     }
/*  950 */     lines = Integer.parseInt((String)v.get("Private-Lines"));
/*  951 */     prvkey = parseLines(buffer, lines);
/*      */     for (;;)
/*      */     {
/*  954 */       if (!parseHeader(buffer, v)) {
/*      */         break;
/*      */       }
/*      */     }
/*  958 */     prvkey = Util.fromBase64(prvkey, 0, prvkey.length);
/*  959 */     pubkey = Util.fromBase64(pubkey, 0, pubkey.length);
/*      */     
/*  961 */     KeyPair kpair = null;
/*      */     
/*  963 */     if (typ.equals("ssh-rsa"))
/*      */     {
/*  965 */       Buffer _buf = new Buffer(pubkey);
/*  966 */       _buf.skip(pubkey.length);
/*      */       
/*  968 */       int len = _buf.getInt();
/*  969 */       _buf.getByte(new byte[len]);
/*  970 */       byte[] pub_array = new byte[_buf.getInt()];
/*  971 */       _buf.getByte(pub_array);
/*  972 */       byte[] n_array = new byte[_buf.getInt()];
/*  973 */       _buf.getByte(n_array);
/*      */       
/*  975 */       kpair = new KeyPairRSA(jsch, n_array, pub_array, null);
/*      */     }
/*  977 */     else if (typ.equals("ssh-dss")) {
/*  978 */       Buffer _buf = new Buffer(pubkey);
/*  979 */       _buf.skip(pubkey.length);
/*      */       
/*  981 */       int len = _buf.getInt();
/*  982 */       _buf.getByte(new byte[len]);
/*      */       
/*  984 */       byte[] p_array = new byte[_buf.getInt()];
/*  985 */       _buf.getByte(p_array);
/*  986 */       byte[] q_array = new byte[_buf.getInt()];
/*  987 */       _buf.getByte(q_array);
/*  988 */       byte[] g_array = new byte[_buf.getInt()];
/*  989 */       _buf.getByte(g_array);
/*  990 */       byte[] y_array = new byte[_buf.getInt()];
/*  991 */       _buf.getByte(y_array);
/*      */       
/*  993 */       kpair = new KeyPairDSA(jsch, p_array, q_array, g_array, y_array, null);
/*      */     }
/*      */     else {
/*  996 */       return null;
/*      */     }
/*      */     
/*  999 */     if (kpair == null) {
/* 1000 */       return null;
/*      */     }
/* 1002 */     kpair.encrypted = (!v.get("Encryption").equals("none"));
/* 1003 */     kpair.vendor = 2;
/* 1004 */     kpair.publicKeyComment = ((String)v.get("Comment"));
/* 1005 */     if (kpair.encrypted) {
/* 1006 */       if (Session.checkCipher(JSch.getConfig("aes256-cbc"))) {
/*      */         try {
/* 1008 */           Class c = Class.forName(JSch.getConfig("aes256-cbc"));
/* 1009 */           kpair.cipher = ((Cipher)c.newInstance());
/* 1010 */           kpair.iv = new byte[kpair.cipher.getIVSize()];
/*      */         }
/*      */         catch (Exception e) {
/* 1013 */           throw new JSchException("The cipher 'aes256-cbc' is required, but it is not available.");
/*      */         }
/*      */         
/*      */       } else {
/* 1017 */         throw new JSchException("The cipher 'aes256-cbc' is required, but it is not available.");
/*      */       }
/* 1019 */       kpair.data = prvkey;
/*      */     }
/*      */     else {
/* 1022 */       kpair.data = prvkey;
/* 1023 */       kpair.parse(prvkey);
/*      */     }
/* 1025 */     return kpair;
/*      */   }
/*      */   
/*      */   private static byte[] parseLines(Buffer buffer, int lines) {
/* 1029 */     byte[] buf = buffer.buffer;
/* 1030 */     int index = buffer.index;
/* 1031 */     byte[] data = null;
/*      */     
/* 1033 */     int i = index;
/* 1034 */     while (lines-- > 0) {
/* 1035 */       while (buf.length > i) {
/* 1036 */         if (buf[(i++)] == 13) {
/* 1037 */           if (data == null) {
/* 1038 */             data = new byte[i - index - 1];
/* 1039 */             System.arraycopy(buf, index, data, 0, i - index - 1);
/*      */           }
/*      */           else {
/* 1042 */             byte[] tmp = new byte[data.length + i - index - 1];
/* 1043 */             System.arraycopy(data, 0, tmp, 0, data.length);
/* 1044 */             System.arraycopy(buf, index, tmp, data.length, i - index - 1);
/* 1045 */             for (int j = 0; j < data.length; j++) data[j] = 0;
/* 1046 */             data = tmp;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1051 */       if (buf[i] == 10)
/* 1052 */         i++;
/* 1053 */       index = i;
/*      */     }
/*      */     
/* 1056 */     if (data != null) {
/* 1057 */       buffer.index = index;
/*      */     }
/* 1059 */     return data;
/*      */   }
/*      */   
/*      */   private static boolean parseHeader(Buffer buffer, Hashtable v) {
/* 1063 */     byte[] buf = buffer.buffer;
/* 1064 */     int index = buffer.index;
/* 1065 */     String key = null;
/* 1066 */     String value = null;
/* 1067 */     for (int i = index; i < buf.length; i++) {
/* 1068 */       if (buf[i] == 13) {
/*      */         break;
/*      */       }
/* 1071 */       if (buf[i] == 58) {
/* 1072 */         key = new String(buf, index, i - index);
/* 1073 */         i++;
/* 1074 */         if ((i < buf.length) && (buf[i] == 32)) {
/* 1075 */           i++;
/*      */         }
/* 1077 */         index = i;
/* 1078 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1082 */     if (key == null) {
/* 1083 */       return false;
/*      */     }
/* 1085 */     for (int i = index; i < buf.length; i++) {
/* 1086 */       if (buf[i] == 13) {
/* 1087 */         value = new String(buf, index, i - index);
/* 1088 */         i++;
/* 1089 */         if ((i < buf.length) && (buf[i] == 10)) {
/* 1090 */           i++;
/*      */         }
/* 1092 */         index = i;
/* 1093 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1097 */     if (value != null) {
/* 1098 */       v.put(key, value);
/* 1099 */       buffer.index = index;
/*      */     }
/*      */     
/* 1102 */     return (key != null) && (value != null);
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\KeyPair.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */