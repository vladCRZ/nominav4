package com.jcraft.jsch;

public abstract interface KeyPairGenDSA
{
  public abstract void init(int paramInt)
    throws Exception;
  
  public abstract byte[] getX();
  
  public abstract byte[] getY();
  
  public abstract byte[] getP();
  
  public abstract byte[] getQ();
  
  public abstract byte[] getG();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\KeyPairGenDSA.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */