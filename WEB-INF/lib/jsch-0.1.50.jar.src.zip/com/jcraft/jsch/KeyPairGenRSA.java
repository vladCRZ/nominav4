package com.jcraft.jsch;

public abstract interface KeyPairGenRSA
{
  public abstract void init(int paramInt)
    throws Exception;
  
  public abstract byte[] getD();
  
  public abstract byte[] getE();
  
  public abstract byte[] getN();
  
  public abstract byte[] getC();
  
  public abstract byte[] getEP();
  
  public abstract byte[] getEQ();
  
  public abstract byte[] getP();
  
  public abstract byte[] getQ();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\KeyPairGenRSA.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */