/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KnownHosts
/*     */   implements HostKeyRepository
/*     */ {
/*     */   private static final String _known_hosts = "known_hosts";
/*  44 */   private JSch jsch = null;
/*  45 */   private String known_hosts = null;
/*  46 */   private Vector pool = null;
/*     */   
/*  48 */   private MAC hmacsha1 = null;
/*     */   
/*     */   KnownHosts(JSch jsch)
/*     */   {
/*  52 */     this.jsch = jsch;
/*  53 */     this.pool = new Vector();
/*     */   }
/*     */   
/*     */   void setKnownHosts(String foo) throws JSchException {
/*     */     try {
/*  58 */       this.known_hosts = foo;
/*  59 */       FileInputStream fis = new FileInputStream(Util.checkTilde(foo));
/*  60 */       setKnownHosts(fis);
/*     */     }
/*     */     catch (FileNotFoundException e) {}
/*     */   }
/*     */   
/*     */   void setKnownHosts(InputStream foo) throws JSchException {
/*  66 */     this.pool.removeAllElements();
/*  67 */     StringBuffer sb = new StringBuffer();
/*     */     
/*     */ 
/*  70 */     boolean error = false;
/*     */     try {
/*  72 */       InputStream fis = foo;
/*     */       
/*  74 */       String key = null;
/*     */       
/*  76 */       byte[] buf = new byte['Ѐ'];
/*  77 */       int bufl = 0;
/*     */       for (;;)
/*     */       {
/*  80 */         bufl = 0;
/*     */         for (;;) {
/*  82 */           j = fis.read();
/*  83 */           if (j == -1) {
/*  84 */             if (bufl != 0) break;
/*     */             break label836;
/*     */           }
/*  87 */           if (j != 13) {
/*  88 */             if (j == 10) break;
/*  89 */             if (buf.length <= bufl) {
/*  90 */               if (bufl > 10240) break;
/*  91 */               byte[] newbuf = new byte[buf.length * 2];
/*  92 */               System.arraycopy(buf, 0, newbuf, 0, buf.length);
/*  93 */               buf = newbuf;
/*     */             }
/*  95 */             buf[(bufl++)] = ((byte)j);
/*     */           }
/*     */         }
/*  98 */         int j = 0;
/*  99 */         for (;;) { if (j < bufl) {
/* 100 */             byte i = buf[j];
/* 101 */             if ((i == 32) || (i == 9)) { j++;
/* 102 */             } else if (i == 35) {
/* 103 */               addInvalidLine(Util.byte2str(buf, 0, bufl));
/* 104 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 108 */         if (j >= bufl) {
/* 109 */           addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */         }
/*     */         else
/*     */         {
/* 113 */           sb.setLength(0);
/* 114 */           while (j < bufl) {
/* 115 */             byte i = buf[(j++)];
/* 116 */             if ((i == 32) || (i == 9)) break;
/* 117 */             sb.append((char)i);
/*     */           }
/* 119 */           String host = sb.toString();
/* 120 */           if ((j >= bufl) || (host.length() == 0)) {
/* 121 */             addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */           }
/*     */           else
/*     */           {
/* 125 */             for (; j < bufl; 
/*     */                 
/* 127 */                 j++)
/*     */             {
/* 126 */               byte i = buf[j];
/* 127 */               if ((i != 32) && (i != 9)) {
/*     */                 break;
/*     */               }
/*     */             }
/* 131 */             String marker = "";
/* 132 */             if (host.charAt(0) == '@') {
/* 133 */               marker = host;
/*     */               
/* 135 */               sb.setLength(0);
/* 136 */               while (j < bufl) {
/* 137 */                 byte i = buf[(j++)];
/* 138 */                 if ((i == 32) || (i == 9)) break;
/* 139 */                 sb.append((char)i);
/*     */               }
/* 141 */               host = sb.toString();
/* 142 */               if ((j >= bufl) || (host.length() == 0)) {
/* 143 */                 addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */               } else {
/* 147 */                 for (; 
/*     */                     
/* 147 */                     j < bufl; 
/*     */                     
/* 149 */                     j++)
/*     */                 {
/* 148 */                   byte i = buf[j];
/* 149 */                   if ((i != 32) && (i != 9))
/*     */                     break;
/*     */                 }
/*     */               }
/*     */             } else {
/* 154 */               sb.setLength(0);
/* 155 */               int type = -1;
/* 156 */               while (j < bufl) {
/* 157 */                 byte i = buf[(j++)];
/* 158 */                 if ((i == 32) || (i == 9)) break;
/* 159 */                 sb.append((char)i);
/*     */               }
/* 161 */               if (sb.toString().equals("ssh-dss")) { type = 1;
/* 162 */               } else if (sb.toString().equals("ssh-rsa")) type = 2; else
/* 163 */                 j = bufl;
/* 164 */               if (j >= bufl) {
/* 165 */                 addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */               }
/*     */               else
/*     */               {
/* 169 */                 for (; j < bufl; 
/*     */                     
/* 171 */                     j++)
/*     */                 {
/* 170 */                   byte i = buf[j];
/* 171 */                   if ((i != 32) && (i != 9)) {
/*     */                     break;
/*     */                   }
/*     */                 }
/* 175 */                 sb.setLength(0);
/* 176 */                 while (j < bufl) {
/* 177 */                   byte i = buf[(j++)];
/* 178 */                   if (i != 13) {
/* 179 */                     if ((i == 10) || 
/* 180 */                       (i == 32) || (i == 9)) break;
/* 181 */                     sb.append((char)i);
/*     */                   } }
/* 183 */                 key = sb.toString();
/* 184 */                 if (key.length() == 0) {
/* 185 */                   addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */                 }
/*     */                 else
/*     */                 {
/* 189 */                   for (; j < bufl; 
/*     */                       
/* 191 */                       j++)
/*     */                   {
/* 190 */                     byte i = buf[j];
/* 191 */                     if ((i != 32) && (i != 9)) {
/*     */                       break;
/*     */                     }
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 205 */                   String comment = null;
/* 206 */                   if (j < bufl) {
/* 207 */                     sb.setLength(0);
/* 208 */                     while (j < bufl) {
/* 209 */                       byte i = buf[(j++)];
/* 210 */                       if (i != 13) {
/* 211 */                         if (i == 10) break;
/* 212 */                         sb.append((char)i);
/*     */                       } }
/* 214 */                     comment = sb.toString();
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/* 220 */                   HostKey hk = null;
/* 221 */                   hk = new HashedHostKey(marker, host, type, Util.fromBase64(Util.str2byte(key), 0, key.length()), comment);
/*     */                   
/*     */ 
/* 224 */                   this.pool.addElement(hk); } } } } } }
/*     */       label836:
/* 226 */       fis.close();
/* 227 */       if (error) {
/* 228 */         throw new JSchException("KnownHosts: invalid format");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 232 */       if ((e instanceof JSchException))
/* 233 */         throw ((JSchException)e);
/* 234 */       if ((e instanceof Throwable))
/* 235 */         throw new JSchException(e.toString(), e);
/* 236 */       throw new JSchException(e.toString());
/*     */     }
/*     */   }
/*     */   
/* 240 */   private void addInvalidLine(String line) throws JSchException { HostKey hk = new HostKey(line, 3, null);
/* 241 */     this.pool.addElement(hk); }
/*     */   
/* 243 */   String getKnownHostsFile() { return this.known_hosts; }
/* 244 */   public String getKnownHostsRepositoryID() { return this.known_hosts; }
/*     */   
/*     */   public int check(String host, byte[] key) {
/* 247 */     int result = 1;
/* 248 */     if (host == null) {
/* 249 */       return result;
/*     */     }
/*     */     
/* 252 */     int type = getType(key);
/*     */     
/*     */ 
/* 255 */     synchronized (this.pool) {
/* 256 */       for (int i = 0; i < this.pool.size(); i++) {
/* 257 */         HostKey hk = (HostKey)this.pool.elementAt(i);
/* 258 */         if ((hk.isMatched(host)) && (hk.type == type)) {
/* 259 */           if (Util.array_equals(hk.key, key)) {
/* 260 */             return 0;
/*     */           }
/*     */           
/* 263 */           result = 2;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 269 */     if ((result == 1) && (host.startsWith("[")) && (host.indexOf("]:") > 1))
/*     */     {
/*     */ 
/*     */ 
/* 273 */       return check(host.substring(1, host.indexOf("]:")), key);
/*     */     }
/*     */     
/* 276 */     return result;
/*     */   }
/*     */   
/*     */   public void add(HostKey hostkey, UserInfo userinfo) {
/* 280 */     int type = hostkey.type;
/* 281 */     String host = hostkey.getHost();
/* 282 */     byte[] key = hostkey.key;
/*     */     
/* 284 */     HostKey hk = null;
/* 285 */     synchronized (this.pool) {
/* 286 */       for (int i = 0; i < this.pool.size(); i++) {
/* 287 */         hk = (HostKey)this.pool.elementAt(i);
/* 288 */         if ((!hk.isMatched(host)) || (hk.type != type)) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 304 */     hk = hostkey;
/*     */     
/* 306 */     this.pool.addElement(hk);
/*     */     
/* 308 */     String bar = getKnownHostsRepositoryID();
/* 309 */     if (bar != null) {
/* 310 */       boolean foo = true;
/* 311 */       File goo = new File(Util.checkTilde(bar));
/* 312 */       if (!goo.exists()) {
/* 313 */         foo = false;
/* 314 */         if (userinfo != null) {
/* 315 */           foo = userinfo.promptYesNo(bar + " does not exist.\n" + "Are you sure you want to create it?");
/*     */           
/*     */ 
/* 318 */           goo = goo.getParentFile();
/* 319 */           if ((foo) && (goo != null) && (!goo.exists())) {
/* 320 */             foo = userinfo.promptYesNo("The parent directory " + goo + " does not exist.\n" + "Are you sure you want to create it?");
/*     */             
/*     */ 
/* 323 */             if (foo) {
/* 324 */               if (!goo.mkdirs()) {
/* 325 */                 userinfo.showMessage(goo + " has not been created.");
/* 326 */                 foo = false;
/*     */               }
/*     */               else {
/* 329 */                 userinfo.showMessage(goo + " has been succesfully created.\nPlease check its access permission.");
/*     */               }
/*     */             }
/*     */           }
/* 333 */           if (goo == null) foo = false;
/*     */         }
/*     */       }
/* 336 */       if (foo) {
/*     */         try {
/* 338 */           sync(bar);
/*     */         } catch (Exception e) {
/* 340 */           System.err.println("sync known_hosts: " + e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 346 */   public HostKey[] getHostKey() { return getHostKey(null, (String)null); }
/*     */   
/*     */   public HostKey[] getHostKey(String host, String type) {
/* 349 */     synchronized (this.pool) {
/* 350 */       int count = 0;
/* 351 */       for (int i = 0; i < this.pool.size(); i++) {
/* 352 */         HostKey hk = (HostKey)this.pool.elementAt(i);
/* 353 */         if ((hk.type != 3) && (
/* 354 */           (host == null) || ((hk.isMatched(host)) && ((type == null) || (hk.getType().equals(type))))))
/*     */         {
/*     */ 
/* 357 */           count++;
/*     */         }
/*     */       }
/* 360 */       if (count == 0) return null;
/* 361 */       HostKey[] foo = new HostKey[count];
/* 362 */       int j = 0;
/* 363 */       for (int i = 0; i < this.pool.size(); i++) {
/* 364 */         HostKey hk = (HostKey)this.pool.elementAt(i);
/* 365 */         if ((hk.type != 3) && (
/* 366 */           (host == null) || ((hk.isMatched(host)) && ((type == null) || (hk.getType().equals(type))))))
/*     */         {
/*     */ 
/* 369 */           foo[(j++)] = hk;
/*     */         }
/*     */       }
/* 372 */       return foo;
/*     */     }
/*     */   }
/*     */   
/* 376 */   public void remove(String host, String type) { remove(host, type, null); }
/*     */   
/*     */   public void remove(String host, String type, byte[] key) {
/* 379 */     boolean sync = false;
/* 380 */     synchronized (this.pool) {
/* 381 */       for (int i = 0; i < this.pool.size(); i++) {
/* 382 */         HostKey hk = (HostKey)this.pool.elementAt(i);
/* 383 */         if ((host == null) || ((hk.isMatched(host)) && ((type == null) || ((hk.getType().equals(type)) && ((key == null) || (Util.array_equals(key, hk.key)))))))
/*     */         {
/*     */ 
/*     */ 
/* 387 */           String hosts = hk.getHost();
/* 388 */           if ((hosts.equals(host)) || (((hk instanceof HashedHostKey)) && (((HashedHostKey)hk).isHashed())))
/*     */           {
/*     */ 
/* 391 */             this.pool.removeElement(hk);
/*     */           }
/*     */           else {
/* 394 */             hk.host = deleteSubString(hosts, host);
/*     */           }
/* 396 */           sync = true;
/*     */         }
/*     */       }
/*     */     }
/* 400 */     if (sync)
/* 401 */       try { sync();
/*     */       } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   protected void sync() throws IOException {
/* 406 */     if (this.known_hosts != null)
/* 407 */       sync(this.known_hosts);
/*     */   }
/*     */   
/* 410 */   protected synchronized void sync(String foo) throws IOException { if (foo == null) return;
/* 411 */     FileOutputStream fos = new FileOutputStream(Util.checkTilde(foo));
/* 412 */     dump(fos);
/* 413 */     fos.close();
/*     */   }
/*     */   
/* 416 */   private static final byte[] space = { 32 };
/* 417 */   private static final byte[] cr = Util.str2byte("\n");
/*     */   
/*     */   void dump(OutputStream out) throws IOException {
/*     */     try {
/* 421 */       synchronized (this.pool) {
/* 422 */         for (int i = 0; i < this.pool.size(); i++) {
/* 423 */           HostKey hk = (HostKey)this.pool.elementAt(i);
/*     */           
/* 425 */           String marker = hk.getMarker();
/* 426 */           String host = hk.getHost();
/* 427 */           String type = hk.getType();
/* 428 */           String comment = hk.getComment();
/* 429 */           if (type.equals("UNKNOWN")) {
/* 430 */             out.write(Util.str2byte(host));
/* 431 */             out.write(cr);
/*     */           }
/*     */           else {
/* 434 */             if (marker.length() != 0) {
/* 435 */               out.write(Util.str2byte(marker));
/* 436 */               out.write(space);
/*     */             }
/* 438 */             out.write(Util.str2byte(host));
/* 439 */             out.write(space);
/* 440 */             out.write(Util.str2byte(type));
/* 441 */             out.write(space);
/* 442 */             out.write(Util.str2byte(hk.getKey()));
/* 443 */             if (comment != null) {
/* 444 */               out.write(space);
/* 445 */               out.write(Util.str2byte(comment));
/*     */             }
/* 447 */             out.write(cr);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 452 */       System.err.println(e);
/*     */     }
/*     */   }
/*     */   
/* 456 */   private int getType(byte[] key) { if (key[8] == 100) return 1;
/* 457 */     if (key[8] == 114) return 2;
/* 458 */     return 3;
/*     */   }
/*     */   
/* 461 */   private String deleteSubString(String hosts, String host) { int i = 0;
/* 462 */     int hostlen = host.length();
/* 463 */     int hostslen = hosts.length();
/*     */     
/* 465 */     while (i < hostslen) {
/* 466 */       int j = hosts.indexOf(',', i);
/* 467 */       if (j != -1)
/* 468 */         if (!host.equals(hosts.substring(i, j))) {
/* 469 */           i = j + 1;
/*     */         }
/*     */         else
/* 472 */           return hosts.substring(0, i) + hosts.substring(j + 1);
/*     */     }
/* 474 */     if ((hosts.endsWith(host)) && (hostslen - i == hostlen)) {
/* 475 */       return hosts.substring(0, hostlen == hostslen ? 0 : hostslen - hostlen - 1);
/*     */     }
/* 477 */     return hosts;
/*     */   }
/*     */   
/*     */   private synchronized MAC getHMACSHA1() {
/* 481 */     if (this.hmacsha1 == null) {
/*     */       try {
/* 483 */         Class c = Class.forName(JSch.getConfig("hmac-sha1"));
/* 484 */         this.hmacsha1 = ((MAC)c.newInstance());
/*     */       }
/*     */       catch (Exception e) {
/* 487 */         System.err.println("hmacsha1: " + e);
/*     */       }
/*     */     }
/* 490 */     return this.hmacsha1;
/*     */   }
/*     */   
/*     */   HostKey createHashedHostKey(String host, byte[] key) throws JSchException {
/* 494 */     HashedHostKey hhk = new HashedHostKey(host, key);
/* 495 */     hhk.hash();
/* 496 */     return hhk;
/*     */   }
/*     */   
/*     */   class HashedHostKey extends HostKey {
/*     */     private static final String HASH_MAGIC = "|1|";
/*     */     private static final String HASH_DELIM = "|";
/* 502 */     private boolean hashed = false;
/* 503 */     byte[] salt = null;
/* 504 */     byte[] hash = null;
/*     */     
/*     */     HashedHostKey(String host, byte[] key) throws JSchException
/*     */     {
/* 508 */       this(host, 0, key);
/*     */     }
/*     */     
/* 511 */     HashedHostKey(String host, int type, byte[] key) throws JSchException { this("", host, type, key, null); }
/*     */     
/*     */     HashedHostKey(String marker, String host, int type, byte[] key, String comment) throws JSchException {
/* 514 */       super(host, type, key, comment);
/* 515 */       String data; if ((this.host.startsWith("|1|")) && (this.host.substring("|1|".length()).indexOf("|") > 0))
/*     */       {
/* 517 */         data = this.host.substring("|1|".length());
/* 518 */         String _salt = data.substring(0, data.indexOf("|"));
/* 519 */         String _hash = data.substring(data.indexOf("|") + 1);
/* 520 */         this.salt = Util.fromBase64(Util.str2byte(_salt), 0, _salt.length());
/* 521 */         this.hash = Util.fromBase64(Util.str2byte(_hash), 0, _hash.length());
/* 522 */         if ((this.salt.length != 20) || (this.hash.length != 20))
/*     */         {
/* 524 */           this.salt = null;
/* 525 */           this.hash = null;
/* 526 */           return;
/*     */         }
/* 528 */         this.hashed = true;
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isMatched(String _host) {
/* 533 */       if (!this.hashed) {
/* 534 */         return super.isMatched(_host);
/*     */       }
/* 536 */       MAC macsha1 = KnownHosts.this.getHMACSHA1();
/*     */       try {
/* 538 */         synchronized (macsha1) {
/* 539 */           macsha1.init(this.salt);
/* 540 */           byte[] foo = Util.str2byte(_host);
/* 541 */           macsha1.update(foo, 0, foo.length);
/* 542 */           byte[] bar = new byte[macsha1.getBlockSize()];
/* 543 */           macsha1.doFinal(bar, 0);
/* 544 */           return Util.array_equals(this.hash, bar);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 550 */         return false;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 548 */         System.out.println(e);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isHashed()
/*     */     {
/* 554 */       return this.hashed;
/*     */     }
/*     */     
/*     */     void hash() {
/* 558 */       if (this.hashed)
/* 559 */         return;
/* 560 */       MAC macsha1 = KnownHosts.this.getHMACSHA1();
/* 561 */       if (this.salt == null) {
/* 562 */         Random random = Session.random;
/* 563 */         synchronized (random) {
/* 564 */           this.salt = new byte[macsha1.getBlockSize()];
/* 565 */           random.fill(this.salt, 0, this.salt.length);
/*     */         }
/*     */       }
/*     */       try {
/* 569 */         synchronized (macsha1) {
/* 570 */           macsha1.init(this.salt);
/* 571 */           byte[] foo = Util.str2byte(this.host);
/* 572 */           macsha1.update(foo, 0, foo.length);
/* 573 */           this.hash = new byte[macsha1.getBlockSize()];
/* 574 */           macsha1.doFinal(this.hash, 0);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */       
/* 579 */       this.host = ("|1|" + Util.byte2str(Util.toBase64(this.salt, 0, this.salt.length)) + "|" + Util.byte2str(Util.toBase64(this.hash, 0, this.hash.length)));
/*     */       
/* 581 */       this.hashed = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\KnownHosts.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */