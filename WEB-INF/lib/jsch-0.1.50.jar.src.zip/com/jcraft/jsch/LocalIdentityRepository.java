/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LocalIdentityRepository
/*     */   implements IdentityRepository
/*     */ {
/*     */   private static final String name = "Local Identity Repository";
/*  37 */   private Vector identities = new Vector();
/*     */   private JSch jsch;
/*     */   
/*     */   LocalIdentityRepository(JSch jsch) {
/*  41 */     this.jsch = jsch;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  45 */     return "Local Identity Repository";
/*     */   }
/*     */   
/*     */   public int getStatus() {
/*  49 */     return 2;
/*     */   }
/*     */   
/*     */   public synchronized Vector getIdentities() {
/*  53 */     Vector v = new Vector();
/*  54 */     for (int i = 0; i < this.identities.size(); i++) {
/*  55 */       v.addElement(this.identities.elementAt(i));
/*     */     }
/*  57 */     return v;
/*     */   }
/*     */   
/*     */   public synchronized void add(Identity identity) {
/*  61 */     if (!this.identities.contains(identity)) {
/*  62 */       this.identities.addElement(identity);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized boolean add(byte[] identity) {
/*     */     try {
/*  68 */       Identity _identity = IdentityFile.newInstance("from remote:", identity, null, this.jsch);
/*     */       
/*  70 */       this.identities.addElement(_identity);
/*  71 */       return true;
/*     */     }
/*     */     catch (JSchException e) {}
/*  74 */     return false;
/*     */   }
/*     */   
/*     */   synchronized void remove(Identity identity)
/*     */   {
/*  79 */     this.identities.removeElement(identity);
/*     */   }
/*     */   
/*     */   public synchronized boolean remove(byte[] blob) {
/*  83 */     if (blob == null) return false;
/*  84 */     for (int i = 0; i < this.identities.size(); i++) {
/*  85 */       Identity _identity = (Identity)this.identities.elementAt(i);
/*  86 */       byte[] _blob = _identity.getPublicKeyBlob();
/*  87 */       if ((_blob != null) && (Util.array_equals(blob, _blob)))
/*     */       {
/*  89 */         this.identities.removeElement(_identity);
/*  90 */         _identity.clear();
/*  91 */         return true;
/*     */       } }
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public synchronized void removeAll() {
/*  97 */     for (int i = 0; i < this.identities.size(); i++) {
/*  98 */       Identity identity = (Identity)this.identities.elementAt(i);
/*  99 */       identity.clear();
/*     */     }
/* 101 */     this.identities.removeAllElements();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\LocalIdentityRepository.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */