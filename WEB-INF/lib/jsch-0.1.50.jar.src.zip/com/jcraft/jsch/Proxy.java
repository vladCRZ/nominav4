package com.jcraft.jsch;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public abstract interface Proxy
{
  public abstract void connect(SocketFactory paramSocketFactory, String paramString, int paramInt1, int paramInt2)
    throws Exception;
  
  public abstract InputStream getInputStream();
  
  public abstract OutputStream getOutputStream();
  
  public abstract Socket getSocket();
  
  public abstract void close();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\Proxy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */