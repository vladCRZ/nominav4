/*      */ package com.jcraft.jsch;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.Socket;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Session
/*      */   implements Runnable
/*      */ {
/*      */   static final int SSH_MSG_DISCONNECT = 1;
/*      */   static final int SSH_MSG_IGNORE = 2;
/*      */   static final int SSH_MSG_UNIMPLEMENTED = 3;
/*      */   static final int SSH_MSG_DEBUG = 4;
/*      */   static final int SSH_MSG_SERVICE_REQUEST = 5;
/*      */   static final int SSH_MSG_SERVICE_ACCEPT = 6;
/*      */   static final int SSH_MSG_KEXINIT = 20;
/*      */   static final int SSH_MSG_NEWKEYS = 21;
/*      */   static final int SSH_MSG_KEXDH_INIT = 30;
/*      */   static final int SSH_MSG_KEXDH_REPLY = 31;
/*      */   static final int SSH_MSG_KEX_DH_GEX_GROUP = 31;
/*      */   static final int SSH_MSG_KEX_DH_GEX_INIT = 32;
/*      */   static final int SSH_MSG_KEX_DH_GEX_REPLY = 33;
/*      */   static final int SSH_MSG_KEX_DH_GEX_REQUEST = 34;
/*      */   static final int SSH_MSG_GLOBAL_REQUEST = 80;
/*      */   static final int SSH_MSG_REQUEST_SUCCESS = 81;
/*      */   static final int SSH_MSG_REQUEST_FAILURE = 82;
/*      */   static final int SSH_MSG_CHANNEL_OPEN = 90;
/*      */   static final int SSH_MSG_CHANNEL_OPEN_CONFIRMATION = 91;
/*      */   static final int SSH_MSG_CHANNEL_OPEN_FAILURE = 92;
/*      */   static final int SSH_MSG_CHANNEL_WINDOW_ADJUST = 93;
/*      */   static final int SSH_MSG_CHANNEL_DATA = 94;
/*      */   static final int SSH_MSG_CHANNEL_EXTENDED_DATA = 95;
/*      */   static final int SSH_MSG_CHANNEL_EOF = 96;
/*      */   static final int SSH_MSG_CHANNEL_CLOSE = 97;
/*      */   static final int SSH_MSG_CHANNEL_REQUEST = 98;
/*      */   static final int SSH_MSG_CHANNEL_SUCCESS = 99;
/*      */   static final int SSH_MSG_CHANNEL_FAILURE = 100;
/*      */   private static final int PACKET_MAX_SIZE = 262144;
/*      */   private byte[] V_S;
/*   71 */   private byte[] V_C = Util.str2byte("SSH-2.0-JSCH-0.1.50");
/*      */   
/*      */   private byte[] I_C;
/*      */   
/*      */   private byte[] I_S;
/*      */   
/*      */   private byte[] K_S;
/*      */   
/*      */   private byte[] session_id;
/*      */   private byte[] IVc2s;
/*      */   private byte[] IVs2c;
/*      */   private byte[] Ec2s;
/*      */   private byte[] Es2c;
/*      */   private byte[] MACc2s;
/*      */   private byte[] MACs2c;
/*   86 */   private int seqi = 0;
/*   87 */   private int seqo = 0;
/*      */   
/*   89 */   String[] guess = null;
/*      */   
/*      */   private Cipher s2ccipher;
/*      */   
/*      */   private Cipher c2scipher;
/*      */   
/*      */   private MAC s2cmac;
/*      */   private MAC c2smac;
/*      */   private byte[] s2cmac_result1;
/*      */   private byte[] s2cmac_result2;
/*      */   private Compression deflater;
/*      */   private Compression inflater;
/*      */   private IO io;
/*      */   private Socket socket;
/*  103 */   private int timeout = 0;
/*      */   
/*  105 */   private volatile boolean isConnected = false;
/*      */   
/*  107 */   private boolean isAuthed = false;
/*      */   
/*  109 */   private Thread connectThread = null;
/*  110 */   private Object lock = new Object();
/*      */   
/*  112 */   boolean x11_forwarding = false;
/*  113 */   boolean agent_forwarding = false;
/*      */   
/*  115 */   InputStream in = null;
/*  116 */   OutputStream out = null;
/*      */   
/*      */   static Random random;
/*      */   
/*      */   Buffer buf;
/*      */   
/*      */   Packet packet;
/*  123 */   SocketFactory socket_factory = null;
/*      */   
/*      */ 
/*      */   static final int buffer_margin = 84;
/*      */   
/*      */ 
/*  129 */   private Hashtable config = null;
/*      */   
/*  131 */   private Proxy proxy = null;
/*      */   
/*      */   private UserInfo userinfo;
/*  134 */   private String hostKeyAlias = null;
/*  135 */   private int serverAliveInterval = 0;
/*  136 */   private int serverAliveCountMax = 1;
/*      */   
/*  138 */   private IdentityRepository identityRepository = null;
/*  139 */   private HostKeyRepository hostkeyRepository = null;
/*      */   
/*  141 */   protected boolean daemon_thread = false;
/*      */   
/*  143 */   private long kex_start_time = 0L;
/*      */   
/*  145 */   int max_auth_tries = 6;
/*  146 */   int auth_failures = 0;
/*      */   
/*  148 */   String host = "127.0.0.1";
/*  149 */   String org_host = "127.0.0.1";
/*  150 */   int port = 22;
/*      */   
/*  152 */   String username = null;
/*  153 */   byte[] password = null;
/*      */   JSch jsch;
/*      */   
/*      */   Session(JSch jsch, String username, String host, int port)
/*      */     throws JSchException
/*      */   {
/*  159 */     this.jsch = jsch;
/*  160 */     this.buf = new Buffer();
/*  161 */     this.packet = new Packet(this.buf);
/*  162 */     this.username = username;
/*  163 */     this.org_host = (this.host = host);
/*  164 */     this.port = port;
/*      */     
/*  166 */     applyConfig();
/*      */     
/*  168 */     if (this.username == null) {
/*      */       try {
/*  170 */         this.username = ((String)System.getProperties().get("user.name"));
/*      */       }
/*      */       catch (SecurityException e) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  177 */     if (this.username == null) {
/*  178 */       throw new JSchException("username is not given.");
/*      */     }
/*      */   }
/*      */   
/*      */   public void connect() throws JSchException {
/*  183 */     connect(this.timeout);
/*      */   }
/*      */   
/*      */   public void connect(int connectTimeout) throws JSchException {
/*  187 */     if (this.isConnected) {
/*  188 */       throw new JSchException("session is already connected");
/*      */     }
/*      */     
/*  191 */     this.io = new IO();
/*  192 */     if (random == null) {
/*      */       try {
/*  194 */         Class c = Class.forName(getConfig("random"));
/*  195 */         random = (Random)c.newInstance();
/*      */       }
/*      */       catch (Exception e) {
/*  198 */         throw new JSchException(e.toString(), e);
/*      */       }
/*      */     }
/*  201 */     Packet.setRandom(random);
/*      */     
/*  203 */     if (JSch.getLogger().isEnabled(1)) {
/*  204 */       JSch.getLogger().log(1, "Connecting to " + this.host + " port " + this.port);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  211 */       if (this.proxy == null) { OutputStream out;
/*      */         InputStream in;
/*      */         OutputStream out;
/*  214 */         if (this.socket_factory == null) {
/*  215 */           this.socket = Util.createSocket(this.host, this.port, connectTimeout);
/*  216 */           InputStream in = this.socket.getInputStream();
/*  217 */           out = this.socket.getOutputStream();
/*      */         }
/*      */         else {
/*  220 */           this.socket = this.socket_factory.createSocket(this.host, this.port);
/*  221 */           in = this.socket_factory.getInputStream(this.socket);
/*  222 */           out = this.socket_factory.getOutputStream(this.socket);
/*      */         }
/*      */         
/*  225 */         this.socket.setTcpNoDelay(true);
/*  226 */         this.io.setInputStream(in);
/*  227 */         this.io.setOutputStream(out);
/*      */       }
/*      */       else {
/*  230 */         synchronized (this.proxy) {
/*  231 */           this.proxy.connect(this.socket_factory, this.host, this.port, connectTimeout);
/*  232 */           this.io.setInputStream(this.proxy.getInputStream());
/*  233 */           this.io.setOutputStream(this.proxy.getOutputStream());
/*  234 */           this.socket = this.proxy.getSocket();
/*      */         }
/*      */       }
/*      */       
/*  238 */       if ((connectTimeout > 0) && (this.socket != null)) {
/*  239 */         this.socket.setSoTimeout(connectTimeout);
/*      */       }
/*      */       
/*  242 */       this.isConnected = true;
/*      */       
/*  244 */       if (JSch.getLogger().isEnabled(1)) {
/*  245 */         JSch.getLogger().log(1, "Connection established");
/*      */       }
/*      */       
/*      */ 
/*  249 */       this.jsch.addSession(this);
/*      */       
/*      */ 
/*      */ 
/*  253 */       byte[] foo = new byte[this.V_C.length + 1];
/*  254 */       System.arraycopy(this.V_C, 0, foo, 0, this.V_C.length);
/*  255 */       foo[(foo.length - 1)] = 10;
/*  256 */       this.io.put(foo, 0, foo.length);
/*      */       int i;
/*      */       do
/*      */       {
/*  260 */         i = 0;
/*  261 */         int j = 0;
/*  262 */         while (i < this.buf.buffer.length) {
/*  263 */           j = this.io.getByte();
/*  264 */           if (j >= 0) {
/*  265 */             this.buf.buffer[i] = ((byte)j);i++;
/*  266 */             if (j == 10) break;
/*      */           } }
/*  268 */         if (j < 0) {
/*  269 */           throw new JSchException("connection is closed by foreign host");
/*      */         }
/*      */         
/*  272 */         if (this.buf.buffer[(i - 1)] == 10) {
/*  273 */           i--;
/*  274 */           if ((i > 0) && (this.buf.buffer[(i - 1)] == 13)) {
/*  275 */             i--;
/*      */           }
/*      */           
/*      */         }
/*  279 */       } while ((i <= 3) || ((i != this.buf.buffer.length) && ((this.buf.buffer[0] != 83) || (this.buf.buffer[1] != 83) || (this.buf.buffer[2] != 72) || (this.buf.buffer[3] != 45))));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  288 */       if ((i == this.buf.buffer.length) || (i < 7) || ((this.buf.buffer[4] == 49) && (this.buf.buffer[6] != 57)))
/*      */       {
/*      */ 
/*      */ 
/*  292 */         throw new JSchException("invalid server's version string");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  297 */       this.V_S = new byte[i];System.arraycopy(this.buf.buffer, 0, this.V_S, 0, i);
/*      */       
/*      */ 
/*  300 */       if (JSch.getLogger().isEnabled(1)) {
/*  301 */         JSch.getLogger().log(1, "Remote version string: " + Util.byte2str(this.V_S));
/*      */         
/*  303 */         JSch.getLogger().log(1, "Local version string: " + Util.byte2str(this.V_C));
/*      */       }
/*      */       
/*      */ 
/*  307 */       send_kexinit();
/*      */       
/*  309 */       this.buf = read(this.buf);
/*  310 */       if (this.buf.getCommand() != 20) {
/*  311 */         this.in_kex = false;
/*  312 */         throw new JSchException("invalid protocol: " + this.buf.getCommand());
/*      */       }
/*      */       
/*  315 */       if (JSch.getLogger().isEnabled(1)) {
/*  316 */         JSch.getLogger().log(1, "SSH_MSG_KEXINIT received");
/*      */       }
/*      */       
/*      */ 
/*  320 */       KeyExchange kex = receive_kexinit(this.buf);
/*      */       for (;;)
/*      */       {
/*  323 */         this.buf = read(this.buf);
/*  324 */         if (kex.getState() == this.buf.getCommand()) {
/*  325 */           this.kex_start_time = System.currentTimeMillis();
/*  326 */           boolean result = kex.next(this.buf);
/*  327 */           if (!result)
/*      */           {
/*  329 */             this.in_kex = false;
/*  330 */             throw new JSchException("verify: " + result);
/*      */           }
/*      */         }
/*      */         else {
/*  334 */           this.in_kex = false;
/*  335 */           throw new JSchException("invalid protocol(kex): " + this.buf.getCommand());
/*      */         }
/*  337 */         if (kex.getState() == 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       try {
/*  342 */         checkHost(this.host, this.port, kex);
/*      */       } catch (JSchException ee) {
/*  344 */         this.in_kex = false;
/*  345 */         throw ee;
/*      */       }
/*      */       
/*  348 */       send_newkeys();
/*      */       
/*      */ 
/*  351 */       this.buf = read(this.buf);
/*      */       
/*  353 */       if (this.buf.getCommand() == 21)
/*      */       {
/*  355 */         if (JSch.getLogger().isEnabled(1)) {
/*  356 */           JSch.getLogger().log(1, "SSH_MSG_NEWKEYS received");
/*      */         }
/*      */         
/*      */ 
/*  360 */         receive_newkeys(this.buf, kex);
/*      */       }
/*      */       else {
/*  363 */         this.in_kex = false;
/*  364 */         throw new JSchException("invalid protocol(newkyes): " + this.buf.getCommand());
/*      */       }
/*      */       try
/*      */       {
/*  368 */         String s = getConfig("MaxAuthTries");
/*  369 */         if (s != null) {
/*  370 */           this.max_auth_tries = Integer.parseInt(s);
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException e) {
/*  374 */         throw new JSchException("MaxAuthTries: " + getConfig("MaxAuthTries"), e);
/*      */       }
/*      */       
/*  377 */       boolean auth = false;
/*  378 */       boolean auth_cancel = false;
/*      */       
/*  380 */       UserAuth ua = null;
/*      */       try {
/*  382 */         Class c = Class.forName(getConfig("userauth.none"));
/*  383 */         ua = (UserAuth)c.newInstance();
/*      */       }
/*      */       catch (Exception e) {
/*  386 */         throw new JSchException(e.toString(), e);
/*      */       }
/*      */       
/*  389 */       auth = ua.start(this);
/*      */       
/*  391 */       String cmethods = getConfig("PreferredAuthentications");
/*      */       
/*  393 */       String[] cmethoda = Util.split(cmethods, ",");
/*      */       
/*  395 */       String smethods = null;
/*  396 */       if (!auth) {
/*  397 */         smethods = ((UserAuthNone)ua).getMethods();
/*  398 */         if (smethods != null) {
/*  399 */           smethods = smethods.toLowerCase();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  404 */           smethods = cmethods;
/*      */         }
/*      */       }
/*      */       
/*  408 */       String[] smethoda = Util.split(smethods, ",");
/*      */       
/*  410 */       int methodi = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  416 */       while ((!auth) && (cmethoda != null) && (methodi < cmethoda.length))
/*      */       {
/*  418 */         String method = cmethoda[(methodi++)];
/*  419 */         boolean acceptable = false;
/*  420 */         for (int k = 0; k < smethoda.length; k++) {
/*  421 */           if (smethoda[k].equals(method)) {
/*  422 */             acceptable = true;
/*  423 */             break;
/*      */           }
/*      */         }
/*  426 */         if (acceptable)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  432 */           if (JSch.getLogger().isEnabled(1)) {
/*  433 */             String str = "Authentications that can continue: ";
/*  434 */             for (int k = methodi - 1; k < cmethoda.length; k++) {
/*  435 */               str = str + cmethoda[k];
/*  436 */               if (k + 1 < cmethoda.length)
/*  437 */                 str = str + ",";
/*      */             }
/*  439 */             JSch.getLogger().log(1, str);
/*      */             
/*  441 */             JSch.getLogger().log(1, "Next authentication method: " + method);
/*      */           }
/*      */           
/*      */ 
/*  445 */           ua = null;
/*      */           try {
/*  447 */             Class c = null;
/*  448 */             if (getConfig("userauth." + method) != null) {
/*  449 */               c = Class.forName(getConfig("userauth." + method));
/*  450 */               ua = (UserAuth)c.newInstance();
/*      */             }
/*      */           }
/*      */           catch (Exception e) {
/*  454 */             if (JSch.getLogger().isEnabled(2)) {
/*  455 */               JSch.getLogger().log(2, "failed to load " + method + " method");
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  460 */           if (ua != null) {
/*  461 */             auth_cancel = false;
/*      */             try {
/*  463 */               auth = ua.start(this);
/*  464 */               if ((auth) && (JSch.getLogger().isEnabled(1)))
/*      */               {
/*  466 */                 JSch.getLogger().log(1, "Authentication succeeded (" + method + ").");
/*      */               }
/*      */             }
/*      */             catch (JSchAuthCancelException ee)
/*      */             {
/*  471 */               auth_cancel = true;
/*      */             }
/*      */             catch (JSchPartialAuthException ee) {
/*  474 */               String tmp = smethods;
/*  475 */               smethods = ee.getMethods();
/*  476 */               smethoda = Util.split(smethods, ",");
/*  477 */               if (!tmp.equals(smethods)) {
/*  478 */                 methodi = 0;
/*      */               }
/*      */               
/*  481 */               auth_cancel = false;
/*      */             }
/*      */             catch (RuntimeException ee)
/*      */             {
/*  485 */               throw ee;
/*      */             }
/*      */             catch (JSchException ee) {
/*  488 */               throw ee;
/*      */             }
/*      */             catch (Exception ee)
/*      */             {
/*  492 */               if (JSch.getLogger().isEnabled(2)) {
/*  493 */                 JSch.getLogger().log(2, "an exception during authentication\n" + ee.toString());
/*      */               }
/*      */               
/*  496 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  503 */       if (!auth) {
/*  504 */         if ((this.auth_failures >= this.max_auth_tries) && 
/*  505 */           (JSch.getLogger().isEnabled(1))) {
/*  506 */           JSch.getLogger().log(1, "Login trials exceeds " + this.max_auth_tries);
/*      */         }
/*      */         
/*      */ 
/*  510 */         if (auth_cancel)
/*  511 */           throw new JSchException("Auth cancel");
/*  512 */         throw new JSchException("Auth fail");
/*      */       }
/*      */       
/*  515 */       if ((this.socket != null) && ((connectTimeout > 0) || (this.timeout > 0))) {
/*  516 */         this.socket.setSoTimeout(this.timeout);
/*      */       }
/*      */       
/*  519 */       this.isAuthed = true;
/*      */       
/*  521 */       synchronized (this.lock) {
/*  522 */         if (this.isConnected) {
/*  523 */           this.connectThread = new Thread(this);
/*  524 */           this.connectThread.setName("Connect thread " + this.host + " session");
/*  525 */           if (this.daemon_thread) {
/*  526 */             this.connectThread.setDaemon(this.daemon_thread);
/*      */           }
/*  528 */           this.connectThread.start();
/*      */           
/*  530 */           requestPortForwarding();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  539 */       this.in_kex = false;
/*  540 */       if (this.isConnected) {
/*      */         try {
/*  542 */           this.packet.reset();
/*  543 */           this.buf.putByte((byte)1);
/*  544 */           this.buf.putInt(3);
/*  545 */           this.buf.putString(Util.str2byte(e.toString()));
/*  546 */           this.buf.putString(Util.str2byte("en"));
/*  547 */           write(this.packet);
/*  548 */           disconnect();
/*      */         }
/*      */         catch (Exception ee) {}
/*      */       }
/*      */       
/*  553 */       this.isConnected = false;
/*      */       
/*  555 */       if ((e instanceof RuntimeException)) throw ((RuntimeException)e);
/*  556 */       if ((e instanceof JSchException)) throw ((JSchException)e);
/*  557 */       throw new JSchException("Session.connect: " + e);
/*      */     }
/*      */     finally {
/*  560 */       Util.bzero(this.password);
/*  561 */       this.password = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private KeyExchange receive_kexinit(Buffer buf) throws Exception {
/*  566 */     int j = buf.getInt();
/*  567 */     if (j != buf.getLength()) {
/*  568 */       buf.getByte();
/*  569 */       this.I_S = new byte[buf.index - 5];
/*      */     }
/*      */     else {
/*  572 */       this.I_S = new byte[j - 1 - buf.getByte()];
/*      */     }
/*  574 */     System.arraycopy(buf.buffer, buf.s, this.I_S, 0, this.I_S.length);
/*      */     
/*  576 */     if (!this.in_kex) {
/*  577 */       send_kexinit();
/*      */     }
/*      */     
/*  580 */     this.guess = KeyExchange.guess(this.I_S, this.I_C);
/*  581 */     if (this.guess == null) {
/*  582 */       throw new JSchException("Algorithm negotiation fail");
/*      */     }
/*      */     
/*  585 */     if ((!this.isAuthed) && ((this.guess[2].equals("none")) || (this.guess[3].equals("none"))))
/*      */     {
/*      */ 
/*  588 */       throw new JSchException("NONE Cipher should not be chosen before authentification is successed.");
/*      */     }
/*      */     
/*  591 */     KeyExchange kex = null;
/*      */     try {
/*  593 */       Class c = Class.forName(getConfig(this.guess[0]));
/*  594 */       kex = (KeyExchange)c.newInstance();
/*      */     }
/*      */     catch (Exception e) {
/*  597 */       throw new JSchException(e.toString(), e);
/*      */     }
/*      */     
/*  600 */     kex.init(this, this.V_S, this.V_C, this.I_S, this.I_C);
/*  601 */     return kex;
/*      */   }
/*      */   
/*  604 */   private boolean in_kex = false;
/*      */   
/*  606 */   public void rekey() throws Exception { send_kexinit(); }
/*      */   
/*      */   private void send_kexinit() throws Exception {
/*  609 */     if (this.in_kex) {
/*  610 */       return;
/*      */     }
/*  612 */     String cipherc2s = getConfig("cipher.c2s");
/*  613 */     String ciphers2c = getConfig("cipher.s2c");
/*      */     
/*  615 */     String[] not_available_ciphers = checkCiphers(getConfig("CheckCiphers"));
/*  616 */     if ((not_available_ciphers != null) && (not_available_ciphers.length > 0)) {
/*  617 */       cipherc2s = Util.diffString(cipherc2s, not_available_ciphers);
/*  618 */       ciphers2c = Util.diffString(ciphers2c, not_available_ciphers);
/*  619 */       if ((cipherc2s == null) || (ciphers2c == null)) {
/*  620 */         throw new JSchException("There are not any available ciphers.");
/*      */       }
/*      */     }
/*      */     
/*  624 */     String kex = getConfig("kex");
/*  625 */     String[] not_available_kexes = checkKexes(getConfig("CheckKexes"));
/*  626 */     if ((not_available_kexes != null) && (not_available_kexes.length > 0)) {
/*  627 */       kex = Util.diffString(kex, not_available_kexes);
/*  628 */       if (kex == null) {
/*  629 */         throw new JSchException("There are not any available kexes.");
/*      */       }
/*      */     }
/*      */     
/*  633 */     this.in_kex = true;
/*  634 */     this.kex_start_time = System.currentTimeMillis();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  648 */     Buffer buf = new Buffer();
/*  649 */     Packet packet = new Packet(buf);
/*  650 */     packet.reset();
/*  651 */     buf.putByte((byte)20);
/*  652 */     synchronized (random) {
/*  653 */       random.fill(buf.buffer, buf.index, 16);buf.skip(16);
/*      */     }
/*  655 */     buf.putString(Util.str2byte(kex));
/*  656 */     buf.putString(Util.str2byte(getConfig("server_host_key")));
/*  657 */     buf.putString(Util.str2byte(cipherc2s));
/*  658 */     buf.putString(Util.str2byte(ciphers2c));
/*  659 */     buf.putString(Util.str2byte(getConfig("mac.c2s")));
/*  660 */     buf.putString(Util.str2byte(getConfig("mac.s2c")));
/*  661 */     buf.putString(Util.str2byte(getConfig("compression.c2s")));
/*  662 */     buf.putString(Util.str2byte(getConfig("compression.s2c")));
/*  663 */     buf.putString(Util.str2byte(getConfig("lang.c2s")));
/*  664 */     buf.putString(Util.str2byte(getConfig("lang.s2c")));
/*  665 */     buf.putByte((byte)0);
/*  666 */     buf.putInt(0);
/*      */     
/*  668 */     buf.setOffSet(5);
/*  669 */     this.I_C = new byte[buf.getLength()];
/*  670 */     buf.getByte(this.I_C);
/*      */     
/*  672 */     write(packet);
/*      */     
/*  674 */     if (JSch.getLogger().isEnabled(1)) {
/*  675 */       JSch.getLogger().log(1, "SSH_MSG_KEXINIT sent");
/*      */     }
/*      */   }
/*      */   
/*      */   private void send_newkeys()
/*      */     throws Exception
/*      */   {
/*  682 */     this.packet.reset();
/*  683 */     this.buf.putByte((byte)21);
/*  684 */     write(this.packet);
/*      */     
/*  686 */     if (JSch.getLogger().isEnabled(1)) {
/*  687 */       JSch.getLogger().log(1, "SSH_MSG_NEWKEYS sent");
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkHost(String chost, int port, KeyExchange kex) throws JSchException
/*      */   {
/*  693 */     String shkc = getConfig("StrictHostKeyChecking");
/*      */     
/*  695 */     if (this.hostKeyAlias != null) {
/*  696 */       chost = this.hostKeyAlias;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  701 */     byte[] K_S = kex.getHostKey();
/*  702 */     String key_type = kex.getKeyType();
/*  703 */     String key_fprint = kex.getFingerPrint();
/*      */     
/*  705 */     if ((this.hostKeyAlias == null) && (port != 22)) {
/*  706 */       chost = "[" + chost + "]:" + port;
/*      */     }
/*      */     
/*  709 */     HostKeyRepository hkr = getHostKeyRepository();
/*      */     
/*  711 */     String hkh = getConfig("HashKnownHosts");
/*  712 */     if ((hkh.equals("yes")) && ((hkr instanceof KnownHosts))) {
/*  713 */       this.hostkey = ((KnownHosts)hkr).createHashedHostKey(chost, K_S);
/*      */     }
/*      */     else {
/*  716 */       this.hostkey = new HostKey(chost, K_S);
/*      */     }
/*      */     
/*  719 */     int i = 0;
/*  720 */     synchronized (hkr) {
/*  721 */       i = hkr.check(chost, K_S);
/*      */     }
/*      */     
/*  724 */     boolean insert = false;
/*  725 */     if (((shkc.equals("ask")) || (shkc.equals("yes"))) && (i == 2))
/*      */     {
/*  727 */       String file = null;
/*  728 */       synchronized (hkr) {
/*  729 */         file = hkr.getKnownHostsRepositoryID();
/*      */       }
/*  731 */       if (file == null) { file = "known_hosts";
/*      */       }
/*  733 */       boolean b = false;
/*      */       
/*  735 */       if (this.userinfo != null) {
/*  736 */         String message = "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!\nIT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!\nSomeone could be eavesdropping on you right now (man-in-the-middle attack)!\nIt is also possible that the " + key_type + " host key has just been changed.\n" + "The fingerprint for the " + key_type + " key sent by the remote host is\n" + key_fprint + ".\n" + "Please contact your system administrator.\n" + "Add correct host key in " + file + " to get rid of this message.";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  746 */         if (shkc.equals("ask")) {
/*  747 */           b = this.userinfo.promptYesNo(message + "\nDo you want to delete the old key and insert the new key?");
/*      */         }
/*      */         else
/*      */         {
/*  751 */           this.userinfo.showMessage(message);
/*      */         }
/*      */       }
/*      */       
/*  755 */       if (!b) {
/*  756 */         throw new JSchException("HostKey has been changed: " + chost);
/*      */       }
/*      */       
/*  759 */       synchronized (hkr) {
/*  760 */         hkr.remove(chost, key_type.equals("DSA") ? "ssh-dss" : "ssh-rsa", null);
/*      */         
/*      */ 
/*  763 */         insert = true;
/*      */       }
/*      */     }
/*      */     
/*  767 */     if (((shkc.equals("ask")) || (shkc.equals("yes"))) && (i != 0) && (!insert))
/*      */     {
/*  769 */       if (shkc.equals("yes")) {
/*  770 */         throw new JSchException("reject HostKey: " + this.host);
/*      */       }
/*      */       
/*  773 */       if (this.userinfo != null) {
/*  774 */         boolean foo = this.userinfo.promptYesNo("The authenticity of host '" + this.host + "' can't be established.\n" + key_type + " key fingerprint is " + key_fprint + ".\n" + "Are you sure you want to continue connecting?");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  779 */         if (!foo) {
/*  780 */           throw new JSchException("reject HostKey: " + this.host);
/*      */         }
/*  782 */         insert = true;
/*      */       }
/*      */       else {
/*  785 */         if (i == 1) {
/*  786 */           throw new JSchException("UnknownHostKey: " + this.host + ". " + key_type + " key fingerprint is " + key_fprint);
/*      */         }
/*  788 */         throw new JSchException("HostKey has been changed: " + this.host);
/*      */       }
/*      */     }
/*      */     
/*  792 */     if ((shkc.equals("no")) && (1 == i))
/*      */     {
/*  794 */       insert = true;
/*      */     }
/*      */     
/*  797 */     if (i == 0) {
/*  798 */       HostKey[] keys = hkr.getHostKey(chost, key_type.equals("DSA") ? "ssh-dss" : "ssh-rsa");
/*      */       
/*      */ 
/*  801 */       String _key = Util.byte2str(Util.toBase64(K_S, 0, K_S.length));
/*  802 */       for (int j = 0; j < keys.length; j++) {
/*  803 */         if ((keys[i].getKey().equals(_key)) && (keys[j].getMarker().equals("@revoked")))
/*      */         {
/*  805 */           if (this.userinfo != null) {
/*  806 */             this.userinfo.showMessage("The " + key_type + " host key for " + this.host + " is marked as revoked.\n" + "This could mean that a stolen key is being used to " + "impersonate this host.");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  811 */           if (JSch.getLogger().isEnabled(1)) {
/*  812 */             JSch.getLogger().log(1, "Host '" + this.host + "' has provided revoked key.");
/*      */           }
/*      */           
/*  815 */           throw new JSchException("revoked HostKey: " + this.host);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  820 */     if ((i == 0) && (JSch.getLogger().isEnabled(1)))
/*      */     {
/*  822 */       JSch.getLogger().log(1, "Host '" + this.host + "' is known and mathces the " + key_type + " host key");
/*      */     }
/*      */     
/*      */ 
/*  826 */     if ((insert) && (JSch.getLogger().isEnabled(2)))
/*      */     {
/*  828 */       JSch.getLogger().log(2, "Permanently added '" + this.host + "' (" + key_type + ") to the list of known hosts.");
/*      */     }
/*      */     
/*      */ 
/*  832 */     if (insert) {
/*  833 */       synchronized (hkr) {
/*  834 */         hkr.add(this.hostkey, this.userinfo);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Channel openChannel(String type)
/*      */     throws JSchException
/*      */   {
/*  842 */     if (!this.isConnected) {
/*  843 */       throw new JSchException("session is down");
/*      */     }
/*      */     try {
/*  846 */       Channel channel = Channel.getChannel(type);
/*  847 */       addChannel(channel);
/*  848 */       channel.init();
/*  849 */       if ((channel instanceof ChannelSession)) {
/*  850 */         applyConfigChannel((ChannelSession)channel);
/*      */       }
/*  852 */       return channel;
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/*  857 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void encode(Packet packet)
/*      */     throws Exception
/*      */   {
/*  867 */     if (this.deflater != null) {
/*  868 */       this.compress_len[0] = packet.buffer.index;
/*  869 */       packet.buffer.buffer = this.deflater.compress(packet.buffer.buffer, 5, this.compress_len);
/*      */       
/*  871 */       packet.buffer.index = this.compress_len[0];
/*      */     }
/*  873 */     if (this.c2scipher != null)
/*      */     {
/*  875 */       packet.padding(this.c2scipher_size);
/*  876 */       int pad = packet.buffer.buffer[4];
/*  877 */       synchronized (random) {
/*  878 */         random.fill(packet.buffer.buffer, packet.buffer.index - pad, pad);
/*      */       }
/*      */     }
/*      */     else {
/*  882 */       packet.padding(8);
/*      */     }
/*      */     
/*  885 */     if (this.c2smac != null) {
/*  886 */       this.c2smac.update(this.seqo);
/*  887 */       this.c2smac.update(packet.buffer.buffer, 0, packet.buffer.index);
/*  888 */       this.c2smac.doFinal(packet.buffer.buffer, packet.buffer.index);
/*      */     }
/*  890 */     if (this.c2scipher != null) {
/*  891 */       byte[] buf = packet.buffer.buffer;
/*  892 */       this.c2scipher.update(buf, 0, packet.buffer.index, buf, 0);
/*      */     }
/*  894 */     if (this.c2smac != null) {
/*  895 */       packet.buffer.skip(this.c2smac.getBlockSize());
/*      */     }
/*      */   }
/*      */   
/*  899 */   int[] uncompress_len = new int[1];
/*  900 */   int[] compress_len = new int[1];
/*      */   
/*  902 */   private int s2ccipher_size = 8;
/*  903 */   private int c2scipher_size = 8;
/*      */   
/*  905 */   public Buffer read(Buffer buf) throws Exception { int j = 0;
/*      */     for (;;) {
/*  907 */       buf.reset();
/*  908 */       this.io.getByte(buf.buffer, buf.index, this.s2ccipher_size);
/*  909 */       buf.index += this.s2ccipher_size;
/*  910 */       if (this.s2ccipher != null) {
/*  911 */         this.s2ccipher.update(buf.buffer, 0, this.s2ccipher_size, buf.buffer, 0);
/*      */       }
/*  913 */       j = buf.buffer[0] << 24 & 0xFF000000 | buf.buffer[1] << 16 & 0xFF0000 | buf.buffer[2] << 8 & 0xFF00 | buf.buffer[3] & 0xFF;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  918 */       if ((j < 5) || (j > 262144)) {
/*  919 */         start_discard(buf, this.s2ccipher, this.s2cmac, j, 262144);
/*      */       }
/*  921 */       int need = j + 4 - this.s2ccipher_size;
/*      */       
/*      */ 
/*      */ 
/*  925 */       if (buf.index + need > buf.buffer.length) {
/*  926 */         byte[] foo = new byte[buf.index + need];
/*  927 */         System.arraycopy(buf.buffer, 0, foo, 0, buf.index);
/*  928 */         buf.buffer = foo;
/*      */       }
/*      */       
/*  931 */       if (need % this.s2ccipher_size != 0) {
/*  932 */         String message = "Bad packet length " + need;
/*  933 */         if (JSch.getLogger().isEnabled(4)) {
/*  934 */           JSch.getLogger().log(4, message);
/*      */         }
/*  936 */         start_discard(buf, this.s2ccipher, this.s2cmac, j, 262144 - this.s2ccipher_size);
/*      */       }
/*      */       
/*  939 */       if (need > 0) {
/*  940 */         this.io.getByte(buf.buffer, buf.index, need);buf.index += need;
/*  941 */         if (this.s2ccipher != null) {
/*  942 */           this.s2ccipher.update(buf.buffer, this.s2ccipher_size, need, buf.buffer, this.s2ccipher_size);
/*      */         }
/*      */       }
/*      */       
/*  946 */       if (this.s2cmac != null) {
/*  947 */         this.s2cmac.update(this.seqi);
/*  948 */         this.s2cmac.update(buf.buffer, 0, buf.index);
/*      */         
/*  950 */         this.s2cmac.doFinal(this.s2cmac_result1, 0);
/*  951 */         this.io.getByte(this.s2cmac_result2, 0, this.s2cmac_result2.length);
/*  952 */         if (!Arrays.equals(this.s2cmac_result1, this.s2cmac_result2)) {
/*  953 */           if (need > 262144) {
/*  954 */             throw new IOException("MAC Error");
/*      */           }
/*  956 */           start_discard(buf, this.s2ccipher, this.s2cmac, j, 262144 - need);
/*  957 */           continue;
/*      */         }
/*      */       }
/*      */       
/*  961 */       this.seqi += 1;
/*      */       
/*  963 */       if (this.inflater != null)
/*      */       {
/*  965 */         int pad = buf.buffer[4];
/*  966 */         this.uncompress_len[0] = (buf.index - 5 - pad);
/*  967 */         byte[] foo = this.inflater.uncompress(buf.buffer, 5, this.uncompress_len);
/*  968 */         if (foo != null) {
/*  969 */           buf.buffer = foo;
/*  970 */           buf.index = (5 + this.uncompress_len[0]);
/*      */         }
/*      */         else {
/*  973 */           System.err.println("fail in inflater");
/*  974 */           break;
/*      */         }
/*      */       }
/*      */       
/*  978 */       int type = buf.getCommand() & 0xFF;
/*      */       
/*  980 */       if (type == 1) {
/*  981 */         buf.rewind();
/*  982 */         buf.getInt();buf.getShort();
/*  983 */         int reason_code = buf.getInt();
/*  984 */         byte[] description = buf.getString();
/*  985 */         byte[] language_tag = buf.getString();
/*  986 */         throw new JSchException("SSH_MSG_DISCONNECT: " + reason_code + " " + Util.byte2str(description) + " " + Util.byte2str(language_tag));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  992 */       if (type != 2)
/*      */       {
/*  994 */         if (type == 3) {
/*  995 */           buf.rewind();
/*  996 */           buf.getInt();buf.getShort();
/*  997 */           int reason_id = buf.getInt();
/*  998 */           if (JSch.getLogger().isEnabled(1)) {
/*  999 */             JSch.getLogger().log(1, "Received SSH_MSG_UNIMPLEMENTED for " + reason_id);
/*      */           }
/*      */           
/*      */         }
/* 1003 */         else if (type == 4) {
/* 1004 */           buf.rewind();
/* 1005 */           buf.getInt();buf.getShort();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1015 */         else if (type == 93) {
/* 1016 */           buf.rewind();
/* 1017 */           buf.getInt();buf.getShort();
/* 1018 */           Channel c = Channel.getChannel(buf.getInt(), this);
/* 1019 */           if (c != null)
/*      */           {
/*      */ 
/* 1022 */             c.addRemoteWindowSize(buf.getInt());
/*      */           }
/*      */         } else {
/* 1025 */           if (type != 52) break;
/* 1026 */           this.isAuthed = true;
/* 1027 */           if ((this.inflater != null) || (this.deflater != null))
/*      */             break;
/* 1029 */           String method = this.guess[6];
/* 1030 */           initDeflater(method);
/* 1031 */           method = this.guess[7];
/* 1032 */           initInflater(method);
/* 1033 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1040 */     buf.rewind();
/* 1041 */     return buf;
/*      */   }
/*      */   
/*      */   private void start_discard(Buffer buf, Cipher cipher, MAC mac, int packet_length, int discard) throws JSchException, IOException
/*      */   {
/* 1046 */     MAC discard_mac = null;
/*      */     
/* 1048 */     if (!cipher.isCBC()) {
/* 1049 */       throw new JSchException("Packet corrupt");
/*      */     }
/*      */     
/* 1052 */     if ((packet_length != 262144) && (mac != null)) {
/* 1053 */       discard_mac = mac;
/*      */     }
/*      */     
/* 1056 */     discard -= buf.index;
/*      */     
/* 1058 */     while (discard > 0) {
/* 1059 */       buf.reset();
/* 1060 */       int len = discard > buf.buffer.length ? buf.buffer.length : discard;
/* 1061 */       this.io.getByte(buf.buffer, 0, len);
/* 1062 */       if (discard_mac != null) {
/* 1063 */         discard_mac.update(buf.buffer, 0, len);
/*      */       }
/* 1065 */       discard -= len;
/*      */     }
/*      */     
/* 1068 */     if (discard_mac != null) {
/* 1069 */       discard_mac.doFinal(buf.buffer, 0);
/*      */     }
/*      */     
/* 1072 */     throw new JSchException("Packet corrupt");
/*      */   }
/*      */   
/*      */   byte[] getSessionId() {
/* 1076 */     return this.session_id;
/*      */   }
/*      */   
/*      */   private void receive_newkeys(Buffer buf, KeyExchange kex) throws Exception {
/* 1080 */     updateKeys(kex);
/* 1081 */     this.in_kex = false;
/*      */   }
/*      */   
/* 1084 */   private void updateKeys(KeyExchange kex) throws Exception { byte[] K = kex.getK();
/* 1085 */     byte[] H = kex.getH();
/* 1086 */     HASH hash = kex.getHash();
/*      */     
/* 1088 */     if (this.session_id == null) {
/* 1089 */       this.session_id = new byte[H.length];
/* 1090 */       System.arraycopy(H, 0, this.session_id, 0, H.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1102 */     this.buf.reset();
/* 1103 */     this.buf.putMPInt(K);
/* 1104 */     this.buf.putByte(H);
/* 1105 */     this.buf.putByte((byte)65);
/* 1106 */     this.buf.putByte(this.session_id);
/* 1107 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1108 */     this.IVc2s = hash.digest();
/*      */     
/* 1110 */     int j = this.buf.index - this.session_id.length - 1; int 
/*      */     
/* 1112 */       tmp145_143 = j; byte[] tmp145_140 = this.buf.buffer;tmp145_140[tmp145_143] = ((byte)(tmp145_140[tmp145_143] + 1));
/* 1113 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1114 */     this.IVs2c = hash.digest(); int 
/*      */     
/* 1116 */       tmp193_191 = j; byte[] tmp193_188 = this.buf.buffer;tmp193_188[tmp193_191] = ((byte)(tmp193_188[tmp193_191] + 1));
/* 1117 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1118 */     this.Ec2s = hash.digest(); int 
/*      */     
/* 1120 */       tmp241_239 = j; byte[] tmp241_236 = this.buf.buffer;tmp241_236[tmp241_239] = ((byte)(tmp241_236[tmp241_239] + 1));
/* 1121 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1122 */     this.Es2c = hash.digest(); int 
/*      */     
/* 1124 */       tmp289_287 = j; byte[] tmp289_284 = this.buf.buffer;tmp289_284[tmp289_287] = ((byte)(tmp289_284[tmp289_287] + 1));
/* 1125 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1126 */     this.MACc2s = hash.digest(); int 
/*      */     
/* 1128 */       tmp337_335 = j; byte[] tmp337_332 = this.buf.buffer;tmp337_332[tmp337_335] = ((byte)(tmp337_332[tmp337_335] + 1));
/* 1129 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1130 */     this.MACs2c = hash.digest();
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1136 */       String method = this.guess[3];
/* 1137 */       Class c = Class.forName(getConfig(method));
/* 1138 */       this.s2ccipher = ((Cipher)c.newInstance());
/* 1139 */       while (this.s2ccipher.getBlockSize() > this.Es2c.length) {
/* 1140 */         this.buf.reset();
/* 1141 */         this.buf.putMPInt(K);
/* 1142 */         this.buf.putByte(H);
/* 1143 */         this.buf.putByte(this.Es2c);
/* 1144 */         hash.update(this.buf.buffer, 0, this.buf.index);
/* 1145 */         byte[] foo = hash.digest();
/* 1146 */         byte[] bar = new byte[this.Es2c.length + foo.length];
/* 1147 */         System.arraycopy(this.Es2c, 0, bar, 0, this.Es2c.length);
/* 1148 */         System.arraycopy(foo, 0, bar, this.Es2c.length, foo.length);
/* 1149 */         this.Es2c = bar;
/*      */       }
/* 1151 */       this.s2ccipher.init(1, this.Es2c, this.IVs2c);
/* 1152 */       this.s2ccipher_size = this.s2ccipher.getIVSize();
/*      */       
/* 1154 */       method = this.guess[5];
/* 1155 */       c = Class.forName(getConfig(method));
/* 1156 */       this.s2cmac = ((MAC)c.newInstance());
/* 1157 */       this.MACs2c = expandKey(this.buf, K, H, this.MACs2c, hash, this.s2cmac.getBlockSize());
/* 1158 */       this.s2cmac.init(this.MACs2c);
/*      */       
/* 1160 */       this.s2cmac_result1 = new byte[this.s2cmac.getBlockSize()];
/* 1161 */       this.s2cmac_result2 = new byte[this.s2cmac.getBlockSize()];
/*      */       
/* 1163 */       method = this.guess[2];
/* 1164 */       c = Class.forName(getConfig(method));
/* 1165 */       this.c2scipher = ((Cipher)c.newInstance());
/* 1166 */       while (this.c2scipher.getBlockSize() > this.Ec2s.length) {
/* 1167 */         this.buf.reset();
/* 1168 */         this.buf.putMPInt(K);
/* 1169 */         this.buf.putByte(H);
/* 1170 */         this.buf.putByte(this.Ec2s);
/* 1171 */         hash.update(this.buf.buffer, 0, this.buf.index);
/* 1172 */         byte[] foo = hash.digest();
/* 1173 */         byte[] bar = new byte[this.Ec2s.length + foo.length];
/* 1174 */         System.arraycopy(this.Ec2s, 0, bar, 0, this.Ec2s.length);
/* 1175 */         System.arraycopy(foo, 0, bar, this.Ec2s.length, foo.length);
/* 1176 */         this.Ec2s = bar;
/*      */       }
/* 1178 */       this.c2scipher.init(0, this.Ec2s, this.IVc2s);
/* 1179 */       this.c2scipher_size = this.c2scipher.getIVSize();
/*      */       
/* 1181 */       method = this.guess[4];
/* 1182 */       c = Class.forName(getConfig(method));
/* 1183 */       this.c2smac = ((MAC)c.newInstance());
/* 1184 */       this.MACc2s = expandKey(this.buf, K, H, this.MACc2s, hash, this.c2smac.getBlockSize());
/* 1185 */       this.c2smac.init(this.MACc2s);
/*      */       
/* 1187 */       method = this.guess[6];
/* 1188 */       initDeflater(method);
/*      */       
/* 1190 */       method = this.guess[7];
/* 1191 */       initInflater(method);
/*      */     }
/*      */     catch (Exception e) {
/* 1194 */       if ((e instanceof JSchException))
/* 1195 */         throw e;
/* 1196 */       throw new JSchException(e.toString(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] expandKey(Buffer buf, byte[] K, byte[] H, byte[] key, HASH hash, int required_length)
/*      */     throws Exception
/*      */   {
/* 1218 */     byte[] result = key;
/* 1219 */     int size = hash.getBlockSize();
/* 1220 */     while (result.length < required_length) {
/* 1221 */       buf.reset();
/* 1222 */       buf.putMPInt(K);
/* 1223 */       buf.putByte(H);
/* 1224 */       buf.putByte(result);
/* 1225 */       hash.update(buf.buffer, 0, buf.index);
/* 1226 */       byte[] tmp = new byte[result.length + size];
/* 1227 */       System.arraycopy(result, 0, tmp, 0, result.length);
/* 1228 */       System.arraycopy(hash.digest(), 0, tmp, result.length, size);
/* 1229 */       Util.bzero(result);
/* 1230 */       result = tmp;
/*      */     }
/* 1232 */     return result;
/*      */   }
/*      */   
/*      */   void write(Packet packet, Channel c, int length) throws Exception {
/* 1236 */     long t = getTimeout();
/*      */     for (;;) {
/* 1238 */       if (this.in_kex) {
/* 1239 */         if ((t > 0L) && (System.currentTimeMillis() - this.kex_start_time > t))
/* 1240 */           throw new JSchException("timeout in wating for rekeying process.");
/*      */         try {
/* 1242 */           Thread.sleep(10L);
/*      */         }
/*      */         catch (InterruptedException e) {}
/*      */       } else {
/* 1246 */         synchronized (c)
/*      */         {
/* 1248 */           if (c.rwsize < length) {
/*      */             try {
/* 1250 */               c.notifyme += 1;
/* 1251 */               c.wait(100L);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1256 */               c.notifyme -= 1; } catch (InterruptedException e) { c.notifyme -= 1; } finally { c.notifyme -= 1;
/*      */             }
/*      */           }
/*      */           
/* 1260 */           if (c.rwsize >= length) {
/* 1261 */             c.rwsize -= length;
/* 1262 */             break;
/*      */           }
/*      */         }
/*      */         
/* 1266 */         if ((c.close) || (!c.isConnected())) {
/* 1267 */           throw new IOException("channel is broken");
/*      */         }
/*      */         
/* 1270 */         boolean sendit = false;
/* 1271 */         int s = 0;
/* 1272 */         byte command = 0;
/* 1273 */         int recipient = -1;
/* 1274 */         synchronized (c) {
/* 1275 */           if (c.rwsize > 0L) {
/* 1276 */             long len = c.rwsize;
/* 1277 */             if (len > length) {
/* 1278 */               len = length;
/*      */             }
/* 1280 */             if (len != length) {
/* 1281 */               s = packet.shift((int)len, this.c2scipher != null ? this.c2scipher_size : 8, this.c2smac != null ? this.c2smac.getBlockSize() : 0);
/*      */             }
/*      */             
/*      */ 
/* 1285 */             command = packet.buffer.getCommand();
/* 1286 */             recipient = c.getRecipient();
/* 1287 */             length = (int)(length - len);
/* 1288 */             c.rwsize -= len;
/* 1289 */             sendit = true;
/*      */           }
/*      */         }
/* 1292 */         if (sendit) {
/* 1293 */           _write(packet);
/* 1294 */           if (length == 0) {
/* 1295 */             return;
/*      */           }
/* 1297 */           packet.unshift(command, recipient, s, length);
/*      */         }
/*      */         
/* 1300 */         synchronized (c) {
/* 1301 */           if (!this.in_kex)
/*      */           {
/*      */ 
/* 1304 */             if (c.rwsize >= length) {
/* 1305 */               c.rwsize -= length;
/* 1306 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1321 */     _write(packet);
/*      */   }
/*      */   
/*      */   public void write(Packet packet) throws Exception
/*      */   {
/* 1326 */     long t = getTimeout();
/* 1327 */     while (this.in_kex) {
/* 1328 */       if ((t > 0L) && (System.currentTimeMillis() - this.kex_start_time > t)) {
/* 1329 */         throw new JSchException("timeout in wating for rekeying process.");
/*      */       }
/* 1331 */       byte command = packet.buffer.getCommand();
/*      */       
/* 1333 */       if ((command == 20) || (command == 21) || (command == 30) || (command == 31) || (command == 31) || (command == 32) || (command == 33) || (command == 34) || (command == 1)) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1344 */         Thread.sleep(10L);
/*      */       } catch (InterruptedException e) {}
/*      */     }
/* 1347 */     _write(packet);
/*      */   }
/*      */   
/*      */   private void _write(Packet packet) throws Exception {
/* 1351 */     synchronized (this.lock) {
/* 1352 */       encode(packet);
/* 1353 */       if (this.io != null) {
/* 1354 */         this.io.put(packet);
/* 1355 */         this.seqo += 1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void run()
/*      */   {
/* 1362 */     this.thread = this;
/*      */     
/*      */ 
/* 1365 */     Buffer buf = new Buffer();
/* 1366 */     Packet packet = new Packet(buf);
/* 1367 */     int i = 0;
/*      */     
/* 1369 */     int[] start = new int[1];
/* 1370 */     int[] length = new int[1];
/* 1371 */     KeyExchange kex = null;
/*      */     
/* 1373 */     int stimeout = 0;
/*      */     try {
/*      */       label1570:
/* 1376 */       while ((this.isConnected) && (this.thread != null)) {
/*      */         try {
/* 1378 */           buf = read(buf);
/* 1379 */           stimeout = 0;
/*      */         }
/*      */         catch (InterruptedIOException ee) {
/* 1382 */           if ((!this.in_kex) && (stimeout < this.serverAliveCountMax)) {
/* 1383 */             sendKeepAliveMsg();
/* 1384 */             stimeout++;
/* 1385 */             continue;
/*      */           }
/* 1387 */           if ((this.in_kex) && (stimeout < this.serverAliveCountMax)) {
/* 1388 */             stimeout++;
/* 1389 */             continue;
/*      */           }
/* 1391 */           throw ee;
/*      */         }
/*      */         
/* 1394 */         int msgType = buf.getCommand() & 0xFF;
/*      */         
/* 1396 */         if ((kex != null) && (kex.getState() == msgType)) {
/* 1397 */           this.kex_start_time = System.currentTimeMillis();
/* 1398 */           boolean result = kex.next(buf);
/* 1399 */           if (!result)
/* 1400 */             throw new JSchException("verify: " + result); } else { Channel channel;
/*      */           byte[] foo;
/*      */           int len;
/*      */           boolean reply;
/*      */           Channel channel;
/* 1405 */           switch (msgType)
/*      */           {
/*      */           case 20: 
/* 1408 */             kex = receive_kexinit(buf);
/* 1409 */             break;
/*      */           
/*      */ 
/*      */           case 21: 
/* 1413 */             send_newkeys();
/* 1414 */             receive_newkeys(buf, kex);
/* 1415 */             kex = null;
/* 1416 */             break;
/*      */           
/*      */           case 94: 
/* 1419 */             buf.getInt();
/* 1420 */             buf.getByte();
/* 1421 */             buf.getByte();
/* 1422 */             i = buf.getInt();
/* 1423 */             channel = Channel.getChannel(i, this);
/* 1424 */             foo = buf.getString(start, length);
/* 1425 */             if (channel == null) {
/*      */               break label1570;
/*      */             }
/*      */             
/* 1429 */             if (length[0] == 0) {
/*      */               break label1570;
/*      */             }
/*      */             try
/*      */             {
/* 1434 */               channel.write(foo, start[0], length[0]);
/*      */             }
/*      */             catch (Exception e) {
/*      */               try {
/* 1438 */                 channel.disconnect();
/*      */               } catch (Exception ee) {}
/*      */               break label1570; }
/* 1441 */             len = length[0];
/* 1442 */             channel.setLocalWindowSize(channel.lwsize - len);
/* 1443 */             if (channel.lwsize >= channel.lwsize_max / 2) break label1570;
/* 1444 */             packet.reset();
/* 1445 */             buf.putByte((byte)93);
/* 1446 */             buf.putInt(channel.getRecipient());
/* 1447 */             buf.putInt(channel.lwsize_max - channel.lwsize);
/* 1448 */             synchronized (channel) {
/* 1449 */               if (!channel.close)
/* 1450 */                 write(packet);
/*      */             }
/* 1452 */             channel.setLocalWindowSize(channel.lwsize_max); break;
/*      */           
/*      */ 
/*      */ 
/*      */           case 95: 
/* 1457 */             buf.getInt();
/* 1458 */             buf.getShort();
/* 1459 */             i = buf.getInt();
/* 1460 */             channel = Channel.getChannel(i, this);
/* 1461 */             buf.getInt();
/* 1462 */             foo = buf.getString(start, length);
/*      */             
/* 1464 */             if (channel == null) {
/*      */               break label1570;
/*      */             }
/*      */             
/* 1468 */             if (length[0] == 0) {
/*      */               break label1570;
/*      */             }
/*      */             
/* 1472 */             channel.write_ext(foo, start[0], length[0]);
/*      */             
/* 1474 */             len = length[0];
/* 1475 */             channel.setLocalWindowSize(channel.lwsize - len);
/* 1476 */             if (channel.lwsize >= channel.lwsize_max / 2) break label1570;
/* 1477 */             packet.reset();
/* 1478 */             buf.putByte((byte)93);
/* 1479 */             buf.putInt(channel.getRecipient());
/* 1480 */             buf.putInt(channel.lwsize_max - channel.lwsize);
/* 1481 */             synchronized (channel) {
/* 1482 */               if (!channel.close)
/* 1483 */                 write(packet);
/*      */             }
/* 1485 */             channel.setLocalWindowSize(channel.lwsize_max); break;
/*      */           
/*      */ 
/*      */ 
/*      */           case 93: 
/* 1490 */             buf.getInt();
/* 1491 */             buf.getShort();
/* 1492 */             i = buf.getInt();
/* 1493 */             channel = Channel.getChannel(i, this);
/* 1494 */             if (channel == null) {
/*      */               break label1570;
/*      */             }
/* 1497 */             channel.addRemoteWindowSize(buf.getInt());
/* 1498 */             break;
/*      */           
/*      */           case 96: 
/* 1501 */             buf.getInt();
/* 1502 */             buf.getShort();
/* 1503 */             i = buf.getInt();
/* 1504 */             channel = Channel.getChannel(i, this);
/* 1505 */             if (channel == null) {
/*      */               break label1570;
/*      */             }
/* 1508 */             channel.eof_remote(); break;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           case 97: 
/* 1518 */             buf.getInt();
/* 1519 */             buf.getShort();
/* 1520 */             i = buf.getInt();
/* 1521 */             channel = Channel.getChannel(i, this);
/* 1522 */             if (channel == null)
/*      */               break label1570;
/* 1524 */             channel.disconnect(); break;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           case 91: 
/* 1533 */             buf.getInt();
/* 1534 */             buf.getShort();
/* 1535 */             i = buf.getInt();
/* 1536 */             channel = Channel.getChannel(i, this);
/* 1537 */             if (channel == null) {}
/*      */             
/*      */ 
/* 1540 */             int r = buf.getInt();
/* 1541 */             long rws = buf.getUInt();
/* 1542 */             int rps = buf.getInt();
/*      */             
/* 1544 */             channel.setRemoteWindowSize(rws);
/* 1545 */             channel.setRemotePacketSize(rps);
/* 1546 */             channel.open_confirmation = true;
/* 1547 */             channel.setRecipient(r);
/* 1548 */             break;
/*      */           case 92: 
/* 1550 */             buf.getInt();
/* 1551 */             buf.getShort();
/* 1552 */             i = buf.getInt();
/* 1553 */             channel = Channel.getChannel(i, this);
/* 1554 */             if (channel == null) {}
/*      */             
/*      */ 
/* 1557 */             int reason_code = buf.getInt();
/*      */             
/*      */ 
/* 1560 */             channel.setExitStatus(reason_code);
/* 1561 */             channel.close = true;
/* 1562 */             channel.eof_remote = true;
/* 1563 */             channel.setRecipient(0);
/* 1564 */             break;
/*      */           case 98: 
/* 1566 */             buf.getInt();
/* 1567 */             buf.getShort();
/* 1568 */             i = buf.getInt();
/* 1569 */             foo = buf.getString();
/* 1570 */             reply = buf.getByte() != 0;
/* 1571 */             channel = Channel.getChannel(i, this);
/* 1572 */             if (channel == null) break label1570;
/* 1573 */             byte reply_type = 100;
/* 1574 */             if (Util.byte2str(foo).equals("exit-status")) {
/* 1575 */               i = buf.getInt();
/* 1576 */               channel.setExitStatus(i);
/* 1577 */               reply_type = 99;
/*      */             }
/* 1579 */             if (reply) {
/* 1580 */               packet.reset();
/* 1581 */               buf.putByte(reply_type);
/* 1582 */               buf.putInt(channel.getRecipient());
/* 1583 */               write(packet);
/*      */             }
/* 1585 */             break;
/*      */           
/*      */ 
/*      */ 
/*      */           case 90: 
/* 1590 */             buf.getInt();
/* 1591 */             buf.getShort();
/* 1592 */             foo = buf.getString();
/* 1593 */             String ctyp = Util.byte2str(foo);
/* 1594 */             if ((!"forwarded-tcpip".equals(ctyp)) && ((!"x11".equals(ctyp)) || (!this.x11_forwarding)) && ((!"auth-agent@openssh.com".equals(ctyp)) || (!this.agent_forwarding)))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 1599 */               packet.reset();
/* 1600 */               buf.putByte((byte)92);
/* 1601 */               buf.putInt(buf.getInt());
/* 1602 */               buf.putInt(1);
/* 1603 */               buf.putString(Util.empty);
/* 1604 */               buf.putString(Util.empty);
/* 1605 */               write(packet);
/*      */             }
/*      */             else {
/* 1608 */               channel = Channel.getChannel(ctyp);
/* 1609 */               addChannel(channel);
/* 1610 */               channel.getData(buf);
/* 1611 */               channel.init();
/*      */               
/* 1613 */               Thread tmp = new Thread(channel);
/* 1614 */               tmp.setName("Channel " + ctyp + " " + this.host);
/* 1615 */               if (this.daemon_thread) {
/* 1616 */                 tmp.setDaemon(this.daemon_thread);
/*      */               }
/* 1618 */               tmp.start(); }
/* 1619 */             break;
/*      */           
/*      */           case 99: 
/* 1622 */             buf.getInt();
/* 1623 */             buf.getShort();
/* 1624 */             i = buf.getInt();
/* 1625 */             channel = Channel.getChannel(i, this);
/* 1626 */             if (channel == null) {
/*      */               break label1570;
/*      */             }
/* 1629 */             channel.reply = 1;
/* 1630 */             break;
/*      */           case 100: 
/* 1632 */             buf.getInt();
/* 1633 */             buf.getShort();
/* 1634 */             i = buf.getInt();
/* 1635 */             channel = Channel.getChannel(i, this);
/* 1636 */             if (channel == null) {
/*      */               break label1570;
/*      */             }
/* 1639 */             channel.reply = 0;
/* 1640 */             break;
/*      */           case 80: 
/* 1642 */             buf.getInt();
/* 1643 */             buf.getShort();
/* 1644 */             foo = buf.getString();
/* 1645 */             reply = buf.getByte() != 0;
/* 1646 */             if (!reply) break label1570;
/* 1647 */             packet.reset();
/* 1648 */             buf.putByte((byte)82);
/* 1649 */             write(packet); break;
/*      */           
/*      */ 
/*      */           case 81: 
/*      */           case 82: 
/* 1654 */             Thread t = this.grr.getThread();
/* 1655 */             if (t == null) break label1570;
/* 1656 */             this.grr.setReply(msgType == 81 ? 1 : 0);
/* 1657 */             if ((msgType == 81) && (this.grr.getPort() == 0)) {
/* 1658 */               buf.getInt();
/* 1659 */               buf.getShort();
/* 1660 */               this.grr.setPort(buf.getInt());
/*      */             }
/* 1662 */             t.interrupt(); break;
/*      */           }
/*      */           
/*      */           
/*      */ 
/* 1667 */           throw new IOException("Unknown SSH message type " + msgType);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1672 */       this.in_kex = false;
/* 1673 */       if (JSch.getLogger().isEnabled(1)) {
/* 1674 */         JSch.getLogger().log(1, "Caught an exception, leaving main loop due to " + e.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1681 */       disconnect();
/*      */     }
/*      */     catch (NullPointerException e) {}catch (Exception e) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1691 */     this.isConnected = false;
/*      */   }
/*      */   
/*      */   public void disconnect() {
/* 1695 */     if (!this.isConnected) { return;
/*      */     }
/*      */     
/* 1698 */     if (JSch.getLogger().isEnabled(1)) {
/* 1699 */       JSch.getLogger().log(1, "Disconnecting from " + this.host + " port " + this.port);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1713 */     Channel.disconnect(this);
/*      */     
/* 1715 */     this.isConnected = false;
/*      */     
/* 1717 */     PortWatcher.delPort(this);
/* 1718 */     ChannelForwardedTCPIP.delPort(this);
/* 1719 */     ChannelX11.removeFakedCookie(this);
/*      */     
/* 1721 */     synchronized (this.lock) {
/* 1722 */       if (this.connectThread != null) {
/* 1723 */         Thread.yield();
/* 1724 */         this.connectThread.interrupt();
/* 1725 */         this.connectThread = null;
/*      */       }
/*      */     }
/* 1728 */     this.thread = null;
/*      */     try {
/* 1730 */       if (this.io != null) {
/* 1731 */         if (this.io.in != null) this.io.in.close();
/* 1732 */         if (this.io.out != null) this.io.out.close();
/* 1733 */         if (this.io.out_ext != null) this.io.out_ext.close();
/*      */       }
/* 1735 */       if (this.proxy == null) {
/* 1736 */         if (this.socket != null) {
/* 1737 */           this.socket.close();
/*      */         }
/*      */       } else {
/* 1740 */         synchronized (this.proxy) {
/* 1741 */           this.proxy.close();
/*      */         }
/* 1743 */         this.proxy = null;
/*      */       }
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/* 1749 */     this.io = null;
/* 1750 */     this.socket = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1755 */     this.jsch.removeSession(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(int lport, String host, int rport)
/*      */     throws JSchException
/*      */   {
/* 1770 */     return setPortForwardingL("127.0.0.1", lport, host, rport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String bind_address, int lport, String host, int rport)
/*      */     throws JSchException
/*      */   {
/* 1787 */     return setPortForwardingL(bind_address, lport, host, rport, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String bind_address, int lport, String host, int rport, ServerSocketFactory ssf)
/*      */     throws JSchException
/*      */   {
/* 1806 */     return setPortForwardingL(bind_address, lport, host, rport, ssf, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String bind_address, int lport, String host, int rport, ServerSocketFactory ssf, int connectTimeout)
/*      */     throws JSchException
/*      */   {
/* 1825 */     PortWatcher pw = PortWatcher.addPort(this, bind_address, lport, host, rport, ssf);
/* 1826 */     pw.setConnectTimeout(connectTimeout);
/* 1827 */     Thread tmp = new Thread(pw);
/* 1828 */     tmp.setName("PortWatcher Thread for " + host);
/* 1829 */     if (this.daemon_thread) {
/* 1830 */       tmp.setDaemon(this.daemon_thread);
/*      */     }
/* 1832 */     tmp.start();
/* 1833 */     return pw.lport;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingL(int lport)
/*      */     throws JSchException
/*      */   {
/* 1843 */     delPortForwardingL("127.0.0.1", lport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingL(String bind_address, int lport)
/*      */     throws JSchException
/*      */   {
/* 1854 */     PortWatcher.delPort(this, bind_address, lport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getPortForwardingL()
/*      */     throws JSchException
/*      */   {
/* 1863 */     return PortWatcher.getPortForwarding(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String host, int lport)
/*      */     throws JSchException
/*      */   {
/* 1876 */     setPortForwardingR(null, rport, host, lport, (SocketFactory)null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(String bind_address, int rport, String host, int lport)
/*      */     throws JSchException
/*      */   {
/* 1895 */     setPortForwardingR(bind_address, rport, host, lport, (SocketFactory)null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String host, int lport, SocketFactory sf)
/*      */     throws JSchException
/*      */   {
/* 1909 */     setPortForwardingR(null, rport, host, lport, sf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(String bind_address, int rport, String host, int lport, SocketFactory sf)
/*      */     throws JSchException
/*      */   {
/* 1930 */     int allocated = _setPortForwardingR(bind_address, rport);
/* 1931 */     ChannelForwardedTCPIP.addPort(this, bind_address, rport, allocated, host, lport, sf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String daemon)
/*      */     throws JSchException
/*      */   {
/* 1948 */     setPortForwardingR(null, rport, daemon, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String daemon, Object[] arg)
/*      */     throws JSchException
/*      */   {
/* 1965 */     setPortForwardingR(null, rport, daemon, arg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Runnable thread;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(String bind_address, int rport, String daemon, Object[] arg)
/*      */     throws JSchException
/*      */   {
/* 1988 */     int allocated = _setPortForwardingR(bind_address, rport);
/* 1989 */     ChannelForwardedTCPIP.addPort(this, bind_address, rport, allocated, daemon, arg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1999 */   public String[] getPortForwardingR()
/* 1999 */     throws JSchException { return ChannelForwardedTCPIP.getPortForwarding(this); }
/*      */   
/*      */   private class Forwarding { private Forwarding() {}
/* 2002 */     Forwarding(Session.1 x1) { this(); }
/* 2003 */     String bind_address = null;
/* 2004 */     int port = -1;
/* 2005 */     String host = null;
/* 2006 */     int hostport = -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Forwarding parseForwarding(String conf)
/*      */     throws JSchException
/*      */   {
/* 2015 */     String[] tmp = conf.split(" ");
/* 2016 */     if (tmp.length > 1) {
/* 2017 */       Vector foo = new Vector();
/* 2018 */       for (int i = 0; i < tmp.length; i++) {
/* 2019 */         if (tmp[i].length() != 0)
/* 2020 */           foo.addElement(tmp[i].trim());
/*      */       }
/* 2022 */       StringBuffer sb = new StringBuffer();
/* 2023 */       for (int i = 0; i < foo.size(); i++) {
/* 2024 */         sb.append((String)foo.elementAt(i));
/* 2025 */         if (i + 1 < foo.size())
/* 2026 */           sb.append(":");
/*      */       }
/* 2028 */       conf = sb.toString();
/*      */     }
/*      */     
/* 2031 */     String org = conf;
/* 2032 */     Forwarding f = new Forwarding(null);
/*      */     try {
/* 2034 */       if (conf.lastIndexOf(":") == -1)
/* 2035 */         throw new JSchException("parseForwarding: " + org);
/* 2036 */       f.hostport = Integer.parseInt(conf.substring(conf.lastIndexOf(":") + 1));
/* 2037 */       conf = conf.substring(0, conf.lastIndexOf(":"));
/* 2038 */       if (conf.lastIndexOf(":") == -1)
/* 2039 */         throw new JSchException("parseForwarding: " + org);
/* 2040 */       f.host = conf.substring(conf.lastIndexOf(":") + 1);
/* 2041 */       conf = conf.substring(0, conf.lastIndexOf(":"));
/* 2042 */       if (conf.lastIndexOf(":") != -1) {
/* 2043 */         f.port = Integer.parseInt(conf.substring(conf.lastIndexOf(":") + 1));
/* 2044 */         conf = conf.substring(0, conf.lastIndexOf(":"));
/* 2045 */         if ((conf.length() == 0) || (conf.equals("*"))) conf = "0.0.0.0";
/* 2046 */         if (conf.equals("localhost")) conf = "127.0.0.1";
/* 2047 */         f.bind_address = conf;
/*      */       }
/*      */       else {
/* 2050 */         f.port = Integer.parseInt(conf);
/* 2051 */         f.bind_address = "127.0.0.1";
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException e) {
/* 2055 */       throw new JSchException("parseForwarding: " + e.toString());
/*      */     }
/* 2057 */     return f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String conf)
/*      */     throws JSchException
/*      */   {
/* 2073 */     Forwarding f = parseForwarding(conf);
/* 2074 */     return setPortForwardingL(f.bind_address, f.port, f.host, f.hostport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingR(String conf)
/*      */     throws JSchException
/*      */   {
/* 2093 */     Forwarding f = parseForwarding(conf);
/* 2094 */     int allocated = _setPortForwardingR(f.bind_address, f.port);
/* 2095 */     ChannelForwardedTCPIP.addPort(this, f.bind_address, f.port, allocated, f.host, f.hostport, null);
/*      */     
/* 2097 */     return allocated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Channel getStreamForwarder(String host, int port)
/*      */     throws JSchException
/*      */   {
/* 2108 */     ChannelDirectTCPIP channel = new ChannelDirectTCPIP();
/* 2109 */     channel.init();
/* 2110 */     addChannel(channel);
/* 2111 */     channel.setHost(host);
/* 2112 */     channel.setPort(port);
/* 2113 */     return channel;
/*      */   }
/*      */   
/* 2116 */   private class GlobalRequestReply { GlobalRequestReply(Session.1 x1) { this(); }
/* 2117 */     private Thread thread = null;
/* 2118 */     private int reply = -1;
/* 2119 */     private int port = 0;
/*      */     
/* 2121 */     void setThread(Thread thread) { this.thread = thread;
/* 2122 */       this.reply = -1; }
/*      */     
/* 2124 */     Thread getThread() { return this.thread; }
/* 2125 */     void setReply(int reply) { this.reply = reply; }
/* 2126 */     int getReply() { return this.reply; }
/* 2127 */     int getPort() { return this.port; }
/* 2128 */     void setPort(int port) { this.port = port; }
/*      */     private GlobalRequestReply() {} }
/* 2130 */   private GlobalRequestReply grr = new GlobalRequestReply(null);
/*      */   
/* 2132 */   private int _setPortForwardingR(String bind_address, int rport) throws JSchException { synchronized (this.grr) {
/* 2133 */       Buffer buf = new Buffer(100);
/* 2134 */       Packet packet = new Packet(buf);
/*      */       
/* 2136 */       String address_to_bind = ChannelForwardedTCPIP.normalize(bind_address);
/*      */       
/* 2138 */       this.grr.setThread(Thread.currentThread());
/* 2139 */       this.grr.setPort(rport);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 2147 */         packet.reset();
/* 2148 */         buf.putByte((byte)80);
/* 2149 */         buf.putString(Util.str2byte("tcpip-forward"));
/* 2150 */         buf.putByte((byte)1);
/* 2151 */         buf.putString(Util.str2byte(address_to_bind));
/* 2152 */         buf.putInt(rport);
/* 2153 */         write(packet);
/*      */       }
/*      */       catch (Exception e) {
/* 2156 */         this.grr.setThread(null);
/* 2157 */         if ((e instanceof Throwable))
/* 2158 */           throw new JSchException(e.toString(), e);
/* 2159 */         throw new JSchException(e.toString());
/*      */       }
/*      */       
/* 2162 */       int count = 0;
/* 2163 */       int reply = this.grr.getReply();
/* 2164 */       while ((count < 10) && (reply == -1)) {
/* 2165 */         try { Thread.sleep(1000L);
/*      */         }
/*      */         catch (Exception e) {}
/* 2168 */         count++;
/* 2169 */         reply = this.grr.getReply();
/*      */       }
/* 2171 */       this.grr.setThread(null);
/* 2172 */       if (reply != 1) {
/* 2173 */         throw new JSchException("remote port forwarding failed for listen port " + rport);
/*      */       }
/* 2175 */       rport = this.grr.getPort();
/*      */     }
/* 2177 */     return rport;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingR(int rport)
/*      */     throws JSchException
/*      */   {
/* 2186 */     delPortForwardingR(null, rport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingR(String bind_address, int rport)
/*      */     throws JSchException
/*      */   {
/* 2198 */     ChannelForwardedTCPIP.delPort(this, bind_address, rport);
/*      */   }
/*      */   
/*      */   private void initDeflater(String method) throws JSchException {
/* 2202 */     if (method.equals("none")) {
/* 2203 */       this.deflater = null;
/* 2204 */       return;
/*      */     }
/* 2206 */     String foo = getConfig(method);
/* 2207 */     if ((foo != null) && (
/* 2208 */       (method.equals("zlib")) || ((this.isAuthed) && (method.equals("zlib@openssh.com"))))) {
/*      */       try
/*      */       {
/* 2211 */         Class c = Class.forName(foo);
/* 2212 */         this.deflater = ((Compression)c.newInstance());
/* 2213 */         int level = 6;
/* 2214 */         try { level = Integer.parseInt(getConfig("compression_level"));
/*      */         } catch (Exception ee) {}
/* 2216 */         this.deflater.init(1, level);
/*      */       }
/*      */       catch (NoClassDefFoundError ee) {
/* 2219 */         throw new JSchException(ee.toString(), ee);
/*      */       }
/*      */       catch (Exception ee) {
/* 2222 */         throw new JSchException(ee.toString(), ee);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void initInflater(String method) throws JSchException
/*      */   {
/* 2229 */     if (method.equals("none")) {
/* 2230 */       this.inflater = null;
/* 2231 */       return;
/*      */     }
/* 2233 */     String foo = getConfig(method);
/* 2234 */     if ((foo != null) && (
/* 2235 */       (method.equals("zlib")) || ((this.isAuthed) && (method.equals("zlib@openssh.com"))))) {
/*      */       try
/*      */       {
/* 2238 */         Class c = Class.forName(foo);
/* 2239 */         this.inflater = ((Compression)c.newInstance());
/* 2240 */         this.inflater.init(0, 0);
/*      */       }
/*      */       catch (Exception ee) {
/* 2243 */         throw new JSchException(ee.toString(), ee);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void addChannel(Channel channel)
/*      */   {
/* 2251 */     channel.setSession(this);
/*      */   }
/*      */   
/* 2254 */   public void setProxy(Proxy proxy) { this.proxy = proxy; }
/* 2255 */   public void setHost(String host) { this.host = host; }
/* 2256 */   public void setPort(int port) { this.port = port; }
/* 2257 */   void setUserName(String username) { this.username = username; }
/* 2258 */   public void setUserInfo(UserInfo userinfo) { this.userinfo = userinfo; }
/* 2259 */   public UserInfo getUserInfo() { return this.userinfo; }
/* 2260 */   public void setInputStream(InputStream in) { this.in = in; }
/* 2261 */   public void setOutputStream(OutputStream out) { this.out = out; }
/* 2262 */   public void setX11Host(String host) { ChannelX11.setHost(host); }
/* 2263 */   public void setX11Port(int port) { ChannelX11.setPort(port); }
/* 2264 */   public void setX11Cookie(String cookie) { ChannelX11.setCookie(cookie); }
/*      */   
/* 2266 */   public void setPassword(String password) { if (password != null)
/* 2267 */       this.password = Util.str2byte(password);
/*      */   }
/*      */   
/* 2270 */   public void setPassword(byte[] password) { if (password != null) {
/* 2271 */       this.password = new byte[password.length];
/* 2272 */       System.arraycopy(password, 0, this.password, 0, password.length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 2277 */   public void setConfig(Properties newconf) { setConfig(newconf); }
/*      */   
/*      */   public void setConfig(Hashtable newconf) {
/*      */     Enumeration e;
/* 2281 */     synchronized (this.lock) {
/* 2282 */       if (this.config == null)
/* 2283 */         this.config = new Hashtable();
/* 2284 */       for (e = newconf.keys(); e.hasMoreElements();) {
/* 2285 */         String key = (String)e.nextElement();
/* 2286 */         this.config.put(key, (String)newconf.get(key));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setConfig(String key, String value) {
/* 2292 */     synchronized (this.lock) {
/* 2293 */       if (this.config == null) {
/* 2294 */         this.config = new Hashtable();
/*      */       }
/* 2296 */       this.config.put(key, value);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getConfig(String key) {
/* 2301 */     Object foo = null;
/* 2302 */     if (this.config != null) {
/* 2303 */       foo = this.config.get(key);
/* 2304 */       if ((foo instanceof String)) return (String)foo;
/*      */     }
/* 2306 */     foo = JSch.getConfig(key);
/* 2307 */     if ((foo instanceof String)) return (String)foo;
/* 2308 */     return null;
/*      */   }
/*      */   
/*      */ 
/* 2312 */   public void setSocketFactory(SocketFactory sfactory) { this.socket_factory = sfactory; }
/*      */   
/* 2314 */   public boolean isConnected() { return this.isConnected; }
/* 2315 */   public int getTimeout() { return this.timeout; }
/*      */   
/* 2317 */   public void setTimeout(int timeout) throws JSchException { if (this.socket == null) {
/* 2318 */       if (timeout < 0) {
/* 2319 */         throw new JSchException("invalid timeout value");
/*      */       }
/* 2321 */       this.timeout = timeout;
/* 2322 */       return;
/*      */     }
/*      */     try {
/* 2325 */       this.socket.setSoTimeout(timeout);
/* 2326 */       this.timeout = timeout;
/*      */     }
/*      */     catch (Exception e) {
/* 2329 */       if ((e instanceof Throwable))
/* 2330 */         throw new JSchException(e.toString(), e);
/* 2331 */       throw new JSchException(e.toString());
/*      */     }
/*      */   }
/*      */   
/* 2335 */   public String getServerVersion() { return Util.byte2str(this.V_S); }
/*      */   
/*      */   public String getClientVersion() {
/* 2338 */     return Util.byte2str(this.V_C);
/*      */   }
/*      */   
/* 2341 */   public void setClientVersion(String cv) { this.V_C = Util.str2byte(cv); }
/*      */   
/*      */   public void sendIgnore() throws Exception
/*      */   {
/* 2345 */     Buffer buf = new Buffer();
/* 2346 */     Packet packet = new Packet(buf);
/* 2347 */     packet.reset();
/* 2348 */     buf.putByte((byte)2);
/* 2349 */     write(packet);
/*      */   }
/*      */   
/* 2352 */   private static final byte[] keepalivemsg = Util.str2byte("keepalive@jcraft.com");
/*      */   
/* 2354 */   public void sendKeepAliveMsg() throws Exception { Buffer buf = new Buffer();
/* 2355 */     Packet packet = new Packet(buf);
/* 2356 */     packet.reset();
/* 2357 */     buf.putByte((byte)80);
/* 2358 */     buf.putString(keepalivemsg);
/* 2359 */     buf.putByte((byte)1);
/* 2360 */     write(packet);
/*      */   }
/*      */   
/* 2363 */   private static final byte[] nomoresessions = Util.str2byte("no-more-sessions@openssh.com");
/*      */   
/* 2365 */   public void noMoreSessionChannels() throws Exception { Buffer buf = new Buffer();
/* 2366 */     Packet packet = new Packet(buf);
/* 2367 */     packet.reset();
/* 2368 */     buf.putByte((byte)80);
/* 2369 */     buf.putString(nomoresessions);
/* 2370 */     buf.putByte((byte)0);
/* 2371 */     write(packet);
/*      */   }
/*      */   
/* 2374 */   private HostKey hostkey = null;
/* 2375 */   public HostKey getHostKey() { return this.hostkey; }
/* 2376 */   public String getHost() { return this.host; }
/* 2377 */   public String getUserName() { return this.username; }
/* 2378 */   public int getPort() { return this.port; }
/*      */   
/* 2380 */   public void setHostKeyAlias(String hostKeyAlias) { this.hostKeyAlias = hostKeyAlias; }
/*      */   
/*      */   public String getHostKeyAlias() {
/* 2383 */     return this.hostKeyAlias;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerAliveInterval(int interval)
/*      */     throws JSchException
/*      */   {
/* 2395 */     setTimeout(interval);
/* 2396 */     this.serverAliveInterval = interval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getServerAliveInterval()
/*      */   {
/* 2405 */     return this.serverAliveInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerAliveCountMax(int count)
/*      */   {
/* 2418 */     this.serverAliveCountMax = count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getServerAliveCountMax()
/*      */   {
/* 2427 */     return this.serverAliveCountMax;
/*      */   }
/*      */   
/*      */   public void setDaemonThread(boolean enable) {
/* 2431 */     this.daemon_thread = enable;
/*      */   }
/*      */   
/*      */   private String[] checkCiphers(String ciphers) {
/* 2435 */     if ((ciphers == null) || (ciphers.length() == 0)) {
/* 2436 */       return null;
/*      */     }
/* 2438 */     if (JSch.getLogger().isEnabled(1)) {
/* 2439 */       JSch.getLogger().log(1, "CheckCiphers: " + ciphers);
/*      */     }
/*      */     
/*      */ 
/* 2443 */     Vector result = new Vector();
/* 2444 */     String[] _ciphers = Util.split(ciphers, ",");
/* 2445 */     for (int i = 0; i < _ciphers.length; i++) {
/* 2446 */       if (!checkCipher(getConfig(_ciphers[i]))) {
/* 2447 */         result.addElement(_ciphers[i]);
/*      */       }
/*      */     }
/* 2450 */     if (result.size() == 0)
/* 2451 */       return null;
/* 2452 */     String[] foo = new String[result.size()];
/* 2453 */     System.arraycopy(result.toArray(), 0, foo, 0, result.size());
/*      */     
/* 2455 */     if (JSch.getLogger().isEnabled(1)) {
/* 2456 */       for (int i = 0; i < foo.length; i++) {
/* 2457 */         JSch.getLogger().log(1, foo[i] + " is not available.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2462 */     return foo;
/*      */   }
/*      */   
/*      */   static boolean checkCipher(String cipher) {
/*      */     try {
/* 2467 */       Class c = Class.forName(cipher);
/* 2468 */       Cipher _c = (Cipher)c.newInstance();
/* 2469 */       _c.init(0, new byte[_c.getBlockSize()], new byte[_c.getIVSize()]);
/*      */       
/*      */ 
/* 2472 */       return true;
/*      */     }
/*      */     catch (Exception e) {}
/* 2475 */     return false;
/*      */   }
/*      */   
/*      */   private String[] checkKexes(String kexes)
/*      */   {
/* 2480 */     if ((kexes == null) || (kexes.length() == 0)) {
/* 2481 */       return null;
/*      */     }
/* 2483 */     if (JSch.getLogger().isEnabled(1)) {
/* 2484 */       JSch.getLogger().log(1, "CheckKexes: " + kexes);
/*      */     }
/*      */     
/*      */ 
/* 2488 */     Vector result = new Vector();
/* 2489 */     String[] _kexes = Util.split(kexes, ",");
/* 2490 */     for (int i = 0; i < _kexes.length; i++) {
/* 2491 */       if (!checkKex(this, getConfig(_kexes[i]))) {
/* 2492 */         result.addElement(_kexes[i]);
/*      */       }
/*      */     }
/* 2495 */     if (result.size() == 0)
/* 2496 */       return null;
/* 2497 */     String[] foo = new String[result.size()];
/* 2498 */     System.arraycopy(result.toArray(), 0, foo, 0, result.size());
/*      */     
/* 2500 */     if (JSch.getLogger().isEnabled(1)) {
/* 2501 */       for (int i = 0; i < foo.length; i++) {
/* 2502 */         JSch.getLogger().log(1, foo[i] + " is not available.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2507 */     return foo;
/*      */   }
/*      */   
/*      */   static boolean checkKex(Session s, String kex) {
/*      */     try {
/* 2512 */       Class c = Class.forName(kex);
/* 2513 */       KeyExchange _c = (KeyExchange)c.newInstance();
/* 2514 */       _c.init(s, null, null, null, null);
/* 2515 */       return true;
/*      */     } catch (Exception e) {}
/* 2517 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIdentityRepository(IdentityRepository identityRepository)
/*      */   {
/* 2528 */     this.identityRepository = identityRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   IdentityRepository getIdentityRepository()
/*      */   {
/* 2539 */     if (this.identityRepository == null)
/* 2540 */       return this.jsch.getIdentityRepository();
/* 2541 */     return this.identityRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostKeyRepository(HostKeyRepository hostkeyRepository)
/*      */   {
/* 2552 */     this.hostkeyRepository = hostkeyRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HostKeyRepository getHostKeyRepository()
/*      */   {
/* 2563 */     if (this.hostkeyRepository == null)
/* 2564 */       return this.jsch.getHostKeyRepository();
/* 2565 */     return this.hostkeyRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void applyConfig()
/*      */     throws JSchException
/*      */   {
/* 2609 */     ConfigRepository configRepository = this.jsch.getConfigRepository();
/* 2610 */     if (configRepository == null) {
/* 2611 */       return;
/*      */     }
/*      */     
/* 2614 */     ConfigRepository.Config config = configRepository.getConfig(this.org_host);
/*      */     
/*      */ 
/* 2617 */     String value = null;
/*      */     
/* 2619 */     value = config.getUser();
/* 2620 */     if (value != null) {
/* 2621 */       this.username = value;
/*      */     }
/* 2623 */     value = config.getHostname();
/* 2624 */     if (value != null) {
/* 2625 */       this.host = value;
/*      */     }
/* 2627 */     int port = config.getPort();
/* 2628 */     if (port != -1) {
/* 2629 */       this.port = port;
/*      */     }
/* 2631 */     checkConfig(config, "kex");
/* 2632 */     checkConfig(config, "server_host_key");
/*      */     
/* 2634 */     checkConfig(config, "cipher.c2s");
/* 2635 */     checkConfig(config, "cipher.s2c");
/* 2636 */     checkConfig(config, "mac.c2s");
/* 2637 */     checkConfig(config, "mac.s2c");
/* 2638 */     checkConfig(config, "compression.c2s");
/* 2639 */     checkConfig(config, "compression.s2c");
/* 2640 */     checkConfig(config, "compression_level");
/*      */     
/* 2642 */     checkConfig(config, "StrictHostKeyChecking");
/* 2643 */     checkConfig(config, "HashKnownHosts");
/* 2644 */     checkConfig(config, "PreferredAuthentications");
/* 2645 */     checkConfig(config, "MaxAuthTries");
/* 2646 */     checkConfig(config, "ClearAllForwardings");
/*      */     
/* 2648 */     value = config.getValue("HostKeyAlias");
/* 2649 */     if (value != null) {
/* 2650 */       setHostKeyAlias(value);
/*      */     }
/* 2652 */     value = config.getValue("UserKnownHostsFile");
/* 2653 */     if (value != null) {
/* 2654 */       KnownHosts kh = new KnownHosts(this.jsch);
/* 2655 */       kh.setKnownHosts(value);
/* 2656 */       setHostKeyRepository(kh);
/*      */     }
/*      */     
/* 2659 */     String[] values = config.getValues("IdentityFile");
/* 2660 */     if (values != null) {
/* 2661 */       String[] global = configRepository.getConfig("").getValues("IdentityFile");
/*      */       
/* 2663 */       if (global != null) {
/* 2664 */         for (int i = 0; i < global.length; i++) {
/* 2665 */           this.jsch.addIdentity(global[i]);
/*      */         }
/*      */         
/*      */       } else {
/* 2669 */         global = new String[0];
/*      */       }
/* 2671 */       if (values.length - global.length > 0) {
/* 2672 */         IdentityRepository.Wrapper ir = new IdentityRepository.Wrapper(this.jsch.getIdentityRepository(), true);
/*      */         
/* 2674 */         for (int i = 0; i < values.length; i++) {
/* 2675 */           String ifile = values[i];
/* 2676 */           for (int j = 0; j < global.length; j++)
/* 2677 */             if (ifile.equals(global[j]))
/*      */             {
/* 2679 */               ifile = null;
/* 2680 */               break;
/*      */             }
/* 2682 */           if (ifile != null)
/*      */           {
/* 2684 */             Identity identity = IdentityFile.newInstance(ifile, null, this.jsch);
/*      */             
/* 2686 */             ir.add(identity);
/*      */           } }
/* 2688 */         setIdentityRepository(ir);
/*      */       }
/*      */     }
/*      */     
/* 2692 */     value = config.getValue("ServerAliveInterval");
/* 2693 */     if (value != null) {
/*      */       try {
/* 2695 */         setServerAliveInterval(Integer.parseInt(value));
/*      */       }
/*      */       catch (NumberFormatException e) {}
/*      */     }
/*      */     
/*      */ 
/* 2701 */     value = config.getValue("ConnectTimeout");
/* 2702 */     if (value != null) {
/*      */       try {
/* 2704 */         setTimeout(Integer.parseInt(value));
/*      */       }
/*      */       catch (NumberFormatException e) {}
/*      */     }
/*      */     
/*      */ 
/* 2710 */     value = config.getValue("MaxAuthTries");
/* 2711 */     if (value != null) {
/* 2712 */       setConfig("MaxAuthTries", value);
/*      */     }
/*      */     
/* 2715 */     value = config.getValue("ClearAllForwardings");
/* 2716 */     if (value != null) {
/* 2717 */       setConfig("ClearAllForwardings", value);
/*      */     }
/*      */   }
/*      */   
/*      */   private void applyConfigChannel(ChannelSession channel) throws JSchException
/*      */   {
/* 2723 */     ConfigRepository configRepository = this.jsch.getConfigRepository();
/* 2724 */     if (configRepository == null) {
/* 2725 */       return;
/*      */     }
/*      */     
/* 2728 */     ConfigRepository.Config config = configRepository.getConfig(this.org_host);
/*      */     
/*      */ 
/* 2731 */     String value = null;
/*      */     
/* 2733 */     value = config.getValue("ForwardAgent");
/* 2734 */     if (value != null) {
/* 2735 */       channel.setAgentForwarding(value.equals("yes"));
/*      */     }
/*      */     
/* 2738 */     value = config.getValue("RequestTTY");
/* 2739 */     if (value != null) {
/* 2740 */       channel.setPty(value.equals("yes"));
/*      */     }
/*      */   }
/*      */   
/*      */   private void requestPortForwarding() throws JSchException
/*      */   {
/* 2746 */     if (getConfig("ClearAllForwardings").equals("yes")) {
/* 2747 */       return;
/*      */     }
/* 2749 */     ConfigRepository configRepository = this.jsch.getConfigRepository();
/* 2750 */     if (configRepository == null) {
/* 2751 */       return;
/*      */     }
/*      */     
/* 2754 */     ConfigRepository.Config config = configRepository.getConfig(this.org_host);
/*      */     
/*      */ 
/* 2757 */     String[] values = config.getValues("LocalForward");
/* 2758 */     if (values != null) {
/* 2759 */       for (int i = 0; i < values.length; i++) {
/* 2760 */         setPortForwardingL(values[i]);
/*      */       }
/*      */     }
/*      */     
/* 2764 */     values = config.getValues("RemoteForward");
/* 2765 */     if (values != null) {
/* 2766 */       for (int i = 0; i < values.length; i++) {
/* 2767 */         setPortForwardingR(values[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkConfig(ConfigRepository.Config config, String key) {
/* 2773 */     String value = config.getValue(key);
/* 2774 */     if (value != null) {
/* 2775 */       setConfig(key, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\Session.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */