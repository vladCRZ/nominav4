/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SftpException
/*    */   extends Exception
/*    */ {
/*    */   public int id;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 35 */   private Throwable cause = null;
/*    */   
/* 37 */   public SftpException(int id, String message) { super(message);
/* 38 */     this.id = id;
/*    */   }
/*    */   
/* 41 */   public SftpException(int id, String message, Throwable e) { super(message);
/* 42 */     this.id = id;
/* 43 */     this.cause = e;
/*    */   }
/*    */   
/* 46 */   public String toString() { return this.id + ": " + getMessage(); }
/*    */   
/*    */   public Throwable getCause() {
/* 49 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\SftpException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */