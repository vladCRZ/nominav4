/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SftpStatVFS
/*     */ {
/*     */   private long bsize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private long frsize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long blocks;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long bfree;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long bavail;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long files;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long ffree;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long favail;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long fsid;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long flag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long namemax;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   int flags = 0;
/*     */   long size;
/*     */   int uid;
/*     */   int gid;
/*     */   int permissions;
/*     */   int atime;
/*     */   int mtime;
/*  73 */   String[] extended = null;
/*     */   
/*     */ 
/*     */ 
/*     */   static SftpStatVFS getStatVFS(Buffer buf)
/*     */   {
/*  79 */     SftpStatVFS statvfs = new SftpStatVFS();
/*     */     
/*  81 */     statvfs.bsize = buf.getLong();
/*  82 */     statvfs.frsize = buf.getLong();
/*  83 */     statvfs.blocks = buf.getLong();
/*  84 */     statvfs.bfree = buf.getLong();
/*  85 */     statvfs.bavail = buf.getLong();
/*  86 */     statvfs.files = buf.getLong();
/*  87 */     statvfs.ffree = buf.getLong();
/*  88 */     statvfs.favail = buf.getLong();
/*  89 */     statvfs.fsid = buf.getLong();
/*  90 */     int flag = (int)buf.getLong();
/*  91 */     statvfs.namemax = buf.getLong();
/*     */     
/*  93 */     statvfs.flag = ((flag & 0x1) != 0 ? 1L : 0L);
/*     */     
/*  95 */     statvfs.flag |= ((flag & 0x2) != 0 ? 2L : 0L);
/*     */     
/*     */ 
/*  98 */     return statvfs;
/*     */   }
/*     */   
/* 101 */   public long getBlockSize() { return this.bsize; }
/* 102 */   public long getFragmentSize() { return this.frsize; }
/* 103 */   public long getBlocks() { return this.blocks; }
/* 104 */   public long getFreeBlocks() { return this.bfree; }
/* 105 */   public long getAvailBlocks() { return this.bavail; }
/* 106 */   public long getINodes() { return this.files; }
/* 107 */   public long getFreeINodes() { return this.ffree; }
/* 108 */   public long getAvailINodes() { return this.favail; }
/* 109 */   public long getFileSystemID() { return this.fsid; }
/* 110 */   public long getMountFlag() { return this.flag; }
/* 111 */   public long getMaximumFilenameLength() { return this.namemax; }
/*     */   
/*     */   public long getSize() {
/* 114 */     return getFragmentSize() * getBlocks() / 1024L;
/*     */   }
/*     */   
/*     */   public long getUsed() {
/* 118 */     return getFragmentSize() * (getBlocks() - getFreeBlocks()) / 1024L;
/*     */   }
/*     */   
/*     */   public long getAvailForNonRoot() {
/* 122 */     return getFragmentSize() * getAvailBlocks() / 1024L;
/*     */   }
/*     */   
/*     */   public long getAvail() {
/* 126 */     return getFragmentSize() * getFreeBlocks() / 1024L;
/*     */   }
/*     */   
/*     */   public int getCapacity() {
/* 130 */     return (int)(100L * (getBlocks() - getFreeBlocks()) / getBlocks());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\SftpStatVFS.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */