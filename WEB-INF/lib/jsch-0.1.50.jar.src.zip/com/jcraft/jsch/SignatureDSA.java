package com.jcraft.jsch;

public abstract interface SignatureDSA
  extends Signature
{
  public abstract void setPubKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
    throws Exception;
  
  public abstract void setPrvKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
    throws Exception;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\SignatureDSA.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */