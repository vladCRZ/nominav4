package com.jcraft.jsch;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public abstract interface SocketFactory
{
  public abstract Socket createSocket(String paramString, int paramInt)
    throws IOException, UnknownHostException;
  
  public abstract InputStream getInputStream(Socket paramSocket)
    throws IOException;
  
  public abstract OutputStream getOutputStream(Socket paramSocket)
    throws IOException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\SocketFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */