/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UserAuthPassword
/*    */   extends UserAuth
/*    */ {
/* 33 */   private final int SSH_MSG_USERAUTH_PASSWD_CHANGEREQ = 60;
/*    */   
/*    */   /* Error */
/*    */   public boolean start(Session session)
/*    */     throws java.lang.Exception
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: invokespecial 3	com/jcraft/jsch/UserAuth:start	(Lcom/jcraft/jsch/Session;)Z
/*    */     //   5: pop
/*    */     //   6: aload_1
/*    */     //   7: getfield 4	com/jcraft/jsch/Session:password	[B
/*    */     //   10: astore_2
/*    */     //   11: new 5	java/lang/StringBuffer
/*    */     //   14: dup
/*    */     //   15: invokespecial 6	java/lang/StringBuffer:<init>	()V
/*    */     //   18: aload_0
/*    */     //   19: getfield 7	com/jcraft/jsch/UserAuthPassword:username	Ljava/lang/String;
/*    */     //   22: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   25: ldc 9
/*    */     //   27: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   30: aload_1
/*    */     //   31: getfield 10	com/jcraft/jsch/Session:host	Ljava/lang/String;
/*    */     //   34: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   37: invokevirtual 11	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*    */     //   40: astore_3
/*    */     //   41: aload_1
/*    */     //   42: getfield 12	com/jcraft/jsch/Session:port	I
/*    */     //   45: bipush 22
/*    */     //   47: if_icmpeq +30 -> 77
/*    */     //   50: new 5	java/lang/StringBuffer
/*    */     //   53: dup
/*    */     //   54: invokespecial 6	java/lang/StringBuffer:<init>	()V
/*    */     //   57: aload_3
/*    */     //   58: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   61: ldc 13
/*    */     //   63: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   66: aload_1
/*    */     //   67: getfield 12	com/jcraft/jsch/Session:port	I
/*    */     //   70: invokevirtual 14	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*    */     //   73: invokevirtual 11	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*    */     //   76: astore_3
/*    */     //   77: aload_1
/*    */     //   78: getfield 15	com/jcraft/jsch/Session:auth_failures	I
/*    */     //   81: aload_1
/*    */     //   82: getfield 16	com/jcraft/jsch/Session:max_auth_tries	I
/*    */     //   85: if_icmplt +19 -> 104
/*    */     //   88: iconst_0
/*    */     //   89: istore 4
/*    */     //   91: aload_2
/*    */     //   92: ifnull +9 -> 101
/*    */     //   95: aload_2
/*    */     //   96: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   99: aconst_null
/*    */     //   100: astore_2
/*    */     //   101: iload 4
/*    */     //   103: ireturn
/*    */     //   104: aload_2
/*    */     //   105: ifnonnull +99 -> 204
/*    */     //   108: aload_0
/*    */     //   109: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   112: ifnonnull +19 -> 131
/*    */     //   115: iconst_0
/*    */     //   116: istore 4
/*    */     //   118: aload_2
/*    */     //   119: ifnull +9 -> 128
/*    */     //   122: aload_2
/*    */     //   123: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   126: aconst_null
/*    */     //   127: astore_2
/*    */     //   128: iload 4
/*    */     //   130: ireturn
/*    */     //   131: aload_0
/*    */     //   132: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   135: new 5	java/lang/StringBuffer
/*    */     //   138: dup
/*    */     //   139: invokespecial 6	java/lang/StringBuffer:<init>	()V
/*    */     //   142: ldc 19
/*    */     //   144: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   147: aload_3
/*    */     //   148: invokevirtual 8	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   151: invokevirtual 11	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*    */     //   154: invokeinterface 20 2 0
/*    */     //   159: ifne +13 -> 172
/*    */     //   162: new 21	com/jcraft/jsch/JSchAuthCancelException
/*    */     //   165: dup
/*    */     //   166: ldc 22
/*    */     //   168: invokespecial 23	com/jcraft/jsch/JSchAuthCancelException:<init>	(Ljava/lang/String;)V
/*    */     //   171: athrow
/*    */     //   172: aload_0
/*    */     //   173: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   176: invokeinterface 24 1 0
/*    */     //   181: astore 4
/*    */     //   183: aload 4
/*    */     //   185: ifnonnull +13 -> 198
/*    */     //   188: new 21	com/jcraft/jsch/JSchAuthCancelException
/*    */     //   191: dup
/*    */     //   192: ldc 22
/*    */     //   194: invokespecial 23	com/jcraft/jsch/JSchAuthCancelException:<init>	(Ljava/lang/String;)V
/*    */     //   197: athrow
/*    */     //   198: aload 4
/*    */     //   200: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   203: astore_2
/*    */     //   204: aconst_null
/*    */     //   205: astore 4
/*    */     //   207: aload_0
/*    */     //   208: getfield 7	com/jcraft/jsch/UserAuthPassword:username	Ljava/lang/String;
/*    */     //   211: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   214: astore 4
/*    */     //   216: aload_0
/*    */     //   217: getfield 26	com/jcraft/jsch/UserAuthPassword:packet	Lcom/jcraft/jsch/Packet;
/*    */     //   220: invokevirtual 27	com/jcraft/jsch/Packet:reset	()V
/*    */     //   223: aload_0
/*    */     //   224: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   227: bipush 50
/*    */     //   229: invokevirtual 29	com/jcraft/jsch/Buffer:putByte	(B)V
/*    */     //   232: aload_0
/*    */     //   233: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   236: aload 4
/*    */     //   238: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   241: aload_0
/*    */     //   242: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   245: ldc 31
/*    */     //   247: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   250: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   253: aload_0
/*    */     //   254: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   257: ldc 22
/*    */     //   259: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   262: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   265: aload_0
/*    */     //   266: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   269: iconst_0
/*    */     //   270: invokevirtual 29	com/jcraft/jsch/Buffer:putByte	(B)V
/*    */     //   273: aload_0
/*    */     //   274: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   277: aload_2
/*    */     //   278: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   281: aload_1
/*    */     //   282: aload_0
/*    */     //   283: getfield 26	com/jcraft/jsch/UserAuthPassword:packet	Lcom/jcraft/jsch/Packet;
/*    */     //   286: invokevirtual 32	com/jcraft/jsch/Session:write	(Lcom/jcraft/jsch/Packet;)V
/*    */     //   289: aload_0
/*    */     //   290: aload_1
/*    */     //   291: aload_0
/*    */     //   292: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   295: invokevirtual 33	com/jcraft/jsch/Session:read	(Lcom/jcraft/jsch/Buffer;)Lcom/jcraft/jsch/Buffer;
/*    */     //   298: putfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   301: aload_0
/*    */     //   302: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   305: invokevirtual 34	com/jcraft/jsch/Buffer:getCommand	()B
/*    */     //   308: sipush 255
/*    */     //   311: iand
/*    */     //   312: istore 5
/*    */     //   314: iload 5
/*    */     //   316: bipush 52
/*    */     //   318: if_icmpne +19 -> 337
/*    */     //   321: iconst_1
/*    */     //   322: istore 6
/*    */     //   324: aload_2
/*    */     //   325: ifnull +9 -> 334
/*    */     //   328: aload_2
/*    */     //   329: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   332: aconst_null
/*    */     //   333: astore_2
/*    */     //   334: iload 6
/*    */     //   336: ireturn
/*    */     //   337: iload 5
/*    */     //   339: bipush 53
/*    */     //   341: if_icmpne +73 -> 414
/*    */     //   344: aload_0
/*    */     //   345: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   348: invokevirtual 35	com/jcraft/jsch/Buffer:getInt	()I
/*    */     //   351: pop
/*    */     //   352: aload_0
/*    */     //   353: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   356: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   359: pop
/*    */     //   360: aload_0
/*    */     //   361: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   364: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   367: pop
/*    */     //   368: aload_0
/*    */     //   369: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   372: invokevirtual 37	com/jcraft/jsch/Buffer:getString	()[B
/*    */     //   375: astore 6
/*    */     //   377: aload_0
/*    */     //   378: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   381: invokevirtual 37	com/jcraft/jsch/Buffer:getString	()[B
/*    */     //   384: astore 7
/*    */     //   386: aload 6
/*    */     //   388: invokestatic 38	com/jcraft/jsch/Util:byte2str	([B)Ljava/lang/String;
/*    */     //   391: astore 8
/*    */     //   393: aload_0
/*    */     //   394: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   397: ifnull -108 -> 289
/*    */     //   400: aload_0
/*    */     //   401: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   404: aload 8
/*    */     //   406: invokeinterface 39 2 0
/*    */     //   411: goto -122 -> 289
/*    */     //   414: iload 5
/*    */     //   416: bipush 60
/*    */     //   418: if_icmpne +267 -> 685
/*    */     //   421: aload_0
/*    */     //   422: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   425: invokevirtual 35	com/jcraft/jsch/Buffer:getInt	()I
/*    */     //   428: pop
/*    */     //   429: aload_0
/*    */     //   430: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   433: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   436: pop
/*    */     //   437: aload_0
/*    */     //   438: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   441: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   444: pop
/*    */     //   445: aload_0
/*    */     //   446: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   449: invokevirtual 37	com/jcraft/jsch/Buffer:getString	()[B
/*    */     //   452: astore 6
/*    */     //   454: aload_0
/*    */     //   455: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   458: invokevirtual 37	com/jcraft/jsch/Buffer:getString	()[B
/*    */     //   461: astore 7
/*    */     //   463: aload_0
/*    */     //   464: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   467: ifnull +13 -> 480
/*    */     //   470: aload_0
/*    */     //   471: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   474: instanceof 40
/*    */     //   477: ifne +37 -> 514
/*    */     //   480: aload_0
/*    */     //   481: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   484: ifnull +14 -> 498
/*    */     //   487: aload_0
/*    */     //   488: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   491: ldc 41
/*    */     //   493: invokeinterface 39 2 0
/*    */     //   498: iconst_0
/*    */     //   499: istore 8
/*    */     //   501: aload_2
/*    */     //   502: ifnull +9 -> 511
/*    */     //   505: aload_2
/*    */     //   506: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   509: aconst_null
/*    */     //   510: astore_2
/*    */     //   511: iload 8
/*    */     //   513: ireturn
/*    */     //   514: aload_0
/*    */     //   515: getfield 18	com/jcraft/jsch/UserAuthPassword:userinfo	Lcom/jcraft/jsch/UserInfo;
/*    */     //   518: checkcast 40	com/jcraft/jsch/UIKeyboardInteractive
/*    */     //   521: astore 8
/*    */     //   523: ldc 42
/*    */     //   525: astore 10
/*    */     //   527: iconst_1
/*    */     //   528: anewarray 43	java/lang/String
/*    */     //   531: dup
/*    */     //   532: iconst_0
/*    */     //   533: ldc 44
/*    */     //   535: aastore
/*    */     //   536: astore 11
/*    */     //   538: iconst_1
/*    */     //   539: newarray <illegal type>
/*    */     //   541: dup
/*    */     //   542: iconst_0
/*    */     //   543: iconst_0
/*    */     //   544: bastore
/*    */     //   545: astore 12
/*    */     //   547: aload 8
/*    */     //   549: aload_3
/*    */     //   550: aload 10
/*    */     //   552: aload 6
/*    */     //   554: invokestatic 38	com/jcraft/jsch/Util:byte2str	([B)Ljava/lang/String;
/*    */     //   557: aload 11
/*    */     //   559: aload 12
/*    */     //   561: invokeinterface 45 6 0
/*    */     //   566: astore 9
/*    */     //   568: aload 9
/*    */     //   570: ifnonnull +13 -> 583
/*    */     //   573: new 21	com/jcraft/jsch/JSchAuthCancelException
/*    */     //   576: dup
/*    */     //   577: ldc 22
/*    */     //   579: invokespecial 23	com/jcraft/jsch/JSchAuthCancelException:<init>	(Ljava/lang/String;)V
/*    */     //   582: athrow
/*    */     //   583: aload 9
/*    */     //   585: iconst_0
/*    */     //   586: aaload
/*    */     //   587: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   590: astore 13
/*    */     //   592: aload_0
/*    */     //   593: getfield 26	com/jcraft/jsch/UserAuthPassword:packet	Lcom/jcraft/jsch/Packet;
/*    */     //   596: invokevirtual 27	com/jcraft/jsch/Packet:reset	()V
/*    */     //   599: aload_0
/*    */     //   600: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   603: bipush 50
/*    */     //   605: invokevirtual 29	com/jcraft/jsch/Buffer:putByte	(B)V
/*    */     //   608: aload_0
/*    */     //   609: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   612: aload 4
/*    */     //   614: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   617: aload_0
/*    */     //   618: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   621: ldc 31
/*    */     //   623: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   626: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   629: aload_0
/*    */     //   630: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   633: ldc 22
/*    */     //   635: invokestatic 25	com/jcraft/jsch/Util:str2byte	(Ljava/lang/String;)[B
/*    */     //   638: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   641: aload_0
/*    */     //   642: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   645: iconst_1
/*    */     //   646: invokevirtual 29	com/jcraft/jsch/Buffer:putByte	(B)V
/*    */     //   649: aload_0
/*    */     //   650: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   653: aload_2
/*    */     //   654: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   657: aload_0
/*    */     //   658: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   661: aload 13
/*    */     //   663: invokevirtual 30	com/jcraft/jsch/Buffer:putString	([B)V
/*    */     //   666: aload 13
/*    */     //   668: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   671: aconst_null
/*    */     //   672: astore 9
/*    */     //   674: aload_1
/*    */     //   675: aload_0
/*    */     //   676: getfield 26	com/jcraft/jsch/UserAuthPassword:packet	Lcom/jcraft/jsch/Packet;
/*    */     //   679: invokevirtual 32	com/jcraft/jsch/Session:write	(Lcom/jcraft/jsch/Packet;)V
/*    */     //   682: goto -393 -> 289
/*    */     //   685: iload 5
/*    */     //   687: bipush 51
/*    */     //   689: if_icmpne +76 -> 765
/*    */     //   692: aload_0
/*    */     //   693: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   696: invokevirtual 35	com/jcraft/jsch/Buffer:getInt	()I
/*    */     //   699: pop
/*    */     //   700: aload_0
/*    */     //   701: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   704: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   707: pop
/*    */     //   708: aload_0
/*    */     //   709: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   712: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   715: pop
/*    */     //   716: aload_0
/*    */     //   717: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   720: invokevirtual 37	com/jcraft/jsch/Buffer:getString	()[B
/*    */     //   723: astore 6
/*    */     //   725: aload_0
/*    */     //   726: getfield 28	com/jcraft/jsch/UserAuthPassword:buf	Lcom/jcraft/jsch/Buffer;
/*    */     //   729: invokevirtual 36	com/jcraft/jsch/Buffer:getByte	()I
/*    */     //   732: istore 7
/*    */     //   734: iload 7
/*    */     //   736: ifeq +16 -> 752
/*    */     //   739: new 46	com/jcraft/jsch/JSchPartialAuthException
/*    */     //   742: dup
/*    */     //   743: aload 6
/*    */     //   745: invokestatic 38	com/jcraft/jsch/Util:byte2str	([B)Ljava/lang/String;
/*    */     //   748: invokespecial 47	com/jcraft/jsch/JSchPartialAuthException:<init>	(Ljava/lang/String;)V
/*    */     //   751: athrow
/*    */     //   752: aload_1
/*    */     //   753: dup
/*    */     //   754: getfield 15	com/jcraft/jsch/Session:auth_failures	I
/*    */     //   757: iconst_1
/*    */     //   758: iadd
/*    */     //   759: putfield 15	com/jcraft/jsch/Session:auth_failures	I
/*    */     //   762: goto +19 -> 781
/*    */     //   765: iconst_0
/*    */     //   766: istore 6
/*    */     //   768: aload_2
/*    */     //   769: ifnull +9 -> 778
/*    */     //   772: aload_2
/*    */     //   773: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   776: aconst_null
/*    */     //   777: astore_2
/*    */     //   778: iload 6
/*    */     //   780: ireturn
/*    */     //   781: aload_2
/*    */     //   782: ifnull +9 -> 791
/*    */     //   785: aload_2
/*    */     //   786: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   789: aconst_null
/*    */     //   790: astore_2
/*    */     //   791: goto -714 -> 77
/*    */     //   794: astore 14
/*    */     //   796: aload_2
/*    */     //   797: ifnull +9 -> 806
/*    */     //   800: aload_2
/*    */     //   801: invokestatic 17	com/jcraft/jsch/Util:bzero	([B)V
/*    */     //   804: aconst_null
/*    */     //   805: astore_2
/*    */     //   806: aload 14
/*    */     //   808: athrow
/*    */     // Line number table:
/*    */     //   Java source line #36	-> byte code offset #0
/*    */     //   Java source line #38	-> byte code offset #6
/*    */     //   Java source line #39	-> byte code offset #11
/*    */     //   Java source line #40	-> byte code offset #41
/*    */     //   Java source line #41	-> byte code offset #50
/*    */     //   Java source line #48	-> byte code offset #77
/*    */     //   Java source line #49	-> byte code offset #88
/*    */     //   Java source line #184	-> byte code offset #91
/*    */     //   Java source line #185	-> byte code offset #95
/*    */     //   Java source line #186	-> byte code offset #99
/*    */     //   Java source line #52	-> byte code offset #104
/*    */     //   Java source line #53	-> byte code offset #108
/*    */     //   Java source line #55	-> byte code offset #115
/*    */     //   Java source line #184	-> byte code offset #118
/*    */     //   Java source line #185	-> byte code offset #122
/*    */     //   Java source line #186	-> byte code offset #126
/*    */     //   Java source line #57	-> byte code offset #131
/*    */     //   Java source line #58	-> byte code offset #162
/*    */     //   Java source line #62	-> byte code offset #172
/*    */     //   Java source line #63	-> byte code offset #183
/*    */     //   Java source line #64	-> byte code offset #188
/*    */     //   Java source line #67	-> byte code offset #198
/*    */     //   Java source line #70	-> byte code offset #204
/*    */     //   Java source line #71	-> byte code offset #207
/*    */     //   Java source line #80	-> byte code offset #216
/*    */     //   Java source line #81	-> byte code offset #223
/*    */     //   Java source line #82	-> byte code offset #232
/*    */     //   Java source line #83	-> byte code offset #241
/*    */     //   Java source line #84	-> byte code offset #253
/*    */     //   Java source line #85	-> byte code offset #265
/*    */     //   Java source line #86	-> byte code offset #273
/*    */     //   Java source line #87	-> byte code offset #281
/*    */     //   Java source line #91	-> byte code offset #289
/*    */     //   Java source line #92	-> byte code offset #301
/*    */     //   Java source line #94	-> byte code offset #314
/*    */     //   Java source line #95	-> byte code offset #321
/*    */     //   Java source line #184	-> byte code offset #324
/*    */     //   Java source line #185	-> byte code offset #328
/*    */     //   Java source line #186	-> byte code offset #332
/*    */     //   Java source line #97	-> byte code offset #337
/*    */     //   Java source line #98	-> byte code offset #344
/*    */     //   Java source line #99	-> byte code offset #368
/*    */     //   Java source line #100	-> byte code offset #377
/*    */     //   Java source line #101	-> byte code offset #386
/*    */     //   Java source line #102	-> byte code offset #393
/*    */     //   Java source line #103	-> byte code offset #400
/*    */     //   Java source line #107	-> byte code offset #414
/*    */     //   Java source line #108	-> byte code offset #421
/*    */     //   Java source line #109	-> byte code offset #445
/*    */     //   Java source line #110	-> byte code offset #454
/*    */     //   Java source line #111	-> byte code offset #463
/*    */     //   Java source line #113	-> byte code offset #480
/*    */     //   Java source line #114	-> byte code offset #487
/*    */     //   Java source line #116	-> byte code offset #498
/*    */     //   Java source line #184	-> byte code offset #501
/*    */     //   Java source line #185	-> byte code offset #505
/*    */     //   Java source line #186	-> byte code offset #509
/*    */     //   Java source line #119	-> byte code offset #514
/*    */     //   Java source line #121	-> byte code offset #523
/*    */     //   Java source line #122	-> byte code offset #527
/*    */     //   Java source line #123	-> byte code offset #538
/*    */     //   Java source line #124	-> byte code offset #547
/*    */     //   Java source line #129	-> byte code offset #568
/*    */     //   Java source line #130	-> byte code offset #573
/*    */     //   Java source line #133	-> byte code offset #583
/*    */     //   Java source line #143	-> byte code offset #592
/*    */     //   Java source line #144	-> byte code offset #599
/*    */     //   Java source line #145	-> byte code offset #608
/*    */     //   Java source line #146	-> byte code offset #617
/*    */     //   Java source line #147	-> byte code offset #629
/*    */     //   Java source line #148	-> byte code offset #641
/*    */     //   Java source line #149	-> byte code offset #649
/*    */     //   Java source line #150	-> byte code offset #657
/*    */     //   Java source line #151	-> byte code offset #666
/*    */     //   Java source line #152	-> byte code offset #671
/*    */     //   Java source line #153	-> byte code offset #674
/*    */     //   Java source line #154	-> byte code offset #682
/*    */     //   Java source line #156	-> byte code offset #685
/*    */     //   Java source line #157	-> byte code offset #692
/*    */     //   Java source line #158	-> byte code offset #716
/*    */     //   Java source line #159	-> byte code offset #725
/*    */     //   Java source line #162	-> byte code offset #734
/*    */     //   Java source line #163	-> byte code offset #739
/*    */     //   Java source line #165	-> byte code offset #752
/*    */     //   Java source line #166	-> byte code offset #762
/*    */     //   Java source line #171	-> byte code offset #765
/*    */     //   Java source line #184	-> byte code offset #768
/*    */     //   Java source line #185	-> byte code offset #772
/*    */     //   Java source line #186	-> byte code offset #776
/*    */     //   Java source line #175	-> byte code offset #781
/*    */     //   Java source line #176	-> byte code offset #785
/*    */     //   Java source line #177	-> byte code offset #789
/*    */     //   Java source line #180	-> byte code offset #791
/*    */     //   Java source line #184	-> byte code offset #794
/*    */     //   Java source line #185	-> byte code offset #800
/*    */     //   Java source line #186	-> byte code offset #804
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	809	0	this	UserAuthPassword
/*    */     //   0	809	1	session	Session
/*    */     //   10	796	2	password	byte[]
/*    */     //   40	510	3	dest	String
/*    */     //   89	40	4	bool1	boolean
/*    */     //   181	18	4	_password	String
/*    */     //   205	408	4	_username	byte[]
/*    */     //   312	374	5	command	int
/*    */     //   322	13	6	bool2	boolean
/*    */     //   375	12	6	_message	byte[]
/*    */     //   452	101	6	instruction	byte[]
/*    */     //   723	56	6	foo	byte[]
/*    */     //   766	13	6	bool3	boolean
/*    */     //   384	3	7	lang	byte[]
/*    */     //   461	3	7	tag	byte[]
/*    */     //   732	3	7	partial_success	int
/*    */     //   391	121	8	message	String
/*    */     //   521	27	8	kbi	UIKeyboardInteractive
/*    */     //   566	107	9	response	String[]
/*    */     //   525	26	10	name	String
/*    */     //   536	22	11	prompt	String[]
/*    */     //   545	15	12	echo	boolean[]
/*    */     //   590	77	13	newpassword	byte[]
/*    */     //   794	13	14	localObject	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   77	91	794	finally
/*    */     //   104	118	794	finally
/*    */     //   131	324	794	finally
/*    */     //   337	501	794	finally
/*    */     //   514	768	794	finally
/*    */     //   781	796	794	finally
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\UserAuthPassword.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */