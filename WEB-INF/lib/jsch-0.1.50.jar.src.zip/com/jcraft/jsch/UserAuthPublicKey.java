/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UserAuthPublicKey
/*     */   extends UserAuth
/*     */ {
/*     */   public boolean start(Session session)
/*     */     throws Exception
/*     */   {
/*  37 */     super.start(session);
/*     */     
/*  39 */     Vector identities = session.getIdentityRepository().getIdentities();
/*     */     
/*  41 */     byte[] passphrase = null;
/*  42 */     byte[] _username = null;
/*     */     
/*     */ 
/*     */ 
/*  46 */     synchronized (identities) {
/*  47 */       if (identities.size() <= 0) {
/*  48 */         return false;
/*     */       }
/*     */       
/*  51 */       _username = Util.str2byte(this.username);
/*     */       
/*  53 */       for (int i = 0; i < identities.size(); i++)
/*     */       {
/*  55 */         if (session.auth_failures >= session.max_auth_tries) {
/*  56 */           return false;
/*     */         }
/*     */         
/*  59 */         Identity identity = (Identity)identities.elementAt(i);
/*  60 */         byte[] pubkeyblob = identity.getPublicKeyBlob();
/*     */         
/*  62 */         if (pubkeyblob != null)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */           this.packet.reset();
/*  71 */           this.buf.putByte((byte)50);
/*  72 */           this.buf.putString(_username);
/*  73 */           this.buf.putString(Util.str2byte("ssh-connection"));
/*  74 */           this.buf.putString(Util.str2byte("publickey"));
/*  75 */           this.buf.putByte((byte)0);
/*  76 */           this.buf.putString(Util.str2byte(identity.getAlgName()));
/*  77 */           this.buf.putString(pubkeyblob);
/*  78 */           session.write(this.packet);
/*     */           int command;
/*     */           for (;;)
/*     */           {
/*  82 */             this.buf = session.read(this.buf);
/*  83 */             command = this.buf.getCommand() & 0xFF;
/*     */             
/*  85 */             if (command == 60) {
/*     */               break;
/*     */             }
/*  88 */             if (command == 51) {
/*     */               break;
/*     */             }
/*  91 */             if (command != 53) break;
/*  92 */             this.buf.getInt();this.buf.getByte();this.buf.getByte();
/*  93 */             byte[] _message = this.buf.getString();
/*  94 */             byte[] lang = this.buf.getString();
/*  95 */             String message = Util.byte2str(_message);
/*  96 */             if (this.userinfo != null) {
/*  97 */               this.userinfo.showMessage(message);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */           if (command != 60) {}
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 115 */           int count = 5;
/*     */           for (;;) {
/* 117 */             if ((identity.isEncrypted()) && (passphrase == null)) {
/* 118 */               if (this.userinfo == null) throw new JSchException("USERAUTH fail");
/* 119 */               if ((identity.isEncrypted()) && (!this.userinfo.promptPassphrase("Passphrase for " + identity.getName())))
/*     */               {
/* 121 */                 throw new JSchAuthCancelException("publickey");
/*     */               }
/*     */               
/*     */ 
/* 125 */               String _passphrase = this.userinfo.getPassphrase();
/* 126 */               if (_passphrase != null) {
/* 127 */                 passphrase = Util.str2byte(_passphrase);
/*     */               }
/*     */             }
/*     */             
/* 131 */             if (((!identity.isEncrypted()) || (passphrase != null)) && 
/* 132 */               (identity.setPassphrase(passphrase))) {
/* 133 */               if ((passphrase != null) && ((session.getIdentityRepository() instanceof IdentityRepository.Wrapper)))
/*     */               {
/* 135 */                 ((IdentityRepository.Wrapper)session.getIdentityRepository()).check();
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 140 */               Util.bzero(passphrase);
/* 141 */               passphrase = null;
/* 142 */               count--;
/* 143 */               if (count == 0) break;
/*     */             }
/*     */           }
/* 146 */           Util.bzero(passphrase);
/* 147 */           passphrase = null;
/*     */           
/*     */ 
/* 150 */           if (!identity.isEncrypted()) {
/* 151 */             if (pubkeyblob == null) { pubkeyblob = identity.getPublicKeyBlob();
/*     */             }
/*     */             
/*     */ 
/* 155 */             if (pubkeyblob != null)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 164 */               this.packet.reset();
/* 165 */               this.buf.putByte((byte)50);
/* 166 */               this.buf.putString(_username);
/* 167 */               this.buf.putString(Util.str2byte("ssh-connection"));
/* 168 */               this.buf.putString(Util.str2byte("publickey"));
/* 169 */               this.buf.putByte((byte)1);
/* 170 */               this.buf.putString(Util.str2byte(identity.getAlgName()));
/* 171 */               this.buf.putString(pubkeyblob);
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */               byte[] sid = session.getSessionId();
/* 178 */               int sidlen = sid.length;
/* 179 */               byte[] tmp = new byte[4 + sidlen + this.buf.index - 5];
/* 180 */               tmp[0] = ((byte)(sidlen >>> 24));
/* 181 */               tmp[1] = ((byte)(sidlen >>> 16));
/* 182 */               tmp[2] = ((byte)(sidlen >>> 8));
/* 183 */               tmp[3] = ((byte)sidlen);
/* 184 */               System.arraycopy(sid, 0, tmp, 4, sidlen);
/* 185 */               System.arraycopy(this.buf.buffer, 5, tmp, 4 + sidlen, this.buf.index - 5);
/* 186 */               byte[] signature = identity.getSignature(tmp);
/* 187 */               if (signature == null) {
/*     */                 break;
/*     */               }
/* 190 */               this.buf.putString(signature);
/* 191 */               session.write(this.packet);
/*     */               int command;
/*     */               for (;;)
/*     */               {
/* 195 */                 this.buf = session.read(this.buf);
/* 196 */                 command = this.buf.getCommand() & 0xFF;
/*     */                 
/* 198 */                 if (command == 52) {
/* 199 */                   return true;
/*     */                 }
/* 201 */                 if (command != 53) break;
/* 202 */                 this.buf.getInt();this.buf.getByte();this.buf.getByte();
/* 203 */                 byte[] _message = this.buf.getString();
/* 204 */                 byte[] lang = this.buf.getString();
/* 205 */                 String message = Util.byte2str(_message);
/* 206 */                 if (this.userinfo != null) {
/* 207 */                   this.userinfo.showMessage(message);
/*     */                 }
/*     */               }
/*     */               
/* 211 */               if (command == 51) {
/* 212 */                 this.buf.getInt();this.buf.getByte();this.buf.getByte();
/* 213 */                 byte[] foo = this.buf.getString();
/* 214 */                 int partial_success = this.buf.getByte();
/*     */                 
/*     */ 
/* 217 */                 if (partial_success != 0) {
/* 218 */                   throw new JSchPartialAuthException(Util.byte2str(foo));
/*     */                 }
/* 220 */                 session.auth_failures += 1;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 229 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\UserAuthPublicKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */