/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.Socket;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Util
/*     */ {
/*  38 */   private static final byte[] b64 = str2byte("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=");
/*     */   
/*  40 */   private static byte val(byte foo) { if (foo == 61) return 0;
/*  41 */     for (int j = 0; j < b64.length; j++) {
/*  42 */       if (foo == b64[j]) return (byte)j;
/*     */     }
/*  44 */     return 0;
/*     */   }
/*     */   
/*  47 */   static byte[] fromBase64(byte[] buf, int start, int length) { byte[] foo = new byte[length];
/*  48 */     int j = 0;
/*  49 */     for (int i = start; i < start + length; i += 4) {
/*  50 */       foo[j] = ((byte)(val(buf[i]) << 2 | (val(buf[(i + 1)]) & 0x30) >>> 4));
/*  51 */       if (buf[(i + 2)] == 61) { j++; break; }
/*  52 */       foo[(j + 1)] = ((byte)((val(buf[(i + 1)]) & 0xF) << 4 | (val(buf[(i + 2)]) & 0x3C) >>> 2));
/*  53 */       if (buf[(i + 3)] == 61) { j += 2; break; }
/*  54 */       foo[(j + 2)] = ((byte)((val(buf[(i + 2)]) & 0x3) << 6 | val(buf[(i + 3)]) & 0x3F));
/*  55 */       j += 3;
/*     */     }
/*  57 */     byte[] bar = new byte[j];
/*  58 */     System.arraycopy(foo, 0, bar, 0, j);
/*  59 */     return bar;
/*     */   }
/*     */   
/*     */   static byte[] toBase64(byte[] buf, int start, int length) {
/*  63 */     byte[] tmp = new byte[length * 2];
/*     */     
/*     */ 
/*  66 */     int foo = length / 3 * 3 + start;
/*  67 */     int i = 0;
/*  68 */     for (int j = start; j < foo; j += 3) {
/*  69 */       int k = buf[j] >>> 2 & 0x3F;
/*  70 */       tmp[(i++)] = b64[k];
/*  71 */       k = (buf[j] & 0x3) << 4 | buf[(j + 1)] >>> 4 & 0xF;
/*  72 */       tmp[(i++)] = b64[k];
/*  73 */       k = (buf[(j + 1)] & 0xF) << 2 | buf[(j + 2)] >>> 6 & 0x3;
/*  74 */       tmp[(i++)] = b64[k];
/*  75 */       k = buf[(j + 2)] & 0x3F;
/*  76 */       tmp[(i++)] = b64[k];
/*     */     }
/*     */     
/*  79 */     foo = start + length - foo;
/*  80 */     if (foo == 1) {
/*  81 */       int k = buf[j] >>> 2 & 0x3F;
/*  82 */       tmp[(i++)] = b64[k];
/*  83 */       k = (buf[j] & 0x3) << 4 & 0x3F;
/*  84 */       tmp[(i++)] = b64[k];
/*  85 */       tmp[(i++)] = 61;
/*  86 */       tmp[(i++)] = 61;
/*     */     }
/*  88 */     else if (foo == 2) {
/*  89 */       int k = buf[j] >>> 2 & 0x3F;
/*  90 */       tmp[(i++)] = b64[k];
/*  91 */       k = (buf[j] & 0x3) << 4 | buf[(j + 1)] >>> 4 & 0xF;
/*  92 */       tmp[(i++)] = b64[k];
/*  93 */       k = (buf[(j + 1)] & 0xF) << 2 & 0x3F;
/*  94 */       tmp[(i++)] = b64[k];
/*  95 */       tmp[(i++)] = 61;
/*     */     }
/*  97 */     byte[] bar = new byte[i];
/*  98 */     System.arraycopy(tmp, 0, bar, 0, i);
/*  99 */     return bar;
/*     */   }
/*     */   
/*     */ 
/*     */   static String[] split(String foo, String split)
/*     */   {
/* 105 */     if (foo == null)
/* 106 */       return null;
/* 107 */     byte[] buf = str2byte(foo);
/* 108 */     Vector bar = new Vector();
/* 109 */     int start = 0;
/*     */     for (;;)
/*     */     {
/* 112 */       int index = foo.indexOf(split, start);
/* 113 */       if (index < 0) break;
/* 114 */       bar.addElement(byte2str(buf, start, index - start));
/* 115 */       start = index + 1;
/*     */     }
/*     */     
/* 118 */     bar.addElement(byte2str(buf, start, buf.length - start));
/*     */     
/*     */ 
/* 121 */     String[] result = new String[bar.size()];
/* 122 */     for (int i = 0; i < result.length; i++) {
/* 123 */       result[i] = ((String)(String)bar.elementAt(i));
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */   
/* 128 */   static boolean glob(byte[] pattern, byte[] name) { return glob0(pattern, 0, name, 0); }
/*     */   
/*     */   private static boolean glob0(byte[] pattern, int pattern_index, byte[] name, int name_index)
/*     */   {
/* 132 */     if ((name.length > 0) && (name[0] == 46)) {
/* 133 */       if ((pattern.length > 0) && (pattern[0] == 46)) {
/* 134 */         if ((pattern.length == 2) && (pattern[1] == 42)) return true;
/* 135 */         return glob(pattern, pattern_index + 1, name, name_index + 1);
/*     */       }
/* 137 */       return false;
/*     */     }
/* 139 */     return glob(pattern, pattern_index, name, name_index);
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean glob(byte[] pattern, int pattern_index, byte[] name, int name_index)
/*     */   {
/* 145 */     int patternlen = pattern.length;
/* 146 */     if (patternlen == 0) {
/* 147 */       return false;
/*     */     }
/* 149 */     int namelen = name.length;
/* 150 */     int i = pattern_index;
/* 151 */     int j = name_index;
/*     */     
/* 153 */     while ((i < patternlen) && (j < namelen)) {
/* 154 */       if (pattern[i] == 92) {
/* 155 */         if (i + 1 == patternlen)
/* 156 */           return false;
/* 157 */         i++;
/* 158 */         if (pattern[i] != name[j])
/* 159 */           return false;
/* 160 */         i += skipUTF8Char(pattern[i]);
/* 161 */         j += skipUTF8Char(name[j]);
/*     */       }
/*     */       else
/*     */       {
/* 165 */         if (pattern[i] == 42) {
/* 166 */           while ((i < patternlen) && 
/* 167 */             (pattern[i] == 42)) {
/* 168 */             i++;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 173 */           if (patternlen == i) {
/* 174 */             return true;
/*     */           }
/* 176 */           byte foo = pattern[i];
/* 177 */           if (foo == 63) {
/* 178 */             while (j < namelen) {
/* 179 */               if (glob(pattern, i, name, j)) {
/* 180 */                 return true;
/*     */               }
/* 182 */               j += skipUTF8Char(name[j]);
/*     */             }
/* 184 */             return false;
/*     */           }
/* 186 */           if (foo == 92) {
/* 187 */             if (i + 1 == patternlen)
/* 188 */               return false;
/* 189 */             i++;
/* 190 */             foo = pattern[i];
/* 191 */             while (j < namelen) {
/* 192 */               if ((foo == name[j]) && 
/* 193 */                 (glob(pattern, i + skipUTF8Char(foo), name, j + skipUTF8Char(name[j]))))
/*     */               {
/* 195 */                 return true;
/*     */               }
/*     */               
/* 198 */               j += skipUTF8Char(name[j]);
/*     */             }
/* 200 */             return false;
/*     */           }
/*     */           
/* 203 */           while (j < namelen) {
/* 204 */             if ((foo == name[j]) && 
/* 205 */               (glob(pattern, i, name, j))) {
/* 206 */               return true;
/*     */             }
/*     */             
/* 209 */             j += skipUTF8Char(name[j]);
/*     */           }
/* 211 */           return false;
/*     */         }
/*     */         
/* 214 */         if (pattern[i] == 63) {
/* 215 */           i++;
/* 216 */           j += skipUTF8Char(name[j]);
/*     */         }
/*     */         else
/*     */         {
/* 220 */           if (pattern[i] != name[j]) {
/* 221 */             return false;
/*     */           }
/* 223 */           i += skipUTF8Char(pattern[i]);
/* 224 */           j += skipUTF8Char(name[j]);
/*     */           
/* 226 */           if (j >= namelen) {
/* 227 */             if (i >= patternlen) {
/* 228 */               return true;
/*     */             }
/* 230 */             if (pattern[i] == 42) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 237 */     if ((i == patternlen) && (j == namelen)) {
/* 238 */       return true;
/*     */     }
/* 240 */     if ((j >= namelen) && (pattern[i] == 42))
/*     */     {
/* 242 */       boolean ok = true;
/* 243 */       while (i < patternlen) {
/* 244 */         if (pattern[(i++)] != 42) {
/* 245 */           ok = false;
/*     */         }
/*     */       }
/*     */       
/* 249 */       return ok;
/*     */     }
/*     */     
/* 252 */     return false;
/*     */   }
/*     */   
/*     */   static String quote(String path) {
/* 256 */     byte[] _path = str2byte(path);
/* 257 */     int count = 0;
/* 258 */     for (int i = 0; i < _path.length; i++) {
/* 259 */       byte b = _path[i];
/* 260 */       if ((b == 92) || (b == 63) || (b == 42))
/* 261 */         count++;
/*     */     }
/* 263 */     if (count == 0)
/* 264 */       return path;
/* 265 */     byte[] _path2 = new byte[_path.length + count];
/* 266 */     int i = 0; for (int j = 0; i < _path.length; i++) {
/* 267 */       byte b = _path[i];
/* 268 */       if ((b == 92) || (b == 63) || (b == 42)) {
/* 269 */         _path2[(j++)] = 92;
/*     */       }
/* 271 */       _path2[(j++)] = b;
/*     */     }
/* 273 */     return byte2str(_path2);
/*     */   }
/*     */   
/*     */   static String unquote(String path) {
/* 277 */     byte[] foo = str2byte(path);
/* 278 */     byte[] bar = unquote(foo);
/* 279 */     if (foo.length == bar.length)
/* 280 */       return path;
/* 281 */     return byte2str(bar);
/*     */   }
/*     */   
/* 284 */   static byte[] unquote(byte[] path) { int pathlen = path.length;
/* 285 */     int i = 0;
/* 286 */     while (i < pathlen)
/* 287 */       if (path[i] == 92) {
/* 288 */         if (i + 1 == pathlen)
/*     */           break;
/* 290 */         System.arraycopy(path, i + 1, path, i, path.length - (i + 1));
/* 291 */         pathlen--;
/* 292 */         i++;
/*     */       }
/*     */       else {
/* 295 */         i++;
/*     */       }
/* 297 */     if (pathlen == path.length)
/* 298 */       return path;
/* 299 */     byte[] foo = new byte[pathlen];
/* 300 */     System.arraycopy(path, 0, foo, 0, pathlen);
/* 301 */     return foo;
/*     */   }
/*     */   
/* 304 */   private static String[] chars = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };
/*     */   
/*     */   static String getFingerPrint(HASH hash, byte[] data)
/*     */   {
/*     */     try {
/* 309 */       hash.init();
/* 310 */       hash.update(data, 0, data.length);
/* 311 */       byte[] foo = hash.digest();
/* 312 */       StringBuffer sb = new StringBuffer();
/*     */       
/* 314 */       for (int i = 0; i < foo.length; i++) {
/* 315 */         int bar = foo[i] & 0xFF;
/* 316 */         sb.append(chars[(bar >>> 4 & 0xF)]);
/* 317 */         sb.append(chars[(bar & 0xF)]);
/* 318 */         if (i + 1 < foo.length)
/* 319 */           sb.append(":");
/*     */       }
/* 321 */       return sb.toString();
/*     */     }
/*     */     catch (Exception e) {}
/* 324 */     return "???";
/*     */   }
/*     */   
/*     */   static boolean array_equals(byte[] foo, byte[] bar) {
/* 328 */     int i = foo.length;
/* 329 */     if (i != bar.length) return false;
/* 330 */     for (int j = 0; j < i; j++) if (foo[j] != bar[j]) { return false;
/*     */       }
/* 332 */     return true;
/*     */   }
/*     */   
/* 335 */   static Socket createSocket(String host, int port, int timeout) throws JSchException { Socket socket = null;
/* 336 */     if (timeout == 0) {
/*     */       try {
/* 338 */         return new Socket(host, port);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 342 */         String message = e.toString();
/* 343 */         if ((e instanceof Throwable))
/* 344 */           throw new JSchException(message, e);
/* 345 */         throw new JSchException(message);
/*     */       }
/*     */     }
/* 348 */     final String _host = host;
/* 349 */     final int _port = port;
/* 350 */     Socket[] sockp = new Socket[1];
/* 351 */     final Exception[] ee = new Exception[1];
/* 352 */     String message = "";
/* 353 */     Thread tmp = new Thread(new Runnable() { private final Socket[] val$sockp;
/*     */       
/* 355 */       public void run() { this.val$sockp[0] = null;
/*     */         try {
/* 357 */           this.val$sockp[0] = new Socket(_host, _port);
/*     */         }
/*     */         catch (Exception e) {
/* 360 */           ee[0] = e;
/* 361 */           if ((this.val$sockp[0] != null) && (this.val$sockp[0].isConnected())) {
/*     */             try {
/* 363 */               this.val$sockp[0].close();
/*     */             }
/*     */             catch (Exception eee) {}
/*     */           }
/* 367 */           this.val$sockp[0] = null;
/*     */         }
/*     */       }
/* 370 */     });
/* 371 */     tmp.setName("Opening Socket " + host);
/* 372 */     tmp.start();
/*     */     try {
/* 374 */       tmp.join(timeout);
/* 375 */       message = "timeout: ";
/*     */     }
/*     */     catch (InterruptedException eee) {}
/*     */     
/* 379 */     if ((sockp[0] != null) && (sockp[0].isConnected())) {
/* 380 */       socket = sockp[0];
/*     */     }
/*     */     else {
/* 383 */       message = message + "socket is not established";
/* 384 */       if (ee[0] != null) {
/* 385 */         message = ee[0].toString();
/*     */       }
/* 387 */       tmp.interrupt();
/* 388 */       tmp = null;
/* 389 */       throw new JSchException(message);
/*     */     }
/* 391 */     return socket;
/*     */   }
/*     */   
/*     */   static byte[] str2byte(String str, String encoding) {
/* 395 */     if (str == null)
/* 396 */       return null;
/* 397 */     try { return str.getBytes(encoding);
/*     */     } catch (UnsupportedEncodingException e) {}
/* 399 */     return str.getBytes();
/*     */   }
/*     */   
/*     */   static byte[] str2byte(String str)
/*     */   {
/* 404 */     return str2byte(str, "UTF-8");
/*     */   }
/*     */   
/*     */ 
/* 408 */   static String byte2str(byte[] str, String encoding) { return byte2str(str, 0, str.length, encoding); }
/*     */   
/*     */   static String byte2str(byte[] str, int s, int l, String encoding) {
/*     */     try {
/* 412 */       return new String(str, s, l, encoding);
/*     */     } catch (UnsupportedEncodingException e) {}
/* 414 */     return new String(str, s, l);
/*     */   }
/*     */   
/*     */   static String byte2str(byte[] str)
/*     */   {
/* 419 */     return byte2str(str, 0, str.length, "UTF-8");
/*     */   }
/*     */   
/*     */   static String byte2str(byte[] str, int s, int l) {
/* 423 */     return byte2str(str, s, l, "UTF-8");
/*     */   }
/*     */   
/* 426 */   static final byte[] empty = str2byte("");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void bzero(byte[] foo)
/*     */   {
/* 449 */     if (foo == null)
/* 450 */       return;
/* 451 */     for (int i = 0; i < foo.length; i++)
/* 452 */       foo[i] = 0;
/*     */   }
/*     */   
/*     */   static String diffString(String str, String[] not_available) {
/* 456 */     String[] stra = split(str, ",");
/* 457 */     String result = null;
/*     */     label91:
/* 459 */     for (int i = 0; i < stra.length; i++) {
/* 460 */       for (int j = 0; j < not_available.length; j++) {
/* 461 */         if (stra[i].equals(not_available[j])) {
/*     */           break label91;
/*     */         }
/*     */       }
/* 465 */       if (result == null) result = stra[i]; else
/* 466 */         result = result + "," + stra[i];
/*     */     }
/* 468 */     return result;
/*     */   }
/*     */   
/*     */   static String checkTilde(String str) {
/* 472 */     if (str.indexOf("~") != -1) {
/*     */       try {
/* 474 */         str = str.replace("~", System.getProperty("user.home"));
/*     */       }
/*     */       catch (SecurityException e) {}
/*     */     }
/*     */     
/* 479 */     return str;
/*     */   }
/*     */   
/*     */   private static int skipUTF8Char(byte b) {
/* 483 */     if ((byte)(b & 0x80) == 0) return 1;
/* 484 */     if ((byte)(b & 0xE0) == -64) return 2;
/* 485 */     if ((byte)(b & 0xF0) == -32) return 3;
/* 486 */     return 1;
/*     */   }
/*     */   
/*     */   static byte[] fromFile(String _file) throws IOException {
/* 490 */     _file = checkTilde(_file);
/* 491 */     File file = new File(_file);
/* 492 */     FileInputStream fis = new FileInputStream(_file);
/*     */     try {
/* 494 */       byte[] result = new byte[(int)file.length()];
/* 495 */       int len = 0;
/*     */       int i;
/* 497 */       for (;;) { i = fis.read(result, len, result.length - len);
/* 498 */         if (i <= 0)
/*     */           break;
/* 500 */         len += i;
/*     */       }
/* 502 */       fis.close();
/* 503 */       return result;
/*     */     }
/*     */     finally {
/* 506 */       if (fis != null) {
/* 507 */         fis.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */