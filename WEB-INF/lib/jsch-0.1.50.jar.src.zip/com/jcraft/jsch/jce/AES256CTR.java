/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AES256CTR
/*    */   implements com.jcraft.jsch.Cipher
/*    */ {
/*    */   private static final int ivsize = 16;
/*    */   private static final int bsize = 32;
/*    */   private javax.crypto.Cipher cipher;
/*    */   
/* 39 */   public int getIVSize() { return 16; }
/* 40 */   public int getBlockSize() { return 32; }
/*    */   
/* 42 */   public void init(int mode, byte[] key, byte[] iv) throws Exception { String pad = "NoPadding";
/*    */     
/* 44 */     if (iv.length > 16) {
/* 45 */       byte[] tmp = new byte[16];
/* 46 */       System.arraycopy(iv, 0, tmp, 0, tmp.length);
/* 47 */       iv = tmp;
/*    */     }
/* 49 */     if (key.length > 32) {
/* 50 */       byte[] tmp = new byte[32];
/* 51 */       System.arraycopy(key, 0, tmp, 0, tmp.length);
/* 52 */       key = tmp;
/*    */     }
/*    */     try {
/* 55 */       SecretKeySpec keyspec = new SecretKeySpec(key, "AES");
/* 56 */       this.cipher = javax.crypto.Cipher.getInstance("AES/CTR/" + pad);
/* 57 */       this.cipher.init(mode == 0 ? 1 : 2, keyspec, new IvParameterSpec(iv));
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/* 63 */       this.cipher = null;
/* 64 */       throw e;
/*    */     }
/*    */   }
/*    */   
/* 68 */   public void update(byte[] foo, int s1, int len, byte[] bar, int s2) throws Exception { this.cipher.update(foo, s1, len, bar, s2); }
/*    */   
/* 70 */   public boolean isCBC() { return false; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\jce\AES256CTR.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */