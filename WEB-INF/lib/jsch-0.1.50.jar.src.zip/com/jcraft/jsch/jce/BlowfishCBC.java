/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlowfishCBC
/*    */   implements com.jcraft.jsch.Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   private static final int bsize = 16;
/*    */   private javax.crypto.Cipher cipher;
/*    */   
/* 39 */   public int getIVSize() { return 8; }
/* 40 */   public int getBlockSize() { return 16; }
/*    */   
/* 42 */   public void init(int mode, byte[] key, byte[] iv) throws Exception { String pad = "NoPadding";
/*    */     
/*    */ 
/* 45 */     if (iv.length > 8) {
/* 46 */       byte[] tmp = new byte[8];
/* 47 */       System.arraycopy(iv, 0, tmp, 0, tmp.length);
/* 48 */       iv = tmp;
/*    */     }
/* 50 */     if (key.length > 16) {
/* 51 */       byte[] tmp = new byte[16];
/* 52 */       System.arraycopy(key, 0, tmp, 0, tmp.length);
/* 53 */       key = tmp;
/*    */     }
/*    */     try {
/* 56 */       SecretKeySpec skeySpec = new SecretKeySpec(key, "Blowfish");
/* 57 */       this.cipher = javax.crypto.Cipher.getInstance("Blowfish/CBC/" + pad);
/* 58 */       this.cipher.init(mode == 0 ? 1 : 2, skeySpec, new IvParameterSpec(iv));
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/* 64 */       throw e;
/*    */     }
/*    */   }
/*    */   
/* 68 */   public void update(byte[] foo, int s1, int len, byte[] bar, int s2) throws Exception { this.cipher.update(foo, s1, len, bar, s2); }
/*    */   
/* 70 */   public boolean isCBC() { return true; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\jce\BlowfishCBC.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */