/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import java.security.KeyFactory;
/*    */ import java.security.KeyPair;
/*    */ import java.security.KeyPairGenerator;
/*    */ import java.security.PublicKey;
/*    */ import javax.crypto.KeyAgreement;
/*    */ import javax.crypto.interfaces.DHPublicKey;
/*    */ import javax.crypto.spec.DHParameterSpec;
/*    */ import javax.crypto.spec.DHPublicKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DH
/*    */   implements com.jcraft.jsch.DH
/*    */ {
/*    */   BigInteger p;
/*    */   BigInteger g;
/*    */   BigInteger e;
/*    */   byte[] e_array;
/*    */   BigInteger f;
/*    */   BigInteger K;
/*    */   byte[] K_array;
/*    */   private KeyPairGenerator myKpairGen;
/*    */   private KeyAgreement myKeyAgree;
/*    */   
/*    */   public void init()
/*    */     throws Exception
/*    */   {
/* 49 */     this.myKpairGen = KeyPairGenerator.getInstance("DH");
/*    */     
/* 51 */     this.myKeyAgree = KeyAgreement.getInstance("DH");
/*    */   }
/*    */   
/*    */   public byte[] getE() throws Exception {
/* 55 */     if (this.e == null) {
/* 56 */       DHParameterSpec dhSkipParamSpec = new DHParameterSpec(this.p, this.g);
/* 57 */       this.myKpairGen.initialize(dhSkipParamSpec);
/* 58 */       KeyPair myKpair = this.myKpairGen.generateKeyPair();
/* 59 */       this.myKeyAgree.init(myKpair.getPrivate());
/*    */       
/* 61 */       byte[] myPubKeyEnc = myKpair.getPublic().getEncoded();
/* 62 */       this.e = ((DHPublicKey)myKpair.getPublic()).getY();
/* 63 */       this.e_array = this.e.toByteArray();
/*    */     }
/* 65 */     return this.e_array;
/*    */   }
/*    */   
/* 68 */   public byte[] getK() throws Exception { if (this.K == null) {
/* 69 */       KeyFactory myKeyFac = KeyFactory.getInstance("DH");
/* 70 */       DHPublicKeySpec keySpec = new DHPublicKeySpec(this.f, this.p, this.g);
/* 71 */       PublicKey yourPubKey = myKeyFac.generatePublic(keySpec);
/* 72 */       this.myKeyAgree.doPhase(yourPubKey, true);
/* 73 */       byte[] mySharedSecret = this.myKeyAgree.generateSecret();
/* 74 */       this.K = new BigInteger(mySharedSecret);
/* 75 */       this.K_array = this.K.toByteArray();
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 81 */       this.K_array = mySharedSecret;
/*    */     }
/* 83 */     return this.K_array; }
/*    */   
/* 85 */   public void setP(byte[] p) { setP(new BigInteger(p)); }
/* 86 */   public void setG(byte[] g) { setG(new BigInteger(g)); }
/* 87 */   public void setF(byte[] f) { setF(new BigInteger(f)); }
/* 88 */   void setP(BigInteger p) { this.p = p; }
/* 89 */   void setG(BigInteger g) { this.g = g; }
/* 90 */   void setF(BigInteger f) { this.f = f; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\jce\DH.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */