/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACSHA512
/*    */   extends HMAC
/*    */ {
/*    */   public HMACSHA512()
/*    */   {
/* 34 */     this.name = "hmac-sha2-512";
/* 35 */     this.bsize = 64;
/* 36 */     this.algorithm = "HmacSHA512";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\jce\HMACSHA512.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */