/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import java.security.SecureRandom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Random
/*    */   implements com.jcraft.jsch.Random
/*    */ {
/* 35 */   private byte[] tmp = new byte[16];
/* 36 */   private SecureRandom random = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Random()
/*    */   {
/* 48 */     this.random = new SecureRandom();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void fill(byte[] foo, int start, int len)
/*    */   {
/* 77 */     if (len > this.tmp.length) this.tmp = new byte[len];
/* 78 */     this.random.nextBytes(this.tmp);
/* 79 */     System.arraycopy(this.tmp, 0, foo, start, len);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\jce\Random.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */