/*     */ package com.jcraft.jsch.jcraft;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HMAC
/*     */ {
/*     */   private static final int B = 64;
/*  47 */   private byte[] k_ipad = null;
/*  48 */   private byte[] k_opad = null;
/*     */   
/*  50 */   private MessageDigest md = null;
/*     */   
/*  52 */   private int bsize = 0;
/*     */   
/*     */   protected void setH(MessageDigest md) {
/*  55 */     this.md = md;
/*  56 */     this.bsize = md.getDigestLength();
/*     */   }
/*     */   
/*  59 */   public int getBlockSize() { return this.bsize; }
/*     */   
/*  61 */   public void init(byte[] key) throws Exception { if (key.length > this.bsize) {
/*  62 */       byte[] tmp = new byte[this.bsize];
/*  63 */       System.arraycopy(key, 0, tmp, 0, this.bsize);
/*  64 */       key = tmp;
/*     */     }
/*     */     
/*     */ 
/*  68 */     if (key.length > 64) {
/*  69 */       this.md.update(key, 0, key.length);
/*  70 */       key = this.md.digest();
/*     */     }
/*     */     
/*  73 */     this.k_ipad = new byte[64];
/*  74 */     System.arraycopy(key, 0, this.k_ipad, 0, key.length);
/*  75 */     this.k_opad = new byte[64];
/*  76 */     System.arraycopy(key, 0, this.k_opad, 0, key.length);
/*     */     
/*     */ 
/*  79 */     for (int i = 0; i < 64; i++) {
/*  80 */       int tmp108_107 = i; byte[] tmp108_104 = this.k_ipad;tmp108_104[tmp108_107] = ((byte)(tmp108_104[tmp108_107] ^ 0x36)); int 
/*  81 */         tmp120_119 = i; byte[] tmp120_116 = this.k_opad;tmp120_116[tmp120_119] = ((byte)(tmp120_116[tmp120_119] ^ 0x5C));
/*     */     }
/*     */     
/*  84 */     this.md.update(this.k_ipad, 0, 64);
/*     */   }
/*     */   
/*  87 */   private final byte[] tmp = new byte[4];
/*     */   
/*  89 */   public void update(int i) { this.tmp[0] = ((byte)(i >>> 24));
/*  90 */     this.tmp[1] = ((byte)(i >>> 16));
/*  91 */     this.tmp[2] = ((byte)(i >>> 8));
/*  92 */     this.tmp[3] = ((byte)i);
/*  93 */     update(this.tmp, 0, 4);
/*     */   }
/*     */   
/*     */   public void update(byte[] foo, int s, int l) {
/*  97 */     this.md.update(foo, s, l);
/*     */   }
/*     */   
/*     */   public void doFinal(byte[] buf, int offset) {
/* 101 */     byte[] result = this.md.digest();
/* 102 */     this.md.update(this.k_opad, 0, 64);
/* 103 */     this.md.update(result, 0, this.bsize);
/* 104 */     try { this.md.digest(buf, offset, this.bsize); } catch (Exception e) {}
/* 105 */     this.md.update(this.k_ipad, 0, 64);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.50.jar!\com\jcraft\jsch\jcraft\HMAC.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */