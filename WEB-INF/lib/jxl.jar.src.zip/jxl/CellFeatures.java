/*    */ package jxl;
/*    */ 
/*    */ import jxl.biff.BaseCellFeatures;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CellFeatures
/*    */   extends BaseCellFeatures
/*    */ {
/*    */   public CellFeatures() {}
/*    */   
/*    */   protected CellFeatures(CellFeatures cf)
/*    */   {
/* 44 */     super(cf);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getComment()
/*    */   {
/* 55 */     return super.getComment();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDataValidationList()
/*    */   {
/* 65 */     return super.getDataValidationList();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Range getSharedDataValidationRange()
/*    */   {
/* 78 */     return super.getSharedDataValidationRange();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\CellFeatures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */