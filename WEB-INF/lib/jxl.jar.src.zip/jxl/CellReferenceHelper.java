/*     */ package jxl;
/*     */ 
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CellReferenceHelper
/*     */ {
/*     */   public static void getCellReference(int column, int row, StringBuffer buf)
/*     */   {
/*  46 */     jxl.biff.CellReferenceHelper.getCellReference(column, row, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int column, boolean colabs, int row, boolean rowabs, StringBuffer buf)
/*     */   {
/*  64 */     jxl.biff.CellReferenceHelper.getCellReference(column, colabs, row, rowabs, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellReference(int column, int row)
/*     */   {
/*  79 */     return jxl.biff.CellReferenceHelper.getCellReference(column, row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getColumn(String s)
/*     */   {
/*  90 */     return jxl.biff.CellReferenceHelper.getColumn(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getColumnReference(int c)
/*     */   {
/* 101 */     return jxl.biff.CellReferenceHelper.getColumnReference(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getRow(String s)
/*     */   {
/* 111 */     return jxl.biff.CellReferenceHelper.getRow(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isColumnRelative(String s)
/*     */   {
/* 122 */     return jxl.biff.CellReferenceHelper.isColumnRelative(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isRowRelative(String s)
/*     */   {
/* 133 */     return jxl.biff.CellReferenceHelper.isRowRelative(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int sheet, int column, int row, Workbook workbook, StringBuffer buf)
/*     */   {
/* 150 */     jxl.biff.CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int sheet, int column, int row, WritableWorkbook workbook, StringBuffer buf)
/*     */   {
/* 170 */     jxl.biff.CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int sheet, int column, boolean colabs, int row, boolean rowabs, Workbook workbook, StringBuffer buf)
/*     */   {
/* 194 */     jxl.biff.CellReferenceHelper.getCellReference(sheet, column, colabs, row, rowabs, (ExternalSheet)workbook, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellReference(int sheet, int column, int row, Workbook workbook)
/*     */   {
/* 214 */     return jxl.biff.CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellReference(int sheet, int column, int row, WritableWorkbook workbook)
/*     */   {
/* 233 */     return jxl.biff.CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSheet(String ref)
/*     */   {
/* 246 */     return jxl.biff.CellReferenceHelper.getSheet(ref);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellReference(Cell c)
/*     */   {
/* 256 */     return getCellReference(c.getColumn(), c.getRow());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(Cell c, StringBuffer sb)
/*     */   {
/* 267 */     getCellReference(c.getColumn(), c.getRow(), sb);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\CellReferenceHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */