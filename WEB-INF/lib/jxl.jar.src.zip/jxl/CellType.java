/*    */ package jxl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CellType
/*    */ {
/*    */   private String description;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private CellType(String desc)
/*    */   {
/* 39 */     this.description = desc;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 49 */     return this.description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 55 */   public static final CellType EMPTY = new CellType("Empty");
/*    */   
/*    */ 
/* 58 */   public static final CellType LABEL = new CellType("Label");
/*    */   
/*    */ 
/* 61 */   public static final CellType NUMBER = new CellType("Number");
/*    */   
/*    */ 
/* 64 */   public static final CellType BOOLEAN = new CellType("Boolean");
/*    */   
/*    */ 
/* 67 */   public static final CellType ERROR = new CellType("Error");
/*    */   
/*    */ 
/* 70 */   public static final CellType NUMBER_FORMULA = new CellType("Numerical Formula");
/*    */   
/*    */ 
/*    */ 
/* 74 */   public static final CellType DATE_FORMULA = new CellType("Date Formula");
/*    */   
/*    */ 
/* 77 */   public static final CellType STRING_FORMULA = new CellType("String Formula");
/*    */   
/*    */ 
/* 80 */   public static final CellType BOOLEAN_FORMULA = new CellType("Boolean Formula");
/*    */   
/*    */ 
/*    */ 
/* 84 */   public static final CellType FORMULA_ERROR = new CellType("Formula Error");
/*    */   
/*    */ 
/* 87 */   public static final CellType DATE = new CellType("Date");
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\CellType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */