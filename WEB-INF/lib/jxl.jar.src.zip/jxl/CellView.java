/*     */ package jxl;
/*     */ 
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CellView
/*     */ {
/*     */   private int dimension;
/*     */   private int size;
/*     */   private boolean depUsed;
/*     */   private boolean hidden;
/*     */   private CellFormat format;
/*     */   private boolean autosize;
/*     */   
/*     */   public CellView()
/*     */   {
/*  70 */     this.hidden = false;
/*  71 */     this.depUsed = false;
/*  72 */     this.dimension = 1;
/*  73 */     this.size = 1;
/*  74 */     this.autosize = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellView(CellView cv)
/*     */   {
/*  82 */     this.hidden = cv.hidden;
/*  83 */     this.depUsed = cv.depUsed;
/*  84 */     this.dimension = cv.dimension;
/*  85 */     this.size = cv.size;
/*  86 */     this.autosize = cv.autosize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHidden(boolean h)
/*     */   {
/*  96 */     this.hidden = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHidden()
/*     */   {
/* 106 */     return this.hidden;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setDimension(int d)
/*     */   {
/* 118 */     this.dimension = d;
/* 119 */     this.depUsed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(int d)
/*     */   {
/* 130 */     this.size = d;
/* 131 */     this.depUsed = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public int getDimension()
/*     */   {
/* 143 */     return this.dimension;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 154 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(CellFormat cf)
/*     */   {
/* 164 */     this.format = cf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFormat getFormat()
/*     */   {
/* 175 */     return this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean depUsed()
/*     */   {
/* 186 */     return this.depUsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutosize(boolean a)
/*     */   {
/* 196 */     this.autosize = a;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutosize()
/*     */   {
/* 208 */     return this.autosize;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\CellView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */