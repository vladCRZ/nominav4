package jxl;

import java.text.DateFormat;
import java.util.Date;

public abstract interface DateCell
  extends Cell
{
  public abstract Date getDate();
  
  public abstract boolean isTime();
  
  public abstract DateFormat getDateFormat();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\DateCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */