package jxl;

import jxl.biff.formula.FormulaException;

public abstract interface FormulaCell
  extends Cell
{
  public abstract String getFormula()
    throws FormulaException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\FormulaCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */