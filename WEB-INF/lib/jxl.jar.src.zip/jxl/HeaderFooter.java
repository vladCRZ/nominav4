/*     */ package jxl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HeaderFooter
/*     */   extends jxl.biff.HeaderFooter
/*     */ {
/*     */   public HeaderFooter() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Contents
/*     */     extends jxl.biff.HeaderFooter.Contents
/*     */   {
/*     */     Contents() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Contents(String s)
/*     */     {
/*  48 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Contents(Contents copy)
/*     */     {
/*  58 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void append(String txt)
/*     */     {
/*  68 */       super.append(txt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleBold()
/*     */     {
/*  79 */       super.toggleBold();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleUnderline()
/*     */     {
/*  90 */       super.toggleUnderline();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleItalics()
/*     */     {
/* 101 */       super.toggleItalics();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleStrikethrough()
/*     */     {
/* 112 */       super.toggleStrikethrough();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleDoubleUnderline()
/*     */     {
/* 123 */       super.toggleDoubleUnderline();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleSuperScript()
/*     */     {
/* 134 */       super.toggleSuperScript();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleSubScript()
/*     */     {
/* 145 */       super.toggleSubScript();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleOutline()
/*     */     {
/* 156 */       super.toggleOutline();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void toggleShadow()
/*     */     {
/* 167 */       super.toggleShadow();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setFontName(String fontName)
/*     */     {
/* 181 */       super.setFontName(fontName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean setFontSize(int size)
/*     */     {
/* 200 */       return super.setFontSize(size);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void appendPageNumber()
/*     */     {
/* 208 */       super.appendPageNumber();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void appendTotalPages()
/*     */     {
/* 216 */       super.appendTotalPages();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void appendDate()
/*     */     {
/* 224 */       super.appendDate();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void appendTime()
/*     */     {
/* 232 */       super.appendTime();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void appendWorkbookName()
/*     */     {
/* 240 */       super.appendWorkbookName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void appendWorkSheetName()
/*     */     {
/* 248 */       super.appendWorkSheetName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void clear()
/*     */     {
/* 256 */       super.clear();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean empty()
/*     */     {
/* 266 */       return super.empty();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderFooter(HeaderFooter hf)
/*     */   {
/* 285 */     super(hf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderFooter(String s)
/*     */   {
/* 296 */     super(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 307 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Contents getRight()
/*     */   {
/* 317 */     return (Contents)super.getRightText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Contents getCentre()
/*     */   {
/* 327 */     return (Contents)super.getCentreText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Contents getLeft()
/*     */   {
/* 337 */     return (Contents)super.getLeftText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 345 */     super.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected jxl.biff.HeaderFooter.Contents createContents()
/*     */   {
/* 355 */     return new Contents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected jxl.biff.HeaderFooter.Contents createContents(String s)
/*     */   {
/* 366 */     return new Contents(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected jxl.biff.HeaderFooter.Contents createContents(jxl.biff.HeaderFooter.Contents c)
/*     */   {
/* 378 */     return new Contents((Contents)c);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\HeaderFooter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */