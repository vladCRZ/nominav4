package jxl;

import java.io.File;
import java.net.URL;

public abstract interface Hyperlink
{
  public abstract int getRow();
  
  public abstract int getColumn();
  
  public abstract Range getRange();
  
  public abstract boolean isFile();
  
  public abstract boolean isURL();
  
  public abstract boolean isLocation();
  
  public abstract int getLastRow();
  
  public abstract int getLastColumn();
  
  public abstract URL getURL();
  
  public abstract File getFile();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\Hyperlink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */