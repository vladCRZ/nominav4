/*      */ package jxl;
/*      */ 
/*      */ import jxl.biff.SheetRangeImpl;
/*      */ import jxl.common.Assert;
/*      */ import jxl.format.PageOrder;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SheetSettings
/*      */ {
/*      */   private PageOrientation orientation;
/*      */   private PageOrder pageOrder;
/*      */   private PaperSize paperSize;
/*      */   private boolean sheetProtected;
/*      */   private boolean hidden;
/*      */   private boolean selected;
/*      */   private HeaderFooter header;
/*      */   private double headerMargin;
/*      */   private HeaderFooter footer;
/*      */   private double footerMargin;
/*      */   private int scaleFactor;
/*      */   private int zoomFactor;
/*      */   private int pageStart;
/*      */   private int fitWidth;
/*      */   private int fitHeight;
/*      */   private int horizontalPrintResolution;
/*      */   private int verticalPrintResolution;
/*      */   private double leftMargin;
/*      */   private double rightMargin;
/*      */   private double topMargin;
/*      */   private double bottomMargin;
/*      */   private boolean fitToPages;
/*      */   private boolean showGridLines;
/*      */   private boolean printGridLines;
/*      */   private boolean printHeaders;
/*      */   private boolean pageBreakPreviewMode;
/*      */   private boolean displayZeroValues;
/*      */   private String password;
/*      */   private int passwordHash;
/*      */   private int defaultColumnWidth;
/*      */   private int defaultRowHeight;
/*      */   private int horizontalFreeze;
/*      */   private int verticalFreeze;
/*      */   private boolean verticalCentre;
/*      */   private boolean horizontalCentre;
/*      */   private int copies;
/*      */   private boolean automaticFormulaCalculation;
/*      */   private boolean recalculateFormulasBeforeSave;
/*      */   private int pageBreakPreviewMagnification;
/*      */   private int normalMagnification;
/*      */   private Range printArea;
/*      */   private Range printTitlesRow;
/*      */   private Range printTitlesCol;
/*      */   private Sheet sheet;
/*  264 */   private static final PageOrientation DEFAULT_ORIENTATION = PageOrientation.PORTRAIT;
/*      */   
/*  266 */   private static final PageOrder DEFAULT_ORDER = PageOrder.RIGHT_THEN_DOWN;
/*      */   
/*  268 */   private static final PaperSize DEFAULT_PAPER_SIZE = PaperSize.A4;
/*      */   
/*      */   private static final double DEFAULT_HEADER_MARGIN = 0.5D;
/*      */   
/*      */   private static final double DEFAULT_FOOTER_MARGIN = 0.5D;
/*      */   
/*      */   private static final int DEFAULT_PRINT_RESOLUTION = 300;
/*      */   
/*      */   private static final double DEFAULT_WIDTH_MARGIN = 0.75D;
/*      */   
/*      */   private static final double DEFAULT_HEIGHT_MARGIN = 1.0D;
/*      */   
/*      */   private static final int DEFAULT_DEFAULT_COLUMN_WIDTH = 8;
/*      */   
/*      */   private static final int DEFAULT_ZOOM_FACTOR = 100;
/*      */   
/*      */   private static final int DEFAULT_NORMAL_MAGNIFICATION = 100;
/*      */   
/*      */   private static final int DEFAULT_PAGE_BREAK_PREVIEW_MAGNIFICATION = 60;
/*      */   public static final int DEFAULT_DEFAULT_ROW_HEIGHT = 255;
/*      */   
/*      */   public SheetSettings(Sheet s)
/*      */   {
/*  291 */     this.sheet = s;
/*  292 */     this.orientation = DEFAULT_ORIENTATION;
/*  293 */     this.pageOrder = DEFAULT_ORDER;
/*  294 */     this.paperSize = DEFAULT_PAPER_SIZE;
/*  295 */     this.sheetProtected = false;
/*  296 */     this.hidden = false;
/*  297 */     this.selected = false;
/*  298 */     this.headerMargin = 0.5D;
/*  299 */     this.footerMargin = 0.5D;
/*  300 */     this.horizontalPrintResolution = 300;
/*  301 */     this.verticalPrintResolution = 300;
/*  302 */     this.leftMargin = 0.75D;
/*  303 */     this.rightMargin = 0.75D;
/*  304 */     this.topMargin = 1.0D;
/*  305 */     this.bottomMargin = 1.0D;
/*  306 */     this.fitToPages = false;
/*  307 */     this.showGridLines = true;
/*  308 */     this.printGridLines = false;
/*  309 */     this.printHeaders = false;
/*  310 */     this.pageBreakPreviewMode = false;
/*  311 */     this.displayZeroValues = true;
/*  312 */     this.defaultColumnWidth = 8;
/*  313 */     this.defaultRowHeight = 255;
/*  314 */     this.zoomFactor = 100;
/*  315 */     this.pageBreakPreviewMagnification = 60;
/*  316 */     this.normalMagnification = 100;
/*  317 */     this.horizontalFreeze = 0;
/*  318 */     this.verticalFreeze = 0;
/*  319 */     this.copies = 1;
/*  320 */     this.header = new HeaderFooter();
/*  321 */     this.footer = new HeaderFooter();
/*  322 */     this.automaticFormulaCalculation = true;
/*  323 */     this.recalculateFormulasBeforeSave = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SheetSettings(SheetSettings copy, Sheet s)
/*      */   {
/*  332 */     Assert.verify(copy != null);
/*      */     
/*  334 */     this.sheet = s;
/*  335 */     this.orientation = copy.orientation;
/*  336 */     this.pageOrder = copy.pageOrder;
/*  337 */     this.paperSize = copy.paperSize;
/*  338 */     this.sheetProtected = copy.sheetProtected;
/*  339 */     this.hidden = copy.hidden;
/*  340 */     this.selected = false;
/*  341 */     this.headerMargin = copy.headerMargin;
/*  342 */     this.footerMargin = copy.footerMargin;
/*  343 */     this.scaleFactor = copy.scaleFactor;
/*  344 */     this.pageStart = copy.pageStart;
/*  345 */     this.fitWidth = copy.fitWidth;
/*  346 */     this.fitHeight = copy.fitHeight;
/*  347 */     this.horizontalPrintResolution = copy.horizontalPrintResolution;
/*  348 */     this.verticalPrintResolution = copy.verticalPrintResolution;
/*  349 */     this.leftMargin = copy.leftMargin;
/*  350 */     this.rightMargin = copy.rightMargin;
/*  351 */     this.topMargin = copy.topMargin;
/*  352 */     this.bottomMargin = copy.bottomMargin;
/*  353 */     this.fitToPages = copy.fitToPages;
/*  354 */     this.password = copy.password;
/*  355 */     this.passwordHash = copy.passwordHash;
/*  356 */     this.defaultColumnWidth = copy.defaultColumnWidth;
/*  357 */     this.defaultRowHeight = copy.defaultRowHeight;
/*  358 */     this.zoomFactor = copy.zoomFactor;
/*  359 */     this.pageBreakPreviewMagnification = copy.pageBreakPreviewMagnification;
/*  360 */     this.normalMagnification = copy.normalMagnification;
/*  361 */     this.showGridLines = copy.showGridLines;
/*  362 */     this.displayZeroValues = copy.displayZeroValues;
/*  363 */     this.pageBreakPreviewMode = copy.pageBreakPreviewMode;
/*  364 */     this.horizontalFreeze = copy.horizontalFreeze;
/*  365 */     this.verticalFreeze = copy.verticalFreeze;
/*  366 */     this.horizontalCentre = copy.horizontalCentre;
/*  367 */     this.verticalCentre = copy.verticalCentre;
/*  368 */     this.copies = copy.copies;
/*  369 */     this.header = new HeaderFooter(copy.header);
/*  370 */     this.footer = new HeaderFooter(copy.footer);
/*  371 */     this.automaticFormulaCalculation = copy.automaticFormulaCalculation;
/*  372 */     this.recalculateFormulasBeforeSave = copy.recalculateFormulasBeforeSave;
/*      */     
/*  374 */     if (copy.printArea != null)
/*      */     {
/*  376 */       this.printArea = new SheetRangeImpl(this.sheet, copy.getPrintArea().getTopLeft().getColumn(), copy.getPrintArea().getTopLeft().getRow(), copy.getPrintArea().getBottomRight().getColumn(), copy.getPrintArea().getBottomRight().getRow());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  384 */     if (copy.printTitlesRow != null)
/*      */     {
/*  386 */       this.printTitlesRow = new SheetRangeImpl(this.sheet, copy.getPrintTitlesRow().getTopLeft().getColumn(), copy.getPrintTitlesRow().getTopLeft().getRow(), copy.getPrintTitlesRow().getBottomRight().getColumn(), copy.getPrintTitlesRow().getBottomRight().getRow());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  394 */     if (copy.printTitlesCol != null)
/*      */     {
/*  396 */       this.printTitlesCol = new SheetRangeImpl(this.sheet, copy.getPrintTitlesCol().getTopLeft().getColumn(), copy.getPrintTitlesCol().getTopLeft().getRow(), copy.getPrintTitlesCol().getBottomRight().getColumn(), copy.getPrintTitlesCol().getBottomRight().getRow());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOrientation(PageOrientation po)
/*      */   {
/*  412 */     this.orientation = po;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PageOrientation getOrientation()
/*      */   {
/*  422 */     return this.orientation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PageOrder getPageOrder()
/*      */   {
/*  432 */     return this.pageOrder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageOrder(PageOrder order)
/*      */   {
/*  442 */     this.pageOrder = order;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPaperSize(PaperSize ps)
/*      */   {
/*  452 */     this.paperSize = ps;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PaperSize getPaperSize()
/*      */   {
/*  462 */     return this.paperSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isProtected()
/*      */   {
/*  472 */     return this.sheetProtected;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtected(boolean p)
/*      */   {
/*  482 */     this.sheetProtected = p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderMargin(double d)
/*      */   {
/*  492 */     this.headerMargin = d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getHeaderMargin()
/*      */   {
/*  502 */     return this.headerMargin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFooterMargin(double d)
/*      */   {
/*  512 */     this.footerMargin = d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getFooterMargin()
/*      */   {
/*  522 */     return this.footerMargin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHidden(boolean h)
/*      */   {
/*  532 */     this.hidden = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHidden()
/*      */   {
/*  542 */     return this.hidden;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setSelected()
/*      */   {
/*  552 */     setSelected(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelected(boolean s)
/*      */   {
/*  562 */     this.selected = s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSelected()
/*      */   {
/*  572 */     return this.selected;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setScaleFactor(int sf)
/*      */   {
/*  584 */     this.scaleFactor = sf;
/*  585 */     this.fitToPages = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getScaleFactor()
/*      */   {
/*  595 */     return this.scaleFactor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageStart(int ps)
/*      */   {
/*  605 */     this.pageStart = ps;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPageStart()
/*      */   {
/*  615 */     return this.pageStart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFitWidth(int fw)
/*      */   {
/*  626 */     this.fitWidth = fw;
/*  627 */     this.fitToPages = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFitWidth()
/*      */   {
/*  637 */     return this.fitWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFitHeight(int fh)
/*      */   {
/*  647 */     this.fitHeight = fh;
/*  648 */     this.fitToPages = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFitHeight()
/*      */   {
/*  658 */     return this.fitHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHorizontalPrintResolution(int hpw)
/*      */   {
/*  668 */     this.horizontalPrintResolution = hpw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHorizontalPrintResolution()
/*      */   {
/*  678 */     return this.horizontalPrintResolution;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVerticalPrintResolution(int vpw)
/*      */   {
/*  688 */     this.verticalPrintResolution = vpw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getVerticalPrintResolution()
/*      */   {
/*  698 */     return this.verticalPrintResolution;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRightMargin(double m)
/*      */   {
/*  708 */     this.rightMargin = m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getRightMargin()
/*      */   {
/*  718 */     return this.rightMargin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeftMargin(double m)
/*      */   {
/*  728 */     this.leftMargin = m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getLeftMargin()
/*      */   {
/*  738 */     return this.leftMargin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTopMargin(double m)
/*      */   {
/*  748 */     this.topMargin = m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getTopMargin()
/*      */   {
/*  758 */     return this.topMargin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBottomMargin(double m)
/*      */   {
/*  768 */     this.bottomMargin = m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getBottomMargin()
/*      */   {
/*  778 */     return this.bottomMargin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDefaultWidthMargin()
/*      */   {
/*  788 */     return 0.75D;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDefaultHeightMargin()
/*      */   {
/*  798 */     return 1.0D;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFitToPages()
/*      */   {
/*  807 */     return this.fitToPages;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFitToPages(boolean b)
/*      */   {
/*  816 */     this.fitToPages = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPassword()
/*      */   {
/*  826 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassword(String s)
/*      */   {
/*  836 */     this.password = s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPasswordHash()
/*      */   {
/*  846 */     return this.passwordHash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPasswordHash(int ph)
/*      */   {
/*  856 */     this.passwordHash = ph;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDefaultColumnWidth()
/*      */   {
/*  866 */     return this.defaultColumnWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultColumnWidth(int w)
/*      */   {
/*  876 */     this.defaultColumnWidth = w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDefaultRowHeight()
/*      */   {
/*  886 */     return this.defaultRowHeight;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultRowHeight(int h)
/*      */   {
/*  896 */     this.defaultRowHeight = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getZoomFactor()
/*      */   {
/*  908 */     return this.zoomFactor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setZoomFactor(int zf)
/*      */   {
/*  920 */     this.zoomFactor = zf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPageBreakPreviewMagnification()
/*      */   {
/*  931 */     return this.pageBreakPreviewMagnification;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageBreakPreviewMagnification(int f)
/*      */   {
/*  942 */     this.pageBreakPreviewMagnification = f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNormalMagnification()
/*      */   {
/*  953 */     return this.normalMagnification;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNormalMagnification(int f)
/*      */   {
/*  964 */     this.normalMagnification = f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDisplayZeroValues()
/*      */   {
/*  975 */     return this.displayZeroValues;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisplayZeroValues(boolean b)
/*      */   {
/*  985 */     this.displayZeroValues = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getShowGridLines()
/*      */   {
/*  995 */     return this.showGridLines;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShowGridLines(boolean b)
/*      */   {
/* 1005 */     this.showGridLines = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPageBreakPreviewMode()
/*      */   {
/* 1015 */     return this.pageBreakPreviewMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageBreakPreviewMode(boolean b)
/*      */   {
/* 1025 */     this.pageBreakPreviewMode = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPrintGridLines()
/*      */   {
/* 1035 */     return this.printGridLines;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintGridLines(boolean b)
/*      */   {
/* 1045 */     this.printGridLines = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPrintHeaders()
/*      */   {
/* 1055 */     return this.printHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintHeaders(boolean b)
/*      */   {
/* 1065 */     this.printHeaders = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHorizontalFreeze()
/*      */   {
/* 1076 */     return this.horizontalFreeze;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHorizontalFreeze(int row)
/*      */   {
/* 1086 */     this.horizontalFreeze = Math.max(row, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getVerticalFreeze()
/*      */   {
/* 1097 */     return this.verticalFreeze;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVerticalFreeze(int col)
/*      */   {
/* 1107 */     this.verticalFreeze = Math.max(col, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCopies(int c)
/*      */   {
/* 1117 */     this.copies = c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCopies()
/*      */   {
/* 1127 */     return this.copies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HeaderFooter getHeader()
/*      */   {
/* 1137 */     return this.header;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeader(HeaderFooter h)
/*      */   {
/* 1147 */     this.header = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFooter(HeaderFooter f)
/*      */   {
/* 1157 */     this.footer = f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HeaderFooter getFooter()
/*      */   {
/* 1167 */     return this.footer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHorizontalCentre()
/*      */   {
/* 1177 */     return this.horizontalCentre;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHorizontalCentre(boolean horizCentre)
/*      */   {
/* 1187 */     this.horizontalCentre = horizCentre;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isVerticalCentre()
/*      */   {
/* 1197 */     return this.verticalCentre;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVerticalCentre(boolean vertCentre)
/*      */   {
/* 1207 */     this.verticalCentre = vertCentre;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutomaticFormulaCalculation(boolean auto)
/*      */   {
/* 1218 */     this.automaticFormulaCalculation = auto;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAutomaticFormulaCalculation()
/*      */   {
/* 1229 */     return this.automaticFormulaCalculation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRecalculateFormulasBeforeSave(boolean recalc)
/*      */   {
/* 1240 */     this.recalculateFormulasBeforeSave = recalc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRecalculateFormulasBeforeSave()
/*      */   {
/* 1251 */     return this.recalculateFormulasBeforeSave;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintArea(int firstCol, int firstRow, int lastCol, int lastRow)
/*      */   {
/* 1267 */     this.printArea = new SheetRangeImpl(this.sheet, firstCol, firstRow, lastCol, lastRow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range getPrintArea()
/*      */   {
/* 1278 */     return this.printArea;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintTitles(int firstRow, int lastRow, int firstCol, int lastCol)
/*      */   {
/* 1294 */     setPrintTitlesRow(firstRow, lastRow);
/* 1295 */     setPrintTitlesCol(firstCol, lastCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintTitlesRow(int firstRow, int lastRow)
/*      */   {
/* 1307 */     this.printTitlesRow = new SheetRangeImpl(this.sheet, 0, firstRow, 255, lastRow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintTitlesCol(int firstCol, int lastCol)
/*      */   {
/* 1320 */     this.printTitlesCol = new SheetRangeImpl(this.sheet, firstCol, 0, lastCol, 65535);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range getPrintTitlesRow()
/*      */   {
/* 1331 */     return this.printTitlesRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range getPrintTitlesCol()
/*      */   {
/* 1342 */     return this.printTitlesCol;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\SheetSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */