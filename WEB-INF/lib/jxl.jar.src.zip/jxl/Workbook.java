/*     */ package jxl;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.read.biff.PasswordException;
/*     */ import jxl.read.biff.WorkbookParser;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.biff.WritableWorkbookImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Workbook
/*     */ {
/*     */   private static final String VERSION = "2.6.12";
/*     */   
/*     */   public abstract Sheet[] getSheets();
/*     */   
/*     */   public abstract String[] getSheetNames();
/*     */   
/*     */   public abstract Sheet getSheet(int paramInt)
/*     */     throws IndexOutOfBoundsException;
/*     */   
/*     */   public abstract Sheet getSheet(String paramString);
/*     */   
/*     */   public static String getVersion()
/*     */   {
/* 104 */     return "2.6.12";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getNumberOfSheets();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Cell findCellByName(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Cell getCell(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Range[] findByName(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String[] getRangeNames();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isProtected();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void parse()
/*     */     throws BiffException, PasswordException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void close();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Workbook getWorkbook(java.io.File file)
/*     */     throws IOException, BiffException
/*     */   {
/* 198 */     return getWorkbook(file, new WorkbookSettings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Workbook getWorkbook(java.io.File file, WorkbookSettings ws)
/*     */     throws IOException, BiffException
/*     */   {
/* 213 */     FileInputStream fis = new FileInputStream(file);
/*     */     
/*     */ 
/*     */ 
/* 217 */     jxl.read.biff.File dataFile = null;
/*     */     
/*     */     try
/*     */     {
/* 221 */       dataFile = new jxl.read.biff.File(fis, ws);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 225 */       fis.close();
/* 226 */       throw e;
/*     */     }
/*     */     catch (BiffException e)
/*     */     {
/* 230 */       fis.close();
/* 231 */       throw e;
/*     */     }
/*     */     
/* 234 */     fis.close();
/*     */     
/* 236 */     Workbook workbook = new WorkbookParser(dataFile, ws);
/* 237 */     workbook.parse();
/*     */     
/* 239 */     return workbook;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Workbook getWorkbook(InputStream is)
/*     */     throws IOException, BiffException
/*     */   {
/* 253 */     return getWorkbook(is, new WorkbookSettings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Workbook getWorkbook(InputStream is, WorkbookSettings ws)
/*     */     throws IOException, BiffException
/*     */   {
/* 268 */     jxl.read.biff.File dataFile = new jxl.read.biff.File(is, ws);
/*     */     
/* 270 */     Workbook workbook = new WorkbookParser(dataFile, ws);
/* 271 */     workbook.parse();
/*     */     
/* 273 */     return workbook;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(java.io.File file)
/*     */     throws IOException
/*     */   {
/* 286 */     return createWorkbook(file, new WorkbookSettings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(java.io.File file, WorkbookSettings ws)
/*     */     throws IOException
/*     */   {
/* 301 */     FileOutputStream fos = new FileOutputStream(file);
/* 302 */     WritableWorkbook w = new WritableWorkbookImpl(fos, true, ws);
/* 303 */     return w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(java.io.File file, Workbook in)
/*     */     throws IOException
/*     */   {
/* 320 */     return createWorkbook(file, in, new WorkbookSettings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(java.io.File file, Workbook in, WorkbookSettings ws)
/*     */     throws IOException
/*     */   {
/* 338 */     FileOutputStream fos = new FileOutputStream(file);
/* 339 */     WritableWorkbook w = new WritableWorkbookImpl(fos, in, true, ws);
/* 340 */     return w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(OutputStream os, Workbook in)
/*     */     throws IOException
/*     */   {
/* 357 */     return createWorkbook(os, in, ((WorkbookParser)in).getSettings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(OutputStream os, Workbook in, WorkbookSettings ws)
/*     */     throws IOException
/*     */   {
/* 376 */     WritableWorkbook w = new WritableWorkbookImpl(os, in, false, ws);
/* 377 */     return w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(OutputStream os)
/*     */     throws IOException
/*     */   {
/* 393 */     return createWorkbook(os, new WorkbookSettings());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static WritableWorkbook createWorkbook(OutputStream os, WorkbookSettings ws)
/*     */     throws IOException
/*     */   {
/* 411 */     WritableWorkbook w = new WritableWorkbookImpl(os, false, ws);
/* 412 */     return w;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\Workbook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */