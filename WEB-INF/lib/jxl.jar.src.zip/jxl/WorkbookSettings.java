/*     */ package jxl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import jxl.biff.CountryCode;
/*     */ import jxl.biff.formula.FunctionNames;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WorkbookSettings
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(WorkbookSettings.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int initialFileSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int arrayGrowSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean drawingsDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean namesDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean formulaReferenceAdjustDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean gcDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rationalizationDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean mergedCellCheckingDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean propertySetsDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean cellValidationDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ignoreBlankCells;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean autoFilterDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean useTemporaryFileDuringWrite;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File temporaryFileDuringWriteDirectory;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Locale locale;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FunctionNames functionNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String encoding;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int characterSet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String excelDisplayLanguage;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String excelRegionalSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HashMap localeFunctionNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean refreshAll;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean template;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */   private boolean excel9file = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean windowProtected;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String writeAccess;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int hideobj;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HIDEOBJ_HIDE_ALL = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HIDEOBJ_SHOW_PLACEHOLDERS = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HIDEOBJ_SHOW_ALL = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int DEFAULT_INITIAL_FILE_SIZE = 5242880;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int DEFAULT_ARRAY_GROW_SIZE = 1048576;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WorkbookSettings()
/*     */   {
/* 254 */     this.initialFileSize = 5242880;
/* 255 */     this.arrayGrowSize = 1048576;
/* 256 */     this.localeFunctionNames = new HashMap();
/* 257 */     this.excelDisplayLanguage = CountryCode.USA.getCode();
/* 258 */     this.excelRegionalSettings = CountryCode.UK.getCode();
/* 259 */     this.refreshAll = false;
/* 260 */     this.template = false;
/* 261 */     this.excel9file = false;
/* 262 */     this.windowProtected = false;
/* 263 */     this.hideobj = 0;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 268 */       boolean suppressWarnings = Boolean.getBoolean("jxl.nowarnings");
/* 269 */       setSuppressWarnings(suppressWarnings);
/* 270 */       this.drawingsDisabled = Boolean.getBoolean("jxl.nodrawings");
/* 271 */       this.namesDisabled = Boolean.getBoolean("jxl.nonames");
/* 272 */       this.gcDisabled = Boolean.getBoolean("jxl.nogc");
/* 273 */       this.rationalizationDisabled = Boolean.getBoolean("jxl.norat");
/* 274 */       this.mergedCellCheckingDisabled = Boolean.getBoolean("jxl.nomergedcellchecks");
/*     */       
/* 276 */       this.formulaReferenceAdjustDisabled = Boolean.getBoolean("jxl.noformulaadjust");
/*     */       
/* 278 */       this.propertySetsDisabled = Boolean.getBoolean("jxl.nopropertysets");
/* 279 */       this.ignoreBlankCells = Boolean.getBoolean("jxl.ignoreblanks");
/* 280 */       this.cellValidationDisabled = Boolean.getBoolean("jxl.nocellvalidation");
/* 281 */       this.autoFilterDisabled = (!Boolean.getBoolean("jxl.autofilter"));
/*     */       
/* 283 */       this.useTemporaryFileDuringWrite = Boolean.getBoolean("jxl.usetemporaryfileduringwrite");
/*     */       
/* 285 */       String tempdir = System.getProperty("jxl.temporaryfileduringwritedirectory");
/*     */       
/*     */ 
/* 288 */       if (tempdir != null)
/*     */       {
/* 290 */         this.temporaryFileDuringWriteDirectory = new File(tempdir);
/*     */       }
/*     */       
/* 293 */       this.encoding = System.getProperty("file.encoding");
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/* 297 */       logger.warn("Error accessing system properties.", e);
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 303 */       if ((System.getProperty("jxl.lang") == null) || (System.getProperty("jxl.country") == null))
/*     */       {
/*     */ 
/* 306 */         this.locale = Locale.getDefault();
/*     */       }
/*     */       else
/*     */       {
/* 310 */         this.locale = new Locale(System.getProperty("jxl.lang"), System.getProperty("jxl.country"));
/*     */       }
/*     */       
/*     */ 
/* 314 */       if (System.getProperty("jxl.encoding") != null)
/*     */       {
/* 316 */         this.encoding = System.getProperty("jxl.encoding");
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/* 321 */       logger.warn("Error accessing system properties.", e);
/* 322 */       this.locale = Locale.getDefault();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArrayGrowSize(int sz)
/*     */   {
/* 337 */     this.arrayGrowSize = sz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getArrayGrowSize()
/*     */   {
/* 347 */     return this.arrayGrowSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInitialFileSize(int sz)
/*     */   {
/* 360 */     this.initialFileSize = sz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInitialFileSize()
/*     */   {
/* 370 */     return this.initialFileSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDrawingsDisabled()
/*     */   {
/* 380 */     return this.drawingsDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getGCDisabled()
/*     */   {
/* 390 */     return this.gcDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getNamesDisabled()
/*     */   {
/* 400 */     return this.namesDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamesDisabled(boolean b)
/*     */   {
/* 410 */     this.namesDisabled = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingsDisabled(boolean b)
/*     */   {
/* 420 */     this.drawingsDisabled = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRationalization(boolean r)
/*     */   {
/* 431 */     this.rationalizationDisabled = (!r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRationalizationDisabled()
/*     */   {
/* 441 */     return this.rationalizationDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getMergedCellCheckingDisabled()
/*     */   {
/* 451 */     return this.mergedCellCheckingDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMergedCellChecking(boolean b)
/*     */   {
/* 461 */     this.mergedCellCheckingDisabled = (!b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertySets(boolean r)
/*     */   {
/* 474 */     this.propertySetsDisabled = (!r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getPropertySetsDisabled()
/*     */   {
/* 484 */     return this.propertySetsDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuppressWarnings(boolean w)
/*     */   {
/* 496 */     logger.setSuppressWarnings(w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFormulaAdjust()
/*     */   {
/* 507 */     return !this.formulaReferenceAdjustDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormulaAdjust(boolean b)
/*     */   {
/* 517 */     this.formulaReferenceAdjustDisabled = (!b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(Locale l)
/*     */   {
/* 529 */     this.locale = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 539 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 549 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String enc)
/*     */   {
/* 559 */     this.encoding = enc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FunctionNames getFunctionNames()
/*     */   {
/* 571 */     if (this.functionNames == null)
/*     */     {
/* 573 */       this.functionNames = ((FunctionNames)this.localeFunctionNames.get(this.locale));
/*     */       
/*     */ 
/*     */ 
/* 577 */       if (this.functionNames == null)
/*     */       {
/* 579 */         this.functionNames = new FunctionNames(this.locale);
/* 580 */         this.localeFunctionNames.put(this.locale, this.functionNames);
/*     */       }
/*     */     }
/*     */     
/* 584 */     return this.functionNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCharacterSet()
/*     */   {
/* 595 */     return this.characterSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterSet(int cs)
/*     */   {
/* 606 */     this.characterSet = cs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGCDisabled(boolean disabled)
/*     */   {
/* 616 */     this.gcDisabled = disabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreBlanks(boolean ignoreBlanks)
/*     */   {
/* 626 */     this.ignoreBlankCells = ignoreBlanks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getIgnoreBlanks()
/*     */   {
/* 636 */     return this.ignoreBlankCells;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellValidationDisabled(boolean cv)
/*     */   {
/* 646 */     this.cellValidationDisabled = cv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCellValidationDisabled()
/*     */   {
/* 656 */     return this.cellValidationDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExcelDisplayLanguage()
/*     */   {
/* 666 */     return this.excelDisplayLanguage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExcelRegionalSettings()
/*     */   {
/* 676 */     return this.excelRegionalSettings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcelDisplayLanguage(String code)
/*     */   {
/* 686 */     this.excelDisplayLanguage = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcelRegionalSettings(String code)
/*     */   {
/* 696 */     this.excelRegionalSettings = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAutoFilterDisabled()
/*     */   {
/* 706 */     return this.autoFilterDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoFilterDisabled(boolean disabled)
/*     */   {
/* 716 */     this.autoFilterDisabled = disabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseTemporaryFileDuringWrite()
/*     */   {
/* 731 */     return this.useTemporaryFileDuringWrite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseTemporaryFileDuringWrite(boolean temp)
/*     */   {
/* 746 */     this.useTemporaryFileDuringWrite = temp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemporaryFileDuringWriteDirectory(File dir)
/*     */   {
/* 760 */     this.temporaryFileDuringWriteDirectory = dir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getTemporaryFileDuringWriteDirectory()
/*     */   {
/* 774 */     return this.temporaryFileDuringWriteDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefreshAll(boolean refreshAll)
/*     */   {
/* 786 */     this.refreshAll = refreshAll;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRefreshAll()
/*     */   {
/* 797 */     return this.refreshAll;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getTemplate()
/*     */   {
/* 806 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplate(boolean template)
/*     */   {
/* 815 */     this.template = template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getExcel9File()
/*     */   {
/* 825 */     return this.excel9file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcel9File(boolean excel9file)
/*     */   {
/* 833 */     this.excel9file = excel9file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getWindowProtected()
/*     */   {
/* 841 */     return this.windowProtected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWindowProtected(boolean windowprotected)
/*     */   {
/* 849 */     this.windowProtected = this.windowProtected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHideobj()
/*     */   {
/* 861 */     return this.hideobj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHideobj(int hideobj)
/*     */   {
/* 873 */     this.hideobj = hideobj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWriteAccess()
/*     */   {
/* 881 */     return this.writeAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriteAccess(String writeAccess)
/*     */   {
/* 889 */     this.writeAccess = writeAccess;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\WorkbookSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */