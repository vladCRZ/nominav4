/*    */ package jxl.biff;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import jxl.write.biff.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoFilter
/*    */ {
/*    */   private FilterModeRecord filterMode;
/*    */   private AutoFilterInfoRecord autoFilterInfo;
/*    */   private AutoFilterRecord autoFilter;
/*    */   
/*    */   public AutoFilter(FilterModeRecord fmr, AutoFilterInfoRecord afir)
/*    */   {
/* 41 */     this.filterMode = fmr;
/* 42 */     this.autoFilterInfo = afir;
/*    */   }
/*    */   
/*    */   public void add(AutoFilterRecord af)
/*    */   {
/* 47 */     this.autoFilter = af;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void write(File outputFile)
/*    */     throws IOException
/*    */   {
/* 58 */     if (this.filterMode != null)
/*    */     {
/* 60 */       outputFile.write(this.filterMode);
/*    */     }
/*    */     
/* 63 */     if (this.autoFilterInfo != null)
/*    */     {
/* 65 */       outputFile.write(this.autoFilterInfo);
/*    */     }
/*    */     
/* 68 */     if (this.autoFilter != null)
/*    */     {
/* 70 */       outputFile.write(this.autoFilter);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\AutoFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */