/*    */ package jxl.biff;
/*    */ 
/*    */ import jxl.common.Logger;
/*    */ import jxl.read.biff.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoFilterInfoRecord
/*    */   extends WritableRecordData
/*    */ {
/* 32 */   private static Logger logger = Logger.getLogger(AutoFilterInfoRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private byte[] data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AutoFilterInfoRecord(Record t)
/*    */   {
/* 45 */     super(t);
/*    */     
/* 47 */     this.data = getRecord().getData();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 57 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\AutoFilterInfoRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */