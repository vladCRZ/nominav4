/*     */ package jxl.biff;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.Range;
/*     */ import jxl.biff.drawing.ComboBox;
/*     */ import jxl.biff.drawing.Comment;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.CellValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseCellFeatures
/*     */ {
/*  41 */   public static Logger logger = Logger.getLogger(BaseCellFeatures.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private String comment;
/*     */   
/*     */ 
/*     */ 
/*     */   private double commentWidth;
/*     */   
/*     */ 
/*     */ 
/*     */   private double commentHeight;
/*     */   
/*     */ 
/*     */ 
/*     */   private Comment commentDrawing;
/*     */   
/*     */ 
/*     */ 
/*     */   private ComboBox comboBox;
/*     */   
/*     */ 
/*     */ 
/*     */   private DataValiditySettingsRecord validationSettings;
/*     */   
/*     */ 
/*     */ 
/*     */   private DVParser dvParser;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean dropDown;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean dataValidation;
/*     */   
/*     */ 
/*     */ 
/*     */   private CellValue writableCell;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final double defaultCommentWidth = 3.0D;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final double defaultCommentHeight = 4.0D;
/*     */   
/*     */ 
/*     */ 
/*     */   protected BaseCellFeatures() {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected static class ValidationCondition
/*     */   {
/*     */     private DVParser.Condition condition;
/*     */     
/*     */ 
/* 102 */     private static ValidationCondition[] types = new ValidationCondition[0];
/*     */     
/*     */     ValidationCondition(DVParser.Condition c)
/*     */     {
/* 106 */       this.condition = c;
/* 107 */       ValidationCondition[] oldtypes = types;
/* 108 */       types = new ValidationCondition[oldtypes.length + 1];
/* 109 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/* 110 */       types[oldtypes.length] = this;
/*     */     }
/*     */     
/*     */     public DVParser.Condition getCondition()
/*     */     {
/* 115 */       return this.condition;
/*     */     }
/*     */   }
/*     */   
/* 119 */   public static final ValidationCondition BETWEEN = new ValidationCondition(DVParser.BETWEEN);
/*     */   
/* 121 */   public static final ValidationCondition NOT_BETWEEN = new ValidationCondition(DVParser.NOT_BETWEEN);
/*     */   
/* 123 */   public static final ValidationCondition EQUAL = new ValidationCondition(DVParser.EQUAL);
/*     */   
/* 125 */   public static final ValidationCondition NOT_EQUAL = new ValidationCondition(DVParser.NOT_EQUAL);
/*     */   
/* 127 */   public static final ValidationCondition GREATER_THAN = new ValidationCondition(DVParser.GREATER_THAN);
/*     */   
/* 129 */   public static final ValidationCondition LESS_THAN = new ValidationCondition(DVParser.LESS_THAN);
/*     */   
/* 131 */   public static final ValidationCondition GREATER_EQUAL = new ValidationCondition(DVParser.GREATER_EQUAL);
/*     */   
/* 133 */   public static final ValidationCondition LESS_EQUAL = new ValidationCondition(DVParser.LESS_EQUAL);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseCellFeatures(BaseCellFeatures cf)
/*     */   {
/* 151 */     this.comment = cf.comment;
/* 152 */     this.commentWidth = cf.commentWidth;
/* 153 */     this.commentHeight = cf.commentHeight;
/*     */     
/*     */ 
/* 156 */     this.dropDown = cf.dropDown;
/* 157 */     this.dataValidation = cf.dataValidation;
/*     */     
/* 159 */     this.validationSettings = cf.validationSettings;
/*     */     
/* 161 */     if (cf.dvParser != null)
/*     */     {
/* 163 */       this.dvParser = new DVParser(cf.dvParser);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getComment()
/*     */   {
/* 172 */     return this.comment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getCommentWidth()
/*     */   {
/* 180 */     return this.commentWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getCommentHeight()
/*     */   {
/* 188 */     return this.commentHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setWritableCell(CellValue wc)
/*     */   {
/* 198 */     this.writableCell = wc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadComment(String s, double w, double h)
/*     */   {
/* 206 */     this.comment = s;
/* 207 */     this.commentWidth = w;
/* 208 */     this.commentHeight = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidationSettings(DataValiditySettingsRecord dvsr)
/*     */   {
/* 216 */     Assert.verify(dvsr != null);
/*     */     
/* 218 */     this.validationSettings = dvsr;
/* 219 */     this.dataValidation = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComment(String s)
/*     */   {
/* 229 */     setComment(s, 3.0D, 4.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComment(String s, double width, double height)
/*     */   {
/* 241 */     this.comment = s;
/* 242 */     this.commentWidth = width;
/* 243 */     this.commentHeight = height;
/*     */     
/* 245 */     if (this.commentDrawing != null)
/*     */     {
/* 247 */       this.commentDrawing.setCommentText(s);
/* 248 */       this.commentDrawing.setWidth(width);
/* 249 */       this.commentDrawing.setWidth(height);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeComment()
/*     */   {
/* 260 */     this.comment = null;
/*     */     
/*     */ 
/* 263 */     if (this.commentDrawing != null)
/*     */     {
/*     */ 
/*     */ 
/* 267 */       this.writableCell.removeComment(this.commentDrawing);
/* 268 */       this.commentDrawing = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeDataValidation()
/*     */   {
/* 277 */     if (!this.dataValidation)
/*     */     {
/* 279 */       return;
/*     */     }
/*     */     
/*     */ 
/* 283 */     DVParser dvp = getDVParser();
/* 284 */     if (dvp.extendedCellsValidation())
/*     */     {
/* 286 */       logger.warn("Cannot remove data validation from " + CellReferenceHelper.getCellReference(this.writableCell) + " as it is part of the shared reference " + CellReferenceHelper.getCellReference(dvp.getFirstColumn(), dvp.getFirstRow()) + "-" + CellReferenceHelper.getCellReference(dvp.getLastColumn(), dvp.getLastRow()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 294 */       return;
/*     */     }
/*     */     
/*     */ 
/* 298 */     this.writableCell.removeDataValidation();
/* 299 */     clearValidationSettings();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSharedDataValidation()
/*     */   {
/* 309 */     if (!this.dataValidation)
/*     */     {
/* 311 */       return;
/*     */     }
/*     */     
/*     */ 
/* 315 */     this.writableCell.removeDataValidation();
/* 316 */     clearValidationSettings();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCommentDrawing(Comment c)
/*     */   {
/* 324 */     this.commentDrawing = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Comment getCommentDrawing()
/*     */   {
/* 332 */     return this.commentDrawing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDataValidationList()
/*     */   {
/* 342 */     if (this.validationSettings == null)
/*     */     {
/* 344 */       return null;
/*     */     }
/*     */     
/* 347 */     return this.validationSettings.getValidationFormula();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataValidationList(Collection c)
/*     */   {
/* 359 */     if ((this.dataValidation) && (getDVParser().extendedCellsValidation()))
/*     */     {
/* 361 */       logger.warn("Cannot set data validation on " + CellReferenceHelper.getCellReference(this.writableCell) + " as it is part of a shared data validation");
/*     */       
/*     */ 
/* 364 */       return;
/*     */     }
/* 366 */     clearValidationSettings();
/* 367 */     this.dvParser = new DVParser(c);
/* 368 */     this.dropDown = true;
/* 369 */     this.dataValidation = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataValidationRange(int col1, int r1, int col2, int r2)
/*     */   {
/* 379 */     if ((this.dataValidation) && (getDVParser().extendedCellsValidation()))
/*     */     {
/* 381 */       logger.warn("Cannot set data validation on " + CellReferenceHelper.getCellReference(this.writableCell) + " as it is part of a shared data validation");
/*     */       
/*     */ 
/* 384 */       return;
/*     */     }
/* 386 */     clearValidationSettings();
/* 387 */     this.dvParser = new DVParser(col1, r1, col2, r2);
/* 388 */     this.dropDown = true;
/* 389 */     this.dataValidation = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataValidationRange(String namedRange)
/*     */   {
/* 397 */     if ((this.dataValidation) && (getDVParser().extendedCellsValidation()))
/*     */     {
/* 399 */       logger.warn("Cannot set data validation on " + CellReferenceHelper.getCellReference(this.writableCell) + " as it is part of a shared data validation");
/*     */       
/*     */ 
/* 402 */       return;
/*     */     }
/* 404 */     clearValidationSettings();
/* 405 */     this.dvParser = new DVParser(namedRange);
/* 406 */     this.dropDown = true;
/* 407 */     this.dataValidation = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumberValidation(double val, ValidationCondition c)
/*     */   {
/* 415 */     if ((this.dataValidation) && (getDVParser().extendedCellsValidation()))
/*     */     {
/* 417 */       logger.warn("Cannot set data validation on " + CellReferenceHelper.getCellReference(this.writableCell) + " as it is part of a shared data validation");
/*     */       
/*     */ 
/* 420 */       return;
/*     */     }
/* 422 */     clearValidationSettings();
/* 423 */     this.dvParser = new DVParser(val, NaN.0D, c.getCondition());
/* 424 */     this.dropDown = false;
/* 425 */     this.dataValidation = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setNumberValidation(double val1, double val2, ValidationCondition c)
/*     */   {
/* 431 */     if ((this.dataValidation) && (getDVParser().extendedCellsValidation()))
/*     */     {
/* 433 */       logger.warn("Cannot set data validation on " + CellReferenceHelper.getCellReference(this.writableCell) + " as it is part of a shared data validation");
/*     */       
/*     */ 
/* 436 */       return;
/*     */     }
/* 438 */     clearValidationSettings();
/* 439 */     this.dvParser = new DVParser(val1, val2, c.getCondition());
/* 440 */     this.dropDown = false;
/* 441 */     this.dataValidation = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasDataValidation()
/*     */   {
/* 452 */     return this.dataValidation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void clearValidationSettings()
/*     */   {
/* 460 */     this.validationSettings = null;
/* 461 */     this.dvParser = null;
/* 462 */     this.dropDown = false;
/* 463 */     this.comboBox = null;
/* 464 */     this.dataValidation = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasDropDown()
/*     */   {
/* 474 */     return this.dropDown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComboBox(ComboBox cb)
/*     */   {
/* 484 */     this.comboBox = cb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DVParser getDVParser()
/*     */   {
/* 493 */     if (this.dvParser != null)
/*     */     {
/* 495 */       return this.dvParser;
/*     */     }
/*     */     
/*     */ 
/* 499 */     if (this.validationSettings != null)
/*     */     {
/* 501 */       this.dvParser = new DVParser(this.validationSettings.getDVParser());
/* 502 */       return this.dvParser;
/*     */     }
/*     */     
/* 505 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shareDataValidation(BaseCellFeatures source)
/*     */   {
/* 515 */     if (this.dataValidation)
/*     */     {
/* 517 */       logger.warn("Attempting to share a data validation on cell " + CellReferenceHelper.getCellReference(this.writableCell) + " which already has a data validation");
/*     */       
/*     */ 
/* 520 */       return;
/*     */     }
/* 522 */     clearValidationSettings();
/* 523 */     this.dvParser = source.getDVParser();
/* 524 */     this.validationSettings = null;
/* 525 */     this.dataValidation = true;
/* 526 */     this.dropDown = source.dropDown;
/* 527 */     this.comboBox = source.comboBox;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Range getSharedDataValidationRange()
/*     */   {
/* 540 */     if (!this.dataValidation)
/*     */     {
/* 542 */       return null;
/*     */     }
/*     */     
/* 545 */     DVParser dvp = getDVParser();
/*     */     
/* 547 */     return new SheetRangeImpl(this.writableCell.getSheet(), dvp.getFirstColumn(), dvp.getFirstRow(), dvp.getLastColumn(), dvp.getLastRow());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\BaseCellFeatures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */