/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseCompoundFile
/*     */ {
/*  33 */   private static Logger logger = Logger.getLogger(BaseCompoundFile.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   protected static final byte[] IDENTIFIER = { -48, -49, 17, -32, -95, -79, 26, -31 };
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final int NUM_BIG_BLOCK_DEPOT_BLOCKS_POS = 44;
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final int SMALL_BLOCK_DEPOT_BLOCK_POS = 60;
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final int NUM_SMALL_BLOCK_DEPOT_BLOCKS_POS = 64;
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final int ROOT_START_BLOCK_POS = 48;
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final int BIG_BLOCK_SIZE = 512;
/*     */   
/*     */ 
/*     */   protected static final int SMALL_BLOCK_SIZE = 64;
/*     */   
/*     */ 
/*     */   protected static final int EXTENSION_BLOCK_POS = 68;
/*     */   
/*     */ 
/*     */   protected static final int NUM_EXTENSION_BLOCK_POS = 72;
/*     */   
/*     */ 
/*     */   protected static final int PROPERTY_STORAGE_BLOCK_SIZE = 128;
/*     */   
/*     */ 
/*     */   protected static final int BIG_BLOCK_DEPOT_BLOCKS_POS = 76;
/*     */   
/*     */ 
/*     */   protected static final int SMALL_BLOCK_THRESHOLD = 4096;
/*     */   
/*     */ 
/*     */   private static final int SIZE_OF_NAME_POS = 64;
/*     */   
/*     */ 
/*     */   private static final int TYPE_POS = 66;
/*     */   
/*     */ 
/*     */   private static final int COLOUR_POS = 67;
/*     */   
/*     */ 
/*     */   private static final int PREVIOUS_POS = 68;
/*     */   
/*     */ 
/*     */   private static final int NEXT_POS = 72;
/*     */   
/*     */ 
/*     */   private static final int CHILD_POS = 76;
/*     */   
/*     */ 
/*     */   private static final int START_BLOCK_POS = 116;
/*     */   
/*     */ 
/*     */   private static final int SIZE_POS = 120;
/*     */   
/*     */ 
/*     */   public static final String ROOT_ENTRY_NAME = "Root Entry";
/*     */   
/*     */ 
/*     */   public static final String WORKBOOK_NAME = "Workbook";
/*     */   
/*     */ 
/*     */   public static final String SUMMARY_INFORMATION_NAME = "\005SummaryInformation";
/*     */   
/*     */ 
/*     */   public static final String DOCUMENT_SUMMARY_INFORMATION_NAME = "\005DocumentSummaryInformation";
/*     */   
/*     */ 
/*     */   public static final String COMP_OBJ_NAME = "\001CompObj";
/*     */   
/*     */ 
/* 118 */   public static final String[] STANDARD_PROPERTY_SETS = { "Root Entry", "Workbook", "\005SummaryInformation", "\005DocumentSummaryInformation" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int NONE_PS_TYPE = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DIRECTORY_PS_TYPE = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int FILE_PS_TYPE = 2;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int ROOT_ENTRY_PS_TYPE = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public class PropertyStorage
/*     */   {
/*     */     public String name;
/*     */     
/*     */ 
/*     */ 
/*     */     public int type;
/*     */     
/*     */ 
/*     */ 
/*     */     public int colour;
/*     */     
/*     */ 
/*     */ 
/*     */     public int startBlock;
/*     */     
/*     */ 
/*     */ 
/*     */     public int size;
/*     */     
/*     */ 
/*     */ 
/*     */     public int previous;
/*     */     
/*     */ 
/*     */ 
/*     */     public int next;
/*     */     
/*     */ 
/*     */ 
/*     */     public int child;
/*     */     
/*     */ 
/*     */ 
/*     */     public byte[] data;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public PropertyStorage(byte[] d)
/*     */     {
/* 183 */       this.data = d;
/* 184 */       int nameSize = IntegerHelper.getInt(this.data[64], this.data[65]);
/*     */       
/*     */ 
/* 187 */       if (nameSize > 64)
/*     */       {
/* 189 */         BaseCompoundFile.logger.warn("property set name exceeds max length - truncating");
/* 190 */         nameSize = 64;
/*     */       }
/*     */       
/* 193 */       this.type = this.data[66];
/* 194 */       this.colour = this.data[67];
/*     */       
/* 196 */       this.startBlock = IntegerHelper.getInt(this.data[116], this.data[117], this.data[118], this.data[119]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 201 */       this.size = IntegerHelper.getInt(this.data[120], this.data[121], this.data[122], this.data[123]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 206 */       this.previous = IntegerHelper.getInt(this.data[68], this.data[69], this.data[70], this.data[71]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 211 */       this.next = IntegerHelper.getInt(this.data[72], this.data[73], this.data[74], this.data[75]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 216 */       this.child = IntegerHelper.getInt(this.data[76], this.data[77], this.data[78], this.data[79]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 222 */       int chars = 0;
/* 223 */       if (nameSize > 2)
/*     */       {
/* 225 */         chars = (nameSize - 1) / 2;
/*     */       }
/*     */       
/* 228 */       StringBuffer n = new StringBuffer("");
/* 229 */       for (int i = 0; i < chars; i++)
/*     */       {
/* 231 */         n.append((char)this.data[(i * 2)]);
/*     */       }
/*     */       
/* 234 */       this.name = n.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public PropertyStorage(String name)
/*     */     {
/* 244 */       this.data = new byte[''];
/*     */       
/* 246 */       Assert.verify(name.length() < 32);
/*     */       
/* 248 */       IntegerHelper.getTwoBytes((name.length() + 1) * 2, this.data, 64);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 253 */       for (int i = 0; i < name.length(); i++)
/*     */       {
/* 255 */         this.data[(i * 2)] = ((byte)name.charAt(i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setType(int t)
/*     */     {
/* 266 */       this.type = t;
/* 267 */       this.data[66] = ((byte)t);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setStartBlock(int sb)
/*     */     {
/* 277 */       this.startBlock = sb;
/* 278 */       IntegerHelper.getFourBytes(sb, this.data, 116);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setSize(int s)
/*     */     {
/* 288 */       this.size = s;
/* 289 */       IntegerHelper.getFourBytes(s, this.data, 120);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setPrevious(int prev)
/*     */     {
/* 299 */       this.previous = prev;
/* 300 */       IntegerHelper.getFourBytes(prev, this.data, 68);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setNext(int nxt)
/*     */     {
/* 310 */       this.next = nxt;
/* 311 */       IntegerHelper.getFourBytes(this.next, this.data, 72);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setChild(int dir)
/*     */     {
/* 321 */       this.child = dir;
/* 322 */       IntegerHelper.getFourBytes(this.child, this.data, 76);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setColour(int col)
/*     */     {
/* 332 */       this.colour = (col == 0 ? 0 : 1);
/* 333 */       this.data[67] = ((byte)this.colour);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\BaseCompoundFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */