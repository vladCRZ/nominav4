/*     */ package jxl.biff;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuiltInName
/*     */ {
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private static BuiltInName[] builtInNames = new BuiltInName[0];
/*     */   
/*     */ 
/*     */ 
/*     */   private BuiltInName(String n, int v)
/*     */   {
/*  46 */     this.name = n;
/*  47 */     this.value = v;
/*     */     
/*  49 */     BuiltInName[] oldnames = builtInNames;
/*  50 */     builtInNames = new BuiltInName[oldnames.length + 1];
/*  51 */     System.arraycopy(oldnames, 0, builtInNames, 0, oldnames.length);
/*  52 */     builtInNames[oldnames.length] = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  62 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  72 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BuiltInName getBuiltInName(int val)
/*     */   {
/*  80 */     BuiltInName ret = FILTER_DATABASE;
/*  81 */     for (int i = 0; i < builtInNames.length; i++)
/*     */     {
/*  83 */       if (builtInNames[i].getValue() == val)
/*     */       {
/*  85 */         ret = builtInNames[i];
/*     */       }
/*     */     }
/*  88 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*  92 */   public static final BuiltInName CONSOLIDATE_AREA = new BuiltInName("Consolidate_Area", 0);
/*     */   
/*  94 */   public static final BuiltInName AUTO_OPEN = new BuiltInName("Auto_Open", 1);
/*     */   
/*  96 */   public static final BuiltInName AUTO_CLOSE = new BuiltInName("Auto_Open", 2);
/*     */   
/*  98 */   public static final BuiltInName EXTRACT = new BuiltInName("Extract", 3);
/*     */   
/* 100 */   public static final BuiltInName DATABASE = new BuiltInName("Database", 4);
/*     */   
/* 102 */   public static final BuiltInName CRITERIA = new BuiltInName("Criteria", 5);
/*     */   
/* 104 */   public static final BuiltInName PRINT_AREA = new BuiltInName("Print_Area", 6);
/*     */   
/* 106 */   public static final BuiltInName PRINT_TITLES = new BuiltInName("Print_Titles", 7);
/*     */   
/* 108 */   public static final BuiltInName RECORDER = new BuiltInName("Recorder", 8);
/*     */   
/* 110 */   public static final BuiltInName DATA_FORM = new BuiltInName("Data_Form", 9);
/*     */   
/* 112 */   public static final BuiltInName AUTO_ACTIVATE = new BuiltInName("Auto_Activate", 10);
/*     */   
/* 114 */   public static final BuiltInName AUTO_DEACTIVATE = new BuiltInName("Auto_Deactivate", 11);
/*     */   
/* 116 */   public static final BuiltInName SHEET_TITLE = new BuiltInName("Sheet_Title", 11);
/*     */   
/* 118 */   public static final BuiltInName FILTER_DATABASE = new BuiltInName("_FilterDatabase", 13);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\BuiltInName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */