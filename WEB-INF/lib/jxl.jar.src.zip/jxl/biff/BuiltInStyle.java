/*    */ package jxl.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BuiltInStyle
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int xfIndex;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int styleNumber;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BuiltInStyle(int xfind, int sn)
/*    */   {
/* 46 */     super(Type.STYLE);
/*    */     
/* 48 */     this.xfIndex = xfind;
/* 49 */     this.styleNumber = sn;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 59 */     byte[] data = new byte[4];
/*    */     
/* 61 */     IntegerHelper.getTwoBytes(this.xfIndex, data, 0); int 
/*    */     
/*    */ 
/* 64 */       tmp15_14 = 1; byte[] tmp15_13 = data;tmp15_13[tmp15_14] = ((byte)(tmp15_13[tmp15_14] | 0x80));
/*    */     
/* 66 */     data[2] = ((byte)this.styleNumber);
/*    */     
/*    */ 
/* 69 */     data[3] = -1;
/*    */     
/* 71 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\BuiltInStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */