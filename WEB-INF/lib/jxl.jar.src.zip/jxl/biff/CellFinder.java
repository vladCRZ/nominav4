/*     */ package jxl.biff;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.Sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellFinder
/*     */ {
/*     */   private Sheet sheet;
/*     */   
/*     */   public CellFinder(Sheet s)
/*     */   {
/*  40 */     this.sheet = s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell findCell(String contents, int firstCol, int firstRow, int lastCol, int lastRow, boolean reverse)
/*     */   {
/*  64 */     Cell cell = null;
/*  65 */     boolean found = false;
/*     */     
/*  67 */     int numCols = lastCol - firstCol;
/*  68 */     int numRows = lastRow - firstRow;
/*     */     
/*  70 */     int row1 = reverse ? lastRow : firstRow;
/*  71 */     int row2 = reverse ? firstRow : lastRow;
/*  72 */     int col1 = reverse ? lastCol : firstCol;
/*  73 */     int col2 = reverse ? firstCol : lastCol;
/*  74 */     int inc = reverse ? -1 : 1;
/*     */     
/*  76 */     for (int i = 0; (i <= numCols) && (!found); i++)
/*     */     {
/*  78 */       for (int j = 0; (j <= numRows) && (!found); j++)
/*     */       {
/*  80 */         int curCol = col1 + i * inc;
/*  81 */         int curRow = row1 + j * inc;
/*  82 */         if ((curCol < this.sheet.getColumns()) && (curRow < this.sheet.getRows()))
/*     */         {
/*  84 */           Cell c = this.sheet.getCell(curCol, curRow);
/*  85 */           if (c.getType() != CellType.EMPTY)
/*     */           {
/*  87 */             if (c.getContents().equals(contents))
/*     */             {
/*  89 */               cell = c;
/*  90 */               found = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  97 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell findCell(String contents)
/*     */   {
/* 108 */     Cell cell = null;
/* 109 */     boolean found = false;
/*     */     
/* 111 */     for (int i = 0; (i < this.sheet.getRows()) && (!found); i++)
/*     */     {
/* 113 */       Cell[] row = this.sheet.getRow(i);
/* 114 */       for (int j = 0; (j < row.length) && (!found); j++)
/*     */       {
/* 116 */         if (row[j].getContents().equals(contents))
/*     */         {
/* 118 */           cell = row[j];
/* 119 */           found = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 124 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell findCell(Pattern pattern, int firstCol, int firstRow, int lastCol, int lastRow, boolean reverse)
/*     */   {
/* 148 */     Cell cell = null;
/* 149 */     boolean found = false;
/*     */     
/* 151 */     int numCols = lastCol - firstCol;
/* 152 */     int numRows = lastRow - firstRow;
/*     */     
/* 154 */     int row1 = reverse ? lastRow : firstRow;
/* 155 */     int row2 = reverse ? firstRow : lastRow;
/* 156 */     int col1 = reverse ? lastCol : firstCol;
/* 157 */     int col2 = reverse ? firstCol : lastCol;
/* 158 */     int inc = reverse ? -1 : 1;
/*     */     
/* 160 */     for (int i = 0; (i <= numCols) && (!found); i++)
/*     */     {
/* 162 */       for (int j = 0; (j <= numRows) && (!found); j++)
/*     */       {
/* 164 */         int curCol = col1 + i * inc;
/* 165 */         int curRow = row1 + j * inc;
/* 166 */         if ((curCol < this.sheet.getColumns()) && (curRow < this.sheet.getRows()))
/*     */         {
/* 168 */           Cell c = this.sheet.getCell(curCol, curRow);
/* 169 */           if (c.getType() != CellType.EMPTY)
/*     */           {
/* 171 */             Matcher m = pattern.matcher(c.getContents());
/* 172 */             if (m.matches())
/*     */             {
/* 174 */               cell = c;
/* 175 */               found = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 182 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LabelCell findLabelCell(String contents)
/*     */   {
/* 199 */     LabelCell cell = null;
/* 200 */     boolean found = false;
/*     */     
/* 202 */     for (int i = 0; (i < this.sheet.getRows()) && (!found); i++)
/*     */     {
/* 204 */       Cell[] row = this.sheet.getRow(i);
/* 205 */       for (int j = 0; (j < row.length) && (!found); j++)
/*     */       {
/* 207 */         if (((row[j].getType() == CellType.LABEL) || (row[j].getType() == CellType.STRING_FORMULA)) && (row[j].getContents().equals(contents)))
/*     */         {
/*     */ 
/*     */ 
/* 211 */           cell = (LabelCell)row[j];
/* 212 */           found = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 217 */     return cell;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\CellFinder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */