/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CellReferenceHelper
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(CellReferenceHelper.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final char fixedInd = '$';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final char sheetInd = '!';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int column, int row, StringBuffer buf)
/*     */   {
/*  68 */     getColumnReference(column, buf);
/*     */     
/*     */ 
/*  71 */     buf.append(Integer.toString(row + 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int column, boolean colabs, int row, boolean rowabs, StringBuffer buf)
/*     */   {
/*  87 */     if (colabs)
/*     */     {
/*  89 */       buf.append('$');
/*     */     }
/*     */     
/*     */ 
/*  93 */     getColumnReference(column, buf);
/*     */     
/*  95 */     if (rowabs)
/*     */     {
/*  97 */       buf.append('$');
/*     */     }
/*     */     
/*     */ 
/* 101 */     buf.append(Integer.toString(row + 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getColumnReference(int column)
/*     */   {
/* 112 */     StringBuffer buf = new StringBuffer();
/* 113 */     getColumnReference(column, buf);
/* 114 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getColumnReference(int column, StringBuffer buf)
/*     */   {
/* 125 */     int v = column / 26;
/* 126 */     int r = column % 26;
/*     */     
/* 128 */     StringBuffer tmp = new StringBuffer();
/* 129 */     while (v != 0)
/*     */     {
/* 131 */       char col = (char)(65 + r);
/*     */       
/* 133 */       tmp.append(col);
/*     */       
/* 135 */       r = v % 26 - 1;
/* 136 */       v /= 26;
/*     */     }
/*     */     
/* 139 */     char col = (char)(65 + r);
/* 140 */     tmp.append(col);
/*     */     
/*     */ 
/* 143 */     for (int i = tmp.length() - 1; i >= 0; i--)
/*     */     {
/* 145 */       buf.append(tmp.charAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int sheet, int column, int row, ExternalSheet workbook, StringBuffer buf)
/*     */   {
/* 164 */     String name = workbook.getExternalSheetName(sheet);
/* 165 */     buf.append(StringHelper.replace(name, "'", "''"));
/* 166 */     buf.append('!');
/* 167 */     getCellReference(column, row, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getCellReference(int sheet, int column, boolean colabs, int row, boolean rowabs, ExternalSheet workbook, StringBuffer buf)
/*     */   {
/* 188 */     String name = workbook.getExternalSheetName(sheet);
/* 189 */     buf.append(name);
/* 190 */     buf.append('!');
/* 191 */     getCellReference(column, colabs, row, rowabs, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellReference(int sheet, int column, int row, ExternalSheet workbook)
/*     */   {
/* 208 */     StringBuffer sb = new StringBuffer();
/* 209 */     getCellReference(sheet, column, row, workbook, sb);
/* 210 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCellReference(int column, int row)
/*     */   {
/* 223 */     StringBuffer buf = new StringBuffer();
/* 224 */     getCellReference(column, row, buf);
/* 225 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getColumn(String s)
/*     */   {
/* 236 */     int colnum = 0;
/* 237 */     int numindex = getNumberIndex(s);
/*     */     
/* 239 */     String s2 = s.toUpperCase();
/*     */     
/* 241 */     int startPos = s.lastIndexOf('!') + 1;
/* 242 */     if (s.charAt(startPos) == '$')
/*     */     {
/* 244 */       startPos++;
/*     */     }
/*     */     
/* 247 */     int endPos = numindex;
/* 248 */     if (s.charAt(numindex - 1) == '$')
/*     */     {
/* 250 */       endPos--;
/*     */     }
/*     */     
/* 253 */     for (int i = startPos; i < endPos; i++)
/*     */     {
/*     */ 
/* 256 */       if (i != startPos)
/*     */       {
/* 258 */         colnum = (colnum + 1) * 26;
/*     */       }
/* 260 */       colnum += s2.charAt(i) - 'A';
/*     */     }
/*     */     
/* 263 */     return colnum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getRow(String s)
/*     */   {
/*     */     try
/*     */     {
/* 273 */       return Integer.parseInt(s.substring(getNumberIndex(s))) - 1;
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 277 */       logger.warn(e, e); }
/* 278 */     return 65535;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getNumberIndex(String s)
/*     */   {
/* 288 */     boolean numberFound = false;
/* 289 */     int pos = s.lastIndexOf('!') + 1;
/* 290 */     char c = '\000';
/*     */     
/* 292 */     while ((!numberFound) && (pos < s.length()))
/*     */     {
/* 294 */       c = s.charAt(pos);
/*     */       
/* 296 */       if ((c >= '0') && (c <= '9'))
/*     */       {
/* 298 */         numberFound = true;
/*     */       }
/*     */       else
/*     */       {
/* 302 */         pos++;
/*     */       }
/*     */     }
/*     */     
/* 306 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isColumnRelative(String s)
/*     */   {
/* 317 */     return s.charAt(0) != '$';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isRowRelative(String s)
/*     */   {
/* 328 */     return s.charAt(getNumberIndex(s) - 1) != '$';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSheet(String ref)
/*     */   {
/* 339 */     int sheetPos = ref.lastIndexOf('!');
/* 340 */     if (sheetPos == -1)
/*     */     {
/* 342 */       return "";
/*     */     }
/*     */     
/* 345 */     return ref.substring(0, sheetPos);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\CellReferenceHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */