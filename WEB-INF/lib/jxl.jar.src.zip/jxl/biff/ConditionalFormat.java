/*     */ package jxl.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionalFormat
/*     */ {
/*     */   private ConditionalFormatRangeRecord range;
/*     */   private ArrayList conditions;
/*     */   
/*     */   public ConditionalFormat(ConditionalFormatRangeRecord cfrr)
/*     */   {
/*  51 */     this.range = cfrr;
/*  52 */     this.conditions = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCondition(ConditionalFormatRecord cond)
/*     */   {
/*  62 */     this.conditions.add(cond);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertColumn(int col)
/*     */   {
/*  73 */     this.range.insertColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeColumn(int col)
/*     */   {
/*  84 */     this.range.removeColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int row)
/*     */   {
/*  95 */     this.range.removeRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertRow(int row)
/*     */   {
/* 106 */     this.range.insertRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/* 117 */     outputFile.write(this.range);
/*     */     
/* 119 */     for (Iterator i = this.conditions.iterator(); i.hasNext();)
/*     */     {
/* 121 */       ConditionalFormatRecord cfr = (ConditionalFormatRecord)i.next();
/* 122 */       outputFile.write(cfr);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\ConditionalFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */