/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionalFormatRangeRecord
/*     */   extends WritableRecordData
/*     */ {
/*  32 */   private static Logger logger = Logger.getLogger(ConditionalFormatRangeRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private Range enclosingRange;
/*     */   
/*     */ 
/*     */   private Range[] ranges;
/*     */   
/*     */ 
/*     */   private int numRanges;
/*     */   
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */   private boolean modified;
/*     */   
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */   private static class Range
/*     */   {
/*     */     public int firstRow;
/*     */     
/*     */ 
/*     */     public int firstColumn;
/*     */     
/*     */ 
/*     */     public int lastRow;
/*     */     
/*     */ 
/*     */     public int lastColumn;
/*     */     
/*     */ 
/*     */     public boolean modified;
/*     */     
/*     */ 
/*     */ 
/*     */     public Range()
/*     */     {
/*  75 */       this.modified = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void insertColumn(int col)
/*     */     {
/*  86 */       if (col > this.lastColumn)
/*     */       {
/*  88 */         return;
/*     */       }
/*     */       
/*  91 */       if (col <= this.firstColumn)
/*     */       {
/*  93 */         this.firstColumn += 1;
/*  94 */         this.modified = true;
/*     */       }
/*     */       
/*  97 */       if (col <= this.lastColumn)
/*     */       {
/*  99 */         this.lastColumn += 1;
/* 100 */         this.modified = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void removeColumn(int col)
/*     */     {
/* 112 */       if (col > this.lastColumn)
/*     */       {
/* 114 */         return;
/*     */       }
/*     */       
/* 117 */       if (col < this.firstColumn)
/*     */       {
/* 119 */         this.firstColumn -= 1;
/* 120 */         this.modified = true;
/*     */       }
/*     */       
/* 123 */       if (col <= this.lastColumn)
/*     */       {
/* 125 */         this.lastColumn -= 1;
/* 126 */         this.modified = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void removeRow(int row)
/*     */     {
/* 138 */       if (row > this.lastRow)
/*     */       {
/* 140 */         return;
/*     */       }
/*     */       
/* 143 */       if (row < this.firstRow)
/*     */       {
/* 145 */         this.firstRow -= 1;
/* 146 */         this.modified = true;
/*     */       }
/*     */       
/* 149 */       if (row <= this.lastRow)
/*     */       {
/* 151 */         this.lastRow -= 1;
/* 152 */         this.modified = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void insertRow(int row)
/*     */     {
/* 164 */       if (row > this.lastRow)
/*     */       {
/* 166 */         return;
/*     */       }
/*     */       
/* 169 */       if (row <= this.firstRow)
/*     */       {
/* 171 */         this.firstRow += 1;
/* 172 */         this.modified = true;
/*     */       }
/*     */       
/* 175 */       if (row <= this.lastRow)
/*     */       {
/* 177 */         this.lastRow += 1;
/* 178 */         this.modified = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConditionalFormatRangeRecord(Record t)
/*     */   {
/* 189 */     super(t);
/*     */     
/* 191 */     this.initialized = false;
/* 192 */     this.modified = false;
/* 193 */     this.data = getRecord().getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 201 */     this.enclosingRange = new Range();
/* 202 */     this.enclosingRange.firstRow = IntegerHelper.getInt(this.data[4], this.data[5]);
/* 203 */     this.enclosingRange.lastRow = IntegerHelper.getInt(this.data[6], this.data[7]);
/* 204 */     this.enclosingRange.firstColumn = IntegerHelper.getInt(this.data[8], this.data[9]);
/* 205 */     this.enclosingRange.lastColumn = IntegerHelper.getInt(this.data[10], this.data[11]);
/* 206 */     this.numRanges = IntegerHelper.getInt(this.data[12], this.data[13]);
/* 207 */     this.ranges = new Range[this.numRanges];
/*     */     
/* 209 */     int pos = 14;
/*     */     
/* 211 */     for (int i = 0; i < this.numRanges; i++)
/*     */     {
/* 213 */       this.ranges[i] = new Range();
/* 214 */       this.ranges[i].firstRow = IntegerHelper.getInt(this.data[pos], this.data[(pos + 1)]);
/* 215 */       this.ranges[i].lastRow = IntegerHelper.getInt(this.data[(pos + 2)], this.data[(pos + 3)]);
/* 216 */       this.ranges[i].firstColumn = IntegerHelper.getInt(this.data[(pos + 4)], this.data[(pos + 5)]);
/* 217 */       this.ranges[i].lastColumn = IntegerHelper.getInt(this.data[(pos + 6)], this.data[(pos + 7)]);
/* 218 */       pos += 8;
/*     */     }
/*     */     
/* 221 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertColumn(int col)
/*     */   {
/* 232 */     if (!this.initialized)
/*     */     {
/* 234 */       initialize();
/*     */     }
/*     */     
/* 237 */     this.enclosingRange.insertColumn(col);
/* 238 */     if (this.enclosingRange.modified)
/*     */     {
/* 240 */       this.modified = true;
/*     */     }
/*     */     
/* 243 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 245 */       this.ranges[i].insertColumn(col);
/*     */       
/* 247 */       if (this.ranges[i].modified)
/*     */       {
/* 249 */         this.modified = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeColumn(int col)
/*     */   {
/* 264 */     if (!this.initialized)
/*     */     {
/* 266 */       initialize();
/*     */     }
/*     */     
/* 269 */     this.enclosingRange.removeColumn(col);
/* 270 */     if (this.enclosingRange.modified)
/*     */     {
/* 272 */       this.modified = true;
/*     */     }
/*     */     
/* 275 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 277 */       this.ranges[i].removeColumn(col);
/*     */       
/* 279 */       if (this.ranges[i].modified)
/*     */       {
/* 281 */         this.modified = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int row)
/*     */   {
/* 296 */     if (!this.initialized)
/*     */     {
/* 298 */       initialize();
/*     */     }
/*     */     
/* 301 */     this.enclosingRange.removeRow(row);
/* 302 */     if (this.enclosingRange.modified)
/*     */     {
/* 304 */       this.modified = true;
/*     */     }
/*     */     
/* 307 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 309 */       this.ranges[i].removeRow(row);
/*     */       
/* 311 */       if (this.ranges[i].modified)
/*     */       {
/* 313 */         this.modified = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertRow(int row)
/*     */   {
/* 328 */     if (!this.initialized)
/*     */     {
/* 330 */       initialize();
/*     */     }
/*     */     
/* 333 */     this.enclosingRange.insertRow(row);
/* 334 */     if (this.enclosingRange.modified)
/*     */     {
/* 336 */       this.modified = true;
/*     */     }
/*     */     
/* 339 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 341 */       this.ranges[i].insertRow(row);
/*     */       
/* 343 */       if (this.ranges[i].modified)
/*     */       {
/* 345 */         this.modified = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 360 */     if (!this.modified)
/*     */     {
/* 362 */       return this.data;
/*     */     }
/*     */     
/* 365 */     byte[] d = new byte[14 + this.ranges.length * 8];
/*     */     
/*     */ 
/* 368 */     System.arraycopy(this.data, 0, d, 0, 4);
/*     */     
/*     */ 
/* 371 */     IntegerHelper.getTwoBytes(this.enclosingRange.firstRow, d, 4);
/* 372 */     IntegerHelper.getTwoBytes(this.enclosingRange.lastRow, d, 6);
/* 373 */     IntegerHelper.getTwoBytes(this.enclosingRange.firstColumn, d, 8);
/* 374 */     IntegerHelper.getTwoBytes(this.enclosingRange.lastColumn, d, 10);
/*     */     
/* 376 */     IntegerHelper.getTwoBytes(this.numRanges, d, 12);
/*     */     
/* 378 */     int pos = 14;
/* 379 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 381 */       IntegerHelper.getTwoBytes(this.ranges[i].firstRow, d, pos);
/* 382 */       IntegerHelper.getTwoBytes(this.ranges[i].lastRow, d, pos + 2);
/* 383 */       IntegerHelper.getTwoBytes(this.ranges[i].firstColumn, d, pos + 4);
/* 384 */       IntegerHelper.getTwoBytes(this.ranges[i].lastColumn, d, pos + 6);
/* 385 */       pos += 8;
/*     */     }
/*     */     
/* 388 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\ConditionalFormatRangeRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */