/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CountryCode
/*     */ {
/*  32 */   private static Logger logger = Logger.getLogger(CountryCode.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String code;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String description;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private static CountryCode[] codes = new CountryCode[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CountryCode(int v, String c, String d)
/*     */   {
/*  59 */     this.value = v;
/*  60 */     this.code = c;
/*  61 */     this.description = d;
/*     */     
/*  63 */     CountryCode[] newcodes = new CountryCode[codes.length + 1];
/*  64 */     System.arraycopy(codes, 0, newcodes, 0, codes.length);
/*  65 */     newcodes[codes.length] = this;
/*  66 */     codes = newcodes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CountryCode(int v)
/*     */   {
/*  75 */     this.value = v;
/*  76 */     this.description = "Arbitrary";
/*  77 */     this.code = "??";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  87 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCode()
/*     */   {
/*  97 */     return this.code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CountryCode getCountryCode(String s)
/*     */   {
/* 105 */     if ((s == null) || (s.length() != 2))
/*     */     {
/* 107 */       logger.warn("Please specify two character ISO 3166 country code");
/* 108 */       return USA;
/*     */     }
/*     */     
/* 111 */     CountryCode code = UNKNOWN;
/* 112 */     for (int i = 0; (i < codes.length) && (code == UNKNOWN); i++)
/*     */     {
/* 114 */       if (codes[i].code.equals(s))
/*     */       {
/* 116 */         code = codes[i];
/*     */       }
/*     */     }
/*     */     
/* 120 */     return code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CountryCode createArbitraryCode(int i)
/*     */   {
/* 130 */     return new CountryCode(i);
/*     */   }
/*     */   
/*     */ 
/* 134 */   public static final CountryCode USA = new CountryCode(1, "US", "USA");
/* 135 */   public static final CountryCode CANADA = new CountryCode(2, "CA", "Canada");
/*     */   
/* 137 */   public static final CountryCode GREECE = new CountryCode(30, "GR", "Greece");
/*     */   
/* 139 */   public static final CountryCode NETHERLANDS = new CountryCode(31, "NE", "Netherlands");
/*     */   
/* 141 */   public static final CountryCode BELGIUM = new CountryCode(32, "BE", "Belgium");
/*     */   
/* 143 */   public static final CountryCode FRANCE = new CountryCode(33, "FR", "France");
/*     */   
/* 145 */   public static final CountryCode SPAIN = new CountryCode(34, "ES", "Spain");
/* 146 */   public static final CountryCode ITALY = new CountryCode(39, "IT", "Italy");
/* 147 */   public static final CountryCode SWITZERLAND = new CountryCode(41, "CH", "Switzerland");
/*     */   
/* 149 */   public static final CountryCode UK = new CountryCode(44, "UK", "United Kingdowm");
/*     */   
/* 151 */   public static final CountryCode DENMARK = new CountryCode(45, "DK", "Denmark");
/*     */   
/* 153 */   public static final CountryCode SWEDEN = new CountryCode(46, "SE", "Sweden");
/*     */   
/* 155 */   public static final CountryCode NORWAY = new CountryCode(47, "NO", "Norway");
/*     */   
/* 157 */   public static final CountryCode GERMANY = new CountryCode(49, "DE", "Germany");
/*     */   
/* 159 */   public static final CountryCode PHILIPPINES = new CountryCode(63, "PH", "Philippines");
/*     */   
/* 161 */   public static final CountryCode CHINA = new CountryCode(86, "CN", "China");
/*     */   
/* 163 */   public static final CountryCode INDIA = new CountryCode(91, "IN", "India");
/*     */   
/* 165 */   public static final CountryCode UNKNOWN = new CountryCode(65535, "??", "Unknown");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\CountryCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */