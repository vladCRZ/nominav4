/*      */ package jxl.biff;
/*      */ 
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.formula.ExternalSheet;
/*      */ import jxl.biff.formula.FormulaException;
/*      */ import jxl.biff.formula.FormulaParser;
/*      */ import jxl.biff.formula.ParseContext;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DVParser
/*      */ {
/*   45 */   private static Logger logger = Logger.getLogger(DVParser.class);
/*      */   
/*      */ 
/*      */   public static class DVType
/*      */   {
/*      */     private int value;
/*      */     
/*      */     private String desc;
/*   53 */     private static DVType[] types = new DVType[0];
/*      */     
/*      */     DVType(int v, String d)
/*      */     {
/*   57 */       this.value = v;
/*   58 */       this.desc = d;
/*   59 */       DVType[] oldtypes = types;
/*   60 */       types = new DVType[oldtypes.length + 1];
/*   61 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*   62 */       types[oldtypes.length] = this;
/*      */     }
/*      */     
/*      */     static DVType getType(int v)
/*      */     {
/*   67 */       DVType found = null;
/*   68 */       for (int i = 0; (i < types.length) && (found == null); i++)
/*      */       {
/*   70 */         if (types[i].value == v)
/*      */         {
/*   72 */           found = types[i];
/*      */         }
/*      */       }
/*   75 */       return found;
/*      */     }
/*      */     
/*      */     public int getValue()
/*      */     {
/*   80 */       return this.value;
/*      */     }
/*      */     
/*      */     public String getDescription()
/*      */     {
/*   85 */       return this.desc;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static class ErrorStyle
/*      */   {
/*      */     private int value;
/*      */     
/*   94 */     private static ErrorStyle[] types = new ErrorStyle[0];
/*      */     
/*      */     ErrorStyle(int v)
/*      */     {
/*   98 */       this.value = v;
/*   99 */       ErrorStyle[] oldtypes = types;
/*  100 */       types = new ErrorStyle[oldtypes.length + 1];
/*  101 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*  102 */       types[oldtypes.length] = this;
/*      */     }
/*      */     
/*      */     static ErrorStyle getErrorStyle(int v)
/*      */     {
/*  107 */       ErrorStyle found = null;
/*  108 */       for (int i = 0; (i < types.length) && (found == null); i++)
/*      */       {
/*  110 */         if (types[i].value == v)
/*      */         {
/*  112 */           found = types[i];
/*      */         }
/*      */       }
/*  115 */       return found;
/*      */     }
/*      */     
/*      */     public int getValue()
/*      */     {
/*  120 */       return this.value;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static class Condition
/*      */   {
/*      */     private int value;
/*      */     
/*      */     private MessageFormat format;
/*  130 */     private static Condition[] types = new Condition[0];
/*      */     
/*      */     Condition(int v, String pattern)
/*      */     {
/*  134 */       this.value = v;
/*  135 */       this.format = new MessageFormat(pattern);
/*  136 */       Condition[] oldtypes = types;
/*  137 */       types = new Condition[oldtypes.length + 1];
/*  138 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*  139 */       types[oldtypes.length] = this;
/*      */     }
/*      */     
/*      */     static Condition getCondition(int v)
/*      */     {
/*  144 */       Condition found = null;
/*  145 */       for (int i = 0; (i < types.length) && (found == null); i++)
/*      */       {
/*  147 */         if (types[i].value == v)
/*      */         {
/*  149 */           found = types[i];
/*      */         }
/*      */       }
/*  152 */       return found;
/*      */     }
/*      */     
/*      */     public int getValue()
/*      */     {
/*  157 */       return this.value;
/*      */     }
/*      */     
/*      */     public String getConditionString(String s1, String s2)
/*      */     {
/*  162 */       return this.format.format(new String[] { s1, s2 });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  167 */   public static final DVType ANY = new DVType(0, "any");
/*  168 */   public static final DVType INTEGER = new DVType(1, "int");
/*  169 */   public static final DVType DECIMAL = new DVType(2, "dec");
/*  170 */   public static final DVType LIST = new DVType(3, "list");
/*  171 */   public static final DVType DATE = new DVType(4, "date");
/*  172 */   public static final DVType TIME = new DVType(5, "time");
/*  173 */   public static final DVType TEXT_LENGTH = new DVType(6, "strlen");
/*  174 */   public static final DVType FORMULA = new DVType(7, "form");
/*      */   
/*      */ 
/*  177 */   public static final ErrorStyle STOP = new ErrorStyle(0);
/*  178 */   public static final ErrorStyle WARNING = new ErrorStyle(1);
/*  179 */   public static final ErrorStyle INFO = new ErrorStyle(2);
/*      */   
/*      */ 
/*  182 */   public static final Condition BETWEEN = new Condition(0, "{0} <= x <= {1}");
/*  183 */   public static final Condition NOT_BETWEEN = new Condition(1, "!({0} <= x <= {1}");
/*      */   
/*  185 */   public static final Condition EQUAL = new Condition(2, "x == {0}");
/*  186 */   public static final Condition NOT_EQUAL = new Condition(3, "x != {0}");
/*  187 */   public static final Condition GREATER_THAN = new Condition(4, "x > {0}");
/*  188 */   public static final Condition LESS_THAN = new Condition(5, "x < {0}");
/*  189 */   public static final Condition GREATER_EQUAL = new Condition(6, "x >= {0}");
/*  190 */   public static final Condition LESS_EQUAL = new Condition(7, "x <= {0}");
/*      */   
/*      */   private static final int STRING_LIST_GIVEN_MASK = 128;
/*      */   
/*      */   private static final int EMPTY_CELLS_ALLOWED_MASK = 256;
/*      */   
/*      */   private static final int SUPPRESS_ARROW_MASK = 512;
/*      */   
/*      */   private static final int SHOW_PROMPT_MASK = 262144;
/*      */   private static final int SHOW_ERROR_MASK = 524288;
/*  200 */   private static DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.#");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_VALIDATION_LIST_LENGTH = 254;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_ROWS = 65535;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_COLUMNS = 255;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DVType type;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ErrorStyle errorStyle;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Condition condition;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean stringListGiven;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean emptyCellsAllowed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean suppressArrow;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean showPrompt;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean showError;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String promptTitle;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String errorTitle;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String promptText;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String errorText;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormulaParser formula1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String formula1String;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormulaParser formula2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String formula2String;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int column1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int row1;
/*      */   
/*      */ 
/*      */ 
/*      */   private int column2;
/*      */   
/*      */ 
/*      */ 
/*      */   private int row2;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean extendedCellsValidation;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean copied;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DVParser(byte[] data, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws)
/*      */   {
/*  328 */     Assert.verify(nt != null);
/*      */     
/*  330 */     this.copied = false;
/*  331 */     int options = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/*      */     
/*  333 */     int typeVal = options & 0xF;
/*  334 */     this.type = DVType.getType(typeVal);
/*      */     
/*  336 */     int errorStyleVal = (options & 0x70) >> 4;
/*  337 */     this.errorStyle = ErrorStyle.getErrorStyle(errorStyleVal);
/*      */     
/*  339 */     int conditionVal = (options & 0xF00000) >> 20;
/*  340 */     this.condition = Condition.getCondition(conditionVal);
/*      */     
/*  342 */     this.stringListGiven = ((options & 0x80) != 0);
/*  343 */     this.emptyCellsAllowed = ((options & 0x100) != 0);
/*  344 */     this.suppressArrow = ((options & 0x200) != 0);
/*  345 */     this.showPrompt = ((options & 0x40000) != 0);
/*  346 */     this.showError = ((options & 0x80000) != 0);
/*      */     
/*  348 */     int pos = 4;
/*  349 */     int length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  350 */     if ((length > 0) && (data[(pos + 2)] == 0))
/*      */     {
/*  352 */       this.promptTitle = StringHelper.getString(data, length, pos + 3, ws);
/*  353 */       pos += length + 3;
/*      */     }
/*  355 */     else if (length > 0)
/*      */     {
/*  357 */       this.promptTitle = StringHelper.getUnicodeString(data, length, pos + 3);
/*  358 */       pos += length * 2 + 3;
/*      */     }
/*      */     else
/*      */     {
/*  362 */       pos += 3;
/*      */     }
/*      */     
/*  365 */     length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  366 */     if ((length > 0) && (data[(pos + 2)] == 0))
/*      */     {
/*  368 */       this.errorTitle = StringHelper.getString(data, length, pos + 3, ws);
/*  369 */       pos += length + 3;
/*      */     }
/*  371 */     else if (length > 0)
/*      */     {
/*  373 */       this.errorTitle = StringHelper.getUnicodeString(data, length, pos + 3);
/*  374 */       pos += length * 2 + 3;
/*      */     }
/*      */     else
/*      */     {
/*  378 */       pos += 3;
/*      */     }
/*      */     
/*  381 */     length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  382 */     if ((length > 0) && (data[(pos + 2)] == 0))
/*      */     {
/*  384 */       this.promptText = StringHelper.getString(data, length, pos + 3, ws);
/*  385 */       pos += length + 3;
/*      */     }
/*  387 */     else if (length > 0)
/*      */     {
/*  389 */       this.promptText = StringHelper.getUnicodeString(data, length, pos + 3);
/*  390 */       pos += length * 2 + 3;
/*      */     }
/*      */     else
/*      */     {
/*  394 */       pos += 3;
/*      */     }
/*      */     
/*  397 */     length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  398 */     if ((length > 0) && (data[(pos + 2)] == 0))
/*      */     {
/*  400 */       this.errorText = StringHelper.getString(data, length, pos + 3, ws);
/*  401 */       pos += length + 3;
/*      */     }
/*  403 */     else if (length > 0)
/*      */     {
/*  405 */       this.errorText = StringHelper.getUnicodeString(data, length, pos + 3);
/*  406 */       pos += length * 2 + 3;
/*      */     }
/*      */     else
/*      */     {
/*  410 */       pos += 3;
/*      */     }
/*      */     
/*  413 */     int formula1Length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  414 */     pos += 4;
/*  415 */     int formula1Pos = pos;
/*  416 */     pos += formula1Length;
/*      */     
/*  418 */     int formula2Length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  419 */     pos += 4;
/*  420 */     int formula2Pos = pos;
/*  421 */     pos += formula2Length;
/*      */     
/*  423 */     pos += 2;
/*      */     
/*  425 */     this.row1 = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  426 */     pos += 2;
/*      */     
/*  428 */     this.row2 = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  429 */     pos += 2;
/*      */     
/*  431 */     this.column1 = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  432 */     pos += 2;
/*      */     
/*  434 */     this.column2 = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  435 */     pos += 2;
/*      */     
/*  437 */     this.extendedCellsValidation = ((this.row1 != this.row2) || (this.column1 != this.column2));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  445 */       EmptyCell tmprt = new EmptyCell(this.column1, this.row1);
/*      */       
/*  447 */       if (formula1Length != 0)
/*      */       {
/*  449 */         byte[] tokens = new byte[formula1Length];
/*  450 */         System.arraycopy(data, formula1Pos, tokens, 0, formula1Length);
/*  451 */         this.formula1 = new FormulaParser(tokens, tmprt, es, nt, ws, ParseContext.DATA_VALIDATION);
/*      */         
/*  453 */         this.formula1.parse();
/*      */       }
/*      */       
/*  456 */       if (formula2Length != 0)
/*      */       {
/*  458 */         byte[] tokens = new byte[formula2Length];
/*  459 */         System.arraycopy(data, formula2Pos, tokens, 0, formula2Length);
/*  460 */         this.formula2 = new FormulaParser(tokens, tmprt, es, nt, ws, ParseContext.DATA_VALIDATION);
/*      */         
/*  462 */         this.formula2.parse();
/*      */       }
/*      */     }
/*      */     catch (FormulaException e)
/*      */     {
/*  467 */       logger.warn(e.getMessage() + " for cells " + CellReferenceHelper.getCellReference(this.column1, this.row1) + "-" + CellReferenceHelper.getCellReference(this.column2, this.row2));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DVParser(Collection strings)
/*      */   {
/*  478 */     this.copied = false;
/*  479 */     this.type = LIST;
/*  480 */     this.errorStyle = STOP;
/*  481 */     this.condition = BETWEEN;
/*  482 */     this.extendedCellsValidation = false;
/*      */     
/*      */ 
/*  485 */     this.stringListGiven = true;
/*  486 */     this.emptyCellsAllowed = true;
/*  487 */     this.suppressArrow = false;
/*  488 */     this.showPrompt = true;
/*  489 */     this.showError = true;
/*      */     
/*  491 */     this.promptTitle = "\000";
/*  492 */     this.errorTitle = "\000";
/*  493 */     this.promptText = "\000";
/*  494 */     this.errorText = "\000";
/*  495 */     if (strings.size() == 0)
/*      */     {
/*  497 */       logger.warn("no validation strings - ignoring");
/*      */     }
/*      */     
/*  500 */     Iterator i = strings.iterator();
/*  501 */     StringBuffer formulaString = new StringBuffer();
/*      */     
/*  503 */     formulaString.append(i.next().toString());
/*  504 */     while (i.hasNext())
/*      */     {
/*  506 */       formulaString.append('\000');
/*  507 */       formulaString.append(' ');
/*  508 */       formulaString.append(i.next().toString());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  513 */     if (formulaString.length() > 254)
/*      */     {
/*  515 */       logger.warn("Validation list exceeds maximum number of characters - truncating");
/*      */       
/*  517 */       formulaString.delete(254, formulaString.length());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  522 */     formulaString.insert(0, '"');
/*  523 */     formulaString.append('"');
/*  524 */     this.formula1String = formulaString.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DVParser(String namedRange)
/*      */   {
/*  533 */     if (namedRange.length() == 0)
/*      */     {
/*  535 */       this.copied = false;
/*  536 */       this.type = FORMULA;
/*  537 */       this.errorStyle = STOP;
/*  538 */       this.condition = EQUAL;
/*  539 */       this.extendedCellsValidation = false;
/*      */       
/*  541 */       this.stringListGiven = false;
/*  542 */       this.emptyCellsAllowed = false;
/*  543 */       this.suppressArrow = false;
/*  544 */       this.showPrompt = true;
/*  545 */       this.showError = true;
/*      */       
/*  547 */       this.promptTitle = "\000";
/*  548 */       this.errorTitle = "\000";
/*  549 */       this.promptText = "\000";
/*  550 */       this.errorText = "\000";
/*  551 */       this.formula1String = "\"\"";
/*  552 */       return;
/*      */     }
/*      */     
/*  555 */     this.copied = false;
/*  556 */     this.type = LIST;
/*  557 */     this.errorStyle = STOP;
/*  558 */     this.condition = BETWEEN;
/*  559 */     this.extendedCellsValidation = false;
/*      */     
/*      */ 
/*  562 */     this.stringListGiven = false;
/*  563 */     this.emptyCellsAllowed = true;
/*  564 */     this.suppressArrow = false;
/*  565 */     this.showPrompt = true;
/*  566 */     this.showError = true;
/*      */     
/*  568 */     this.promptTitle = "\000";
/*  569 */     this.errorTitle = "\000";
/*  570 */     this.promptText = "\000";
/*  571 */     this.errorText = "\000";
/*  572 */     this.formula1String = namedRange;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DVParser(int c1, int r1, int c2, int r2)
/*      */   {
/*  580 */     this.copied = false;
/*  581 */     this.type = LIST;
/*  582 */     this.errorStyle = STOP;
/*  583 */     this.condition = BETWEEN;
/*  584 */     this.extendedCellsValidation = false;
/*      */     
/*      */ 
/*  587 */     this.stringListGiven = false;
/*  588 */     this.emptyCellsAllowed = true;
/*  589 */     this.suppressArrow = false;
/*  590 */     this.showPrompt = true;
/*  591 */     this.showError = true;
/*      */     
/*  593 */     this.promptTitle = "\000";
/*  594 */     this.errorTitle = "\000";
/*  595 */     this.promptText = "\000";
/*  596 */     this.errorText = "\000";
/*  597 */     StringBuffer formulaString = new StringBuffer();
/*  598 */     CellReferenceHelper.getCellReference(c1, r1, formulaString);
/*  599 */     formulaString.append(':');
/*  600 */     CellReferenceHelper.getCellReference(c2, r2, formulaString);
/*  601 */     this.formula1String = formulaString.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DVParser(double val1, double val2, Condition c)
/*      */   {
/*  609 */     this.copied = false;
/*  610 */     this.type = DECIMAL;
/*  611 */     this.errorStyle = STOP;
/*  612 */     this.condition = c;
/*  613 */     this.extendedCellsValidation = false;
/*      */     
/*      */ 
/*  616 */     this.stringListGiven = false;
/*  617 */     this.emptyCellsAllowed = true;
/*  618 */     this.suppressArrow = false;
/*  619 */     this.showPrompt = true;
/*  620 */     this.showError = true;
/*      */     
/*  622 */     this.promptTitle = "\000";
/*  623 */     this.errorTitle = "\000";
/*  624 */     this.promptText = "\000";
/*  625 */     this.errorText = "\000";
/*  626 */     this.formula1String = DECIMAL_FORMAT.format(val1);
/*      */     
/*  628 */     if (!Double.isNaN(val2))
/*      */     {
/*  630 */       this.formula2String = DECIMAL_FORMAT.format(val2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DVParser(DVParser copy)
/*      */   {
/*  639 */     this.copied = true;
/*  640 */     this.type = copy.type;
/*  641 */     this.errorStyle = copy.errorStyle;
/*  642 */     this.condition = copy.condition;
/*  643 */     this.stringListGiven = copy.stringListGiven;
/*  644 */     this.emptyCellsAllowed = copy.emptyCellsAllowed;
/*  645 */     this.suppressArrow = copy.suppressArrow;
/*  646 */     this.showPrompt = copy.showPrompt;
/*  647 */     this.showError = copy.showError;
/*  648 */     this.promptTitle = copy.promptTitle;
/*  649 */     this.promptText = copy.promptText;
/*  650 */     this.errorTitle = copy.errorTitle;
/*  651 */     this.errorText = copy.errorText;
/*  652 */     this.extendedCellsValidation = copy.extendedCellsValidation;
/*      */     
/*  654 */     this.row1 = copy.row1;
/*  655 */     this.row2 = copy.row2;
/*  656 */     this.column1 = copy.column1;
/*  657 */     this.column2 = copy.column2;
/*      */     
/*      */ 
/*  660 */     if (copy.formula1String != null)
/*      */     {
/*  662 */       this.formula1String = copy.formula1String;
/*  663 */       this.formula2String = copy.formula2String;
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/*  669 */         this.formula1String = copy.formula1.getFormula();
/*  670 */         this.formula2String = (copy.formula2 != null ? copy.formula2.getFormula() : null);
/*      */ 
/*      */       }
/*      */       catch (FormulaException e)
/*      */       {
/*  675 */         logger.warn("Cannot parse validation formula:  " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getData()
/*      */   {
/*  687 */     byte[] f1Bytes = this.formula1 != null ? this.formula1.getBytes() : new byte[0];
/*  688 */     byte[] f2Bytes = this.formula2 != null ? this.formula2.getBytes() : new byte[0];
/*  689 */     int dataLength = 4 + this.promptTitle.length() * 2 + 3 + this.errorTitle.length() * 2 + 3 + this.promptText.length() * 2 + 3 + this.errorText.length() * 2 + 3 + f1Bytes.length + 2 + f2Bytes.length + 2 + 4 + 10;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  700 */     byte[] data = new byte[dataLength];
/*      */     
/*      */ 
/*  703 */     int pos = 0;
/*      */     
/*      */ 
/*  706 */     int options = 0;
/*  707 */     options |= this.type.getValue();
/*  708 */     options |= this.errorStyle.getValue() << 4;
/*  709 */     options |= this.condition.getValue() << 20;
/*      */     
/*  711 */     if (this.stringListGiven)
/*      */     {
/*  713 */       options |= 0x80;
/*      */     }
/*      */     
/*  716 */     if (this.emptyCellsAllowed)
/*      */     {
/*  718 */       options |= 0x100;
/*      */     }
/*      */     
/*  721 */     if (this.suppressArrow)
/*      */     {
/*  723 */       options |= 0x200;
/*      */     }
/*      */     
/*  726 */     if (this.showPrompt)
/*      */     {
/*  728 */       options |= 0x40000;
/*      */     }
/*      */     
/*  731 */     if (this.showError)
/*      */     {
/*  733 */       options |= 0x80000;
/*      */     }
/*      */     
/*      */ 
/*  737 */     IntegerHelper.getFourBytes(options, data, pos);
/*  738 */     pos += 4;
/*      */     
/*  740 */     IntegerHelper.getTwoBytes(this.promptTitle.length(), data, pos);
/*  741 */     pos += 2;
/*      */     
/*  743 */     data[pos] = 1;
/*  744 */     pos++;
/*      */     
/*  746 */     StringHelper.getUnicodeBytes(this.promptTitle, data, pos);
/*  747 */     pos += this.promptTitle.length() * 2;
/*      */     
/*  749 */     IntegerHelper.getTwoBytes(this.errorTitle.length(), data, pos);
/*  750 */     pos += 2;
/*      */     
/*  752 */     data[pos] = 1;
/*  753 */     pos++;
/*      */     
/*  755 */     StringHelper.getUnicodeBytes(this.errorTitle, data, pos);
/*  756 */     pos += this.errorTitle.length() * 2;
/*      */     
/*  758 */     IntegerHelper.getTwoBytes(this.promptText.length(), data, pos);
/*  759 */     pos += 2;
/*      */     
/*  761 */     data[pos] = 1;
/*  762 */     pos++;
/*      */     
/*  764 */     StringHelper.getUnicodeBytes(this.promptText, data, pos);
/*  765 */     pos += this.promptText.length() * 2;
/*      */     
/*  767 */     IntegerHelper.getTwoBytes(this.errorText.length(), data, pos);
/*  768 */     pos += 2;
/*      */     
/*  770 */     data[pos] = 1;
/*  771 */     pos++;
/*      */     
/*  773 */     StringHelper.getUnicodeBytes(this.errorText, data, pos);
/*  774 */     pos += this.errorText.length() * 2;
/*      */     
/*      */ 
/*  777 */     IntegerHelper.getTwoBytes(f1Bytes.length, data, pos);
/*  778 */     pos += 4;
/*      */     
/*  780 */     System.arraycopy(f1Bytes, 0, data, pos, f1Bytes.length);
/*  781 */     pos += f1Bytes.length;
/*      */     
/*      */ 
/*  784 */     IntegerHelper.getTwoBytes(f2Bytes.length, data, pos);
/*  785 */     pos += 4;
/*      */     
/*  787 */     System.arraycopy(f2Bytes, 0, data, pos, f2Bytes.length);
/*  788 */     pos += f2Bytes.length;
/*      */     
/*      */ 
/*  791 */     IntegerHelper.getTwoBytes(1, data, pos);
/*  792 */     pos += 2;
/*      */     
/*  794 */     IntegerHelper.getTwoBytes(this.row1, data, pos);
/*  795 */     pos += 2;
/*      */     
/*  797 */     IntegerHelper.getTwoBytes(this.row2, data, pos);
/*  798 */     pos += 2;
/*      */     
/*  800 */     IntegerHelper.getTwoBytes(this.column1, data, pos);
/*  801 */     pos += 2;
/*      */     
/*  803 */     IntegerHelper.getTwoBytes(this.column2, data, pos);
/*  804 */     pos += 2;
/*      */     
/*  806 */     return data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertRow(int row)
/*      */   {
/*  816 */     if (this.formula1 != null)
/*      */     {
/*  818 */       this.formula1.rowInserted(0, row, true);
/*      */     }
/*      */     
/*  821 */     if (this.formula2 != null)
/*      */     {
/*  823 */       this.formula2.rowInserted(0, row, true);
/*      */     }
/*      */     
/*  826 */     if (this.row1 >= row)
/*      */     {
/*  828 */       this.row1 += 1;
/*      */     }
/*      */     
/*  831 */     if ((this.row2 >= row) && (this.row2 != 65535))
/*      */     {
/*  833 */       this.row2 += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertColumn(int col)
/*      */   {
/*  844 */     if (this.formula1 != null)
/*      */     {
/*  846 */       this.formula1.columnInserted(0, col, true);
/*      */     }
/*      */     
/*  849 */     if (this.formula2 != null)
/*      */     {
/*  851 */       this.formula2.columnInserted(0, col, true);
/*      */     }
/*      */     
/*  854 */     if (this.column1 >= col)
/*      */     {
/*  856 */       this.column1 += 1;
/*      */     }
/*      */     
/*  859 */     if ((this.column2 >= col) && (this.column2 != 255))
/*      */     {
/*  861 */       this.column2 += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRow(int row)
/*      */   {
/*  872 */     if (this.formula1 != null)
/*      */     {
/*  874 */       this.formula1.rowRemoved(0, row, true);
/*      */     }
/*      */     
/*  877 */     if (this.formula2 != null)
/*      */     {
/*  879 */       this.formula2.rowRemoved(0, row, true);
/*      */     }
/*      */     
/*  882 */     if (this.row1 > row)
/*      */     {
/*  884 */       this.row1 -= 1;
/*      */     }
/*      */     
/*  887 */     if (this.row2 >= row)
/*      */     {
/*  889 */       this.row2 -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeColumn(int col)
/*      */   {
/*  900 */     if (this.formula1 != null)
/*      */     {
/*  902 */       this.formula1.columnRemoved(0, col, true);
/*      */     }
/*      */     
/*  905 */     if (this.formula2 != null)
/*      */     {
/*  907 */       this.formula2.columnRemoved(0, col, true);
/*      */     }
/*      */     
/*  910 */     if (this.column1 > col)
/*      */     {
/*  912 */       this.column1 -= 1;
/*      */     }
/*      */     
/*  915 */     if ((this.column2 >= col) && (this.column2 != 255))
/*      */     {
/*  917 */       this.column2 -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFirstColumn()
/*      */   {
/*  928 */     return this.column1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastColumn()
/*      */   {
/*  938 */     return this.column2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFirstRow()
/*      */   {
/*  948 */     return this.row1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastRow()
/*      */   {
/*  958 */     return this.row2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getValidationFormula()
/*      */     throws FormulaException
/*      */   {
/*  969 */     if (this.type == LIST)
/*      */     {
/*  971 */       return this.formula1.getFormula();
/*      */     }
/*      */     
/*  974 */     String s1 = this.formula1.getFormula();
/*  975 */     String s2 = this.formula2 != null ? this.formula2.getFormula() : null;
/*  976 */     return this.condition.getConditionString(s1, s2) + "; x " + this.type.getDescription();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCell(int col, int row, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws)
/*      */     throws FormulaException
/*      */   {
/*  992 */     if (this.extendedCellsValidation)
/*      */     {
/*  994 */       return;
/*      */     }
/*      */     
/*  997 */     this.row1 = row;
/*  998 */     this.row2 = row;
/*  999 */     this.column1 = col;
/* 1000 */     this.column2 = col;
/*      */     
/* 1002 */     this.formula1 = new FormulaParser(this.formula1String, es, nt, ws, ParseContext.DATA_VALIDATION);
/*      */     
/*      */ 
/* 1005 */     this.formula1.parse();
/*      */     
/* 1007 */     if (this.formula2String != null)
/*      */     {
/* 1009 */       this.formula2 = new FormulaParser(this.formula2String, es, nt, ws, ParseContext.DATA_VALIDATION);
/*      */       
/*      */ 
/* 1012 */       this.formula2.parse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void extendCellValidation(int cols, int rows)
/*      */   {
/* 1024 */     this.row2 = (this.row1 + rows);
/* 1025 */     this.column2 = (this.column1 + cols);
/* 1026 */     this.extendedCellsValidation = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean extendedCellsValidation()
/*      */   {
/* 1035 */     return this.extendedCellsValidation;
/*      */   }
/*      */   
/*      */   public boolean copied()
/*      */   {
/* 1040 */     return this.copied;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DVParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */