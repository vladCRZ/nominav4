/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DValParser
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(DValParser.class);
/*     */   
/*     */ 
/*  38 */   private static int PROMPT_BOX_VISIBLE_MASK = 1;
/*  39 */   private static int PROMPT_BOX_AT_CELL_MASK = 2;
/*  40 */   private static int VALIDITY_DATA_CACHED_MASK = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean promptBoxVisible;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean promptBoxAtCell;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean validityDataCached;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numDVRecords;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DValParser(byte[] data)
/*     */   {
/*  72 */     int options = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  74 */     this.promptBoxVisible = ((options & PROMPT_BOX_VISIBLE_MASK) != 0);
/*  75 */     this.promptBoxAtCell = ((options & PROMPT_BOX_AT_CELL_MASK) != 0);
/*  76 */     this.validityDataCached = ((options & VALIDITY_DATA_CACHED_MASK) != 0);
/*     */     
/*  78 */     this.objectId = IntegerHelper.getInt(data[10], data[11], data[12], data[13]);
/*  79 */     this.numDVRecords = IntegerHelper.getInt(data[14], data[15], data[16], data[17]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DValParser(int objid, int num)
/*     */   {
/*  88 */     this.objectId = objid;
/*  89 */     this.numDVRecords = num;
/*  90 */     this.validityDataCached = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  98 */     byte[] data = new byte[18];
/*     */     
/* 100 */     int options = 0;
/*     */     
/* 102 */     if (this.promptBoxVisible)
/*     */     {
/* 104 */       options |= PROMPT_BOX_VISIBLE_MASK;
/*     */     }
/*     */     
/* 107 */     if (this.promptBoxAtCell)
/*     */     {
/* 109 */       options |= PROMPT_BOX_AT_CELL_MASK;
/*     */     }
/*     */     
/* 112 */     if (this.validityDataCached)
/*     */     {
/* 114 */       options |= VALIDITY_DATA_CACHED_MASK;
/*     */     }
/*     */     
/* 117 */     IntegerHelper.getTwoBytes(options, data, 0);
/*     */     
/* 119 */     IntegerHelper.getFourBytes(this.objectId, data, 10);
/*     */     
/* 121 */     IntegerHelper.getFourBytes(this.numDVRecords, data, 14);
/*     */     
/* 123 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dvRemoved()
/*     */   {
/* 132 */     this.numDVRecords -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfDVRecords()
/*     */   {
/* 142 */     return this.numDVRecords;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectId()
/*     */   {
/* 152 */     return this.objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dvAdded()
/*     */   {
/* 160 */     this.numDVRecords += 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DValParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */