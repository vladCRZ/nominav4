/*     */ package jxl.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataValidation
/*     */ {
/*  44 */   private static Logger logger = Logger.getLogger(DataValidation.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DataValidityListRecord validityList;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList validitySettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods workbook;
/*     */   
/*     */ 
/*     */ 
/*     */   private ExternalSheet externalSheet;
/*     */   
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */   private int comboBoxObjectId;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean copied;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_OBJECT_ID = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int MAX_NO_OF_VALIDITY_SETTINGS = 65533;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValidation(DataValidityListRecord dvlr)
/*     */   {
/*  90 */     this.validityList = dvlr;
/*  91 */     this.validitySettings = new ArrayList(this.validityList.getNumberOfSettings());
/*  92 */     this.copied = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValidation(int objId, ExternalSheet es, WorkbookMethods wm, WorkbookSettings ws)
/*     */   {
/* 103 */     this.workbook = wm;
/* 104 */     this.externalSheet = es;
/* 105 */     this.workbookSettings = ws;
/* 106 */     this.validitySettings = new ArrayList();
/* 107 */     this.comboBoxObjectId = objId;
/* 108 */     this.copied = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValidation(DataValidation dv, ExternalSheet es, WorkbookMethods wm, WorkbookSettings ws)
/*     */   {
/* 119 */     this.workbook = wm;
/* 120 */     this.externalSheet = es;
/* 121 */     this.workbookSettings = ws;
/* 122 */     this.copied = true;
/* 123 */     this.validityList = new DataValidityListRecord(dv.getDataValidityList());
/*     */     
/* 125 */     this.validitySettings = new ArrayList();
/* 126 */     DataValiditySettingsRecord[] settings = dv.getDataValiditySettings();
/*     */     
/* 128 */     for (int i = 0; i < settings.length; i++)
/*     */     {
/* 130 */       this.validitySettings.add(new DataValiditySettingsRecord(settings[i], this.externalSheet, this.workbook, this.workbookSettings));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(DataValiditySettingsRecord dvsr)
/*     */   {
/* 142 */     this.validitySettings.add(dvsr);
/* 143 */     dvsr.setDataValidation(this);
/*     */     
/* 145 */     if (this.copied)
/*     */     {
/*     */ 
/* 148 */       Assert.verify(this.validityList != null);
/* 149 */       this.validityList.dvAdded();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValidityListRecord getDataValidityList()
/*     */   {
/* 158 */     return this.validityList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValiditySettingsRecord[] getDataValiditySettings()
/*     */   {
/* 166 */     DataValiditySettingsRecord[] dvlr = new DataValiditySettingsRecord[0];
/* 167 */     return (DataValiditySettingsRecord[])this.validitySettings.toArray(dvlr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/* 178 */     if (this.validitySettings.size() > 65533)
/*     */     {
/* 180 */       logger.warn("Maximum number of data validations exceeded - truncating...");
/*     */       
/* 182 */       this.validitySettings = new ArrayList(this.validitySettings.subList(0, 65532));
/*     */       
/* 184 */       Assert.verify(this.validitySettings.size() <= 65533);
/*     */     }
/*     */     
/* 187 */     if (this.validityList == null)
/*     */     {
/* 189 */       DValParser dvp = new DValParser(this.comboBoxObjectId, this.validitySettings.size());
/*     */       
/* 191 */       this.validityList = new DataValidityListRecord(dvp);
/*     */     }
/*     */     
/* 194 */     if (!this.validityList.hasDVRecords())
/*     */     {
/* 196 */       return;
/*     */     }
/*     */     
/* 199 */     outputFile.write(this.validityList);
/*     */     
/* 201 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 203 */       DataValiditySettingsRecord dvsr = (DataValiditySettingsRecord)i.next();
/* 204 */       outputFile.write(dvsr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertRow(int row)
/*     */   {
/* 215 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 217 */       DataValiditySettingsRecord dv = (DataValiditySettingsRecord)i.next();
/* 218 */       dv.insertRow(row);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int row)
/*     */   {
/* 229 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 231 */       DataValiditySettingsRecord dv = (DataValiditySettingsRecord)i.next();
/*     */       
/* 233 */       if ((dv.getFirstRow() == row) && (dv.getLastRow() == row))
/*     */       {
/* 235 */         i.remove();
/* 236 */         this.validityList.dvRemoved();
/*     */       }
/*     */       else
/*     */       {
/* 240 */         dv.removeRow(row);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertColumn(int col)
/*     */   {
/* 252 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 254 */       DataValiditySettingsRecord dv = (DataValiditySettingsRecord)i.next();
/* 255 */       dv.insertColumn(col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeColumn(int col)
/*     */   {
/* 266 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 268 */       DataValiditySettingsRecord dv = (DataValiditySettingsRecord)i.next();
/*     */       
/* 270 */       if ((dv.getFirstColumn() == col) && (dv.getLastColumn() == col))
/*     */       {
/* 272 */         i.remove();
/* 273 */         this.validityList.dvRemoved();
/*     */       }
/*     */       else
/*     */       {
/* 277 */         dv.removeColumn(col);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeDataValidation(int col, int row)
/*     */   {
/* 290 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 292 */       DataValiditySettingsRecord dv = (DataValiditySettingsRecord)i.next();
/*     */       
/* 294 */       if ((dv.getFirstColumn() == col) && (dv.getLastColumn() == col) && (dv.getFirstRow() == row) && (dv.getLastRow() == row))
/*     */       {
/*     */ 
/* 297 */         i.remove();
/* 298 */         this.validityList.dvRemoved();
/* 299 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSharedDataValidation(int col1, int row1, int col2, int row2)
/*     */   {
/* 313 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext();)
/*     */     {
/* 315 */       DataValiditySettingsRecord dv = (DataValiditySettingsRecord)i.next();
/*     */       
/* 317 */       if ((dv.getFirstColumn() == col1) && (dv.getLastColumn() == col2) && (dv.getFirstRow() == row1) && (dv.getLastRow() == row2))
/*     */       {
/*     */ 
/* 320 */         i.remove();
/* 321 */         this.validityList.dvRemoved();
/* 322 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValiditySettingsRecord getDataValiditySettings(int col, int row)
/*     */   {
/* 333 */     boolean found = false;
/* 334 */     DataValiditySettingsRecord foundRecord = null;
/* 335 */     for (Iterator i = this.validitySettings.iterator(); (i.hasNext()) && (!found);)
/*     */     {
/* 337 */       DataValiditySettingsRecord dvsr = (DataValiditySettingsRecord)i.next();
/* 338 */       if ((dvsr.getFirstColumn() == col) && (dvsr.getFirstRow() == row))
/*     */       {
/* 340 */         found = true;
/* 341 */         foundRecord = dvsr;
/*     */       }
/*     */     }
/*     */     
/* 345 */     return foundRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getComboBoxObjectId()
/*     */   {
/* 353 */     return this.comboBoxObjectId;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DataValidation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */