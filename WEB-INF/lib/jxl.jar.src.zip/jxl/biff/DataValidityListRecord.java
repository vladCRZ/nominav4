/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataValidityListRecord
/*     */   extends WritableRecordData
/*     */ {
/*  30 */   private static Logger logger = Logger.getLogger(DataValidityListRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DValParser dvalParser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValidityListRecord(Record t)
/*     */   {
/*  58 */     super(t);
/*     */     
/*  60 */     this.data = getRecord().getData();
/*  61 */     this.objectId = IntegerHelper.getInt(this.data[10], this.data[11], this.data[12], this.data[13]);
/*  62 */     this.numSettings = IntegerHelper.getInt(this.data[14], this.data[15], this.data[16], this.data[17]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValidityListRecord(DValParser dval)
/*     */   {
/*  70 */     super(Type.DVAL);
/*     */     
/*  72 */     this.dvalParser = dval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DataValidityListRecord(DataValidityListRecord dvlr)
/*     */   {
/*  82 */     super(Type.DVAL);
/*     */     
/*  84 */     this.data = dvlr.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getNumberOfSettings()
/*     */   {
/*  92 */     return this.numSettings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 102 */     if (this.dvalParser == null)
/*     */     {
/* 104 */       return this.data;
/*     */     }
/*     */     
/* 107 */     return this.dvalParser.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void dvRemoved()
/*     */   {
/* 116 */     if (this.dvalParser == null)
/*     */     {
/* 118 */       this.dvalParser = new DValParser(this.data);
/*     */     }
/*     */     
/* 121 */     this.dvalParser.dvRemoved();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void dvAdded()
/*     */   {
/* 129 */     if (this.dvalParser == null)
/*     */     {
/* 131 */       this.dvalParser = new DValParser(this.data);
/*     */     }
/*     */     
/* 134 */     this.dvalParser.dvAdded();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasDVRecords()
/*     */   {
/* 144 */     if (this.dvalParser == null)
/*     */     {
/* 146 */       return true;
/*     */     }
/*     */     
/* 149 */     return this.dvalParser.getNumberOfDVRecords() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectId()
/*     */   {
/* 159 */     if (this.dvalParser == null)
/*     */     {
/* 161 */       return this.objectId;
/*     */     }
/*     */     
/* 164 */     return this.dvalParser.getObjectId();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DataValidityListRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */