/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataValiditySettingsRecord
/*     */   extends WritableRecordData
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(DataValiditySettingsRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DVParser dvParser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods workbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet externalSheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DataValidation dataValidation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValiditySettingsRecord(Record t, ExternalSheet es, WorkbookMethods wm, WorkbookSettings ws)
/*     */   {
/*  81 */     super(t);
/*     */     
/*  83 */     this.data = t.getData();
/*  84 */     this.externalSheet = es;
/*  85 */     this.workbook = wm;
/*  86 */     this.workbookSettings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   DataValiditySettingsRecord(DataValiditySettingsRecord dvsr)
/*     */   {
/*  94 */     super(Type.DV);
/*     */     
/*  96 */     this.data = dvsr.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DataValiditySettingsRecord(DataValiditySettingsRecord dvsr, ExternalSheet es, WorkbookMethods w, WorkbookSettings ws)
/*     */   {
/* 109 */     super(Type.DV);
/*     */     
/* 111 */     this.workbook = w;
/* 112 */     this.externalSheet = es;
/* 113 */     this.workbookSettings = ws;
/*     */     
/* 115 */     Assert.verify(w != null);
/* 116 */     Assert.verify(es != null);
/*     */     
/* 118 */     this.data = new byte[dvsr.data.length];
/* 119 */     System.arraycopy(dvsr.data, 0, this.data, 0, this.data.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataValiditySettingsRecord(DVParser dvp)
/*     */   {
/* 129 */     super(Type.DV);
/* 130 */     this.dvParser = dvp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 138 */     if (this.dvParser == null)
/*     */     {
/* 140 */       this.dvParser = new DVParser(this.data, this.externalSheet, this.workbook, this.workbookSettings);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 152 */     if (this.dvParser == null)
/*     */     {
/* 154 */       return this.data;
/*     */     }
/*     */     
/* 157 */     return this.dvParser.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertRow(int row)
/*     */   {
/* 167 */     if (this.dvParser == null)
/*     */     {
/* 169 */       initialize();
/*     */     }
/*     */     
/* 172 */     this.dvParser.insertRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int row)
/*     */   {
/* 182 */     if (this.dvParser == null)
/*     */     {
/* 184 */       initialize();
/*     */     }
/*     */     
/* 187 */     this.dvParser.removeRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertColumn(int col)
/*     */   {
/* 197 */     if (this.dvParser == null)
/*     */     {
/* 199 */       initialize();
/*     */     }
/*     */     
/* 202 */     this.dvParser.insertColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeColumn(int col)
/*     */   {
/* 212 */     if (this.dvParser == null)
/*     */     {
/* 214 */       initialize();
/*     */     }
/*     */     
/* 217 */     this.dvParser.removeColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstColumn()
/*     */   {
/* 227 */     if (this.dvParser == null)
/*     */     {
/* 229 */       initialize();
/*     */     }
/*     */     
/* 232 */     return this.dvParser.getFirstColumn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastColumn()
/*     */   {
/* 242 */     if (this.dvParser == null)
/*     */     {
/* 244 */       initialize();
/*     */     }
/*     */     
/* 247 */     return this.dvParser.getLastColumn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstRow()
/*     */   {
/* 257 */     if (this.dvParser == null)
/*     */     {
/* 259 */       initialize();
/*     */     }
/*     */     
/* 262 */     return this.dvParser.getFirstRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastRow()
/*     */   {
/* 272 */     if (this.dvParser == null)
/*     */     {
/* 274 */       initialize();
/*     */     }
/*     */     
/* 277 */     return this.dvParser.getLastRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setDataValidation(DataValidation dv)
/*     */   {
/* 287 */     this.dataValidation = dv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DVParser getDVParser()
/*     */   {
/* 296 */     return this.dvParser;
/*     */   }
/*     */   
/*     */   public String getValidationFormula()
/*     */   {
/*     */     try
/*     */     {
/* 303 */       if (this.dvParser == null)
/*     */       {
/* 305 */         initialize();
/*     */       }
/*     */       
/* 308 */       return this.dvParser.getValidationFormula();
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 312 */       logger.warn("Cannot read drop down range " + e.getMessage()); }
/* 313 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DataValiditySettingsRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */