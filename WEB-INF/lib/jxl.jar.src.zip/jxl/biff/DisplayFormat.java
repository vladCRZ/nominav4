package jxl.biff;

public abstract interface DisplayFormat
{
  public abstract int getFormatIndex();
  
  public abstract boolean isInitialized();
  
  public abstract void initialize(int paramInt);
  
  public abstract boolean isBuiltIn();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DisplayFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */