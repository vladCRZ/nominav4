/*    */ package jxl.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleHelper
/*    */ {
/*    */   public static double getIEEEDouble(byte[] data, int pos)
/*    */   {
/* 43 */     int num1 = IntegerHelper.getInt(data[pos], data[(pos + 1)], data[(pos + 2)], data[(pos + 3)]);
/*    */     
/* 45 */     int num2 = IntegerHelper.getInt(data[(pos + 4)], data[(pos + 5)], data[(pos + 6)], data[(pos + 7)]);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 51 */     boolean negative = (num2 & 0x80000000) != 0;
/*    */     
/*    */ 
/* 54 */     long val = (num2 & 0x7FFFFFFF) * 4294967296L + (num1 < 0 ? 4294967296L + num1 : num1);
/*    */     
/* 56 */     double value = Double.longBitsToDouble(val);
/*    */     
/* 58 */     if (negative)
/*    */     {
/* 60 */       value = -value;
/*    */     }
/* 62 */     return value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void getIEEEBytes(double d, byte[] target, int pos)
/*    */   {
/* 76 */     long val = Double.doubleToLongBits(d);
/* 77 */     target[pos] = ((byte)(int)(val & 0xFF));
/* 78 */     target[(pos + 1)] = ((byte)(int)((val & 0xFF00) >> 8));
/* 79 */     target[(pos + 2)] = ((byte)(int)((val & 0xFF0000) >> 16));
/* 80 */     target[(pos + 3)] = ((byte)(int)((val & 0xFFFFFFFFFF000000) >> 24));
/* 81 */     target[(pos + 4)] = ((byte)(int)((val & 0xFF00000000) >> 32));
/* 82 */     target[(pos + 5)] = ((byte)(int)((val & 0xFF0000000000) >> 40));
/* 83 */     target[(pos + 6)] = ((byte)(int)((val & 0xFF000000000000) >> 48));
/* 84 */     target[(pos + 7)] = ((byte)(int)((val & 0xFF00000000000000) >> 56));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\DoubleHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */