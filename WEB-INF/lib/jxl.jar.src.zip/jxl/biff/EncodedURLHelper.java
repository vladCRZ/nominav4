/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncodedURLHelper
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(EncodedURLHelper.class);
/*     */   
/*     */ 
/*  37 */   private static byte msDosDriveLetter = 1;
/*  38 */   private static byte sameDrive = 2;
/*  39 */   private static byte endOfSubdirectory = 3;
/*  40 */   private static byte parentDirectory = 4;
/*  41 */   private static byte unencodedUrl = 5;
/*     */   
/*     */   public static byte[] getEncodedURL(String s, WorkbookSettings ws)
/*     */   {
/*  45 */     if (s.startsWith("http:"))
/*     */     {
/*  47 */       return getURL(s, ws);
/*     */     }
/*     */     
/*     */ 
/*  51 */     return getFile(s, ws);
/*     */   }
/*     */   
/*     */ 
/*     */   private static byte[] getFile(String s, WorkbookSettings ws)
/*     */   {
/*  57 */     ByteArray byteArray = new ByteArray();
/*     */     
/*  59 */     int pos = 0;
/*  60 */     if (s.charAt(1) == ':')
/*     */     {
/*     */ 
/*  63 */       byteArray.add(msDosDriveLetter);
/*  64 */       byteArray.add((byte)s.charAt(0));
/*  65 */       pos = 2;
/*     */     }
/*  67 */     else if ((s.charAt(pos) == '\\') || (s.charAt(pos) == '/'))
/*     */     {
/*     */ 
/*  70 */       byteArray.add(sameDrive);
/*     */     }
/*     */     
/*     */ 
/*  74 */     while ((s.charAt(pos) == '\\') || (s.charAt(pos) == '/'))
/*     */     {
/*  76 */       pos++;
/*     */     }
/*     */     
/*  79 */     while (pos < s.length())
/*     */     {
/*  81 */       int nextSepIndex1 = s.indexOf('/', pos);
/*  82 */       int nextSepIndex2 = s.indexOf('\\', pos);
/*  83 */       int nextSepIndex = 0;
/*  84 */       String nextFileNameComponent = null;
/*     */       
/*  86 */       if ((nextSepIndex1 != -1) && (nextSepIndex2 != -1))
/*     */       {
/*     */ 
/*  89 */         nextSepIndex = Math.min(nextSepIndex1, nextSepIndex2);
/*     */       }
/*  91 */       else if ((nextSepIndex1 == -1) || (nextSepIndex2 == -1))
/*     */       {
/*     */ 
/*  94 */         nextSepIndex = Math.max(nextSepIndex1, nextSepIndex2);
/*     */       }
/*     */       
/*  97 */       if (nextSepIndex == -1)
/*     */       {
/*     */ 
/* 100 */         nextFileNameComponent = s.substring(pos);
/* 101 */         pos = s.length();
/*     */       }
/*     */       else
/*     */       {
/* 105 */         nextFileNameComponent = s.substring(pos, nextSepIndex);
/* 106 */         pos = nextSepIndex + 1;
/*     */       }
/*     */       
/* 109 */       if (!nextFileNameComponent.equals("."))
/*     */       {
/*     */ 
/*     */ 
/* 113 */         if (nextFileNameComponent.equals(".."))
/*     */         {
/*     */ 
/* 116 */           byteArray.add(parentDirectory);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 121 */           byteArray.add(StringHelper.getBytes(nextFileNameComponent, ws));
/*     */         }
/*     */       }
/*     */       
/* 125 */       if (pos < s.length())
/*     */       {
/* 127 */         byteArray.add(endOfSubdirectory);
/*     */       }
/*     */     }
/*     */     
/* 131 */     return byteArray.getBytes();
/*     */   }
/*     */   
/*     */   private static byte[] getURL(String s, WorkbookSettings ws)
/*     */   {
/* 136 */     ByteArray byteArray = new ByteArray();
/* 137 */     byteArray.add(unencodedUrl);
/* 138 */     byteArray.add((byte)s.length());
/* 139 */     byteArray.add(StringHelper.getBytes(s, ws));
/* 140 */     return byteArray.getBytes();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\EncodedURLHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */