/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Font;
/*     */ import jxl.format.ScriptStyle;
/*     */ import jxl.format.UnderlineStyle;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontRecord
/*     */   extends WritableRecordData
/*     */   implements Font
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(FontRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pointHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int colourIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int boldWeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int scriptStyle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int underlineStyle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte fontFamily;
/*     */   
/*     */ 
/*     */ 
/*     */   private byte characterSet;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean italic;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean struckout;
/*     */   
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */   private int fontIndex;
/*     */   
/*     */ 
/*     */ 
/*  98 */   public static final Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int EXCEL_UNITS_PER_POINT = 20;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FontRecord(String fn, int ps, int bold, boolean it, int us, int ci, int ss)
/*     */   {
/* 119 */     super(Type.FONT);
/* 120 */     this.boldWeight = bold;
/* 121 */     this.underlineStyle = us;
/* 122 */     this.name = fn;
/* 123 */     this.pointHeight = ps;
/* 124 */     this.italic = it;
/* 125 */     this.scriptStyle = ss;
/* 126 */     this.colourIndex = ci;
/* 127 */     this.initialized = false;
/* 128 */     this.struckout = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontRecord(Record t, WorkbookSettings ws)
/*     */   {
/* 140 */     super(t);
/*     */     
/* 142 */     byte[] data = getRecord().getData();
/*     */     
/* 144 */     this.pointHeight = (IntegerHelper.getInt(data[0], data[1]) / 20);
/*     */     
/* 146 */     this.colourIndex = IntegerHelper.getInt(data[4], data[5]);
/* 147 */     this.boldWeight = IntegerHelper.getInt(data[6], data[7]);
/* 148 */     this.scriptStyle = IntegerHelper.getInt(data[8], data[9]);
/* 149 */     this.underlineStyle = data[10];
/* 150 */     this.fontFamily = data[11];
/* 151 */     this.characterSet = data[12];
/* 152 */     this.initialized = false;
/*     */     
/* 154 */     if ((data[2] & 0x2) != 0)
/*     */     {
/* 156 */       this.italic = true;
/*     */     }
/*     */     
/* 159 */     if ((data[2] & 0x8) != 0)
/*     */     {
/* 161 */       this.struckout = true;
/*     */     }
/*     */     
/* 164 */     int numChars = data[14];
/* 165 */     if (data[15] == 0)
/*     */     {
/* 167 */       this.name = StringHelper.getString(data, numChars, 16, ws);
/*     */     }
/* 169 */     else if (data[15] == 1)
/*     */     {
/* 171 */       this.name = StringHelper.getUnicodeString(data, numChars, 16);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 176 */       this.name = StringHelper.getString(data, numChars, 15, ws);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontRecord(Record t, WorkbookSettings ws, Biff7 dummy)
/*     */   {
/* 190 */     super(t);
/*     */     
/* 192 */     byte[] data = getRecord().getData();
/*     */     
/* 194 */     this.pointHeight = (IntegerHelper.getInt(data[0], data[1]) / 20);
/*     */     
/* 196 */     this.colourIndex = IntegerHelper.getInt(data[4], data[5]);
/* 197 */     this.boldWeight = IntegerHelper.getInt(data[6], data[7]);
/* 198 */     this.scriptStyle = IntegerHelper.getInt(data[8], data[9]);
/* 199 */     this.underlineStyle = data[10];
/* 200 */     this.fontFamily = data[11];
/* 201 */     this.initialized = false;
/*     */     
/* 203 */     if ((data[2] & 0x2) != 0)
/*     */     {
/* 205 */       this.italic = true;
/*     */     }
/*     */     
/* 208 */     if ((data[2] & 0x8) != 0)
/*     */     {
/* 210 */       this.struckout = true;
/*     */     }
/*     */     
/* 213 */     int numChars = data[14];
/* 214 */     this.name = StringHelper.getString(data, numChars, 15, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FontRecord(Font f)
/*     */   {
/* 224 */     super(Type.FONT);
/*     */     
/* 226 */     Assert.verify(f != null);
/*     */     
/* 228 */     this.pointHeight = f.getPointSize();
/* 229 */     this.colourIndex = f.getColour().getValue();
/* 230 */     this.boldWeight = f.getBoldWeight();
/* 231 */     this.scriptStyle = f.getScriptStyle().getValue();
/* 232 */     this.underlineStyle = f.getUnderlineStyle().getValue();
/* 233 */     this.italic = f.isItalic();
/* 234 */     this.name = f.getName();
/* 235 */     this.struckout = f.isStruckout();
/* 236 */     this.initialized = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 246 */     byte[] data = new byte[16 + this.name.length() * 2];
/*     */     
/*     */ 
/* 249 */     IntegerHelper.getTwoBytes(this.pointHeight * 20, data, 0);
/*     */     
/*     */ 
/* 252 */     if (this.italic)
/*     */     {
/* 254 */       int tmp36_35 = 2; byte[] tmp36_34 = data;tmp36_34[tmp36_35] = ((byte)(tmp36_34[tmp36_35] | 0x2));
/*     */     }
/*     */     
/* 257 */     if (this.struckout)
/*     */     {
/* 259 */       int tmp51_50 = 2; byte[] tmp51_49 = data;tmp51_49[tmp51_50] = ((byte)(tmp51_49[tmp51_50] | 0x8));
/*     */     }
/*     */     
/*     */ 
/* 263 */     IntegerHelper.getTwoBytes(this.colourIndex, data, 4);
/*     */     
/*     */ 
/* 266 */     IntegerHelper.getTwoBytes(this.boldWeight, data, 6);
/*     */     
/*     */ 
/* 269 */     IntegerHelper.getTwoBytes(this.scriptStyle, data, 8);
/*     */     
/*     */ 
/* 272 */     data[10] = ((byte)this.underlineStyle);
/*     */     
/*     */ 
/* 275 */     data[11] = this.fontFamily;
/*     */     
/*     */ 
/* 278 */     data[12] = this.characterSet;
/*     */     
/*     */ 
/* 281 */     data[13] = 0;
/*     */     
/*     */ 
/* 284 */     data[14] = ((byte)this.name.length());
/*     */     
/* 286 */     data[15] = 1;
/*     */     
/*     */ 
/* 289 */     StringHelper.getUnicodeBytes(this.name, data, 16);
/*     */     
/* 291 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isInitialized()
/*     */   {
/* 301 */     return this.initialized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void initialize(int pos)
/*     */   {
/* 312 */     this.fontIndex = pos;
/* 313 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void uninitialize()
/*     */   {
/* 322 */     this.initialized = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getFontIndex()
/*     */   {
/* 332 */     return this.fontIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontPointSize(int ps)
/*     */   {
/* 342 */     Assert.verify(!this.initialized);
/*     */     
/* 344 */     this.pointHeight = ps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPointSize()
/*     */   {
/* 354 */     return this.pointHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontBoldStyle(int bs)
/*     */   {
/* 364 */     Assert.verify(!this.initialized);
/*     */     
/* 366 */     this.boldWeight = bs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBoldWeight()
/*     */   {
/* 376 */     return this.boldWeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontItalic(boolean i)
/*     */   {
/* 387 */     Assert.verify(!this.initialized);
/*     */     
/* 389 */     this.italic = i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isItalic()
/*     */   {
/* 399 */     return this.italic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontUnderlineStyle(int us)
/*     */   {
/* 410 */     Assert.verify(!this.initialized);
/*     */     
/* 412 */     this.underlineStyle = us;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnderlineStyle getUnderlineStyle()
/*     */   {
/* 422 */     return UnderlineStyle.getStyle(this.underlineStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontColour(int c)
/*     */   {
/* 433 */     Assert.verify(!this.initialized);
/*     */     
/* 435 */     this.colourIndex = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Colour getColour()
/*     */   {
/* 445 */     return Colour.getInternalColour(this.colourIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontScriptStyle(int ss)
/*     */   {
/* 456 */     Assert.verify(!this.initialized);
/*     */     
/* 458 */     this.scriptStyle = ss;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptStyle getScriptStyle()
/*     */   {
/* 468 */     return ScriptStyle.getStyle(this.scriptStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 478 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 487 */     return this.name.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 497 */     if (o == this)
/*     */     {
/* 499 */       return true;
/*     */     }
/*     */     
/* 502 */     if (!(o instanceof FontRecord))
/*     */     {
/* 504 */       return false;
/*     */     }
/*     */     
/* 507 */     FontRecord font = (FontRecord)o;
/*     */     
/* 509 */     if ((this.pointHeight == font.pointHeight) && (this.colourIndex == font.colourIndex) && (this.boldWeight == font.boldWeight) && (this.scriptStyle == font.scriptStyle) && (this.underlineStyle == font.underlineStyle) && (this.italic == font.italic) && (this.struckout == font.struckout) && (this.fontFamily == font.fontFamily) && (this.characterSet == font.characterSet) && (this.name.equals(font.name)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 520 */       return true;
/*     */     }
/*     */     
/* 523 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStruckout()
/*     */   {
/* 533 */     return this.struckout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFontStruckout(boolean os)
/*     */   {
/* 543 */     this.struckout = os;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\FontRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */