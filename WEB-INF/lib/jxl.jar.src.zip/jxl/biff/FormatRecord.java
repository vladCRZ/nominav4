/*     */ package jxl.biff;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatRecord
/*     */   extends WritableRecordData
/*     */   implements DisplayFormat, jxl.format.Format
/*     */ {
/*  42 */   public static Logger logger = Logger.getLogger(FormatRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int indexCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formatString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean date;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean number;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private java.text.Format format;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private static String[] dateStrings = { "dd", "mm", "yy", "hh", "ss", "m/", "/d" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */   public static final BiffType biff8 = new BiffType(null);
/*  99 */   public static final BiffType biff7 = new BiffType(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FormatRecord(String fmt, int refno)
/*     */   {
/* 109 */     super(Type.FORMAT);
/* 110 */     this.formatString = fmt;
/* 111 */     this.indexCode = refno;
/* 112 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FormatRecord()
/*     */   {
/* 120 */     super(Type.FORMAT);
/* 121 */     this.initialized = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FormatRecord(FormatRecord fr)
/*     */   {
/* 131 */     super(Type.FORMAT);
/* 132 */     this.initialized = false;
/*     */     
/* 134 */     this.formatString = fr.formatString;
/* 135 */     this.date = fr.date;
/* 136 */     this.number = fr.number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormatRecord(Record t, WorkbookSettings ws, BiffType biffType)
/*     */   {
/* 150 */     super(t);
/*     */     
/* 152 */     byte[] data = getRecord().getData();
/* 153 */     this.indexCode = IntegerHelper.getInt(data[0], data[1]);
/* 154 */     this.initialized = true;
/*     */     
/* 156 */     if (biffType == biff8)
/*     */     {
/* 158 */       int numchars = IntegerHelper.getInt(data[2], data[3]);
/* 159 */       if (data[4] == 0)
/*     */       {
/* 161 */         this.formatString = StringHelper.getString(data, numchars, 5, ws);
/*     */       }
/*     */       else
/*     */       {
/* 165 */         this.formatString = StringHelper.getUnicodeString(data, numchars, 5);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 170 */       int numchars = data[2];
/* 171 */       byte[] chars = new byte[numchars];
/* 172 */       System.arraycopy(data, 3, chars, 0, chars.length);
/* 173 */       this.formatString = new String(chars);
/*     */     }
/*     */     
/* 176 */     this.date = false;
/* 177 */     this.number = false;
/*     */     
/*     */ 
/* 180 */     for (int i = 0; i < dateStrings.length; i++)
/*     */     {
/* 182 */       String dateString = dateStrings[i];
/* 183 */       if ((this.formatString.indexOf(dateString) != -1) || (this.formatString.indexOf(dateString.toUpperCase()) != -1))
/*     */       {
/*     */ 
/* 186 */         this.date = true;
/* 187 */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 192 */     if (!this.date)
/*     */     {
/* 194 */       if ((this.formatString.indexOf('#') != -1) || (this.formatString.indexOf('0') != -1))
/*     */       {
/*     */ 
/* 197 */         this.number = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 209 */     this.data = new byte[this.formatString.length() * 2 + 3 + 2];
/*     */     
/* 211 */     IntegerHelper.getTwoBytes(this.indexCode, this.data, 0);
/* 212 */     IntegerHelper.getTwoBytes(this.formatString.length(), this.data, 2);
/* 213 */     this.data[4] = 1;
/* 214 */     StringHelper.getUnicodeBytes(this.formatString, this.data, 5);
/*     */     
/* 216 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFormatIndex()
/*     */   {
/* 226 */     return this.indexCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInitialized()
/*     */   {
/* 236 */     return this.initialized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize(int pos)
/*     */   {
/* 248 */     this.indexCode = pos;
/* 249 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String replace(String input, String search, String replace)
/*     */   {
/* 263 */     String fmtstr = input;
/* 264 */     int pos = fmtstr.indexOf(search);
/* 265 */     while (pos != -1)
/*     */     {
/* 267 */       StringBuffer tmp = new StringBuffer(fmtstr.substring(0, pos));
/* 268 */       tmp.append(replace);
/* 269 */       tmp.append(fmtstr.substring(pos + search.length()));
/* 270 */       fmtstr = tmp.toString();
/* 271 */       pos = fmtstr.indexOf(search);
/*     */     }
/* 273 */     return fmtstr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setFormatString(String s)
/*     */   {
/* 284 */     this.formatString = s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isDate()
/*     */   {
/* 294 */     return this.date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isNumber()
/*     */   {
/* 304 */     return this.number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final NumberFormat getNumberFormat()
/*     */   {
/* 314 */     if ((this.format != null) && ((this.format instanceof NumberFormat)))
/*     */     {
/* 316 */       return (NumberFormat)this.format;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 321 */       String fs = this.formatString;
/*     */       
/*     */ 
/* 324 */       fs = replace(fs, "E+", "E");
/* 325 */       fs = replace(fs, "_)", "");
/* 326 */       fs = replace(fs, "_", "");
/* 327 */       fs = replace(fs, "[Red]", "");
/* 328 */       fs = replace(fs, "\\", "");
/*     */       
/* 330 */       this.format = new DecimalFormat(fs);
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/*     */ 
/* 336 */       this.format = new DecimalFormat("#.###");
/*     */     }
/*     */     
/* 339 */     return (NumberFormat)this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DateFormat getDateFormat()
/*     */   {
/* 349 */     if ((this.format != null) && ((this.format instanceof DateFormat)))
/*     */     {
/* 351 */       return (DateFormat)this.format;
/*     */     }
/*     */     
/* 354 */     String fmt = this.formatString;
/*     */     
/*     */ 
/* 357 */     int pos = fmt.indexOf("AM/PM");
/* 358 */     while (pos != -1)
/*     */     {
/* 360 */       StringBuffer sb = new StringBuffer(fmt.substring(0, pos));
/* 361 */       sb.append('a');
/* 362 */       sb.append(fmt.substring(pos + 5));
/* 363 */       fmt = sb.toString();
/* 364 */       pos = fmt.indexOf("AM/PM");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 369 */     pos = fmt.indexOf("ss.0");
/* 370 */     while (pos != -1)
/*     */     {
/* 372 */       StringBuffer sb = new StringBuffer(fmt.substring(0, pos));
/* 373 */       sb.append("ss.SSS");
/*     */       
/*     */ 
/* 376 */       pos += 4;
/* 377 */       while ((pos < fmt.length()) && (fmt.charAt(pos) == '0'))
/*     */       {
/* 379 */         pos++;
/*     */       }
/*     */       
/* 382 */       sb.append(fmt.substring(pos));
/* 383 */       fmt = sb.toString();
/* 384 */       pos = fmt.indexOf("ss.0");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 389 */     StringBuffer sb = new StringBuffer();
/* 390 */     for (int i = 0; i < fmt.length(); i++)
/*     */     {
/* 392 */       if (fmt.charAt(i) != '\\')
/*     */       {
/* 394 */         sb.append(fmt.charAt(i));
/*     */       }
/*     */     }
/*     */     
/* 398 */     fmt = sb.toString();
/*     */     
/*     */ 
/*     */ 
/* 402 */     if (fmt.charAt(0) == '[')
/*     */     {
/* 404 */       int end = fmt.indexOf(']');
/* 405 */       if (end != -1)
/*     */       {
/* 407 */         fmt = fmt.substring(end + 1);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 412 */     fmt = replace(fmt, ";@", "");
/*     */     
/*     */ 
/*     */ 
/* 416 */     char[] formatBytes = fmt.toCharArray();
/*     */     
/* 418 */     for (int i = 0; i < formatBytes.length; i++)
/*     */     {
/* 420 */       if (formatBytes[i] == 'm')
/*     */       {
/*     */ 
/*     */ 
/* 424 */         if ((i > 0) && ((formatBytes[(i - 1)] == 'm') || (formatBytes[(i - 1)] == 'M')))
/*     */         {
/* 426 */           formatBytes[i] = formatBytes[(i - 1)];
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 434 */           int minuteDist = Integer.MAX_VALUE;
/* 435 */           for (int j = i - 1; j > 0; j--)
/*     */           {
/* 437 */             if (formatBytes[j] == 'h')
/*     */             {
/* 439 */               minuteDist = i - j;
/* 440 */               break;
/*     */             }
/*     */           }
/*     */           
/* 444 */           for (int j = i + 1; j < formatBytes.length; j++)
/*     */           {
/* 446 */             if (formatBytes[j] == 'h')
/*     */             {
/* 448 */               minuteDist = Math.min(minuteDist, j - i);
/* 449 */               break;
/*     */             }
/*     */           }
/*     */           
/* 453 */           for (int j = i - 1; j > 0; j--)
/*     */           {
/* 455 */             if (formatBytes[j] == 'H')
/*     */             {
/* 457 */               minuteDist = i - j;
/* 458 */               break;
/*     */             }
/*     */           }
/*     */           
/* 462 */           for (int j = i + 1; j < formatBytes.length; j++)
/*     */           {
/* 464 */             if (formatBytes[j] == 'H')
/*     */             {
/* 466 */               minuteDist = Math.min(minuteDist, j - i);
/* 467 */               break;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 472 */           for (int j = i - 1; j > 0; j--)
/*     */           {
/* 474 */             if (formatBytes[j] == 's')
/*     */             {
/* 476 */               minuteDist = Math.min(minuteDist, i - j);
/* 477 */               break;
/*     */             }
/*     */           }
/* 480 */           for (int j = i + 1; j < formatBytes.length; j++)
/*     */           {
/* 482 */             if (formatBytes[j] == 's')
/*     */             {
/* 484 */               minuteDist = Math.min(minuteDist, j - i);
/* 485 */               break;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 491 */           int monthDist = Integer.MAX_VALUE;
/* 492 */           for (int j = i - 1; j > 0; j--)
/*     */           {
/* 494 */             if (formatBytes[j] == 'd')
/*     */             {
/* 496 */               monthDist = i - j;
/* 497 */               break;
/*     */             }
/*     */           }
/*     */           
/* 501 */           for (int j = i + 1; j < formatBytes.length; j++)
/*     */           {
/* 503 */             if (formatBytes[j] == 'd')
/*     */             {
/* 505 */               monthDist = Math.min(monthDist, j - i);
/* 506 */               break;
/*     */             }
/*     */           }
/*     */           
/* 510 */           for (int j = i - 1; j > 0; j--)
/*     */           {
/* 512 */             if (formatBytes[j] == 'y')
/*     */             {
/* 514 */               monthDist = Math.min(monthDist, i - j);
/* 515 */               break;
/*     */             }
/*     */           }
/* 518 */           for (int j = i + 1; j < formatBytes.length; j++)
/*     */           {
/* 520 */             if (formatBytes[j] == 'y')
/*     */             {
/* 522 */               monthDist = Math.min(monthDist, j - i);
/* 523 */               break;
/*     */             }
/*     */           }
/*     */           
/* 527 */           if (monthDist < minuteDist)
/*     */           {
/*     */ 
/* 530 */             formatBytes[i] = Character.toUpperCase(formatBytes[i]);
/*     */           }
/* 532 */           else if ((monthDist == minuteDist) && (monthDist != Integer.MAX_VALUE))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 537 */             char ind = formatBytes[(i - monthDist)];
/* 538 */             if ((ind == 'y') || (ind == 'd'))
/*     */             {
/*     */ 
/* 541 */               formatBytes[i] = Character.toUpperCase(formatBytes[i]);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 550 */       this.format = new SimpleDateFormat(new String(formatBytes));
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 555 */       this.format = new SimpleDateFormat("dd MM yyyy hh:mm:ss");
/*     */     }
/* 557 */     return (DateFormat)this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndexCode()
/*     */   {
/* 567 */     return this.indexCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormatString()
/*     */   {
/* 577 */     return this.formatString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBuiltIn()
/*     */   {
/* 587 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 596 */     return this.formatString.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 608 */     if (o == this)
/*     */     {
/* 610 */       return true;
/*     */     }
/*     */     
/* 613 */     if (!(o instanceof FormatRecord))
/*     */     {
/* 615 */       return false;
/*     */     }
/*     */     
/* 618 */     FormatRecord fr = (FormatRecord)o;
/*     */     
/*     */ 
/* 621 */     if ((this.initialized) && (fr.initialized))
/*     */     {
/*     */ 
/* 624 */       if ((this.date != fr.date) || (this.number != fr.number))
/*     */       {
/*     */ 
/* 627 */         return false;
/*     */       }
/*     */       
/* 630 */       return this.formatString.equals(fr.formatString);
/*     */     }
/*     */     
/*     */ 
/* 634 */     return this.formatString.equals(fr.formatString);
/*     */   }
/*     */   
/*     */   private static class BiffType {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\FormatRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */