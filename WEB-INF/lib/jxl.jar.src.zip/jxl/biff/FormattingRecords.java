/*     */ package jxl.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.RGB;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormattingRecords
/*     */ {
/*  44 */   private static Logger logger = Logger.getLogger(FormattingRecords.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HashMap formats;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList formatsList;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList xfRecords;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int nextCustomIndexNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Fonts fonts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PaletteRecord palette;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int customFormatStartIndex = 164;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int maxFormatRecordsIndex = 441;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int minXFRecords = 21;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormattingRecords(Fonts f)
/*     */   {
/* 101 */     this.xfRecords = new ArrayList(10);
/* 102 */     this.formats = new HashMap(10);
/* 103 */     this.formatsList = new ArrayList(10);
/* 104 */     this.fonts = f;
/* 105 */     this.nextCustomIndexNumber = 164;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addStyle(XFRecord xf)
/*     */     throws NumFormatRecordsException
/*     */   {
/* 120 */     if (!xf.isInitialized())
/*     */     {
/* 122 */       int pos = this.xfRecords.size();
/* 123 */       xf.initialize(pos, this, this.fonts);
/* 124 */       this.xfRecords.add(xf);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 131 */     else if (xf.getXFIndex() >= this.xfRecords.size())
/*     */     {
/* 133 */       this.xfRecords.add(xf);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addFormat(DisplayFormat fr)
/*     */     throws NumFormatRecordsException
/*     */   {
/* 151 */     if ((fr.isInitialized()) && (fr.getFormatIndex() >= 441))
/*     */     {
/*     */ 
/* 154 */       logger.warn("Format index exceeds Excel maximum - assigning custom number");
/*     */       
/* 156 */       fr.initialize(this.nextCustomIndexNumber);
/* 157 */       this.nextCustomIndexNumber += 1;
/*     */     }
/*     */     
/*     */ 
/* 161 */     if (!fr.isInitialized())
/*     */     {
/* 163 */       fr.initialize(this.nextCustomIndexNumber);
/* 164 */       this.nextCustomIndexNumber += 1;
/*     */     }
/*     */     
/* 167 */     if (this.nextCustomIndexNumber > 441)
/*     */     {
/* 169 */       this.nextCustomIndexNumber = 441;
/* 170 */       throw new NumFormatRecordsException();
/*     */     }
/*     */     
/* 173 */     if (fr.getFormatIndex() >= this.nextCustomIndexNumber)
/*     */     {
/* 175 */       this.nextCustomIndexNumber = (fr.getFormatIndex() + 1);
/*     */     }
/*     */     
/* 178 */     if (!fr.isBuiltIn())
/*     */     {
/* 180 */       this.formatsList.add(fr);
/* 181 */       this.formats.put(new Integer(fr.getFormatIndex()), fr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isDate(int pos)
/*     */   {
/* 195 */     XFRecord xfr = (XFRecord)this.xfRecords.get(pos);
/*     */     
/* 197 */     if (xfr.isDate())
/*     */     {
/* 199 */       return true;
/*     */     }
/*     */     
/* 202 */     FormatRecord fr = (FormatRecord)this.formats.get(new Integer(xfr.getFormatRecord()));
/*     */     
/*     */ 
/* 205 */     return fr == null ? false : fr.isDate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DateFormat getDateFormat(int pos)
/*     */   {
/* 217 */     XFRecord xfr = (XFRecord)this.xfRecords.get(pos);
/*     */     
/* 219 */     if (xfr.isDate())
/*     */     {
/* 221 */       return xfr.getDateFormat();
/*     */     }
/*     */     
/* 224 */     FormatRecord fr = (FormatRecord)this.formats.get(new Integer(xfr.getFormatRecord()));
/*     */     
/*     */ 
/* 227 */     if (fr == null)
/*     */     {
/* 229 */       return null;
/*     */     }
/*     */     
/* 232 */     return fr.isDate() ? fr.getDateFormat() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final NumberFormat getNumberFormat(int pos)
/*     */   {
/* 244 */     XFRecord xfr = (XFRecord)this.xfRecords.get(pos);
/*     */     
/* 246 */     if (xfr.isNumber())
/*     */     {
/* 248 */       return xfr.getNumberFormat();
/*     */     }
/*     */     
/* 251 */     FormatRecord fr = (FormatRecord)this.formats.get(new Integer(xfr.getFormatRecord()));
/*     */     
/*     */ 
/* 254 */     if (fr == null)
/*     */     {
/* 256 */       return null;
/*     */     }
/*     */     
/* 259 */     return fr.isNumber() ? fr.getNumberFormat() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FormatRecord getFormatRecord(int index)
/*     */   {
/* 270 */     return (FormatRecord)this.formats.get(new Integer(index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/* 282 */     Iterator i = this.formatsList.iterator();
/* 283 */     FormatRecord fr = null;
/* 284 */     while (i.hasNext())
/*     */     {
/* 286 */       fr = (FormatRecord)i.next();
/* 287 */       outputFile.write(fr);
/*     */     }
/*     */     
/*     */ 
/* 291 */     i = this.xfRecords.iterator();
/* 292 */     XFRecord xfr = null;
/* 293 */     while (i.hasNext())
/*     */     {
/* 295 */       xfr = (XFRecord)i.next();
/* 296 */       outputFile.write(xfr);
/*     */     }
/*     */     
/*     */ 
/* 300 */     BuiltInStyle style = new BuiltInStyle(16, 3);
/* 301 */     outputFile.write(style);
/*     */     
/* 303 */     style = new BuiltInStyle(17, 6);
/* 304 */     outputFile.write(style);
/*     */     
/* 306 */     style = new BuiltInStyle(18, 4);
/* 307 */     outputFile.write(style);
/*     */     
/* 309 */     style = new BuiltInStyle(19, 7);
/* 310 */     outputFile.write(style);
/*     */     
/* 312 */     style = new BuiltInStyle(0, 0);
/* 313 */     outputFile.write(style);
/*     */     
/* 315 */     style = new BuiltInStyle(20, 5);
/* 316 */     outputFile.write(style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Fonts getFonts()
/*     */   {
/* 326 */     return this.fonts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final XFRecord getXFRecord(int index)
/*     */   {
/* 338 */     return (XFRecord)this.xfRecords.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int getNumberOfFormatRecords()
/*     */   {
/* 350 */     return this.formatsList.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IndexMapping rationalizeFonts()
/*     */   {
/* 360 */     return this.fonts.rationalize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IndexMapping rationalize(IndexMapping fontMapping, IndexMapping formatMapping)
/*     */   {
/* 378 */     XFRecord xfr = null;
/* 379 */     for (Iterator it = this.xfRecords.iterator(); it.hasNext();)
/*     */     {
/* 381 */       xfr = (XFRecord)it.next();
/*     */       
/* 383 */       if (xfr.getFormatRecord() >= 164)
/*     */       {
/* 385 */         xfr.setFormatIndex(formatMapping.getNewIndex(xfr.getFormatRecord()));
/*     */       }
/*     */       
/* 388 */       xfr.setFontIndex(fontMapping.getNewIndex(xfr.getFontIndex()));
/*     */     }
/*     */     
/* 391 */     ArrayList newrecords = new ArrayList(21);
/* 392 */     IndexMapping mapping = new IndexMapping(this.xfRecords.size());
/* 393 */     int numremoved = 0;
/*     */     
/* 395 */     int numXFRecords = Math.min(21, this.xfRecords.size());
/*     */     
/* 397 */     for (int i = 0; i < numXFRecords; i++)
/*     */     {
/* 399 */       newrecords.add(this.xfRecords.get(i));
/* 400 */       mapping.setMapping(i, i);
/*     */     }
/*     */     
/* 403 */     if (numXFRecords < 21)
/*     */     {
/* 405 */       logger.warn("There are less than the expected minimum number of XF records");
/*     */       
/* 407 */       return mapping;
/*     */     }
/*     */     
/*     */ 
/* 411 */     for (int i = 21; i < this.xfRecords.size(); i++)
/*     */     {
/* 413 */       XFRecord xf = (XFRecord)this.xfRecords.get(i);
/*     */       
/*     */ 
/* 416 */       boolean duplicate = false;
/* 417 */       Iterator it = newrecords.iterator();
/* 418 */       while ((it.hasNext()) && (!duplicate))
/*     */       {
/* 420 */         XFRecord xf2 = (XFRecord)it.next();
/* 421 */         if (xf2.equals(xf))
/*     */         {
/* 423 */           duplicate = true;
/* 424 */           mapping.setMapping(i, mapping.getNewIndex(xf2.getXFIndex()));
/* 425 */           numremoved++;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 430 */       if (!duplicate)
/*     */       {
/* 432 */         newrecords.add(xf);
/* 433 */         mapping.setMapping(i, i - numremoved);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 440 */     for (Iterator i = this.xfRecords.iterator(); i.hasNext();)
/*     */     {
/* 442 */       XFRecord xf = (XFRecord)i.next();
/* 443 */       xf.rationalize(mapping);
/*     */     }
/*     */     
/*     */ 
/* 447 */     this.xfRecords = newrecords;
/*     */     
/* 449 */     return mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IndexMapping rationalizeDisplayFormats()
/*     */   {
/* 462 */     ArrayList newformats = new ArrayList();
/* 463 */     int numremoved = 0;
/* 464 */     IndexMapping mapping = new IndexMapping(this.nextCustomIndexNumber);
/*     */     
/*     */ 
/* 467 */     Iterator i = this.formatsList.iterator();
/* 468 */     DisplayFormat df = null;
/* 469 */     DisplayFormat df2 = null;
/* 470 */     boolean duplicate = false;
/* 471 */     while (i.hasNext())
/*     */     {
/* 473 */       df = (DisplayFormat)i.next();
/*     */       
/* 475 */       Assert.verify(!df.isBuiltIn());
/*     */       
/*     */ 
/* 478 */       Iterator i2 = newformats.iterator();
/* 479 */       duplicate = false;
/* 480 */       while ((i2.hasNext()) && (!duplicate))
/*     */       {
/* 482 */         df2 = (DisplayFormat)i2.next();
/* 483 */         if (df2.equals(df))
/*     */         {
/* 485 */           duplicate = true;
/* 486 */           mapping.setMapping(df.getFormatIndex(), mapping.getNewIndex(df2.getFormatIndex()));
/*     */           
/* 488 */           numremoved++;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 493 */       if (!duplicate)
/*     */       {
/* 495 */         newformats.add(df);
/* 496 */         int indexnum = df.getFormatIndex() - numremoved;
/* 497 */         if (indexnum > 441)
/*     */         {
/* 499 */           logger.warn("Too many number formats - using default format.");
/* 500 */           indexnum = 0;
/*     */         }
/* 502 */         mapping.setMapping(df.getFormatIndex(), df.getFormatIndex() - numremoved);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 508 */     this.formatsList = newformats;
/*     */     
/*     */ 
/* 511 */     i = this.formatsList.iterator();
/*     */     
/* 513 */     while (i.hasNext())
/*     */     {
/* 515 */       df = (DisplayFormat)i.next();
/* 516 */       df.initialize(mapping.getNewIndex(df.getFormatIndex()));
/*     */     }
/*     */     
/* 519 */     return mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PaletteRecord getPalette()
/*     */   {
/* 529 */     return this.palette;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPalette(PaletteRecord pr)
/*     */   {
/* 539 */     this.palette = pr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColourRGB(Colour c, int r, int g, int b)
/*     */   {
/* 552 */     if (this.palette == null)
/*     */     {
/* 554 */       this.palette = new PaletteRecord();
/*     */     }
/* 556 */     this.palette.setColourRGB(c, r, g, b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB getColourRGB(Colour c)
/*     */   {
/* 566 */     if (this.palette == null)
/*     */     {
/* 568 */       return c.getDefaultRGB();
/*     */     }
/*     */     
/* 571 */     return this.palette.getColourRGB(c);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\FormattingRecords.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */