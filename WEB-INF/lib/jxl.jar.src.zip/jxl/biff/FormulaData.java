package jxl.biff;

import jxl.Cell;
import jxl.biff.formula.FormulaException;

public abstract interface FormulaData
  extends Cell
{
  public abstract byte[] getFormulaData()
    throws FormulaException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\FormulaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */