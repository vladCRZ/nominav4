/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HeaderFooter
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(HeaderFooter.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String BOLD_TOGGLE = "&B";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String UNDERLINE_TOGGLE = "&U";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String ITALICS_TOGGLE = "&I";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String STRIKETHROUGH_TOGGLE = "&S";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String DOUBLE_UNDERLINE_TOGGLE = "&E";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String SUPERSCRIPT_TOGGLE = "&X";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String SUBSCRIPT_TOGGLE = "&Y";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String OUTLINE_TOGGLE = "&O";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String SHADOW_TOGGLE = "&H";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String LEFT_ALIGN = "&L";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String CENTRE = "&C";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String RIGHT_ALIGN = "&R";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String PAGENUM = "&P";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String TOTAL_PAGENUM = "&N";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String DATE = "&D";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String TIME = "&T";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String WORKBOOK_NAME = "&F";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String WORKSHEET_NAME = "&A";
/*     */   
/*     */ 
/*     */ 
/*     */   private Contents left;
/*     */   
/*     */ 
/*     */ 
/*     */   private Contents right;
/*     */   
/*     */ 
/*     */ 
/*     */   private Contents centre;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static class Contents
/*     */   {
/*     */     private StringBuffer contents;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Contents()
/*     */     {
/* 149 */       this.contents = new StringBuffer();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Contents(String s)
/*     */     {
/* 160 */       this.contents = new StringBuffer(s);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Contents(Contents copy)
/*     */     {
/* 170 */       this.contents = new StringBuffer(copy.getContents());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected String getContents()
/*     */     {
/* 181 */       return this.contents != null ? this.contents.toString() : "";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void appendInternal(String txt)
/*     */     {
/* 191 */       if (this.contents == null)
/*     */       {
/* 193 */         this.contents = new StringBuffer();
/*     */       }
/*     */       
/* 196 */       this.contents.append(txt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void appendInternal(char ch)
/*     */     {
/* 206 */       if (this.contents == null)
/*     */       {
/* 208 */         this.contents = new StringBuffer();
/*     */       }
/*     */       
/* 211 */       this.contents.append(ch);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void append(String txt)
/*     */     {
/* 221 */       appendInternal(txt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleBold()
/*     */     {
/* 232 */       appendInternal("&B");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleUnderline()
/*     */     {
/* 243 */       appendInternal("&U");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleItalics()
/*     */     {
/* 254 */       appendInternal("&I");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleStrikethrough()
/*     */     {
/* 265 */       appendInternal("&S");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleDoubleUnderline()
/*     */     {
/* 276 */       appendInternal("&E");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleSuperScript()
/*     */     {
/* 287 */       appendInternal("&X");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleSubScript()
/*     */     {
/* 298 */       appendInternal("&Y");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleOutline()
/*     */     {
/* 309 */       appendInternal("&O");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void toggleShadow()
/*     */     {
/* 320 */       appendInternal("&H");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void setFontName(String fontName)
/*     */     {
/* 335 */       appendInternal("&\"");
/* 336 */       appendInternal(fontName);
/* 337 */       appendInternal('"');
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean setFontSize(int size)
/*     */     {
/* 356 */       if ((size < 1) || (size > 99))
/*     */       {
/* 358 */         return false;
/*     */       }
/*     */       
/*     */       String fontSize;
/*     */       
/*     */       String fontSize;
/* 364 */       if (size < 10)
/*     */       {
/*     */ 
/* 367 */         fontSize = "0" + size;
/*     */       }
/*     */       else
/*     */       {
/* 371 */         fontSize = Integer.toString(size);
/*     */       }
/*     */       
/* 374 */       appendInternal('&');
/* 375 */       appendInternal(fontSize);
/* 376 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void appendPageNumber()
/*     */     {
/* 384 */       appendInternal("&P");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void appendTotalPages()
/*     */     {
/* 392 */       appendInternal("&N");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void appendDate()
/*     */     {
/* 400 */       appendInternal("&D");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void appendTime()
/*     */     {
/* 408 */       appendInternal("&T");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void appendWorkbookName()
/*     */     {
/* 416 */       appendInternal("&F");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void appendWorkSheetName()
/*     */     {
/* 424 */       appendInternal("&A");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void clear()
/*     */     {
/* 432 */       this.contents = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean empty()
/*     */     {
/* 442 */       if ((this.contents == null) || (this.contents.length() == 0))
/*     */       {
/* 444 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 448 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HeaderFooter()
/*     */   {
/* 473 */     this.left = createContents();
/* 474 */     this.right = createContents();
/* 475 */     this.centre = createContents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HeaderFooter(HeaderFooter hf)
/*     */   {
/* 485 */     this.left = createContents(hf.left);
/* 486 */     this.right = createContents(hf.right);
/* 487 */     this.centre = createContents(hf.centre);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HeaderFooter(String s)
/*     */   {
/* 496 */     if ((s == null) || (s.length() == 0))
/*     */     {
/* 498 */       this.left = createContents();
/* 499 */       this.right = createContents();
/* 500 */       this.centre = createContents();
/* 501 */       return;
/*     */     }
/*     */     
/* 504 */     int leftPos = s.indexOf("&L");
/* 505 */     int rightPos = s.indexOf("&R");
/* 506 */     int centrePos = s.indexOf("&C");
/*     */     
/* 508 */     if ((leftPos == -1) && (rightPos == -1) && (centrePos == -1))
/*     */     {
/*     */ 
/* 511 */       this.centre = createContents(s);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 516 */       if (leftPos != -1)
/*     */       {
/*     */ 
/* 519 */         int endLeftPos = s.length();
/* 520 */         if (centrePos > leftPos)
/*     */         {
/*     */ 
/* 523 */           endLeftPos = centrePos;
/* 524 */           if ((rightPos > leftPos) && (endLeftPos > rightPos))
/*     */           {
/*     */ 
/* 527 */             endLeftPos = rightPos;
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 537 */         else if (rightPos > leftPos)
/*     */         {
/*     */ 
/* 540 */           endLeftPos = rightPos;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 550 */         this.left = createContents(s.substring(leftPos + 2, endLeftPos));
/*     */       }
/*     */       
/*     */ 
/* 554 */       if (rightPos != -1)
/*     */       {
/*     */ 
/* 557 */         int endRightPos = s.length();
/* 558 */         if (centrePos > rightPos)
/*     */         {
/*     */ 
/* 561 */           endRightPos = centrePos;
/* 562 */           if ((leftPos > rightPos) && (endRightPos > leftPos))
/*     */           {
/*     */ 
/* 565 */             endRightPos = leftPos;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 574 */         else if (leftPos > rightPos)
/*     */         {
/*     */ 
/* 577 */           endRightPos = leftPos;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 585 */         this.right = createContents(s.substring(rightPos + 2, endRightPos));
/*     */       }
/*     */       
/*     */ 
/* 589 */       if (centrePos != -1)
/*     */       {
/*     */ 
/* 592 */         int endCentrePos = s.length();
/* 593 */         if (rightPos > centrePos)
/*     */         {
/*     */ 
/* 596 */           endCentrePos = rightPos;
/* 597 */           if ((leftPos > centrePos) && (endCentrePos > leftPos))
/*     */           {
/*     */ 
/* 600 */             endCentrePos = leftPos;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 609 */         else if (leftPos > centrePos)
/*     */         {
/*     */ 
/* 612 */           endCentrePos = leftPos;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 620 */         this.centre = createContents(s.substring(centrePos + 2, endCentrePos));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 625 */     if (this.left == null)
/*     */     {
/* 627 */       this.left = createContents();
/*     */     }
/*     */     
/* 630 */     if (this.centre == null)
/*     */     {
/* 632 */       this.centre = createContents();
/*     */     }
/*     */     
/* 635 */     if (this.right == null)
/*     */     {
/* 637 */       this.right = createContents();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 649 */     StringBuffer hf = new StringBuffer();
/* 650 */     if (!this.left.empty())
/*     */     {
/* 652 */       hf.append("&L");
/* 653 */       hf.append(this.left.getContents());
/*     */     }
/*     */     
/* 656 */     if (!this.centre.empty())
/*     */     {
/* 658 */       hf.append("&C");
/* 659 */       hf.append(this.centre.getContents());
/*     */     }
/*     */     
/* 662 */     if (!this.right.empty())
/*     */     {
/* 664 */       hf.append("&R");
/* 665 */       hf.append(this.right.getContents());
/*     */     }
/*     */     
/* 668 */     return hf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Contents getRightText()
/*     */   {
/* 678 */     return this.right;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Contents getCentreText()
/*     */   {
/* 688 */     return this.centre;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Contents getLeftText()
/*     */   {
/* 698 */     return this.left;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void clear()
/*     */   {
/* 706 */     this.left.clear();
/* 707 */     this.right.clear();
/* 708 */     this.centre.clear();
/*     */   }
/*     */   
/*     */   protected abstract Contents createContents();
/*     */   
/*     */   protected abstract Contents createContents(String paramString);
/*     */   
/*     */   protected abstract Contents createContents(Contents paramContents);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\HeaderFooter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */