/*    */ package jxl.biff;
/*    */ 
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IndexMapping
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(IndexMapping.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int[] newIndices;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IndexMapping(int size)
/*    */   {
/* 48 */     this.newIndices = new int[size];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMapping(int oldIndex, int newIndex)
/*    */   {
/* 58 */     this.newIndices[oldIndex] = newIndex;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getNewIndex(int oldIndex)
/*    */   {
/* 68 */     return this.newIndices[oldIndex];
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\IndexMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */