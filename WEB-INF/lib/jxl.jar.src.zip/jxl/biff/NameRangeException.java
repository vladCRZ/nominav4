/*    */ package jxl.biff;
/*    */ 
/*    */ import jxl.JXLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameRangeException
/*    */   extends JXLException
/*    */ {
/*    */   public NameRangeException()
/*    */   {
/* 35 */     super("");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\NameRangeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */