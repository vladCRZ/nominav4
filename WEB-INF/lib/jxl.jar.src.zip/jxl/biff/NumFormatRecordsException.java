/*    */ package jxl.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumFormatRecordsException
/*    */   extends Exception
/*    */ {
/*    */   public NumFormatRecordsException()
/*    */   {
/* 34 */     super("Internal error:  max number of FORMAT records exceeded");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\NumFormatRecordsException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */