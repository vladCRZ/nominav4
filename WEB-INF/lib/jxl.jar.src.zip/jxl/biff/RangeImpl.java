/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.Range;
/*     */ import jxl.Sheet;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RangeImpl
/*     */   implements Range
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(RangeImpl.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods workbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int sheet1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int sheet2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RangeImpl(WorkbookMethods w, int s1, int c1, int r1, int s2, int c2, int r2)
/*     */   {
/*  92 */     this.workbook = w;
/*  93 */     this.sheet1 = s1;
/*  94 */     this.sheet2 = s2;
/*  95 */     this.row1 = r1;
/*  96 */     this.row2 = r2;
/*  97 */     this.column1 = c1;
/*  98 */     this.column2 = c2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell getTopLeft()
/*     */   {
/* 108 */     Sheet s = this.workbook.getReadSheet(this.sheet1);
/*     */     
/* 110 */     if ((this.column1 < s.getColumns()) && (this.row1 < s.getRows()))
/*     */     {
/*     */ 
/* 113 */       return s.getCell(this.column1, this.row1);
/*     */     }
/*     */     
/*     */ 
/* 117 */     return new EmptyCell(this.column1, this.row1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell getBottomRight()
/*     */   {
/* 128 */     Sheet s = this.workbook.getReadSheet(this.sheet2);
/*     */     
/* 130 */     if ((this.column2 < s.getColumns()) && (this.row2 < s.getRows()))
/*     */     {
/*     */ 
/* 133 */       return s.getCell(this.column2, this.row2);
/*     */     }
/*     */     
/*     */ 
/* 137 */     return new EmptyCell(this.column2, this.row2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstSheetIndex()
/*     */   {
/* 148 */     return this.sheet1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastSheetIndex()
/*     */   {
/* 158 */     return this.sheet2;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\RangeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */