/*     */ package jxl.biff;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringHelper
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(StringHelper.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */   public static String UNICODE_ENCODING = "UnicodeLittle";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static byte[] getBytes(String s)
/*     */   {
/*  63 */     return s.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytes(String s, WorkbookSettings ws)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       return s.getBytes(ws.getEncoding());
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {}
/*     */     
/*     */ 
/*  82 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getUnicodeBytes(String s)
/*     */   {
/*     */     try
/*     */     {
/*  96 */       byte[] b = s.getBytes(UNICODE_ENCODING);
/*     */       
/*     */       byte[] b2;
/*     */       
/* 100 */       if (b.length == s.length() * 2 + 2)
/*     */       {
/* 102 */         b2 = new byte[b.length - 2];
/* 103 */         System.arraycopy(b, 2, b2, 0, b2.length); }
/* 104 */       return b2;
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 111 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getBytes(String s, byte[] d, int pos)
/*     */   {
/* 126 */     byte[] b = getBytes(s);
/* 127 */     System.arraycopy(b, 0, d, pos, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getUnicodeBytes(String s, byte[] d, int pos)
/*     */   {
/* 140 */     byte[] b = getUnicodeBytes(s);
/* 141 */     System.arraycopy(b, 0, d, pos, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getString(byte[] d, int length, int pos, WorkbookSettings ws)
/*     */   {
/* 157 */     if (length == 0)
/*     */     {
/* 159 */       return "";
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 164 */       return new String(d, pos, length, ws.getEncoding());
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/*     */ 
/* 171 */       logger.warn(e.toString()); }
/* 172 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUnicodeString(byte[] d, int length, int pos)
/*     */   {
/*     */     try
/*     */     {
/* 188 */       byte[] b = new byte[length * 2];
/* 189 */       System.arraycopy(d, pos, b, 0, length * 2);
/* 190 */       return new String(b, UNICODE_ENCODING);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {}
/*     */     
/*     */ 
/* 195 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String replace(String input, String search, String replace)
/*     */   {
/* 213 */     String fmtstr = input;
/* 214 */     int pos = fmtstr.indexOf(search);
/* 215 */     while (pos != -1)
/*     */     {
/* 217 */       StringBuffer tmp = new StringBuffer(fmtstr.substring(0, pos));
/* 218 */       tmp.append(replace);
/* 219 */       tmp.append(fmtstr.substring(pos + search.length()));
/* 220 */       fmtstr = tmp.toString();
/* 221 */       pos = fmtstr.indexOf(search, pos + replace.length());
/*     */     }
/* 223 */     return fmtstr;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\StringHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */