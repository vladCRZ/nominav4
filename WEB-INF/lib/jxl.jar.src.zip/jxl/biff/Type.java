/*     */ package jxl.biff;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Type
/*     */ {
/*     */   public final int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  34 */   private static Type[] types = new Type[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type(int v)
/*     */   {
/*  44 */     this.value = v;
/*     */     
/*     */ 
/*  47 */     Type[] newTypes = new Type[types.length + 1];
/*  48 */     System.arraycopy(types, 0, newTypes, 0, types.length);
/*  49 */     newTypes[types.length] = this;
/*  50 */     types = newTypes;
/*     */   }
/*     */   
/*     */ 
/*  54 */   private static ArbitraryType arbitrary = new ArbitraryType(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type(int v, ArbitraryType arb)
/*     */   {
/*  61 */     this.value = v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  70 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  80 */     if (o == this)
/*     */     {
/*  82 */       return true;
/*     */     }
/*     */     
/*  85 */     if (!(o instanceof Type))
/*     */     {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     Type t = (Type)o;
/*     */     
/*  92 */     return this.value == t.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(int v)
/*     */   {
/* 102 */     for (int i = 0; i < types.length; i++)
/*     */     {
/* 104 */       if (types[i].value == v)
/*     */       {
/* 106 */         return types[i];
/*     */       }
/*     */     }
/*     */     
/* 110 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type createType(int v)
/*     */   {
/* 120 */     return new Type(v, arbitrary);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 125 */   public static final Type BOF = new Type(2057);
/*     */   
/*     */ 
/* 128 */   public static final Type EOF = new Type(10);
/*     */   
/*     */ 
/* 131 */   public static final Type BOUNDSHEET = new Type(133);
/*     */   
/*     */ 
/* 134 */   public static final Type SUPBOOK = new Type(430);
/*     */   
/*     */ 
/* 137 */   public static final Type EXTERNSHEET = new Type(23);
/*     */   
/*     */ 
/* 140 */   public static final Type DIMENSION = new Type(512);
/*     */   
/*     */ 
/* 143 */   public static final Type BLANK = new Type(513);
/*     */   
/*     */ 
/* 146 */   public static final Type MULBLANK = new Type(190);
/*     */   
/*     */ 
/* 149 */   public static final Type ROW = new Type(520);
/*     */   
/*     */ 
/* 152 */   public static final Type NOTE = new Type(28);
/*     */   
/*     */ 
/* 155 */   public static final Type TXO = new Type(438);
/*     */   
/*     */ 
/* 158 */   public static final Type RK = new Type(126);
/*     */   
/*     */ 
/* 161 */   public static final Type RK2 = new Type(638);
/*     */   
/*     */ 
/* 164 */   public static final Type MULRK = new Type(189);
/*     */   
/*     */ 
/* 167 */   public static final Type INDEX = new Type(523);
/*     */   
/*     */ 
/* 170 */   public static final Type DBCELL = new Type(215);
/*     */   
/*     */ 
/* 173 */   public static final Type SST = new Type(252);
/*     */   
/*     */ 
/* 176 */   public static final Type COLINFO = new Type(125);
/*     */   
/*     */ 
/* 179 */   public static final Type EXTSST = new Type(255);
/*     */   
/*     */ 
/* 182 */   public static final Type CONTINUE = new Type(60);
/*     */   
/*     */ 
/* 185 */   public static final Type LABEL = new Type(516);
/*     */   
/*     */ 
/* 188 */   public static final Type RSTRING = new Type(214);
/*     */   
/*     */ 
/* 191 */   public static final Type LABELSST = new Type(253);
/*     */   
/*     */ 
/* 194 */   public static final Type NUMBER = new Type(515);
/*     */   
/*     */ 
/* 197 */   public static final Type NAME = new Type(24);
/*     */   
/*     */ 
/* 200 */   public static final Type TABID = new Type(317);
/*     */   
/*     */ 
/* 203 */   public static final Type ARRAY = new Type(545);
/*     */   
/*     */ 
/* 206 */   public static final Type STRING = new Type(519);
/*     */   
/*     */ 
/* 209 */   public static final Type FORMULA = new Type(1030);
/*     */   
/*     */ 
/* 212 */   public static final Type FORMULA2 = new Type(6);
/*     */   
/*     */ 
/* 215 */   public static final Type SHAREDFORMULA = new Type(1212);
/*     */   
/*     */ 
/* 218 */   public static final Type FORMAT = new Type(1054);
/*     */   
/*     */ 
/* 221 */   public static final Type XF = new Type(224);
/*     */   
/*     */ 
/* 224 */   public static final Type BOOLERR = new Type(517);
/*     */   
/*     */ 
/* 227 */   public static final Type INTERFACEHDR = new Type(225);
/*     */   
/*     */ 
/* 230 */   public static final Type SAVERECALC = new Type(95);
/*     */   
/*     */ 
/* 233 */   public static final Type INTERFACEEND = new Type(226);
/*     */   
/*     */ 
/* 236 */   public static final Type XCT = new Type(89);
/*     */   
/*     */ 
/* 239 */   public static final Type CRN = new Type(90);
/*     */   
/*     */ 
/* 242 */   public static final Type DEFCOLWIDTH = new Type(85);
/*     */   
/*     */ 
/* 245 */   public static final Type DEFAULTROWHEIGHT = new Type(549);
/*     */   
/*     */ 
/* 248 */   public static final Type WRITEACCESS = new Type(92);
/*     */   
/*     */ 
/* 251 */   public static final Type WSBOOL = new Type(129);
/*     */   
/*     */ 
/* 254 */   public static final Type CODEPAGE = new Type(66);
/*     */   
/*     */ 
/* 257 */   public static final Type DSF = new Type(353);
/*     */   
/*     */ 
/* 260 */   public static final Type FNGROUPCOUNT = new Type(156);
/*     */   
/*     */ 
/* 263 */   public static final Type FILTERMODE = new Type(155);
/*     */   
/*     */ 
/* 266 */   public static final Type AUTOFILTERINFO = new Type(157);
/*     */   
/*     */ 
/* 269 */   public static final Type AUTOFILTER = new Type(158);
/*     */   
/*     */ 
/* 272 */   public static final Type COUNTRY = new Type(140);
/*     */   
/*     */ 
/* 275 */   public static final Type PROTECT = new Type(18);
/*     */   
/*     */ 
/* 278 */   public static final Type SCENPROTECT = new Type(221);
/*     */   
/*     */ 
/* 281 */   public static final Type OBJPROTECT = new Type(99);
/*     */   
/*     */ 
/* 284 */   public static final Type PRINTHEADERS = new Type(42);
/*     */   
/*     */ 
/* 287 */   public static final Type HEADER = new Type(20);
/*     */   
/*     */ 
/* 290 */   public static final Type FOOTER = new Type(21);
/*     */   
/*     */ 
/* 293 */   public static final Type HCENTER = new Type(131);
/*     */   
/*     */ 
/* 296 */   public static final Type VCENTER = new Type(132);
/*     */   
/*     */ 
/* 299 */   public static final Type FILEPASS = new Type(47);
/*     */   
/*     */ 
/* 302 */   public static final Type SETUP = new Type(161);
/*     */   
/*     */ 
/* 305 */   public static final Type PRINTGRIDLINES = new Type(43);
/*     */   
/*     */ 
/* 308 */   public static final Type GRIDSET = new Type(130);
/*     */   
/*     */ 
/* 311 */   public static final Type GUTS = new Type(128);
/*     */   
/*     */ 
/* 314 */   public static final Type WINDOWPROTECT = new Type(25);
/*     */   
/*     */ 
/* 317 */   public static final Type PROT4REV = new Type(431);
/*     */   
/*     */ 
/* 320 */   public static final Type PROT4REVPASS = new Type(444);
/*     */   
/*     */ 
/* 323 */   public static final Type PASSWORD = new Type(19);
/*     */   
/*     */ 
/* 326 */   public static final Type REFRESHALL = new Type(439);
/*     */   
/*     */ 
/* 329 */   public static final Type WINDOW1 = new Type(61);
/*     */   
/*     */ 
/* 332 */   public static final Type WINDOW2 = new Type(574);
/*     */   
/*     */ 
/* 335 */   public static final Type BACKUP = new Type(64);
/*     */   
/*     */ 
/* 338 */   public static final Type HIDEOBJ = new Type(141);
/*     */   
/*     */ 
/* 341 */   public static final Type NINETEENFOUR = new Type(34);
/*     */   
/*     */ 
/* 344 */   public static final Type PRECISION = new Type(14);
/*     */   
/*     */ 
/* 347 */   public static final Type BOOKBOOL = new Type(218);
/*     */   
/*     */ 
/* 350 */   public static final Type FONT = new Type(49);
/*     */   
/*     */ 
/* 353 */   public static final Type MMS = new Type(193);
/*     */   
/*     */ 
/* 356 */   public static final Type CALCMODE = new Type(13);
/*     */   
/*     */ 
/* 359 */   public static final Type CALCCOUNT = new Type(12);
/*     */   
/*     */ 
/* 362 */   public static final Type REFMODE = new Type(15);
/*     */   
/*     */ 
/* 365 */   public static final Type TEMPLATE = new Type(96);
/*     */   
/*     */ 
/* 368 */   public static final Type OBJPROJ = new Type(211);
/*     */   
/*     */ 
/* 371 */   public static final Type DELTA = new Type(16);
/*     */   
/*     */ 
/* 374 */   public static final Type MERGEDCELLS = new Type(229);
/*     */   
/*     */ 
/* 377 */   public static final Type ITERATION = new Type(17);
/*     */   
/*     */ 
/* 380 */   public static final Type STYLE = new Type(659);
/*     */   
/*     */ 
/* 383 */   public static final Type USESELFS = new Type(352);
/*     */   
/*     */ 
/* 386 */   public static final Type VERTICALPAGEBREAKS = new Type(26);
/*     */   
/*     */ 
/* 389 */   public static final Type HORIZONTALPAGEBREAKS = new Type(27);
/*     */   
/*     */ 
/* 392 */   public static final Type SELECTION = new Type(29);
/*     */   
/*     */ 
/* 395 */   public static final Type HLINK = new Type(440);
/*     */   
/*     */ 
/* 398 */   public static final Type OBJ = new Type(93);
/*     */   
/*     */ 
/* 401 */   public static final Type MSODRAWING = new Type(236);
/*     */   
/*     */ 
/* 404 */   public static final Type MSODRAWINGGROUP = new Type(235);
/*     */   
/*     */ 
/* 407 */   public static final Type LEFTMARGIN = new Type(38);
/*     */   
/*     */ 
/* 410 */   public static final Type RIGHTMARGIN = new Type(39);
/*     */   
/*     */ 
/* 413 */   public static final Type TOPMARGIN = new Type(40);
/*     */   
/*     */ 
/* 416 */   public static final Type BOTTOMMARGIN = new Type(41);
/*     */   
/*     */ 
/* 419 */   public static final Type EXTERNNAME = new Type(35);
/*     */   
/*     */ 
/* 422 */   public static final Type PALETTE = new Type(146);
/*     */   
/*     */ 
/* 425 */   public static final Type PLS = new Type(77);
/*     */   
/*     */ 
/* 428 */   public static final Type SCL = new Type(160);
/*     */   
/*     */ 
/* 431 */   public static final Type PANE = new Type(65);
/*     */   
/*     */ 
/* 434 */   public static final Type WEIRD1 = new Type(239);
/*     */   
/*     */ 
/* 437 */   public static final Type SORT = new Type(144);
/*     */   
/*     */ 
/* 440 */   public static final Type CONDFMT = new Type(432);
/*     */   
/*     */ 
/* 443 */   public static final Type CF = new Type(433);
/*     */   
/*     */ 
/* 446 */   public static final Type DV = new Type(446);
/*     */   
/*     */ 
/* 449 */   public static final Type DVAL = new Type(434);
/*     */   
/*     */ 
/* 452 */   public static final Type BUTTONPROPERTYSET = new Type(442);
/*     */   
/*     */ 
/*     */ 
/* 456 */   public static final Type EXCEL9FILE = new Type(448);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 461 */   public static final Type FONTX = new Type(4134);
/*     */   
/*     */ 
/* 464 */   public static final Type IFMT = new Type(4174);
/*     */   
/*     */ 
/* 467 */   public static final Type FBI = new Type(4192);
/*     */   
/*     */ 
/* 470 */   public static final Type ALRUNS = new Type(4176);
/*     */   
/*     */ 
/* 473 */   public static final Type SERIES = new Type(4099);
/*     */   
/*     */ 
/* 476 */   public static final Type SERIESLIST = new Type(4118);
/*     */   
/*     */ 
/* 479 */   public static final Type SBASEREF = new Type(4168);
/*     */   
/*     */ 
/* 482 */   public static final Type UNKNOWN = new Type(65535);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 490 */   public static final Type U1C0 = new Type(448);
/* 491 */   public static final Type U1C1 = new Type(449);
/*     */   
/*     */   private static class ArbitraryType {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\Type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */