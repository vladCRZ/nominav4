package jxl.biff;

import jxl.Sheet;

public abstract interface WorkbookMethods
{
  public abstract Sheet getReadSheet(int paramInt);
  
  public abstract String getName(int paramInt)
    throws NameRangeException;
  
  public abstract int getNameIndex(String paramString);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\WorkbookMethods.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */