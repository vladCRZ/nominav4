/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspaceInformationRecord
/*     */   extends WritableRecordData
/*     */ {
/*  31 */   private static Logger logger = Logger.getLogger(WorkspaceInformationRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private int wsoptions;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean rowOutlines;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean columnOutlines;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean fitToPages;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int FIT_TO_PAGES = 256;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int SHOW_ROW_OUTLINE_SYMBOLS = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int SHOW_COLUMN_OUTLINE_SYMBOLS = 2048;
/*     */   
/*     */ 
/*     */   private static final int DEFAULT_OPTIONS = 1217;
/*     */   
/*     */ 
/*     */ 
/*     */   public WorkspaceInformationRecord(Record t)
/*     */   {
/*  68 */     super(t);
/*  69 */     byte[] data = getRecord().getData();
/*     */     
/*  71 */     this.wsoptions = IntegerHelper.getInt(data[0], data[1]);
/*  72 */     this.fitToPages = ((this.wsoptions | 0x100) != 0);
/*  73 */     this.rowOutlines = ((this.wsoptions | 0x400) != 0);
/*  74 */     this.columnOutlines = ((this.wsoptions | 0x800) != 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WorkspaceInformationRecord()
/*     */   {
/*  82 */     super(Type.WSBOOL);
/*  83 */     this.wsoptions = 1217;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFitToPages()
/*     */   {
/*  93 */     return this.fitToPages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFitToPages(boolean b)
/*     */   {
/* 103 */     this.fitToPages = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRowOutlines(boolean ro)
/*     */   {
/* 111 */     this.rowOutlines = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnOutlines(boolean ro)
/*     */   {
/* 119 */     this.rowOutlines = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 129 */     byte[] data = new byte[2];
/*     */     
/* 131 */     if (this.fitToPages)
/*     */     {
/* 133 */       this.wsoptions |= 0x100;
/*     */     }
/*     */     
/* 136 */     if (this.rowOutlines)
/*     */     {
/* 138 */       this.wsoptions |= 0x400;
/*     */     }
/*     */     
/* 141 */     if (this.columnOutlines)
/*     */     {
/* 143 */       this.wsoptions |= 0x800;
/*     */     }
/*     */     
/* 146 */     IntegerHelper.getTwoBytes(this.wsoptions, data, 0);
/*     */     
/* 148 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\WorkspaceInformationRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */