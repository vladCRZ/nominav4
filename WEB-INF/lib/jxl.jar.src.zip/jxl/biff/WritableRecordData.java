/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WritableRecordData
/*     */   extends RecordData
/*     */   implements ByteData
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(WritableRecordData.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final int maxRecordLength = 8228;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WritableRecordData(Type t)
/*     */   {
/*  49 */     super(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WritableRecordData(Record t)
/*     */   {
/*  59 */     super(t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final byte[] getBytes()
/*     */   {
/*  71 */     byte[] data = getData();
/*     */     
/*  73 */     int dataLength = data.length;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */     if (data.length > 8224)
/*     */     {
/*  81 */       dataLength = 8224;
/*  82 */       data = handleContinueRecords(data);
/*     */     }
/*     */     
/*  85 */     byte[] bytes = new byte[data.length + 4];
/*     */     
/*  87 */     System.arraycopy(data, 0, bytes, 4, data.length);
/*     */     
/*  89 */     IntegerHelper.getTwoBytes(getCode(), bytes, 0);
/*  90 */     IntegerHelper.getTwoBytes(dataLength, bytes, 2);
/*     */     
/*  92 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] handleContinueRecords(byte[] data)
/*     */   {
/* 104 */     int continuedData = data.length - 8224;
/* 105 */     int numContinueRecords = continuedData / 8224 + 1;
/*     */     
/*     */ 
/*     */ 
/* 109 */     byte[] newdata = new byte[data.length + numContinueRecords * 4];
/*     */     
/*     */ 
/*     */ 
/* 113 */     System.arraycopy(data, 0, newdata, 0, 8224);
/* 114 */     int oldarraypos = 8224;
/* 115 */     int newarraypos = 8224;
/*     */     
/*     */ 
/* 118 */     for (int i = 0; i < numContinueRecords; i++)
/*     */     {
/*     */ 
/* 121 */       int length = Math.min(data.length - oldarraypos, 8224);
/*     */       
/*     */ 
/* 124 */       IntegerHelper.getTwoBytes(Type.CONTINUE.value, newdata, newarraypos);
/* 125 */       IntegerHelper.getTwoBytes(length, newdata, newarraypos + 2);
/*     */       
/*     */ 
/* 128 */       System.arraycopy(data, oldarraypos, newdata, newarraypos + 4, length);
/*     */       
/*     */ 
/* 131 */       oldarraypos += length;
/* 132 */       newarraypos += length + 4;
/*     */     }
/*     */     
/* 135 */     return newdata;
/*     */   }
/*     */   
/*     */   protected abstract byte[] getData();
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\WritableRecordData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */