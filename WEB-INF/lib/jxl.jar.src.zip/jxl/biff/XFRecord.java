/*      */ package jxl.biff;
/*      */ 
/*      */ import java.text.DateFormat;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.DecimalFormatSymbols;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.Alignment;
/*      */ import jxl.format.Border;
/*      */ import jxl.format.BorderLineStyle;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.format.Colour;
/*      */ import jxl.format.Font;
/*      */ import jxl.format.Format;
/*      */ import jxl.format.Orientation;
/*      */ import jxl.format.Pattern;
/*      */ import jxl.format.VerticalAlignment;
/*      */ import jxl.read.biff.Record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XFRecord
/*      */   extends WritableRecordData
/*      */   implements CellFormat
/*      */ {
/*   53 */   private static Logger logger = Logger.getLogger(XFRecord.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int formatIndex;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int parentFormat;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private XFType xfFormatType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean date;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean number;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DateFormat dateFormat;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private NumberFormat numberFormat;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte usedAttributes;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int fontIndex;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean locked;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean hidden;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Alignment align;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private VerticalAlignment valign;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Orientation orientation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean wrap;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int indentation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean shrinkToFit;
/*      */   
/*      */ 
/*      */ 
/*      */   private BorderLineStyle leftBorder;
/*      */   
/*      */ 
/*      */ 
/*      */   private BorderLineStyle rightBorder;
/*      */   
/*      */ 
/*      */ 
/*      */   private BorderLineStyle topBorder;
/*      */   
/*      */ 
/*      */ 
/*      */   private BorderLineStyle bottomBorder;
/*      */   
/*      */ 
/*      */ 
/*      */   private Colour leftBorderColour;
/*      */   
/*      */ 
/*      */ 
/*      */   private Colour rightBorderColour;
/*      */   
/*      */ 
/*      */ 
/*      */   private Colour topBorderColour;
/*      */   
/*      */ 
/*      */ 
/*      */   private Colour bottomBorderColour;
/*      */   
/*      */ 
/*      */ 
/*      */   private Colour backgroundColour;
/*      */   
/*      */ 
/*      */ 
/*      */   private Pattern pattern;
/*      */   
/*      */ 
/*      */ 
/*      */   private int options;
/*      */   
/*      */ 
/*      */ 
/*      */   private int xfIndex;
/*      */   
/*      */ 
/*      */ 
/*      */   private FontRecord font;
/*      */   
/*      */ 
/*      */ 
/*      */   private DisplayFormat format;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean initialized;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean read;
/*      */   
/*      */ 
/*      */ 
/*      */   private Format excelFormat;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean formatInfoInitialized;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean copied;
/*      */   
/*      */ 
/*      */ 
/*      */   private FormattingRecords formattingRecords;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_FONT = 4;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_FORMAT = 8;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_ALIGNMENT = 16;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_BORDER = 32;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_BACKGROUND = 64;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_PROTECTION = 128;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int USE_DEFAULT_VALUE = 248;
/*      */   
/*      */ 
/*      */ 
/*  250 */   private static final int[] dateFormats = { 14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */   private static final DateFormat[] javaDateFormats = { SimpleDateFormat.getDateInstance(3), SimpleDateFormat.getDateInstance(2), new SimpleDateFormat("d-MMM"), new SimpleDateFormat("MMM-yy"), new SimpleDateFormat("h:mm a"), new SimpleDateFormat("h:mm:ss a"), new SimpleDateFormat("H:mm"), new SimpleDateFormat("H:mm:ss"), new SimpleDateFormat("M/d/yy H:mm"), new SimpleDateFormat("mm:ss"), new SimpleDateFormat("H:mm:ss"), new SimpleDateFormat("mm:ss.S") };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  284 */   private static int[] numberFormats = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 37, 38, 39, 40, 41, 42, 43, 44, 48 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  309 */   private static NumberFormat[] javaNumberFormats = { new DecimalFormat("0"), new DecimalFormat("0.00"), new DecimalFormat("#,##0"), new DecimalFormat("#,##0.00"), new DecimalFormat("$#,##0;($#,##0)"), new DecimalFormat("$#,##0;($#,##0)"), new DecimalFormat("$#,##0.00;($#,##0.00)"), new DecimalFormat("$#,##0.00;($#,##0.00)"), new DecimalFormat("0%"), new DecimalFormat("0.00%"), new DecimalFormat("0.00E00"), new DecimalFormat("#,##0;(#,##0)"), new DecimalFormat("#,##0;(#,##0)"), new DecimalFormat("#,##0.00;(#,##0.00)"), new DecimalFormat("#,##0.00;(#,##0.00)"), new DecimalFormat("#,##0;(#,##0)"), new DecimalFormat("$#,##0;($#,##0)"), new DecimalFormat("#,##0.00;(#,##0.00)"), new DecimalFormat("$#,##0.00;($#,##0.00)"), new DecimalFormat("##0.0E0") };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  334 */   public static final BiffType biff8 = new BiffType(null);
/*  335 */   public static final BiffType biff7 = new BiffType(null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private BiffType biffType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  346 */   protected static final XFType cell = new XFType(null);
/*  347 */   protected static final XFType style = new XFType(null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XFRecord(Record t, WorkbookSettings ws, BiffType bt)
/*      */   {
/*  357 */     super(t);
/*      */     
/*  359 */     this.biffType = bt;
/*      */     
/*  361 */     byte[] data = getRecord().getData();
/*      */     
/*  363 */     this.fontIndex = IntegerHelper.getInt(data[0], data[1]);
/*  364 */     this.formatIndex = IntegerHelper.getInt(data[2], data[3]);
/*  365 */     this.date = false;
/*  366 */     this.number = false;
/*      */     
/*      */ 
/*      */ 
/*  370 */     for (int i = 0; (i < dateFormats.length) && (!this.date); i++)
/*      */     {
/*  372 */       if (this.formatIndex == dateFormats[i])
/*      */       {
/*  374 */         this.date = true;
/*  375 */         this.dateFormat = javaDateFormats[i];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  380 */     for (int i = 0; (i < numberFormats.length) && (!this.number); i++)
/*      */     {
/*  382 */       if (this.formatIndex == numberFormats[i])
/*      */       {
/*  384 */         this.number = true;
/*  385 */         DecimalFormat df = (DecimalFormat)javaNumberFormats[i].clone();
/*  386 */         DecimalFormatSymbols symbols = new DecimalFormatSymbols(ws.getLocale());
/*      */         
/*  388 */         df.setDecimalFormatSymbols(symbols);
/*  389 */         this.numberFormat = df;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  395 */     int cellAttributes = IntegerHelper.getInt(data[4], data[5]);
/*  396 */     this.parentFormat = ((cellAttributes & 0xFFF0) >> 4);
/*      */     
/*  398 */     int formatType = cellAttributes & 0x4;
/*  399 */     this.xfFormatType = (formatType == 0 ? cell : style);
/*  400 */     this.locked = ((cellAttributes & 0x1) != 0);
/*  401 */     this.hidden = ((cellAttributes & 0x2) != 0);
/*      */     
/*  403 */     if ((this.xfFormatType == cell) && ((this.parentFormat & 0xFFF) == 4095))
/*      */     {
/*      */ 
/*      */ 
/*  407 */       this.parentFormat = 0;
/*  408 */       logger.warn("Invalid parent format found - ignoring");
/*      */     }
/*      */     
/*  411 */     this.initialized = false;
/*  412 */     this.read = true;
/*  413 */     this.formatInfoInitialized = false;
/*  414 */     this.copied = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public XFRecord(FontRecord fnt, DisplayFormat form)
/*      */   {
/*  425 */     super(Type.XF);
/*      */     
/*  427 */     this.initialized = false;
/*  428 */     this.locked = true;
/*  429 */     this.hidden = false;
/*  430 */     this.align = Alignment.GENERAL;
/*  431 */     this.valign = VerticalAlignment.BOTTOM;
/*  432 */     this.orientation = Orientation.HORIZONTAL;
/*  433 */     this.wrap = false;
/*  434 */     this.leftBorder = BorderLineStyle.NONE;
/*  435 */     this.rightBorder = BorderLineStyle.NONE;
/*  436 */     this.topBorder = BorderLineStyle.NONE;
/*  437 */     this.bottomBorder = BorderLineStyle.NONE;
/*  438 */     this.leftBorderColour = Colour.AUTOMATIC;
/*  439 */     this.rightBorderColour = Colour.AUTOMATIC;
/*  440 */     this.topBorderColour = Colour.AUTOMATIC;
/*  441 */     this.bottomBorderColour = Colour.AUTOMATIC;
/*  442 */     this.pattern = Pattern.NONE;
/*  443 */     this.backgroundColour = Colour.DEFAULT_BACKGROUND;
/*  444 */     this.indentation = 0;
/*  445 */     this.shrinkToFit = false;
/*  446 */     this.usedAttributes = 124;
/*      */     
/*      */ 
/*      */ 
/*  450 */     this.parentFormat = 0;
/*  451 */     this.xfFormatType = null;
/*      */     
/*  453 */     this.font = fnt;
/*  454 */     this.format = form;
/*  455 */     this.biffType = biff8;
/*  456 */     this.read = false;
/*  457 */     this.copied = false;
/*  458 */     this.formatInfoInitialized = true;
/*      */     
/*  460 */     Assert.verify(this.font != null);
/*  461 */     Assert.verify(this.format != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected XFRecord(XFRecord fmt)
/*      */   {
/*  472 */     super(Type.XF);
/*      */     
/*  474 */     this.initialized = false;
/*  475 */     this.locked = fmt.locked;
/*  476 */     this.hidden = fmt.hidden;
/*  477 */     this.align = fmt.align;
/*  478 */     this.valign = fmt.valign;
/*  479 */     this.orientation = fmt.orientation;
/*  480 */     this.wrap = fmt.wrap;
/*  481 */     this.leftBorder = fmt.leftBorder;
/*  482 */     this.rightBorder = fmt.rightBorder;
/*  483 */     this.topBorder = fmt.topBorder;
/*  484 */     this.bottomBorder = fmt.bottomBorder;
/*  485 */     this.leftBorderColour = fmt.leftBorderColour;
/*  486 */     this.rightBorderColour = fmt.rightBorderColour;
/*  487 */     this.topBorderColour = fmt.topBorderColour;
/*  488 */     this.bottomBorderColour = fmt.bottomBorderColour;
/*  489 */     this.pattern = fmt.pattern;
/*  490 */     this.xfFormatType = fmt.xfFormatType;
/*  491 */     this.indentation = fmt.indentation;
/*  492 */     this.shrinkToFit = fmt.shrinkToFit;
/*  493 */     this.parentFormat = fmt.parentFormat;
/*  494 */     this.backgroundColour = fmt.backgroundColour;
/*      */     
/*      */ 
/*  497 */     this.font = fmt.font;
/*  498 */     this.format = fmt.format;
/*      */     
/*  500 */     this.fontIndex = fmt.fontIndex;
/*  501 */     this.formatIndex = fmt.formatIndex;
/*      */     
/*  503 */     this.formatInfoInitialized = fmt.formatInfoInitialized;
/*      */     
/*  505 */     this.biffType = biff8;
/*  506 */     this.read = false;
/*  507 */     this.copied = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected XFRecord(CellFormat cellFormat)
/*      */   {
/*  519 */     super(Type.XF);
/*      */     
/*  521 */     Assert.verify(cellFormat != null);
/*  522 */     Assert.verify(cellFormat instanceof XFRecord);
/*  523 */     XFRecord fmt = (XFRecord)cellFormat;
/*      */     
/*  525 */     if (!fmt.formatInfoInitialized)
/*      */     {
/*  527 */       fmt.initializeFormatInformation();
/*      */     }
/*      */     
/*  530 */     this.locked = fmt.locked;
/*  531 */     this.hidden = fmt.hidden;
/*  532 */     this.align = fmt.align;
/*  533 */     this.valign = fmt.valign;
/*  534 */     this.orientation = fmt.orientation;
/*  535 */     this.wrap = fmt.wrap;
/*  536 */     this.leftBorder = fmt.leftBorder;
/*  537 */     this.rightBorder = fmt.rightBorder;
/*  538 */     this.topBorder = fmt.topBorder;
/*  539 */     this.bottomBorder = fmt.bottomBorder;
/*  540 */     this.leftBorderColour = fmt.leftBorderColour;
/*  541 */     this.rightBorderColour = fmt.rightBorderColour;
/*  542 */     this.topBorderColour = fmt.topBorderColour;
/*  543 */     this.bottomBorderColour = fmt.bottomBorderColour;
/*  544 */     this.pattern = fmt.pattern;
/*  545 */     this.xfFormatType = fmt.xfFormatType;
/*  546 */     this.parentFormat = fmt.parentFormat;
/*  547 */     this.indentation = fmt.indentation;
/*  548 */     this.shrinkToFit = fmt.shrinkToFit;
/*  549 */     this.backgroundColour = fmt.backgroundColour;
/*      */     
/*      */ 
/*  552 */     this.font = new FontRecord(fmt.getFont());
/*      */     
/*      */ 
/*  555 */     if (fmt.getFormat() == null)
/*      */     {
/*      */ 
/*  558 */       if (fmt.format.isBuiltIn())
/*      */       {
/*  560 */         this.format = fmt.format;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  565 */         this.format = new FormatRecord((FormatRecord)fmt.format);
/*      */       }
/*      */     }
/*  568 */     else if ((fmt.getFormat() instanceof BuiltInFormat))
/*      */     {
/*      */ 
/*  571 */       this.excelFormat = ((BuiltInFormat)fmt.excelFormat);
/*  572 */       this.format = ((BuiltInFormat)fmt.excelFormat);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  577 */       Assert.verify(fmt.formatInfoInitialized);
/*      */       
/*      */ 
/*      */ 
/*  581 */       Assert.verify(fmt.excelFormat instanceof FormatRecord);
/*      */       
/*      */ 
/*  584 */       FormatRecord fr = new FormatRecord((FormatRecord)fmt.excelFormat);
/*      */       
/*      */ 
/*      */ 
/*  588 */       this.excelFormat = fr;
/*  589 */       this.format = fr;
/*      */     }
/*      */     
/*  592 */     this.biffType = biff8;
/*      */     
/*      */ 
/*  595 */     this.formatInfoInitialized = true;
/*      */     
/*      */ 
/*  598 */     this.read = false;
/*      */     
/*      */ 
/*  601 */     this.copied = false;
/*      */     
/*      */ 
/*  604 */     this.initialized = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DateFormat getDateFormat()
/*      */   {
/*  614 */     return this.dateFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NumberFormat getNumberFormat()
/*      */   {
/*  624 */     return this.numberFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFormatRecord()
/*      */   {
/*  634 */     return this.formatIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDate()
/*      */   {
/*  644 */     return this.date;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNumber()
/*      */   {
/*  654 */     return this.number;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getData()
/*      */   {
/*  670 */     if (!this.formatInfoInitialized)
/*      */     {
/*  672 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  675 */     byte[] data = new byte[20];
/*      */     
/*  677 */     IntegerHelper.getTwoBytes(this.fontIndex, data, 0);
/*  678 */     IntegerHelper.getTwoBytes(this.formatIndex, data, 2);
/*      */     
/*      */ 
/*  681 */     int cellAttributes = 0;
/*      */     
/*  683 */     if (getLocked())
/*      */     {
/*  685 */       cellAttributes |= 0x1;
/*      */     }
/*      */     
/*  688 */     if (getHidden())
/*      */     {
/*  690 */       cellAttributes |= 0x2;
/*      */     }
/*      */     
/*  693 */     if (this.xfFormatType == style)
/*      */     {
/*  695 */       cellAttributes |= 0x4;
/*  696 */       this.parentFormat = 65535;
/*      */     }
/*      */     
/*  699 */     cellAttributes |= this.parentFormat << 4;
/*      */     
/*  701 */     IntegerHelper.getTwoBytes(cellAttributes, data, 4);
/*      */     
/*  703 */     int alignMask = this.align.getValue();
/*      */     
/*  705 */     if (this.wrap)
/*      */     {
/*  707 */       alignMask |= 0x8;
/*      */     }
/*      */     
/*  710 */     alignMask |= this.valign.getValue() << 4;
/*      */     
/*  712 */     alignMask |= this.orientation.getValue() << 8;
/*      */     
/*  714 */     IntegerHelper.getTwoBytes(alignMask, data, 6);
/*      */     
/*  716 */     data[9] = 16;
/*      */     
/*      */ 
/*  719 */     int borderMask = this.leftBorder.getValue();
/*  720 */     borderMask |= this.rightBorder.getValue() << 4;
/*  721 */     borderMask |= this.topBorder.getValue() << 8;
/*  722 */     borderMask |= this.bottomBorder.getValue() << 12;
/*      */     
/*  724 */     IntegerHelper.getTwoBytes(borderMask, data, 10);
/*      */     
/*      */ 
/*      */ 
/*  728 */     if (borderMask != 0)
/*      */     {
/*  730 */       byte lc = (byte)this.leftBorderColour.getValue();
/*  731 */       byte rc = (byte)this.rightBorderColour.getValue();
/*  732 */       byte tc = (byte)this.topBorderColour.getValue();
/*  733 */       byte bc = (byte)this.bottomBorderColour.getValue();
/*      */       
/*  735 */       int sideColourMask = lc & 0x7F | (rc & 0x7F) << 7;
/*  736 */       int topColourMask = tc & 0x7F | (bc & 0x7F) << 7;
/*      */       
/*  738 */       IntegerHelper.getTwoBytes(sideColourMask, data, 12);
/*  739 */       IntegerHelper.getTwoBytes(topColourMask, data, 14);
/*      */     }
/*      */     
/*      */ 
/*  743 */     int patternVal = this.pattern.getValue() << 10;
/*  744 */     IntegerHelper.getTwoBytes(patternVal, data, 16);
/*      */     
/*      */ 
/*  747 */     int colourPaletteMask = this.backgroundColour.getValue();
/*  748 */     colourPaletteMask |= 0x2000;
/*  749 */     IntegerHelper.getTwoBytes(colourPaletteMask, data, 18);
/*      */     
/*      */ 
/*  752 */     this.options |= this.indentation & 0xF;
/*      */     
/*  754 */     if (this.shrinkToFit)
/*      */     {
/*  756 */       this.options |= 0x10;
/*      */     }
/*      */     else
/*      */     {
/*  760 */       this.options &= 0xEF;
/*      */     }
/*      */     
/*  763 */     data[8] = ((byte)this.options);
/*      */     
/*  765 */     if (this.biffType == biff8)
/*      */     {
/*  767 */       data[9] = this.usedAttributes;
/*      */     }
/*      */     
/*  770 */     return data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean getLocked()
/*      */   {
/*  780 */     return this.locked;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean getHidden()
/*      */   {
/*  790 */     return this.hidden;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void setXFLocked(boolean l)
/*      */   {
/*  800 */     this.locked = l;
/*  801 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x80));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void setXFCellOptions(int opt)
/*      */   {
/*  811 */     this.options |= opt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFAlignment(Alignment a)
/*      */   {
/*  823 */     Assert.verify(!this.initialized);
/*  824 */     this.align = a;
/*  825 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x10));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFIndentation(int i)
/*      */   {
/*  835 */     Assert.verify(!this.initialized);
/*  836 */     this.indentation = i;
/*  837 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x10));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFShrinkToFit(boolean s)
/*      */   {
/*  847 */     Assert.verify(!this.initialized);
/*  848 */     this.shrinkToFit = s;
/*  849 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x10));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Alignment getAlignment()
/*      */   {
/*  859 */     if (!this.formatInfoInitialized)
/*      */     {
/*  861 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  864 */     return this.align;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIndentation()
/*      */   {
/*  874 */     if (!this.formatInfoInitialized)
/*      */     {
/*  876 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  879 */     return this.indentation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isShrinkToFit()
/*      */   {
/*  889 */     if (!this.formatInfoInitialized)
/*      */     {
/*  891 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  894 */     return this.shrinkToFit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLocked()
/*      */   {
/*  904 */     if (!this.formatInfoInitialized)
/*      */     {
/*  906 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  909 */     return this.locked;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public VerticalAlignment getVerticalAlignment()
/*      */   {
/*  920 */     if (!this.formatInfoInitialized)
/*      */     {
/*  922 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  925 */     return this.valign;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Orientation getOrientation()
/*      */   {
/*  935 */     if (!this.formatInfoInitialized)
/*      */     {
/*  937 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  940 */     return this.orientation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFBackground(Colour c, Pattern p)
/*      */   {
/*  953 */     Assert.verify(!this.initialized);
/*  954 */     this.backgroundColour = c;
/*  955 */     this.pattern = p;
/*  956 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x40));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Colour getBackgroundColour()
/*      */   {
/*  966 */     if (!this.formatInfoInitialized)
/*      */     {
/*  968 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  971 */     return this.backgroundColour;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Pattern getPattern()
/*      */   {
/*  981 */     if (!this.formatInfoInitialized)
/*      */     {
/*  983 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  986 */     return this.pattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFVerticalAlignment(VerticalAlignment va)
/*      */   {
/*  999 */     Assert.verify(!this.initialized);
/* 1000 */     this.valign = va;
/* 1001 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x10));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFOrientation(Orientation o)
/*      */   {
/* 1014 */     Assert.verify(!this.initialized);
/* 1015 */     this.orientation = o;
/* 1016 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x10));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFWrap(boolean w)
/*      */   {
/* 1028 */     Assert.verify(!this.initialized);
/* 1029 */     this.wrap = w;
/* 1030 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x10));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getWrap()
/*      */   {
/* 1040 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1042 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1045 */     return this.wrap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFBorder(Border b, BorderLineStyle ls, Colour c)
/*      */   {
/* 1058 */     Assert.verify(!this.initialized);
/*      */     
/* 1060 */     if ((c == Colour.BLACK) || (c == Colour.UNKNOWN))
/*      */     {
/* 1062 */       c = Colour.PALETTE_BLACK;
/*      */     }
/*      */     
/* 1065 */     if (b == Border.LEFT)
/*      */     {
/* 1067 */       this.leftBorder = ls;
/* 1068 */       this.leftBorderColour = c;
/*      */     }
/* 1070 */     else if (b == Border.RIGHT)
/*      */     {
/* 1072 */       this.rightBorder = ls;
/* 1073 */       this.rightBorderColour = c;
/*      */     }
/* 1075 */     else if (b == Border.TOP)
/*      */     {
/* 1077 */       this.topBorder = ls;
/* 1078 */       this.topBorderColour = c;
/*      */     }
/* 1080 */     else if (b == Border.BOTTOM)
/*      */     {
/* 1082 */       this.bottomBorder = ls;
/* 1083 */       this.bottomBorderColour = c;
/*      */     }
/*      */     
/* 1086 */     this.usedAttributes = ((byte)(this.usedAttributes | 0x20));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BorderLineStyle getBorder(Border border)
/*      */   {
/* 1102 */     return getBorderLine(border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BorderLineStyle getBorderLine(Border border)
/*      */   {
/* 1116 */     if ((border == Border.NONE) || (border == Border.ALL))
/*      */     {
/*      */ 
/* 1119 */       return BorderLineStyle.NONE;
/*      */     }
/*      */     
/* 1122 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1124 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1127 */     if (border == Border.LEFT)
/*      */     {
/* 1129 */       return this.leftBorder;
/*      */     }
/* 1131 */     if (border == Border.RIGHT)
/*      */     {
/* 1133 */       return this.rightBorder;
/*      */     }
/* 1135 */     if (border == Border.TOP)
/*      */     {
/* 1137 */       return this.topBorder;
/*      */     }
/* 1139 */     if (border == Border.BOTTOM)
/*      */     {
/* 1141 */       return this.bottomBorder;
/*      */     }
/*      */     
/* 1144 */     return BorderLineStyle.NONE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Colour getBorderColour(Border border)
/*      */   {
/* 1158 */     if ((border == Border.NONE) || (border == Border.ALL))
/*      */     {
/*      */ 
/* 1161 */       return Colour.PALETTE_BLACK;
/*      */     }
/*      */     
/* 1164 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1166 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1169 */     if (border == Border.LEFT)
/*      */     {
/* 1171 */       return this.leftBorderColour;
/*      */     }
/* 1173 */     if (border == Border.RIGHT)
/*      */     {
/* 1175 */       return this.rightBorderColour;
/*      */     }
/* 1177 */     if (border == Border.TOP)
/*      */     {
/* 1179 */       return this.topBorderColour;
/*      */     }
/* 1181 */     if (border == Border.BOTTOM)
/*      */     {
/* 1183 */       return this.bottomBorderColour;
/*      */     }
/*      */     
/* 1186 */     return Colour.BLACK;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean hasBorders()
/*      */   {
/* 1198 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1200 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1203 */     if ((this.leftBorder == BorderLineStyle.NONE) && (this.rightBorder == BorderLineStyle.NONE) && (this.topBorder == BorderLineStyle.NONE) && (this.bottomBorder == BorderLineStyle.NONE))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1208 */       return false;
/*      */     }
/*      */     
/* 1211 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void initialize(int pos, FormattingRecords fr, Fonts fonts)
/*      */     throws NumFormatRecordsException
/*      */   {
/* 1227 */     this.xfIndex = pos;
/* 1228 */     this.formattingRecords = fr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1234 */     if ((this.read) || (this.copied))
/*      */     {
/* 1236 */       this.initialized = true;
/* 1237 */       return;
/*      */     }
/*      */     
/* 1240 */     if (!this.font.isInitialized())
/*      */     {
/* 1242 */       fonts.addFont(this.font);
/*      */     }
/*      */     
/* 1245 */     if (!this.format.isInitialized())
/*      */     {
/* 1247 */       fr.addFormat(this.format);
/*      */     }
/*      */     
/* 1250 */     this.fontIndex = this.font.getFontIndex();
/* 1251 */     this.formatIndex = this.format.getFormatIndex();
/*      */     
/* 1253 */     this.initialized = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void uninitialize()
/*      */   {
/* 1264 */     if (this.initialized == true)
/*      */     {
/* 1266 */       logger.warn("A default format has been initialized");
/*      */     }
/* 1268 */     this.initialized = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void setXFIndex(int xfi)
/*      */   {
/* 1279 */     this.xfIndex = xfi;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int getXFIndex()
/*      */   {
/* 1289 */     return this.xfIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isInitialized()
/*      */   {
/* 1299 */     return this.initialized;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isRead()
/*      */   {
/* 1311 */     return this.read;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Format getFormat()
/*      */   {
/* 1321 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1323 */       initializeFormatInformation();
/*      */     }
/* 1325 */     return this.excelFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont()
/*      */   {
/* 1335 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1337 */       initializeFormatInformation();
/*      */     }
/* 1339 */     return this.font;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializeFormatInformation()
/*      */   {
/* 1348 */     if ((this.formatIndex < BuiltInFormat.builtIns.length) && (BuiltInFormat.builtIns[this.formatIndex] != null))
/*      */     {
/*      */ 
/* 1351 */       this.excelFormat = BuiltInFormat.builtIns[this.formatIndex];
/*      */     }
/*      */     else
/*      */     {
/* 1355 */       this.excelFormat = this.formattingRecords.getFormatRecord(this.formatIndex);
/*      */     }
/*      */     
/*      */ 
/* 1359 */     this.font = this.formattingRecords.getFonts().getFont(this.fontIndex);
/*      */     
/*      */ 
/* 1362 */     byte[] data = getRecord().getData();
/*      */     
/*      */ 
/* 1365 */     int cellAttributes = IntegerHelper.getInt(data[4], data[5]);
/* 1366 */     this.parentFormat = ((cellAttributes & 0xFFF0) >> 4);
/* 1367 */     int formatType = cellAttributes & 0x4;
/* 1368 */     this.xfFormatType = (formatType == 0 ? cell : style);
/* 1369 */     this.locked = ((cellAttributes & 0x1) != 0);
/* 1370 */     this.hidden = ((cellAttributes & 0x2) != 0);
/*      */     
/* 1372 */     if ((this.xfFormatType == cell) && ((this.parentFormat & 0xFFF) == 4095))
/*      */     {
/*      */ 
/*      */ 
/* 1376 */       this.parentFormat = 0;
/* 1377 */       logger.warn("Invalid parent format found - ignoring");
/*      */     }
/*      */     
/*      */ 
/* 1381 */     int alignMask = IntegerHelper.getInt(data[6], data[7]);
/*      */     
/*      */ 
/* 1384 */     if ((alignMask & 0x8) != 0)
/*      */     {
/* 1386 */       this.wrap = true;
/*      */     }
/*      */     
/*      */ 
/* 1390 */     this.align = Alignment.getAlignment(alignMask & 0x7);
/*      */     
/*      */ 
/* 1393 */     this.valign = VerticalAlignment.getAlignment(alignMask >> 4 & 0x7);
/*      */     
/*      */ 
/* 1396 */     this.orientation = Orientation.getOrientation(alignMask >> 8 & 0xFF);
/*      */     
/* 1398 */     int attr = IntegerHelper.getInt(data[8], data[9]);
/*      */     
/*      */ 
/* 1401 */     this.indentation = (attr & 0xF);
/*      */     
/*      */ 
/* 1404 */     this.shrinkToFit = ((attr & 0x10) != 0);
/*      */     
/*      */ 
/* 1407 */     if (this.biffType == biff8)
/*      */     {
/* 1409 */       this.usedAttributes = data[9];
/*      */     }
/*      */     
/*      */ 
/* 1413 */     int borderMask = IntegerHelper.getInt(data[10], data[11]);
/*      */     
/* 1415 */     this.leftBorder = BorderLineStyle.getStyle(borderMask & 0x7);
/* 1416 */     this.rightBorder = BorderLineStyle.getStyle(borderMask >> 4 & 0x7);
/* 1417 */     this.topBorder = BorderLineStyle.getStyle(borderMask >> 8 & 0x7);
/* 1418 */     this.bottomBorder = BorderLineStyle.getStyle(borderMask >> 12 & 0x7);
/*      */     
/* 1420 */     int borderColourMask = IntegerHelper.getInt(data[12], data[13]);
/*      */     
/* 1422 */     this.leftBorderColour = Colour.getInternalColour(borderColourMask & 0x7F);
/* 1423 */     this.rightBorderColour = Colour.getInternalColour((borderColourMask & 0x3F80) >> 7);
/*      */     
/*      */ 
/* 1426 */     borderColourMask = IntegerHelper.getInt(data[14], data[15]);
/* 1427 */     this.topBorderColour = Colour.getInternalColour(borderColourMask & 0x7F);
/* 1428 */     this.bottomBorderColour = Colour.getInternalColour((borderColourMask & 0x3F80) >> 7);
/*      */     
/*      */ 
/* 1431 */     if (this.biffType == biff8)
/*      */     {
/*      */ 
/* 1434 */       int patternVal = IntegerHelper.getInt(data[16], data[17]);
/* 1435 */       patternVal &= 0xFC00;
/* 1436 */       patternVal >>= 10;
/* 1437 */       this.pattern = Pattern.getPattern(patternVal);
/*      */       
/*      */ 
/* 1440 */       int colourPaletteMask = IntegerHelper.getInt(data[18], data[19]);
/* 1441 */       this.backgroundColour = Colour.getInternalColour(colourPaletteMask & 0x3F);
/*      */       
/* 1443 */       if ((this.backgroundColour == Colour.UNKNOWN) || (this.backgroundColour == Colour.DEFAULT_BACKGROUND1))
/*      */       {
/*      */ 
/* 1446 */         this.backgroundColour = Colour.DEFAULT_BACKGROUND;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1451 */       this.pattern = Pattern.NONE;
/* 1452 */       this.backgroundColour = Colour.DEFAULT_BACKGROUND;
/*      */     }
/*      */     
/*      */ 
/* 1456 */     this.formatInfoInitialized = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1466 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1468 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1471 */     int hashValue = 17;
/* 1472 */     int oddPrimeNumber = 37;
/*      */     
/*      */ 
/* 1475 */     hashValue = oddPrimeNumber * hashValue + (this.hidden ? 1 : 0);
/* 1476 */     hashValue = oddPrimeNumber * hashValue + (this.locked ? 1 : 0);
/* 1477 */     hashValue = oddPrimeNumber * hashValue + (this.wrap ? 1 : 0);
/* 1478 */     hashValue = oddPrimeNumber * hashValue + (this.shrinkToFit ? 1 : 0);
/*      */     
/*      */ 
/* 1481 */     if (this.xfFormatType == cell)
/*      */     {
/* 1483 */       hashValue = oddPrimeNumber * hashValue + 1;
/*      */     }
/* 1485 */     else if (this.xfFormatType == style)
/*      */     {
/* 1487 */       hashValue = oddPrimeNumber * hashValue + 2;
/*      */     }
/*      */     
/* 1490 */     hashValue = oddPrimeNumber * hashValue + (this.align.getValue() + 1);
/* 1491 */     hashValue = oddPrimeNumber * hashValue + (this.valign.getValue() + 1);
/* 1492 */     hashValue = oddPrimeNumber * hashValue + this.orientation.getValue();
/*      */     
/* 1494 */     hashValue ^= this.leftBorder.getDescription().hashCode();
/* 1495 */     hashValue ^= this.rightBorder.getDescription().hashCode();
/* 1496 */     hashValue ^= this.topBorder.getDescription().hashCode();
/* 1497 */     hashValue ^= this.bottomBorder.getDescription().hashCode();
/*      */     
/* 1499 */     hashValue = oddPrimeNumber * hashValue + this.leftBorderColour.getValue();
/* 1500 */     hashValue = oddPrimeNumber * hashValue + this.rightBorderColour.getValue();
/* 1501 */     hashValue = oddPrimeNumber * hashValue + this.topBorderColour.getValue();
/* 1502 */     hashValue = oddPrimeNumber * hashValue + this.bottomBorderColour.getValue();
/* 1503 */     hashValue = oddPrimeNumber * hashValue + this.backgroundColour.getValue();
/* 1504 */     hashValue = oddPrimeNumber * hashValue + (this.pattern.getValue() + 1);
/*      */     
/*      */ 
/* 1507 */     hashValue = oddPrimeNumber * hashValue + this.usedAttributes;
/* 1508 */     hashValue = oddPrimeNumber * hashValue + this.parentFormat;
/* 1509 */     hashValue = oddPrimeNumber * hashValue + this.fontIndex;
/* 1510 */     hashValue = oddPrimeNumber * hashValue + this.formatIndex;
/* 1511 */     hashValue = oddPrimeNumber * hashValue + this.indentation;
/*      */     
/* 1513 */     return hashValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1525 */     if (o == this)
/*      */     {
/* 1527 */       return true;
/*      */     }
/*      */     
/* 1530 */     if (!(o instanceof XFRecord))
/*      */     {
/* 1532 */       return false;
/*      */     }
/*      */     
/* 1535 */     XFRecord xfr = (XFRecord)o;
/*      */     
/*      */ 
/* 1538 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1540 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1543 */     if (!xfr.formatInfoInitialized)
/*      */     {
/* 1545 */       xfr.initializeFormatInformation();
/*      */     }
/*      */     
/* 1548 */     if ((this.xfFormatType != xfr.xfFormatType) || (this.parentFormat != xfr.parentFormat) || (this.locked != xfr.locked) || (this.hidden != xfr.hidden) || (this.usedAttributes != xfr.usedAttributes))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1554 */       return false;
/*      */     }
/*      */     
/* 1557 */     if ((this.align != xfr.align) || (this.valign != xfr.valign) || (this.orientation != xfr.orientation) || (this.wrap != xfr.wrap) || (this.shrinkToFit != xfr.shrinkToFit) || (this.indentation != xfr.indentation))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1564 */       return false;
/*      */     }
/*      */     
/* 1567 */     if ((this.leftBorder != xfr.leftBorder) || (this.rightBorder != xfr.rightBorder) || (this.topBorder != xfr.topBorder) || (this.bottomBorder != xfr.bottomBorder))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1572 */       return false;
/*      */     }
/*      */     
/* 1575 */     if ((this.leftBorderColour != xfr.leftBorderColour) || (this.rightBorderColour != xfr.rightBorderColour) || (this.topBorderColour != xfr.topBorderColour) || (this.bottomBorderColour != xfr.bottomBorderColour))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1580 */       return false;
/*      */     }
/*      */     
/* 1583 */     if ((this.backgroundColour != xfr.backgroundColour) || (this.pattern != xfr.pattern))
/*      */     {
/*      */ 
/* 1586 */       return false;
/*      */     }
/*      */     
/* 1589 */     if ((this.initialized) && (xfr.initialized))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1596 */       if ((this.fontIndex != xfr.fontIndex) || (this.formatIndex != xfr.formatIndex))
/*      */       {
/*      */ 
/* 1599 */         return false;
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1605 */     else if ((!this.font.equals(xfr.font)) || (!this.format.equals(xfr.format)))
/*      */     {
/*      */ 
/* 1608 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1612 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setFormatIndex(int newindex)
/*      */   {
/* 1622 */     this.formatIndex = newindex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFontIndex()
/*      */   {
/* 1632 */     return this.fontIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setFontIndex(int newindex)
/*      */   {
/* 1643 */     this.fontIndex = newindex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setXFDetails(XFType t, int pf)
/*      */   {
/* 1653 */     this.xfFormatType = t;
/* 1654 */     this.parentFormat = pf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void rationalize(IndexMapping xfMapping)
/*      */   {
/* 1663 */     this.xfIndex = xfMapping.getNewIndex(this.xfIndex);
/*      */     
/* 1665 */     if (this.xfFormatType == cell)
/*      */     {
/* 1667 */       this.parentFormat = xfMapping.getNewIndex(this.parentFormat);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(FontRecord f)
/*      */   {
/* 1684 */     this.font = f;
/*      */   }
/*      */   
/*      */   private static class XFType {}
/*      */   
/*      */   private static class BiffType {}
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\XFRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */