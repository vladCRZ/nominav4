/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BStoreContainer
/*    */   extends EscherContainer
/*    */ {
/* 32 */   private static Logger logger = Logger.getLogger(BStoreContainer.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int numBlips;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BStoreContainer(EscherRecordData erd)
/*    */   {
/* 47 */     super(erd);
/* 48 */     this.numBlips = getInstance();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public BStoreContainer()
/*    */   {
/* 56 */     super(EscherRecordType.BSTORE_CONTAINER);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   void setNumBlips(int count)
/*    */   {
/* 66 */     this.numBlips = count;
/* 67 */     setInstance(this.numBlips);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getNumBlips()
/*    */   {
/* 77 */     return this.numBlips;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BlipStoreEntry getDrawing(int i)
/*    */   {
/* 88 */     EscherRecord[] children = getChildren();
/* 89 */     BlipStoreEntry bse = (BlipStoreEntry)children[i];
/* 90 */     return bse;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\BStoreContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */