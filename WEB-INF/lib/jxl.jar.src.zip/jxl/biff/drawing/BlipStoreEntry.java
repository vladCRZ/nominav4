/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BlipStoreEntry
/*     */   extends EscherAtom
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(BlipStoreEntry.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BlipType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int imageDataLength;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean write;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int IMAGE_DATA_OFFSET = 61;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BlipStoreEntry(EscherRecordData erd)
/*     */   {
/*  77 */     super(erd);
/*  78 */     this.type = BlipType.getType(getInstance());
/*  79 */     this.write = false;
/*  80 */     byte[] bytes = getBytes();
/*  81 */     this.referenceCount = IntegerHelper.getInt(bytes[24], bytes[25], bytes[26], bytes[27]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BlipStoreEntry(Drawing d)
/*     */     throws IOException
/*     */   {
/*  93 */     super(EscherRecordType.BSE);
/*  94 */     this.type = BlipType.PNG;
/*  95 */     setVersion(2);
/*  96 */     setInstance(this.type.getValue());
/*     */     
/*  98 */     byte[] imageData = d.getImageBytes();
/*  99 */     this.imageDataLength = imageData.length;
/* 100 */     this.data = new byte[this.imageDataLength + 61];
/* 101 */     System.arraycopy(imageData, 0, this.data, 61, this.imageDataLength);
/* 102 */     this.referenceCount = d.getReferenceCount();
/* 103 */     this.write = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BlipType getBlipType()
/*     */   {
/* 113 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 123 */     if (this.write)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 128 */       this.data[0] = ((byte)this.type.getValue());
/*     */       
/*     */ 
/* 131 */       this.data[1] = ((byte)this.type.getValue());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */       IntegerHelper.getFourBytes(this.imageDataLength + 8 + 17, this.data, 20);
/*     */       
/*     */ 
/* 143 */       IntegerHelper.getFourBytes(this.referenceCount, this.data, 24);
/*     */       
/*     */ 
/* 146 */       IntegerHelper.getFourBytes(0, this.data, 28);
/*     */       
/*     */ 
/* 149 */       this.data[32] = 0;
/*     */       
/*     */ 
/* 152 */       this.data[33] = 0;
/*     */       
/*     */ 
/* 155 */       this.data[34] = 126;
/* 156 */       this.data[35] = 1;
/*     */       
/*     */ 
/* 159 */       this.data[36] = 0;
/* 160 */       this.data[37] = 110;
/*     */       
/*     */ 
/* 163 */       IntegerHelper.getTwoBytes(61470, this.data, 38);
/*     */       
/*     */ 
/*     */ 
/* 167 */       IntegerHelper.getFourBytes(this.imageDataLength + 17, this.data, 40);
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 175 */       this.data = getBytes();
/*     */     }
/*     */     
/* 178 */     return setHeaderData(this.data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void dereference()
/*     */   {
/* 187 */     this.referenceCount -= 1;
/* 188 */     Assert.verify(this.referenceCount >= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getReferenceCount()
/*     */   {
/* 198 */     return this.referenceCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getImageData()
/*     */   {
/* 208 */     byte[] allData = getBytes();
/* 209 */     byte[] imageData = new byte[allData.length - 61];
/* 210 */     System.arraycopy(allData, 61, imageData, 0, imageData.length);
/*     */     
/* 212 */     return imageData;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\BlipStoreEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */