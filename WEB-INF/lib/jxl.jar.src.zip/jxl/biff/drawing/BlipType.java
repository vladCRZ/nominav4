/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BlipType
/*     */ {
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String desc;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private static BlipType[] types = new BlipType[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BlipType(int val, String d)
/*     */   {
/*  50 */     this.value = val;
/*  51 */     this.desc = d;
/*     */     
/*  53 */     BlipType[] newtypes = new BlipType[types.length + 1];
/*  54 */     System.arraycopy(types, 0, newtypes, 0, types.length);
/*  55 */     newtypes[types.length] = this;
/*  56 */     types = newtypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  66 */     return this.desc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  76 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BlipType getType(int val)
/*     */   {
/*  87 */     BlipType type = UNKNOWN;
/*  88 */     for (int i = 0; i < types.length; i++)
/*     */     {
/*  90 */       if (types[i].value == val)
/*     */       {
/*  92 */         type = types[i];
/*  93 */         break;
/*     */       }
/*     */     }
/*     */     
/*  97 */     return type;
/*     */   }
/*     */   
/* 100 */   public static final BlipType ERROR = new BlipType(0, "Error");
/*     */   
/* 102 */   public static final BlipType UNKNOWN = new BlipType(1, "Unknown");
/*     */   
/* 104 */   public static final BlipType EMF = new BlipType(2, "EMF");
/*     */   
/* 106 */   public static final BlipType WMF = new BlipType(3, "WMF");
/*     */   
/* 108 */   public static final BlipType PICT = new BlipType(4, "PICT");
/*     */   
/* 110 */   public static final BlipType JPEG = new BlipType(5, "JPEG");
/* 111 */   public static final BlipType PNG = new BlipType(6, "PNG");
/* 112 */   public static final BlipType DIB = new BlipType(7, "DIB");
/* 113 */   public static final BlipType FIRST_CLIENT = new BlipType(32, "FIRST");
/*     */   
/* 115 */   public static final BlipType LAST_CLIENT = new BlipType(255, "LAST");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\BlipType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */