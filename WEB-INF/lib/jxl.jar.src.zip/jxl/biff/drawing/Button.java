/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ContinueRecord;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Button
/*     */   implements DrawingGroupObject
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(Button.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer readSpContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer spContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord objRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private boolean initialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int blipId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double width;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double height;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer escherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Origin origin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingGroup drawingGroup;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingData drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ShapeType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord mso;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TextObjectRecord txo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContinueRecord text;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContinueRecord formatting;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String commentText;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button(MsoDrawingRecord msodr, ObjRecord obj, DrawingData dd, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 184 */     this.drawingGroup = dg;
/* 185 */     this.msoDrawingRecord = msodr;
/* 186 */     this.drawingData = dd;
/* 187 */     this.objRecord = obj;
/* 188 */     this.initialized = false;
/* 189 */     this.workbookSettings = ws;
/* 190 */     this.origin = Origin.READ;
/* 191 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 192 */     this.drawingNumber = (this.drawingData.getNumDrawings() - 1);
/* 193 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 195 */     Assert.verify((this.msoDrawingRecord != null) && (this.objRecord != null));
/*     */     
/* 197 */     initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button(DrawingGroupObject dgo, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 211 */     Button d = (Button)dgo;
/* 212 */     Assert.verify(d.origin == Origin.READ);
/* 213 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 214 */     this.objRecord = d.objRecord;
/* 215 */     this.initialized = false;
/* 216 */     this.origin = Origin.READ;
/* 217 */     this.drawingData = d.drawingData;
/* 218 */     this.drawingGroup = dg;
/* 219 */     this.drawingNumber = d.drawingNumber;
/* 220 */     this.drawingGroup.addDrawing(this);
/* 221 */     this.mso = d.mso;
/* 222 */     this.txo = d.txo;
/* 223 */     this.text = d.text;
/* 224 */     this.formatting = d.formatting;
/* 225 */     this.workbookSettings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 233 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 234 */     Assert.verify(this.readSpContainer != null);
/*     */     
/* 236 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 238 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 239 */     this.objectId = this.objRecord.getObjectId();
/* 240 */     this.shapeId = sp.getShapeId();
/* 241 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 243 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 245 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 248 */     ClientAnchor clientAnchor = null;
/* 249 */     for (int i = 0; (i < children.length) && (clientAnchor == null); i++)
/*     */     {
/* 251 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 253 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     }
/*     */     
/* 257 */     if (clientAnchor == null)
/*     */     {
/* 259 */       logger.warn("Client anchor not found");
/*     */     }
/*     */     else
/*     */     {
/* 263 */       this.column = ((int)clientAnchor.getX1() - 1);
/* 264 */       this.row = ((int)clientAnchor.getY1() + 1);
/*     */     }
/*     */     
/* 267 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setObjectId(int objid, int bip, int sid)
/*     */   {
/* 281 */     this.objectId = objid;
/* 282 */     this.blipId = bip;
/* 283 */     this.shapeId = sid;
/*     */     
/* 285 */     if (this.origin == Origin.READ)
/*     */     {
/* 287 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getObjectId()
/*     */   {
/* 298 */     if (!this.initialized)
/*     */     {
/* 300 */       initialize();
/*     */     }
/*     */     
/* 303 */     return this.objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getShapeId()
/*     */   {
/* 313 */     if (!this.initialized)
/*     */     {
/* 315 */       initialize();
/*     */     }
/*     */     
/* 318 */     return this.shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getBlipId()
/*     */   {
/* 328 */     if (!this.initialized)
/*     */     {
/* 330 */       initialize();
/*     */     }
/*     */     
/* 333 */     return this.blipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MsoDrawingRecord getMsoDrawingRecord()
/*     */   {
/* 343 */     return this.msoDrawingRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainer getSpContainer()
/*     */   {
/* 353 */     if (!this.initialized)
/*     */     {
/* 355 */       initialize();
/*     */     }
/*     */     
/* 358 */     if (this.origin == Origin.READ)
/*     */     {
/* 360 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 363 */     Assert.verify(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 392 */     return this.spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingGroup(DrawingGroup dg)
/*     */   {
/* 403 */     this.drawingGroup = dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup getDrawingGroup()
/*     */   {
/* 413 */     return this.drawingGroup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Origin getOrigin()
/*     */   {
/* 423 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReferenceCount()
/*     */   {
/* 433 */     return this.referenceCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReferenceCount(int r)
/*     */   {
/* 443 */     this.referenceCount = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getX()
/*     */   {
/* 453 */     if (!this.initialized)
/*     */     {
/* 455 */       initialize();
/*     */     }
/* 457 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setX(double x)
/*     */   {
/* 468 */     if (this.origin == Origin.READ)
/*     */     {
/* 470 */       if (!this.initialized)
/*     */       {
/* 472 */         initialize();
/*     */       }
/* 474 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 477 */     this.column = ((int)x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getY()
/*     */   {
/* 487 */     if (!this.initialized)
/*     */     {
/* 489 */       initialize();
/*     */     }
/*     */     
/* 492 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setY(double y)
/*     */   {
/* 502 */     if (this.origin == Origin.READ)
/*     */     {
/* 504 */       if (!this.initialized)
/*     */       {
/* 506 */         initialize();
/*     */       }
/* 508 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 511 */     this.row = ((int)y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getWidth()
/*     */   {
/* 522 */     if (!this.initialized)
/*     */     {
/* 524 */       initialize();
/*     */     }
/*     */     
/* 527 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(double w)
/*     */   {
/* 537 */     if (this.origin == Origin.READ)
/*     */     {
/* 539 */       if (!this.initialized)
/*     */       {
/* 541 */         initialize();
/*     */       }
/* 543 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 546 */     this.width = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getHeight()
/*     */   {
/* 556 */     if (!this.initialized)
/*     */     {
/* 558 */       initialize();
/*     */     }
/*     */     
/* 561 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(double h)
/*     */   {
/* 571 */     if (this.origin == Origin.READ)
/*     */     {
/* 573 */       if (!this.initialized)
/*     */       {
/* 575 */         initialize();
/*     */       }
/* 577 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 580 */     this.height = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer getReadSpContainer()
/*     */   {
/* 591 */     if (!this.initialized)
/*     */     {
/* 593 */       initialize();
/*     */     }
/*     */     
/* 596 */     return this.readSpContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageData()
/*     */   {
/* 606 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*     */     
/* 608 */     if (!this.initialized)
/*     */     {
/* 610 */       initialize();
/*     */     }
/*     */     
/* 613 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ShapeType getType()
/*     */   {
/* 623 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTextObject(TextObjectRecord t)
/*     */   {
/* 633 */     this.txo = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(ContinueRecord t)
/*     */   {
/* 643 */     this.text = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatting(ContinueRecord t)
/*     */   {
/* 653 */     this.formatting = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageBytes()
/*     */   {
/* 663 */     Assert.verify(false);
/* 664 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImageFilePath()
/*     */   {
/* 676 */     Assert.verify(false);
/* 677 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMso(MsoDrawingRecord d)
/*     */   {
/* 687 */     this.mso = d;
/* 688 */     this.drawingData.addRawData(this.mso.getData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAdditionalRecords(File outputFile)
/*     */     throws IOException
/*     */   {
/* 699 */     if (this.origin == Origin.READ)
/*     */     {
/* 701 */       outputFile.write(this.objRecord);
/*     */       
/* 703 */       if (this.mso != null)
/*     */       {
/* 705 */         outputFile.write(this.mso);
/*     */       }
/* 707 */       outputFile.write(this.txo);
/* 708 */       outputFile.write(this.text);
/* 709 */       if (this.formatting != null)
/*     */       {
/* 711 */         outputFile.write(this.formatting);
/*     */       }
/* 713 */       return;
/*     */     }
/*     */     
/* 716 */     Assert.verify(false);
/*     */     
/*     */ 
/* 719 */     ObjRecord objrec = new ObjRecord(this.objectId, ObjRecord.EXCELNOTE);
/*     */     
/*     */ 
/* 722 */     outputFile.write(objrec);
/*     */     
/*     */ 
/*     */ 
/* 726 */     ClientTextBox textBox = new ClientTextBox();
/* 727 */     MsoDrawingRecord msod = new MsoDrawingRecord(textBox.getData());
/* 728 */     outputFile.write(msod);
/*     */     
/* 730 */     TextObjectRecord tor = new TextObjectRecord(getText());
/* 731 */     outputFile.write(tor);
/*     */     
/*     */ 
/* 734 */     byte[] textData = new byte[this.commentText.length() * 2 + 1];
/* 735 */     textData[0] = 1;
/* 736 */     StringHelper.getUnicodeBytes(this.commentText, textData, 1);
/*     */     
/* 738 */     ContinueRecord textContinue = new ContinueRecord(textData);
/* 739 */     outputFile.write(textContinue);
/*     */     
/*     */ 
/*     */ 
/* 743 */     byte[] frData = new byte[16];
/*     */     
/*     */ 
/* 746 */     IntegerHelper.getTwoBytes(0, frData, 0);
/* 747 */     IntegerHelper.getTwoBytes(0, frData, 2);
/*     */     
/* 749 */     IntegerHelper.getTwoBytes(this.commentText.length(), frData, 8);
/* 750 */     IntegerHelper.getTwoBytes(0, frData, 10);
/*     */     
/* 752 */     ContinueRecord frContinue = new ContinueRecord(frData);
/* 753 */     outputFile.write(frContinue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTailRecords(File outputFile) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 775 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 786 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 796 */     if (this.commentText == null)
/*     */     {
/* 798 */       Assert.verify(this.text != null);
/*     */       
/* 800 */       byte[] td = this.text.getData();
/* 801 */       if (td[0] == 0)
/*     */       {
/* 803 */         this.commentText = StringHelper.getString(td, td.length - 1, 1, this.workbookSettings);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 808 */         this.commentText = StringHelper.getUnicodeString(td, (td.length - 1) / 2, 1);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 813 */     return this.commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 823 */     return this.commentText.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButtonText(String t)
/*     */   {
/* 833 */     this.commentText = t;
/*     */     
/* 835 */     if (this.origin == Origin.READ)
/*     */     {
/* 837 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */   {
/* 850 */     return this.mso.isFirst();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFormObject()
/*     */   {
/* 862 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Button.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */