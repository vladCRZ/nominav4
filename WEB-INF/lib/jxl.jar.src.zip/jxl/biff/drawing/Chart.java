/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.IndexMapping;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.File;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Chart
/*     */   implements ByteData, EscherStream
/*     */ {
/*  41 */   private static final Logger logger = Logger.getLogger(Chart.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord objRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int startpos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int endpos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File file;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingData drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Chart(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, int sp, int ep, File f, WorkbookSettings ws)
/*     */   {
/* 109 */     this.msoDrawingRecord = mso;
/* 110 */     this.objRecord = obj;
/* 111 */     this.startpos = sp;
/* 112 */     this.endpos = ep;
/* 113 */     this.file = f;
/* 114 */     this.workbookSettings = ws;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     if (this.msoDrawingRecord != null)
/*     */     {
/* 121 */       this.drawingData = dd;
/* 122 */       this.drawingData.addData(this.msoDrawingRecord.getRecord().getData());
/* 123 */       this.drawingNumber = (this.drawingData.getNumDrawings() - 1);
/*     */     }
/*     */     
/* 126 */     this.initialized = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     Assert.verify(((mso != null) && (obj != null)) || ((mso == null) && (obj == null)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 142 */     if (!this.initialized)
/*     */     {
/* 144 */       initialize();
/*     */     }
/*     */     
/* 147 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 157 */     return this.msoDrawingRecord.getRecord().getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 165 */     this.data = this.file.read(this.startpos, this.endpos - this.startpos);
/* 166 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rationalize(IndexMapping xfMapping, IndexMapping fontMapping, IndexMapping formatMapping)
/*     */   {
/* 179 */     if (!this.initialized)
/*     */     {
/* 181 */       initialize();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 187 */     int pos = 0;
/* 188 */     int code = 0;
/* 189 */     int length = 0;
/* 190 */     Type type = null;
/* 191 */     while (pos < this.data.length)
/*     */     {
/* 193 */       code = IntegerHelper.getInt(this.data[pos], this.data[(pos + 1)]);
/* 194 */       length = IntegerHelper.getInt(this.data[(pos + 2)], this.data[(pos + 3)]);
/*     */       
/* 196 */       type = Type.getType(code);
/*     */       
/* 198 */       if (type == Type.FONTX)
/*     */       {
/* 200 */         int fontind = IntegerHelper.getInt(this.data[(pos + 4)], this.data[(pos + 5)]);
/* 201 */         IntegerHelper.getTwoBytes(fontMapping.getNewIndex(fontind), this.data, pos + 4);
/*     */ 
/*     */       }
/* 204 */       else if (type == Type.FBI)
/*     */       {
/* 206 */         int fontind = IntegerHelper.getInt(this.data[(pos + 12)], this.data[(pos + 13)]);
/* 207 */         IntegerHelper.getTwoBytes(fontMapping.getNewIndex(fontind), this.data, pos + 12);
/*     */ 
/*     */       }
/* 210 */       else if (type == Type.IFMT)
/*     */       {
/* 212 */         int formind = IntegerHelper.getInt(this.data[(pos + 4)], this.data[(pos + 5)]);
/* 213 */         IntegerHelper.getTwoBytes(formatMapping.getNewIndex(formind), this.data, pos + 4);
/*     */ 
/*     */       }
/* 216 */       else if (type == Type.ALRUNS)
/*     */       {
/* 218 */         int numRuns = IntegerHelper.getInt(this.data[(pos + 4)], this.data[(pos + 5)]);
/* 219 */         int fontPos = pos + 6;
/* 220 */         for (int i = 0; i < numRuns; i++)
/*     */         {
/* 222 */           int fontind = IntegerHelper.getInt(this.data[(fontPos + 2)], this.data[(fontPos + 3)]);
/*     */           
/* 224 */           IntegerHelper.getTwoBytes(fontMapping.getNewIndex(fontind), this.data, fontPos + 2);
/*     */           
/* 226 */           fontPos += 4;
/*     */         }
/*     */       }
/*     */       
/* 230 */       pos += length + 4;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   EscherContainer getSpContainer()
/*     */   {
/* 241 */     EscherContainer spContainer = this.drawingData.getSpContainer(this.drawingNumber);
/*     */     
/* 243 */     return spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MsoDrawingRecord getMsoDrawingRecord()
/*     */   {
/* 253 */     return this.msoDrawingRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ObjRecord getObjRecord()
/*     */   {
/* 263 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Chart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */