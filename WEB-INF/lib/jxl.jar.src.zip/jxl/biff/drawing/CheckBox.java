/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ContinueRecord;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBox
/*     */   implements DrawingGroupObject
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(CheckBox.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer readSpContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer spContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord objRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private boolean initialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int blipId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double width;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double height;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer escherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Origin origin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingGroup drawingGroup;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingData drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ShapeType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord mso;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TextObjectRecord txo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContinueRecord text;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContinueRecord formatting;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CheckBox(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 174 */     this.drawingGroup = dg;
/* 175 */     this.msoDrawingRecord = mso;
/* 176 */     this.drawingData = dd;
/* 177 */     this.objRecord = obj;
/* 178 */     this.initialized = false;
/* 179 */     this.workbookSettings = ws;
/* 180 */     this.origin = Origin.READ;
/* 181 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 182 */     this.drawingNumber = (this.drawingData.getNumDrawings() - 1);
/* 183 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 185 */     Assert.verify((mso != null) && (obj != null));
/*     */     
/* 187 */     initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CheckBox(DrawingGroupObject dgo, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 201 */     CheckBox d = (CheckBox)dgo;
/* 202 */     Assert.verify(d.origin == Origin.READ);
/* 203 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 204 */     this.objRecord = d.objRecord;
/* 205 */     this.initialized = false;
/* 206 */     this.origin = Origin.READ;
/* 207 */     this.drawingData = d.drawingData;
/* 208 */     this.drawingGroup = dg;
/* 209 */     this.drawingNumber = d.drawingNumber;
/* 210 */     this.drawingGroup.addDrawing(this);
/* 211 */     this.mso = d.mso;
/* 212 */     this.txo = d.txo;
/* 213 */     this.text = d.text;
/* 214 */     this.formatting = d.formatting;
/* 215 */     this.workbookSettings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CheckBox()
/*     */   {
/* 223 */     this.initialized = true;
/* 224 */     this.origin = Origin.WRITE;
/* 225 */     this.referenceCount = 1;
/* 226 */     this.type = ShapeType.HOST_CONTROL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 234 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 235 */     Assert.verify(this.readSpContainer != null);
/*     */     
/* 237 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 239 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 240 */     this.objectId = this.objRecord.getObjectId();
/* 241 */     this.shapeId = sp.getShapeId();
/* 242 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 244 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 246 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 249 */     ClientAnchor clientAnchor = null;
/* 250 */     for (int i = 0; (i < children.length) && (clientAnchor == null); i++)
/*     */     {
/* 252 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 254 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     }
/*     */     
/* 258 */     if (clientAnchor == null)
/*     */     {
/* 260 */       logger.warn("Client anchor not found");
/*     */     }
/*     */     else
/*     */     {
/* 264 */       this.column = ((int)clientAnchor.getX1());
/* 265 */       this.row = ((int)clientAnchor.getY1());
/*     */     }
/*     */     
/* 268 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setObjectId(int objid, int bip, int sid)
/*     */   {
/* 282 */     this.objectId = objid;
/* 283 */     this.blipId = bip;
/* 284 */     this.shapeId = sid;
/*     */     
/* 286 */     if (this.origin == Origin.READ)
/*     */     {
/* 288 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getObjectId()
/*     */   {
/* 299 */     if (!this.initialized)
/*     */     {
/* 301 */       initialize();
/*     */     }
/*     */     
/* 304 */     return this.objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getShapeId()
/*     */   {
/* 314 */     if (!this.initialized)
/*     */     {
/* 316 */       initialize();
/*     */     }
/*     */     
/* 319 */     return this.shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getBlipId()
/*     */   {
/* 329 */     if (!this.initialized)
/*     */     {
/* 331 */       initialize();
/*     */     }
/*     */     
/* 334 */     return this.blipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MsoDrawingRecord getMsoDrawingRecord()
/*     */   {
/* 344 */     return this.msoDrawingRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainer getSpContainer()
/*     */   {
/* 354 */     if (!this.initialized)
/*     */     {
/* 356 */       initialize();
/*     */     }
/*     */     
/* 359 */     if (this.origin == Origin.READ)
/*     */     {
/* 361 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 364 */     SpContainer spc = new SpContainer();
/* 365 */     Sp sp = new Sp(this.type, this.shapeId, 2560);
/* 366 */     spc.add(sp);
/* 367 */     Opt opt = new Opt();
/* 368 */     opt.addProperty(127, false, false, 17039620);
/* 369 */     opt.addProperty(191, false, false, 524296);
/* 370 */     opt.addProperty(511, false, false, 524288);
/* 371 */     opt.addProperty(959, false, false, 131072);
/*     */     
/*     */ 
/* 374 */     spc.add(opt);
/*     */     
/* 376 */     ClientAnchor clientAnchor = new ClientAnchor(this.column, this.row, this.column + 1, this.row + 1, 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 381 */     spc.add(clientAnchor);
/* 382 */     ClientData clientData = new ClientData();
/* 383 */     spc.add(clientData);
/*     */     
/* 385 */     return spc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingGroup(DrawingGroup dg)
/*     */   {
/* 396 */     this.drawingGroup = dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup getDrawingGroup()
/*     */   {
/* 406 */     return this.drawingGroup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Origin getOrigin()
/*     */   {
/* 416 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReferenceCount()
/*     */   {
/* 426 */     return this.referenceCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReferenceCount(int r)
/*     */   {
/* 436 */     this.referenceCount = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getX()
/*     */   {
/* 446 */     if (!this.initialized)
/*     */     {
/* 448 */       initialize();
/*     */     }
/* 450 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setX(double x)
/*     */   {
/* 461 */     if (this.origin == Origin.READ)
/*     */     {
/* 463 */       if (!this.initialized)
/*     */       {
/* 465 */         initialize();
/*     */       }
/* 467 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 470 */     this.column = ((int)x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getY()
/*     */   {
/* 480 */     if (!this.initialized)
/*     */     {
/* 482 */       initialize();
/*     */     }
/*     */     
/* 485 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setY(double y)
/*     */   {
/* 495 */     if (this.origin == Origin.READ)
/*     */     {
/* 497 */       if (!this.initialized)
/*     */       {
/* 499 */         initialize();
/*     */       }
/* 501 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 504 */     this.row = ((int)y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getWidth()
/*     */   {
/* 515 */     if (!this.initialized)
/*     */     {
/* 517 */       initialize();
/*     */     }
/*     */     
/* 520 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(double w)
/*     */   {
/* 530 */     if (this.origin == Origin.READ)
/*     */     {
/* 532 */       if (!this.initialized)
/*     */       {
/* 534 */         initialize();
/*     */       }
/* 536 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 539 */     this.width = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getHeight()
/*     */   {
/* 549 */     if (!this.initialized)
/*     */     {
/* 551 */       initialize();
/*     */     }
/*     */     
/* 554 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(double h)
/*     */   {
/* 564 */     if (this.origin == Origin.READ)
/*     */     {
/* 566 */       if (!this.initialized)
/*     */       {
/* 568 */         initialize();
/*     */       }
/* 570 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 573 */     this.height = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer getReadSpContainer()
/*     */   {
/* 584 */     if (!this.initialized)
/*     */     {
/* 586 */       initialize();
/*     */     }
/*     */     
/* 589 */     return this.readSpContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageData()
/*     */   {
/* 599 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*     */     
/* 601 */     if (!this.initialized)
/*     */     {
/* 603 */       initialize();
/*     */     }
/*     */     
/* 606 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ShapeType getType()
/*     */   {
/* 616 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageBytes()
/*     */   {
/* 626 */     Assert.verify(false);
/* 627 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImageFilePath()
/*     */   {
/* 639 */     Assert.verify(false);
/* 640 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAdditionalRecords(File outputFile)
/*     */     throws IOException
/*     */   {
/* 651 */     if (this.origin == Origin.READ)
/*     */     {
/* 653 */       outputFile.write(this.objRecord);
/*     */       
/* 655 */       if (this.mso != null)
/*     */       {
/* 657 */         outputFile.write(this.mso);
/*     */       }
/* 659 */       outputFile.write(this.txo);
/* 660 */       outputFile.write(this.text);
/* 661 */       if (this.formatting != null)
/*     */       {
/* 663 */         outputFile.write(this.formatting);
/*     */       }
/* 665 */       return;
/*     */     }
/*     */     
/*     */ 
/* 669 */     ObjRecord objrec = new ObjRecord(this.objectId, ObjRecord.CHECKBOX);
/*     */     
/*     */ 
/* 672 */     outputFile.write(objrec);
/*     */     
/* 674 */     logger.warn("Writing of additional records for checkboxes not implemented");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTailRecords(File outputFile) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 696 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 706 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 716 */     return getClass().getName().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */   {
/* 728 */     return this.msoDrawingRecord.isFirst();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFormObject()
/*     */   {
/* 740 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTextObject(TextObjectRecord t)
/*     */   {
/* 750 */     this.txo = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(ContinueRecord t)
/*     */   {
/* 760 */     this.text = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatting(ContinueRecord t)
/*     */   {
/* 770 */     this.formatting = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMso(MsoDrawingRecord d)
/*     */   {
/* 780 */     this.mso = d;
/* 781 */     this.drawingData.addRawData(this.mso.getData());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\CheckBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */