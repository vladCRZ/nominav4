/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Chunk
/*    */ {
/*    */   private int pos;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private int length;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private ChunkType type;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private byte[] data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Chunk(int p, int l, ChunkType ct, byte[] d)
/*    */   {
/* 31 */     this.pos = p;
/* 32 */     this.length = l;
/* 33 */     this.type = ct;
/* 34 */     this.data = new byte[this.length];
/* 35 */     System.arraycopy(d, this.pos, this.data, 0, this.length);
/*    */   }
/*    */   
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 41 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Chunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */