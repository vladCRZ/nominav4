/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ChunkType
/*    */ {
/*    */   private byte[] id;
/*    */   private String name;
/* 32 */   private static ChunkType[] chunkTypes = new ChunkType[0];
/*    */   
/*    */   private ChunkType(int d1, int d2, int d3, int d4, String n)
/*    */   {
/* 36 */     this.id = new byte[] { (byte)d1, (byte)d2, (byte)d3, (byte)d4 };
/* 37 */     this.name = n;
/*    */     
/* 39 */     ChunkType[] ct = new ChunkType[chunkTypes.length + 1];
/* 40 */     System.arraycopy(chunkTypes, 0, ct, 0, chunkTypes.length);
/* 41 */     ct[chunkTypes.length] = this;
/* 42 */     chunkTypes = ct;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 47 */     return this.name;
/*    */   }
/*    */   
/*    */   public static ChunkType getChunkType(byte d1, byte d2, byte d3, byte d4)
/*    */   {
/* 52 */     byte[] cmp = { d1, d2, d3, d4 };
/*    */     
/* 54 */     boolean found = false;
/* 55 */     ChunkType chunk = UNKNOWN;
/*    */     
/* 57 */     for (int i = 0; (i < chunkTypes.length) && (!found); i++)
/*    */     {
/* 59 */       if (Arrays.equals(chunkTypes[i].id, cmp))
/*    */       {
/* 61 */         chunk = chunkTypes[i];
/* 62 */         found = true;
/*    */       }
/*    */     }
/*    */     
/* 66 */     return chunk;
/*    */   }
/*    */   
/*    */ 
/* 70 */   public static ChunkType IHDR = new ChunkType(73, 72, 68, 82, "IHDR");
/* 71 */   public static ChunkType IEND = new ChunkType(73, 69, 78, 68, "IEND");
/* 72 */   public static ChunkType PHYS = new ChunkType(112, 72, 89, 115, "pHYs");
/* 73 */   public static ChunkType UNKNOWN = new ChunkType(255, 255, 255, 255, "UNKNOWN");
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\ChunkType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */