/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClientAnchor
/*     */   extends EscherAtom
/*     */ {
/*  34 */   private static final Logger logger = Logger.getLogger(ClientAnchor.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int properties;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double x1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double y1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double x2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double y2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientAnchor(EscherRecordData erd)
/*     */   {
/*  73 */     super(erd);
/*  74 */     byte[] bytes = getBytes();
/*     */     
/*     */ 
/*  77 */     this.properties = IntegerHelper.getInt(bytes[0], bytes[1]);
/*     */     
/*     */ 
/*  80 */     int x1Cell = IntegerHelper.getInt(bytes[2], bytes[3]);
/*  81 */     int x1Fraction = IntegerHelper.getInt(bytes[4], bytes[5]);
/*     */     
/*  83 */     this.x1 = (x1Cell + x1Fraction / 1024.0D);
/*     */     
/*     */ 
/*  86 */     int y1Cell = IntegerHelper.getInt(bytes[6], bytes[7]);
/*  87 */     int y1Fraction = IntegerHelper.getInt(bytes[8], bytes[9]);
/*     */     
/*  89 */     this.y1 = (y1Cell + y1Fraction / 256.0D);
/*     */     
/*     */ 
/*  92 */     int x2Cell = IntegerHelper.getInt(bytes[10], bytes[11]);
/*  93 */     int x2Fraction = IntegerHelper.getInt(bytes[12], bytes[13]);
/*     */     
/*  95 */     this.x2 = (x2Cell + x2Fraction / 1024.0D);
/*     */     
/*     */ 
/*  98 */     int y2Cell = IntegerHelper.getInt(bytes[14], bytes[15]);
/*  99 */     int y2Fraction = IntegerHelper.getInt(bytes[16], bytes[17]);
/*     */     
/* 101 */     this.y2 = (y2Cell + y2Fraction / 256.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientAnchor(double x1, double y1, double x2, double y2, int props)
/*     */   {
/* 115 */     super(EscherRecordType.CLIENT_ANCHOR);
/* 116 */     this.x1 = x1;
/* 117 */     this.y1 = y1;
/* 118 */     this.x2 = x2;
/* 119 */     this.y2 = y2;
/* 120 */     this.properties = props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getData()
/*     */   {
/* 130 */     this.data = new byte[18];
/* 131 */     IntegerHelper.getTwoBytes(this.properties, this.data, 0);
/*     */     
/*     */ 
/* 134 */     IntegerHelper.getTwoBytes((int)this.x1, this.data, 2);
/*     */     
/*     */ 
/* 137 */     int x1fraction = (int)((this.x1 - (int)this.x1) * 1024.0D);
/* 138 */     IntegerHelper.getTwoBytes(x1fraction, this.data, 4);
/*     */     
/*     */ 
/* 141 */     IntegerHelper.getTwoBytes((int)this.y1, this.data, 6);
/*     */     
/*     */ 
/* 144 */     int y1fraction = (int)((this.y1 - (int)this.y1) * 256.0D);
/* 145 */     IntegerHelper.getTwoBytes(y1fraction, this.data, 8);
/*     */     
/*     */ 
/* 148 */     IntegerHelper.getTwoBytes((int)this.x2, this.data, 10);
/*     */     
/*     */ 
/* 151 */     int x2fraction = (int)((this.x2 - (int)this.x2) * 1024.0D);
/* 152 */     IntegerHelper.getTwoBytes(x2fraction, this.data, 12);
/*     */     
/*     */ 
/* 155 */     IntegerHelper.getTwoBytes((int)this.y2, this.data, 14);
/*     */     
/*     */ 
/* 158 */     int y2fraction = (int)((this.y2 - (int)this.y2) * 256.0D);
/* 159 */     IntegerHelper.getTwoBytes(y2fraction, this.data, 16);
/*     */     
/* 161 */     return setHeaderData(this.data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   double getX1()
/*     */   {
/* 171 */     return this.x1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   double getY1()
/*     */   {
/* 181 */     return this.y1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   double getX2()
/*     */   {
/* 191 */     return this.x2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   double getY2()
/*     */   {
/* 201 */     return this.y2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getProperties()
/*     */   {
/* 209 */     return this.properties;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\ClientAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */