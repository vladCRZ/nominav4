/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClientData
/*    */   extends EscherAtom
/*    */ {
/* 32 */   private static Logger logger = Logger.getLogger(ClientData.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private byte[] data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClientData(EscherRecordData erd)
/*    */   {
/* 46 */     super(erd);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClientData()
/*    */   {
/* 54 */     super(EscherRecordType.CLIENT_DATA);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getData()
/*    */   {
/* 64 */     this.data = new byte[0];
/* 65 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\ClientData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */