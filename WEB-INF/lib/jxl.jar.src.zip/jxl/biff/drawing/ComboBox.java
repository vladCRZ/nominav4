/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBox
/*     */   implements DrawingGroupObject
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(ComboBox.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer readSpContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer spContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord objRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private boolean initialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int blipId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double width;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double height;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer escherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Origin origin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingGroup drawingGroup;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingData drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ShapeType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboBox(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 153 */     this.drawingGroup = dg;
/* 154 */     this.msoDrawingRecord = mso;
/* 155 */     this.drawingData = dd;
/* 156 */     this.objRecord = obj;
/* 157 */     this.initialized = false;
/* 158 */     this.workbookSettings = ws;
/* 159 */     this.origin = Origin.READ;
/* 160 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 161 */     this.drawingNumber = (this.drawingData.getNumDrawings() - 1);
/* 162 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 164 */     Assert.verify((mso != null) && (obj != null));
/*     */     
/* 166 */     initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboBox(DrawingGroupObject dgo, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 180 */     ComboBox d = (ComboBox)dgo;
/* 181 */     Assert.verify(d.origin == Origin.READ);
/* 182 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 183 */     this.objRecord = d.objRecord;
/* 184 */     this.initialized = false;
/* 185 */     this.origin = Origin.READ;
/* 186 */     this.drawingData = d.drawingData;
/* 187 */     this.drawingGroup = dg;
/* 188 */     this.drawingNumber = d.drawingNumber;
/* 189 */     this.drawingGroup.addDrawing(this);
/* 190 */     this.workbookSettings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboBox()
/*     */   {
/* 198 */     this.initialized = true;
/* 199 */     this.origin = Origin.WRITE;
/* 200 */     this.referenceCount = 1;
/* 201 */     this.type = ShapeType.HOST_CONTROL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 209 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 210 */     Assert.verify(this.readSpContainer != null);
/*     */     
/* 212 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 214 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 215 */     this.objectId = this.objRecord.getObjectId();
/* 216 */     this.shapeId = sp.getShapeId();
/* 217 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 219 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 221 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 224 */     ClientAnchor clientAnchor = null;
/* 225 */     for (int i = 0; (i < children.length) && (clientAnchor == null); i++)
/*     */     {
/* 227 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 229 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     }
/*     */     
/* 233 */     if (clientAnchor == null)
/*     */     {
/* 235 */       logger.warn("Client anchor not found");
/*     */     }
/*     */     else
/*     */     {
/* 239 */       this.column = ((int)clientAnchor.getX1());
/* 240 */       this.row = ((int)clientAnchor.getY1());
/*     */     }
/*     */     
/* 243 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setObjectId(int objid, int bip, int sid)
/*     */   {
/* 257 */     this.objectId = objid;
/* 258 */     this.blipId = bip;
/* 259 */     this.shapeId = sid;
/*     */     
/* 261 */     if (this.origin == Origin.READ)
/*     */     {
/* 263 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getObjectId()
/*     */   {
/* 274 */     if (!this.initialized)
/*     */     {
/* 276 */       initialize();
/*     */     }
/*     */     
/* 279 */     return this.objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getShapeId()
/*     */   {
/* 289 */     if (!this.initialized)
/*     */     {
/* 291 */       initialize();
/*     */     }
/*     */     
/* 294 */     return this.shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getBlipId()
/*     */   {
/* 304 */     if (!this.initialized)
/*     */     {
/* 306 */       initialize();
/*     */     }
/*     */     
/* 309 */     return this.blipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MsoDrawingRecord getMsoDrawingRecord()
/*     */   {
/* 319 */     return this.msoDrawingRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainer getSpContainer()
/*     */   {
/* 329 */     if (!this.initialized)
/*     */     {
/* 331 */       initialize();
/*     */     }
/*     */     
/* 334 */     if (this.origin == Origin.READ)
/*     */     {
/* 336 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 339 */     SpContainer spc = new SpContainer();
/* 340 */     Sp sp = new Sp(this.type, this.shapeId, 2560);
/* 341 */     spc.add(sp);
/* 342 */     Opt opt = new Opt();
/* 343 */     opt.addProperty(127, false, false, 17039620);
/* 344 */     opt.addProperty(191, false, false, 524296);
/* 345 */     opt.addProperty(511, false, false, 524288);
/* 346 */     opt.addProperty(959, false, false, 131072);
/*     */     
/*     */ 
/* 349 */     spc.add(opt);
/*     */     
/* 351 */     ClientAnchor clientAnchor = new ClientAnchor(this.column, this.row, this.column + 1, this.row + 1, 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 356 */     spc.add(clientAnchor);
/* 357 */     ClientData clientData = new ClientData();
/* 358 */     spc.add(clientData);
/*     */     
/* 360 */     return spc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingGroup(DrawingGroup dg)
/*     */   {
/* 371 */     this.drawingGroup = dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup getDrawingGroup()
/*     */   {
/* 381 */     return this.drawingGroup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Origin getOrigin()
/*     */   {
/* 391 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReferenceCount()
/*     */   {
/* 401 */     return this.referenceCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReferenceCount(int r)
/*     */   {
/* 411 */     this.referenceCount = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getX()
/*     */   {
/* 421 */     if (!this.initialized)
/*     */     {
/* 423 */       initialize();
/*     */     }
/* 425 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setX(double x)
/*     */   {
/* 436 */     if (this.origin == Origin.READ)
/*     */     {
/* 438 */       if (!this.initialized)
/*     */       {
/* 440 */         initialize();
/*     */       }
/* 442 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 445 */     this.column = ((int)x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getY()
/*     */   {
/* 455 */     if (!this.initialized)
/*     */     {
/* 457 */       initialize();
/*     */     }
/*     */     
/* 460 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setY(double y)
/*     */   {
/* 470 */     if (this.origin == Origin.READ)
/*     */     {
/* 472 */       if (!this.initialized)
/*     */       {
/* 474 */         initialize();
/*     */       }
/* 476 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 479 */     this.row = ((int)y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getWidth()
/*     */   {
/* 490 */     if (!this.initialized)
/*     */     {
/* 492 */       initialize();
/*     */     }
/*     */     
/* 495 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(double w)
/*     */   {
/* 505 */     if (this.origin == Origin.READ)
/*     */     {
/* 507 */       if (!this.initialized)
/*     */       {
/* 509 */         initialize();
/*     */       }
/* 511 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 514 */     this.width = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getHeight()
/*     */   {
/* 524 */     if (!this.initialized)
/*     */     {
/* 526 */       initialize();
/*     */     }
/*     */     
/* 529 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(double h)
/*     */   {
/* 539 */     if (this.origin == Origin.READ)
/*     */     {
/* 541 */       if (!this.initialized)
/*     */       {
/* 543 */         initialize();
/*     */       }
/* 545 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 548 */     this.height = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer getReadSpContainer()
/*     */   {
/* 559 */     if (!this.initialized)
/*     */     {
/* 561 */       initialize();
/*     */     }
/*     */     
/* 564 */     return this.readSpContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageData()
/*     */   {
/* 574 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*     */     
/* 576 */     if (!this.initialized)
/*     */     {
/* 578 */       initialize();
/*     */     }
/*     */     
/* 581 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ShapeType getType()
/*     */   {
/* 591 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageBytes()
/*     */   {
/* 601 */     Assert.verify(false);
/* 602 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImageFilePath()
/*     */   {
/* 614 */     Assert.verify(false);
/* 615 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAdditionalRecords(File outputFile)
/*     */     throws IOException
/*     */   {
/* 626 */     if (this.origin == Origin.READ)
/*     */     {
/* 628 */       outputFile.write(this.objRecord);
/* 629 */       return;
/*     */     }
/*     */     
/*     */ 
/* 633 */     ObjRecord objrec = new ObjRecord(this.objectId, ObjRecord.COMBOBOX);
/*     */     
/*     */ 
/* 636 */     outputFile.write(objrec);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTailRecords(File outputFile) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 657 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 667 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 677 */     return getClass().getName().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */   {
/* 689 */     return this.msoDrawingRecord.isFirst();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFormObject()
/*     */   {
/* 701 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\ComboBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */