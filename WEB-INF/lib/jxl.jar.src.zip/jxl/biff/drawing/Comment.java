/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ContinueRecord;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Comment
/*     */   implements DrawingGroupObject
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(Comment.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer readSpContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer spContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord objRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private boolean initialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int blipId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double width;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double height;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer escherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Origin origin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingGroup drawingGroup;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingData drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ShapeType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord mso;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TextObjectRecord txo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private NoteRecord note;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContinueRecord text;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ContinueRecord formatting;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String commentText;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Comment(MsoDrawingRecord msorec, ObjRecord obj, DrawingData dd, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 186 */     this.drawingGroup = dg;
/* 187 */     this.msoDrawingRecord = msorec;
/* 188 */     this.drawingData = dd;
/* 189 */     this.objRecord = obj;
/* 190 */     this.initialized = false;
/* 191 */     this.workbookSettings = ws;
/* 192 */     this.origin = Origin.READ;
/* 193 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 194 */     this.drawingNumber = (this.drawingData.getNumDrawings() - 1);
/* 195 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 197 */     Assert.verify((this.msoDrawingRecord != null) && (this.objRecord != null));
/*     */     
/* 199 */     if (!this.initialized)
/*     */     {
/* 201 */       initialize();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Comment(DrawingGroupObject dgo, DrawingGroup dg, WorkbookSettings ws)
/*     */   {
/* 216 */     Comment d = (Comment)dgo;
/* 217 */     Assert.verify(d.origin == Origin.READ);
/* 218 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 219 */     this.objRecord = d.objRecord;
/* 220 */     this.initialized = false;
/* 221 */     this.origin = Origin.READ;
/* 222 */     this.drawingData = d.drawingData;
/* 223 */     this.drawingGroup = dg;
/* 224 */     this.drawingNumber = d.drawingNumber;
/* 225 */     this.drawingGroup.addDrawing(this);
/* 226 */     this.mso = d.mso;
/* 227 */     this.txo = d.txo;
/* 228 */     this.text = d.text;
/* 229 */     this.formatting = d.formatting;
/* 230 */     this.note = d.note;
/* 231 */     this.width = d.width;
/* 232 */     this.height = d.height;
/* 233 */     this.workbookSettings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Comment(String txt, int c, int r)
/*     */   {
/* 245 */     this.initialized = true;
/* 246 */     this.origin = Origin.WRITE;
/* 247 */     this.column = c;
/* 248 */     this.row = r;
/* 249 */     this.referenceCount = 1;
/* 250 */     this.type = ShapeType.TEXT_BOX;
/* 251 */     this.commentText = txt;
/* 252 */     this.width = 3.0D;
/* 253 */     this.height = 4.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 261 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 262 */     Assert.verify(this.readSpContainer != null);
/*     */     
/* 264 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 266 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 267 */     this.objectId = this.objRecord.getObjectId();
/* 268 */     this.shapeId = sp.getShapeId();
/* 269 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 271 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 273 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 276 */     ClientAnchor clientAnchor = null;
/* 277 */     for (int i = 0; (i < children.length) && (clientAnchor == null); i++)
/*     */     {
/* 279 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 281 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     }
/*     */     
/* 285 */     if (clientAnchor == null)
/*     */     {
/* 287 */       logger.warn("client anchor not found");
/*     */     }
/*     */     else
/*     */     {
/* 291 */       this.column = ((int)clientAnchor.getX1() - 1);
/* 292 */       this.row = ((int)clientAnchor.getY1() + 1);
/* 293 */       this.width = (clientAnchor.getX2() - clientAnchor.getX1());
/* 294 */       this.height = (clientAnchor.getY2() - clientAnchor.getY1());
/*     */     }
/*     */     
/* 297 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setObjectId(int objid, int bip, int sid)
/*     */   {
/* 311 */     this.objectId = objid;
/* 312 */     this.blipId = bip;
/* 313 */     this.shapeId = sid;
/*     */     
/* 315 */     if (this.origin == Origin.READ)
/*     */     {
/* 317 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getObjectId()
/*     */   {
/* 328 */     if (!this.initialized)
/*     */     {
/* 330 */       initialize();
/*     */     }
/*     */     
/* 333 */     return this.objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getShapeId()
/*     */   {
/* 343 */     if (!this.initialized)
/*     */     {
/* 345 */       initialize();
/*     */     }
/*     */     
/* 348 */     return this.shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getBlipId()
/*     */   {
/* 358 */     if (!this.initialized)
/*     */     {
/* 360 */       initialize();
/*     */     }
/*     */     
/* 363 */     return this.blipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MsoDrawingRecord getMsoDrawingRecord()
/*     */   {
/* 373 */     return this.msoDrawingRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainer getSpContainer()
/*     */   {
/* 383 */     if (!this.initialized)
/*     */     {
/* 385 */       initialize();
/*     */     }
/*     */     
/* 388 */     if (this.origin == Origin.READ)
/*     */     {
/* 390 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 393 */     if (this.spContainer == null)
/*     */     {
/* 395 */       this.spContainer = new SpContainer();
/* 396 */       Sp sp = new Sp(this.type, this.shapeId, 2560);
/* 397 */       this.spContainer.add(sp);
/* 398 */       Opt opt = new Opt();
/* 399 */       opt.addProperty(344, false, false, 0);
/* 400 */       opt.addProperty(385, false, false, 134217808);
/* 401 */       opt.addProperty(387, false, false, 134217808);
/* 402 */       opt.addProperty(959, false, false, 131074);
/* 403 */       this.spContainer.add(opt);
/*     */       
/* 405 */       ClientAnchor clientAnchor = new ClientAnchor(this.column + 1.3D, Math.max(0.0D, this.row - 0.6D), this.column + 1.3D + this.width, this.row + this.height, 1);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 411 */       this.spContainer.add(clientAnchor);
/*     */       
/* 413 */       ClientData clientData = new ClientData();
/* 414 */       this.spContainer.add(clientData);
/*     */       
/* 416 */       ClientTextBox clientTextBox = new ClientTextBox();
/* 417 */       this.spContainer.add(clientTextBox);
/*     */     }
/*     */     
/* 420 */     return this.spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingGroup(DrawingGroup dg)
/*     */   {
/* 431 */     this.drawingGroup = dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup getDrawingGroup()
/*     */   {
/* 441 */     return this.drawingGroup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Origin getOrigin()
/*     */   {
/* 451 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReferenceCount()
/*     */   {
/* 461 */     return this.referenceCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReferenceCount(int r)
/*     */   {
/* 471 */     this.referenceCount = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getX()
/*     */   {
/* 481 */     if (!this.initialized)
/*     */     {
/* 483 */       initialize();
/*     */     }
/* 485 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setX(double x)
/*     */   {
/* 496 */     if (this.origin == Origin.READ)
/*     */     {
/* 498 */       if (!this.initialized)
/*     */       {
/* 500 */         initialize();
/*     */       }
/* 502 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 505 */     this.column = ((int)x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getY()
/*     */   {
/* 515 */     if (!this.initialized)
/*     */     {
/* 517 */       initialize();
/*     */     }
/*     */     
/* 520 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setY(double y)
/*     */   {
/* 530 */     if (this.origin == Origin.READ)
/*     */     {
/* 532 */       if (!this.initialized)
/*     */       {
/* 534 */         initialize();
/*     */       }
/* 536 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 539 */     this.row = ((int)y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getWidth()
/*     */   {
/* 550 */     if (!this.initialized)
/*     */     {
/* 552 */       initialize();
/*     */     }
/*     */     
/* 555 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(double w)
/*     */   {
/* 565 */     if (this.origin == Origin.READ)
/*     */     {
/* 567 */       if (!this.initialized)
/*     */       {
/* 569 */         initialize();
/*     */       }
/* 571 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 574 */     this.width = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getHeight()
/*     */   {
/* 584 */     if (!this.initialized)
/*     */     {
/* 586 */       initialize();
/*     */     }
/*     */     
/* 589 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(double h)
/*     */   {
/* 599 */     if (this.origin == Origin.READ)
/*     */     {
/* 601 */       if (!this.initialized)
/*     */       {
/* 603 */         initialize();
/*     */       }
/* 605 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 608 */     this.height = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer getReadSpContainer()
/*     */   {
/* 619 */     if (!this.initialized)
/*     */     {
/* 621 */       initialize();
/*     */     }
/*     */     
/* 624 */     return this.readSpContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageData()
/*     */   {
/* 634 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*     */     
/* 636 */     if (!this.initialized)
/*     */     {
/* 638 */       initialize();
/*     */     }
/*     */     
/* 641 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ShapeType getType()
/*     */   {
/* 651 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTextObject(TextObjectRecord t)
/*     */   {
/* 661 */     this.txo = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNote(NoteRecord t)
/*     */   {
/* 671 */     this.note = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(ContinueRecord t)
/*     */   {
/* 681 */     this.text = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatting(ContinueRecord t)
/*     */   {
/* 691 */     this.formatting = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageBytes()
/*     */   {
/* 701 */     Assert.verify(false);
/* 702 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImageFilePath()
/*     */   {
/* 714 */     Assert.verify(false);
/* 715 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMso(MsoDrawingRecord d)
/*     */   {
/* 725 */     this.mso = d;
/* 726 */     this.drawingData.addRawData(this.mso.getData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAdditionalRecords(File outputFile)
/*     */     throws IOException
/*     */   {
/* 737 */     if (this.origin == Origin.READ)
/*     */     {
/* 739 */       outputFile.write(this.objRecord);
/*     */       
/* 741 */       if (this.mso != null)
/*     */       {
/* 743 */         outputFile.write(this.mso);
/*     */       }
/* 745 */       outputFile.write(this.txo);
/* 746 */       outputFile.write(this.text);
/* 747 */       if (this.formatting != null)
/*     */       {
/* 749 */         outputFile.write(this.formatting);
/*     */       }
/* 751 */       return;
/*     */     }
/*     */     
/*     */ 
/* 755 */     ObjRecord objrec = new ObjRecord(this.objectId, ObjRecord.EXCELNOTE);
/*     */     
/*     */ 
/* 758 */     outputFile.write(objrec);
/*     */     
/*     */ 
/*     */ 
/* 762 */     ClientTextBox textBox = new ClientTextBox();
/* 763 */     MsoDrawingRecord msod = new MsoDrawingRecord(textBox.getData());
/* 764 */     outputFile.write(msod);
/*     */     
/* 766 */     TextObjectRecord txorec = new TextObjectRecord(getText());
/* 767 */     outputFile.write(txorec);
/*     */     
/*     */ 
/* 770 */     byte[] textData = new byte[this.commentText.length() * 2 + 1];
/* 771 */     textData[0] = 1;
/* 772 */     StringHelper.getUnicodeBytes(this.commentText, textData, 1);
/*     */     
/* 774 */     ContinueRecord textContinue = new ContinueRecord(textData);
/* 775 */     outputFile.write(textContinue);
/*     */     
/*     */ 
/*     */ 
/* 779 */     byte[] frData = new byte[16];
/*     */     
/*     */ 
/* 782 */     IntegerHelper.getTwoBytes(0, frData, 0);
/* 783 */     IntegerHelper.getTwoBytes(0, frData, 2);
/*     */     
/* 785 */     IntegerHelper.getTwoBytes(this.commentText.length(), frData, 8);
/* 786 */     IntegerHelper.getTwoBytes(0, frData, 10);
/*     */     
/* 788 */     ContinueRecord frContinue = new ContinueRecord(frData);
/* 789 */     outputFile.write(frContinue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTailRecords(File outputFile)
/*     */     throws IOException
/*     */   {
/* 802 */     if (this.origin == Origin.READ)
/*     */     {
/* 804 */       outputFile.write(this.note);
/* 805 */       return;
/*     */     }
/*     */     
/*     */ 
/* 809 */     NoteRecord noteRecord = new NoteRecord(this.column, this.row, this.objectId);
/* 810 */     outputFile.write(noteRecord);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 820 */     return this.note.getRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 830 */     return this.note.getColumn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 840 */     if (this.commentText == null)
/*     */     {
/* 842 */       Assert.verify(this.text != null);
/*     */       
/* 844 */       byte[] td = this.text.getData();
/* 845 */       if (td[0] == 0)
/*     */       {
/* 847 */         this.commentText = StringHelper.getString(td, td.length - 1, 1, this.workbookSettings);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 852 */         this.commentText = StringHelper.getUnicodeString(td, (td.length - 1) / 2, 1);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 857 */     return this.commentText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 867 */     return this.commentText.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCommentText(String t)
/*     */   {
/* 877 */     this.commentText = t;
/*     */     
/* 879 */     if (this.origin == Origin.READ)
/*     */     {
/* 881 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */   {
/* 894 */     return this.msoDrawingRecord.isFirst();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFormObject()
/*     */   {
/* 905 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Comment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */