/*      */ package jxl.biff.drawing;
/*      */ 
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import jxl.CellView;
/*      */ import jxl.Image;
/*      */ import jxl.Sheet;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.LengthConverter;
/*      */ import jxl.common.LengthUnit;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.format.Font;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Drawing
/*      */   implements DrawingGroupObject, Image
/*      */ {
/*   45 */   private static Logger logger = Logger.getLogger(Drawing.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private EscherContainer readSpContainer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MsoDrawingRecord msoDrawingRecord;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ObjRecord objRecord;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   65 */   private boolean initialized = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private java.io.File imageFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] imageData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int objectId;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int blipId;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private double x;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private double y;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private double width;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private double height;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int referenceCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private EscherContainer escherData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Origin origin;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DrawingGroup drawingGroup;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DrawingData drawingData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ShapeType type;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int shapeId;
/*      */   
/*      */ 
/*      */ 
/*      */   private int drawingNumber;
/*      */   
/*      */ 
/*      */ 
/*      */   private Sheet sheet;
/*      */   
/*      */ 
/*      */ 
/*      */   private PNGReader pngReader;
/*      */   
/*      */ 
/*      */ 
/*      */   private ImageAnchorProperties imageAnchorProperties;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class ImageAnchorProperties
/*      */   {
/*      */     private int value;
/*      */     
/*      */ 
/*      */ 
/*  167 */     private static ImageAnchorProperties[] o = new ImageAnchorProperties[0];
/*      */     
/*      */     ImageAnchorProperties(int v)
/*      */     {
/*  171 */       this.value = v;
/*      */       
/*  173 */       ImageAnchorProperties[] oldArray = o;
/*  174 */       o = new ImageAnchorProperties[oldArray.length + 1];
/*  175 */       System.arraycopy(oldArray, 0, o, 0, oldArray.length);
/*  176 */       o[oldArray.length] = this;
/*      */     }
/*      */     
/*      */     int getValue()
/*      */     {
/*  181 */       return this.value;
/*      */     }
/*      */     
/*      */     static ImageAnchorProperties getImageAnchorProperties(int val)
/*      */     {
/*  186 */       ImageAnchorProperties iap = Drawing.MOVE_AND_SIZE_WITH_CELLS;
/*  187 */       int pos = 0;
/*  188 */       while (pos < o.length)
/*      */       {
/*  190 */         if (o[pos].getValue() == val)
/*      */         {
/*  192 */           iap = o[pos];
/*  193 */           break;
/*      */         }
/*      */         
/*      */ 
/*  197 */         pos++;
/*      */       }
/*      */       
/*  200 */       return iap;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  205 */   public static ImageAnchorProperties MOVE_AND_SIZE_WITH_CELLS = new ImageAnchorProperties(1);
/*      */   
/*  207 */   public static ImageAnchorProperties MOVE_WITH_CELLS = new ImageAnchorProperties(2);
/*      */   
/*  209 */   public static ImageAnchorProperties NO_MOVE_OR_SIZE_WITH_CELLS = new ImageAnchorProperties(3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final double DEFAULT_FONT_SIZE = 10.0D;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Drawing(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, DrawingGroup dg, Sheet s)
/*      */   {
/*  231 */     this.drawingGroup = dg;
/*  232 */     this.msoDrawingRecord = mso;
/*  233 */     this.drawingData = dd;
/*  234 */     this.objRecord = obj;
/*  235 */     this.sheet = s;
/*  236 */     this.initialized = false;
/*  237 */     this.origin = Origin.READ;
/*  238 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/*  239 */     this.drawingNumber = (this.drawingData.getNumDrawings() - 1);
/*  240 */     this.drawingGroup.addDrawing(this);
/*      */     
/*  242 */     Assert.verify((mso != null) && (obj != null));
/*      */     
/*  244 */     initialize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Drawing(DrawingGroupObject dgo, DrawingGroup dg)
/*      */   {
/*  255 */     Drawing d = (Drawing)dgo;
/*  256 */     Assert.verify(d.origin == Origin.READ);
/*  257 */     this.msoDrawingRecord = d.msoDrawingRecord;
/*  258 */     this.objRecord = d.objRecord;
/*  259 */     this.initialized = false;
/*  260 */     this.origin = Origin.READ;
/*  261 */     this.drawingData = d.drawingData;
/*  262 */     this.drawingGroup = dg;
/*  263 */     this.drawingNumber = d.drawingNumber;
/*  264 */     this.drawingGroup.addDrawing(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Drawing(double x, double y, double w, double h, java.io.File image)
/*      */   {
/*  282 */     this.imageFile = image;
/*  283 */     this.initialized = true;
/*  284 */     this.origin = Origin.WRITE;
/*  285 */     this.x = x;
/*  286 */     this.y = y;
/*  287 */     this.width = w;
/*  288 */     this.height = h;
/*  289 */     this.referenceCount = 1;
/*  290 */     this.imageAnchorProperties = MOVE_WITH_CELLS;
/*  291 */     this.type = ShapeType.PICTURE_FRAME;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Drawing(double x, double y, double w, double h, byte[] image)
/*      */   {
/*  309 */     this.imageData = image;
/*  310 */     this.initialized = true;
/*  311 */     this.origin = Origin.WRITE;
/*  312 */     this.x = x;
/*  313 */     this.y = y;
/*  314 */     this.width = w;
/*  315 */     this.height = h;
/*  316 */     this.referenceCount = 1;
/*  317 */     this.imageAnchorProperties = MOVE_WITH_CELLS;
/*  318 */     this.type = ShapeType.PICTURE_FRAME;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initialize()
/*      */   {
/*  326 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/*  327 */     Assert.verify(this.readSpContainer != null);
/*      */     
/*  329 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*      */     
/*  331 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/*  332 */     this.shapeId = sp.getShapeId();
/*  333 */     this.objectId = this.objRecord.getObjectId();
/*  334 */     this.type = ShapeType.getType(sp.getShapeType());
/*      */     
/*  336 */     if (this.type == ShapeType.UNKNOWN)
/*      */     {
/*  338 */       logger.warn("Unknown shape type");
/*      */     }
/*      */     
/*  341 */     Opt opt = (Opt)this.readSpContainer.getChildren()[1];
/*      */     
/*  343 */     if (opt.getProperty(260) != null)
/*      */     {
/*  345 */       this.blipId = opt.getProperty(260).value;
/*      */     }
/*      */     
/*  348 */     if (opt.getProperty(261) != null)
/*      */     {
/*  350 */       this.imageFile = new java.io.File(opt.getProperty(261).stringValue);
/*      */ 
/*      */ 
/*      */     }
/*  354 */     else if (this.type == ShapeType.PICTURE_FRAME)
/*      */     {
/*  356 */       logger.warn("no filename property for drawing");
/*  357 */       this.imageFile = new java.io.File(Integer.toString(this.blipId));
/*      */     }
/*      */     
/*      */ 
/*  361 */     ClientAnchor clientAnchor = null;
/*  362 */     for (int i = 0; (i < children.length) && (clientAnchor == null); i++)
/*      */     {
/*  364 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*      */       {
/*  366 */         clientAnchor = (ClientAnchor)children[i];
/*      */       }
/*      */     }
/*      */     
/*  370 */     if (clientAnchor == null)
/*      */     {
/*  372 */       logger.warn("client anchor not found");
/*      */     }
/*      */     else
/*      */     {
/*  376 */       this.x = clientAnchor.getX1();
/*  377 */       this.y = clientAnchor.getY1();
/*  378 */       this.width = (clientAnchor.getX2() - this.x);
/*  379 */       this.height = (clientAnchor.getY2() - this.y);
/*  380 */       this.imageAnchorProperties = ImageAnchorProperties.getImageAnchorProperties(clientAnchor.getProperties());
/*      */     }
/*      */     
/*      */ 
/*  384 */     if (this.blipId == 0)
/*      */     {
/*  386 */       logger.warn("linked drawings are not supported");
/*      */     }
/*      */     
/*  389 */     this.initialized = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.io.File getImageFile()
/*      */   {
/*  399 */     return this.imageFile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getImageFilePath()
/*      */   {
/*  411 */     if (this.imageFile == null)
/*      */     {
/*      */ 
/*  414 */       return this.blipId != 0 ? Integer.toString(this.blipId) : "__new__image__";
/*      */     }
/*      */     
/*  417 */     return this.imageFile.getPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setObjectId(int objid, int bip, int sid)
/*      */   {
/*  430 */     this.objectId = objid;
/*  431 */     this.blipId = bip;
/*  432 */     this.shapeId = sid;
/*      */     
/*  434 */     if (this.origin == Origin.READ)
/*      */     {
/*  436 */       this.origin = Origin.READ_WRITE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int getObjectId()
/*      */   {
/*  447 */     if (!this.initialized)
/*      */     {
/*  449 */       initialize();
/*      */     }
/*      */     
/*  452 */     return this.objectId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getShapeId()
/*      */   {
/*  462 */     if (!this.initialized)
/*      */     {
/*  464 */       initialize();
/*      */     }
/*      */     
/*  467 */     return this.shapeId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int getBlipId()
/*      */   {
/*  477 */     if (!this.initialized)
/*      */     {
/*  479 */       initialize();
/*      */     }
/*      */     
/*  482 */     return this.blipId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MsoDrawingRecord getMsoDrawingRecord()
/*      */   {
/*  492 */     return this.msoDrawingRecord;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EscherContainer getSpContainer()
/*      */   {
/*  502 */     if (!this.initialized)
/*      */     {
/*  504 */       initialize();
/*      */     }
/*      */     
/*  507 */     if (this.origin == Origin.READ)
/*      */     {
/*  509 */       return getReadSpContainer();
/*      */     }
/*      */     
/*  512 */     SpContainer spContainer = new SpContainer();
/*  513 */     Sp sp = new Sp(this.type, this.shapeId, 2560);
/*  514 */     spContainer.add(sp);
/*  515 */     Opt opt = new Opt();
/*  516 */     opt.addProperty(260, true, false, this.blipId);
/*      */     
/*  518 */     if (this.type == ShapeType.PICTURE_FRAME)
/*      */     {
/*  520 */       String filePath = this.imageFile != null ? this.imageFile.getPath() : "";
/*  521 */       opt.addProperty(261, true, true, filePath.length() * 2, filePath);
/*  522 */       opt.addProperty(447, false, false, 65536);
/*  523 */       opt.addProperty(959, false, false, 524288);
/*  524 */       spContainer.add(opt);
/*      */     }
/*      */     
/*  527 */     ClientAnchor clientAnchor = new ClientAnchor(this.x, this.y, this.x + this.width, this.y + this.height, this.imageAnchorProperties.getValue());
/*      */     
/*      */ 
/*  530 */     spContainer.add(clientAnchor);
/*  531 */     ClientData clientData = new ClientData();
/*  532 */     spContainer.add(clientData);
/*      */     
/*  534 */     return spContainer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDrawingGroup(DrawingGroup dg)
/*      */   {
/*  545 */     this.drawingGroup = dg;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DrawingGroup getDrawingGroup()
/*      */   {
/*  555 */     return this.drawingGroup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Origin getOrigin()
/*      */   {
/*  565 */     return this.origin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getReferenceCount()
/*      */   {
/*  575 */     return this.referenceCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReferenceCount(int r)
/*      */   {
/*  585 */     this.referenceCount = r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getX()
/*      */   {
/*  595 */     if (!this.initialized)
/*      */     {
/*  597 */       initialize();
/*      */     }
/*  599 */     return this.x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setX(double x)
/*      */   {
/*  609 */     if (this.origin == Origin.READ)
/*      */     {
/*  611 */       if (!this.initialized)
/*      */       {
/*  613 */         initialize();
/*      */       }
/*  615 */       this.origin = Origin.READ_WRITE;
/*      */     }
/*      */     
/*  618 */     this.x = x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getY()
/*      */   {
/*  628 */     if (!this.initialized)
/*      */     {
/*  630 */       initialize();
/*      */     }
/*      */     
/*  633 */     return this.y;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setY(double y)
/*      */   {
/*  643 */     if (this.origin == Origin.READ)
/*      */     {
/*  645 */       if (!this.initialized)
/*      */       {
/*  647 */         initialize();
/*      */       }
/*  649 */       this.origin = Origin.READ_WRITE;
/*      */     }
/*      */     
/*  652 */     this.y = y;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getWidth()
/*      */   {
/*  663 */     if (!this.initialized)
/*      */     {
/*  665 */       initialize();
/*      */     }
/*      */     
/*  668 */     return this.width;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidth(double w)
/*      */   {
/*  678 */     if (this.origin == Origin.READ)
/*      */     {
/*  680 */       if (!this.initialized)
/*      */       {
/*  682 */         initialize();
/*      */       }
/*  684 */       this.origin = Origin.READ_WRITE;
/*      */     }
/*      */     
/*  687 */     this.width = w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getHeight()
/*      */   {
/*  697 */     if (!this.initialized)
/*      */     {
/*  699 */       initialize();
/*      */     }
/*      */     
/*  702 */     return this.height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeight(double h)
/*      */   {
/*  712 */     if (this.origin == Origin.READ)
/*      */     {
/*  714 */       if (!this.initialized)
/*      */       {
/*  716 */         initialize();
/*      */       }
/*  718 */       this.origin = Origin.READ_WRITE;
/*      */     }
/*      */     
/*  721 */     this.height = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private EscherContainer getReadSpContainer()
/*      */   {
/*  732 */     if (!this.initialized)
/*      */     {
/*  734 */       initialize();
/*      */     }
/*      */     
/*  737 */     return this.readSpContainer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getImageData()
/*      */   {
/*  747 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*      */     
/*  749 */     if (!this.initialized)
/*      */     {
/*  751 */       initialize();
/*      */     }
/*      */     
/*  754 */     return this.drawingGroup.getImageData(this.blipId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getImageBytes()
/*      */     throws IOException
/*      */   {
/*  764 */     if ((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE))
/*      */     {
/*  766 */       return getImageData();
/*      */     }
/*      */     
/*  769 */     Assert.verify(this.origin == Origin.WRITE);
/*      */     
/*  771 */     if (this.imageFile == null)
/*      */     {
/*  773 */       Assert.verify(this.imageData != null);
/*  774 */       return this.imageData;
/*      */     }
/*      */     
/*  777 */     byte[] data = new byte[(int)this.imageFile.length()];
/*  778 */     FileInputStream fis = new FileInputStream(this.imageFile);
/*  779 */     fis.read(data, 0, data.length);
/*  780 */     fis.close();
/*  781 */     return data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ShapeType getType()
/*      */   {
/*  791 */     return this.type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeAdditionalRecords(jxl.write.biff.File outputFile)
/*      */     throws IOException
/*      */   {
/*  802 */     if (this.origin == Origin.READ)
/*      */     {
/*  804 */       outputFile.write(this.objRecord);
/*  805 */       return;
/*      */     }
/*      */     
/*      */ 
/*  809 */     ObjRecord objrec = new ObjRecord(this.objectId, ObjRecord.PICTURE);
/*      */     
/*  811 */     outputFile.write(objrec);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeTailRecords(jxl.write.biff.File outputFile)
/*      */     throws IOException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getColumn()
/*      */   {
/*  833 */     return getX();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getRow()
/*      */   {
/*  843 */     return getY();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFirst()
/*      */   {
/*  855 */     return this.msoDrawingRecord.isFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFormObject()
/*      */   {
/*  867 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRow(int r)
/*      */   {
/*  877 */     if (this.y > r)
/*      */     {
/*  879 */       setY(r);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private double getWidthInPoints()
/*      */   {
/*  891 */     if (this.sheet == null)
/*      */     {
/*  893 */       logger.warn("calculating image width:  sheet is null");
/*  894 */       return 0.0D;
/*      */     }
/*      */     
/*      */ 
/*  898 */     int firstCol = (int)this.x;
/*  899 */     int lastCol = (int)Math.ceil(this.x + this.width) - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  908 */     CellView cellView = this.sheet.getColumnView(firstCol);
/*  909 */     int firstColWidth = cellView.getSize();
/*  910 */     double firstColImageWidth = (1.0D - (this.x - firstCol)) * firstColWidth;
/*  911 */     double pointSize = cellView.getFormat() != null ? cellView.getFormat().getFont().getPointSize() : 10.0D;
/*      */     
/*  913 */     double firstColWidthInPoints = firstColImageWidth * 0.59D * pointSize / 256.0D;
/*      */     
/*      */ 
/*      */ 
/*  917 */     int lastColWidth = 0;
/*  918 */     double lastColImageWidth = 0.0D;
/*  919 */     double lastColWidthInPoints = 0.0D;
/*  920 */     if (lastCol != firstCol)
/*      */     {
/*  922 */       cellView = this.sheet.getColumnView(lastCol);
/*  923 */       lastColWidth = cellView.getSize();
/*  924 */       lastColImageWidth = (this.x + this.width - lastCol) * lastColWidth;
/*  925 */       pointSize = cellView.getFormat() != null ? cellView.getFormat().getFont().getPointSize() : 10.0D;
/*      */       
/*  927 */       lastColWidthInPoints = lastColImageWidth * 0.59D * pointSize / 256.0D;
/*      */     }
/*      */     
/*      */ 
/*  931 */     double width = 0.0D;
/*  932 */     for (int i = 0; i < lastCol - firstCol - 1; i++)
/*      */     {
/*  934 */       cellView = this.sheet.getColumnView(firstCol + 1 + i);
/*  935 */       pointSize = cellView.getFormat() != null ? cellView.getFormat().getFont().getPointSize() : 10.0D;
/*      */       
/*  937 */       width += cellView.getSize() * 0.59D * pointSize / 256.0D;
/*      */     }
/*      */     
/*      */ 
/*  941 */     double widthInPoints = width + firstColWidthInPoints + lastColWidthInPoints;
/*      */     
/*      */ 
/*  944 */     return widthInPoints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private double getHeightInPoints()
/*      */   {
/*  955 */     if (this.sheet == null)
/*      */     {
/*  957 */       logger.warn("calculating image height:  sheet is null");
/*  958 */       return 0.0D;
/*      */     }
/*      */     
/*      */ 
/*  962 */     int firstRow = (int)this.y;
/*  963 */     int lastRow = (int)Math.ceil(this.y + this.height) - 1;
/*      */     
/*      */ 
/*      */ 
/*  967 */     int firstRowHeight = this.sheet.getRowView(firstRow).getSize();
/*  968 */     double firstRowImageHeight = (1.0D - (this.y - firstRow)) * firstRowHeight;
/*      */     
/*      */ 
/*      */ 
/*  972 */     int lastRowHeight = 0;
/*  973 */     double lastRowImageHeight = 0.0D;
/*  974 */     if (lastRow != firstRow)
/*      */     {
/*  976 */       lastRowHeight = this.sheet.getRowView(lastRow).getSize();
/*  977 */       lastRowImageHeight = (this.y + this.height - lastRow) * lastRowHeight;
/*      */     }
/*      */     
/*      */ 
/*  981 */     double height = 0.0D;
/*  982 */     for (int i = 0; i < lastRow - firstRow - 1; i++)
/*      */     {
/*  984 */       height += this.sheet.getRowView(firstRow + 1 + i).getSize();
/*      */     }
/*      */     
/*      */ 
/*  988 */     double heightInTwips = height + firstRowHeight + lastRowHeight;
/*      */     
/*      */ 
/*      */ 
/*  992 */     double heightInPoints = heightInTwips / 20.0D;
/*      */     
/*  994 */     return heightInPoints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getWidth(LengthUnit unit)
/*      */   {
/* 1005 */     double widthInPoints = getWidthInPoints();
/* 1006 */     return widthInPoints * LengthConverter.getConversionFactor(LengthUnit.POINTS, unit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getHeight(LengthUnit unit)
/*      */   {
/* 1018 */     double heightInPoints = getHeightInPoints();
/* 1019 */     return heightInPoints * LengthConverter.getConversionFactor(LengthUnit.POINTS, unit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getImageWidth()
/*      */   {
/* 1032 */     return getPngReader().getWidth();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getImageHeight()
/*      */   {
/* 1044 */     return getPngReader().getHeight();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getHorizontalResolution(LengthUnit unit)
/*      */   {
/* 1056 */     int res = getPngReader().getHorizontalResolution();
/* 1057 */     return res / LengthConverter.getConversionFactor(LengthUnit.METRES, unit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getVerticalResolution(LengthUnit unit)
/*      */   {
/* 1068 */     int res = getPngReader().getVerticalResolution();
/* 1069 */     return res / LengthConverter.getConversionFactor(LengthUnit.METRES, unit);
/*      */   }
/*      */   
/*      */   private PNGReader getPngReader()
/*      */   {
/* 1074 */     if (this.pngReader != null)
/*      */     {
/* 1076 */       return this.pngReader;
/*      */     }
/*      */     
/* 1079 */     byte[] imdata = null;
/* 1080 */     if ((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE))
/*      */     {
/* 1082 */       imdata = getImageData();
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/* 1088 */         imdata = getImageBytes();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1092 */         logger.warn("Could not read image file");
/* 1093 */         imdata = new byte[0];
/*      */       }
/*      */     }
/*      */     
/* 1097 */     this.pngReader = new PNGReader(imdata);
/* 1098 */     this.pngReader.read();
/* 1099 */     return this.pngReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setImageAnchor(ImageAnchorProperties iap)
/*      */   {
/* 1107 */     this.imageAnchorProperties = iap;
/*      */     
/* 1109 */     if (this.origin == Origin.READ)
/*      */     {
/* 1111 */       this.origin = Origin.READ_WRITE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ImageAnchorProperties getImageAnchor()
/*      */   {
/* 1120 */     if (!this.initialized)
/*      */     {
/* 1122 */       initialize();
/*      */     }
/*      */     
/* 1125 */     return this.imageAnchorProperties;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Drawing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */