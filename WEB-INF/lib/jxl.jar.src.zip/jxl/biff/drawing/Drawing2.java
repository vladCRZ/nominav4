/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Drawing2
/*     */   implements DrawingGroupObject
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(Drawing.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer readSpContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private boolean initialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private java.io.File imageFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] imageData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int blipId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double width;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double height;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer escherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Origin origin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingGroup drawingGroup;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DrawingData drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ShapeType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Drawing2(MsoDrawingRecord mso, DrawingData dd, DrawingGroup dg)
/*     */   {
/* 150 */     this.drawingGroup = dg;
/* 151 */     this.msoDrawingRecord = mso;
/* 152 */     this.drawingData = dd;
/* 153 */     this.initialized = false;
/* 154 */     this.origin = Origin.READ;
/*     */     
/* 156 */     this.drawingData.addRawData(this.msoDrawingRecord.getData());
/* 157 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 159 */     Assert.verify(mso != null);
/*     */     
/* 161 */     initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Drawing2(DrawingGroupObject dgo, DrawingGroup dg)
/*     */   {
/* 172 */     Drawing2 d = (Drawing2)dgo;
/* 173 */     Assert.verify(d.origin == Origin.READ);
/* 174 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 175 */     this.initialized = false;
/* 176 */     this.origin = Origin.READ;
/* 177 */     this.drawingData = d.drawingData;
/* 178 */     this.drawingGroup = dg;
/* 179 */     this.drawingNumber = d.drawingNumber;
/* 180 */     this.drawingGroup.addDrawing(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Drawing2(double x, double y, double w, double h, java.io.File image)
/*     */   {
/* 198 */     this.imageFile = image;
/* 199 */     this.initialized = true;
/* 200 */     this.origin = Origin.WRITE;
/* 201 */     this.x = x;
/* 202 */     this.y = y;
/* 203 */     this.width = w;
/* 204 */     this.height = h;
/* 205 */     this.referenceCount = 1;
/* 206 */     this.type = ShapeType.PICTURE_FRAME;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Drawing2(double x, double y, double w, double h, byte[] image)
/*     */   {
/* 224 */     this.imageData = image;
/* 225 */     this.initialized = true;
/* 226 */     this.origin = Origin.WRITE;
/* 227 */     this.x = x;
/* 228 */     this.y = y;
/* 229 */     this.width = w;
/* 230 */     this.height = h;
/* 231 */     this.referenceCount = 1;
/* 232 */     this.type = ShapeType.PICTURE_FRAME;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 240 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setObjectId(int objid, int bip, int sid)
/*     */   {
/* 253 */     this.objectId = objid;
/* 254 */     this.blipId = bip;
/* 255 */     this.shapeId = sid;
/*     */     
/* 257 */     if (this.origin == Origin.READ)
/*     */     {
/* 259 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getObjectId()
/*     */   {
/* 270 */     if (!this.initialized)
/*     */     {
/* 272 */       initialize();
/*     */     }
/*     */     
/* 275 */     return this.objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getShapeId()
/*     */   {
/* 285 */     if (!this.initialized)
/*     */     {
/* 287 */       initialize();
/*     */     }
/*     */     
/* 290 */     return this.shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getBlipId()
/*     */   {
/* 300 */     if (!this.initialized)
/*     */     {
/* 302 */       initialize();
/*     */     }
/*     */     
/* 305 */     return this.blipId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MsoDrawingRecord getMsoDrawingRecord()
/*     */   {
/* 315 */     return this.msoDrawingRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainer getSpContainer()
/*     */   {
/* 325 */     if (!this.initialized)
/*     */     {
/* 327 */       initialize();
/*     */     }
/*     */     
/* 330 */     Assert.verify(this.origin == Origin.READ);
/*     */     
/* 332 */     return getReadSpContainer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingGroup(DrawingGroup dg)
/*     */   {
/* 343 */     this.drawingGroup = dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup getDrawingGroup()
/*     */   {
/* 353 */     return this.drawingGroup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Origin getOrigin()
/*     */   {
/* 363 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReferenceCount()
/*     */   {
/* 373 */     return this.referenceCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReferenceCount(int r)
/*     */   {
/* 383 */     this.referenceCount = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getX()
/*     */   {
/* 393 */     if (!this.initialized)
/*     */     {
/* 395 */       initialize();
/*     */     }
/* 397 */     return this.x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setX(double x)
/*     */   {
/* 407 */     if (this.origin == Origin.READ)
/*     */     {
/* 409 */       if (!this.initialized)
/*     */       {
/* 411 */         initialize();
/*     */       }
/* 413 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 416 */     this.x = x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getY()
/*     */   {
/* 426 */     if (!this.initialized)
/*     */     {
/* 428 */       initialize();
/*     */     }
/*     */     
/* 431 */     return this.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setY(double y)
/*     */   {
/* 441 */     if (this.origin == Origin.READ)
/*     */     {
/* 443 */       if (!this.initialized)
/*     */       {
/* 445 */         initialize();
/*     */       }
/* 447 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 450 */     this.y = y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getWidth()
/*     */   {
/* 461 */     if (!this.initialized)
/*     */     {
/* 463 */       initialize();
/*     */     }
/*     */     
/* 466 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(double w)
/*     */   {
/* 476 */     if (this.origin == Origin.READ)
/*     */     {
/* 478 */       if (!this.initialized)
/*     */       {
/* 480 */         initialize();
/*     */       }
/* 482 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 485 */     this.width = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getHeight()
/*     */   {
/* 495 */     if (!this.initialized)
/*     */     {
/* 497 */       initialize();
/*     */     }
/*     */     
/* 500 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(double h)
/*     */   {
/* 510 */     if (this.origin == Origin.READ)
/*     */     {
/* 512 */       if (!this.initialized)
/*     */       {
/* 514 */         initialize();
/*     */       }
/* 516 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */     
/* 519 */     this.height = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer getReadSpContainer()
/*     */   {
/* 530 */     if (!this.initialized)
/*     */     {
/* 532 */       initialize();
/*     */     }
/*     */     
/* 535 */     return this.readSpContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageData()
/*     */   {
/* 545 */     Assert.verify(false);
/* 546 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*     */     
/* 548 */     if (!this.initialized)
/*     */     {
/* 550 */       initialize();
/*     */     }
/*     */     
/* 553 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getImageBytes()
/*     */     throws IOException
/*     */   {
/* 563 */     Assert.verify(false);
/* 564 */     if ((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE))
/*     */     {
/* 566 */       return getImageData();
/*     */     }
/*     */     
/* 569 */     Assert.verify(this.origin == Origin.WRITE);
/*     */     
/* 571 */     if (this.imageFile == null)
/*     */     {
/* 573 */       Assert.verify(this.imageData != null);
/* 574 */       return this.imageData;
/*     */     }
/*     */     
/* 577 */     byte[] data = new byte[(int)this.imageFile.length()];
/* 578 */     FileInputStream fis = new FileInputStream(this.imageFile);
/* 579 */     fis.read(data, 0, data.length);
/* 580 */     fis.close();
/* 581 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ShapeType getType()
/*     */   {
/* 591 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAdditionalRecords(jxl.write.biff.File outputFile)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTailRecords(jxl.write.biff.File outputFile)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getColumn()
/*     */   {
/* 625 */     return getX();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getRow()
/*     */   {
/* 635 */     return getY();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */   {
/* 647 */     return this.msoDrawingRecord.isFirst();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFormObject()
/*     */   {
/* 659 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int r)
/*     */   {
/* 669 */     if (this.y > r)
/*     */     {
/* 671 */       setY(r);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImageFilePath()
/*     */   {
/* 684 */     Assert.verify(false);
/* 685 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Drawing2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */