/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawingData
/*     */   implements EscherStream
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(DrawingData.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numDrawings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherRecord[] spContainers;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingData()
/*     */   {
/*  63 */     this.numDrawings = 0;
/*  64 */     this.drawingData = null;
/*  65 */     this.initialized = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/*  73 */     EscherRecordData er = new EscherRecordData(this, 0);
/*  74 */     Assert.verify(er.isContainer());
/*     */     
/*  76 */     EscherContainer dgContainer = new EscherContainer(er);
/*  77 */     EscherRecord[] children = dgContainer.getChildren();
/*     */     
/*  79 */     children = dgContainer.getChildren();
/*     */     
/*     */ 
/*  82 */     EscherContainer spgrContainer = null;
/*     */     
/*  84 */     for (int i = 0; (i < children.length) && (spgrContainer == null); i++)
/*     */     {
/*  86 */       EscherRecord child = children[i];
/*  87 */       if (child.getType() == EscherRecordType.SPGR_CONTAINER)
/*     */       {
/*  89 */         spgrContainer = (EscherContainer)child;
/*     */       }
/*     */     }
/*  92 */     Assert.verify(spgrContainer != null);
/*     */     
/*  94 */     EscherRecord[] spgrChildren = spgrContainer.getChildren();
/*     */     
/*     */ 
/*  97 */     boolean nestedContainers = false;
/*  98 */     for (int i = 0; (i < spgrChildren.length) && (!nestedContainers); i++)
/*     */     {
/* 100 */       if (spgrChildren[i].getType() == EscherRecordType.SPGR_CONTAINER)
/*     */       {
/* 102 */         nestedContainers = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 108 */     if (!nestedContainers)
/*     */     {
/* 110 */       this.spContainers = spgrChildren;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 115 */       ArrayList sps = new ArrayList();
/* 116 */       getSpContainers(spgrContainer, sps);
/* 117 */       this.spContainers = new EscherRecord[sps.size()];
/* 118 */       this.spContainers = ((EscherRecord[])sps.toArray(this.spContainers));
/*     */     }
/*     */     
/* 121 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getSpContainers(EscherContainer spgrContainer, ArrayList sps)
/*     */   {
/* 132 */     EscherRecord[] spgrChildren = spgrContainer.getChildren();
/* 133 */     for (int i = 0; i < spgrChildren.length; i++)
/*     */     {
/* 135 */       if (spgrChildren[i].getType() == EscherRecordType.SP_CONTAINER)
/*     */       {
/* 137 */         sps.add(spgrChildren[i]);
/*     */       }
/* 139 */       else if (spgrChildren[i].getType() == EscherRecordType.SPGR_CONTAINER)
/*     */       {
/* 141 */         getSpContainers((EscherContainer)spgrChildren[i], sps);
/*     */       }
/*     */       else
/*     */       {
/* 145 */         logger.warn("Spgr Containers contains a record other than Sp/Spgr containers");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addData(byte[] data)
/*     */   {
/* 158 */     addRawData(data);
/* 159 */     this.numDrawings += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRawData(byte[] data)
/*     */   {
/* 171 */     if (this.drawingData == null)
/*     */     {
/* 173 */       this.drawingData = data;
/* 174 */       return;
/*     */     }
/*     */     
/*     */ 
/* 178 */     byte[] newArray = new byte[this.drawingData.length + data.length];
/* 179 */     System.arraycopy(this.drawingData, 0, newArray, 0, this.drawingData.length);
/* 180 */     System.arraycopy(data, 0, newArray, this.drawingData.length, data.length);
/* 181 */     this.drawingData = newArray;
/*     */     
/*     */ 
/* 184 */     this.initialized = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int getNumDrawings()
/*     */   {
/* 194 */     return this.numDrawings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   EscherContainer getSpContainer(int drawingNum)
/*     */   {
/* 205 */     if (!this.initialized)
/*     */     {
/* 207 */       initialize();
/*     */     }
/*     */     
/* 210 */     if (drawingNum + 1 >= this.spContainers.length)
/*     */     {
/* 212 */       throw new DrawingDataException();
/*     */     }
/*     */     
/* 215 */     EscherContainer spContainer = (EscherContainer)this.spContainers[(drawingNum + 1)];
/*     */     
/*     */ 
/* 218 */     Assert.verify(spContainer != null);
/*     */     
/* 220 */     return spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 230 */     return this.drawingData;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\DrawingData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */