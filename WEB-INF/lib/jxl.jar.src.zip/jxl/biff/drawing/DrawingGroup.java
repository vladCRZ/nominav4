/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawingGroup
/*     */   implements EscherStream
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(DrawingGroup.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] drawingData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainer escherData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BStoreContainer bstoreContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList drawings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numBlips;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numCharts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int drawingGroupId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean drawingsOmitted;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Origin origin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private HashMap imageFiles;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int maxObjectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int maxShapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup(Origin o)
/*     */   {
/* 118 */     this.origin = o;
/* 119 */     this.initialized = (o == Origin.WRITE);
/* 120 */     this.drawings = new ArrayList();
/* 121 */     this.imageFiles = new HashMap();
/* 122 */     this.drawingsOmitted = false;
/* 123 */     this.maxObjectId = 1;
/* 124 */     this.maxShapeId = 1024;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingGroup(DrawingGroup dg)
/*     */   {
/* 137 */     this.drawingData = dg.drawingData;
/* 138 */     this.escherData = dg.escherData;
/* 139 */     this.bstoreContainer = dg.bstoreContainer;
/* 140 */     this.initialized = dg.initialized;
/* 141 */     this.drawingData = dg.drawingData;
/* 142 */     this.escherData = dg.escherData;
/* 143 */     this.bstoreContainer = dg.bstoreContainer;
/* 144 */     this.numBlips = dg.numBlips;
/* 145 */     this.numCharts = dg.numCharts;
/* 146 */     this.drawingGroupId = dg.drawingGroupId;
/* 147 */     this.drawingsOmitted = dg.drawingsOmitted;
/* 148 */     this.origin = dg.origin;
/* 149 */     this.imageFiles = ((HashMap)dg.imageFiles.clone());
/* 150 */     this.maxObjectId = dg.maxObjectId;
/* 151 */     this.maxShapeId = dg.maxShapeId;
/*     */     
/*     */ 
/*     */ 
/* 155 */     this.drawings = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(MsoDrawingGroupRecord mso)
/*     */   {
/* 169 */     addData(mso.getData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Record cont)
/*     */   {
/* 180 */     addData(cont.getData());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addData(byte[] msodata)
/*     */   {
/* 190 */     if (this.drawingData == null)
/*     */     {
/* 192 */       this.drawingData = new byte[msodata.length];
/* 193 */       System.arraycopy(msodata, 0, this.drawingData, 0, msodata.length);
/* 194 */       return;
/*     */     }
/*     */     
/*     */ 
/* 198 */     byte[] newdata = new byte[this.drawingData.length + msodata.length];
/* 199 */     System.arraycopy(this.drawingData, 0, newdata, 0, this.drawingData.length);
/* 200 */     System.arraycopy(msodata, 0, newdata, this.drawingData.length, msodata.length);
/* 201 */     this.drawingData = newdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void addDrawing(DrawingGroupObject d)
/*     */   {
/* 211 */     this.drawings.add(d);
/* 212 */     this.maxObjectId = Math.max(this.maxObjectId, d.getObjectId());
/* 213 */     this.maxShapeId = Math.max(this.maxShapeId, d.getShapeId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Chart c)
/*     */   {
/* 223 */     this.numCharts += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(DrawingGroupObject d)
/*     */   {
/* 233 */     if (this.origin == Origin.READ)
/*     */     {
/* 235 */       this.origin = Origin.READ_WRITE;
/* 236 */       BStoreContainer bsc = getBStoreContainer();
/* 237 */       Dgg dgg = (Dgg)this.escherData.getChildren()[0];
/* 238 */       this.drawingGroupId = (dgg.getCluster(1).drawingGroupId - this.numBlips - 1);
/* 239 */       this.numBlips = (bsc != null ? bsc.getNumBlips() : 0);
/*     */       
/* 241 */       if (bsc != null)
/*     */       {
/* 243 */         Assert.verify(this.numBlips == bsc.getNumBlips());
/*     */       }
/*     */     }
/*     */     
/* 247 */     if (!(d instanceof Drawing))
/*     */     {
/*     */ 
/*     */ 
/* 251 */       this.maxObjectId += 1;
/* 252 */       this.maxShapeId += 1;
/* 253 */       d.setDrawingGroup(this);
/* 254 */       d.setObjectId(this.maxObjectId, this.numBlips + 1, this.maxShapeId);
/* 255 */       if (this.drawings.size() > this.maxObjectId)
/*     */       {
/* 257 */         logger.warn("drawings length " + this.drawings.size() + " exceeds the max object id " + this.maxObjectId);
/*     */       }
/*     */       
/*     */ 
/* 261 */       return;
/*     */     }
/*     */     
/* 264 */     Drawing drawing = (Drawing)d;
/*     */     
/*     */ 
/* 267 */     Drawing refImage = (Drawing)this.imageFiles.get(d.getImageFilePath());
/*     */     
/*     */ 
/* 270 */     if (refImage == null)
/*     */     {
/*     */ 
/*     */ 
/* 274 */       this.maxObjectId += 1;
/* 275 */       this.maxShapeId += 1;
/* 276 */       this.drawings.add(drawing);
/* 277 */       drawing.setDrawingGroup(this);
/* 278 */       drawing.setObjectId(this.maxObjectId, this.numBlips + 1, this.maxShapeId);
/* 279 */       this.numBlips += 1;
/* 280 */       this.imageFiles.put(drawing.getImageFilePath(), drawing);
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 287 */       refImage.setReferenceCount(refImage.getReferenceCount() + 1);
/* 288 */       drawing.setDrawingGroup(this);
/* 289 */       drawing.setObjectId(refImage.getObjectId(), refImage.getBlipId(), refImage.getShapeId());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(DrawingGroupObject d)
/*     */   {
/* 304 */     if (getBStoreContainer() == null)
/*     */     {
/* 306 */       return;
/*     */     }
/*     */     
/* 309 */     if (this.origin == Origin.READ)
/*     */     {
/* 311 */       this.origin = Origin.READ_WRITE;
/* 312 */       this.numBlips = getBStoreContainer().getNumBlips();
/* 313 */       Dgg dgg = (Dgg)this.escherData.getChildren()[0];
/* 314 */       this.drawingGroupId = (dgg.getCluster(1).drawingGroupId - this.numBlips - 1);
/*     */     }
/*     */     
/*     */ 
/* 318 */     EscherRecord[] children = getBStoreContainer().getChildren();
/* 319 */     BlipStoreEntry bse = (BlipStoreEntry)children[(d.getBlipId() - 1)];
/*     */     
/* 321 */     bse.dereference();
/*     */     
/* 323 */     if (bse.getReferenceCount() == 0)
/*     */     {
/*     */ 
/* 326 */       getBStoreContainer().remove(bse);
/*     */       
/*     */ 
/* 329 */       for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */       {
/* 331 */         DrawingGroupObject drawing = (DrawingGroupObject)i.next();
/*     */         
/* 333 */         if (drawing.getBlipId() > d.getBlipId())
/*     */         {
/* 335 */           drawing.setObjectId(drawing.getObjectId(), drawing.getBlipId() - 1, drawing.getShapeId());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 341 */       this.numBlips -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 351 */     EscherRecordData er = new EscherRecordData(this, 0);
/*     */     
/* 353 */     Assert.verify(er.isContainer());
/*     */     
/* 355 */     this.escherData = new EscherContainer(er);
/*     */     
/* 357 */     Assert.verify(this.escherData.getLength() == this.drawingData.length);
/* 358 */     Assert.verify(this.escherData.getType() == EscherRecordType.DGG_CONTAINER);
/*     */     
/* 360 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BStoreContainer getBStoreContainer()
/*     */   {
/* 370 */     if (this.bstoreContainer == null)
/*     */     {
/* 372 */       if (!this.initialized)
/*     */       {
/* 374 */         initialize();
/*     */       }
/*     */       
/* 377 */       EscherRecord[] children = this.escherData.getChildren();
/* 378 */       if ((children.length > 1) && (children[1].getType() == EscherRecordType.BSTORE_CONTAINER))
/*     */       {
/*     */ 
/* 381 */         this.bstoreContainer = ((BStoreContainer)children[1]);
/*     */       }
/*     */     }
/*     */     
/* 385 */     return this.bstoreContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 395 */     return this.drawingData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/* 406 */     if (this.origin == Origin.WRITE)
/*     */     {
/* 408 */       DggContainer dggContainer = new DggContainer();
/*     */       
/* 410 */       Dgg dgg = new Dgg(this.numBlips + this.numCharts + 1, this.numBlips);
/*     */       
/* 412 */       dgg.addCluster(1, 0);
/* 413 */       dgg.addCluster(this.numBlips + 1, 0);
/*     */       
/* 415 */       dggContainer.add(dgg);
/*     */       
/* 417 */       int drawingsAdded = 0;
/* 418 */       BStoreContainer bstoreCont = new BStoreContainer();
/*     */       
/*     */ 
/* 421 */       for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */       {
/* 423 */         Object o = i.next();
/* 424 */         if ((o instanceof Drawing))
/*     */         {
/* 426 */           Drawing d = (Drawing)o;
/* 427 */           BlipStoreEntry bse = new BlipStoreEntry(d);
/*     */           
/* 429 */           bstoreCont.add(bse);
/* 430 */           drawingsAdded++;
/*     */         }
/*     */       }
/* 433 */       if (drawingsAdded > 0)
/*     */       {
/* 435 */         bstoreCont.setNumBlips(drawingsAdded);
/* 436 */         dggContainer.add(bstoreCont);
/*     */       }
/*     */       
/* 439 */       Opt opt = new Opt();
/*     */       
/* 441 */       dggContainer.add(opt);
/*     */       
/* 443 */       SplitMenuColors splitMenuColors = new SplitMenuColors();
/* 444 */       dggContainer.add(splitMenuColors);
/*     */       
/* 446 */       this.drawingData = dggContainer.getData();
/*     */     }
/* 448 */     else if (this.origin == Origin.READ_WRITE)
/*     */     {
/* 450 */       DggContainer dggContainer = new DggContainer();
/*     */       
/* 452 */       Dgg dgg = new Dgg(this.numBlips + this.numCharts + 1, this.numBlips);
/*     */       
/* 454 */       dgg.addCluster(1, 0);
/* 455 */       dgg.addCluster(this.drawingGroupId + this.numBlips + 1, 0);
/*     */       
/* 457 */       dggContainer.add(dgg);
/*     */       
/* 459 */       BStoreContainer bstoreCont = new BStoreContainer();
/* 460 */       bstoreCont.setNumBlips(this.numBlips);
/*     */       
/*     */ 
/* 463 */       BStoreContainer readBStoreContainer = getBStoreContainer();
/*     */       
/* 465 */       if (readBStoreContainer != null)
/*     */       {
/* 467 */         EscherRecord[] children = readBStoreContainer.getChildren();
/* 468 */         for (int i = 0; i < children.length; i++)
/*     */         {
/* 470 */           BlipStoreEntry bse = (BlipStoreEntry)children[i];
/* 471 */           bstoreCont.add(bse);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 476 */       for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */       {
/* 478 */         DrawingGroupObject dgo = (DrawingGroupObject)i.next();
/* 479 */         if ((dgo instanceof Drawing))
/*     */         {
/* 481 */           Drawing d = (Drawing)dgo;
/* 482 */           if (d.getOrigin() == Origin.WRITE)
/*     */           {
/* 484 */             BlipStoreEntry bse = new BlipStoreEntry(d);
/* 485 */             bstoreCont.add(bse);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 490 */       dggContainer.add(bstoreCont);
/*     */       
/* 492 */       Opt opt = new Opt();
/*     */       
/* 494 */       opt.addProperty(191, false, false, 524296);
/* 495 */       opt.addProperty(385, false, false, 134217737);
/* 496 */       opt.addProperty(448, false, false, 134217792);
/*     */       
/* 498 */       dggContainer.add(opt);
/*     */       
/* 500 */       SplitMenuColors splitMenuColors = new SplitMenuColors();
/* 501 */       dggContainer.add(splitMenuColors);
/*     */       
/* 503 */       this.drawingData = dggContainer.getData();
/*     */     }
/*     */     
/* 506 */     MsoDrawingGroupRecord msodg = new MsoDrawingGroupRecord(this.drawingData);
/* 507 */     outputFile.write(msodg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int getNumberOfBlips()
/*     */   {
/* 517 */     return this.numBlips;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getImageData(int blipId)
/*     */   {
/* 529 */     this.numBlips = getBStoreContainer().getNumBlips();
/*     */     
/* 531 */     Assert.verify(blipId <= this.numBlips);
/* 532 */     Assert.verify((this.origin == Origin.READ) || (this.origin == Origin.READ_WRITE));
/*     */     
/*     */ 
/* 535 */     EscherRecord[] children = getBStoreContainer().getChildren();
/* 536 */     BlipStoreEntry bse = (BlipStoreEntry)children[(blipId - 1)];
/*     */     
/* 538 */     return bse.getImageData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawingsOmitted(MsoDrawingRecord mso, ObjRecord obj)
/*     */   {
/* 550 */     this.drawingsOmitted = true;
/*     */     
/* 552 */     if (obj != null)
/*     */     {
/* 554 */       this.maxObjectId = Math.max(this.maxObjectId, obj.getObjectId());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasDrawingsOmitted()
/*     */   {
/* 565 */     return this.drawingsOmitted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateData(DrawingGroup dg)
/*     */   {
/* 580 */     this.drawingsOmitted = dg.drawingsOmitted;
/* 581 */     this.maxObjectId = dg.maxObjectId;
/* 582 */     this.maxShapeId = dg.maxShapeId;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\DrawingGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */