/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EscherContainer
/*     */   extends EscherRecord
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(EscherContainer.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList children;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainer(EscherRecordData erd)
/*     */   {
/*  56 */     super(erd);
/*  57 */     this.initialized = false;
/*  58 */     this.children = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EscherContainer(EscherRecordType type)
/*     */   {
/*  68 */     super(type);
/*  69 */     setContainer(true);
/*  70 */     this.children = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherRecord[] getChildren()
/*     */   {
/*  80 */     if (!this.initialized)
/*     */     {
/*  82 */       initialize();
/*     */     }
/*     */     
/*  85 */     Object[] ca = this.children.toArray(new EscherRecord[this.children.size()]);
/*     */     
/*  87 */     return (EscherRecord[])ca;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(EscherRecord child)
/*     */   {
/*  97 */     this.children.add(child);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(EscherRecord child)
/*     */   {
/* 107 */     boolean result = this.children.remove(child);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/* 115 */     int curpos = getPos() + 8;
/* 116 */     int endpos = Math.min(getPos() + getLength(), getStreamLength());
/*     */     
/* 118 */     EscherRecord newRecord = null;
/*     */     
/* 120 */     while (curpos < endpos)
/*     */     {
/* 122 */       EscherRecordData erd = new EscherRecordData(getEscherStream(), curpos);
/*     */       
/* 124 */       EscherRecordType type = erd.getType();
/* 125 */       if (type == EscherRecordType.DGG)
/*     */       {
/* 127 */         newRecord = new Dgg(erd);
/*     */       }
/* 129 */       else if (type == EscherRecordType.DG)
/*     */       {
/* 131 */         newRecord = new Dg(erd);
/*     */       }
/* 133 */       else if (type == EscherRecordType.BSTORE_CONTAINER)
/*     */       {
/* 135 */         newRecord = new BStoreContainer(erd);
/*     */       }
/* 137 */       else if (type == EscherRecordType.SPGR_CONTAINER)
/*     */       {
/* 139 */         newRecord = new SpgrContainer(erd);
/*     */       }
/* 141 */       else if (type == EscherRecordType.SP_CONTAINER)
/*     */       {
/* 143 */         newRecord = new SpContainer(erd);
/*     */       }
/* 145 */       else if (type == EscherRecordType.SPGR)
/*     */       {
/* 147 */         newRecord = new Spgr(erd);
/*     */       }
/* 149 */       else if (type == EscherRecordType.SP)
/*     */       {
/* 151 */         newRecord = new Sp(erd);
/*     */       }
/* 153 */       else if (type == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 155 */         newRecord = new ClientAnchor(erd);
/*     */       }
/* 157 */       else if (type == EscherRecordType.CLIENT_DATA)
/*     */       {
/* 159 */         newRecord = new ClientData(erd);
/*     */       }
/* 161 */       else if (type == EscherRecordType.BSE)
/*     */       {
/* 163 */         newRecord = new BlipStoreEntry(erd);
/*     */       }
/* 165 */       else if (type == EscherRecordType.OPT)
/*     */       {
/* 167 */         newRecord = new Opt(erd);
/*     */       }
/* 169 */       else if (type == EscherRecordType.SPLIT_MENU_COLORS)
/*     */       {
/* 171 */         newRecord = new SplitMenuColors(erd);
/*     */       }
/* 173 */       else if (type == EscherRecordType.CLIENT_TEXT_BOX)
/*     */       {
/* 175 */         newRecord = new ClientTextBox(erd);
/*     */       }
/*     */       else
/*     */       {
/* 179 */         newRecord = new EscherAtom(erd);
/*     */       }
/*     */       
/* 182 */       this.children.add(newRecord);
/* 183 */       curpos += newRecord.getLength();
/*     */     }
/*     */     
/* 186 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getData()
/*     */   {
/* 196 */     if (!this.initialized)
/*     */     {
/* 198 */       initialize();
/*     */     }
/*     */     
/* 201 */     byte[] data = new byte[0];
/* 202 */     for (Iterator i = this.children.iterator(); i.hasNext();)
/*     */     {
/* 204 */       EscherRecord er = (EscherRecord)i.next();
/* 205 */       byte[] childData = er.getData();
/*     */       
/* 207 */       if (childData != null)
/*     */       {
/* 209 */         byte[] newData = new byte[data.length + childData.length];
/* 210 */         System.arraycopy(data, 0, newData, 0, data.length);
/* 211 */         System.arraycopy(childData, 0, newData, data.length, childData.length);
/* 212 */         data = newData;
/*     */       }
/*     */     }
/*     */     
/* 216 */     return setHeaderData(data);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\EscherContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */