/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherDisplay
/*     */ {
/*     */   private EscherStream stream;
/*     */   private BufferedWriter writer;
/*     */   
/*     */   public EscherDisplay(EscherStream s, BufferedWriter bw)
/*     */   {
/*  51 */     this.stream = s;
/*  52 */     this.writer = bw;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void display()
/*     */     throws IOException
/*     */   {
/*  62 */     EscherRecordData er = new EscherRecordData(this.stream, 0);
/*  63 */     EscherContainer ec = new EscherContainer(er);
/*  64 */     displayContainer(ec, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void displayContainer(EscherContainer ec, int level)
/*     */     throws IOException
/*     */   {
/*  77 */     displayRecord(ec, level);
/*     */     
/*     */ 
/*  80 */     level++;
/*     */     
/*  82 */     EscherRecord[] children = ec.getChildren();
/*     */     
/*  84 */     for (int i = 0; i < children.length; i++)
/*     */     {
/*  86 */       EscherRecord er = children[i];
/*  87 */       if (er.getEscherData().isContainer())
/*     */       {
/*  89 */         displayContainer((EscherContainer)er, level);
/*     */       }
/*     */       else
/*     */       {
/*  93 */         displayRecord(er, level);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void displayRecord(EscherRecord er, int level)
/*     */     throws IOException
/*     */   {
/* 108 */     indent(level);
/*     */     
/* 110 */     EscherRecordType type = er.getType();
/*     */     
/*     */ 
/* 113 */     this.writer.write(Integer.toString(type.getValue(), 16));
/* 114 */     this.writer.write(" - ");
/*     */     
/*     */ 
/* 117 */     if (type == EscherRecordType.DGG_CONTAINER)
/*     */     {
/* 119 */       this.writer.write("Dgg Container");
/* 120 */       this.writer.newLine();
/*     */     }
/* 122 */     else if (type == EscherRecordType.BSTORE_CONTAINER)
/*     */     {
/* 124 */       this.writer.write("BStore Container");
/* 125 */       this.writer.newLine();
/*     */     }
/* 127 */     else if (type == EscherRecordType.DG_CONTAINER)
/*     */     {
/* 129 */       this.writer.write("Dg Container");
/* 130 */       this.writer.newLine();
/*     */     }
/* 132 */     else if (type == EscherRecordType.SPGR_CONTAINER)
/*     */     {
/* 134 */       this.writer.write("Spgr Container");
/* 135 */       this.writer.newLine();
/*     */     }
/* 137 */     else if (type == EscherRecordType.SP_CONTAINER)
/*     */     {
/* 139 */       this.writer.write("Sp Container");
/* 140 */       this.writer.newLine();
/*     */     }
/* 142 */     else if (type == EscherRecordType.DGG)
/*     */     {
/* 144 */       this.writer.write("Dgg");
/* 145 */       this.writer.newLine();
/*     */     }
/* 147 */     else if (type == EscherRecordType.BSE)
/*     */     {
/* 149 */       this.writer.write("Bse");
/* 150 */       this.writer.newLine();
/*     */     }
/* 152 */     else if (type == EscherRecordType.DG)
/*     */     {
/* 154 */       Dg dg = new Dg(er.getEscherData());
/* 155 */       this.writer.write("Dg:  drawing id " + dg.getDrawingId() + " shape count " + dg.getShapeCount());
/*     */       
/* 157 */       this.writer.newLine();
/*     */     }
/* 159 */     else if (type == EscherRecordType.SPGR)
/*     */     {
/* 161 */       this.writer.write("Spgr");
/* 162 */       this.writer.newLine();
/*     */     }
/* 164 */     else if (type == EscherRecordType.SP)
/*     */     {
/* 166 */       Sp sp = new Sp(er.getEscherData());
/* 167 */       this.writer.write("Sp:  shape id " + sp.getShapeId() + " shape type " + sp.getShapeType());
/*     */       
/* 169 */       this.writer.newLine();
/*     */     }
/* 171 */     else if (type == EscherRecordType.OPT)
/*     */     {
/* 173 */       Opt opt = new Opt(er.getEscherData());
/* 174 */       Opt.Property p260 = opt.getProperty(260);
/* 175 */       Opt.Property p261 = opt.getProperty(261);
/* 176 */       this.writer.write("Opt (value, stringValue): ");
/* 177 */       if (p260 != null)
/*     */       {
/* 179 */         this.writer.write("260: " + p260.value + ", " + p260.stringValue + ";");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 184 */       if (p261 != null)
/*     */       {
/* 186 */         this.writer.write("261: " + p261.value + ", " + p261.stringValue + ";");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 191 */       this.writer.newLine();
/*     */     }
/* 193 */     else if (type == EscherRecordType.CLIENT_ANCHOR)
/*     */     {
/* 195 */       this.writer.write("Client Anchor");
/* 196 */       this.writer.newLine();
/*     */     }
/* 198 */     else if (type == EscherRecordType.CLIENT_DATA)
/*     */     {
/* 200 */       this.writer.write("Client Data");
/* 201 */       this.writer.newLine();
/*     */     }
/* 203 */     else if (type == EscherRecordType.CLIENT_TEXT_BOX)
/*     */     {
/* 205 */       this.writer.write("Client Text Box");
/* 206 */       this.writer.newLine();
/*     */     }
/* 208 */     else if (type == EscherRecordType.SPLIT_MENU_COLORS)
/*     */     {
/* 210 */       this.writer.write("Split Menu Colors");
/* 211 */       this.writer.newLine();
/*     */     }
/*     */     else
/*     */     {
/* 215 */       this.writer.write("???");
/* 216 */       this.writer.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void indent(int level)
/*     */     throws IOException
/*     */   {
/* 228 */     for (int i = 0; i < level * 2; i++)
/*     */     {
/* 230 */       this.writer.write(32);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\EscherDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */