/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class EscherRecord
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(EscherRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherRecordData data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final int HEADER_LENGTH = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EscherRecord(EscherRecordData erd)
/*     */   {
/*  54 */     this.data = erd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EscherRecord(EscherRecordType type)
/*     */   {
/*  64 */     this.data = new EscherRecordData(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setContainer(boolean cont)
/*     */   {
/*  74 */     this.data.setContainer(cont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  84 */     return this.data.getLength() + 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final EscherStream getEscherStream()
/*     */   {
/*  94 */     return this.data.getEscherStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int getPos()
/*     */   {
/* 104 */     return this.data.getPos();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int getInstance()
/*     */   {
/* 114 */     return this.data.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setInstance(int i)
/*     */   {
/* 124 */     this.data.setInstance(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setVersion(int v)
/*     */   {
/* 134 */     this.data.setVersion(v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherRecordType getType()
/*     */   {
/* 144 */     return this.data.getType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract byte[] getData();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final byte[] setHeaderData(byte[] d)
/*     */   {
/* 164 */     return this.data.setHeaderData(d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 174 */     return this.data.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getStreamLength()
/*     */   {
/* 184 */     return this.data.getStreamLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EscherRecordData getEscherData()
/*     */   {
/* 194 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\EscherRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */