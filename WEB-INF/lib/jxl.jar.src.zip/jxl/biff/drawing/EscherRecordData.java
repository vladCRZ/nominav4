/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EscherRecordData
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(EscherRecordData.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int instance;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int version;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int recordId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int streamLength;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean container;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherRecordType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherStream escherStream;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherRecordData(EscherStream dg, int p)
/*     */   {
/*  92 */     this.escherStream = dg;
/*  93 */     this.pos = p;
/*  94 */     byte[] data = this.escherStream.getData();
/*     */     
/*  96 */     this.streamLength = data.length;
/*     */     
/*     */ 
/*  99 */     int value = IntegerHelper.getInt(data[this.pos], data[(this.pos + 1)]);
/*     */     
/*     */ 
/* 102 */     this.instance = ((value & 0xFFF0) >> 4);
/*     */     
/*     */ 
/* 105 */     this.version = (value & 0xF);
/*     */     
/*     */ 
/* 108 */     this.recordId = IntegerHelper.getInt(data[(this.pos + 2)], data[(this.pos + 3)]);
/*     */     
/*     */ 
/* 111 */     this.length = IntegerHelper.getInt(data[(this.pos + 4)], data[(this.pos + 5)], data[(this.pos + 6)], data[(this.pos + 7)]);
/*     */     
/*     */ 
/* 114 */     if (this.version == 15)
/*     */     {
/* 116 */       this.container = true;
/*     */     }
/*     */     else
/*     */     {
/* 120 */       this.container = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherRecordData(EscherRecordType t)
/*     */   {
/* 131 */     this.type = t;
/* 132 */     this.recordId = this.type.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isContainer()
/*     */   {
/* 142 */     return this.container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 152 */     return this.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordId()
/*     */   {
/* 162 */     return this.recordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   EscherStream getDrawingGroup()
/*     */   {
/* 172 */     return this.escherStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPos()
/*     */   {
/* 182 */     return this.pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   EscherRecordType getType()
/*     */   {
/* 192 */     if (this.type == null)
/*     */     {
/* 194 */       this.type = EscherRecordType.getType(this.recordId);
/*     */     }
/*     */     
/* 197 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getInstance()
/*     */   {
/* 207 */     return this.instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setContainer(boolean c)
/*     */   {
/* 218 */     this.container = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setInstance(int inst)
/*     */   {
/* 228 */     this.instance = inst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setLength(int l)
/*     */   {
/* 238 */     this.length = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setVersion(int v)
/*     */   {
/* 248 */     this.version = v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] setHeaderData(byte[] d)
/*     */   {
/* 260 */     byte[] data = new byte[d.length + 8];
/* 261 */     System.arraycopy(d, 0, data, 8, d.length);
/*     */     
/* 263 */     if (this.container)
/*     */     {
/* 265 */       this.version = 15;
/*     */     }
/*     */     
/*     */ 
/* 269 */     int value = this.instance << 4;
/* 270 */     value |= this.version;
/* 271 */     IntegerHelper.getTwoBytes(value, data, 0);
/*     */     
/*     */ 
/* 274 */     IntegerHelper.getTwoBytes(this.recordId, data, 2);
/*     */     
/*     */ 
/* 277 */     IntegerHelper.getFourBytes(d.length, data, 4);
/*     */     
/* 279 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   EscherStream getEscherStream()
/*     */   {
/* 289 */     return this.escherStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 299 */     byte[] d = new byte[this.length];
/* 300 */     System.arraycopy(this.escherStream.getData(), this.pos + 8, d, 0, this.length);
/* 301 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getStreamLength()
/*     */   {
/* 311 */     return this.streamLength;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\EscherRecordData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */