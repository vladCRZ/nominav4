/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EscherRecordType
/*     */ {
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  35 */   private static EscherRecordType[] types = new EscherRecordType[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherRecordType(int val)
/*     */   {
/*  44 */     this.value = val;
/*     */     
/*  46 */     EscherRecordType[] newtypes = new EscherRecordType[types.length + 1];
/*  47 */     System.arraycopy(types, 0, newtypes, 0, types.length);
/*  48 */     newtypes[types.length] = this;
/*  49 */     types = newtypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  59 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EscherRecordType getType(int val)
/*     */   {
/*  71 */     EscherRecordType type = UNKNOWN;
/*     */     
/*  73 */     for (int i = 0; i < types.length; i++)
/*     */     {
/*  75 */       if (val == types[i].value)
/*     */       {
/*  77 */         type = types[i];
/*  78 */         break;
/*     */       }
/*     */     }
/*     */     
/*  82 */     return type;
/*     */   }
/*     */   
/*  85 */   public static final EscherRecordType UNKNOWN = new EscherRecordType(0);
/*  86 */   public static final EscherRecordType DGG_CONTAINER = new EscherRecordType(61440);
/*     */   
/*  88 */   public static final EscherRecordType BSTORE_CONTAINER = new EscherRecordType(61441);
/*     */   
/*  90 */   public static final EscherRecordType DG_CONTAINER = new EscherRecordType(61442);
/*     */   
/*  92 */   public static final EscherRecordType SPGR_CONTAINER = new EscherRecordType(61443);
/*     */   
/*  94 */   public static final EscherRecordType SP_CONTAINER = new EscherRecordType(61444);
/*     */   
/*     */ 
/*  97 */   public static final EscherRecordType DGG = new EscherRecordType(61446);
/*  98 */   public static final EscherRecordType BSE = new EscherRecordType(61447);
/*  99 */   public static final EscherRecordType DG = new EscherRecordType(61448);
/* 100 */   public static final EscherRecordType SPGR = new EscherRecordType(61449);
/* 101 */   public static final EscherRecordType SP = new EscherRecordType(61450);
/* 102 */   public static final EscherRecordType OPT = new EscherRecordType(61451);
/* 103 */   public static final EscherRecordType CLIENT_ANCHOR = new EscherRecordType(61456);
/*     */   
/* 105 */   public static final EscherRecordType CLIENT_DATA = new EscherRecordType(61457);
/*     */   
/* 107 */   public static final EscherRecordType CLIENT_TEXT_BOX = new EscherRecordType(61453);
/*     */   
/* 109 */   public static final EscherRecordType SPLIT_MENU_COLORS = new EscherRecordType(61726);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\EscherRecordType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */