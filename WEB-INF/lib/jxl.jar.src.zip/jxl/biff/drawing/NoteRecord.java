/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoteRecord
/*     */   extends WritableRecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(NoteRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoteRecord(Record t)
/*     */   {
/*  66 */     super(t);
/*  67 */     this.data = getRecord().getData();
/*  68 */     this.row = IntegerHelper.getInt(this.data[0], this.data[1]);
/*  69 */     this.column = IntegerHelper.getInt(this.data[2], this.data[3]);
/*  70 */     this.objectId = IntegerHelper.getInt(this.data[6], this.data[7]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoteRecord(byte[] d)
/*     */   {
/*  80 */     super(Type.NOTE);
/*  81 */     this.data = d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoteRecord(int c, int r, int id)
/*     */   {
/*  93 */     super(Type.NOTE);
/*  94 */     this.row = r;
/*  95 */     this.column = c;
/*  96 */     this.objectId = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 106 */     if (this.data != null)
/*     */     {
/* 108 */       return this.data;
/*     */     }
/*     */     
/* 111 */     String author = "";
/* 112 */     this.data = new byte[8 + author.length() + 4];
/*     */     
/*     */ 
/* 115 */     IntegerHelper.getTwoBytes(this.row, this.data, 0);
/*     */     
/*     */ 
/* 118 */     IntegerHelper.getTwoBytes(this.column, this.data, 2);
/*     */     
/*     */ 
/* 121 */     IntegerHelper.getTwoBytes(this.objectId, this.data, 6);
/*     */     
/*     */ 
/* 124 */     IntegerHelper.getTwoBytes(author.length(), this.data, 8);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getRow()
/*     */   {
/* 141 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getColumn()
/*     */   {
/* 151 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectId()
/*     */   {
/* 161 */     return this.objectId;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\NoteRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */