/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjRecord
/*     */   extends WritableRecordData
/*     */ {
/*  39 */   private static final Logger logger = Logger.getLogger(ObjRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private ObjType type;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean read;
/*     */   
/*     */ 
/*     */ 
/*     */   private int objectId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class ObjType
/*     */   {
/*     */     public int value;
/*     */     
/*     */ 
/*     */     public String desc;
/*     */     
/*     */ 
/*  64 */     private static ObjType[] types = new ObjType[0];
/*     */     
/*     */     ObjType(int v, String d)
/*     */     {
/*  68 */       this.value = v;
/*  69 */       this.desc = d;
/*     */       
/*  71 */       ObjType[] oldtypes = types;
/*  72 */       types = new ObjType[types.length + 1];
/*  73 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*  74 */       types[oldtypes.length] = this;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  79 */       return this.desc;
/*     */     }
/*     */     
/*     */     public static ObjType getType(int val)
/*     */     {
/*  84 */       ObjType retval = ObjRecord.UNKNOWN;
/*  85 */       for (int i = 0; (i < types.length) && (retval == ObjRecord.UNKNOWN); i++)
/*     */       {
/*  87 */         if (types[i].value == val)
/*     */         {
/*  89 */           retval = types[i];
/*     */         }
/*     */       }
/*  92 */       return retval;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  97 */   public static final ObjType GROUP = new ObjType(0, "Group");
/*  98 */   public static final ObjType LINE = new ObjType(1, "Line");
/*  99 */   public static final ObjType RECTANGLE = new ObjType(2, "Rectangle");
/* 100 */   public static final ObjType OVAL = new ObjType(3, "Oval");
/* 101 */   public static final ObjType ARC = new ObjType(4, "Arc");
/* 102 */   public static final ObjType CHART = new ObjType(5, "Chart");
/* 103 */   public static final ObjType TEXT = new ObjType(6, "Text");
/* 104 */   public static final ObjType BUTTON = new ObjType(7, "Button");
/* 105 */   public static final ObjType PICTURE = new ObjType(8, "Picture");
/* 106 */   public static final ObjType POLYGON = new ObjType(9, "Polygon");
/* 107 */   public static final ObjType CHECKBOX = new ObjType(11, "Checkbox");
/* 108 */   public static final ObjType OPTION = new ObjType(12, "Option");
/* 109 */   public static final ObjType EDITBOX = new ObjType(13, "Edit Box");
/* 110 */   public static final ObjType LABEL = new ObjType(14, "Label");
/* 111 */   public static final ObjType DIALOGUEBOX = new ObjType(15, "Dialogue Box");
/* 112 */   public static final ObjType SPINBOX = new ObjType(16, "Spin Box");
/* 113 */   public static final ObjType SCROLLBAR = new ObjType(17, "Scrollbar");
/* 114 */   public static final ObjType LISTBOX = new ObjType(18, "List Box");
/* 115 */   public static final ObjType GROUPBOX = new ObjType(19, "Group Box");
/* 116 */   public static final ObjType COMBOBOX = new ObjType(20, "Combo Box");
/* 117 */   public static final ObjType MSOFFICEDRAWING = new ObjType(30, "MS Office Drawing");
/*     */   
/* 119 */   public static final ObjType FORMCONTROL = new ObjType(20, "Form Combo Box");
/*     */   
/* 121 */   public static final ObjType EXCELNOTE = new ObjType(25, "Excel Note");
/*     */   
/*     */ 
/* 124 */   public static final ObjType UNKNOWN = new ObjType(255, "Unknown");
/*     */   
/*     */   private static final int COMMON_DATA_LENGTH = 22;
/*     */   
/*     */   private static final int CLIPBOARD_FORMAT_LENGTH = 6;
/*     */   
/*     */   private static final int PICTURE_OPTION_LENGTH = 6;
/*     */   
/*     */   private static final int NOTE_STRUCTURE_LENGTH = 26;
/*     */   
/*     */   private static final int COMBOBOX_STRUCTURE_LENGTH = 44;
/*     */   
/*     */   private static final int END_LENGTH = 4;
/*     */   
/*     */ 
/*     */   public ObjRecord(Record t)
/*     */   {
/* 141 */     super(t);
/* 142 */     byte[] data = t.getData();
/* 143 */     int objtype = IntegerHelper.getInt(data[4], data[5]);
/* 144 */     this.read = true;
/* 145 */     this.type = ObjType.getType(objtype);
/*     */     
/* 147 */     if (this.type == UNKNOWN)
/*     */     {
/* 149 */       logger.warn("unknown object type code " + objtype);
/*     */     }
/*     */     
/* 152 */     this.objectId = IntegerHelper.getInt(data[6], data[7]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ObjRecord(int objId, ObjType t)
/*     */   {
/* 163 */     super(Type.OBJ);
/* 164 */     this.objectId = objId;
/* 165 */     this.type = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 175 */     if (this.read)
/*     */     {
/* 177 */       return getRecord().getData();
/*     */     }
/*     */     
/* 180 */     if ((this.type == PICTURE) || (this.type == CHART))
/*     */     {
/* 182 */       return getPictureData();
/*     */     }
/* 184 */     if (this.type == EXCELNOTE)
/*     */     {
/* 186 */       return getNoteData();
/*     */     }
/* 188 */     if (this.type == COMBOBOX)
/*     */     {
/* 190 */       return getComboBoxData();
/*     */     }
/*     */     
/*     */ 
/* 194 */     Assert.verify(false);
/*     */     
/* 196 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getPictureData()
/*     */   {
/* 206 */     int dataLength = 38;
/*     */     
/*     */ 
/*     */ 
/* 210 */     int pos = 0;
/* 211 */     byte[] data = new byte[dataLength];
/*     */     
/*     */ 
/*     */ 
/* 215 */     IntegerHelper.getTwoBytes(21, data, pos);
/*     */     
/*     */ 
/* 218 */     IntegerHelper.getTwoBytes(18, data, pos + 2);
/*     */     
/*     */ 
/* 221 */     IntegerHelper.getTwoBytes(this.type.value, data, pos + 4);
/*     */     
/*     */ 
/* 224 */     IntegerHelper.getTwoBytes(this.objectId, data, pos + 6);
/*     */     
/*     */ 
/* 227 */     IntegerHelper.getTwoBytes(24593, data, pos + 8);
/* 228 */     pos += 22;
/*     */     
/*     */ 
/*     */ 
/* 232 */     IntegerHelper.getTwoBytes(7, data, pos);
/*     */     
/*     */ 
/* 235 */     IntegerHelper.getTwoBytes(2, data, pos + 2);
/*     */     
/*     */ 
/* 238 */     IntegerHelper.getTwoBytes(65535, data, pos + 4);
/* 239 */     pos += 6;
/*     */     
/*     */ 
/*     */ 
/* 243 */     IntegerHelper.getTwoBytes(8, data, pos);
/*     */     
/*     */ 
/* 246 */     IntegerHelper.getTwoBytes(2, data, pos + 2);
/*     */     
/*     */ 
/* 249 */     IntegerHelper.getTwoBytes(1, data, pos + 4);
/* 250 */     pos += 6;
/*     */     
/*     */ 
/* 253 */     IntegerHelper.getTwoBytes(0, data, pos);
/*     */     
/*     */ 
/* 256 */     IntegerHelper.getTwoBytes(0, data, pos + 2);
/*     */     
/*     */ 
/* 259 */     pos += 4;
/*     */     
/* 261 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getNoteData()
/*     */   {
/* 271 */     int dataLength = 52;
/*     */     
/*     */ 
/* 274 */     int pos = 0;
/* 275 */     byte[] data = new byte[dataLength];
/*     */     
/*     */ 
/*     */ 
/* 279 */     IntegerHelper.getTwoBytes(21, data, pos);
/*     */     
/*     */ 
/* 282 */     IntegerHelper.getTwoBytes(18, data, pos + 2);
/*     */     
/*     */ 
/* 285 */     IntegerHelper.getTwoBytes(this.type.value, data, pos + 4);
/*     */     
/*     */ 
/* 288 */     IntegerHelper.getTwoBytes(this.objectId, data, pos + 6);
/*     */     
/*     */ 
/* 291 */     IntegerHelper.getTwoBytes(16401, data, pos + 8);
/* 292 */     pos += 22;
/*     */     
/*     */ 
/*     */ 
/* 296 */     IntegerHelper.getTwoBytes(13, data, pos);
/*     */     
/*     */ 
/* 299 */     IntegerHelper.getTwoBytes(22, data, pos + 2);
/*     */     
/*     */ 
/* 302 */     pos += 26;
/*     */     
/*     */ 
/*     */ 
/* 306 */     IntegerHelper.getTwoBytes(0, data, pos);
/*     */     
/*     */ 
/* 309 */     IntegerHelper.getTwoBytes(0, data, pos + 2);
/*     */     
/*     */ 
/* 312 */     pos += 4;
/*     */     
/* 314 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getComboBoxData()
/*     */   {
/* 324 */     int dataLength = 70;
/*     */     
/*     */ 
/* 327 */     int pos = 0;
/* 328 */     byte[] data = new byte[dataLength];
/*     */     
/*     */ 
/*     */ 
/* 332 */     IntegerHelper.getTwoBytes(21, data, pos);
/*     */     
/*     */ 
/* 335 */     IntegerHelper.getTwoBytes(18, data, pos + 2);
/*     */     
/*     */ 
/* 338 */     IntegerHelper.getTwoBytes(this.type.value, data, pos + 4);
/*     */     
/*     */ 
/* 341 */     IntegerHelper.getTwoBytes(this.objectId, data, pos + 6);
/*     */     
/*     */ 
/* 344 */     IntegerHelper.getTwoBytes(0, data, pos + 8);
/* 345 */     pos += 22;
/*     */     
/*     */ 
/*     */ 
/* 349 */     IntegerHelper.getTwoBytes(12, data, pos);
/*     */     
/*     */ 
/* 352 */     IntegerHelper.getTwoBytes(20, data, pos + 2);
/*     */     
/*     */ 
/* 355 */     data[(pos + 14)] = 1;
/* 356 */     data[(pos + 16)] = 4;
/* 357 */     data[(pos + 20)] = 16;
/* 358 */     data[(pos + 24)] = 19;
/* 359 */     data[(pos + 26)] = -18;
/* 360 */     data[(pos + 27)] = 31;
/* 361 */     data[(pos + 30)] = 4;
/* 362 */     data[(pos + 34)] = 1;
/* 363 */     data[(pos + 35)] = 6;
/* 364 */     data[(pos + 38)] = 2;
/* 365 */     data[(pos + 40)] = 8;
/* 366 */     data[(pos + 42)] = 64;
/*     */     
/* 368 */     pos += 44;
/*     */     
/*     */ 
/*     */ 
/* 372 */     IntegerHelper.getTwoBytes(0, data, pos);
/*     */     
/*     */ 
/* 375 */     IntegerHelper.getTwoBytes(0, data, pos + 2);
/*     */     
/*     */ 
/* 378 */     pos += 4;
/*     */     
/* 380 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Record getRecord()
/*     */   {
/* 391 */     return super.getRecord();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjType getType()
/*     */   {
/* 401 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectId()
/*     */   {
/* 411 */     return this.objectId;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\ObjRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */