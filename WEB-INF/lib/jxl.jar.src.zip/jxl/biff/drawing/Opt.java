/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Opt
/*     */   extends EscherAtom
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(Opt.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */   private int numProperties;
/*     */   
/*     */ 
/*     */ 
/*     */   private ArrayList properties;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Property
/*     */   {
/*     */     int id;
/*     */     
/*     */ 
/*     */ 
/*     */     boolean blipId;
/*     */     
/*     */ 
/*     */     boolean complex;
/*     */     
/*     */ 
/*     */     int value;
/*     */     
/*     */ 
/*     */     String stringValue;
/*     */     
/*     */ 
/*     */ 
/*     */     public Property(int i, boolean bl, boolean co, int v)
/*     */     {
/*  76 */       this.id = i;
/*  77 */       this.blipId = bl;
/*  78 */       this.complex = co;
/*  79 */       this.value = v;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Property(int i, boolean bl, boolean co, int v, String s)
/*     */     {
/*  93 */       this.id = i;
/*  94 */       this.blipId = bl;
/*  95 */       this.complex = co;
/*  96 */       this.value = v;
/*  97 */       this.stringValue = s;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Opt(EscherRecordData erd)
/*     */   {
/* 108 */     super(erd);
/* 109 */     this.numProperties = getInstance();
/* 110 */     readProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readProperties()
/*     */   {
/* 118 */     this.properties = new ArrayList();
/* 119 */     int pos = 0;
/* 120 */     byte[] bytes = getBytes();
/*     */     
/* 122 */     for (int i = 0; i < this.numProperties; i++)
/*     */     {
/* 124 */       int val = IntegerHelper.getInt(bytes[pos], bytes[(pos + 1)]);
/* 125 */       int id = val & 0x3FFF;
/* 126 */       int value = IntegerHelper.getInt(bytes[(pos + 2)], bytes[(pos + 3)], bytes[(pos + 4)], bytes[(pos + 5)]);
/*     */       
/* 128 */       Property p = new Property(id, (val & 0x4000) != 0, (val & 0x8000) != 0, value);
/*     */       
/*     */ 
/*     */ 
/* 132 */       pos += 6;
/* 133 */       this.properties.add(p);
/*     */     }
/*     */     
/* 136 */     for (Iterator i = this.properties.iterator(); i.hasNext();)
/*     */     {
/* 138 */       Property p = (Property)i.next();
/* 139 */       if (p.complex)
/*     */       {
/* 141 */         p.stringValue = StringHelper.getUnicodeString(bytes, p.value / 2, pos);
/*     */         
/* 143 */         pos += p.value;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Opt()
/*     */   {
/* 153 */     super(EscherRecordType.OPT);
/* 154 */     this.properties = new ArrayList();
/* 155 */     setVersion(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getData()
/*     */   {
/* 165 */     this.numProperties = this.properties.size();
/* 166 */     setInstance(this.numProperties);
/*     */     
/* 168 */     this.data = new byte[this.numProperties * 6];
/* 169 */     int pos = 0;
/*     */     
/*     */ 
/* 172 */     for (Iterator i = this.properties.iterator(); i.hasNext();)
/*     */     {
/* 174 */       Property p = (Property)i.next();
/* 175 */       int val = p.id & 0x3FFF;
/*     */       
/* 177 */       if (p.blipId)
/*     */       {
/* 179 */         val |= 0x4000;
/*     */       }
/*     */       
/* 182 */       if (p.complex)
/*     */       {
/* 184 */         val |= 0x8000;
/*     */       }
/*     */       
/* 187 */       IntegerHelper.getTwoBytes(val, this.data, pos);
/* 188 */       IntegerHelper.getFourBytes(p.value, this.data, pos + 2);
/* 189 */       pos += 6;
/*     */     }
/*     */     
/*     */ 
/* 193 */     for (Iterator i = this.properties.iterator(); i.hasNext();)
/*     */     {
/* 195 */       Property p = (Property)i.next();
/*     */       
/* 197 */       if ((p.complex) && (p.stringValue != null))
/*     */       {
/* 199 */         byte[] newData = new byte[this.data.length + p.stringValue.length() * 2];
/*     */         
/* 201 */         System.arraycopy(this.data, 0, newData, 0, this.data.length);
/* 202 */         StringHelper.getUnicodeBytes(p.stringValue, newData, this.data.length);
/* 203 */         this.data = newData;
/*     */       }
/*     */     }
/*     */     
/* 207 */     return setHeaderData(this.data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addProperty(int id, boolean blip, boolean complex, int val)
/*     */   {
/* 220 */     Property p = new Property(id, blip, complex, val);
/* 221 */     this.properties.add(p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addProperty(int id, boolean blip, boolean complex, int val, String s)
/*     */   {
/* 235 */     Property p = new Property(id, blip, complex, val, s);
/* 236 */     this.properties.add(p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Property getProperty(int id)
/*     */   {
/* 247 */     boolean found = false;
/* 248 */     Property p = null;
/* 249 */     for (Iterator i = this.properties.iterator(); (i.hasNext()) && (!found);)
/*     */     {
/* 251 */       p = (Property)i.next();
/* 252 */       if (p.id == id)
/*     */       {
/* 254 */         found = true;
/*     */       }
/*     */     }
/* 257 */     return found ? p : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Opt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */