/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNGReader
/*     */ {
/*     */   private byte[] pngData;
/*     */   private Chunk ihdr;
/*     */   private Chunk phys;
/*     */   private int pixelWidth;
/*     */   private int pixelHeight;
/*     */   private int verticalResolution;
/*     */   private int horizontalResolution;
/*     */   private int resolutionUnit;
/*  39 */   private static byte[] PNG_MAGIC_NUMBER = { -119, 80, 78, 71, 13, 10, 26, 10 };
/*     */   
/*     */ 
/*     */ 
/*     */   public PNGReader(byte[] data)
/*     */   {
/*  45 */     this.pngData = data;
/*     */   }
/*     */   
/*     */ 
/*     */   void read()
/*     */   {
/*  51 */     byte[] header = new byte[PNG_MAGIC_NUMBER.length];
/*  52 */     System.arraycopy(this.pngData, 0, header, 0, header.length);
/*  53 */     boolean pngFile = Arrays.equals(PNG_MAGIC_NUMBER, header);
/*  54 */     if (!pngFile)
/*     */     {
/*  56 */       return;
/*     */     }
/*     */     
/*  59 */     int pos = 8;
/*  60 */     while (pos < this.pngData.length)
/*     */     {
/*  62 */       int length = getInt(this.pngData[pos], this.pngData[(pos + 1)], this.pngData[(pos + 2)], this.pngData[(pos + 3)]);
/*     */       
/*     */ 
/*     */ 
/*  66 */       ChunkType chunkType = ChunkType.getChunkType(this.pngData[(pos + 4)], this.pngData[(pos + 5)], this.pngData[(pos + 6)], this.pngData[(pos + 7)]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  71 */       if (chunkType == ChunkType.IHDR)
/*     */       {
/*  73 */         this.ihdr = new Chunk(pos + 8, length, chunkType, this.pngData);
/*     */       }
/*  75 */       else if (chunkType == ChunkType.PHYS)
/*     */       {
/*  77 */         this.phys = new Chunk(pos + 8, length, chunkType, this.pngData);
/*     */       }
/*     */       
/*  80 */       pos += length + 12;
/*     */     }
/*     */     
/*     */ 
/*  84 */     byte[] ihdrData = this.ihdr.getData();
/*  85 */     this.pixelWidth = getInt(ihdrData[0], ihdrData[1], ihdrData[2], ihdrData[3]);
/*  86 */     this.pixelHeight = getInt(ihdrData[4], ihdrData[5], ihdrData[6], ihdrData[7]);
/*     */     
/*  88 */     if (this.phys != null)
/*     */     {
/*  90 */       byte[] physData = this.phys.getData();
/*  91 */       this.resolutionUnit = physData[8];
/*  92 */       this.horizontalResolution = getInt(physData[0], physData[1], physData[2], physData[3]);
/*     */       
/*  94 */       this.verticalResolution = getInt(physData[4], physData[5], physData[6], physData[7]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getInt(byte d1, byte d2, byte d3, byte d4)
/*     */   {
/* 102 */     int i1 = d1 & 0xFF;
/* 103 */     int i2 = d2 & 0xFF;
/* 104 */     int i3 = d3 & 0xFF;
/* 105 */     int i4 = d4 & 0xFF;
/*     */     
/* 107 */     int val = i1 << 24 | i2 << 16 | i3 << 8 | i4;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 112 */     return val;
/*     */   }
/*     */   
/*     */   public int getHeight()
/*     */   {
/* 117 */     return this.pixelHeight;
/*     */   }
/*     */   
/*     */   public int getWidth()
/*     */   {
/* 122 */     return this.pixelWidth;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getHorizontalResolution()
/*     */   {
/* 128 */     return this.resolutionUnit == 1 ? this.horizontalResolution : 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getVerticalResolution()
/*     */   {
/* 134 */     return this.resolutionUnit == 1 ? this.verticalResolution : 0;
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 141 */       File f = new File(args[0]);
/* 142 */       int size = (int)f.length();
/*     */       
/* 144 */       byte[] data = new byte[size];
/*     */       
/* 146 */       FileInputStream fis = new FileInputStream(f);
/* 147 */       fis.read(data);
/* 148 */       fis.close();
/* 149 */       PNGReader reader = new PNGReader(data);
/* 150 */       reader.read();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 154 */       t.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\PNGReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */