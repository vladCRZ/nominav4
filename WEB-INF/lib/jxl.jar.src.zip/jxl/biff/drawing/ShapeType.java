/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ShapeType
/*    */ {
/*    */   private int value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 35 */   private static ShapeType[] types = new ShapeType[0];
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ShapeType(int v)
/*    */   {
/* 44 */     this.value = v;
/*    */     
/* 46 */     ShapeType[] old = types;
/* 47 */     types = new ShapeType[types.length + 1];
/* 48 */     System.arraycopy(old, 0, types, 0, old.length);
/* 49 */     types[old.length] = this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static ShapeType getType(int v)
/*    */   {
/* 60 */     ShapeType st = UNKNOWN;
/* 61 */     boolean found = false;
/* 62 */     for (int i = 0; (i < types.length) && (!found); i++)
/*    */     {
/* 64 */       if (types[i].value == v)
/*    */       {
/* 66 */         found = true;
/* 67 */         st = types[i];
/*    */       }
/*    */     }
/* 70 */     return st;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 80 */     return this.value;
/*    */   }
/*    */   
/* 83 */   public static final ShapeType MIN = new ShapeType(0);
/* 84 */   public static final ShapeType PICTURE_FRAME = new ShapeType(75);
/* 85 */   public static final ShapeType HOST_CONTROL = new ShapeType(201);
/* 86 */   public static final ShapeType TEXT_BOX = new ShapeType(202);
/* 87 */   public static final ShapeType UNKNOWN = new ShapeType(-1);
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\ShapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */