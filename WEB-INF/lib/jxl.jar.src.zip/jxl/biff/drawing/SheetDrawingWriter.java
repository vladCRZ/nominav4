/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SheetDrawingWriter
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(SheetDrawingWriter.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList drawings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean drawingsModified;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Chart[] charts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SheetDrawingWriter(WorkbookSettings ws)
/*     */   {
/*  70 */     this.charts = new Chart[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawings(ArrayList dr, boolean mod)
/*     */   {
/*  81 */     this.drawings = dr;
/*  82 */     this.drawingsModified = mod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/*  95 */     if ((this.drawings.size() == 0) && (this.charts.length == 0))
/*     */     {
/*  97 */       return;
/*     */     }
/*     */     
/*     */ 
/* 101 */     boolean modified = this.drawingsModified;
/* 102 */     int numImages = this.drawings.size();
/*     */     
/* 104 */     for (Iterator i = this.drawings.iterator(); (i.hasNext()) && (!modified);)
/*     */     {
/* 106 */       DrawingGroupObject d = (DrawingGroupObject)i.next();
/* 107 */       if (d.getOrigin() != Origin.READ)
/*     */       {
/* 109 */         modified = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 115 */     if ((numImages > 0) && (!modified))
/*     */     {
/* 117 */       DrawingGroupObject d2 = (DrawingGroupObject)this.drawings.get(0);
/* 118 */       if (!d2.isFirst())
/*     */       {
/* 120 */         modified = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 126 */     if ((numImages == 0) && (this.charts.length == 1) && (this.charts[0].getMsoDrawingRecord() == null))
/*     */     {
/*     */ 
/*     */ 
/* 130 */       modified = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 135 */     if (!modified)
/*     */     {
/* 137 */       writeUnmodified(outputFile);
/* 138 */       return;
/*     */     }
/*     */     
/* 141 */     Object[] spContainerData = new Object[numImages + this.charts.length];
/* 142 */     int length = 0;
/* 143 */     EscherContainer firstSpContainer = null;
/*     */     
/*     */ 
/*     */ 
/* 147 */     for (int i = 0; i < numImages; i++)
/*     */     {
/* 149 */       DrawingGroupObject drawing = (DrawingGroupObject)this.drawings.get(i);
/*     */       
/* 151 */       EscherContainer spc = drawing.getSpContainer();
/*     */       
/* 153 */       if (spc != null)
/*     */       {
/* 155 */         byte[] data = spc.getData();
/* 156 */         spContainerData[i] = data;
/*     */         
/* 158 */         if (i == 0)
/*     */         {
/* 160 */           firstSpContainer = spc;
/*     */         }
/*     */         else
/*     */         {
/* 164 */           length += data.length;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 170 */     for (int i = 0; i < this.charts.length; i++)
/*     */     {
/* 172 */       EscherContainer spContainer = this.charts[i].getSpContainer();
/* 173 */       byte[] data = spContainer.getBytes();
/* 174 */       data = spContainer.setHeaderData(data);
/* 175 */       spContainerData[(i + numImages)] = data;
/*     */       
/* 177 */       if ((i == 0) && (numImages == 0))
/*     */       {
/* 179 */         firstSpContainer = spContainer;
/*     */       }
/*     */       else
/*     */       {
/* 183 */         length += data.length;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 188 */     DgContainer dgContainer = new DgContainer();
/* 189 */     Dg dg = new Dg(numImages + this.charts.length);
/* 190 */     dgContainer.add(dg);
/*     */     
/* 192 */     SpgrContainer spgrContainer = new SpgrContainer();
/*     */     
/* 194 */     SpContainer spContainer = new SpContainer();
/* 195 */     Spgr spgr = new Spgr();
/* 196 */     spContainer.add(spgr);
/* 197 */     Sp sp = new Sp(ShapeType.MIN, 1024, 5);
/* 198 */     spContainer.add(sp);
/* 199 */     spgrContainer.add(spContainer);
/*     */     
/* 201 */     spgrContainer.add(firstSpContainer);
/*     */     
/* 203 */     dgContainer.add(spgrContainer);
/*     */     
/* 205 */     byte[] firstMsoData = dgContainer.getData();
/*     */     
/*     */ 
/* 208 */     int len = IntegerHelper.getInt(firstMsoData[4], firstMsoData[5], firstMsoData[6], firstMsoData[7]);
/*     */     
/*     */ 
/*     */ 
/* 212 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 4);
/*     */     
/*     */ 
/* 215 */     len = IntegerHelper.getInt(firstMsoData[28], firstMsoData[29], firstMsoData[30], firstMsoData[31]);
/*     */     
/*     */ 
/*     */ 
/* 219 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 28);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */     if ((numImages > 0) && (((DrawingGroupObject)this.drawings.get(0)).isFormObject()))
/*     */     {
/*     */ 
/* 229 */       byte[] msodata2 = new byte[firstMsoData.length - 8];
/* 230 */       System.arraycopy(firstMsoData, 0, msodata2, 0, msodata2.length);
/* 231 */       firstMsoData = msodata2;
/*     */     }
/*     */     
/* 234 */     MsoDrawingRecord msoDrawingRecord = new MsoDrawingRecord(firstMsoData);
/* 235 */     outputFile.write(msoDrawingRecord);
/*     */     
/* 237 */     if (numImages > 0)
/*     */     {
/* 239 */       DrawingGroupObject firstDrawing = (DrawingGroupObject)this.drawings.get(0);
/* 240 */       firstDrawing.writeAdditionalRecords(outputFile);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 245 */       Chart chart = this.charts[0];
/* 246 */       ObjRecord objRecord = chart.getObjRecord();
/* 247 */       outputFile.write(objRecord);
/* 248 */       outputFile.write(chart);
/*     */     }
/*     */     
/*     */ 
/* 252 */     for (int i = 1; i < spContainerData.length; i++)
/*     */     {
/* 254 */       byte[] bytes = (byte[])spContainerData[i];
/*     */       
/*     */ 
/*     */ 
/* 258 */       if ((i < numImages) && (((DrawingGroupObject)this.drawings.get(i)).isFormObject()))
/*     */       {
/*     */ 
/* 261 */         byte[] bytes2 = new byte[bytes.length - 8];
/* 262 */         System.arraycopy(bytes, 0, bytes2, 0, bytes2.length);
/* 263 */         bytes = bytes2;
/*     */       }
/*     */       
/* 266 */       msoDrawingRecord = new MsoDrawingRecord(bytes);
/* 267 */       outputFile.write(msoDrawingRecord);
/*     */       
/* 269 */       if (i < numImages)
/*     */       {
/*     */ 
/* 272 */         DrawingGroupObject d = (DrawingGroupObject)this.drawings.get(i);
/* 273 */         d.writeAdditionalRecords(outputFile);
/*     */       }
/*     */       else
/*     */       {
/* 277 */         Chart chart = this.charts[(i - numImages)];
/* 278 */         ObjRecord objRecord = chart.getObjRecord();
/* 279 */         outputFile.write(objRecord);
/* 280 */         outputFile.write(chart);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 285 */     for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */     {
/* 287 */       DrawingGroupObject dgo2 = (DrawingGroupObject)i.next();
/* 288 */       dgo2.writeTailRecords(outputFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeUnmodified(File outputFile)
/*     */     throws IOException
/*     */   {
/* 300 */     if ((this.charts.length == 0) && (this.drawings.size() == 0))
/*     */     {
/*     */ 
/* 303 */       return;
/*     */     }
/* 305 */     if ((this.charts.length == 0) && (this.drawings.size() != 0))
/*     */     {
/*     */ 
/* 308 */       for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */       {
/* 310 */         DrawingGroupObject d = (DrawingGroupObject)i.next();
/* 311 */         outputFile.write(d.getMsoDrawingRecord());
/* 312 */         d.writeAdditionalRecords(outputFile);
/*     */       }
/*     */       
/* 315 */       for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */       {
/* 317 */         DrawingGroupObject d = (DrawingGroupObject)i.next();
/* 318 */         d.writeTailRecords(outputFile);
/*     */       }
/* 320 */       return;
/*     */     }
/* 322 */     if ((this.drawings.size() == 0) && (this.charts.length != 0))
/*     */     {
/*     */ 
/* 325 */       Chart curChart = null;
/* 326 */       for (int i = 0; i < this.charts.length; i++)
/*     */       {
/* 328 */         curChart = this.charts[i];
/* 329 */         if (curChart.getMsoDrawingRecord() != null)
/*     */         {
/* 331 */           outputFile.write(curChart.getMsoDrawingRecord());
/*     */         }
/*     */         
/* 334 */         if (curChart.getObjRecord() != null)
/*     */         {
/* 336 */           outputFile.write(curChart.getObjRecord());
/*     */         }
/*     */         
/* 339 */         outputFile.write(curChart);
/*     */       }
/*     */       
/* 342 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 349 */     int numDrawings = this.drawings.size();
/* 350 */     int length = 0;
/* 351 */     EscherContainer[] spContainers = new EscherContainer[numDrawings + this.charts.length];
/*     */     
/* 353 */     boolean[] isFormObject = new boolean[numDrawings + this.charts.length];
/*     */     
/* 355 */     for (int i = 0; i < numDrawings; i++)
/*     */     {
/* 357 */       DrawingGroupObject d = (DrawingGroupObject)this.drawings.get(i);
/* 358 */       spContainers[i] = d.getSpContainer();
/*     */       
/* 360 */       if (i > 0)
/*     */       {
/* 362 */         length += spContainers[i].getLength();
/*     */       }
/*     */       
/* 365 */       if (d.isFormObject())
/*     */       {
/* 367 */         isFormObject[i] = true;
/*     */       }
/*     */     }
/*     */     
/* 371 */     for (int i = 0; i < this.charts.length; i++)
/*     */     {
/* 373 */       spContainers[(i + numDrawings)] = this.charts[i].getSpContainer();
/* 374 */       length += spContainers[(i + numDrawings)].getLength();
/*     */     }
/*     */     
/*     */ 
/* 378 */     DgContainer dgContainer = new DgContainer();
/* 379 */     Dg dg = new Dg(numDrawings + this.charts.length);
/* 380 */     dgContainer.add(dg);
/*     */     
/* 382 */     SpgrContainer spgrContainer = new SpgrContainer();
/*     */     
/* 384 */     SpContainer spContainer = new SpContainer();
/* 385 */     Spgr spgr = new Spgr();
/* 386 */     spContainer.add(spgr);
/* 387 */     Sp sp = new Sp(ShapeType.MIN, 1024, 5);
/* 388 */     spContainer.add(sp);
/* 389 */     spgrContainer.add(spContainer);
/*     */     
/* 391 */     spgrContainer.add(spContainers[0]);
/*     */     
/* 393 */     dgContainer.add(spgrContainer);
/*     */     
/* 395 */     byte[] firstMsoData = dgContainer.getData();
/*     */     
/*     */ 
/* 398 */     int len = IntegerHelper.getInt(firstMsoData[4], firstMsoData[5], firstMsoData[6], firstMsoData[7]);
/*     */     
/*     */ 
/*     */ 
/* 402 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 4);
/*     */     
/*     */ 
/* 405 */     len = IntegerHelper.getInt(firstMsoData[28], firstMsoData[29], firstMsoData[30], firstMsoData[31]);
/*     */     
/*     */ 
/*     */ 
/* 409 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 28);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 415 */     if (isFormObject[0] == 1)
/*     */     {
/* 417 */       byte[] cbytes = new byte[firstMsoData.length - 8];
/* 418 */       System.arraycopy(firstMsoData, 0, cbytes, 0, cbytes.length);
/* 419 */       firstMsoData = cbytes;
/*     */     }
/*     */     
/*     */ 
/* 423 */     MsoDrawingRecord msoDrawingRecord = new MsoDrawingRecord(firstMsoData);
/* 424 */     outputFile.write(msoDrawingRecord);
/*     */     
/* 426 */     DrawingGroupObject dgo = (DrawingGroupObject)this.drawings.get(0);
/* 427 */     dgo.writeAdditionalRecords(outputFile);
/*     */     
/*     */ 
/* 430 */     for (int i = 1; i < spContainers.length; i++)
/*     */     {
/* 432 */       byte[] bytes = spContainers[i].getBytes();
/* 433 */       byte[] bytes2 = spContainers[i].setHeaderData(bytes);
/*     */       
/*     */ 
/*     */ 
/* 437 */       if (isFormObject[i] == 1)
/*     */       {
/* 439 */         byte[] cbytes = new byte[bytes2.length - 8];
/* 440 */         System.arraycopy(bytes2, 0, cbytes, 0, cbytes.length);
/* 441 */         bytes2 = cbytes;
/*     */       }
/*     */       
/* 444 */       msoDrawingRecord = new MsoDrawingRecord(bytes2);
/* 445 */       outputFile.write(msoDrawingRecord);
/*     */       
/* 447 */       if (i < numDrawings)
/*     */       {
/* 449 */         dgo = (DrawingGroupObject)this.drawings.get(i);
/* 450 */         dgo.writeAdditionalRecords(outputFile);
/*     */       }
/*     */       else
/*     */       {
/* 454 */         Chart chart = this.charts[(i - numDrawings)];
/* 455 */         ObjRecord objRecord = chart.getObjRecord();
/* 456 */         outputFile.write(objRecord);
/* 457 */         outputFile.write(chart);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 462 */     for (Iterator i = this.drawings.iterator(); i.hasNext();)
/*     */     {
/* 464 */       DrawingGroupObject dgo2 = (DrawingGroupObject)i.next();
/* 465 */       dgo2.writeTailRecords(outputFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharts(Chart[] ch)
/*     */   {
/* 476 */     this.charts = ch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Chart[] getCharts()
/*     */   {
/* 486 */     return this.charts;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\SheetDrawingWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */