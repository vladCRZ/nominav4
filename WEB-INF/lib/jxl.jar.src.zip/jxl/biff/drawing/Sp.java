/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Sp
/*     */   extends EscherAtom
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(Sp.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int shapeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int persistenceFlags;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sp(EscherRecordData erd)
/*     */   {
/*  63 */     super(erd);
/*  64 */     this.shapeType = getInstance();
/*  65 */     byte[] bytes = getBytes();
/*  66 */     this.shapeId = IntegerHelper.getInt(bytes[0], bytes[1], bytes[2], bytes[3]);
/*  67 */     this.persistenceFlags = IntegerHelper.getInt(bytes[4], bytes[5], bytes[6], bytes[7]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sp(ShapeType st, int sid, int p)
/*     */   {
/*  80 */     super(EscherRecordType.SP);
/*  81 */     setVersion(2);
/*  82 */     this.shapeType = st.getValue();
/*  83 */     this.shapeId = sid;
/*  84 */     this.persistenceFlags = p;
/*  85 */     setInstance(this.shapeType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getShapeId()
/*     */   {
/*  95 */     return this.shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getShapeType()
/*     */   {
/* 105 */     return this.shapeType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getData()
/*     */   {
/* 115 */     this.data = new byte[8];
/* 116 */     IntegerHelper.getFourBytes(this.shapeId, this.data, 0);
/* 117 */     IntegerHelper.getFourBytes(this.persistenceFlags, this.data, 4);
/* 118 */     return setHeaderData(this.data);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Sp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */