/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpContainer
/*    */   extends EscherContainer
/*    */ {
/*    */   public SpContainer()
/*    */   {
/* 32 */     super(EscherRecordType.SP_CONTAINER);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SpContainer(EscherRecordData erd)
/*    */   {
/* 42 */     super(erd);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\SpContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */