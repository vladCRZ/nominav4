/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Spgr
/*    */   extends EscherAtom
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Spgr(EscherRecordData erd)
/*    */   {
/* 39 */     super(erd);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Spgr()
/*    */   {
/* 47 */     super(EscherRecordType.SPGR);
/* 48 */     setVersion(1);
/* 49 */     this.data = new byte[16];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getData()
/*    */   {
/* 59 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\Spgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */