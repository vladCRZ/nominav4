/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpgrContainer
/*    */   extends EscherContainer
/*    */ {
/* 32 */   private static final Logger logger = Logger.getLogger(SpgrContainer.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SpgrContainer()
/*    */   {
/* 39 */     super(EscherRecordType.SPGR_CONTAINER);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SpgrContainer(EscherRecordData erd)
/*    */   {
/* 49 */     super(erd);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\SpgrContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */