/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SplitMenuColors
/*    */   extends EscherAtom
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SplitMenuColors(EscherRecordData erd)
/*    */   {
/* 39 */     super(erd);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SplitMenuColors()
/*    */   {
/* 47 */     super(EscherRecordType.SPLIT_MENU_COLORS);
/* 48 */     setVersion(0);
/* 49 */     setInstance(4);
/*    */     
/* 51 */     this.data = new byte[] { 13, 0, 0, 8, 12, 0, 0, 8, 23, 0, 0, 8, -9, 0, 0, 16 };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getData()
/*    */   {
/* 65 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\SplitMenuColors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */