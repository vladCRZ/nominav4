/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextObjectRecord
/*     */   extends WritableRecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(TextObjectRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int textLength;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TextObjectRecord(String t)
/*     */   {
/*  56 */     super(Type.TXO);
/*     */     
/*  58 */     this.textLength = t.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextObjectRecord(Record t)
/*     */   {
/*  68 */     super(t);
/*  69 */     this.data = getRecord().getData();
/*  70 */     this.textLength = IntegerHelper.getInt(this.data[10], this.data[11]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextObjectRecord(byte[] d)
/*     */   {
/*  80 */     super(Type.TXO);
/*  81 */     this.data = d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTextLength()
/*     */   {
/*  92 */     return this.textLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 102 */     if (this.data != null)
/*     */     {
/* 104 */       return this.data;
/*     */     }
/*     */     
/* 107 */     this.data = new byte[18];
/*     */     
/*     */ 
/* 110 */     int options = 0;
/* 111 */     options |= 0x2;
/* 112 */     options |= 0x10;
/* 113 */     options |= 0x200;
/* 114 */     IntegerHelper.getTwoBytes(options, this.data, 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     IntegerHelper.getTwoBytes(this.textLength, this.data, 10);
/*     */     
/*     */ 
/* 123 */     IntegerHelper.getTwoBytes(16, this.data, 12);
/*     */     
/* 125 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\drawing\TextObjectRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */