/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Area
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(Area.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int columnFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int columnLast;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowLast;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnFirstRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowFirstRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnLastRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowLastRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Area() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Area(String s)
/*     */   {
/*  92 */     int seppos = s.indexOf(":");
/*  93 */     Assert.verify(seppos != -1);
/*  94 */     String startcell = s.substring(0, seppos);
/*  95 */     String endcell = s.substring(seppos + 1);
/*     */     
/*  97 */     this.columnFirst = CellReferenceHelper.getColumn(startcell);
/*  98 */     this.rowFirst = CellReferenceHelper.getRow(startcell);
/*  99 */     this.columnLast = CellReferenceHelper.getColumn(endcell);
/* 100 */     this.rowLast = CellReferenceHelper.getRow(endcell);
/*     */     
/* 102 */     this.columnFirstRelative = CellReferenceHelper.isColumnRelative(startcell);
/* 103 */     this.rowFirstRelative = CellReferenceHelper.isRowRelative(startcell);
/* 104 */     this.columnLastRelative = CellReferenceHelper.isColumnRelative(endcell);
/* 105 */     this.rowLastRelative = CellReferenceHelper.isRowRelative(endcell);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getFirstColumn()
/*     */   {
/* 115 */     return this.columnFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getFirstRow()
/*     */   {
/* 125 */     return this.rowFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLastColumn()
/*     */   {
/* 135 */     return this.columnLast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLastRow()
/*     */   {
/* 145 */     return this.rowLast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/* 157 */     this.rowFirst = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 158 */     this.rowLast = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)]);
/* 159 */     int columnMask = IntegerHelper.getInt(data[(pos + 4)], data[(pos + 5)]);
/* 160 */     this.columnFirst = (columnMask & 0xFF);
/* 161 */     this.columnFirstRelative = ((columnMask & 0x4000) != 0);
/* 162 */     this.rowFirstRelative = ((columnMask & 0x8000) != 0);
/* 163 */     columnMask = IntegerHelper.getInt(data[(pos + 6)], data[(pos + 7)]);
/* 164 */     this.columnLast = (columnMask & 0xFF);
/* 165 */     this.columnLastRelative = ((columnMask & 0x4000) != 0);
/* 166 */     this.rowLastRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 168 */     return 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 178 */     CellReferenceHelper.getCellReference(this.columnFirst, this.rowFirst, buf);
/* 179 */     buf.append(':');
/* 180 */     CellReferenceHelper.getCellReference(this.columnLast, this.rowLast, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 190 */     byte[] data = new byte[9];
/* 191 */     data[0] = (!useAlternateCode() ? Token.AREA.getCode() : Token.AREA.getCode2());
/*     */     
/*     */ 
/* 194 */     IntegerHelper.getTwoBytes(this.rowFirst, data, 1);
/* 195 */     IntegerHelper.getTwoBytes(this.rowLast, data, 3);
/*     */     
/* 197 */     int grcol = this.columnFirst;
/*     */     
/*     */ 
/* 200 */     if (this.rowFirstRelative)
/*     */     {
/* 202 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 205 */     if (this.columnFirstRelative)
/*     */     {
/* 207 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 210 */     IntegerHelper.getTwoBytes(grcol, data, 5);
/*     */     
/* 212 */     grcol = this.columnLast;
/*     */     
/*     */ 
/* 215 */     if (this.rowLastRelative)
/*     */     {
/* 217 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 220 */     if (this.columnLastRelative)
/*     */     {
/* 222 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 225 */     IntegerHelper.getTwoBytes(grcol, data, 7);
/*     */     
/* 227 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 239 */     if (this.columnFirstRelative)
/*     */     {
/* 241 */       this.columnFirst += colAdjust;
/*     */     }
/*     */     
/* 244 */     if (this.columnLastRelative)
/*     */     {
/* 246 */       this.columnLast += colAdjust;
/*     */     }
/*     */     
/* 249 */     if (this.rowFirstRelative)
/*     */     {
/* 251 */       this.rowFirst += rowAdjust;
/*     */     }
/*     */     
/* 254 */     if (this.rowLastRelative)
/*     */     {
/* 256 */       this.rowLast += rowAdjust;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 272 */     if (!currentSheet)
/*     */     {
/* 274 */       return;
/*     */     }
/*     */     
/* 277 */     if (col <= this.columnFirst)
/*     */     {
/* 279 */       this.columnFirst += 1;
/*     */     }
/*     */     
/* 282 */     if (col <= this.columnLast)
/*     */     {
/* 284 */       this.columnLast += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 300 */     if (!currentSheet)
/*     */     {
/* 302 */       return;
/*     */     }
/*     */     
/* 305 */     if (col < this.columnFirst)
/*     */     {
/* 307 */       this.columnFirst -= 1;
/*     */     }
/*     */     
/* 310 */     if (col <= this.columnLast)
/*     */     {
/* 312 */       this.columnLast -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 328 */     if (!currentSheet)
/*     */     {
/* 330 */       return;
/*     */     }
/*     */     
/* 333 */     if (this.rowLast == 65535)
/*     */     {
/*     */ 
/* 336 */       return;
/*     */     }
/*     */     
/* 339 */     if (row <= this.rowFirst)
/*     */     {
/* 341 */       this.rowFirst += 1;
/*     */     }
/*     */     
/* 344 */     if (row <= this.rowLast)
/*     */     {
/* 346 */       this.rowLast += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 362 */     if (!currentSheet)
/*     */     {
/* 364 */       return;
/*     */     }
/*     */     
/* 367 */     if (this.rowLast == 65535)
/*     */     {
/*     */ 
/* 370 */       return;
/*     */     }
/*     */     
/* 373 */     if (row < this.rowFirst)
/*     */     {
/* 375 */       this.rowFirst -= 1;
/*     */     }
/*     */     
/* 378 */     if (row <= this.rowLast)
/*     */     {
/* 380 */       this.rowLast -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRangeData(int colFirst, int colLast, int rwFirst, int rwLast, boolean colFirstRel, boolean colLastRel, boolean rowFirstRel, boolean rowLastRel)
/*     */   {
/* 405 */     this.columnFirst = colFirst;
/* 406 */     this.columnLast = colLast;
/* 407 */     this.rowFirst = rwFirst;
/* 408 */     this.rowLast = rwLast;
/* 409 */     this.columnFirstRelative = colFirstRel;
/* 410 */     this.columnLastRelative = colLastRel;
/* 411 */     this.rowFirstRelative = rowFirstRel;
/* 412 */     this.rowLastRelative = rowLastRel;
/*     */   }
/*     */   
/*     */   void handleImportedCellReferences() {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Area.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */