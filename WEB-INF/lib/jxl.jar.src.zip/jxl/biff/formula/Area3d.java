/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Area3d
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(Area3d.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int columnFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int columnLast;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowLast;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnFirstRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowFirstRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnLastRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowLastRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet workbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Area3d(ExternalSheet es)
/*     */   {
/*  95 */     this.workbook = es;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Area3d(String s, ExternalSheet es)
/*     */     throws FormulaException
/*     */   {
/* 107 */     this.workbook = es;
/* 108 */     int seppos = s.lastIndexOf(":");
/* 109 */     Assert.verify(seppos != -1);
/* 110 */     String endcell = s.substring(seppos + 1);
/*     */     
/*     */ 
/* 113 */     int sep = s.indexOf('!');
/* 114 */     String cellString = s.substring(sep + 1, seppos);
/* 115 */     this.columnFirst = CellReferenceHelper.getColumn(cellString);
/* 116 */     this.rowFirst = CellReferenceHelper.getRow(cellString);
/*     */     
/*     */ 
/* 119 */     String sheetName = s.substring(0, sep);
/*     */     
/*     */ 
/* 122 */     if ((sheetName.charAt(0) == '\'') && (sheetName.charAt(sheetName.length() - 1) == '\''))
/*     */     {
/*     */ 
/* 125 */       sheetName = sheetName.substring(1, sheetName.length() - 1);
/*     */     }
/*     */     
/* 128 */     this.sheet = es.getExternalSheetIndex(sheetName);
/*     */     
/* 130 */     if (this.sheet < 0)
/*     */     {
/* 132 */       throw new FormulaException(FormulaException.SHEET_REF_NOT_FOUND, sheetName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 137 */     this.columnLast = CellReferenceHelper.getColumn(endcell);
/* 138 */     this.rowLast = CellReferenceHelper.getRow(endcell);
/*     */     
/* 140 */     this.columnFirstRelative = true;
/* 141 */     this.rowFirstRelative = true;
/* 142 */     this.columnLastRelative = true;
/* 143 */     this.rowLastRelative = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getFirstColumn()
/*     */   {
/* 153 */     return this.columnFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getFirstRow()
/*     */   {
/* 163 */     return this.rowFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLastColumn()
/*     */   {
/* 173 */     return this.columnLast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLastRow()
/*     */   {
/* 183 */     return this.rowLast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/* 195 */     this.sheet = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 196 */     this.rowFirst = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)]);
/* 197 */     this.rowLast = IntegerHelper.getInt(data[(pos + 4)], data[(pos + 5)]);
/* 198 */     int columnMask = IntegerHelper.getInt(data[(pos + 6)], data[(pos + 7)]);
/* 199 */     this.columnFirst = (columnMask & 0xFF);
/* 200 */     this.columnFirstRelative = ((columnMask & 0x4000) != 0);
/* 201 */     this.rowFirstRelative = ((columnMask & 0x8000) != 0);
/* 202 */     columnMask = IntegerHelper.getInt(data[(pos + 8)], data[(pos + 9)]);
/* 203 */     this.columnLast = (columnMask & 0xFF);
/* 204 */     this.columnLastRelative = ((columnMask & 0x4000) != 0);
/* 205 */     this.rowLastRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 207 */     return 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 217 */     CellReferenceHelper.getCellReference(this.sheet, this.columnFirst, this.rowFirst, this.workbook, buf);
/*     */     
/* 219 */     buf.append(':');
/* 220 */     CellReferenceHelper.getCellReference(this.columnLast, this.rowLast, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 230 */     byte[] data = new byte[11];
/* 231 */     data[0] = Token.AREA3D.getCode();
/*     */     
/* 233 */     IntegerHelper.getTwoBytes(this.sheet, data, 1);
/*     */     
/* 235 */     IntegerHelper.getTwoBytes(this.rowFirst, data, 3);
/* 236 */     IntegerHelper.getTwoBytes(this.rowLast, data, 5);
/*     */     
/* 238 */     int grcol = this.columnFirst;
/*     */     
/*     */ 
/* 241 */     if (this.rowFirstRelative)
/*     */     {
/* 243 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 246 */     if (this.columnFirstRelative)
/*     */     {
/* 248 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 251 */     IntegerHelper.getTwoBytes(grcol, data, 7);
/*     */     
/* 253 */     grcol = this.columnLast;
/*     */     
/*     */ 
/* 256 */     if (this.rowLastRelative)
/*     */     {
/* 258 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 261 */     if (this.columnLastRelative)
/*     */     {
/* 263 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 266 */     IntegerHelper.getTwoBytes(grcol, data, 9);
/*     */     
/* 268 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 280 */     if (this.columnFirstRelative)
/*     */     {
/* 282 */       this.columnFirst += colAdjust;
/*     */     }
/*     */     
/* 285 */     if (this.columnLastRelative)
/*     */     {
/* 287 */       this.columnLast += colAdjust;
/*     */     }
/*     */     
/* 290 */     if (this.rowFirstRelative)
/*     */     {
/* 292 */       this.rowFirst += rowAdjust;
/*     */     }
/*     */     
/* 295 */     if (this.rowLastRelative)
/*     */     {
/* 297 */       this.rowLast += rowAdjust;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 313 */     if (sheetIndex != this.sheet)
/*     */     {
/* 315 */       return;
/*     */     }
/*     */     
/* 318 */     if (this.columnFirst >= col)
/*     */     {
/* 320 */       this.columnFirst += 1;
/*     */     }
/*     */     
/* 323 */     if (this.columnLast >= col)
/*     */     {
/* 325 */       this.columnLast += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 341 */     if (sheetIndex != this.sheet)
/*     */     {
/* 343 */       return;
/*     */     }
/*     */     
/* 346 */     if (col < this.columnFirst)
/*     */     {
/* 348 */       this.columnFirst -= 1;
/*     */     }
/*     */     
/* 351 */     if (col <= this.columnLast)
/*     */     {
/* 353 */       this.columnLast -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 369 */     if (sheetIndex != this.sheet)
/*     */     {
/* 371 */       return;
/*     */     }
/*     */     
/* 374 */     if (this.rowLast == 65535)
/*     */     {
/*     */ 
/* 377 */       return;
/*     */     }
/*     */     
/* 380 */     if (row <= this.rowFirst)
/*     */     {
/* 382 */       this.rowFirst += 1;
/*     */     }
/*     */     
/* 385 */     if (row <= this.rowLast)
/*     */     {
/* 387 */       this.rowLast += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 403 */     if (sheetIndex != this.sheet)
/*     */     {
/* 405 */       return;
/*     */     }
/*     */     
/* 408 */     if (this.rowLast == 65535)
/*     */     {
/*     */ 
/* 411 */       return;
/*     */     }
/*     */     
/* 414 */     if (row < this.rowFirst)
/*     */     {
/* 416 */       this.rowFirst -= 1;
/*     */     }
/*     */     
/* 419 */     if (row <= this.rowLast)
/*     */     {
/* 421 */       this.rowLast -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRangeData(int sht, int colFirst, int colLast, int rwFirst, int rwLast, boolean colFirstRel, boolean colLastRel, boolean rowFirstRel, boolean rowLastRel)
/*     */   {
/* 448 */     this.sheet = sht;
/* 449 */     this.columnFirst = colFirst;
/* 450 */     this.columnLast = colLast;
/* 451 */     this.rowFirst = rwFirst;
/* 452 */     this.rowLast = rwLast;
/* 453 */     this.columnFirstRelative = colFirstRel;
/* 454 */     this.columnLastRelative = colLastRel;
/* 455 */     this.rowFirstRelative = rowFirstRel;
/* 456 */     this.rowLastRelative = rowLastRel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 465 */     setInvalid();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Area3d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */