/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Attribute
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(Attribute.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private int options;
/*     */   
/*     */ 
/*     */ 
/*     */   private int word;
/*     */   
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int SUM_MASK = 16;
/*     */   
/*     */ 
/*     */   private static final int IF_MASK = 2;
/*     */   
/*     */ 
/*     */   private static final int CHOOSE_MASK = 4;
/*     */   
/*     */ 
/*     */   private static final int GOTO_MASK = 8;
/*     */   
/*     */ 
/*     */   private VariableArgFunction ifConditions;
/*     */   
/*     */ 
/*     */ 
/*     */   public Attribute(WorkbookSettings ws)
/*     */   {
/*  72 */     this.settings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Attribute(StringFunction sf, WorkbookSettings ws)
/*     */   {
/*  83 */     this.settings = ws;
/*     */     
/*  85 */     if (sf.getFunction(this.settings) == Function.SUM)
/*     */     {
/*  87 */       this.options |= 0x10;
/*     */     }
/*  89 */     else if (sf.getFunction(this.settings) == Function.IF)
/*     */     {
/*  91 */       this.options |= 0x2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setIfConditions(VariableArgFunction vaf)
/*     */   {
/* 102 */     this.ifConditions = vaf;
/*     */     
/*     */ 
/*     */ 
/* 106 */     this.options |= 0x2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/* 118 */     this.options = data[pos];
/* 119 */     this.word = IntegerHelper.getInt(data[(pos + 1)], data[(pos + 2)]);
/*     */     
/* 121 */     if (!isChoose())
/*     */     {
/* 123 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 128 */     return 3 + (this.word + 1) * 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFunction()
/*     */   {
/* 138 */     return (this.options & 0x12) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSum()
/*     */   {
/* 148 */     return (this.options & 0x10) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIf()
/*     */   {
/* 158 */     return (this.options & 0x2) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isGoto()
/*     */   {
/* 168 */     return (this.options & 0x8) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isChoose()
/*     */   {
/* 178 */     return (this.options & 0x4) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s)
/*     */   {
/* 188 */     if ((this.options & 0x10) != 0)
/*     */     {
/* 190 */       ParseItem o1 = (ParseItem)s.pop();
/* 191 */       add(o1);
/*     */     }
/* 193 */     else if ((this.options & 0x2) != 0)
/*     */     {
/* 195 */       ParseItem o1 = (ParseItem)s.pop();
/* 196 */       add(o1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 207 */     if ((this.options & 0x10) != 0)
/*     */     {
/* 209 */       ParseItem[] operands = getOperands();
/* 210 */       buf.append(Function.SUM.getName(this.settings));
/* 211 */       buf.append('(');
/* 212 */       operands[0].getString(buf);
/* 213 */       buf.append(')');
/*     */     }
/* 215 */     else if ((this.options & 0x2) != 0)
/*     */     {
/* 217 */       buf.append(Function.IF.getName(this.settings));
/* 218 */       buf.append('(');
/*     */       
/* 220 */       ParseItem[] operands = this.ifConditions.getOperands();
/*     */       
/*     */ 
/* 223 */       for (int i = 0; i < operands.length - 1; i++)
/*     */       {
/* 225 */         operands[i].getString(buf);
/* 226 */         buf.append(',');
/*     */       }
/* 228 */       operands[(operands.length - 1)].getString(buf);
/* 229 */       buf.append(')');
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 242 */     byte[] data = new byte[0];
/* 243 */     if (isSum())
/*     */     {
/*     */ 
/* 246 */       ParseItem[] operands = getOperands();
/*     */       
/*     */ 
/* 249 */       for (int i = operands.length - 1; i >= 0; i--)
/*     */       {
/* 251 */         byte[] opdata = operands[i].getBytes();
/*     */         
/*     */ 
/* 254 */         byte[] newdata = new byte[data.length + opdata.length];
/* 255 */         System.arraycopy(data, 0, newdata, 0, data.length);
/* 256 */         System.arraycopy(opdata, 0, newdata, data.length, opdata.length);
/* 257 */         data = newdata;
/*     */       }
/*     */       
/*     */ 
/* 261 */       byte[] newdata = new byte[data.length + 4];
/* 262 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 263 */       newdata[data.length] = Token.ATTRIBUTE.getCode();
/* 264 */       newdata[(data.length + 1)] = 16;
/* 265 */       data = newdata;
/*     */     }
/* 267 */     else if (isIf())
/*     */     {
/* 269 */       return getIf();
/*     */     }
/*     */     
/* 272 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getIf()
/*     */   {
/* 282 */     ParseItem[] operands = this.ifConditions.getOperands();
/*     */     
/*     */ 
/* 285 */     int falseOffsetPos = 0;
/* 286 */     int gotoEndPos = 0;
/* 287 */     int numArgs = operands.length;
/*     */     
/*     */ 
/* 290 */     byte[] data = operands[0].getBytes();
/*     */     
/*     */ 
/* 293 */     int pos = data.length;
/* 294 */     byte[] newdata = new byte[data.length + 4];
/* 295 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 296 */     data = newdata;
/* 297 */     data[pos] = Token.ATTRIBUTE.getCode();
/* 298 */     data[(pos + 1)] = 2;
/* 299 */     falseOffsetPos = pos + 2;
/*     */     
/*     */ 
/* 302 */     byte[] truedata = operands[1].getBytes();
/* 303 */     newdata = new byte[data.length + truedata.length];
/* 304 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 305 */     System.arraycopy(truedata, 0, newdata, data.length, truedata.length);
/* 306 */     data = newdata;
/*     */     
/*     */ 
/* 309 */     pos = data.length;
/* 310 */     newdata = new byte[data.length + 4];
/* 311 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 312 */     data = newdata;
/* 313 */     data[pos] = Token.ATTRIBUTE.getCode();
/* 314 */     data[(pos + 1)] = 8;
/* 315 */     gotoEndPos = pos + 2;
/*     */     
/*     */ 
/* 318 */     if (numArgs > 2)
/*     */     {
/*     */ 
/* 321 */       IntegerHelper.getTwoBytes(data.length - falseOffsetPos - 2, data, falseOffsetPos);
/*     */       
/*     */ 
/*     */ 
/* 325 */       byte[] falsedata = operands[(numArgs - 1)].getBytes();
/* 326 */       newdata = new byte[data.length + falsedata.length];
/* 327 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 328 */       System.arraycopy(falsedata, 0, newdata, data.length, falsedata.length);
/* 329 */       data = newdata;
/*     */       
/*     */ 
/* 332 */       pos = data.length;
/* 333 */       newdata = new byte[data.length + 4];
/* 334 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 335 */       data = newdata;
/* 336 */       data[pos] = Token.ATTRIBUTE.getCode();
/* 337 */       data[(pos + 1)] = 8;
/* 338 */       data[(pos + 2)] = 3;
/*     */     }
/*     */     
/*     */ 
/* 342 */     pos = data.length;
/* 343 */     newdata = new byte[data.length + 4];
/* 344 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 345 */     data = newdata;
/* 346 */     data[pos] = Token.FUNCTIONVARARG.getCode();
/* 347 */     data[(pos + 1)] = ((byte)numArgs);
/* 348 */     data[(pos + 2)] = 1;
/* 349 */     data[(pos + 3)] = 0;
/*     */     
/*     */ 
/* 352 */     int endPos = data.length - 1;
/*     */     
/* 354 */     if (numArgs < 3)
/*     */     {
/*     */ 
/* 357 */       IntegerHelper.getTwoBytes(endPos - falseOffsetPos - 5, data, falseOffsetPos);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 362 */     IntegerHelper.getTwoBytes(endPos - gotoEndPos - 2, data, gotoEndPos);
/*     */     
/*     */ 
/* 365 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPrecedence()
/*     */   {
/* 376 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 387 */     ParseItem[] operands = null;
/*     */     
/* 389 */     if (isIf())
/*     */     {
/* 391 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else
/*     */     {
/* 395 */       operands = getOperands();
/*     */     }
/*     */     
/* 398 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 400 */       operands[i].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 416 */     ParseItem[] operands = null;
/*     */     
/* 418 */     if (isIf())
/*     */     {
/* 420 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else
/*     */     {
/* 424 */       operands = getOperands();
/*     */     }
/*     */     
/* 427 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 429 */       operands[i].columnInserted(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 445 */     ParseItem[] operands = null;
/*     */     
/* 447 */     if (isIf())
/*     */     {
/* 449 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else
/*     */     {
/* 453 */       operands = getOperands();
/*     */     }
/*     */     
/* 456 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 458 */       operands[i].columnRemoved(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 474 */     ParseItem[] operands = null;
/*     */     
/* 476 */     if (isIf())
/*     */     {
/* 478 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else
/*     */     {
/* 482 */       operands = getOperands();
/*     */     }
/*     */     
/* 485 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 487 */       operands[i].rowInserted(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 503 */     ParseItem[] operands = null;
/*     */     
/* 505 */     if (isIf())
/*     */     {
/* 507 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else
/*     */     {
/* 511 */       operands = getOperands();
/*     */     }
/*     */     
/* 514 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 516 */       operands[i].rowRemoved(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 527 */     ParseItem[] operands = null;
/*     */     
/* 529 */     if (isIf())
/*     */     {
/* 531 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else
/*     */     {
/* 535 */       operands = getOperands();
/*     */     }
/*     */     
/* 538 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 540 */       operands[i].handleImportedCellReferences();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Attribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */