/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BinaryOperator
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  32 */   private static final Logger logger = Logger.getLogger(BinaryOperator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  50 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s)
/*     */   {
/*  60 */     ParseItem o1 = (ParseItem)s.pop();
/*  61 */     ParseItem o2 = (ParseItem)s.pop();
/*     */     
/*  63 */     add(o1);
/*  64 */     add(o2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/*  74 */     ParseItem[] operands = getOperands();
/*  75 */     operands[1].getString(buf);
/*  76 */     buf.append(getSymbol());
/*  77 */     operands[0].getString(buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/*  89 */     ParseItem[] operands = getOperands();
/*  90 */     operands[1].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*  91 */     operands[0].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 106 */     ParseItem[] operands = getOperands();
/* 107 */     operands[1].columnInserted(sheetIndex, col, currentSheet);
/* 108 */     operands[0].columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 123 */     ParseItem[] operands = getOperands();
/* 124 */     operands[1].columnRemoved(sheetIndex, col, currentSheet);
/* 125 */     operands[0].columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 140 */     ParseItem[] operands = getOperands();
/* 141 */     operands[1].rowInserted(sheetIndex, row, currentSheet);
/* 142 */     operands[0].rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 157 */     ParseItem[] operands = getOperands();
/* 158 */     operands[1].rowRemoved(sheetIndex, row, currentSheet);
/* 159 */     operands[0].rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 170 */     ParseItem[] operands = getOperands();
/* 171 */     byte[] data = new byte[0];
/*     */     
/*     */ 
/* 174 */     for (int i = operands.length - 1; i >= 0; i--)
/*     */     {
/* 176 */       byte[] opdata = operands[i].getBytes();
/*     */       
/*     */ 
/* 179 */       byte[] newdata = new byte[data.length + opdata.length];
/* 180 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 181 */       System.arraycopy(opdata, 0, newdata, data.length, opdata.length);
/* 182 */       data = newdata;
/*     */     }
/*     */     
/*     */ 
/* 186 */     byte[] newdata = new byte[data.length + 1];
/* 187 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 188 */     newdata[data.length] = getToken().getCode();
/*     */     
/* 190 */     return newdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract String getSymbol();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract Token getToken();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 214 */     ParseItem[] operands = getOperands();
/* 215 */     operands[0].handleImportedCellReferences();
/* 216 */     operands[1].handleImportedCellReferences();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\BinaryOperator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */