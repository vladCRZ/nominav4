/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BooleanValue
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   private boolean value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BooleanValue() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BooleanValue(String s)
/*    */   {
/* 47 */     this.value = Boolean.valueOf(s).booleanValue();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read(byte[] data, int pos)
/*    */   {
/* 60 */     this.value = (data[pos] == 1);
/* 61 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getBytes()
/*    */   {
/* 71 */     byte[] data = new byte[2];
/* 72 */     data[0] = Token.BOOL.getCode();
/* 73 */     data[1] = ((byte)(this.value == true ? 1 : 0));
/*    */     
/* 75 */     return data;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void getString(StringBuffer buf)
/*    */   {
/* 86 */     buf.append(new Boolean(this.value).toString());
/*    */   }
/*    */   
/*    */   void handleImportedCellReferences() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\BooleanValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */