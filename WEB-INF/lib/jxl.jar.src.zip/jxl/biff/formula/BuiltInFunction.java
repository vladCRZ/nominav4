/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BuiltInFunction
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(BuiltInFunction.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Function function;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BuiltInFunction(WorkbookSettings ws)
/*     */   {
/*  56 */     this.settings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BuiltInFunction(Function f, WorkbookSettings ws)
/*     */   {
/*  67 */     this.function = f;
/*  68 */     this.settings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  80 */     int index = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  81 */     this.function = Function.getFunction(index);
/*  82 */     Assert.verify(this.function != Function.UNKNOWN, "function code " + index);
/*  83 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s)
/*     */   {
/*  94 */     ParseItem[] items = new ParseItem[this.function.getNumArgs()];
/*     */     
/*  96 */     for (int i = this.function.getNumArgs() - 1; i >= 0; i--)
/*     */     {
/*  98 */       ParseItem pi = (ParseItem)s.pop();
/*     */       
/* 100 */       items[i] = pi;
/*     */     }
/*     */     
/* 103 */     for (int i = 0; i < this.function.getNumArgs(); i++)
/*     */     {
/* 105 */       add(items[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 116 */     buf.append(this.function.getName(this.settings));
/* 117 */     buf.append('(');
/*     */     
/* 119 */     int numArgs = this.function.getNumArgs();
/*     */     
/* 121 */     if (numArgs > 0)
/*     */     {
/* 123 */       ParseItem[] operands = getOperands();
/*     */       
/*     */ 
/* 126 */       operands[0].getString(buf);
/*     */       
/* 128 */       for (int i = 1; i < numArgs; i++)
/*     */       {
/* 130 */         buf.append(',');
/* 131 */         operands[i].getString(buf);
/*     */       }
/*     */     }
/*     */     
/* 135 */     buf.append(')');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 147 */     ParseItem[] operands = getOperands();
/*     */     
/* 149 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 151 */       operands[i].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 167 */     ParseItem[] operands = getOperands();
/* 168 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 170 */       operands[i].columnInserted(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 186 */     ParseItem[] operands = getOperands();
/* 187 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 189 */       operands[i].columnRemoved(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 206 */     ParseItem[] operands = getOperands();
/* 207 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 209 */       operands[i].rowInserted(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 225 */     ParseItem[] operands = getOperands();
/* 226 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 228 */       operands[i].rowRemoved(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 239 */     ParseItem[] operands = getOperands();
/* 240 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 242 */       operands[i].handleImportedCellReferences();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 254 */     ParseItem[] operands = getOperands();
/* 255 */     byte[] data = new byte[0];
/*     */     
/* 257 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 259 */       byte[] opdata = operands[i].getBytes();
/*     */       
/*     */ 
/* 262 */       byte[] newdata = new byte[data.length + opdata.length];
/* 263 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 264 */       System.arraycopy(opdata, 0, newdata, data.length, opdata.length);
/* 265 */       data = newdata;
/*     */     }
/*     */     
/*     */ 
/* 269 */     byte[] newdata = new byte[data.length + 3];
/* 270 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 271 */     newdata[data.length] = (!useAlternateCode() ? Token.FUNCTION.getCode() : Token.FUNCTION.getCode2());
/*     */     
/* 273 */     IntegerHelper.getTwoBytes(this.function.getCode(), newdata, data.length + 1);
/*     */     
/* 275 */     return newdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPrecedence()
/*     */   {
/* 286 */     return 3;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\BuiltInFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */