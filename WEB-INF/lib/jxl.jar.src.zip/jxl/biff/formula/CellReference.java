/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CellReference
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(CellReference.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cell relativeTo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellReference(Cell rt)
/*     */   {
/*  71 */     this.relativeTo = rt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellReference() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellReference(String s)
/*     */   {
/*  88 */     this.column = CellReferenceHelper.getColumn(s);
/*  89 */     this.row = CellReferenceHelper.getRow(s);
/*  90 */     this.columnRelative = CellReferenceHelper.isColumnRelative(s);
/*  91 */     this.rowRelative = CellReferenceHelper.isRowRelative(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/* 103 */     this.row = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 104 */     int columnMask = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)]);
/* 105 */     this.column = (columnMask & 0xFF);
/* 106 */     this.columnRelative = ((columnMask & 0x4000) != 0);
/* 107 */     this.rowRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 109 */     return 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 119 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 129 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 139 */     CellReferenceHelper.getCellReference(this.column, !this.columnRelative, this.row, !this.rowRelative, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 151 */     byte[] data = new byte[5];
/* 152 */     data[0] = (!useAlternateCode() ? Token.REF.getCode() : Token.REF.getCode2());
/*     */     
/*     */ 
/* 155 */     IntegerHelper.getTwoBytes(this.row, data, 1);
/*     */     
/* 157 */     int grcol = this.column;
/*     */     
/*     */ 
/* 160 */     if (this.rowRelative)
/*     */     {
/* 162 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 165 */     if (this.columnRelative)
/*     */     {
/* 167 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 170 */     IntegerHelper.getTwoBytes(grcol, data, 3);
/*     */     
/* 172 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 184 */     if (this.columnRelative)
/*     */     {
/* 186 */       this.column += colAdjust;
/*     */     }
/*     */     
/* 189 */     if (this.rowRelative)
/*     */     {
/* 191 */       this.row += rowAdjust;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 207 */     if (!currentSheet)
/*     */     {
/* 209 */       return;
/*     */     }
/*     */     
/* 212 */     if (this.column >= col)
/*     */     {
/* 214 */       this.column += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 230 */     if (!currentSheet)
/*     */     {
/* 232 */       return;
/*     */     }
/*     */     
/* 235 */     if (this.column >= col)
/*     */     {
/* 237 */       this.column -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int r, boolean currentSheet)
/*     */   {
/* 253 */     if (!currentSheet)
/*     */     {
/* 255 */       return;
/*     */     }
/*     */     
/* 258 */     if (this.row >= r)
/*     */     {
/* 260 */       this.row += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int r, boolean currentSheet)
/*     */   {
/* 276 */     if (!currentSheet)
/*     */     {
/* 278 */       return;
/*     */     }
/*     */     
/* 281 */     if (this.row >= r)
/*     */     {
/* 283 */       this.row -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   void handleImportedCellReferences() {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\CellReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */