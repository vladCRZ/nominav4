/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CellReference3d
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(CellReference3d.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cell relativeTo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet workbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellReference3d(Cell rt, ExternalSheet w)
/*     */   {
/*  83 */     this.relativeTo = rt;
/*  84 */     this.workbook = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellReference3d(String s, ExternalSheet w)
/*     */     throws FormulaException
/*     */   {
/*  96 */     this.workbook = w;
/*  97 */     this.columnRelative = true;
/*  98 */     this.rowRelative = true;
/*     */     
/*     */ 
/* 101 */     int sep = s.indexOf('!');
/* 102 */     String cellString = s.substring(sep + 1);
/* 103 */     this.column = CellReferenceHelper.getColumn(cellString);
/* 104 */     this.row = CellReferenceHelper.getRow(cellString);
/*     */     
/*     */ 
/* 107 */     String sheetName = s.substring(0, sep);
/*     */     
/*     */ 
/* 110 */     if ((sheetName.charAt(0) == '\'') && (sheetName.charAt(sheetName.length() - 1) == '\''))
/*     */     {
/*     */ 
/* 113 */       sheetName = sheetName.substring(1, sheetName.length() - 1);
/*     */     }
/* 115 */     this.sheet = w.getExternalSheetIndex(sheetName);
/*     */     
/* 117 */     if (this.sheet < 0)
/*     */     {
/* 119 */       throw new FormulaException(FormulaException.SHEET_REF_NOT_FOUND, sheetName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/* 133 */     this.sheet = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 134 */     this.row = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)]);
/* 135 */     int columnMask = IntegerHelper.getInt(data[(pos + 4)], data[(pos + 5)]);
/* 136 */     this.column = (columnMask & 0xFF);
/* 137 */     this.columnRelative = ((columnMask & 0x4000) != 0);
/* 138 */     this.rowRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 140 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 150 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 160 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 170 */     CellReferenceHelper.getCellReference(this.sheet, this.column, !this.columnRelative, this.row, !this.rowRelative, this.workbook, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 182 */     byte[] data = new byte[7];
/* 183 */     data[0] = Token.REF3D.getCode();
/*     */     
/* 185 */     IntegerHelper.getTwoBytes(this.sheet, data, 1);
/* 186 */     IntegerHelper.getTwoBytes(this.row, data, 3);
/*     */     
/* 188 */     int grcol = this.column;
/*     */     
/*     */ 
/* 191 */     if (this.rowRelative)
/*     */     {
/* 193 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 196 */     if (this.columnRelative)
/*     */     {
/* 198 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 201 */     IntegerHelper.getTwoBytes(grcol, data, 5);
/*     */     
/* 203 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 215 */     if (this.columnRelative)
/*     */     {
/* 217 */       this.column += colAdjust;
/*     */     }
/*     */     
/* 220 */     if (this.rowRelative)
/*     */     {
/* 222 */       this.row += rowAdjust;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 238 */     if (sheetIndex != this.sheet)
/*     */     {
/* 240 */       return;
/*     */     }
/*     */     
/* 243 */     if (this.column >= col)
/*     */     {
/* 245 */       this.column += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 262 */     if (sheetIndex != this.sheet)
/*     */     {
/* 264 */       return;
/*     */     }
/*     */     
/* 267 */     if (this.column >= col)
/*     */     {
/* 269 */       this.column -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int r, boolean currentSheet)
/*     */   {
/* 285 */     if (sheetIndex != this.sheet)
/*     */     {
/* 287 */       return;
/*     */     }
/*     */     
/* 290 */     if (this.row >= r)
/*     */     {
/* 292 */       this.row += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int r, boolean currentSheet)
/*     */   {
/* 308 */     if (sheetIndex != this.sheet)
/*     */     {
/* 310 */       return;
/*     */     }
/*     */     
/* 313 */     if (this.row >= r)
/*     */     {
/* 315 */       this.row -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 326 */     setInvalid();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\CellReference3d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */