/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CellReferenceError
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/* 32 */   private static Logger logger = Logger.getLogger(CellReferenceError.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read(byte[] data, int pos)
/*    */   {
/* 52 */     return 4;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void getString(StringBuffer buf)
/*    */   {
/* 62 */     buf.append(FormulaErrorCode.REF.getDescription());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getBytes()
/*    */   {
/* 72 */     byte[] data = new byte[5];
/* 73 */     data[0] = Token.REFERR.getCode();
/*    */     
/*    */ 
/*    */ 
/* 77 */     return data;
/*    */   }
/*    */   
/*    */   void handleImportedCellReferences() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\CellReferenceError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */