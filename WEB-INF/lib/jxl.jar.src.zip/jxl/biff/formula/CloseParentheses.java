package jxl.biff.formula;

class CloseParentheses
  extends StringParseItem
{}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\CloseParentheses.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */