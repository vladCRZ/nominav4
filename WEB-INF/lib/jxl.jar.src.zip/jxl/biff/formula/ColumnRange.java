/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.biff.CellReferenceHelper;
/*    */ import jxl.common.Assert;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ColumnRange
/*    */   extends Area
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(ColumnRange.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ColumnRange() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ColumnRange(String s)
/*    */   {
/* 52 */     int seppos = s.indexOf(":");
/* 53 */     Assert.verify(seppos != -1);
/* 54 */     String startcell = s.substring(0, seppos);
/* 55 */     String endcell = s.substring(seppos + 1);
/*    */     
/* 57 */     int columnFirst = CellReferenceHelper.getColumn(startcell);
/* 58 */     int rowFirst = 0;
/* 59 */     int columnLast = CellReferenceHelper.getColumn(endcell);
/* 60 */     int rowLast = 65535;
/*    */     
/* 62 */     boolean columnFirstRelative = CellReferenceHelper.isColumnRelative(startcell);
/*    */     
/* 64 */     boolean rowFirstRelative = false;
/* 65 */     boolean columnLastRelative = CellReferenceHelper.isColumnRelative(endcell);
/* 66 */     boolean rowLastRelative = false;
/*    */     
/* 68 */     setRangeData(columnFirst, columnLast, rowFirst, rowLast, columnFirstRelative, columnLastRelative, rowFirstRelative, rowLastRelative);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void getString(StringBuffer buf)
/*    */   {
/* 81 */     CellReferenceHelper.getColumnReference(getFirstColumn(), buf);
/* 82 */     buf.append(':');
/* 83 */     CellReferenceHelper.getColumnReference(getLastColumn(), buf);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ColumnRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */