/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ColumnRange3d
/*     */   extends Area3d
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(ColumnRange3d.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet workbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ColumnRange3d(ExternalSheet es)
/*     */   {
/*  54 */     super(es);
/*  55 */     this.workbook = es;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ColumnRange3d(String s, ExternalSheet es)
/*     */     throws FormulaException
/*     */   {
/*  67 */     super(es);
/*  68 */     this.workbook = es;
/*  69 */     int seppos = s.lastIndexOf(":");
/*  70 */     Assert.verify(seppos != -1);
/*  71 */     String startcell = s.substring(0, seppos);
/*  72 */     String endcell = s.substring(seppos + 1);
/*     */     
/*     */ 
/*  75 */     int sep = s.indexOf('!');
/*  76 */     String cellString = s.substring(sep + 1, seppos);
/*  77 */     int columnFirst = CellReferenceHelper.getColumn(cellString);
/*  78 */     int rowFirst = 0;
/*     */     
/*     */ 
/*  81 */     String sheetName = s.substring(0, sep);
/*  82 */     int sheetNamePos = sheetName.lastIndexOf(']');
/*     */     
/*     */ 
/*  85 */     if ((sheetName.charAt(0) == '\'') && (sheetName.charAt(sheetName.length() - 1) == '\''))
/*     */     {
/*     */ 
/*  88 */       sheetName = sheetName.substring(1, sheetName.length() - 1);
/*     */     }
/*     */     
/*  91 */     this.sheet = es.getExternalSheetIndex(sheetName);
/*     */     
/*  93 */     if (this.sheet < 0)
/*     */     {
/*  95 */       throw new FormulaException(FormulaException.SHEET_REF_NOT_FOUND, sheetName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 100 */     int columnLast = CellReferenceHelper.getColumn(endcell);
/* 101 */     int rowLast = 65535;
/*     */     
/* 103 */     boolean columnFirstRelative = true;
/* 104 */     boolean rowFirstRelative = true;
/* 105 */     boolean columnLastRelative = true;
/* 106 */     boolean rowLastRelative = true;
/*     */     
/* 108 */     setRangeData(this.sheet, columnFirst, columnLast, rowFirst, rowLast, columnFirstRelative, rowFirstRelative, columnLastRelative, rowLastRelative);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 120 */     buf.append('\'');
/* 121 */     buf.append(this.workbook.getExternalSheetName(this.sheet));
/* 122 */     buf.append('\'');
/* 123 */     buf.append('!');
/*     */     
/* 125 */     CellReferenceHelper.getColumnReference(getFirstColumn(), buf);
/* 126 */     buf.append(':');
/* 127 */     CellReferenceHelper.getColumnReference(getLastColumn(), buf);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ColumnRange3d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */