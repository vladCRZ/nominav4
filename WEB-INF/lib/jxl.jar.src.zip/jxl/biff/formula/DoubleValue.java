/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DoubleValue
/*     */   extends NumberValue
/*     */   implements ParsedThing
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(DoubleValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DoubleValue() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DoubleValue(double v)
/*     */   {
/*  56 */     this.value = v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DoubleValue(String s)
/*     */   {
/*     */     try
/*     */     {
/*  68 */       this.value = Double.parseDouble(s);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/*  72 */       logger.warn(e, e);
/*  73 */       this.value = 0.0D;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  86 */     this.value = DoubleHelper.getIEEEDouble(data, pos);
/*     */     
/*  88 */     return 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/*  98 */     byte[] data = new byte[9];
/*  99 */     data[0] = Token.DOUBLE.getCode();
/*     */     
/* 101 */     DoubleHelper.getIEEEBytes(this.value, data, 1);
/*     */     
/* 103 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 113 */     return this.value;
/*     */   }
/*     */   
/*     */   void handleImportedCellReferences() {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\DoubleValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */