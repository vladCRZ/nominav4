/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ErrorConstant
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   private FormulaErrorCode error;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ErrorConstant() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ErrorConstant(String s)
/*    */   {
/* 48 */     this.error = FormulaErrorCode.getErrorCode(s);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read(byte[] data, int pos)
/*    */   {
/* 60 */     int code = data[pos];
/* 61 */     this.error = FormulaErrorCode.getErrorCode(code);
/* 62 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getBytes()
/*    */   {
/* 72 */     byte[] data = new byte[2];
/* 73 */     data[0] = Token.ERR.getCode();
/* 74 */     data[1] = ((byte)this.error.getCode());
/*    */     
/* 76 */     return data;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void getString(StringBuffer buf)
/*    */   {
/* 87 */     buf.append(this.error.getDescription());
/*    */   }
/*    */   
/*    */   void handleImportedCellReferences() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ErrorConstant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */