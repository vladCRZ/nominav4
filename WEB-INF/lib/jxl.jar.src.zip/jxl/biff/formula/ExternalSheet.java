package jxl.biff.formula;

import jxl.read.biff.BOFRecord;

public abstract interface ExternalSheet
{
  public abstract String getExternalSheetName(int paramInt);
  
  public abstract int getExternalSheetIndex(String paramString);
  
  public abstract int getExternalSheetIndex(int paramInt);
  
  public abstract int getLastExternalSheetIndex(String paramString);
  
  public abstract int getLastExternalSheetIndex(int paramInt);
  
  public abstract BOFRecord getWorkbookBof();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ExternalSheet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */