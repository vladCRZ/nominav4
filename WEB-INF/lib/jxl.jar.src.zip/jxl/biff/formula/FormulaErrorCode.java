/*     */ package jxl.biff.formula;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormulaErrorCode
/*     */ {
/*     */   private int errorCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String description;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private static FormulaErrorCode[] codes = new FormulaErrorCode[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FormulaErrorCode(int code, String desc)
/*     */   {
/*  50 */     this.errorCode = code;
/*  51 */     this.description = desc;
/*  52 */     FormulaErrorCode[] newcodes = new FormulaErrorCode[codes.length + 1];
/*  53 */     System.arraycopy(codes, 0, newcodes, 0, codes.length);
/*  54 */     newcodes[codes.length] = this;
/*  55 */     codes = newcodes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCode()
/*     */   {
/*  65 */     return this.errorCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  75 */     return this.description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FormulaErrorCode getErrorCode(int code)
/*     */   {
/*  86 */     boolean found = false;
/*  87 */     FormulaErrorCode ec = UNKNOWN;
/*  88 */     for (int i = 0; (i < codes.length) && (!found); i++)
/*     */     {
/*  90 */       if (codes[i].errorCode == code)
/*     */       {
/*  92 */         found = true;
/*  93 */         ec = codes[i];
/*     */       }
/*     */     }
/*  96 */     return ec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FormulaErrorCode getErrorCode(String code)
/*     */   {
/* 107 */     boolean found = false;
/* 108 */     FormulaErrorCode ec = UNKNOWN;
/*     */     
/* 110 */     if ((code == null) || (code.length() == 0))
/*     */     {
/* 112 */       return ec;
/*     */     }
/*     */     
/* 115 */     for (int i = 0; (i < codes.length) && (!found); i++)
/*     */     {
/* 117 */       if (codes[i].description.equals(code))
/*     */       {
/* 119 */         found = true;
/* 120 */         ec = codes[i];
/*     */       }
/*     */     }
/* 123 */     return ec;
/*     */   }
/*     */   
/* 126 */   public static final FormulaErrorCode UNKNOWN = new FormulaErrorCode(255, "?");
/*     */   
/* 128 */   public static final FormulaErrorCode NULL = new FormulaErrorCode(0, "#NULL!");
/*     */   
/* 130 */   public static final FormulaErrorCode DIV0 = new FormulaErrorCode(7, "#DIV/0!");
/*     */   
/* 132 */   public static final FormulaErrorCode VALUE = new FormulaErrorCode(15, "#VALUE!");
/*     */   
/* 134 */   public static final FormulaErrorCode REF = new FormulaErrorCode(23, "#REF!");
/*     */   
/* 136 */   public static final FormulaErrorCode NAME = new FormulaErrorCode(29, "#NAME?");
/*     */   
/* 138 */   public static final FormulaErrorCode NUM = new FormulaErrorCode(36, "#NUM!");
/*     */   
/* 140 */   public static final FormulaErrorCode NA = new FormulaErrorCode(42, "#N/A!");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\FormulaErrorCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */