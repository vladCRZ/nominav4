/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.read.biff.BOFRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormulaParser
/*     */ {
/*  38 */   private static final Logger logger = Logger.getLogger(FormulaParser.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Parser parser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaParser(byte[] tokens, Cell rt, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws)
/*     */     throws FormulaException
/*     */   {
/*  66 */     if ((es.getWorkbookBof() != null) && (!es.getWorkbookBof().isBiff8()))
/*     */     {
/*     */ 
/*  69 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*  71 */     Assert.verify(nt != null);
/*  72 */     this.parser = new TokenFormulaParser(tokens, rt, es, nt, ws, ParseContext.DEFAULT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaParser(byte[] tokens, Cell rt, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws, ParseContext pc)
/*     */     throws FormulaException
/*     */   {
/*  97 */     if ((es.getWorkbookBof() != null) && (!es.getWorkbookBof().isBiff8()))
/*     */     {
/*     */ 
/* 100 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/* 102 */     Assert.verify(nt != null);
/* 103 */     this.parser = new TokenFormulaParser(tokens, rt, es, nt, ws, pc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaParser(String form, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws)
/*     */   {
/* 119 */     this.parser = new StringFormulaParser(form, es, nt, ws, ParseContext.DEFAULT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaParser(String form, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws, ParseContext pc)
/*     */   {
/* 138 */     this.parser = new StringFormulaParser(form, es, nt, ws, pc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 151 */     this.parser.adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse()
/*     */     throws FormulaException
/*     */   {
/* 161 */     this.parser.parse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 172 */     return this.parser.getFormula();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 183 */     return this.parser.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 198 */     this.parser.columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 213 */     this.parser.columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 228 */     this.parser.rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 243 */     this.parser.rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handleImportedCellReferences()
/*     */   {
/* 254 */     return this.parser.handleImportedCellReferences();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\FormulaParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */