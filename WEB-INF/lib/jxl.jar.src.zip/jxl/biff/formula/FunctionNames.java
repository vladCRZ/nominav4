/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionNames
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(FunctionNames.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HashMap names;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HashMap functions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FunctionNames(Locale l)
/*     */   {
/*  59 */     ResourceBundle rb = ResourceBundle.getBundle("functions", l);
/*  60 */     Function[] allfunctions = Function.getFunctions();
/*  61 */     this.names = new HashMap(allfunctions.length);
/*  62 */     this.functions = new HashMap(allfunctions.length);
/*     */     
/*     */ 
/*  65 */     Function f = null;
/*  66 */     String n = null;
/*  67 */     String propname = null;
/*  68 */     for (int i = 0; i < allfunctions.length; i++)
/*     */     {
/*  70 */       f = allfunctions[i];
/*  71 */       propname = f.getPropertyName();
/*     */       
/*  73 */       n = propname.length() != 0 ? rb.getString(propname) : null;
/*     */       
/*  75 */       if (n != null)
/*     */       {
/*  77 */         this.names.put(f, n);
/*  78 */         this.functions.put(n, f);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Function getFunction(String s)
/*     */   {
/*  91 */     return (Function)this.functions.get(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getName(Function f)
/*     */   {
/* 102 */     return (String)this.names.get(f);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\FunctionNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */