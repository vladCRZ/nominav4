/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IntegerValue
/*     */   extends NumberValue
/*     */   implements ParsedThing
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(IntegerValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean outOfRange;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IntegerValue()
/*     */   {
/*  51 */     this.outOfRange = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IntegerValue(String s)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       this.value = Integer.parseInt(s);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/*  65 */       logger.warn(e, e);
/*  66 */       this.value = 0.0D;
/*     */     }
/*     */     
/*  69 */     short v = (short)(int)this.value;
/*  70 */     this.outOfRange = (this.value != v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  82 */     this.value = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*     */     
/*  84 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/*  94 */     byte[] data = new byte[3];
/*  95 */     data[0] = Token.INTEGER.getCode();
/*     */     
/*  97 */     IntegerHelper.getTwoBytes((int)this.value, data, 1);
/*     */     
/*  99 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 109 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isOutOfRange()
/*     */   {
/* 119 */     return this.outOfRange;
/*     */   }
/*     */   
/*     */   void handleImportedCellReferences() {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\IntegerValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */