/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MemArea
/*    */   extends SubExpression
/*    */ {
/*    */   public void getString(StringBuffer buf)
/*    */   {
/* 38 */     ParseItem[] subExpression = getSubExpression();
/*    */     
/* 40 */     if (subExpression.length == 1)
/*    */     {
/* 42 */       subExpression[0].getString(buf);
/*    */     }
/* 44 */     else if (subExpression.length == 2)
/*    */     {
/* 46 */       subExpression[1].getString(buf);
/* 47 */       buf.append(':');
/* 48 */       subExpression[0].getString(buf);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read(byte[] data, int pos)
/*    */   {
/* 62 */     setLength(IntegerHelper.getInt(data[(pos + 4)], data[(pos + 5)]));
/* 63 */     return 6;
/*    */   }
/*    */   
/*    */   void handleImportedCellReferences() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\MemArea.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */