/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MissingArg
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   public int read(byte[] data, int pos)
/*    */   {
/* 44 */     return 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getBytes()
/*    */   {
/* 54 */     byte[] data = new byte[1];
/* 55 */     data[0] = Token.MISSING_ARG.getCode();
/*    */     
/* 57 */     return data;
/*    */   }
/*    */   
/*    */   public void getString(StringBuffer buf) {}
/*    */   
/*    */   void handleImportedCellReferences() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\MissingArg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */