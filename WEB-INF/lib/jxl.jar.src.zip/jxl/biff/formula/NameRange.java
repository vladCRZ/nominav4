/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.NameRangeException;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NameRange
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(NameRange.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods nameTable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int index;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRange(WorkbookMethods nt)
/*     */   {
/*  59 */     this.nameTable = nt;
/*  60 */     Assert.verify(this.nameTable != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRange(String nm, WorkbookMethods nt)
/*     */     throws FormulaException
/*     */   {
/*  71 */     this.name = nm;
/*  72 */     this.nameTable = nt;
/*     */     
/*  74 */     this.index = this.nameTable.getNameIndex(this.name);
/*     */     
/*  76 */     if (this.index < 0)
/*     */     {
/*  78 */       throw new FormulaException(FormulaException.CELL_NAME_NOT_FOUND, this.name);
/*     */     }
/*     */     
/*  81 */     this.index += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */     throws FormulaException
/*     */   {
/*     */     try
/*     */     {
/*  95 */       this.index = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*     */       
/*  97 */       this.name = this.nameTable.getName(this.index - 1);
/*     */       
/*  99 */       return 4;
/*     */     }
/*     */     catch (NameRangeException e)
/*     */     {
/* 103 */       throw new FormulaException(FormulaException.CELL_NAME_NOT_FOUND, "");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 114 */     byte[] data = new byte[5];
/*     */     
/* 116 */     data[0] = Token.NAMED_RANGE.getValueCode();
/*     */     
/* 118 */     if (getParseContext() == ParseContext.DATA_VALIDATION)
/*     */     {
/* 120 */       data[0] = Token.NAMED_RANGE.getReferenceCode();
/*     */     }
/*     */     
/* 123 */     IntegerHelper.getTwoBytes(this.index, data, 1);
/*     */     
/* 125 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 136 */     buf.append(this.name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 147 */     setInvalid();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\NameRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */