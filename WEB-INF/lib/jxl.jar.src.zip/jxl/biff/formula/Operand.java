package jxl.biff.formula;

abstract class Operand
  extends ParseItem
{
  public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {}
  
  void columnInserted(int sheetIndex, int col, boolean currentSheet) {}
  
  void columnRemoved(int sheetIndex, int col, boolean currentSheet) {}
  
  void rowInserted(int sheetIndex, int row, boolean currentSheet) {}
  
  void rowRemoved(int sheetIndex, int row, boolean currentSheet) {}
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Operand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */