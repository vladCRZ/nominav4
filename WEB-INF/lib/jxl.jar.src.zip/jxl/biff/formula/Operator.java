/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Operator
/*    */   extends ParseItem
/*    */ {
/*    */   private ParseItem[] operands;
/*    */   
/*    */   public Operator()
/*    */   {
/* 41 */     this.operands = new ParseItem[0];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setOperandAlternateCode()
/*    */   {
/* 49 */     for (int i = 0; i < this.operands.length; i++)
/*    */     {
/* 51 */       this.operands[i].setAlternateCode();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void add(ParseItem n)
/*    */   {
/* 60 */     n.setParent(this);
/*    */     
/*    */ 
/* 63 */     ParseItem[] newOperands = new ParseItem[this.operands.length + 1];
/* 64 */     System.arraycopy(this.operands, 0, newOperands, 0, this.operands.length);
/* 65 */     newOperands[this.operands.length] = n;
/* 66 */     this.operands = newOperands;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void getOperands(Stack paramStack);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ParseItem[] getOperands()
/*    */   {
/* 79 */     return this.operands;
/*    */   }
/*    */   
/*    */   abstract int getPrecedence();
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Operator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */