/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Parenthesis
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  45 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s)
/*     */   {
/*  53 */     ParseItem pi = (ParseItem)s.pop();
/*     */     
/*  55 */     add(pi);
/*     */   }
/*     */   
/*     */   public void getString(StringBuffer buf)
/*     */   {
/*  60 */     ParseItem[] operands = getOperands();
/*  61 */     buf.append('(');
/*  62 */     operands[0].getString(buf);
/*  63 */     buf.append(')');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/*  75 */     ParseItem[] operands = getOperands();
/*  76 */     operands[0].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/*  91 */     ParseItem[] operands = getOperands();
/*  92 */     operands[0].columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 107 */     ParseItem[] operands = getOperands();
/* 108 */     operands[0].columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 123 */     ParseItem[] operands = getOperands();
/* 124 */     operands[0].rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 139 */     ParseItem[] operands = getOperands();
/* 140 */     operands[0].rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 150 */     ParseItem[] operands = getOperands();
/* 151 */     operands[0].handleImportedCellReferences();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Token getToken()
/*     */   {
/* 161 */     return Token.PARENTHESIS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 172 */     ParseItem[] operands = getOperands();
/* 173 */     byte[] data = operands[0].getBytes();
/*     */     
/*     */ 
/* 176 */     byte[] newdata = new byte[data.length + 1];
/* 177 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 178 */     newdata[data.length] = getToken().getCode();
/*     */     
/* 180 */     return newdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPrecedence()
/*     */   {
/* 191 */     return 4;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Parenthesis.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */