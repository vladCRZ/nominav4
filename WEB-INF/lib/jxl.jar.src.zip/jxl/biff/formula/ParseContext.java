/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseContext
/*    */ {
/* 27 */   public static ParseContext DEFAULT = new ParseContext();
/* 28 */   public static ParseContext DATA_VALIDATION = new ParseContext();
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ParseContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */