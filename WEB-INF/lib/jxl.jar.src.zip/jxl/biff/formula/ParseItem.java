/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ParseItem
/*     */ {
/*  30 */   private static Logger logger = Logger.getLogger(ParseItem.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseItem parent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean volatileFunction;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   private boolean alternateCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseContext parseContext;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean valid;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseItem()
/*     */   {
/*  64 */     this.volatileFunction = false;
/*  65 */     this.alternateCode = false;
/*  66 */     this.valid = true;
/*  67 */     this.parseContext = ParseContext.DEFAULT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setParent(ParseItem p)
/*     */   {
/*  75 */     this.parent = p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setVolatile()
/*     */   {
/*  83 */     this.volatileFunction = true;
/*  84 */     if ((this.parent != null) && (!this.parent.isVolatile()))
/*     */     {
/*  86 */       this.parent.setVolatile();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setInvalid()
/*     */   {
/*  95 */     this.valid = false;
/*  96 */     if (this.parent != null)
/*     */     {
/*  98 */       this.parent.setInvalid();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final boolean isVolatile()
/*     */   {
/* 109 */     return this.volatileFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final boolean isValid()
/*     */   {
/* 119 */     return this.valid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void getString(StringBuffer paramStringBuffer);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract byte[] getBytes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void adjustRelativeCellReferences(int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void columnInserted(int paramInt1, int paramInt2, boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void columnRemoved(int paramInt1, int paramInt2, boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void rowInserted(int paramInt1, int paramInt2, boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void rowRemoved(int paramInt1, int paramInt2, boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract void handleImportedCellReferences();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected void setAlternateCode()
/*     */   {
/* 205 */     this.alternateCode = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected final boolean useAlternateCode()
/*     */   {
/* 216 */     return this.alternateCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setParseContext(ParseContext pc)
/*     */   {
/* 226 */     this.parseContext = pc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ParseContext getParseContext()
/*     */   {
/* 236 */     return this.parseContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ParseItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */