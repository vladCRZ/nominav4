package jxl.biff.formula;

abstract interface ParsedThing
{
  public abstract int read(byte[] paramArrayOfByte, int paramInt)
    throws FormulaException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\ParsedThing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */