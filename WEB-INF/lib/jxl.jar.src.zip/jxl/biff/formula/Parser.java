package jxl.biff.formula;

abstract interface Parser
{
  public abstract void parse()
    throws FormulaException;
  
  public abstract String getFormula();
  
  public abstract byte[] getBytes();
  
  public abstract void adjustRelativeCellReferences(int paramInt1, int paramInt2);
  
  public abstract void columnInserted(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public abstract void columnRemoved(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public abstract void rowInserted(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public abstract void rowRemoved(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public abstract boolean handleImportedCellReferences();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Parser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */