/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Percent
/*    */   extends UnaryOperator
/*    */   implements ParsedThing
/*    */ {
/*    */   public String getSymbol()
/*    */   {
/* 36 */     return "%";
/*    */   }
/*    */   
/*    */   public void getString(StringBuffer buf)
/*    */   {
/* 41 */     ParseItem[] operands = getOperands();
/* 42 */     operands[0].getString(buf);
/* 43 */     buf.append(getSymbol());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   void handleImportedCellReferences()
/*    */   {
/* 53 */     ParseItem[] operands = getOperands();
/* 54 */     operands[0].handleImportedCellReferences();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   Token getToken()
/*    */   {
/* 64 */     return Token.PERCENT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   int getPrecedence()
/*    */   {
/* 75 */     return 5;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Percent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */