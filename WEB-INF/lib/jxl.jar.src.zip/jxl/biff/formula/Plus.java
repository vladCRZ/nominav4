/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Plus
/*    */   extends StringOperator
/*    */ {
/*    */   Operator getBinaryOperator()
/*    */   {
/* 43 */     return new Add();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   Operator getUnaryOperator()
/*    */   {
/* 51 */     return new UnaryPlus();
/*    */   }
/*    */   
/*    */   void handleImportedCellReferences() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Plus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */