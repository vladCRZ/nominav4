/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RangeSeparator
/*    */   extends BinaryOperator
/*    */   implements ParsedThing
/*    */ {
/*    */   public String getSymbol()
/*    */   {
/* 40 */     return ":";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   Token getToken()
/*    */   {
/* 50 */     return Token.RANGE;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   int getPrecedence()
/*    */   {
/* 61 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   byte[] getBytes()
/*    */   {
/* 72 */     setVolatile();
/* 73 */     setOperandAlternateCode();
/*    */     
/* 75 */     byte[] funcBytes = super.getBytes();
/*    */     
/* 77 */     byte[] bytes = new byte[funcBytes.length + 3];
/* 78 */     System.arraycopy(funcBytes, 0, bytes, 3, funcBytes.length);
/*    */     
/*    */ 
/* 81 */     bytes[0] = Token.MEM_FUNC.getCode();
/* 82 */     IntegerHelper.getTwoBytes(funcBytes.length, bytes, 1);
/*    */     
/* 84 */     return bytes;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\RangeSeparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */