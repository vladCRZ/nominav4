/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedFormulaCellReference
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(SharedFormulaCellReference.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean columnRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean rowRelative;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cell relativeTo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedFormulaCellReference(Cell rt)
/*     */   {
/*  71 */     this.relativeTo = rt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  85 */     this.row = IntegerHelper.getShort(data[pos], data[(pos + 1)]);
/*     */     
/*  87 */     int columnMask = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)]);
/*     */     
/*  89 */     this.column = ((byte)(columnMask & 0xFF));
/*  90 */     this.columnRelative = ((columnMask & 0x4000) != 0);
/*  91 */     this.rowRelative = ((columnMask & 0x8000) != 0);
/*     */     
/*  93 */     if ((this.columnRelative) && (this.relativeTo != null))
/*     */     {
/*  95 */       this.column = (this.relativeTo.getColumn() + this.column);
/*     */     }
/*     */     
/*  98 */     if ((this.rowRelative) && (this.relativeTo != null))
/*     */     {
/* 100 */       this.row = (this.relativeTo.getRow() + this.row);
/*     */     }
/*     */     
/* 103 */     return 4;
/*     */   }
/*     */   
/*     */   public int getColumn()
/*     */   {
/* 108 */     return this.column;
/*     */   }
/*     */   
/*     */   public int getRow()
/*     */   {
/* 113 */     return this.row;
/*     */   }
/*     */   
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 118 */     CellReferenceHelper.getCellReference(this.column, this.row, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 128 */     byte[] data = new byte[5];
/* 129 */     data[0] = Token.REF.getCode();
/*     */     
/* 131 */     IntegerHelper.getTwoBytes(this.row, data, 1);
/*     */     
/* 133 */     int columnMask = this.column;
/*     */     
/* 135 */     if (this.columnRelative)
/*     */     {
/* 137 */       columnMask |= 0x4000;
/*     */     }
/*     */     
/* 140 */     if (this.rowRelative)
/*     */     {
/* 142 */       columnMask |= 0x8000;
/*     */     }
/*     */     
/* 145 */     IntegerHelper.getTwoBytes(columnMask, data, 3);
/*     */     
/* 147 */     return data;
/*     */   }
/*     */   
/*     */   void handleImportedCellReferences() {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\SharedFormulaCellReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */