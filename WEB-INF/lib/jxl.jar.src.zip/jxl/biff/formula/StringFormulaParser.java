/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringFormulaParser
/*     */   implements Parser
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(StringFormulaParser.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formula;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String parsedFormula;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseItem root;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Stack arguments;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet externalSheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods nameTable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseContext parseContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringFormulaParser(String f, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws, ParseContext pc)
/*     */   {
/*  95 */     this.formula = f;
/*  96 */     this.settings = ws;
/*  97 */     this.externalSheet = es;
/*  98 */     this.nameTable = nt;
/*  99 */     this.parseContext = pc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse()
/*     */     throws FormulaException
/*     */   {
/* 109 */     ArrayList tokens = getTokens();
/*     */     
/* 111 */     Iterator i = tokens.iterator();
/*     */     
/* 113 */     this.root = parseCurrent(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseItem parseCurrent(Iterator i)
/*     */     throws FormulaException
/*     */   {
/* 126 */     Stack stack = new Stack();
/* 127 */     Stack operators = new Stack();
/* 128 */     Stack args = null;
/*     */     
/* 130 */     boolean parenthesesClosed = false;
/* 131 */     ParseItem lastParseItem = null;
/*     */     
/* 133 */     while ((i.hasNext()) && (!parenthesesClosed))
/*     */     {
/* 135 */       ParseItem pi = (ParseItem)i.next();
/* 136 */       pi.setParseContext(this.parseContext);
/*     */       
/* 138 */       if ((pi instanceof Operand))
/*     */       {
/* 140 */         handleOperand((Operand)pi, stack);
/*     */       }
/* 142 */       else if ((pi instanceof StringFunction))
/*     */       {
/* 144 */         handleFunction((StringFunction)pi, i, stack);
/*     */       }
/* 146 */       else if ((pi instanceof Operator))
/*     */       {
/* 148 */         Operator op = (Operator)pi;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 153 */         if ((op instanceof StringOperator))
/*     */         {
/* 155 */           StringOperator sop = (StringOperator)op;
/* 156 */           if ((stack.isEmpty()) || ((lastParseItem instanceof Operator)))
/*     */           {
/* 158 */             op = sop.getUnaryOperator();
/*     */           }
/*     */           else
/*     */           {
/* 162 */             op = sop.getBinaryOperator();
/*     */           }
/*     */         }
/*     */         
/* 166 */         if (operators.empty())
/*     */         {
/*     */ 
/* 169 */           operators.push(op);
/*     */         }
/*     */         else
/*     */         {
/* 173 */           Operator operator = (Operator)operators.peek();
/*     */           
/*     */ 
/*     */ 
/* 177 */           if (op.getPrecedence() < operator.getPrecedence())
/*     */           {
/* 179 */             operators.push(op);
/*     */           }
/* 181 */           else if ((op.getPrecedence() == operator.getPrecedence()) && ((op instanceof UnaryOperator)))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */             operators.push(op);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 193 */             operators.pop();
/* 194 */             operator.getOperands(stack);
/* 195 */             stack.push(operator);
/* 196 */             operators.push(op);
/*     */           }
/*     */         }
/*     */       }
/* 200 */       else if ((pi instanceof ArgumentSeparator))
/*     */       {
/*     */ 
/* 203 */         while (!operators.isEmpty())
/*     */         {
/* 205 */           Operator o = (Operator)operators.pop();
/* 206 */           o.getOperands(stack);
/* 207 */           stack.push(o);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 213 */         if (args == null)
/*     */         {
/* 215 */           args = new Stack();
/*     */         }
/*     */         
/* 218 */         args.push(stack.pop());
/* 219 */         stack.clear();
/*     */       }
/* 221 */       else if ((pi instanceof OpenParentheses))
/*     */       {
/* 223 */         ParseItem pi2 = parseCurrent(i);
/* 224 */         Parenthesis p = new Parenthesis();
/* 225 */         pi2.setParent(p);
/* 226 */         p.add(pi2);
/* 227 */         stack.push(p);
/*     */       }
/* 229 */       else if ((pi instanceof CloseParentheses))
/*     */       {
/* 231 */         parenthesesClosed = true;
/*     */       }
/*     */       
/* 234 */       lastParseItem = pi;
/*     */     }
/*     */     
/* 237 */     while (!operators.isEmpty())
/*     */     {
/* 239 */       Operator o = (Operator)operators.pop();
/* 240 */       o.getOperands(stack);
/* 241 */       stack.push(o);
/*     */     }
/*     */     
/* 244 */     ParseItem rt = !stack.empty() ? (ParseItem)stack.pop() : null;
/*     */     
/*     */ 
/*     */ 
/* 248 */     if ((args != null) && (rt != null))
/*     */     {
/* 250 */       args.push(rt);
/*     */     }
/*     */     
/* 253 */     this.arguments = args;
/*     */     
/* 255 */     if ((!stack.empty()) || (!operators.empty()))
/*     */     {
/* 257 */       logger.warn("Formula " + this.formula + " has a non-empty parse stack");
/*     */     }
/*     */     
/*     */ 
/* 261 */     return rt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList getTokens()
/*     */     throws FormulaException
/*     */   {
/* 272 */     ArrayList tokens = new ArrayList();
/*     */     
/* 274 */     StringReader sr = new StringReader(this.formula);
/* 275 */     Yylex lex = new Yylex(sr);
/* 276 */     lex.setExternalSheet(this.externalSheet);
/* 277 */     lex.setNameTable(this.nameTable);
/*     */     try
/*     */     {
/* 280 */       ParseItem pi = lex.yylex();
/* 281 */       while (pi != null)
/*     */       {
/* 283 */         tokens.add(pi);
/* 284 */         pi = lex.yylex();
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 289 */       logger.warn(e.toString());
/*     */     }
/*     */     catch (Error e)
/*     */     {
/* 293 */       throw new FormulaException(FormulaException.LEXICAL_ERROR, this.formula + " at char  " + lex.getPos());
/*     */     }
/*     */     
/*     */ 
/* 297 */     return tokens;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */   {
/* 306 */     if (this.parsedFormula == null)
/*     */     {
/* 308 */       StringBuffer sb = new StringBuffer();
/* 309 */       this.root.getString(sb);
/* 310 */       this.parsedFormula = sb.toString();
/*     */     }
/*     */     
/* 313 */     return this.parsedFormula;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 323 */     byte[] bytes = this.root.getBytes();
/*     */     
/* 325 */     if (this.root.isVolatile())
/*     */     {
/* 327 */       byte[] newBytes = new byte[bytes.length + 4];
/* 328 */       System.arraycopy(bytes, 0, newBytes, 4, bytes.length);
/* 329 */       newBytes[0] = Token.ATTRIBUTE.getCode();
/* 330 */       newBytes[1] = 1;
/* 331 */       bytes = newBytes;
/*     */     }
/*     */     
/* 334 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void handleFunction(StringFunction sf, Iterator i, Stack stack)
/*     */     throws FormulaException
/*     */   {
/* 349 */     ParseItem pi2 = parseCurrent(i);
/*     */     
/*     */ 
/* 352 */     if (sf.getFunction(this.settings) == Function.UNKNOWN)
/*     */     {
/* 354 */       throw new FormulaException(FormulaException.UNRECOGNIZED_FUNCTION);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 359 */     if ((sf.getFunction(this.settings) == Function.SUM) && (this.arguments == null))
/*     */     {
/*     */ 
/* 362 */       Attribute a = new Attribute(sf, this.settings);
/* 363 */       a.add(pi2);
/* 364 */       stack.push(a);
/* 365 */       return;
/*     */     }
/*     */     
/* 368 */     if (sf.getFunction(this.settings) == Function.IF)
/*     */     {
/*     */ 
/* 371 */       Attribute a = new Attribute(sf, this.settings);
/*     */       
/*     */ 
/*     */ 
/* 375 */       VariableArgFunction vaf = new VariableArgFunction(this.settings);
/* 376 */       int numargs = this.arguments.size();
/* 377 */       for (int j = 0; j < numargs; j++)
/*     */       {
/* 379 */         ParseItem pi3 = (ParseItem)this.arguments.get(j);
/* 380 */         vaf.add(pi3);
/*     */       }
/*     */       
/* 383 */       a.setIfConditions(vaf);
/* 384 */       stack.push(a);
/* 385 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 390 */     if (sf.getFunction(this.settings).getNumArgs() == 255)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 395 */       if (this.arguments == null)
/*     */       {
/* 397 */         int numArgs = pi2 != null ? 1 : 0;
/* 398 */         VariableArgFunction vaf = new VariableArgFunction(sf.getFunction(this.settings), numArgs, this.settings);
/*     */         
/*     */ 
/* 401 */         if (pi2 != null)
/*     */         {
/* 403 */           vaf.add(pi2);
/*     */         }
/*     */         
/* 406 */         stack.push(vaf);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 411 */         int numargs = this.arguments.size();
/* 412 */         VariableArgFunction vaf = new VariableArgFunction(sf.getFunction(this.settings), numargs, this.settings);
/*     */         
/*     */ 
/* 415 */         ParseItem[] args = new ParseItem[numargs];
/* 416 */         for (int j = 0; j < numargs; j++)
/*     */         {
/* 418 */           ParseItem pi3 = (ParseItem)this.arguments.pop();
/* 419 */           args[(numargs - j - 1)] = pi3;
/*     */         }
/*     */         
/* 422 */         for (int j = 0; j < args.length; j++)
/*     */         {
/* 424 */           vaf.add(args[j]);
/*     */         }
/* 426 */         stack.push(vaf);
/* 427 */         this.arguments.clear();
/* 428 */         this.arguments = null;
/*     */       }
/* 430 */       return;
/*     */     }
/*     */     
/*     */ 
/* 434 */     BuiltInFunction bif = new BuiltInFunction(sf.getFunction(this.settings), this.settings);
/*     */     
/*     */ 
/* 437 */     int numargs = sf.getFunction(this.settings).getNumArgs();
/* 438 */     if (numargs == 1)
/*     */     {
/*     */ 
/* 441 */       bif.add(pi2);
/*     */     }
/*     */     else
/*     */     {
/* 445 */       if (((this.arguments == null) && (numargs != 0)) || ((this.arguments != null) && (numargs != this.arguments.size())))
/*     */       {
/*     */ 
/* 448 */         throw new FormulaException(FormulaException.INCORRECT_ARGUMENTS);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 453 */       for (int j = 0; j < numargs; j++)
/*     */       {
/* 455 */         ParseItem pi3 = (ParseItem)this.arguments.get(j);
/* 456 */         bif.add(pi3);
/*     */       }
/*     */     }
/* 459 */     stack.push(bif);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 470 */     this.root.adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 485 */     this.root.columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 501 */     this.root.columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 516 */     this.root.rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 531 */     this.root.rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void handleOperand(Operand o, Stack stack)
/*     */   {
/* 542 */     if (!(o instanceof IntegerValue))
/*     */     {
/* 544 */       stack.push(o);
/* 545 */       return;
/*     */     }
/*     */     
/* 548 */     if ((o instanceof IntegerValue))
/*     */     {
/* 550 */       IntegerValue iv = (IntegerValue)o;
/* 551 */       if (!iv.isOutOfRange())
/*     */       {
/* 553 */         stack.push(iv);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 558 */         DoubleValue dv = new DoubleValue(iv.getValue());
/* 559 */         stack.push(dv);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handleImportedCellReferences()
/*     */   {
/* 572 */     this.root.handleImportedCellReferences();
/* 573 */     return this.root.isValid();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\StringFormulaParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */