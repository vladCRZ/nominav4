/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.WorkbookSettings;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringFunction
/*    */   extends StringParseItem
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(StringFunction.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Function function;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String functionString;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   StringFunction(String s)
/*    */   {
/* 54 */     this.functionString = s.substring(0, s.length() - 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   Function getFunction(WorkbookSettings ws)
/*    */   {
/* 65 */     if (this.function == null)
/*    */     {
/* 67 */       this.function = Function.getFunction(this.functionString, ws);
/*    */     }
/* 69 */     return this.function;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\StringFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */