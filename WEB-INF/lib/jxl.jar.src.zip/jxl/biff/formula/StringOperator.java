/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.common.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class StringOperator
/*     */   extends Operator
/*     */ {
/*     */   public void getOperands(Stack s)
/*     */   {
/*  48 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPrecedence()
/*     */   {
/*  58 */     Assert.verify(false);
/*  59 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/*  69 */     Assert.verify(false);
/*  70 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void getString(StringBuffer buf)
/*     */   {
/*  78 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/*  89 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 103 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 118 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 133 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 148 */     Assert.verify(false);
/*     */   }
/*     */   
/*     */   abstract Operator getBinaryOperator();
/*     */   
/*     */   abstract Operator getUnaryOperator();
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\StringOperator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */