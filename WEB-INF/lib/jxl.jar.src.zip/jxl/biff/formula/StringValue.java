/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringValue
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  37 */   private static final Logger logger = Logger.getLogger(StringValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringValue(WorkbookSettings ws)
/*     */   {
/*  54 */     this.settings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringValue(String s)
/*     */   {
/*  65 */     this.value = s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  77 */     int length = data[pos] & 0xFF;
/*  78 */     int consumed = 2;
/*     */     
/*  80 */     if ((data[(pos + 1)] & 0x1) == 0)
/*     */     {
/*  82 */       this.value = StringHelper.getString(data, length, pos + 2, this.settings);
/*  83 */       consumed += length;
/*     */     }
/*     */     else
/*     */     {
/*  87 */       this.value = StringHelper.getUnicodeString(data, length, pos + 2);
/*  88 */       consumed += length * 2;
/*     */     }
/*     */     
/*  91 */     return consumed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 101 */     byte[] data = new byte[this.value.length() * 2 + 3];
/* 102 */     data[0] = Token.STRING.getCode();
/* 103 */     data[1] = ((byte)this.value.length());
/* 104 */     data[2] = 1;
/* 105 */     StringHelper.getUnicodeBytes(this.value, data, 3);
/*     */     
/* 107 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 118 */     buf.append("\"");
/* 119 */     buf.append(this.value);
/* 120 */     buf.append("\"");
/*     */   }
/*     */   
/*     */   void handleImportedCellReferences() {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\StringValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */