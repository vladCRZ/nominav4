/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SubExpression
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*     */   private int length;
/*     */   private ParseItem[] subExpression;
/*     */   
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  57 */     this.length = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  58 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/*  77 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPrecedence()
/*     */   {
/*  89 */     return 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  99 */     return this.length;
/*     */   }
/*     */   
/*     */   protected final void setLength(int l)
/*     */   {
/* 104 */     this.length = l;
/*     */   }
/*     */   
/*     */   public void setSubExpression(ParseItem[] pi)
/*     */   {
/* 109 */     this.subExpression = pi;
/*     */   }
/*     */   
/*     */   protected ParseItem[] getSubExpression()
/*     */   {
/* 114 */     return this.subExpression;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\SubExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */