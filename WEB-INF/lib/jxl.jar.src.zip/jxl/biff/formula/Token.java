/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Token
/*     */ {
/*     */   public final int[] value;
/*  38 */   private static HashMap tokens = new HashMap(20);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Token(int v)
/*     */   {
/*  48 */     this.value = new int[] { v };
/*     */     
/*  50 */     tokens.put(new Integer(v), this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Token(int v1, int v2)
/*     */   {
/*  61 */     this.value = new int[] { v1, v2 };
/*     */     
/*  63 */     tokens.put(new Integer(v1), this);
/*  64 */     tokens.put(new Integer(v2), this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Token(int v1, int v2, int v3)
/*     */   {
/*  75 */     this.value = new int[] { v1, v2, v3 };
/*     */     
/*  77 */     tokens.put(new Integer(v1), this);
/*  78 */     tokens.put(new Integer(v2), this);
/*  79 */     tokens.put(new Integer(v3), this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Token(int v1, int v2, int v3, int v4)
/*     */   {
/*  90 */     this.value = new int[] { v1, v2, v3, v4 };
/*     */     
/*  92 */     tokens.put(new Integer(v1), this);
/*  93 */     tokens.put(new Integer(v2), this);
/*  94 */     tokens.put(new Integer(v3), this);
/*  95 */     tokens.put(new Integer(v4), this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Token(int v1, int v2, int v3, int v4, int v5)
/*     */   {
/* 106 */     this.value = new int[] { v1, v2, v3, v4, v5 };
/*     */     
/* 108 */     tokens.put(new Integer(v1), this);
/* 109 */     tokens.put(new Integer(v2), this);
/* 110 */     tokens.put(new Integer(v3), this);
/* 111 */     tokens.put(new Integer(v4), this);
/* 112 */     tokens.put(new Integer(v5), this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getCode()
/*     */   {
/* 122 */     return (byte)this.value[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getReferenceCode()
/*     */   {
/* 133 */     return (byte)this.value[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getCode2()
/*     */   {
/* 144 */     return (byte)(this.value.length > 0 ? this.value[1] : this.value[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getValueCode()
/*     */   {
/* 155 */     return (byte)(this.value.length > 0 ? this.value[1] : this.value[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Token getToken(int v)
/*     */   {
/* 163 */     Token t = (Token)tokens.get(new Integer(v));
/*     */     
/* 165 */     return t != null ? t : UNKNOWN;
/*     */   }
/*     */   
/*     */ 
/* 169 */   public static final Token REF = new Token(68, 36, 100);
/* 170 */   public static final Token REF3D = new Token(90, 58, 122);
/* 171 */   public static final Token MISSING_ARG = new Token(22);
/* 172 */   public static final Token STRING = new Token(23);
/* 173 */   public static final Token ERR = new Token(28);
/* 174 */   public static final Token BOOL = new Token(29);
/* 175 */   public static final Token INTEGER = new Token(30);
/* 176 */   public static final Token DOUBLE = new Token(31);
/* 177 */   public static final Token REFERR = new Token(42, 74, 106);
/* 178 */   public static final Token REFV = new Token(44, 76, 108);
/* 179 */   public static final Token AREAV = new Token(45, 77, 109);
/* 180 */   public static final Token MEM_AREA = new Token(38, 70, 102);
/* 181 */   public static final Token AREA = new Token(37, 101, 69);
/* 182 */   public static final Token NAMED_RANGE = new Token(35, 67, 99);
/*     */   
/* 184 */   public static final Token NAME = new Token(57, 89);
/* 185 */   public static final Token AREA3D = new Token(59, 91);
/*     */   
/*     */ 
/* 188 */   public static final Token UNARY_PLUS = new Token(18);
/* 189 */   public static final Token UNARY_MINUS = new Token(19);
/* 190 */   public static final Token PERCENT = new Token(20);
/* 191 */   public static final Token PARENTHESIS = new Token(21);
/*     */   
/*     */ 
/* 194 */   public static final Token ADD = new Token(3);
/* 195 */   public static final Token SUBTRACT = new Token(4);
/* 196 */   public static final Token MULTIPLY = new Token(5);
/* 197 */   public static final Token DIVIDE = new Token(6);
/* 198 */   public static final Token POWER = new Token(7);
/* 199 */   public static final Token CONCAT = new Token(8);
/* 200 */   public static final Token LESS_THAN = new Token(9);
/* 201 */   public static final Token LESS_EQUAL = new Token(10);
/* 202 */   public static final Token EQUAL = new Token(11);
/* 203 */   public static final Token GREATER_EQUAL = new Token(12);
/* 204 */   public static final Token GREATER_THAN = new Token(13);
/* 205 */   public static final Token NOT_EQUAL = new Token(14);
/* 206 */   public static final Token UNION = new Token(16);
/* 207 */   public static final Token RANGE = new Token(17);
/*     */   
/*     */ 
/* 210 */   public static final Token FUNCTION = new Token(65, 33, 97);
/* 211 */   public static final Token FUNCTIONVARARG = new Token(66, 34, 98);
/*     */   
/*     */ 
/* 214 */   public static final Token ATTRIBUTE = new Token(25);
/* 215 */   public static final Token MEM_FUNC = new Token(41, 73, 105);
/*     */   
/*     */ 
/* 218 */   public static final Token UNKNOWN = new Token(65535);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Token.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */