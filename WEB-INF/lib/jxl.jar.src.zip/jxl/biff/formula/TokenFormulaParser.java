/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.Cell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TokenFormulaParser
/*     */   implements Parser
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(TokenFormulaParser.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] tokenData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cell relativeTo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseItem root;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Stack tokenStack;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet workbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods nameTable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseContext parseContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TokenFormulaParser(byte[] data, Cell c, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws, ParseContext pc)
/*     */   {
/*  98 */     this.tokenData = data;
/*  99 */     this.pos = 0;
/* 100 */     this.relativeTo = c;
/* 101 */     this.workbook = es;
/* 102 */     this.nameTable = nt;
/* 103 */     this.tokenStack = new Stack();
/* 104 */     this.settings = ws;
/* 105 */     this.parseContext = pc;
/*     */     
/* 107 */     Assert.verify(this.nameTable != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse()
/*     */     throws FormulaException
/*     */   {
/* 118 */     parseSubExpression(this.tokenData.length);
/*     */     
/*     */ 
/*     */ 
/* 122 */     this.root = ((ParseItem)this.tokenStack.pop());
/*     */     
/* 124 */     Assert.verify(this.tokenStack.empty());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseSubExpression(int len)
/*     */     throws FormulaException
/*     */   {
/* 137 */     int tokenVal = 0;
/* 138 */     Token t = null;
/*     */     
/*     */ 
/*     */ 
/* 142 */     Stack ifStack = new Stack();
/*     */     
/*     */ 
/* 145 */     int endpos = this.pos + len;
/*     */     
/* 147 */     while (this.pos < endpos)
/*     */     {
/* 149 */       tokenVal = this.tokenData[this.pos];
/* 150 */       this.pos += 1;
/*     */       
/* 152 */       t = Token.getToken(tokenVal);
/*     */       
/* 154 */       if (t == Token.UNKNOWN)
/*     */       {
/* 156 */         throw new FormulaException(FormulaException.UNRECOGNIZED_TOKEN, tokenVal);
/*     */       }
/*     */       
/*     */ 
/* 160 */       Assert.verify(t != Token.UNKNOWN);
/*     */       
/*     */ 
/* 163 */       if (t == Token.REF)
/*     */       {
/* 165 */         CellReference cr = new CellReference(this.relativeTo);
/* 166 */         this.pos += cr.read(this.tokenData, this.pos);
/* 167 */         this.tokenStack.push(cr);
/*     */       }
/* 169 */       else if (t == Token.REFERR)
/*     */       {
/* 171 */         CellReferenceError cr = new CellReferenceError();
/* 172 */         this.pos += cr.read(this.tokenData, this.pos);
/* 173 */         this.tokenStack.push(cr);
/*     */       }
/* 175 */       else if (t == Token.ERR)
/*     */       {
/* 177 */         ErrorConstant ec = new ErrorConstant();
/* 178 */         this.pos += ec.read(this.tokenData, this.pos);
/* 179 */         this.tokenStack.push(ec);
/*     */       }
/* 181 */       else if (t == Token.REFV)
/*     */       {
/* 183 */         SharedFormulaCellReference cr = new SharedFormulaCellReference(this.relativeTo);
/*     */         
/* 185 */         this.pos += cr.read(this.tokenData, this.pos);
/* 186 */         this.tokenStack.push(cr);
/*     */       }
/* 188 */       else if (t == Token.REF3D)
/*     */       {
/* 190 */         CellReference3d cr = new CellReference3d(this.relativeTo, this.workbook);
/* 191 */         this.pos += cr.read(this.tokenData, this.pos);
/* 192 */         this.tokenStack.push(cr);
/*     */       }
/* 194 */       else if (t == Token.AREA)
/*     */       {
/* 196 */         Area a = new Area();
/* 197 */         this.pos += a.read(this.tokenData, this.pos);
/* 198 */         this.tokenStack.push(a);
/*     */       }
/* 200 */       else if (t == Token.AREAV)
/*     */       {
/* 202 */         SharedFormulaArea a = new SharedFormulaArea(this.relativeTo);
/* 203 */         this.pos += a.read(this.tokenData, this.pos);
/* 204 */         this.tokenStack.push(a);
/*     */       }
/* 206 */       else if (t == Token.AREA3D)
/*     */       {
/* 208 */         Area3d a = new Area3d(this.workbook);
/* 209 */         this.pos += a.read(this.tokenData, this.pos);
/* 210 */         this.tokenStack.push(a);
/*     */       }
/* 212 */       else if (t == Token.NAME)
/*     */       {
/* 214 */         Name n = new Name();
/* 215 */         this.pos += n.read(this.tokenData, this.pos);
/* 216 */         n.setParseContext(this.parseContext);
/* 217 */         this.tokenStack.push(n);
/*     */       }
/* 219 */       else if (t == Token.NAMED_RANGE)
/*     */       {
/* 221 */         NameRange nr = new NameRange(this.nameTable);
/* 222 */         this.pos += nr.read(this.tokenData, this.pos);
/* 223 */         nr.setParseContext(this.parseContext);
/* 224 */         this.tokenStack.push(nr);
/*     */       }
/* 226 */       else if (t == Token.INTEGER)
/*     */       {
/* 228 */         IntegerValue i = new IntegerValue();
/* 229 */         this.pos += i.read(this.tokenData, this.pos);
/* 230 */         this.tokenStack.push(i);
/*     */       }
/* 232 */       else if (t == Token.DOUBLE)
/*     */       {
/* 234 */         DoubleValue d = new DoubleValue();
/* 235 */         this.pos += d.read(this.tokenData, this.pos);
/* 236 */         this.tokenStack.push(d);
/*     */       }
/* 238 */       else if (t == Token.BOOL)
/*     */       {
/* 240 */         BooleanValue bv = new BooleanValue();
/* 241 */         this.pos += bv.read(this.tokenData, this.pos);
/* 242 */         this.tokenStack.push(bv);
/*     */       }
/* 244 */       else if (t == Token.STRING)
/*     */       {
/* 246 */         StringValue sv = new StringValue(this.settings);
/* 247 */         this.pos += sv.read(this.tokenData, this.pos);
/* 248 */         this.tokenStack.push(sv);
/*     */       }
/* 250 */       else if (t == Token.MISSING_ARG)
/*     */       {
/* 252 */         MissingArg ma = new MissingArg();
/* 253 */         this.pos += ma.read(this.tokenData, this.pos);
/* 254 */         this.tokenStack.push(ma);
/*     */ 
/*     */ 
/*     */       }
/* 258 */       else if (t == Token.UNARY_PLUS)
/*     */       {
/* 260 */         UnaryPlus up = new UnaryPlus();
/* 261 */         this.pos += up.read(this.tokenData, this.pos);
/* 262 */         addOperator(up);
/*     */       }
/* 264 */       else if (t == Token.UNARY_MINUS)
/*     */       {
/* 266 */         UnaryMinus um = new UnaryMinus();
/* 267 */         this.pos += um.read(this.tokenData, this.pos);
/* 268 */         addOperator(um);
/*     */       }
/* 270 */       else if (t == Token.PERCENT)
/*     */       {
/* 272 */         Percent p = new Percent();
/* 273 */         this.pos += p.read(this.tokenData, this.pos);
/* 274 */         addOperator(p);
/*     */ 
/*     */ 
/*     */       }
/* 278 */       else if (t == Token.SUBTRACT)
/*     */       {
/* 280 */         Subtract s = new Subtract();
/* 281 */         this.pos += s.read(this.tokenData, this.pos);
/* 282 */         addOperator(s);
/*     */       }
/* 284 */       else if (t == Token.ADD)
/*     */       {
/* 286 */         Add s = new Add();
/* 287 */         this.pos += s.read(this.tokenData, this.pos);
/* 288 */         addOperator(s);
/*     */       }
/* 290 */       else if (t == Token.MULTIPLY)
/*     */       {
/* 292 */         Multiply s = new Multiply();
/* 293 */         this.pos += s.read(this.tokenData, this.pos);
/* 294 */         addOperator(s);
/*     */       }
/* 296 */       else if (t == Token.DIVIDE)
/*     */       {
/* 298 */         Divide s = new Divide();
/* 299 */         this.pos += s.read(this.tokenData, this.pos);
/* 300 */         addOperator(s);
/*     */       }
/* 302 */       else if (t == Token.CONCAT)
/*     */       {
/* 304 */         Concatenate c = new Concatenate();
/* 305 */         this.pos += c.read(this.tokenData, this.pos);
/* 306 */         addOperator(c);
/*     */       }
/* 308 */       else if (t == Token.POWER)
/*     */       {
/* 310 */         Power p = new Power();
/* 311 */         this.pos += p.read(this.tokenData, this.pos);
/* 312 */         addOperator(p);
/*     */       }
/* 314 */       else if (t == Token.LESS_THAN)
/*     */       {
/* 316 */         LessThan lt = new LessThan();
/* 317 */         this.pos += lt.read(this.tokenData, this.pos);
/* 318 */         addOperator(lt);
/*     */       }
/* 320 */       else if (t == Token.LESS_EQUAL)
/*     */       {
/* 322 */         LessEqual lte = new LessEqual();
/* 323 */         this.pos += lte.read(this.tokenData, this.pos);
/* 324 */         addOperator(lte);
/*     */       }
/* 326 */       else if (t == Token.GREATER_THAN)
/*     */       {
/* 328 */         GreaterThan gt = new GreaterThan();
/* 329 */         this.pos += gt.read(this.tokenData, this.pos);
/* 330 */         addOperator(gt);
/*     */       }
/* 332 */       else if (t == Token.GREATER_EQUAL)
/*     */       {
/* 334 */         GreaterEqual gte = new GreaterEqual();
/* 335 */         this.pos += gte.read(this.tokenData, this.pos);
/* 336 */         addOperator(gte);
/*     */       }
/* 338 */       else if (t == Token.NOT_EQUAL)
/*     */       {
/* 340 */         NotEqual ne = new NotEqual();
/* 341 */         this.pos += ne.read(this.tokenData, this.pos);
/* 342 */         addOperator(ne);
/*     */       }
/* 344 */       else if (t == Token.EQUAL)
/*     */       {
/* 346 */         Equal e = new Equal();
/* 347 */         this.pos += e.read(this.tokenData, this.pos);
/* 348 */         addOperator(e);
/*     */       }
/* 350 */       else if (t == Token.PARENTHESIS)
/*     */       {
/* 352 */         Parenthesis p = new Parenthesis();
/* 353 */         this.pos += p.read(this.tokenData, this.pos);
/* 354 */         addOperator(p);
/*     */ 
/*     */ 
/*     */       }
/* 358 */       else if (t == Token.ATTRIBUTE)
/*     */       {
/* 360 */         Attribute a = new Attribute(this.settings);
/* 361 */         this.pos += a.read(this.tokenData, this.pos);
/*     */         
/* 363 */         if (a.isSum())
/*     */         {
/* 365 */           addOperator(a);
/*     */         }
/* 367 */         else if (a.isIf())
/*     */         {
/*     */ 
/* 370 */           ifStack.push(a);
/*     */         }
/*     */       }
/* 373 */       else if (t == Token.FUNCTION)
/*     */       {
/* 375 */         BuiltInFunction bif = new BuiltInFunction(this.settings);
/* 376 */         this.pos += bif.read(this.tokenData, this.pos);
/*     */         
/* 378 */         addOperator(bif);
/*     */       }
/* 380 */       else if (t == Token.FUNCTIONVARARG)
/*     */       {
/* 382 */         VariableArgFunction vaf = new VariableArgFunction(this.settings);
/* 383 */         this.pos += vaf.read(this.tokenData, this.pos);
/*     */         
/* 385 */         if (vaf.getFunction() != Function.ATTRIBUTE)
/*     */         {
/* 387 */           addOperator(vaf);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 393 */           vaf.getOperands(this.tokenStack);
/*     */           
/* 395 */           Attribute ifattr = null;
/* 396 */           if (ifStack.empty())
/*     */           {
/* 398 */             ifattr = new Attribute(this.settings);
/*     */           }
/*     */           else
/*     */           {
/* 402 */             ifattr = (Attribute)ifStack.pop();
/*     */           }
/*     */           
/* 405 */           ifattr.setIfConditions(vaf);
/* 406 */           this.tokenStack.push(ifattr);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 411 */       else if (t == Token.MEM_FUNC)
/*     */       {
/* 413 */         MemFunc memFunc = new MemFunc();
/* 414 */         handleMemoryFunction(memFunc);
/*     */       }
/* 416 */       else if (t == Token.MEM_AREA)
/*     */       {
/* 418 */         MemArea memArea = new MemArea();
/* 419 */         handleMemoryFunction(memArea);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void handleMemoryFunction(SubExpression subxp)
/*     */     throws FormulaException
/*     */   {
/* 430 */     this.pos += subxp.read(this.tokenData, this.pos);
/*     */     
/*     */ 
/* 433 */     Stack oldStack = this.tokenStack;
/* 434 */     this.tokenStack = new Stack();
/*     */     
/* 436 */     parseSubExpression(subxp.getLength());
/*     */     
/* 438 */     ParseItem[] subexpr = new ParseItem[this.tokenStack.size()];
/* 439 */     int i = 0;
/* 440 */     while (!this.tokenStack.isEmpty())
/*     */     {
/* 442 */       subexpr[i] = ((ParseItem)this.tokenStack.pop());
/* 443 */       i++;
/*     */     }
/*     */     
/* 446 */     subxp.setSubExpression(subexpr);
/*     */     
/* 448 */     this.tokenStack = oldStack;
/* 449 */     this.tokenStack.push(subxp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addOperator(Operator o)
/*     */   {
/* 459 */     o.getOperands(this.tokenStack);
/*     */     
/*     */ 
/* 462 */     this.tokenStack.push(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */   {
/* 470 */     StringBuffer sb = new StringBuffer();
/* 471 */     this.root.getString(sb);
/* 472 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 484 */     this.root.adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 495 */     return this.root.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 510 */     this.root.columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 524 */     this.root.columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 539 */     this.root.rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 554 */     this.root.rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handleImportedCellReferences()
/*     */   {
/* 565 */     this.root.handleImportedCellReferences();
/* 566 */     return this.root.isValid();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\TokenFormulaParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */