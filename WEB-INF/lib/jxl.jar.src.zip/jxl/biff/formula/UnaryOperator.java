/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class UnaryOperator
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*     */   public int read(byte[] data, int pos)
/*     */   {
/*  45 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s)
/*     */   {
/*  53 */     ParseItem o1 = (ParseItem)s.pop();
/*     */     
/*  55 */     add(o1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getString(StringBuffer buf)
/*     */   {
/*  65 */     ParseItem[] operands = getOperands();
/*  66 */     buf.append(getSymbol());
/*  67 */     operands[0].getString(buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/*  79 */     ParseItem[] operands = getOperands();
/*  80 */     operands[0].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/*  95 */     ParseItem[] operands = getOperands();
/*  96 */     operands[0].columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 111 */     ParseItem[] operands = getOperands();
/* 112 */     operands[0].columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 127 */     ParseItem[] operands = getOperands();
/* 128 */     operands[0].rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 143 */     ParseItem[] operands = getOperands();
/* 144 */     operands[0].rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 155 */     ParseItem[] operands = getOperands();
/* 156 */     byte[] data = operands[0].getBytes();
/*     */     
/*     */ 
/* 159 */     byte[] newdata = new byte[data.length + 1];
/* 160 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 161 */     newdata[data.length] = getToken().getCode();
/*     */     
/* 163 */     return newdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract String getSymbol();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract Token getToken();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 187 */     ParseItem[] operands = getOperands();
/* 188 */     operands[0].handleImportedCellReferences();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\UnaryOperator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */