/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VariableArgFunction
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(VariableArgFunction.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Function function;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int arguments;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean readFromSheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VariableArgFunction(WorkbookSettings ws)
/*     */   {
/*  66 */     this.readFromSheet = true;
/*  67 */     this.settings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VariableArgFunction(Function f, int a, WorkbookSettings ws)
/*     */   {
/*  78 */     this.function = f;
/*  79 */     this.arguments = a;
/*  80 */     this.readFromSheet = false;
/*  81 */     this.settings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] data, int pos)
/*     */     throws FormulaException
/*     */   {
/*  94 */     this.arguments = data[pos];
/*  95 */     int index = IntegerHelper.getInt(data[(pos + 1)], data[(pos + 2)]);
/*  96 */     this.function = Function.getFunction(index);
/*     */     
/*  98 */     if (this.function == Function.UNKNOWN)
/*     */     {
/* 100 */       throw new FormulaException(FormulaException.UNRECOGNIZED_FUNCTION, index);
/*     */     }
/*     */     
/*     */ 
/* 104 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getOperands(Stack s)
/*     */   {
/* 113 */     ParseItem[] items = new ParseItem[this.arguments];
/*     */     
/* 115 */     for (int i = this.arguments - 1; i >= 0; i--)
/*     */     {
/* 117 */       ParseItem pi = (ParseItem)s.pop();
/*     */       
/* 119 */       items[i] = pi;
/*     */     }
/*     */     
/* 122 */     for (int i = 0; i < this.arguments; i++)
/*     */     {
/* 124 */       add(items[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void getString(StringBuffer buf)
/*     */   {
/* 130 */     buf.append(this.function.getName(this.settings));
/* 131 */     buf.append('(');
/*     */     
/* 133 */     if (this.arguments > 0)
/*     */     {
/* 135 */       ParseItem[] operands = getOperands();
/* 136 */       if (this.readFromSheet)
/*     */       {
/*     */ 
/* 139 */         operands[0].getString(buf);
/*     */         
/* 141 */         for (int i = 1; i < this.arguments; i++)
/*     */         {
/* 143 */           buf.append(',');
/* 144 */           operands[i].getString(buf);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 151 */         operands[(this.arguments - 1)].getString(buf);
/*     */         
/* 153 */         for (int i = this.arguments - 2; i >= 0; i--)
/*     */         {
/* 155 */           buf.append(',');
/* 156 */           operands[i].getString(buf);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 161 */     buf.append(')');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust)
/*     */   {
/* 173 */     ParseItem[] operands = getOperands();
/*     */     
/* 175 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 177 */       operands[i].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 193 */     ParseItem[] operands = getOperands();
/* 194 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 196 */       operands[i].columnInserted(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet)
/*     */   {
/* 212 */     ParseItem[] operands = getOperands();
/* 213 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 215 */       operands[i].columnRemoved(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 231 */     ParseItem[] operands = getOperands();
/* 232 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 234 */       operands[i].rowInserted(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet)
/*     */   {
/* 250 */     ParseItem[] operands = getOperands();
/* 251 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 253 */       operands[i].rowRemoved(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void handleImportedCellReferences()
/*     */   {
/* 264 */     ParseItem[] operands = getOperands();
/* 265 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 267 */       operands[i].handleImportedCellReferences();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Function getFunction()
/*     */   {
/* 276 */     return this.function;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getBytes()
/*     */   {
/* 286 */     handleSpecialCases();
/*     */     
/*     */ 
/* 289 */     ParseItem[] operands = getOperands();
/* 290 */     byte[] data = new byte[0];
/*     */     
/* 292 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 294 */       byte[] opdata = operands[i].getBytes();
/*     */       
/*     */ 
/* 297 */       byte[] newdata = new byte[data.length + opdata.length];
/* 298 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 299 */       System.arraycopy(opdata, 0, newdata, data.length, opdata.length);
/* 300 */       data = newdata;
/*     */     }
/*     */     
/*     */ 
/* 304 */     byte[] newdata = new byte[data.length + 4];
/* 305 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 306 */     newdata[data.length] = (!useAlternateCode() ? Token.FUNCTIONVARARG.getCode() : Token.FUNCTIONVARARG.getCode2());
/*     */     
/* 308 */     newdata[(data.length + 1)] = ((byte)this.arguments);
/* 309 */     IntegerHelper.getTwoBytes(this.function.getCode(), newdata, data.length + 2);
/*     */     
/* 311 */     return newdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPrecedence()
/*     */   {
/* 322 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void handleSpecialCases()
/*     */   {
/* 332 */     if (this.function == Function.SUMPRODUCT)
/*     */     {
/*     */ 
/* 335 */       ParseItem[] operands = getOperands();
/*     */       
/* 337 */       for (int i = operands.length - 1; i >= 0; i--)
/*     */       {
/* 339 */         if ((operands[i] instanceof Area))
/*     */         {
/* 341 */           operands[i].setAlternateCode();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\VariableArgFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */