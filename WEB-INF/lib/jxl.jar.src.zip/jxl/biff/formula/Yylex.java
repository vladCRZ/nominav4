/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Yylex
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   public static final int YYSTRING = 1;
/*     */   public static final int YYINITIAL = 0;
/*     */   private static final String ZZ_CMAP_PACKED = "\b\000\003\025\025\000\001\025\001\024\001\021\001\026\001\b\002\000\001\022\001\005\001\006\001!\001\037\001\004\001 \001\007\001\033\001\034\t\002\001\003\001\000\001$\001#\001\"\001\036\001\000\001\016\002\001\001\030\001\f\001\r\002\001\001\031\002\001\001\017\001\035\001\027\003\001\001\n\001\020\001\t\001\013\001\032\004\001\004\000\001\023\001\000\032\001ﾅ\000";
/*  63 */   private static final char[] ZZ_CMAP = zzUnpackCMap("\b\000\003\025\025\000\001\025\001\024\001\021\001\026\001\b\002\000\001\022\001\005\001\006\001!\001\037\001\004\001 \001\007\001\033\001\034\t\002\001\003\001\000\001$\001#\001\"\001\036\001\000\001\016\002\001\001\030\001\f\001\r\002\001\001\031\002\001\001\017\001\035\001\027\003\001\001\n\001\020\001\t\001\013\001\032\004\001\004\000\001\023\001\000\032\001ﾅ\000");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\001\000\001\001\001\002\001\003\001\004\001\005\001\006\001\007\001\000\002\002\001\b\001\000\001\t\001\000\001\n\001\013\001\f\001\r\001\016\001\017\001\020\001\001\001\021\001\002\001\022\001\000\001\023\001\000\001\002\003\000\002\002\005\000\001\024\001\025\001\026\001\002\001\000\001\027\001\000\001\022\002\000\001\030\001\000\002\002\b\000\001\027\001\000\001\031\001\000\001\032\b\000\001\033\002\000\001\031\002\000\001\034\004\000\001\035\003\000\001\035\001\000\001\036\001\000";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int[] zzUnpackAction()
/*     */   {
/*  81 */     int[] result = new int[94];
/*  82 */     int offset = 0;
/*  83 */     offset = zzUnpackAction("\001\000\001\001\001\002\001\003\001\004\001\005\001\006\001\007\001\000\002\002\001\b\001\000\001\t\001\000\001\n\001\013\001\f\001\r\001\016\001\017\001\020\001\001\001\021\001\002\001\022\001\000\001\023\001\000\001\002\003\000\002\002\005\000\001\024\001\025\001\026\001\002\001\000\001\027\001\000\001\022\002\000\001\030\001\000\002\002\b\000\001\027\001\000\001\031\001\000\001\032\b\000\001\033\002\000\001\031\002\000\001\034\004\000\001\035\003\000\001\035\001\000\001\036\001\000", offset, result);
/*  84 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  88 */     int i = 0;
/*  89 */     int j = offset;
/*  90 */     int l = packed.length();
/*  91 */     int count; for (; i < l; 
/*     */         
/*     */ 
/*  94 */         count > 0)
/*     */     {
/*  92 */       count = packed.charAt(i++);
/*  93 */       int value = packed.charAt(i++);
/*  94 */       result[(j++)] = value;count--;
/*     */     }
/*  96 */     return j;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000%\000J\000o\000\000\000\000\000¹\000Þ\000ă\000\000Ĩ\000\000ō\000\000\000\000\000Ų\000\000Ɨ\000Ƽ\000\000ǡ\000Ȇ\000ȫ\000\000ɐ\000ɵ\000ʚ\000ʿ\000ˤ\000̉\000̮\000͓\000͸\000Ν\000ς\000ϧ\000\000\000\000Ќ\000б\000і\000ѻ\000Ҡ\000Ӆ\000Ӫ\000ʿ\000ԏ\000Դ\000ՙ\000վ\000֣\000׈\000׭\000ؒ\000ط\000ٜ\000ځ\000\000ڦ\000ۋ\000ۋ\000Ќ\000۰\000ܕ\000ܺ\000ݟ\000ބ\000ީ\000ߎ\000߳\000࠘\000࠘\000࠽\000ࡢ\000ࢇ\000ࢬ\000\000࣑\000ࣶ\000छ\000ी\000॥\000ঊ\000য\000৔\000\000৹\000ਞ\000ਞ";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int[] zzUnpackRowMap()
/*     */   {
/* 120 */     int[] result = new int[94];
/* 121 */     int offset = 0;
/* 122 */     offset = zzUnpackRowMap("\000\000\000%\000J\000o\000\000\000\000\000¹\000Þ\000ă\000\000Ĩ\000\000ō\000\000\000\000\000Ų\000\000Ɨ\000Ƽ\000\000ǡ\000Ȇ\000ȫ\000\000ɐ\000ɵ\000ʚ\000ʿ\000ˤ\000̉\000̮\000͓\000͸\000Ν\000ς\000ϧ\000\000\000\000Ќ\000б\000і\000ѻ\000Ҡ\000Ӆ\000Ӫ\000ʿ\000ԏ\000Դ\000ՙ\000վ\000֣\000׈\000׭\000ؒ\000ط\000ٜ\000ځ\000\000ڦ\000ۋ\000ۋ\000Ќ\000۰\000ܕ\000ܺ\000ݟ\000ބ\000ީ\000ߎ\000߳\000࠘\000࠘\000࠽\000ࡢ\000ࢇ\000ࢬ\000\000࣑\000ࣶ\000छ\000ी\000॥\000ঊ\000য\000৔\000\000৹\000ਞ\000ਞ", offset, result);
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 127 */     int i = 0;
/* 128 */     int j = offset;
/* 129 */     int l = packed.length();
/* 130 */     while (i < l) {
/* 131 */       int high = packed.charAt(i++) << '\020';
/* 132 */       result[(j++)] = (high | packed.charAt(i++));
/*     */     }
/* 134 */     return j;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 140 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\000\001\003\001\004\001\005\001\006\001\007\001\b\001\000\001\t\001\n\003\003\001\013\003\003\001\f\001\r\002\000\001\016\001\017\004\003\001\020\001\004\001\003\001\000\001\021\001\022\001\023\001\024\001\025\001\026\021\027\001\030\023\027\001\000\001\031\001\032\001\033\001\000\001\034\002\000\001\035\b\031\002\000\001\036\001\037\002\000\004\031\001\000\001\032\001\031\t\000\001\004\004\000\001 \024\000\001\004.\000\001!\007\000\b!\006\000\004!\002\000\001!\b\000\001\031\001\032\001\033\001\000\001\034\002\000\001\035\001\031\001\"\006\031\002\000\001\036\001\037\002\000\004\031\001\000\001\032\001\031\b\000\001\031\001\032\001\033\001\000\001\034\002\000\001\035\005\031\001#\002\031\002\000\001\036\001\037\002\000\004\031\001\000\001\032\001\031\007\000\022\r\001$\022\r\n\000\001%\f\000\001&\001'\001\000\001(-\000\001)#\000\001*\001+\001\000\021\027\001\000\023\027\001\000\001,\001\032\001\033\001\000\001\034\002\000\001\035\b,\002\000\001\036\001\037\002\000\004,\001\000\001\032\001,\b\000\001\036\001\032\001-\005\000\b\036\002\000\001\036\003\000\004\036\001\000\001\032\001\036\b\000\001.\006\000\001/\b.\006\000\004.\002\000\001.\t\000\0010\031\000\0010\t\000\002\036\006\000\b\036\002\000\001\036\003\000\004\036\001\000\002\036\b\000\0011\006\000\0012\b1\006\000\0041\002\000\0011\t\000\0013\031\000\0013\t\000\0014\0010\001\033\004\000\001\035\b4\006\000\0044\001\000\0010\0014\b\000\001,\001\032\001\033\001\000\001\034\002\000\001\035\002,\0015\005,\002\000\001\036\001\037\002\000\004,\001\000\001\032\001,\b\000\001,\001\032\001\033\001\000\001\034\002\000\001\035\006,\0016\001,\002\000\001\036\001\037\002\000\004,\001\000\001\032\001,\033\000\0017\034\000\0018#\000\0019\002\000\001:/\000\001;\031\000\001<\027\000\001,\001\036\002\000\001\034\003\000\b,\002\000\001\036\001\037\002\000\004,\001\000\001\036\001,\b\000\001=\006\000\001>\b=\006\000\004=\002\000\001=\b\000\001?\007\000\b?\006\000\004?\002\000\001?\b\000\001.\007\000\b.\006\000\004.\002\000\001.\t\000\0010\001-\030\000\0010\t\000\001@\001A\005\000\001B\b@\006\000\004@\001\000\001A\001@\b\000\0011\007\000\b1\006\000\0041\002\000\0011\t\000\0010\001\033\004\000\001\035\023\000\0010\t\000\001,\001\036\002\000\001\034\003\000\003,\001C\004,\002\000\001\036\001\037\002\000\004,\001\000\001\036\001,\b\000\001,\001\036\002\000\001\034\003\000\007,\0015\002\000\001\036\001\037\002\000\004,\001\000\001\036\001,\b\000\001D\006\000\001E\bD\006\000\004D\002\000\001D\024\000\001F&\000\001G\r\000\001F$\000\001H!\000\001I\031\000\001J\026\000\001K\001L\005\000\001M\bK\006\000\004K\001\000\001L\001K\b\000\001=\007\000\b=\006\000\004=\002\000\001=\t\000\001A\005\000\001B\023\000\001A\n\000\001A\031\000\001A\t\000\001N\001O\001P\004\000\001Q\bN\006\000\004N\001\000\001O\001N\b\000\001D\007\000\bD\006\000\004D\002\000\001D\033\000\001R\037\000\001F!\000\001S3\000\001T\024\000\001U\033\000\001L\005\000\001M\023\000\001L\n\000\001L\031\000\001L\n\000\001O\001P\004\000\001Q\023\000\001O\n\000\001O\001V\030\000\001O\t\000\001W\006\000\001X\bW\006\000\004W\002\000\001W\t\000\001O\031\000\001O&\000\001R\"\000\001F\024\000\001F\031\000\001Y\006\000\001Z\bY\006\000\004Y\002\000\001Y\b\000\001[\007\000\b[\006\000\004[\002\000\001[\b\000\001W\007\000\bW\006\000\004W\002\000\001W\b\000\001\\\001]\005\000\001^\b\\\006\000\004\\\001\000\001]\001\\\b\000\001Y\007\000\bY\006\000\004Y\002\000\001Y\t\000\001]\005\000\001^\023\000\001]\n\000\001]\031\000\001]\b\000";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int[] zzUnpackTrans()
/*     */   {
/* 212 */     int[] result = new int['੃'];
/* 213 */     int offset = 0;
/* 214 */     offset = zzUnpackTrans("\001\000\001\003\001\004\001\005\001\006\001\007\001\b\001\000\001\t\001\n\003\003\001\013\003\003\001\f\001\r\002\000\001\016\001\017\004\003\001\020\001\004\001\003\001\000\001\021\001\022\001\023\001\024\001\025\001\026\021\027\001\030\023\027\001\000\001\031\001\032\001\033\001\000\001\034\002\000\001\035\b\031\002\000\001\036\001\037\002\000\004\031\001\000\001\032\001\031\t\000\001\004\004\000\001 \024\000\001\004.\000\001!\007\000\b!\006\000\004!\002\000\001!\b\000\001\031\001\032\001\033\001\000\001\034\002\000\001\035\001\031\001\"\006\031\002\000\001\036\001\037\002\000\004\031\001\000\001\032\001\031\b\000\001\031\001\032\001\033\001\000\001\034\002\000\001\035\005\031\001#\002\031\002\000\001\036\001\037\002\000\004\031\001\000\001\032\001\031\007\000\022\r\001$\022\r\n\000\001%\f\000\001&\001'\001\000\001(-\000\001)#\000\001*\001+\001\000\021\027\001\000\023\027\001\000\001,\001\032\001\033\001\000\001\034\002\000\001\035\b,\002\000\001\036\001\037\002\000\004,\001\000\001\032\001,\b\000\001\036\001\032\001-\005\000\b\036\002\000\001\036\003\000\004\036\001\000\001\032\001\036\b\000\001.\006\000\001/\b.\006\000\004.\002\000\001.\t\000\0010\031\000\0010\t\000\002\036\006\000\b\036\002\000\001\036\003\000\004\036\001\000\002\036\b\000\0011\006\000\0012\b1\006\000\0041\002\000\0011\t\000\0013\031\000\0013\t\000\0014\0010\001\033\004\000\001\035\b4\006\000\0044\001\000\0010\0014\b\000\001,\001\032\001\033\001\000\001\034\002\000\001\035\002,\0015\005,\002\000\001\036\001\037\002\000\004,\001\000\001\032\001,\b\000\001,\001\032\001\033\001\000\001\034\002\000\001\035\006,\0016\001,\002\000\001\036\001\037\002\000\004,\001\000\001\032\001,\033\000\0017\034\000\0018#\000\0019\002\000\001:/\000\001;\031\000\001<\027\000\001,\001\036\002\000\001\034\003\000\b,\002\000\001\036\001\037\002\000\004,\001\000\001\036\001,\b\000\001=\006\000\001>\b=\006\000\004=\002\000\001=\b\000\001?\007\000\b?\006\000\004?\002\000\001?\b\000\001.\007\000\b.\006\000\004.\002\000\001.\t\000\0010\001-\030\000\0010\t\000\001@\001A\005\000\001B\b@\006\000\004@\001\000\001A\001@\b\000\0011\007\000\b1\006\000\0041\002\000\0011\t\000\0010\001\033\004\000\001\035\023\000\0010\t\000\001,\001\036\002\000\001\034\003\000\003,\001C\004,\002\000\001\036\001\037\002\000\004,\001\000\001\036\001,\b\000\001,\001\036\002\000\001\034\003\000\007,\0015\002\000\001\036\001\037\002\000\004,\001\000\001\036\001,\b\000\001D\006\000\001E\bD\006\000\004D\002\000\001D\024\000\001F&\000\001G\r\000\001F$\000\001H!\000\001I\031\000\001J\026\000\001K\001L\005\000\001M\bK\006\000\004K\001\000\001L\001K\b\000\001=\007\000\b=\006\000\004=\002\000\001=\t\000\001A\005\000\001B\023\000\001A\n\000\001A\031\000\001A\t\000\001N\001O\001P\004\000\001Q\bN\006\000\004N\001\000\001O\001N\b\000\001D\007\000\bD\006\000\004D\002\000\001D\033\000\001R\037\000\001F!\000\001S3\000\001T\024\000\001U\033\000\001L\005\000\001M\023\000\001L\n\000\001L\031\000\001L\n\000\001O\001P\004\000\001Q\023\000\001O\n\000\001O\001V\030\000\001O\t\000\001W\006\000\001X\bW\006\000\004W\002\000\001W\t\000\001O\031\000\001O&\000\001R\"\000\001F\024\000\001F\031\000\001Y\006\000\001Z\bY\006\000\004Y\002\000\001Y\b\000\001[\007\000\b[\006\000\004[\002\000\001[\b\000\001W\007\000\bW\006\000\004W\002\000\001W\b\000\001\\\001]\005\000\001^\b\\\006\000\004\\\001\000\001]\001\\\b\000\001Y\007\000\bY\006\000\004Y\002\000\001Y\t\000\001]\005\000\001^\023\000\001]\n\000\001]\031\000\001]\b\000", offset, result);
/* 215 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 219 */     int i = 0;
/* 220 */     int j = offset;
/* 221 */     int l = packed.length();
/* 222 */     int count; for (; i < l; 
/*     */         
/*     */ 
/*     */ 
/* 226 */         count > 0)
/*     */     {
/* 223 */       count = packed.charAt(i++);
/* 224 */       int value = packed.charAt(i++);
/* 225 */       value--;
/* 226 */       result[(j++)] = value;count--;
/*     */     }
/* 228 */     return j;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 238 */   private static final String[] ZZ_ERROR_MSG = { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   
/*     */ 
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\001\000\003\001\004\t\001\000\002\001\001\t\001\000\001\t\001\000\004\t\001\001\001\t\002\001\001\t\002\001\001\000\001\t\001\000\001\001\003\000\002\001\005\000\003\t\001\001\001\000\001\001\001\000\001\001\002\000\001\001\001\000\002\001\b\000\001\t\001\000\001\001\001\000\001\001\b\000\001\001\002\000\001\001\002\000\001\t\004\000\001\001\003\000\001\t\001\000\001\001\001\000";
/*     */   
/*     */   private Reader zzReader;
/*     */   
/*     */   private int zzState;
/*     */   
/*     */ 
/*     */   private static int[] zzUnpackAttribute()
/*     */   {
/* 259 */     int[] result = new int[94];
/* 260 */     int offset = 0;
/* 261 */     offset = zzUnpackAttribute("\001\000\003\001\004\t\001\000\002\001\001\t\001\000\001\t\001\000\004\t\001\001\001\t\002\001\001\t\002\001\001\000\001\t\001\000\001\001\003\000\002\001\005\000\003\t\001\001\001\000\001\001\001\000\001\001\002\000\001\001\001\000\002\001\b\000\001\t\001\000\001\001\001\000\001\001\b\000\001\001\002\000\001\001\002\000\001\t\004\000\001\001\003\000\001\t\001\000\001\001\001\000", offset, result);
/* 262 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 266 */     int i = 0;
/* 267 */     int j = offset;
/* 268 */     int l = packed.length();
/* 269 */     int count; for (; i < l; 
/*     */         
/*     */ 
/* 272 */         count > 0)
/*     */     {
/* 270 */       count = packed.charAt(i++);
/* 271 */       int value = packed.charAt(i++);
/* 272 */       result[(j++)] = value;count--;
/*     */     }
/* 274 */     return j;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */   private int zzLexicalState = 0;
/*     */   
/*     */ 
/*     */ 
/* 288 */   private char[] zzBuffer = new char['䀀'];
/*     */   
/*     */ 
/*     */ 
/*     */   private int zzMarkedPos;
/*     */   
/*     */ 
/*     */ 
/*     */   private int zzPushbackPos;
/*     */   
/*     */ 
/*     */ 
/*     */   private int zzCurrentPos;
/*     */   
/*     */ 
/*     */ 
/*     */   private int zzStartRead;
/*     */   
/*     */ 
/*     */ 
/*     */   private int zzEndRead;
/*     */   
/*     */ 
/*     */ 
/*     */   private int yyline;
/*     */   
/*     */ 
/*     */   private int yychar;
/*     */   
/*     */ 
/*     */   private int yycolumn;
/*     */   
/*     */ 
/* 321 */   private boolean zzAtBOL = true;
/*     */   private boolean zzAtEOF;
/*     */   private boolean emptyString;
/*     */   private ExternalSheet externalSheet;
/*     */   private WorkbookMethods nameTable;
/*     */   
/* 327 */   int getPos() { return this.yychar; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setExternalSheet(ExternalSheet es)
/*     */   {
/* 334 */     this.externalSheet = es;
/*     */   }
/*     */   
/*     */   void setNameTable(WorkbookMethods nt)
/*     */   {
/* 339 */     this.nameTable = nt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Yylex(Reader in)
/*     */   {
/* 350 */     this.zzReader = in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Yylex(InputStream in)
/*     */   {
/* 360 */     this(new InputStreamReader(in));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static char[] zzUnpackCMap(String packed)
/*     */   {
/* 370 */     char[] map = new char[65536];
/* 371 */     int i = 0;
/* 372 */     int j = 0;
/* 373 */     int count; for (; i < 100; 
/*     */         
/*     */ 
/* 376 */         count > 0)
/*     */     {
/* 374 */       count = packed.charAt(i++);
/* 375 */       char value = packed.charAt(i++);
/* 376 */       map[(j++)] = value;count--;
/*     */     }
/* 378 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean zzRefill()
/*     */     throws IOException
/*     */   {
/* 392 */     if (this.zzStartRead > 0) {
/* 393 */       System.arraycopy(this.zzBuffer, this.zzStartRead, this.zzBuffer, 0, this.zzEndRead - this.zzStartRead);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 398 */       this.zzEndRead -= this.zzStartRead;
/* 399 */       this.zzCurrentPos -= this.zzStartRead;
/* 400 */       this.zzMarkedPos -= this.zzStartRead;
/* 401 */       this.zzPushbackPos -= this.zzStartRead;
/* 402 */       this.zzStartRead = 0;
/*     */     }
/*     */     
/*     */ 
/* 406 */     if (this.zzCurrentPos >= this.zzBuffer.length)
/*     */     {
/* 408 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 409 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 410 */       this.zzBuffer = newBuffer;
/*     */     }
/*     */     
/*     */ 
/* 414 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, this.zzBuffer.length - this.zzEndRead);
/*     */     
/*     */ 
/* 417 */     if (numRead < 0) {
/* 418 */       return true;
/*     */     }
/*     */     
/* 421 */     this.zzEndRead += numRead;
/* 422 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void yyclose()
/*     */     throws IOException
/*     */   {
/* 431 */     this.zzAtEOF = true;
/* 432 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 434 */     if (this.zzReader != null) {
/* 435 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void yyreset(Reader reader)
/*     */   {
/* 450 */     this.zzReader = reader;
/* 451 */     this.zzAtBOL = true;
/* 452 */     this.zzAtEOF = false;
/* 453 */     this.zzEndRead = (this.zzStartRead = 0);
/* 454 */     this.zzCurrentPos = (this.zzMarkedPos = this.zzPushbackPos = 0);
/* 455 */     this.yyline = (this.yychar = this.yycolumn = 0);
/* 456 */     this.zzLexicalState = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int yystate()
/*     */   {
/* 464 */     return this.zzLexicalState;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void yybegin(int newState)
/*     */   {
/* 474 */     this.zzLexicalState = newState;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String yytext()
/*     */   {
/* 482 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final char yycharat(int pos)
/*     */   {
/* 498 */     return this.zzBuffer[(this.zzStartRead + pos)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int yylength()
/*     */   {
/* 506 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void zzScanError(int errorCode)
/*     */   {
/*     */     String message;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 527 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 530 */       message = ZZ_ERROR_MSG[0];
/*     */     }
/*     */     
/* 533 */     throw new Error(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void yypushback(int number)
/*     */   {
/* 546 */     if (number > yylength()) {
/* 547 */       zzScanError(2);
/*     */     }
/* 549 */     this.zzMarkedPos -= number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseItem yylex()
/*     */     throws IOException, FormulaException
/*     */   {
/* 568 */     int zzEndReadL = this.zzEndRead;
/* 569 */     char[] zzBufferL = this.zzBuffer;
/* 570 */     char[] zzCMapL = ZZ_CMAP;
/*     */     
/* 572 */     int[] zzTransL = ZZ_TRANS;
/* 573 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 574 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     for (;;)
/*     */     {
/* 577 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 579 */       this.yychar += zzMarkedPosL - this.zzStartRead;
/*     */       
/* 581 */       boolean zzR = false;
/* 582 */       for (int zzCurrentPosL = this.zzStartRead; zzCurrentPosL < zzMarkedPosL; 
/* 583 */           zzCurrentPosL++) {
/* 584 */         switch (zzBufferL[zzCurrentPosL]) {
/*     */         case '\013': 
/*     */         case '\f': 
/*     */         case '': 
/*     */         case ' ': 
/*     */         case ' ': 
/* 590 */           this.yyline += 1;
/* 591 */           zzR = false;
/* 592 */           break;
/*     */         case '\r': 
/* 594 */           this.yyline += 1;
/* 595 */           zzR = true;
/* 596 */           break;
/*     */         case '\n': 
/* 598 */           if (zzR) {
/* 599 */             zzR = false;
/*     */           } else {
/* 601 */             this.yyline += 1;
/*     */           }
/* 603 */           break;
/*     */         default: 
/* 605 */           zzR = false;
/*     */         }
/*     */         
/*     */       }
/* 609 */       if (zzR) {
/*     */         boolean zzPeek;
/*     */         boolean zzPeek;
/* 612 */         if (zzMarkedPosL < zzEndReadL) {
/* 613 */           zzPeek = zzBufferL[zzMarkedPosL] == '\n'; } else { boolean zzPeek;
/* 614 */           if (this.zzAtEOF) {
/* 615 */             zzPeek = false;
/*     */           } else {
/* 617 */             boolean eof = zzRefill();
/* 618 */             zzEndReadL = this.zzEndRead;
/* 619 */             zzMarkedPosL = this.zzMarkedPos;
/* 620 */             zzBufferL = this.zzBuffer;
/* 621 */             boolean zzPeek; if (eof) {
/* 622 */               zzPeek = false;
/*     */             } else
/* 624 */               zzPeek = zzBufferL[zzMarkedPosL] == '\n';
/*     */           } }
/* 626 */         if (zzPeek) this.yyline -= 1;
/*     */       }
/* 628 */       int zzAction = -1;
/*     */       
/* 630 */       zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 632 */       this.zzState = this.zzLexicalState;
/*     */       
/*     */       int zzInput;
/*     */       for (;;)
/*     */       {
/*     */         int zzInput;
/* 638 */         if (zzCurrentPosL < zzEndReadL) {
/* 639 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/* 640 */         } else { if (this.zzAtEOF) {
/* 641 */             int zzInput = -1;
/* 642 */             break;
/*     */           }
/*     */           
/*     */ 
/* 646 */           this.zzCurrentPos = zzCurrentPosL;
/* 647 */           this.zzMarkedPos = zzMarkedPosL;
/* 648 */           boolean eof = zzRefill();
/*     */           
/* 650 */           zzCurrentPosL = this.zzCurrentPos;
/* 651 */           zzMarkedPosL = this.zzMarkedPos;
/* 652 */           zzBufferL = this.zzBuffer;
/* 653 */           zzEndReadL = this.zzEndRead;
/* 654 */           if (eof) {
/* 655 */             int zzInput = -1;
/* 656 */             break;
/*     */           }
/*     */           
/* 659 */           zzInput = zzBufferL[(zzCurrentPosL++)];
/*     */         }
/*     */         
/* 662 */         int zzNext = zzTransL[(zzRowMapL[this.zzState] + zzCMapL[zzInput])];
/* 663 */         if (zzNext == -1) break;
/* 664 */         this.zzState = zzNext;
/*     */         
/* 666 */         int zzAttributes = zzAttrL[this.zzState];
/* 667 */         if ((zzAttributes & 0x1) == 1) {
/* 668 */           zzAction = this.zzState;
/* 669 */           zzMarkedPosL = zzCurrentPosL;
/* 670 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 677 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 679 */       switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
/*     */       case 12: 
/* 681 */         return new Minus();
/*     */       case 31: 
/*     */         break;
/*     */       case 7: 
/* 685 */         return new CloseParentheses();
/*     */       case 32: 
/*     */         break;
/*     */       case 3: 
/* 689 */         return new IntegerValue(yytext());
/*     */       case 33: 
/*     */         break;
/*     */       case 24: 
/* 693 */         return new DoubleValue(yytext());
/*     */       case 34: 
/*     */         break;
/*     */       case 29: 
/* 697 */         return new ColumnRange3d(yytext(), this.externalSheet);
/*     */       case 35: 
/*     */         break;
/*     */       case 4: 
/* 701 */         return new RangeSeparator();
/*     */       case 36: 
/*     */         break;
/*     */       case 10: 
/* 705 */         return new Divide();
/*     */       case 37: 
/*     */         break;
/*     */       case 25: 
/* 709 */         return new CellReference3d(yytext(), this.externalSheet);
/*     */       case 38: 
/*     */         break;
/*     */       case 26: 
/* 713 */         return new BooleanValue(yytext());
/*     */       case 39: 
/*     */         break;
/*     */       case 15: 
/* 717 */         return new Equal();
/*     */       case 40: 
/*     */         break;
/*     */       case 17: 
/* 721 */         yybegin(0); if (this.emptyString) return new StringValue("");
/*     */       case 41: 
/*     */         break;
/*     */       case 8: 
/* 725 */         this.emptyString = true;yybegin(1);
/*     */       case 42: 
/*     */         break;
/*     */       case 21: 
/* 729 */         return new NotEqual();
/*     */       case 43: 
/*     */         break;
/*     */       case 22: 
/* 733 */         return new LessEqual();
/*     */       case 44: 
/*     */         break;
/*     */       case 16: 
/* 737 */         return new LessThan();
/*     */       case 45: 
/*     */         break;
/*     */       case 5: 
/* 741 */         return new ArgumentSeparator();
/*     */       case 46: 
/*     */         break;
/*     */       case 30: 
/* 745 */         return new Area3d(yytext(), this.externalSheet);
/*     */       case 47: 
/*     */         break;
/*     */       case 14: 
/* 749 */         return new GreaterThan();
/*     */       case 48: 
/*     */         break;
/*     */       case 18: 
/* 753 */         return new CellReference(yytext());
/*     */       case 49: 
/*     */         break;
/*     */       case 20: 
/* 757 */         return new GreaterEqual();
/*     */       case 50: 
/*     */         break;
/*     */       case 27: 
/* 761 */         return new Area(yytext());
/*     */       case 51: 
/*     */         break;
/*     */       case 23: 
/* 765 */         return new ColumnRange(yytext());
/*     */       case 52: 
/*     */         break;
/*     */       case 1: 
/* 769 */         this.emptyString = false;return new StringValue(yytext());
/*     */       case 53: 
/*     */         break;
/*     */       case 2: 
/* 773 */         return new NameRange(yytext(), this.nameTable);
/*     */       case 54: 
/*     */         break;
/*     */       case 19: 
/* 777 */         return new StringFunction(yytext());
/*     */       case 55: 
/*     */         break;
/*     */       case 11: 
/* 781 */         return new Plus();
/*     */       case 56: 
/*     */         break;
/*     */       case 28: 
/* 785 */         return new ErrorConstant(yytext());
/*     */       case 57: 
/*     */         break;
/*     */       case 9: 
/*     */       case 58: 
/*     */         break;
/*     */       
/*     */       case 13: 
/* 793 */         return new Multiply();
/*     */       case 59: 
/*     */         break;
/*     */       case 6: 
/* 797 */         return new OpenParentheses();
/*     */       case 60: 
/*     */         break;
/*     */       }
/* 801 */       if ((zzInput == -1) && (this.zzStartRead == this.zzCurrentPos)) {
/* 802 */         this.zzAtEOF = true;
/* 803 */         return null;
/*     */       }
/*     */       
/* 806 */       zzScanError(1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\biff\formula\Yylex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */