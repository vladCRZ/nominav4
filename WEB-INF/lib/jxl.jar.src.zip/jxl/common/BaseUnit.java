/*    */ package jxl.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BaseUnit
/*    */ {
/*    */   private int index;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected BaseUnit(int ind)
/*    */   {
/* 28 */     this.index = ind;
/*    */   }
/*    */   
/*    */   protected int getIndex()
/*    */   {
/* 33 */     return this.index;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\common\BaseUnit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */