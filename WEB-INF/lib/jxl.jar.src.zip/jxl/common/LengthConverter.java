/*    */ package jxl.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthConverter
/*    */ {
/* 24 */   private static double[][] factors = new double[LengthUnit.getCount()][LengthUnit.getCount()];
/*    */   
/*    */ 
/*    */ 
/*    */   static
/*    */   {
/* 30 */     factors[LengthUnit.POINTS.getIndex()][LengthUnit.POINTS.getIndex()] = 1.0D;
/* 31 */     factors[LengthUnit.METRES.getIndex()][LengthUnit.METRES.getIndex()] = 1.0D;
/* 32 */     factors[LengthUnit.CENTIMETRES.getIndex()][LengthUnit.CENTIMETRES.getIndex()] = 1.0D;
/* 33 */     factors[LengthUnit.INCHES.getIndex()][LengthUnit.INCHES.getIndex()] = 1.0D;
/*    */     
/*    */ 
/* 36 */     factors[LengthUnit.POINTS.getIndex()][LengthUnit.METRES.getIndex()] = 3.5277777778E-4D;
/* 37 */     factors[LengthUnit.POINTS.getIndex()][LengthUnit.CENTIMETRES.getIndex()] = 0.035277777778D;
/* 38 */     factors[LengthUnit.POINTS.getIndex()][LengthUnit.INCHES.getIndex()] = 0.013888888889D;
/*    */     
/*    */ 
/* 41 */     factors[LengthUnit.METRES.getIndex()][LengthUnit.POINTS.getIndex()] = 2877.84D;
/* 42 */     factors[LengthUnit.METRES.getIndex()][LengthUnit.CENTIMETRES.getIndex()] = 100.0D;
/* 43 */     factors[LengthUnit.METRES.getIndex()][LengthUnit.INCHES.getIndex()] = 39.37D;
/*    */     
/*    */ 
/* 46 */     factors[LengthUnit.CENTIMETRES.getIndex()][LengthUnit.POINTS.getIndex()] = 28.34643D;
/* 47 */     factors[LengthUnit.CENTIMETRES.getIndex()][LengthUnit.METRES.getIndex()] = 0.01D;
/* 48 */     factors[LengthUnit.CENTIMETRES.getIndex()][LengthUnit.INCHES.getIndex()] = 0.3937D;
/*    */     
/*    */ 
/* 51 */     factors[LengthUnit.INCHES.getIndex()][LengthUnit.POINTS.getIndex()] = 72.0D;
/* 52 */     factors[LengthUnit.INCHES.getIndex()][LengthUnit.METRES.getIndex()] = 0.0254D;
/* 53 */     factors[LengthUnit.INCHES.getIndex()][LengthUnit.CENTIMETRES.getIndex()] = 2.54D;
/*    */   }
/*    */   
/*    */   public static double getConversionFactor(LengthUnit from, LengthUnit to)
/*    */   {
/* 58 */     return factors[from.getIndex()][to.getIndex()];
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\common\LengthConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */