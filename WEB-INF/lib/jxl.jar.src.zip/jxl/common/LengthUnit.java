/*    */ package jxl.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LengthUnit
/*    */   extends BaseUnit
/*    */ {
/* 28 */   private static int count = 0;
/*    */   
/*    */   private LengthUnit()
/*    */   {
/* 32 */     super(count++);
/*    */   }
/*    */   
/*    */   public static int getCount()
/*    */   {
/* 37 */     return count;
/*    */   }
/*    */   
/* 40 */   public static LengthUnit POINTS = new LengthUnit();
/* 41 */   public static LengthUnit METRES = new LengthUnit();
/* 42 */   public static LengthUnit CENTIMETRES = new LengthUnit();
/* 43 */   public static LengthUnit INCHES = new LengthUnit();
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\common\LengthUnit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */