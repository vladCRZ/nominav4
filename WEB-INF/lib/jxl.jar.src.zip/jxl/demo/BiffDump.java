/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.HashMap;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.Type;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.read.biff.BiffRecordReader;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BiffDump
/*     */ {
/*     */   private BufferedWriter writer;
/*     */   private BiffRecordReader reader;
/*     */   private HashMap recordNames;
/*     */   private int xfIndex;
/*     */   private int fontIndex;
/*     */   private int bofs;
/*     */   private static final int bytesPerLine = 16;
/*     */   
/*     */   public BiffDump(java.io.File file, OutputStream os)
/*     */     throws IOException, BiffException
/*     */   {
/*  65 */     this.writer = new BufferedWriter(new OutputStreamWriter(os));
/*  66 */     FileInputStream fis = new FileInputStream(file);
/*  67 */     jxl.read.biff.File f = new jxl.read.biff.File(fis, new WorkbookSettings());
/*  68 */     this.reader = new BiffRecordReader(f);
/*     */     
/*  70 */     buildNameHash();
/*  71 */     dump();
/*     */     
/*  73 */     this.writer.flush();
/*  74 */     this.writer.close();
/*  75 */     fis.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buildNameHash()
/*     */   {
/*  83 */     this.recordNames = new HashMap(50);
/*     */     
/*  85 */     this.recordNames.put(Type.BOF, "BOF");
/*  86 */     this.recordNames.put(Type.EOF, "EOF");
/*  87 */     this.recordNames.put(Type.FONT, "FONT");
/*  88 */     this.recordNames.put(Type.SST, "SST");
/*  89 */     this.recordNames.put(Type.LABELSST, "LABELSST");
/*  90 */     this.recordNames.put(Type.WRITEACCESS, "WRITEACCESS");
/*  91 */     this.recordNames.put(Type.FORMULA, "FORMULA");
/*  92 */     this.recordNames.put(Type.FORMULA2, "FORMULA");
/*  93 */     this.recordNames.put(Type.XF, "XF");
/*  94 */     this.recordNames.put(Type.MULRK, "MULRK");
/*  95 */     this.recordNames.put(Type.NUMBER, "NUMBER");
/*  96 */     this.recordNames.put(Type.BOUNDSHEET, "BOUNDSHEET");
/*  97 */     this.recordNames.put(Type.CONTINUE, "CONTINUE");
/*  98 */     this.recordNames.put(Type.FORMAT, "FORMAT");
/*  99 */     this.recordNames.put(Type.EXTERNSHEET, "EXTERNSHEET");
/* 100 */     this.recordNames.put(Type.INDEX, "INDEX");
/* 101 */     this.recordNames.put(Type.DIMENSION, "DIMENSION");
/* 102 */     this.recordNames.put(Type.ROW, "ROW");
/* 103 */     this.recordNames.put(Type.DBCELL, "DBCELL");
/* 104 */     this.recordNames.put(Type.BLANK, "BLANK");
/* 105 */     this.recordNames.put(Type.MULBLANK, "MULBLANK");
/* 106 */     this.recordNames.put(Type.RK, "RK");
/* 107 */     this.recordNames.put(Type.RK2, "RK");
/* 108 */     this.recordNames.put(Type.COLINFO, "COLINFO");
/* 109 */     this.recordNames.put(Type.LABEL, "LABEL");
/* 110 */     this.recordNames.put(Type.SHAREDFORMULA, "SHAREDFORMULA");
/* 111 */     this.recordNames.put(Type.CODEPAGE, "CODEPAGE");
/* 112 */     this.recordNames.put(Type.WINDOW1, "WINDOW1");
/* 113 */     this.recordNames.put(Type.WINDOW2, "WINDOW2");
/* 114 */     this.recordNames.put(Type.MERGEDCELLS, "MERGEDCELLS");
/* 115 */     this.recordNames.put(Type.HLINK, "HLINK");
/* 116 */     this.recordNames.put(Type.HEADER, "HEADER");
/* 117 */     this.recordNames.put(Type.FOOTER, "FOOTER");
/* 118 */     this.recordNames.put(Type.INTERFACEHDR, "INTERFACEHDR");
/* 119 */     this.recordNames.put(Type.MMS, "MMS");
/* 120 */     this.recordNames.put(Type.INTERFACEEND, "INTERFACEEND");
/* 121 */     this.recordNames.put(Type.DSF, "DSF");
/* 122 */     this.recordNames.put(Type.FNGROUPCOUNT, "FNGROUPCOUNT");
/* 123 */     this.recordNames.put(Type.COUNTRY, "COUNTRY");
/* 124 */     this.recordNames.put(Type.TABID, "TABID");
/* 125 */     this.recordNames.put(Type.PROTECT, "PROTECT");
/* 126 */     this.recordNames.put(Type.SCENPROTECT, "SCENPROTECT");
/* 127 */     this.recordNames.put(Type.OBJPROTECT, "OBJPROTECT");
/* 128 */     this.recordNames.put(Type.WINDOWPROTECT, "WINDOWPROTECT");
/* 129 */     this.recordNames.put(Type.PASSWORD, "PASSWORD");
/* 130 */     this.recordNames.put(Type.PROT4REV, "PROT4REV");
/* 131 */     this.recordNames.put(Type.PROT4REVPASS, "PROT4REVPASS");
/* 132 */     this.recordNames.put(Type.BACKUP, "BACKUP");
/* 133 */     this.recordNames.put(Type.HIDEOBJ, "HIDEOBJ");
/* 134 */     this.recordNames.put(Type.NINETEENFOUR, "1904");
/* 135 */     this.recordNames.put(Type.PRECISION, "PRECISION");
/* 136 */     this.recordNames.put(Type.BOOKBOOL, "BOOKBOOL");
/* 137 */     this.recordNames.put(Type.STYLE, "STYLE");
/* 138 */     this.recordNames.put(Type.EXTSST, "EXTSST");
/* 139 */     this.recordNames.put(Type.REFRESHALL, "REFRESHALL");
/* 140 */     this.recordNames.put(Type.CALCMODE, "CALCMODE");
/* 141 */     this.recordNames.put(Type.CALCCOUNT, "CALCCOUNT");
/* 142 */     this.recordNames.put(Type.NAME, "NAME");
/* 143 */     this.recordNames.put(Type.MSODRAWINGGROUP, "MSODRAWINGGROUP");
/* 144 */     this.recordNames.put(Type.MSODRAWING, "MSODRAWING");
/* 145 */     this.recordNames.put(Type.OBJ, "OBJ");
/* 146 */     this.recordNames.put(Type.USESELFS, "USESELFS");
/* 147 */     this.recordNames.put(Type.SUPBOOK, "SUPBOOK");
/* 148 */     this.recordNames.put(Type.LEFTMARGIN, "LEFTMARGIN");
/* 149 */     this.recordNames.put(Type.RIGHTMARGIN, "RIGHTMARGIN");
/* 150 */     this.recordNames.put(Type.TOPMARGIN, "TOPMARGIN");
/* 151 */     this.recordNames.put(Type.BOTTOMMARGIN, "BOTTOMMARGIN");
/* 152 */     this.recordNames.put(Type.HCENTER, "HCENTER");
/* 153 */     this.recordNames.put(Type.VCENTER, "VCENTER");
/* 154 */     this.recordNames.put(Type.ITERATION, "ITERATION");
/* 155 */     this.recordNames.put(Type.DELTA, "DELTA");
/* 156 */     this.recordNames.put(Type.SAVERECALC, "SAVERECALC");
/* 157 */     this.recordNames.put(Type.PRINTHEADERS, "PRINTHEADERS");
/* 158 */     this.recordNames.put(Type.PRINTGRIDLINES, "PRINTGRIDLINES");
/* 159 */     this.recordNames.put(Type.SETUP, "SETUP");
/* 160 */     this.recordNames.put(Type.SELECTION, "SELECTION");
/* 161 */     this.recordNames.put(Type.STRING, "STRING");
/* 162 */     this.recordNames.put(Type.FONTX, "FONTX");
/* 163 */     this.recordNames.put(Type.IFMT, "IFMT");
/* 164 */     this.recordNames.put(Type.WSBOOL, "WSBOOL");
/* 165 */     this.recordNames.put(Type.GRIDSET, "GRIDSET");
/* 166 */     this.recordNames.put(Type.REFMODE, "REFMODE");
/* 167 */     this.recordNames.put(Type.GUTS, "GUTS");
/* 168 */     this.recordNames.put(Type.EXTERNNAME, "EXTERNNAME");
/* 169 */     this.recordNames.put(Type.FBI, "FBI");
/* 170 */     this.recordNames.put(Type.CRN, "CRN");
/* 171 */     this.recordNames.put(Type.HORIZONTALPAGEBREAKS, "HORIZONTALPAGEBREAKS");
/* 172 */     this.recordNames.put(Type.VERTICALPAGEBREAKS, "VERTICALPAGEBREAKS");
/* 173 */     this.recordNames.put(Type.DEFAULTROWHEIGHT, "DEFAULTROWHEIGHT");
/* 174 */     this.recordNames.put(Type.TEMPLATE, "TEMPLATE");
/* 175 */     this.recordNames.put(Type.PANE, "PANE");
/* 176 */     this.recordNames.put(Type.SCL, "SCL");
/* 177 */     this.recordNames.put(Type.PALETTE, "PALETTE");
/* 178 */     this.recordNames.put(Type.PLS, "PLS");
/* 179 */     this.recordNames.put(Type.OBJPROJ, "OBJPROJ");
/* 180 */     this.recordNames.put(Type.DEFCOLWIDTH, "DEFCOLWIDTH");
/* 181 */     this.recordNames.put(Type.ARRAY, "ARRAY");
/* 182 */     this.recordNames.put(Type.WEIRD1, "WEIRD1");
/* 183 */     this.recordNames.put(Type.BOOLERR, "BOOLERR");
/* 184 */     this.recordNames.put(Type.SORT, "SORT");
/* 185 */     this.recordNames.put(Type.BUTTONPROPERTYSET, "BUTTONPROPERTYSET");
/* 186 */     this.recordNames.put(Type.NOTE, "NOTE");
/* 187 */     this.recordNames.put(Type.TXO, "TXO");
/* 188 */     this.recordNames.put(Type.DV, "DV");
/* 189 */     this.recordNames.put(Type.DVAL, "DVAL");
/* 190 */     this.recordNames.put(Type.SERIES, "SERIES");
/* 191 */     this.recordNames.put(Type.SERIESLIST, "SERIESLIST");
/* 192 */     this.recordNames.put(Type.SBASEREF, "SBASEREF");
/* 193 */     this.recordNames.put(Type.CONDFMT, "CONDFMT");
/* 194 */     this.recordNames.put(Type.CF, "CF");
/* 195 */     this.recordNames.put(Type.FILTERMODE, "FILTERMODE");
/* 196 */     this.recordNames.put(Type.AUTOFILTER, "AUTOFILTER");
/* 197 */     this.recordNames.put(Type.AUTOFILTERINFO, "AUTOFILTERINFO");
/* 198 */     this.recordNames.put(Type.XCT, "XCT");
/*     */     
/* 200 */     this.recordNames.put(Type.UNKNOWN, "???");
/*     */   }
/*     */   
/*     */ 
/*     */   private void dump()
/*     */     throws IOException
/*     */   {
/* 207 */     Record r = null;
/* 208 */     boolean cont = true;
/* 209 */     while ((this.reader.hasNext()) && (cont))
/*     */     {
/* 211 */       r = this.reader.next();
/* 212 */       cont = writeRecord(r);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean writeRecord(Record r)
/*     */     throws IOException
/*     */   {
/* 224 */     boolean cont = true;
/* 225 */     int pos = this.reader.getPos();
/* 226 */     int code = r.getCode();
/*     */     
/* 228 */     if (this.bofs == 0)
/*     */     {
/* 230 */       cont = r.getType() == Type.BOF;
/*     */     }
/*     */     
/* 233 */     if (!cont)
/*     */     {
/* 235 */       return cont;
/*     */     }
/*     */     
/* 238 */     if (r.getType() == Type.BOF)
/*     */     {
/* 240 */       this.bofs += 1;
/*     */     }
/*     */     
/* 243 */     if (r.getType() == Type.EOF)
/*     */     {
/* 245 */       this.bofs -= 1;
/*     */     }
/*     */     
/* 248 */     StringBuffer buf = new StringBuffer();
/*     */     
/*     */ 
/* 251 */     writeSixDigitValue(pos, buf);
/* 252 */     buf.append(" [");
/* 253 */     buf.append(this.recordNames.get(r.getType()));
/* 254 */     buf.append("]");
/* 255 */     buf.append("  (0x");
/* 256 */     buf.append(Integer.toHexString(code));
/* 257 */     buf.append(")");
/*     */     
/* 259 */     if (code == Type.XF.value)
/*     */     {
/* 261 */       buf.append(" (0x");
/* 262 */       buf.append(Integer.toHexString(this.xfIndex));
/* 263 */       buf.append(")");
/* 264 */       this.xfIndex += 1;
/*     */     }
/*     */     
/* 267 */     if (code == Type.FONT.value)
/*     */     {
/* 269 */       if (this.fontIndex == 4)
/*     */       {
/* 271 */         this.fontIndex += 1;
/*     */       }
/*     */       
/* 274 */       buf.append(" (0x");
/* 275 */       buf.append(Integer.toHexString(this.fontIndex));
/* 276 */       buf.append(")");
/* 277 */       this.fontIndex += 1;
/*     */     }
/*     */     
/* 280 */     this.writer.write(buf.toString());
/* 281 */     this.writer.newLine();
/*     */     
/* 283 */     byte[] standardData = new byte[4];
/* 284 */     standardData[0] = ((byte)(code & 0xFF));
/* 285 */     standardData[1] = ((byte)((code & 0xFF00) >> 8));
/* 286 */     standardData[2] = ((byte)(r.getLength() & 0xFF));
/* 287 */     standardData[3] = ((byte)((r.getLength() & 0xFF00) >> 8));
/* 288 */     byte[] recordData = r.getData();
/* 289 */     byte[] data = new byte[standardData.length + recordData.length];
/* 290 */     System.arraycopy(standardData, 0, data, 0, standardData.length);
/* 291 */     System.arraycopy(recordData, 0, data, standardData.length, recordData.length);
/*     */     
/*     */ 
/* 294 */     int byteCount = 0;
/* 295 */     int lineBytes = 0;
/*     */     
/* 297 */     while (byteCount < data.length)
/*     */     {
/* 299 */       buf = new StringBuffer();
/* 300 */       writeSixDigitValue(pos + byteCount, buf);
/* 301 */       buf.append("   ");
/*     */       
/* 303 */       lineBytes = Math.min(16, data.length - byteCount);
/*     */       
/* 305 */       for (int i = 0; i < lineBytes; i++)
/*     */       {
/* 307 */         writeByte(data[(i + byteCount)], buf);
/* 308 */         buf.append(' ');
/*     */       }
/*     */       
/*     */ 
/* 312 */       if (lineBytes < 16)
/*     */       {
/* 314 */         for (int i = 0; i < 16 - lineBytes; i++)
/*     */         {
/* 316 */           buf.append("   ");
/*     */         }
/*     */       }
/*     */       
/* 320 */       buf.append("  ");
/*     */       
/* 322 */       for (int i = 0; i < lineBytes; i++)
/*     */       {
/* 324 */         char c = (char)data[(i + byteCount)];
/* 325 */         if ((c < ' ') || (c > 'z'))
/*     */         {
/* 327 */           c = '.';
/*     */         }
/* 329 */         buf.append(c);
/*     */       }
/*     */       
/* 332 */       byteCount += lineBytes;
/*     */       
/* 334 */       this.writer.write(buf.toString());
/* 335 */       this.writer.newLine();
/*     */     }
/*     */     
/* 338 */     return cont;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeSixDigitValue(int pos, StringBuffer buf)
/*     */   {
/* 346 */     String val = Integer.toHexString(pos);
/*     */     
/* 348 */     for (int i = 6; i > val.length(); i--)
/*     */     {
/* 350 */       buf.append('0');
/*     */     }
/* 352 */     buf.append(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeByte(byte val, StringBuffer buf)
/*     */   {
/* 360 */     String sv = Integer.toHexString(val & 0xFF);
/*     */     
/* 362 */     if (sv.length() == 1)
/*     */     {
/* 364 */       buf.append('0');
/*     */     }
/* 366 */     buf.append(sv);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\BiffDump.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */