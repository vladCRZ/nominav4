/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.Cell;
/*     */ import jxl.Sheet;
/*     */ import jxl.SheetSettings;
/*     */ import jxl.Workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSV
/*     */ {
/*     */   public CSV(Workbook w, OutputStream out, String encoding, boolean hide)
/*     */     throws IOException
/*     */   {
/*  52 */     if ((encoding == null) || (!encoding.equals("UnicodeBig")))
/*     */     {
/*  54 */       encoding = "UTF8";
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  59 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/*  60 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/*  62 */       for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++)
/*     */       {
/*  64 */         Sheet s = w.getSheet(sheet);
/*     */         
/*  66 */         if ((!hide) || (!s.getSettings().isHidden()))
/*     */         {
/*  68 */           bw.write("*** " + s.getName() + " ****");
/*  69 */           bw.newLine();
/*     */           
/*  71 */           Cell[] row = null;
/*     */           
/*  73 */           for (int i = 0; i < s.getRows(); i++)
/*     */           {
/*  75 */             row = s.getRow(i);
/*     */             
/*  77 */             if (row.length > 0)
/*     */             {
/*  79 */               if ((!hide) || (!row[0].isHidden()))
/*     */               {
/*  81 */                 bw.write(row[0].getContents());
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*  86 */               for (int j = 1; j < row.length; j++)
/*     */               {
/*  88 */                 bw.write(44);
/*  89 */                 if ((!hide) || (!row[j].isHidden()))
/*     */                 {
/*  91 */                   bw.write(row[j].getContents());
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*  97 */             bw.newLine();
/*     */           }
/*     */         }
/*     */       }
/* 101 */       bw.flush();
/* 102 */       bw.close();
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 106 */       System.err.println(e.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\CSV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */