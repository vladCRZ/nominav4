/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import jxl.Cell;
/*     */ import jxl.Range;
/*     */ import jxl.Workbook;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Demo
/*     */ {
/*     */   private static final int CSVFormat = 13;
/*     */   private static final int XMLFormat = 14;
/*  45 */   private static Logger logger = Logger.getLogger(Demo.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void displayHelp()
/*     */   {
/*  52 */     System.err.println("Command format:  Demo [-unicode] [-csv] [-hide] excelfile");
/*     */     
/*  54 */     System.err.println("                 Demo -xml [-format]  excelfile");
/*  55 */     System.err.println("                 Demo -readwrite|-rw excelfile output");
/*  56 */     System.err.println("                 Demo -biffdump | -bd | -wa | -write | -formulas | -features | -escher | -escherdg excelfile");
/*  57 */     System.err.println("                 Demo -ps excelfile [property] [output]");
/*  58 */     System.err.println("                 Demo -version | -logtest | -h | -help");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  71 */     if (args.length == 0)
/*     */     {
/*  73 */       displayHelp();
/*  74 */       System.exit(1);
/*     */     }
/*     */     
/*  77 */     if ((args[0].equals("-help")) || (args[0].equals("-h")))
/*     */     {
/*  79 */       displayHelp();
/*  80 */       System.exit(1);
/*     */     }
/*     */     
/*  83 */     if (args[0].equals("-version"))
/*     */     {
/*  85 */       System.out.println("v" + Workbook.getVersion());
/*  86 */       System.exit(0);
/*     */     }
/*     */     
/*  89 */     if (args[0].equals("-logtest"))
/*     */     {
/*  91 */       logger.debug("A sample \"debug\" message");
/*  92 */       logger.info("A sample \"info\" message");
/*  93 */       logger.warn("A sample \"warning\" message");
/*  94 */       logger.error("A sample \"error\" message");
/*  95 */       logger.fatal("A sample \"fatal\" message");
/*  96 */       System.exit(0);
/*     */     }
/*     */     
/*  99 */     boolean write = false;
/* 100 */     boolean readwrite = false;
/* 101 */     boolean formulas = false;
/* 102 */     boolean biffdump = false;
/* 103 */     boolean jxlversion = false;
/* 104 */     boolean propertysets = false;
/* 105 */     boolean features = false;
/* 106 */     boolean escher = false;
/* 107 */     boolean escherdg = false;
/* 108 */     String file = args[0];
/* 109 */     String outputFile = null;
/* 110 */     String propertySet = null;
/*     */     
/* 112 */     if (args[0].equals("-write"))
/*     */     {
/* 114 */       write = true;
/* 115 */       file = args[1];
/*     */     }
/* 117 */     else if (args[0].equals("-formulas"))
/*     */     {
/* 119 */       formulas = true;
/* 120 */       file = args[1];
/*     */     }
/* 122 */     else if (args[0].equals("-features"))
/*     */     {
/* 124 */       features = true;
/* 125 */       file = args[1];
/*     */     }
/* 127 */     else if (args[0].equals("-escher"))
/*     */     {
/* 129 */       escher = true;
/* 130 */       file = args[1];
/*     */     }
/* 132 */     else if (args[0].equals("-escherdg"))
/*     */     {
/* 134 */       escherdg = true;
/* 135 */       file = args[1];
/*     */     }
/* 137 */     else if ((args[0].equals("-biffdump")) || (args[0].equals("-bd")))
/*     */     {
/* 139 */       biffdump = true;
/* 140 */       file = args[1];
/*     */     }
/* 142 */     else if (args[0].equals("-wa"))
/*     */     {
/* 144 */       jxlversion = true;
/* 145 */       file = args[1];
/*     */     }
/* 147 */     else if (args[0].equals("-ps"))
/*     */     {
/* 149 */       propertysets = true;
/* 150 */       file = args[1];
/*     */       
/* 152 */       if (args.length > 2)
/*     */       {
/* 154 */         propertySet = args[2];
/*     */       }
/*     */       
/* 157 */       if (args.length == 4)
/*     */       {
/* 159 */         outputFile = args[3];
/*     */       }
/*     */     }
/* 162 */     else if ((args[0].equals("-readwrite")) || (args[0].equals("-rw")))
/*     */     {
/* 164 */       readwrite = true;
/* 165 */       file = args[1];
/* 166 */       outputFile = args[2];
/*     */     }
/*     */     else
/*     */     {
/* 170 */       file = args[(args.length - 1)];
/*     */     }
/*     */     
/* 173 */     String encoding = "UTF8";
/* 174 */     int format = 13;
/* 175 */     boolean formatInfo = false;
/* 176 */     boolean hideCells = false;
/*     */     
/* 178 */     if ((!write) && (!readwrite) && (!formulas) && (!biffdump) && (!jxlversion) && (!propertysets) && (!features) && (!escher) && (!escherdg))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */       for (int i = 0; i < args.length - 1; i++)
/*     */       {
/* 190 */         if (args[i].equals("-unicode"))
/*     */         {
/* 192 */           encoding = "UnicodeBig";
/*     */         }
/* 194 */         else if (args[i].equals("-xml"))
/*     */         {
/* 196 */           format = 14;
/*     */         }
/* 198 */         else if (args[i].equals("-csv"))
/*     */         {
/* 200 */           format = 13;
/*     */         }
/* 202 */         else if (args[i].equals("-format"))
/*     */         {
/* 204 */           formatInfo = true;
/*     */         }
/* 206 */         else if (args[i].equals("-hide"))
/*     */         {
/* 208 */           hideCells = true;
/*     */         }
/*     */         else
/*     */         {
/* 212 */           System.err.println("Command format:  CSV [-unicode] [-xml|-csv] excelfile");
/*     */           
/* 214 */           System.exit(1);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 221 */       if (write)
/*     */       {
/* 223 */         Write w = new Write(file);
/* 224 */         w.write();
/*     */       }
/* 226 */       else if (readwrite)
/*     */       {
/* 228 */         ReadWrite rw = new ReadWrite(file, outputFile);
/* 229 */         rw.readWrite();
/*     */       }
/* 231 */       else if (formulas)
/*     */       {
/* 233 */         Workbook w = Workbook.getWorkbook(new File(file));
/* 234 */         Formulas f = new Formulas(w, System.out, encoding);
/* 235 */         w.close();
/*     */       }
/* 237 */       else if (features)
/*     */       {
/* 239 */         Workbook w = Workbook.getWorkbook(new File(file));
/* 240 */         Features f = new Features(w, System.out, encoding);
/* 241 */         w.close();
/*     */       }
/* 243 */       else if (escher)
/*     */       {
/* 245 */         Workbook w = Workbook.getWorkbook(new File(file));
/* 246 */         Escher f = new Escher(w, System.out, encoding);
/* 247 */         w.close();
/*     */       }
/* 249 */       else if (escherdg)
/*     */       {
/* 251 */         Workbook w = Workbook.getWorkbook(new File(file));
/* 252 */         EscherDrawingGroup f = new EscherDrawingGroup(w, System.out, encoding);
/* 253 */         w.close();
/*     */       } else { BiffDump bd;
/* 255 */         if (biffdump)
/*     */         {
/* 257 */           bd = new BiffDump(new File(file), System.out);
/*     */         } else { WriteAccess bd;
/* 259 */           if (jxlversion)
/*     */           {
/* 261 */             bd = new WriteAccess(new File(file));
/*     */           } else { PropertySetsReader psr;
/* 263 */             if (propertysets)
/*     */             {
/* 265 */               OutputStream os = System.out;
/* 266 */               if (outputFile != null)
/*     */               {
/* 268 */                 os = new FileOutputStream(outputFile);
/*     */               }
/* 270 */               psr = new PropertySetsReader(new File(file), propertySet, os);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 276 */               Workbook w = Workbook.getWorkbook(new File(file));
/*     */               
/*     */               CSV csv;
/*     */               XML xml;
/* 280 */               if (format == 13)
/*     */               {
/* 282 */                 csv = new CSV(w, System.out, encoding, hideCells);
/*     */               }
/* 284 */               else if (format == 14)
/*     */               {
/* 286 */                 xml = new XML(w, System.out, encoding, formatInfo);
/*     */               }
/*     */               
/* 289 */               w.close();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 294 */     } catch (Throwable t) { System.out.println(t.toString());
/* 295 */       t.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void findTest(Workbook w)
/*     */   {
/* 304 */     logger.info("Find test");
/*     */     
/* 306 */     Cell c = w.findCellByName("named1");
/* 307 */     if (c != null)
/*     */     {
/* 309 */       logger.info("named1 contents:  " + c.getContents());
/*     */     }
/*     */     
/* 312 */     c = w.findCellByName("named2");
/* 313 */     if (c != null)
/*     */     {
/* 315 */       logger.info("named2 contents:  " + c.getContents());
/*     */     }
/*     */     
/* 318 */     c = w.findCellByName("namedrange");
/* 319 */     if (c != null)
/*     */     {
/* 321 */       logger.info("named2 contents:  " + c.getContents());
/*     */     }
/*     */     
/* 324 */     Range[] range = w.findByName("namedrange");
/* 325 */     if (range != null)
/*     */     {
/* 327 */       c = range[0].getTopLeft();
/* 328 */       logger.info("namedrange top left contents:  " + c.getContents());
/*     */       
/* 330 */       c = range[0].getBottomRight();
/* 331 */       logger.info("namedrange bottom right contents:  " + c.getContents());
/*     */     }
/*     */     
/* 334 */     range = w.findByName("nonadjacentrange");
/* 335 */     if (range != null)
/*     */     {
/* 337 */       for (int i = 0; i < range.length; i++)
/*     */       {
/* 339 */         c = range[i].getTopLeft();
/* 340 */         logger.info("nonadjacent top left contents:  " + c.getContents());
/*     */         
/* 342 */         c = range[i].getBottomRight();
/* 343 */         logger.info("nonadjacent bottom right contents:  " + c.getContents());
/*     */       }
/*     */     }
/*     */     
/* 347 */     range = w.findByName("horizontalnonadjacentrange");
/* 348 */     if (range != null)
/*     */     {
/* 350 */       for (int i = 0; i < range.length; i++)
/*     */       {
/* 352 */         c = range[i].getTopLeft();
/* 353 */         logger.info("horizontalnonadjacent top left contents:  " + c.getContents());
/*     */         
/*     */ 
/* 356 */         c = range[i].getBottomRight();
/* 357 */         logger.info("horizontalnonadjacent bottom right contents:  " + c.getContents());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\Demo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */