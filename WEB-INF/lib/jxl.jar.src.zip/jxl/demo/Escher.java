/*    */ package jxl.demo;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintStream;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import jxl.Workbook;
/*    */ import jxl.biff.drawing.DrawingData;
/*    */ import jxl.biff.drawing.EscherDisplay;
/*    */ import jxl.read.biff.SheetImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Escher
/*    */ {
/*    */   public Escher(Workbook w, OutputStream out, String encoding)
/*    */     throws IOException
/*    */   {
/* 50 */     if ((encoding == null) || (!encoding.equals("UnicodeBig")))
/*    */     {
/* 52 */       encoding = "UTF8";
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 57 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/* 58 */       BufferedWriter bw = new BufferedWriter(osw);
/*    */       
/* 60 */       for (int i = 0; i < w.getNumberOfSheets(); i++)
/*    */       {
/* 62 */         SheetImpl s = (SheetImpl)w.getSheet(i);
/* 63 */         bw.write(s.getName());
/* 64 */         bw.newLine();
/* 65 */         bw.newLine();
/*    */         
/* 67 */         DrawingData dd = s.getDrawingData();
/*    */         
/* 69 */         if (dd != null)
/*    */         {
/* 71 */           EscherDisplay ed = new EscherDisplay(dd, bw);
/* 72 */           ed.display();
/*    */         }
/*    */         
/* 75 */         bw.newLine();
/* 76 */         bw.newLine();
/* 77 */         bw.flush();
/*    */       }
/* 79 */       bw.flush();
/* 80 */       bw.close();
/*    */     }
/*    */     catch (UnsupportedEncodingException e)
/*    */     {
/* 84 */       System.err.println(e.toString());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\Escher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */