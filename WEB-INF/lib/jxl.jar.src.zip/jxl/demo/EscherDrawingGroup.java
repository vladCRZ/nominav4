/*    */ package jxl.demo;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintStream;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import jxl.Workbook;
/*    */ import jxl.biff.drawing.DrawingGroup;
/*    */ import jxl.biff.drawing.EscherDisplay;
/*    */ import jxl.read.biff.WorkbookParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EscherDrawingGroup
/*    */ {
/*    */   public EscherDrawingGroup(Workbook w, OutputStream out, String encoding)
/*    */     throws IOException
/*    */   {
/* 50 */     if ((encoding == null) || (!encoding.equals("UnicodeBig")))
/*    */     {
/* 52 */       encoding = "UTF8";
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 57 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/* 58 */       BufferedWriter bw = new BufferedWriter(osw);
/*    */       
/* 60 */       WorkbookParser wp = (WorkbookParser)w;
/*    */       
/* 62 */       DrawingGroup dg = wp.getDrawingGroup();
/*    */       
/* 64 */       if (dg != null)
/*    */       {
/* 66 */         EscherDisplay ed = new EscherDisplay(dg, bw);
/* 67 */         ed.display();
/*    */       }
/*    */       
/* 70 */       bw.newLine();
/* 71 */       bw.newLine();
/* 72 */       bw.flush();
/* 73 */       bw.close();
/*    */     }
/*    */     catch (UnsupportedEncodingException e)
/*    */     {
/* 77 */       System.err.println(e.toString());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\EscherDrawingGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */