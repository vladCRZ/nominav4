/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Features
/*     */ {
/*     */   public Features(Workbook w, OutputStream out, String encoding)
/*     */     throws IOException
/*     */   {
/*  54 */     if ((encoding == null) || (!encoding.equals("UnicodeBig")))
/*     */     {
/*  56 */       encoding = "UTF8";
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  61 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/*  62 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/*  64 */       for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++)
/*     */       {
/*  66 */         Sheet s = w.getSheet(sheet);
/*     */         
/*  68 */         bw.write(s.getName());
/*  69 */         bw.newLine();
/*     */         
/*  71 */         Cell[] row = null;
/*  72 */         Cell c = null;
/*     */         
/*  74 */         for (int i = 0; i < s.getRows(); i++)
/*     */         {
/*  76 */           row = s.getRow(i);
/*     */           
/*  78 */           for (int j = 0; j < row.length; j++)
/*     */           {
/*  80 */             c = row[j];
/*  81 */             if (c.getCellFeatures() != null)
/*     */             {
/*  83 */               CellFeatures features = c.getCellFeatures();
/*  84 */               StringBuffer sb = new StringBuffer();
/*  85 */               CellReferenceHelper.getCellReference(c.getColumn(), c.getRow(), sb);
/*     */               
/*     */ 
/*  88 */               bw.write("Cell " + sb.toString() + " contents:  " + c.getContents());
/*     */               
/*  90 */               bw.flush();
/*  91 */               bw.write(" comment: " + features.getComment());
/*  92 */               bw.flush();
/*  93 */               bw.newLine();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  98 */       bw.flush();
/*  99 */       bw.close();
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 103 */       System.err.println(e.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\Features.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */