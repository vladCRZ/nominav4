/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.FormulaCell;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Formulas
/*     */ {
/*     */   public Formulas(Workbook w, OutputStream out, String encoding)
/*     */     throws IOException
/*     */   {
/*  58 */     if ((encoding == null) || (!encoding.equals("UnicodeBig")))
/*     */     {
/*  60 */       encoding = "UTF8";
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  65 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/*  66 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/*  68 */       ArrayList parseErrors = new ArrayList();
/*     */       
/*  70 */       for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++)
/*     */       {
/*  72 */         Sheet s = w.getSheet(sheet);
/*     */         
/*  74 */         bw.write(s.getName());
/*  75 */         bw.newLine();
/*     */         
/*  77 */         Cell[] row = null;
/*  78 */         Cell c = null;
/*     */         
/*  80 */         for (int i = 0; i < s.getRows(); i++)
/*     */         {
/*  82 */           row = s.getRow(i);
/*     */           
/*  84 */           for (int j = 0; j < row.length; j++)
/*     */           {
/*  86 */             c = row[j];
/*  87 */             if ((c.getType() == CellType.NUMBER_FORMULA) || (c.getType() == CellType.STRING_FORMULA) || (c.getType() == CellType.BOOLEAN_FORMULA) || (c.getType() == CellType.DATE_FORMULA) || (c.getType() == CellType.FORMULA_ERROR))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */               FormulaCell nfc = (FormulaCell)c;
/*  94 */               StringBuffer sb = new StringBuffer();
/*  95 */               CellReferenceHelper.getCellReference(c.getColumn(), c.getRow(), sb);
/*     */               
/*     */ 
/*     */               try
/*     */               {
/* 100 */                 bw.write("Formula in " + sb.toString() + " value:  " + c.getContents());
/*     */                 
/* 102 */                 bw.flush();
/* 103 */                 bw.write(" formula: " + nfc.getFormula());
/* 104 */                 bw.flush();
/* 105 */                 bw.newLine();
/*     */               }
/*     */               catch (FormulaException e)
/*     */               {
/* 109 */                 bw.newLine();
/* 110 */                 parseErrors.add(s.getName() + '!' + sb.toString() + ": " + e.getMessage());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 117 */       bw.flush();
/* 118 */       bw.close();
/*     */       
/* 120 */       if (parseErrors.size() > 0)
/*     */       {
/* 122 */         System.err.println();
/* 123 */         System.err.println("There were " + parseErrors.size() + " errors");
/*     */         
/* 125 */         Iterator i = parseErrors.iterator();
/* 126 */         while (i.hasNext())
/*     */         {
/* 128 */           System.err.println(i.next());
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 134 */       System.err.println(e.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\Formulas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */