/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.BaseCompoundFile.PropertyStorage;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.read.biff.CompoundFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertySetsReader
/*     */ {
/*     */   private BufferedWriter writer;
/*     */   private CompoundFile compoundFile;
/*     */   
/*     */   public PropertySetsReader(File file, String propertySet, OutputStream os)
/*     */     throws IOException, BiffException
/*     */   {
/*  55 */     this.writer = new BufferedWriter(new OutputStreamWriter(os));
/*  56 */     FileInputStream fis = new FileInputStream(file);
/*     */     
/*  58 */     int initialFileSize = 1048576;
/*  59 */     int arrayGrowSize = 1048576;
/*     */     
/*  61 */     byte[] d = new byte[initialFileSize];
/*  62 */     int bytesRead = fis.read(d);
/*  63 */     int pos = bytesRead;
/*     */     
/*  65 */     while (bytesRead != -1)
/*     */     {
/*  67 */       if (pos >= d.length)
/*     */       {
/*     */ 
/*  70 */         byte[] newArray = new byte[d.length + arrayGrowSize];
/*  71 */         System.arraycopy(d, 0, newArray, 0, d.length);
/*  72 */         d = newArray;
/*     */       }
/*  74 */       bytesRead = fis.read(d, pos, d.length - pos);
/*  75 */       pos += bytesRead;
/*     */     }
/*     */     
/*  78 */     bytesRead = pos + 1;
/*     */     
/*  80 */     this.compoundFile = new CompoundFile(d, new WorkbookSettings());
/*  81 */     fis.close();
/*     */     
/*  83 */     if (propertySet == null)
/*     */     {
/*  85 */       displaySets();
/*     */     }
/*     */     else
/*     */     {
/*  89 */       displayPropertySet(propertySet, os);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void displaySets()
/*     */     throws IOException
/*     */   {
/*  98 */     int numSets = this.compoundFile.getNumberOfPropertySets();
/*     */     
/* 100 */     for (int i = 0; i < numSets; i++)
/*     */     {
/* 102 */       BaseCompoundFile.PropertyStorage ps = this.compoundFile.getPropertySet(i);
/* 103 */       this.writer.write(Integer.toString(i));
/* 104 */       this.writer.write(") ");
/* 105 */       this.writer.write(ps.name);
/* 106 */       this.writer.write("(type ");
/* 107 */       this.writer.write(Integer.toString(ps.type));
/* 108 */       this.writer.write(" size ");
/* 109 */       this.writer.write(Integer.toString(ps.size));
/* 110 */       this.writer.write(" prev ");
/* 111 */       this.writer.write(Integer.toString(ps.previous));
/* 112 */       this.writer.write(" next ");
/* 113 */       this.writer.write(Integer.toString(ps.next));
/* 114 */       this.writer.write(" child ");
/* 115 */       this.writer.write(Integer.toString(ps.child));
/* 116 */       this.writer.write(" start block ");
/* 117 */       this.writer.write(Integer.toString(ps.startBlock));
/* 118 */       this.writer.write(")");
/* 119 */       this.writer.newLine();
/*     */     }
/*     */     
/* 122 */     this.writer.flush();
/* 123 */     this.writer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void displayPropertySet(String ps, OutputStream os)
/*     */     throws IOException, BiffException
/*     */   {
/* 132 */     if (ps.equalsIgnoreCase("SummaryInformation"))
/*     */     {
/* 134 */       ps = "\005SummaryInformation";
/*     */     }
/* 136 */     else if (ps.equalsIgnoreCase("DocumentSummaryInformation"))
/*     */     {
/* 138 */       ps = "\005DocumentSummaryInformation";
/*     */     }
/* 140 */     else if (ps.equalsIgnoreCase("CompObj"))
/*     */     {
/* 142 */       ps = "\001CompObj";
/*     */     }
/*     */     
/* 145 */     byte[] stream = this.compoundFile.getStream(ps);
/* 146 */     os.write(stream);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\PropertySetsReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */