/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.Range;
/*     */ import jxl.Workbook;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.UnderlineStyle;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.write.Blank;
/*     */ import jxl.write.DateFormat;
/*     */ import jxl.write.DateFormats;
/*     */ import jxl.write.DateTime;
/*     */ import jxl.write.Formula;
/*     */ import jxl.write.Label;
/*     */ import jxl.write.Number;
/*     */ import jxl.write.NumberFormat;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFeatures;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableFont;
/*     */ import jxl.write.WritableHyperlink;
/*     */ import jxl.write.WritableImage;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadWrite
/*     */ {
/*  73 */   private static Logger logger = Logger.getLogger(ReadWrite.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File inputWorkbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private File outputWorkbook;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWrite(String input, String output)
/*     */   {
/*  92 */     this.inputWorkbook = new File(input);
/*  93 */     this.outputWorkbook = new File(output);
/*  94 */     logger.setSuppressWarnings(Boolean.getBoolean("jxl.nowarnings"));
/*  95 */     logger.info("Input file:  " + input);
/*  96 */     logger.info("Output file:  " + output);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readWrite()
/*     */     throws IOException, BiffException, WriteException
/*     */   {
/* 107 */     logger.info("Reading...");
/* 108 */     Workbook w1 = Workbook.getWorkbook(this.inputWorkbook);
/*     */     
/* 110 */     logger.info("Copying...");
/* 111 */     WritableWorkbook w2 = Workbook.createWorkbook(this.outputWorkbook, w1);
/*     */     
/* 113 */     if (this.inputWorkbook.getName().equals("jxlrwtest.xls"))
/*     */     {
/* 115 */       modify(w2);
/*     */     }
/*     */     
/* 118 */     w2.write();
/* 119 */     w2.close();
/* 120 */     logger.info("Done");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void modify(WritableWorkbook w)
/*     */     throws WriteException
/*     */   {
/* 131 */     logger.info("Modifying...");
/*     */     
/* 133 */     WritableSheet sheet = w.getSheet("modified");
/*     */     
/* 135 */     WritableCell cell = null;
/* 136 */     CellFormat cf = null;
/* 137 */     Label l = null;
/* 138 */     WritableCellFeatures wcf = null;
/*     */     
/*     */ 
/* 141 */     cell = sheet.getWritableCell(1, 3);
/* 142 */     WritableFont bold = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD);
/*     */     
/*     */ 
/* 145 */     cf = new WritableCellFormat(bold);
/* 146 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/* 149 */     cell = sheet.getWritableCell(1, 4);
/* 150 */     WritableFont underline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 155 */     cf = new WritableCellFormat(underline);
/* 156 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/* 159 */     cell = sheet.getWritableCell(1, 5);
/* 160 */     WritableFont tenpoint = new WritableFont(WritableFont.ARIAL, 10);
/* 161 */     cf = new WritableCellFormat(tenpoint);
/* 162 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/* 165 */     cell = sheet.getWritableCell(1, 6);
/* 166 */     if (cell.getType() == CellType.LABEL)
/*     */     {
/* 168 */       Label lc = (Label)cell;
/* 169 */       lc.setString(lc.getString() + " - mod");
/*     */     }
/*     */     
/*     */ 
/* 173 */     cell = sheet.getWritableCell(1, 9);
/* 174 */     NumberFormat sevendps = new NumberFormat("#.0000000");
/* 175 */     cf = new WritableCellFormat(sevendps);
/* 176 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/*     */ 
/* 180 */     cell = sheet.getWritableCell(1, 10);
/* 181 */     NumberFormat exp4 = new NumberFormat("0.####E0");
/* 182 */     cf = new WritableCellFormat(exp4);
/* 183 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/* 186 */     cell = sheet.getWritableCell(1, 11);
/* 187 */     cell.setCellFormat(WritableWorkbook.NORMAL_STYLE);
/*     */     
/*     */ 
/* 190 */     cell = sheet.getWritableCell(1, 12);
/* 191 */     if (cell.getType() == CellType.NUMBER)
/*     */     {
/* 193 */       Number n = (Number)cell;
/* 194 */       n.setValue(42.0D);
/*     */     }
/*     */     
/*     */ 
/* 198 */     cell = sheet.getWritableCell(1, 13);
/* 199 */     if (cell.getType() == CellType.NUMBER)
/*     */     {
/* 201 */       Number n = (Number)cell;
/* 202 */       n.setValue(n.getValue() + 0.1D);
/*     */     }
/*     */     
/*     */ 
/* 206 */     cell = sheet.getWritableCell(1, 16);
/* 207 */     DateFormat df = new DateFormat("dd MMM yyyy HH:mm:ss");
/* 208 */     cf = new WritableCellFormat(df);
/* 209 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/* 212 */     cell = sheet.getWritableCell(1, 17);
/* 213 */     cf = new WritableCellFormat(DateFormats.FORMAT9);
/* 214 */     cell.setCellFormat(cf);
/*     */     
/*     */ 
/* 217 */     cell = sheet.getWritableCell(1, 18);
/* 218 */     if (cell.getType() == CellType.DATE)
/*     */     {
/* 220 */       DateTime dt = (DateTime)cell;
/* 221 */       Calendar cal = Calendar.getInstance();
/* 222 */       cal.set(1998, 1, 18, 11, 23, 28);
/* 223 */       Date d = cal.getTime();
/* 224 */       dt.setDate(d);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 229 */     cell = sheet.getWritableCell(1, 22);
/* 230 */     if (cell.getType() == CellType.NUMBER)
/*     */     {
/* 232 */       Number n = (Number)cell;
/* 233 */       n.setValue(6.8D);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 238 */     cell = sheet.getWritableCell(1, 29);
/* 239 */     if (cell.getType() == CellType.LABEL)
/*     */     {
/* 241 */       l = (Label)cell;
/* 242 */       l.setString("Modified string contents");
/*     */     }
/*     */     
/* 245 */     sheet.insertRow(34);
/*     */     
/*     */ 
/* 248 */     sheet.removeRow(38);
/*     */     
/*     */ 
/* 251 */     sheet.insertColumn(9);
/*     */     
/*     */ 
/* 254 */     sheet.removeColumn(11);
/*     */     
/*     */ 
/*     */ 
/* 258 */     sheet.removeRow(43);
/* 259 */     sheet.insertRow(43);
/*     */     
/*     */ 
/* 262 */     WritableHyperlink[] hyperlinks = sheet.getWritableHyperlinks();
/*     */     
/* 264 */     for (int i = 0; i < hyperlinks.length; i++)
/*     */     {
/* 266 */       WritableHyperlink wh = hyperlinks[i];
/* 267 */       if ((wh.getColumn() == 1) && (wh.getRow() == 39))
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 272 */           wh.setURL(new URL("http://www.andykhan.com/jexcelapi/index.html"));
/*     */         }
/*     */         catch (MalformedURLException e)
/*     */         {
/* 276 */           logger.warn(e.toString());
/*     */         }
/*     */         
/* 279 */       } else if ((wh.getColumn() == 1) && (wh.getRow() == 40))
/*     */       {
/* 281 */         wh.setFile(new File("../jexcelapi/docs/overview-summary.html"));
/*     */       }
/* 283 */       else if ((wh.getColumn() == 1) && (wh.getRow() == 41))
/*     */       {
/* 285 */         wh.setFile(new File("d:/home/jexcelapi/docs/jxl/package-summary.html"));
/*     */       }
/* 287 */       else if ((wh.getColumn() == 1) && (wh.getRow() == 44))
/*     */       {
/*     */ 
/* 290 */         sheet.removeHyperlink(wh);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 295 */     WritableCell c = sheet.getWritableCell(5, 30);
/* 296 */     WritableCellFormat newFormat = new WritableCellFormat(c.getCellFormat());
/* 297 */     newFormat.setBackground(Colour.RED);
/* 298 */     c.setCellFormat(newFormat);
/*     */     
/*     */ 
/* 301 */     l = new Label(0, 49, "Modified merged cells");
/* 302 */     sheet.addCell(l);
/*     */     
/*     */ 
/* 305 */     Number n = (Number)sheet.getWritableCell(0, 70);
/* 306 */     n.setValue(9.0D);
/*     */     
/* 308 */     n = (Number)sheet.getWritableCell(0, 71);
/* 309 */     n.setValue(10.0D);
/*     */     
/* 311 */     n = (Number)sheet.getWritableCell(0, 73);
/* 312 */     n.setValue(4.0D);
/*     */     
/*     */ 
/* 315 */     Formula f = new Formula(1, 80, "ROUND(COS(original!B10),2)");
/* 316 */     sheet.addCell(f);
/*     */     
/*     */ 
/* 319 */     f = new Formula(1, 83, "value1+value2");
/* 320 */     sheet.addCell(f);
/*     */     
/*     */ 
/* 323 */     f = new Formula(1, 84, "AVERAGE(value1,value1*4,value2)");
/* 324 */     sheet.addCell(f);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 330 */     Label label = new Label(0, 88, "Some copied cells", cf);
/* 331 */     sheet.addCell(label);
/*     */     
/* 333 */     label = new Label(0, 89, "Number from B9");
/* 334 */     sheet.addCell(label);
/*     */     
/* 336 */     WritableCell wc = sheet.getWritableCell(1, 9).copyTo(1, 89);
/* 337 */     sheet.addCell(wc);
/*     */     
/* 339 */     label = new Label(0, 90, "Label from B4 (modified format)");
/* 340 */     sheet.addCell(label);
/*     */     
/* 342 */     wc = sheet.getWritableCell(1, 3).copyTo(1, 90);
/* 343 */     sheet.addCell(wc);
/*     */     
/* 345 */     label = new Label(0, 91, "Date from B17");
/* 346 */     sheet.addCell(label);
/*     */     
/* 348 */     wc = sheet.getWritableCell(1, 16).copyTo(1, 91);
/* 349 */     sheet.addCell(wc);
/*     */     
/* 351 */     label = new Label(0, 92, "Boolean from E16");
/* 352 */     sheet.addCell(label);
/*     */     
/* 354 */     wc = sheet.getWritableCell(4, 15).copyTo(1, 92);
/* 355 */     sheet.addCell(wc);
/*     */     
/* 357 */     label = new Label(0, 93, "URL from B40");
/* 358 */     sheet.addCell(label);
/*     */     
/* 360 */     wc = sheet.getWritableCell(1, 39).copyTo(1, 93);
/* 361 */     sheet.addCell(wc);
/*     */     
/*     */ 
/* 364 */     for (int i = 0; i < 6; i++)
/*     */     {
/* 366 */       Number number = new Number(1, 94 + i, i + 1 + i / 8.0D);
/* 367 */       sheet.addCell(number);
/*     */     }
/*     */     
/* 370 */     label = new Label(0, 100, "Formula from B27");
/* 371 */     sheet.addCell(label);
/*     */     
/* 373 */     wc = sheet.getWritableCell(1, 26).copyTo(1, 100);
/* 374 */     sheet.addCell(wc);
/*     */     
/* 376 */     label = new Label(0, 101, "A brand new formula");
/* 377 */     sheet.addCell(label);
/*     */     
/* 379 */     Formula formula = new Formula(1, 101, "SUM(B94:B96)");
/* 380 */     sheet.addCell(formula);
/*     */     
/* 382 */     label = new Label(0, 102, "A copy of it");
/* 383 */     sheet.addCell(label);
/*     */     
/* 385 */     wc = sheet.getWritableCell(1, 101).copyTo(1, 102);
/* 386 */     sheet.addCell(wc);
/*     */     
/*     */ 
/* 389 */     WritableImage wi = sheet.getImage(1);
/* 390 */     sheet.removeImage(wi);
/*     */     
/* 392 */     wi = new WritableImage(1.0D, 116.0D, 2.0D, 9.0D, new File("resources/littlemoretonhall.png"));
/*     */     
/* 394 */     sheet.addImage(wi);
/*     */     
/*     */ 
/* 397 */     label = new Label(0, 151, "Added drop down validation");
/* 398 */     sheet.addCell(label);
/*     */     
/* 400 */     Blank b = new Blank(1, 151);
/* 401 */     wcf = new WritableCellFeatures();
/* 402 */     ArrayList al = new ArrayList();
/* 403 */     al.add("The Fellowship of the Ring");
/* 404 */     al.add("The Two Towers");
/* 405 */     al.add("The Return of the King");
/* 406 */     wcf.setDataValidationList(al);
/* 407 */     b.setCellFeatures(wcf);
/* 408 */     sheet.addCell(b);
/*     */     
/*     */ 
/* 411 */     label = new Label(0, 152, "Added number validation 2.718 < x < 3.142");
/* 412 */     sheet.addCell(label);
/* 413 */     b = new Blank(1, 152);
/* 414 */     wcf = new WritableCellFeatures();
/* 415 */     wcf.setNumberValidation(2.718D, 3.142D, WritableCellFeatures.BETWEEN);
/* 416 */     b.setCellFeatures(wcf);
/* 417 */     sheet.addCell(b);
/*     */     
/*     */ 
/* 420 */     cell = sheet.getWritableCell(0, 156);
/* 421 */     l = (Label)cell;
/* 422 */     l.setString("Label text modified");
/*     */     
/* 424 */     cell = sheet.getWritableCell(0, 157);
/* 425 */     wcf = cell.getWritableCellFeatures();
/* 426 */     wcf.setComment("modified comment text");
/*     */     
/* 428 */     cell = sheet.getWritableCell(0, 158);
/* 429 */     wcf = cell.getWritableCellFeatures();
/* 430 */     wcf.removeComment();
/*     */     
/*     */ 
/* 433 */     cell = sheet.getWritableCell(0, 172);
/* 434 */     wcf = cell.getWritableCellFeatures();
/* 435 */     Range r = wcf.getSharedDataValidationRange();
/* 436 */     Cell botright = r.getBottomRight();
/* 437 */     sheet.removeSharedDataValidation(cell);
/* 438 */     al = new ArrayList();
/* 439 */     al.add("Stanley Featherstonehaugh Ukridge");
/* 440 */     al.add("Major Plank");
/* 441 */     al.add("Earl of Ickenham");
/* 442 */     al.add("Sir Gregory Parsloe-Parsloe");
/* 443 */     al.add("Honoria Glossop");
/* 444 */     al.add("Stiffy Byng");
/* 445 */     al.add("Bingo Little");
/* 446 */     wcf.setDataValidationList(al);
/* 447 */     cell.setCellFeatures(wcf);
/* 448 */     sheet.applySharedDataValidation(cell, botright.getColumn() - cell.getColumn(), 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\ReadWrite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */