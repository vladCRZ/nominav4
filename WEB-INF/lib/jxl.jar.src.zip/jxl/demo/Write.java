/*      */ package jxl.demo;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import jxl.CellReferenceHelper;
/*      */ import jxl.CellView;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.HeaderFooter.Contents;
/*      */ import jxl.Range;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.Workbook;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.format.Alignment;
/*      */ import jxl.format.Border;
/*      */ import jxl.format.BorderLineStyle;
/*      */ import jxl.format.Colour;
/*      */ import jxl.format.Orientation;
/*      */ import jxl.format.PageOrder;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ import jxl.format.ScriptStyle;
/*      */ import jxl.format.UnderlineStyle;
/*      */ import jxl.write.Blank;
/*      */ import jxl.write.Boolean;
/*      */ import jxl.write.DateFormat;
/*      */ import jxl.write.DateFormats;
/*      */ import jxl.write.DateTime;
/*      */ import jxl.write.Formula;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.Number;
/*      */ import jxl.write.NumberFormat;
/*      */ import jxl.write.NumberFormats;
/*      */ import jxl.write.WritableCellFeatures;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableFont;
/*      */ import jxl.write.WritableFont.FontName;
/*      */ import jxl.write.WritableHyperlink;
/*      */ import jxl.write.WritableImage;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ import jxl.write.WriteException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Write
/*      */ {
/*      */   private String filename;
/*      */   private WritableWorkbook workbook;
/*      */   
/*      */   public Write(String fn)
/*      */   {
/*   93 */     this.filename = fn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write()
/*      */     throws IOException, WriteException
/*      */   {
/*  104 */     WorkbookSettings ws = new WorkbookSettings();
/*  105 */     ws.setLocale(new Locale("en", "EN"));
/*  106 */     this.workbook = Workbook.createWorkbook(new File(this.filename), ws);
/*      */     
/*      */ 
/*  109 */     WritableSheet s2 = this.workbook.createSheet("Number Formats", 0);
/*  110 */     WritableSheet s3 = this.workbook.createSheet("Date Formats", 1);
/*  111 */     WritableSheet s1 = this.workbook.createSheet("Label Formats", 2);
/*  112 */     WritableSheet s4 = this.workbook.createSheet("Borders", 3);
/*  113 */     WritableSheet s5 = this.workbook.createSheet("Labels", 4);
/*  114 */     WritableSheet s6 = this.workbook.createSheet("Formulas", 5);
/*  115 */     WritableSheet s7 = this.workbook.createSheet("Images", 6);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  120 */     this.workbook.setColourRGB(Colour.LIME, 255, 0, 0);
/*      */     
/*      */ 
/*  123 */     this.workbook.addNameArea("namedrange", s4, 1, 11, 5, 14);
/*  124 */     this.workbook.addNameArea("validation_range", s1, 4, 65, 9, 65);
/*  125 */     this.workbook.addNameArea("formulavalue", s6, 1, 45, 1, 45);
/*      */     
/*      */ 
/*  128 */     s5.getSettings().setPrintArea(4, 4, 15, 35);
/*      */     
/*  130 */     writeLabelFormatSheet(s1);
/*  131 */     writeNumberFormatSheet(s2);
/*  132 */     writeDateFormatSheet(s3);
/*  133 */     writeBordersSheet(s4);
/*  134 */     writeLabelsSheet(s5);
/*  135 */     writeFormulaSheet(s6);
/*  136 */     writeImageSheet(s7);
/*      */     
/*  138 */     this.workbook.write();
/*  139 */     this.workbook.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeNumberFormatSheet(WritableSheet s)
/*      */     throws WriteException
/*      */   {
/*  149 */     WritableCellFormat wrappedText = new WritableCellFormat(WritableWorkbook.ARIAL_10_PT);
/*      */     
/*  151 */     wrappedText.setWrap(true);
/*      */     
/*  153 */     s.setColumnView(0, 20);
/*  154 */     s.setColumnView(4, 20);
/*  155 */     s.setColumnView(5, 20);
/*  156 */     s.setColumnView(6, 20);
/*      */     
/*      */ 
/*  159 */     Label l = new Label(0, 0, "+/- Pi - default format", wrappedText);
/*  160 */     s.addCell(l);
/*      */     
/*  162 */     Number n = new Number(1, 0, 3.1415926535D);
/*  163 */     s.addCell(n);
/*      */     
/*  165 */     n = new Number(2, 0, -3.1415926535D);
/*  166 */     s.addCell(n);
/*      */     
/*  168 */     l = new Label(0, 1, "+/- Pi - integer format", wrappedText);
/*  169 */     s.addCell(l);
/*      */     
/*  171 */     WritableCellFormat cf1 = new WritableCellFormat(NumberFormats.INTEGER);
/*  172 */     n = new Number(1, 1, 3.1415926535D, cf1);
/*  173 */     s.addCell(n);
/*      */     
/*  175 */     n = new Number(2, 1, -3.1415926535D, cf1);
/*  176 */     s.addCell(n);
/*      */     
/*  178 */     l = new Label(0, 2, "+/- Pi - float 2dps", wrappedText);
/*  179 */     s.addCell(l);
/*      */     
/*  181 */     WritableCellFormat cf2 = new WritableCellFormat(NumberFormats.FLOAT);
/*  182 */     n = new Number(1, 2, 3.1415926535D, cf2);
/*  183 */     s.addCell(n);
/*      */     
/*  185 */     n = new Number(2, 2, -3.1415926535D, cf2);
/*  186 */     s.addCell(n);
/*      */     
/*  188 */     l = new Label(0, 3, "+/- Pi - custom 3dps", wrappedText);
/*      */     
/*  190 */     s.addCell(l);
/*      */     
/*  192 */     NumberFormat dp3 = new NumberFormat("#.###");
/*  193 */     WritableCellFormat dp3cell = new WritableCellFormat(dp3);
/*  194 */     n = new Number(1, 3, 3.1415926535D, dp3cell);
/*  195 */     s.addCell(n);
/*      */     
/*  197 */     n = new Number(2, 3, -3.1415926535D, dp3cell);
/*  198 */     s.addCell(n);
/*      */     
/*  200 */     l = new Label(0, 4, "+/- Pi - custom &3.14", wrappedText);
/*      */     
/*  202 */     s.addCell(l);
/*      */     
/*  204 */     NumberFormat pounddp2 = new NumberFormat("&#.00");
/*  205 */     WritableCellFormat pounddp2cell = new WritableCellFormat(pounddp2);
/*  206 */     n = new Number(1, 4, 3.1415926535D, pounddp2cell);
/*  207 */     s.addCell(n);
/*      */     
/*  209 */     n = new Number(2, 4, -3.1415926535D, pounddp2cell);
/*  210 */     s.addCell(n);
/*      */     
/*  212 */     l = new Label(0, 5, "+/- Pi - custom Text #.### Text", wrappedText);
/*      */     
/*  214 */     s.addCell(l);
/*      */     
/*  216 */     NumberFormat textdp4 = new NumberFormat("Text#.####Text");
/*  217 */     WritableCellFormat textdp4cell = new WritableCellFormat(textdp4);
/*  218 */     n = new Number(1, 5, 3.1415926535D, textdp4cell);
/*  219 */     s.addCell(n);
/*      */     
/*  221 */     n = new Number(2, 5, -3.1415926535D, textdp4cell);
/*  222 */     s.addCell(n);
/*      */     
/*      */ 
/*  225 */     l = new Label(4, 0, "+/- Bilko default format");
/*  226 */     s.addCell(l);
/*  227 */     n = new Number(5, 0, 1.5042699E7D);
/*  228 */     s.addCell(n);
/*  229 */     n = new Number(6, 0, -1.5042699E7D);
/*  230 */     s.addCell(n);
/*      */     
/*  232 */     l = new Label(4, 1, "+/- Bilko float format");
/*  233 */     s.addCell(l);
/*  234 */     WritableCellFormat cfi1 = new WritableCellFormat(NumberFormats.FLOAT);
/*  235 */     n = new Number(5, 1, 1.5042699E7D, cfi1);
/*  236 */     s.addCell(n);
/*  237 */     n = new Number(6, 1, -1.5042699E7D, cfi1);
/*  238 */     s.addCell(n);
/*      */     
/*  240 */     l = new Label(4, 2, "+/- Thousands separator");
/*  241 */     s.addCell(l);
/*  242 */     WritableCellFormat cfi2 = new WritableCellFormat(NumberFormats.THOUSANDS_INTEGER);
/*      */     
/*  244 */     n = new Number(5, 2, 1.5042699E7D, cfi2);
/*  245 */     s.addCell(n);
/*  246 */     n = new Number(6, 2, -1.5042699E7D, cfi2);
/*  247 */     s.addCell(n);
/*      */     
/*  249 */     l = new Label(4, 3, "+/- Accounting red - added 0.01");
/*  250 */     s.addCell(l);
/*  251 */     WritableCellFormat cfi3 = new WritableCellFormat(NumberFormats.ACCOUNTING_RED_FLOAT);
/*      */     
/*  253 */     n = new Number(5, 3, 1.504269901E7D, cfi3);
/*  254 */     s.addCell(n);
/*  255 */     n = new Number(6, 3, -1.504269901E7D, cfi3);
/*  256 */     s.addCell(n);
/*      */     
/*  258 */     l = new Label(4, 4, "+/- Percent");
/*  259 */     s.addCell(l);
/*  260 */     WritableCellFormat cfi4 = new WritableCellFormat(NumberFormats.PERCENT_INTEGER);
/*      */     
/*  262 */     n = new Number(5, 4, 1.5042699E7D, cfi4);
/*  263 */     s.addCell(n);
/*  264 */     n = new Number(6, 4, -1.5042699E7D, cfi4);
/*  265 */     s.addCell(n);
/*      */     
/*  267 */     l = new Label(4, 5, "+/- Exponential - 2dps");
/*  268 */     s.addCell(l);
/*  269 */     WritableCellFormat cfi5 = new WritableCellFormat(NumberFormats.EXPONENTIAL);
/*      */     
/*  271 */     n = new Number(5, 5, 1.5042699E7D, cfi5);
/*  272 */     s.addCell(n);
/*  273 */     n = new Number(6, 5, -1.5042699E7D, cfi5);
/*  274 */     s.addCell(n);
/*      */     
/*  276 */     l = new Label(4, 6, "+/- Custom exponentional - 3dps", wrappedText);
/*  277 */     s.addCell(l);
/*  278 */     NumberFormat edp3 = new NumberFormat("0.000E0");
/*  279 */     WritableCellFormat edp3Cell = new WritableCellFormat(edp3);
/*  280 */     n = new Number(5, 6, 1.5042699E7D, edp3Cell);
/*  281 */     s.addCell(n);
/*  282 */     n = new Number(6, 6, -1.5042699E7D, edp3Cell);
/*  283 */     s.addCell(n);
/*      */     
/*  285 */     l = new Label(4, 7, "Custom neg brackets", wrappedText);
/*  286 */     s.addCell(l);
/*  287 */     NumberFormat negbracks = new NumberFormat("#,##0;(#,##0)");
/*  288 */     WritableCellFormat negbrackscell = new WritableCellFormat(negbracks);
/*  289 */     n = new Number(5, 7, 1.5042699E7D, negbrackscell);
/*  290 */     s.addCell(n);
/*  291 */     n = new Number(6, 7, -1.5042699E7D, negbrackscell);
/*  292 */     s.addCell(n);
/*      */     
/*  294 */     l = new Label(4, 8, "Custom neg brackets 2", wrappedText);
/*  295 */     s.addCell(l);
/*  296 */     NumberFormat negbracks2 = new NumberFormat("#,##0;(#,##0)a");
/*  297 */     WritableCellFormat negbrackscell2 = new WritableCellFormat(negbracks2);
/*  298 */     n = new Number(5, 8, 1.5042699E7D, negbrackscell2);
/*  299 */     s.addCell(n);
/*  300 */     n = new Number(6, 8, -1.5042699E7D, negbrackscell2);
/*  301 */     s.addCell(n);
/*      */     
/*  303 */     l = new Label(4, 9, "Custom percent", wrappedText);
/*  304 */     s.addCell(l);
/*  305 */     NumberFormat cuspercent = new NumberFormat("0.0%");
/*  306 */     WritableCellFormat cuspercentf = new WritableCellFormat(cuspercent);
/*  307 */     n = new Number(5, 9, 3.14159265D, cuspercentf);
/*  308 */     s.addCell(n);
/*      */     
/*      */ 
/*      */ 
/*  312 */     l = new Label(0, 10, "Boolean - TRUE");
/*  313 */     s.addCell(l);
/*  314 */     Boolean b = new Boolean(1, 10, true);
/*  315 */     s.addCell(b);
/*      */     
/*  317 */     l = new Label(0, 11, "Boolean - FALSE");
/*  318 */     s.addCell(l);
/*  319 */     b = new Boolean(1, 11, false);
/*  320 */     s.addCell(b);
/*      */     
/*  322 */     l = new Label(0, 12, "A hidden cell->");
/*  323 */     s.addCell(l);
/*  324 */     n = new Number(1, 12, 17.0D, WritableWorkbook.HIDDEN_STYLE);
/*  325 */     s.addCell(n);
/*      */     
/*      */ 
/*  328 */     l = new Label(4, 19, "Currency formats");
/*  329 */     s.addCell(l);
/*      */     
/*  331 */     l = new Label(4, 21, "UK Pound");
/*  332 */     s.addCell(l);
/*  333 */     NumberFormat poundCurrency = new NumberFormat("� #,###.00", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  336 */     WritableCellFormat poundFormat = new WritableCellFormat(poundCurrency);
/*  337 */     n = new Number(5, 21, 12345.0D, poundFormat);
/*  338 */     s.addCell(n);
/*      */     
/*  340 */     l = new Label(4, 22, "Euro 1");
/*  341 */     s.addCell(l);
/*  342 */     NumberFormat euroPrefixCurrency = new NumberFormat("[$�-2] #,###.00", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  345 */     WritableCellFormat euroPrefixFormat = new WritableCellFormat(euroPrefixCurrency);
/*      */     
/*  347 */     n = new Number(5, 22, 12345.0D, euroPrefixFormat);
/*  348 */     s.addCell(n);
/*      */     
/*  350 */     l = new Label(4, 23, "Euro 2");
/*  351 */     s.addCell(l);
/*  352 */     NumberFormat euroSuffixCurrency = new NumberFormat("#,###.00[$�-1]", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  355 */     WritableCellFormat euroSuffixFormat = new WritableCellFormat(euroSuffixCurrency);
/*      */     
/*  357 */     n = new Number(5, 23, 12345.0D, euroSuffixFormat);
/*  358 */     s.addCell(n);
/*      */     
/*  360 */     l = new Label(4, 24, "Dollar");
/*  361 */     s.addCell(l);
/*  362 */     NumberFormat dollarCurrency = new NumberFormat("[$$-409] #,###.00", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  365 */     WritableCellFormat dollarFormat = new WritableCellFormat(dollarCurrency);
/*      */     
/*  367 */     n = new Number(5, 24, 12345.0D, dollarFormat);
/*  368 */     s.addCell(n);
/*      */     
/*  370 */     l = new Label(4, 25, "Japanese Yen");
/*  371 */     s.addCell(l);
/*  372 */     NumberFormat japaneseYenCurrency = new NumberFormat("[$�-411] #,###.00", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  375 */     WritableCellFormat japaneseYenFormat = new WritableCellFormat(japaneseYenCurrency);
/*      */     
/*  377 */     n = new Number(5, 25, 12345.0D, japaneseYenFormat);
/*  378 */     s.addCell(n);
/*      */     
/*  380 */     l = new Label(4, 30, "Fraction formats");
/*  381 */     s.addCell(l);
/*      */     
/*  383 */     l = new Label(4, 32, "One digit fraction format", wrappedText);
/*  384 */     s.addCell(l);
/*      */     
/*  386 */     WritableCellFormat fraction1digitformat = new WritableCellFormat(NumberFormats.FRACTION_ONE_DIGIT);
/*      */     
/*  388 */     n = new Number(5, 32, 3.18279D, fraction1digitformat);
/*  389 */     s.addCell(n);
/*      */     
/*  391 */     l = new Label(4, 33, "Two digit fraction format", wrappedText);
/*  392 */     s.addCell(l);
/*      */     
/*  394 */     WritableCellFormat fraction2digitformat = new WritableCellFormat(NumberFormats.FRACTION_TWO_DIGITS);
/*      */     
/*  396 */     n = new Number(5, 33, 3.18279D, fraction2digitformat);
/*  397 */     s.addCell(n);
/*      */     
/*  399 */     l = new Label(4, 34, "Three digit fraction format (improper)", wrappedText);
/*  400 */     s.addCell(l);
/*      */     
/*  402 */     NumberFormat fraction3digit1 = new NumberFormat("???/???", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  405 */     WritableCellFormat fraction3digitformat1 = new WritableCellFormat(fraction3digit1);
/*      */     
/*  407 */     n = new Number(5, 34, 3.18927D, fraction3digitformat1);
/*  408 */     s.addCell(n);
/*      */     
/*  410 */     l = new Label(4, 35, "Three digit fraction format (proper)", wrappedText);
/*  411 */     s.addCell(l);
/*      */     
/*  413 */     NumberFormat fraction3digit2 = new NumberFormat("# ???/???", NumberFormat.COMPLEX_FORMAT);
/*      */     
/*      */ 
/*  416 */     WritableCellFormat fraction3digitformat2 = new WritableCellFormat(fraction3digit2);
/*      */     
/*  418 */     n = new Number(5, 35, 3.18927D, fraction3digitformat2);
/*  419 */     s.addCell(n);
/*      */     
/*      */ 
/*  422 */     for (int row = 0; row < 100; row++)
/*      */     {
/*  424 */       for (int col = 8; col < 108; col++)
/*      */       {
/*  426 */         n = new Number(col, row, col + row);
/*  427 */         s.addCell(n);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  432 */     for (int row = 101; row < 3000; row++)
/*      */     {
/*  434 */       for (int col = 0; col < 25; col++)
/*      */       {
/*  436 */         n = new Number(col, row, col + row);
/*  437 */         s.addCell(n);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeDateFormatSheet(WritableSheet s)
/*      */     throws WriteException
/*      */   {
/*  449 */     WritableCellFormat wrappedText = new WritableCellFormat(WritableWorkbook.ARIAL_10_PT);
/*      */     
/*  451 */     wrappedText.setWrap(true);
/*      */     
/*  453 */     s.setColumnView(0, 20);
/*  454 */     s.setColumnView(2, 20);
/*  455 */     s.setColumnView(3, 20);
/*  456 */     s.setColumnView(4, 20);
/*      */     
/*  458 */     s.getSettings().setFitWidth(2);
/*  459 */     s.getSettings().setFitHeight(2);
/*      */     
/*  461 */     Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*  462 */     c.set(1975, 4, 31, 15, 21, 45);
/*  463 */     c.set(14, 660);
/*  464 */     Date date = c.getTime();
/*  465 */     c.set(1900, 0, 1, 0, 0, 0);
/*  466 */     c.set(14, 0);
/*      */     
/*  468 */     Date date2 = c.getTime();
/*  469 */     c.set(1970, 0, 1, 0, 0, 0);
/*  470 */     Date date3 = c.getTime();
/*  471 */     c.set(1918, 10, 11, 11, 0, 0);
/*  472 */     Date date4 = c.getTime();
/*  473 */     c.set(1900, 0, 2, 0, 0, 0);
/*  474 */     Date date5 = c.getTime();
/*  475 */     c.set(1901, 0, 1, 0, 0, 0);
/*  476 */     Date date6 = c.getTime();
/*  477 */     c.set(1900, 4, 31, 0, 0, 0);
/*  478 */     Date date7 = c.getTime();
/*  479 */     c.set(1900, 1, 1, 0, 0, 0);
/*  480 */     Date date8 = c.getTime();
/*  481 */     c.set(1900, 0, 31, 0, 0, 0);
/*  482 */     Date date9 = c.getTime();
/*  483 */     c.set(1900, 2, 1, 0, 0, 0);
/*  484 */     Date date10 = c.getTime();
/*  485 */     c.set(1900, 1, 27, 0, 0, 0);
/*  486 */     Date date11 = c.getTime();
/*  487 */     c.set(1900, 1, 28, 0, 0, 0);
/*  488 */     Date date12 = c.getTime();
/*  489 */     c.set(1980, 5, 31, 12, 0, 0);
/*  490 */     Date date13 = c.getTime();
/*  491 */     c.set(1066, 9, 14, 0, 0, 0);
/*  492 */     Date date14 = c.getTime();
/*      */     
/*      */ 
/*  495 */     SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm:ss.SSS");
/*  496 */     sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  497 */     Label l = new Label(0, 0, "All dates are " + sdf.format(date), wrappedText);
/*      */     
/*  499 */     s.addCell(l);
/*      */     
/*  501 */     l = new Label(0, 1, "Built in formats", wrappedText);
/*      */     
/*  503 */     s.addCell(l);
/*      */     
/*  505 */     l = new Label(2, 1, "Custom formats");
/*  506 */     s.addCell(l);
/*      */     
/*  508 */     WritableCellFormat cf1 = new WritableCellFormat(DateFormats.FORMAT1);
/*  509 */     DateTime dt = new DateTime(0, 2, date, cf1, DateTime.GMT);
/*  510 */     s.addCell(dt);
/*      */     
/*  512 */     cf1 = new WritableCellFormat(DateFormats.FORMAT2);
/*  513 */     dt = new DateTime(0, 3, date, cf1, DateTime.GMT);
/*  514 */     s.addCell(dt);
/*      */     
/*  516 */     cf1 = new WritableCellFormat(DateFormats.FORMAT3);
/*  517 */     dt = new DateTime(0, 4, date, cf1);
/*  518 */     s.addCell(dt);
/*      */     
/*  520 */     cf1 = new WritableCellFormat(DateFormats.FORMAT4);
/*  521 */     dt = new DateTime(0, 5, date, cf1);
/*  522 */     s.addCell(dt);
/*      */     
/*  524 */     cf1 = new WritableCellFormat(DateFormats.FORMAT5);
/*  525 */     dt = new DateTime(0, 6, date, cf1);
/*  526 */     s.addCell(dt);
/*      */     
/*  528 */     cf1 = new WritableCellFormat(DateFormats.FORMAT6);
/*  529 */     dt = new DateTime(0, 7, date, cf1);
/*  530 */     s.addCell(dt);
/*      */     
/*  532 */     cf1 = new WritableCellFormat(DateFormats.FORMAT7);
/*  533 */     dt = new DateTime(0, 8, date, cf1, DateTime.GMT);
/*  534 */     s.addCell(dt);
/*      */     
/*  536 */     cf1 = new WritableCellFormat(DateFormats.FORMAT8);
/*  537 */     dt = new DateTime(0, 9, date, cf1, DateTime.GMT);
/*  538 */     s.addCell(dt);
/*      */     
/*  540 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  541 */     dt = new DateTime(0, 10, date, cf1, DateTime.GMT);
/*  542 */     s.addCell(dt);
/*      */     
/*  544 */     cf1 = new WritableCellFormat(DateFormats.FORMAT10);
/*  545 */     dt = new DateTime(0, 11, date, cf1, DateTime.GMT);
/*  546 */     s.addCell(dt);
/*      */     
/*  548 */     cf1 = new WritableCellFormat(DateFormats.FORMAT11);
/*  549 */     dt = new DateTime(0, 12, date, cf1, DateTime.GMT);
/*  550 */     s.addCell(dt);
/*      */     
/*  552 */     cf1 = new WritableCellFormat(DateFormats.FORMAT12);
/*  553 */     dt = new DateTime(0, 13, date, cf1, DateTime.GMT);
/*  554 */     s.addCell(dt);
/*      */     
/*      */ 
/*  557 */     DateFormat df = new DateFormat("dd MM yyyy");
/*  558 */     cf1 = new WritableCellFormat(df);
/*  559 */     l = new Label(2, 2, "dd MM yyyy");
/*  560 */     s.addCell(l);
/*      */     
/*  562 */     dt = new DateTime(3, 2, date, cf1, DateTime.GMT);
/*  563 */     s.addCell(dt);
/*      */     
/*  565 */     df = new DateFormat("dd MMM yyyy");
/*  566 */     cf1 = new WritableCellFormat(df);
/*  567 */     l = new Label(2, 3, "dd MMM yyyy");
/*  568 */     s.addCell(l);
/*      */     
/*  570 */     dt = new DateTime(3, 3, date, cf1, DateTime.GMT);
/*  571 */     s.addCell(dt);
/*      */     
/*  573 */     df = new DateFormat("hh:mm");
/*  574 */     cf1 = new WritableCellFormat(df);
/*  575 */     l = new Label(2, 4, "hh:mm");
/*  576 */     s.addCell(l);
/*      */     
/*  578 */     dt = new DateTime(3, 4, date, cf1, DateTime.GMT);
/*  579 */     s.addCell(dt);
/*      */     
/*  581 */     df = new DateFormat("hh:mm:ss");
/*  582 */     cf1 = new WritableCellFormat(df);
/*  583 */     l = new Label(2, 5, "hh:mm:ss");
/*  584 */     s.addCell(l);
/*      */     
/*  586 */     dt = new DateTime(3, 5, date, cf1, DateTime.GMT);
/*  587 */     s.addCell(dt);
/*      */     
/*  589 */     df = new DateFormat("H:mm:ss a");
/*  590 */     cf1 = new WritableCellFormat(df);
/*  591 */     l = new Label(2, 5, "H:mm:ss a");
/*  592 */     s.addCell(l);
/*      */     
/*  594 */     dt = new DateTime(3, 5, date, cf1, DateTime.GMT);
/*  595 */     s.addCell(dt);
/*  596 */     dt = new DateTime(4, 5, date13, cf1, DateTime.GMT);
/*  597 */     s.addCell(dt);
/*      */     
/*  599 */     df = new DateFormat("mm:ss.SSS");
/*  600 */     cf1 = new WritableCellFormat(df);
/*  601 */     l = new Label(2, 6, "mm:ss.SSS");
/*  602 */     s.addCell(l);
/*      */     
/*  604 */     dt = new DateTime(3, 6, date, cf1, DateTime.GMT);
/*  605 */     s.addCell(dt);
/*      */     
/*  607 */     df = new DateFormat("hh:mm:ss a");
/*  608 */     cf1 = new WritableCellFormat(df);
/*  609 */     l = new Label(2, 7, "hh:mm:ss a");
/*  610 */     s.addCell(l);
/*      */     
/*  612 */     dt = new DateTime(4, 7, date13, cf1, DateTime.GMT);
/*  613 */     s.addCell(dt);
/*      */     
/*      */ 
/*      */ 
/*  617 */     l = new Label(0, 16, "Zero date " + sdf.format(date2), wrappedText);
/*      */     
/*  619 */     s.addCell(l);
/*      */     
/*  621 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  622 */     dt = new DateTime(0, 17, date2, cf1, DateTime.GMT);
/*  623 */     s.addCell(dt);
/*      */     
/*      */ 
/*  626 */     l = new Label(3, 16, "Zero date + 1 " + sdf.format(date5), wrappedText);
/*      */     
/*  628 */     s.addCell(l);
/*      */     
/*  630 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  631 */     dt = new DateTime(3, 17, date5, cf1, DateTime.GMT);
/*  632 */     s.addCell(dt);
/*      */     
/*      */ 
/*  635 */     l = new Label(3, 19, sdf.format(date6), wrappedText);
/*      */     
/*  637 */     s.addCell(l);
/*      */     
/*  639 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  640 */     dt = new DateTime(3, 20, date6, cf1, DateTime.GMT);
/*  641 */     s.addCell(dt);
/*      */     
/*      */ 
/*  644 */     l = new Label(3, 22, sdf.format(date7), wrappedText);
/*      */     
/*  646 */     s.addCell(l);
/*      */     
/*  648 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  649 */     dt = new DateTime(3, 23, date7, cf1, DateTime.GMT);
/*  650 */     s.addCell(dt);
/*      */     
/*      */ 
/*  653 */     l = new Label(3, 25, sdf.format(date8), wrappedText);
/*      */     
/*  655 */     s.addCell(l);
/*      */     
/*  657 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  658 */     dt = new DateTime(3, 26, date8, cf1, DateTime.GMT);
/*  659 */     s.addCell(dt);
/*      */     
/*      */ 
/*  662 */     l = new Label(3, 28, sdf.format(date9), wrappedText);
/*      */     
/*  664 */     s.addCell(l);
/*      */     
/*  666 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  667 */     dt = new DateTime(3, 29, date9, cf1, DateTime.GMT);
/*  668 */     s.addCell(dt);
/*      */     
/*      */ 
/*  671 */     l = new Label(3, 28, sdf.format(date9), wrappedText);
/*      */     
/*  673 */     s.addCell(l);
/*      */     
/*  675 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  676 */     dt = new DateTime(3, 29, date9, cf1, DateTime.GMT);
/*  677 */     s.addCell(dt);
/*      */     
/*      */ 
/*  680 */     l = new Label(3, 31, sdf.format(date10), wrappedText);
/*      */     
/*  682 */     s.addCell(l);
/*      */     
/*  684 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  685 */     dt = new DateTime(3, 32, date10, cf1, DateTime.GMT);
/*  686 */     s.addCell(dt);
/*      */     
/*      */ 
/*  689 */     l = new Label(3, 34, sdf.format(date11), wrappedText);
/*      */     
/*  691 */     s.addCell(l);
/*      */     
/*  693 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  694 */     dt = new DateTime(3, 35, date11, cf1, DateTime.GMT);
/*  695 */     s.addCell(dt);
/*      */     
/*      */ 
/*  698 */     l = new Label(3, 37, sdf.format(date12), wrappedText);
/*      */     
/*  700 */     s.addCell(l);
/*      */     
/*  702 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  703 */     dt = new DateTime(3, 38, date12, cf1, DateTime.GMT);
/*  704 */     s.addCell(dt);
/*      */     
/*      */ 
/*  707 */     l = new Label(0, 19, "Zero UTC date " + sdf.format(date3), wrappedText);
/*      */     
/*  709 */     s.addCell(l);
/*      */     
/*  711 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  712 */     dt = new DateTime(0, 20, date3, cf1, DateTime.GMT);
/*  713 */     s.addCell(dt);
/*      */     
/*      */ 
/*  716 */     l = new Label(0, 22, "Armistice date " + sdf.format(date4), wrappedText);
/*      */     
/*  718 */     s.addCell(l);
/*      */     
/*  720 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  721 */     dt = new DateTime(0, 23, date4, cf1, DateTime.GMT);
/*  722 */     s.addCell(dt);
/*      */     
/*      */ 
/*  725 */     l = new Label(0, 25, "Battle of Hastings " + sdf.format(date14), wrappedText);
/*      */     
/*  727 */     s.addCell(l);
/*      */     
/*  729 */     cf1 = new WritableCellFormat(DateFormats.FORMAT2);
/*  730 */     dt = new DateTime(0, 26, date14, cf1, DateTime.GMT);
/*  731 */     s.addCell(dt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeLabelFormatSheet(WritableSheet s1)
/*      */     throws WriteException
/*      */   {
/*  742 */     s1.setColumnView(0, 60);
/*      */     
/*  744 */     Label lr = new Label(0, 0, "Arial Fonts");
/*  745 */     s1.addCell(lr);
/*      */     
/*  747 */     lr = new Label(1, 0, "10pt");
/*  748 */     s1.addCell(lr);
/*      */     
/*  750 */     lr = new Label(2, 0, "Normal");
/*  751 */     s1.addCell(lr);
/*      */     
/*  753 */     lr = new Label(3, 0, "12pt");
/*  754 */     s1.addCell(lr);
/*      */     
/*  756 */     WritableFont arial12pt = new WritableFont(WritableFont.ARIAL, 12);
/*  757 */     WritableCellFormat arial12format = new WritableCellFormat(arial12pt);
/*  758 */     arial12format.setWrap(true);
/*  759 */     lr = new Label(4, 0, "Normal", arial12format);
/*  760 */     s1.addCell(lr);
/*      */     
/*  762 */     WritableFont arial10ptBold = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD);
/*      */     
/*  764 */     WritableCellFormat arial10BoldFormat = new WritableCellFormat(arial10ptBold);
/*      */     
/*  766 */     lr = new Label(2, 2, "BOLD", arial10BoldFormat);
/*  767 */     s1.addCell(lr);
/*      */     
/*  769 */     WritableFont arial12ptBold = new WritableFont(WritableFont.ARIAL, 12, WritableFont.BOLD);
/*      */     
/*  771 */     WritableCellFormat arial12BoldFormat = new WritableCellFormat(arial12ptBold);
/*      */     
/*  773 */     lr = new Label(4, 2, "BOLD", arial12BoldFormat);
/*  774 */     s1.addCell(lr);
/*      */     
/*  776 */     WritableFont arial10ptItalic = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, true);
/*      */     
/*  778 */     WritableCellFormat arial10ItalicFormat = new WritableCellFormat(arial10ptItalic);
/*      */     
/*  780 */     lr = new Label(2, 4, "Italic", arial10ItalicFormat);
/*  781 */     s1.addCell(lr);
/*      */     
/*  783 */     WritableFont arial12ptItalic = new WritableFont(WritableFont.ARIAL, 12, WritableFont.NO_BOLD, true);
/*      */     
/*  785 */     WritableCellFormat arial12ptItalicFormat = new WritableCellFormat(arial12ptItalic);
/*      */     
/*  787 */     lr = new Label(4, 4, "Italic", arial12ptItalicFormat);
/*  788 */     s1.addCell(lr);
/*      */     
/*  790 */     WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
/*  791 */     WritableCellFormat times10format = new WritableCellFormat(times10pt);
/*  792 */     lr = new Label(0, 7, "Times Fonts", times10format);
/*  793 */     s1.addCell(lr);
/*      */     
/*  795 */     lr = new Label(1, 7, "10pt", times10format);
/*  796 */     s1.addCell(lr);
/*      */     
/*  798 */     lr = new Label(2, 7, "Normal", times10format);
/*  799 */     s1.addCell(lr);
/*      */     
/*  801 */     lr = new Label(3, 7, "12pt", times10format);
/*  802 */     s1.addCell(lr);
/*      */     
/*  804 */     WritableFont times12pt = new WritableFont(WritableFont.TIMES, 12);
/*  805 */     WritableCellFormat times12format = new WritableCellFormat(times12pt);
/*  806 */     lr = new Label(4, 7, "Normal", times12format);
/*  807 */     s1.addCell(lr);
/*      */     
/*  809 */     WritableFont times10ptBold = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD);
/*      */     
/*  811 */     WritableCellFormat times10BoldFormat = new WritableCellFormat(times10ptBold);
/*      */     
/*  813 */     lr = new Label(2, 9, "BOLD", times10BoldFormat);
/*  814 */     s1.addCell(lr);
/*      */     
/*  816 */     WritableFont times12ptBold = new WritableFont(WritableFont.TIMES, 12, WritableFont.BOLD);
/*      */     
/*  818 */     WritableCellFormat times12BoldFormat = new WritableCellFormat(times12ptBold);
/*      */     
/*  820 */     lr = new Label(4, 9, "BOLD", times12BoldFormat);
/*  821 */     s1.addCell(lr);
/*      */     
/*      */ 
/*  824 */     s1.setColumnView(6, 22);
/*  825 */     s1.setColumnView(7, 22);
/*  826 */     s1.setColumnView(8, 22);
/*  827 */     s1.setColumnView(9, 22);
/*      */     
/*  829 */     lr = new Label(0, 11, "Underlining");
/*  830 */     s1.addCell(lr);
/*      */     
/*  832 */     WritableFont arial10ptUnderline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  838 */     WritableCellFormat arialUnderline = new WritableCellFormat(arial10ptUnderline);
/*      */     
/*  840 */     lr = new Label(6, 11, "Underline", arialUnderline);
/*  841 */     s1.addCell(lr);
/*      */     
/*  843 */     WritableFont arial10ptDoubleUnderline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.DOUBLE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  849 */     WritableCellFormat arialDoubleUnderline = new WritableCellFormat(arial10ptDoubleUnderline);
/*      */     
/*  851 */     lr = new Label(7, 11, "Double Underline", arialDoubleUnderline);
/*  852 */     s1.addCell(lr);
/*      */     
/*  854 */     WritableFont arial10ptSingleAcc = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE_ACCOUNTING);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  860 */     WritableCellFormat arialSingleAcc = new WritableCellFormat(arial10ptSingleAcc);
/*      */     
/*  862 */     lr = new Label(8, 11, "Single Accounting Underline", arialSingleAcc);
/*  863 */     s1.addCell(lr);
/*      */     
/*  865 */     WritableFont arial10ptDoubleAcc = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.DOUBLE_ACCOUNTING);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  871 */     WritableCellFormat arialDoubleAcc = new WritableCellFormat(arial10ptDoubleAcc);
/*      */     
/*  873 */     lr = new Label(9, 11, "Double Accounting Underline", arialDoubleAcc);
/*  874 */     s1.addCell(lr);
/*      */     
/*  876 */     WritableFont times14ptBoldUnderline = new WritableFont(WritableFont.TIMES, 14, WritableFont.BOLD, false, UnderlineStyle.SINGLE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  882 */     WritableCellFormat timesBoldUnderline = new WritableCellFormat(times14ptBoldUnderline);
/*      */     
/*  884 */     lr = new Label(6, 12, "Times 14 Bold Underline", timesBoldUnderline);
/*  885 */     s1.addCell(lr);
/*      */     
/*  887 */     WritableFont arial18ptBoldItalicUnderline = new WritableFont(WritableFont.ARIAL, 18, WritableFont.BOLD, true, UnderlineStyle.SINGLE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  893 */     WritableCellFormat arialBoldItalicUnderline = new WritableCellFormat(arial18ptBoldItalicUnderline);
/*      */     
/*  895 */     lr = new Label(6, 13, "Arial 18 Bold Italic Underline", arialBoldItalicUnderline);
/*      */     
/*  897 */     s1.addCell(lr);
/*      */     
/*  899 */     lr = new Label(0, 15, "Script styles");
/*  900 */     s1.addCell(lr);
/*      */     
/*  902 */     WritableFont superscript = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.SUPERSCRIPT);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  910 */     WritableCellFormat superscriptFormat = new WritableCellFormat(superscript);
/*      */     
/*  912 */     lr = new Label(1, 15, "superscript", superscriptFormat);
/*  913 */     s1.addCell(lr);
/*      */     
/*  915 */     WritableFont subscript = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.SUBSCRIPT);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  923 */     WritableCellFormat subscriptFormat = new WritableCellFormat(subscript);
/*      */     
/*  925 */     lr = new Label(2, 15, "subscript", subscriptFormat);
/*  926 */     s1.addCell(lr);
/*      */     
/*  928 */     lr = new Label(0, 17, "Colours");
/*  929 */     s1.addCell(lr);
/*      */     
/*  931 */     WritableFont red = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.RED);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  937 */     WritableCellFormat redFormat = new WritableCellFormat(red);
/*  938 */     lr = new Label(2, 17, "Red", redFormat);
/*  939 */     s1.addCell(lr);
/*      */     
/*  941 */     WritableFont blue = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  947 */     WritableCellFormat blueFormat = new WritableCellFormat(blue);
/*  948 */     lr = new Label(2, 18, "Blue", blueFormat);
/*  949 */     s1.addCell(lr);
/*      */     
/*  951 */     WritableFont lime = new WritableFont(WritableFont.ARIAL);
/*  952 */     lime.setColour(Colour.LIME);
/*  953 */     WritableCellFormat limeFormat = new WritableCellFormat(lime);
/*  954 */     limeFormat.setWrap(true);
/*  955 */     lr = new Label(4, 18, "Modified palette - was lime, now red", limeFormat);
/*  956 */     s1.addCell(lr);
/*      */     
/*  958 */     WritableCellFormat greyBackground = new WritableCellFormat();
/*  959 */     greyBackground.setWrap(true);
/*  960 */     greyBackground.setBackground(Colour.GRAY_50);
/*  961 */     lr = new Label(2, 19, "Grey background", greyBackground);
/*  962 */     s1.addCell(lr);
/*      */     
/*  964 */     WritableFont yellow = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.YELLOW);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  970 */     WritableCellFormat yellowOnBlue = new WritableCellFormat(yellow);
/*  971 */     yellowOnBlue.setWrap(true);
/*  972 */     yellowOnBlue.setBackground(Colour.BLUE);
/*  973 */     lr = new Label(2, 20, "Blue background, yellow foreground", yellowOnBlue);
/*  974 */     s1.addCell(lr);
/*      */     
/*  976 */     WritableCellFormat yellowOnBlack = new WritableCellFormat(yellow);
/*  977 */     yellowOnBlack.setWrap(true);
/*  978 */     yellowOnBlack.setBackground(Colour.PALETTE_BLACK);
/*  979 */     lr = new Label(3, 20, "Black background, yellow foreground", yellowOnBlack);
/*      */     
/*  981 */     s1.addCell(lr);
/*      */     
/*  983 */     lr = new Label(0, 22, "Null label");
/*  984 */     s1.addCell(lr);
/*      */     
/*  986 */     lr = new Label(2, 22, null);
/*  987 */     s1.addCell(lr);
/*      */     
/*  989 */     lr = new Label(0, 24, "A very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nA very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nA very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nA very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nAnd sat and drank coffee an talked for an hour\n", arial12format);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1022 */     s1.addCell(lr);
/*      */     
/* 1024 */     WritableCellFormat vertical = new WritableCellFormat();
/* 1025 */     vertical.setOrientation(Orientation.VERTICAL);
/* 1026 */     lr = new Label(0, 26, "Vertical orientation", vertical);
/* 1027 */     s1.addCell(lr);
/*      */     
/*      */ 
/* 1030 */     WritableCellFormat plus_90 = new WritableCellFormat();
/* 1031 */     plus_90.setOrientation(Orientation.PLUS_90);
/* 1032 */     lr = new Label(1, 26, "Plus 90", plus_90);
/* 1033 */     s1.addCell(lr);
/*      */     
/*      */ 
/* 1036 */     WritableCellFormat minus_90 = new WritableCellFormat();
/* 1037 */     minus_90.setOrientation(Orientation.MINUS_90);
/* 1038 */     lr = new Label(2, 26, "Minus 90", minus_90);
/* 1039 */     s1.addCell(lr);
/*      */     
/* 1041 */     lr = new Label(0, 28, "Modified row height");
/* 1042 */     s1.addCell(lr);
/* 1043 */     s1.setRowView(28, 480);
/*      */     
/* 1045 */     lr = new Label(0, 29, "Collapsed row");
/* 1046 */     s1.addCell(lr);
/* 1047 */     s1.setRowView(29, true);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1052 */       Label l = new Label(0, 30, "Hyperlink to home page");
/* 1053 */       s1.addCell(l);
/*      */       
/* 1055 */       URL url = new URL("http://www.andykhan.com/jexcelapi");
/* 1056 */       WritableHyperlink wh = new WritableHyperlink(0, 30, 8, 31, url);
/* 1057 */       s1.addHyperlink(wh);
/*      */       
/*      */ 
/* 1060 */       WritableHyperlink wh2 = new WritableHyperlink(7, 30, 9, 31, url);
/* 1061 */       s1.addHyperlink(wh2);
/*      */       
/* 1063 */       l = new Label(4, 2, "File hyperlink to documentation");
/* 1064 */       s1.addCell(l);
/*      */       
/* 1066 */       File file = new File("../jexcelapi/docs/index.html");
/* 1067 */       wh = new WritableHyperlink(0, 32, 8, 32, file, "JExcelApi Documentation");
/*      */       
/* 1069 */       s1.addHyperlink(wh);
/*      */       
/*      */ 
/* 1072 */       wh = new WritableHyperlink(0, 34, 8, 34, "Link to another cell", s1, 0, 180, 1, 181);
/*      */       
/*      */ 
/*      */ 
/* 1076 */       s1.addHyperlink(wh);
/*      */       
/* 1078 */       file = new File("\\\\localhost\\file.txt");
/* 1079 */       wh = new WritableHyperlink(0, 36, 8, 36, file);
/* 1080 */       s1.addHyperlink(wh);
/*      */       
/*      */ 
/* 1083 */       url = new URL("http://www.amazon.co.uk/exec/obidos/ASIN/0571058086/qid=1099836249/sr=1-3/ref=sr_1_11_3/202-6017285-1620664");
/*      */       
/* 1085 */       wh = new WritableHyperlink(0, 38, 0, 38, url);
/* 1086 */       s1.addHyperlink(wh);
/*      */     }
/*      */     catch (MalformedURLException e)
/*      */     {
/* 1090 */       System.err.println(e.toString());
/*      */     }
/*      */     
/*      */ 
/* 1094 */     Label l = new Label(5, 35, "Merged cells", timesBoldUnderline);
/* 1095 */     s1.mergeCells(5, 35, 8, 37);
/* 1096 */     s1.addCell(l);
/*      */     
/* 1098 */     l = new Label(5, 38, "More merged cells");
/* 1099 */     s1.addCell(l);
/* 1100 */     Range r = s1.mergeCells(5, 38, 8, 41);
/* 1101 */     s1.insertRow(40);
/* 1102 */     s1.removeRow(39);
/* 1103 */     s1.unmergeCells(r);
/*      */     
/*      */ 
/* 1106 */     WritableCellFormat wcf = new WritableCellFormat();
/* 1107 */     wcf.setAlignment(Alignment.CENTRE);
/* 1108 */     l = new Label(5, 42, "Centred across merged cells", wcf);
/* 1109 */     s1.addCell(l);
/* 1110 */     s1.mergeCells(5, 42, 10, 42);
/*      */     
/* 1112 */     wcf = new WritableCellFormat();
/* 1113 */     wcf.setBorder(Border.ALL, BorderLineStyle.THIN);
/* 1114 */     wcf.setBackground(Colour.GRAY_25);
/* 1115 */     l = new Label(3, 44, "Merged with border", wcf);
/* 1116 */     s1.addCell(l);
/* 1117 */     s1.mergeCells(3, 44, 4, 46);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1134 */     WritableFont courier10ptFont = new WritableFont(WritableFont.COURIER, 10);
/* 1135 */     WritableCellFormat courier10pt = new WritableCellFormat(courier10ptFont);
/* 1136 */     l = new Label(0, 49, "Courier fonts", courier10pt);
/* 1137 */     s1.addCell(l);
/*      */     
/* 1139 */     WritableFont tahoma12ptFont = new WritableFont(WritableFont.TAHOMA, 12);
/* 1140 */     WritableCellFormat tahoma12pt = new WritableCellFormat(tahoma12ptFont);
/* 1141 */     l = new Label(0, 50, "Tahoma fonts", tahoma12pt);
/* 1142 */     s1.addCell(l);
/*      */     
/* 1144 */     WritableFont.FontName wingdingsFont = WritableFont.createFont("Wingdings 2");
/*      */     
/* 1146 */     WritableFont wingdings210ptFont = new WritableFont(wingdingsFont, 10);
/* 1147 */     WritableCellFormat wingdings210pt = new WritableCellFormat(wingdings210ptFont);
/*      */     
/* 1149 */     l = new Label(0, 51, "Bespoke Windgdings 2", wingdings210pt);
/* 1150 */     s1.addCell(l);
/*      */     
/* 1152 */     WritableCellFormat shrinkToFit = new WritableCellFormat(times12pt);
/* 1153 */     shrinkToFit.setShrinkToFit(true);
/* 1154 */     l = new Label(3, 53, "Shrunk to fit", shrinkToFit);
/* 1155 */     s1.addCell(l);
/*      */     
/* 1157 */     l = new Label(3, 55, "Some long wrapped text in a merged cell", arial12format);
/*      */     
/* 1159 */     s1.addCell(l);
/* 1160 */     s1.mergeCells(3, 55, 4, 55);
/*      */     
/* 1162 */     l = new Label(0, 57, "A cell with a comment");
/* 1163 */     WritableCellFeatures cellFeatures = new WritableCellFeatures();
/* 1164 */     cellFeatures.setComment("the cell comment");
/* 1165 */     l.setCellFeatures(cellFeatures);
/* 1166 */     s1.addCell(l);
/*      */     
/* 1168 */     l = new Label(0, 59, "A cell with a long comment");
/*      */     
/* 1170 */     cellFeatures = new WritableCellFeatures();
/* 1171 */     cellFeatures.setComment("a very long cell comment indeed that won't fit inside a standard comment box, so a larger comment box is used instead", 5.0D, 6.0D);
/*      */     
/*      */ 
/*      */ 
/* 1175 */     l.setCellFeatures(cellFeatures);
/* 1176 */     s1.addCell(l);
/*      */     
/* 1178 */     WritableCellFormat indented = new WritableCellFormat(times12pt);
/* 1179 */     indented.setIndentation(4);
/* 1180 */     l = new Label(0, 61, "Some indented text", indented);
/* 1181 */     s1.addCell(l);
/*      */     
/* 1183 */     l = new Label(0, 63, "Data validation:  list");
/* 1184 */     s1.addCell(l);
/*      */     
/* 1186 */     Blank b = new Blank(1, 63);
/* 1187 */     cellFeatures = new WritableCellFeatures();
/* 1188 */     ArrayList al = new ArrayList();
/* 1189 */     al.add("bagpuss");
/* 1190 */     al.add("clangers");
/* 1191 */     al.add("ivor the engine");
/* 1192 */     al.add("noggin the nog");
/* 1193 */     cellFeatures.setDataValidationList(al);
/* 1194 */     b.setCellFeatures(cellFeatures);
/* 1195 */     s1.addCell(b);
/*      */     
/* 1197 */     l = new Label(0, 64, "Data validation:  number > 4.5");
/* 1198 */     s1.addCell(l);
/*      */     
/* 1200 */     b = new Blank(1, 64);
/* 1201 */     cellFeatures = new WritableCellFeatures();
/* 1202 */     cellFeatures.setNumberValidation(4.5D, WritableCellFeatures.GREATER_THAN);
/* 1203 */     b.setCellFeatures(cellFeatures);
/* 1204 */     s1.addCell(b);
/*      */     
/* 1206 */     l = new Label(0, 65, "Data validation:  named range");
/* 1207 */     s1.addCell(l);
/*      */     
/* 1209 */     l = new Label(4, 65, "tiger");
/* 1210 */     s1.addCell(l);
/* 1211 */     l = new Label(5, 65, "sword");
/* 1212 */     s1.addCell(l);
/* 1213 */     l = new Label(6, 65, "honour");
/* 1214 */     s1.addCell(l);
/* 1215 */     l = new Label(7, 65, "company");
/* 1216 */     s1.addCell(l);
/* 1217 */     l = new Label(8, 65, "victory");
/* 1218 */     s1.addCell(l);
/* 1219 */     l = new Label(9, 65, "fortress");
/* 1220 */     s1.addCell(l);
/*      */     
/* 1222 */     b = new Blank(1, 65);
/* 1223 */     cellFeatures = new WritableCellFeatures();
/* 1224 */     cellFeatures.setDataValidationRange("validation_range");
/* 1225 */     b.setCellFeatures(cellFeatures);
/* 1226 */     s1.addCell(b);
/*      */     
/*      */ 
/* 1229 */     s1.setRowGroup(39, 45, false);
/*      */     
/*      */ 
/* 1232 */     l = new Label(0, 66, "Block of cells B67-F71 with data validation");
/* 1233 */     s1.addCell(l);
/*      */     
/* 1235 */     al = new ArrayList();
/* 1236 */     al.add("Achilles");
/* 1237 */     al.add("Agamemnon");
/* 1238 */     al.add("Hector");
/* 1239 */     al.add("Odysseus");
/* 1240 */     al.add("Patroclus");
/* 1241 */     al.add("Nestor");
/*      */     
/* 1243 */     b = new Blank(1, 66);
/* 1244 */     cellFeatures = new WritableCellFeatures();
/* 1245 */     cellFeatures.setDataValidationList(al);
/* 1246 */     b.setCellFeatures(cellFeatures);
/* 1247 */     s1.addCell(b);
/* 1248 */     s1.applySharedDataValidation(b, 4, 4);
/*      */     
/* 1250 */     cellFeatures = new WritableCellFeatures();
/* 1251 */     cellFeatures.setDataValidationRange("");
/* 1252 */     l = new Label(0, 71, "Read only cell using empty data validation");
/* 1253 */     l.setCellFeatures(cellFeatures);
/* 1254 */     s1.addCell(l);
/*      */     
/*      */ 
/* 1257 */     s1.setRowGroup(39, 45, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeBordersSheet(WritableSheet s)
/*      */     throws WriteException
/*      */   {
/* 1269 */     s.getSettings().setProtected(true);
/*      */     
/* 1271 */     s.setColumnView(1, 15);
/* 1272 */     s.setColumnView(2, 15);
/* 1273 */     s.setColumnView(4, 15);
/* 1274 */     WritableCellFormat thickLeft = new WritableCellFormat();
/* 1275 */     thickLeft.setBorder(Border.LEFT, BorderLineStyle.THICK);
/* 1276 */     Label lr = new Label(1, 0, "Thick left", thickLeft);
/* 1277 */     s.addCell(lr);
/*      */     
/* 1279 */     WritableCellFormat dashedRight = new WritableCellFormat();
/* 1280 */     dashedRight.setBorder(Border.RIGHT, BorderLineStyle.DASHED);
/* 1281 */     lr = new Label(2, 0, "Dashed right", dashedRight);
/* 1282 */     s.addCell(lr);
/*      */     
/* 1284 */     WritableCellFormat doubleTop = new WritableCellFormat();
/* 1285 */     doubleTop.setBorder(Border.TOP, BorderLineStyle.DOUBLE);
/* 1286 */     lr = new Label(1, 2, "Double top", doubleTop);
/* 1287 */     s.addCell(lr);
/*      */     
/* 1289 */     WritableCellFormat hairBottom = new WritableCellFormat();
/* 1290 */     hairBottom.setBorder(Border.BOTTOM, BorderLineStyle.HAIR);
/* 1291 */     lr = new Label(2, 2, "Hair bottom", hairBottom);
/* 1292 */     s.addCell(lr);
/*      */     
/* 1294 */     WritableCellFormat allThin = new WritableCellFormat();
/* 1295 */     allThin.setBorder(Border.ALL, BorderLineStyle.THIN);
/* 1296 */     lr = new Label(4, 2, "All thin", allThin);
/* 1297 */     s.addCell(lr);
/*      */     
/* 1299 */     WritableCellFormat twoBorders = new WritableCellFormat();
/* 1300 */     twoBorders.setBorder(Border.TOP, BorderLineStyle.THICK);
/* 1301 */     twoBorders.setBorder(Border.LEFT, BorderLineStyle.THICK);
/* 1302 */     lr = new Label(6, 2, "Two borders", twoBorders);
/* 1303 */     s.addCell(lr);
/*      */     
/*      */ 
/* 1306 */     lr = new Label(20, 20, "Dislocated cell - after a page break");
/* 1307 */     s.addCell(lr);
/*      */     
/*      */ 
/* 1310 */     s.getSettings().setPaperSize(PaperSize.A3);
/* 1311 */     s.getSettings().setOrientation(PageOrientation.LANDSCAPE);
/* 1312 */     s.getSettings().setPageOrder(PageOrder.DOWN_THEN_RIGHT);
/* 1313 */     s.getSettings().setHeaderMargin(2.0D);
/* 1314 */     s.getSettings().setFooterMargin(2.0D);
/*      */     
/* 1316 */     s.getSettings().setTopMargin(3.0D);
/* 1317 */     s.getSettings().setBottomMargin(3.0D);
/*      */     
/*      */ 
/* 1320 */     HeaderFooter header = new HeaderFooter();
/* 1321 */     header.getCentre().append("Page Header");
/* 1322 */     s.getSettings().setHeader(header);
/*      */     
/* 1324 */     HeaderFooter footer = new HeaderFooter();
/* 1325 */     footer.getRight().append("page ");
/* 1326 */     footer.getRight().appendPageNumber();
/* 1327 */     s.getSettings().setFooter(footer);
/*      */     
/*      */ 
/* 1330 */     s.addRowPageBreak(18);
/* 1331 */     s.insertRow(17);
/* 1332 */     s.insertRow(17);
/* 1333 */     s.removeRow(17);
/*      */     
/*      */ 
/* 1336 */     s.addRowPageBreak(30);
/*      */     
/*      */ 
/* 1339 */     lr = new Label(10, 1, "Hidden column");
/* 1340 */     s.addCell(lr);
/*      */     
/* 1342 */     lr = new Label(3, 8, "Hidden row");
/* 1343 */     s.addCell(lr);
/* 1344 */     s.setRowView(8, true);
/*      */     
/* 1346 */     WritableCellFormat allThickRed = new WritableCellFormat();
/* 1347 */     allThickRed.setBorder(Border.ALL, BorderLineStyle.THICK, Colour.RED);
/* 1348 */     lr = new Label(1, 5, "All thick red", allThickRed);
/* 1349 */     s.addCell(lr);
/*      */     
/* 1351 */     WritableCellFormat topBottomBlue = new WritableCellFormat();
/* 1352 */     topBottomBlue.setBorder(Border.TOP, BorderLineStyle.THIN, Colour.BLUE);
/* 1353 */     topBottomBlue.setBorder(Border.BOTTOM, BorderLineStyle.THIN, Colour.BLUE);
/* 1354 */     lr = new Label(4, 5, "Top and bottom blue", topBottomBlue);
/* 1355 */     s.addCell(lr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void writeLabelsSheet(WritableSheet ws)
/*      */     throws WriteException
/*      */   {
/* 1363 */     ws.getSettings().setProtected(true);
/* 1364 */     ws.getSettings().setPassword("jxl");
/* 1365 */     ws.getSettings().setVerticalFreeze(5);
/* 1366 */     ws.getSettings().setDefaultRowHeight(500);
/*      */     
/* 1368 */     WritableFont wf = new WritableFont(WritableFont.ARIAL, 12);
/* 1369 */     wf.setItalic(true);
/*      */     
/* 1371 */     WritableCellFormat wcf = new WritableCellFormat(wf);
/*      */     
/* 1373 */     CellView cv = new CellView();
/* 1374 */     cv.setSize(6400);
/* 1375 */     cv.setFormat(wcf);
/* 1376 */     ws.setColumnView(0, cv);
/* 1377 */     ws.setColumnView(1, 15);
/*      */     
/* 1379 */     for (int i = 0; i < 61; i++)
/*      */     {
/* 1381 */       Label l1 = new Label(0, i, "Common Label");
/* 1382 */       Label l2 = new Label(1, i, "Distinct label number " + i);
/* 1383 */       ws.addCell(l1);
/* 1384 */       ws.addCell(l2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1390 */     Label l3 = new Label(0, 61, "Common Label", wcf);
/* 1391 */     Label l4 = new Label(1, 61, "1-1234567890", wcf);
/* 1392 */     Label l5 = new Label(2, 61, "2-1234567890", wcf);
/* 1393 */     ws.addCell(l3);
/* 1394 */     ws.addCell(l4);
/* 1395 */     ws.addCell(l5);
/*      */     
/* 1397 */     for (int i = 62; i < 200; i++)
/*      */     {
/* 1399 */       Label l1 = new Label(0, i, "Common Label");
/* 1400 */       Label l2 = new Label(1, i, "Distinct label number " + i);
/* 1401 */       ws.addCell(l1);
/* 1402 */       ws.addCell(l2);
/*      */     }
/*      */     
/*      */ 
/* 1406 */     wf = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD);
/* 1407 */     wf.setColour(Colour.RED);
/* 1408 */     WritableCellFormat wcf2 = new WritableCellFormat(wf);
/* 1409 */     wcf2.setWrap(true);
/* 1410 */     Label l = new Label(0, 205, "Different format", wcf2);
/* 1411 */     ws.addCell(l);
/*      */     
/*      */ 
/* 1414 */     Label l6 = new Label(5, 2, "A column for autosizing", wcf2);
/* 1415 */     ws.addCell(l6);
/* 1416 */     l6 = new Label(5, 4, "Another label, longer this time and in a different font");
/*      */     
/* 1418 */     ws.addCell(l6);
/*      */     
/* 1420 */     CellView cf = new CellView();
/* 1421 */     cf.setAutosize(true);
/* 1422 */     ws.setColumnView(5, cf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeFormulaSheet(WritableSheet ws)
/*      */     throws WriteException
/*      */   {
/* 1431 */     Number nc = new Number(0, 0, 15.0D);
/* 1432 */     ws.addCell(nc);
/*      */     
/* 1434 */     nc = new Number(0, 1, 16.0D);
/* 1435 */     ws.addCell(nc);
/*      */     
/* 1437 */     nc = new Number(0, 2, 10.0D);
/* 1438 */     ws.addCell(nc);
/*      */     
/* 1440 */     nc = new Number(0, 3, 12.0D);
/* 1441 */     ws.addCell(nc);
/*      */     
/* 1443 */     ws.setColumnView(2, 20);
/* 1444 */     WritableCellFormat wcf = new WritableCellFormat();
/* 1445 */     wcf.setAlignment(Alignment.RIGHT);
/* 1446 */     wcf.setWrap(true);
/* 1447 */     CellView cv = new CellView();
/* 1448 */     cv.setSize(6400);
/* 1449 */     cv.setFormat(wcf);
/* 1450 */     ws.setColumnView(3, cv);
/*      */     
/*      */ 
/* 1453 */     Formula f = null;
/* 1454 */     Label l = null;
/*      */     
/* 1456 */     f = new Formula(2, 0, "A1+A2");
/* 1457 */     ws.addCell(f);
/* 1458 */     l = new Label(3, 0, "a1+a2");
/* 1459 */     ws.addCell(l);
/*      */     
/* 1461 */     f = new Formula(2, 1, "A2 * 3");
/* 1462 */     ws.addCell(f);
/* 1463 */     l = new Label(3, 1, "A2 * 3");
/* 1464 */     ws.addCell(l);
/*      */     
/* 1466 */     f = new Formula(2, 2, "A2+A1/2.5");
/* 1467 */     ws.addCell(f);
/* 1468 */     l = new Label(3, 2, "A2+A1/2.5");
/* 1469 */     ws.addCell(l);
/*      */     
/* 1471 */     f = new Formula(2, 3, "3+(a1+a2)/2.5");
/* 1472 */     ws.addCell(f);
/* 1473 */     l = new Label(3, 3, "3+(a1+a2)/2.5");
/* 1474 */     ws.addCell(l);
/*      */     
/* 1476 */     f = new Formula(2, 4, "(a1+a2)/2.5");
/* 1477 */     ws.addCell(f);
/* 1478 */     l = new Label(3, 4, "(a1+a2)/2.5");
/* 1479 */     ws.addCell(l);
/*      */     
/* 1481 */     f = new Formula(2, 5, "15+((a1+a2)/2.5)*17");
/* 1482 */     ws.addCell(f);
/* 1483 */     l = new Label(3, 5, "15+((a1+a2)/2.5)*17");
/* 1484 */     ws.addCell(l);
/*      */     
/* 1486 */     f = new Formula(2, 6, "SUM(a1:a4)");
/* 1487 */     ws.addCell(f);
/* 1488 */     l = new Label(3, 6, "SUM(a1:a4)");
/* 1489 */     ws.addCell(l);
/*      */     
/* 1491 */     f = new Formula(2, 7, "SUM(a1:a4)/4");
/* 1492 */     ws.addCell(f);
/* 1493 */     l = new Label(3, 7, "SUM(a1:a4)/4");
/* 1494 */     ws.addCell(l);
/*      */     
/* 1496 */     f = new Formula(2, 8, "AVERAGE(A1:A4)");
/* 1497 */     ws.addCell(f);
/* 1498 */     l = new Label(3, 8, "AVERAGE(a1:a4)");
/* 1499 */     ws.addCell(l);
/*      */     
/* 1501 */     f = new Formula(2, 9, "MIN(5,4,1,2,3)");
/* 1502 */     ws.addCell(f);
/* 1503 */     l = new Label(3, 9, "MIN(5,4,1,2,3)");
/* 1504 */     ws.addCell(l);
/*      */     
/* 1506 */     f = new Formula(2, 10, "ROUND(3.14159265, 3)");
/* 1507 */     ws.addCell(f);
/* 1508 */     l = new Label(3, 10, "ROUND(3.14159265, 3)");
/* 1509 */     ws.addCell(l);
/*      */     
/* 1511 */     f = new Formula(2, 11, "MAX(SUM(A1:A2), A1*A2, POWER(A1, 2))");
/* 1512 */     ws.addCell(f);
/* 1513 */     l = new Label(3, 11, "MAX(SUM(A1:A2), A1*A2, POWER(A1, 2))");
/* 1514 */     ws.addCell(l);
/*      */     
/* 1516 */     f = new Formula(2, 12, "IF(A2>A1, \"A2 bigger\", \"A1 bigger\")");
/* 1517 */     ws.addCell(f);
/* 1518 */     l = new Label(3, 12, "IF(A2>A1, \"A2 bigger\", \"A1 bigger\")");
/* 1519 */     ws.addCell(l);
/*      */     
/* 1521 */     f = new Formula(2, 13, "IF(A2<=A1, \"A2 smaller\", \"A1 smaller\")");
/* 1522 */     ws.addCell(f);
/* 1523 */     l = new Label(3, 13, "IF(A2<=A1, \"A2 smaller\", \"A1 smaller\")");
/* 1524 */     ws.addCell(l);
/*      */     
/* 1526 */     f = new Formula(2, 14, "IF(A3<=10, \"<= 10\")");
/* 1527 */     ws.addCell(f);
/* 1528 */     l = new Label(3, 14, "IF(A3<=10, \"<= 10\")");
/* 1529 */     ws.addCell(l);
/*      */     
/* 1531 */     f = new Formula(2, 15, "SUM(1,2,3,4,5)");
/* 1532 */     ws.addCell(f);
/* 1533 */     l = new Label(3, 15, "SUM(1,2,3,4,5)");
/* 1534 */     ws.addCell(l);
/*      */     
/* 1536 */     f = new Formula(2, 16, "HYPERLINK(\"http://www.andykhan.com/jexcelapi\", \"JExcelApi Home Page\")");
/* 1537 */     ws.addCell(f);
/* 1538 */     l = new Label(3, 16, "HYPERLINK(\"http://www.andykhan.com/jexcelapi\", \"JExcelApi Home Page\")");
/* 1539 */     ws.addCell(l);
/*      */     
/* 1541 */     f = new Formula(2, 17, "3*4+5");
/* 1542 */     ws.addCell(f);
/* 1543 */     l = new Label(3, 17, "3*4+5");
/* 1544 */     ws.addCell(l);
/*      */     
/* 1546 */     f = new Formula(2, 18, "\"Plain text formula\"");
/* 1547 */     ws.addCell(f);
/* 1548 */     l = new Label(3, 18, "Plain text formula");
/* 1549 */     ws.addCell(l);
/*      */     
/* 1551 */     f = new Formula(2, 19, "SUM(a1,a2,-a3,a4)");
/* 1552 */     ws.addCell(f);
/* 1553 */     l = new Label(3, 19, "SUM(a1,a2,-a3,a4)");
/* 1554 */     ws.addCell(l);
/*      */     
/* 1556 */     f = new Formula(2, 20, "2*-(a1+a2)");
/* 1557 */     ws.addCell(f);
/* 1558 */     l = new Label(3, 20, "2*-(a1+a2)");
/* 1559 */     ws.addCell(l);
/*      */     
/* 1561 */     f = new Formula(2, 21, "'Number Formats'!B1/2");
/* 1562 */     ws.addCell(f);
/* 1563 */     l = new Label(3, 21, "'Number Formats'!B1/2");
/* 1564 */     ws.addCell(l);
/*      */     
/* 1566 */     f = new Formula(2, 22, "IF(F22=0, 0, F21/F22)");
/* 1567 */     ws.addCell(f);
/* 1568 */     l = new Label(3, 22, "IF(F22=0, 0, F21/F22)");
/* 1569 */     ws.addCell(l);
/*      */     
/* 1571 */     f = new Formula(2, 23, "RAND()");
/* 1572 */     ws.addCell(f);
/* 1573 */     l = new Label(3, 23, "RAND()");
/* 1574 */     ws.addCell(l);
/*      */     
/* 1576 */     StringBuffer buf = new StringBuffer();
/* 1577 */     buf.append("'");
/* 1578 */     buf.append(this.workbook.getSheet(0).getName());
/* 1579 */     buf.append("'!");
/* 1580 */     buf.append(CellReferenceHelper.getCellReference(9, 18));
/* 1581 */     buf.append("*25");
/* 1582 */     f = new Formula(2, 24, buf.toString());
/* 1583 */     ws.addCell(f);
/* 1584 */     l = new Label(3, 24, buf.toString());
/* 1585 */     ws.addCell(l);
/*      */     
/* 1587 */     wcf = new WritableCellFormat(DateFormats.DEFAULT);
/* 1588 */     f = new Formula(2, 25, "NOW()", wcf);
/* 1589 */     ws.addCell(f);
/* 1590 */     l = new Label(3, 25, "NOW()");
/* 1591 */     ws.addCell(l);
/*      */     
/* 1593 */     f = new Formula(2, 26, "$A$2+A3");
/* 1594 */     ws.addCell(f);
/* 1595 */     l = new Label(3, 26, "$A$2+A3");
/* 1596 */     ws.addCell(l);
/*      */     
/* 1598 */     f = new Formula(2, 27, "IF(COUNT(A1:A9,B1:B9)=0,\"\",COUNT(A1:A9,B1:B9))");
/* 1599 */     ws.addCell(f);
/* 1600 */     l = new Label(3, 27, "IF(COUNT(A1:A9,B1:B9)=0,\"\",COUNT(A1:A9,B1:B9))");
/* 1601 */     ws.addCell(l);
/*      */     
/* 1603 */     f = new Formula(2, 28, "SUM(A1,A2,A3,A4)");
/* 1604 */     ws.addCell(f);
/* 1605 */     l = new Label(3, 28, "SUM(A1,A2,A3,A4)");
/* 1606 */     ws.addCell(l);
/*      */     
/* 1608 */     l = new Label(1, 29, "a1");
/* 1609 */     ws.addCell(l);
/* 1610 */     f = new Formula(2, 29, "SUM(INDIRECT(ADDRESS(2,29)):A4)");
/* 1611 */     ws.addCell(f);
/* 1612 */     l = new Label(3, 29, "SUM(INDIRECT(ADDRESS(2,29):A4)");
/* 1613 */     ws.addCell(l);
/*      */     
/* 1615 */     f = new Formula(2, 30, "COUNTIF(A1:A4, \">=12\")");
/* 1616 */     ws.addCell(f);
/* 1617 */     l = new Label(3, 30, "COUNTIF(A1:A4, \">=12\")");
/* 1618 */     ws.addCell(l);
/*      */     
/* 1620 */     f = new Formula(2, 31, "MAX($A$1:$A$4)");
/* 1621 */     ws.addCell(f);
/* 1622 */     l = new Label(3, 31, "MAX($A$1:$A$4)");
/* 1623 */     ws.addCell(l);
/*      */     
/* 1625 */     f = new Formula(2, 32, "OR(A1,TRUE)");
/* 1626 */     ws.addCell(f);
/* 1627 */     l = new Label(3, 32, "OR(A1,TRUE)");
/* 1628 */     ws.addCell(l);
/*      */     
/* 1630 */     f = new Formula(2, 33, "ROWS(A1:C14)");
/* 1631 */     ws.addCell(f);
/* 1632 */     l = new Label(3, 33, "ROWS(A1:C14)");
/* 1633 */     ws.addCell(l);
/*      */     
/* 1635 */     f = new Formula(2, 34, "COUNTBLANK(A1:C14)");
/* 1636 */     ws.addCell(f);
/* 1637 */     l = new Label(3, 34, "COUNTBLANK(A1:C14)");
/* 1638 */     ws.addCell(l);
/*      */     
/* 1640 */     f = new Formula(2, 35, "IF(((F1=\"Not Found\")*(F2=\"Not Found\")*(F3=\"\")*(F4=\"\")*(F5=\"\")),1,0)");
/* 1641 */     ws.addCell(f);
/* 1642 */     l = new Label(3, 35, "IF(((F1=\"Not Found\")*(F2=\"Not Found\")*(F3=\"\")*(F4=\"\")*(F5=\"\")),1,0)");
/* 1643 */     ws.addCell(l);
/*      */     
/* 1645 */     f = new Formula(2, 36, "HYPERLINK(\"http://www.amazon.co.uk/exec/obidos/ASIN/0571058086qid=1099836249/sr=1-3/ref=sr_1_11_3/202-6017285-1620664\",  \"Long hyperlink\")");
/*      */     
/* 1647 */     ws.addCell(f);
/*      */     
/* 1649 */     f = new Formula(2, 37, "1234567+2699");
/* 1650 */     ws.addCell(f);
/* 1651 */     l = new Label(3, 37, "1234567+2699");
/* 1652 */     ws.addCell(l);
/*      */     
/* 1654 */     f = new Formula(2, 38, "IF(ISERROR(G25/G29),0,-1)");
/* 1655 */     ws.addCell(f);
/* 1656 */     l = new Label(3, 38, "IF(ISERROR(G25/G29),0,-1)");
/* 1657 */     ws.addCell(l);
/*      */     
/* 1659 */     f = new Formula(2, 39, "SEARCH(\"C\",D40)");
/* 1660 */     ws.addCell(f);
/* 1661 */     l = new Label(3, 39, "SEARCH(\"C\",D40)");
/* 1662 */     ws.addCell(l);
/*      */     
/* 1664 */     f = new Formula(2, 40, "#REF!");
/* 1665 */     ws.addCell(f);
/* 1666 */     l = new Label(3, 40, "#REF!");
/* 1667 */     ws.addCell(l);
/*      */     
/* 1669 */     nc = new Number(1, 41, 79.0D);
/* 1670 */     ws.addCell(nc);
/* 1671 */     f = new Formula(2, 41, "--B42");
/* 1672 */     ws.addCell(f);
/* 1673 */     l = new Label(3, 41, "--B42");
/* 1674 */     ws.addCell(l);
/*      */     
/* 1676 */     f = new Formula(2, 42, "CHOOSE(3,A1,A2,A3,A4");
/* 1677 */     ws.addCell(f);
/* 1678 */     l = new Label(3, 42, "CHOOSE(3,A1,A2,A3,A4");
/* 1679 */     ws.addCell(l);
/*      */     
/* 1681 */     f = new Formula(2, 43, "A4-A3-A2");
/* 1682 */     ws.addCell(f);
/* 1683 */     l = new Label(3, 43, "A4-A3-A2");
/* 1684 */     ws.addCell(l);
/*      */     
/* 1686 */     f = new Formula(2, 44, "F29+F34+F41+F48+F55+F62+F69+F76+F83+F90+F97+F104+F111+F118+F125+F132+F139+F146+F153+F160+F167+F174+F181+F188+F195+F202+F209+F216+F223+F230+F237+F244+F251+F258+F265+F272+F279+F286+F293+F300+F305+F308");
/* 1687 */     ws.addCell(f);
/* 1688 */     l = new Label(3, 44, "F29+F34+F41+F48+F55+F62+F69+F76+F83+F90+F97+F104+F111+F118+F125+F132+F139+F146+F153+F160+F167+F174+F181+F188+F195+F202+F209+F216+F223+F230+F237+F244+F251+F258+F265+F272+F279+F286+F293+F300+F305+F308");
/* 1689 */     ws.addCell(l);
/*      */     
/* 1691 */     nc = new Number(1, 45, 17.0D);
/* 1692 */     ws.addCell(nc);
/* 1693 */     f = new Formula(2, 45, "formulavalue+5");
/* 1694 */     ws.addCell(f);
/* 1695 */     l = new Label(3, 45, "formulavalue+5");
/* 1696 */     ws.addCell(l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeImageSheet(WritableSheet ws)
/*      */     throws WriteException
/*      */   {
/* 1722 */     Label l = new Label(0, 0, "Weald & Downland Open Air Museum, Sussex");
/* 1723 */     ws.addCell(l);
/*      */     
/* 1725 */     WritableImage wi = new WritableImage(0.0D, 3.0D, 5.0D, 7.0D, new File("resources/wealdanddownland.png"));
/*      */     
/* 1727 */     ws.addImage(wi);
/*      */     
/* 1729 */     l = new Label(0, 12, "Merchant Adventurers Hall, York");
/* 1730 */     ws.addCell(l);
/*      */     
/* 1732 */     wi = new WritableImage(5.0D, 12.0D, 4.0D, 10.0D, new File("resources/merchantadventurers.png"));
/*      */     
/* 1734 */     ws.addImage(wi);
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\Write.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */