/*    */ package jxl.demo;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import jxl.WorkbookSettings;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.read.biff.BiffException;
/*    */ import jxl.read.biff.BiffRecordReader;
/*    */ import jxl.read.biff.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WriteAccess
/*    */ {
/*    */   private BiffRecordReader reader;
/*    */   
/*    */   public WriteAccess(java.io.File file)
/*    */     throws IOException, BiffException
/*    */   {
/* 43 */     WorkbookSettings ws = new WorkbookSettings();
/* 44 */     FileInputStream fis = new FileInputStream(file);
/* 45 */     jxl.read.biff.File f = new jxl.read.biff.File(fis, ws);
/* 46 */     this.reader = new BiffRecordReader(f);
/*    */     
/* 48 */     display(ws);
/* 49 */     fis.close();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private void display(WorkbookSettings ws)
/*    */     throws IOException
/*    */   {
/* 57 */     Record r = null;
/* 58 */     boolean found = false;
/* 59 */     while ((this.reader.hasNext()) && (!found))
/*    */     {
/* 61 */       r = this.reader.next();
/* 62 */       if (r.getType() == Type.WRITEACCESS)
/*    */       {
/* 64 */         found = true;
/*    */       }
/*    */     }
/*    */     
/* 68 */     if (!found)
/*    */     {
/* 70 */       System.err.println("Warning:  could not find write access record");
/* 71 */       return;
/*    */     }
/*    */     
/* 74 */     byte[] data = r.getData();
/*    */     
/* 76 */     String s = null;
/*    */     
/* 78 */     s = StringHelper.getString(data, data.length, 0, ws);
/*    */     
/* 80 */     System.out.println(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\WriteAccess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */