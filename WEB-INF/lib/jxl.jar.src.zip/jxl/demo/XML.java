/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.format.Alignment;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Font;
/*     */ import jxl.format.Format;
/*     */ import jxl.format.Orientation;
/*     */ import jxl.format.Pattern;
/*     */ import jxl.format.ScriptStyle;
/*     */ import jxl.format.UnderlineStyle;
/*     */ import jxl.format.VerticalAlignment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XML
/*     */ {
/*     */   private OutputStream out;
/*     */   private String encoding;
/*     */   private Workbook workbook;
/*     */   
/*     */   public XML(Workbook w, OutputStream out, String enc, boolean f)
/*     */     throws IOException
/*     */   {
/*  75 */     this.encoding = enc;
/*  76 */     this.workbook = w;
/*  77 */     this.out = out;
/*     */     
/*  79 */     if ((this.encoding == null) || (!this.encoding.equals("UnicodeBig")))
/*     */     {
/*  81 */       this.encoding = "UTF8";
/*     */     }
/*     */     
/*  84 */     if (f)
/*     */     {
/*  86 */       writeFormattedXML();
/*     */     }
/*     */     else
/*     */     {
/*  90 */       writeXML();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeXML()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 102 */       OutputStreamWriter osw = new OutputStreamWriter(this.out, this.encoding);
/* 103 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/* 105 */       bw.write("<?xml version=\"1.0\" ?>");
/* 106 */       bw.newLine();
/* 107 */       bw.write("<!DOCTYPE workbook SYSTEM \"workbook.dtd\">");
/* 108 */       bw.newLine();
/* 109 */       bw.newLine();
/* 110 */       bw.write("<workbook>");
/* 111 */       bw.newLine();
/* 112 */       for (int sheet = 0; sheet < this.workbook.getNumberOfSheets(); sheet++)
/*     */       {
/* 114 */         Sheet s = this.workbook.getSheet(sheet);
/*     */         
/* 116 */         bw.write("  <sheet>");
/* 117 */         bw.newLine();
/* 118 */         bw.write("    <name><![CDATA[" + s.getName() + "]]></name>");
/* 119 */         bw.newLine();
/*     */         
/* 121 */         Cell[] row = null;
/*     */         
/* 123 */         for (int i = 0; i < s.getRows(); i++)
/*     */         {
/* 125 */           bw.write("    <row number=\"" + i + "\">");
/* 126 */           bw.newLine();
/* 127 */           row = s.getRow(i);
/*     */           
/* 129 */           for (int j = 0; j < row.length; j++)
/*     */           {
/* 131 */             if (row[j].getType() != CellType.EMPTY)
/*     */             {
/* 133 */               bw.write("      <col number=\"" + j + "\">");
/* 134 */               bw.write("<![CDATA[" + row[j].getContents() + "]]>");
/* 135 */               bw.write("</col>");
/* 136 */               bw.newLine();
/*     */             }
/*     */           }
/* 139 */           bw.write("    </row>");
/* 140 */           bw.newLine();
/*     */         }
/* 142 */         bw.write("  </sheet>");
/* 143 */         bw.newLine();
/*     */       }
/*     */       
/* 146 */       bw.write("</workbook>");
/* 147 */       bw.newLine();
/*     */       
/* 149 */       bw.flush();
/* 150 */       bw.close();
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 154 */       System.err.println(e.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void writeFormattedXML()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 165 */       OutputStreamWriter osw = new OutputStreamWriter(this.out, this.encoding);
/* 166 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/* 168 */       bw.write("<?xml version=\"1.0\" ?>");
/* 169 */       bw.newLine();
/* 170 */       bw.write("<!DOCTYPE workbook SYSTEM \"formatworkbook.dtd\">");
/* 171 */       bw.newLine();
/* 172 */       bw.newLine();
/* 173 */       bw.write("<workbook>");
/* 174 */       bw.newLine();
/* 175 */       for (int sheet = 0; sheet < this.workbook.getNumberOfSheets(); sheet++)
/*     */       {
/* 177 */         Sheet s = this.workbook.getSheet(sheet);
/*     */         
/* 179 */         bw.write("  <sheet>");
/* 180 */         bw.newLine();
/* 181 */         bw.write("    <name><![CDATA[" + s.getName() + "]]></name>");
/* 182 */         bw.newLine();
/*     */         
/* 184 */         Cell[] row = null;
/* 185 */         CellFormat format = null;
/* 186 */         Font font = null;
/*     */         
/* 188 */         for (int i = 0; i < s.getRows(); i++)
/*     */         {
/* 190 */           bw.write("    <row number=\"" + i + "\">");
/* 191 */           bw.newLine();
/* 192 */           row = s.getRow(i);
/*     */           
/* 194 */           for (int j = 0; j < row.length; j++)
/*     */           {
/*     */ 
/* 197 */             if ((row[j].getType() != CellType.EMPTY) || (row[j].getCellFormat() != null))
/*     */             {
/*     */ 
/* 200 */               format = row[j].getCellFormat();
/* 201 */               bw.write("      <col number=\"" + j + "\">");
/* 202 */               bw.newLine();
/* 203 */               bw.write("        <data>");
/* 204 */               bw.write("<![CDATA[" + row[j].getContents() + "]]>");
/* 205 */               bw.write("</data>");
/* 206 */               bw.newLine();
/*     */               
/* 208 */               if (row[j].getCellFormat() != null)
/*     */               {
/* 210 */                 bw.write("        <format wrap=\"" + format.getWrap() + "\"");
/* 211 */                 bw.newLine();
/* 212 */                 bw.write("                align=\"" + format.getAlignment().getDescription() + "\"");
/*     */                 
/* 214 */                 bw.newLine();
/* 215 */                 bw.write("                valign=\"" + format.getVerticalAlignment().getDescription() + "\"");
/*     */                 
/* 217 */                 bw.newLine();
/* 218 */                 bw.write("                orientation=\"" + format.getOrientation().getDescription() + "\"");
/*     */                 
/* 220 */                 bw.write(">");
/* 221 */                 bw.newLine();
/*     */                 
/*     */ 
/* 224 */                 font = format.getFont();
/* 225 */                 bw.write("          <font name=\"" + font.getName() + "\"");
/* 226 */                 bw.newLine();
/* 227 */                 bw.write("                point_size=\"" + font.getPointSize() + "\"");
/*     */                 
/* 229 */                 bw.newLine();
/* 230 */                 bw.write("                bold_weight=\"" + font.getBoldWeight() + "\"");
/*     */                 
/* 232 */                 bw.newLine();
/* 233 */                 bw.write("                italic=\"" + font.isItalic() + "\"");
/* 234 */                 bw.newLine();
/* 235 */                 bw.write("                underline=\"" + font.getUnderlineStyle().getDescription() + "\"");
/*     */                 
/* 237 */                 bw.newLine();
/* 238 */                 bw.write("                colour=\"" + font.getColour().getDescription() + "\"");
/*     */                 
/* 240 */                 bw.newLine();
/* 241 */                 bw.write("                script=\"" + font.getScriptStyle().getDescription() + "\"");
/*     */                 
/* 243 */                 bw.write(" />");
/* 244 */                 bw.newLine();
/*     */                 
/*     */ 
/*     */ 
/* 248 */                 if ((format.getBackgroundColour() != Colour.DEFAULT_BACKGROUND) || (format.getPattern() != Pattern.NONE))
/*     */                 {
/*     */ 
/* 251 */                   bw.write("          <background colour=\"" + format.getBackgroundColour().getDescription() + "\"");
/*     */                   
/* 253 */                   bw.newLine();
/* 254 */                   bw.write("                      pattern=\"" + format.getPattern().getDescription() + "\"");
/*     */                   
/* 256 */                   bw.write(" />");
/* 257 */                   bw.newLine();
/*     */                 }
/*     */                 
/*     */ 
/*     */ 
/* 262 */                 if ((format.getBorder(Border.TOP) != BorderLineStyle.NONE) || (format.getBorder(Border.BOTTOM) != BorderLineStyle.NONE) || (format.getBorder(Border.LEFT) != BorderLineStyle.NONE) || (format.getBorder(Border.RIGHT) != BorderLineStyle.NONE))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 268 */                   bw.write("          <border top=\"" + format.getBorder(Border.TOP).getDescription() + "\"");
/*     */                   
/* 270 */                   bw.newLine();
/* 271 */                   bw.write("                  bottom=\"" + format.getBorder(Border.BOTTOM).getDescription() + "\"");
/*     */                   
/*     */ 
/* 274 */                   bw.newLine();
/* 275 */                   bw.write("                  left=\"" + format.getBorder(Border.LEFT).getDescription() + "\"");
/*     */                   
/* 277 */                   bw.newLine();
/* 278 */                   bw.write("                  right=\"" + format.getBorder(Border.RIGHT).getDescription() + "\"");
/*     */                   
/* 280 */                   bw.write(" />");
/* 281 */                   bw.newLine();
/*     */                 }
/*     */                 
/*     */ 
/* 285 */                 if (!format.getFormat().getFormatString().equals(""))
/*     */                 {
/* 287 */                   bw.write("          <format_string string=\"");
/* 288 */                   bw.write(format.getFormat().getFormatString());
/* 289 */                   bw.write("\" />");
/* 290 */                   bw.newLine();
/*     */                 }
/*     */                 
/* 293 */                 bw.write("        </format>");
/* 294 */                 bw.newLine();
/*     */               }
/*     */               
/* 297 */               bw.write("      </col>");
/* 298 */               bw.newLine();
/*     */             }
/*     */           }
/* 301 */           bw.write("    </row>");
/* 302 */           bw.newLine();
/*     */         }
/* 304 */         bw.write("  </sheet>");
/* 305 */         bw.newLine();
/*     */       }
/*     */       
/* 308 */       bw.write("</workbook>");
/* 309 */       bw.newLine();
/*     */       
/* 311 */       bw.flush();
/* 312 */       bw.close();
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 316 */       System.err.println(e.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\demo\XML.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */