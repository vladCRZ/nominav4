/*    */ package jxl.format;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoldStyle
/*    */ {
/*    */   private int value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String string;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected BoldStyle(int val, String s)
/*    */   {
/* 44 */     this.value = val;
/* 45 */     this.string = s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 56 */     return this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDescription()
/*    */   {
/* 64 */     return this.string;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 70 */   public static final BoldStyle NORMAL = new BoldStyle(400, "Normal");
/*    */   
/*    */ 
/*    */ 
/* 74 */   public static final BoldStyle BOLD = new BoldStyle(700, "Bold");
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\format\BoldStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */