/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BorderLineStyle
/*     */ {
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String string;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private static BorderLineStyle[] styles = new BorderLineStyle[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BorderLineStyle(int val, String s)
/*     */   {
/*  48 */     this.value = val;
/*  49 */     this.string = s;
/*     */     
/*  51 */     BorderLineStyle[] oldstyles = styles;
/*  52 */     styles = new BorderLineStyle[oldstyles.length + 1];
/*  53 */     System.arraycopy(oldstyles, 0, styles, 0, oldstyles.length);
/*  54 */     styles[oldstyles.length] = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  64 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  72 */     return this.string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BorderLineStyle getStyle(int val)
/*     */   {
/*  83 */     for (int i = 0; i < styles.length; i++)
/*     */     {
/*  85 */       if (styles[i].getValue() == val)
/*     */       {
/*  87 */         return styles[i];
/*     */       }
/*     */     }
/*     */     
/*  91 */     return NONE;
/*     */   }
/*     */   
/*  94 */   public static final BorderLineStyle NONE = new BorderLineStyle(0, "none");
/*     */   
/*  96 */   public static final BorderLineStyle THIN = new BorderLineStyle(1, "thin");
/*     */   
/*  98 */   public static final BorderLineStyle MEDIUM = new BorderLineStyle(2, "medium");
/*     */   
/* 100 */   public static final BorderLineStyle DASHED = new BorderLineStyle(3, "dashed");
/*     */   
/* 102 */   public static final BorderLineStyle DOTTED = new BorderLineStyle(4, "dotted");
/*     */   
/* 104 */   public static final BorderLineStyle THICK = new BorderLineStyle(5, "thick");
/*     */   
/* 106 */   public static final BorderLineStyle DOUBLE = new BorderLineStyle(6, "double");
/*     */   
/* 108 */   public static final BorderLineStyle HAIR = new BorderLineStyle(7, "hair");
/*     */   
/* 110 */   public static final BorderLineStyle MEDIUM_DASHED = new BorderLineStyle(8, "medium dashed");
/*     */   
/* 112 */   public static final BorderLineStyle DASH_DOT = new BorderLineStyle(9, "dash dot");
/*     */   
/* 114 */   public static final BorderLineStyle MEDIUM_DASH_DOT = new BorderLineStyle(10, "medium dash dot");
/*     */   
/* 116 */   public static final BorderLineStyle DASH_DOT_DOT = new BorderLineStyle(11, "Dash dot dot");
/*     */   
/* 118 */   public static final BorderLineStyle MEDIUM_DASH_DOT_DOT = new BorderLineStyle(12, "Medium dash dot dot");
/*     */   
/* 120 */   public static final BorderLineStyle SLANTED_DASH_DOT = new BorderLineStyle(13, "Slanted dash dot");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\format\BorderLineStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */