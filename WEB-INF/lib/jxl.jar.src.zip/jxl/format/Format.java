package jxl.format;

public abstract interface Format
{
  public abstract String getFormatString();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\format\Format.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */