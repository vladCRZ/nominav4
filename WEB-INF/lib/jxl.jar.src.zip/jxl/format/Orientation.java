/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Orientation
/*     */ {
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String string;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private static Orientation[] orientations = new Orientation[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Orientation(int val, String s)
/*     */   {
/*  49 */     this.value = val;this.string = s;
/*     */     
/*  51 */     Orientation[] oldorients = orientations;
/*  52 */     orientations = new Orientation[oldorients.length + 1];
/*  53 */     System.arraycopy(oldorients, 0, orientations, 0, oldorients.length);
/*  54 */     orientations[oldorients.length] = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  64 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  72 */     return this.string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Orientation getOrientation(int val)
/*     */   {
/*  83 */     for (int i = 0; i < orientations.length; i++)
/*     */     {
/*  85 */       if (orientations[i].getValue() == val)
/*     */       {
/*  87 */         return orientations[i];
/*     */       }
/*     */     }
/*     */     
/*  91 */     return HORIZONTAL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */   public static Orientation HORIZONTAL = new Orientation(0, "horizontal");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 103 */   public static Orientation VERTICAL = new Orientation(255, "vertical");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   public static Orientation PLUS_90 = new Orientation(90, "up 90");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 113 */   public static Orientation MINUS_90 = new Orientation(180, "down 90");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 118 */   public static Orientation PLUS_45 = new Orientation(45, "up 45");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 123 */   public static Orientation MINUS_45 = new Orientation(135, "down 45");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 128 */   public static Orientation STACKED = new Orientation(255, "stacked");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\format\Orientation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */