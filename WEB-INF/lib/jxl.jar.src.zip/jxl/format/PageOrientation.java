/*    */ package jxl.format;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PageOrientation
/*    */ {
/* 38 */   public static PageOrientation PORTRAIT = new PageOrientation();
/*    */   
/*    */ 
/*    */ 
/* 42 */   public static PageOrientation LANDSCAPE = new PageOrientation();
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\format\PageOrientation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */