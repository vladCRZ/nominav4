/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnderlineStyle
/*     */ {
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String string;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  43 */   private static UnderlineStyle[] styles = new UnderlineStyle[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UnderlineStyle(int val, String s)
/*     */   {
/*  53 */     this.value = val;
/*  54 */     this.string = s;
/*     */     
/*  56 */     UnderlineStyle[] oldstyles = styles;
/*  57 */     styles = new UnderlineStyle[oldstyles.length + 1];
/*  58 */     System.arraycopy(oldstyles, 0, styles, 0, oldstyles.length);
/*  59 */     styles[oldstyles.length] = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  70 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  80 */     return this.string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UnderlineStyle getStyle(int val)
/*     */   {
/*  91 */     for (int i = 0; i < styles.length; i++)
/*     */     {
/*  93 */       if (styles[i].getValue() == val)
/*     */       {
/*  95 */         return styles[i];
/*     */       }
/*     */     }
/*     */     
/*  99 */     return NO_UNDERLINE;
/*     */   }
/*     */   
/*     */ 
/* 103 */   public static final UnderlineStyle NO_UNDERLINE = new UnderlineStyle(0, "none");
/*     */   
/*     */ 
/* 106 */   public static final UnderlineStyle SINGLE = new UnderlineStyle(1, "single");
/*     */   
/*     */ 
/* 109 */   public static final UnderlineStyle DOUBLE = new UnderlineStyle(2, "double");
/*     */   
/*     */ 
/* 112 */   public static final UnderlineStyle SINGLE_ACCOUNTING = new UnderlineStyle(33, "single accounting");
/*     */   
/*     */ 
/* 115 */   public static final UnderlineStyle DOUBLE_ACCOUNTING = new UnderlineStyle(34, "double accounting");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\format\UnderlineStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */