/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BOFRecord
/*     */   extends RecordData
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(BOFRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int Biff8 = 1536;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int Biff7 = 1280;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int WorkbookGlobals = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int Worksheet = 16;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int Chart = 32;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int MacroSheet = 64;
/*     */   
/*     */ 
/*     */ 
/*     */   private int version;
/*     */   
/*     */ 
/*     */ 
/*     */   private int substreamType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   BOFRecord(Record t)
/*     */   {
/*  79 */     super(t);
/*  80 */     byte[] data = getRecord().getData();
/*  81 */     this.version = IntegerHelper.getInt(data[0], data[1]);
/*  82 */     this.substreamType = IntegerHelper.getInt(data[2], data[3]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBiff8()
/*     */   {
/*  92 */     return this.version == 1536;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBiff7()
/*     */   {
/* 102 */     return this.version == 1280;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isWorkbookGlobals()
/*     */   {
/* 115 */     return this.substreamType == 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWorksheet()
/*     */   {
/* 126 */     return this.substreamType == 16;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMacroSheet()
/*     */   {
/* 137 */     return this.substreamType == 64;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isChart()
/*     */   {
/* 148 */     return this.substreamType == 32;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLength()
/*     */   {
/* 158 */     return getRecord().getLength();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\BOFRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */