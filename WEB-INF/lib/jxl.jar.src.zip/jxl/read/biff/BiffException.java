/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.JXLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BiffException
/*    */   extends JXLException
/*    */ {
/*    */   private static class BiffMessage
/*    */   {
/*    */     public String message;
/*    */     
/*    */     BiffMessage(String m)
/*    */     {
/* 45 */       this.message = m;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 51 */   static final BiffMessage unrecognizedBiffVersion = new BiffMessage("Unrecognized biff version");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 56 */   static final BiffMessage expectedGlobals = new BiffMessage("Expected globals");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 61 */   static final BiffMessage excelFileTooBig = new BiffMessage("Not all of the excel file could be read");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 66 */   static final BiffMessage excelFileNotFound = new BiffMessage("The input file was not found");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 71 */   static final BiffMessage unrecognizedOLEFile = new BiffMessage("Unable to recognize OLE stream");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 76 */   static final BiffMessage streamNotFound = new BiffMessage("Compound file does not contain the specified stream");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 81 */   static final BiffMessage passwordProtected = new BiffMessage("The workbook is password protected");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 86 */   static final BiffMessage corruptFileFormat = new BiffMessage("The file format is corrupt");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BiffException(BiffMessage m)
/*    */   {
/* 96 */     super(m.message);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\BiffException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */