/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.CellType;
/*    */ import jxl.biff.FormattingRecords;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlankCell
/*    */   extends CellValue
/*    */ {
/*    */   BlankCell(Record t, FormattingRecords fr, SheetImpl si)
/*    */   {
/* 40 */     super(t, fr, si);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getContents()
/*    */   {
/* 50 */     return "";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CellType getType()
/*    */   {
/* 60 */     return CellType.EMPTY;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\BlankCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */