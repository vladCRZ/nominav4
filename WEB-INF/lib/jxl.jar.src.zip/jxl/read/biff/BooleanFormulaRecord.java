/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.BooleanCell;
/*     */ import jxl.BooleanFormulaCell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BooleanFormulaRecord
/*     */   extends CellValue
/*     */   implements BooleanCell, FormulaData, BooleanFormulaCell
/*     */ {
/*     */   private boolean value;
/*     */   private ExternalSheet externalSheet;
/*     */   private WorkbookMethods nameTable;
/*     */   private String formulaString;
/*     */   private byte[] data;
/*     */   
/*     */   public BooleanFormulaRecord(Record t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/*  79 */     super(t, fr, si);
/*  80 */     this.externalSheet = es;
/*  81 */     this.nameTable = nt;
/*  82 */     this.value = false;
/*     */     
/*  84 */     this.data = getRecord().getData();
/*     */     
/*  86 */     Assert.verify(this.data[6] != 2);
/*     */     
/*  88 */     this.value = (this.data[8] == 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getValue()
/*     */   {
/* 101 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 112 */     return new Boolean(this.value).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 122 */     return CellType.BOOLEAN_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 133 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 135 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/* 139 */     byte[] d = new byte[this.data.length - 6];
/* 140 */     System.arraycopy(this.data, 6, d, 0, this.data.length - 6);
/*     */     
/* 142 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 153 */     if (this.formulaString == null)
/*     */     {
/* 155 */       byte[] tokens = new byte[this.data.length - 22];
/* 156 */       System.arraycopy(this.data, 22, tokens, 0, tokens.length);
/* 157 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */       
/*     */ 
/* 160 */       fp.parse();
/* 161 */       this.formulaString = fp.getFormula();
/*     */     }
/*     */     
/* 164 */     return this.formulaString;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\BooleanFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */