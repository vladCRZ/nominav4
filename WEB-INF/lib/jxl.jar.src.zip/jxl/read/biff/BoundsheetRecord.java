/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BoundsheetRecord
/*     */   extends RecordData
/*     */ {
/*     */   private int offset;
/*     */   private byte typeFlag;
/*     */   private byte visibilityFlag;
/*     */   private int length;
/*     */   private String name;
/*  57 */   public static Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BoundsheetRecord(Record t, WorkbookSettings s)
/*     */   {
/*  67 */     super(t);
/*  68 */     byte[] data = getRecord().getData();
/*  69 */     this.offset = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/*  70 */     this.typeFlag = data[5];
/*  71 */     this.visibilityFlag = data[4];
/*  72 */     this.length = data[6];
/*     */     
/*  74 */     if (data[7] == 0)
/*     */     {
/*     */ 
/*  77 */       byte[] bytes = new byte[this.length];
/*  78 */       System.arraycopy(data, 8, bytes, 0, this.length);
/*  79 */       this.name = StringHelper.getString(bytes, this.length, 0, s);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  84 */       byte[] bytes = new byte[this.length * 2];
/*  85 */       System.arraycopy(data, 8, bytes, 0, this.length * 2);
/*  86 */       this.name = StringHelper.getUnicodeString(bytes, this.length, 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BoundsheetRecord(Record t, Biff7 biff7)
/*     */   {
/* 100 */     super(t);
/* 101 */     byte[] data = getRecord().getData();
/* 102 */     this.offset = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/* 103 */     this.typeFlag = data[5];
/* 104 */     this.visibilityFlag = data[4];
/* 105 */     this.length = data[6];
/* 106 */     byte[] bytes = new byte[this.length];
/* 107 */     System.arraycopy(data, 7, bytes, 0, this.length);
/* 108 */     this.name = new String(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 118 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHidden()
/*     */   {
/* 128 */     return this.visibilityFlag != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSheet()
/*     */   {
/* 139 */     return this.typeFlag == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isChart()
/*     */   {
/* 149 */     return this.typeFlag == 2;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\BoundsheetRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */