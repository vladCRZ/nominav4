package jxl.read.biff;

import jxl.CellFeatures;

abstract interface CellFeaturesAccessor
{
  public abstract void setCellFeatures(CellFeatures paramCellFeatures);
  
  public abstract CellFeatures getCellFeatures();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\CellFeaturesAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */