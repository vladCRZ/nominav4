/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CellValue
/*     */   extends RecordData
/*     */   implements Cell, CellFeaturesAccessor
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(CellValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int xfIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormattingRecords formattingRecords;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private XFRecord format;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SheetImpl sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CellFeatures features;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CellValue(Record t, FormattingRecords fr, SheetImpl si)
/*     */   {
/*  93 */     super(t);
/*  94 */     byte[] data = getRecord().getData();
/*  95 */     this.row = IntegerHelper.getInt(data[0], data[1]);
/*  96 */     this.column = IntegerHelper.getInt(data[2], data[3]);
/*  97 */     this.xfIndex = IntegerHelper.getInt(data[4], data[5]);
/*  98 */     this.sheet = si;
/*  99 */     this.formattingRecords = fr;
/* 100 */     this.initialized = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getRow()
/*     */   {
/* 110 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getColumn()
/*     */   {
/* 120 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getXFIndex()
/*     */   {
/* 131 */     return this.xfIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFormat getCellFormat()
/*     */   {
/* 142 */     if (!this.initialized)
/*     */     {
/* 144 */       this.format = this.formattingRecords.getXFRecord(this.xfIndex);
/* 145 */       this.initialized = true;
/*     */     }
/*     */     
/* 148 */     return this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHidden()
/*     */   {
/* 158 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 160 */     if ((cir != null) && ((cir.getWidth() == 0) || (cir.getHidden())))
/*     */     {
/* 162 */       return true;
/*     */     }
/*     */     
/* 165 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 167 */     if ((rr != null) && ((rr.getRowHeight() == 0) || (rr.isCollapsed())))
/*     */     {
/* 169 */       return true;
/*     */     }
/*     */     
/* 172 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SheetImpl getSheet()
/*     */   {
/* 182 */     return this.sheet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFeatures getCellFeatures()
/*     */   {
/* 192 */     return this.features;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellFeatures(CellFeatures cf)
/*     */   {
/* 202 */     if (this.features != null)
/*     */     {
/* 204 */       logger.warn("current cell features not null - overwriting");
/*     */     }
/*     */     
/* 207 */     this.features = cf;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\CellValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */