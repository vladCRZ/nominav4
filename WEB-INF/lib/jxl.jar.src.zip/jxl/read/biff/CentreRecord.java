/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CentreRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean centre;
/*    */   
/*    */   public CentreRecord(Record t)
/*    */   {
/* 42 */     super(t);
/* 43 */     byte[] data = getRecord().getData();
/* 44 */     this.centre = (IntegerHelper.getInt(data[0], data[1]) != 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isCentre()
/*    */   {
/* 54 */     return this.centre;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\CentreRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */