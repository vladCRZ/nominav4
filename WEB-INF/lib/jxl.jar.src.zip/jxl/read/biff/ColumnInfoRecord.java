/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnInfoRecord
/*     */   extends RecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private int startColumn;
/*     */   private int endColumn;
/*     */   private int xfIndex;
/*     */   private int width;
/*     */   private boolean hidden;
/*     */   private int outlineLevel;
/*     */   private boolean collapsed;
/*     */   
/*     */   ColumnInfoRecord(Record t)
/*     */   {
/*  78 */     super(Type.COLINFO);
/*     */     
/*  80 */     this.data = t.getData();
/*     */     
/*  82 */     this.startColumn = IntegerHelper.getInt(this.data[0], this.data[1]);
/*  83 */     this.endColumn = IntegerHelper.getInt(this.data[2], this.data[3]);
/*  84 */     this.width = IntegerHelper.getInt(this.data[4], this.data[5]);
/*  85 */     this.xfIndex = IntegerHelper.getInt(this.data[6], this.data[7]);
/*     */     
/*  87 */     int options = IntegerHelper.getInt(this.data[8], this.data[9]);
/*  88 */     this.hidden = ((options & 0x1) != 0);
/*  89 */     this.outlineLevel = ((options & 0x700) >> 8);
/*  90 */     this.collapsed = ((options & 0x1000) != 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStartColumn()
/*     */   {
/* 100 */     return this.startColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEndColumn()
/*     */   {
/* 110 */     return this.endColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXFIndex()
/*     */   {
/* 120 */     return this.xfIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOutlineLevel()
/*     */   {
/* 130 */     return this.outlineLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCollapsed()
/*     */   {
/* 140 */     return this.collapsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 150 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getHidden()
/*     */   {
/* 160 */     return this.hidden;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\ColumnInfoRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */