/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.BaseCompoundFile;
/*     */ import jxl.biff.BaseCompoundFile.PropertyStorage;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CompoundFile
/*     */   extends BaseCompoundFile
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(CompoundFile.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numBigBlockDepotBlocks;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int sbdStartBlock;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rootStartBlock;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int extensionBlock;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numExtensionBlocks;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] rootEntry;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] bigBlockChain;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] smallBlockChain;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] bigBlockDepotBlocks;
/*     */   
/*     */ 
/*     */ 
/*     */   private ArrayList propertySets;
/*     */   
/*     */ 
/*     */ 
/*     */   private WorkbookSettings settings;
/*     */   
/*     */ 
/*     */ 
/*     */   private BaseCompoundFile.PropertyStorage rootEntryPropertyStorage;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompoundFile(byte[] d, WorkbookSettings ws)
/*     */     throws BiffException
/*     */   {
/* 108 */     this.data = d;
/* 109 */     this.settings = ws;
/*     */     
/*     */ 
/* 112 */     for (int i = 0; i < IDENTIFIER.length; i++)
/*     */     {
/* 114 */       if (this.data[i] != IDENTIFIER[i])
/*     */       {
/* 116 */         throw new BiffException(BiffException.unrecognizedOLEFile);
/*     */       }
/*     */     }
/*     */     
/* 120 */     this.propertySets = new ArrayList();
/* 121 */     this.numBigBlockDepotBlocks = IntegerHelper.getInt(this.data[44], this.data[45], this.data[46], this.data[47]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 126 */     this.sbdStartBlock = IntegerHelper.getInt(this.data[60], this.data[61], this.data[62], this.data[63]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     this.rootStartBlock = IntegerHelper.getInt(this.data[48], this.data[49], this.data[50], this.data[51]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 136 */     this.extensionBlock = IntegerHelper.getInt(this.data[68], this.data[69], this.data[70], this.data[71]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     this.numExtensionBlocks = IntegerHelper.getInt(this.data[72], this.data[73], this.data[74], this.data[75]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */     this.bigBlockDepotBlocks = new int[this.numBigBlockDepotBlocks];
/*     */     
/* 149 */     int pos = 76;
/*     */     
/* 151 */     int bbdBlocks = this.numBigBlockDepotBlocks;
/*     */     
/* 153 */     if (this.numExtensionBlocks != 0)
/*     */     {
/* 155 */       bbdBlocks = 109;
/*     */     }
/*     */     
/* 158 */     for (int i = 0; i < bbdBlocks; i++)
/*     */     {
/* 160 */       this.bigBlockDepotBlocks[i] = IntegerHelper.getInt(d[pos], d[(pos + 1)], d[(pos + 2)], d[(pos + 3)]);
/*     */       
/* 162 */       pos += 4;
/*     */     }
/*     */     
/* 165 */     for (int j = 0; j < this.numExtensionBlocks; j++)
/*     */     {
/* 167 */       pos = (this.extensionBlock + 1) * 512;
/* 168 */       int blocksToRead = Math.min(this.numBigBlockDepotBlocks - bbdBlocks, 127);
/*     */       
/*     */ 
/* 171 */       for (int i = bbdBlocks; i < bbdBlocks + blocksToRead; i++)
/*     */       {
/* 173 */         this.bigBlockDepotBlocks[i] = IntegerHelper.getInt(d[pos], d[(pos + 1)], d[(pos + 2)], d[(pos + 3)]);
/*     */         
/* 175 */         pos += 4;
/*     */       }
/*     */       
/* 178 */       bbdBlocks += blocksToRead;
/* 179 */       if (bbdBlocks < this.numBigBlockDepotBlocks)
/*     */       {
/* 181 */         this.extensionBlock = IntegerHelper.getInt(d[pos], d[(pos + 1)], d[(pos + 2)], d[(pos + 3)]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 186 */     readBigBlockDepot();
/* 187 */     readSmallBlockDepot();
/*     */     
/* 189 */     this.rootEntry = readData(this.rootStartBlock);
/* 190 */     readPropertySets();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readBigBlockDepot()
/*     */   {
/* 198 */     int pos = 0;
/* 199 */     int index = 0;
/* 200 */     this.bigBlockChain = new int[this.numBigBlockDepotBlocks * 512 / 4];
/*     */     
/* 202 */     for (int i = 0; i < this.numBigBlockDepotBlocks; i++)
/*     */     {
/* 204 */       pos = (this.bigBlockDepotBlocks[i] + 1) * 512;
/*     */       
/* 206 */       for (int j = 0; j < 128; j++)
/*     */       {
/* 208 */         this.bigBlockChain[index] = IntegerHelper.getInt(this.data[pos], this.data[(pos + 1)], this.data[(pos + 2)], this.data[(pos + 3)]);
/*     */         
/* 210 */         pos += 4;
/* 211 */         index++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readSmallBlockDepot()
/*     */     throws BiffException
/*     */   {
/* 221 */     int pos = 0;
/* 222 */     int index = 0;
/* 223 */     int sbdBlock = this.sbdStartBlock;
/* 224 */     this.smallBlockChain = new int[0];
/*     */     
/*     */ 
/*     */ 
/* 228 */     if (sbdBlock == -1)
/*     */     {
/* 230 */       logger.warn("invalid small block depot number");
/* 231 */       return;
/*     */     }
/*     */     
/* 234 */     for (int blockCount = 0; 
/* 235 */         (blockCount <= this.bigBlockChain.length) && (sbdBlock != -2); blockCount++)
/*     */     {
/*     */ 
/* 238 */       int[] oldChain = this.smallBlockChain;
/* 239 */       this.smallBlockChain = new int[this.smallBlockChain.length + 128];
/* 240 */       System.arraycopy(oldChain, 0, this.smallBlockChain, 0, oldChain.length);
/*     */       
/* 242 */       pos = (sbdBlock + 1) * 512;
/*     */       
/* 244 */       for (int j = 0; j < 128; j++)
/*     */       {
/* 246 */         this.smallBlockChain[index] = IntegerHelper.getInt(this.data[pos], this.data[(pos + 1)], this.data[(pos + 2)], this.data[(pos + 3)]);
/*     */         
/* 248 */         pos += 4;
/* 249 */         index++;
/*     */       }
/*     */       
/* 252 */       sbdBlock = this.bigBlockChain[sbdBlock];
/*     */     }
/*     */     
/* 255 */     if (blockCount > this.bigBlockChain.length)
/*     */     {
/*     */ 
/*     */ 
/* 259 */       throw new BiffException(BiffException.corruptFileFormat);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readPropertySets()
/*     */   {
/* 268 */     int offset = 0;
/* 269 */     byte[] d = null;
/*     */     
/* 271 */     while (offset < this.rootEntry.length)
/*     */     {
/* 273 */       d = new byte[''];
/* 274 */       System.arraycopy(this.rootEntry, offset, d, 0, d.length);
/* 275 */       BaseCompoundFile.PropertyStorage ps = new BaseCompoundFile.PropertyStorage(this, d);
/*     */       
/*     */ 
/*     */ 
/* 279 */       if ((ps.name == null) || (ps.name.length() == 0))
/*     */       {
/* 281 */         if (ps.type == 5)
/*     */         {
/* 283 */           ps.name = "Root Entry";
/* 284 */           logger.warn("Property storage name for " + ps.type + " is empty - setting to " + "Root Entry");
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 289 */         else if (ps.size != 0)
/*     */         {
/* 291 */           logger.warn("Property storage type " + ps.type + " is non-empty and has no associated name");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 296 */       this.propertySets.add(ps);
/* 297 */       if (ps.name.equalsIgnoreCase("Root Entry"))
/*     */       {
/* 299 */         this.rootEntryPropertyStorage = ps;
/*     */       }
/* 301 */       offset += 128;
/*     */     }
/*     */     
/* 304 */     if (this.rootEntryPropertyStorage == null)
/*     */     {
/* 306 */       this.rootEntryPropertyStorage = ((BaseCompoundFile.PropertyStorage)this.propertySets.get(0));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getStream(String streamName)
/*     */     throws BiffException
/*     */   {
/* 319 */     BaseCompoundFile.PropertyStorage ps = findPropertyStorage(streamName, this.rootEntryPropertyStorage);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 324 */     if (ps == null)
/*     */     {
/* 326 */       ps = getPropertyStorage(streamName);
/*     */     }
/*     */     
/* 329 */     if ((ps.size >= 4096) || (streamName.equalsIgnoreCase("Root Entry")))
/*     */     {
/*     */ 
/* 332 */       return getBigBlockStream(ps);
/*     */     }
/*     */     
/*     */ 
/* 336 */     return getSmallBlockStream(ps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getStream(int psIndex)
/*     */     throws BiffException
/*     */   {
/* 350 */     BaseCompoundFile.PropertyStorage ps = getPropertyStorage(psIndex);
/*     */     
/* 352 */     if ((ps.size >= 4096) || (ps.name.equalsIgnoreCase("Root Entry")))
/*     */     {
/*     */ 
/* 355 */       return getBigBlockStream(ps);
/*     */     }
/*     */     
/*     */ 
/* 359 */     return getSmallBlockStream(ps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseCompoundFile.PropertyStorage findPropertyStorage(String name)
/*     */   {
/* 371 */     return findPropertyStorage(name, this.rootEntryPropertyStorage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BaseCompoundFile.PropertyStorage findPropertyStorage(String name, BaseCompoundFile.PropertyStorage base)
/*     */   {
/* 381 */     if (base.child == -1)
/*     */     {
/* 383 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 387 */     BaseCompoundFile.PropertyStorage child = getPropertyStorage(base.child);
/* 388 */     if (child.name.equalsIgnoreCase(name))
/*     */     {
/* 390 */       return child;
/*     */     }
/*     */     
/*     */ 
/* 394 */     BaseCompoundFile.PropertyStorage prev = child;
/* 395 */     while (prev.previous != -1)
/*     */     {
/* 397 */       prev = getPropertyStorage(prev.previous);
/* 398 */       if (prev.name.equalsIgnoreCase(name))
/*     */       {
/* 400 */         return prev;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 405 */     BaseCompoundFile.PropertyStorage next = child;
/* 406 */     while (next.next != -1)
/*     */     {
/* 408 */       next = getPropertyStorage(next.next);
/* 409 */       if (next.name.equalsIgnoreCase(name))
/*     */       {
/* 411 */         return next;
/*     */       }
/*     */     }
/*     */     
/* 415 */     return findPropertyStorage(name, child);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   private BaseCompoundFile.PropertyStorage getPropertyStorage(String name)
/*     */     throws BiffException
/*     */   {
/* 429 */     Iterator i = this.propertySets.iterator();
/* 430 */     boolean found = false;
/* 431 */     boolean multiple = false;
/* 432 */     BaseCompoundFile.PropertyStorage ps = null;
/* 433 */     while (i.hasNext())
/*     */     {
/* 435 */       BaseCompoundFile.PropertyStorage ps2 = (BaseCompoundFile.PropertyStorage)i.next();
/* 436 */       if (ps2.name.equalsIgnoreCase(name))
/*     */       {
/* 438 */         multiple = found == true;
/* 439 */         found = true;
/* 440 */         ps = ps2;
/*     */       }
/*     */     }
/*     */     
/* 444 */     if (multiple)
/*     */     {
/* 446 */       logger.warn("found multiple copies of property set " + name);
/*     */     }
/*     */     
/* 449 */     if (!found)
/*     */     {
/* 451 */       throw new BiffException(BiffException.streamNotFound);
/*     */     }
/*     */     
/* 454 */     return ps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BaseCompoundFile.PropertyStorage getPropertyStorage(int index)
/*     */   {
/* 464 */     return (BaseCompoundFile.PropertyStorage)this.propertySets.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getBigBlockStream(BaseCompoundFile.PropertyStorage ps)
/*     */   {
/* 475 */     int numBlocks = ps.size / 512;
/* 476 */     if (ps.size % 512 != 0)
/*     */     {
/* 478 */       numBlocks++;
/*     */     }
/*     */     
/* 481 */     byte[] streamData = new byte[numBlocks * 512];
/*     */     
/* 483 */     int block = ps.startBlock;
/*     */     
/* 485 */     int count = 0;
/* 486 */     int pos = 0;
/* 487 */     while ((block != -2) && (count < numBlocks))
/*     */     {
/* 489 */       pos = (block + 1) * 512;
/* 490 */       System.arraycopy(this.data, pos, streamData, count * 512, 512);
/*     */       
/* 492 */       count++;
/* 493 */       block = this.bigBlockChain[block];
/*     */     }
/*     */     
/* 496 */     if ((block != -2) && (count == numBlocks))
/*     */     {
/* 498 */       logger.warn("Property storage size inconsistent with block chain.");
/*     */     }
/*     */     
/* 501 */     return streamData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getSmallBlockStream(BaseCompoundFile.PropertyStorage ps)
/*     */     throws BiffException
/*     */   {
/* 513 */     byte[] rootdata = readData(this.rootEntryPropertyStorage.startBlock);
/* 514 */     byte[] sbdata = new byte[0];
/*     */     
/* 516 */     int block = ps.startBlock;
/* 517 */     int pos = 0;
/*     */     
/* 519 */     for (int blockCount = 0; 
/* 520 */         (blockCount <= this.smallBlockChain.length) && (block != -2); blockCount++)
/*     */     {
/*     */ 
/* 523 */       byte[] olddata = sbdata;
/* 524 */       sbdata = new byte[olddata.length + 64];
/* 525 */       System.arraycopy(olddata, 0, sbdata, 0, olddata.length);
/*     */       
/*     */ 
/* 528 */       pos = block * 64;
/* 529 */       System.arraycopy(rootdata, pos, sbdata, olddata.length, 64);
/*     */       
/* 531 */       block = this.smallBlockChain[block];
/*     */       
/* 533 */       if (block == -1)
/*     */       {
/* 535 */         logger.warn("Incorrect terminator for small block stream " + ps.name);
/* 536 */         block = -2;
/*     */       }
/*     */     }
/*     */     
/* 540 */     if (blockCount > this.smallBlockChain.length)
/*     */     {
/*     */ 
/*     */ 
/* 544 */       throw new BiffException(BiffException.corruptFileFormat);
/*     */     }
/*     */     
/* 547 */     return sbdata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] readData(int bl)
/*     */     throws BiffException
/*     */   {
/* 559 */     int block = bl;
/* 560 */     int pos = 0;
/* 561 */     byte[] entry = new byte[0];
/*     */     
/* 563 */     for (int blockCount = 0; 
/* 564 */         (blockCount <= this.bigBlockChain.length) && (block != -2); blockCount++)
/*     */     {
/*     */ 
/* 567 */       byte[] oldEntry = entry;
/* 568 */       entry = new byte[oldEntry.length + 512];
/* 569 */       System.arraycopy(oldEntry, 0, entry, 0, oldEntry.length);
/* 570 */       pos = (block + 1) * 512;
/* 571 */       System.arraycopy(this.data, pos, entry, oldEntry.length, 512);
/*     */       
/* 573 */       if (this.bigBlockChain[block] == block)
/*     */       {
/* 575 */         throw new BiffException(BiffException.corruptFileFormat);
/*     */       }
/* 577 */       block = this.bigBlockChain[block];
/*     */     }
/*     */     
/* 580 */     if (blockCount > this.bigBlockChain.length)
/*     */     {
/*     */ 
/*     */ 
/* 584 */       throw new BiffException(BiffException.corruptFileFormat);
/*     */     }
/*     */     
/* 587 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfPropertySets()
/*     */   {
/* 596 */     return this.propertySets.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseCompoundFile.PropertyStorage getPropertySet(int index)
/*     */   {
/* 608 */     return getPropertyStorage(index);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\CompoundFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */