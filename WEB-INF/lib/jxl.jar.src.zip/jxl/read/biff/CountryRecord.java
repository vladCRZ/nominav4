/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountryRecord
/*    */   extends RecordData
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(CountryRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int language;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private int regionalSettings;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CountryRecord(Record t)
/*    */   {
/* 54 */     super(t);
/* 55 */     byte[] data = t.getData();
/*    */     
/* 57 */     this.language = IntegerHelper.getInt(data[0], data[1]);
/* 58 */     this.regionalSettings = IntegerHelper.getInt(data[2], data[3]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getLanguageCode()
/*    */   {
/* 68 */     return this.language;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getRegionalSettingsCode()
/*    */   {
/* 78 */     return this.regionalSettings;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\CountryRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */