/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.DateFormulaCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DateFormulaRecord
/*     */   extends DateRecord
/*     */   implements DateCell, FormulaData, DateFormulaCell
/*     */ {
/*     */   private String formulaString;
/*     */   private ExternalSheet externalSheet;
/*     */   private WorkbookMethods nameTable;
/*     */   private byte[] data;
/*     */   
/*     */   public DateFormulaRecord(NumberFormulaRecord t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, boolean nf, SheetImpl si)
/*     */     throws FormulaException
/*     */   {
/*  74 */     super(t, t.getXFIndex(), fr, nf, si);
/*     */     
/*  76 */     this.externalSheet = es;
/*  77 */     this.nameTable = nt;
/*  78 */     this.data = t.getFormulaData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/*  88 */     return CellType.DATE_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/*  99 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 101 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/* 105 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 118 */     if (this.formulaString == null)
/*     */     {
/* 120 */       byte[] tokens = new byte[this.data.length - 16];
/* 121 */       System.arraycopy(this.data, 16, tokens, 0, tokens.length);
/* 122 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */       
/*     */ 
/* 125 */       fp.parse();
/* 126 */       this.formulaString = fp.getFormula();
/*     */     }
/*     */     
/* 129 */     return this.formulaString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 139 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumberFormat getNumberFormat()
/*     */   {
/* 149 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\DateFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */