/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DateRecord
/*     */   implements DateCell, CellFeaturesAccessor
/*     */ {
/*  45 */   private static Logger logger = Logger.getLogger(DateRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Date date;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean time;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DateFormat format;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CellFormat cellFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int xfIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormattingRecords formattingRecords;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SheetImpl sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CellFeatures features;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/* 103 */   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
/*     */   
/*     */ 
/* 106 */   private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int nonLeapDay = 61;
/*     */   
/*     */ 
/*     */ 
/* 115 */   private static final TimeZone gmtZone = TimeZone.getTimeZone("GMT");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int utcOffsetDays = 25569;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int utcOffsetDays1904 = 24107;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final long secondsInADay = 86400L;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final long msInASecond = 1000L;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final long msInADay = 86400000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateRecord(NumberCell num, int xfi, FormattingRecords fr, boolean nf, SheetImpl si)
/*     */   {
/* 144 */     this.row = num.getRow();
/* 145 */     this.column = num.getColumn();
/* 146 */     this.xfIndex = xfi;
/* 147 */     this.formattingRecords = fr;
/* 148 */     this.sheet = si;
/* 149 */     this.initialized = false;
/*     */     
/* 151 */     this.format = this.formattingRecords.getDateFormat(this.xfIndex);
/*     */     
/*     */ 
/* 154 */     double numValue = num.getValue();
/*     */     
/* 156 */     if (Math.abs(numValue) < 1.0D)
/*     */     {
/* 158 */       if (this.format == null)
/*     */       {
/* 160 */         this.format = timeFormat;
/*     */       }
/* 162 */       this.time = true;
/*     */     }
/*     */     else
/*     */     {
/* 166 */       if (this.format == null)
/*     */       {
/* 168 */         this.format = dateFormat;
/*     */       }
/* 170 */       this.time = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */     if ((!nf) && (!this.time) && (numValue < 61.0D))
/*     */     {
/* 179 */       numValue += 1.0D;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 184 */     this.format.setTimeZone(gmtZone);
/*     */     
/*     */ 
/* 187 */     int offsetDays = nf ? 24107 : 25569;
/* 188 */     double utcDays = numValue - offsetDays;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 193 */     long utcValue = Math.round(utcDays * 86400.0D) * 1000L;
/*     */     
/* 195 */     this.date = new Date(utcValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getRow()
/*     */   {
/* 205 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getColumn()
/*     */   {
/* 215 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getDate()
/*     */   {
/* 225 */     return this.date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 236 */     return this.format.format(this.date);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 246 */     return CellType.DATE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTime()
/*     */   {
/* 257 */     return this.time;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateFormat getDateFormat()
/*     */   {
/* 270 */     Assert.verify(this.format != null);
/*     */     
/* 272 */     return this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFormat getCellFormat()
/*     */   {
/* 283 */     if (!this.initialized)
/*     */     {
/* 285 */       this.cellFormat = this.formattingRecords.getXFRecord(this.xfIndex);
/* 286 */       this.initialized = true;
/*     */     }
/*     */     
/* 289 */     return this.cellFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHidden()
/*     */   {
/* 299 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 301 */     if ((cir != null) && (cir.getWidth() == 0))
/*     */     {
/* 303 */       return true;
/*     */     }
/*     */     
/* 306 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 308 */     if ((rr != null) && ((rr.getRowHeight() == 0) || (rr.isCollapsed())))
/*     */     {
/* 310 */       return true;
/*     */     }
/*     */     
/* 313 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final SheetImpl getSheet()
/*     */   {
/* 323 */     return this.sheet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFeatures getCellFeatures()
/*     */   {
/* 333 */     return this.features;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellFeatures(CellFeatures cf)
/*     */   {
/* 343 */     this.features = cf;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\DateRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */