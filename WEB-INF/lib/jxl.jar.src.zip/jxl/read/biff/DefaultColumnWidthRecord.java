/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultColumnWidthRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int width;
/*    */   
/*    */   public DefaultColumnWidthRecord(Record t)
/*    */   {
/* 42 */     super(t);
/* 43 */     byte[] data = t.getData();
/*    */     
/* 45 */     this.width = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getWidth()
/*    */   {
/* 56 */     return this.width;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\DefaultColumnWidthRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */