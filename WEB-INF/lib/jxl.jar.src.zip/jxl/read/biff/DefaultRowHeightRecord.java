/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultRowHeightRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int height;
/*    */   
/*    */   public DefaultRowHeightRecord(Record t)
/*    */   {
/* 42 */     super(t);
/* 43 */     byte[] data = t.getData();
/*    */     
/* 45 */     if (data.length > 2)
/*    */     {
/* 47 */       this.height = IntegerHelper.getInt(data[2], data[3]);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getHeight()
/*    */   {
/* 58 */     return this.height;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\DefaultRowHeightRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */