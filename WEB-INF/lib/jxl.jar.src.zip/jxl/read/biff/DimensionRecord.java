/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DimensionRecord
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(DimensionRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numRows;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numCols;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  50 */   public static Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DimensionRecord(Record t)
/*     */   {
/*  59 */     super(t);
/*  60 */     byte[] data = t.getData();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     if (data.length == 10)
/*     */     {
/*  68 */       read10ByteData(data);
/*     */     }
/*     */     else
/*     */     {
/*  72 */       read14ByteData(data);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DimensionRecord(Record t, Biff7 biff7)
/*     */   {
/*  84 */     super(t);
/*  85 */     byte[] data = t.getData();
/*  86 */     read10ByteData(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void read10ByteData(byte[] data)
/*     */   {
/*  95 */     this.numRows = IntegerHelper.getInt(data[2], data[3]);
/*  96 */     this.numCols = IntegerHelper.getInt(data[6], data[7]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void read14ByteData(byte[] data)
/*     */   {
/* 105 */     this.numRows = IntegerHelper.getInt(data[4], data[5], data[6], data[7]);
/* 106 */     this.numCols = IntegerHelper.getInt(data[10], data[11]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfRows()
/*     */   {
/* 116 */     return this.numRows;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfColumns()
/*     */   {
/* 126 */     return this.numCols;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\DimensionRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */