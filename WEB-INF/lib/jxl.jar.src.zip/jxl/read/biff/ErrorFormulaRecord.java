/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.ErrorCell;
/*     */ import jxl.ErrorFormulaCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaErrorCode;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ErrorFormulaRecord
/*     */   extends CellValue
/*     */   implements ErrorCell, FormulaData, ErrorFormulaCell
/*     */ {
/*     */   private int errorCode;
/*     */   private ExternalSheet externalSheet;
/*     */   private WorkbookMethods nameTable;
/*     */   private String formulaString;
/*     */   private byte[] data;
/*     */   private FormulaErrorCode error;
/*     */   
/*     */   public ErrorFormulaRecord(Record t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/*  84 */     super(t, fr, si);
/*     */     
/*  86 */     this.externalSheet = es;
/*  87 */     this.nameTable = nt;
/*  88 */     this.data = getRecord().getData();
/*     */     
/*  90 */     Assert.verify(this.data[6] == 2);
/*     */     
/*  92 */     this.errorCode = this.data[8];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/* 104 */     return this.errorCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 114 */     if (this.error == null)
/*     */     {
/* 116 */       this.error = FormulaErrorCode.getErrorCode(this.errorCode);
/*     */     }
/*     */     
/* 119 */     return "ERROR " + this.errorCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 130 */     return CellType.FORMULA_ERROR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 141 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 143 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/* 147 */     byte[] d = new byte[this.data.length - 6];
/* 148 */     System.arraycopy(this.data, 6, d, 0, this.data.length - 6);
/*     */     
/* 150 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 161 */     if (this.formulaString == null)
/*     */     {
/* 163 */       byte[] tokens = new byte[this.data.length - 22];
/* 164 */       System.arraycopy(this.data, 22, tokens, 0, tokens.length);
/* 165 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */       
/*     */ 
/* 168 */       fp.parse();
/* 169 */       this.formulaString = fp.getFormula();
/*     */     }
/*     */     
/* 172 */     return this.formulaString;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\ErrorFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */