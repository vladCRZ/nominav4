/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.CellType;
/*    */ import jxl.ErrorCell;
/*    */ import jxl.biff.FormattingRecords;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ErrorRecord
/*    */   extends CellValue
/*    */   implements ErrorCell
/*    */ {
/*    */   private int errorCode;
/*    */   
/*    */   public ErrorRecord(Record t, FormattingRecords fr, SheetImpl si)
/*    */   {
/* 46 */     super(t, fr, si);
/*    */     
/* 48 */     byte[] data = getRecord().getData();
/*    */     
/* 50 */     this.errorCode = data[6];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getErrorCode()
/*    */   {
/* 62 */     return this.errorCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getContents()
/*    */   {
/* 72 */     return "ERROR " + this.errorCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CellType getType()
/*    */   {
/* 82 */     return CellType.ERROR;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\ErrorRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */