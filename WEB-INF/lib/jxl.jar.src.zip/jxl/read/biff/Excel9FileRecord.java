/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Excel9FileRecord
/*    */   extends RecordData
/*    */ {
/* 33 */   private static Logger logger = Logger.getLogger(Excel9FileRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean excel9file;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Excel9FileRecord(Record t)
/*    */   {
/* 47 */     super(t);
/* 48 */     this.excel9file = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getExcel9File()
/*    */   {
/* 58 */     return this.excel9file;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\Excel9FileRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */