/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalNameRecord
/*     */   extends RecordData
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(ExternalNameRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean addInFunction;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ExternalNameRecord(Record t, WorkbookSettings ws)
/*     */   {
/*  58 */     super(t);
/*     */     
/*  60 */     byte[] data = getRecord().getData();
/*  61 */     int options = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  63 */     if (options == 0)
/*     */     {
/*  65 */       this.addInFunction = true;
/*     */     }
/*     */     
/*  68 */     if (!this.addInFunction)
/*     */     {
/*  70 */       return;
/*     */     }
/*     */     
/*  73 */     int length = data[6];
/*     */     
/*  75 */     boolean unicode = data[7] != 0;
/*     */     
/*  77 */     if (unicode)
/*     */     {
/*  79 */       this.name = StringHelper.getUnicodeString(data, length, 8);
/*     */     }
/*     */     else
/*     */     {
/*  83 */       this.name = StringHelper.getString(data, length, 8, ws);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAddInFunction()
/*     */   {
/*  94 */     return this.addInFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 104 */     return this.name;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\ExternalNameRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */