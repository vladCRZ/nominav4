/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FooterRecord
/*     */   extends RecordData
/*     */ {
/*     */   private String footer;
/*  41 */   public static Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FooterRecord(Record t, WorkbookSettings ws)
/*     */   {
/*  51 */     super(t);
/*  52 */     byte[] data = getRecord().getData();
/*     */     
/*  54 */     if (data.length == 0)
/*     */     {
/*  56 */       return;
/*     */     }
/*     */     
/*  59 */     int chars = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  61 */     boolean unicode = data[2] == 1;
/*     */     
/*  63 */     if (unicode)
/*     */     {
/*  65 */       this.footer = StringHelper.getUnicodeString(data, chars, 3);
/*     */     }
/*     */     else
/*     */     {
/*  69 */       this.footer = StringHelper.getString(data, chars, 3, ws);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FooterRecord(Record t, WorkbookSettings ws, Biff7 dummy)
/*     */   {
/*  82 */     super(t);
/*  83 */     byte[] data = getRecord().getData();
/*     */     
/*  85 */     if (data.length == 0)
/*     */     {
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     int chars = data[0];
/*  91 */     this.footer = StringHelper.getString(data, chars, 1, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getFooter()
/*     */   {
/* 101 */     return this.footer;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\FooterRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */