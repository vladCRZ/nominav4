/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FormulaRecord
/*     */   extends CellValue
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(FormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CellValue formula;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean shared;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  58 */   public static final IgnoreSharedFormula ignoreSharedFormula = new IgnoreSharedFormula(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, WorkbookSettings ws)
/*     */   {
/*  82 */     super(t, fr, si);
/*     */     
/*  84 */     byte[] data = getRecord().getData();
/*     */     
/*  86 */     this.shared = false;
/*     */     
/*     */ 
/*  89 */     int grbit = IntegerHelper.getInt(data[14], data[15]);
/*  90 */     if ((grbit & 0x8) != 0)
/*     */     {
/*  92 */       this.shared = true;
/*     */       
/*  94 */       if ((data[6] == 0) && (data[12] == -1) && (data[13] == -1))
/*     */       {
/*     */ 
/*  97 */         this.formula = new SharedStringFormulaRecord(t, excelFile, fr, es, nt, si, ws);
/*     */ 
/*     */       }
/* 100 */       else if ((data[6] == 3) && (data[12] == -1) && (data[13] == -1))
/*     */       {
/*     */ 
/* 103 */         this.formula = new SharedStringFormulaRecord(t, excelFile, fr, es, nt, si, SharedStringFormulaRecord.EMPTY_STRING);
/*     */ 
/*     */ 
/*     */       }
/* 107 */       else if ((data[6] == 2) && (data[12] == -1) && (data[13] == -1))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 112 */         int errorCode = data[8];
/* 113 */         this.formula = new SharedErrorFormulaRecord(t, excelFile, errorCode, fr, es, nt, si);
/*     */ 
/*     */       }
/* 116 */       else if ((data[6] == 1) && (data[12] == -1) && (data[13] == -1))
/*     */       {
/*     */ 
/*     */ 
/* 120 */         boolean value = data[8] == 1;
/* 121 */         this.formula = new SharedBooleanFormulaRecord(t, excelFile, value, fr, es, nt, si);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 127 */         double value = DoubleHelper.getIEEEDouble(data, 6);
/* 128 */         SharedNumberFormulaRecord snfr = new SharedNumberFormulaRecord(t, excelFile, value, fr, es, nt, si);
/*     */         
/* 130 */         snfr.setNumberFormat(fr.getNumberFormat(getXFIndex()));
/* 131 */         this.formula = snfr;
/*     */       }
/*     */       
/* 134 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 139 */     if ((data[6] == 0) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/* 142 */       this.formula = new StringFormulaRecord(t, excelFile, fr, es, nt, si, ws);
/*     */     }
/* 144 */     else if ((data[6] == 1) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */       this.formula = new BooleanFormulaRecord(t, fr, es, nt, si);
/*     */     }
/* 152 */     else if ((data[6] == 2) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 157 */       this.formula = new ErrorFormulaRecord(t, fr, es, nt, si);
/*     */     }
/* 159 */     else if ((data[6] == 3) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/* 162 */       this.formula = new StringFormulaRecord(t, fr, es, nt, si);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 167 */       this.formula = new NumberFormulaRecord(t, fr, es, nt, si);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, IgnoreSharedFormula i, SheetImpl si, WorkbookSettings ws)
/*     */   {
/* 195 */     super(t, fr, si);
/* 196 */     byte[] data = getRecord().getData();
/*     */     
/* 198 */     this.shared = false;
/*     */     
/*     */ 
/*     */ 
/* 202 */     if ((data[6] == 0) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/* 205 */       this.formula = new StringFormulaRecord(t, excelFile, fr, es, nt, si, ws);
/*     */     }
/* 207 */     else if ((data[6] == 1) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 213 */       this.formula = new BooleanFormulaRecord(t, fr, es, nt, si);
/*     */     }
/* 215 */     else if ((data[6] == 2) && (data[12] == -1) && (data[13] == -1))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 220 */       this.formula = new ErrorFormulaRecord(t, fr, es, nt, si);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 225 */       this.formula = new NumberFormulaRecord(t, fr, es, nt, si);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 236 */     Assert.verify(false);
/* 237 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 247 */     Assert.verify(false);
/* 248 */     return CellType.EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final CellValue getFormula()
/*     */   {
/* 258 */     return this.formula;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final boolean isShared()
/*     */   {
/* 269 */     return this.shared;
/*     */   }
/*     */   
/*     */   private static class IgnoreSharedFormula {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\FormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */