/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuttersRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   private int rowOutlineLevel;
/*    */   private int columnOutlineLevel;
/*    */   
/*    */   public GuttersRecord(Record r)
/*    */   {
/* 42 */     super(r);
/*    */     
/* 44 */     byte[] data = getRecord().getData();
/* 45 */     this.width = IntegerHelper.getInt(data[0], data[1]);
/* 46 */     this.height = IntegerHelper.getInt(data[2], data[3]);
/* 47 */     this.rowOutlineLevel = IntegerHelper.getInt(data[4], data[5]);
/* 48 */     this.columnOutlineLevel = IntegerHelper.getInt(data[6], data[7]);
/*    */   }
/*    */   
/*    */   int getRowOutlineLevel()
/*    */   {
/* 53 */     return this.rowOutlineLevel;
/*    */   }
/*    */   
/*    */   int getColumnOutlineLevel()
/*    */   {
/* 58 */     return this.columnOutlineLevel;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\GuttersRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */