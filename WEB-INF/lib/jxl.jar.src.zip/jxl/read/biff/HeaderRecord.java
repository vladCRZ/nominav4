/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderRecord
/*     */   extends RecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(HeaderRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String header;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   public static Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HeaderRecord(Record t, WorkbookSettings ws)
/*     */   {
/*  58 */     super(t);
/*  59 */     byte[] data = getRecord().getData();
/*     */     
/*  61 */     if (data.length == 0)
/*     */     {
/*  63 */       return;
/*     */     }
/*     */     
/*  66 */     int chars = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  68 */     boolean unicode = data[2] == 1;
/*     */     
/*  70 */     if (unicode)
/*     */     {
/*  72 */       this.header = StringHelper.getUnicodeString(data, chars, 3);
/*     */     }
/*     */     else
/*     */     {
/*  76 */       this.header = StringHelper.getString(data, chars, 3, ws);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HeaderRecord(Record t, WorkbookSettings ws, Biff7 dummy)
/*     */   {
/*  89 */     super(t);
/*  90 */     byte[] data = getRecord().getData();
/*     */     
/*  92 */     if (data.length == 0)
/*     */     {
/*  94 */       return;
/*     */     }
/*     */     
/*  97 */     int chars = data[0];
/*  98 */     this.header = StringHelper.getString(data, chars, 1, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getHeader()
/*     */   {
/* 108 */     return this.header;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\HeaderRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */