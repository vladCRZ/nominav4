/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HideobjRecord
/*    */   extends RecordData
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(HideobjRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int hidemode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HideobjRecord(Record t)
/*    */   {
/* 48 */     super(t);
/* 49 */     byte[] data = t.getData();
/* 50 */     this.hidemode = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getHideMode()
/*    */   {
/* 60 */     return this.hidemode;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\HideobjRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */