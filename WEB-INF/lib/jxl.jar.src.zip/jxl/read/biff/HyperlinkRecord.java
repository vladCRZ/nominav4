/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.Hyperlink;
/*     */ import jxl.Range;
/*     */ import jxl.Sheet;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.SheetRangeImpl;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperlinkRecord
/*     */   extends RecordData
/*     */   implements Hyperlink
/*     */ {
/*  47 */   private static Logger logger = Logger.getLogger(HyperlinkRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int firstRow;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int lastRow;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int firstColumn;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int lastColumn;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private URL url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private File file;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String location;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SheetRangeImpl range;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private LinkType linkType;
/*     */   
/*     */ 
/*     */ 
/*  96 */   private static final LinkType urlLink = new LinkType(null);
/*  97 */   private static final LinkType fileLink = new LinkType(null);
/*  98 */   private static final LinkType workbookLink = new LinkType(null);
/*  99 */   private static final LinkType unknown = new LinkType(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HyperlinkRecord(Record t, Sheet s, WorkbookSettings ws)
/*     */   {
/* 110 */     super(t);
/*     */     
/* 112 */     this.linkType = unknown;
/*     */     
/* 114 */     byte[] data = getRecord().getData();
/*     */     
/*     */ 
/* 117 */     this.firstRow = IntegerHelper.getInt(data[0], data[1]);
/* 118 */     this.lastRow = IntegerHelper.getInt(data[2], data[3]);
/* 119 */     this.firstColumn = IntegerHelper.getInt(data[4], data[5]);
/* 120 */     this.lastColumn = IntegerHelper.getInt(data[6], data[7]);
/* 121 */     this.range = new SheetRangeImpl(s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*     */     
/*     */ 
/*     */ 
/* 125 */     int options = IntegerHelper.getInt(data[28], data[29], data[30], data[31]);
/*     */     
/* 127 */     boolean description = (options & 0x14) != 0;
/* 128 */     int startpos = 32;
/* 129 */     int descbytes = 0;
/* 130 */     if (description)
/*     */     {
/* 132 */       int descchars = IntegerHelper.getInt(data[startpos], data[(startpos + 1)], data[(startpos + 2)], data[(startpos + 3)]);
/*     */       
/*     */ 
/* 135 */       descbytes = descchars * 2 + 4;
/*     */     }
/*     */     
/* 138 */     startpos += descbytes;
/*     */     
/* 140 */     boolean targetFrame = (options & 0x80) != 0;
/* 141 */     int targetbytes = 0;
/* 142 */     if (targetFrame)
/*     */     {
/* 144 */       int targetchars = IntegerHelper.getInt(data[startpos], data[(startpos + 1)], data[(startpos + 2)], data[(startpos + 3)]);
/*     */       
/*     */ 
/* 147 */       targetbytes = targetchars * 2 + 4;
/*     */     }
/*     */     
/* 150 */     startpos += targetbytes;
/*     */     
/*     */ 
/* 153 */     if ((options & 0x3) == 3)
/*     */     {
/* 155 */       this.linkType = urlLink;
/*     */       
/*     */ 
/* 158 */       if (data[startpos] == 3)
/*     */       {
/* 160 */         this.linkType = fileLink;
/*     */       }
/*     */     }
/* 163 */     else if ((options & 0x1) != 0)
/*     */     {
/* 165 */       this.linkType = fileLink;
/*     */       
/* 167 */       if (data[startpos] == -32)
/*     */       {
/* 169 */         this.linkType = urlLink;
/*     */       }
/*     */     }
/* 172 */     else if ((options & 0x8) != 0)
/*     */     {
/* 174 */       this.linkType = workbookLink;
/*     */     }
/*     */     
/*     */ 
/* 178 */     if (this.linkType == urlLink)
/*     */     {
/* 180 */       String urlString = null;
/*     */       try
/*     */       {
/* 183 */         startpos += 16;
/*     */         
/*     */ 
/* 186 */         int bytes = IntegerHelper.getInt(data[startpos], data[(startpos + 1)], data[(startpos + 2)], data[(startpos + 3)]);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 191 */         urlString = StringHelper.getUnicodeString(data, bytes / 2 - 1, startpos + 4);
/*     */         
/* 193 */         this.url = new URL(urlString);
/*     */       }
/*     */       catch (MalformedURLException e)
/*     */       {
/* 197 */         logger.warn("URL " + urlString + " is malformed.  Trying a file");
/*     */         try
/*     */         {
/* 200 */           this.linkType = fileLink;
/* 201 */           this.file = new File(urlString);
/*     */         }
/*     */         catch (Exception e3)
/*     */         {
/* 205 */           logger.warn("Cannot set to file.  Setting a default URL");
/*     */           
/*     */ 
/*     */           try
/*     */           {
/* 210 */             this.linkType = urlLink;
/* 211 */             this.url = new URL("http://www.andykhan.com/jexcelapi/index.html");
/*     */ 
/*     */           }
/*     */           catch (MalformedURLException e2) {}
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 221 */         StringBuffer sb1 = new StringBuffer();
/* 222 */         StringBuffer sb2 = new StringBuffer();
/* 223 */         CellReferenceHelper.getCellReference(this.firstColumn, this.firstRow, sb1);
/* 224 */         CellReferenceHelper.getCellReference(this.lastColumn, this.lastRow, sb2);
/* 225 */         sb1.insert(0, "Exception when parsing URL ");
/* 226 */         sb1.append('"').append(sb2.toString()).append("\".  Using default.");
/* 227 */         logger.warn(sb1, e);
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 232 */           this.url = new URL("http://www.andykhan.com/jexcelapi/index.html");
/*     */ 
/*     */         }
/*     */         catch (MalformedURLException e2) {}
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 240 */     else if (this.linkType == fileLink)
/*     */     {
/*     */       try
/*     */       {
/* 244 */         startpos += 16;
/*     */         
/*     */ 
/*     */ 
/* 248 */         int upLevelCount = IntegerHelper.getInt(data[startpos], data[(startpos + 1)]);
/*     */         
/* 250 */         int chars = IntegerHelper.getInt(data[(startpos + 2)], data[(startpos + 3)], data[(startpos + 4)], data[(startpos + 5)]);
/*     */         
/*     */ 
/*     */ 
/* 254 */         String fileName = StringHelper.getString(data, chars - 1, startpos + 6, ws);
/*     */         
/*     */ 
/* 257 */         StringBuffer sb = new StringBuffer();
/*     */         
/* 259 */         for (int i = 0; i < upLevelCount; i++)
/*     */         {
/* 261 */           sb.append("..\\");
/*     */         }
/*     */         
/* 264 */         sb.append(fileName);
/*     */         
/* 266 */         this.file = new File(sb.toString());
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 270 */         logger.warn("Exception when parsing file " + e.getClass().getName() + ".");
/*     */         
/* 272 */         this.file = new File(".");
/*     */       }
/*     */     }
/* 275 */     else if (this.linkType == workbookLink)
/*     */     {
/* 277 */       int chars = IntegerHelper.getInt(data[32], data[33], data[34], data[35]);
/* 278 */       this.location = StringHelper.getUnicodeString(data, chars - 1, 36);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 283 */       logger.warn("Cannot determine link type");
/* 284 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFile()
/*     */   {
/* 295 */     return this.linkType == fileLink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isURL()
/*     */   {
/* 305 */     return this.linkType == urlLink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLocation()
/*     */   {
/* 315 */     return this.linkType == workbookLink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 325 */     return this.firstRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 335 */     return this.firstColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastRow()
/*     */   {
/* 345 */     return this.lastRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastColumn()
/*     */   {
/* 355 */     return this.lastColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURL()
/*     */   {
/* 365 */     return this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getFile()
/*     */   {
/* 375 */     return this.file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Record getRecord()
/*     */   {
/* 385 */     return super.getRecord();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Range getRange()
/*     */   {
/* 397 */     return this.range;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocation()
/*     */   {
/* 407 */     return this.location;
/*     */   }
/*     */   
/*     */   private static class LinkType {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\HyperlinkRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */