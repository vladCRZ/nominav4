/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LabelRecord
/*     */   extends CellValue
/*     */   implements LabelCell
/*     */ {
/*     */   private int length;
/*     */   private String string;
/*  48 */   public static Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LabelRecord(Record t, FormattingRecords fr, SheetImpl si, WorkbookSettings ws)
/*     */   {
/*  61 */     super(t, fr, si);
/*  62 */     byte[] data = getRecord().getData();
/*  63 */     this.length = IntegerHelper.getInt(data[6], data[7]);
/*     */     
/*  65 */     if (data[8] == 0)
/*     */     {
/*  67 */       this.string = StringHelper.getString(data, this.length, 9, ws);
/*     */     }
/*     */     else
/*     */     {
/*  71 */       this.string = StringHelper.getUnicodeString(data, this.length, 9);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LabelRecord(Record t, FormattingRecords fr, SheetImpl si, WorkbookSettings ws, Biff7 dummy)
/*     */   {
/*  87 */     super(t, fr, si);
/*  88 */     byte[] data = getRecord().getData();
/*  89 */     this.length = IntegerHelper.getInt(data[6], data[7]);
/*     */     
/*  91 */     this.string = StringHelper.getString(data, this.length, 8, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/* 101 */     return this.string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 111 */     return this.string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 121 */     return CellType.LABEL;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\LabelRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */