/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.CellType;
/*    */ import jxl.LabelCell;
/*    */ import jxl.biff.FormattingRecords;
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LabelSSTRecord
/*    */   extends CellValue
/*    */   implements LabelCell
/*    */ {
/*    */   private int index;
/*    */   private String string;
/*    */   
/*    */   public LabelSSTRecord(Record t, SSTRecord stringTable, FormattingRecords fr, SheetImpl si)
/*    */   {
/* 53 */     super(t, fr, si);
/* 54 */     byte[] data = getRecord().getData();
/* 55 */     this.index = IntegerHelper.getInt(data[6], data[7], data[8], data[9]);
/* 56 */     this.string = stringTable.getString(this.index);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getString()
/*    */   {
/* 66 */     return this.string;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getContents()
/*    */   {
/* 76 */     return this.string;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CellType getType()
/*    */   {
/* 86 */     return CellType.LABEL;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\LabelSSTRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */