/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.Range;
/*    */ import jxl.Sheet;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.SheetRangeImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergedCellsRecord
/*    */   extends RecordData
/*    */ {
/*    */   private Range[] ranges;
/*    */   
/*    */   MergedCellsRecord(Record t, Sheet s)
/*    */   {
/* 46 */     super(t);
/*    */     
/* 48 */     byte[] data = getRecord().getData();
/*    */     
/* 50 */     int numRanges = IntegerHelper.getInt(data[0], data[1]);
/*    */     
/* 52 */     this.ranges = new Range[numRanges];
/*    */     
/* 54 */     int pos = 2;
/* 55 */     int firstRow = 0;
/* 56 */     int lastRow = 0;
/* 57 */     int firstCol = 0;
/* 58 */     int lastCol = 0;
/*    */     
/* 60 */     for (int i = 0; i < numRanges; i++)
/*    */     {
/* 62 */       firstRow = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 63 */       lastRow = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)]);
/* 64 */       firstCol = IntegerHelper.getInt(data[(pos + 4)], data[(pos + 5)]);
/* 65 */       lastCol = IntegerHelper.getInt(data[(pos + 6)], data[(pos + 7)]);
/*    */       
/* 67 */       this.ranges[i] = new SheetRangeImpl(s, firstCol, firstRow, lastCol, lastRow);
/*    */       
/*    */ 
/* 70 */       pos += 8;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Range[] getRanges()
/*    */   {
/* 81 */     return this.ranges;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\MergedCellsRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */