/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MulBlankRecord
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(MulBlankRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int colFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int colLast;
/*     */   
/*     */ 
/*     */ 
/*     */   private int numblanks;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] xfIndices;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MulBlankRecord(Record t)
/*     */   {
/*  65 */     super(t);
/*  66 */     byte[] data = getRecord().getData();
/*  67 */     int length = getRecord().getLength();
/*  68 */     this.row = IntegerHelper.getInt(data[0], data[1]);
/*  69 */     this.colFirst = IntegerHelper.getInt(data[2], data[3]);
/*  70 */     this.colLast = IntegerHelper.getInt(data[(length - 2)], data[(length - 1)]);
/*  71 */     this.numblanks = (this.colLast - this.colFirst + 1);
/*  72 */     this.xfIndices = new int[this.numblanks];
/*     */     
/*  74 */     readBlanks(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readBlanks(byte[] data)
/*     */   {
/*  84 */     int pos = 4;
/*  85 */     for (int i = 0; i < this.numblanks; i++)
/*     */     {
/*  87 */       this.xfIndices[i] = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  88 */       pos += 2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/*  99 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstColumn()
/*     */   {
/* 109 */     return this.colFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfColumns()
/*     */   {
/* 119 */     return this.numblanks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXFIndex(int index)
/*     */   {
/* 129 */     return this.xfIndices[index];
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\MulBlankRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */