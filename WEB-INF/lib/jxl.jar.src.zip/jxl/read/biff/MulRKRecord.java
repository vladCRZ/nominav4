/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MulRKRecord
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(MulRKRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int colFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int colLast;
/*     */   
/*     */ 
/*     */ 
/*     */   private int numrks;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] rknumbers;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] xfIndices;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MulRKRecord(Record t)
/*     */   {
/*  69 */     super(t);
/*  70 */     byte[] data = getRecord().getData();
/*  71 */     int length = getRecord().getLength();
/*  72 */     this.row = IntegerHelper.getInt(data[0], data[1]);
/*  73 */     this.colFirst = IntegerHelper.getInt(data[2], data[3]);
/*  74 */     this.colLast = IntegerHelper.getInt(data[(length - 2)], data[(length - 1)]);
/*  75 */     this.numrks = (this.colLast - this.colFirst + 1);
/*  76 */     this.rknumbers = new int[this.numrks];
/*  77 */     this.xfIndices = new int[this.numrks];
/*     */     
/*  79 */     readRks(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readRks(byte[] data)
/*     */   {
/*  89 */     int pos = 4;
/*     */     
/*  91 */     for (int i = 0; i < this.numrks; i++)
/*     */     {
/*  93 */       this.xfIndices[i] = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/*  94 */       int rk = IntegerHelper.getInt(data[(pos + 2)], data[(pos + 3)], data[(pos + 4)], data[(pos + 5)]);
/*     */       
/*  96 */       this.rknumbers[i] = rk;
/*  97 */       pos += 6;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 108 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstColumn()
/*     */   {
/* 118 */     return this.colFirst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfColumns()
/*     */   {
/* 128 */     return this.numrks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRKNumber(int index)
/*     */   {
/* 139 */     return this.rknumbers[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXFIndex(int index)
/*     */   {
/* 150 */     return this.xfIndices[index];
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\MulRKRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */