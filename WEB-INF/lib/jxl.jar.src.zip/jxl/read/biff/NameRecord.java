/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.BuiltInName;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameRecord
/*     */   extends RecordData
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(NameRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private BuiltInName builtInName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int index;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private int sheetRef = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isbiff8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  74 */   public static Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int commandMacro = 12;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int builtIn = 32;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int cellReference = 58;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int areaReference = 59;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int subExpression = 41;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int union = 16;
/*     */   
/*     */ 
/*     */ 
/*     */   private ArrayList ranges;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public class NameRange
/*     */   {
/*     */     private int columnFirst;
/*     */     
/*     */ 
/*     */     private int rowFirst;
/*     */     
/*     */ 
/*     */     private int columnLast;
/*     */     
/*     */ 
/*     */     private int rowLast;
/*     */     
/*     */ 
/*     */     private int externalSheet;
/*     */     
/*     */ 
/*     */ 
/*     */     NameRange(int s1, int c1, int r1, int c2, int r2)
/*     */     {
/* 127 */       this.columnFirst = c1;
/* 128 */       this.rowFirst = r1;
/* 129 */       this.columnLast = c2;
/* 130 */       this.rowLast = r2;
/* 131 */       this.externalSheet = s1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getFirstColumn()
/*     */     {
/* 141 */       return this.columnFirst;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getFirstRow()
/*     */     {
/* 151 */       return this.rowFirst;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getLastColumn()
/*     */     {
/* 161 */       return this.columnLast;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getLastRow()
/*     */     {
/* 171 */       return this.rowLast;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getExternalSheet()
/*     */     {
/* 181 */       return this.externalSheet;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NameRecord(Record t, WorkbookSettings ws, int ind)
/*     */   {
/* 199 */     super(t);
/* 200 */     this.index = ind;
/* 201 */     this.isbiff8 = true;
/*     */     
/*     */     try
/*     */     {
/* 205 */       this.ranges = new ArrayList();
/*     */       
/* 207 */       byte[] data = getRecord().getData();
/* 208 */       int option = IntegerHelper.getInt(data[0], data[1]);
/* 209 */       int length = data[3];
/* 210 */       this.sheetRef = IntegerHelper.getInt(data[8], data[9]);
/*     */       
/* 212 */       if ((option & 0x20) != 0)
/*     */       {
/* 214 */         this.builtInName = BuiltInName.getBuiltInName(data[15]);
/*     */       }
/*     */       else
/*     */       {
/* 218 */         this.name = StringHelper.getString(data, length, 15, ws);
/*     */       }
/*     */       
/* 221 */       if ((option & 0xC) != 0)
/*     */       {
/*     */ 
/* 224 */         return;
/*     */       }
/*     */       
/* 227 */       int pos = length + 15;
/*     */       
/* 229 */       if (data[pos] == 58)
/*     */       {
/* 231 */         int sheet = IntegerHelper.getInt(data[(pos + 1)], data[(pos + 2)]);
/* 232 */         int row = IntegerHelper.getInt(data[(pos + 3)], data[(pos + 4)]);
/* 233 */         int columnMask = IntegerHelper.getInt(data[(pos + 5)], data[(pos + 6)]);
/* 234 */         int column = columnMask & 0xFF;
/*     */         
/*     */ 
/* 237 */         Assert.verify((columnMask & 0xC0000) == 0);
/*     */         
/* 239 */         NameRange r = new NameRange(sheet, column, row, column, row);
/* 240 */         this.ranges.add(r);
/*     */       }
/* 242 */       else if (data[pos] == 59)
/*     */       {
/* 244 */         int sheet1 = 0;
/* 245 */         int r1 = 0;
/* 246 */         int columnMask = 0;
/* 247 */         int c1 = 0;
/* 248 */         int r2 = 0;
/* 249 */         int c2 = 0;
/* 250 */         NameRange range = null;
/*     */         
/* 252 */         while (pos < data.length)
/*     */         {
/* 254 */           sheet1 = IntegerHelper.getInt(data[(pos + 1)], data[(pos + 2)]);
/* 255 */           r1 = IntegerHelper.getInt(data[(pos + 3)], data[(pos + 4)]);
/* 256 */           r2 = IntegerHelper.getInt(data[(pos + 5)], data[(pos + 6)]);
/*     */           
/* 258 */           columnMask = IntegerHelper.getInt(data[(pos + 7)], data[(pos + 8)]);
/* 259 */           c1 = columnMask & 0xFF;
/*     */           
/*     */ 
/* 262 */           Assert.verify((columnMask & 0xC0000) == 0);
/*     */           
/* 264 */           columnMask = IntegerHelper.getInt(data[(pos + 9)], data[(pos + 10)]);
/* 265 */           c2 = columnMask & 0xFF;
/*     */           
/*     */ 
/* 268 */           Assert.verify((columnMask & 0xC0000) == 0);
/*     */           
/* 270 */           range = new NameRange(sheet1, c1, r1, c2, r2);
/* 271 */           this.ranges.add(range);
/*     */           
/* 273 */           pos += 11;
/*     */         }
/*     */       }
/* 276 */       else if (data[pos] == 41)
/*     */       {
/* 278 */         int sheet1 = 0;
/* 279 */         int r1 = 0;
/* 280 */         int columnMask = 0;
/* 281 */         int c1 = 0;
/* 282 */         int r2 = 0;
/* 283 */         int c2 = 0;
/* 284 */         NameRange range = null;
/*     */         
/*     */ 
/* 287 */         if ((pos < data.length) && (data[pos] != 58) && (data[pos] != 59))
/*     */         {
/*     */ 
/*     */ 
/* 291 */           if (data[pos] == 41)
/*     */           {
/* 293 */             pos += 3;
/*     */           }
/* 295 */           else if (data[pos] == 16)
/*     */           {
/* 297 */             pos++;
/*     */           }
/*     */         }
/*     */         
/* 301 */         while (pos < data.length)
/*     */         {
/* 303 */           sheet1 = IntegerHelper.getInt(data[(pos + 1)], data[(pos + 2)]);
/* 304 */           r1 = IntegerHelper.getInt(data[(pos + 3)], data[(pos + 4)]);
/* 305 */           r2 = IntegerHelper.getInt(data[(pos + 5)], data[(pos + 6)]);
/*     */           
/* 307 */           columnMask = IntegerHelper.getInt(data[(pos + 7)], data[(pos + 8)]);
/* 308 */           c1 = columnMask & 0xFF;
/*     */           
/*     */ 
/* 311 */           Assert.verify((columnMask & 0xC0000) == 0);
/*     */           
/* 313 */           columnMask = IntegerHelper.getInt(data[(pos + 9)], data[(pos + 10)]);
/* 314 */           c2 = columnMask & 0xFF;
/*     */           
/*     */ 
/* 317 */           Assert.verify((columnMask & 0xC0000) == 0);
/*     */           
/* 319 */           range = new NameRange(sheet1, c1, r1, c2, r2);
/* 320 */           this.ranges.add(range);
/*     */           
/* 322 */           pos += 11;
/*     */           
/*     */ 
/* 325 */           if ((pos < data.length) && (data[pos] != 58) && (data[pos] != 59))
/*     */           {
/*     */ 
/*     */ 
/* 329 */             if (data[pos] == 41)
/*     */             {
/* 331 */               pos += 3;
/*     */             }
/* 333 */             else if (data[pos] == 16)
/*     */             {
/* 335 */               pos++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 342 */         String n = this.name != null ? this.name : this.builtInName.getName();
/* 343 */         logger.warn("Cannot read name ranges for " + n + " - setting to empty");
/*     */         
/* 345 */         NameRange range = new NameRange(0, 0, 0, 0, 0);
/* 346 */         this.ranges.add(range);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (Throwable t1)
/*     */     {
/*     */ 
/* 354 */       logger.warn("Cannot read name");
/* 355 */       this.name = "ERROR";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NameRecord(Record t, WorkbookSettings ws, int ind, Biff7 dummy)
/*     */   {
/* 369 */     super(t);
/* 370 */     this.index = ind;
/* 371 */     this.isbiff8 = false;
/*     */     
/*     */     try
/*     */     {
/* 375 */       this.ranges = new ArrayList();
/* 376 */       byte[] data = getRecord().getData();
/* 377 */       int length = data[3];
/* 378 */       this.sheetRef = IntegerHelper.getInt(data[8], data[9]);
/* 379 */       this.name = StringHelper.getString(data, length, 14, ws);
/*     */       
/* 381 */       int pos = length + 14;
/*     */       
/* 383 */       if (pos >= data.length)
/*     */       {
/*     */ 
/* 386 */         return;
/*     */       }
/*     */       
/* 389 */       if (data[pos] == 58)
/*     */       {
/* 391 */         int sheet = IntegerHelper.getInt(data[(pos + 11)], data[(pos + 12)]);
/* 392 */         int row = IntegerHelper.getInt(data[(pos + 15)], data[(pos + 16)]);
/* 393 */         int column = data[(pos + 17)];
/*     */         
/* 395 */         NameRange r = new NameRange(sheet, column, row, column, row);
/* 396 */         this.ranges.add(r);
/*     */       }
/* 398 */       else if (data[pos] == 59)
/*     */       {
/* 400 */         int sheet1 = 0;
/* 401 */         int r1 = 0;
/* 402 */         int c1 = 0;
/* 403 */         int r2 = 0;
/* 404 */         int c2 = 0;
/* 405 */         NameRange range = null;
/*     */         
/* 407 */         while (pos < data.length)
/*     */         {
/* 409 */           sheet1 = IntegerHelper.getInt(data[(pos + 11)], data[(pos + 12)]);
/* 410 */           r1 = IntegerHelper.getInt(data[(pos + 15)], data[(pos + 16)]);
/* 411 */           r2 = IntegerHelper.getInt(data[(pos + 17)], data[(pos + 18)]);
/*     */           
/* 413 */           c1 = data[(pos + 19)];
/* 414 */           c2 = data[(pos + 20)];
/*     */           
/* 416 */           range = new NameRange(sheet1, c1, r1, c2, r2);
/* 417 */           this.ranges.add(range);
/*     */           
/* 419 */           pos += 21;
/*     */         }
/*     */       }
/* 422 */       else if (data[pos] == 41)
/*     */       {
/* 424 */         int sheet1 = 0;
/* 425 */         int sheet2 = 0;
/* 426 */         int r1 = 0;
/* 427 */         int c1 = 0;
/* 428 */         int r2 = 0;
/* 429 */         int c2 = 0;
/* 430 */         NameRange range = null;
/*     */         
/*     */ 
/* 433 */         if ((pos < data.length) && (data[pos] != 58) && (data[pos] != 59))
/*     */         {
/*     */ 
/*     */ 
/* 437 */           if (data[pos] == 41)
/*     */           {
/* 439 */             pos += 3;
/*     */           }
/* 441 */           else if (data[pos] == 16)
/*     */           {
/* 443 */             pos++;
/*     */           }
/*     */         }
/*     */         
/* 447 */         while (pos < data.length)
/*     */         {
/* 449 */           sheet1 = IntegerHelper.getInt(data[(pos + 11)], data[(pos + 12)]);
/* 450 */           r1 = IntegerHelper.getInt(data[(pos + 15)], data[(pos + 16)]);
/* 451 */           r2 = IntegerHelper.getInt(data[(pos + 17)], data[(pos + 18)]);
/*     */           
/* 453 */           c1 = data[(pos + 19)];
/* 454 */           c2 = data[(pos + 20)];
/*     */           
/* 456 */           range = new NameRange(sheet1, c1, r1, c2, r2);
/* 457 */           this.ranges.add(range);
/*     */           
/* 459 */           pos += 21;
/*     */           
/*     */ 
/* 462 */           if ((pos < data.length) && (data[pos] != 58) && (data[pos] != 59))
/*     */           {
/*     */ 
/*     */ 
/* 466 */             if (data[pos] == 41)
/*     */             {
/* 468 */               pos += 3;
/*     */             }
/* 470 */             else if (data[pos] == 16)
/*     */             {
/* 472 */               pos++;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (Throwable t1)
/*     */     {
/* 483 */       logger.warn("Cannot read name.");
/* 484 */       this.name = "ERROR";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 495 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BuiltInName getBuiltInName()
/*     */   {
/* 505 */     return this.builtInName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRange[] getRanges()
/*     */   {
/* 516 */     NameRange[] nr = new NameRange[this.ranges.size()];
/* 517 */     return (NameRange[])this.ranges.toArray(nr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getIndex()
/*     */   {
/* 527 */     return this.index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSheetRef()
/*     */   {
/* 538 */     return this.sheetRef;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSheetRef(int i)
/*     */   {
/* 547 */     this.sheetRef = i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 557 */     return getRecord().getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBiff8()
/*     */   {
/* 567 */     return this.isbiff8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isGlobal()
/*     */   {
/* 577 */     return this.sheetRef == 0;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\NameRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */