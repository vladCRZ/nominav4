/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NineteenFourRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean nineteenFour;
/*    */   
/*    */   public NineteenFourRecord(Record t)
/*    */   {
/* 41 */     super(t);
/*    */     
/* 43 */     byte[] data = getRecord().getData();
/*    */     
/* 45 */     this.nineteenFour = (data[0] == 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean is1904()
/*    */   {
/* 58 */     return this.nineteenFour;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\NineteenFourRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */