/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.NumberFormulaCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NumberFormulaRecord
/*     */   extends CellValue
/*     */   implements NumberCell, FormulaData, NumberFormulaCell
/*     */ {
/*  47 */   private static Logger logger = Logger.getLogger(NumberFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private NumberFormat format;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private static final DecimalFormat defaultFormat = new DecimalFormat("#.###");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formulaString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet externalSheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods nameTable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumberFormulaRecord(Record t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/*  98 */     super(t, fr, si);
/*     */     
/* 100 */     this.externalSheet = es;
/* 101 */     this.nameTable = nt;
/* 102 */     this.data = getRecord().getData();
/*     */     
/* 104 */     this.format = fr.getNumberFormat(getXFIndex());
/*     */     
/* 106 */     if (this.format == null)
/*     */     {
/* 108 */       this.format = defaultFormat;
/*     */     }
/*     */     
/* 111 */     this.value = DoubleHelper.getIEEEDouble(this.data, 6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 121 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 131 */     return !Double.isNaN(this.value) ? this.format.format(this.value) : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 141 */     return CellType.NUMBER_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 152 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 154 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/* 158 */     byte[] d = new byte[this.data.length - 6];
/* 159 */     System.arraycopy(this.data, 6, d, 0, this.data.length - 6);
/*     */     
/* 161 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 172 */     if (this.formulaString == null)
/*     */     {
/* 174 */       byte[] tokens = new byte[this.data.length - 22];
/* 175 */       System.arraycopy(this.data, 22, tokens, 0, tokens.length);
/* 176 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */       
/*     */ 
/* 179 */       fp.parse();
/* 180 */       this.formulaString = fp.getFormula();
/*     */     }
/*     */     
/* 183 */     return this.formulaString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumberFormat getNumberFormat()
/*     */   {
/* 194 */     return this.format;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\NumberFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */