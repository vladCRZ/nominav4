/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PasswordRecord
/*    */   extends RecordData
/*    */ {
/*    */   private String password;
/*    */   private int passwordHash;
/*    */   
/*    */   public PasswordRecord(Record t)
/*    */   {
/* 47 */     super(Type.PASSWORD);
/*    */     
/* 49 */     byte[] data = t.getData();
/* 50 */     this.passwordHash = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getPasswordHash()
/*    */   {
/* 60 */     return this.passwordHash;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\PasswordRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */