/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrintHeadersRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean printHeaders;
/*    */   
/*    */   public PrintHeadersRecord(Record ph)
/*    */   {
/* 41 */     super(ph);
/* 42 */     byte[] data = ph.getData();
/*    */     
/* 44 */     this.printHeaders = (data[0] == 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getPrintHeaders()
/*    */   {
/* 54 */     return this.printHeaders;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\PrintHeadersRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */