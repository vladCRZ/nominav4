/*    */ package jxl.read.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RKHelper
/*    */ {
/*    */   public static double getDouble(int rk)
/*    */   {
/* 42 */     if ((rk & 0x2) != 0)
/*    */     {
/* 44 */       int intval = rk >> 2;
/*    */       
/* 46 */       double value = intval;
/* 47 */       if ((rk & 0x1) != 0)
/*    */       {
/* 49 */         value /= 100.0D;
/*    */       }
/*    */       
/* 52 */       return value;
/*    */     }
/*    */     
/*    */ 
/* 56 */     long valbits = rk & 0xFFFFFFFC;
/* 57 */     valbits <<= 32;
/* 58 */     double value = Double.longBitsToDouble(valbits);
/*    */     
/* 60 */     if ((rk & 0x1) != 0)
/*    */     {
/* 62 */       value /= 100.0D;
/*    */     }
/*    */     
/* 65 */     return value;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\RKHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */