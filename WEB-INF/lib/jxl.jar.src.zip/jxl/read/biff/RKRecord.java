/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RKRecord
/*     */   extends CellValue
/*     */   implements NumberCell
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(RKRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private NumberFormat format;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private static DecimalFormat defaultFormat = new DecimalFormat("#.###");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RKRecord(Record t, FormattingRecords fr, SheetImpl si)
/*     */   {
/*  66 */     super(t, fr, si);
/*  67 */     byte[] data = getRecord().getData();
/*  68 */     int rknum = IntegerHelper.getInt(data[6], data[7], data[8], data[9]);
/*  69 */     this.value = RKHelper.getDouble(rknum);
/*     */     
/*     */ 
/*  72 */     this.format = fr.getNumberFormat(getXFIndex());
/*  73 */     if (this.format == null)
/*     */     {
/*  75 */       this.format = defaultFormat;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/*  86 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/*  96 */     return this.format.format(this.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 106 */     return CellType.NUMBER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumberFormat getNumberFormat()
/*     */   {
/* 117 */     return this.format;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\RKRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */