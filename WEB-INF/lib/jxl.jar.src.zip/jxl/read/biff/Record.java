/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Record
/*     */ {
/*  38 */   private static final Logger logger = Logger.getLogger(Record.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int code;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int dataPos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private File file;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */   private ArrayList continueRecords;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Record(byte[] d, int offset, File f)
/*     */   {
/*  79 */     this.code = IntegerHelper.getInt(d[offset], d[(offset + 1)]);
/*  80 */     this.length = IntegerHelper.getInt(d[(offset + 2)], d[(offset + 3)]);
/*  81 */     this.file = f;
/*  82 */     this.file.skip(4);
/*  83 */     this.dataPos = f.getPos();
/*  84 */     this.file.skip(this.length);
/*  85 */     this.type = Type.getType(this.code);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getType()
/*     */   {
/*  95 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 105 */     return this.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 115 */     if (this.data == null)
/*     */     {
/* 117 */       this.data = this.file.read(this.dataPos, this.length);
/*     */     }
/*     */     
/*     */ 
/* 121 */     if (this.continueRecords != null)
/*     */     {
/* 123 */       int size = 0;
/* 124 */       byte[][] contData = new byte[this.continueRecords.size()][];
/* 125 */       for (int i = 0; i < this.continueRecords.size(); i++)
/*     */       {
/* 127 */         Record r = (Record)this.continueRecords.get(i);
/* 128 */         contData[i] = r.getData();
/* 129 */         byte[] d2 = contData[i];
/* 130 */         size += d2.length;
/*     */       }
/*     */       
/* 133 */       byte[] d3 = new byte[this.data.length + size];
/* 134 */       System.arraycopy(this.data, 0, d3, 0, this.data.length);
/* 135 */       int pos = this.data.length;
/* 136 */       for (int i = 0; i < contData.length; i++)
/*     */       {
/* 138 */         byte[] d2 = contData[i];
/* 139 */         System.arraycopy(d2, 0, d3, pos, d2.length);
/* 140 */         pos += d2.length;
/*     */       }
/*     */       
/* 143 */       this.data = d3;
/*     */     }
/*     */     
/* 146 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCode()
/*     */   {
/* 156 */     return this.code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setType(Type t)
/*     */   {
/* 167 */     this.type = t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addContinueRecord(Record d)
/*     */   {
/* 177 */     if (this.continueRecords == null)
/*     */     {
/* 179 */       this.continueRecords = new ArrayList();
/*     */     }
/*     */     
/* 182 */     this.continueRecords.add(d);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\Record.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */