/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RefreshAllRecord
/*    */   extends RecordData
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(RefreshAllRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean refreshAll;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RefreshAllRecord(Record t)
/*    */   {
/* 48 */     super(t);
/* 49 */     byte[] data = t.getData();
/* 50 */     int mode = IntegerHelper.getInt(data[0], data[1]);
/* 51 */     this.refreshAll = (mode == 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getRefreshAll()
/*    */   {
/* 61 */     return this.refreshAll;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\RefreshAllRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */