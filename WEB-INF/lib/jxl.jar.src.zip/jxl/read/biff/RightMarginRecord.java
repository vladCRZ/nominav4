/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RightMarginRecord
/*    */   extends MarginRecord
/*    */ {
/*    */   RightMarginRecord(Record r)
/*    */   {
/* 35 */     super(Type.RIGHTMARGIN, r);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\RightMarginRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */