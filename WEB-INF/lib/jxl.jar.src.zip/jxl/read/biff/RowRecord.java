/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RowRecord
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(RowRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean collapsed;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean defaultFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean matchesDefFontHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int xfIndex;
/*     */   
/*     */ 
/*     */ 
/*     */   private int outlineLevel;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean groupStart;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int defaultHeightIndicator = 255;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   RowRecord(Record t)
/*     */   {
/*  84 */     super(t);
/*     */     
/*  86 */     byte[] data = getRecord().getData();
/*  87 */     this.rowNumber = IntegerHelper.getInt(data[0], data[1]);
/*  88 */     this.rowHeight = IntegerHelper.getInt(data[6], data[7]);
/*     */     
/*  90 */     int options = IntegerHelper.getInt(data[12], data[13], data[14], data[15]);
/*     */     
/*  92 */     this.outlineLevel = (options & 0x7);
/*  93 */     this.groupStart = ((options & 0x10) != 0);
/*  94 */     this.collapsed = ((options & 0x20) != 0);
/*  95 */     this.matchesDefFontHeight = ((options & 0x40) == 0);
/*  96 */     this.defaultFormat = ((options & 0x80) != 0);
/*  97 */     this.xfIndex = ((options & 0xFFF0000) >> 16);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isDefaultHeight()
/*     */   {
/* 107 */     return this.rowHeight == 255;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesDefaultFontHeight()
/*     */   {
/* 117 */     return this.matchesDefFontHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowNumber()
/*     */   {
/* 127 */     return this.rowNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOutlineLevel()
/*     */   {
/* 137 */     return this.outlineLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getGroupStart()
/*     */   {
/* 147 */     return this.groupStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowHeight()
/*     */   {
/* 157 */     return this.rowHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCollapsed()
/*     */   {
/* 167 */     return this.collapsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXFIndex()
/*     */   {
/* 177 */     return this.xfIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasDefaultFormat()
/*     */   {
/* 187 */     return this.defaultFormat;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\RowRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */