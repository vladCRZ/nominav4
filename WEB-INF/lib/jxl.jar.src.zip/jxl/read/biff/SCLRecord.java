/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SCLRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int numerator;
/*    */   private int denominator;
/*    */   
/*    */   protected SCLRecord(Record r)
/*    */   {
/* 47 */     super(Type.SCL);
/*    */     
/* 49 */     byte[] data = r.getData();
/*    */     
/* 51 */     this.numerator = IntegerHelper.getInt(data[0], data[1]);
/* 52 */     this.denominator = IntegerHelper.getInt(data[2], data[3]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getZoomFactor()
/*    */   {
/* 62 */     return this.numerator * 100 / this.denominator;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SCLRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */