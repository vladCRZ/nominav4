/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.common.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSTRecord
/*     */   extends RecordData
/*     */ {
/*     */   private int totalStrings;
/*     */   private int uniqueStrings;
/*     */   private String[] strings;
/*     */   private int[] continuationBreaks;
/*     */   
/*     */   public SSTRecord(Record t, Record[] continuations, WorkbookSettings ws)
/*     */   {
/*  82 */     super(t);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     int totalRecordLength = 0;
/*     */     
/*  90 */     for (int i = 0; i < continuations.length; i++)
/*     */     {
/*  92 */       totalRecordLength += continuations[i].getLength();
/*     */     }
/*  94 */     totalRecordLength += getRecord().getLength();
/*     */     
/*  96 */     byte[] data = new byte[totalRecordLength];
/*     */     
/*     */ 
/*  99 */     int pos = 0;
/* 100 */     System.arraycopy(getRecord().getData(), 0, data, 0, getRecord().getLength());
/*     */     
/* 102 */     pos += getRecord().getLength();
/*     */     
/*     */ 
/* 105 */     this.continuationBreaks = new int[continuations.length];
/* 106 */     Record r = null;
/* 107 */     for (int i = 0; i < continuations.length; i++)
/*     */     {
/* 109 */       r = continuations[i];
/* 110 */       System.arraycopy(r.getData(), 0, data, pos, r.getLength());
/*     */       
/*     */ 
/* 113 */       this.continuationBreaks[i] = pos;
/* 114 */       pos += r.getLength();
/*     */     }
/*     */     
/* 117 */     this.totalStrings = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/*     */     
/* 119 */     this.uniqueStrings = IntegerHelper.getInt(data[4], data[5], data[6], data[7]);
/*     */     
/*     */ 
/* 122 */     this.strings = new String[this.uniqueStrings];
/* 123 */     readStrings(data, 8, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readStrings(byte[] data, int offset, WorkbookSettings ws)
/*     */   {
/* 135 */     int pos = offset;
/*     */     
/*     */ 
/* 138 */     String s = null;
/* 139 */     boolean asciiEncoding = false;
/* 140 */     boolean richString = false;
/* 141 */     boolean extendedString = false;
/* 142 */     int formattingRuns = 0;
/* 143 */     int extendedRunLength = 0;
/*     */     
/* 145 */     for (int i = 0; i < this.uniqueStrings; i++)
/*     */     {
/*     */ 
/* 148 */       int numChars = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 149 */       pos += 2;
/* 150 */       byte optionFlags = data[pos];
/* 151 */       pos++;
/*     */       
/*     */ 
/* 154 */       extendedString = (optionFlags & 0x4) != 0;
/*     */       
/*     */ 
/* 157 */       richString = (optionFlags & 0x8) != 0;
/*     */       
/* 159 */       if (richString)
/*     */       {
/*     */ 
/* 162 */         formattingRuns = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 163 */         pos += 2;
/*     */       }
/*     */       
/* 166 */       if (extendedString)
/*     */       {
/*     */ 
/* 169 */         extendedRunLength = IntegerHelper.getInt(data[pos], data[(pos + 1)], data[(pos + 2)], data[(pos + 3)]);
/*     */         
/* 171 */         pos += 4;
/*     */       }
/*     */       
/*     */ 
/* 175 */       asciiEncoding = (optionFlags & 0x1) == 0;
/*     */       
/* 177 */       ByteArrayHolder bah = new ByteArrayHolder(null);
/* 178 */       BooleanHolder bh = new BooleanHolder(null);
/* 179 */       bh.value = asciiEncoding;
/* 180 */       pos += getChars(data, bah, pos, bh, numChars);
/* 181 */       asciiEncoding = bh.value;
/*     */       
/* 183 */       if (asciiEncoding)
/*     */       {
/* 185 */         s = StringHelper.getString(bah.bytes, numChars, 0, ws);
/*     */       }
/*     */       else
/*     */       {
/* 189 */         s = StringHelper.getUnicodeString(bah.bytes, numChars, 0);
/*     */       }
/*     */       
/* 192 */       this.strings[i] = s;
/*     */       
/*     */ 
/* 195 */       if (richString)
/*     */       {
/* 197 */         pos += 4 * formattingRuns;
/*     */       }
/*     */       
/*     */ 
/* 201 */       if (extendedString)
/*     */       {
/* 203 */         pos += extendedRunLength;
/*     */       }
/*     */       
/* 206 */       if (pos > data.length)
/*     */       {
/* 208 */         Assert.verify(false, "pos exceeds record length");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getChars(byte[] source, ByteArrayHolder bah, int pos, BooleanHolder ascii, int numChars)
/*     */   {
/* 230 */     int i = 0;
/* 231 */     boolean spansBreak = false;
/*     */     
/* 233 */     if (ascii.value)
/*     */     {
/* 235 */       bah.bytes = new byte[numChars];
/*     */     }
/*     */     else
/*     */     {
/* 239 */       bah.bytes = new byte[numChars * 2];
/*     */     }
/*     */     
/* 242 */     while ((i < this.continuationBreaks.length) && (!spansBreak))
/*     */     {
/* 244 */       spansBreak = (pos <= this.continuationBreaks[i]) && (pos + bah.bytes.length > this.continuationBreaks[i]);
/*     */       
/*     */ 
/* 247 */       if (!spansBreak)
/*     */       {
/* 249 */         i++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 255 */     if (!spansBreak)
/*     */     {
/* 257 */       System.arraycopy(source, pos, bah.bytes, 0, bah.bytes.length);
/* 258 */       return bah.bytes.length;
/*     */     }
/*     */     
/*     */ 
/* 262 */     int breakpos = this.continuationBreaks[i];
/* 263 */     System.arraycopy(source, pos, bah.bytes, 0, breakpos - pos);
/*     */     
/* 265 */     int bytesRead = breakpos - pos;
/*     */     int charsRead;
/* 267 */     int charsRead; if (ascii.value)
/*     */     {
/* 269 */       charsRead = bytesRead;
/*     */     }
/*     */     else
/*     */     {
/* 273 */       charsRead = bytesRead / 2;
/*     */     }
/*     */     
/* 276 */     bytesRead += getContinuedString(source, bah, bytesRead, i, ascii, numChars - charsRead);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 282 */     return bytesRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getContinuedString(byte[] source, ByteArrayHolder bah, int destPos, int contBreakIndex, BooleanHolder ascii, int charsLeft)
/*     */   {
/* 303 */     int breakpos = this.continuationBreaks[contBreakIndex];
/* 304 */     int bytesRead = 0;
/*     */     
/* 306 */     while (charsLeft > 0)
/*     */     {
/* 308 */       Assert.verify(contBreakIndex < this.continuationBreaks.length, "continuation break index");
/*     */       
/*     */ 
/* 311 */       if ((ascii.value) && (source[breakpos] == 0))
/*     */       {
/*     */ 
/*     */ 
/* 315 */         int length = contBreakIndex == this.continuationBreaks.length - 1 ? charsLeft : Math.min(charsLeft, this.continuationBreaks[(contBreakIndex + 1)] - breakpos - 1);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 321 */         System.arraycopy(source, breakpos + 1, bah.bytes, destPos, length);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 326 */         destPos += length;
/* 327 */         bytesRead += length + 1;
/* 328 */         charsLeft -= length;
/* 329 */         ascii.value = true;
/*     */       }
/* 331 */       else if ((!ascii.value) && (source[breakpos] != 0))
/*     */       {
/*     */ 
/*     */ 
/* 335 */         int length = contBreakIndex == this.continuationBreaks.length - 1 ? charsLeft * 2 : Math.min(charsLeft * 2, this.continuationBreaks[(contBreakIndex + 1)] - breakpos - 1);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */         System.arraycopy(source, breakpos + 1, bah.bytes, destPos, length);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 348 */         destPos += length;
/* 349 */         bytesRead += length + 1;
/* 350 */         charsLeft -= length / 2;
/* 351 */         ascii.value = false;
/*     */       }
/* 353 */       else if ((!ascii.value) && (source[breakpos] == 0))
/*     */       {
/*     */ 
/*     */ 
/* 357 */         int chars = contBreakIndex == this.continuationBreaks.length - 1 ? charsLeft : Math.min(charsLeft, this.continuationBreaks[(contBreakIndex + 1)] - breakpos - 1);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */         for (int j = 0; j < chars; j++)
/*     */         {
/* 365 */           bah.bytes[destPos] = source[(breakpos + j + 1)];
/* 366 */           destPos += 2;
/*     */         }
/*     */         
/* 369 */         bytesRead += chars + 1;
/* 370 */         charsLeft -= chars;
/* 371 */         ascii.value = false;
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 380 */         byte[] oldBytes = bah.bytes;
/* 381 */         bah.bytes = new byte[destPos * 2 + charsLeft * 2];
/* 382 */         for (int j = 0; j < destPos; j++)
/*     */         {
/* 384 */           bah.bytes[(j * 2)] = oldBytes[j];
/*     */         }
/*     */         
/* 387 */         destPos *= 2;
/*     */         
/* 389 */         int length = contBreakIndex == this.continuationBreaks.length - 1 ? charsLeft * 2 : Math.min(charsLeft * 2, this.continuationBreaks[(contBreakIndex + 1)] - breakpos - 1);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 395 */         System.arraycopy(source, breakpos + 1, bah.bytes, destPos, length);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 401 */         destPos += length;
/* 402 */         bytesRead += length + 1;
/* 403 */         charsLeft -= length / 2;
/* 404 */         ascii.value = false;
/*     */       }
/*     */       
/* 407 */       contBreakIndex++;
/*     */       
/* 409 */       if (contBreakIndex < this.continuationBreaks.length)
/*     */       {
/* 411 */         breakpos = this.continuationBreaks[contBreakIndex];
/*     */       }
/*     */     }
/*     */     
/* 415 */     return bytesRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(int index)
/*     */   {
/* 426 */     Assert.verify(index < this.uniqueStrings);
/* 427 */     return this.strings[index];
/*     */   }
/*     */   
/*     */   private static class BooleanHolder
/*     */   {
/*     */     public boolean value;
/*     */   }
/*     */   
/*     */   private static class ByteArrayHolder
/*     */   {
/*     */     public byte[] bytes;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SSTRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */