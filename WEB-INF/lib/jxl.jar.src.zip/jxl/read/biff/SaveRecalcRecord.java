/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SaveRecalcRecord
/*    */   extends RecordData
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(SaveRecalcRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean recalculateOnSave;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SaveRecalcRecord(Record t)
/*    */   {
/* 49 */     super(t);
/* 50 */     byte[] data = t.getData();
/* 51 */     int mode = IntegerHelper.getInt(data[0], data[1]);
/* 52 */     this.recalculateOnSave = (mode == 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getRecalculateOnSave()
/*    */   {
/* 62 */     return this.recalculateOnSave;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SaveRecalcRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */