/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.Type;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetupRecord
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(SetupRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean portraitOrientation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean pageOrder;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double headerMargin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double footerMargin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int paperSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int scaleFactor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pageStart;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int fitWidth;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int fitHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int horizontalPrintResolution;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int verticalPrintResolution;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int copies;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SetupRecord(Record t)
/*     */   {
/* 115 */     super(Type.SETUP);
/*     */     
/* 117 */     this.data = t.getData();
/*     */     
/* 119 */     this.paperSize = IntegerHelper.getInt(this.data[0], this.data[1]);
/* 120 */     this.scaleFactor = IntegerHelper.getInt(this.data[2], this.data[3]);
/* 121 */     this.pageStart = IntegerHelper.getInt(this.data[4], this.data[5]);
/* 122 */     this.fitWidth = IntegerHelper.getInt(this.data[6], this.data[7]);
/* 123 */     this.fitHeight = IntegerHelper.getInt(this.data[8], this.data[9]);
/* 124 */     this.horizontalPrintResolution = IntegerHelper.getInt(this.data[12], this.data[13]);
/* 125 */     this.verticalPrintResolution = IntegerHelper.getInt(this.data[14], this.data[15]);
/* 126 */     this.copies = IntegerHelper.getInt(this.data[32], this.data[33]);
/*     */     
/* 128 */     this.headerMargin = DoubleHelper.getIEEEDouble(this.data, 16);
/* 129 */     this.footerMargin = DoubleHelper.getIEEEDouble(this.data, 24);
/*     */     
/*     */ 
/*     */ 
/* 133 */     int grbit = IntegerHelper.getInt(this.data[10], this.data[11]);
/* 134 */     this.pageOrder = ((grbit & 0x1) != 0);
/* 135 */     this.portraitOrientation = ((grbit & 0x2) != 0);
/* 136 */     this.initialized = ((grbit & 0x4) == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPortrait()
/*     */   {
/* 146 */     return this.portraitOrientation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRightDown()
/*     */   {
/* 158 */     return this.pageOrder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getHeaderMargin()
/*     */   {
/* 168 */     return this.headerMargin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getFooterMargin()
/*     */   {
/* 178 */     return this.footerMargin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPaperSize()
/*     */   {
/* 188 */     return this.paperSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getScaleFactor()
/*     */   {
/* 198 */     return this.scaleFactor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPageStart()
/*     */   {
/* 208 */     return this.pageStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFitWidth()
/*     */   {
/* 218 */     return this.fitWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFitHeight()
/*     */   {
/* 228 */     return this.fitHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHorizontalPrintResolution()
/*     */   {
/* 238 */     return this.horizontalPrintResolution;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVerticalPrintResolution()
/*     */   {
/* 248 */     return this.verticalPrintResolution;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCopies()
/*     */   {
/* 258 */     return this.copies;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getInitialized()
/*     */   {
/* 269 */     return this.initialized;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SetupRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */