/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.BooleanCell;
/*     */ import jxl.BooleanFormulaCell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedBooleanFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements BooleanCell, FormulaData, BooleanFormulaCell
/*     */ {
/*  46 */   private static Logger logger = Logger.getLogger(SharedBooleanFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedBooleanFormulaRecord(Record t, File excelFile, boolean v, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/*  74 */     super(t, fr, es, nt, si, excelFile.getPos());
/*  75 */     this.value = v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getValue()
/*     */   {
/*  88 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/*  99 */     return new Boolean(this.value).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 109 */     return CellType.BOOLEAN_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 121 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 123 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 128 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */     
/*     */ 
/*     */ 
/* 132 */     fp.parse();
/* 133 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 135 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */     
/*     */ 
/* 138 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 139 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 140 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/* 141 */     data[6] = 1;
/* 142 */     data[8] = ((byte)(this.value == true ? 1 : 0));
/* 143 */     data[12] = -1;
/* 144 */     data[13] = -1;
/*     */     
/*     */ 
/* 147 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 148 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */     
/*     */ 
/* 151 */     byte[] d = new byte[data.length - 6];
/* 152 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 154 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SharedBooleanFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */