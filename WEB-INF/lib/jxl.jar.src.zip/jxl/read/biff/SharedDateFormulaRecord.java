/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.DateFormulaCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedDateFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements DateCell, FormulaData, DateFormulaCell
/*     */ {
/*     */   private DateRecord dateRecord;
/*     */   private double value;
/*     */   
/*     */   public SharedDateFormulaRecord(SharedNumberFormulaRecord nfr, FormattingRecords fr, boolean nf, SheetImpl si, int pos)
/*     */   {
/*  69 */     super(nfr.getRecord(), fr, nfr.getExternalSheet(), nfr.getNameTable(), si, pos);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */     this.dateRecord = new DateRecord(nfr, nfr.getXFIndex(), fr, nf, si);
/*  76 */     this.value = nfr.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/*  86 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/*  96 */     return this.dateRecord.getContents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 106 */     return CellType.DATE_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 118 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 120 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 125 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */     
/*     */ 
/*     */ 
/* 129 */     fp.parse();
/* 130 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 132 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */     
/*     */ 
/* 135 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 136 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 137 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/* 138 */     DoubleHelper.getIEEEBytes(this.value, data, 6);
/*     */     
/*     */ 
/* 141 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 142 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */     
/*     */ 
/* 145 */     byte[] d = new byte[data.length - 6];
/* 146 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 148 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getDate()
/*     */   {
/* 158 */     return this.dateRecord.getDate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTime()
/*     */   {
/* 169 */     return this.dateRecord.isTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateFormat getDateFormat()
/*     */   {
/* 182 */     return this.dateRecord.getDateFormat();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SharedDateFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */