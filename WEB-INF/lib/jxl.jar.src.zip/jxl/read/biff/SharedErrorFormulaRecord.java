/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.ErrorCell;
/*     */ import jxl.ErrorFormulaCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaErrorCode;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedErrorFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements ErrorCell, FormulaData, ErrorFormulaCell
/*     */ {
/*  46 */   private static Logger logger = Logger.getLogger(SharedErrorFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int errorCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormulaErrorCode error;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedErrorFormulaRecord(Record t, File excelFile, int ec, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/*  83 */     super(t, fr, es, nt, si, excelFile.getPos());
/*  84 */     this.errorCode = ec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/*  96 */     return this.errorCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 106 */     if (this.error == null)
/*     */     {
/* 108 */       this.error = FormulaErrorCode.getErrorCode(this.errorCode);
/*     */     }
/*     */     
/* 111 */     return "ERROR " + this.errorCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 122 */     return CellType.FORMULA_ERROR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 134 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 136 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 141 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */     
/*     */ 
/*     */ 
/* 145 */     fp.parse();
/* 146 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 148 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */     
/*     */ 
/* 151 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 152 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 153 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/*     */     
/* 155 */     data[6] = 2;
/* 156 */     data[8] = ((byte)this.errorCode);
/* 157 */     data[12] = -1;
/* 158 */     data[13] = -1;
/*     */     
/*     */ 
/* 161 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 162 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */     
/*     */ 
/* 165 */     byte[] d = new byte[data.length - 6];
/* 166 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 168 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SharedErrorFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */