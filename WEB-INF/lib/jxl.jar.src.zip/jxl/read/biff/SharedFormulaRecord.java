/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedFormulaRecord
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(SharedFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int firstRow;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int lastRow;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int firstCol;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int lastCol;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BaseSharedFormulaRecord templateFormula;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList formulas;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] tokens;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet externalSheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SheetImpl sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedFormulaRecord(Record t, BaseSharedFormulaRecord fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/* 105 */     this.sheet = si;
/* 106 */     byte[] data = t.getData();
/*     */     
/* 108 */     this.firstRow = IntegerHelper.getInt(data[0], data[1]);
/* 109 */     this.lastRow = IntegerHelper.getInt(data[2], data[3]);
/* 110 */     this.firstCol = (data[4] & 0xFF);
/* 111 */     this.lastCol = (data[5] & 0xFF);
/*     */     
/* 113 */     this.formulas = new ArrayList();
/*     */     
/* 115 */     this.templateFormula = fr;
/*     */     
/* 117 */     this.tokens = new byte[data.length - 10];
/* 118 */     System.arraycopy(data, 10, this.tokens, 0, this.tokens.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean add(BaseSharedFormulaRecord fr)
/*     */   {
/* 130 */     boolean added = false;
/* 131 */     int r = fr.getRow();
/* 132 */     if ((r >= this.firstRow) && (r <= this.lastRow))
/*     */     {
/* 134 */       int c = fr.getColumn();
/* 135 */       if ((c >= this.firstCol) && (c <= this.lastCol))
/*     */       {
/* 137 */         this.formulas.add(fr);
/* 138 */         added = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 143 */     return added;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Cell[] getFormulas(FormattingRecords fr, boolean nf)
/*     */   {
/* 156 */     Cell[] sfs = new Cell[this.formulas.size() + 1];
/*     */     
/*     */ 
/*     */ 
/* 160 */     if (this.templateFormula == null)
/*     */     {
/* 162 */       logger.warn("Shared formula template formula is null");
/* 163 */       return new Cell[0];
/*     */     }
/*     */     
/* 166 */     this.templateFormula.setTokens(this.tokens);
/* 167 */     NumberFormat templateNumberFormat = null;
/*     */     
/*     */ 
/* 170 */     if (this.templateFormula.getType() == CellType.NUMBER_FORMULA)
/*     */     {
/* 172 */       SharedNumberFormulaRecord snfr = (SharedNumberFormulaRecord)this.templateFormula;
/*     */       
/* 174 */       templateNumberFormat = snfr.getNumberFormat();
/*     */       
/* 176 */       if (fr.isDate(this.templateFormula.getXFIndex()))
/*     */       {
/* 178 */         this.templateFormula = new SharedDateFormulaRecord(snfr, fr, nf, this.sheet, snfr.getFilePos());
/*     */         
/* 180 */         this.templateFormula.setTokens(snfr.getTokens());
/*     */       }
/*     */     }
/*     */     
/* 184 */     sfs[0] = this.templateFormula;
/*     */     
/* 186 */     BaseSharedFormulaRecord f = null;
/*     */     
/* 188 */     for (int i = 0; i < this.formulas.size(); i++)
/*     */     {
/* 190 */       f = (BaseSharedFormulaRecord)this.formulas.get(i);
/*     */       
/*     */ 
/* 193 */       if (f.getType() == CellType.NUMBER_FORMULA)
/*     */       {
/* 195 */         SharedNumberFormulaRecord snfr = (SharedNumberFormulaRecord)f;
/*     */         
/* 197 */         if (fr.isDate(f.getXFIndex()))
/*     */         {
/* 199 */           f = new SharedDateFormulaRecord(snfr, fr, nf, this.sheet, snfr.getFilePos());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */       f.setTokens(this.tokens);
/* 209 */       sfs[(i + 1)] = f;
/*     */     }
/*     */     
/* 212 */     return sfs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   BaseSharedFormulaRecord getTemplateFormula()
/*     */   {
/* 222 */     return this.templateFormula;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SharedFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */