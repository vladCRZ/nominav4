/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.StringFormulaCell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedStringFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements LabelCell, FormulaData, StringFormulaCell
/*     */ {
/*  49 */   private static Logger logger = Logger.getLogger(SharedStringFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   protected static final EmptyString EMPTY_STRING = new EmptyString(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedStringFormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, WorkbookSettings ws)
/*     */   {
/*  81 */     super(t, fr, es, nt, si, excelFile.getPos());
/*  82 */     int pos = excelFile.getPos();
/*     */     
/*     */ 
/*  85 */     int filepos = excelFile.getPos();
/*     */     
/*     */ 
/*     */ 
/*  89 */     Record nextRecord = excelFile.next();
/*  90 */     int count = 0;
/*  91 */     while ((nextRecord.getType() != Type.STRING) && (count < 4))
/*     */     {
/*  93 */       nextRecord = excelFile.next();
/*  94 */       count++;
/*     */     }
/*  96 */     Assert.verify(count < 4, " @ " + pos);
/*     */     
/*  98 */     byte[] stringData = nextRecord.getData();
/*     */     
/*     */ 
/* 101 */     nextRecord = excelFile.peek();
/* 102 */     while (nextRecord.getType() == Type.CONTINUE)
/*     */     {
/* 104 */       nextRecord = excelFile.next();
/* 105 */       byte[] d = new byte[stringData.length + nextRecord.getLength() - 1];
/* 106 */       System.arraycopy(stringData, 0, d, 0, stringData.length);
/* 107 */       System.arraycopy(nextRecord.getData(), 1, d, stringData.length, nextRecord.getLength() - 1);
/*     */       
/* 109 */       stringData = d;
/* 110 */       nextRecord = excelFile.peek();
/*     */     }
/*     */     
/* 113 */     int chars = IntegerHelper.getInt(stringData[0], stringData[1]);
/*     */     
/* 115 */     boolean unicode = false;
/* 116 */     int startpos = 3;
/* 117 */     if (stringData.length == chars + 2)
/*     */     {
/*     */ 
/*     */ 
/* 121 */       startpos = 2;
/* 122 */       unicode = false;
/*     */     }
/* 124 */     else if (stringData[2] == 1)
/*     */     {
/*     */ 
/* 127 */       startpos = 3;
/* 128 */       unicode = true;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 133 */       startpos = 3;
/* 134 */       unicode = false;
/*     */     }
/*     */     
/* 137 */     if (!unicode)
/*     */     {
/* 139 */       this.value = StringHelper.getString(stringData, chars, startpos, ws);
/*     */     }
/*     */     else
/*     */     {
/* 143 */       this.value = StringHelper.getUnicodeString(stringData, chars, startpos);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     excelFile.setPos(filepos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedStringFormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, EmptyString dummy)
/*     */   {
/* 170 */     super(t, fr, es, nt, si, excelFile.getPos());
/*     */     
/* 172 */     this.value = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/* 182 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 192 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 202 */     return CellType.STRING_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 214 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 216 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 221 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */     
/*     */ 
/*     */ 
/* 225 */     fp.parse();
/* 226 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 228 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */     
/*     */ 
/* 231 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 232 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 233 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/*     */     
/*     */ 
/*     */ 
/* 237 */     data[6] = 0;
/* 238 */     data[12] = -1;
/* 239 */     data[13] = -1;
/*     */     
/*     */ 
/* 242 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 243 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */     
/*     */ 
/* 246 */     byte[] d = new byte[data.length - 6];
/* 247 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 249 */     return d;
/*     */   }
/*     */   
/*     */   private static final class EmptyString {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SharedStringFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */