/*      */ package jxl.read.biff;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.regex.Pattern;
/*      */ import jxl.Cell;
/*      */ import jxl.CellView;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.Image;
/*      */ import jxl.LabelCell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.AutoFilter;
/*      */ import jxl.biff.BuiltInName;
/*      */ import jxl.biff.CellFinder;
/*      */ import jxl.biff.CellReferenceHelper;
/*      */ import jxl.biff.ConditionalFormat;
/*      */ import jxl.biff.DataValidation;
/*      */ import jxl.biff.EmptyCell;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingData;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.CellFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SheetImpl
/*      */   implements Sheet
/*      */ {
/*   68 */   private static Logger logger = Logger.getLogger(SheetImpl.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private File excelFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SSTRecord sharedStrings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private BOFRecord sheetBof;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private BOFRecord workbookBof;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormattingRecords formattingRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numRows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numCols;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Cell[][] cells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int startPosition;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ColumnInfoRecord[] columnInfos;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private RowRecord[] rowRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList rowProperties;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList columnInfosArray;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList sharedFormulas;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList hyperlinks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList charts;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList drawings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList images;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DataValidation dataValidation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Range[] mergedCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean columnInfosInitialized;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean rowRecordsInitialized;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean nineteenFour;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkspaceInformationRecord workspaceOptions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean hidden;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PLSRecord plsRecord;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetSettings settings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] rowBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] columnBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxRowOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxColumnOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList localNames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList conditionalFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AutoFilter autoFilter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookParser workbook;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookSettings workbookSettings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SheetImpl(File f, SSTRecord sst, FormattingRecords fr, BOFRecord sb, BOFRecord wb, boolean nf, WorkbookParser wp)
/*      */     throws BiffException
/*      */   {
/*  283 */     this.excelFile = f;
/*  284 */     this.sharedStrings = sst;
/*  285 */     this.formattingRecords = fr;
/*  286 */     this.sheetBof = sb;
/*  287 */     this.workbookBof = wb;
/*  288 */     this.columnInfosArray = new ArrayList();
/*  289 */     this.sharedFormulas = new ArrayList();
/*  290 */     this.hyperlinks = new ArrayList();
/*  291 */     this.rowProperties = new ArrayList(10);
/*  292 */     this.columnInfosInitialized = false;
/*  293 */     this.rowRecordsInitialized = false;
/*  294 */     this.nineteenFour = nf;
/*  295 */     this.workbook = wp;
/*  296 */     this.workbookSettings = this.workbook.getSettings();
/*      */     
/*      */ 
/*  299 */     this.startPosition = f.getPos();
/*      */     
/*  301 */     if (this.sheetBof.isChart())
/*      */     {
/*      */ 
/*  304 */       this.startPosition -= this.sheetBof.getLength() + 4;
/*      */     }
/*      */     
/*  307 */     Record r = null;
/*  308 */     int bofs = 1;
/*      */     
/*  310 */     while (bofs >= 1)
/*      */     {
/*  312 */       r = f.next();
/*      */       
/*      */ 
/*  315 */       if (r.getCode() == Type.EOF.value)
/*      */       {
/*  317 */         bofs--;
/*      */       }
/*      */       
/*  320 */       if (r.getCode() == Type.BOF.value)
/*      */       {
/*  322 */         bofs++;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell getCell(String loc)
/*      */   {
/*  336 */     return getCell(CellReferenceHelper.getColumn(loc), CellReferenceHelper.getRow(loc));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell getCell(int column, int row)
/*      */   {
/*  351 */     if (this.cells == null)
/*      */     {
/*  353 */       readSheet();
/*      */     }
/*      */     
/*  356 */     Cell c = this.cells[row][column];
/*      */     
/*  358 */     if (c == null)
/*      */     {
/*  360 */       c = new EmptyCell(column, row);
/*  361 */       this.cells[row][column] = c;
/*      */     }
/*      */     
/*  364 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCell(String contents)
/*      */   {
/*  378 */     CellFinder cellFinder = new CellFinder(this);
/*  379 */     return cellFinder.findCell(contents);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCell(String contents, int firstCol, int firstRow, int lastCol, int lastRow, boolean reverse)
/*      */   {
/*  403 */     CellFinder cellFinder = new CellFinder(this);
/*  404 */     return cellFinder.findCell(contents, firstCol, firstRow, lastCol, lastRow, reverse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCell(Pattern pattern, int firstCol, int firstRow, int lastCol, int lastRow, boolean reverse)
/*      */   {
/*  433 */     CellFinder cellFinder = new CellFinder(this);
/*  434 */     return cellFinder.findCell(pattern, firstCol, firstRow, lastCol, lastRow, reverse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LabelCell findLabelCell(String contents)
/*      */   {
/*  456 */     CellFinder cellFinder = new CellFinder(this);
/*  457 */     return cellFinder.findLabelCell(contents);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRows()
/*      */   {
/*  469 */     if (this.cells == null)
/*      */     {
/*  471 */       readSheet();
/*      */     }
/*      */     
/*  474 */     return this.numRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumns()
/*      */   {
/*  486 */     if (this.cells == null)
/*      */     {
/*  488 */       readSheet();
/*      */     }
/*      */     
/*  491 */     return this.numCols;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell[] getRow(int row)
/*      */   {
/*  505 */     if (this.cells == null)
/*      */     {
/*  507 */       readSheet();
/*      */     }
/*      */     
/*      */ 
/*  511 */     boolean found = false;
/*  512 */     int col = this.numCols - 1;
/*  513 */     while ((col >= 0) && (!found))
/*      */     {
/*  515 */       if (this.cells[row][col] != null)
/*      */       {
/*  517 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/*  521 */         col--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  526 */     Cell[] c = new Cell[col + 1];
/*      */     
/*  528 */     for (int i = 0; i <= col; i++)
/*      */     {
/*  530 */       c[i] = getCell(i, row);
/*      */     }
/*  532 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell[] getColumn(int col)
/*      */   {
/*  546 */     if (this.cells == null)
/*      */     {
/*  548 */       readSheet();
/*      */     }
/*      */     
/*      */ 
/*  552 */     boolean found = false;
/*  553 */     int row = this.numRows - 1;
/*  554 */     while ((row >= 0) && (!found))
/*      */     {
/*  556 */       if (this.cells[row][col] != null)
/*      */       {
/*  558 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/*  562 */         row--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  567 */     Cell[] c = new Cell[row + 1];
/*      */     
/*  569 */     for (int i = 0; i <= row; i++)
/*      */     {
/*  571 */       c[i] = getCell(col, i);
/*      */     }
/*  573 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  583 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void setName(String s)
/*      */   {
/*  593 */     this.name = s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isHidden()
/*      */   {
/*  604 */     return this.hidden;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ColumnInfoRecord getColumnInfo(int col)
/*      */   {
/*  616 */     if (!this.columnInfosInitialized)
/*      */     {
/*      */ 
/*  619 */       Iterator i = this.columnInfosArray.iterator();
/*  620 */       ColumnInfoRecord cir = null;
/*  621 */       while (i.hasNext())
/*      */       {
/*  623 */         cir = (ColumnInfoRecord)i.next();
/*      */         
/*  625 */         int startcol = Math.max(0, cir.getStartColumn());
/*  626 */         int endcol = Math.min(this.columnInfos.length - 1, cir.getEndColumn());
/*      */         
/*  628 */         for (int c = startcol; c <= endcol; c++)
/*      */         {
/*  630 */           this.columnInfos[c] = cir;
/*      */         }
/*      */         
/*  633 */         if (endcol < startcol)
/*      */         {
/*  635 */           this.columnInfos[startcol] = cir;
/*      */         }
/*      */       }
/*      */       
/*  639 */       this.columnInfosInitialized = true;
/*      */     }
/*      */     
/*  642 */     return col < this.columnInfos.length ? this.columnInfos[col] : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ColumnInfoRecord[] getColumnInfos()
/*      */   {
/*  653 */     ColumnInfoRecord[] infos = new ColumnInfoRecord[this.columnInfosArray.size()];
/*  654 */     for (int i = 0; i < this.columnInfosArray.size(); i++)
/*      */     {
/*  656 */       infos[i] = ((ColumnInfoRecord)this.columnInfosArray.get(i));
/*      */     }
/*      */     
/*  659 */     return infos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void setHidden(boolean h)
/*      */   {
/*  669 */     this.hidden = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void clear()
/*      */   {
/*  678 */     this.cells = ((Cell[][])null);
/*  679 */     this.mergedCells = null;
/*  680 */     this.columnInfosArray.clear();
/*  681 */     this.sharedFormulas.clear();
/*  682 */     this.hyperlinks.clear();
/*  683 */     this.columnInfosInitialized = false;
/*      */     
/*  685 */     if (!this.workbookSettings.getGCDisabled())
/*      */     {
/*  687 */       System.gc();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void readSheet()
/*      */   {
/*  699 */     if (!this.sheetBof.isWorksheet())
/*      */     {
/*  701 */       this.numRows = 0;
/*  702 */       this.numCols = 0;
/*  703 */       this.cells = new Cell[0][0];
/*      */     }
/*      */     
/*      */ 
/*  707 */     SheetReader reader = new SheetReader(this.excelFile, this.sharedStrings, this.formattingRecords, this.sheetBof, this.workbookBof, this.nineteenFour, this.workbook, this.startPosition, this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  716 */     reader.read();
/*      */     
/*      */ 
/*  719 */     this.numRows = reader.getNumRows();
/*  720 */     this.numCols = reader.getNumCols();
/*  721 */     this.cells = reader.getCells();
/*  722 */     this.rowProperties = reader.getRowProperties();
/*  723 */     this.columnInfosArray = reader.getColumnInfosArray();
/*  724 */     this.hyperlinks = reader.getHyperlinks();
/*  725 */     this.conditionalFormats = reader.getConditionalFormats();
/*  726 */     this.autoFilter = reader.getAutoFilter();
/*  727 */     this.charts = reader.getCharts();
/*  728 */     this.drawings = reader.getDrawings();
/*  729 */     this.dataValidation = reader.getDataValidation();
/*  730 */     this.mergedCells = reader.getMergedCells();
/*  731 */     this.settings = reader.getSettings();
/*  732 */     this.settings.setHidden(this.hidden);
/*  733 */     this.rowBreaks = reader.getRowBreaks();
/*  734 */     this.columnBreaks = reader.getColumnBreaks();
/*  735 */     this.workspaceOptions = reader.getWorkspaceOptions();
/*  736 */     this.plsRecord = reader.getPLS();
/*  737 */     this.buttonPropertySet = reader.getButtonPropertySet();
/*  738 */     this.maxRowOutlineLevel = reader.getMaxRowOutlineLevel();
/*  739 */     this.maxColumnOutlineLevel = reader.getMaxColumnOutlineLevel();
/*      */     
/*  741 */     reader = null;
/*      */     
/*  743 */     if (!this.workbookSettings.getGCDisabled())
/*      */     {
/*  745 */       System.gc();
/*      */     }
/*      */     
/*  748 */     if (this.columnInfosArray.size() > 0)
/*      */     {
/*  750 */       ColumnInfoRecord cir = (ColumnInfoRecord)this.columnInfosArray.get(this.columnInfosArray.size() - 1);
/*      */       
/*  752 */       this.columnInfos = new ColumnInfoRecord[cir.getEndColumn() + 1];
/*      */     }
/*      */     else
/*      */     {
/*  756 */       this.columnInfos = new ColumnInfoRecord[0];
/*      */     }
/*      */     
/*      */     Iterator it;
/*  760 */     if (this.localNames != null)
/*      */     {
/*  762 */       for (it = this.localNames.iterator(); it.hasNext();)
/*      */       {
/*  764 */         NameRecord nr = (NameRecord)it.next();
/*  765 */         if (nr.getBuiltInName() == BuiltInName.PRINT_AREA)
/*      */         {
/*  767 */           if (nr.getRanges().length > 0)
/*      */           {
/*  769 */             NameRecord.NameRange rng = nr.getRanges()[0];
/*  770 */             this.settings.setPrintArea(rng.getFirstColumn(), rng.getFirstRow(), rng.getLastColumn(), rng.getLastRow());
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*  776 */         else if (nr.getBuiltInName() == BuiltInName.PRINT_TITLES)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  783 */           for (int i = 0; i < nr.getRanges().length; i++)
/*      */           {
/*  785 */             NameRecord.NameRange rng = nr.getRanges()[i];
/*  786 */             if ((rng.getFirstColumn() == 0) && (rng.getLastColumn() == 255))
/*      */             {
/*  788 */               this.settings.setPrintTitlesRow(rng.getFirstRow(), rng.getLastRow());
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  793 */               this.settings.setPrintTitlesCol(rng.getFirstColumn(), rng.getLastColumn());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Hyperlink[] getHyperlinks()
/*      */   {
/*  809 */     Hyperlink[] hl = new Hyperlink[this.hyperlinks.size()];
/*      */     
/*  811 */     for (int i = 0; i < this.hyperlinks.size(); i++)
/*      */     {
/*  813 */       hl[i] = ((Hyperlink)this.hyperlinks.get(i));
/*      */     }
/*      */     
/*  816 */     return hl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range[] getMergedCells()
/*      */   {
/*  826 */     if (this.mergedCells == null)
/*      */     {
/*  828 */       return new Range[0];
/*      */     }
/*      */     
/*  831 */     return this.mergedCells;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowRecord[] getRowProperties()
/*      */   {
/*  841 */     RowRecord[] rp = new RowRecord[this.rowProperties.size()];
/*  842 */     for (int i = 0; i < rp.length; i++)
/*      */     {
/*  844 */       rp[i] = ((RowRecord)this.rowProperties.get(i));
/*      */     }
/*      */     
/*  847 */     return rp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DataValidation getDataValidation()
/*      */   {
/*  857 */     return this.dataValidation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   RowRecord getRowInfo(int r)
/*      */   {
/*  869 */     if (!this.rowRecordsInitialized)
/*      */     {
/*  871 */       this.rowRecords = new RowRecord[getRows()];
/*  872 */       Iterator i = this.rowProperties.iterator();
/*      */       
/*  874 */       int rownum = 0;
/*  875 */       RowRecord rr = null;
/*  876 */       while (i.hasNext())
/*      */       {
/*  878 */         rr = (RowRecord)i.next();
/*  879 */         rownum = rr.getRowNumber();
/*  880 */         if (rownum < this.rowRecords.length)
/*      */         {
/*  882 */           this.rowRecords[rownum] = rr;
/*      */         }
/*      */       }
/*      */       
/*  886 */       this.rowRecordsInitialized = true;
/*      */     }
/*      */     
/*  889 */     return r < this.rowRecords.length ? this.rowRecords[r] : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int[] getRowPageBreaks()
/*      */   {
/*  899 */     return this.rowBreaks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int[] getColumnPageBreaks()
/*      */   {
/*  909 */     return this.columnBreaks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Chart[] getCharts()
/*      */   {
/*  919 */     Chart[] ch = new Chart[this.charts.size()];
/*      */     
/*  921 */     for (int i = 0; i < ch.length; i++)
/*      */     {
/*  923 */       ch[i] = ((Chart)this.charts.get(i));
/*      */     }
/*  925 */     return ch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final DrawingGroupObject[] getDrawings()
/*      */   {
/*  935 */     DrawingGroupObject[] dr = new DrawingGroupObject[this.drawings.size()];
/*  936 */     dr = (DrawingGroupObject[])this.drawings.toArray(dr);
/*  937 */     return dr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isProtected()
/*      */   {
/*  948 */     return this.settings.isProtected();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WorkspaceInformationRecord getWorkspaceOptions()
/*      */   {
/*  959 */     return this.workspaceOptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SheetSettings getSettings()
/*      */   {
/*  969 */     return this.settings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WorkbookParser getWorkbook()
/*      */   {
/*  980 */     return this.workbook;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public CellFormat getColumnFormat(int col)
/*      */   {
/*  992 */     CellView cv = getColumnView(col);
/*  993 */     return cv.getFormat();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumnWidth(int col)
/*      */   {
/* 1005 */     return getColumnView(col).getSize() / 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CellView getColumnView(int col)
/*      */   {
/* 1017 */     ColumnInfoRecord cir = getColumnInfo(col);
/* 1018 */     CellView cv = new CellView();
/*      */     
/* 1020 */     if (cir != null)
/*      */     {
/* 1022 */       cv.setDimension(cir.getWidth() / 256);
/* 1023 */       cv.setSize(cir.getWidth());
/* 1024 */       cv.setHidden(cir.getHidden());
/* 1025 */       cv.setFormat(this.formattingRecords.getXFRecord(cir.getXFIndex()));
/*      */     }
/*      */     else
/*      */     {
/* 1029 */       cv.setDimension(this.settings.getDefaultColumnWidth());
/* 1030 */       cv.setSize(this.settings.getDefaultColumnWidth() * 256);
/*      */     }
/*      */     
/* 1033 */     return cv;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getRowHeight(int row)
/*      */   {
/* 1046 */     return getRowView(row).getDimension();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CellView getRowView(int row)
/*      */   {
/* 1058 */     RowRecord rr = getRowInfo(row);
/*      */     
/* 1060 */     CellView cv = new CellView();
/*      */     
/* 1062 */     if (rr != null)
/*      */     {
/* 1064 */       cv.setDimension(rr.getRowHeight());
/* 1065 */       cv.setSize(rr.getRowHeight());
/* 1066 */       cv.setHidden(rr.isCollapsed());
/* 1067 */       if (rr.hasDefaultFormat())
/*      */       {
/* 1069 */         cv.setFormat(this.formattingRecords.getXFRecord(rr.getXFIndex()));
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1074 */       cv.setDimension(this.settings.getDefaultRowHeight());
/* 1075 */       cv.setSize(this.settings.getDefaultRowHeight());
/*      */     }
/*      */     
/* 1078 */     return cv;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BOFRecord getSheetBof()
/*      */   {
/* 1089 */     return this.sheetBof;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BOFRecord getWorkbookBof()
/*      */   {
/* 1100 */     return this.workbookBof;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PLSRecord getPLS()
/*      */   {
/* 1111 */     return this.plsRecord;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ButtonPropertySetRecord getButtonPropertySet()
/*      */   {
/* 1121 */     return this.buttonPropertySet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumberOfImages()
/*      */   {
/* 1131 */     if (this.images == null)
/*      */     {
/* 1133 */       initializeImages();
/*      */     }
/*      */     
/* 1136 */     return this.images.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getDrawing(int i)
/*      */   {
/* 1147 */     if (this.images == null)
/*      */     {
/* 1149 */       initializeImages();
/*      */     }
/*      */     
/* 1152 */     return (Image)this.images.get(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializeImages()
/*      */   {
/* 1160 */     if (this.images != null)
/*      */     {
/* 1162 */       return;
/*      */     }
/*      */     
/* 1165 */     this.images = new ArrayList();
/* 1166 */     DrawingGroupObject[] dgos = getDrawings();
/*      */     
/* 1168 */     for (int i = 0; i < dgos.length; i++)
/*      */     {
/* 1170 */       if ((dgos[i] instanceof Drawing))
/*      */       {
/* 1172 */         this.images.add(dgos[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DrawingData getDrawingData()
/*      */   {
/* 1182 */     SheetReader reader = new SheetReader(this.excelFile, this.sharedStrings, this.formattingRecords, this.sheetBof, this.workbookBof, this.nineteenFour, this.workbook, this.startPosition, this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1191 */     reader.read();
/* 1192 */     return reader.getDrawingData();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addLocalName(NameRecord nr)
/*      */   {
/* 1202 */     if (this.localNames == null)
/*      */     {
/* 1204 */       this.localNames = new ArrayList();
/*      */     }
/*      */     
/* 1207 */     this.localNames.add(nr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConditionalFormat[] getConditionalFormats()
/*      */   {
/* 1217 */     ConditionalFormat[] formats = new ConditionalFormat[this.conditionalFormats.size()];
/*      */     
/* 1219 */     formats = (ConditionalFormat[])this.conditionalFormats.toArray(formats);
/* 1220 */     return formats;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AutoFilter getAutoFilter()
/*      */   {
/* 1230 */     return this.autoFilter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnOutlineLevel()
/*      */   {
/* 1240 */     return this.maxColumnOutlineLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxRowOutlineLevel()
/*      */   {
/* 1250 */     return this.maxRowOutlineLevel;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SheetImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */