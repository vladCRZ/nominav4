/*      */ package jxl.read.biff;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.Cell;
/*      */ import jxl.CellFeatures;
/*      */ import jxl.CellReferenceHelper;
/*      */ import jxl.CellType;
/*      */ import jxl.DateCell;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.Range;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.AutoFilter;
/*      */ import jxl.biff.AutoFilterInfoRecord;
/*      */ import jxl.biff.AutoFilterRecord;
/*      */ import jxl.biff.ConditionalFormat;
/*      */ import jxl.biff.ConditionalFormatRangeRecord;
/*      */ import jxl.biff.ConditionalFormatRecord;
/*      */ import jxl.biff.ContinueRecord;
/*      */ import jxl.biff.DataValidation;
/*      */ import jxl.biff.DataValidityListRecord;
/*      */ import jxl.biff.DataValiditySettingsRecord;
/*      */ import jxl.biff.FilterModeRecord;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.drawing.Button;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.CheckBox;
/*      */ import jxl.biff.drawing.ComboBox;
/*      */ import jxl.biff.drawing.Comment;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.Drawing2;
/*      */ import jxl.biff.drawing.DrawingData;
/*      */ import jxl.biff.drawing.DrawingDataException;
/*      */ import jxl.biff.drawing.DrawingGroup;
/*      */ import jxl.biff.drawing.MsoDrawingRecord;
/*      */ import jxl.biff.drawing.NoteRecord;
/*      */ import jxl.biff.drawing.ObjRecord;
/*      */ import jxl.biff.drawing.TextObjectRecord;
/*      */ import jxl.biff.formula.FormulaException;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.PageOrder;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class SheetReader
/*      */ {
/*   80 */   private static Logger logger = Logger.getLogger(SheetReader.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private File excelFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SSTRecord sharedStrings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private BOFRecord sheetBof;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private BOFRecord workbookBof;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormattingRecords formattingRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numRows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numCols;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Cell[][] cells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList outOfBoundsCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int startPosition;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList rowProperties;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList columnInfosArray;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList sharedFormulas;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList hyperlinks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList conditionalFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AutoFilter autoFilter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Range[] mergedCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DataValidation dataValidation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList charts;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList drawings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DrawingData drawingData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean nineteenFour;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PLSRecord plsRecord;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkspaceInformationRecord workspaceOptions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] rowBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] columnBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxRowOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxColumnOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetSettings settings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookSettings workbookSettings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookParser workbook;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetImpl sheet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SheetReader(File f, SSTRecord sst, FormattingRecords fr, BOFRecord sb, BOFRecord wb, boolean nf, WorkbookParser wp, int sp, SheetImpl sh)
/*      */   {
/*  273 */     this.excelFile = f;
/*  274 */     this.sharedStrings = sst;
/*  275 */     this.formattingRecords = fr;
/*  276 */     this.sheetBof = sb;
/*  277 */     this.workbookBof = wb;
/*  278 */     this.columnInfosArray = new ArrayList();
/*  279 */     this.sharedFormulas = new ArrayList();
/*  280 */     this.hyperlinks = new ArrayList();
/*  281 */     this.conditionalFormats = new ArrayList();
/*  282 */     this.rowProperties = new ArrayList(10);
/*  283 */     this.charts = new ArrayList();
/*  284 */     this.drawings = new ArrayList();
/*  285 */     this.outOfBoundsCells = new ArrayList();
/*  286 */     this.nineteenFour = nf;
/*  287 */     this.workbook = wp;
/*  288 */     this.startPosition = sp;
/*  289 */     this.sheet = sh;
/*  290 */     this.settings = new SheetSettings(sh);
/*  291 */     this.workbookSettings = this.workbook.getSettings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addCell(Cell cell)
/*      */   {
/*  303 */     if ((cell.getRow() < this.numRows) && (cell.getColumn() < this.numCols))
/*      */     {
/*  305 */       if (this.cells[cell.getRow()][cell.getColumn()] != null)
/*      */       {
/*  307 */         StringBuffer sb = new StringBuffer();
/*  308 */         CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow(), sb);
/*      */         
/*  310 */         logger.warn("Cell " + sb.toString() + " already contains data");
/*      */       }
/*      */       
/*  313 */       this.cells[cell.getRow()][cell.getColumn()] = cell;
/*      */     }
/*      */     else
/*      */     {
/*  317 */       this.outOfBoundsCells.add(cell);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void read()
/*      */   {
/*  333 */     Record r = null;
/*  334 */     BaseSharedFormulaRecord sharedFormula = null;
/*  335 */     boolean sharedFormulaAdded = false;
/*      */     
/*  337 */     boolean cont = true;
/*      */     
/*      */ 
/*  340 */     this.excelFile.setPos(this.startPosition);
/*      */     
/*      */ 
/*  343 */     MsoDrawingRecord msoRecord = null;
/*  344 */     ObjRecord objRecord = null;
/*  345 */     boolean firstMsoRecord = true;
/*      */     
/*      */ 
/*  348 */     ConditionalFormat condFormat = null;
/*      */     
/*      */ 
/*  351 */     FilterModeRecord filterMode = null;
/*  352 */     AutoFilterInfoRecord autoFilterInfo = null;
/*      */     
/*      */ 
/*  355 */     Window2Record window2Record = null;
/*      */     
/*      */ 
/*  358 */     PrintGridLinesRecord printGridLinesRecord = null;
/*      */     
/*      */ 
/*  361 */     PrintHeadersRecord printHeadersRecord = null;
/*      */     
/*      */ 
/*      */ 
/*  365 */     HashMap comments = new HashMap();
/*      */     
/*      */ 
/*  368 */     ArrayList objectIds = new ArrayList();
/*      */     
/*      */ 
/*  371 */     ContinueRecord continueRecord = null;
/*      */     
/*  373 */     while (cont)
/*      */     {
/*  375 */       r = this.excelFile.next();
/*  376 */       Type type = r.getType();
/*      */       
/*  378 */       if ((type == Type.UNKNOWN) && (r.getCode() == 0))
/*      */       {
/*  380 */         logger.warn("Biff code zero found");
/*      */         
/*      */ 
/*  383 */         if (r.getLength() == 10)
/*      */         {
/*  385 */           logger.warn("Biff code zero found - trying a dimension record.");
/*  386 */           r.setType(Type.DIMENSION);
/*      */         }
/*      */         else
/*      */         {
/*  390 */           logger.warn("Biff code zero found - Ignoring.");
/*      */         }
/*      */       }
/*      */       
/*  394 */       if (type == Type.DIMENSION)
/*      */       {
/*  396 */         DimensionRecord dr = null;
/*      */         
/*  398 */         if (this.workbookBof.isBiff8())
/*      */         {
/*  400 */           dr = new DimensionRecord(r);
/*      */         }
/*      */         else
/*      */         {
/*  404 */           dr = new DimensionRecord(r, DimensionRecord.biff7);
/*      */         }
/*  406 */         this.numRows = dr.getNumberOfRows();
/*  407 */         this.numCols = dr.getNumberOfColumns();
/*  408 */         this.cells = new Cell[this.numRows][this.numCols];
/*      */       }
/*  410 */       else if (type == Type.LABELSST)
/*      */       {
/*  412 */         LabelSSTRecord label = new LabelSSTRecord(r, this.sharedStrings, this.formattingRecords, this.sheet);
/*      */         
/*      */ 
/*      */ 
/*  416 */         addCell(label);
/*      */       }
/*  418 */       else if ((type == Type.RK) || (type == Type.RK2))
/*      */       {
/*  420 */         RKRecord rkr = new RKRecord(r, this.formattingRecords, this.sheet);
/*      */         
/*  422 */         if (this.formattingRecords.isDate(rkr.getXFIndex()))
/*      */         {
/*  424 */           DateCell dc = new DateRecord(rkr, rkr.getXFIndex(), this.formattingRecords, this.nineteenFour, this.sheet);
/*      */           
/*  426 */           addCell(dc);
/*      */         }
/*      */         else
/*      */         {
/*  430 */           addCell(rkr);
/*      */         }
/*      */       }
/*  433 */       else if (type == Type.HLINK)
/*      */       {
/*  435 */         HyperlinkRecord hr = new HyperlinkRecord(r, this.sheet, this.workbookSettings);
/*  436 */         this.hyperlinks.add(hr);
/*      */       }
/*  438 */       else if (type == Type.MERGEDCELLS)
/*      */       {
/*  440 */         MergedCellsRecord mc = new MergedCellsRecord(r, this.sheet);
/*  441 */         if (this.mergedCells == null)
/*      */         {
/*  443 */           this.mergedCells = mc.getRanges();
/*      */         }
/*      */         else
/*      */         {
/*  447 */           Range[] newMergedCells = new Range[this.mergedCells.length + mc.getRanges().length];
/*      */           
/*  449 */           System.arraycopy(this.mergedCells, 0, newMergedCells, 0, this.mergedCells.length);
/*      */           
/*  451 */           System.arraycopy(mc.getRanges(), 0, newMergedCells, this.mergedCells.length, mc.getRanges().length);
/*      */           
/*      */ 
/*      */ 
/*  455 */           this.mergedCells = newMergedCells;
/*      */         }
/*      */       }
/*  458 */       else if (type == Type.MULRK)
/*      */       {
/*  460 */         MulRKRecord mulrk = new MulRKRecord(r);
/*      */         
/*      */ 
/*  463 */         int num = mulrk.getNumberOfColumns();
/*  464 */         int ixf = 0;
/*  465 */         for (int i = 0; i < num; i++)
/*      */         {
/*  467 */           ixf = mulrk.getXFIndex(i);
/*      */           
/*  469 */           NumberValue nv = new NumberValue(mulrk.getRow(), mulrk.getFirstColumn() + i, RKHelper.getDouble(mulrk.getRKNumber(i)), ixf, this.formattingRecords, this.sheet);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  478 */           if (this.formattingRecords.isDate(ixf))
/*      */           {
/*  480 */             DateCell dc = new DateRecord(nv, ixf, this.formattingRecords, this.nineteenFour, this.sheet);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  485 */             addCell(dc);
/*      */           }
/*      */           else
/*      */           {
/*  489 */             nv.setNumberFormat(this.formattingRecords.getNumberFormat(ixf));
/*  490 */             addCell(nv);
/*      */           }
/*      */         }
/*      */       }
/*  494 */       else if (type == Type.NUMBER)
/*      */       {
/*  496 */         NumberRecord nr = new NumberRecord(r, this.formattingRecords, this.sheet);
/*      */         
/*  498 */         if (this.formattingRecords.isDate(nr.getXFIndex()))
/*      */         {
/*  500 */           DateCell dc = new DateRecord(nr, nr.getXFIndex(), this.formattingRecords, this.nineteenFour, this.sheet);
/*      */           
/*      */ 
/*      */ 
/*  504 */           addCell(dc);
/*      */         }
/*      */         else
/*      */         {
/*  508 */           addCell(nr);
/*      */         }
/*      */       }
/*  511 */       else if (type == Type.BOOLERR)
/*      */       {
/*  513 */         BooleanRecord br = new BooleanRecord(r, this.formattingRecords, this.sheet);
/*      */         
/*  515 */         if (br.isError())
/*      */         {
/*  517 */           ErrorRecord er = new ErrorRecord(br.getRecord(), this.formattingRecords, this.sheet);
/*      */           
/*  519 */           addCell(er);
/*      */         }
/*      */         else
/*      */         {
/*  523 */           addCell(br);
/*      */         }
/*      */       }
/*  526 */       else if (type == Type.PRINTGRIDLINES)
/*      */       {
/*  528 */         printGridLinesRecord = new PrintGridLinesRecord(r);
/*  529 */         this.settings.setPrintGridLines(printGridLinesRecord.getPrintGridLines());
/*      */       }
/*  531 */       else if (type == Type.PRINTHEADERS)
/*      */       {
/*  533 */         printHeadersRecord = new PrintHeadersRecord(r);
/*  534 */         this.settings.setPrintHeaders(printHeadersRecord.getPrintHeaders());
/*      */       }
/*  536 */       else if (type == Type.WINDOW2)
/*      */       {
/*  538 */         window2Record = null;
/*      */         
/*  540 */         if (this.workbookBof.isBiff8())
/*      */         {
/*  542 */           window2Record = new Window2Record(r);
/*      */         }
/*      */         else
/*      */         {
/*  546 */           window2Record = new Window2Record(r, Window2Record.biff7);
/*      */         }
/*      */         
/*  549 */         this.settings.setShowGridLines(window2Record.getShowGridLines());
/*  550 */         this.settings.setDisplayZeroValues(window2Record.getDisplayZeroValues());
/*  551 */         this.settings.setSelected(true);
/*  552 */         this.settings.setPageBreakPreviewMode(window2Record.isPageBreakPreview());
/*      */       }
/*  554 */       else if (type == Type.PANE)
/*      */       {
/*  556 */         PaneRecord pr = new PaneRecord(r);
/*      */         
/*  558 */         if ((window2Record != null) && (window2Record.getFrozen()))
/*      */         {
/*      */ 
/*  561 */           this.settings.setVerticalFreeze(pr.getRowsVisible());
/*  562 */           this.settings.setHorizontalFreeze(pr.getColumnsVisible());
/*      */         }
/*      */       }
/*  565 */       else if (type == Type.CONTINUE)
/*      */       {
/*      */ 
/*  568 */         continueRecord = new ContinueRecord(r);
/*      */       }
/*  570 */       else if (type == Type.NOTE)
/*      */       {
/*  572 */         if (!this.workbookSettings.getDrawingsDisabled())
/*      */         {
/*  574 */           NoteRecord nr = new NoteRecord(r);
/*      */           
/*      */ 
/*  577 */           Comment comment = (Comment)comments.remove(new Integer(nr.getObjectId()));
/*      */           
/*      */ 
/*  580 */           if (comment == null)
/*      */           {
/*  582 */             logger.warn(" cannot find comment for note id " + nr.getObjectId() + "...ignoring");
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  587 */             comment.setNote(nr);
/*      */             
/*  589 */             this.drawings.add(comment);
/*      */             
/*  591 */             addCellComment(comment.getColumn(), comment.getRow(), comment.getText(), comment.getWidth(), comment.getHeight());
/*      */ 
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*  599 */       else if (type != Type.ARRAY)
/*      */       {
/*      */ 
/*      */ 
/*  603 */         if (type == Type.PROTECT)
/*      */         {
/*  605 */           ProtectRecord pr = new ProtectRecord(r);
/*  606 */           this.settings.setProtected(pr.isProtected());
/*      */         }
/*  608 */         else if (type == Type.SHAREDFORMULA)
/*      */         {
/*  610 */           if (sharedFormula == null)
/*      */           {
/*  612 */             logger.warn("Shared template formula is null - trying most recent formula template");
/*      */             
/*  614 */             SharedFormulaRecord lastSharedFormula = (SharedFormulaRecord)this.sharedFormulas.get(this.sharedFormulas.size() - 1);
/*      */             
/*      */ 
/*  617 */             if (lastSharedFormula != null)
/*      */             {
/*  619 */               sharedFormula = lastSharedFormula.getTemplateFormula();
/*      */             }
/*      */           }
/*      */           
/*  623 */           SharedFormulaRecord sfr = new SharedFormulaRecord(r, sharedFormula, this.workbook, this.workbook, this.sheet);
/*      */           
/*  625 */           this.sharedFormulas.add(sfr);
/*  626 */           sharedFormula = null;
/*      */         }
/*  628 */         else if ((type == Type.FORMULA) || (type == Type.FORMULA2))
/*      */         {
/*  630 */           FormulaRecord fr = new FormulaRecord(r, this.excelFile, this.formattingRecords, this.workbook, this.workbook, this.sheet, this.workbookSettings);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  638 */           if (fr.isShared())
/*      */           {
/*  640 */             BaseSharedFormulaRecord prevSharedFormula = sharedFormula;
/*  641 */             sharedFormula = (BaseSharedFormulaRecord)fr.getFormula();
/*      */             
/*      */ 
/*  644 */             sharedFormulaAdded = addToSharedFormulas(sharedFormula);
/*      */             
/*  646 */             if (sharedFormulaAdded)
/*      */             {
/*  648 */               sharedFormula = prevSharedFormula;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  653 */             if ((!sharedFormulaAdded) && (prevSharedFormula != null))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  660 */               addCell(revertSharedFormula(prevSharedFormula));
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  665 */             Cell cell = fr.getFormula();
/*      */             
/*      */             try
/*      */             {
/*  669 */               if (fr.getFormula().getType() == CellType.NUMBER_FORMULA)
/*      */               {
/*  671 */                 NumberFormulaRecord nfr = (NumberFormulaRecord)fr.getFormula();
/*  672 */                 if (this.formattingRecords.isDate(nfr.getXFIndex()))
/*      */                 {
/*  674 */                   cell = new DateFormulaRecord(nfr, this.formattingRecords, this.workbook, this.workbook, this.nineteenFour, this.sheet);
/*      */                 }
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  683 */               addCell(cell);
/*      */ 
/*      */             }
/*      */             catch (FormulaException e)
/*      */             {
/*      */ 
/*  689 */               logger.warn(CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow()) + " " + e.getMessage());
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*  695 */         else if (type == Type.LABEL)
/*      */         {
/*  697 */           LabelRecord lr = null;
/*      */           
/*  699 */           if (this.workbookBof.isBiff8())
/*      */           {
/*  701 */             lr = new LabelRecord(r, this.formattingRecords, this.sheet, this.workbookSettings);
/*      */           }
/*      */           else
/*      */           {
/*  705 */             lr = new LabelRecord(r, this.formattingRecords, this.sheet, this.workbookSettings, LabelRecord.biff7);
/*      */           }
/*      */           
/*  708 */           addCell(lr);
/*      */         }
/*  710 */         else if (type == Type.RSTRING)
/*      */         {
/*  712 */           RStringRecord lr = null;
/*      */           
/*      */ 
/*  715 */           Assert.verify(!this.workbookBof.isBiff8());
/*  716 */           lr = new RStringRecord(r, this.formattingRecords, this.sheet, this.workbookSettings, RStringRecord.biff7);
/*      */           
/*      */ 
/*  719 */           addCell(lr);
/*      */         }
/*  721 */         else if (type != Type.NAME)
/*      */         {
/*      */ 
/*      */ 
/*  725 */           if (type == Type.PASSWORD)
/*      */           {
/*  727 */             PasswordRecord pr = new PasswordRecord(r);
/*  728 */             this.settings.setPasswordHash(pr.getPasswordHash());
/*      */           }
/*  730 */           else if (type == Type.ROW)
/*      */           {
/*  732 */             RowRecord rr = new RowRecord(r);
/*      */             
/*      */ 
/*  735 */             if ((!rr.isDefaultHeight()) || (!rr.matchesDefaultFontHeight()) || (rr.isCollapsed()) || (rr.hasDefaultFormat()) || (rr.getOutlineLevel() != 0))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  741 */               this.rowProperties.add(rr);
/*      */             }
/*      */           }
/*  744 */           else if (type == Type.BLANK)
/*      */           {
/*  746 */             if (!this.workbookSettings.getIgnoreBlanks())
/*      */             {
/*  748 */               BlankCell bc = new BlankCell(r, this.formattingRecords, this.sheet);
/*  749 */               addCell(bc);
/*      */             }
/*      */           }
/*  752 */           else if (type == Type.MULBLANK)
/*      */           {
/*  754 */             if (!this.workbookSettings.getIgnoreBlanks())
/*      */             {
/*  756 */               MulBlankRecord mulblank = new MulBlankRecord(r);
/*      */               
/*      */ 
/*  759 */               int num = mulblank.getNumberOfColumns();
/*      */               
/*  761 */               for (int i = 0; i < num; i++)
/*      */               {
/*  763 */                 int ixf = mulblank.getXFIndex(i);
/*      */                 
/*  765 */                 MulBlankCell mbc = new MulBlankCell(mulblank.getRow(), mulblank.getFirstColumn() + i, ixf, this.formattingRecords, this.sheet);
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  772 */                 addCell(mbc);
/*      */               }
/*      */             }
/*      */           }
/*  776 */           else if (type == Type.SCL)
/*      */           {
/*  778 */             SCLRecord scl = new SCLRecord(r);
/*  779 */             this.settings.setZoomFactor(scl.getZoomFactor());
/*      */           }
/*  781 */           else if (type == Type.COLINFO)
/*      */           {
/*  783 */             ColumnInfoRecord cir = new ColumnInfoRecord(r);
/*  784 */             this.columnInfosArray.add(cir);
/*      */           }
/*  786 */           else if (type == Type.HEADER)
/*      */           {
/*  788 */             HeaderRecord hr = null;
/*  789 */             if (this.workbookBof.isBiff8())
/*      */             {
/*  791 */               hr = new HeaderRecord(r, this.workbookSettings);
/*      */             }
/*      */             else
/*      */             {
/*  795 */               hr = new HeaderRecord(r, this.workbookSettings, HeaderRecord.biff7);
/*      */             }
/*      */             
/*  798 */             HeaderFooter header = new HeaderFooter(hr.getHeader());
/*  799 */             this.settings.setHeader(header);
/*      */           }
/*  801 */           else if (type == Type.FOOTER)
/*      */           {
/*  803 */             FooterRecord fr = null;
/*  804 */             if (this.workbookBof.isBiff8())
/*      */             {
/*  806 */               fr = new FooterRecord(r, this.workbookSettings);
/*      */             }
/*      */             else
/*      */             {
/*  810 */               fr = new FooterRecord(r, this.workbookSettings, FooterRecord.biff7);
/*      */             }
/*      */             
/*  813 */             HeaderFooter footer = new HeaderFooter(fr.getFooter());
/*  814 */             this.settings.setFooter(footer);
/*      */           }
/*  816 */           else if (type == Type.SETUP)
/*      */           {
/*  818 */             SetupRecord sr = new SetupRecord(r);
/*      */             
/*      */ 
/*      */ 
/*  822 */             if (sr.getInitialized())
/*      */             {
/*  824 */               if (sr.isPortrait())
/*      */               {
/*  826 */                 this.settings.setOrientation(PageOrientation.PORTRAIT);
/*      */               }
/*      */               else
/*      */               {
/*  830 */                 this.settings.setOrientation(PageOrientation.LANDSCAPE);
/*      */               }
/*  832 */               if (sr.isRightDown())
/*      */               {
/*  834 */                 this.settings.setPageOrder(PageOrder.RIGHT_THEN_DOWN);
/*      */               }
/*      */               else
/*      */               {
/*  838 */                 this.settings.setPageOrder(PageOrder.DOWN_THEN_RIGHT);
/*      */               }
/*  840 */               this.settings.setPaperSize(PaperSize.getPaperSize(sr.getPaperSize()));
/*  841 */               this.settings.setHeaderMargin(sr.getHeaderMargin());
/*  842 */               this.settings.setFooterMargin(sr.getFooterMargin());
/*  843 */               this.settings.setScaleFactor(sr.getScaleFactor());
/*  844 */               this.settings.setPageStart(sr.getPageStart());
/*  845 */               this.settings.setFitWidth(sr.getFitWidth());
/*  846 */               this.settings.setFitHeight(sr.getFitHeight());
/*  847 */               this.settings.setHorizontalPrintResolution(sr.getHorizontalPrintResolution());
/*      */               
/*  849 */               this.settings.setVerticalPrintResolution(sr.getVerticalPrintResolution());
/*  850 */               this.settings.setCopies(sr.getCopies());
/*      */               
/*  852 */               if (this.workspaceOptions != null)
/*      */               {
/*  854 */                 this.settings.setFitToPages(this.workspaceOptions.getFitToPages());
/*      */               }
/*      */             }
/*      */           }
/*  858 */           else if (type == Type.WSBOOL)
/*      */           {
/*  860 */             this.workspaceOptions = new WorkspaceInformationRecord(r);
/*      */           }
/*  862 */           else if (type == Type.DEFCOLWIDTH)
/*      */           {
/*  864 */             DefaultColumnWidthRecord dcwr = new DefaultColumnWidthRecord(r);
/*  865 */             this.settings.setDefaultColumnWidth(dcwr.getWidth());
/*      */           }
/*  867 */           else if (type == Type.DEFAULTROWHEIGHT)
/*      */           {
/*  869 */             DefaultRowHeightRecord drhr = new DefaultRowHeightRecord(r);
/*  870 */             if (drhr.getHeight() != 0)
/*      */             {
/*  872 */               this.settings.setDefaultRowHeight(drhr.getHeight());
/*      */             }
/*      */           }
/*  875 */           else if (type == Type.CONDFMT)
/*      */           {
/*  877 */             ConditionalFormatRangeRecord cfrr = new ConditionalFormatRangeRecord(r);
/*      */             
/*  879 */             condFormat = new ConditionalFormat(cfrr);
/*  880 */             this.conditionalFormats.add(condFormat);
/*      */           }
/*  882 */           else if (type == Type.CF)
/*      */           {
/*  884 */             ConditionalFormatRecord cfr = new ConditionalFormatRecord(r);
/*  885 */             condFormat.addCondition(cfr);
/*      */           }
/*  887 */           else if (type == Type.FILTERMODE)
/*      */           {
/*  889 */             filterMode = new FilterModeRecord(r);
/*      */           }
/*  891 */           else if (type == Type.AUTOFILTERINFO)
/*      */           {
/*  893 */             autoFilterInfo = new AutoFilterInfoRecord(r);
/*      */           }
/*  895 */           else if (type == Type.AUTOFILTER)
/*      */           {
/*  897 */             if (!this.workbookSettings.getAutoFilterDisabled())
/*      */             {
/*  899 */               AutoFilterRecord af = new AutoFilterRecord(r);
/*      */               
/*  901 */               if (this.autoFilter == null)
/*      */               {
/*  903 */                 this.autoFilter = new AutoFilter(filterMode, autoFilterInfo);
/*  904 */                 filterMode = null;
/*  905 */                 autoFilterInfo = null;
/*      */               }
/*      */               
/*  908 */               this.autoFilter.add(af);
/*      */             }
/*      */           }
/*  911 */           else if (type == Type.LEFTMARGIN)
/*      */           {
/*  913 */             MarginRecord m = new LeftMarginRecord(r);
/*  914 */             this.settings.setLeftMargin(m.getMargin());
/*      */           }
/*  916 */           else if (type == Type.RIGHTMARGIN)
/*      */           {
/*  918 */             MarginRecord m = new RightMarginRecord(r);
/*  919 */             this.settings.setRightMargin(m.getMargin());
/*      */           }
/*  921 */           else if (type == Type.TOPMARGIN)
/*      */           {
/*  923 */             MarginRecord m = new TopMarginRecord(r);
/*  924 */             this.settings.setTopMargin(m.getMargin());
/*      */           }
/*  926 */           else if (type == Type.BOTTOMMARGIN)
/*      */           {
/*  928 */             MarginRecord m = new BottomMarginRecord(r);
/*  929 */             this.settings.setBottomMargin(m.getMargin());
/*      */           }
/*  931 */           else if (type == Type.HORIZONTALPAGEBREAKS)
/*      */           {
/*  933 */             HorizontalPageBreaksRecord dr = null;
/*      */             
/*  935 */             if (this.workbookBof.isBiff8())
/*      */             {
/*  937 */               dr = new HorizontalPageBreaksRecord(r);
/*      */             }
/*      */             else
/*      */             {
/*  941 */               dr = new HorizontalPageBreaksRecord(r, HorizontalPageBreaksRecord.biff7);
/*      */             }
/*      */             
/*  944 */             this.rowBreaks = dr.getRowBreaks();
/*      */           }
/*  946 */           else if (type == Type.VERTICALPAGEBREAKS)
/*      */           {
/*  948 */             VerticalPageBreaksRecord dr = null;
/*      */             
/*  950 */             if (this.workbookBof.isBiff8())
/*      */             {
/*  952 */               dr = new VerticalPageBreaksRecord(r);
/*      */             }
/*      */             else
/*      */             {
/*  956 */               dr = new VerticalPageBreaksRecord(r, VerticalPageBreaksRecord.biff7);
/*      */             }
/*      */             
/*  959 */             this.columnBreaks = dr.getColumnBreaks();
/*      */           } else {
/*  961 */             if (type == Type.PLS)
/*      */             {
/*  963 */               this.plsRecord = new PLSRecord(r);
/*      */               
/*      */ 
/*  966 */               while (this.excelFile.peek().getType() == Type.CONTINUE)
/*      */               {
/*  968 */                 r.addContinueRecord(this.excelFile.next());
/*      */               }
/*      */             }
/*  971 */             if (type == Type.DVAL)
/*      */             {
/*  973 */               if (!this.workbookSettings.getCellValidationDisabled())
/*      */               {
/*  975 */                 DataValidityListRecord dvlr = new DataValidityListRecord(r);
/*  976 */                 if (dvlr.getObjectId() == -1)
/*      */                 {
/*  978 */                   if ((msoRecord != null) && (objRecord == null))
/*      */                   {
/*      */ 
/*  981 */                     if (this.drawingData == null)
/*      */                     {
/*  983 */                       this.drawingData = new DrawingData();
/*      */                     }
/*      */                     
/*  986 */                     Drawing2 d2 = new Drawing2(msoRecord, this.drawingData, this.workbook.getDrawingGroup());
/*      */                     
/*  988 */                     this.drawings.add(d2);
/*  989 */                     msoRecord = null;
/*      */                     
/*  991 */                     this.dataValidation = new DataValidation(dvlr);
/*      */ 
/*      */                   }
/*      */                   else
/*      */                   {
/*  996 */                     this.dataValidation = new DataValidation(dvlr);
/*      */                   }
/*      */                 }
/*  999 */                 else if (objectIds.contains(new Integer(dvlr.getObjectId())))
/*      */                 {
/* 1001 */                   this.dataValidation = new DataValidation(dvlr);
/*      */                 }
/*      */                 else
/*      */                 {
/* 1005 */                   logger.warn("object id " + dvlr.getObjectId() + " referenced " + " by data validity list record not found - ignoring");
/*      */                 }
/*      */                 
/*      */               }
/*      */             }
/* 1010 */             else if (type == Type.HCENTER)
/*      */             {
/* 1012 */               CentreRecord hr = new CentreRecord(r);
/* 1013 */               this.settings.setHorizontalCentre(hr.isCentre());
/*      */             }
/* 1015 */             else if (type == Type.VCENTER)
/*      */             {
/* 1017 */               CentreRecord vc = new CentreRecord(r);
/* 1018 */               this.settings.setVerticalCentre(vc.isCentre());
/*      */             }
/* 1020 */             else if (type == Type.DV)
/*      */             {
/* 1022 */               if (!this.workbookSettings.getCellValidationDisabled())
/*      */               {
/* 1024 */                 DataValiditySettingsRecord dvsr = new DataValiditySettingsRecord(r, this.workbook, this.workbook, this.workbook.getSettings());
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 1029 */                 if (this.dataValidation != null)
/*      */                 {
/* 1031 */                   this.dataValidation.add(dvsr);
/* 1032 */                   addCellValidation(dvsr.getFirstColumn(), dvsr.getFirstRow(), dvsr.getLastColumn(), dvsr.getLastRow(), dvsr);
/*      */ 
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/*      */ 
/*      */ 
/* 1040 */                   logger.warn("cannot add data validity settings");
/*      */                 }
/*      */               }
/*      */             }
/* 1044 */             else if (type == Type.OBJ)
/*      */             {
/* 1046 */               objRecord = new ObjRecord(r);
/*      */               
/* 1048 */               if (!this.workbookSettings.getDrawingsDisabled())
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 1053 */                 if ((msoRecord == null) && (continueRecord != null))
/*      */                 {
/* 1055 */                   logger.warn("Cannot find drawing record - using continue record");
/* 1056 */                   msoRecord = new MsoDrawingRecord(continueRecord.getRecord());
/* 1057 */                   continueRecord = null;
/*      */                 }
/* 1059 */                 handleObjectRecord(objRecord, msoRecord, comments);
/* 1060 */                 objectIds.add(new Integer(objRecord.getObjectId()));
/*      */               }
/*      */               
/*      */ 
/* 1064 */               if (objRecord.getType() != ObjRecord.CHART)
/*      */               {
/* 1066 */                 objRecord = null;
/* 1067 */                 msoRecord = null;
/*      */               }
/*      */             }
/* 1070 */             else if (type == Type.MSODRAWING)
/*      */             {
/* 1072 */               if (!this.workbookSettings.getDrawingsDisabled())
/*      */               {
/* 1074 */                 if (msoRecord != null)
/*      */                 {
/*      */ 
/*      */ 
/* 1078 */                   this.drawingData.addRawData(msoRecord.getData());
/*      */                 }
/* 1080 */                 msoRecord = new MsoDrawingRecord(r);
/*      */                 
/* 1082 */                 if (firstMsoRecord)
/*      */                 {
/* 1084 */                   msoRecord.setFirst();
/* 1085 */                   firstMsoRecord = false;
/*      */                 }
/*      */               }
/*      */             }
/* 1089 */             else if (type == Type.BUTTONPROPERTYSET)
/*      */             {
/* 1091 */               this.buttonPropertySet = new ButtonPropertySetRecord(r);
/*      */             }
/* 1093 */             else if (type == Type.CALCMODE)
/*      */             {
/* 1095 */               CalcModeRecord cmr = new CalcModeRecord(r);
/* 1096 */               this.settings.setAutomaticFormulaCalculation(cmr.isAutomatic());
/*      */             }
/* 1098 */             else if (type == Type.SAVERECALC)
/*      */             {
/* 1100 */               SaveRecalcRecord cmr = new SaveRecalcRecord(r);
/* 1101 */               this.settings.setRecalculateFormulasBeforeSave(cmr.getRecalculateOnSave());
/*      */             }
/* 1103 */             else if (type == Type.GUTS)
/*      */             {
/* 1105 */               GuttersRecord gr = new GuttersRecord(r);
/* 1106 */               this.maxRowOutlineLevel = (gr.getRowOutlineLevel() > 0 ? gr.getRowOutlineLevel() - 1 : 0);
/*      */               
/* 1108 */               this.maxColumnOutlineLevel = (gr.getColumnOutlineLevel() > 0 ? gr.getRowOutlineLevel() - 1 : 0);
/*      */ 
/*      */             }
/* 1111 */             else if (type == Type.BOF)
/*      */             {
/* 1113 */               BOFRecord br = new BOFRecord(r);
/* 1114 */               Assert.verify(!br.isWorksheet());
/*      */               
/* 1116 */               int startpos = this.excelFile.getPos() - r.getLength() - 4;
/*      */               
/*      */ 
/*      */ 
/* 1120 */               Record r2 = this.excelFile.next();
/* 1121 */               while (r2.getCode() != Type.EOF.value)
/*      */               {
/* 1123 */                 r2 = this.excelFile.next();
/*      */               }
/*      */               
/* 1126 */               if (br.isChart())
/*      */               {
/* 1128 */                 if (!this.workbook.getWorkbookBof().isBiff8())
/*      */                 {
/* 1130 */                   logger.warn("only biff8 charts are supported");
/*      */                 }
/*      */                 else
/*      */                 {
/* 1134 */                   if (this.drawingData == null)
/*      */                   {
/* 1136 */                     this.drawingData = new DrawingData();
/*      */                   }
/*      */                   
/* 1139 */                   if (!this.workbookSettings.getDrawingsDisabled())
/*      */                   {
/* 1141 */                     Chart chart = new Chart(msoRecord, objRecord, this.drawingData, startpos, this.excelFile.getPos(), this.excelFile, this.workbookSettings);
/*      */                     
/*      */ 
/* 1144 */                     this.charts.add(chart);
/*      */                     
/* 1146 */                     if (this.workbook.getDrawingGroup() != null)
/*      */                     {
/* 1148 */                       this.workbook.getDrawingGroup().add(chart);
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 
/*      */ 
/* 1154 */                 msoRecord = null;
/* 1155 */                 objRecord = null;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 1160 */               if (this.sheetBof.isChart())
/*      */               {
/* 1162 */                 cont = false;
/*      */               }
/*      */             }
/* 1165 */             else if (type == Type.EOF)
/*      */             {
/* 1167 */               cont = false;
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/* 1172 */     this.excelFile.restorePos();
/*      */     
/*      */ 
/* 1175 */     if (this.outOfBoundsCells.size() > 0)
/*      */     {
/* 1177 */       handleOutOfBoundsCells();
/*      */     }
/*      */     
/*      */ 
/* 1181 */     Iterator i = this.sharedFormulas.iterator();
/*      */     
/* 1183 */     while (i.hasNext())
/*      */     {
/* 1185 */       SharedFormulaRecord sfr = (SharedFormulaRecord)i.next();
/*      */       
/* 1187 */       Cell[] sfnr = sfr.getFormulas(this.formattingRecords, this.nineteenFour);
/*      */       
/* 1189 */       for (int sf = 0; sf < sfnr.length; sf++)
/*      */       {
/* 1191 */         addCell(sfnr[sf]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1197 */     if ((!sharedFormulaAdded) && (sharedFormula != null))
/*      */     {
/* 1199 */       addCell(revertSharedFormula(sharedFormula));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1204 */     if ((msoRecord != null) && (this.workbook.getDrawingGroup() != null))
/*      */     {
/* 1206 */       this.workbook.getDrawingGroup().setDrawingsOmitted(msoRecord, objRecord);
/*      */     }
/*      */     
/*      */ 
/* 1210 */     if (!comments.isEmpty())
/*      */     {
/* 1212 */       logger.warn("Not all comments have a corresponding Note record");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean addToSharedFormulas(BaseSharedFormulaRecord fr)
/*      */   {
/* 1225 */     boolean added = false;
/* 1226 */     SharedFormulaRecord sfr = null;
/*      */     
/* 1228 */     int i = 0; for (int size = this.sharedFormulas.size(); (i < size) && (!added); i++)
/*      */     {
/* 1230 */       sfr = (SharedFormulaRecord)this.sharedFormulas.get(i);
/* 1231 */       added = sfr.add(fr);
/*      */     }
/*      */     
/* 1234 */     return added;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Cell revertSharedFormula(BaseSharedFormulaRecord f)
/*      */   {
/* 1250 */     int pos = this.excelFile.getPos();
/* 1251 */     this.excelFile.setPos(f.getFilePos());
/*      */     
/* 1253 */     FormulaRecord fr = new FormulaRecord(f.getRecord(), this.excelFile, this.formattingRecords, this.workbook, this.workbook, FormulaRecord.ignoreSharedFormula, this.sheet, this.workbookSettings);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1264 */       Cell cell = fr.getFormula();
/*      */       
/*      */ 
/* 1267 */       if (fr.getFormula().getType() == CellType.NUMBER_FORMULA)
/*      */       {
/* 1269 */         NumberFormulaRecord nfr = (NumberFormulaRecord)fr.getFormula();
/* 1270 */         if (this.formattingRecords.isDate(fr.getXFIndex()))
/*      */         {
/* 1272 */           cell = new DateFormulaRecord(nfr, this.formattingRecords, this.workbook, this.workbook, this.nineteenFour, this.sheet);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1281 */       this.excelFile.setPos(pos);
/* 1282 */       return cell;
/*      */ 
/*      */     }
/*      */     catch (FormulaException e)
/*      */     {
/*      */ 
/* 1288 */       logger.warn(CellReferenceHelper.getCellReference(fr.getColumn(), fr.getRow()) + " " + e.getMessage());
/*      */     }
/*      */     
/*      */ 
/* 1292 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getNumRows()
/*      */   {
/* 1304 */     return this.numRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getNumCols()
/*      */   {
/* 1314 */     return this.numCols;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Cell[][] getCells()
/*      */   {
/* 1324 */     return this.cells;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ArrayList getRowProperties()
/*      */   {
/* 1334 */     return this.rowProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ArrayList getColumnInfosArray()
/*      */   {
/* 1344 */     return this.columnInfosArray;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ArrayList getHyperlinks()
/*      */   {
/* 1354 */     return this.hyperlinks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ArrayList getConditionalFormats()
/*      */   {
/* 1364 */     return this.conditionalFormats;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final AutoFilter getAutoFilter()
/*      */   {
/* 1374 */     return this.autoFilter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ArrayList getCharts()
/*      */   {
/* 1384 */     return this.charts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ArrayList getDrawings()
/*      */   {
/* 1394 */     return this.drawings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final DataValidation getDataValidation()
/*      */   {
/* 1404 */     return this.dataValidation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Range[] getMergedCells()
/*      */   {
/* 1414 */     return this.mergedCells;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final SheetSettings getSettings()
/*      */   {
/* 1424 */     return this.settings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int[] getRowBreaks()
/*      */   {
/* 1434 */     return this.rowBreaks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int[] getColumnBreaks()
/*      */   {
/* 1444 */     return this.columnBreaks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final WorkspaceInformationRecord getWorkspaceOptions()
/*      */   {
/* 1454 */     return this.workspaceOptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final PLSRecord getPLS()
/*      */   {
/* 1464 */     return this.plsRecord;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ButtonPropertySetRecord getButtonPropertySet()
/*      */   {
/* 1474 */     return this.buttonPropertySet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addCellComment(int col, int row, String text, double width, double height)
/*      */   {
/* 1492 */     Cell c = this.cells[row][col];
/* 1493 */     if (c == null)
/*      */     {
/* 1495 */       logger.warn("Cell at " + CellReferenceHelper.getCellReference(col, row) + " not present - adding a blank");
/*      */       
/* 1497 */       MulBlankCell mbc = new MulBlankCell(row, col, 0, this.formattingRecords, this.sheet);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1502 */       CellFeatures cf = new CellFeatures();
/* 1503 */       cf.setReadComment(text, width, height);
/* 1504 */       mbc.setCellFeatures(cf);
/* 1505 */       addCell(mbc);
/*      */       
/* 1507 */       return;
/*      */     }
/*      */     
/* 1510 */     if ((c instanceof CellFeaturesAccessor))
/*      */     {
/* 1512 */       CellFeaturesAccessor cv = (CellFeaturesAccessor)c;
/* 1513 */       CellFeatures cf = cv.getCellFeatures();
/*      */       
/* 1515 */       if (cf == null)
/*      */       {
/* 1517 */         cf = new CellFeatures();
/* 1518 */         cv.setCellFeatures(cf);
/*      */       }
/*      */       
/* 1521 */       cf.setReadComment(text, width, height);
/*      */     }
/*      */     else
/*      */     {
/* 1525 */       logger.warn("Not able to add comment to cell type " + c.getClass().getName() + " at " + CellReferenceHelper.getCellReference(col, row));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addCellValidation(int col1, int row1, int col2, int row2, DataValiditySettingsRecord dvsr)
/*      */   {
/* 1546 */     for (int row = row1; row <= row2; row++)
/*      */     {
/* 1548 */       for (int col = col1; col <= col2; col++)
/*      */       {
/* 1550 */         Cell c = null;
/*      */         
/* 1552 */         if ((this.cells.length > row) && (this.cells[row].length > col))
/*      */         {
/* 1554 */           c = this.cells[row][col];
/*      */         }
/*      */         
/* 1557 */         if (c == null)
/*      */         {
/* 1559 */           MulBlankCell mbc = new MulBlankCell(row, col, 0, this.formattingRecords, this.sheet);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1564 */           CellFeatures cf = new CellFeatures();
/* 1565 */           cf.setValidationSettings(dvsr);
/* 1566 */           mbc.setCellFeatures(cf);
/* 1567 */           addCell(mbc);
/*      */         }
/* 1569 */         else if ((c instanceof CellFeaturesAccessor))
/*      */         {
/* 1571 */           CellFeaturesAccessor cv = (CellFeaturesAccessor)c;
/* 1572 */           CellFeatures cf = cv.getCellFeatures();
/*      */           
/* 1574 */           if (cf == null)
/*      */           {
/* 1576 */             cf = new CellFeatures();
/* 1577 */             cv.setCellFeatures(cf);
/*      */           }
/*      */           
/* 1580 */           cf.setValidationSettings(dvsr);
/*      */         }
/*      */         else
/*      */         {
/* 1584 */           logger.warn("Not able to add comment to cell type " + c.getClass().getName() + " at " + CellReferenceHelper.getCellReference(col, row));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleObjectRecord(ObjRecord objRecord, MsoDrawingRecord msoRecord, HashMap comments)
/*      */   {
/* 1603 */     if (msoRecord == null)
/*      */     {
/* 1605 */       logger.warn("Object record is not associated with a drawing  record - ignoring");
/*      */       
/* 1607 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1613 */       if (objRecord.getType() == ObjRecord.PICTURE)
/*      */       {
/* 1615 */         if (this.drawingData == null)
/*      */         {
/* 1617 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1620 */         Drawing drawing = new Drawing(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.sheet);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1625 */         this.drawings.add(drawing);
/* 1626 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1630 */       if (objRecord.getType() == ObjRecord.EXCELNOTE)
/*      */       {
/* 1632 */         if (this.drawingData == null)
/*      */         {
/* 1634 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1637 */         Comment comment = new Comment(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1645 */         Record r2 = this.excelFile.next();
/* 1646 */         if ((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE))
/*      */         {
/* 1648 */           MsoDrawingRecord mso = new MsoDrawingRecord(r2);
/* 1649 */           comment.addMso(mso);
/* 1650 */           r2 = this.excelFile.next();
/*      */         }
/* 1652 */         Assert.verify(r2.getType() == Type.TXO);
/* 1653 */         TextObjectRecord txo = new TextObjectRecord(r2);
/* 1654 */         comment.setTextObject(txo);
/*      */         
/* 1656 */         r2 = this.excelFile.next();
/* 1657 */         Assert.verify(r2.getType() == Type.CONTINUE);
/* 1658 */         ContinueRecord text = new ContinueRecord(r2);
/* 1659 */         comment.setText(text);
/*      */         
/* 1661 */         r2 = this.excelFile.next();
/* 1662 */         if (r2.getType() == Type.CONTINUE)
/*      */         {
/* 1664 */           ContinueRecord formatting = new ContinueRecord(r2);
/* 1665 */           comment.setFormatting(formatting);
/*      */         }
/*      */         
/* 1668 */         comments.put(new Integer(comment.getObjectId()), comment);
/* 1669 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1673 */       if (objRecord.getType() == ObjRecord.COMBOBOX)
/*      */       {
/* 1675 */         if (this.drawingData == null)
/*      */         {
/* 1677 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1680 */         ComboBox comboBox = new ComboBox(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1685 */         this.drawings.add(comboBox);
/* 1686 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1690 */       if (objRecord.getType() == ObjRecord.CHECKBOX)
/*      */       {
/* 1692 */         if (this.drawingData == null)
/*      */         {
/* 1694 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1697 */         CheckBox checkBox = new CheckBox(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1703 */         Record r2 = this.excelFile.next();
/* 1704 */         Assert.verify((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE));
/*      */         
/* 1706 */         if ((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE))
/*      */         {
/* 1708 */           MsoDrawingRecord mso = new MsoDrawingRecord(r2);
/* 1709 */           checkBox.addMso(mso);
/* 1710 */           r2 = this.excelFile.next();
/*      */         }
/*      */         
/* 1713 */         Assert.verify(r2.getType() == Type.TXO);
/* 1714 */         TextObjectRecord txo = new TextObjectRecord(r2);
/* 1715 */         checkBox.setTextObject(txo);
/*      */         
/* 1717 */         if (txo.getTextLength() == 0)
/*      */         {
/* 1719 */           return;
/*      */         }
/*      */         
/* 1722 */         r2 = this.excelFile.next();
/* 1723 */         Assert.verify(r2.getType() == Type.CONTINUE);
/* 1724 */         ContinueRecord text = new ContinueRecord(r2);
/* 1725 */         checkBox.setText(text);
/*      */         
/* 1727 */         r2 = this.excelFile.next();
/* 1728 */         if (r2.getType() == Type.CONTINUE)
/*      */         {
/* 1730 */           ContinueRecord formatting = new ContinueRecord(r2);
/* 1731 */           checkBox.setFormatting(formatting);
/*      */         }
/*      */         
/* 1734 */         this.drawings.add(checkBox);
/*      */         
/* 1736 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1740 */       if (objRecord.getType() == ObjRecord.BUTTON)
/*      */       {
/* 1742 */         if (this.drawingData == null)
/*      */         {
/* 1744 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1747 */         Button button = new Button(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1753 */         Record r2 = this.excelFile.next();
/* 1754 */         Assert.verify((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE));
/*      */         
/* 1756 */         if ((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE))
/*      */         {
/*      */ 
/* 1759 */           MsoDrawingRecord mso = new MsoDrawingRecord(r2);
/* 1760 */           button.addMso(mso);
/* 1761 */           r2 = this.excelFile.next();
/*      */         }
/*      */         
/* 1764 */         Assert.verify(r2.getType() == Type.TXO);
/* 1765 */         TextObjectRecord txo = new TextObjectRecord(r2);
/* 1766 */         button.setTextObject(txo);
/*      */         
/* 1768 */         r2 = this.excelFile.next();
/* 1769 */         Assert.verify(r2.getType() == Type.CONTINUE);
/* 1770 */         ContinueRecord text = new ContinueRecord(r2);
/* 1771 */         button.setText(text);
/*      */         
/* 1773 */         r2 = this.excelFile.next();
/* 1774 */         if (r2.getType() == Type.CONTINUE)
/*      */         {
/* 1776 */           ContinueRecord formatting = new ContinueRecord(r2);
/* 1777 */           button.setFormatting(formatting);
/*      */         }
/*      */         
/* 1780 */         this.drawings.add(button);
/*      */         
/* 1782 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1786 */       if (objRecord.getType() == ObjRecord.TEXT)
/*      */       {
/* 1788 */         logger.warn(objRecord.getType() + " Object on sheet \"" + this.sheet.getName() + "\" not supported - omitting");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1793 */         if (this.drawingData == null)
/*      */         {
/* 1795 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1798 */         this.drawingData.addData(msoRecord.getData());
/*      */         
/* 1800 */         Record r2 = this.excelFile.next();
/* 1801 */         Assert.verify((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE));
/*      */         
/* 1803 */         if ((r2.getType() == Type.MSODRAWING) || (r2.getType() == Type.CONTINUE))
/*      */         {
/*      */ 
/* 1806 */           MsoDrawingRecord mso = new MsoDrawingRecord(r2);
/* 1807 */           this.drawingData.addRawData(mso.getData());
/* 1808 */           r2 = this.excelFile.next();
/*      */         }
/*      */         
/* 1811 */         Assert.verify(r2.getType() == Type.TXO);
/*      */         
/* 1813 */         if (this.workbook.getDrawingGroup() != null)
/*      */         {
/* 1815 */           this.workbook.getDrawingGroup().setDrawingsOmitted(msoRecord, objRecord);
/*      */         }
/*      */         
/*      */ 
/* 1819 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1823 */       if (objRecord.getType() != ObjRecord.CHART)
/*      */       {
/* 1825 */         logger.warn(objRecord.getType() + " Object on sheet \"" + this.sheet.getName() + "\" not supported - omitting");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1830 */         if (this.drawingData == null)
/*      */         {
/* 1832 */           this.drawingData = new DrawingData();
/*      */         }
/*      */         
/* 1835 */         this.drawingData.addData(msoRecord.getData());
/*      */         
/* 1837 */         if (this.workbook.getDrawingGroup() != null)
/*      */         {
/* 1839 */           this.workbook.getDrawingGroup().setDrawingsOmitted(msoRecord, objRecord);
/*      */         }
/*      */         
/*      */ 
/* 1843 */         return;
/*      */       }
/*      */     }
/*      */     catch (DrawingDataException e)
/*      */     {
/* 1848 */       logger.warn(e.getMessage() + "...disabling drawings for the remainder of the workbook");
/*      */       
/* 1850 */       this.workbookSettings.setDrawingsDisabled(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   DrawingData getDrawingData()
/*      */   {
/* 1859 */     return this.drawingData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleOutOfBoundsCells()
/*      */   {
/* 1868 */     int resizedRows = this.numRows;
/* 1869 */     int resizedCols = this.numCols;
/*      */     
/*      */ 
/* 1872 */     for (Iterator i = this.outOfBoundsCells.iterator(); i.hasNext();)
/*      */     {
/* 1874 */       Cell cell = (Cell)i.next();
/* 1875 */       resizedRows = Math.max(resizedRows, cell.getRow() + 1);
/* 1876 */       resizedCols = Math.max(resizedCols, cell.getColumn() + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1885 */     if (resizedCols > this.numCols)
/*      */     {
/* 1887 */       for (int r = 0; r < this.numRows; r++)
/*      */       {
/* 1889 */         Cell[] newRow = new Cell[resizedCols];
/* 1890 */         Cell[] oldRow = this.cells[r];
/* 1891 */         System.arraycopy(oldRow, 0, newRow, 0, oldRow.length);
/* 1892 */         this.cells[r] = newRow;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1897 */     if (resizedRows > this.numRows)
/*      */     {
/* 1899 */       Cell[][] newCells = new Cell[resizedRows][];
/* 1900 */       System.arraycopy(this.cells, 0, newCells, 0, this.cells.length);
/* 1901 */       this.cells = newCells;
/*      */       
/*      */ 
/* 1904 */       for (int i = this.numRows; i < resizedRows; i++)
/*      */       {
/* 1906 */         newCells[i] = new Cell[resizedCols];
/*      */       }
/*      */     }
/*      */     
/* 1910 */     this.numRows = resizedRows;
/* 1911 */     this.numCols = resizedCols;
/*      */     
/*      */ 
/* 1914 */     for (Iterator i = this.outOfBoundsCells.iterator(); i.hasNext();)
/*      */     {
/* 1916 */       Cell cell = (Cell)i.next();
/* 1917 */       addCell(cell);
/*      */     }
/*      */     
/* 1920 */     this.outOfBoundsCells.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnOutlineLevel()
/*      */   {
/* 1930 */     return this.maxColumnOutlineLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxRowOutlineLevel()
/*      */   {
/* 1940 */     return this.maxRowOutlineLevel;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\SheetReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */