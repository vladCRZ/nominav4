/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.StringFormulaCell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringFormulaRecord
/*     */   extends CellValue
/*     */   implements LabelCell, FormulaData, StringFormulaCell
/*     */ {
/*  49 */   private static Logger logger = Logger.getLogger(StringFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExternalSheet externalSheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookMethods nameTable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formulaString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringFormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, WorkbookSettings ws)
/*     */   {
/*  95 */     super(t, fr, si);
/*     */     
/*  97 */     this.externalSheet = es;
/*  98 */     this.nameTable = nt;
/*     */     
/* 100 */     this.data = getRecord().getData();
/*     */     
/* 102 */     int pos = excelFile.getPos();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 107 */     Record nextRecord = excelFile.next();
/* 108 */     int count = 0;
/* 109 */     while ((nextRecord.getType() != Type.STRING) && (count < 4))
/*     */     {
/* 111 */       nextRecord = excelFile.next();
/* 112 */       count++;
/*     */     }
/* 114 */     Assert.verify(count < 4, " @ " + pos);
/* 115 */     byte[] stringData = nextRecord.getData();
/*     */     
/*     */ 
/* 118 */     nextRecord = excelFile.peek();
/* 119 */     while (nextRecord.getType() == Type.CONTINUE)
/*     */     {
/* 121 */       nextRecord = excelFile.next();
/* 122 */       byte[] d = new byte[stringData.length + nextRecord.getLength() - 1];
/* 123 */       System.arraycopy(stringData, 0, d, 0, stringData.length);
/* 124 */       System.arraycopy(nextRecord.getData(), 1, d, stringData.length, nextRecord.getLength() - 1);
/*     */       
/* 126 */       stringData = d;
/* 127 */       nextRecord = excelFile.peek();
/*     */     }
/* 129 */     readString(stringData, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringFormulaRecord(Record t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si)
/*     */   {
/* 149 */     super(t, fr, si);
/*     */     
/* 151 */     this.externalSheet = es;
/* 152 */     this.nameTable = nt;
/*     */     
/* 154 */     this.data = getRecord().getData();
/* 155 */     this.value = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readString(byte[] d, WorkbookSettings ws)
/*     */   {
/* 167 */     int pos = 0;
/* 168 */     int chars = IntegerHelper.getInt(d[0], d[1]);
/*     */     
/* 170 */     if (chars == 0)
/*     */     {
/* 172 */       this.value = "";
/* 173 */       return;
/*     */     }
/* 175 */     pos += 2;
/* 176 */     int optionFlags = d[pos];
/* 177 */     pos++;
/*     */     
/* 179 */     if ((optionFlags & 0xF) != optionFlags)
/*     */     {
/*     */ 
/*     */ 
/* 183 */       pos = 0;
/* 184 */       chars = IntegerHelper.getInt(d[0], (byte)0);
/* 185 */       optionFlags = d[1];
/* 186 */       pos = 2;
/*     */     }
/*     */     
/*     */ 
/* 190 */     boolean extendedString = (optionFlags & 0x4) != 0;
/*     */     
/*     */ 
/* 193 */     boolean richString = (optionFlags & 0x8) != 0;
/*     */     
/* 195 */     if (richString)
/*     */     {
/* 197 */       pos += 2;
/*     */     }
/*     */     
/* 200 */     if (extendedString)
/*     */     {
/* 202 */       pos += 4;
/*     */     }
/*     */     
/*     */ 
/* 206 */     boolean asciiEncoding = (optionFlags & 0x1) == 0;
/*     */     
/* 208 */     if (asciiEncoding)
/*     */     {
/* 210 */       this.value = StringHelper.getString(d, chars, pos, ws);
/*     */     }
/*     */     else
/*     */     {
/* 214 */       this.value = StringHelper.getUnicodeString(d, chars, pos);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 225 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/* 235 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 245 */     return CellType.STRING_FORMULA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 256 */     if (!getSheet().getWorkbook().getWorkbookBof().isBiff8())
/*     */     {
/* 258 */       throw new FormulaException(FormulaException.BIFF8_SUPPORTED);
/*     */     }
/*     */     
/*     */ 
/* 262 */     byte[] d = new byte[this.data.length - 6];
/* 263 */     System.arraycopy(this.data, 6, d, 0, this.data.length - 6);
/*     */     
/* 265 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 276 */     if (this.formulaString == null)
/*     */     {
/* 278 */       byte[] tokens = new byte[this.data.length - 22];
/* 279 */       System.arraycopy(this.data, 22, tokens, 0, tokens.length);
/* 280 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */       
/*     */ 
/* 283 */       fp.parse();
/* 284 */       this.formulaString = fp.getFormula();
/*     */     }
/*     */     
/* 287 */     return this.formulaString;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\StringFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */