/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VerticalPageBreaksRecord
/*    */   extends RecordData
/*    */ {
/* 35 */   private final Logger logger = Logger.getLogger(VerticalPageBreaksRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int[] columnBreaks;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */   public static Biff7 biff7 = new Biff7(null);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public VerticalPageBreaksRecord(Record t)
/*    */   {
/* 56 */     super(t);
/*    */     
/* 58 */     byte[] data = t.getData();
/*    */     
/* 60 */     int numbreaks = IntegerHelper.getInt(data[0], data[1]);
/* 61 */     int pos = 2;
/* 62 */     this.columnBreaks = new int[numbreaks];
/*    */     
/* 64 */     for (int i = 0; i < numbreaks; i++)
/*    */     {
/* 66 */       this.columnBreaks[i] = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 67 */       pos += 6;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public VerticalPageBreaksRecord(Record t, Biff7 biff7)
/*    */   {
/* 79 */     super(t);
/*    */     
/* 81 */     byte[] data = t.getData();
/* 82 */     int numbreaks = IntegerHelper.getInt(data[0], data[1]);
/* 83 */     int pos = 2;
/* 84 */     this.columnBreaks = new int[numbreaks];
/* 85 */     for (int i = 0; i < numbreaks; i++)
/*    */     {
/* 87 */       this.columnBreaks[i] = IntegerHelper.getInt(data[pos], data[(pos + 1)]);
/* 88 */       pos += 2;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int[] getColumnBreaks()
/*    */   {
/* 99 */     return this.columnBreaks;
/*    */   }
/*    */   
/*    */   private static class Biff7 {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\VerticalPageBreaksRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */