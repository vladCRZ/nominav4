/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Window2Record
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(Window2Record.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean selected;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean showGridLines;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean displayZeroValues;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean frozenPanes;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean frozenNotSplit;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean pageBreakPreviewMode;
/*     */   
/*     */ 
/*     */ 
/*     */   private int pageBreakPreviewMagnification;
/*     */   
/*     */ 
/*     */ 
/*     */   private int normalMagnification;
/*     */   
/*     */ 
/*     */ 
/*  74 */   public static final Biff7 biff7 = new Biff7(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Window2Record(Record t)
/*     */   {
/*  83 */     super(t);
/*  84 */     byte[] data = t.getData();
/*     */     
/*  86 */     int options = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  88 */     this.selected = ((options & 0x200) != 0);
/*  89 */     this.showGridLines = ((options & 0x2) != 0);
/*  90 */     this.frozenPanes = ((options & 0x8) != 0);
/*  91 */     this.displayZeroValues = ((options & 0x10) != 0);
/*  92 */     this.frozenNotSplit = ((options & 0x100) != 0);
/*  93 */     this.pageBreakPreviewMode = ((options & 0x800) != 0);
/*     */     
/*  95 */     this.pageBreakPreviewMagnification = IntegerHelper.getInt(data[10], data[11]);
/*  96 */     this.normalMagnification = IntegerHelper.getInt(data[12], data[13]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Window2Record(Record t, Biff7 biff7)
/*     */   {
/* 108 */     super(t);
/* 109 */     byte[] data = t.getData();
/*     */     
/* 111 */     int options = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/* 113 */     this.selected = ((options & 0x200) != 0);
/* 114 */     this.showGridLines = ((options & 0x2) != 0);
/* 115 */     this.frozenPanes = ((options & 0x8) != 0);
/* 116 */     this.displayZeroValues = ((options & 0x10) != 0);
/* 117 */     this.frozenNotSplit = ((options & 0x100) != 0);
/* 118 */     this.pageBreakPreviewMode = ((options & 0x800) != 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSelected()
/*     */   {
/* 128 */     return this.selected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getShowGridLines()
/*     */   {
/* 138 */     return this.showGridLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDisplayZeroValues()
/*     */   {
/* 148 */     return this.displayZeroValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFrozen()
/*     */   {
/* 158 */     return this.frozenPanes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFrozenNotSplit()
/*     */   {
/* 168 */     return this.frozenNotSplit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPageBreakPreview()
/*     */   {
/* 178 */     return this.pageBreakPreviewMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPageBreakPreviewMagnificaiton()
/*     */   {
/* 188 */     return this.pageBreakPreviewMagnification;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNormalMagnificaiton()
/*     */   {
/* 198 */     return this.normalMagnification;
/*     */   }
/*     */   
/*     */   private static class Biff7 {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\Window2Record.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */