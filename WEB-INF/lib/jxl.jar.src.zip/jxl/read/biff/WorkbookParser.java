/*      */ package jxl.read.biff;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Set;
/*      */ import jxl.Cell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.Workbook;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.BuiltInName;
/*      */ import jxl.biff.CellReferenceHelper;
/*      */ import jxl.biff.EmptyCell;
/*      */ import jxl.biff.FontRecord;
/*      */ import jxl.biff.Fonts;
/*      */ import jxl.biff.FormatRecord;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.NameRangeException;
/*      */ import jxl.biff.NumFormatRecordsException;
/*      */ import jxl.biff.PaletteRecord;
/*      */ import jxl.biff.RangeImpl;
/*      */ import jxl.biff.StringHelper;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WorkbookMethods;
/*      */ import jxl.biff.XCTRecord;
/*      */ import jxl.biff.XFRecord;
/*      */ import jxl.biff.drawing.DrawingGroup;
/*      */ import jxl.biff.drawing.MsoDrawingGroupRecord;
/*      */ import jxl.biff.drawing.Origin;
/*      */ import jxl.biff.formula.ExternalSheet;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WorkbookParser
/*      */   extends Workbook
/*      */   implements ExternalSheet, WorkbookMethods
/*      */ {
/*   65 */   private static Logger logger = Logger.getLogger(WorkbookParser.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private File excelFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int bofs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean nineteenFour;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SSTRecord sharedStrings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList boundsheets;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormattingRecords formattingRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Fonts fonts;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList sheets;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetImpl lastSheet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lastSheetIndex;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private HashMap namedRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList nameTable;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList addInFunctions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ExternalSheetRecord externSheet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList supbooks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private BOFRecord workbookBof;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MsoDrawingGroupRecord msoDrawingGroup;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean wbProtected;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean containsMacros;
/*      */   
/*      */ 
/*      */ 
/*      */   private WorkbookSettings settings;
/*      */   
/*      */ 
/*      */ 
/*      */   private DrawingGroup drawingGroup;
/*      */   
/*      */ 
/*      */ 
/*      */   private CountryRecord countryRecord;
/*      */   
/*      */ 
/*      */ 
/*      */   private ArrayList xctRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public WorkbookParser(File f, WorkbookSettings s)
/*      */   {
/*  188 */     this.excelFile = f;
/*  189 */     this.boundsheets = new ArrayList(10);
/*  190 */     this.fonts = new Fonts();
/*  191 */     this.formattingRecords = new FormattingRecords(this.fonts);
/*  192 */     this.sheets = new ArrayList(10);
/*  193 */     this.supbooks = new ArrayList(10);
/*  194 */     this.namedRecords = new HashMap();
/*  195 */     this.lastSheetIndex = -1;
/*  196 */     this.wbProtected = false;
/*  197 */     this.containsMacros = false;
/*  198 */     this.settings = s;
/*  199 */     this.xctRecords = new ArrayList(10);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Sheet[] getSheets()
/*      */   {
/*  212 */     Sheet[] sheetArray = new Sheet[getNumberOfSheets()];
/*  213 */     return (Sheet[])this.sheets.toArray(sheetArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Sheet getReadSheet(int index)
/*      */   {
/*  225 */     return getSheet(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Sheet getSheet(int index)
/*      */   {
/*  239 */     if ((this.lastSheet != null) && (this.lastSheetIndex == index))
/*      */     {
/*  241 */       return this.lastSheet;
/*      */     }
/*      */     
/*      */ 
/*  245 */     if (this.lastSheet != null)
/*      */     {
/*  247 */       this.lastSheet.clear();
/*      */       
/*  249 */       if (!this.settings.getGCDisabled())
/*      */       {
/*  251 */         System.gc();
/*      */       }
/*      */     }
/*      */     
/*  255 */     this.lastSheet = ((SheetImpl)this.sheets.get(index));
/*  256 */     this.lastSheetIndex = index;
/*  257 */     this.lastSheet.readSheet();
/*      */     
/*  259 */     return this.lastSheet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Sheet getSheet(String name)
/*      */   {
/*  271 */     int pos = 0;
/*  272 */     boolean found = false;
/*  273 */     Iterator i = this.boundsheets.iterator();
/*  274 */     BoundsheetRecord br = null;
/*      */     
/*  276 */     while ((i.hasNext()) && (!found))
/*      */     {
/*  278 */       br = (BoundsheetRecord)i.next();
/*      */       
/*  280 */       if (br.getName().equals(name))
/*      */       {
/*  282 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/*  286 */         pos++;
/*      */       }
/*      */     }
/*      */     
/*  290 */     return found ? getSheet(pos) : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getSheetNames()
/*      */   {
/*  300 */     String[] names = new String[this.boundsheets.size()];
/*      */     
/*  302 */     BoundsheetRecord br = null;
/*  303 */     for (int i = 0; i < names.length; i++)
/*      */     {
/*  305 */       br = (BoundsheetRecord)this.boundsheets.get(i);
/*  306 */       names[i] = br.getName();
/*      */     }
/*      */     
/*  309 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getExternalSheetIndex(int index)
/*      */   {
/*  325 */     if (this.workbookBof.isBiff7())
/*      */     {
/*  327 */       return index;
/*      */     }
/*      */     
/*  330 */     Assert.verify(this.externSheet != null);
/*      */     
/*  332 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/*  334 */     return firstTab;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastExternalSheetIndex(int index)
/*      */   {
/*  349 */     if (this.workbookBof.isBiff7())
/*      */     {
/*  351 */       return index;
/*      */     }
/*      */     
/*  354 */     Assert.verify(this.externSheet != null);
/*      */     
/*  356 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/*  358 */     return lastTab;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getExternalSheetName(int index)
/*      */   {
/*  371 */     if (this.workbookBof.isBiff7())
/*      */     {
/*  373 */       BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(index);
/*      */       
/*  375 */       return br.getName();
/*      */     }
/*      */     
/*  378 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/*  379 */     SupbookRecord sr = (SupbookRecord)this.supbooks.get(supbookIndex);
/*      */     
/*  381 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*  382 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*  383 */     String firstTabName = "";
/*  384 */     String lastTabName = "";
/*      */     
/*  386 */     if (sr.getType() == SupbookRecord.INTERNAL)
/*      */     {
/*      */ 
/*  389 */       if (firstTab == 65535)
/*      */       {
/*  391 */         firstTabName = "#REF";
/*      */       }
/*      */       else
/*      */       {
/*  395 */         BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(firstTab);
/*  396 */         firstTabName = br.getName();
/*      */       }
/*      */       
/*  399 */       if (lastTab == 65535)
/*      */       {
/*  401 */         lastTabName = "#REF";
/*      */       }
/*      */       else
/*      */       {
/*  405 */         BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(lastTab);
/*  406 */         lastTabName = br.getName();
/*      */       }
/*      */       
/*  409 */       String sheetName = firstTabName + ':' + lastTabName;
/*      */       
/*      */ 
/*      */ 
/*  413 */       sheetName = sheetName.indexOf('\'') == -1 ? sheetName : StringHelper.replace(sheetName, "'", "''");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  418 */       return '\'' + sheetName + '\'';
/*      */     }
/*      */     
/*  421 */     if (sr.getType() == SupbookRecord.EXTERNAL)
/*      */     {
/*      */ 
/*  424 */       StringBuffer sb = new StringBuffer();
/*  425 */       java.io.File fl = new java.io.File(sr.getFileName());
/*  426 */       sb.append("'");
/*  427 */       sb.append(fl.getAbsolutePath());
/*  428 */       sb.append("[");
/*  429 */       sb.append(fl.getName());
/*  430 */       sb.append("]");
/*  431 */       sb.append(firstTab == 65535 ? "#REF" : sr.getSheetName(firstTab));
/*  432 */       if (lastTab != firstTab)
/*      */       {
/*  434 */         sb.append(sr.getSheetName(lastTab));
/*      */       }
/*  436 */       sb.append("'");
/*  437 */       return sb.toString();
/*      */     }
/*      */     
/*      */ 
/*  441 */     logger.warn("Unknown Supbook 3");
/*  442 */     return "[UNKNOWN]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLastExternalSheetName(int index)
/*      */   {
/*  455 */     if (this.workbookBof.isBiff7())
/*      */     {
/*  457 */       BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(index);
/*      */       
/*  459 */       return br.getName();
/*      */     }
/*      */     
/*  462 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/*  463 */     SupbookRecord sr = (SupbookRecord)this.supbooks.get(supbookIndex);
/*      */     
/*  465 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/*  467 */     if (sr.getType() == SupbookRecord.INTERNAL)
/*      */     {
/*      */ 
/*  470 */       if (lastTab == 65535)
/*      */       {
/*  472 */         return "#REF";
/*      */       }
/*      */       
/*      */ 
/*  476 */       BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(lastTab);
/*  477 */       return br.getName();
/*      */     }
/*      */     
/*  480 */     if (sr.getType() == SupbookRecord.EXTERNAL)
/*      */     {
/*      */ 
/*  483 */       StringBuffer sb = new StringBuffer();
/*  484 */       java.io.File fl = new java.io.File(sr.getFileName());
/*  485 */       sb.append("'");
/*  486 */       sb.append(fl.getAbsolutePath());
/*  487 */       sb.append("[");
/*  488 */       sb.append(fl.getName());
/*  489 */       sb.append("]");
/*  490 */       sb.append(lastTab == 65535 ? "#REF" : sr.getSheetName(lastTab));
/*  491 */       sb.append("'");
/*  492 */       return sb.toString();
/*      */     }
/*      */     
/*      */ 
/*  496 */     logger.warn("Unknown Supbook 4");
/*  497 */     return "[UNKNOWN]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumberOfSheets()
/*      */   {
/*  507 */     return this.sheets.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/*  516 */     if (this.lastSheet != null)
/*      */     {
/*  518 */       this.lastSheet.clear();
/*      */     }
/*  520 */     this.excelFile.clear();
/*      */     
/*  522 */     if (!this.settings.getGCDisabled())
/*      */     {
/*  524 */       System.gc();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void addSheet(Sheet s)
/*      */   {
/*  535 */     this.sheets.add(s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parse()
/*      */     throws BiffException, PasswordException
/*      */   {
/*  546 */     Record r = null;
/*      */     
/*  548 */     BOFRecord bof = new BOFRecord(this.excelFile.next());
/*  549 */     this.workbookBof = bof;
/*  550 */     this.bofs += 1;
/*      */     
/*  552 */     if ((!bof.isBiff8()) && (!bof.isBiff7()))
/*      */     {
/*  554 */       throw new BiffException(BiffException.unrecognizedBiffVersion);
/*      */     }
/*      */     
/*  557 */     if (!bof.isWorkbookGlobals())
/*      */     {
/*  559 */       throw new BiffException(BiffException.expectedGlobals);
/*      */     }
/*  561 */     ArrayList continueRecords = new ArrayList();
/*  562 */     ArrayList localNames = new ArrayList();
/*  563 */     this.nameTable = new ArrayList();
/*  564 */     this.addInFunctions = new ArrayList();
/*      */     
/*      */ 
/*  567 */     while (this.bofs == 1)
/*      */     {
/*  569 */       r = this.excelFile.next();
/*      */       
/*  571 */       if (r.getType() == Type.SST)
/*      */       {
/*  573 */         continueRecords.clear();
/*  574 */         Record nextrec = this.excelFile.peek();
/*  575 */         while (nextrec.getType() == Type.CONTINUE)
/*      */         {
/*  577 */           continueRecords.add(this.excelFile.next());
/*  578 */           nextrec = this.excelFile.peek();
/*      */         }
/*      */         
/*      */ 
/*  582 */         Record[] records = new Record[continueRecords.size()];
/*  583 */         records = (Record[])continueRecords.toArray(records);
/*      */         
/*  585 */         this.sharedStrings = new SSTRecord(r, records, this.settings);
/*      */       } else {
/*  587 */         if (r.getType() == Type.FILEPASS)
/*      */         {
/*  589 */           throw new PasswordException();
/*      */         }
/*  591 */         if (r.getType() == Type.NAME)
/*      */         {
/*  593 */           NameRecord nr = null;
/*      */           
/*  595 */           if (bof.isBiff8())
/*      */           {
/*  597 */             nr = new NameRecord(r, this.settings, this.nameTable.size());
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  602 */             nr = new NameRecord(r, this.settings, this.nameTable.size(), NameRecord.biff7);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  608 */           this.nameTable.add(nr);
/*      */           
/*  610 */           if (nr.isGlobal())
/*      */           {
/*  612 */             this.namedRecords.put(nr.getName(), nr);
/*      */           }
/*      */           else
/*      */           {
/*  616 */             localNames.add(nr);
/*      */           }
/*      */         }
/*  619 */         else if (r.getType() == Type.FONT)
/*      */         {
/*  621 */           FontRecord fr = null;
/*      */           
/*  623 */           if (bof.isBiff8())
/*      */           {
/*  625 */             fr = new FontRecord(r, this.settings);
/*      */           }
/*      */           else
/*      */           {
/*  629 */             fr = new FontRecord(r, this.settings, FontRecord.biff7);
/*      */           }
/*  631 */           this.fonts.addFont(fr);
/*      */         }
/*  633 */         else if (r.getType() == Type.PALETTE)
/*      */         {
/*  635 */           PaletteRecord palette = new PaletteRecord(r);
/*  636 */           this.formattingRecords.setPalette(palette);
/*      */         }
/*  638 */         else if (r.getType() == Type.NINETEENFOUR)
/*      */         {
/*  640 */           NineteenFourRecord nr = new NineteenFourRecord(r);
/*  641 */           this.nineteenFour = nr.is1904();
/*      */         }
/*  643 */         else if (r.getType() == Type.FORMAT)
/*      */         {
/*  645 */           FormatRecord fr = null;
/*  646 */           if (bof.isBiff8())
/*      */           {
/*  648 */             fr = new FormatRecord(r, this.settings, FormatRecord.biff8);
/*      */           }
/*      */           else
/*      */           {
/*  652 */             fr = new FormatRecord(r, this.settings, FormatRecord.biff7);
/*      */           }
/*      */           try
/*      */           {
/*  656 */             this.formattingRecords.addFormat(fr);
/*      */ 
/*      */           }
/*      */           catch (NumFormatRecordsException e)
/*      */           {
/*  661 */             Assert.verify(false, e.getMessage());
/*      */           }
/*      */         }
/*  664 */         else if (r.getType() == Type.XF)
/*      */         {
/*  666 */           XFRecord xfr = null;
/*  667 */           if (bof.isBiff8())
/*      */           {
/*  669 */             xfr = new XFRecord(r, this.settings, XFRecord.biff8);
/*      */           }
/*      */           else
/*      */           {
/*  673 */             xfr = new XFRecord(r, this.settings, XFRecord.biff7);
/*      */           }
/*      */           
/*      */           try
/*      */           {
/*  678 */             this.formattingRecords.addStyle(xfr);
/*      */ 
/*      */           }
/*      */           catch (NumFormatRecordsException e)
/*      */           {
/*  683 */             Assert.verify(false, e.getMessage());
/*      */           }
/*      */         }
/*  686 */         else if (r.getType() == Type.BOUNDSHEET)
/*      */         {
/*  688 */           BoundsheetRecord br = null;
/*      */           
/*  690 */           if (bof.isBiff8())
/*      */           {
/*  692 */             br = new BoundsheetRecord(r, this.settings);
/*      */           }
/*      */           else
/*      */           {
/*  696 */             br = new BoundsheetRecord(r, BoundsheetRecord.biff7);
/*      */           }
/*      */           
/*  699 */           if (br.isSheet())
/*      */           {
/*  701 */             this.boundsheets.add(br);
/*      */           }
/*  703 */           else if ((br.isChart()) && (!this.settings.getDrawingsDisabled()))
/*      */           {
/*  705 */             this.boundsheets.add(br);
/*      */           }
/*      */         }
/*  708 */         else if (r.getType() == Type.EXTERNSHEET)
/*      */         {
/*  710 */           if (bof.isBiff8())
/*      */           {
/*  712 */             this.externSheet = new ExternalSheetRecord(r, this.settings);
/*      */           }
/*      */           else
/*      */           {
/*  716 */             this.externSheet = new ExternalSheetRecord(r, this.settings, ExternalSheetRecord.biff7);
/*      */           }
/*      */           
/*      */         }
/*  720 */         else if (r.getType() == Type.XCT)
/*      */         {
/*  722 */           XCTRecord xctr = new XCTRecord(r);
/*  723 */           this.xctRecords.add(xctr);
/*      */         }
/*  725 */         else if (r.getType() == Type.CODEPAGE)
/*      */         {
/*  727 */           CodepageRecord cr = new CodepageRecord(r);
/*  728 */           this.settings.setCharacterSet(cr.getCharacterSet());
/*      */         }
/*  730 */         else if (r.getType() == Type.SUPBOOK)
/*      */         {
/*  732 */           Record nextrec = this.excelFile.peek();
/*  733 */           while (nextrec.getType() == Type.CONTINUE)
/*      */           {
/*  735 */             r.addContinueRecord(this.excelFile.next());
/*  736 */             nextrec = this.excelFile.peek();
/*      */           }
/*      */           
/*  739 */           SupbookRecord sr = new SupbookRecord(r, this.settings);
/*  740 */           this.supbooks.add(sr);
/*      */         }
/*  742 */         else if (r.getType() == Type.EXTERNNAME)
/*      */         {
/*  744 */           ExternalNameRecord enr = new ExternalNameRecord(r, this.settings);
/*      */           
/*  746 */           if (enr.isAddInFunction())
/*      */           {
/*  748 */             this.addInFunctions.add(enr.getName());
/*      */           }
/*      */         }
/*  751 */         else if (r.getType() == Type.PROTECT)
/*      */         {
/*  753 */           ProtectRecord pr = new ProtectRecord(r);
/*  754 */           this.wbProtected = pr.isProtected();
/*      */         }
/*  756 */         else if (r.getType() == Type.OBJPROJ)
/*      */         {
/*  758 */           this.containsMacros = true;
/*      */         }
/*  760 */         else if (r.getType() == Type.COUNTRY)
/*      */         {
/*  762 */           this.countryRecord = new CountryRecord(r);
/*      */         }
/*  764 */         else if (r.getType() == Type.MSODRAWINGGROUP)
/*      */         {
/*  766 */           if (!this.settings.getDrawingsDisabled())
/*      */           {
/*  768 */             this.msoDrawingGroup = new MsoDrawingGroupRecord(r);
/*      */             
/*  770 */             if (this.drawingGroup == null)
/*      */             {
/*  772 */               this.drawingGroup = new DrawingGroup(Origin.READ);
/*      */             }
/*      */             
/*  775 */             this.drawingGroup.add(this.msoDrawingGroup);
/*      */             
/*  777 */             Record nextrec = this.excelFile.peek();
/*  778 */             while (nextrec.getType() == Type.CONTINUE)
/*      */             {
/*  780 */               this.drawingGroup.add(this.excelFile.next());
/*  781 */               nextrec = this.excelFile.peek();
/*      */             }
/*      */           }
/*      */         }
/*  785 */         else if (r.getType() == Type.BUTTONPROPERTYSET)
/*      */         {
/*  787 */           this.buttonPropertySet = new ButtonPropertySetRecord(r);
/*      */         }
/*  789 */         else if (r.getType() == Type.EOF)
/*      */         {
/*  791 */           this.bofs -= 1;
/*      */         }
/*  793 */         else if (r.getType() == Type.REFRESHALL)
/*      */         {
/*  795 */           RefreshAllRecord rfm = new RefreshAllRecord(r);
/*  796 */           this.settings.setRefreshAll(rfm.getRefreshAll());
/*      */         }
/*  798 */         else if (r.getType() == Type.TEMPLATE)
/*      */         {
/*  800 */           TemplateRecord rfm = new TemplateRecord(r);
/*  801 */           this.settings.setTemplate(rfm.getTemplate());
/*      */         }
/*  803 */         else if (r.getType() == Type.EXCEL9FILE)
/*      */         {
/*  805 */           Excel9FileRecord e9f = new Excel9FileRecord(r);
/*  806 */           this.settings.setExcel9File(e9f.getExcel9File());
/*      */         }
/*  808 */         else if (r.getType() == Type.WINDOWPROTECT)
/*      */         {
/*  810 */           WindowProtectedRecord winp = new WindowProtectedRecord(r);
/*  811 */           this.settings.setWindowProtected(winp.getWindowProtected());
/*      */         }
/*  813 */         else if (r.getType() == Type.HIDEOBJ)
/*      */         {
/*  815 */           HideobjRecord hobj = new HideobjRecord(r);
/*  816 */           this.settings.setHideobj(hobj.getHideMode());
/*      */         }
/*  818 */         else if (r.getType() == Type.WRITEACCESS)
/*      */         {
/*  820 */           WriteAccessRecord war = new WriteAccessRecord(r, bof.isBiff8(), this.settings);
/*      */           
/*  822 */           this.settings.setWriteAccess(war.getWriteAccess());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  831 */     bof = null;
/*  832 */     if (this.excelFile.hasNext())
/*      */     {
/*  834 */       r = this.excelFile.next();
/*      */       
/*  836 */       if (r.getType() == Type.BOF)
/*      */       {
/*  838 */         bof = new BOFRecord(r);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  843 */     while ((bof != null) && (getNumberOfSheets() < this.boundsheets.size()))
/*      */     {
/*  845 */       if ((!bof.isBiff8()) && (!bof.isBiff7()))
/*      */       {
/*  847 */         throw new BiffException(BiffException.unrecognizedBiffVersion);
/*      */       }
/*      */       
/*  850 */       if (bof.isWorksheet())
/*      */       {
/*      */ 
/*  853 */         SheetImpl s = new SheetImpl(this.excelFile, this.sharedStrings, this.formattingRecords, bof, this.workbookBof, this.nineteenFour, this);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  861 */         BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(getNumberOfSheets());
/*      */         
/*  863 */         s.setName(br.getName());
/*  864 */         s.setHidden(br.isHidden());
/*  865 */         addSheet(s);
/*      */       }
/*  867 */       else if (bof.isChart())
/*      */       {
/*      */ 
/*  870 */         SheetImpl s = new SheetImpl(this.excelFile, this.sharedStrings, this.formattingRecords, bof, this.workbookBof, this.nineteenFour, this);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  878 */         BoundsheetRecord br = (BoundsheetRecord)this.boundsheets.get(getNumberOfSheets());
/*      */         
/*  880 */         s.setName(br.getName());
/*  881 */         s.setHidden(br.isHidden());
/*  882 */         addSheet(s);
/*      */       }
/*      */       else
/*      */       {
/*  886 */         logger.warn("BOF is unrecognized");
/*      */         
/*      */ 
/*  889 */         while ((this.excelFile.hasNext()) && (r.getType() != Type.EOF))
/*      */         {
/*  891 */           r = this.excelFile.next();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  900 */       bof = null;
/*  901 */       if (this.excelFile.hasNext())
/*      */       {
/*  903 */         r = this.excelFile.next();
/*      */         
/*  905 */         if (r.getType() == Type.BOF)
/*      */         {
/*  907 */           bof = new BOFRecord(r);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  913 */     for (Iterator it = localNames.iterator(); it.hasNext();)
/*      */     {
/*  915 */       NameRecord nr = (NameRecord)it.next();
/*      */       
/*  917 */       if (nr.getBuiltInName() == null)
/*      */       {
/*  919 */         logger.warn("Usage of a local non-builtin name");
/*      */       }
/*  921 */       else if ((nr.getBuiltInName() == BuiltInName.PRINT_AREA) || (nr.getBuiltInName() == BuiltInName.PRINT_TITLES))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  926 */         SheetImpl s = (SheetImpl)this.sheets.get(nr.getSheetRef() - 1);
/*  927 */         s.addLocalName(nr);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FormattingRecords getFormattingRecords()
/*      */   {
/*  940 */     return this.formattingRecords;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ExternalSheetRecord getExternalSheetRecord()
/*      */   {
/*  951 */     return this.externSheet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MsoDrawingGroupRecord getMsoDrawingGroupRecord()
/*      */   {
/*  962 */     return this.msoDrawingGroup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SupbookRecord[] getSupbookRecords()
/*      */   {
/*  973 */     SupbookRecord[] sr = new SupbookRecord[this.supbooks.size()];
/*  974 */     return (SupbookRecord[])this.supbooks.toArray(sr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NameRecord[] getNameRecords()
/*      */   {
/*  985 */     NameRecord[] na = new NameRecord[this.nameTable.size()];
/*  986 */     return (NameRecord[])this.nameTable.toArray(na);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Fonts getFonts()
/*      */   {
/*  996 */     return this.fonts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell getCell(String loc)
/*      */   {
/* 1010 */     Sheet s = getSheet(CellReferenceHelper.getSheet(loc));
/* 1011 */     return s.getCell(loc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCellByName(String name)
/*      */   {
/* 1025 */     NameRecord nr = (NameRecord)this.namedRecords.get(name);
/*      */     
/* 1027 */     if (nr == null)
/*      */     {
/* 1029 */       return null;
/*      */     }
/*      */     
/* 1032 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */     
/*      */ 
/* 1035 */     Sheet s = getSheet(getExternalSheetIndex(ranges[0].getExternalSheet()));
/* 1036 */     int col = ranges[0].getFirstColumn();
/* 1037 */     int row = ranges[0].getFirstRow();
/*      */     
/*      */ 
/*      */ 
/* 1041 */     if ((col > s.getColumns()) || (row > s.getRows()))
/*      */     {
/* 1043 */       return new EmptyCell(col, row);
/*      */     }
/*      */     
/* 1046 */     Cell cell = s.getCell(col, row);
/*      */     
/* 1048 */     return cell;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range[] findByName(String name)
/*      */   {
/* 1067 */     NameRecord nr = (NameRecord)this.namedRecords.get(name);
/*      */     
/* 1069 */     if (nr == null)
/*      */     {
/* 1071 */       return null;
/*      */     }
/*      */     
/* 1074 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */     
/* 1076 */     Range[] cellRanges = new Range[ranges.length];
/*      */     
/* 1078 */     for (int i = 0; i < ranges.length; i++)
/*      */     {
/* 1080 */       cellRanges[i] = new RangeImpl(this, getExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getFirstColumn(), ranges[i].getFirstRow(), getLastExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getLastColumn(), ranges[i].getLastRow());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1090 */     return cellRanges;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getRangeNames()
/*      */   {
/* 1100 */     Object[] keys = this.namedRecords.keySet().toArray();
/* 1101 */     String[] names = new String[keys.length];
/* 1102 */     System.arraycopy(keys, 0, names, 0, keys.length);
/*      */     
/* 1104 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BOFRecord getWorkbookBof()
/*      */   {
/* 1115 */     return this.workbookBof;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isProtected()
/*      */   {
/* 1125 */     return this.wbProtected;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WorkbookSettings getSettings()
/*      */   {
/* 1135 */     return this.settings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getExternalSheetIndex(String sheetName)
/*      */   {
/* 1146 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastExternalSheetIndex(String sheetName)
/*      */   {
/* 1157 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName(int index)
/*      */     throws NameRangeException
/*      */   {
/* 1170 */     if ((index < 0) || (index >= this.nameTable.size()))
/*      */     {
/* 1172 */       throw new NameRangeException();
/*      */     }
/* 1174 */     return ((NameRecord)this.nameTable.get(index)).getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNameIndex(String name)
/*      */   {
/* 1185 */     NameRecord nr = (NameRecord)this.namedRecords.get(name);
/*      */     
/* 1187 */     return nr != null ? nr.getIndex() : 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DrawingGroup getDrawingGroup()
/*      */   {
/* 1197 */     return this.drawingGroup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CompoundFile getCompoundFile()
/*      */   {
/* 1211 */     return this.excelFile.getCompoundFile();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsMacros()
/*      */   {
/* 1221 */     return this.containsMacros;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ButtonPropertySetRecord getButtonPropertySet()
/*      */   {
/* 1231 */     return this.buttonPropertySet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CountryRecord getCountryRecord()
/*      */   {
/* 1241 */     return this.countryRecord;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getAddInFunctionNames()
/*      */   {
/* 1251 */     String[] addins = new String[0];
/* 1252 */     return (String[])this.addInFunctions.toArray(addins);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIndex(Sheet sheet)
/*      */   {
/* 1263 */     String name = sheet.getName();
/* 1264 */     int index = -1;
/* 1265 */     int pos = 0;
/*      */     
/* 1267 */     for (Iterator i = this.boundsheets.iterator(); (i.hasNext()) && (index == -1);)
/*      */     {
/* 1269 */       BoundsheetRecord br = (BoundsheetRecord)i.next();
/*      */       
/* 1271 */       if (br.getName().equals(name))
/*      */       {
/* 1273 */         index = pos;
/*      */       }
/*      */       else
/*      */       {
/* 1277 */         pos++;
/*      */       }
/*      */     }
/*      */     
/* 1281 */     return index;
/*      */   }
/*      */   
/*      */   public XCTRecord[] getXCTRecords()
/*      */   {
/* 1286 */     XCTRecord[] xctr = new XCTRecord[0];
/* 1287 */     return (XCTRecord[])this.xctRecords.toArray(xctr);
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\WorkbookParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */