/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.WorkbookSettings;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WriteAccessRecord
/*    */   extends RecordData
/*    */ {
/*    */   private String wauser;
/*    */   
/*    */   public WriteAccessRecord(Record t, boolean isBiff8, WorkbookSettings ws)
/*    */   {
/* 45 */     super(Type.WRITEACCESS);
/*    */     
/* 47 */     byte[] data = t.getData();
/* 48 */     if (isBiff8)
/*    */     {
/* 50 */       this.wauser = StringHelper.getUnicodeString(data, 56, 0);
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 55 */       int length = data[1];
/* 56 */       this.wauser = StringHelper.getString(data, length, 1, ws);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getWriteAccess()
/*    */   {
/* 67 */     return this.wauser;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\read\biff\WriteAccessRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */