/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.Cell;
/*    */ import jxl.format.CellFormat;
/*    */ import jxl.write.biff.BlankRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Blank
/*    */   extends BlankRecord
/*    */   implements WritableCell
/*    */ {
/*    */   public Blank(int c, int r)
/*    */   {
/* 42 */     super(c, r);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Blank(int c, int r, CellFormat st)
/*    */   {
/* 56 */     super(c, r, st);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Blank(Cell lc)
/*    */   {
/* 67 */     super(lc);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Blank(int col, int row, Blank b)
/*    */   {
/* 80 */     super(col, row, b);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WritableCell copyTo(int col, int row)
/*    */   {
/* 92 */     return new Blank(col, row, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\Blank.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */