/*    */ package jxl.write;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import jxl.biff.DisplayFormat;
/*    */ import jxl.write.biff.DateFormatRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateFormat
/*    */   extends DateFormatRecord
/*    */   implements DisplayFormat
/*    */ {
/*    */   public DateFormat(String format)
/*    */   {
/* 47 */     super(format);
/*    */     
/*    */ 
/* 50 */     SimpleDateFormat df = new SimpleDateFormat(format);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\DateFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */