/*     */ package jxl.write;
/*     */ 
/*     */ import java.util.Date;
/*     */ import jxl.DateCell;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.biff.DateRecord;
/*     */ import jxl.write.biff.DateRecord.GMTDate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateTime
/*     */   extends DateRecord
/*     */   implements WritableCell, DateCell
/*     */ {
/*  46 */   public static final DateRecord.GMTDate GMT = new DateRecord.GMTDate();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTime(int c, int r, Date d)
/*     */   {
/*  58 */     super(c, r, d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTime(int c, int r, Date d, DateRecord.GMTDate a)
/*     */   {
/*  73 */     super(c, r, d, a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTime(int c, int r, Date d, CellFormat st)
/*     */   {
/*  86 */     super(c, r, d, st);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTime(int c, int r, Date d, CellFormat st, DateRecord.GMTDate a)
/*     */   {
/* 101 */     super(c, r, d, st, a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTime(int c, int r, Date d, CellFormat st, boolean tim)
/*     */   {
/* 118 */     super(c, r, d, st, tim);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTime(DateCell dc)
/*     */   {
/* 129 */     super(dc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateTime(int col, int row, DateTime dt)
/*     */   {
/* 141 */     super(col, row, dt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDate(Date d)
/*     */   {
/* 152 */     super.setDate(d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDate(Date d, DateRecord.GMTDate a)
/*     */   {
/* 163 */     super.setDate(d, a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCell copyTo(int col, int row)
/*     */   {
/* 175 */     return new DateTime(col, row, this);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\DateTime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */