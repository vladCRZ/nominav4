/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.ScriptStyle;
/*     */ import jxl.format.UnderlineStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class Font
/*     */   extends WritableFont
/*     */ {
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  39 */   public static final WritableFont.FontName ARIAL = WritableFont.ARIAL;
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  45 */   public static final WritableFont.FontName TIMES = WritableFont.TIMES;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  53 */   public static final WritableFont.BoldStyle NO_BOLD = WritableFont.NO_BOLD;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  58 */   public static final WritableFont.BoldStyle BOLD = WritableFont.BOLD;
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  64 */   public static final UnderlineStyle NO_UNDERLINE = UnderlineStyle.NO_UNDERLINE;
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  70 */   public static final UnderlineStyle SINGLE = UnderlineStyle.SINGLE;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  75 */   public static final UnderlineStyle DOUBLE = UnderlineStyle.DOUBLE;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  80 */   public static final UnderlineStyle SINGLE_ACCOUNTING = UnderlineStyle.SINGLE_ACCOUNTING;
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*  86 */   public static final UnderlineStyle DOUBLE_ACCOUNTING = UnderlineStyle.DOUBLE_ACCOUNTING;
/*     */   
/*     */ 
/*     */ 
/*  90 */   public static final ScriptStyle NORMAL_SCRIPT = ScriptStyle.NORMAL_SCRIPT;
/*  91 */   public static final ScriptStyle SUPERSCRIPT = ScriptStyle.SUPERSCRIPT;
/*  92 */   public static final ScriptStyle SUBSCRIPT = ScriptStyle.SUBSCRIPT;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn)
/*     */   {
/* 103 */     super(fn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn, int ps)
/*     */   {
/* 116 */     super(fn, ps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs)
/*     */   {
/* 129 */     super(fn, ps, bs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean italic)
/*     */   {
/* 144 */     super(fn, ps, bs, italic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean it, UnderlineStyle us)
/*     */   {
/* 164 */     super(fn, ps, bs, it, us);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean it, UnderlineStyle us, Colour c)
/*     */   {
/* 187 */     super(fn, ps, bs, it, us, c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean it, UnderlineStyle us, Colour c, ScriptStyle ss)
/*     */   {
/* 213 */     super(fn, ps, bs, it, us, c, ss);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\Font.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */