/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.CellFormat;
/*    */ import jxl.write.biff.FormulaRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Formula
/*    */   extends FormulaRecord
/*    */   implements WritableCell
/*    */ {
/*    */   public Formula(int c, int r, String form)
/*    */   {
/* 39 */     super(c, r, form);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Formula(int c, int r, String form, CellFormat st)
/*    */   {
/* 52 */     super(c, r, form, st);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Formula(int c, int r, Formula f)
/*    */   {
/* 64 */     super(c, r, f);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WritableCell copyTo(int col, int row)
/*    */   {
/* 75 */     return new Formula(col, row, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\Formula.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */