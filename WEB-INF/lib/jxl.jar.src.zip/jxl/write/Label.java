/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.LabelCell;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.biff.LabelRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Label
/*     */   extends LabelRecord
/*     */   implements WritableCell, LabelCell
/*     */ {
/*     */   public Label(int c, int r, String cont)
/*     */   {
/*  41 */     super(c, r, cont);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Label(int c, int r, String cont, CellFormat st)
/*     */   {
/*  56 */     super(c, r, cont, st);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Label(int col, int row, Label l)
/*     */   {
/*  68 */     super(col, row, l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Label(LabelCell lc)
/*     */   {
/*  79 */     super(lc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setString(String s)
/*     */   {
/*  89 */     super.setString(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCell copyTo(int col, int row)
/*     */   {
/* 101 */     return new Label(col, row, this);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\Label.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */