/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.NumberCell;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.biff.NumberRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Number
/*     */   extends NumberRecord
/*     */   implements WritableCell, NumberCell
/*     */ {
/*     */   public Number(int c, int r, double val)
/*     */   {
/*  42 */     super(c, r, val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Number(int c, int r, double val, CellFormat st)
/*     */   {
/*  58 */     super(c, r, val, st);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Number(NumberCell nc)
/*     */   {
/*  69 */     super(nc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(double val)
/*     */   {
/*  79 */     super.setValue(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Number(int col, int row, Number n)
/*     */   {
/*  91 */     super(col, row, n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCell copyTo(int col, int row)
/*     */   {
/* 103 */     return new Number(col, row, this);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\Number.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */