/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.biff.DisplayFormat;
/*     */ import jxl.format.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberFormats
/*     */ {
/*     */   private static class BuiltInFormat
/*     */     implements DisplayFormat, Format
/*     */   {
/*     */     private int index;
/*     */     private String formatString;
/*     */     
/*     */     public BuiltInFormat(int i, String s)
/*     */     {
/*  53 */       this.index = i;
/*  54 */       this.formatString = s;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getFormatIndex()
/*     */     {
/*  64 */       return this.index;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isInitialized()
/*     */     {
/*  74 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isBuiltIn()
/*     */     {
/*  83 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void initialize(int pos) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getFormatString()
/*     */     {
/* 104 */       return this.formatString;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 115 */       if (o == this)
/*     */       {
/* 117 */         return true;
/*     */       }
/*     */       
/* 120 */       if (!(o instanceof BuiltInFormat))
/*     */       {
/* 122 */         return false;
/*     */       }
/*     */       
/* 125 */       BuiltInFormat bif = (BuiltInFormat)o;
/*     */       
/* 127 */       return this.index == bif.index;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 137 */       return this.index;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */   public static final DisplayFormat DEFAULT = new BuiltInFormat(0, "#");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 153 */   public static final DisplayFormat INTEGER = new BuiltInFormat(1, "0");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */   public static final DisplayFormat FLOAT = new BuiltInFormat(2, "0.00");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */   public static final DisplayFormat THOUSANDS_INTEGER = new BuiltInFormat(3, "#,##0");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */   public static final DisplayFormat THOUSANDS_FLOAT = new BuiltInFormat(4, "#,##0.00");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */   public static final DisplayFormat ACCOUNTING_INTEGER = new BuiltInFormat(5, "$#,##0;($#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */   public static final DisplayFormat ACCOUNTING_RED_INTEGER = new BuiltInFormat(6, "$#,##0;($#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */   public static final DisplayFormat ACCOUNTING_FLOAT = new BuiltInFormat(7, "$#,##0;($#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */   public static final DisplayFormat ACCOUNTING_RED_FLOAT = new BuiltInFormat(8, "$#,##0;($#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */   public static final DisplayFormat PERCENT_INTEGER = new BuiltInFormat(9, "0%");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */   public static final DisplayFormat PERCENT_FLOAT = new BuiltInFormat(10, "0.00%");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */   public static final DisplayFormat EXPONENTIAL = new BuiltInFormat(11, "0.00E00");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */   public static final DisplayFormat FRACTION_ONE_DIGIT = new BuiltInFormat(12, "?/?");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */   public static final DisplayFormat FRACTION_TWO_DIGITS = new BuiltInFormat(13, "??/??");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */   public static final DisplayFormat FORMAT1 = new BuiltInFormat(37, "#,##0;(#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */   public static final DisplayFormat FORMAT2 = new BuiltInFormat(38, "#,##0;(#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */   public static final DisplayFormat FORMAT3 = new BuiltInFormat(39, "#,##0.00;(#,##0.00)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 259 */   public static final DisplayFormat FORMAT4 = new BuiltInFormat(40, "#,##0.00;(#,##0.00)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 265 */   public static final DisplayFormat FORMAT5 = new BuiltInFormat(41, "#,##0;(#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 271 */   public static final DisplayFormat FORMAT6 = new BuiltInFormat(42, "#,##0;(#,##0)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */   public static final DisplayFormat FORMAT7 = new BuiltInFormat(43, "#,##0.00;(#,##0.00)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */   public static final DisplayFormat FORMAT8 = new BuiltInFormat(44, "#,##0.00;(#,##0.00)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 289 */   public static final DisplayFormat FORMAT9 = new BuiltInFormat(46, "#,##0.00;(#,##0.00)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 295 */   public static final DisplayFormat FORMAT10 = new BuiltInFormat(48, "##0.0E0");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 301 */   public static final DisplayFormat TEXT = new BuiltInFormat(49, "@");
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\NumberFormats.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */