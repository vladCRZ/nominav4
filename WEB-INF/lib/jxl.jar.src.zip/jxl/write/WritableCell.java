package jxl.write;

import jxl.Cell;
import jxl.format.CellFormat;

public abstract interface WritableCell
  extends Cell
{
  public abstract void setCellFormat(CellFormat paramCellFormat);
  
  public abstract WritableCell copyTo(int paramInt1, int paramInt2);
  
  public abstract WritableCellFeatures getWritableCellFeatures();
  
  public abstract void setCellFeatures(WritableCellFeatures paramWritableCellFeatures);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\WritableCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */