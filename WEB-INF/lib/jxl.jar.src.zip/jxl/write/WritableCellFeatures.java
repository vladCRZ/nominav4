/*     */ package jxl.write;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.biff.BaseCellFeatures;
/*     */ import jxl.biff.BaseCellFeatures.ValidationCondition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableCellFeatures
/*     */   extends CellFeatures
/*     */ {
/*  34 */   public static final BaseCellFeatures.ValidationCondition BETWEEN = BaseCellFeatures.BETWEEN;
/*  35 */   public static final BaseCellFeatures.ValidationCondition NOT_BETWEEN = BaseCellFeatures.NOT_BETWEEN;
/*     */   
/*  37 */   public static final BaseCellFeatures.ValidationCondition EQUAL = BaseCellFeatures.EQUAL;
/*  38 */   public static final BaseCellFeatures.ValidationCondition NOT_EQUAL = BaseCellFeatures.NOT_EQUAL;
/*     */   
/*  40 */   public static final BaseCellFeatures.ValidationCondition GREATER_THAN = BaseCellFeatures.GREATER_THAN;
/*     */   
/*  42 */   public static final BaseCellFeatures.ValidationCondition LESS_THAN = BaseCellFeatures.LESS_THAN;
/*     */   
/*  44 */   public static final BaseCellFeatures.ValidationCondition GREATER_EQUAL = BaseCellFeatures.GREATER_EQUAL;
/*     */   
/*  46 */   public static final BaseCellFeatures.ValidationCondition LESS_EQUAL = BaseCellFeatures.LESS_EQUAL;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFeatures() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFeatures(CellFeatures cf)
/*     */   {
/*  64 */     super(cf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComment(String s)
/*     */   {
/*  74 */     super.setComment(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComment(String s, double width, double height)
/*     */   {
/*  87 */     super.setComment(s, width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeComment()
/*     */   {
/*  95 */     super.removeComment();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeDataValidation()
/*     */   {
/* 104 */     super.removeDataValidation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataValidationList(Collection c)
/*     */   {
/* 116 */     super.setDataValidationList(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataValidationRange(int col1, int row1, int col2, int row2)
/*     */   {
/* 129 */     super.setDataValidationRange(col1, row1, col2, row2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataValidationRange(String namedRange)
/*     */   {
/* 141 */     super.setDataValidationRange(namedRange);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumberValidation(double val, BaseCellFeatures.ValidationCondition c)
/*     */   {
/* 153 */     super.setNumberValidation(val, c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumberValidation(double val1, double val2, BaseCellFeatures.ValidationCondition c)
/*     */   {
/* 167 */     super.setNumberValidation(val1, val2, c);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\WritableCellFeatures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */