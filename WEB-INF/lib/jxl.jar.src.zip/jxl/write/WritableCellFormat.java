/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.biff.DisplayFormat;
/*     */ import jxl.format.Alignment;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Orientation;
/*     */ import jxl.format.Pattern;
/*     */ import jxl.format.VerticalAlignment;
/*     */ import jxl.write.biff.CellXFRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableCellFormat
/*     */   extends CellXFRecord
/*     */ {
/*     */   public WritableCellFormat()
/*     */   {
/*  53 */     this(WritableWorkbook.ARIAL_10_PT, NumberFormats.DEFAULT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFormat(WritableFont font)
/*     */   {
/*  63 */     this(font, NumberFormats.DEFAULT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFormat(DisplayFormat format)
/*     */   {
/*  74 */     this(WritableWorkbook.ARIAL_10_PT, format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFormat(WritableFont font, DisplayFormat format)
/*     */   {
/*  86 */     super(font, format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFormat(CellFormat format)
/*     */   {
/*  96 */     super(format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlignment(Alignment a)
/*     */     throws WriteException
/*     */   {
/* 107 */     super.setAlignment(a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVerticalAlignment(VerticalAlignment va)
/*     */     throws WriteException
/*     */   {
/* 118 */     super.setVerticalAlignment(va);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrientation(Orientation o)
/*     */     throws WriteException
/*     */   {
/* 129 */     super.setOrientation(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWrap(boolean w)
/*     */     throws WriteException
/*     */   {
/* 142 */     super.setWrap(w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorder(Border b, BorderLineStyle ls)
/*     */     throws WriteException
/*     */   {
/* 154 */     super.setBorder(b, ls, Colour.BLACK);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorder(Border b, BorderLineStyle ls, Colour c)
/*     */     throws WriteException
/*     */   {
/* 168 */     super.setBorder(b, ls, c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackground(Colour c)
/*     */     throws WriteException
/*     */   {
/* 179 */     setBackground(c, Pattern.SOLID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackground(Colour c, Pattern p)
/*     */     throws WriteException
/*     */   {
/* 191 */     super.setBackground(c, p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShrinkToFit(boolean s)
/*     */     throws WriteException
/*     */   {
/* 202 */     super.setShrinkToFit(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndentation(int i)
/*     */     throws WriteException
/*     */   {
/* 212 */     super.setIndentation(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocked(boolean l)
/*     */     throws WriteException
/*     */   {
/* 226 */     super.setLocked(l);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\WritableCellFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */