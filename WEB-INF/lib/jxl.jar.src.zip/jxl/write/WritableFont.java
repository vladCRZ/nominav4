/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Font;
/*     */ import jxl.format.ScriptStyle;
/*     */ import jxl.format.UnderlineStyle;
/*     */ import jxl.write.biff.WritableFontRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableFont
/*     */   extends WritableFontRecord
/*     */ {
/*     */   public static class FontName
/*     */   {
/*     */     String name;
/*     */     
/*     */     FontName(String s)
/*     */     {
/*  51 */       this.name = s;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class BoldStyle
/*     */   {
/*     */     public int value;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     BoldStyle(int val)
/*     */     {
/*  72 */       this.value = val;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   public static final FontName ARIAL = new FontName("Arial");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  85 */   public static final FontName TIMES = new FontName("Times New Roman");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   public static final FontName COURIER = new FontName("Courier New");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  95 */   public static final FontName TAHOMA = new FontName("Tahoma");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   public static final BoldStyle NO_BOLD = new BoldStyle(400);
/*     */   
/*     */ 
/*     */ 
/* 106 */   public static final BoldStyle BOLD = new BoldStyle(700);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_POINT_SIZE = 10;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn)
/*     */   {
/* 121 */     this(fn, 10, NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(Font f)
/*     */   {
/* 137 */     super(f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn, int ps)
/*     */   {
/* 149 */     this(fn, ps, NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs)
/*     */   {
/* 164 */     this(fn, ps, bs, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean italic)
/*     */   {
/* 181 */     this(fn, ps, bs, italic, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us)
/*     */   {
/* 203 */     this(fn, ps, bs, it, us, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us, Colour c)
/*     */   {
/* 225 */     this(fn, ps, bs, it, us, c, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us, Colour c, ScriptStyle ss)
/*     */   {
/* 250 */     super(fn.name, ps, bs.value, it, us.getValue(), c.getValue(), ss.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPointSize(int pointSize)
/*     */     throws WriteException
/*     */   {
/* 263 */     super.setPointSize(pointSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBoldStyle(BoldStyle boldStyle)
/*     */     throws WriteException
/*     */   {
/* 274 */     super.setBoldStyle(boldStyle.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItalic(boolean italic)
/*     */     throws WriteException
/*     */   {
/* 286 */     super.setItalic(italic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnderlineStyle(UnderlineStyle us)
/*     */     throws WriteException
/*     */   {
/* 298 */     super.setUnderlineStyle(us.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColour(Colour colour)
/*     */     throws WriteException
/*     */   {
/* 310 */     super.setColour(colour.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScriptStyle(ScriptStyle scriptStyle)
/*     */     throws WriteException
/*     */   {
/* 322 */     super.setScriptStyle(scriptStyle.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStruckout()
/*     */   {
/* 332 */     return super.isStruckout();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStruckout(boolean struckout)
/*     */     throws WriteException
/*     */   {
/* 344 */     super.setStruckout(struckout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FontName createFont(String fontName)
/*     */   {
/* 357 */     return new FontName(fontName);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\WritableFont.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */