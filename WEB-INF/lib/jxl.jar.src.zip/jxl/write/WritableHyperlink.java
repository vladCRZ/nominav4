/*     */ package jxl.write;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import jxl.Hyperlink;
/*     */ import jxl.write.biff.HyperlinkRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableHyperlink
/*     */   extends HyperlinkRecord
/*     */   implements Hyperlink
/*     */ {
/*     */   public WritableHyperlink(Hyperlink h, WritableSheet ws)
/*     */   {
/*  42 */     super(h, ws);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, URL url)
/*     */   {
/*  54 */     this(col, row, col, row, url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, URL url)
/*     */   {
/*  68 */     this(col, row, lastcol, lastrow, url, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, URL url, String desc)
/*     */   {
/*  88 */     super(col, row, lastcol, lastrow, url, desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, File file)
/*     */   {
/* 100 */     this(col, row, col, row, file, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, File file, String desc)
/*     */   {
/* 113 */     this(col, row, col, row, file, desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, File file)
/*     */   {
/* 128 */     super(col, row, lastcol, lastrow, file, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, File file, String desc)
/*     */   {
/* 148 */     super(col, row, lastcol, lastrow, file, desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, String desc, WritableSheet sheet, int destcol, int destrow)
/*     */   {
/* 166 */     this(col, row, col, row, desc, sheet, destcol, destrow, destcol, destrow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, String desc, WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow)
/*     */   {
/* 192 */     super(col, row, lastcol, lastrow, desc, sheet, destcol, destrow, lastdestcol, lastdestrow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setURL(URL url)
/*     */   {
/* 205 */     super.setURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFile(File file)
/*     */   {
/* 215 */     super.setFile(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDescription(String desc)
/*     */   {
/* 225 */     super.setContents(desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(String desc, WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow)
/*     */   {
/* 243 */     super.setLocation(desc, sheet, destcol, destrow, lastdestcol, lastdestrow);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\WritableHyperlink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */