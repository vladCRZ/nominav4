/*    */ package jxl.write;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import jxl.Range;
/*    */ import jxl.Sheet;
/*    */ import jxl.Workbook;
/*    */ import jxl.format.Colour;
/*    */ import jxl.format.UnderlineStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WritableWorkbook
/*    */ {
/* 40 */   public static final WritableFont ARIAL_10_PT = new WritableFont(WritableFont.ARIAL);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 46 */   public static final WritableFont HYPERLINK_FONT = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE, Colour.BLUE);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 57 */   public static final WritableCellFormat NORMAL_STYLE = new WritableCellFormat(ARIAL_10_PT, NumberFormats.DEFAULT);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 63 */   public static final WritableCellFormat HYPERLINK_STYLE = new WritableCellFormat(HYPERLINK_FONT);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 69 */   public static final WritableCellFormat HIDDEN_STYLE = new WritableCellFormat(new DateFormat(";;;"));
/*    */   
/*    */   public abstract WritableSheet[] getSheets();
/*    */   
/*    */   public abstract String[] getSheetNames();
/*    */   
/*    */   public abstract WritableSheet getSheet(int paramInt)
/*    */     throws IndexOutOfBoundsException;
/*    */   
/*    */   public abstract WritableSheet getSheet(String paramString);
/*    */   
/*    */   public abstract WritableCell getWritableCell(String paramString);
/*    */   
/*    */   public abstract int getNumberOfSheets();
/*    */   
/*    */   public abstract void close()
/*    */     throws IOException, WriteException;
/*    */   
/*    */   public abstract WritableSheet createSheet(String paramString, int paramInt);
/*    */   
/*    */   public abstract WritableSheet importSheet(String paramString, int paramInt, Sheet paramSheet);
/*    */   
/*    */   public abstract void copySheet(int paramInt1, String paramString, int paramInt2);
/*    */   
/*    */   public abstract void copySheet(String paramString1, String paramString2, int paramInt);
/*    */   
/*    */   public abstract void removeSheet(int paramInt);
/*    */   
/*    */   public abstract WritableSheet moveSheet(int paramInt1, int paramInt2);
/*    */   
/*    */   public abstract void write()
/*    */     throws IOException;
/*    */   
/*    */   public abstract void setProtected(boolean paramBoolean);
/*    */   
/*    */   public abstract void setColourRGB(Colour paramColour, int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public void copy(Workbook w) {}
/*    */   
/*    */   public abstract WritableCell findCellByName(String paramString);
/*    */   
/*    */   public abstract Range[] findByName(String paramString);
/*    */   
/*    */   public abstract String[] getRangeNames();
/*    */   
/*    */   public abstract void removeRangeName(String paramString);
/*    */   
/*    */   public abstract void addNameArea(String paramString, WritableSheet paramWritableSheet, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public abstract void setOutputFile(File paramFile)
/*    */     throws IOException;
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\WritableWorkbook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */