/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BOFRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*  40 */   public static final WorkbookGlobalsBOF workbookGlobals = new WorkbookGlobalsBOF(null);
/*     */   
/*  42 */   public static final SheetBOF sheet = new SheetBOF(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BOFRecord(WorkbookGlobalsBOF dummy)
/*     */   {
/*  51 */     super(Type.BOF);
/*     */     
/*     */ 
/*     */ 
/*  55 */     this.data = new byte[] { 0, 6, 5, 0, -14, 21, -52, 7, 0, 0, 0, 0, 6, 0, 0, 0 };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BOFRecord(SheetBOF dummy)
/*     */   {
/*  82 */     super(Type.BOF);
/*     */     
/*     */ 
/*     */ 
/*  86 */     this.data = new byte[] { 0, 6, 16, 0, -14, 21, -52, 7, 0, 0, 0, 0, 6, 0, 0, 0 };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 113 */     return this.data;
/*     */   }
/*     */   
/*     */   private static class SheetBOF {}
/*     */   
/*     */   private static class WorkbookGlobalsBOF {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\BOFRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */