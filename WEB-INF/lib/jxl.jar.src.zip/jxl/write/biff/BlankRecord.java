/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.Type;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BlankRecord
/*     */   extends CellValue
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(BlankRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BlankRecord(int c, int r)
/*     */   {
/*  48 */     super(Type.BLANK, c, r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BlankRecord(int c, int r, CellFormat st)
/*     */   {
/*  61 */     super(Type.BLANK, c, r, st);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BlankRecord(Cell c)
/*     */   {
/*  72 */     super(Type.BLANK, c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BlankRecord(int c, int r, BlankRecord br)
/*     */   {
/*  84 */     super(Type.BLANK, c, r, br);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/*  94 */     return CellType.EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 104 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\BlankRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */