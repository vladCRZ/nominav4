/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BookboolRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean externalLink;
/*    */   private byte[] data;
/*    */   
/*    */   public BookboolRecord(boolean extlink)
/*    */   {
/* 48 */     super(Type.BOOKBOOL);
/*    */     
/* 50 */     this.externalLink = extlink;
/* 51 */     this.data = new byte[2];
/*    */     
/* 53 */     if (!this.externalLink)
/*    */     {
/* 55 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 66 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\BookboolRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */