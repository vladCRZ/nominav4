/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.BooleanCell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.Type;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BooleanRecord
/*     */   extends CellValue
/*     */ {
/*     */   private boolean value;
/*     */   
/*     */   protected BooleanRecord(int c, int r, boolean val)
/*     */   {
/*  49 */     super(Type.BOOLERR, c, r);
/*  50 */     this.value = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BooleanRecord(int c, int r, boolean val, CellFormat st)
/*     */   {
/*  64 */     super(Type.BOOLERR, c, r, st);
/*  65 */     this.value = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BooleanRecord(BooleanCell nc)
/*     */   {
/*  75 */     super(Type.BOOLERR, nc);
/*  76 */     this.value = nc.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BooleanRecord(int c, int r, BooleanRecord br)
/*     */   {
/*  88 */     super(Type.BOOLERR, c, r, br);
/*  89 */     this.value = br.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getValue()
/*     */   {
/* 102 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 113 */     return new Boolean(this.value).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 123 */     return CellType.BOOLEAN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setValue(boolean val)
/*     */   {
/* 133 */     this.value = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 143 */     byte[] celldata = super.getData();
/* 144 */     byte[] data = new byte[celldata.length + 2];
/* 145 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/*     */     
/* 147 */     if (this.value)
/*     */     {
/* 149 */       data[celldata.length] = 1;
/*     */     }
/*     */     
/* 152 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\BooleanRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */