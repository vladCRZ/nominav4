/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BoundsheetRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private boolean hidden;
/*     */   private boolean chartOnly;
/*     */   private String name;
/*     */   private byte[] data;
/*     */   
/*     */   public BoundsheetRecord(String n)
/*     */   {
/*  59 */     super(Type.BOUNDSHEET);
/*  60 */     this.name = n;
/*  61 */     this.hidden = false;
/*  62 */     this.chartOnly = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setHidden()
/*     */   {
/*  70 */     this.hidden = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setChartOnly()
/*     */   {
/*  78 */     this.chartOnly = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  88 */     this.data = new byte[this.name.length() * 2 + 8];
/*     */     
/*  90 */     if (this.chartOnly)
/*     */     {
/*  92 */       this.data[5] = 2;
/*     */     }
/*     */     else
/*     */     {
/*  96 */       this.data[5] = 0;
/*     */     }
/*     */     
/*  99 */     if (this.hidden)
/*     */     {
/* 101 */       this.data[4] = 1;
/* 102 */       this.data[5] = 0;
/*     */     }
/*     */     
/* 105 */     this.data[6] = ((byte)this.name.length());
/* 106 */     this.data[7] = 1;
/* 107 */     StringHelper.getUnicodeBytes(this.name, this.data, 8);
/*     */     
/* 109 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\BoundsheetRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */