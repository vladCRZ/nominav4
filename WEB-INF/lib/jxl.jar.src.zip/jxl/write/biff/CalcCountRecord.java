/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CalcCountRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int calcCount;
/*    */   private byte[] data;
/*    */   
/*    */   public CalcCountRecord(int cnt)
/*    */   {
/* 48 */     super(Type.CALCCOUNT);
/* 49 */     this.calcCount = cnt;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 60 */     byte[] data = new byte[2];
/*    */     
/* 62 */     IntegerHelper.getTwoBytes(this.calcCount, data, 0);
/*    */     
/* 64 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\CalcCountRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */