/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CalcModeRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private CalcMode calculationMode;
/*    */   
/*    */   private static class CalcMode
/*    */   {
/*    */     int value;
/*    */     
/*    */     public CalcMode(int m)
/*    */     {
/* 51 */       this.value = m;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 58 */   static CalcMode manual = new CalcMode(0);
/*    */   
/*    */ 
/*    */ 
/* 62 */   static CalcMode automatic = new CalcMode(1);
/*    */   
/*    */ 
/*    */ 
/* 66 */   static CalcMode automaticNoTables = new CalcMode(-1);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CalcModeRecord(CalcMode cm)
/*    */   {
/* 75 */     super(Type.CALCMODE);
/* 76 */     this.calculationMode = cm;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 87 */     byte[] data = new byte[2];
/*    */     
/* 89 */     IntegerHelper.getTwoBytes(this.calculationMode.value, data, 0);
/*    */     
/* 91 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\CalcModeRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */