/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.Sheet;
/*     */ import jxl.biff.DVParser;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.NumFormatRecordsException;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.biff.drawing.ComboBox;
/*     */ import jxl.biff.drawing.Comment;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFeatures;
/*     */ import jxl.write.WritableWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CellValue
/*     */   extends WritableRecordData
/*     */   implements WritableCell
/*     */ {
/*  58 */   private static Logger logger = Logger.getLogger(CellValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int row;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int column;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private XFRecord format;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormattingRecords formattingRecords;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean referenced;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableSheetImpl sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCellFeatures features;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean copied;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CellValue(Type t, int c, int r)
/*     */   {
/* 113 */     this(t, c, r, WritableWorkbook.NORMAL_STYLE);
/* 114 */     this.copied = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CellValue(Type t, Cell c)
/*     */   {
/* 126 */     this(t, c.getColumn(), c.getRow());
/* 127 */     this.copied = true;
/*     */     
/* 129 */     this.format = ((XFRecord)c.getCellFormat());
/*     */     
/* 131 */     if (c.getCellFeatures() != null)
/*     */     {
/* 133 */       this.features = new WritableCellFeatures(c.getCellFeatures());
/* 134 */       this.features.setWritableCell(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CellValue(Type t, int c, int r, CellFormat st)
/*     */   {
/* 149 */     super(t);
/* 150 */     this.row = r;
/* 151 */     this.column = c;
/* 152 */     this.format = ((XFRecord)st);
/* 153 */     this.referenced = false;
/* 154 */     this.copied = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CellValue(Type t, int c, int r, CellValue cv)
/*     */   {
/* 167 */     super(t);
/* 168 */     this.row = r;
/* 169 */     this.column = c;
/* 170 */     this.format = cv.format;
/* 171 */     this.referenced = false;
/* 172 */     this.copied = false;
/*     */     
/*     */ 
/* 175 */     if (cv.features != null)
/*     */     {
/* 177 */       this.features = new WritableCellFeatures(cv.features);
/* 178 */       this.features.setWritableCell(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellFormat(CellFormat cf)
/*     */   {
/* 189 */     this.format = ((XFRecord)cf);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 194 */     if (!this.referenced)
/*     */     {
/* 196 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 201 */     Assert.verify(this.formattingRecords != null);
/*     */     
/* 203 */     addCellFormat();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 213 */     return this.row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 223 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHidden()
/*     */   {
/* 234 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 236 */     if ((cir != null) && (cir.getWidth() == 0))
/*     */     {
/* 238 */       return true;
/*     */     }
/*     */     
/* 241 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 243 */     if ((rr != null) && ((rr.getRowHeight() == 0) || (rr.isCollapsed())))
/*     */     {
/* 245 */       return true;
/*     */     }
/*     */     
/* 248 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 258 */     byte[] mydata = new byte[6];
/* 259 */     IntegerHelper.getTwoBytes(this.row, mydata, 0);
/* 260 */     IntegerHelper.getTwoBytes(this.column, mydata, 2);
/* 261 */     IntegerHelper.getTwoBytes(this.format.getXFIndex(), mydata, 4);
/* 262 */     return mydata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s)
/*     */   {
/* 278 */     this.referenced = true;
/* 279 */     this.sheet = s;
/* 280 */     this.formattingRecords = fr;
/*     */     
/* 282 */     addCellFormat();
/* 283 */     addCellFeatures();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final boolean isReferenced()
/*     */   {
/* 294 */     return this.referenced;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int getXFIndex()
/*     */   {
/* 304 */     return this.format.getXFIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFormat getCellFormat()
/*     */   {
/* 314 */     return this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void incrementRow()
/*     */   {
/* 323 */     this.row += 1;
/*     */     
/* 325 */     if (this.features != null)
/*     */     {
/* 327 */       Comment c = this.features.getCommentDrawing();
/* 328 */       if (c != null)
/*     */       {
/* 330 */         c.setX(this.column);
/* 331 */         c.setY(this.row);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void decrementRow()
/*     */   {
/* 342 */     this.row -= 1;
/*     */     
/* 344 */     if (this.features != null)
/*     */     {
/* 346 */       Comment c = this.features.getCommentDrawing();
/* 347 */       if (c != null)
/*     */       {
/* 349 */         c.setX(this.column);
/* 350 */         c.setY(this.row);
/*     */       }
/*     */       
/* 353 */       if (this.features.hasDropDown())
/*     */       {
/* 355 */         logger.warn("need to change value for drop down drawing");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void incrementColumn()
/*     */   {
/* 366 */     this.column += 1;
/*     */     
/* 368 */     if (this.features != null)
/*     */     {
/* 370 */       Comment c = this.features.getCommentDrawing();
/* 371 */       if (c != null)
/*     */       {
/* 373 */         c.setX(this.column);
/* 374 */         c.setY(this.row);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void decrementColumn()
/*     */   {
/* 386 */     this.column -= 1;
/*     */     
/* 388 */     if (this.features != null)
/*     */     {
/* 390 */       Comment c = this.features.getCommentDrawing();
/* 391 */       if (c != null)
/*     */       {
/* 393 */         c.setX(this.column);
/* 394 */         c.setY(this.row);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(Sheet s, int sheetIndex, int col) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(Sheet s, int sheetIndex, int col) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(Sheet s, int sheetIndex, int row) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(Sheet s, int sheetIndex, int row) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableSheetImpl getSheet()
/*     */   {
/* 455 */     return this.sheet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addCellFormat()
/*     */   {
/* 467 */     Styles styles = this.sheet.getWorkbook().getStyles();
/* 468 */     this.format = styles.getFormat(this.format);
/*     */     
/*     */     try
/*     */     {
/* 472 */       if (!this.format.isInitialized())
/*     */       {
/* 474 */         this.formattingRecords.addStyle(this.format);
/*     */       }
/*     */     }
/*     */     catch (NumFormatRecordsException e)
/*     */     {
/* 479 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*     */       
/* 481 */       this.format = styles.getNormalStyle();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFeatures getCellFeatures()
/*     */   {
/* 492 */     return this.features;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCellFeatures getWritableCellFeatures()
/*     */   {
/* 502 */     return this.features;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellFeatures(WritableCellFeatures cf)
/*     */   {
/* 512 */     if (this.features != null)
/*     */     {
/* 514 */       logger.warn("current cell features for " + CellReferenceHelper.getCellReference(this) + " not null - overwriting");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 519 */       if ((this.features.hasDataValidation()) && (this.features.getDVParser() != null) && (this.features.getDVParser().extendedCellsValidation()))
/*     */       {
/*     */ 
/*     */ 
/* 523 */         DVParser dvp = this.features.getDVParser();
/* 524 */         logger.warn("Cannot add cell features to " + CellReferenceHelper.getCellReference(this) + " because it is part of the shared cell validation " + "group " + CellReferenceHelper.getCellReference(dvp.getFirstColumn(), dvp.getFirstRow()) + "-" + CellReferenceHelper.getCellReference(dvp.getLastColumn(), dvp.getLastRow()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 533 */         return;
/*     */       }
/*     */     }
/*     */     
/* 537 */     this.features = cf;
/* 538 */     cf.setWritableCell(this);
/*     */     
/*     */ 
/*     */ 
/* 542 */     if (this.referenced)
/*     */     {
/* 544 */       addCellFeatures();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addCellFeatures()
/*     */   {
/* 556 */     if (this.features == null)
/*     */     {
/* 558 */       return;
/*     */     }
/*     */     
/* 561 */     if (this.copied == true)
/*     */     {
/* 563 */       this.copied = false;
/*     */       
/* 565 */       return;
/*     */     }
/*     */     
/* 568 */     if (this.features.getComment() != null)
/*     */     {
/* 570 */       Comment comment = new Comment(this.features.getComment(), this.column, this.row);
/*     */       
/* 572 */       comment.setWidth(this.features.getCommentWidth());
/* 573 */       comment.setHeight(this.features.getCommentHeight());
/* 574 */       this.sheet.addDrawing(comment);
/* 575 */       this.sheet.getWorkbook().addDrawing(comment);
/* 576 */       this.features.setCommentDrawing(comment);
/*     */     }
/*     */     
/* 579 */     if (this.features.hasDataValidation())
/*     */     {
/*     */       try
/*     */       {
/* 583 */         this.features.getDVParser().setCell(this.column, this.row, this.sheet.getWorkbook(), this.sheet.getWorkbook(), this.sheet.getWorkbookSettings());
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (FormulaException e)
/*     */       {
/*     */ 
/*     */ 
/* 591 */         Assert.verify(false);
/*     */       }
/*     */       
/* 594 */       this.sheet.addValidationCell(this);
/* 595 */       if (!this.features.hasDropDown())
/*     */       {
/* 597 */         return;
/*     */       }
/*     */       
/*     */ 
/* 601 */       if (this.sheet.getComboBox() == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 606 */         ComboBox cb = new ComboBox();
/* 607 */         this.sheet.addDrawing(cb);
/* 608 */         this.sheet.getWorkbook().addDrawing(cb);
/* 609 */         this.sheet.setComboBox(cb);
/*     */       }
/*     */       
/* 612 */       this.features.setComboBox(this.sheet.getComboBox());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeCellFeatures()
/*     */   {
/* 630 */     this.features = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeComment(Comment c)
/*     */   {
/* 641 */     this.sheet.removeDrawing(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeDataValidation()
/*     */   {
/* 649 */     this.sheet.removeDataValidation(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final void setCopied(boolean c)
/*     */   {
/* 661 */     this.copied = c;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\CellValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */