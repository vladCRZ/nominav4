/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.DisplayFormat;
/*     */ import jxl.biff.FontRecord;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.format.Alignment;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Orientation;
/*     */ import jxl.format.Pattern;
/*     */ import jxl.format.VerticalAlignment;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellXFRecord
/*     */   extends XFRecord
/*     */ {
/*     */   protected CellXFRecord(FontRecord fnt, DisplayFormat form)
/*     */   {
/*  48 */     super(fnt, form);
/*  49 */     setXFDetails(XFRecord.cell, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CellXFRecord(XFRecord fmt)
/*     */   {
/*  59 */     super(fmt);
/*  60 */     setXFDetails(XFRecord.cell, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CellXFRecord(CellFormat format)
/*     */   {
/*  69 */     super(format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlignment(Alignment a)
/*     */     throws WriteException
/*     */   {
/*  80 */     if (isInitialized())
/*     */     {
/*  82 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*  84 */     super.setXFAlignment(a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackground(Colour c, Pattern p)
/*     */     throws WriteException
/*     */   {
/*  96 */     if (isInitialized())
/*     */     {
/*  98 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 100 */     super.setXFBackground(c, p);
/* 101 */     super.setXFCellOptions(16384);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocked(boolean l)
/*     */     throws WriteException
/*     */   {
/* 112 */     if (isInitialized())
/*     */     {
/* 114 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 116 */     super.setXFLocked(l);
/* 117 */     super.setXFCellOptions(32768);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndentation(int i)
/*     */     throws WriteException
/*     */   {
/* 127 */     if (isInitialized())
/*     */     {
/* 129 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 131 */     super.setXFIndentation(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShrinkToFit(boolean s)
/*     */     throws WriteException
/*     */   {
/* 141 */     if (isInitialized())
/*     */     {
/* 143 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 145 */     super.setXFShrinkToFit(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVerticalAlignment(VerticalAlignment va)
/*     */     throws WriteException
/*     */   {
/* 157 */     if (isInitialized())
/*     */     {
/* 159 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 162 */     super.setXFVerticalAlignment(va);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrientation(Orientation o)
/*     */     throws WriteException
/*     */   {
/* 174 */     if (isInitialized())
/*     */     {
/* 176 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 179 */     super.setXFOrientation(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWrap(boolean w)
/*     */     throws WriteException
/*     */   {
/* 192 */     if (isInitialized())
/*     */     {
/* 194 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 197 */     super.setXFWrap(w);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorder(Border b, BorderLineStyle ls, Colour c)
/*     */     throws WriteException
/*     */   {
/* 210 */     if (isInitialized())
/*     */     {
/* 212 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 215 */     if (b == Border.ALL)
/*     */     {
/*     */ 
/* 218 */       super.setXFBorder(Border.LEFT, ls, c);
/* 219 */       super.setXFBorder(Border.RIGHT, ls, c);
/* 220 */       super.setXFBorder(Border.TOP, ls, c);
/* 221 */       super.setXFBorder(Border.BOTTOM, ls, c);
/* 222 */       return;
/*     */     }
/*     */     
/* 225 */     if (b == Border.NONE)
/*     */     {
/*     */ 
/* 228 */       super.setXFBorder(Border.LEFT, BorderLineStyle.NONE, Colour.BLACK);
/* 229 */       super.setXFBorder(Border.RIGHT, BorderLineStyle.NONE, Colour.BLACK);
/* 230 */       super.setXFBorder(Border.TOP, BorderLineStyle.NONE, Colour.BLACK);
/* 231 */       super.setXFBorder(Border.BOTTOM, BorderLineStyle.NONE, Colour.BLACK);
/* 232 */       return;
/*     */     }
/*     */     
/* 235 */     super.setXFBorder(b, ls, c);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\CellXFRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */