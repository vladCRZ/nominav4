/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IndexMapping;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ColumnInfoRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private int column;
/*     */   private XFRecord style;
/*     */   private int xfIndex;
/*     */   private int width;
/*     */   private boolean hidden;
/*     */   private int outlineLevel;
/*     */   private boolean collapsed;
/*     */   
/*     */   public ColumnInfoRecord(int col, int w, XFRecord xf)
/*     */   {
/*  83 */     super(Type.COLINFO);
/*     */     
/*  85 */     this.column = col;
/*  86 */     this.width = w;
/*  87 */     this.style = xf;
/*  88 */     this.xfIndex = this.style.getXFIndex();
/*  89 */     this.hidden = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnInfoRecord(ColumnInfoRecord cir)
/*     */   {
/* 100 */     super(Type.COLINFO);
/*     */     
/* 102 */     this.column = cir.column;
/* 103 */     this.width = cir.width;
/* 104 */     this.style = cir.style;
/* 105 */     this.xfIndex = cir.xfIndex;
/* 106 */     this.hidden = cir.hidden;
/* 107 */     this.outlineLevel = cir.outlineLevel;
/* 108 */     this.collapsed = cir.collapsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnInfoRecord(jxl.read.biff.ColumnInfoRecord cir, int col, FormattingRecords fr)
/*     */   {
/* 124 */     super(Type.COLINFO);
/*     */     
/* 126 */     this.column = col;
/* 127 */     this.width = cir.getWidth();
/* 128 */     this.xfIndex = cir.getXFIndex();
/* 129 */     this.style = fr.getXFRecord(this.xfIndex);
/* 130 */     this.outlineLevel = cir.getOutlineLevel();
/* 131 */     this.collapsed = cir.getCollapsed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnInfoRecord(jxl.read.biff.ColumnInfoRecord cir, int col)
/*     */   {
/* 144 */     super(Type.COLINFO);
/*     */     
/* 146 */     this.column = col;
/* 147 */     this.width = cir.getWidth();
/* 148 */     this.xfIndex = cir.getXFIndex();
/* 149 */     this.outlineLevel = cir.getOutlineLevel();
/* 150 */     this.collapsed = cir.getCollapsed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 160 */     return this.column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void incrementColumn()
/*     */   {
/* 169 */     this.column += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decrementColumn()
/*     */   {
/* 178 */     this.column -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getWidth()
/*     */   {
/* 188 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setWidth(int w)
/*     */   {
/* 198 */     this.width = w;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 208 */     this.data = new byte[12];
/*     */     
/* 210 */     IntegerHelper.getTwoBytes(this.column, this.data, 0);
/* 211 */     IntegerHelper.getTwoBytes(this.column, this.data, 2);
/* 212 */     IntegerHelper.getTwoBytes(this.width, this.data, 4);
/* 213 */     IntegerHelper.getTwoBytes(this.xfIndex, this.data, 6);
/*     */     
/*     */ 
/* 216 */     int options = 0x6 | this.outlineLevel << 8;
/* 217 */     if (this.hidden)
/*     */     {
/* 219 */       options |= 0x1;
/*     */     }
/*     */     
/* 222 */     this.outlineLevel = ((options & 0x700) / 256);
/*     */     
/* 224 */     if (this.collapsed)
/*     */     {
/* 226 */       options |= 0x1000;
/*     */     }
/*     */     
/* 229 */     IntegerHelper.getTwoBytes(options, this.data, 8);
/*     */     
/*     */ 
/* 232 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XFRecord getCellFormat()
/*     */   {
/* 242 */     return this.style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellFormat(XFRecord xfr)
/*     */   {
/* 252 */     this.style = xfr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXfIndex()
/*     */   {
/* 262 */     return this.xfIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rationalize(IndexMapping xfmapping)
/*     */   {
/* 271 */     this.xfIndex = xfmapping.getNewIndex(this.xfIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setHidden(boolean h)
/*     */   {
/* 281 */     this.hidden = h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean getHidden()
/*     */   {
/* 291 */     return this.hidden;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 301 */     if (o == this)
/*     */     {
/* 303 */       return true;
/*     */     }
/*     */     
/* 306 */     if (!(o instanceof ColumnInfoRecord))
/*     */     {
/* 308 */       return false;
/*     */     }
/*     */     
/* 311 */     ColumnInfoRecord cir = (ColumnInfoRecord)o;
/*     */     
/* 313 */     if ((this.column != cir.column) || (this.xfIndex != cir.xfIndex) || (this.width != cir.width) || (this.hidden != cir.hidden) || (this.outlineLevel != cir.outlineLevel) || (this.collapsed != cir.collapsed))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 320 */       return false;
/*     */     }
/*     */     
/* 323 */     if (((this.style == null) && (cir.style != null)) || ((this.style != null) && (cir.style == null)))
/*     */     {
/*     */ 
/* 326 */       return false;
/*     */     }
/*     */     
/* 329 */     return this.style.equals(cir.style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 339 */     int hashValue = 137;
/* 340 */     int oddPrimeNumber = 79;
/*     */     
/* 342 */     hashValue = hashValue * oddPrimeNumber + this.column;
/* 343 */     hashValue = hashValue * oddPrimeNumber + this.xfIndex;
/* 344 */     hashValue = hashValue * oddPrimeNumber + this.width;
/* 345 */     hashValue = hashValue * oddPrimeNumber + (this.hidden ? 1 : 0);
/*     */     
/* 347 */     if (this.style != null)
/*     */     {
/* 349 */       hashValue ^= this.style.hashCode();
/*     */     }
/*     */     
/* 352 */     return hashValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOutlineLevel()
/*     */   {
/* 362 */     return this.outlineLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCollapsed()
/*     */   {
/* 372 */     return this.collapsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void incrementOutlineLevel()
/*     */   {
/* 381 */     this.outlineLevel += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decrementOutlineLevel()
/*     */   {
/* 391 */     if (0 < this.outlineLevel)
/*     */     {
/* 393 */       this.outlineLevel -= 1;
/*     */     }
/*     */     
/* 396 */     if (0 == this.outlineLevel)
/*     */     {
/* 398 */       this.collapsed = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutlineLevel(int level)
/*     */   {
/* 409 */     this.outlineLevel = level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCollapsed(boolean value)
/*     */   {
/* 419 */     this.collapsed = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ColumnInfoRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */