/*    */ package jxl.write.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnsExceededException
/*    */   extends JxlWriteException
/*    */ {
/*    */   public ColumnsExceededException()
/*    */   {
/* 33 */     super(maxColumnsExceeded);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ColumnsExceededException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */