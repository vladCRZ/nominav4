/*      */ package jxl.write.biff;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.biff.BaseCompoundFile;
/*      */ import jxl.biff.BaseCompoundFile.PropertyStorage;
/*      */ import jxl.biff.IntegerHelper;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.read.biff.BiffException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class CompoundFile
/*      */   extends BaseCompoundFile
/*      */ {
/*   52 */   private static Logger logger = Logger.getLogger(CompoundFile.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private OutputStream out;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ExcelDataOutput excelData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int size;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int requiredSize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numBigBlockDepotBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numSmallBlockDepotChainBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private int numSmallBlockDepotBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private int numExtensionBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private int extensionBlock;
/*      */   
/*      */ 
/*      */ 
/*      */   private int excelDataBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private int rootStartBlock;
/*      */   
/*      */ 
/*      */ 
/*      */   private int excelDataStartBlock;
/*      */   
/*      */ 
/*      */ 
/*      */   private int bbdStartBlock;
/*      */   
/*      */ 
/*      */ 
/*      */   private int sbdStartBlockChain;
/*      */   
/*      */ 
/*      */ 
/*      */   private int sbdStartBlock;
/*      */   
/*      */ 
/*      */ 
/*      */   private int additionalPropertyBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private int numSmallBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private int numPropertySets;
/*      */   
/*      */ 
/*      */ 
/*      */   private int numRootEntryBlocks;
/*      */   
/*      */ 
/*      */ 
/*      */   private ArrayList additionalPropertySets;
/*      */   
/*      */ 
/*      */ 
/*      */   private HashMap standardPropertySets;
/*      */   
/*      */ 
/*      */ 
/*      */   private int bbdPos;
/*      */   
/*      */ 
/*      */ 
/*      */   private byte[] bigBlockDepot;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class ReadPropertyStorage
/*      */   {
/*      */     BaseCompoundFile.PropertyStorage propertyStorage;
/*      */     
/*      */ 
/*      */ 
/*      */     byte[] data;
/*      */     
/*      */ 
/*      */ 
/*      */     int number;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     ReadPropertyStorage(BaseCompoundFile.PropertyStorage ps, byte[] d, int n)
/*      */     {
/*  172 */       this.propertyStorage = ps;
/*  173 */       this.data = d;
/*  174 */       this.number = n;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CompoundFile(ExcelDataOutput data, int l, OutputStream os, jxl.read.biff.CompoundFile rcf)
/*      */     throws CopyAdditionalPropertySetsException, IOException
/*      */   {
/*  206 */     this.size = l;
/*  207 */     this.excelData = data;
/*      */     
/*  209 */     readAdditionalPropertySets(rcf);
/*      */     
/*  211 */     this.numRootEntryBlocks = 1;
/*  212 */     this.numPropertySets = (4 + (this.additionalPropertySets != null ? this.additionalPropertySets.size() : 0));
/*      */     
/*      */ 
/*      */ 
/*  216 */     if (this.additionalPropertySets != null)
/*      */     {
/*  218 */       this.numSmallBlockDepotChainBlocks = getBigBlocksRequired(this.numSmallBlocks * 4);
/*  219 */       this.numSmallBlockDepotBlocks = getBigBlocksRequired(this.numSmallBlocks * 64);
/*      */       
/*      */ 
/*  222 */       this.numRootEntryBlocks += getBigBlocksRequired(this.additionalPropertySets.size() * 128);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  227 */     int blocks = getBigBlocksRequired(l);
/*      */     
/*      */ 
/*      */ 
/*  231 */     if (l < 4096)
/*      */     {
/*  233 */       this.requiredSize = 4096;
/*      */     }
/*      */     else
/*      */     {
/*  237 */       this.requiredSize = (blocks * 512);
/*      */     }
/*      */     
/*  240 */     this.out = os;
/*      */     
/*      */ 
/*      */ 
/*  244 */     this.excelDataBlocks = (this.requiredSize / 512);
/*  245 */     this.numBigBlockDepotBlocks = 1;
/*      */     
/*  247 */     int blockChainLength = 109;
/*      */     
/*  249 */     int startTotalBlocks = this.excelDataBlocks + 8 + 8 + this.additionalPropertyBlocks + this.numSmallBlockDepotBlocks + this.numSmallBlockDepotChainBlocks + this.numRootEntryBlocks;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  257 */     int totalBlocks = startTotalBlocks + this.numBigBlockDepotBlocks;
/*      */     
/*      */ 
/*  260 */     this.numBigBlockDepotBlocks = ((int)Math.ceil(totalBlocks / 128.0D));
/*      */     
/*      */ 
/*      */ 
/*  264 */     totalBlocks = startTotalBlocks + this.numBigBlockDepotBlocks;
/*      */     
/*      */ 
/*  267 */     this.numBigBlockDepotBlocks = ((int)Math.ceil(totalBlocks / 128.0D));
/*      */     
/*      */ 
/*      */ 
/*  271 */     totalBlocks = startTotalBlocks + this.numBigBlockDepotBlocks;
/*      */     
/*      */ 
/*      */ 
/*  275 */     if (this.numBigBlockDepotBlocks > blockChainLength - 1)
/*      */     {
/*      */ 
/*      */ 
/*  279 */       this.extensionBlock = 0;
/*      */       
/*      */ 
/*  282 */       int bbdBlocksLeft = this.numBigBlockDepotBlocks - blockChainLength + 1;
/*      */       
/*  284 */       this.numExtensionBlocks = ((int)Math.ceil(bbdBlocksLeft / 127.0D));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  289 */       totalBlocks = startTotalBlocks + this.numExtensionBlocks + this.numBigBlockDepotBlocks;
/*      */       
/*      */ 
/*  292 */       this.numBigBlockDepotBlocks = ((int)Math.ceil(totalBlocks / 128.0D));
/*      */       
/*      */ 
/*      */ 
/*  296 */       totalBlocks = startTotalBlocks + this.numExtensionBlocks + this.numBigBlockDepotBlocks;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  302 */       this.extensionBlock = -2;
/*  303 */       this.numExtensionBlocks = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  308 */     this.excelDataStartBlock = this.numExtensionBlocks;
/*      */     
/*      */ 
/*  311 */     this.sbdStartBlock = -2;
/*  312 */     if ((this.additionalPropertySets != null) && (this.numSmallBlockDepotBlocks != 0))
/*      */     {
/*  314 */       this.sbdStartBlock = (this.excelDataStartBlock + this.excelDataBlocks + this.additionalPropertyBlocks + 16);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  322 */     this.sbdStartBlockChain = -2;
/*      */     
/*  324 */     if (this.sbdStartBlock != -2)
/*      */     {
/*  326 */       this.sbdStartBlockChain = (this.sbdStartBlock + this.numSmallBlockDepotBlocks);
/*      */     }
/*      */     
/*      */ 
/*  330 */     if (this.sbdStartBlockChain != -2)
/*      */     {
/*  332 */       this.bbdStartBlock = (this.sbdStartBlockChain + this.numSmallBlockDepotChainBlocks);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  337 */       this.bbdStartBlock = (this.excelDataStartBlock + this.excelDataBlocks + this.additionalPropertyBlocks + 16);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  344 */     this.rootStartBlock = (this.bbdStartBlock + this.numBigBlockDepotBlocks);
/*      */     
/*      */ 
/*      */ 
/*  348 */     if (totalBlocks != this.rootStartBlock + this.numRootEntryBlocks)
/*      */     {
/*  350 */       logger.warn("Root start block and total blocks are inconsistent  generated file may be corrupt");
/*      */       
/*  352 */       logger.warn("RootStartBlock " + this.rootStartBlock + " totalBlocks " + totalBlocks);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readAdditionalPropertySets(jxl.read.biff.CompoundFile readCompoundFile)
/*      */     throws CopyAdditionalPropertySetsException, IOException
/*      */   {
/*  367 */     if (readCompoundFile == null)
/*      */     {
/*  369 */       return;
/*      */     }
/*      */     
/*  372 */     this.additionalPropertySets = new ArrayList();
/*  373 */     this.standardPropertySets = new HashMap();
/*  374 */     int blocksRequired = 0;
/*      */     
/*  376 */     int numPropertySets = readCompoundFile.getNumberOfPropertySets();
/*      */     
/*  378 */     for (int i = 0; i < numPropertySets; i++)
/*      */     {
/*  380 */       BaseCompoundFile.PropertyStorage ps = readCompoundFile.getPropertySet(i);
/*      */       
/*  382 */       boolean standard = false;
/*      */       
/*  384 */       if (ps.name.equalsIgnoreCase("Root Entry"))
/*      */       {
/*  386 */         standard = true;
/*  387 */         ReadPropertyStorage rps = new ReadPropertyStorage(ps, null, i);
/*  388 */         this.standardPropertySets.put("Root Entry", rps);
/*      */       }
/*      */       
/*      */ 
/*  392 */       for (int j = 0; (j < STANDARD_PROPERTY_SETS.length) && (!standard); j++)
/*      */       {
/*  394 */         if (ps.name.equalsIgnoreCase(STANDARD_PROPERTY_SETS[j]))
/*      */         {
/*      */ 
/*  397 */           BaseCompoundFile.PropertyStorage ps2 = readCompoundFile.findPropertyStorage(ps.name);
/*  398 */           Assert.verify(ps2 != null);
/*      */           
/*  400 */           if (ps2 == ps)
/*      */           {
/*  402 */             standard = true;
/*  403 */             ReadPropertyStorage rps = new ReadPropertyStorage(ps, null, i);
/*  404 */             this.standardPropertySets.put(STANDARD_PROPERTY_SETS[j], rps);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  409 */       if (!standard)
/*      */       {
/*      */         try
/*      */         {
/*  413 */           byte[] data = null;
/*  414 */           if (ps.size > 0)
/*      */           {
/*  416 */             data = readCompoundFile.getStream(i);
/*      */           }
/*      */           else
/*      */           {
/*  420 */             data = new byte[0];
/*      */           }
/*  422 */           ReadPropertyStorage rps = new ReadPropertyStorage(ps, data, i);
/*  423 */           this.additionalPropertySets.add(rps);
/*      */           
/*  425 */           if (data.length > 4096)
/*      */           {
/*  427 */             int blocks = getBigBlocksRequired(data.length);
/*  428 */             blocksRequired += blocks;
/*      */           }
/*      */           else
/*      */           {
/*  432 */             int blocks = getSmallBlocksRequired(data.length);
/*  433 */             this.numSmallBlocks += blocks;
/*      */           }
/*      */         }
/*      */         catch (BiffException e)
/*      */         {
/*  438 */           logger.error(e);
/*  439 */           throw new CopyAdditionalPropertySetsException();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  444 */     this.additionalPropertyBlocks = blocksRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write()
/*      */     throws IOException
/*      */   {
/*  454 */     writeHeader();
/*  455 */     writeExcelData();
/*  456 */     writeDocumentSummaryData();
/*  457 */     writeSummaryData();
/*  458 */     writeAdditionalPropertySets();
/*  459 */     writeSmallBlockDepot();
/*  460 */     writeSmallBlockDepotChain();
/*  461 */     writeBigBlockDepot();
/*  462 */     writePropertySets();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeAdditionalPropertySets()
/*      */     throws IOException
/*      */   {
/*  473 */     if (this.additionalPropertySets == null)
/*      */     {
/*  475 */       return;
/*      */     }
/*      */     
/*  478 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */     {
/*  480 */       ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*  481 */       byte[] data = rps.data;
/*      */       
/*  483 */       if (data.length > 4096)
/*      */       {
/*  485 */         int numBlocks = getBigBlocksRequired(data.length);
/*  486 */         int requiredSize = numBlocks * 512;
/*      */         
/*  488 */         this.out.write(data, 0, data.length);
/*      */         
/*  490 */         byte[] padding = new byte[requiredSize - data.length];
/*  491 */         this.out.write(padding, 0, padding.length);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeExcelData()
/*      */     throws IOException
/*      */   {
/*  505 */     this.excelData.writeData(this.out);
/*      */     
/*  507 */     byte[] padding = new byte[this.requiredSize - this.size];
/*  508 */     this.out.write(padding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeDocumentSummaryData()
/*      */     throws IOException
/*      */   {
/*  518 */     byte[] padding = new byte['က'];
/*      */     
/*      */ 
/*  521 */     this.out.write(padding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeSummaryData()
/*      */     throws IOException
/*      */   {
/*  531 */     byte[] padding = new byte['က'];
/*      */     
/*      */ 
/*  534 */     this.out.write(padding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeHeader()
/*      */     throws IOException
/*      */   {
/*  545 */     byte[] headerBlock = new byte['Ȁ'];
/*  546 */     byte[] extensionBlockData = new byte[512 * this.numExtensionBlocks];
/*      */     
/*      */ 
/*  549 */     System.arraycopy(IDENTIFIER, 0, headerBlock, 0, IDENTIFIER.length);
/*      */     
/*      */ 
/*  552 */     headerBlock[24] = 62;
/*  553 */     headerBlock[26] = 3;
/*  554 */     headerBlock[28] = -2;
/*  555 */     headerBlock[29] = -1;
/*  556 */     headerBlock[30] = 9;
/*  557 */     headerBlock[32] = 6;
/*  558 */     headerBlock[57] = 16;
/*      */     
/*      */ 
/*  561 */     IntegerHelper.getFourBytes(this.numBigBlockDepotBlocks, headerBlock, 44);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  566 */     IntegerHelper.getFourBytes(this.sbdStartBlockChain, headerBlock, 60);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  571 */     IntegerHelper.getFourBytes(this.numSmallBlockDepotChainBlocks, headerBlock, 64);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  576 */     IntegerHelper.getFourBytes(this.extensionBlock, headerBlock, 68);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  581 */     IntegerHelper.getFourBytes(this.numExtensionBlocks, headerBlock, 72);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  586 */     IntegerHelper.getFourBytes(this.rootStartBlock, headerBlock, 48);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  592 */     int pos = 76;
/*      */     
/*      */ 
/*  595 */     int blocksToWrite = Math.min(this.numBigBlockDepotBlocks, 109);
/*      */     
/*      */ 
/*  598 */     int blocksWritten = 0;
/*      */     
/*  600 */     for (int i = 0; i < blocksToWrite; i++)
/*      */     {
/*  602 */       IntegerHelper.getFourBytes(this.bbdStartBlock + i, headerBlock, pos);
/*      */       
/*      */ 
/*  605 */       pos += 4;
/*  606 */       blocksWritten++;
/*      */     }
/*      */     
/*      */ 
/*  610 */     for (int i = pos; i < 512; i++)
/*      */     {
/*  612 */       headerBlock[i] = -1;
/*      */     }
/*      */     
/*  615 */     this.out.write(headerBlock);
/*      */     
/*      */ 
/*  618 */     pos = 0;
/*      */     
/*  620 */     for (int extBlock = 0; extBlock < this.numExtensionBlocks; extBlock++)
/*      */     {
/*  622 */       blocksToWrite = Math.min(this.numBigBlockDepotBlocks - blocksWritten, 127);
/*      */       
/*      */ 
/*  625 */       for (int j = 0; j < blocksToWrite; j++)
/*      */       {
/*  627 */         IntegerHelper.getFourBytes(this.bbdStartBlock + blocksWritten + j, extensionBlockData, pos);
/*      */         
/*      */ 
/*  630 */         pos += 4;
/*      */       }
/*      */       
/*  633 */       blocksWritten += blocksToWrite;
/*      */       
/*      */ 
/*  636 */       int nextBlock = blocksWritten == this.numBigBlockDepotBlocks ? -2 : extBlock + 1;
/*      */       
/*  638 */       IntegerHelper.getFourBytes(nextBlock, extensionBlockData, pos);
/*  639 */       pos += 4;
/*      */     }
/*      */     
/*  642 */     if (this.numExtensionBlocks > 0)
/*      */     {
/*      */ 
/*  645 */       for (int i = pos; i < extensionBlockData.length; i++)
/*      */       {
/*  647 */         extensionBlockData[i] = -1;
/*      */       }
/*      */       
/*  650 */       this.out.write(extensionBlockData);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkBbdPos()
/*      */     throws IOException
/*      */   {
/*  662 */     if (this.bbdPos >= 512)
/*      */     {
/*      */ 
/*  665 */       this.out.write(this.bigBlockDepot);
/*      */       
/*      */ 
/*  668 */       this.bigBlockDepot = new byte['Ȁ'];
/*  669 */       this.bbdPos = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeBlockChain(int startBlock, int numBlocks)
/*      */     throws IOException
/*      */   {
/*  683 */     int blocksToWrite = numBlocks - 1;
/*  684 */     int blockNumber = startBlock + 1;
/*      */     
/*  686 */     while (blocksToWrite > 0)
/*      */     {
/*  688 */       int bbdBlocks = Math.min(blocksToWrite, (512 - this.bbdPos) / 4);
/*      */       
/*  690 */       for (int i = 0; i < bbdBlocks; i++)
/*      */       {
/*  692 */         IntegerHelper.getFourBytes(blockNumber, this.bigBlockDepot, this.bbdPos);
/*  693 */         this.bbdPos += 4;
/*  694 */         blockNumber++;
/*      */       }
/*      */       
/*  697 */       blocksToWrite -= bbdBlocks;
/*  698 */       checkBbdPos();
/*      */     }
/*      */     
/*      */ 
/*  702 */     IntegerHelper.getFourBytes(-2, this.bigBlockDepot, this.bbdPos);
/*  703 */     this.bbdPos += 4;
/*  704 */     checkBbdPos();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeAdditionalPropertySetBlockChains()
/*      */     throws IOException
/*      */   {
/*  714 */     if (this.additionalPropertySets == null)
/*      */     {
/*  716 */       return;
/*      */     }
/*      */     
/*  719 */     int blockNumber = this.excelDataStartBlock + this.excelDataBlocks + 16;
/*  720 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */     {
/*  722 */       ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*  723 */       if (rps.data.length > 4096)
/*      */       {
/*  725 */         int numBlocks = getBigBlocksRequired(rps.data.length);
/*      */         
/*  727 */         writeBlockChain(blockNumber, numBlocks);
/*  728 */         blockNumber += numBlocks;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void writeSmallBlockDepotChain()
/*      */     throws IOException
/*      */   {
/*  738 */     if (this.sbdStartBlockChain == -2)
/*      */     {
/*  740 */       return;
/*      */     }
/*      */     
/*  743 */     byte[] smallBlockDepotChain = new byte[this.numSmallBlockDepotChainBlocks * 512];
/*      */     
/*      */ 
/*  746 */     int pos = 0;
/*  747 */     int sbdBlockNumber = 1;
/*      */     
/*  749 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */     {
/*  751 */       ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*      */       
/*  753 */       if ((rps.data.length <= 4096) && (rps.data.length != 0))
/*      */       {
/*      */ 
/*  756 */         int numSmallBlocks = getSmallBlocksRequired(rps.data.length);
/*  757 */         for (int j = 0; j < numSmallBlocks - 1; j++)
/*      */         {
/*  759 */           IntegerHelper.getFourBytes(sbdBlockNumber, smallBlockDepotChain, pos);
/*      */           
/*      */ 
/*  762 */           pos += 4;
/*  763 */           sbdBlockNumber++;
/*      */         }
/*      */         
/*      */ 
/*  767 */         IntegerHelper.getFourBytes(-2, smallBlockDepotChain, pos);
/*  768 */         pos += 4;
/*  769 */         sbdBlockNumber++;
/*      */       }
/*      */     }
/*      */     
/*  773 */     this.out.write(smallBlockDepotChain);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeSmallBlockDepot()
/*      */     throws IOException
/*      */   {
/*  783 */     if (this.additionalPropertySets == null)
/*      */     {
/*  785 */       return;
/*      */     }
/*      */     
/*  788 */     byte[] smallBlockDepot = new byte[this.numSmallBlockDepotBlocks * 512];
/*      */     
/*      */ 
/*  791 */     int pos = 0;
/*      */     
/*  793 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */     {
/*  795 */       ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*      */       
/*  797 */       if (rps.data.length <= 4096)
/*      */       {
/*  799 */         int smallBlocks = getSmallBlocksRequired(rps.data.length);
/*  800 */         int length = smallBlocks * 64;
/*  801 */         System.arraycopy(rps.data, 0, smallBlockDepot, pos, rps.data.length);
/*  802 */         pos += length;
/*      */       }
/*      */     }
/*      */     
/*  806 */     this.out.write(smallBlockDepot);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeBigBlockDepot()
/*      */     throws IOException
/*      */   {
/*  818 */     this.bigBlockDepot = new byte['Ȁ'];
/*  819 */     this.bbdPos = 0;
/*      */     
/*      */ 
/*  822 */     for (int i = 0; i < this.numExtensionBlocks; i++)
/*      */     {
/*  824 */       IntegerHelper.getFourBytes(-3, this.bigBlockDepot, this.bbdPos);
/*  825 */       this.bbdPos += 4;
/*  826 */       checkBbdPos();
/*      */     }
/*      */     
/*  829 */     writeBlockChain(this.excelDataStartBlock, this.excelDataBlocks);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  834 */     int summaryInfoBlock = this.excelDataStartBlock + this.excelDataBlocks + this.additionalPropertyBlocks;
/*      */     
/*      */ 
/*      */ 
/*  838 */     for (int i = summaryInfoBlock; i < summaryInfoBlock + 7; i++)
/*      */     {
/*  840 */       IntegerHelper.getFourBytes(i + 1, this.bigBlockDepot, this.bbdPos);
/*  841 */       this.bbdPos += 4;
/*  842 */       checkBbdPos();
/*      */     }
/*      */     
/*      */ 
/*  846 */     IntegerHelper.getFourBytes(-2, this.bigBlockDepot, this.bbdPos);
/*  847 */     this.bbdPos += 4;
/*  848 */     checkBbdPos();
/*      */     
/*      */ 
/*  851 */     for (int i = summaryInfoBlock + 8; i < summaryInfoBlock + 15; i++)
/*      */     {
/*  853 */       IntegerHelper.getFourBytes(i + 1, this.bigBlockDepot, this.bbdPos);
/*  854 */       this.bbdPos += 4;
/*  855 */       checkBbdPos();
/*      */     }
/*      */     
/*      */ 
/*  859 */     IntegerHelper.getFourBytes(-2, this.bigBlockDepot, this.bbdPos);
/*  860 */     this.bbdPos += 4;
/*  861 */     checkBbdPos();
/*      */     
/*      */ 
/*  864 */     writeAdditionalPropertySetBlockChains();
/*      */     
/*  866 */     if (this.sbdStartBlock != -2)
/*      */     {
/*      */ 
/*  869 */       writeBlockChain(this.sbdStartBlock, this.numSmallBlockDepotBlocks);
/*      */       
/*      */ 
/*  872 */       writeBlockChain(this.sbdStartBlockChain, this.numSmallBlockDepotChainBlocks);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  877 */     for (int i = 0; i < this.numBigBlockDepotBlocks; i++)
/*      */     {
/*  879 */       IntegerHelper.getFourBytes(-3, this.bigBlockDepot, this.bbdPos);
/*  880 */       this.bbdPos += 4;
/*  881 */       checkBbdPos();
/*      */     }
/*      */     
/*      */ 
/*  885 */     writeBlockChain(this.rootStartBlock, this.numRootEntryBlocks);
/*      */     
/*      */ 
/*  888 */     if (this.bbdPos != 0)
/*      */     {
/*  890 */       for (int i = this.bbdPos; i < 512; i++)
/*      */       {
/*  892 */         this.bigBlockDepot[i] = -1;
/*      */       }
/*  894 */       this.out.write(this.bigBlockDepot);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getBigBlocksRequired(int length)
/*      */   {
/*  907 */     int blocks = length / 512;
/*      */     
/*  909 */     return length % 512 > 0 ? blocks + 1 : blocks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getSmallBlocksRequired(int length)
/*      */   {
/*  921 */     int blocks = length / 64;
/*      */     
/*  923 */     return length % 64 > 0 ? blocks + 1 : blocks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writePropertySets()
/*      */     throws IOException
/*      */   {
/*  933 */     byte[] propertySetStorage = new byte[512 * this.numRootEntryBlocks];
/*      */     
/*  935 */     int pos = 0;
/*  936 */     int[] mappings = null;
/*      */     int newMapping;
/*      */     Iterator i;
/*  939 */     if (this.additionalPropertySets != null)
/*      */     {
/*  941 */       mappings = new int[this.numPropertySets];
/*      */       
/*      */ 
/*  944 */       for (int i = 0; i < STANDARD_PROPERTY_SETS.length; i++)
/*      */       {
/*  946 */         ReadPropertyStorage rps = (ReadPropertyStorage)this.standardPropertySets.get(STANDARD_PROPERTY_SETS[i]);
/*      */         
/*      */ 
/*  949 */         if (rps != null)
/*      */         {
/*  951 */           mappings[rps.number] = i;
/*      */         }
/*      */         else
/*      */         {
/*  955 */           logger.warn("Standard property set " + STANDARD_PROPERTY_SETS[i] + " not present in source file");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  961 */       newMapping = STANDARD_PROPERTY_SETS.length;
/*  962 */       for (i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */       {
/*  964 */         ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*  965 */         mappings[rps.number] = newMapping;
/*  966 */         newMapping++;
/*      */       }
/*      */     }
/*      */     
/*  970 */     int child = 0;
/*  971 */     int previous = 0;
/*  972 */     int next = 0;
/*      */     
/*      */ 
/*  975 */     int size = 0;
/*      */     Iterator i;
/*  977 */     if (this.additionalPropertySets != null)
/*      */     {
/*      */ 
/*  980 */       size += getBigBlocksRequired(this.requiredSize) * 512;
/*      */       
/*      */ 
/*  983 */       size += getBigBlocksRequired(4096) * 512;
/*  984 */       size += getBigBlocksRequired(4096) * 512;
/*      */       
/*      */ 
/*  987 */       for (i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */       {
/*  989 */         ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*  990 */         if (rps.propertyStorage.type != 1)
/*      */         {
/*  992 */           if (rps.propertyStorage.size >= 4096)
/*      */           {
/*  994 */             size += getBigBlocksRequired(rps.propertyStorage.size) * 512;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  999 */             size += getSmallBlocksRequired(rps.propertyStorage.size) * 64;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1007 */     BaseCompoundFile.PropertyStorage ps = new BaseCompoundFile.PropertyStorage(this, "Root Entry");
/* 1008 */     ps.setType(5);
/* 1009 */     ps.setStartBlock(this.sbdStartBlock);
/* 1010 */     ps.setSize(size);
/* 1011 */     ps.setPrevious(-1);
/* 1012 */     ps.setNext(-1);
/* 1013 */     ps.setColour(0);
/*      */     
/* 1015 */     child = 1;
/* 1016 */     if (this.additionalPropertySets != null)
/*      */     {
/* 1018 */       ReadPropertyStorage rps = (ReadPropertyStorage)this.standardPropertySets.get("Root Entry");
/*      */       
/* 1020 */       child = mappings[rps.propertyStorage.child];
/*      */     }
/* 1022 */     ps.setChild(child);
/*      */     
/* 1024 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */     
/*      */ 
/* 1027 */     pos += 128;
/*      */     
/*      */ 
/*      */ 
/* 1031 */     ps = new BaseCompoundFile.PropertyStorage(this, "Workbook");
/* 1032 */     ps.setType(2);
/* 1033 */     ps.setStartBlock(this.excelDataStartBlock);
/*      */     
/* 1035 */     ps.setSize(this.requiredSize);
/*      */     
/*      */ 
/*      */ 
/* 1039 */     previous = 3;
/* 1040 */     next = -1;
/*      */     
/* 1042 */     if (this.additionalPropertySets != null)
/*      */     {
/* 1044 */       ReadPropertyStorage rps = (ReadPropertyStorage)this.standardPropertySets.get("Workbook");
/*      */       
/* 1046 */       previous = rps.propertyStorage.previous != -1 ? mappings[rps.propertyStorage.previous] : -1;
/*      */       
/* 1048 */       next = rps.propertyStorage.next != -1 ? mappings[rps.propertyStorage.next] : -1;
/*      */     }
/*      */     
/*      */ 
/* 1052 */     ps.setPrevious(previous);
/* 1053 */     ps.setNext(next);
/* 1054 */     ps.setChild(-1);
/*      */     
/* 1056 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */     
/*      */ 
/* 1059 */     pos += 128;
/*      */     
/*      */ 
/* 1062 */     ps = new BaseCompoundFile.PropertyStorage(this, "\005SummaryInformation");
/* 1063 */     ps.setType(2);
/* 1064 */     ps.setStartBlock(this.excelDataStartBlock + this.excelDataBlocks);
/* 1065 */     ps.setSize(4096);
/*      */     
/* 1067 */     previous = 1;
/* 1068 */     next = 3;
/*      */     
/* 1070 */     if (this.additionalPropertySets != null)
/*      */     {
/* 1072 */       ReadPropertyStorage rps = (ReadPropertyStorage)this.standardPropertySets.get("\005SummaryInformation");
/*      */       
/*      */ 
/* 1075 */       if (rps != null)
/*      */       {
/* 1077 */         previous = rps.propertyStorage.previous != -1 ? mappings[rps.propertyStorage.previous] : -1;
/*      */         
/* 1079 */         next = rps.propertyStorage.next != -1 ? mappings[rps.propertyStorage.next] : -1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1084 */     ps.setPrevious(previous);
/* 1085 */     ps.setNext(next);
/* 1086 */     ps.setChild(-1);
/*      */     
/* 1088 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */     
/*      */ 
/* 1091 */     pos += 128;
/*      */     
/*      */ 
/* 1094 */     ps = new BaseCompoundFile.PropertyStorage(this, "\005DocumentSummaryInformation");
/* 1095 */     ps.setType(2);
/* 1096 */     ps.setStartBlock(this.excelDataStartBlock + this.excelDataBlocks + 8);
/* 1097 */     ps.setSize(4096);
/* 1098 */     ps.setPrevious(-1);
/* 1099 */     ps.setNext(-1);
/* 1100 */     ps.setChild(-1);
/*      */     
/* 1102 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */     
/*      */ 
/* 1105 */     pos += 128;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1110 */     if (this.additionalPropertySets == null)
/*      */     {
/* 1112 */       this.out.write(propertySetStorage);
/* 1113 */       return;
/*      */     }
/*      */     
/* 1116 */     int bigBlock = this.excelDataStartBlock + this.excelDataBlocks + 16;
/* 1117 */     int smallBlock = 0;
/*      */     
/* 1119 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext();)
/*      */     {
/* 1121 */       ReadPropertyStorage rps = (ReadPropertyStorage)i.next();
/*      */       
/* 1123 */       int block = rps.data.length > 4096 ? bigBlock : smallBlock;
/*      */       
/*      */ 
/* 1126 */       ps = new BaseCompoundFile.PropertyStorage(this, rps.propertyStorage.name);
/* 1127 */       ps.setType(rps.propertyStorage.type);
/* 1128 */       ps.setStartBlock(block);
/* 1129 */       ps.setSize(rps.propertyStorage.size);
/*      */       
/*      */ 
/* 1132 */       previous = rps.propertyStorage.previous != -1 ? mappings[rps.propertyStorage.previous] : -1;
/*      */       
/* 1134 */       next = rps.propertyStorage.next != -1 ? mappings[rps.propertyStorage.next] : -1;
/*      */       
/* 1136 */       child = rps.propertyStorage.child != -1 ? mappings[rps.propertyStorage.child] : -1;
/*      */       
/*      */ 
/* 1139 */       ps.setPrevious(previous);
/* 1140 */       ps.setNext(next);
/* 1141 */       ps.setChild(child);
/*      */       
/* 1143 */       System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */       
/*      */ 
/* 1146 */       pos += 128;
/*      */       
/* 1148 */       if (rps.data.length > 4096)
/*      */       {
/* 1150 */         bigBlock += getBigBlocksRequired(rps.data.length);
/*      */       }
/*      */       else
/*      */       {
/* 1154 */         smallBlock += getSmallBlocksRequired(rps.data.length);
/*      */       }
/*      */     }
/*      */     
/* 1158 */     this.out.write(propertySetStorage);
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\CompoundFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */