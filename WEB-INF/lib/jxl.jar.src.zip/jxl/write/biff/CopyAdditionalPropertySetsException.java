/*    */ package jxl.write.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyAdditionalPropertySetsException
/*    */   extends JxlWriteException
/*    */ {
/*    */   public CopyAdditionalPropertySetsException()
/*    */   {
/* 33 */     super(copyPropertySets);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\CopyAdditionalPropertySetsException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */