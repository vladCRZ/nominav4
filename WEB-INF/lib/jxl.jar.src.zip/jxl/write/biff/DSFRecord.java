/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DSFRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public DSFRecord()
/*    */   {
/* 41 */     super(Type.DSF);
/*    */     
/*    */ 
/*    */ 
/* 45 */     this.data = new byte[] { 0, 0 };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 55 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\DSFRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */