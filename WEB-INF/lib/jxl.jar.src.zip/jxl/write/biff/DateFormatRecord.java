/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.FormatRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateFormatRecord
/*    */   extends FormatRecord
/*    */ {
/*    */   protected DateFormatRecord(String fmt)
/*    */   {
/* 39 */     String fs = fmt;
/*    */     
/* 41 */     fs = replace(fs, "a", "AM/PM");
/* 42 */     fs = replace(fs, "S", "0");
/*    */     
/* 44 */     setFormatString(fs);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\DateFormatRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */