/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.DateFormats;
/*     */ import jxl.write.WritableCellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DateRecord
/*     */   extends CellValue
/*     */ {
/*  44 */   private static Logger logger = Logger.getLogger(DateRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Date date;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean time;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int utcOffsetDays = 25569;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final long msInADay = 86400000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  75 */   static final WritableCellFormat defaultDateFormat = new WritableCellFormat(DateFormats.DEFAULT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int nonLeapDay = 61;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(int c, int r, Date d)
/*     */   {
/* 103 */     this(c, r, d, defaultDateFormat, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(int c, int r, Date d, GMTDate a)
/*     */   {
/* 116 */     this(c, r, d, defaultDateFormat, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(int c, int r, Date d, CellFormat st)
/*     */   {
/* 129 */     super(Type.NUMBER, c, r, st);
/* 130 */     this.date = d;
/* 131 */     calculateValue(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(int c, int r, Date d, CellFormat st, GMTDate a)
/*     */   {
/* 145 */     super(Type.NUMBER, c, r, st);
/* 146 */     this.date = d;
/* 147 */     calculateValue(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(int c, int r, Date d, CellFormat st, boolean tim)
/*     */   {
/* 161 */     super(Type.NUMBER, c, r, st);
/* 162 */     this.date = d;
/* 163 */     this.time = tim;
/* 164 */     calculateValue(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(DateCell dc)
/*     */   {
/* 174 */     super(Type.NUMBER, dc);
/* 175 */     this.date = dc.getDate();
/* 176 */     this.time = dc.isTime();
/* 177 */     calculateValue(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateRecord(int c, int r, DateRecord dr)
/*     */   {
/* 189 */     super(Type.NUMBER, c, r, dr);
/* 190 */     this.value = dr.value;
/* 191 */     this.time = dr.time;
/* 192 */     this.date = dr.date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void calculateValue(boolean adjust)
/*     */   {
/* 205 */     long zoneOffset = 0L;
/* 206 */     long dstOffset = 0L;
/*     */     
/*     */ 
/*     */ 
/* 210 */     if (adjust)
/*     */     {
/*     */ 
/* 213 */       Calendar cal = Calendar.getInstance();
/* 214 */       cal.setTime(this.date);
/*     */       
/* 216 */       zoneOffset = cal.get(15);
/* 217 */       dstOffset = cal.get(16);
/*     */     }
/*     */     
/* 220 */     long utcValue = this.date.getTime() + zoneOffset + dstOffset;
/*     */     
/*     */ 
/*     */ 
/* 224 */     double utcDays = utcValue / 8.64E7D;
/*     */     
/*     */ 
/* 227 */     this.value = (utcDays + 25569.0D);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */     if ((!this.time) && (this.value < 61.0D))
/*     */     {
/* 235 */       this.value -= 1.0D;
/*     */     }
/*     */     
/*     */ 
/* 239 */     if (this.time)
/*     */     {
/* 241 */       this.value -= (int)this.value;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 252 */     return CellType.DATE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 262 */     byte[] celldata = super.getData();
/* 263 */     byte[] data = new byte[celldata.length + 8];
/* 264 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 265 */     DoubleHelper.getIEEEBytes(this.value, data, celldata.length);
/*     */     
/* 267 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 279 */     return this.date.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setDate(Date d)
/*     */   {
/* 289 */     this.date = d;
/* 290 */     calculateValue(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setDate(Date d, GMTDate a)
/*     */   {
/* 301 */     this.date = d;
/* 302 */     calculateValue(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getDate()
/*     */   {
/* 313 */     return this.date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTime()
/*     */   {
/* 325 */     return this.time;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateFormat getDateFormat()
/*     */   {
/* 338 */     return null;
/*     */   }
/*     */   
/*     */   protected static final class GMTDate {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\DateRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */