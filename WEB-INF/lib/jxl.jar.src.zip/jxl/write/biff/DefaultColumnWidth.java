/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultColumnWidth
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int width;
/*    */   private byte[] data;
/*    */   
/*    */   public DefaultColumnWidth(int w)
/*    */   {
/* 47 */     super(Type.DEFCOLWIDTH);
/* 48 */     this.width = w;
/* 49 */     this.data = new byte[2];
/* 50 */     IntegerHelper.getTwoBytes(this.width, this.data, 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte[] getData()
/*    */   {
/* 60 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\DefaultColumnWidth.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */