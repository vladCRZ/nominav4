/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultRowHeightRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private int rowHeight;
/*    */   private boolean changed;
/*    */   
/*    */   public DefaultRowHeightRecord(int h, boolean ch)
/*    */   {
/* 54 */     super(Type.DEFAULTROWHEIGHT);
/* 55 */     this.data = new byte[4];
/* 56 */     this.rowHeight = h;
/* 57 */     this.changed = ch;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 67 */     if (this.changed)
/*    */     {
/* 69 */       int tmp12_11 = 0; byte[] tmp12_8 = this.data;tmp12_8[tmp12_11] = ((byte)(tmp12_8[tmp12_11] | 0x1));
/*    */     }
/*    */     
/* 72 */     IntegerHelper.getTwoBytes(this.rowHeight, this.data, 2);
/* 73 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\DefaultRowHeightRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */