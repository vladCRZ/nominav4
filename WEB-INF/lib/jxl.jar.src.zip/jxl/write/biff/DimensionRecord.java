/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DimensionRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int numRows;
/*    */   private int numCols;
/*    */   private byte[] data;
/*    */   
/*    */   public DimensionRecord(int r, int c)
/*    */   {
/* 53 */     super(Type.DIMENSION);
/* 54 */     this.numRows = r;
/* 55 */     this.numCols = c;
/*    */     
/* 57 */     this.data = new byte[14];
/*    */     
/* 59 */     IntegerHelper.getFourBytes(this.numRows, this.data, 4);
/* 60 */     IntegerHelper.getTwoBytes(this.numCols, this.data, 10);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte[] getData()
/*    */   {
/* 70 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\DimensionRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */