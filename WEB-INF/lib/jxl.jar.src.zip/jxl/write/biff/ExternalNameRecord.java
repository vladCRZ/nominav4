/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ import jxl.common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExternalNameRecord
/*    */   extends WritableRecordData
/*    */ {
/* 37 */   Logger logger = Logger.getLogger(ExternalNameRecord.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ExternalNameRecord(String n)
/*    */   {
/* 49 */     super(Type.EXTERNNAME);
/* 50 */     this.name = n;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 60 */     byte[] data = new byte[this.name.length() * 2 + 12];
/*    */     
/* 62 */     data[6] = ((byte)this.name.length());
/* 63 */     data[7] = 1;
/* 64 */     StringHelper.getUnicodeBytes(this.name, data, 8);
/*    */     
/* 66 */     int pos = 8 + this.name.length() * 2;
/* 67 */     data[pos] = 2;
/* 68 */     data[(pos + 1)] = 0;
/* 69 */     data[(pos + 2)] = 28;
/* 70 */     data[(pos + 3)] = 23;
/*    */     
/* 72 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ExternalNameRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */