/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExternalSheetRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private ArrayList xtis;
/*     */   
/*     */   private static class XTI
/*     */   {
/*     */     int supbookIndex;
/*     */     int firstTab;
/*     */     int lastTab;
/*     */     
/*     */     XTI(int s, int f, int l)
/*     */     {
/*  56 */       this.supbookIndex = s;
/*  57 */       this.firstTab = f;
/*  58 */       this.lastTab = l;
/*     */     }
/*     */     
/*     */     void sheetInserted(int index)
/*     */     {
/*  63 */       if (this.firstTab >= index)
/*     */       {
/*  65 */         this.firstTab += 1;
/*     */       }
/*     */       
/*  68 */       if (this.lastTab >= index)
/*     */       {
/*  70 */         this.lastTab += 1;
/*     */       }
/*     */     }
/*     */     
/*     */     void sheetRemoved(int index)
/*     */     {
/*  76 */       if (this.firstTab == index)
/*     */       {
/*  78 */         this.firstTab = 0;
/*     */       }
/*     */       
/*  81 */       if (this.lastTab == index)
/*     */       {
/*  83 */         this.lastTab = 0;
/*     */       }
/*     */       
/*  86 */       if (this.firstTab > index)
/*     */       {
/*  88 */         this.firstTab -= 1;
/*     */       }
/*     */       
/*  91 */       if (this.lastTab > index)
/*     */       {
/*  93 */         this.lastTab -= 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExternalSheetRecord(jxl.read.biff.ExternalSheetRecord esf)
/*     */   {
/* 105 */     super(Type.EXTERNSHEET);
/*     */     
/* 107 */     this.xtis = new ArrayList(esf.getNumRecords());
/* 108 */     XTI xti = null;
/* 109 */     for (int i = 0; i < esf.getNumRecords(); i++)
/*     */     {
/* 111 */       xti = new XTI(esf.getSupbookIndex(i), esf.getFirstTabIndex(i), esf.getLastTabIndex(i));
/*     */       
/*     */ 
/* 114 */       this.xtis.add(xti);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExternalSheetRecord()
/*     */   {
/* 123 */     super(Type.EXTERNSHEET);
/* 124 */     this.xtis = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getIndex(int supbookind, int sheetind)
/*     */   {
/* 135 */     Iterator i = this.xtis.iterator();
/* 136 */     XTI xti = null;
/* 137 */     boolean found = false;
/* 138 */     int pos = 0;
/* 139 */     while ((i.hasNext()) && (!found))
/*     */     {
/* 141 */       xti = (XTI)i.next();
/*     */       
/* 143 */       if ((xti.supbookIndex == supbookind) && (xti.firstTab == sheetind))
/*     */       {
/*     */ 
/* 146 */         found = true;
/*     */       }
/*     */       else
/*     */       {
/* 150 */         pos++;
/*     */       }
/*     */     }
/*     */     
/* 154 */     if (!found)
/*     */     {
/* 156 */       xti = new XTI(supbookind, sheetind, sheetind);
/* 157 */       this.xtis.add(xti);
/* 158 */       pos = this.xtis.size() - 1;
/*     */     }
/*     */     
/* 161 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 171 */     byte[] data = new byte[2 + this.xtis.size() * 6];
/*     */     
/* 173 */     int pos = 0;
/* 174 */     IntegerHelper.getTwoBytes(this.xtis.size(), data, 0);
/* 175 */     pos += 2;
/*     */     
/* 177 */     Iterator i = this.xtis.iterator();
/* 178 */     XTI xti = null;
/* 179 */     while (i.hasNext())
/*     */     {
/* 181 */       xti = (XTI)i.next();
/* 182 */       IntegerHelper.getTwoBytes(xti.supbookIndex, data, pos);
/* 183 */       IntegerHelper.getTwoBytes(xti.firstTab, data, pos + 2);
/* 184 */       IntegerHelper.getTwoBytes(xti.lastTab, data, pos + 4);
/* 185 */       pos += 6;
/*     */     }
/*     */     
/* 188 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSupbookIndex(int index)
/*     */   {
/* 199 */     return ((XTI)this.xtis.get(index)).supbookIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstTabIndex(int index)
/*     */   {
/* 210 */     return ((XTI)this.xtis.get(index)).firstTab;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastTabIndex(int index)
/*     */   {
/* 221 */     return ((XTI)this.xtis.get(index)).lastTab;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void sheetInserted(int index)
/*     */   {
/* 230 */     XTI xti = null;
/* 231 */     for (Iterator i = this.xtis.iterator(); i.hasNext();)
/*     */     {
/* 233 */       xti = (XTI)i.next();
/* 234 */       xti.sheetInserted(index);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void sheetRemoved(int index)
/*     */   {
/* 244 */     XTI xti = null;
/* 245 */     for (Iterator i = this.xtis.iterator(); i.hasNext();)
/*     */     {
/* 247 */       xti = (XTI)i.next();
/* 248 */       xti.sheetRemoved(index);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ExternalSheetRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */