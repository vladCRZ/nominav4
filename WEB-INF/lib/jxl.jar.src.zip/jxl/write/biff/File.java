/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class File
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(File.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExcelDataOutput data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private OutputStream outputStream;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int initialFileSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int arrayGrowSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */   jxl.read.biff.CompoundFile readCompoundFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   File(OutputStream os, WorkbookSettings ws, jxl.read.biff.CompoundFile rcf)
/*     */     throws IOException
/*     */   {
/*  83 */     this.outputStream = os;
/*  84 */     this.workbookSettings = ws;
/*  85 */     this.readCompoundFile = rcf;
/*  86 */     createDataOutput();
/*     */   }
/*     */   
/*     */   private void createDataOutput() throws IOException
/*     */   {
/*  91 */     if (this.workbookSettings.getUseTemporaryFileDuringWrite())
/*     */     {
/*  93 */       this.data = new FileDataOutput(this.workbookSettings.getTemporaryFileDuringWriteDirectory());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  98 */       this.initialFileSize = this.workbookSettings.getInitialFileSize();
/*  99 */       this.arrayGrowSize = this.workbookSettings.getArrayGrowSize();
/*     */       
/* 101 */       this.data = new MemoryDataOutput(this.initialFileSize, this.arrayGrowSize);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void close(boolean cs)
/*     */     throws IOException, JxlWriteException
/*     */   {
/* 116 */     CompoundFile cf = new CompoundFile(this.data, this.data.getPosition(), this.outputStream, this.readCompoundFile);
/*     */     
/*     */ 
/*     */ 
/* 120 */     cf.write();
/*     */     
/* 122 */     this.outputStream.flush();
/* 123 */     this.data.close();
/*     */     
/* 125 */     if (cs)
/*     */     {
/* 127 */       this.outputStream.close();
/*     */     }
/*     */     
/*     */ 
/* 131 */     this.data = null;
/*     */     
/* 133 */     if (!this.workbookSettings.getGCDisabled())
/*     */     {
/* 135 */       System.gc();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(ByteData record)
/*     */     throws IOException
/*     */   {
/* 147 */     byte[] bytes = record.getBytes();
/*     */     
/* 149 */     this.data.write(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getPos()
/*     */     throws IOException
/*     */   {
/* 159 */     return this.data.getPosition();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setData(byte[] newdata, int pos)
/*     */     throws IOException
/*     */   {
/* 171 */     this.data.setData(newdata, pos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputFile(OutputStream os)
/*     */     throws IOException
/*     */   {
/* 183 */     if (this.data != null)
/*     */     {
/* 185 */       logger.warn("Rewriting a workbook with non-empty data");
/*     */     }
/*     */     
/* 188 */     this.outputStream = os;
/* 189 */     createDataOutput();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\File.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */