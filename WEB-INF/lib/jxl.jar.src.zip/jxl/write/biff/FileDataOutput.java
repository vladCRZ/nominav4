/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FileDataOutput
/*     */   implements ExcelDataOutput
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(FileDataOutput.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File temporaryFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private RandomAccessFile data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileDataOutput(File tmpdir)
/*     */     throws IOException
/*     */   {
/*  56 */     this.temporaryFile = File.createTempFile("jxl", ".tmp", tmpdir);
/*  57 */     this.temporaryFile.deleteOnExit();
/*  58 */     this.data = new RandomAccessFile(this.temporaryFile, "rw");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] bytes)
/*     */     throws IOException
/*     */   {
/*  69 */     this.data.write(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPosition()
/*     */     throws IOException
/*     */   {
/*  81 */     return (int)this.data.getFilePointer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(byte[] newdata, int pos)
/*     */     throws IOException
/*     */   {
/*  92 */     long curpos = this.data.getFilePointer();
/*  93 */     this.data.seek(pos);
/*  94 */     this.data.write(newdata);
/*  95 */     this.data.seek(curpos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeData(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 103 */     byte[] buffer = new byte['Ѐ'];
/* 104 */     int length = 0;
/* 105 */     this.data.seek(0L);
/* 106 */     while ((length = this.data.read(buffer)) != -1)
/*     */     {
/* 108 */       out.write(buffer, 0, length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 117 */     this.data.close();
/*     */     
/*     */ 
/*     */ 
/* 121 */     this.temporaryFile.delete();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\FileDataOutput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */