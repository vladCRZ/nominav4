/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FooterRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private String footer;
/*    */   
/*    */   public FooterRecord(String s)
/*    */   {
/* 49 */     super(Type.FOOTER);
/*    */     
/* 51 */     this.footer = s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FooterRecord(FooterRecord fr)
/*    */   {
/* 61 */     super(Type.FOOTER);
/*    */     
/* 63 */     this.footer = fr.footer;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 73 */     if ((this.footer == null) || (this.footer.length() == 0))
/*    */     {
/* 75 */       this.data = new byte[0];
/* 76 */       return this.data;
/*    */     }
/*    */     
/* 79 */     this.data = new byte[this.footer.length() * 2 + 3];
/* 80 */     IntegerHelper.getTwoBytes(this.footer.length(), this.data, 0);
/* 81 */     this.data[2] = 1;
/*    */     
/* 83 */     StringHelper.getUnicodeBytes(this.footer, this.data, 3);
/*    */     
/* 85 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\FooterRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */