/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.CellType;
/*     */ import jxl.Sheet;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.WritableCell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormulaRecord
/*     */   extends CellValue
/*     */   implements FormulaData
/*     */ {
/*  49 */   private static Logger logger = Logger.getLogger(FormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formulaToParse;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormulaParser parser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formulaString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] formulaBytes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CellValue copiedFrom;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaRecord(int c, int r, String f)
/*     */   {
/*  84 */     super(Type.FORMULA2, c, r);
/*  85 */     this.formulaToParse = f;
/*  86 */     this.copiedFrom = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaRecord(int c, int r, String f, CellFormat st)
/*     */   {
/*  96 */     super(Type.FORMULA, c, r, st);
/*  97 */     this.formulaToParse = f;
/*  98 */     this.copiedFrom = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FormulaRecord(int c, int r, FormulaRecord fr)
/*     */   {
/* 110 */     super(Type.FORMULA, c, r, fr);
/* 111 */     this.copiedFrom = fr;
/* 112 */     this.formulaBytes = new byte[fr.formulaBytes.length];
/* 113 */     System.arraycopy(fr.formulaBytes, 0, this.formulaBytes, 0, this.formulaBytes.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FormulaRecord(int c, int r, ReadFormulaRecord rfr)
/*     */   {
/* 125 */     super(Type.FORMULA, c, r, rfr);
/*     */     try
/*     */     {
/* 128 */       this.copiedFrom = rfr;
/* 129 */       this.formulaBytes = rfr.getFormulaBytes();
/*     */ 
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 134 */       logger.error("", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize(WorkbookSettings ws, ExternalSheet es, WorkbookMethods nt)
/*     */   {
/* 150 */     if (this.copiedFrom != null)
/*     */     {
/* 152 */       initializeCopiedFormula(ws, es, nt);
/* 153 */       return;
/*     */     }
/*     */     
/* 156 */     this.parser = new FormulaParser(this.formulaToParse, es, nt, ws);
/*     */     
/*     */     try
/*     */     {
/* 160 */       this.parser.parse();
/* 161 */       this.formulaString = this.parser.getFormula();
/* 162 */       this.formulaBytes = this.parser.getBytes();
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 166 */       logger.warn(e.getMessage() + " when parsing formula " + this.formulaToParse + " in cell " + getSheet().getName() + "!" + CellReferenceHelper.getCellReference(getColumn(), getRow()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 175 */         this.formulaToParse = "ERROR(1)";
/* 176 */         this.parser = new FormulaParser(this.formulaToParse, es, nt, ws);
/* 177 */         this.parser.parse();
/* 178 */         this.formulaString = this.parser.getFormula();
/* 179 */         this.formulaBytes = this.parser.getBytes();
/*     */ 
/*     */       }
/*     */       catch (FormulaException e2)
/*     */       {
/* 184 */         logger.error("", e2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initializeCopiedFormula(WorkbookSettings ws, ExternalSheet es, WorkbookMethods nt)
/*     */   {
/*     */     try
/*     */     {
/* 202 */       this.parser = new FormulaParser(this.formulaBytes, this, es, nt, ws);
/* 203 */       this.parser.parse();
/* 204 */       this.parser.adjustRelativeCellReferences(getColumn() - this.copiedFrom.getColumn(), getRow() - this.copiedFrom.getRow());
/*     */       
/*     */ 
/* 207 */       this.formulaString = this.parser.getFormula();
/* 208 */       this.formulaBytes = this.parser.getBytes();
/*     */ 
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/*     */       try
/*     */       {
/* 215 */         this.formulaToParse = "ERROR(1)";
/* 216 */         this.parser = new FormulaParser(this.formulaToParse, es, nt, ws);
/* 217 */         this.parser.parse();
/* 218 */         this.formulaString = this.parser.getFormula();
/* 219 */         this.formulaBytes = this.parser.getBytes();
/*     */ 
/*     */       }
/*     */       catch (FormulaException e2)
/*     */       {
/*     */ 
/* 225 */         logger.error("", e2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s)
/*     */   {
/* 242 */     super.setCellDetails(fr, ss, s);
/* 243 */     initialize(s.getWorkbookSettings(), s.getWorkbook(), s.getWorkbook());
/* 244 */     s.getWorkbook().addRCIRCell(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 254 */     byte[] celldata = super.getData();
/* 255 */     byte[] formulaData = getFormulaData();
/* 256 */     byte[] data = new byte[formulaData.length + celldata.length];
/* 257 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 258 */     System.arraycopy(formulaData, 0, data, celldata.length, formulaData.length);
/*     */     
/* 260 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 270 */     return CellType.ERROR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 282 */     return this.formulaString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */   {
/* 293 */     byte[] data = new byte[this.formulaBytes.length + 16];
/* 294 */     System.arraycopy(this.formulaBytes, 0, data, 16, this.formulaBytes.length);
/*     */     
/* 296 */     data[6] = 16;
/* 297 */     data[7] = 64;
/* 298 */     data[12] = -32;
/* 299 */     data[13] = -4; byte[] 
/*     */     
/* 301 */       tmp54_51 = data;tmp54_51[8] = ((byte)(tmp54_51[8] | 0x2));
/*     */     
/*     */ 
/* 304 */     IntegerHelper.getTwoBytes(this.formulaBytes.length, data, 14);
/*     */     
/* 306 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCell copyTo(int col, int row)
/*     */   {
/* 319 */     Assert.verify(false);
/* 320 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(Sheet s, int sheetIndex, int col)
/*     */   {
/* 333 */     this.parser.columnInserted(sheetIndex, col, s == getSheet());
/* 334 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(Sheet s, int sheetIndex, int col)
/*     */   {
/* 347 */     this.parser.columnRemoved(sheetIndex, col, s == getSheet());
/* 348 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(Sheet s, int sheetIndex, int row)
/*     */   {
/* 361 */     this.parser.rowInserted(sheetIndex, row, s == getSheet());
/* 362 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(Sheet s, int sheetIndex, int row)
/*     */   {
/* 375 */     this.parser.rowRemoved(sheetIndex, row, s == getSheet());
/* 376 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\FormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */