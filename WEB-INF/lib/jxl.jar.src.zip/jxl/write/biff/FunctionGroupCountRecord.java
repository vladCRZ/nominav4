/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FunctionGroupCountRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private int numFunctionGroups;
/*    */   
/*    */   public FunctionGroupCountRecord()
/*    */   {
/* 46 */     super(Type.FNGROUPCOUNT);
/*    */     
/* 48 */     this.numFunctionGroups = 14;
/*    */     
/* 50 */     this.data = new byte[2];
/*    */     
/* 52 */     IntegerHelper.getTwoBytes(this.numFunctionGroups, this.data, 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 62 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\FunctionGroupCountRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */