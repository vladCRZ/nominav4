/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GuttersRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private int rowGutter;
/*     */   private int colGutter;
/*     */   private int maxRowOutline;
/*     */   private int maxColumnOutline;
/*     */   
/*     */   public GuttersRecord()
/*     */   {
/*  58 */     super(Type.GUTS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  68 */     this.data = new byte[8];
/*  69 */     IntegerHelper.getTwoBytes(this.rowGutter, this.data, 0);
/*  70 */     IntegerHelper.getTwoBytes(this.colGutter, this.data, 2);
/*  71 */     IntegerHelper.getTwoBytes(this.maxRowOutline, this.data, 4);
/*  72 */     IntegerHelper.getTwoBytes(this.maxColumnOutline, this.data, 6);
/*  73 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxRowOutline()
/*     */   {
/*  83 */     return this.maxRowOutline;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxRowOutline(int value)
/*     */   {
/*  93 */     this.maxRowOutline = value;
/*  94 */     this.rowGutter = (1 + 14 * value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxColumnOutline()
/*     */   {
/* 104 */     return this.maxColumnOutline;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxColumnOutline(int value)
/*     */   {
/* 114 */     this.maxColumnOutline = value;
/* 115 */     this.colGutter = (1 + 14 * value);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\GuttersRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */