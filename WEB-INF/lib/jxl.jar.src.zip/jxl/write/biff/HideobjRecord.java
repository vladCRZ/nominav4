/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HideobjRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int hidemode;
/*    */   private byte[] data;
/*    */   
/*    */   public HideobjRecord(int newHideMode)
/*    */   {
/* 53 */     super(Type.HIDEOBJ);
/*    */     
/* 55 */     this.hidemode = newHideMode;
/* 56 */     this.data = new byte[2];
/*    */     
/* 58 */     IntegerHelper.getTwoBytes(this.hidemode, this.data, 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 68 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\HideobjRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */