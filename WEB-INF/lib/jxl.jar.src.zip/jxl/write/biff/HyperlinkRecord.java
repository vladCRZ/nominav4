/*      */ package jxl.write.biff;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import jxl.CellType;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.Range;
/*      */ import jxl.biff.CellReferenceHelper;
/*      */ import jxl.biff.IntegerHelper;
/*      */ import jxl.biff.SheetRangeImpl;
/*      */ import jxl.biff.StringHelper;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WritableRecordData;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.read.biff.Record;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableSheet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HyperlinkRecord
/*      */   extends WritableRecordData
/*      */ {
/*   54 */   private static Logger logger = Logger.getLogger(HyperlinkRecord.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int firstRow;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lastRow;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int firstColumn;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lastColumn;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private URL url;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private File file;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String location;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String contents;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private LinkType linkType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] data;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Range range;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WritableSheet sheet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean modified;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  124 */   private static final LinkType urlLink = new LinkType(null);
/*  125 */   private static final LinkType fileLink = new LinkType(null);
/*  126 */   private static final LinkType uncLink = new LinkType(null);
/*  127 */   private static final LinkType workbookLink = new LinkType(null);
/*  128 */   private static final LinkType unknown = new LinkType(null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HyperlinkRecord(Hyperlink h, WritableSheet s)
/*      */   {
/*  137 */     super(Type.HLINK);
/*      */     
/*  139 */     if ((h instanceof jxl.read.biff.HyperlinkRecord))
/*      */     {
/*  141 */       copyReadHyperlink(h, s);
/*      */     }
/*      */     else
/*      */     {
/*  145 */       copyWritableHyperlink(h, s);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void copyReadHyperlink(Hyperlink h, WritableSheet s)
/*      */   {
/*  154 */     jxl.read.biff.HyperlinkRecord hl = (jxl.read.biff.HyperlinkRecord)h;
/*      */     
/*  156 */     this.data = hl.getRecord().getData();
/*  157 */     this.sheet = s;
/*      */     
/*      */ 
/*  160 */     this.firstRow = hl.getRow();
/*  161 */     this.firstColumn = hl.getColumn();
/*  162 */     this.lastRow = hl.getLastRow();
/*  163 */     this.lastColumn = hl.getLastColumn();
/*  164 */     this.range = new SheetRangeImpl(s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     
/*      */ 
/*      */ 
/*  168 */     this.linkType = unknown;
/*      */     
/*  170 */     if (hl.isFile())
/*      */     {
/*  172 */       this.linkType = fileLink;
/*  173 */       this.file = hl.getFile();
/*      */     }
/*  175 */     else if (hl.isURL())
/*      */     {
/*  177 */       this.linkType = urlLink;
/*  178 */       this.url = hl.getURL();
/*      */     }
/*  180 */     else if (hl.isLocation())
/*      */     {
/*  182 */       this.linkType = workbookLink;
/*  183 */       this.location = hl.getLocation();
/*      */     }
/*      */     
/*  186 */     this.modified = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void copyWritableHyperlink(Hyperlink hl, WritableSheet s)
/*      */   {
/*  197 */     HyperlinkRecord h = (HyperlinkRecord)hl;
/*      */     
/*  199 */     this.firstRow = h.firstRow;
/*  200 */     this.lastRow = h.lastRow;
/*  201 */     this.firstColumn = h.firstColumn;
/*  202 */     this.lastColumn = h.lastColumn;
/*      */     
/*  204 */     if (h.url != null)
/*      */     {
/*      */       try
/*      */       {
/*  208 */         this.url = new URL(h.url.toString());
/*      */ 
/*      */       }
/*      */       catch (MalformedURLException e)
/*      */       {
/*  213 */         Assert.verify(false);
/*      */       }
/*      */     }
/*      */     
/*  217 */     if (h.file != null)
/*      */     {
/*  219 */       this.file = new File(h.file.getPath());
/*      */     }
/*      */     
/*  222 */     this.location = h.location;
/*  223 */     this.contents = h.contents;
/*  224 */     this.linkType = h.linkType;
/*  225 */     this.modified = true;
/*      */     
/*  227 */     this.sheet = s;
/*  228 */     this.range = new SheetRangeImpl(s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HyperlinkRecord(int col, int row, int lastcol, int lastrow, URL url, String desc)
/*      */   {
/*  248 */     super(Type.HLINK);
/*      */     
/*  250 */     this.firstColumn = col;
/*  251 */     this.firstRow = row;
/*      */     
/*  253 */     this.lastColumn = Math.max(this.firstColumn, lastcol);
/*  254 */     this.lastRow = Math.max(this.firstRow, lastrow);
/*      */     
/*  256 */     this.url = url;
/*  257 */     this.contents = desc;
/*      */     
/*  259 */     this.linkType = urlLink;
/*      */     
/*  261 */     this.modified = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HyperlinkRecord(int col, int row, int lastcol, int lastrow, File file, String desc)
/*      */   {
/*  277 */     super(Type.HLINK);
/*      */     
/*  279 */     this.firstColumn = col;
/*  280 */     this.firstRow = row;
/*      */     
/*  282 */     this.lastColumn = Math.max(this.firstColumn, lastcol);
/*  283 */     this.lastRow = Math.max(this.firstRow, lastrow);
/*  284 */     this.contents = desc;
/*      */     
/*  286 */     this.file = file;
/*      */     
/*  288 */     if (file.getPath().startsWith("\\\\"))
/*      */     {
/*  290 */       this.linkType = uncLink;
/*      */     }
/*      */     else
/*      */     {
/*  294 */       this.linkType = fileLink;
/*      */     }
/*      */     
/*  297 */     this.modified = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HyperlinkRecord(int col, int row, int lastcol, int lastrow, String desc, WritableSheet s, int destcol, int destrow, int lastdestcol, int lastdestrow)
/*      */   {
/*  321 */     super(Type.HLINK);
/*      */     
/*  323 */     this.firstColumn = col;
/*  324 */     this.firstRow = row;
/*      */     
/*  326 */     this.lastColumn = Math.max(this.firstColumn, lastcol);
/*  327 */     this.lastRow = Math.max(this.firstRow, lastrow);
/*      */     
/*  329 */     setLocation(s, destcol, destrow, lastdestcol, lastdestrow);
/*  330 */     this.contents = desc;
/*      */     
/*  332 */     this.linkType = workbookLink;
/*      */     
/*  334 */     this.modified = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFile()
/*      */   {
/*  344 */     return this.linkType == fileLink;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUNC()
/*      */   {
/*  354 */     return this.linkType == uncLink;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isURL()
/*      */   {
/*  364 */     return this.linkType == urlLink;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLocation()
/*      */   {
/*  374 */     return this.linkType == workbookLink;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRow()
/*      */   {
/*  384 */     return this.firstRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumn()
/*      */   {
/*  394 */     return this.firstColumn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastRow()
/*      */   {
/*  404 */     return this.lastRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastColumn()
/*      */   {
/*  414 */     return this.lastColumn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL()
/*      */   {
/*  424 */     return this.url;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public File getFile()
/*      */   {
/*  434 */     return this.file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getData()
/*      */   {
/*  444 */     if (!this.modified)
/*      */     {
/*  446 */       return this.data;
/*      */     }
/*      */     
/*      */ 
/*  450 */     byte[] commonData = new byte[32];
/*      */     
/*      */ 
/*  453 */     IntegerHelper.getTwoBytes(this.firstRow, commonData, 0);
/*  454 */     IntegerHelper.getTwoBytes(this.lastRow, commonData, 2);
/*  455 */     IntegerHelper.getTwoBytes(this.firstColumn, commonData, 4);
/*  456 */     IntegerHelper.getTwoBytes(this.lastColumn, commonData, 6);
/*      */     
/*      */ 
/*  459 */     commonData[8] = -48;
/*  460 */     commonData[9] = -55;
/*  461 */     commonData[10] = -22;
/*  462 */     commonData[11] = 121;
/*  463 */     commonData[12] = -7;
/*  464 */     commonData[13] = -70;
/*  465 */     commonData[14] = -50;
/*  466 */     commonData[15] = 17;
/*  467 */     commonData[16] = -116;
/*  468 */     commonData[17] = -126;
/*  469 */     commonData[18] = 0;
/*  470 */     commonData[19] = -86;
/*  471 */     commonData[20] = 0;
/*  472 */     commonData[21] = 75;
/*  473 */     commonData[22] = -87;
/*  474 */     commonData[23] = 11;
/*  475 */     commonData[24] = 2;
/*  476 */     commonData[25] = 0;
/*  477 */     commonData[26] = 0;
/*  478 */     commonData[27] = 0;
/*      */     
/*      */ 
/*      */ 
/*  482 */     int optionFlags = 0;
/*  483 */     if (isURL())
/*      */     {
/*  485 */       optionFlags = 3;
/*      */       
/*  487 */       if (this.contents != null)
/*      */       {
/*  489 */         optionFlags |= 0x14;
/*      */       }
/*      */     }
/*  492 */     else if (isFile())
/*      */     {
/*  494 */       optionFlags = 1;
/*      */       
/*  496 */       if (this.contents != null)
/*      */       {
/*  498 */         optionFlags |= 0x14;
/*      */       }
/*      */     }
/*  501 */     else if (isLocation())
/*      */     {
/*  503 */       optionFlags = 8;
/*      */     }
/*  505 */     else if (isUNC())
/*      */     {
/*  507 */       optionFlags = 259;
/*      */     }
/*      */     
/*  510 */     IntegerHelper.getFourBytes(optionFlags, commonData, 28);
/*      */     
/*  512 */     if (isURL())
/*      */     {
/*  514 */       this.data = getURLData(commonData);
/*      */     }
/*  516 */     else if (isFile())
/*      */     {
/*  518 */       this.data = getFileData(commonData);
/*      */     }
/*  520 */     else if (isLocation())
/*      */     {
/*  522 */       this.data = getLocationData(commonData);
/*      */     }
/*  524 */     else if (isUNC())
/*      */     {
/*  526 */       this.data = getUNCData(commonData);
/*      */     }
/*      */     
/*  529 */     return this.data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  539 */     if (isFile())
/*      */     {
/*  541 */       return this.file.toString();
/*      */     }
/*  543 */     if (isURL())
/*      */     {
/*  545 */       return this.url.toString();
/*      */     }
/*  547 */     if (isUNC())
/*      */     {
/*  549 */       return this.file.toString();
/*      */     }
/*      */     
/*      */ 
/*  553 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range getRange()
/*      */   {
/*  567 */     return this.range;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURL(URL url)
/*      */   {
/*  577 */     URL prevurl = this.url;
/*  578 */     this.linkType = urlLink;
/*  579 */     this.file = null;
/*  580 */     this.location = null;
/*  581 */     this.contents = null;
/*  582 */     this.url = url;
/*  583 */     this.modified = true;
/*      */     
/*  585 */     if (this.sheet == null)
/*      */     {
/*      */ 
/*  588 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  593 */     WritableCell wc = this.sheet.getWritableCell(this.firstColumn, this.firstRow);
/*      */     
/*  595 */     if (wc.getType() == CellType.LABEL)
/*      */     {
/*  597 */       Label l = (Label)wc;
/*  598 */       String prevurlString = prevurl.toString();
/*  599 */       String prevurlString2 = "";
/*  600 */       if ((prevurlString.charAt(prevurlString.length() - 1) == '/') || (prevurlString.charAt(prevurlString.length() - 1) == '\\'))
/*      */       {
/*      */ 
/*  603 */         prevurlString2 = prevurlString.substring(0, prevurlString.length() - 1);
/*      */       }
/*      */       
/*      */ 
/*  607 */       if ((l.getString().equals(prevurlString)) || (l.getString().equals(prevurlString2)))
/*      */       {
/*      */ 
/*  610 */         l.setString(url.toString());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFile(File file)
/*      */   {
/*  622 */     this.linkType = fileLink;
/*  623 */     this.url = null;
/*  624 */     this.location = null;
/*  625 */     this.contents = null;
/*  626 */     this.file = file;
/*  627 */     this.modified = true;
/*      */     
/*  629 */     if (this.sheet == null)
/*      */     {
/*      */ 
/*  632 */       return;
/*      */     }
/*      */     
/*      */ 
/*  636 */     WritableCell wc = this.sheet.getWritableCell(this.firstColumn, this.firstRow);
/*      */     
/*  638 */     Assert.verify(wc.getType() == CellType.LABEL);
/*      */     
/*  640 */     Label l = (Label)wc;
/*  641 */     l.setString(file.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setLocation(String desc, WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow)
/*      */   {
/*  659 */     this.linkType = workbookLink;
/*  660 */     this.url = null;
/*  661 */     this.file = null;
/*  662 */     this.modified = true;
/*  663 */     this.contents = desc;
/*      */     
/*  665 */     setLocation(sheet, destcol, destrow, lastdestcol, lastdestrow);
/*      */     
/*  667 */     if (sheet == null)
/*      */     {
/*      */ 
/*  670 */       return;
/*      */     }
/*      */     
/*      */ 
/*  674 */     WritableCell wc = sheet.getWritableCell(this.firstColumn, this.firstRow);
/*      */     
/*  676 */     Assert.verify(wc.getType() == CellType.LABEL);
/*      */     
/*  678 */     Label l = (Label)wc;
/*  679 */     l.setString(desc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setLocation(WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow)
/*      */   {
/*  695 */     StringBuffer sb = new StringBuffer();
/*  696 */     sb.append('\'');
/*      */     
/*  698 */     if (sheet.getName().indexOf('\'') == -1)
/*      */     {
/*  700 */       sb.append(sheet.getName());
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  708 */       String sheetName = sheet.getName();
/*  709 */       int pos = 0;
/*  710 */       int nextPos = sheetName.indexOf('\'', pos);
/*      */       
/*  712 */       while ((nextPos != -1) && (pos < sheetName.length()))
/*      */       {
/*  714 */         sb.append(sheetName.substring(pos, nextPos));
/*  715 */         sb.append("''");
/*  716 */         pos = nextPos + 1;
/*  717 */         nextPos = sheetName.indexOf('\'', pos);
/*      */       }
/*  719 */       sb.append(sheetName.substring(pos));
/*      */     }
/*      */     
/*  722 */     sb.append('\'');
/*  723 */     sb.append('!');
/*      */     
/*  725 */     lastdestcol = Math.max(destcol, lastdestcol);
/*  726 */     lastdestrow = Math.max(destrow, lastdestrow);
/*      */     
/*  728 */     CellReferenceHelper.getCellReference(destcol, destrow, sb);
/*  729 */     sb.append(':');
/*  730 */     CellReferenceHelper.getCellReference(lastdestcol, lastdestrow, sb);
/*      */     
/*  732 */     this.location = sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void insertRow(int r)
/*      */   {
/*  744 */     Assert.verify((this.sheet != null) && (this.range != null));
/*      */     
/*  746 */     if (r > this.lastRow)
/*      */     {
/*  748 */       return;
/*      */     }
/*      */     
/*  751 */     if (r <= this.firstRow)
/*      */     {
/*  753 */       this.firstRow += 1;
/*  754 */       this.modified = true;
/*      */     }
/*      */     
/*  757 */     if (r <= this.lastRow)
/*      */     {
/*  759 */       this.lastRow += 1;
/*  760 */       this.modified = true;
/*      */     }
/*      */     
/*  763 */     if (this.modified)
/*      */     {
/*  765 */       this.range = new SheetRangeImpl(this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void insertColumn(int c)
/*      */   {
/*  780 */     Assert.verify((this.sheet != null) && (this.range != null));
/*      */     
/*  782 */     if (c > this.lastColumn)
/*      */     {
/*  784 */       return;
/*      */     }
/*      */     
/*  787 */     if (c <= this.firstColumn)
/*      */     {
/*  789 */       this.firstColumn += 1;
/*  790 */       this.modified = true;
/*      */     }
/*      */     
/*  793 */     if (c <= this.lastColumn)
/*      */     {
/*  795 */       this.lastColumn += 1;
/*  796 */       this.modified = true;
/*      */     }
/*      */     
/*  799 */     if (this.modified)
/*      */     {
/*  801 */       this.range = new SheetRangeImpl(this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void removeRow(int r)
/*      */   {
/*  816 */     Assert.verify((this.sheet != null) && (this.range != null));
/*      */     
/*  818 */     if (r > this.lastRow)
/*      */     {
/*  820 */       return;
/*      */     }
/*      */     
/*  823 */     if (r < this.firstRow)
/*      */     {
/*  825 */       this.firstRow -= 1;
/*  826 */       this.modified = true;
/*      */     }
/*      */     
/*  829 */     if (r < this.lastRow)
/*      */     {
/*  831 */       this.lastRow -= 1;
/*  832 */       this.modified = true;
/*      */     }
/*      */     
/*  835 */     if (this.modified)
/*      */     {
/*  837 */       Assert.verify(this.range != null);
/*  838 */       this.range = new SheetRangeImpl(this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void removeColumn(int c)
/*      */   {
/*  853 */     Assert.verify((this.sheet != null) && (this.range != null));
/*      */     
/*  855 */     if (c > this.lastColumn)
/*      */     {
/*  857 */       return;
/*      */     }
/*      */     
/*  860 */     if (c < this.firstColumn)
/*      */     {
/*  862 */       this.firstColumn -= 1;
/*  863 */       this.modified = true;
/*      */     }
/*      */     
/*  866 */     if (c < this.lastColumn)
/*      */     {
/*  868 */       this.lastColumn -= 1;
/*  869 */       this.modified = true;
/*      */     }
/*      */     
/*  872 */     if (this.modified)
/*      */     {
/*  874 */       Assert.verify(this.range != null);
/*  875 */       this.range = new SheetRangeImpl(this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] getURLData(byte[] cd)
/*      */   {
/*  889 */     String urlString = this.url.toString();
/*      */     
/*  891 */     int dataLength = cd.length + 20 + (urlString.length() + 1) * 2;
/*      */     
/*  893 */     if (this.contents != null)
/*      */     {
/*  895 */       dataLength += 4 + (this.contents.length() + 1) * 2;
/*      */     }
/*      */     
/*  898 */     byte[] d = new byte[dataLength];
/*      */     
/*  900 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/*  902 */     int urlPos = cd.length;
/*      */     
/*  904 */     if (this.contents != null)
/*      */     {
/*  906 */       IntegerHelper.getFourBytes(this.contents.length() + 1, d, urlPos);
/*  907 */       StringHelper.getUnicodeBytes(this.contents, d, urlPos + 4);
/*  908 */       urlPos += (this.contents.length() + 1) * 2 + 4;
/*      */     }
/*      */     
/*      */ 
/*  912 */     d[urlPos] = -32;
/*  913 */     d[(urlPos + 1)] = -55;
/*  914 */     d[(urlPos + 2)] = -22;
/*  915 */     d[(urlPos + 3)] = 121;
/*  916 */     d[(urlPos + 4)] = -7;
/*  917 */     d[(urlPos + 5)] = -70;
/*  918 */     d[(urlPos + 6)] = -50;
/*  919 */     d[(urlPos + 7)] = 17;
/*  920 */     d[(urlPos + 8)] = -116;
/*  921 */     d[(urlPos + 9)] = -126;
/*  922 */     d[(urlPos + 10)] = 0;
/*  923 */     d[(urlPos + 11)] = -86;
/*  924 */     d[(urlPos + 12)] = 0;
/*  925 */     d[(urlPos + 13)] = 75;
/*  926 */     d[(urlPos + 14)] = -87;
/*  927 */     d[(urlPos + 15)] = 11;
/*      */     
/*      */ 
/*  930 */     IntegerHelper.getFourBytes((urlString.length() + 1) * 2, d, urlPos + 16);
/*      */     
/*      */ 
/*  933 */     StringHelper.getUnicodeBytes(urlString, d, urlPos + 20);
/*      */     
/*  935 */     return d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] getUNCData(byte[] cd)
/*      */   {
/*  946 */     String uncString = this.file.getPath();
/*      */     
/*  948 */     byte[] d = new byte[cd.length + uncString.length() * 2 + 2 + 4];
/*  949 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/*  951 */     int urlPos = cd.length;
/*      */     
/*      */ 
/*  954 */     int length = uncString.length() + 1;
/*  955 */     IntegerHelper.getFourBytes(length, d, urlPos);
/*      */     
/*      */ 
/*  958 */     StringHelper.getUnicodeBytes(uncString, d, urlPos + 4);
/*      */     
/*  960 */     return d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] getFileData(byte[] cd)
/*      */   {
/*  972 */     ArrayList path = new ArrayList();
/*  973 */     ArrayList shortFileName = new ArrayList();
/*  974 */     path.add(this.file.getName());
/*  975 */     shortFileName.add(getShortName(this.file.getName()));
/*      */     
/*  977 */     File parent = this.file.getParentFile();
/*  978 */     while (parent != null)
/*      */     {
/*  980 */       path.add(parent.getName());
/*  981 */       shortFileName.add(getShortName(parent.getName()));
/*  982 */       parent = parent.getParentFile();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  987 */     int upLevelCount = 0;
/*  988 */     int pos = path.size() - 1;
/*  989 */     boolean upDir = true;
/*      */     
/*  991 */     while (upDir)
/*      */     {
/*  993 */       String s = (String)path.get(pos);
/*  994 */       if (s.equals(".."))
/*      */       {
/*  996 */         upLevelCount++;
/*  997 */         path.remove(pos);
/*  998 */         shortFileName.remove(pos);
/*      */       }
/*      */       else
/*      */       {
/* 1002 */         upDir = false;
/*      */       }
/*      */       
/* 1005 */       pos--;
/*      */     }
/*      */     
/* 1008 */     StringBuffer filePathSB = new StringBuffer();
/* 1009 */     StringBuffer shortFilePathSB = new StringBuffer();
/*      */     
/* 1011 */     if (this.file.getPath().charAt(1) == ':')
/*      */     {
/* 1013 */       char driveLetter = this.file.getPath().charAt(0);
/* 1014 */       if ((driveLetter != 'C') && (driveLetter != 'c'))
/*      */       {
/* 1016 */         filePathSB.append(driveLetter);
/* 1017 */         filePathSB.append(':');
/* 1018 */         shortFilePathSB.append(driveLetter);
/* 1019 */         shortFilePathSB.append(':');
/*      */       }
/*      */     }
/*      */     
/* 1023 */     for (int i = path.size() - 1; i >= 0; i--)
/*      */     {
/* 1025 */       filePathSB.append((String)path.get(i));
/* 1026 */       shortFilePathSB.append((String)shortFileName.get(i));
/*      */       
/* 1028 */       if (i != 0)
/*      */       {
/* 1030 */         filePathSB.append("\\");
/* 1031 */         shortFilePathSB.append("\\");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1036 */     String filePath = filePathSB.toString();
/* 1037 */     String shortFilePath = shortFilePathSB.toString();
/*      */     
/* 1039 */     int dataLength = cd.length + 4 + (shortFilePath.length() + 1) + 16 + 2 + 8 + (filePath.length() + 1) * 2 + 24;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1047 */     if (this.contents != null)
/*      */     {
/* 1049 */       dataLength += 4 + (this.contents.length() + 1) * 2;
/*      */     }
/*      */     
/*      */ 
/* 1053 */     byte[] d = new byte[dataLength];
/*      */     
/* 1055 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/* 1057 */     int filePos = cd.length;
/*      */     
/*      */ 
/* 1060 */     if (this.contents != null)
/*      */     {
/* 1062 */       IntegerHelper.getFourBytes(this.contents.length() + 1, d, filePos);
/* 1063 */       StringHelper.getUnicodeBytes(this.contents, d, filePos + 4);
/* 1064 */       filePos += (this.contents.length() + 1) * 2 + 4;
/*      */     }
/*      */     
/* 1067 */     int curPos = filePos;
/*      */     
/*      */ 
/* 1070 */     d[curPos] = 3;
/* 1071 */     d[(curPos + 1)] = 3;
/* 1072 */     d[(curPos + 2)] = 0;
/* 1073 */     d[(curPos + 3)] = 0;
/* 1074 */     d[(curPos + 4)] = 0;
/* 1075 */     d[(curPos + 5)] = 0;
/* 1076 */     d[(curPos + 6)] = 0;
/* 1077 */     d[(curPos + 7)] = 0;
/* 1078 */     d[(curPos + 8)] = -64;
/* 1079 */     d[(curPos + 9)] = 0;
/* 1080 */     d[(curPos + 10)] = 0;
/* 1081 */     d[(curPos + 11)] = 0;
/* 1082 */     d[(curPos + 12)] = 0;
/* 1083 */     d[(curPos + 13)] = 0;
/* 1084 */     d[(curPos + 14)] = 0;
/* 1085 */     d[(curPos + 15)] = 70;
/*      */     
/* 1087 */     curPos += 16;
/*      */     
/*      */ 
/* 1090 */     IntegerHelper.getTwoBytes(upLevelCount, d, curPos);
/* 1091 */     curPos += 2;
/*      */     
/*      */ 
/* 1094 */     IntegerHelper.getFourBytes(shortFilePath.length() + 1, d, curPos);
/*      */     
/*      */ 
/* 1097 */     StringHelper.getBytes(shortFilePath, d, curPos + 4);
/*      */     
/* 1099 */     curPos += 4 + (shortFilePath.length() + 1);
/*      */     
/*      */ 
/* 1102 */     d[curPos] = -1;
/* 1103 */     d[(curPos + 1)] = -1;
/* 1104 */     d[(curPos + 2)] = -83;
/* 1105 */     d[(curPos + 3)] = -34;
/* 1106 */     d[(curPos + 4)] = 0;
/* 1107 */     d[(curPos + 5)] = 0;
/* 1108 */     d[(curPos + 6)] = 0;
/* 1109 */     d[(curPos + 7)] = 0;
/* 1110 */     d[(curPos + 8)] = 0;
/* 1111 */     d[(curPos + 9)] = 0;
/* 1112 */     d[(curPos + 10)] = 0;
/* 1113 */     d[(curPos + 11)] = 0;
/* 1114 */     d[(curPos + 12)] = 0;
/* 1115 */     d[(curPos + 13)] = 0;
/* 1116 */     d[(curPos + 14)] = 0;
/* 1117 */     d[(curPos + 15)] = 0;
/* 1118 */     d[(curPos + 16)] = 0;
/* 1119 */     d[(curPos + 17)] = 0;
/* 1120 */     d[(curPos + 18)] = 0;
/* 1121 */     d[(curPos + 19)] = 0;
/* 1122 */     d[(curPos + 20)] = 0;
/* 1123 */     d[(curPos + 21)] = 0;
/* 1124 */     d[(curPos + 22)] = 0;
/* 1125 */     d[(curPos + 23)] = 0;
/*      */     
/* 1127 */     curPos += 24;
/*      */     
/*      */ 
/*      */ 
/* 1131 */     int size = 6 + filePath.length() * 2;
/* 1132 */     IntegerHelper.getFourBytes(size, d, curPos);
/* 1133 */     curPos += 4;
/*      */     
/*      */ 
/*      */ 
/* 1137 */     IntegerHelper.getFourBytes(filePath.length() * 2, d, curPos);
/* 1138 */     curPos += 4;
/*      */     
/*      */ 
/* 1141 */     d[curPos] = 3;
/* 1142 */     d[(curPos + 1)] = 0;
/*      */     
/* 1144 */     curPos += 2;
/*      */     
/*      */ 
/* 1147 */     StringHelper.getUnicodeBytes(filePath, d, curPos);
/* 1148 */     curPos += (filePath.length() + 1) * 2;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1168 */     return d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getShortName(String s)
/*      */   {
/* 1179 */     int sep = s.indexOf('.');
/*      */     
/* 1181 */     String prefix = null;
/* 1182 */     String suffix = null;
/*      */     
/* 1184 */     if (sep == -1)
/*      */     {
/* 1186 */       prefix = s;
/* 1187 */       suffix = "";
/*      */     }
/*      */     else
/*      */     {
/* 1191 */       prefix = s.substring(0, sep);
/* 1192 */       suffix = s.substring(sep + 1);
/*      */     }
/*      */     
/* 1195 */     if (prefix.length() > 8)
/*      */     {
/* 1197 */       prefix = prefix.substring(0, 6) + "~" + (prefix.length() - 8);
/* 1198 */       prefix = prefix.substring(0, 8);
/*      */     }
/*      */     
/* 1201 */     suffix = suffix.substring(0, Math.min(3, suffix.length()));
/*      */     
/* 1203 */     if (suffix.length() > 0)
/*      */     {
/* 1205 */       return prefix + '.' + suffix;
/*      */     }
/*      */     
/*      */ 
/* 1209 */     return prefix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] getLocationData(byte[] cd)
/*      */   {
/* 1221 */     byte[] d = new byte[cd.length + 4 + (this.location.length() + 1) * 2];
/* 1222 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/* 1224 */     int locPos = cd.length;
/*      */     
/*      */ 
/* 1227 */     IntegerHelper.getFourBytes(this.location.length() + 1, d, locPos);
/*      */     
/*      */ 
/* 1230 */     StringHelper.getUnicodeBytes(this.location, d, locPos + 4);
/*      */     
/* 1232 */     return d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initialize(WritableSheet s)
/*      */   {
/* 1243 */     this.sheet = s;
/* 1244 */     this.range = new SheetRangeImpl(s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getContents()
/*      */   {
/* 1257 */     return this.contents;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setContents(String desc)
/*      */   {
/* 1267 */     this.contents = desc;
/* 1268 */     this.modified = true;
/*      */   }
/*      */   
/*      */   private static class LinkType {}
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\HyperlinkRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */