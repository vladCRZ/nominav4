/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndexRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private int rows;
/*     */   private int bofPosition;
/*     */   private int blocks;
/*     */   private int dataPos;
/*     */   
/*     */   public IndexRecord(int pos, int r, int bl)
/*     */   {
/*  62 */     super(Type.INDEX);
/*  63 */     this.bofPosition = pos;
/*  64 */     this.rows = r;
/*  65 */     this.blocks = bl;
/*     */     
/*     */ 
/*  68 */     this.data = new byte[16 + 4 * this.blocks];
/*  69 */     this.dataPos = 16;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] getData()
/*     */   {
/*  81 */     IntegerHelper.getFourBytes(this.rows, this.data, 8);
/*  82 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addBlockPosition(int pos)
/*     */   {
/*  92 */     IntegerHelper.getFourBytes(pos - this.bofPosition, this.data, this.dataPos);
/*  93 */     this.dataPos += 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setDataStartPosition(int pos)
/*     */   {
/* 102 */     IntegerHelper.getFourBytes(pos - this.bofPosition, this.data, 12);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\IndexRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */