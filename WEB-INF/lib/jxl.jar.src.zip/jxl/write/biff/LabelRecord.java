/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LabelRecord
/*     */   extends CellValue
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(LabelRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String contents;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SharedStrings sharedStrings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int index;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LabelRecord(int c, int r, String cont)
/*     */   {
/*  66 */     super(Type.LABELSST, c, r);
/*  67 */     this.contents = cont;
/*  68 */     if (this.contents == null)
/*     */     {
/*  70 */       this.contents = "";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LabelRecord(int c, int r, String cont, CellFormat st)
/*     */   {
/*  85 */     super(Type.LABELSST, c, r, st);
/*  86 */     this.contents = cont;
/*     */     
/*  88 */     if (this.contents == null)
/*     */     {
/*  90 */       this.contents = "";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LabelRecord(int c, int r, LabelRecord lr)
/*     */   {
/* 104 */     super(Type.LABELSST, c, r, lr);
/* 105 */     this.contents = lr.contents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LabelRecord(LabelCell lc)
/*     */   {
/* 116 */     super(Type.LABELSST, lc);
/* 117 */     this.contents = lc.getString();
/* 118 */     if (this.contents == null)
/*     */     {
/* 120 */       this.contents = "";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 131 */     return CellType.LABEL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 141 */     byte[] celldata = super.getData();
/* 142 */     byte[] data = new byte[celldata.length + 4];
/* 143 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 144 */     IntegerHelper.getFourBytes(this.index, data, celldata.length);
/*     */     
/* 146 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 158 */     return this.contents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/* 169 */     return this.contents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setString(String s)
/*     */   {
/* 179 */     if (s == null)
/*     */     {
/* 181 */       s = "";
/*     */     }
/*     */     
/* 184 */     this.contents = s;
/*     */     
/*     */ 
/*     */ 
/* 188 */     if (!isReferenced())
/*     */     {
/* 190 */       return;
/*     */     }
/*     */     
/* 193 */     Assert.verify(this.sharedStrings != null);
/*     */     
/*     */ 
/* 196 */     this.index = this.sharedStrings.getIndex(this.contents);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 201 */     this.contents = this.sharedStrings.get(this.index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s)
/*     */   {
/* 216 */     super.setCellDetails(fr, ss, s);
/*     */     
/* 218 */     this.sharedStrings = ss;
/*     */     
/* 220 */     this.index = this.sharedStrings.getIndex(this.contents);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 225 */     this.contents = this.sharedStrings.get(this.index);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\LabelRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */