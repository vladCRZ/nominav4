/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MMSRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte numMenuItemsAdded;
/*    */   private byte numMenuItemsDeleted;
/*    */   private byte[] data;
/*    */   
/*    */   public MMSRecord(int menuItemsAdded, int menuItemsDeleted)
/*    */   {
/* 51 */     super(Type.MMS);
/*    */     
/* 53 */     this.numMenuItemsAdded = ((byte)menuItemsAdded);
/* 54 */     this.numMenuItemsDeleted = ((byte)menuItemsDeleted);
/*    */     
/* 56 */     this.data = new byte[2];
/*    */     
/* 58 */     this.data[0] = this.numMenuItemsAdded;
/* 59 */     this.data[1] = this.numMenuItemsDeleted;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 69 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\MMSRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */