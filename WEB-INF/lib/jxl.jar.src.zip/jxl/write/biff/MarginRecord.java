/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.DoubleHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MarginRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private double margin;
/*    */   
/*    */   public MarginRecord(Type t, double v)
/*    */   {
/* 41 */     super(t);
/* 42 */     this.margin = v;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 51 */     byte[] data = new byte[8];
/*    */     
/* 53 */     DoubleHelper.getIEEEBytes(this.margin, data, 0);
/*    */     
/* 55 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\MarginRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */