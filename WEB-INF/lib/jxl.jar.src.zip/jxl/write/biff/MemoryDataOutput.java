/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MemoryDataOutput
/*     */   implements ExcelDataOutput
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(MemoryDataOutput.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int growSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MemoryDataOutput(int initialSize, int gs)
/*     */   {
/*  56 */     this.data = new byte[initialSize];
/*  57 */     this.growSize = gs;
/*  58 */     this.pos = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] bytes)
/*     */   {
/*  69 */     while (this.pos + bytes.length > this.data.length)
/*     */     {
/*     */ 
/*  72 */       byte[] newdata = new byte[this.data.length + this.growSize];
/*  73 */       System.arraycopy(this.data, 0, newdata, 0, this.pos);
/*  74 */       this.data = newdata;
/*     */     }
/*     */     
/*  77 */     System.arraycopy(bytes, 0, this.data, this.pos, bytes.length);
/*  78 */     this.pos += bytes.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPosition()
/*     */   {
/*  88 */     return this.pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(byte[] newdata, int pos)
/*     */   {
/*  99 */     System.arraycopy(newdata, 0, this.data, pos, newdata.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeData(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 107 */     out.write(this.data, 0, this.pos);
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\MemoryDataOutput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */