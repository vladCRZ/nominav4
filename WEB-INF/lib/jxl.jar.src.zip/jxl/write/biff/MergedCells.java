/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.Range;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.SheetRangeImpl;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.Blank;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MergedCells
/*     */ {
/*  47 */   private static Logger logger = Logger.getLogger(MergedCells.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList ranges;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableSheet sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int maxRangesPerSheet = 1020;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MergedCells(WritableSheet ws)
/*     */   {
/*  69 */     this.ranges = new ArrayList();
/*  70 */     this.sheet = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void add(Range r)
/*     */   {
/*  81 */     this.ranges.add(r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void insertRow(int row)
/*     */   {
/*  90 */     SheetRangeImpl sr = null;
/*  91 */     Iterator i = this.ranges.iterator();
/*  92 */     while (i.hasNext())
/*     */     {
/*  94 */       sr = (SheetRangeImpl)i.next();
/*  95 */       sr.insertRow(row);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void insertColumn(int col)
/*     */   {
/* 104 */     SheetRangeImpl sr = null;
/* 105 */     Iterator i = this.ranges.iterator();
/* 106 */     while (i.hasNext())
/*     */     {
/* 108 */       sr = (SheetRangeImpl)i.next();
/* 109 */       sr.insertColumn(col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void removeColumn(int col)
/*     */   {
/* 118 */     SheetRangeImpl sr = null;
/* 119 */     Iterator i = this.ranges.iterator();
/* 120 */     while (i.hasNext())
/*     */     {
/* 122 */       sr = (SheetRangeImpl)i.next();
/* 123 */       if ((sr.getTopLeft().getColumn() == col) && (sr.getBottomRight().getColumn() == col))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 128 */         i.remove();
/*     */       }
/*     */       else
/*     */       {
/* 132 */         sr.removeColumn(col);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void removeRow(int row)
/*     */   {
/* 142 */     SheetRangeImpl sr = null;
/* 143 */     Iterator i = this.ranges.iterator();
/* 144 */     while (i.hasNext())
/*     */     {
/* 146 */       sr = (SheetRangeImpl)i.next();
/* 147 */       if ((sr.getTopLeft().getRow() == row) && (sr.getBottomRight().getRow() == row))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 152 */         i.remove();
/*     */       }
/*     */       else
/*     */       {
/* 156 */         sr.removeRow(row);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Range[] getMergedCells()
/*     */   {
/* 168 */     Range[] cells = new Range[this.ranges.size()];
/*     */     
/* 170 */     for (int i = 0; i < cells.length; i++)
/*     */     {
/* 172 */       cells[i] = ((Range)this.ranges.get(i));
/*     */     }
/*     */     
/* 175 */     return cells;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void unmergeCells(Range r)
/*     */   {
/* 186 */     int index = this.ranges.indexOf(r);
/*     */     
/* 188 */     if (index != -1)
/*     */     {
/* 190 */       this.ranges.remove(index);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkIntersections()
/*     */   {
/* 199 */     ArrayList newcells = new ArrayList(this.ranges.size());
/*     */     
/* 201 */     for (Iterator mci = this.ranges.iterator(); mci.hasNext();)
/*     */     {
/* 203 */       SheetRangeImpl r = (SheetRangeImpl)mci.next();
/*     */       
/*     */ 
/* 206 */       Iterator i = newcells.iterator();
/* 207 */       SheetRangeImpl range = null;
/* 208 */       boolean intersects = false;
/* 209 */       while ((i.hasNext()) && (!intersects))
/*     */       {
/* 211 */         range = (SheetRangeImpl)i.next();
/*     */         
/* 213 */         if (range.intersects(r))
/*     */         {
/* 215 */           logger.warn("Could not merge cells " + r + " as they clash with an existing set of merged cells.");
/*     */           
/*     */ 
/* 218 */           intersects = true;
/*     */         }
/*     */       }
/*     */       
/* 222 */       if (!intersects)
/*     */       {
/* 224 */         newcells.add(r);
/*     */       }
/*     */     }
/*     */     
/* 228 */     this.ranges = newcells;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkRanges()
/*     */   {
/*     */     try
/*     */     {
/* 239 */       SheetRangeImpl range = null;
/*     */       
/*     */ 
/* 242 */       for (int i = 0; i < this.ranges.size(); i++)
/*     */       {
/* 244 */         range = (SheetRangeImpl)this.ranges.get(i);
/*     */         
/*     */ 
/* 247 */         Cell tl = range.getTopLeft();
/* 248 */         Cell br = range.getBottomRight();
/* 249 */         boolean found = false;
/*     */         
/* 251 */         for (int c = tl.getColumn(); c <= br.getColumn(); c++)
/*     */         {
/* 253 */           for (int r = tl.getRow(); r <= br.getRow(); r++)
/*     */           {
/* 255 */             Cell cell = this.sheet.getCell(c, r);
/* 256 */             if (cell.getType() != CellType.EMPTY)
/*     */             {
/* 258 */               if (!found)
/*     */               {
/* 260 */                 found = true;
/*     */               }
/*     */               else
/*     */               {
/* 264 */                 logger.warn("Range " + range + " contains more than one data cell.  " + "Setting the other cells to blank.");
/*     */                 
/*     */ 
/* 267 */                 Blank b = new Blank(c, r);
/* 268 */                 this.sheet.addCell(b);
/*     */               }
/*     */               
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (WriteException e)
/*     */     {
/* 278 */       Assert.verify(false);
/*     */     }
/*     */   }
/*     */   
/*     */   void write(File outputFile) throws IOException
/*     */   {
/* 284 */     if (this.ranges.size() == 0)
/*     */     {
/* 286 */       return;
/*     */     }
/*     */     
/* 289 */     WorkbookSettings ws = ((WritableSheetImpl)this.sheet).getWorkbookSettings();
/*     */     
/*     */ 
/* 292 */     if (!ws.getMergedCellCheckingDisabled())
/*     */     {
/* 294 */       checkIntersections();
/* 295 */       checkRanges();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 300 */     if (this.ranges.size() < 1020)
/*     */     {
/* 302 */       MergedCellsRecord mcr = new MergedCellsRecord(this.ranges);
/* 303 */       outputFile.write(mcr);
/* 304 */       return;
/*     */     }
/*     */     
/* 307 */     int numRecordsRequired = this.ranges.size() / 1020 + 1;
/* 308 */     int pos = 0;
/*     */     
/* 310 */     for (int i = 0; i < numRecordsRequired; i++)
/*     */     {
/* 312 */       int numranges = Math.min(1020, this.ranges.size() - pos);
/*     */       
/* 314 */       ArrayList cells = new ArrayList(numranges);
/* 315 */       for (int j = 0; j < numranges; j++)
/*     */       {
/* 317 */         cells.add(this.ranges.get(pos + j));
/*     */       }
/*     */       
/* 320 */       MergedCellsRecord mcr = new MergedCellsRecord(cells);
/* 321 */       outputFile.write(mcr);
/*     */       
/* 323 */       pos += numranges;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\MergedCells.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */