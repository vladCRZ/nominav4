/*    */ package jxl.write.biff;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import jxl.Cell;
/*    */ import jxl.Range;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergedCellsRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private ArrayList ranges;
/*    */   
/*    */   protected MergedCellsRecord(ArrayList mc)
/*    */   {
/* 48 */     super(Type.MERGEDCELLS);
/*    */     
/* 50 */     this.ranges = mc;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 60 */     byte[] data = new byte[this.ranges.size() * 8 + 2];
/*    */     
/*    */ 
/* 63 */     IntegerHelper.getTwoBytes(this.ranges.size(), data, 0);
/*    */     
/* 65 */     int pos = 2;
/* 66 */     Range range = null;
/* 67 */     for (int i = 0; i < this.ranges.size(); i++)
/*    */     {
/* 69 */       range = (Range)this.ranges.get(i);
/*    */       
/*    */ 
/* 72 */       Cell tl = range.getTopLeft();
/* 73 */       Cell br = range.getBottomRight();
/*    */       
/* 75 */       IntegerHelper.getTwoBytes(tl.getRow(), data, pos);
/* 76 */       IntegerHelper.getTwoBytes(br.getRow(), data, pos + 2);
/* 77 */       IntegerHelper.getTwoBytes(tl.getColumn(), data, pos + 4);
/* 78 */       IntegerHelper.getTwoBytes(br.getColumn(), data, pos + 6);
/*    */       
/* 80 */       pos += 8;
/*    */     }
/*    */     
/* 83 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\MergedCellsRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */