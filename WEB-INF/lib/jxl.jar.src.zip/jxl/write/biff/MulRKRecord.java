/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.List;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.write.Number;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MulRKRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private int row;
/*     */   private int colFirst;
/*     */   private int colLast;
/*     */   private int[] rknumbers;
/*     */   private int[] xfIndices;
/*     */   
/*     */   public MulRKRecord(List numbers)
/*     */   {
/*  62 */     super(Type.MULRK);
/*  63 */     this.row = ((Number)numbers.get(0)).getRow();
/*  64 */     this.colFirst = ((Number)numbers.get(0)).getColumn();
/*  65 */     this.colLast = (this.colFirst + numbers.size() - 1);
/*     */     
/*  67 */     this.rknumbers = new int[numbers.size()];
/*  68 */     this.xfIndices = new int[numbers.size()];
/*     */     
/*  70 */     for (int i = 0; i < numbers.size(); i++)
/*     */     {
/*  72 */       this.rknumbers[i] = ((int)((Number)numbers.get(i)).getValue());
/*  73 */       this.xfIndices[i] = ((CellValue)numbers.get(i)).getXFIndex();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  84 */     byte[] data = new byte[this.rknumbers.length * 6 + 6];
/*     */     
/*     */ 
/*  87 */     IntegerHelper.getTwoBytes(this.row, data, 0);
/*  88 */     IntegerHelper.getTwoBytes(this.colFirst, data, 2);
/*     */     
/*     */ 
/*  91 */     int pos = 4;
/*  92 */     int rkValue = 0;
/*  93 */     byte[] rkBytes = new byte[4];
/*  94 */     for (int i = 0; i < this.rknumbers.length; i++)
/*     */     {
/*  96 */       IntegerHelper.getTwoBytes(this.xfIndices[i], data, pos);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */       rkValue = this.rknumbers[i] << 2;
/*     */       
/*     */ 
/* 105 */       rkValue |= 0x2;
/* 106 */       IntegerHelper.getFourBytes(rkValue, data, pos + 2);
/*     */       
/* 108 */       pos += 6;
/*     */     }
/*     */     
/*     */ 
/* 112 */     IntegerHelper.getTwoBytes(this.colLast, data, pos);
/*     */     
/* 114 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\MulRKRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */