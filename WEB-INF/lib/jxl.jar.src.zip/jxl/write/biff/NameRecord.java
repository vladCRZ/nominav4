/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.BuiltInName;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NameRecord
/*     */   extends WritableRecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(NameRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private BuiltInName builtInName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int index;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private int sheetRef = 0;
/*     */   
/*     */   private boolean modified;
/*     */   
/*     */   private NameRange[] ranges;
/*     */   private static final int cellReference = 58;
/*     */   private static final int areaReference = 59;
/*     */   private static final int subExpression = 41;
/*     */   private static final int union = 16;
/*     */   
/*     */   static class NameRange
/*     */   {
/*     */     private int columnFirst;
/*     */     private int rowFirst;
/*     */     private int columnLast;
/*     */     private int rowLast;
/*     */     private int externalSheet;
/*     */     
/*     */     NameRange(jxl.read.biff.NameRecord.NameRange nr)
/*     */     {
/*  82 */       this.columnFirst = nr.getFirstColumn();
/*  83 */       this.rowFirst = nr.getFirstRow();
/*  84 */       this.columnLast = nr.getLastColumn();
/*  85 */       this.rowLast = nr.getLastRow();
/*  86 */       this.externalSheet = nr.getExternalSheet();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     NameRange(int extSheet, int theStartRow, int theEndRow, int theStartCol, int theEndCol)
/*     */     {
/*  98 */       this.columnFirst = theStartCol;
/*  99 */       this.rowFirst = theStartRow;
/* 100 */       this.columnLast = theEndCol;
/* 101 */       this.rowLast = theEndRow;
/* 102 */       this.externalSheet = extSheet;
/*     */     }
/*     */     
/* 105 */     int getFirstColumn() { return this.columnFirst; }
/* 106 */     int getFirstRow() { return this.rowFirst; }
/* 107 */     int getLastColumn() { return this.columnLast; }
/* 108 */     int getLastRow() { return this.rowLast; }
/* 109 */     int getExternalSheet() { return this.externalSheet; }
/*     */     
/* 111 */     void incrementFirstRow() { this.rowFirst += 1; }
/* 112 */     void incrementLastRow() { this.rowLast += 1; }
/* 113 */     void decrementFirstRow() { this.rowFirst -= 1; }
/* 114 */     void decrementLastRow() { this.rowLast -= 1; }
/* 115 */     void incrementFirstColumn() { this.columnFirst += 1; }
/* 116 */     void incrementLastColumn() { this.columnLast += 1; }
/* 117 */     void decrementFirstColumn() { this.columnFirst -= 1; }
/* 118 */     void decrementLastColumn() { this.columnLast -= 1; }
/*     */     
/*     */     byte[] getData()
/*     */     {
/* 122 */       byte[] d = new byte[10];
/*     */       
/*     */ 
/* 125 */       IntegerHelper.getTwoBytes(this.externalSheet, d, 0);
/*     */       
/*     */ 
/* 128 */       IntegerHelper.getTwoBytes(this.rowFirst, d, 2);
/*     */       
/*     */ 
/* 131 */       IntegerHelper.getTwoBytes(this.rowLast, d, 4);
/*     */       
/*     */ 
/* 134 */       IntegerHelper.getTwoBytes(this.columnFirst & 0xFF, d, 6);
/*     */       
/*     */ 
/* 137 */       IntegerHelper.getTwoBytes(this.columnLast & 0xFF, d, 8);
/*     */       
/* 139 */       return d;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */   private static final NameRange EMPTY_RANGE = new NameRange(0, 0, 0, 0, 0);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRecord(jxl.read.biff.NameRecord sr, int ind)
/*     */   {
/* 164 */     super(Type.NAME);
/*     */     
/* 166 */     this.data = sr.getData();
/* 167 */     this.name = sr.getName();
/* 168 */     this.sheetRef = sr.getSheetRef();
/* 169 */     this.index = ind;
/* 170 */     this.modified = false;
/*     */     
/*     */ 
/* 173 */     jxl.read.biff.NameRecord.NameRange[] r = sr.getRanges();
/* 174 */     this.ranges = new NameRange[r.length];
/* 175 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 177 */       this.ranges[i] = new NameRange(r[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NameRecord(String theName, int theIndex, int extSheet, int theStartRow, int theEndRow, int theStartCol, int theEndCol, boolean global)
/*     */   {
/* 202 */     super(Type.NAME);
/*     */     
/* 204 */     this.name = theName;
/* 205 */     this.index = theIndex;
/* 206 */     this.sheetRef = (global ? 0 : this.index + 1);
/*     */     
/*     */ 
/* 209 */     this.ranges = new NameRange[1];
/* 210 */     this.ranges[0] = new NameRange(extSheet, theStartRow, theEndRow, theStartCol, theEndCol);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 215 */     this.modified = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NameRecord(BuiltInName theName, int theIndex, int extSheet, int theStartRow, int theEndRow, int theStartCol, int theEndCol, boolean global)
/*     */   {
/* 239 */     super(Type.NAME);
/*     */     
/* 241 */     this.builtInName = theName;
/* 242 */     this.index = theIndex;
/* 243 */     this.sheetRef = (global ? 0 : this.index + 1);
/*     */     
/*     */ 
/* 246 */     this.ranges = new NameRange[1];
/* 247 */     this.ranges[0] = new NameRange(extSheet, theStartRow, theEndRow, theStartCol, theEndCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NameRecord(BuiltInName theName, int theIndex, int extSheet, int theStartRow, int theEndRow, int theStartCol, int theEndCol, int theStartRow2, int theEndRow2, int theStartCol2, int theEndCol2, boolean global)
/*     */   {
/* 283 */     super(Type.NAME);
/*     */     
/* 285 */     this.builtInName = theName;
/* 286 */     this.index = theIndex;
/* 287 */     this.sheetRef = (global ? 0 : this.index + 1);
/*     */     
/*     */ 
/* 290 */     this.ranges = new NameRange[2];
/* 291 */     this.ranges[0] = new NameRange(extSheet, theStartRow, theEndRow, theStartCol, theEndCol);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 296 */     this.ranges[1] = new NameRange(extSheet, theStartRow2, theEndRow2, theStartCol2, theEndCol2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 311 */     if ((this.data != null) && (!this.modified))
/*     */     {
/*     */ 
/* 314 */       return this.data;
/*     */     }
/*     */     
/* 317 */     int NAME_HEADER_LENGTH = 15;
/* 318 */     byte AREA_RANGE_LENGTH = 11;
/* 319 */     byte AREA_REFERENCE = 59;
/*     */     
/*     */     int detailLength;
/*     */     int detailLength;
/* 323 */     if (this.ranges.length > 1)
/*     */     {
/* 325 */       detailLength = this.ranges.length * 11 + 4;
/*     */     }
/*     */     else
/*     */     {
/* 329 */       detailLength = 11;
/*     */     }
/*     */     
/* 332 */     int length = 15 + detailLength;
/* 333 */     length += (this.builtInName != null ? 1 : this.name.length());
/* 334 */     this.data = new byte[length];
/*     */     
/*     */ 
/* 337 */     int options = 0;
/*     */     
/* 339 */     if (this.builtInName != null)
/*     */     {
/* 341 */       options |= 0x20;
/*     */     }
/* 343 */     IntegerHelper.getTwoBytes(options, this.data, 0);
/*     */     
/*     */ 
/* 346 */     this.data[2] = 0;
/*     */     
/*     */ 
/* 349 */     if (this.builtInName != null)
/*     */     {
/* 351 */       this.data[3] = 1;
/*     */     }
/*     */     else
/*     */     {
/* 355 */       this.data[3] = ((byte)this.name.length());
/*     */     }
/*     */     
/*     */ 
/* 359 */     IntegerHelper.getTwoBytes(detailLength, this.data, 4);
/*     */     
/*     */ 
/* 362 */     IntegerHelper.getTwoBytes(this.sheetRef, this.data, 6);
/* 363 */     IntegerHelper.getTwoBytes(this.sheetRef, this.data, 8);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 369 */     if (this.builtInName != null)
/*     */     {
/* 371 */       this.data[15] = ((byte)this.builtInName.getValue());
/*     */     }
/*     */     else
/*     */     {
/* 375 */       StringHelper.getBytes(this.name, this.data, 15);
/*     */     }
/*     */     
/*     */ 
/* 379 */     int pos = this.builtInName != null ? 16 : this.name.length() + 15;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 384 */     if (this.ranges.length > 1)
/*     */     {
/* 386 */       this.data[(pos++)] = 41;
/*     */       
/* 388 */       IntegerHelper.getTwoBytes(detailLength - 3, this.data, pos);
/* 389 */       pos += 2;
/*     */       
/* 391 */       for (int i = 0; i < this.ranges.length; i++)
/*     */       {
/* 393 */         this.data[(pos++)] = 59;
/* 394 */         byte[] rd = this.ranges[i].getData();
/* 395 */         System.arraycopy(rd, 0, this.data, pos, rd.length);
/* 396 */         pos += rd.length;
/*     */       }
/* 398 */       this.data[pos] = 16;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 403 */       this.data[pos] = 59;
/*     */       
/*     */ 
/* 406 */       byte[] rd = this.ranges[0].getData();
/* 407 */       System.arraycopy(rd, 0, this.data, pos + 1, rd.length);
/*     */     }
/*     */     
/* 410 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 420 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndex()
/*     */   {
/* 430 */     return this.index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSheetRef()
/*     */   {
/* 441 */     return this.sheetRef;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSheetRef(int i)
/*     */   {
/* 451 */     this.sheetRef = i;
/* 452 */     IntegerHelper.getTwoBytes(this.sheetRef, this.data, 8);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRange[] getRanges()
/*     */   {
/* 461 */     return this.ranges;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(int sheetIndex, int row)
/*     */   {
/* 472 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 474 */       if (sheetIndex == this.ranges[i].getExternalSheet())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 479 */         if (row <= this.ranges[i].getFirstRow())
/*     */         {
/* 481 */           this.ranges[i].incrementFirstRow();
/* 482 */           this.modified = true;
/*     */         }
/*     */         
/* 485 */         if (row <= this.ranges[i].getLastRow())
/*     */         {
/* 487 */           this.ranges[i].incrementLastRow();
/* 488 */           this.modified = true;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean rowRemoved(int sheetIndex, int row)
/*     */   {
/* 502 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 504 */       if (sheetIndex == this.ranges[i].getExternalSheet())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 509 */         if ((row == this.ranges[i].getFirstRow()) && (row == this.ranges[i].getLastRow()))
/*     */         {
/*     */ 
/* 512 */           this.ranges[i] = EMPTY_RANGE;
/*     */         }
/*     */         
/* 515 */         if ((row < this.ranges[i].getFirstRow()) && (row > 0))
/*     */         {
/* 517 */           this.ranges[i].decrementFirstRow();
/* 518 */           this.modified = true;
/*     */         }
/*     */         
/* 521 */         if (row <= this.ranges[i].getLastRow())
/*     */         {
/* 523 */           this.ranges[i].decrementLastRow();
/* 524 */           this.modified = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 529 */     int emptyRanges = 0;
/* 530 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 532 */       if (this.ranges[i] == EMPTY_RANGE)
/*     */       {
/* 534 */         emptyRanges++;
/*     */       }
/*     */     }
/*     */     
/* 538 */     if (emptyRanges == this.ranges.length)
/*     */     {
/* 540 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 544 */     NameRange[] newRanges = new NameRange[this.ranges.length - emptyRanges];
/* 545 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 547 */       if (this.ranges[i] != EMPTY_RANGE)
/*     */       {
/* 549 */         newRanges[i] = this.ranges[i];
/*     */       }
/*     */     }
/*     */     
/* 553 */     this.ranges = newRanges;
/*     */     
/* 555 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean columnRemoved(int sheetIndex, int col)
/*     */   {
/* 567 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 569 */       if (sheetIndex == this.ranges[i].getExternalSheet())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 574 */         if ((col == this.ranges[i].getFirstColumn()) && (col == this.ranges[i].getLastColumn()))
/*     */         {
/*     */ 
/*     */ 
/* 578 */           this.ranges[i] = EMPTY_RANGE;
/*     */         }
/*     */         
/* 581 */         if ((col < this.ranges[i].getFirstColumn()) && (col > 0))
/*     */         {
/* 583 */           this.ranges[i].decrementFirstColumn();
/* 584 */           this.modified = true;
/*     */         }
/*     */         
/* 587 */         if (col <= this.ranges[i].getLastColumn())
/*     */         {
/* 589 */           this.ranges[i].decrementLastColumn();
/* 590 */           this.modified = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 595 */     int emptyRanges = 0;
/* 596 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 598 */       if (this.ranges[i] == EMPTY_RANGE)
/*     */       {
/* 600 */         emptyRanges++;
/*     */       }
/*     */     }
/*     */     
/* 604 */     if (emptyRanges == this.ranges.length)
/*     */     {
/* 606 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 610 */     NameRange[] newRanges = new NameRange[this.ranges.length - emptyRanges];
/* 611 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 613 */       if (this.ranges[i] != EMPTY_RANGE)
/*     */       {
/* 615 */         newRanges[i] = this.ranges[i];
/*     */       }
/*     */     }
/*     */     
/* 619 */     this.ranges = newRanges;
/*     */     
/* 621 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(int sheetIndex, int col)
/*     */   {
/* 633 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 635 */       if (sheetIndex == this.ranges[i].getExternalSheet())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 640 */         if (col <= this.ranges[i].getFirstColumn())
/*     */         {
/* 642 */           this.ranges[i].incrementFirstColumn();
/* 643 */           this.modified = true;
/*     */         }
/*     */         
/* 646 */         if (col <= this.ranges[i].getLastColumn())
/*     */         {
/* 648 */           this.ranges[i].incrementLastColumn();
/* 649 */           this.modified = true;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\NameRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */