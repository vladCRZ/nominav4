/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NineteenFourRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean nineteenFourDate;
/*    */   private byte[] data;
/*    */   
/*    */   public NineteenFourRecord(boolean oldDate)
/*    */   {
/* 49 */     super(Type.NINETEENFOUR);
/*    */     
/* 51 */     this.nineteenFourDate = oldDate;
/* 52 */     this.data = new byte[2];
/*    */     
/* 54 */     if (this.nineteenFourDate)
/*    */     {
/* 56 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 66 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\NineteenFourRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */