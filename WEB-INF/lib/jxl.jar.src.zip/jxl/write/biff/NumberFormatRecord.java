/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.FormatRecord;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberFormatRecord
/*     */   extends FormatRecord
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(NumberFormatRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NumberFormatRecord(String fmt)
/*     */   {
/*  51 */     String fs = fmt;
/*     */     
/*  53 */     fs = replace(fs, "E0", "E+0");
/*     */     
/*  55 */     fs = trimInvalidChars(fs);
/*     */     
/*  57 */     setFormatString(fs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NumberFormatRecord(String fmt, NonValidatingFormat dummy)
/*     */   {
/*  71 */     String fs = fmt;
/*     */     
/*  73 */     fs = replace(fs, "E0", "E+0");
/*     */     
/*  75 */     setFormatString(fs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String trimInvalidChars(String fs)
/*     */   {
/*  87 */     int firstHash = fs.indexOf('#');
/*  88 */     int firstZero = fs.indexOf('0');
/*  89 */     int firstValidChar = 0;
/*     */     
/*  91 */     if ((firstHash == -1) && (firstZero == -1))
/*     */     {
/*     */ 
/*  94 */       return "#.###";
/*     */     }
/*     */     
/*  97 */     if ((firstHash != 0) && (firstZero != 0) && (firstHash != 1) && (firstZero != 1))
/*     */     {
/*     */ 
/*     */ 
/* 101 */       firstHash = firstHash == -1 ? (firstHash = Integer.MAX_VALUE) : firstHash;
/* 102 */       firstZero = firstZero == -1 ? (firstZero = Integer.MAX_VALUE) : firstZero;
/* 103 */       firstValidChar = Math.min(firstHash, firstZero);
/*     */       
/* 105 */       StringBuffer tmp = new StringBuffer();
/* 106 */       tmp.append(fs.charAt(0));
/* 107 */       tmp.append(fs.substring(firstValidChar));
/* 108 */       fs = tmp.toString();
/*     */     }
/*     */     
/*     */ 
/* 112 */     int lastHash = fs.lastIndexOf('#');
/* 113 */     int lastZero = fs.lastIndexOf('0');
/*     */     
/* 115 */     if ((lastHash == fs.length()) || (lastZero == fs.length()))
/*     */     {
/*     */ 
/* 118 */       return fs;
/*     */     }
/*     */     
/*     */ 
/* 122 */     int lastValidChar = Math.max(lastHash, lastZero);
/*     */     
/*     */ 
/* 125 */     while ((fs.length() > lastValidChar + 1) && ((fs.charAt(lastValidChar + 1) == ')') || (fs.charAt(lastValidChar + 1) == '%')))
/*     */     {
/*     */ 
/*     */ 
/* 129 */       lastValidChar++;
/*     */     }
/*     */     
/* 132 */     return fs.substring(0, lastValidChar + 1);
/*     */   }
/*     */   
/*     */   protected static class NonValidatingFormat {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\NumberFormatRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */