/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NumberRecord
/*     */   extends CellValue
/*     */ {
/*     */   private double value;
/*     */   private NumberFormat format;
/*  51 */   private static DecimalFormat defaultFormat = new DecimalFormat("#.###");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NumberRecord(int c, int r, double val)
/*     */   {
/*  62 */     super(Type.NUMBER, c, r);
/*  63 */     this.value = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NumberRecord(int c, int r, double val, CellFormat st)
/*     */   {
/*  77 */     super(Type.NUMBER, c, r, st);
/*  78 */     this.value = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NumberRecord(NumberCell nc)
/*     */   {
/*  88 */     super(Type.NUMBER, nc);
/*  89 */     this.value = nc.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NumberRecord(int c, int r, NumberRecord nr)
/*     */   {
/* 101 */     super(Type.NUMBER, c, r, nr);
/* 102 */     this.value = nr.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 112 */     return CellType.NUMBER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 122 */     byte[] celldata = super.getData();
/* 123 */     byte[] data = new byte[celldata.length + 8];
/* 124 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 125 */     DoubleHelper.getIEEEBytes(this.value, data, celldata.length);
/*     */     
/* 127 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 139 */     if (this.format == null)
/*     */     {
/* 141 */       this.format = ((XFRecord)getCellFormat()).getNumberFormat();
/* 142 */       if (this.format == null)
/*     */       {
/* 144 */         this.format = defaultFormat;
/*     */       }
/*     */     }
/* 147 */     return this.format.format(this.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 157 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(double val)
/*     */   {
/* 167 */     this.value = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumberFormat getNumberFormat()
/*     */   {
/* 178 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\NumberRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */