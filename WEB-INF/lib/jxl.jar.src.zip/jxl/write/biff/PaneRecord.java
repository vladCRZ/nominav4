/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PaneRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private int rowsVisible;
/*     */   private int columnsVisible;
/*     */   private static final int topLeftPane = 3;
/*     */   private static final int bottomLeftPane = 2;
/*     */   private static final int topRightPane = 1;
/*     */   private static final int bottomRightPane = 0;
/*     */   
/*     */   public PaneRecord(int cols, int rows)
/*     */   {
/*  56 */     super(Type.PANE);
/*     */     
/*  58 */     this.rowsVisible = rows;
/*  59 */     this.columnsVisible = cols;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  69 */     byte[] data = new byte[10];
/*     */     
/*     */ 
/*  72 */     IntegerHelper.getTwoBytes(this.columnsVisible, data, 0);
/*     */     
/*     */ 
/*  75 */     IntegerHelper.getTwoBytes(this.rowsVisible, data, 2);
/*     */     
/*     */ 
/*  78 */     if (this.rowsVisible > 0)
/*     */     {
/*  80 */       IntegerHelper.getTwoBytes(this.rowsVisible, data, 4);
/*     */     }
/*     */     
/*     */ 
/*  84 */     if (this.columnsVisible > 0)
/*     */     {
/*  86 */       IntegerHelper.getTwoBytes(this.columnsVisible, data, 6);
/*     */     }
/*     */     
/*     */ 
/*  90 */     int activePane = 3;
/*     */     
/*  92 */     if ((this.rowsVisible > 0) && (this.columnsVisible == 0))
/*     */     {
/*  94 */       activePane = 2;
/*     */     }
/*  96 */     else if ((this.rowsVisible == 0) && (this.columnsVisible > 0))
/*     */     {
/*  98 */       activePane = 1;
/*     */     }
/* 100 */     else if ((this.rowsVisible > 0) && (this.columnsVisible > 0))
/*     */     {
/* 102 */       activePane = 0;
/*     */     }
/*     */     
/* 105 */     IntegerHelper.getTwoBytes(activePane, data, 8);
/*     */     
/* 107 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\PaneRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */