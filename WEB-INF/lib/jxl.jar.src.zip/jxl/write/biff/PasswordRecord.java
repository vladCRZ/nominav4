/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PasswordRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private String password;
/*     */   private byte[] data;
/*     */   
/*     */   public PasswordRecord(String pw)
/*     */   {
/*  48 */     super(Type.PASSWORD);
/*     */     
/*  50 */     this.password = pw;
/*     */     
/*  52 */     if (pw == null)
/*     */     {
/*  54 */       this.data = new byte[2];
/*  55 */       IntegerHelper.getTwoBytes(0, this.data, 0);
/*     */     }
/*     */     else
/*     */     {
/*  59 */       byte[] passwordBytes = pw.getBytes();
/*  60 */       int passwordHash = 0;
/*  61 */       for (int a = 0; a < passwordBytes.length; a++)
/*     */       {
/*  63 */         int shifted = rotLeft15Bit(passwordBytes[a], a + 1);
/*  64 */         passwordHash ^= shifted;
/*     */       }
/*  66 */       passwordHash ^= passwordBytes.length;
/*  67 */       passwordHash ^= 0xCE4B;
/*     */       
/*  69 */       this.data = new byte[2];
/*  70 */       IntegerHelper.getTwoBytes(passwordHash, this.data, 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PasswordRecord(int ph)
/*     */   {
/*  81 */     super(Type.PASSWORD);
/*     */     
/*  83 */     this.data = new byte[2];
/*  84 */     IntegerHelper.getTwoBytes(ph, this.data, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  94 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rotLeft15Bit(int val, int rotate)
/*     */   {
/* 106 */     val &= 0x7FFF;
/* 108 */     for (; 
/* 108 */         rotate > 0; rotate--)
/*     */     {
/* 110 */       if ((val & 0x4000) != 0)
/*     */       {
/* 112 */         val = (val << 1 & 0x7FFF) + 1;
/*     */       }
/*     */       else
/*     */       {
/* 116 */         val = val << 1 & 0x7FFF;
/*     */       }
/*     */     }
/*     */     
/* 120 */     return val;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\PasswordRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */