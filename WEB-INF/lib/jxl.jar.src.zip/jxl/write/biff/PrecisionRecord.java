/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrecisionRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean asDisplayed;
/*    */   private byte[] data;
/*    */   
/*    */   public PrecisionRecord(boolean disp)
/*    */   {
/* 47 */     super(Type.PRECISION);
/*    */     
/* 49 */     this.asDisplayed = disp;
/* 50 */     this.data = new byte[2];
/*    */     
/* 52 */     if (!this.asDisplayed)
/*    */     {
/* 54 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 65 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\PrecisionRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */