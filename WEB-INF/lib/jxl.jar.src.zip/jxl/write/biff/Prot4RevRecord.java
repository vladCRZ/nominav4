/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Prot4RevRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean protection;
/*    */   private byte[] data;
/*    */   
/*    */   public Prot4RevRecord(boolean prot)
/*    */   {
/* 47 */     super(Type.PROT4REV);
/*    */     
/* 49 */     this.protection = prot;
/*    */     
/*    */ 
/* 52 */     this.data = new byte[2];
/*    */     
/* 54 */     if (this.protection)
/*    */     {
/* 56 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 67 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\Prot4RevRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */