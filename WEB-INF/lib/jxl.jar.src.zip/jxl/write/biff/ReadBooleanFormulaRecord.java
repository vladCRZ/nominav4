/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.BooleanFormulaCell;
/*    */ import jxl.biff.FormulaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReadBooleanFormulaRecord
/*    */   extends ReadFormulaRecord
/*    */   implements BooleanFormulaCell
/*    */ {
/*    */   public ReadBooleanFormulaRecord(FormulaData f)
/*    */   {
/* 38 */     super(f);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getValue()
/*    */   {
/* 48 */     return ((BooleanFormulaCell)getReadFormula()).getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ReadBooleanFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */