/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.ErrorFormulaCell;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.formula.FormulaErrorCode;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReadErrorFormulaRecord
/*     */   extends ReadFormulaRecord
/*     */   implements ErrorFormulaCell
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(ReadErrorFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadErrorFormulaRecord(FormulaData f)
/*     */   {
/*  48 */     super(f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/*  58 */     return ((ErrorFormulaCell)getReadFormula()).getErrorCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] handleFormulaException()
/*     */   {
/*  70 */     byte[] expressiondata = null;
/*  71 */     byte[] celldata = super.getCellData();
/*     */     
/*  73 */     int errorCode = getErrorCode();
/*  74 */     String formulaString = null;
/*     */     
/*  76 */     if (errorCode == FormulaErrorCode.DIV0.getCode())
/*     */     {
/*  78 */       formulaString = "1/0";
/*     */     }
/*  80 */     else if (errorCode == FormulaErrorCode.VALUE.getCode())
/*     */     {
/*  82 */       formulaString = "\"\"/0";
/*     */     }
/*  84 */     else if (errorCode == FormulaErrorCode.REF.getCode())
/*     */     {
/*  86 */       formulaString = "\"#REF!\"";
/*     */     }
/*     */     else
/*     */     {
/*  90 */       formulaString = "\"ERROR\"";
/*     */     }
/*     */     
/*     */ 
/*  94 */     WritableWorkbookImpl w = getSheet().getWorkbook();
/*  95 */     FormulaParser parser = new FormulaParser(formulaString, w, w, w.getSettings());
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 101 */       parser.parse();
/*     */     }
/*     */     catch (FormulaException e2)
/*     */     {
/* 105 */       logger.warn(e2.getMessage());
/*     */     }
/* 107 */     byte[] formulaBytes = parser.getBytes();
/* 108 */     expressiondata = new byte[formulaBytes.length + 16];
/* 109 */     IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/* 110 */     System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length); byte[] 
/*     */     
/*     */ 
/*     */ 
/* 114 */       tmp160_157 = expressiondata;tmp160_157[8] = ((byte)(tmp160_157[8] | 0x2));
/*     */     
/* 116 */     byte[] data = new byte[celldata.length + expressiondata.length];
/*     */     
/* 118 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 119 */     System.arraycopy(expressiondata, 0, data, celldata.length, expressiondata.length);
/*     */     
/*     */ 
/*     */ 
/* 123 */     data[6] = 2;
/* 124 */     data[12] = -1;
/* 125 */     data[13] = -1;
/*     */     
/*     */ 
/* 128 */     data[8] = ((byte)errorCode);
/*     */     
/* 130 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ReadErrorFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */