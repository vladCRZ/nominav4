/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.CellType;
/*     */ import jxl.FormulaCell;
/*     */ import jxl.Sheet;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.WritableCell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReadFormulaRecord
/*     */   extends CellValue
/*     */   implements FormulaData
/*     */ {
/*  51 */   private static Logger logger = Logger.getLogger(ReadFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormulaData formula;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormulaParser parser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ReadFormulaRecord(FormulaData f)
/*     */   {
/*  70 */     super(Type.FORMULA, f);
/*  71 */     this.formula = f;
/*     */   }
/*     */   
/*     */   protected final byte[] getCellData()
/*     */   {
/*  76 */     return super.getData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] handleFormulaException()
/*     */   {
/*  88 */     byte[] expressiondata = null;
/*  89 */     byte[] celldata = super.getData();
/*     */     
/*     */ 
/*  92 */     WritableWorkbookImpl w = getSheet().getWorkbook();
/*  93 */     this.parser = new FormulaParser(getContents(), w, w, w.getSettings());
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  99 */       this.parser.parse();
/*     */     }
/*     */     catch (FormulaException e2)
/*     */     {
/* 103 */       logger.warn(e2.getMessage());
/* 104 */       this.parser = new FormulaParser("\"ERROR\"", w, w, w.getSettings());
/* 105 */       try { this.parser.parse();
/* 106 */       } catch (FormulaException e3) { Assert.verify(false);
/*     */       } }
/* 108 */     byte[] formulaBytes = this.parser.getBytes();
/* 109 */     expressiondata = new byte[formulaBytes.length + 16];
/* 110 */     IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/* 111 */     System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length); byte[] 
/*     */     
/*     */ 
/*     */ 
/* 115 */       tmp136_133 = expressiondata;tmp136_133[8] = ((byte)(tmp136_133[8] | 0x2));
/*     */     
/* 117 */     byte[] data = new byte[celldata.length + expressiondata.length];
/*     */     
/* 119 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 120 */     System.arraycopy(expressiondata, 0, data, celldata.length, expressiondata.length);
/*     */     
/* 122 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 134 */     byte[] celldata = super.getData();
/* 135 */     byte[] expressiondata = null;
/*     */     
/*     */     try
/*     */     {
/* 139 */       if (this.parser == null)
/*     */       {
/* 141 */         expressiondata = this.formula.getFormulaData();
/*     */       }
/*     */       else
/*     */       {
/* 145 */         byte[] formulaBytes = this.parser.getBytes();
/* 146 */         expressiondata = new byte[formulaBytes.length + 16];
/* 147 */         IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/* 148 */         System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 153 */       byte[] tmp64_61 = expressiondata;tmp64_61[8] = ((byte)(tmp64_61[8] | 0x2));
/*     */       
/* 155 */       byte[] data = new byte[celldata.length + expressiondata.length];
/*     */       
/* 157 */       System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 158 */       System.arraycopy(expressiondata, 0, data, celldata.length, expressiondata.length);
/*     */       
/* 160 */       return data;
/*     */ 
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/*     */ 
/* 166 */       logger.warn(CellReferenceHelper.getCellReference(getColumn(), getRow()) + " " + e.getMessage());
/*     */     }
/*     */     
/* 169 */     return handleFormulaException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellType getType()
/*     */   {
/* 180 */     return this.formula.getType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContents()
/*     */   {
/* 190 */     return this.formula.getContents();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaData()
/*     */     throws FormulaException
/*     */   {
/* 201 */     byte[] d = this.formula.getFormulaData();
/* 202 */     byte[] data = new byte[d.length];
/*     */     
/* 204 */     System.arraycopy(d, 0, data, 0, d.length); byte[] 
/*     */     
/*     */ 
/* 207 */       tmp27_24 = data;tmp27_24[8] = ((byte)(tmp27_24[8] | 0x2));
/*     */     
/* 209 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getFormulaBytes()
/*     */     throws FormulaException
/*     */   {
/* 220 */     if (this.parser != null)
/*     */     {
/* 222 */       return this.parser.getBytes();
/*     */     }
/*     */     
/*     */ 
/* 226 */     byte[] readFormulaData = getFormulaData();
/* 227 */     byte[] formulaBytes = new byte[readFormulaData.length - 16];
/* 228 */     System.arraycopy(readFormulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */     
/* 230 */     return formulaBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WritableCell copyTo(int col, int row)
/*     */   {
/* 242 */     return new FormulaRecord(col, row, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s)
/*     */   {
/* 256 */     super.setCellDetails(fr, ss, s);
/* 257 */     s.getWorkbook().addRCIRCell(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnInserted(Sheet s, int sheetIndex, int col)
/*     */   {
/*     */     try
/*     */     {
/* 272 */       if (this.parser == null)
/*     */       {
/* 274 */         byte[] formulaData = this.formula.getFormulaData();
/* 275 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 276 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 278 */         this.parser = new FormulaParser(formulaBytes, this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 283 */         this.parser.parse();
/*     */       }
/*     */       
/* 286 */       this.parser.columnInserted(sheetIndex, col, s == getSheet());
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 290 */       logger.warn("cannot insert column within formula:  " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void columnRemoved(Sheet s, int sheetIndex, int col)
/*     */   {
/*     */     try
/*     */     {
/* 306 */       if (this.parser == null)
/*     */       {
/* 308 */         byte[] formulaData = this.formula.getFormulaData();
/* 309 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 310 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 312 */         this.parser = new FormulaParser(formulaBytes, this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 317 */         this.parser.parse();
/*     */       }
/*     */       
/* 320 */       this.parser.columnRemoved(sheetIndex, col, s == getSheet());
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 324 */       logger.warn("cannot remove column within formula:  " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowInserted(Sheet s, int sheetIndex, int row)
/*     */   {
/*     */     try
/*     */     {
/* 340 */       if (this.parser == null)
/*     */       {
/* 342 */         byte[] formulaData = this.formula.getFormulaData();
/* 343 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 344 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 346 */         this.parser = new FormulaParser(formulaBytes, this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 351 */         this.parser.parse();
/*     */       }
/*     */       
/* 354 */       this.parser.rowInserted(sheetIndex, row, s == getSheet());
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 358 */       logger.warn("cannot insert row within formula:  " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rowRemoved(Sheet s, int sheetIndex, int row)
/*     */   {
/*     */     try
/*     */     {
/* 374 */       if (this.parser == null)
/*     */       {
/* 376 */         byte[] formulaData = this.formula.getFormulaData();
/* 377 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 378 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 380 */         this.parser = new FormulaParser(formulaBytes, this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 385 */         this.parser.parse();
/*     */       }
/*     */       
/* 388 */       this.parser.rowRemoved(sheetIndex, row, s == getSheet());
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 392 */       logger.warn("cannot remove row within formula:  " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FormulaData getReadFormula()
/*     */   {
/* 403 */     return this.formula;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormula()
/*     */     throws FormulaException
/*     */   {
/* 413 */     return ((FormulaCell)this.formula).getFormula();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handleImportedCellReferences(ExternalSheet es, WorkbookMethods mt, WorkbookSettings ws)
/*     */   {
/*     */     try
/*     */     {
/* 428 */       if (this.parser == null)
/*     */       {
/* 430 */         byte[] formulaData = this.formula.getFormulaData();
/* 431 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 432 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 434 */         this.parser = new FormulaParser(formulaBytes, this, es, mt, ws);
/*     */         
/*     */ 
/* 437 */         this.parser.parse();
/*     */       }
/*     */       
/* 440 */       return this.parser.handleImportedCellReferences();
/*     */     }
/*     */     catch (FormulaException e)
/*     */     {
/* 444 */       logger.warn("cannot import formula:  " + e.getMessage()); }
/* 445 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ReadFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */