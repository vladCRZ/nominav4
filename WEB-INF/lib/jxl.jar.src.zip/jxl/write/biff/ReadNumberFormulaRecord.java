/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.text.NumberFormat;
/*     */ import jxl.NumberFormulaCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReadNumberFormulaRecord
/*     */   extends ReadFormulaRecord
/*     */   implements NumberFormulaCell
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(ReadNumberFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadNumberFormulaRecord(FormulaData f)
/*     */   {
/*  49 */     super(f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/*  59 */     return ((NumberFormulaCell)getReadFormula()).getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumberFormat getNumberFormat()
/*     */   {
/*  70 */     return ((NumberFormulaCell)getReadFormula()).getNumberFormat();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] handleFormulaException()
/*     */   {
/*  82 */     byte[] expressiondata = null;
/*  83 */     byte[] celldata = super.getCellData();
/*     */     
/*     */ 
/*  86 */     WritableWorkbookImpl w = getSheet().getWorkbook();
/*  87 */     FormulaParser parser = new FormulaParser(Double.toString(getValue()), w, w, w.getSettings());
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  93 */       parser.parse();
/*     */     }
/*     */     catch (FormulaException e2)
/*     */     {
/*  97 */       logger.warn(e2.getMessage());
/*     */     }
/*  99 */     byte[] formulaBytes = parser.getBytes();
/* 100 */     expressiondata = new byte[formulaBytes.length + 16];
/* 101 */     IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/* 102 */     System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length); byte[] 
/*     */     
/*     */ 
/*     */ 
/* 106 */       tmp98_95 = expressiondata;tmp98_95[8] = ((byte)(tmp98_95[8] | 0x2));
/*     */     
/* 108 */     byte[] data = new byte[celldata.length + expressiondata.length];
/*     */     
/* 110 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 111 */     System.arraycopy(expressiondata, 0, data, celldata.length, expressiondata.length);
/*     */     
/*     */ 
/*     */ 
/* 115 */     DoubleHelper.getIEEEBytes(getValue(), data, 6);
/*     */     
/* 117 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ReadNumberFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */