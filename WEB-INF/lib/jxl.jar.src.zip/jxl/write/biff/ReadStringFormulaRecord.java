/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.StringFormulaCell;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReadStringFormulaRecord
/*     */   extends ReadFormulaRecord
/*     */   implements StringFormulaCell
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(ReadFormulaRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadStringFormulaRecord(FormulaData f)
/*     */   {
/*  47 */     super(f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/*  57 */     return ((StringFormulaCell)getReadFormula()).getString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] handleFormulaException()
/*     */   {
/*  69 */     byte[] expressiondata = null;
/*  70 */     byte[] celldata = super.getCellData();
/*     */     
/*     */ 
/*  73 */     WritableWorkbookImpl w = getSheet().getWorkbook();
/*  74 */     FormulaParser parser = new FormulaParser("\"" + getContents() + "\"", w, w, w.getSettings());
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  80 */       parser.parse();
/*     */     }
/*     */     catch (FormulaException e2)
/*     */     {
/*  84 */       logger.warn(e2.getMessage());
/*  85 */       parser = new FormulaParser("\"ERROR\"", w, w, w.getSettings());
/*  86 */       try { parser.parse();
/*  87 */       } catch (FormulaException e3) { Assert.verify(false);
/*     */       } }
/*  89 */     byte[] formulaBytes = parser.getBytes();
/*  90 */     expressiondata = new byte[formulaBytes.length + 16];
/*  91 */     IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/*  92 */     System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length); byte[] 
/*     */     
/*     */ 
/*     */ 
/*  96 */       tmp149_146 = expressiondata;tmp149_146[8] = ((byte)(tmp149_146[8] | 0x2));
/*     */     
/*  98 */     byte[] data = new byte[celldata.length + expressiondata.length];
/*     */     
/* 100 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 101 */     System.arraycopy(expressiondata, 0, data, celldata.length, expressiondata.length);
/*     */     
/*     */ 
/*     */ 
/* 105 */     data[6] = 0;
/* 106 */     data[12] = -1;
/* 107 */     data[13] = -1;
/*     */     
/* 109 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\ReadStringFormulaRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */