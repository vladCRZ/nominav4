/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.CellType;
/*     */ import jxl.SheetSettings;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.DVParser;
/*     */ import jxl.biff.IndexMapping;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.Number;
/*     */ import jxl.write.WritableCellFeatures;
/*     */ import jxl.write.WritableSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RowRecord
/*     */   extends WritableRecordData
/*     */ {
/*  49 */   private static final Logger logger = Logger.getLogger(RowRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private CellValue[] cells;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean collapsed;
/*     */   
/*     */ 
/*     */ 
/*     */   private int rowNumber;
/*     */   
/*     */ 
/*     */ 
/*     */   private int numColumns;
/*     */   
/*     */ 
/*     */ 
/*     */   private int xfIndex;
/*     */   
/*     */ 
/*     */ 
/*     */   private XFRecord style;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean defaultFormat;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean matchesDefFontHeight;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int growSize = 10;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int maxRKValue = 536870911;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int minRKValue = -536870912;
/*     */   
/*     */ 
/*     */ 
/* 109 */   private static int defaultHeightIndicator = 255;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private static int maxColumns = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int outlineLevel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean groupStart;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableSheet sheet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowRecord(int rn, WritableSheet ws)
/*     */   {
/* 138 */     super(Type.ROW);
/* 139 */     this.rowNumber = rn;
/* 140 */     this.cells = new CellValue[0];
/* 141 */     this.numColumns = 0;
/* 142 */     this.rowHeight = defaultHeightIndicator;
/* 143 */     this.collapsed = false;
/* 144 */     this.matchesDefFontHeight = true;
/* 145 */     this.sheet = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRowHeight(int h)
/*     */   {
/* 155 */     if (h == 0)
/*     */     {
/* 157 */       setCollapsed(true);
/* 158 */       this.matchesDefFontHeight = false;
/*     */     }
/*     */     else
/*     */     {
/* 162 */       this.rowHeight = h;
/* 163 */       this.matchesDefFontHeight = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setRowDetails(int height, boolean mdfh, boolean col, int ol, boolean gs, XFRecord xfr)
/*     */   {
/* 185 */     this.rowHeight = height;
/* 186 */     this.collapsed = col;
/* 187 */     this.matchesDefFontHeight = mdfh;
/* 188 */     this.outlineLevel = ol;
/* 189 */     this.groupStart = gs;
/*     */     
/* 191 */     if (xfr != null)
/*     */     {
/* 193 */       this.defaultFormat = true;
/* 194 */       this.style = xfr;
/* 195 */       this.xfIndex = this.style.getXFIndex();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCollapsed(boolean c)
/*     */   {
/* 206 */     this.collapsed = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowNumber()
/*     */   {
/* 216 */     return this.rowNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCell(CellValue cv)
/*     */   {
/* 226 */     int col = cv.getColumn();
/*     */     
/* 228 */     if (col >= maxColumns)
/*     */     {
/* 230 */       logger.warn("Could not add cell at " + CellReferenceHelper.getCellReference(cv.getRow(), cv.getColumn()) + " because it exceeds the maximum column limit");
/*     */       
/*     */ 
/*     */ 
/* 234 */       return;
/*     */     }
/*     */     
/*     */ 
/* 238 */     if (col >= this.cells.length)
/*     */     {
/* 240 */       CellValue[] oldCells = this.cells;
/* 241 */       this.cells = new CellValue[Math.max(oldCells.length + 10, col + 1)];
/* 242 */       System.arraycopy(oldCells, 0, this.cells, 0, oldCells.length);
/* 243 */       oldCells = null;
/*     */     }
/*     */     
/*     */ 
/* 247 */     if (this.cells[col] != null)
/*     */     {
/* 249 */       WritableCellFeatures wcf = this.cells[col].getWritableCellFeatures();
/* 250 */       if (wcf != null)
/*     */       {
/* 252 */         wcf.removeComment();
/*     */         
/*     */ 
/*     */ 
/* 256 */         if ((wcf.getDVParser() != null) && (!wcf.getDVParser().extendedCellsValidation()))
/*     */         {
/*     */ 
/* 259 */           wcf.removeDataValidation();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 265 */     this.cells[col] = cv;
/*     */     
/* 267 */     this.numColumns = Math.max(col + 1, this.numColumns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCell(int col)
/*     */   {
/* 278 */     if (col >= this.numColumns)
/*     */     {
/* 280 */       return;
/*     */     }
/*     */     
/* 283 */     this.cells[col] = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/* 294 */     outputFile.write(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeCells(File outputFile)
/*     */     throws IOException
/*     */   {
/* 309 */     ArrayList integerValues = new ArrayList();
/* 310 */     boolean integerValue = false;
/*     */     
/*     */ 
/* 313 */     for (int i = 0; i < this.numColumns; i++)
/*     */     {
/* 315 */       integerValue = false;
/* 316 */       if (this.cells[i] != null)
/*     */       {
/*     */ 
/*     */ 
/* 320 */         if (this.cells[i].getType() == CellType.NUMBER)
/*     */         {
/* 322 */           Number nc = (Number)this.cells[i];
/* 323 */           if ((nc.getValue() == (int)nc.getValue()) && (nc.getValue() < 5.36870911E8D) && (nc.getValue() > -5.36870912E8D) && (nc.getCellFeatures() == null))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 328 */             integerValue = true;
/*     */           }
/*     */         }
/*     */         
/* 332 */         if (integerValue)
/*     */         {
/*     */ 
/* 335 */           integerValues.add(this.cells[i]);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 341 */           writeIntegerValues(integerValues, outputFile);
/* 342 */           outputFile.write(this.cells[i]);
/*     */           
/*     */ 
/*     */ 
/* 346 */           if (this.cells[i].getType() == CellType.STRING_FORMULA)
/*     */           {
/* 348 */             StringRecord sr = new StringRecord(this.cells[i].getContents());
/* 349 */             outputFile.write(sr);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 357 */         writeIntegerValues(integerValues, outputFile);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 362 */     writeIntegerValues(integerValues, outputFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeIntegerValues(ArrayList integerValues, File outputFile)
/*     */     throws IOException
/*     */   {
/* 376 */     if (integerValues.size() == 0)
/*     */     {
/* 378 */       return;
/*     */     }
/*     */     
/* 381 */     if (integerValues.size() >= 3)
/*     */     {
/*     */ 
/* 384 */       MulRKRecord mulrk = new MulRKRecord(integerValues);
/* 385 */       outputFile.write(mulrk);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 390 */       Iterator i = integerValues.iterator();
/* 391 */       while (i.hasNext())
/*     */       {
/* 393 */         outputFile.write((CellValue)i.next());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 398 */     integerValues.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 409 */     byte[] data = new byte[16];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 414 */     int rh = this.rowHeight;
/* 415 */     if (this.sheet.getSettings().getDefaultRowHeight() != 255)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 420 */       if (rh == defaultHeightIndicator)
/*     */       {
/* 422 */         rh = this.sheet.getSettings().getDefaultRowHeight();
/*     */       }
/*     */     }
/*     */     
/* 426 */     IntegerHelper.getTwoBytes(this.rowNumber, data, 0);
/* 427 */     IntegerHelper.getTwoBytes(this.numColumns, data, 4);
/* 428 */     IntegerHelper.getTwoBytes(rh, data, 6);
/*     */     
/* 430 */     int options = 256 + this.outlineLevel;
/*     */     
/* 432 */     if (this.groupStart)
/*     */     {
/* 434 */       options |= 0x10;
/*     */     }
/*     */     
/* 437 */     if (this.collapsed)
/*     */     {
/* 439 */       options |= 0x20;
/*     */     }
/*     */     
/* 442 */     if (!this.matchesDefFontHeight)
/*     */     {
/* 444 */       options |= 0x40;
/*     */     }
/*     */     
/* 447 */     if (this.defaultFormat)
/*     */     {
/* 449 */       options |= 0x80;
/* 450 */       options |= this.xfIndex << 16;
/*     */     }
/*     */     
/* 453 */     IntegerHelper.getFourBytes(options, data, 12);
/*     */     
/* 455 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxColumn()
/*     */   {
/* 465 */     return this.numColumns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellValue getCell(int col)
/*     */   {
/* 477 */     return (col >= 0) && (col < this.numColumns) ? this.cells[col] : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void incrementRow()
/*     */   {
/* 486 */     this.rowNumber += 1;
/*     */     
/* 488 */     for (int i = 0; i < this.cells.length; i++)
/*     */     {
/* 490 */       if (this.cells[i] != null)
/*     */       {
/* 492 */         this.cells[i].incrementRow();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void decrementRow()
/*     */   {
/* 503 */     this.rowNumber -= 1;
/* 504 */     for (int i = 0; i < this.cells.length; i++)
/*     */     {
/* 506 */       if (this.cells[i] != null)
/*     */       {
/* 508 */         this.cells[i].decrementRow();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void insertColumn(int col)
/*     */   {
/* 523 */     if (col >= this.numColumns)
/*     */     {
/* 525 */       return;
/*     */     }
/*     */     
/*     */ 
/* 529 */     CellValue[] oldCells = this.cells;
/*     */     
/* 531 */     if (this.numColumns >= this.cells.length - 1)
/*     */     {
/* 533 */       this.cells = new CellValue[oldCells.length + 10];
/*     */     }
/*     */     else
/*     */     {
/* 537 */       this.cells = new CellValue[oldCells.length];
/*     */     }
/*     */     
/*     */ 
/* 541 */     System.arraycopy(oldCells, 0, this.cells, 0, col);
/*     */     
/*     */ 
/* 544 */     System.arraycopy(oldCells, col, this.cells, col + 1, this.numColumns - col);
/*     */     
/*     */ 
/* 547 */     for (int i = col + 1; i <= this.numColumns; i++)
/*     */     {
/* 549 */       if (this.cells[i] != null)
/*     */       {
/* 551 */         this.cells[i].incrementColumn();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 556 */     this.numColumns = Math.min(this.numColumns + 1, maxColumns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void removeColumn(int col)
/*     */   {
/* 568 */     if (col >= this.numColumns)
/*     */     {
/* 570 */       return;
/*     */     }
/*     */     
/*     */ 
/* 574 */     CellValue[] oldCells = this.cells;
/*     */     
/* 576 */     this.cells = new CellValue[oldCells.length];
/*     */     
/*     */ 
/* 579 */     System.arraycopy(oldCells, 0, this.cells, 0, col);
/*     */     
/*     */ 
/* 582 */     System.arraycopy(oldCells, col + 1, this.cells, col, this.numColumns - (col + 1));
/*     */     
/*     */ 
/* 585 */     for (int i = col; i < this.numColumns; i++)
/*     */     {
/* 587 */       if (this.cells[i] != null)
/*     */       {
/* 589 */         this.cells[i].decrementColumn();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 594 */     this.numColumns -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultHeight()
/*     */   {
/* 604 */     return this.rowHeight == defaultHeightIndicator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowHeight()
/*     */   {
/* 614 */     return this.rowHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCollapsed()
/*     */   {
/* 624 */     return this.collapsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void rationalize(IndexMapping xfmapping)
/*     */   {
/* 633 */     if (this.defaultFormat)
/*     */     {
/* 635 */       this.xfIndex = xfmapping.getNewIndex(this.xfIndex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   XFRecord getStyle()
/*     */   {
/* 647 */     return this.style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean hasDefaultFormat()
/*     */   {
/* 657 */     return this.defaultFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchesDefaultFontHeight()
/*     */   {
/* 667 */     return this.matchesDefFontHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOutlineLevel()
/*     */   {
/* 677 */     return this.outlineLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getGroupStart()
/*     */   {
/* 687 */     return this.groupStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void incrementOutlineLevel()
/*     */   {
/* 695 */     this.outlineLevel += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decrementOutlineLevel()
/*     */   {
/* 705 */     if (0 < this.outlineLevel)
/*     */     {
/* 707 */       this.outlineLevel -= 1;
/*     */     }
/*     */     
/* 710 */     if (0 == this.outlineLevel)
/*     */     {
/* 712 */       this.collapsed = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutlineLevel(int level)
/*     */   {
/* 723 */     this.outlineLevel = level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGroupStart(boolean value)
/*     */   {
/* 733 */     this.groupStart = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\RowRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */