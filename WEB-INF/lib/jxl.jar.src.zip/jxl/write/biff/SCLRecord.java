/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SCLRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int zoomFactor;
/*    */   
/*    */   public SCLRecord(int zf)
/*    */   {
/* 43 */     super(Type.SCL);
/*    */     
/* 45 */     this.zoomFactor = zf;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 54 */     byte[] data = new byte[4];
/*    */     
/* 56 */     int numerator = this.zoomFactor;
/* 57 */     int denominator = 100;
/*    */     
/* 59 */     IntegerHelper.getTwoBytes(numerator, data, 0);
/* 60 */     IntegerHelper.getTwoBytes(denominator, data, 2);
/*    */     
/* 62 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SCLRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */