/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSTContinueRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private String firstString;
/*     */   private boolean includeLength;
/*     */   private int firstStringLength;
/*     */   private ArrayList strings;
/*     */   private ArrayList stringLengths;
/*     */   private byte[] data;
/*     */   private int byteCount;
/*  68 */   private static int maxBytes = 8224;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SSTContinueRecord()
/*     */   {
/*  79 */     super(Type.CONTINUE);
/*     */     
/*  81 */     this.byteCount = 0;
/*  82 */     this.strings = new ArrayList(50);
/*  83 */     this.stringLengths = new ArrayList(50);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int setFirstString(String s, boolean b)
/*     */   {
/*  95 */     this.includeLength = b;
/*  96 */     this.firstStringLength = s.length();
/*     */     
/*  98 */     int bytes = 0;
/*     */     
/* 100 */     if (!this.includeLength)
/*     */     {
/* 102 */       bytes = s.length() * 2 + 1;
/*     */     }
/*     */     else
/*     */     {
/* 106 */       bytes = s.length() * 2 + 3;
/*     */     }
/*     */     
/* 109 */     if (bytes <= maxBytes)
/*     */     {
/* 111 */       this.firstString = s;
/* 112 */       this.byteCount += bytes;
/* 113 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 118 */     int charsAvailable = this.includeLength ? (maxBytes - 4) / 2 : (maxBytes - 2) / 2;
/*     */     
/*     */ 
/*     */ 
/* 122 */     this.firstString = s.substring(0, charsAvailable);
/* 123 */     this.byteCount = (maxBytes - 1);
/*     */     
/* 125 */     return s.length() - charsAvailable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOffset()
/*     */   {
/* 135 */     return this.byteCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int add(String s)
/*     */   {
/* 148 */     int bytes = s.length() * 2 + 3;
/*     */     
/*     */ 
/*     */ 
/* 152 */     if (this.byteCount >= maxBytes - 5)
/*     */     {
/* 154 */       return s.length();
/*     */     }
/*     */     
/* 157 */     this.stringLengths.add(new Integer(s.length()));
/*     */     
/* 159 */     if (bytes + this.byteCount < maxBytes)
/*     */     {
/*     */ 
/* 162 */       this.strings.add(s);
/* 163 */       this.byteCount += bytes;
/* 164 */       return 0;
/*     */     }
/*     */     
/*     */ 
/* 168 */     int bytesLeft = maxBytes - 3 - this.byteCount;
/* 169 */     int charsAvailable = bytesLeft % 2 == 0 ? bytesLeft / 2 : (bytesLeft - 1) / 2;
/*     */     
/*     */ 
/*     */ 
/* 173 */     this.strings.add(s.substring(0, charsAvailable));
/* 174 */     this.byteCount += charsAvailable * 2 + 3;
/*     */     
/* 176 */     return s.length() - charsAvailable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 186 */     this.data = new byte[this.byteCount];
/*     */     
/* 188 */     int pos = 0;
/*     */     
/*     */ 
/* 191 */     if (this.includeLength)
/*     */     {
/* 193 */       IntegerHelper.getTwoBytes(this.firstStringLength, this.data, 0);
/* 194 */       this.data[2] = 1;
/* 195 */       pos = 3;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 200 */       this.data[0] = 1;
/* 201 */       pos = 1;
/*     */     }
/*     */     
/* 204 */     StringHelper.getUnicodeBytes(this.firstString, this.data, pos);
/* 205 */     pos += this.firstString.length() * 2;
/*     */     
/*     */ 
/* 208 */     Iterator i = this.strings.iterator();
/* 209 */     String s = null;
/* 210 */     int length = 0;
/* 211 */     int count = 0;
/* 212 */     while (i.hasNext())
/*     */     {
/* 214 */       s = (String)i.next();
/* 215 */       length = ((Integer)this.stringLengths.get(count)).intValue();
/* 216 */       IntegerHelper.getTwoBytes(length, this.data, pos);
/* 217 */       this.data[(pos + 2)] = 1;
/* 218 */       StringHelper.getUnicodeBytes(s, this.data, pos + 3);
/* 219 */       pos += s.length() * 2 + 3;
/* 220 */       count++;
/*     */     }
/*     */     
/* 223 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SSTContinueRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */