/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSTRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private int numReferences;
/*     */   private int numStrings;
/*     */   private ArrayList strings;
/*     */   private ArrayList stringLengths;
/*     */   private byte[] data;
/*     */   private int byteCount;
/*  63 */   private static int maxBytes = 8216;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SSTRecord(int numRefs, int s)
/*     */   {
/*  75 */     super(Type.SST);
/*     */     
/*  77 */     this.numReferences = numRefs;
/*  78 */     this.numStrings = s;
/*  79 */     this.byteCount = 0;
/*  80 */     this.strings = new ArrayList(50);
/*  81 */     this.stringLengths = new ArrayList(50);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int add(String s)
/*     */   {
/*  94 */     int bytes = s.length() * 2 + 3;
/*     */     
/*     */ 
/*     */ 
/*  98 */     if (this.byteCount >= maxBytes - 5)
/*     */     {
/* 100 */       return s.length() > 0 ? s.length() : -1;
/*     */     }
/*     */     
/*     */ 
/* 104 */     this.stringLengths.add(new Integer(s.length()));
/*     */     
/* 106 */     if (bytes + this.byteCount < maxBytes)
/*     */     {
/*     */ 
/* 109 */       this.strings.add(s);
/* 110 */       this.byteCount += bytes;
/* 111 */       return 0;
/*     */     }
/*     */     
/*     */ 
/* 115 */     int bytesLeft = maxBytes - 3 - this.byteCount;
/* 116 */     int charsAvailable = bytesLeft % 2 == 0 ? bytesLeft / 2 : (bytesLeft - 1) / 2;
/*     */     
/*     */ 
/*     */ 
/* 120 */     this.strings.add(s.substring(0, charsAvailable));
/* 121 */     this.byteCount += charsAvailable * 2 + 3;
/*     */     
/* 123 */     return s.length() - charsAvailable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOffset()
/*     */   {
/* 133 */     return this.byteCount + 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 143 */     this.data = new byte[this.byteCount + 8];
/* 144 */     IntegerHelper.getFourBytes(this.numReferences, this.data, 0);
/* 145 */     IntegerHelper.getFourBytes(this.numStrings, this.data, 4);
/*     */     
/* 147 */     int pos = 8;
/* 148 */     int count = 0;
/*     */     
/* 150 */     Iterator i = this.strings.iterator();
/* 151 */     String s = null;
/* 152 */     int length = 0;
/* 153 */     while (i.hasNext())
/*     */     {
/* 155 */       s = (String)i.next();
/* 156 */       length = ((Integer)this.stringLengths.get(count)).intValue();
/* 157 */       IntegerHelper.getTwoBytes(length, this.data, pos);
/* 158 */       this.data[(pos + 2)] = 1;
/* 159 */       StringHelper.getUnicodeBytes(s, this.data, pos + 3);
/* 160 */       pos += s.length() * 2 + 3;
/* 161 */       count++;
/*     */     }
/*     */     
/* 164 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SSTRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */