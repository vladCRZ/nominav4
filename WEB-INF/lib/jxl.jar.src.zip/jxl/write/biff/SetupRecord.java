/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.SheetSettings;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.PageOrder;
/*     */ import jxl.format.PageOrientation;
/*     */ import jxl.format.PaperSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SetupRecord
/*     */   extends WritableRecordData
/*     */ {
/*  41 */   Logger logger = Logger.getLogger(SetupRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double headerMargin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double footerMargin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PageOrientation orientation;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PageOrder order;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int paperSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int scaleFactor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int pageStart;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int fitWidth;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int fitHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int horizontalPrintResolution;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int verticalPrintResolution;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int copies;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SetupRecord(SheetSettings s)
/*     */   {
/* 122 */     super(Type.SETUP);
/*     */     
/* 124 */     this.orientation = s.getOrientation();
/* 125 */     this.order = s.getPageOrder();
/* 126 */     this.headerMargin = s.getHeaderMargin();
/* 127 */     this.footerMargin = s.getFooterMargin();
/* 128 */     this.paperSize = s.getPaperSize().getValue();
/* 129 */     this.horizontalPrintResolution = s.getHorizontalPrintResolution();
/* 130 */     this.verticalPrintResolution = s.getVerticalPrintResolution();
/* 131 */     this.fitWidth = s.getFitWidth();
/* 132 */     this.fitHeight = s.getFitHeight();
/* 133 */     this.pageStart = s.getPageStart();
/* 134 */     this.scaleFactor = s.getScaleFactor();
/* 135 */     this.copies = s.getCopies();
/* 136 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrientation(PageOrientation o)
/*     */   {
/* 146 */     this.orientation = o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(PageOrder o)
/*     */   {
/* 156 */     this.order = o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMargins(double hm, double fm)
/*     */   {
/* 167 */     this.headerMargin = hm;
/* 168 */     this.footerMargin = fm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaperSize(PaperSize ps)
/*     */   {
/* 178 */     this.paperSize = ps.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 188 */     this.data = new byte[34];
/*     */     
/*     */ 
/* 191 */     IntegerHelper.getTwoBytes(this.paperSize, this.data, 0);
/*     */     
/*     */ 
/* 194 */     IntegerHelper.getTwoBytes(this.scaleFactor, this.data, 2);
/*     */     
/*     */ 
/* 197 */     IntegerHelper.getTwoBytes(this.pageStart, this.data, 4);
/*     */     
/*     */ 
/* 200 */     IntegerHelper.getTwoBytes(this.fitWidth, this.data, 6);
/*     */     
/*     */ 
/* 203 */     IntegerHelper.getTwoBytes(this.fitHeight, this.data, 8);
/*     */     
/*     */ 
/* 206 */     int options = 0;
/* 207 */     if (this.order == PageOrder.RIGHT_THEN_DOWN)
/*     */     {
/* 209 */       options |= 0x1;
/*     */     }
/*     */     
/* 212 */     if (this.orientation == PageOrientation.PORTRAIT)
/*     */     {
/* 214 */       options |= 0x2;
/*     */     }
/*     */     
/* 217 */     if (this.pageStart != 0)
/*     */     {
/* 219 */       options |= 0x80;
/*     */     }
/*     */     
/* 222 */     if (!this.initialized)
/*     */     {
/* 224 */       options |= 0x4;
/*     */     }
/*     */     
/* 227 */     IntegerHelper.getTwoBytes(options, this.data, 10);
/*     */     
/*     */ 
/* 230 */     IntegerHelper.getTwoBytes(this.horizontalPrintResolution, this.data, 12);
/*     */     
/*     */ 
/* 233 */     IntegerHelper.getTwoBytes(this.verticalPrintResolution, this.data, 14);
/*     */     
/*     */ 
/* 236 */     DoubleHelper.getIEEEBytes(this.headerMargin, this.data, 16);
/*     */     
/*     */ 
/* 239 */     DoubleHelper.getIEEEBytes(this.footerMargin, this.data, 24);
/*     */     
/*     */ 
/* 242 */     IntegerHelper.getTwoBytes(this.copies, this.data, 32);
/*     */     
/* 244 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SetupRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */