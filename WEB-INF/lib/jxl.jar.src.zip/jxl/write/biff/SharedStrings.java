/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedStrings
/*     */ {
/*     */   private HashMap strings;
/*     */   private ArrayList stringList;
/*     */   private int totalOccurrences;
/*     */   
/*     */   public SharedStrings()
/*     */   {
/*  53 */     this.strings = new HashMap(100);
/*  54 */     this.stringList = new ArrayList(100);
/*  55 */     this.totalOccurrences = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndex(String s)
/*     */   {
/*  68 */     Integer i = (Integer)this.strings.get(s);
/*     */     
/*  70 */     if (i == null)
/*     */     {
/*  72 */       i = new Integer(this.strings.size());
/*  73 */       this.strings.put(s, i);
/*  74 */       this.stringList.add(s);
/*     */     }
/*     */     
/*  77 */     this.totalOccurrences += 1;
/*     */     
/*  79 */     return i.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(int i)
/*     */   {
/*  90 */     return (String)this.stringList.get(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(File outputFile)
/*     */     throws IOException
/*     */   {
/* 103 */     int charsLeft = 0;
/* 104 */     String curString = null;
/* 105 */     SSTRecord sst = new SSTRecord(this.totalOccurrences, this.stringList.size());
/* 106 */     ExtendedSSTRecord extsst = new ExtendedSSTRecord(this.stringList.size());
/* 107 */     int bucketSize = extsst.getNumberOfStringsPerBucket();
/*     */     
/* 109 */     Iterator i = this.stringList.iterator();
/* 110 */     int stringIndex = 0;
/* 111 */     while ((i.hasNext()) && (charsLeft == 0))
/*     */     {
/* 113 */       curString = (String)i.next();
/*     */       
/* 115 */       int relativePosition = sst.getOffset() + 4;
/* 116 */       charsLeft = sst.add(curString);
/* 117 */       if (stringIndex % bucketSize == 0) {
/* 118 */         extsst.addString(outputFile.getPos(), relativePosition);
/*     */       }
/* 120 */       stringIndex++;
/*     */     }
/* 122 */     outputFile.write(sst);
/*     */     
/* 124 */     if ((charsLeft != 0) || (i.hasNext()))
/*     */     {
/*     */ 
/* 127 */       SSTContinueRecord cont = createContinueRecord(curString, charsLeft, outputFile);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 132 */       while (i.hasNext())
/*     */       {
/* 134 */         curString = (String)i.next();
/* 135 */         int relativePosition = cont.getOffset() + 4;
/* 136 */         charsLeft = cont.add(curString);
/* 137 */         if (stringIndex % bucketSize == 0) {
/* 138 */           extsst.addString(outputFile.getPos(), relativePosition);
/*     */         }
/* 140 */         stringIndex++;
/*     */         
/* 142 */         if (charsLeft != 0)
/*     */         {
/* 144 */           outputFile.write(cont);
/* 145 */           cont = createContinueRecord(curString, charsLeft, outputFile);
/*     */         }
/*     */       }
/*     */       
/* 149 */       outputFile.write(cont);
/*     */     }
/*     */     
/* 152 */     outputFile.write(extsst);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SSTContinueRecord createContinueRecord(String curString, int charsLeft, File outputFile)
/*     */     throws IOException
/*     */   {
/* 163 */     SSTContinueRecord cont = null;
/* 164 */     while (charsLeft != 0)
/*     */     {
/* 166 */       cont = new SSTContinueRecord();
/*     */       
/* 168 */       if ((charsLeft == curString.length()) || (curString.length() == 0))
/*     */       {
/* 170 */         charsLeft = cont.setFirstString(curString, true);
/*     */       }
/*     */       else
/*     */       {
/* 174 */         charsLeft = cont.setFirstString(curString.substring(curString.length() - charsLeft), false);
/*     */       }
/*     */       
/*     */ 
/* 178 */       if (charsLeft != 0)
/*     */       {
/* 180 */         outputFile.write(cont);
/* 181 */         cont = new SSTContinueRecord();
/*     */       }
/*     */     }
/*     */     
/* 185 */     return cont;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SharedStrings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */