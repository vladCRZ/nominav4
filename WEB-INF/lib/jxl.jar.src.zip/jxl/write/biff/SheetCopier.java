/*      */ package jxl.write.biff;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.TreeSet;
/*      */ import jxl.BooleanCell;
/*      */ import jxl.Cell;
/*      */ import jxl.CellFeatures;
/*      */ import jxl.CellType;
/*      */ import jxl.CellView;
/*      */ import jxl.DateCell;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.LabelCell;
/*      */ import jxl.NumberCell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.AutoFilter;
/*      */ import jxl.biff.CellReferenceHelper;
/*      */ import jxl.biff.ConditionalFormat;
/*      */ import jxl.biff.DataValidation;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.FormulaData;
/*      */ import jxl.biff.NumFormatRecordsException;
/*      */ import jxl.biff.SheetRangeImpl;
/*      */ import jxl.biff.XFRecord;
/*      */ import jxl.biff.drawing.Button;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.CheckBox;
/*      */ import jxl.biff.drawing.ComboBox;
/*      */ import jxl.biff.drawing.Comment;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.biff.formula.FormulaException;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.read.biff.BOFRecord;
/*      */ import jxl.read.biff.NameRecord;
/*      */ import jxl.read.biff.NameRecord.NameRange;
/*      */ import jxl.read.biff.SheetImpl;
/*      */ import jxl.read.biff.WorkbookParser;
/*      */ import jxl.write.Blank;
/*      */ import jxl.write.Boolean;
/*      */ import jxl.write.DateTime;
/*      */ import jxl.write.Formula;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.Number;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFeatures;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableHyperlink;
/*      */ import jxl.write.WritableImage;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ import jxl.write.WriteException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class SheetCopier
/*      */ {
/*   87 */   private static Logger logger = Logger.getLogger(SheetCopier.class);
/*      */   
/*      */   private SheetImpl fromSheet;
/*      */   
/*      */   private WritableSheetImpl toSheet;
/*      */   
/*      */   private WorkbookSettings workbookSettings;
/*      */   
/*      */   private TreeSet columnFormats;
/*      */   
/*      */   private FormattingRecords formatRecords;
/*      */   private ArrayList hyperlinks;
/*      */   private MergedCells mergedCells;
/*      */   private ArrayList rowBreaks;
/*      */   private ArrayList columnBreaks;
/*      */   private SheetWriter sheetWriter;
/*      */   private ArrayList drawings;
/*      */   private ArrayList images;
/*      */   private ArrayList conditionalFormats;
/*      */   private ArrayList validatedCells;
/*      */   private AutoFilter autoFilter;
/*      */   private DataValidation dataValidation;
/*      */   private ComboBox comboBox;
/*      */   private PLSRecord plsRecord;
/*      */   private boolean chartOnly;
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   private int numRows;
/*      */   private int maxRowOutlineLevel;
/*      */   private int maxColumnOutlineLevel;
/*      */   private HashMap xfRecords;
/*      */   private HashMap fonts;
/*      */   private HashMap formats;
/*      */   
/*      */   public SheetCopier(Sheet f, WritableSheet t)
/*      */   {
/*  122 */     this.fromSheet = ((SheetImpl)f);
/*  123 */     this.toSheet = ((WritableSheetImpl)t);
/*  124 */     this.workbookSettings = this.toSheet.getWorkbook().getSettings();
/*  125 */     this.chartOnly = false;
/*      */   }
/*      */   
/*      */   void setColumnFormats(TreeSet cf)
/*      */   {
/*  130 */     this.columnFormats = cf;
/*      */   }
/*      */   
/*      */   void setFormatRecords(FormattingRecords fr)
/*      */   {
/*  135 */     this.formatRecords = fr;
/*      */   }
/*      */   
/*      */   void setHyperlinks(ArrayList h)
/*      */   {
/*  140 */     this.hyperlinks = h;
/*      */   }
/*      */   
/*      */   void setMergedCells(MergedCells mc)
/*      */   {
/*  145 */     this.mergedCells = mc;
/*      */   }
/*      */   
/*      */   void setRowBreaks(ArrayList rb)
/*      */   {
/*  150 */     this.rowBreaks = rb;
/*      */   }
/*      */   
/*      */   void setColumnBreaks(ArrayList cb)
/*      */   {
/*  155 */     this.columnBreaks = cb;
/*      */   }
/*      */   
/*      */   void setSheetWriter(SheetWriter sw)
/*      */   {
/*  160 */     this.sheetWriter = sw;
/*      */   }
/*      */   
/*      */   void setDrawings(ArrayList d)
/*      */   {
/*  165 */     this.drawings = d;
/*      */   }
/*      */   
/*      */   void setImages(ArrayList i)
/*      */   {
/*  170 */     this.images = i;
/*      */   }
/*      */   
/*      */   void setConditionalFormats(ArrayList cf)
/*      */   {
/*  175 */     this.conditionalFormats = cf;
/*      */   }
/*      */   
/*      */   void setValidatedCells(ArrayList vc)
/*      */   {
/*  180 */     this.validatedCells = vc;
/*      */   }
/*      */   
/*      */   AutoFilter getAutoFilter()
/*      */   {
/*  185 */     return this.autoFilter;
/*      */   }
/*      */   
/*      */   DataValidation getDataValidation()
/*      */   {
/*  190 */     return this.dataValidation;
/*      */   }
/*      */   
/*      */   ComboBox getComboBox()
/*      */   {
/*  195 */     return this.comboBox;
/*      */   }
/*      */   
/*      */   PLSRecord getPLSRecord()
/*      */   {
/*  200 */     return this.plsRecord;
/*      */   }
/*      */   
/*      */   boolean isChartOnly()
/*      */   {
/*  205 */     return this.chartOnly;
/*      */   }
/*      */   
/*      */   ButtonPropertySetRecord getButtonPropertySet()
/*      */   {
/*  210 */     return this.buttonPropertySet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copySheet()
/*      */   {
/*  219 */     shallowCopyCells();
/*      */     
/*      */ 
/*  222 */     jxl.read.biff.ColumnInfoRecord[] readCirs = this.fromSheet.getColumnInfos();
/*      */     
/*  224 */     for (int i = 0; i < readCirs.length; i++)
/*      */     {
/*  226 */       jxl.read.biff.ColumnInfoRecord rcir = readCirs[i];
/*  227 */       for (int j = rcir.getStartColumn(); j <= rcir.getEndColumn(); j++)
/*      */       {
/*  229 */         ColumnInfoRecord cir = new ColumnInfoRecord(rcir, j, this.formatRecords);
/*      */         
/*  231 */         cir.setHidden(rcir.getHidden());
/*  232 */         this.columnFormats.add(cir);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  237 */     Hyperlink[] hls = this.fromSheet.getHyperlinks();
/*  238 */     for (int i = 0; i < hls.length; i++)
/*      */     {
/*  240 */       WritableHyperlink hr = new WritableHyperlink(hls[i], this.toSheet);
/*      */       
/*  242 */       this.hyperlinks.add(hr);
/*      */     }
/*      */     
/*      */ 
/*  246 */     Range[] merged = this.fromSheet.getMergedCells();
/*      */     
/*  248 */     for (int i = 0; i < merged.length; i++)
/*      */     {
/*  250 */       this.mergedCells.add(new SheetRangeImpl((SheetRangeImpl)merged[i], this.toSheet));
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  256 */       jxl.read.biff.RowRecord[] rowprops = this.fromSheet.getRowProperties();
/*      */       
/*  258 */       for (int i = 0; i < rowprops.length; i++)
/*      */       {
/*  260 */         RowRecord rr = this.toSheet.getRowRecord(rowprops[i].getRowNumber());
/*  261 */         XFRecord format = rowprops[i].hasDefaultFormat() ? this.formatRecords.getXFRecord(rowprops[i].getXFIndex()) : null;
/*      */         
/*  263 */         rr.setRowDetails(rowprops[i].getRowHeight(), rowprops[i].matchesDefaultFontHeight(), rowprops[i].isCollapsed(), rowprops[i].getOutlineLevel(), rowprops[i].getGroupStart(), format);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  269 */         this.numRows = Math.max(this.numRows, rowprops[i].getRowNumber() + 1);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (RowsExceededException e)
/*      */     {
/*  276 */       Assert.verify(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  284 */     int[] rowbreaks = this.fromSheet.getRowPageBreaks();
/*      */     
/*  286 */     if (rowbreaks != null)
/*      */     {
/*  288 */       for (int i = 0; i < rowbreaks.length; i++)
/*      */       {
/*  290 */         this.rowBreaks.add(new Integer(rowbreaks[i]));
/*      */       }
/*      */     }
/*      */     
/*  294 */     int[] columnbreaks = this.fromSheet.getColumnPageBreaks();
/*      */     
/*  296 */     if (columnbreaks != null)
/*      */     {
/*  298 */       for (int i = 0; i < columnbreaks.length; i++)
/*      */       {
/*  300 */         this.columnBreaks.add(new Integer(columnbreaks[i]));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  305 */     this.sheetWriter.setCharts(this.fromSheet.getCharts());
/*      */     
/*      */ 
/*  308 */     DrawingGroupObject[] dr = this.fromSheet.getDrawings();
/*  309 */     for (int i = 0; i < dr.length; i++)
/*      */     {
/*  311 */       if ((dr[i] instanceof Drawing))
/*      */       {
/*  313 */         WritableImage wi = new WritableImage(dr[i], this.toSheet.getWorkbook().getDrawingGroup());
/*      */         
/*  315 */         this.drawings.add(wi);
/*  316 */         this.images.add(wi);
/*      */       }
/*  318 */       else if ((dr[i] instanceof Comment))
/*      */       {
/*  320 */         Comment c = new Comment(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*  324 */         this.drawings.add(c);
/*      */         
/*      */ 
/*  327 */         CellValue cv = (CellValue)this.toSheet.getWritableCell(c.getColumn(), c.getRow());
/*      */         
/*  329 */         Assert.verify(cv.getCellFeatures() != null);
/*  330 */         cv.getWritableCellFeatures().setCommentDrawing(c);
/*      */       }
/*  332 */       else if ((dr[i] instanceof Button))
/*      */       {
/*  334 */         Button b = new Button(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  339 */         this.drawings.add(b);
/*      */       }
/*  341 */       else if ((dr[i] instanceof ComboBox))
/*      */       {
/*  343 */         ComboBox cb = new ComboBox(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  348 */         this.drawings.add(cb);
/*      */       }
/*  350 */       else if ((dr[i] instanceof CheckBox))
/*      */       {
/*  352 */         CheckBox cb = new CheckBox(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  357 */         this.drawings.add(cb);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  363 */     DataValidation rdv = this.fromSheet.getDataValidation();
/*  364 */     if (rdv != null)
/*      */     {
/*  366 */       this.dataValidation = new DataValidation(rdv, this.toSheet.getWorkbook(), this.toSheet.getWorkbook(), this.workbookSettings);
/*      */       
/*      */ 
/*      */ 
/*  370 */       int objid = this.dataValidation.getComboBoxObjectId();
/*      */       
/*  372 */       if (objid != 0)
/*      */       {
/*  374 */         this.comboBox = ((ComboBox)this.drawings.get(objid));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  379 */     ConditionalFormat[] cf = this.fromSheet.getConditionalFormats();
/*  380 */     if (cf.length > 0)
/*      */     {
/*  382 */       for (int i = 0; i < cf.length; i++)
/*      */       {
/*  384 */         this.conditionalFormats.add(cf[i]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  389 */     this.autoFilter = this.fromSheet.getAutoFilter();
/*      */     
/*      */ 
/*  392 */     this.sheetWriter.setWorkspaceOptions(this.fromSheet.getWorkspaceOptions());
/*      */     
/*      */ 
/*  395 */     if (this.fromSheet.getSheetBof().isChart())
/*      */     {
/*  397 */       this.chartOnly = true;
/*  398 */       this.sheetWriter.setChartOnly();
/*      */     }
/*      */     
/*      */ 
/*  402 */     if (this.fromSheet.getPLS() != null)
/*      */     {
/*  404 */       if (this.fromSheet.getWorkbookBof().isBiff7())
/*      */       {
/*  406 */         logger.warn("Cannot copy Biff7 print settings record - ignoring");
/*      */       }
/*      */       else
/*      */       {
/*  410 */         this.plsRecord = new PLSRecord(this.fromSheet.getPLS());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  415 */     if (this.fromSheet.getButtonPropertySet() != null)
/*      */     {
/*  417 */       this.buttonPropertySet = new ButtonPropertySetRecord(this.fromSheet.getButtonPropertySet());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  422 */     this.maxRowOutlineLevel = this.fromSheet.getMaxRowOutlineLevel();
/*  423 */     this.maxColumnOutlineLevel = this.fromSheet.getMaxColumnOutlineLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyWritableSheet()
/*      */   {
/*  432 */     shallowCopyCells();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void importSheet()
/*      */   {
/*  538 */     this.xfRecords = new HashMap();
/*  539 */     this.fonts = new HashMap();
/*  540 */     this.formats = new HashMap();
/*      */     
/*  542 */     deepCopyCells();
/*      */     
/*      */ 
/*  545 */     jxl.read.biff.ColumnInfoRecord[] readCirs = this.fromSheet.getColumnInfos();
/*      */     
/*  547 */     for (int i = 0; i < readCirs.length; i++)
/*      */     {
/*  549 */       jxl.read.biff.ColumnInfoRecord rcir = readCirs[i];
/*  550 */       for (int j = rcir.getStartColumn(); j <= rcir.getEndColumn(); j++)
/*      */       {
/*  552 */         ColumnInfoRecord cir = new ColumnInfoRecord(rcir, j);
/*  553 */         int xfIndex = cir.getXfIndex();
/*  554 */         XFRecord cf = (WritableCellFormat)this.xfRecords.get(new Integer(xfIndex));
/*      */         WritableCellFormat wcf;
/*  556 */         if (cf == null)
/*      */         {
/*  558 */           CellFormat readFormat = this.fromSheet.getColumnView(j).getFormat();
/*  559 */           wcf = copyCellFormat(readFormat);
/*      */         }
/*      */         
/*  562 */         cir.setCellFormat(cf);
/*  563 */         cir.setHidden(rcir.getHidden());
/*  564 */         this.columnFormats.add(cir);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  569 */     Hyperlink[] hls = this.fromSheet.getHyperlinks();
/*  570 */     for (int i = 0; i < hls.length; i++)
/*      */     {
/*  572 */       WritableHyperlink hr = new WritableHyperlink(hls[i], this.toSheet);
/*      */       
/*  574 */       this.hyperlinks.add(hr);
/*      */     }
/*      */     
/*      */ 
/*  578 */     Range[] merged = this.fromSheet.getMergedCells();
/*      */     
/*  580 */     for (int i = 0; i < merged.length; i++)
/*      */     {
/*  582 */       this.mergedCells.add(new SheetRangeImpl((SheetRangeImpl)merged[i], this.toSheet));
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  588 */       jxl.read.biff.RowRecord[] rowprops = this.fromSheet.getRowProperties();
/*      */       
/*  590 */       for (int i = 0; i < rowprops.length; i++)
/*      */       {
/*  592 */         RowRecord rr = this.toSheet.getRowRecord(rowprops[i].getRowNumber());
/*  593 */         XFRecord format = null;
/*  594 */         jxl.read.biff.RowRecord rowrec = rowprops[i];
/*  595 */         WritableCellFormat wcf; if (rowrec.hasDefaultFormat())
/*      */         {
/*  597 */           format = (WritableCellFormat)this.xfRecords.get(new Integer(rowrec.getXFIndex()));
/*      */           
/*      */ 
/*  600 */           if (format == null)
/*      */           {
/*  602 */             int rownum = rowrec.getRowNumber();
/*  603 */             CellFormat readFormat = this.fromSheet.getRowView(rownum).getFormat();
/*  604 */             wcf = copyCellFormat(readFormat);
/*      */           }
/*      */         }
/*      */         
/*  608 */         rr.setRowDetails(rowrec.getRowHeight(), rowrec.matchesDefaultFontHeight(), rowrec.isCollapsed(), rowrec.getOutlineLevel(), rowrec.getGroupStart(), format);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  614 */         this.numRows = Math.max(this.numRows, rowprops[i].getRowNumber() + 1);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (RowsExceededException e)
/*      */     {
/*  621 */       Assert.verify(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */     int[] rowbreaks = this.fromSheet.getRowPageBreaks();
/*      */     
/*  631 */     if (rowbreaks != null)
/*      */     {
/*  633 */       for (int i = 0; i < rowbreaks.length; i++)
/*      */       {
/*  635 */         this.rowBreaks.add(new Integer(rowbreaks[i]));
/*      */       }
/*      */     }
/*      */     
/*  639 */     int[] columnbreaks = this.fromSheet.getColumnPageBreaks();
/*      */     
/*  641 */     if (columnbreaks != null)
/*      */     {
/*  643 */       for (int i = 0; i < columnbreaks.length; i++)
/*      */       {
/*  645 */         this.columnBreaks.add(new Integer(columnbreaks[i]));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  650 */     Chart[] fromCharts = this.fromSheet.getCharts();
/*  651 */     if ((fromCharts != null) && (fromCharts.length > 0))
/*      */     {
/*  653 */       logger.warn("Importing of charts is not supported");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  690 */     DrawingGroupObject[] dr = this.fromSheet.getDrawings();
/*      */     
/*      */ 
/*      */ 
/*  694 */     if ((dr.length > 0) && (this.toSheet.getWorkbook().getDrawingGroup() == null))
/*      */     {
/*      */ 
/*  697 */       this.toSheet.getWorkbook().createDrawingGroup();
/*      */     }
/*      */     
/*  700 */     for (int i = 0; i < dr.length; i++)
/*      */     {
/*  702 */       if ((dr[i] instanceof Drawing))
/*      */       {
/*  704 */         WritableImage wi = new WritableImage(dr[i].getX(), dr[i].getY(), dr[i].getWidth(), dr[i].getHeight(), dr[i].getImageData());
/*      */         
/*      */ 
/*      */ 
/*  708 */         this.toSheet.getWorkbook().addDrawing(wi);
/*  709 */         this.drawings.add(wi);
/*  710 */         this.images.add(wi);
/*      */       }
/*  712 */       else if ((dr[i] instanceof Comment))
/*      */       {
/*  714 */         Comment c = new Comment(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*  718 */         this.drawings.add(c);
/*      */         
/*      */ 
/*  721 */         CellValue cv = (CellValue)this.toSheet.getWritableCell(c.getColumn(), c.getRow());
/*      */         
/*  723 */         Assert.verify(cv.getCellFeatures() != null);
/*  724 */         cv.getWritableCellFeatures().setCommentDrawing(c);
/*      */       }
/*  726 */       else if ((dr[i] instanceof Button))
/*      */       {
/*  728 */         Button b = new Button(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  733 */         this.drawings.add(b);
/*      */       }
/*  735 */       else if ((dr[i] instanceof ComboBox))
/*      */       {
/*  737 */         ComboBox cb = new ComboBox(dr[i], this.toSheet.getWorkbook().getDrawingGroup(), this.workbookSettings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  742 */         this.drawings.add(cb);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  747 */     DataValidation rdv = this.fromSheet.getDataValidation();
/*  748 */     if (rdv != null)
/*      */     {
/*  750 */       this.dataValidation = new DataValidation(rdv, this.toSheet.getWorkbook(), this.toSheet.getWorkbook(), this.workbookSettings);
/*      */       
/*      */ 
/*      */ 
/*  754 */       int objid = this.dataValidation.getComboBoxObjectId();
/*  755 */       if (objid != 0)
/*      */       {
/*  757 */         this.comboBox = ((ComboBox)this.drawings.get(objid));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  762 */     this.sheetWriter.setWorkspaceOptions(this.fromSheet.getWorkspaceOptions());
/*      */     
/*      */ 
/*  765 */     if (this.fromSheet.getSheetBof().isChart())
/*      */     {
/*  767 */       this.chartOnly = true;
/*  768 */       this.sheetWriter.setChartOnly();
/*      */     }
/*      */     
/*      */ 
/*  772 */     if (this.fromSheet.getPLS() != null)
/*      */     {
/*  774 */       if (this.fromSheet.getWorkbookBof().isBiff7())
/*      */       {
/*  776 */         logger.warn("Cannot copy Biff7 print settings record - ignoring");
/*      */       }
/*      */       else
/*      */       {
/*  780 */         this.plsRecord = new PLSRecord(this.fromSheet.getPLS());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  785 */     if (this.fromSheet.getButtonPropertySet() != null)
/*      */     {
/*  787 */       this.buttonPropertySet = new ButtonPropertySetRecord(this.fromSheet.getButtonPropertySet());
/*      */     }
/*      */     
/*      */ 
/*  791 */     importNames();
/*      */     
/*      */ 
/*  794 */     this.maxRowOutlineLevel = this.fromSheet.getMaxRowOutlineLevel();
/*  795 */     this.maxColumnOutlineLevel = this.fromSheet.getMaxColumnOutlineLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WritableCell shallowCopyCell(Cell cell)
/*      */   {
/*  803 */     CellType ct = cell.getType();
/*  804 */     WritableCell newCell = null;
/*      */     
/*  806 */     if (ct == CellType.LABEL)
/*      */     {
/*  808 */       newCell = new Label((LabelCell)cell);
/*      */     }
/*  810 */     else if (ct == CellType.NUMBER)
/*      */     {
/*  812 */       newCell = new Number((NumberCell)cell);
/*      */     }
/*  814 */     else if (ct == CellType.DATE)
/*      */     {
/*  816 */       newCell = new DateTime((DateCell)cell);
/*      */     }
/*  818 */     else if (ct == CellType.BOOLEAN)
/*      */     {
/*  820 */       newCell = new Boolean((BooleanCell)cell);
/*      */     }
/*  822 */     else if (ct == CellType.NUMBER_FORMULA)
/*      */     {
/*  824 */       newCell = new ReadNumberFormulaRecord((FormulaData)cell);
/*      */     }
/*  826 */     else if (ct == CellType.STRING_FORMULA)
/*      */     {
/*  828 */       newCell = new ReadStringFormulaRecord((FormulaData)cell);
/*      */     }
/*  830 */     else if (ct == CellType.BOOLEAN_FORMULA)
/*      */     {
/*  832 */       newCell = new ReadBooleanFormulaRecord((FormulaData)cell);
/*      */     }
/*  834 */     else if (ct == CellType.DATE_FORMULA)
/*      */     {
/*  836 */       newCell = new ReadDateFormulaRecord((FormulaData)cell);
/*      */     }
/*  838 */     else if (ct == CellType.FORMULA_ERROR)
/*      */     {
/*  840 */       newCell = new ReadErrorFormulaRecord((FormulaData)cell);
/*      */     }
/*  842 */     else if (ct == CellType.EMPTY)
/*      */     {
/*  844 */       if (cell.getCellFormat() != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  849 */         newCell = new Blank(cell);
/*      */       }
/*      */     }
/*      */     
/*  853 */     return newCell;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WritableCell deepCopyCell(Cell cell)
/*      */   {
/*  863 */     WritableCell c = shallowCopyCell(cell);
/*      */     
/*  865 */     if (c == null)
/*      */     {
/*  867 */       return c;
/*      */     }
/*      */     
/*  870 */     if ((c instanceof ReadFormulaRecord))
/*      */     {
/*  872 */       ReadFormulaRecord rfr = (ReadFormulaRecord)c;
/*  873 */       boolean crossSheetReference = !rfr.handleImportedCellReferences(this.fromSheet.getWorkbook(), this.fromSheet.getWorkbook(), this.workbookSettings);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  878 */       if (crossSheetReference)
/*      */       {
/*      */         try
/*      */         {
/*  882 */           logger.warn("Formula " + rfr.getFormula() + " in cell " + CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow()) + " cannot be imported because it references another " + " sheet from the source workbook");
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         catch (FormulaException e)
/*      */         {
/*      */ 
/*      */ 
/*  891 */           logger.warn("Formula  in cell " + CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow()) + " cannot be imported:  " + e.getMessage());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  898 */         c = new Formula(cell.getColumn(), cell.getRow(), "\"ERROR\"");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  903 */     CellFormat cf = c.getCellFormat();
/*  904 */     int index = ((XFRecord)cf).getXFIndex();
/*  905 */     WritableCellFormat wcf = (WritableCellFormat)this.xfRecords.get(new Integer(index));
/*      */     
/*      */ 
/*  908 */     if (wcf == null)
/*      */     {
/*  910 */       wcf = copyCellFormat(cf);
/*      */     }
/*      */     
/*  913 */     c.setCellFormat(wcf);
/*      */     
/*  915 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void shallowCopyCells()
/*      */   {
/*  924 */     int cells = this.fromSheet.getRows();
/*  925 */     Cell[] row = null;
/*  926 */     Cell cell = null;
/*  927 */     for (int i = 0; i < cells; i++)
/*      */     {
/*  929 */       row = this.fromSheet.getRow(i);
/*      */       
/*  931 */       for (int j = 0; j < row.length; j++)
/*      */       {
/*  933 */         cell = row[j];
/*  934 */         WritableCell c = shallowCopyCell(cell);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/*  943 */           if (c != null)
/*      */           {
/*  945 */             this.toSheet.addCell(c);
/*      */             
/*      */ 
/*      */ 
/*  949 */             if ((c.getCellFeatures() != null) && (c.getCellFeatures().hasDataValidation()))
/*      */             {
/*      */ 
/*  952 */               this.validatedCells.add(c);
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (WriteException e)
/*      */         {
/*  958 */           Assert.verify(false);
/*      */         }
/*      */       }
/*      */     }
/*  962 */     this.numRows = this.toSheet.getRows();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void deepCopyCells()
/*      */   {
/*  971 */     int cells = this.fromSheet.getRows();
/*  972 */     Cell[] row = null;
/*  973 */     Cell cell = null;
/*  974 */     for (int i = 0; i < cells; i++)
/*      */     {
/*  976 */       row = this.fromSheet.getRow(i);
/*      */       
/*  978 */       for (int j = 0; j < row.length; j++)
/*      */       {
/*  980 */         cell = row[j];
/*  981 */         WritableCell c = deepCopyCell(cell);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/*  990 */           if (c != null)
/*      */           {
/*  992 */             this.toSheet.addCell(c);
/*      */             
/*      */ 
/*      */ 
/*  996 */             if ((c.getCellFeatures() != null & c.getCellFeatures().hasDataValidation()))
/*      */             {
/*      */ 
/*  999 */               this.validatedCells.add(c);
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (WriteException e)
/*      */         {
/* 1005 */           Assert.verify(false);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WritableCellFormat copyCellFormat(CellFormat cf)
/*      */   {
/*      */     try
/*      */     {
/* 1024 */       XFRecord xfr = (XFRecord)cf;
/* 1025 */       WritableCellFormat f = new WritableCellFormat(xfr);
/* 1026 */       this.formatRecords.addStyle(f);
/*      */       
/*      */ 
/* 1029 */       int xfIndex = xfr.getXFIndex();
/* 1030 */       this.xfRecords.put(new Integer(xfIndex), f);
/*      */       
/* 1032 */       int fontIndex = xfr.getFontIndex();
/* 1033 */       this.fonts.put(new Integer(fontIndex), new Integer(f.getFontIndex()));
/*      */       
/* 1035 */       int formatIndex = xfr.getFormatRecord();
/* 1036 */       this.formats.put(new Integer(formatIndex), new Integer(f.getFormatRecord()));
/*      */       
/* 1038 */       return f;
/*      */     }
/*      */     catch (NumFormatRecordsException e)
/*      */     {
/* 1042 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*      */     }
/*      */     
/* 1045 */     return WritableWorkbook.NORMAL_STYLE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void importNames()
/*      */   {
/* 1054 */     WorkbookParser fromWorkbook = this.fromSheet.getWorkbook();
/* 1055 */     WritableWorkbook toWorkbook = this.toSheet.getWorkbook();
/* 1056 */     int fromSheetIndex = fromWorkbook.getIndex(this.fromSheet);
/* 1057 */     NameRecord[] nameRecords = fromWorkbook.getNameRecords();
/* 1058 */     String[] names = toWorkbook.getRangeNames();
/*      */     
/* 1060 */     for (int i = 0; i < nameRecords.length; i++)
/*      */     {
/* 1062 */       NameRecord.NameRange[] nameRanges = nameRecords[i].getRanges();
/*      */       
/* 1064 */       for (int j = 0; j < nameRanges.length; j++)
/*      */       {
/* 1066 */         int nameSheetIndex = fromWorkbook.getExternalSheetIndex(nameRanges[j].getExternalSheet());
/*      */         
/*      */ 
/* 1069 */         if (fromSheetIndex == nameSheetIndex)
/*      */         {
/* 1071 */           String name = nameRecords[i].getName();
/* 1072 */           if (Arrays.binarySearch(names, name) < 0)
/*      */           {
/* 1074 */             toWorkbook.addNameArea(name, this.toSheet, nameRanges[j].getFirstColumn(), nameRanges[j].getFirstRow(), nameRanges[j].getLastColumn(), nameRanges[j].getLastRow());
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/* 1083 */             logger.warn("Named range " + name + " is already present in the destination workbook");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getRows()
/*      */   {
/* 1100 */     return this.numRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnOutlineLevel()
/*      */   {
/* 1110 */     return this.maxColumnOutlineLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxRowOutlineLevel()
/*      */   {
/* 1120 */     return this.maxRowOutlineLevel;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SheetCopier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */