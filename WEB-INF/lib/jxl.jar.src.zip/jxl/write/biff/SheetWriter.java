/*      */ package jxl.write.biff;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.TreeSet;
/*      */ import jxl.Cell;
/*      */ import jxl.CellFeatures;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.Range;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.AutoFilter;
/*      */ import jxl.biff.ConditionalFormat;
/*      */ import jxl.biff.DVParser;
/*      */ import jxl.biff.DataValidation;
/*      */ import jxl.biff.DataValiditySettingsRecord;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.XFRecord;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.ComboBox;
/*      */ import jxl.biff.drawing.SheetDrawingWriter;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.Border;
/*      */ import jxl.format.BorderLineStyle;
/*      */ import jxl.format.Colour;
/*      */ import jxl.write.Blank;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableHyperlink;
/*      */ import jxl.write.WriteException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class SheetWriter
/*      */ {
/*   66 */   private static Logger logger = Logger.getLogger(SheetWriter.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private File outputFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private RowRecord[] rows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numRows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numCols;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private HeaderRecord header;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private FooterRecord footer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetSettings settings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookSettings workbookSettings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList rowBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList columnBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList hyperlinks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList conditionalFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AutoFilter autoFilter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList validatedCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DataValidation dataValidation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MergedCells mergedCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PLSRecord plsRecord;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkspaceInformationRecord workspaceOptions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private TreeSet columnFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetDrawingWriter drawingWriter;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean chartOnly;
/*      */   
/*      */ 
/*      */ 
/*      */   private int maxRowOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */   private int maxColumnOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */   private WritableSheetImpl sheet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SheetWriter(File of, WritableSheetImpl wsi, WorkbookSettings ws)
/*      */   {
/*  194 */     this.outputFile = of;
/*  195 */     this.sheet = wsi;
/*  196 */     this.workspaceOptions = new WorkspaceInformationRecord();
/*  197 */     this.workbookSettings = ws;
/*  198 */     this.chartOnly = false;
/*  199 */     this.drawingWriter = new SheetDrawingWriter(ws);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write()
/*      */     throws IOException
/*      */   {
/*  212 */     Assert.verify(this.rows != null);
/*      */     
/*      */ 
/*  215 */     if (this.chartOnly)
/*      */     {
/*  217 */       this.drawingWriter.write(this.outputFile);
/*  218 */       return;
/*      */     }
/*      */     
/*  221 */     BOFRecord bof = new BOFRecord(BOFRecord.sheet);
/*  222 */     this.outputFile.write(bof);
/*      */     
/*      */ 
/*  225 */     int numBlocks = this.numRows / 32;
/*  226 */     if (this.numRows - numBlocks * 32 != 0)
/*      */     {
/*  228 */       numBlocks++;
/*      */     }
/*      */     
/*  231 */     int indexPos = this.outputFile.getPos();
/*      */     
/*      */ 
/*      */ 
/*  235 */     IndexRecord indexRecord = new IndexRecord(0, this.numRows, numBlocks);
/*  236 */     this.outputFile.write(indexRecord);
/*      */     
/*  238 */     if (this.settings.getAutomaticFormulaCalculation())
/*      */     {
/*  240 */       CalcModeRecord cmr = new CalcModeRecord(CalcModeRecord.automatic);
/*  241 */       this.outputFile.write(cmr);
/*      */     }
/*      */     else
/*      */     {
/*  245 */       CalcModeRecord cmr = new CalcModeRecord(CalcModeRecord.manual);
/*  246 */       this.outputFile.write(cmr);
/*      */     }
/*      */     
/*  249 */     CalcCountRecord ccr = new CalcCountRecord(100);
/*  250 */     this.outputFile.write(ccr);
/*      */     
/*  252 */     RefModeRecord rmr = new RefModeRecord();
/*  253 */     this.outputFile.write(rmr);
/*      */     
/*  255 */     IterationRecord itr = new IterationRecord(false);
/*  256 */     this.outputFile.write(itr);
/*      */     
/*  258 */     DeltaRecord dtr = new DeltaRecord(0.001D);
/*  259 */     this.outputFile.write(dtr);
/*      */     
/*  261 */     SaveRecalcRecord srr = new SaveRecalcRecord(this.settings.getRecalculateFormulasBeforeSave());
/*      */     
/*  263 */     this.outputFile.write(srr);
/*      */     
/*  265 */     PrintHeadersRecord phr = new PrintHeadersRecord(this.settings.getPrintHeaders());
/*      */     
/*  267 */     this.outputFile.write(phr);
/*      */     
/*  269 */     PrintGridLinesRecord pglr = new PrintGridLinesRecord(this.settings.getPrintGridLines());
/*      */     
/*  271 */     this.outputFile.write(pglr);
/*      */     
/*  273 */     GridSetRecord gsr = new GridSetRecord(true);
/*  274 */     this.outputFile.write(gsr);
/*      */     
/*  276 */     GuttersRecord gutr = new GuttersRecord();
/*  277 */     gutr.setMaxColumnOutline(this.maxColumnOutlineLevel + 1);
/*  278 */     gutr.setMaxRowOutline(this.maxRowOutlineLevel + 1);
/*      */     
/*  280 */     this.outputFile.write(gutr);
/*      */     
/*  282 */     DefaultRowHeightRecord drhr = new DefaultRowHeightRecord(this.settings.getDefaultRowHeight(), this.settings.getDefaultRowHeight() != 255);
/*      */     
/*      */ 
/*      */ 
/*  286 */     this.outputFile.write(drhr);
/*      */     
/*  288 */     if (this.maxRowOutlineLevel > 0)
/*      */     {
/*  290 */       this.workspaceOptions.setRowOutlines(true);
/*      */     }
/*      */     
/*  293 */     if (this.maxColumnOutlineLevel > 0)
/*      */     {
/*  295 */       this.workspaceOptions.setColumnOutlines(true);
/*      */     }
/*      */     
/*  298 */     this.workspaceOptions.setFitToPages(this.settings.getFitToPages());
/*  299 */     this.outputFile.write(this.workspaceOptions);
/*      */     
/*  301 */     if (this.rowBreaks.size() > 0)
/*      */     {
/*  303 */       int[] rb = new int[this.rowBreaks.size()];
/*      */       
/*  305 */       for (int i = 0; i < rb.length; i++)
/*      */       {
/*  307 */         rb[i] = ((Integer)this.rowBreaks.get(i)).intValue();
/*      */       }
/*      */       
/*  310 */       HorizontalPageBreaksRecord hpbr = new HorizontalPageBreaksRecord(rb);
/*  311 */       this.outputFile.write(hpbr);
/*      */     }
/*      */     
/*  314 */     if (this.columnBreaks.size() > 0)
/*      */     {
/*  316 */       int[] rb = new int[this.columnBreaks.size()];
/*      */       
/*  318 */       for (int i = 0; i < rb.length; i++)
/*      */       {
/*  320 */         rb[i] = ((Integer)this.columnBreaks.get(i)).intValue();
/*      */       }
/*      */       
/*  323 */       VerticalPageBreaksRecord hpbr = new VerticalPageBreaksRecord(rb);
/*  324 */       this.outputFile.write(hpbr);
/*      */     }
/*      */     
/*  327 */     HeaderRecord header = new HeaderRecord(this.settings.getHeader().toString());
/*  328 */     this.outputFile.write(header);
/*      */     
/*  330 */     FooterRecord footer = new FooterRecord(this.settings.getFooter().toString());
/*  331 */     this.outputFile.write(footer);
/*      */     
/*  333 */     HorizontalCentreRecord hcr = new HorizontalCentreRecord(this.settings.isHorizontalCentre());
/*      */     
/*  335 */     this.outputFile.write(hcr);
/*      */     
/*  337 */     VerticalCentreRecord vcr = new VerticalCentreRecord(this.settings.isVerticalCentre());
/*      */     
/*  339 */     this.outputFile.write(vcr);
/*      */     
/*      */ 
/*  342 */     if (this.settings.getLeftMargin() != this.settings.getDefaultWidthMargin())
/*      */     {
/*  344 */       MarginRecord mr = new LeftMarginRecord(this.settings.getLeftMargin());
/*  345 */       this.outputFile.write(mr);
/*      */     }
/*      */     
/*  348 */     if (this.settings.getRightMargin() != this.settings.getDefaultWidthMargin())
/*      */     {
/*  350 */       MarginRecord mr = new RightMarginRecord(this.settings.getRightMargin());
/*  351 */       this.outputFile.write(mr);
/*      */     }
/*      */     
/*  354 */     if (this.settings.getTopMargin() != this.settings.getDefaultHeightMargin())
/*      */     {
/*  356 */       MarginRecord mr = new TopMarginRecord(this.settings.getTopMargin());
/*  357 */       this.outputFile.write(mr);
/*      */     }
/*      */     
/*  360 */     if (this.settings.getBottomMargin() != this.settings.getDefaultHeightMargin())
/*      */     {
/*  362 */       MarginRecord mr = new BottomMarginRecord(this.settings.getBottomMargin());
/*  363 */       this.outputFile.write(mr);
/*      */     }
/*      */     
/*  366 */     if (this.plsRecord != null)
/*      */     {
/*  368 */       this.outputFile.write(this.plsRecord);
/*      */     }
/*      */     
/*  371 */     SetupRecord setup = new SetupRecord(this.settings);
/*  372 */     this.outputFile.write(setup);
/*      */     
/*  374 */     if (this.settings.isProtected())
/*      */     {
/*  376 */       ProtectRecord pr = new ProtectRecord(this.settings.isProtected());
/*  377 */       this.outputFile.write(pr);
/*      */       
/*  379 */       ScenarioProtectRecord spr = new ScenarioProtectRecord(this.settings.isProtected());
/*      */       
/*  381 */       this.outputFile.write(spr);
/*      */       
/*  383 */       ObjectProtectRecord opr = new ObjectProtectRecord(this.settings.isProtected());
/*      */       
/*  385 */       this.outputFile.write(opr);
/*      */       
/*  387 */       if (this.settings.getPassword() != null)
/*      */       {
/*  389 */         PasswordRecord pw = new PasswordRecord(this.settings.getPassword());
/*  390 */         this.outputFile.write(pw);
/*      */       }
/*  392 */       else if (this.settings.getPasswordHash() != 0)
/*      */       {
/*  394 */         PasswordRecord pw = new PasswordRecord(this.settings.getPasswordHash());
/*  395 */         this.outputFile.write(pw);
/*      */       }
/*      */     }
/*      */     
/*  399 */     indexRecord.setDataStartPosition(this.outputFile.getPos());
/*  400 */     DefaultColumnWidth dcw = new DefaultColumnWidth(this.settings.getDefaultColumnWidth());
/*      */     
/*  402 */     this.outputFile.write(dcw);
/*      */     
/*      */ 
/*  405 */     WritableCellFormat normalStyle = this.sheet.getWorkbook().getStyles().getNormalStyle();
/*      */     
/*  407 */     WritableCellFormat defaultDateFormat = this.sheet.getWorkbook().getStyles().getDefaultDateFormat();
/*      */     
/*      */ 
/*      */ 
/*  411 */     ColumnInfoRecord cir = null;
/*  412 */     for (Iterator colit = this.columnFormats.iterator(); colit.hasNext();)
/*      */     {
/*  414 */       cir = (ColumnInfoRecord)colit.next();
/*      */       
/*      */ 
/*  417 */       if (cir.getColumn() < 256)
/*      */       {
/*  419 */         this.outputFile.write(cir);
/*      */       }
/*      */       
/*  422 */       XFRecord xfr = cir.getCellFormat();
/*      */       
/*  424 */       if ((xfr != normalStyle) && (cir.getColumn() < 256))
/*      */       {
/*      */ 
/*  427 */         Cell[] cells = getColumn(cir.getColumn());
/*      */         
/*  429 */         for (int i = 0; i < cells.length; i++)
/*      */         {
/*  431 */           if ((cells[i] != null) && ((cells[i].getCellFormat() == normalStyle) || (cells[i].getCellFormat() == defaultDateFormat)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  437 */             ((WritableCell)cells[i]).setCellFormat(xfr);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  444 */     if (this.autoFilter != null)
/*      */     {
/*  446 */       this.autoFilter.write(this.outputFile);
/*      */     }
/*      */     
/*  449 */     DimensionRecord dr = new DimensionRecord(this.numRows, this.numCols);
/*  450 */     this.outputFile.write(dr);
/*      */     
/*      */ 
/*  453 */     for (int block = 0; block < numBlocks; block++)
/*      */     {
/*  455 */       DBCellRecord dbcell = new DBCellRecord(this.outputFile.getPos());
/*      */       
/*  457 */       int blockRows = Math.min(32, this.numRows - block * 32);
/*  458 */       boolean firstRow = true;
/*      */       
/*      */ 
/*  461 */       for (int i = block * 32; i < block * 32 + blockRows; i++)
/*      */       {
/*  463 */         if (this.rows[i] != null)
/*      */         {
/*  465 */           this.rows[i].write(this.outputFile);
/*  466 */           if (firstRow)
/*      */           {
/*  468 */             dbcell.setCellOffset(this.outputFile.getPos());
/*  469 */             firstRow = false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  475 */       for (int i = block * 32; i < block * 32 + blockRows; i++)
/*      */       {
/*  477 */         if (this.rows[i] != null)
/*      */         {
/*  479 */           dbcell.addCellRowPosition(this.outputFile.getPos());
/*  480 */           this.rows[i].writeCells(this.outputFile);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  485 */       indexRecord.addBlockPosition(this.outputFile.getPos());
/*      */       
/*      */ 
/*      */ 
/*  489 */       dbcell.setPosition(this.outputFile.getPos());
/*  490 */       this.outputFile.write(dbcell);
/*      */     }
/*      */     
/*      */ 
/*  494 */     if (!this.workbookSettings.getDrawingsDisabled())
/*      */     {
/*  496 */       this.drawingWriter.write(this.outputFile);
/*      */     }
/*      */     
/*  499 */     Window2Record w2r = new Window2Record(this.settings);
/*  500 */     this.outputFile.write(w2r);
/*      */     
/*      */ 
/*  503 */     if ((this.settings.getHorizontalFreeze() != 0) || (this.settings.getVerticalFreeze() != 0))
/*      */     {
/*      */ 
/*  506 */       PaneRecord pr = new PaneRecord(this.settings.getHorizontalFreeze(), this.settings.getVerticalFreeze());
/*      */       
/*  508 */       this.outputFile.write(pr);
/*      */       
/*      */ 
/*  511 */       SelectionRecord sr = new SelectionRecord(SelectionRecord.upperLeft, 0, 0);
/*      */       
/*  513 */       this.outputFile.write(sr);
/*      */       
/*      */ 
/*  516 */       if (this.settings.getHorizontalFreeze() != 0)
/*      */       {
/*  518 */         sr = new SelectionRecord(SelectionRecord.upperRight, this.settings.getHorizontalFreeze(), 0);
/*      */         
/*  520 */         this.outputFile.write(sr);
/*      */       }
/*      */       
/*      */ 
/*  524 */       if (this.settings.getVerticalFreeze() != 0)
/*      */       {
/*  526 */         sr = new SelectionRecord(SelectionRecord.lowerLeft, 0, this.settings.getVerticalFreeze());
/*      */         
/*  528 */         this.outputFile.write(sr);
/*      */       }
/*      */       
/*      */ 
/*  532 */       if ((this.settings.getHorizontalFreeze() != 0) && (this.settings.getVerticalFreeze() != 0))
/*      */       {
/*      */ 
/*  535 */         sr = new SelectionRecord(SelectionRecord.lowerRight, this.settings.getHorizontalFreeze(), this.settings.getVerticalFreeze());
/*      */         
/*      */ 
/*      */ 
/*  539 */         this.outputFile.write(sr);
/*      */       }
/*      */       
/*  542 */       Weird1Record w1r = new Weird1Record();
/*  543 */       this.outputFile.write(w1r);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  549 */       SelectionRecord sr = new SelectionRecord(SelectionRecord.upperLeft, 0, 0);
/*      */       
/*  551 */       this.outputFile.write(sr);
/*      */     }
/*      */     
/*      */ 
/*  555 */     if (this.settings.getZoomFactor() != 100)
/*      */     {
/*  557 */       SCLRecord sclr = new SCLRecord(this.settings.getZoomFactor());
/*  558 */       this.outputFile.write(sclr);
/*      */     }
/*      */     
/*      */ 
/*  562 */     this.mergedCells.write(this.outputFile);
/*      */     
/*      */ 
/*  565 */     Iterator hi = this.hyperlinks.iterator();
/*  566 */     WritableHyperlink hlr = null;
/*  567 */     while (hi.hasNext())
/*      */     {
/*  569 */       hlr = (WritableHyperlink)hi.next();
/*  570 */       this.outputFile.write(hlr);
/*      */     }
/*      */     
/*  573 */     if (this.buttonPropertySet != null)
/*      */     {
/*  575 */       this.outputFile.write(this.buttonPropertySet);
/*      */     }
/*      */     
/*      */ 
/*  579 */     if ((this.dataValidation != null) || (this.validatedCells.size() > 0))
/*      */     {
/*  581 */       writeDataValidation();
/*      */     }
/*      */     
/*      */     Iterator i;
/*  585 */     if ((this.conditionalFormats != null) && (this.conditionalFormats.size() > 0))
/*      */     {
/*  587 */       for (i = this.conditionalFormats.iterator(); i.hasNext();)
/*      */       {
/*  589 */         ConditionalFormat cf = (ConditionalFormat)i.next();
/*  590 */         cf.write(this.outputFile);
/*      */       }
/*      */     }
/*      */     
/*  594 */     EOFRecord eof = new EOFRecord();
/*  595 */     this.outputFile.write(eof);
/*      */     
/*      */ 
/*      */ 
/*  599 */     this.outputFile.setData(indexRecord.getData(), indexPos + 4);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final HeaderRecord getHeader()
/*      */   {
/*  609 */     return this.header;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final FooterRecord getFooter()
/*      */   {
/*  619 */     return this.footer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setWriteData(RowRecord[] rws, ArrayList rb, ArrayList cb, ArrayList hl, MergedCells mc, TreeSet cf, int mrol, int mcol)
/*      */   {
/*  637 */     this.rows = rws;
/*  638 */     this.rowBreaks = rb;
/*  639 */     this.columnBreaks = cb;
/*  640 */     this.hyperlinks = hl;
/*  641 */     this.mergedCells = mc;
/*  642 */     this.columnFormats = cf;
/*  643 */     this.maxRowOutlineLevel = mrol;
/*  644 */     this.maxColumnOutlineLevel = mcol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDimensions(int rws, int cls)
/*      */   {
/*  656 */     this.numRows = rws;
/*  657 */     this.numCols = cls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setSettings(SheetSettings sr)
/*      */   {
/*  668 */     this.settings = sr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   WorkspaceInformationRecord getWorkspaceOptions()
/*      */   {
/*  678 */     return this.workspaceOptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setWorkspaceOptions(WorkspaceInformationRecord wo)
/*      */   {
/*  688 */     if (wo != null)
/*      */     {
/*  690 */       this.workspaceOptions = wo;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setCharts(Chart[] ch)
/*      */   {
/*  702 */     this.drawingWriter.setCharts(ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDrawings(ArrayList dr, boolean mod)
/*      */   {
/*  713 */     this.drawingWriter.setDrawings(dr, mod);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Chart[] getCharts()
/*      */   {
/*  723 */     return this.drawingWriter.getCharts();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkMergedBorders()
/*      */   {
/*  734 */     Range[] mcells = this.mergedCells.getMergedCells();
/*  735 */     ArrayList borderFormats = new ArrayList();
/*  736 */     for (int mci = 0; mci < mcells.length; mci++)
/*      */     {
/*  738 */       Range range = mcells[mci];
/*  739 */       Cell topLeft = range.getTopLeft();
/*  740 */       XFRecord tlformat = (XFRecord)topLeft.getCellFormat();
/*      */       
/*  742 */       if ((tlformat != null) && (tlformat.hasBorders() == true) && (!tlformat.isRead()))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/*      */ 
/*  748 */           CellXFRecord cf1 = new CellXFRecord(tlformat);
/*  749 */           Cell bottomRight = range.getBottomRight();
/*      */           
/*  751 */           cf1.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  752 */           cf1.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*      */           
/*      */ 
/*  755 */           cf1.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*      */           
/*      */ 
/*      */ 
/*  759 */           if (topLeft.getRow() == bottomRight.getRow())
/*      */           {
/*  761 */             cf1.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  766 */           if (topLeft.getColumn() == bottomRight.getColumn())
/*      */           {
/*  768 */             cf1.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  773 */           int index = borderFormats.indexOf(cf1);
/*  774 */           if (index != -1)
/*      */           {
/*  776 */             cf1 = (CellXFRecord)borderFormats.get(index);
/*      */           }
/*      */           else
/*      */           {
/*  780 */             borderFormats.add(cf1);
/*      */           }
/*  782 */           ((WritableCell)topLeft).setCellFormat(cf1);
/*      */           
/*      */ 
/*  785 */           if (bottomRight.getRow() > topLeft.getRow())
/*      */           {
/*      */ 
/*  788 */             if (bottomRight.getColumn() != topLeft.getColumn())
/*      */             {
/*  790 */               CellXFRecord cf2 = new CellXFRecord(tlformat);
/*  791 */               cf2.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  792 */               cf2.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*      */               
/*      */ 
/*  795 */               cf2.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*      */               
/*      */ 
/*      */ 
/*  799 */               index = borderFormats.indexOf(cf2);
/*  800 */               if (index != -1)
/*      */               {
/*  802 */                 cf2 = (CellXFRecord)borderFormats.get(index);
/*      */               }
/*      */               else
/*      */               {
/*  806 */                 borderFormats.add(cf2);
/*      */               }
/*      */               
/*  809 */               this.sheet.addCell(new Blank(topLeft.getColumn(), bottomRight.getRow(), cf2));
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  815 */             for (int i = topLeft.getRow() + 1; i < bottomRight.getRow(); i++)
/*      */             {
/*  817 */               CellXFRecord cf3 = new CellXFRecord(tlformat);
/*  818 */               cf3.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  819 */               cf3.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*      */               
/*      */ 
/*      */ 
/*  823 */               if (topLeft.getColumn() == bottomRight.getColumn())
/*      */               {
/*  825 */                 cf3.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*  830 */               index = borderFormats.indexOf(cf3);
/*  831 */               if (index != -1)
/*      */               {
/*  833 */                 cf3 = (CellXFRecord)borderFormats.get(index);
/*      */               }
/*      */               else
/*      */               {
/*  837 */                 borderFormats.add(cf3);
/*      */               }
/*      */               
/*  840 */               this.sheet.addCell(new Blank(topLeft.getColumn(), i, cf3));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  845 */           if (bottomRight.getColumn() > topLeft.getColumn())
/*      */           {
/*  847 */             if (bottomRight.getRow() != topLeft.getRow())
/*      */             {
/*      */ 
/*  850 */               CellXFRecord cf6 = new CellXFRecord(tlformat);
/*  851 */               cf6.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  852 */               cf6.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*      */               
/*      */ 
/*  855 */               cf6.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*      */               
/*      */ 
/*  858 */               index = borderFormats.indexOf(cf6);
/*  859 */               if (index != -1)
/*      */               {
/*  861 */                 cf6 = (CellXFRecord)borderFormats.get(index);
/*      */               }
/*      */               else
/*      */               {
/*  865 */                 borderFormats.add(cf6);
/*      */               }
/*      */               
/*  868 */               this.sheet.addCell(new Blank(bottomRight.getColumn(), topLeft.getRow(), cf6));
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  873 */             for (int i = topLeft.getRow() + 1; 
/*  874 */                 i < bottomRight.getRow(); i++)
/*      */             {
/*  876 */               CellXFRecord cf7 = new CellXFRecord(tlformat);
/*  877 */               cf7.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  878 */               cf7.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*      */               
/*      */ 
/*      */ 
/*  882 */               index = borderFormats.indexOf(cf7);
/*  883 */               if (index != -1)
/*      */               {
/*  885 */                 cf7 = (CellXFRecord)borderFormats.get(index);
/*      */               }
/*      */               else
/*      */               {
/*  889 */                 borderFormats.add(cf7);
/*      */               }
/*      */               
/*  892 */               this.sheet.addCell(new Blank(bottomRight.getColumn(), i, cf7));
/*      */             }
/*      */             
/*      */ 
/*  896 */             for (int i = topLeft.getColumn() + 1; 
/*  897 */                 i < bottomRight.getColumn(); i++)
/*      */             {
/*  899 */               CellXFRecord cf8 = new CellXFRecord(tlformat);
/*  900 */               cf8.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  901 */               cf8.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*      */               
/*      */ 
/*      */ 
/*  905 */               if (topLeft.getRow() == bottomRight.getRow())
/*      */               {
/*  907 */                 cf8.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*  912 */               index = borderFormats.indexOf(cf8);
/*  913 */               if (index != -1)
/*      */               {
/*  915 */                 cf8 = (CellXFRecord)borderFormats.get(index);
/*      */               }
/*      */               else
/*      */               {
/*  919 */                 borderFormats.add(cf8);
/*      */               }
/*      */               
/*  922 */               this.sheet.addCell(new Blank(i, topLeft.getRow(), cf8));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  927 */           if ((bottomRight.getColumn() > topLeft.getColumn()) || (bottomRight.getRow() > topLeft.getRow()))
/*      */           {
/*      */ 
/*      */ 
/*  931 */             CellXFRecord cf4 = new CellXFRecord(tlformat);
/*  932 */             cf4.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  933 */             cf4.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*      */             
/*      */ 
/*  936 */             cf4.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*      */             
/*      */ 
/*      */ 
/*  940 */             if (bottomRight.getRow() == topLeft.getRow())
/*      */             {
/*  942 */               cf4.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  947 */             if (bottomRight.getColumn() == topLeft.getColumn())
/*      */             {
/*  949 */               cf4.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  954 */             index = borderFormats.indexOf(cf4);
/*  955 */             if (index != -1)
/*      */             {
/*  957 */               cf4 = (CellXFRecord)borderFormats.get(index);
/*      */             }
/*      */             else
/*      */             {
/*  961 */               borderFormats.add(cf4);
/*      */             }
/*      */             
/*  964 */             this.sheet.addCell(new Blank(bottomRight.getColumn(), bottomRight.getRow(), cf4));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  969 */             for (int i = topLeft.getColumn() + 1; 
/*  970 */                 i < bottomRight.getColumn(); i++)
/*      */             {
/*  972 */               CellXFRecord cf5 = new CellXFRecord(tlformat);
/*  973 */               cf5.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/*  974 */               cf5.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*      */               
/*      */ 
/*      */ 
/*  978 */               if (topLeft.getRow() == bottomRight.getRow())
/*      */               {
/*  980 */                 cf5.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*  985 */               index = borderFormats.indexOf(cf5);
/*  986 */               if (index != -1)
/*      */               {
/*  988 */                 cf5 = (CellXFRecord)borderFormats.get(index);
/*      */               }
/*      */               else
/*      */               {
/*  992 */                 borderFormats.add(cf5);
/*      */               }
/*      */               
/*  995 */               this.sheet.addCell(new Blank(i, bottomRight.getRow(), cf5));
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */         catch (WriteException e)
/*      */         {
/* 1002 */           logger.warn(e.toString());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Cell[] getColumn(int col)
/*      */   {
/* 1016 */     boolean found = false;
/* 1017 */     int row = this.numRows - 1;
/*      */     
/* 1019 */     while ((row >= 0) && (!found))
/*      */     {
/* 1021 */       if ((this.rows[row] != null) && (this.rows[row].getCell(col) != null))
/*      */       {
/*      */ 
/* 1024 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/* 1028 */         row--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1033 */     Cell[] cells = new Cell[row + 1];
/*      */     
/* 1035 */     for (int i = 0; i <= row; i++)
/*      */     {
/* 1037 */       cells[i] = (this.rows[i] != null ? this.rows[i].getCell(col) : null);
/*      */     }
/*      */     
/* 1040 */     return cells;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void setChartOnly()
/*      */   {
/* 1048 */     this.chartOnly = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setPLS(PLSRecord pls)
/*      */   {
/* 1058 */     this.plsRecord = pls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setButtonPropertySet(ButtonPropertySetRecord bps)
/*      */   {
/* 1068 */     this.buttonPropertySet = bps;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDataValidation(DataValidation dv, ArrayList vc)
/*      */   {
/* 1079 */     this.dataValidation = dv;
/* 1080 */     this.validatedCells = vc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setConditionalFormats(ArrayList cf)
/*      */   {
/* 1090 */     this.conditionalFormats = cf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setAutoFilter(AutoFilter af)
/*      */   {
/* 1100 */     this.autoFilter = af;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void writeDataValidation()
/*      */     throws IOException
/*      */   {
/* 1108 */     if ((this.dataValidation != null) && (this.validatedCells.size() == 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1113 */       this.dataValidation.write(this.outputFile);
/* 1114 */       return;
/*      */     }
/*      */     
/* 1117 */     if ((this.dataValidation == null) && (this.validatedCells.size() > 0))
/*      */     {
/*      */ 
/*      */ 
/* 1121 */       int comboBoxId = this.sheet.getComboBox() != null ? this.sheet.getComboBox().getObjectId() : -1;
/*      */       
/* 1123 */       this.dataValidation = new DataValidation(comboBoxId, this.sheet.getWorkbook(), this.sheet.getWorkbook(), this.workbookSettings);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1129 */     for (Iterator i = this.validatedCells.iterator(); i.hasNext();)
/*      */     {
/* 1131 */       CellValue cv = (CellValue)i.next();
/* 1132 */       CellFeatures cf = cv.getCellFeatures();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1137 */       if (!cf.getDVParser().copied())
/*      */       {
/* 1139 */         if (!cf.getDVParser().extendedCellsValidation())
/*      */         {
/*      */ 
/* 1142 */           DataValiditySettingsRecord dvsr = new DataValiditySettingsRecord(cf.getDVParser());
/*      */           
/* 1144 */           this.dataValidation.add(dvsr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1150 */         else if ((cv.getColumn() == cf.getDVParser().getFirstColumn()) && (cv.getRow() == cf.getDVParser().getFirstRow()))
/*      */         {
/*      */ 
/* 1153 */           DataValiditySettingsRecord dvsr = new DataValiditySettingsRecord(cf.getDVParser());
/*      */           
/* 1155 */           this.dataValidation.add(dvsr);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1160 */     this.dataValidation.write(this.outputFile);
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SheetWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */