/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SortRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private String column1Name;
/*     */   private String column2Name;
/*     */   private String column3Name;
/*     */   private boolean sortColumns;
/*     */   private boolean sortKey1Desc;
/*     */   private boolean sortKey2Desc;
/*     */   private boolean sortKey3Desc;
/*     */   private boolean sortCaseSensitive;
/*     */   
/*     */   public SortRecord(String a, String b, String c, boolean sc, boolean sk1d, boolean sk2d, boolean sk3d, boolean scs)
/*     */   {
/*  56 */     super(Type.SORT);
/*     */     
/*  58 */     this.column1Name = a;
/*  59 */     this.column2Name = b;
/*  60 */     this.column3Name = c;
/*  61 */     this.sortColumns = sc;
/*  62 */     this.sortKey1Desc = sk1d;
/*  63 */     this.sortKey2Desc = sk2d;
/*  64 */     this.sortKey3Desc = sk3d;
/*  65 */     this.sortCaseSensitive = scs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  75 */     int byteCount = 5 + this.column1Name.length() * 2 + 1;
/*  76 */     if (this.column2Name.length() > 0)
/*  77 */       byteCount += this.column2Name.length() * 2 + 1;
/*  78 */     if (this.column3Name.length() > 0)
/*  79 */       byteCount += this.column3Name.length() * 2 + 1;
/*  80 */     byte[] data = new byte[byteCount + 1];
/*     */     
/*  82 */     int optionFlag = 0;
/*  83 */     if (this.sortColumns)
/*  84 */       optionFlag |= 0x1;
/*  85 */     if (this.sortKey1Desc)
/*  86 */       optionFlag |= 0x2;
/*  87 */     if (this.sortKey2Desc)
/*  88 */       optionFlag |= 0x4;
/*  89 */     if (this.sortKey3Desc)
/*  90 */       optionFlag |= 0x8;
/*  91 */     if (this.sortCaseSensitive) {
/*  92 */       optionFlag |= 0x10;
/*     */     }
/*  94 */     data[0] = ((byte)optionFlag);
/*     */     
/*  96 */     data[2] = ((byte)this.column1Name.length());
/*  97 */     data[3] = ((byte)this.column2Name.length());
/*  98 */     data[4] = ((byte)this.column3Name.length());
/*     */     
/* 100 */     data[5] = 1;
/* 101 */     StringHelper.getUnicodeBytes(this.column1Name, data, 6);
/* 102 */     int curPos = 6 + this.column1Name.length() * 2;
/* 103 */     if (this.column2Name.length() > 0)
/*     */     {
/* 105 */       data[(curPos++)] = 1;
/* 106 */       StringHelper.getUnicodeBytes(this.column2Name, data, curPos);
/* 107 */       curPos += this.column2Name.length() * 2;
/*     */     }
/* 109 */     if (this.column3Name.length() > 0)
/*     */     {
/* 111 */       data[(curPos++)] = 1;
/* 112 */       StringHelper.getUnicodeBytes(this.column3Name, data, curPos);
/* 113 */       curPos += this.column3Name.length() * 2;
/*     */     }
/*     */     
/* 116 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SortRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */