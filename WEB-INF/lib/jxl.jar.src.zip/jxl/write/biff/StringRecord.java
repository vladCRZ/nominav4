/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private String value;
/*    */   
/*    */   public StringRecord(String val)
/*    */   {
/* 43 */     super(Type.STRING);
/*    */     
/* 45 */     this.value = val;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 55 */     byte[] data = new byte[this.value.length() * 2 + 3];
/* 56 */     IntegerHelper.getTwoBytes(this.value.length(), data, 0);
/* 57 */     data[2] = 1;
/* 58 */     StringHelper.getUnicodeBytes(this.value, data, 3);
/*    */     
/* 60 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\StringRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */