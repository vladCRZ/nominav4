/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.DisplayFormat;
/*    */ import jxl.biff.FontRecord;
/*    */ import jxl.biff.XFRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StyleXFRecord
/*    */   extends XFRecord
/*    */ {
/*    */   public StyleXFRecord(FontRecord fnt, DisplayFormat form)
/*    */   {
/* 39 */     super(fnt, form);
/*    */     
/* 41 */     setXFDetails(XFRecord.style, 65520);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void setCellOptions(int opt)
/*    */   {
/* 53 */     super.setXFCellOptions(opt);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setLocked(boolean l)
/*    */   {
/* 64 */     super.setXFLocked(l);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\StyleXFRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */