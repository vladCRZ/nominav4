/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.common.Logger;
/*     */ import jxl.write.DateFormat;
/*     */ import jxl.write.DateFormats;
/*     */ import jxl.write.NumberFormats;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableFont;
/*     */ import jxl.write.WritableWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Styles
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(Styles.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableFont arial10pt;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableFont hyperlinkFont;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCellFormat normalStyle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCellFormat hyperlinkStyle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCellFormat hiddenStyle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCellFormat defaultDateFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Styles()
/*     */   {
/*  79 */     this.arial10pt = null;
/*  80 */     this.hyperlinkFont = null;
/*  81 */     this.normalStyle = null;
/*  82 */     this.hyperlinkStyle = null;
/*  83 */     this.hiddenStyle = null;
/*     */   }
/*     */   
/*     */   private synchronized void initNormalStyle()
/*     */   {
/*  88 */     this.normalStyle = new WritableCellFormat(getArial10Pt(), NumberFormats.DEFAULT);
/*     */     
/*  90 */     this.normalStyle.setFont(getArial10Pt());
/*     */   }
/*     */   
/*     */   public WritableCellFormat getNormalStyle()
/*     */   {
/*  95 */     if (this.normalStyle == null)
/*     */     {
/*  97 */       initNormalStyle();
/*     */     }
/*     */     
/* 100 */     return this.normalStyle;
/*     */   }
/*     */   
/*     */   private synchronized void initHiddenStyle()
/*     */   {
/* 105 */     this.hiddenStyle = new WritableCellFormat(getArial10Pt(), new DateFormat(";;;"));
/*     */   }
/*     */   
/*     */ 
/*     */   public WritableCellFormat getHiddenStyle()
/*     */   {
/* 111 */     if (this.hiddenStyle == null)
/*     */     {
/* 113 */       initHiddenStyle();
/*     */     }
/*     */     
/* 116 */     return this.hiddenStyle;
/*     */   }
/*     */   
/*     */   private synchronized void initHyperlinkStyle()
/*     */   {
/* 121 */     this.hyperlinkStyle = new WritableCellFormat(getHyperlinkFont(), NumberFormats.DEFAULT);
/*     */   }
/*     */   
/*     */ 
/*     */   public WritableCellFormat getHyperlinkStyle()
/*     */   {
/* 127 */     if (this.hyperlinkStyle == null)
/*     */     {
/* 129 */       initHyperlinkStyle();
/*     */     }
/*     */     
/* 132 */     return this.hyperlinkStyle;
/*     */   }
/*     */   
/*     */   private synchronized void initArial10Pt()
/*     */   {
/* 137 */     this.arial10pt = new WritableFont(WritableWorkbook.ARIAL_10_PT);
/*     */   }
/*     */   
/*     */   public WritableFont getArial10Pt()
/*     */   {
/* 142 */     if (this.arial10pt == null)
/*     */     {
/* 144 */       initArial10Pt();
/*     */     }
/*     */     
/* 147 */     return this.arial10pt;
/*     */   }
/*     */   
/*     */   private synchronized void initHyperlinkFont()
/*     */   {
/* 152 */     this.hyperlinkFont = new WritableFont(WritableWorkbook.HYPERLINK_FONT);
/*     */   }
/*     */   
/*     */   public WritableFont getHyperlinkFont()
/*     */   {
/* 157 */     if (this.hyperlinkFont == null)
/*     */     {
/* 159 */       initHyperlinkFont();
/*     */     }
/*     */     
/* 162 */     return this.hyperlinkFont;
/*     */   }
/*     */   
/*     */   private synchronized void initDefaultDateFormat()
/*     */   {
/* 167 */     this.defaultDateFormat = new WritableCellFormat(DateFormats.DEFAULT);
/*     */   }
/*     */   
/*     */   public WritableCellFormat getDefaultDateFormat()
/*     */   {
/* 172 */     if (this.defaultDateFormat == null)
/*     */     {
/* 174 */       initDefaultDateFormat();
/*     */     }
/*     */     
/* 177 */     return this.defaultDateFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XFRecord getFormat(XFRecord wf)
/*     */   {
/* 192 */     XFRecord format = wf;
/*     */     
/*     */ 
/*     */ 
/* 196 */     if (format == WritableWorkbook.NORMAL_STYLE)
/*     */     {
/* 198 */       format = getNormalStyle();
/*     */     }
/* 200 */     else if (format == WritableWorkbook.HYPERLINK_STYLE)
/*     */     {
/* 202 */       format = getHyperlinkStyle();
/*     */     }
/* 204 */     else if (format == WritableWorkbook.HIDDEN_STYLE)
/*     */     {
/* 206 */       format = getHiddenStyle();
/*     */     }
/* 208 */     else if (format == DateRecord.defaultDateFormat)
/*     */     {
/* 210 */       format = getDefaultDateFormat();
/*     */     }
/*     */     
/*     */ 
/* 214 */     if (format.getFont() == WritableWorkbook.ARIAL_10_PT)
/*     */     {
/* 216 */       format.setFont(getArial10Pt());
/*     */     }
/* 218 */     else if (format.getFont() == WritableWorkbook.HYPERLINK_FONT)
/*     */     {
/* 220 */       format.setFont(getHyperlinkFont());
/*     */     }
/*     */     
/* 223 */     return format;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\Styles.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */