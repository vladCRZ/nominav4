/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.EncodedURLHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SupbookRecord
/*     */   extends WritableRecordData
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(SupbookRecord.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SupbookType type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int numSheets;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fileName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] sheetNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   public static final SupbookType INTERNAL = new SupbookType(null);
/*  79 */   public static final SupbookType EXTERNAL = new SupbookType(null);
/*  80 */   public static final SupbookType ADDIN = new SupbookType(null);
/*  81 */   public static final SupbookType LINK = new SupbookType(null);
/*  82 */   public static final SupbookType UNKNOWN = new SupbookType(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupbookRecord()
/*     */   {
/*  89 */     super(Type.SUPBOOK);
/*  90 */     this.type = ADDIN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupbookRecord(int sheets, WorkbookSettings ws)
/*     */   {
/*  98 */     super(Type.SUPBOOK);
/*     */     
/* 100 */     this.numSheets = sheets;
/* 101 */     this.type = INTERNAL;
/* 102 */     this.workbookSettings = ws;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupbookRecord(String fn, WorkbookSettings ws)
/*     */   {
/* 113 */     super(Type.SUPBOOK);
/*     */     
/* 115 */     this.fileName = fn;
/* 116 */     this.numSheets = 1;
/* 117 */     this.sheetNames = new String[0];
/* 118 */     this.workbookSettings = ws;
/*     */     
/* 120 */     this.type = EXTERNAL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupbookRecord(jxl.read.biff.SupbookRecord sr, WorkbookSettings ws)
/*     */   {
/* 128 */     super(Type.SUPBOOK);
/*     */     
/* 130 */     this.workbookSettings = ws;
/* 131 */     if (sr.getType() == jxl.read.biff.SupbookRecord.INTERNAL)
/*     */     {
/* 133 */       this.type = INTERNAL;
/* 134 */       this.numSheets = sr.getNumberOfSheets();
/*     */     }
/* 136 */     else if (sr.getType() == jxl.read.biff.SupbookRecord.EXTERNAL)
/*     */     {
/* 138 */       this.type = EXTERNAL;
/* 139 */       this.numSheets = sr.getNumberOfSheets();
/* 140 */       this.fileName = sr.getFileName();
/* 141 */       this.sheetNames = new String[this.numSheets];
/*     */       
/* 143 */       for (int i = 0; i < this.numSheets; i++)
/*     */       {
/* 145 */         this.sheetNames[i] = sr.getSheetName(i);
/*     */       }
/*     */     }
/*     */     
/* 149 */     if (sr.getType() == jxl.read.biff.SupbookRecord.ADDIN)
/*     */     {
/* 151 */       logger.warn("Supbook type is addin");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initInternal(jxl.read.biff.SupbookRecord sr)
/*     */   {
/* 162 */     this.numSheets = sr.getNumberOfSheets();
/* 163 */     initInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initInternal()
/*     */   {
/* 171 */     this.data = new byte[4];
/*     */     
/* 173 */     IntegerHelper.getTwoBytes(this.numSheets, this.data, 0);
/* 174 */     this.data[2] = 1;
/* 175 */     this.data[3] = 4;
/* 176 */     this.type = INTERNAL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void adjustInternal(int sheets)
/*     */   {
/* 187 */     Assert.verify(this.type == INTERNAL);
/* 188 */     this.numSheets = sheets;
/* 189 */     initInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initExternal()
/*     */   {
/* 197 */     int totalSheetNameLength = 0;
/* 198 */     for (int i = 0; i < this.numSheets; i++)
/*     */     {
/* 200 */       totalSheetNameLength += this.sheetNames[i].length();
/*     */     }
/*     */     
/* 203 */     byte[] fileNameData = EncodedURLHelper.getEncodedURL(this.fileName, this.workbookSettings);
/*     */     
/* 205 */     int dataLength = 6 + fileNameData.length + this.numSheets * 3 + totalSheetNameLength * 2;
/*     */     
/*     */ 
/*     */ 
/* 209 */     this.data = new byte[dataLength];
/*     */     
/* 211 */     IntegerHelper.getTwoBytes(this.numSheets, this.data, 0);
/*     */     
/*     */ 
/*     */ 
/* 215 */     int pos = 2;
/* 216 */     IntegerHelper.getTwoBytes(fileNameData.length + 1, this.data, pos);
/* 217 */     this.data[(pos + 2)] = 0;
/* 218 */     this.data[(pos + 3)] = 1;
/* 219 */     System.arraycopy(fileNameData, 0, this.data, pos + 4, fileNameData.length);
/*     */     
/* 221 */     pos += 4 + fileNameData.length;
/*     */     
/*     */ 
/* 224 */     for (int i = 0; i < this.sheetNames.length; i++)
/*     */     {
/* 226 */       IntegerHelper.getTwoBytes(this.sheetNames[i].length(), this.data, pos);
/* 227 */       this.data[(pos + 2)] = 1;
/* 228 */       StringHelper.getUnicodeBytes(this.sheetNames[i], this.data, pos + 3);
/* 229 */       pos += 3 + this.sheetNames[i].length() * 2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initAddin()
/*     */   {
/* 238 */     this.data = new byte[] { 1, 0, 1, 58 };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 248 */     if (this.type == INTERNAL)
/*     */     {
/* 250 */       initInternal();
/*     */     }
/* 252 */     else if (this.type == EXTERNAL)
/*     */     {
/* 254 */       initExternal();
/*     */     }
/* 256 */     else if (this.type == ADDIN)
/*     */     {
/* 258 */       initAddin();
/*     */     }
/*     */     else
/*     */     {
/* 262 */       logger.warn("unsupported supbook type - defaulting to internal");
/* 263 */       initInternal();
/*     */     }
/*     */     
/* 266 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupbookType getType()
/*     */   {
/* 276 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfSheets()
/*     */   {
/* 287 */     return this.numSheets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileName()
/*     */   {
/* 297 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSheetIndex(String s)
/*     */   {
/* 308 */     boolean found = false;
/* 309 */     int sheetIndex = 0;
/* 310 */     for (int i = 0; (i < this.sheetNames.length) && (!found); i++)
/*     */     {
/* 312 */       if (this.sheetNames[i].equals(s))
/*     */       {
/* 314 */         found = true;
/* 315 */         sheetIndex = 0;
/*     */       }
/*     */     }
/*     */     
/* 319 */     if (found)
/*     */     {
/* 321 */       return sheetIndex;
/*     */     }
/*     */     
/*     */ 
/* 325 */     String[] names = new String[this.sheetNames.length + 1];
/* 326 */     System.arraycopy(this.sheetNames, 0, names, 0, this.sheetNames.length);
/* 327 */     names[this.sheetNames.length] = s;
/* 328 */     this.sheetNames = names;
/* 329 */     return this.sheetNames.length - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSheetName(int s)
/*     */   {
/* 339 */     return this.sheetNames[s];
/*     */   }
/*     */   
/*     */   private static class SupbookType {}
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\SupbookRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */