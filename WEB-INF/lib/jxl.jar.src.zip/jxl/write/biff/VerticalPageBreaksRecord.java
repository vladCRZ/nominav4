/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VerticalPageBreaksRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int[] columnBreaks;
/*    */   
/*    */   public VerticalPageBreaksRecord(int[] breaks)
/*    */   {
/* 43 */     super(Type.VERTICALPAGEBREAKS);
/*    */     
/* 45 */     this.columnBreaks = breaks;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 55 */     byte[] data = new byte[this.columnBreaks.length * 6 + 2];
/*    */     
/*    */ 
/* 58 */     IntegerHelper.getTwoBytes(this.columnBreaks.length, data, 0);
/* 59 */     int pos = 2;
/*    */     
/* 61 */     for (int i = 0; i < this.columnBreaks.length; i++)
/*    */     {
/* 63 */       IntegerHelper.getTwoBytes(this.columnBreaks[i], data, pos);
/* 64 */       IntegerHelper.getTwoBytes(255, data, pos + 4);
/* 65 */       pos += 6;
/*    */     }
/*    */     
/* 68 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\VerticalPageBreaksRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */