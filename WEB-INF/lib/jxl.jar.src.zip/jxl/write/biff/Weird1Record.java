/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Weird1Record
/*    */   extends WritableRecordData
/*    */ {
/*    */   public Weird1Record()
/*    */   {
/* 35 */     super(Type.WEIRD1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 45 */     byte[] data = new byte[6];
/*    */     
/* 47 */     data[2] = 55;
/*    */     
/* 49 */     return data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\Weird1Record.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */