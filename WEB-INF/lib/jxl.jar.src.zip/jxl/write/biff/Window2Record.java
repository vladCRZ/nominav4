/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.SheetSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Window2Record
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   
/*     */   public Window2Record(SheetSettings settings)
/*     */   {
/*  42 */     super(Type.WINDOW2);
/*     */     
/*  44 */     int options = 0;
/*     */     
/*  46 */     options |= 0x0;
/*     */     
/*  48 */     if (settings.getShowGridLines())
/*     */     {
/*  50 */       options |= 0x2;
/*     */     }
/*     */     
/*  53 */     options |= 0x4;
/*     */     
/*  55 */     options |= 0x0;
/*     */     
/*  57 */     if (settings.getDisplayZeroValues())
/*     */     {
/*  59 */       options |= 0x10;
/*     */     }
/*     */     
/*  62 */     options |= 0x20;
/*     */     
/*  64 */     options |= 0x80;
/*     */     
/*     */ 
/*  67 */     if ((settings.getHorizontalFreeze() != 0) || (settings.getVerticalFreeze() != 0))
/*     */     {
/*     */ 
/*  70 */       options |= 0x8;
/*  71 */       options |= 0x100;
/*     */     }
/*     */     
/*     */ 
/*  75 */     if (settings.isSelected())
/*     */     {
/*  77 */       options |= 0x600;
/*     */     }
/*     */     
/*     */ 
/*  81 */     if (settings.getPageBreakPreviewMode())
/*     */     {
/*  83 */       options |= 0x800;
/*     */     }
/*     */     
/*     */ 
/*  87 */     this.data = new byte[18];
/*  88 */     IntegerHelper.getTwoBytes(options, this.data, 0);
/*  89 */     IntegerHelper.getTwoBytes(64, this.data, 6);
/*  90 */     IntegerHelper.getTwoBytes(settings.getPageBreakPreviewMagnification(), this.data, 10);
/*     */     
/*  92 */     IntegerHelper.getTwoBytes(settings.getNormalMagnification(), this.data, 12);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 104 */     return this.data;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\Window2Record.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */