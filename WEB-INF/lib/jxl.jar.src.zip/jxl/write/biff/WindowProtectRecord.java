/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WindowProtectRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean protection;
/*    */   private byte[] data;
/*    */   
/*    */   public WindowProtectRecord(boolean prot)
/*    */   {
/* 47 */     super(Type.WINDOWPROTECT);
/*    */     
/* 49 */     this.protection = prot;
/*    */     
/* 51 */     this.data = new byte[2];
/*    */     
/* 53 */     if (this.protection)
/*    */     {
/* 55 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 66 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WindowProtectRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */