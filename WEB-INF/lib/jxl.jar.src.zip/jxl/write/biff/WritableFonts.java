/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Fonts;
/*    */ import jxl.write.WritableFont;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WritableFonts
/*    */   extends Fonts
/*    */ {
/*    */   public WritableFonts(WritableWorkbookImpl w)
/*    */   {
/* 39 */     addFont(w.getStyles().getArial10Pt());
/*    */     
/*    */ 
/* 42 */     WritableFont f = new WritableFont(WritableFont.ARIAL);
/* 43 */     addFont(f);
/*    */     
/* 45 */     f = new WritableFont(WritableFont.ARIAL);
/* 46 */     addFont(f);
/*    */     
/* 48 */     f = new WritableFont(WritableFont.ARIAL);
/* 49 */     addFont(f);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WritableFonts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */