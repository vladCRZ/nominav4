/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.Fonts;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.NumFormatRecordsException;
/*     */ import jxl.common.Assert;
/*     */ import jxl.write.NumberFormats;
/*     */ import jxl.write.WritableCellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableFormattingRecords
/*     */   extends FormattingRecords
/*     */ {
/*     */   public static WritableCellFormat normalStyle;
/*     */   
/*     */   public WritableFormattingRecords(Fonts f, Styles styles)
/*     */   {
/*  52 */     super(f);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  57 */       StyleXFRecord sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/*  59 */       sxf.setLocked(true);
/*  60 */       addStyle(sxf);
/*     */       
/*  62 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.DEFAULT);
/*  63 */       sxf.setLocked(true);
/*  64 */       sxf.setCellOptions(62464);
/*  65 */       addStyle(sxf);
/*     */       
/*  67 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.DEFAULT);
/*  68 */       sxf.setLocked(true);
/*  69 */       sxf.setCellOptions(62464);
/*  70 */       addStyle(sxf);
/*     */       
/*  72 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.DEFAULT);
/*  73 */       sxf.setLocked(true);
/*  74 */       sxf.setCellOptions(62464);
/*  75 */       addStyle(sxf);
/*     */       
/*  77 */       sxf = new StyleXFRecord(getFonts().getFont(2), NumberFormats.DEFAULT);
/*  78 */       sxf.setLocked(true);
/*  79 */       sxf.setCellOptions(62464);
/*  80 */       addStyle(sxf);
/*     */       
/*  82 */       sxf = new StyleXFRecord(getFonts().getFont(3), NumberFormats.DEFAULT);
/*  83 */       sxf.setLocked(true);
/*  84 */       sxf.setCellOptions(62464);
/*  85 */       addStyle(sxf);
/*     */       
/*  87 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/*  89 */       sxf.setLocked(true);
/*  90 */       sxf.setCellOptions(62464);
/*  91 */       addStyle(sxf);
/*     */       
/*  93 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/*  95 */       sxf.setLocked(true);
/*  96 */       sxf.setCellOptions(62464);
/*  97 */       addStyle(sxf);
/*     */       
/*  99 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 101 */       sxf.setLocked(true);
/* 102 */       sxf.setCellOptions(62464);
/* 103 */       addStyle(sxf);
/*     */       
/* 105 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 107 */       sxf.setLocked(true);
/* 108 */       sxf.setCellOptions(62464);
/* 109 */       addStyle(sxf);
/*     */       
/* 111 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 113 */       sxf.setLocked(true);
/* 114 */       sxf.setCellOptions(62464);
/* 115 */       addStyle(sxf);
/*     */       
/* 117 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 119 */       sxf.setLocked(true);
/* 120 */       sxf.setCellOptions(62464);
/* 121 */       addStyle(sxf);
/*     */       
/* 123 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 125 */       sxf.setLocked(true);
/* 126 */       sxf.setCellOptions(62464);
/* 127 */       addStyle(sxf);
/*     */       
/* 129 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 131 */       sxf.setLocked(true);
/* 132 */       sxf.setCellOptions(62464);
/* 133 */       addStyle(sxf);
/*     */       
/* 135 */       sxf = new StyleXFRecord(styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 137 */       sxf.setLocked(true);
/* 138 */       sxf.setCellOptions(62464);
/* 139 */       addStyle(sxf);
/*     */       
/*     */ 
/*     */ 
/* 143 */       addStyle(styles.getNormalStyle());
/*     */       
/*     */ 
/* 146 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT7);
/*     */       
/* 148 */       sxf.setLocked(true);
/* 149 */       sxf.setCellOptions(63488);
/* 150 */       addStyle(sxf);
/*     */       
/* 152 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT5);
/*     */       
/* 154 */       sxf.setLocked(true);
/* 155 */       sxf.setCellOptions(63488);
/* 156 */       addStyle(sxf);
/*     */       
/* 158 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT8);
/*     */       
/* 160 */       sxf.setLocked(true);
/* 161 */       sxf.setCellOptions(63488);
/* 162 */       addStyle(sxf);
/*     */       
/* 164 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT6);
/*     */       
/* 166 */       sxf.setLocked(true);
/* 167 */       sxf.setCellOptions(63488);
/* 168 */       addStyle(sxf);
/*     */       
/* 170 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.PERCENT_INTEGER);
/*     */       
/* 172 */       sxf.setLocked(true);
/* 173 */       sxf.setCellOptions(63488);
/* 174 */       addStyle(sxf);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NumFormatRecordsException e)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */       Assert.verify(false, e.getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WritableFormattingRecords.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */