/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ import jxl.BooleanCell;
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.LabelCell;
/*     */ import jxl.NumberCell;
/*     */ import jxl.Range;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.DataValidation;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.NumFormatRecordsException;
/*     */ import jxl.biff.SheetRangeImpl;
/*     */ import jxl.biff.WorkspaceInformationRecord;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.biff.drawing.Drawing;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.common.Assert;
/*     */ import jxl.common.Logger;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.Blank;
/*     */ import jxl.write.Boolean;
/*     */ import jxl.write.DateTime;
/*     */ import jxl.write.Formula;
/*     */ import jxl.write.Label;
/*     */ import jxl.write.Number;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableHyperlink;
/*     */ import jxl.write.WritableImage;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WritableSheetCopier
/*     */ {
/*  87 */   private static Logger logger = Logger.getLogger(SheetCopier.class);
/*     */   
/*     */   private WritableSheetImpl fromSheet;
/*     */   
/*     */   private WritableSheetImpl toSheet;
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */   
/*     */   private TreeSet fromColumnFormats;
/*     */   
/*     */   private TreeSet toColumnFormats;
/*     */   
/*     */   private MergedCells fromMergedCells;
/*     */   
/*     */   private MergedCells toMergedCells;
/*     */   
/*     */   private RowRecord[] fromRows;
/*     */   
/*     */   private ArrayList fromRowBreaks;
/*     */   private ArrayList fromColumnBreaks;
/*     */   private ArrayList toRowBreaks;
/*     */   private ArrayList toColumnBreaks;
/*     */   private DataValidation fromDataValidation;
/*     */   private DataValidation toDataValidation;
/*     */   private SheetWriter sheetWriter;
/*     */   private ArrayList fromDrawings;
/*     */   private ArrayList toDrawings;
/*     */   private ArrayList toImages;
/*     */   private WorkspaceInformationRecord fromWorkspaceOptions;
/*     */   private PLSRecord fromPLSRecord;
/*     */   private PLSRecord toPLSRecord;
/*     */   private ButtonPropertySetRecord fromButtonPropertySet;
/*     */   private ButtonPropertySetRecord toButtonPropertySet;
/*     */   private ArrayList fromHyperlinks;
/*     */   private ArrayList toHyperlinks;
/*     */   private ArrayList validatedCells;
/*     */   private int numRows;
/*     */   private int maxRowOutlineLevel;
/*     */   private int maxColumnOutlineLevel;
/*     */   private boolean chartOnly;
/*     */   private FormattingRecords formatRecords;
/*     */   private HashMap xfRecords;
/*     */   private HashMap fonts;
/*     */   private HashMap formats;
/*     */   
/*     */   public WritableSheetCopier(WritableSheet f, WritableSheet t)
/*     */   {
/* 134 */     this.fromSheet = ((WritableSheetImpl)f);
/* 135 */     this.toSheet = ((WritableSheetImpl)t);
/* 136 */     this.workbookSettings = this.toSheet.getWorkbook().getSettings();
/* 137 */     this.chartOnly = false;
/*     */   }
/*     */   
/*     */   void setColumnFormats(TreeSet fcf, TreeSet tcf)
/*     */   {
/* 142 */     this.fromColumnFormats = fcf;
/* 143 */     this.toColumnFormats = tcf;
/*     */   }
/*     */   
/*     */   void setMergedCells(MergedCells fmc, MergedCells tmc)
/*     */   {
/* 148 */     this.fromMergedCells = fmc;
/* 149 */     this.toMergedCells = tmc;
/*     */   }
/*     */   
/*     */   void setRows(RowRecord[] r)
/*     */   {
/* 154 */     this.fromRows = r;
/*     */   }
/*     */   
/*     */   void setValidatedCells(ArrayList vc)
/*     */   {
/* 159 */     this.validatedCells = vc;
/*     */   }
/*     */   
/*     */   void setRowBreaks(ArrayList frb, ArrayList trb)
/*     */   {
/* 164 */     this.fromRowBreaks = frb;
/* 165 */     this.toRowBreaks = trb;
/*     */   }
/*     */   
/*     */   void setColumnBreaks(ArrayList fcb, ArrayList tcb)
/*     */   {
/* 170 */     this.fromColumnBreaks = fcb;
/* 171 */     this.toColumnBreaks = tcb;
/*     */   }
/*     */   
/*     */   void setDrawings(ArrayList fd, ArrayList td, ArrayList ti)
/*     */   {
/* 176 */     this.fromDrawings = fd;
/* 177 */     this.toDrawings = td;
/* 178 */     this.toImages = ti;
/*     */   }
/*     */   
/*     */   void setHyperlinks(ArrayList fh, ArrayList th)
/*     */   {
/* 183 */     this.fromHyperlinks = fh;
/* 184 */     this.toHyperlinks = th;
/*     */   }
/*     */   
/*     */   void setWorkspaceOptions(WorkspaceInformationRecord wir)
/*     */   {
/* 189 */     this.fromWorkspaceOptions = wir;
/*     */   }
/*     */   
/*     */   void setDataValidation(DataValidation dv)
/*     */   {
/* 194 */     this.fromDataValidation = dv;
/*     */   }
/*     */   
/*     */   void setPLSRecord(PLSRecord plsr)
/*     */   {
/* 199 */     this.fromPLSRecord = plsr;
/*     */   }
/*     */   
/*     */   void setButtonPropertySetRecord(ButtonPropertySetRecord bpsr)
/*     */   {
/* 204 */     this.fromButtonPropertySet = bpsr;
/*     */   }
/*     */   
/*     */   void setSheetWriter(SheetWriter sw)
/*     */   {
/* 209 */     this.sheetWriter = sw;
/*     */   }
/*     */   
/*     */ 
/*     */   DataValidation getDataValidation()
/*     */   {
/* 215 */     return this.toDataValidation;
/*     */   }
/*     */   
/*     */   PLSRecord getPLSRecord()
/*     */   {
/* 220 */     return this.toPLSRecord;
/*     */   }
/*     */   
/*     */   boolean isChartOnly()
/*     */   {
/* 225 */     return this.chartOnly;
/*     */   }
/*     */   
/*     */   ButtonPropertySetRecord getButtonPropertySet()
/*     */   {
/* 230 */     return this.toButtonPropertySet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copySheet()
/*     */   {
/* 239 */     shallowCopyCells();
/*     */     
/*     */ 
/* 242 */     Iterator cfit = this.fromColumnFormats.iterator();
/* 243 */     while (cfit.hasNext())
/*     */     {
/* 245 */       ColumnInfoRecord cv = new ColumnInfoRecord((ColumnInfoRecord)cfit.next());
/*     */       
/* 247 */       this.toColumnFormats.add(cv);
/*     */     }
/*     */     
/*     */ 
/* 251 */     Range[] merged = this.fromMergedCells.getMergedCells();
/*     */     
/* 253 */     for (int i = 0; i < merged.length; i++)
/*     */     {
/* 255 */       this.toMergedCells.add(new SheetRangeImpl((SheetRangeImpl)merged[i], this.toSheet));
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 261 */       RowRecord row = null;
/* 262 */       RowRecord newRow = null;
/* 263 */       for (int i = 0; i < this.fromRows.length; i++)
/*     */       {
/* 265 */         row = this.fromRows[i];
/*     */         
/* 267 */         if ((row != null) && ((!row.isDefaultHeight()) || (row.isCollapsed())))
/*     */         {
/*     */ 
/*     */ 
/* 271 */           newRow = this.toSheet.getRowRecord(i);
/* 272 */           newRow.setRowDetails(row.getRowHeight(), row.matchesDefaultFontHeight(), row.isCollapsed(), row.getOutlineLevel(), row.getGroupStart(), row.getStyle());
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (RowsExceededException e)
/*     */     {
/*     */ 
/* 285 */       Assert.verify(false);
/*     */     }
/*     */     
/*     */ 
/* 289 */     this.toRowBreaks = new ArrayList(this.fromRowBreaks);
/*     */     
/*     */ 
/* 292 */     this.toColumnBreaks = new ArrayList(this.fromColumnBreaks);
/*     */     
/*     */ 
/* 295 */     if (this.fromDataValidation != null)
/*     */     {
/* 297 */       this.toDataValidation = new DataValidation(this.fromDataValidation, this.toSheet.getWorkbook(), this.toSheet.getWorkbook(), this.toSheet.getWorkbook().getSettings());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */     this.sheetWriter.setCharts(this.fromSheet.getCharts());
/*     */     
/*     */ 
/* 308 */     for (Iterator i = this.fromDrawings.iterator(); i.hasNext();)
/*     */     {
/* 310 */       Object o = i.next();
/* 311 */       if ((o instanceof Drawing))
/*     */       {
/* 313 */         WritableImage wi = new WritableImage((Drawing)o, this.toSheet.getWorkbook().getDrawingGroup());
/*     */         
/*     */ 
/* 316 */         this.toDrawings.add(wi);
/* 317 */         this.toImages.add(wi);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 325 */     this.sheetWriter.setWorkspaceOptions(this.fromWorkspaceOptions);
/*     */     
/*     */ 
/* 328 */     if (this.fromPLSRecord != null)
/*     */     {
/* 330 */       this.toPLSRecord = new PLSRecord(this.fromPLSRecord);
/*     */     }
/*     */     
/*     */ 
/* 334 */     if (this.fromButtonPropertySet != null)
/*     */     {
/* 336 */       this.toButtonPropertySet = new ButtonPropertySetRecord(this.fromButtonPropertySet);
/*     */     }
/*     */     
/*     */ 
/* 340 */     for (Iterator i = this.fromHyperlinks.iterator(); i.hasNext();)
/*     */     {
/* 342 */       WritableHyperlink hr = new WritableHyperlink((WritableHyperlink)i.next(), this.toSheet);
/*     */       
/* 344 */       this.toHyperlinks.add(hr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCell shallowCopyCell(Cell cell)
/*     */   {
/* 353 */     CellType ct = cell.getType();
/* 354 */     WritableCell newCell = null;
/*     */     
/* 356 */     if (ct == CellType.LABEL)
/*     */     {
/* 358 */       newCell = new Label((LabelCell)cell);
/*     */     }
/* 360 */     else if (ct == CellType.NUMBER)
/*     */     {
/* 362 */       newCell = new Number((NumberCell)cell);
/*     */     }
/* 364 */     else if (ct == CellType.DATE)
/*     */     {
/* 366 */       newCell = new DateTime((DateCell)cell);
/*     */     }
/* 368 */     else if (ct == CellType.BOOLEAN)
/*     */     {
/* 370 */       newCell = new Boolean((BooleanCell)cell);
/*     */     }
/* 372 */     else if (ct == CellType.NUMBER_FORMULA)
/*     */     {
/* 374 */       newCell = new ReadNumberFormulaRecord((FormulaData)cell);
/*     */     }
/* 376 */     else if (ct == CellType.STRING_FORMULA)
/*     */     {
/* 378 */       newCell = new ReadStringFormulaRecord((FormulaData)cell);
/*     */     }
/* 380 */     else if (ct == CellType.BOOLEAN_FORMULA)
/*     */     {
/* 382 */       newCell = new ReadBooleanFormulaRecord((FormulaData)cell);
/*     */     }
/* 384 */     else if (ct == CellType.DATE_FORMULA)
/*     */     {
/* 386 */       newCell = new ReadDateFormulaRecord((FormulaData)cell);
/*     */     }
/* 388 */     else if (ct == CellType.FORMULA_ERROR)
/*     */     {
/* 390 */       newCell = new ReadErrorFormulaRecord((FormulaData)cell);
/*     */     }
/* 392 */     else if (ct == CellType.EMPTY)
/*     */     {
/* 394 */       if (cell.getCellFormat() != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 399 */         newCell = new Blank(cell);
/*     */       }
/*     */     }
/*     */     
/* 403 */     return newCell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCell deepCopyCell(Cell cell)
/*     */   {
/* 413 */     WritableCell c = shallowCopyCell(cell);
/*     */     
/* 415 */     if (c == null)
/*     */     {
/* 417 */       return c;
/*     */     }
/*     */     
/* 420 */     if ((c instanceof ReadFormulaRecord))
/*     */     {
/* 422 */       ReadFormulaRecord rfr = (ReadFormulaRecord)c;
/* 423 */       boolean crossSheetReference = !rfr.handleImportedCellReferences(this.fromSheet.getWorkbook(), this.fromSheet.getWorkbook(), this.workbookSettings);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 428 */       if (crossSheetReference)
/*     */       {
/*     */         try
/*     */         {
/* 432 */           logger.warn("Formula " + rfr.getFormula() + " in cell " + CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow()) + " cannot be imported because it references another " + " sheet from the source workbook");
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (FormulaException e)
/*     */         {
/*     */ 
/*     */ 
/* 441 */           logger.warn("Formula  in cell " + CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow()) + " cannot be imported:  " + e.getMessage());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 448 */         c = new Formula(cell.getColumn(), cell.getRow(), "\"ERROR\"");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 453 */     CellFormat cf = c.getCellFormat();
/* 454 */     int index = ((XFRecord)cf).getXFIndex();
/* 455 */     WritableCellFormat wcf = (WritableCellFormat)this.xfRecords.get(new Integer(index));
/*     */     
/*     */ 
/* 458 */     if (wcf == null)
/*     */     {
/* 460 */       wcf = copyCellFormat(cf);
/*     */     }
/*     */     
/* 463 */     c.setCellFormat(wcf);
/*     */     
/* 465 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void shallowCopyCells()
/*     */   {
/* 474 */     int cells = this.fromSheet.getRows();
/* 475 */     Cell[] row = null;
/* 476 */     Cell cell = null;
/* 477 */     for (int i = 0; i < cells; i++)
/*     */     {
/* 479 */       row = this.fromSheet.getRow(i);
/*     */       
/* 481 */       for (int j = 0; j < row.length; j++)
/*     */       {
/* 483 */         cell = row[j];
/* 484 */         WritableCell c = shallowCopyCell(cell);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 493 */           if (c != null)
/*     */           {
/* 495 */             this.toSheet.addCell(c);
/*     */             
/*     */ 
/*     */ 
/* 499 */             if ((c.getCellFeatures() != null & c.getCellFeatures().hasDataValidation()))
/*     */             {
/*     */ 
/* 502 */               this.validatedCells.add(c);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (WriteException e)
/*     */         {
/* 508 */           Assert.verify(false);
/*     */         }
/*     */       }
/*     */     }
/* 512 */     this.numRows = this.toSheet.getRows();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void deepCopyCells()
/*     */   {
/* 521 */     int cells = this.fromSheet.getRows();
/* 522 */     Cell[] row = null;
/* 523 */     Cell cell = null;
/* 524 */     for (int i = 0; i < cells; i++)
/*     */     {
/* 526 */       row = this.fromSheet.getRow(i);
/*     */       
/* 528 */       for (int j = 0; j < row.length; j++)
/*     */       {
/* 530 */         cell = row[j];
/* 531 */         WritableCell c = deepCopyCell(cell);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 540 */           if (c != null)
/*     */           {
/* 542 */             this.toSheet.addCell(c);
/*     */             
/*     */ 
/*     */ 
/* 546 */             if ((c.getCellFeatures() != null & c.getCellFeatures().hasDataValidation()))
/*     */             {
/*     */ 
/* 549 */               this.validatedCells.add(c);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (WriteException e)
/*     */         {
/* 555 */           Assert.verify(false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WritableCellFormat copyCellFormat(CellFormat cf)
/*     */   {
/*     */     try
/*     */     {
/* 574 */       XFRecord xfr = (XFRecord)cf;
/* 575 */       WritableCellFormat f = new WritableCellFormat(xfr);
/* 576 */       this.formatRecords.addStyle(f);
/*     */       
/*     */ 
/* 579 */       int xfIndex = xfr.getXFIndex();
/* 580 */       this.xfRecords.put(new Integer(xfIndex), f);
/*     */       
/* 582 */       int fontIndex = xfr.getFontIndex();
/* 583 */       this.fonts.put(new Integer(fontIndex), new Integer(f.getFontIndex()));
/*     */       
/* 585 */       int formatIndex = xfr.getFormatRecord();
/* 586 */       this.formats.put(new Integer(formatIndex), new Integer(f.getFormatRecord()));
/*     */       
/* 588 */       return f;
/*     */     }
/*     */     catch (NumFormatRecordsException e)
/*     */     {
/* 592 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*     */     }
/*     */     
/* 595 */     return WritableWorkbook.NORMAL_STYLE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxColumnOutlineLevel()
/*     */   {
/* 607 */     return this.maxColumnOutlineLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxRowOutlineLevel()
/*     */   {
/* 617 */     return this.maxRowOutlineLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WritableSheetCopier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */