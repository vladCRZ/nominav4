/*      */ package jxl.write.biff;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.TreeSet;
/*      */ import java.util.regex.Pattern;
/*      */ import jxl.Cell;
/*      */ import jxl.CellFeatures;
/*      */ import jxl.CellReferenceHelper;
/*      */ import jxl.CellType;
/*      */ import jxl.CellView;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.HeaderFooter.Contents;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.Image;
/*      */ import jxl.LabelCell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.AutoFilter;
/*      */ import jxl.biff.CellFinder;
/*      */ import jxl.biff.ConditionalFormat;
/*      */ import jxl.biff.DVParser;
/*      */ import jxl.biff.DataValidation;
/*      */ import jxl.biff.EmptyCell;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.IndexMapping;
/*      */ import jxl.biff.NumFormatRecordsException;
/*      */ import jxl.biff.SheetRangeImpl;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.XFRecord;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.ComboBox;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingGroup;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.format.Font;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ import jxl.write.Blank;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFeatures;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableHyperlink;
/*      */ import jxl.write.WritableImage;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ import jxl.write.WriteException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class WritableSheetImpl
/*      */   implements WritableSheet
/*      */ {
/*   94 */   private static Logger logger = Logger.getLogger(WritableSheetImpl.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private File outputFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private RowRecord[] rows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormattingRecords formatRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SharedStrings sharedStrings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private TreeSet columnFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private TreeSet autosizedColumns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList hyperlinks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MergedCells mergedCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numRows;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int numColumns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private PLSRecord plsRecord;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean chartOnly;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DataValidation dataValidation;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList rowBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList columnBreaks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList drawings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList images;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList conditionalFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AutoFilter autoFilter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList validatedCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ComboBox comboBox;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean drawingsModified;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxRowOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxColumnOutlineLevel;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetSettings settings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SheetWriter sheetWriter;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookSettings workbookSettings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WritableWorkbookImpl workbook;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int rowGrowSize = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int numRowsPerSheet = 65536;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int maxSheetNameLength = 31;
/*      */   
/*      */ 
/*      */ 
/*  263 */   private static final char[] illegalSheetNameCharacters = { '*', ':', '?', '\\' };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  269 */   private static final String[] imageTypes = { "png" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class ColumnInfoComparator
/*      */     implements Comparator
/*      */   {
/*      */     public boolean equals(Object o)
/*      */     {
/*  284 */       return o == this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int compare(Object o1, Object o2)
/*      */     {
/*  296 */       if (o1 == o2)
/*      */       {
/*  298 */         return 0;
/*      */       }
/*      */       
/*  301 */       Assert.verify(o1 instanceof ColumnInfoRecord);
/*  302 */       Assert.verify(o2 instanceof ColumnInfoRecord);
/*      */       
/*  304 */       ColumnInfoRecord ci1 = (ColumnInfoRecord)o1;
/*  305 */       ColumnInfoRecord ci2 = (ColumnInfoRecord)o2;
/*      */       
/*  307 */       return ci1.getColumn() - ci2.getColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheetImpl(String n, File of, FormattingRecords fr, SharedStrings ss, WorkbookSettings ws, WritableWorkbookImpl ww)
/*      */   {
/*  328 */     this.name = validateName(n);
/*  329 */     this.outputFile = of;
/*  330 */     this.rows = new RowRecord[0];
/*  331 */     this.numRows = 0;
/*  332 */     this.numColumns = 0;
/*  333 */     this.chartOnly = false;
/*  334 */     this.workbook = ww;
/*      */     
/*  336 */     this.formatRecords = fr;
/*  337 */     this.sharedStrings = ss;
/*  338 */     this.workbookSettings = ws;
/*  339 */     this.drawingsModified = false;
/*  340 */     this.columnFormats = new TreeSet(new ColumnInfoComparator(null));
/*  341 */     this.autosizedColumns = new TreeSet();
/*  342 */     this.hyperlinks = new ArrayList();
/*  343 */     this.mergedCells = new MergedCells(this);
/*  344 */     this.rowBreaks = new ArrayList();
/*  345 */     this.columnBreaks = new ArrayList();
/*  346 */     this.drawings = new ArrayList();
/*  347 */     this.images = new ArrayList();
/*  348 */     this.conditionalFormats = new ArrayList();
/*  349 */     this.validatedCells = new ArrayList();
/*  350 */     this.settings = new SheetSettings(this);
/*      */     
/*      */ 
/*  353 */     this.sheetWriter = new SheetWriter(this.outputFile, this, this.workbookSettings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell getCell(String loc)
/*      */   {
/*  367 */     return getCell(CellReferenceHelper.getColumn(loc), CellReferenceHelper.getRow(loc));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell getCell(int column, int row)
/*      */   {
/*  380 */     return getWritableCell(column, row);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableCell getWritableCell(String loc)
/*      */   {
/*  395 */     return getWritableCell(CellReferenceHelper.getColumn(loc), CellReferenceHelper.getRow(loc));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableCell getWritableCell(int column, int row)
/*      */   {
/*  408 */     WritableCell c = null;
/*      */     
/*  410 */     if ((row < this.rows.length) && (this.rows[row] != null))
/*      */     {
/*  412 */       c = this.rows[row].getCell(column);
/*      */     }
/*      */     
/*  415 */     if (c == null)
/*      */     {
/*  417 */       c = new EmptyCell(column, row);
/*      */     }
/*      */     
/*  420 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRows()
/*      */   {
/*  430 */     return this.numRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumns()
/*      */   {
/*  440 */     return this.numColumns;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCell(String contents)
/*      */   {
/*  454 */     CellFinder cellFinder = new CellFinder(this);
/*  455 */     return cellFinder.findCell(contents);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCell(String contents, int firstCol, int firstRow, int lastCol, int lastRow, boolean reverse)
/*      */   {
/*  479 */     CellFinder cellFinder = new CellFinder(this);
/*  480 */     return cellFinder.findCell(contents, firstCol, firstRow, lastCol, lastRow, reverse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell findCell(Pattern pattern, int firstCol, int firstRow, int lastCol, int lastRow, boolean reverse)
/*      */   {
/*  509 */     CellFinder cellFinder = new CellFinder(this);
/*  510 */     return cellFinder.findCell(pattern, firstCol, firstRow, lastCol, lastRow, reverse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LabelCell findLabelCell(String contents)
/*      */   {
/*  532 */     CellFinder cellFinder = new CellFinder(this);
/*  533 */     return cellFinder.findLabelCell(contents);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell[] getRow(int row)
/*      */   {
/*  545 */     boolean found = false;
/*  546 */     int col = this.numColumns - 1;
/*  547 */     while ((col >= 0) && (!found))
/*      */     {
/*  549 */       if (getCell(col, row).getType() != CellType.EMPTY)
/*      */       {
/*  551 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/*  555 */         col--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  560 */     Cell[] cells = new Cell[col + 1];
/*      */     
/*  562 */     for (int i = 0; i <= col; i++)
/*      */     {
/*  564 */       cells[i] = getCell(i, row);
/*      */     }
/*  566 */     return cells;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cell[] getColumn(int col)
/*      */   {
/*  578 */     boolean found = false;
/*  579 */     int row = this.numRows - 1;
/*      */     
/*  581 */     while ((row >= 0) && (!found))
/*      */     {
/*  583 */       if (getCell(col, row).getType() != CellType.EMPTY)
/*      */       {
/*  585 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/*  589 */         row--;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  594 */     Cell[] cells = new Cell[row + 1];
/*      */     
/*  596 */     for (int i = 0; i <= row; i++)
/*      */     {
/*  598 */       cells[i] = getCell(col, i);
/*      */     }
/*  600 */     return cells;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  610 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertRow(int row)
/*      */   {
/*  621 */     if ((row < 0) || (row >= this.numRows))
/*      */     {
/*  623 */       return;
/*      */     }
/*      */     
/*      */ 
/*  627 */     RowRecord[] oldRows = this.rows;
/*      */     
/*  629 */     if (this.numRows == this.rows.length)
/*      */     {
/*  631 */       this.rows = new RowRecord[oldRows.length + 10];
/*      */     }
/*      */     else
/*      */     {
/*  635 */       this.rows = new RowRecord[oldRows.length];
/*      */     }
/*      */     
/*      */ 
/*  639 */     System.arraycopy(oldRows, 0, this.rows, 0, row);
/*      */     
/*      */ 
/*  642 */     System.arraycopy(oldRows, row, this.rows, row + 1, this.numRows - row);
/*      */     
/*      */ 
/*  645 */     for (int i = row + 1; i <= this.numRows; i++)
/*      */     {
/*  647 */       if (this.rows[i] != null)
/*      */       {
/*  649 */         this.rows[i].incrementRow();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  654 */     HyperlinkRecord hr = null;
/*  655 */     Iterator i = this.hyperlinks.iterator();
/*  656 */     while (i.hasNext())
/*      */     {
/*  658 */       hr = (HyperlinkRecord)i.next();
/*  659 */       hr.insertRow(row);
/*      */     }
/*      */     
/*      */ 
/*  663 */     if (this.dataValidation != null)
/*      */     {
/*  665 */       this.dataValidation.insertRow(row);
/*      */     }
/*      */     Iterator vci;
/*  668 */     if ((this.validatedCells != null) && (this.validatedCells.size() > 0))
/*      */     {
/*  670 */       for (vci = this.validatedCells.iterator(); vci.hasNext();)
/*      */       {
/*  672 */         CellValue cv = (CellValue)vci.next();
/*  673 */         CellFeatures cf = cv.getCellFeatures();
/*  674 */         if (cf.getDVParser() != null)
/*      */         {
/*  676 */           cf.getDVParser().insertRow(row);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  682 */     this.mergedCells.insertRow(row);
/*      */     
/*      */ 
/*  685 */     ArrayList newRowBreaks = new ArrayList();
/*  686 */     Iterator ri = this.rowBreaks.iterator();
/*  687 */     while (ri.hasNext())
/*      */     {
/*  689 */       int val = ((Integer)ri.next()).intValue();
/*  690 */       if (val >= row)
/*      */       {
/*  692 */         val++;
/*      */       }
/*      */       
/*  695 */       newRowBreaks.add(new Integer(val));
/*      */     }
/*  697 */     this.rowBreaks = newRowBreaks;
/*      */     
/*      */ 
/*  700 */     for (Iterator cfit = this.conditionalFormats.iterator(); cfit.hasNext();)
/*      */     {
/*  702 */       ConditionalFormat cf = (ConditionalFormat)cfit.next();
/*  703 */       cf.insertRow(row);
/*      */     }
/*      */     
/*      */ 
/*  707 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  709 */       this.workbook.rowInserted(this, row);
/*      */     }
/*      */     
/*      */ 
/*  713 */     this.numRows += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertColumn(int col)
/*      */   {
/*  726 */     if ((col < 0) || (col >= this.numColumns))
/*      */     {
/*  728 */       return;
/*      */     }
/*      */     
/*      */ 
/*  732 */     for (int i = 0; i < this.numRows; i++)
/*      */     {
/*  734 */       if (this.rows[i] != null)
/*      */       {
/*  736 */         this.rows[i].insertColumn(col);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  741 */     HyperlinkRecord hr = null;
/*  742 */     Iterator i = this.hyperlinks.iterator();
/*  743 */     while (i.hasNext())
/*      */     {
/*  745 */       hr = (HyperlinkRecord)i.next();
/*  746 */       hr.insertColumn(col);
/*      */     }
/*      */     
/*      */ 
/*  750 */     i = this.columnFormats.iterator();
/*  751 */     while (i.hasNext())
/*      */     {
/*  753 */       ColumnInfoRecord cir = (ColumnInfoRecord)i.next();
/*      */       
/*  755 */       if (cir.getColumn() >= col)
/*      */       {
/*  757 */         cir.incrementColumn();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  762 */     if (this.autosizedColumns.size() > 0)
/*      */     {
/*  764 */       TreeSet newAutosized = new TreeSet();
/*  765 */       i = this.autosizedColumns.iterator();
/*  766 */       while (i.hasNext())
/*      */       {
/*  768 */         Integer colnumber = (Integer)i.next();
/*      */         
/*  770 */         if (colnumber.intValue() >= col)
/*      */         {
/*  772 */           newAutosized.add(new Integer(colnumber.intValue() + 1));
/*      */         }
/*      */         else
/*      */         {
/*  776 */           newAutosized.add(colnumber);
/*      */         }
/*      */       }
/*  779 */       this.autosizedColumns = newAutosized;
/*      */     }
/*      */     
/*      */ 
/*  783 */     if (this.dataValidation != null)
/*      */     {
/*  785 */       this.dataValidation.insertColumn(col);
/*      */     }
/*      */     Iterator vci;
/*  788 */     if ((this.validatedCells != null) && (this.validatedCells.size() > 0))
/*      */     {
/*  790 */       for (vci = this.validatedCells.iterator(); vci.hasNext();)
/*      */       {
/*  792 */         CellValue cv = (CellValue)vci.next();
/*  793 */         CellFeatures cf = cv.getCellFeatures();
/*  794 */         if (cf.getDVParser() != null)
/*      */         {
/*  796 */           cf.getDVParser().insertColumn(col);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  802 */     this.mergedCells.insertColumn(col);
/*      */     
/*      */ 
/*  805 */     ArrayList newColumnBreaks = new ArrayList();
/*  806 */     Iterator ri = this.columnBreaks.iterator();
/*  807 */     while (ri.hasNext())
/*      */     {
/*  809 */       int val = ((Integer)ri.next()).intValue();
/*  810 */       if (val >= col)
/*      */       {
/*  812 */         val++;
/*      */       }
/*      */       
/*  815 */       newColumnBreaks.add(new Integer(val));
/*      */     }
/*  817 */     this.columnBreaks = newColumnBreaks;
/*      */     
/*      */ 
/*  820 */     for (Iterator cfit = this.conditionalFormats.iterator(); cfit.hasNext();)
/*      */     {
/*  822 */       ConditionalFormat cf = (ConditionalFormat)cfit.next();
/*  823 */       cf.insertColumn(col);
/*      */     }
/*      */     
/*      */ 
/*  827 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  829 */       this.workbook.columnInserted(this, col);
/*      */     }
/*      */     
/*  832 */     this.numColumns += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeColumn(int col)
/*      */   {
/*  843 */     if ((col < 0) || (col >= this.numColumns))
/*      */     {
/*  845 */       return;
/*      */     }
/*      */     
/*      */ 
/*  849 */     for (int i = 0; i < this.numRows; i++)
/*      */     {
/*  851 */       if (this.rows[i] != null)
/*      */       {
/*  853 */         this.rows[i].removeColumn(col);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  858 */     HyperlinkRecord hr = null;
/*  859 */     Iterator i = this.hyperlinks.iterator();
/*  860 */     while (i.hasNext())
/*      */     {
/*  862 */       hr = (HyperlinkRecord)i.next();
/*      */       
/*  864 */       if ((hr.getColumn() == col) && (hr.getLastColumn() == col))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  869 */         i.remove();
/*      */       }
/*      */       else
/*      */       {
/*  873 */         hr.removeColumn(col);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  878 */     if (this.dataValidation != null)
/*      */     {
/*  880 */       this.dataValidation.removeColumn(col);
/*      */     }
/*      */     Iterator vci;
/*  883 */     if ((this.validatedCells != null) && (this.validatedCells.size() > 0))
/*      */     {
/*  885 */       for (vci = this.validatedCells.iterator(); vci.hasNext();)
/*      */       {
/*  887 */         CellValue cv = (CellValue)vci.next();
/*  888 */         CellFeatures cf = cv.getCellFeatures();
/*  889 */         if (cf.getDVParser() != null)
/*      */         {
/*  891 */           cf.getDVParser().removeColumn(col);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  897 */     this.mergedCells.removeColumn(col);
/*      */     
/*      */ 
/*  900 */     ArrayList newColumnBreaks = new ArrayList();
/*  901 */     Iterator ri = this.columnBreaks.iterator();
/*  902 */     while (ri.hasNext())
/*      */     {
/*  904 */       int val = ((Integer)ri.next()).intValue();
/*      */       
/*  906 */       if (val != col)
/*      */       {
/*  908 */         if (val > col)
/*      */         {
/*  910 */           val--;
/*      */         }
/*      */         
/*  913 */         newColumnBreaks.add(new Integer(val));
/*      */       }
/*      */     }
/*      */     
/*  917 */     this.columnBreaks = newColumnBreaks;
/*      */     
/*      */ 
/*      */ 
/*  921 */     i = this.columnFormats.iterator();
/*  922 */     ColumnInfoRecord removeColumn = null;
/*  923 */     while (i.hasNext())
/*      */     {
/*  925 */       ColumnInfoRecord cir = (ColumnInfoRecord)i.next();
/*      */       
/*  927 */       if (cir.getColumn() == col)
/*      */       {
/*  929 */         removeColumn = cir;
/*      */       }
/*  931 */       else if (cir.getColumn() > col)
/*      */       {
/*  933 */         cir.decrementColumn();
/*      */       }
/*      */     }
/*      */     
/*  937 */     if (removeColumn != null)
/*      */     {
/*  939 */       this.columnFormats.remove(removeColumn);
/*      */     }
/*      */     
/*      */ 
/*  943 */     if (this.autosizedColumns.size() > 0)
/*      */     {
/*  945 */       TreeSet newAutosized = new TreeSet();
/*  946 */       i = this.autosizedColumns.iterator();
/*  947 */       while (i.hasNext())
/*      */       {
/*  949 */         Integer colnumber = (Integer)i.next();
/*      */         
/*  951 */         if (colnumber.intValue() != col)
/*      */         {
/*      */ 
/*      */ 
/*  955 */           if (colnumber.intValue() > col)
/*      */           {
/*  957 */             newAutosized.add(new Integer(colnumber.intValue() - 1));
/*      */           }
/*      */           else
/*      */           {
/*  961 */             newAutosized.add(colnumber); }
/*      */         }
/*      */       }
/*  964 */       this.autosizedColumns = newAutosized;
/*      */     }
/*      */     
/*      */ 
/*  968 */     for (Iterator cfit = this.conditionalFormats.iterator(); cfit.hasNext();)
/*      */     {
/*  970 */       ConditionalFormat cf = (ConditionalFormat)cfit.next();
/*  971 */       cf.removeColumn(col);
/*      */     }
/*      */     
/*      */ 
/*  975 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  977 */       this.workbook.columnRemoved(this, col);
/*      */     }
/*      */     
/*  980 */     this.numColumns -= 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRow(int row)
/*      */   {
/*  991 */     if ((row < 0) || (row >= this.numRows))
/*      */     {
/*      */ 
/*  994 */       if (this.workbookSettings.getFormulaAdjust())
/*      */       {
/*  996 */         this.workbook.rowRemoved(this, row);
/*      */       }
/*      */       
/*  999 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1003 */     RowRecord[] oldRows = this.rows;
/*      */     
/* 1005 */     this.rows = new RowRecord[oldRows.length];
/*      */     
/*      */ 
/* 1008 */     System.arraycopy(oldRows, 0, this.rows, 0, row);
/*      */     
/*      */ 
/* 1011 */     System.arraycopy(oldRows, row + 1, this.rows, row, this.numRows - (row + 1));
/*      */     
/*      */ 
/* 1014 */     for (int i = row; i < this.numRows; i++)
/*      */     {
/* 1016 */       if (this.rows[i] != null)
/*      */       {
/* 1018 */         this.rows[i].decrementRow();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1023 */     HyperlinkRecord hr = null;
/* 1024 */     Iterator i = this.hyperlinks.iterator();
/* 1025 */     while (i.hasNext())
/*      */     {
/* 1027 */       hr = (HyperlinkRecord)i.next();
/*      */       
/* 1029 */       if ((hr.getRow() == row) && (hr.getLastRow() == row))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1034 */         i.remove();
/*      */       }
/*      */       else
/*      */       {
/* 1038 */         hr.removeRow(row);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1043 */     if (this.dataValidation != null)
/*      */     {
/* 1045 */       this.dataValidation.removeRow(row);
/*      */     }
/*      */     Iterator vci;
/* 1048 */     if ((this.validatedCells != null) && (this.validatedCells.size() > 0))
/*      */     {
/* 1050 */       for (vci = this.validatedCells.iterator(); vci.hasNext();)
/*      */       {
/* 1052 */         CellValue cv = (CellValue)vci.next();
/* 1053 */         CellFeatures cf = cv.getCellFeatures();
/* 1054 */         if (cf.getDVParser() != null)
/*      */         {
/* 1056 */           cf.getDVParser().removeRow(row);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1062 */     this.mergedCells.removeRow(row);
/*      */     
/*      */ 
/* 1065 */     ArrayList newRowBreaks = new ArrayList();
/* 1066 */     Iterator ri = this.rowBreaks.iterator();
/* 1067 */     while (ri.hasNext())
/*      */     {
/* 1069 */       int val = ((Integer)ri.next()).intValue();
/*      */       
/* 1071 */       if (val != row)
/*      */       {
/* 1073 */         if (val > row)
/*      */         {
/* 1075 */           val--;
/*      */         }
/*      */         
/* 1078 */         newRowBreaks.add(new Integer(val));
/*      */       }
/*      */     }
/*      */     
/* 1082 */     this.rowBreaks = newRowBreaks;
/*      */     
/*      */ 
/* 1085 */     for (Iterator cfit = this.conditionalFormats.iterator(); cfit.hasNext();)
/*      */     {
/* 1087 */       ConditionalFormat cf = (ConditionalFormat)cfit.next();
/* 1088 */       cf.removeRow(row);
/*      */     }
/*      */     
/*      */ 
/* 1092 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/* 1094 */       this.workbook.rowRemoved(this, row);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1110 */     this.numRows -= 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCell(WritableCell cell)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1133 */     if (cell.getType() == CellType.EMPTY)
/*      */     {
/* 1135 */       if ((cell != null) && (cell.getCellFormat() == null))
/*      */       {
/*      */ 
/*      */ 
/* 1139 */         return;
/*      */       }
/*      */     }
/*      */     
/* 1143 */     CellValue cv = (CellValue)cell;
/*      */     
/* 1145 */     if (cv.isReferenced())
/*      */     {
/* 1147 */       throw new JxlWriteException(JxlWriteException.cellReferenced);
/*      */     }
/*      */     
/* 1150 */     int row = cell.getRow();
/* 1151 */     RowRecord rowrec = getRowRecord(row);
/*      */     
/* 1153 */     CellValue curcell = rowrec.getCell(cv.getColumn());
/* 1154 */     boolean curSharedValidation = (curcell != null) && (curcell.getCellFeatures() != null) && (curcell.getCellFeatures().getDVParser() != null) && (curcell.getCellFeatures().getDVParser().extendedCellsValidation());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1161 */     if ((cell.getCellFeatures() != null) && (cell.getCellFeatures().hasDataValidation()) && (curSharedValidation))
/*      */     {
/*      */ 
/*      */ 
/* 1165 */       DVParser dvp = curcell.getCellFeatures().getDVParser();
/* 1166 */       logger.warn("Cannot add cell at " + CellReferenceHelper.getCellReference(cv) + " because it is part of the shared cell validation group " + CellReferenceHelper.getCellReference(dvp.getFirstColumn(), dvp.getFirstRow()) + "-" + CellReferenceHelper.getCellReference(dvp.getLastColumn(), dvp.getLastRow()));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1174 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1178 */     if (curSharedValidation)
/*      */     {
/* 1180 */       WritableCellFeatures wcf = cell.getWritableCellFeatures();
/*      */       
/* 1182 */       if (wcf == null)
/*      */       {
/* 1184 */         wcf = new WritableCellFeatures();
/* 1185 */         cell.setCellFeatures(wcf);
/*      */       }
/*      */       
/* 1188 */       wcf.shareDataValidation(curcell.getCellFeatures());
/*      */     }
/*      */     
/* 1191 */     rowrec.addCell(cv);
/*      */     
/*      */ 
/* 1194 */     this.numRows = Math.max(row + 1, this.numRows);
/* 1195 */     this.numColumns = Math.max(this.numColumns, rowrec.getMaxColumn());
/*      */     
/*      */ 
/*      */ 
/* 1199 */     cv.setCellDetails(this.formatRecords, this.sharedStrings, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   RowRecord getRowRecord(int row)
/*      */     throws RowsExceededException
/*      */   {
/* 1212 */     if (row >= 65536)
/*      */     {
/* 1214 */       throw new RowsExceededException();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1220 */     if (row >= this.rows.length)
/*      */     {
/* 1222 */       RowRecord[] oldRows = this.rows;
/* 1223 */       this.rows = new RowRecord[Math.max(oldRows.length + 10, row + 1)];
/* 1224 */       System.arraycopy(oldRows, 0, this.rows, 0, oldRows.length);
/* 1225 */       oldRows = null;
/*      */     }
/*      */     
/* 1228 */     RowRecord rowrec = this.rows[row];
/*      */     
/* 1230 */     if (rowrec == null)
/*      */     {
/* 1232 */       rowrec = new RowRecord(row, this);
/* 1233 */       this.rows[row] = rowrec;
/*      */     }
/*      */     
/* 1236 */     return rowrec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   RowRecord getRowInfo(int r)
/*      */   {
/* 1247 */     if ((r < 0) || (r > this.rows.length))
/*      */     {
/* 1249 */       return null;
/*      */     }
/*      */     
/* 1252 */     return this.rows[r];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ColumnInfoRecord getColumnInfo(int c)
/*      */   {
/* 1263 */     Iterator i = this.columnFormats.iterator();
/* 1264 */     ColumnInfoRecord cir = null;
/* 1265 */     boolean stop = false;
/*      */     
/* 1267 */     while ((i.hasNext()) && (!stop))
/*      */     {
/* 1269 */       cir = (ColumnInfoRecord)i.next();
/*      */       
/* 1271 */       if (cir.getColumn() >= c)
/*      */       {
/* 1273 */         stop = true;
/*      */       }
/*      */     }
/*      */     
/* 1277 */     if (!stop)
/*      */     {
/* 1279 */       return null;
/*      */     }
/*      */     
/* 1282 */     return cir.getColumn() == c ? cir : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String n)
/*      */   {
/* 1292 */     this.name = n;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setHidden(boolean h)
/*      */   {
/* 1303 */     this.settings.setHidden(h);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setProtected(boolean prot)
/*      */   {
/* 1314 */     this.settings.setProtected(prot);
/*      */   }
/*      */   
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setSelected()
/*      */   {
/* 1323 */     this.settings.setSelected();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isHidden()
/*      */   {
/* 1334 */     return this.settings.isHidden();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnView(int col, int width)
/*      */   {
/* 1345 */     CellView cv = new CellView();
/* 1346 */     cv.setSize(width * 256);
/* 1347 */     setColumnView(col, cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnView(int col, int width, CellFormat format)
/*      */   {
/* 1360 */     CellView cv = new CellView();
/* 1361 */     cv.setSize(width * 256);
/* 1362 */     cv.setFormat(format);
/* 1363 */     setColumnView(col, cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnView(int col, CellView view)
/*      */   {
/* 1374 */     XFRecord xfr = (XFRecord)view.getFormat();
/* 1375 */     if (xfr == null)
/*      */     {
/* 1377 */       Styles styles = getWorkbook().getStyles();
/* 1378 */       xfr = styles.getNormalStyle();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1383 */       if (!xfr.isInitialized())
/*      */       {
/* 1385 */         this.formatRecords.addStyle(xfr);
/*      */       }
/*      */       
/* 1388 */       int width = view.depUsed() ? view.getDimension() * 256 : view.getSize();
/*      */       
/* 1390 */       if (view.isAutosize())
/*      */       {
/* 1392 */         this.autosizedColumns.add(new Integer(col));
/*      */       }
/*      */       
/* 1395 */       ColumnInfoRecord cir = new ColumnInfoRecord(col, width, xfr);
/*      */       
/*      */ 
/*      */ 
/* 1399 */       if (view.isHidden())
/*      */       {
/* 1401 */         cir.setHidden(true);
/*      */       }
/*      */       
/* 1404 */       if (!this.columnFormats.contains(cir))
/*      */       {
/* 1406 */         this.columnFormats.add(cir);
/*      */       }
/*      */       else
/*      */       {
/* 1410 */         this.columnFormats.remove(cir);
/* 1411 */         this.columnFormats.add(cir);
/*      */       }
/*      */     }
/*      */     catch (NumFormatRecordsException e)
/*      */     {
/* 1416 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*      */       
/*      */ 
/* 1419 */       ColumnInfoRecord cir = new ColumnInfoRecord(col, view.getDimension() * 256, WritableWorkbook.NORMAL_STYLE);
/*      */       
/* 1421 */       if (!this.columnFormats.contains(cir))
/*      */       {
/* 1423 */         this.columnFormats.add(cir);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setRowView(int row, int height)
/*      */     throws RowsExceededException
/*      */   {
/* 1439 */     CellView cv = new CellView();
/* 1440 */     cv.setSize(height);
/* 1441 */     cv.setHidden(false);
/* 1442 */     setRowView(row, cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setRowView(int row, boolean collapsed)
/*      */     throws RowsExceededException
/*      */   {
/* 1456 */     CellView cv = new CellView();
/* 1457 */     cv.setHidden(collapsed);
/* 1458 */     setRowView(row, cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setRowView(int row, int height, boolean collapsed)
/*      */     throws RowsExceededException
/*      */   {
/* 1475 */     CellView cv = new CellView();
/* 1476 */     cv.setSize(height);
/* 1477 */     cv.setHidden(collapsed);
/* 1478 */     setRowView(row, cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRowView(int row, CellView view)
/*      */     throws RowsExceededException
/*      */   {
/* 1490 */     RowRecord rowrec = getRowRecord(row);
/*      */     
/* 1492 */     XFRecord xfr = (XFRecord)view.getFormat();
/*      */     
/*      */     try
/*      */     {
/* 1496 */       if (xfr != null)
/*      */       {
/* 1498 */         if (!xfr.isInitialized())
/*      */         {
/* 1500 */           this.formatRecords.addStyle(xfr);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (NumFormatRecordsException e)
/*      */     {
/* 1506 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*      */       
/*      */ 
/* 1509 */       xfr = null;
/*      */     }
/*      */     
/* 1512 */     rowrec.setRowDetails(view.getSize(), false, view.isHidden(), 0, false, xfr);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1518 */     this.numRows = Math.max(this.numRows, row + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write()
/*      */     throws IOException
/*      */   {
/* 1530 */     boolean dmod = this.drawingsModified;
/* 1531 */     if (this.workbook.getDrawingGroup() != null)
/*      */     {
/* 1533 */       dmod |= this.workbook.getDrawingGroup().hasDrawingsOmitted();
/*      */     }
/*      */     
/* 1536 */     if (this.autosizedColumns.size() > 0)
/*      */     {
/* 1538 */       autosizeColumns();
/*      */     }
/*      */     
/* 1541 */     this.sheetWriter.setWriteData(this.rows, this.rowBreaks, this.columnBreaks, this.hyperlinks, this.mergedCells, this.columnFormats, this.maxRowOutlineLevel, this.maxColumnOutlineLevel);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1549 */     this.sheetWriter.setDimensions(getRows(), getColumns());
/* 1550 */     this.sheetWriter.setSettings(this.settings);
/* 1551 */     this.sheetWriter.setPLS(this.plsRecord);
/* 1552 */     this.sheetWriter.setDrawings(this.drawings, dmod);
/* 1553 */     this.sheetWriter.setButtonPropertySet(this.buttonPropertySet);
/* 1554 */     this.sheetWriter.setDataValidation(this.dataValidation, this.validatedCells);
/* 1555 */     this.sheetWriter.setConditionalFormats(this.conditionalFormats);
/* 1556 */     this.sheetWriter.setAutoFilter(this.autoFilter);
/*      */     
/* 1558 */     this.sheetWriter.write();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void copy(Sheet s)
/*      */   {
/* 1569 */     this.settings = new SheetSettings(s.getSettings(), this);
/*      */     
/* 1571 */     SheetCopier si = new SheetCopier(s, this);
/* 1572 */     si.setColumnFormats(this.columnFormats);
/* 1573 */     si.setFormatRecords(this.formatRecords);
/* 1574 */     si.setHyperlinks(this.hyperlinks);
/* 1575 */     si.setMergedCells(this.mergedCells);
/* 1576 */     si.setRowBreaks(this.rowBreaks);
/* 1577 */     si.setColumnBreaks(this.columnBreaks);
/* 1578 */     si.setSheetWriter(this.sheetWriter);
/* 1579 */     si.setDrawings(this.drawings);
/* 1580 */     si.setImages(this.images);
/* 1581 */     si.setConditionalFormats(this.conditionalFormats);
/* 1582 */     si.setValidatedCells(this.validatedCells);
/*      */     
/* 1584 */     si.copySheet();
/*      */     
/* 1586 */     this.dataValidation = si.getDataValidation();
/* 1587 */     this.comboBox = si.getComboBox();
/* 1588 */     this.plsRecord = si.getPLSRecord();
/* 1589 */     this.chartOnly = si.isChartOnly();
/* 1590 */     this.buttonPropertySet = si.getButtonPropertySet();
/* 1591 */     this.numRows = si.getRows();
/* 1592 */     this.autoFilter = si.getAutoFilter();
/* 1593 */     this.maxRowOutlineLevel = si.getMaxRowOutlineLevel();
/* 1594 */     this.maxColumnOutlineLevel = si.getMaxColumnOutlineLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void copy(WritableSheet s)
/*      */   {
/* 1604 */     this.settings = new SheetSettings(s.getSettings(), this);
/* 1605 */     WritableSheetImpl si = (WritableSheetImpl)s;
/*      */     
/* 1607 */     WritableSheetCopier sc = new WritableSheetCopier(s, this);
/* 1608 */     sc.setColumnFormats(si.columnFormats, this.columnFormats);
/* 1609 */     sc.setMergedCells(si.mergedCells, this.mergedCells);
/* 1610 */     sc.setRows(si.rows);
/* 1611 */     sc.setRowBreaks(si.rowBreaks, this.rowBreaks);
/* 1612 */     sc.setColumnBreaks(si.columnBreaks, this.columnBreaks);
/* 1613 */     sc.setDataValidation(si.dataValidation);
/* 1614 */     sc.setSheetWriter(this.sheetWriter);
/* 1615 */     sc.setDrawings(si.drawings, this.drawings, this.images);
/* 1616 */     sc.setWorkspaceOptions(si.getWorkspaceOptions());
/* 1617 */     sc.setPLSRecord(si.plsRecord);
/* 1618 */     sc.setButtonPropertySetRecord(si.buttonPropertySet);
/* 1619 */     sc.setHyperlinks(si.hyperlinks, this.hyperlinks);
/* 1620 */     sc.setValidatedCells(this.validatedCells);
/*      */     
/* 1622 */     sc.copySheet();
/*      */     
/* 1624 */     this.dataValidation = sc.getDataValidation();
/* 1625 */     this.plsRecord = sc.getPLSRecord();
/* 1626 */     this.buttonPropertySet = sc.getButtonPropertySet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final HeaderRecord getHeader()
/*      */   {
/* 1636 */     return this.sheetWriter.getHeader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final FooterRecord getFooter()
/*      */   {
/* 1646 */     return this.sheetWriter.getFooter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public boolean isProtected()
/*      */   {
/* 1656 */     return this.settings.isProtected();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Hyperlink[] getHyperlinks()
/*      */   {
/* 1666 */     Hyperlink[] hl = new Hyperlink[this.hyperlinks.size()];
/*      */     
/* 1668 */     for (int i = 0; i < this.hyperlinks.size(); i++)
/*      */     {
/* 1670 */       hl[i] = ((Hyperlink)this.hyperlinks.get(i));
/*      */     }
/*      */     
/* 1673 */     return hl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range[] getMergedCells()
/*      */   {
/* 1683 */     return this.mergedCells.getMergedCells();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableHyperlink[] getWritableHyperlinks()
/*      */   {
/* 1693 */     WritableHyperlink[] hl = new WritableHyperlink[this.hyperlinks.size()];
/*      */     
/* 1695 */     for (int i = 0; i < this.hyperlinks.size(); i++)
/*      */     {
/* 1697 */       hl[i] = ((WritableHyperlink)this.hyperlinks.get(i));
/*      */     }
/*      */     
/* 1700 */     return hl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeHyperlink(WritableHyperlink h)
/*      */   {
/* 1717 */     removeHyperlink(h, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeHyperlink(WritableHyperlink h, boolean preserveLabel)
/*      */   {
/* 1737 */     this.hyperlinks.remove(this.hyperlinks.indexOf(h));
/*      */     
/* 1739 */     if (!preserveLabel)
/*      */     {
/*      */ 
/*      */ 
/* 1743 */       Assert.verify((this.rows.length > h.getRow()) && (this.rows[h.getRow()] != null));
/* 1744 */       this.rows[h.getRow()].removeCell(h.getColumn());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addHyperlink(WritableHyperlink h)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1759 */     Cell c = getCell(h.getColumn(), h.getRow());
/*      */     
/* 1761 */     String contents = null;
/* 1762 */     if ((h.isFile()) || (h.isUNC()))
/*      */     {
/* 1764 */       String cnts = h.getContents();
/* 1765 */       if (cnts == null)
/*      */       {
/* 1767 */         contents = h.getFile().getPath();
/*      */       }
/*      */       else
/*      */       {
/* 1771 */         contents = cnts;
/*      */       }
/*      */     }
/* 1774 */     else if (h.isURL())
/*      */     {
/* 1776 */       String cnts = h.getContents();
/* 1777 */       if (cnts == null)
/*      */       {
/* 1779 */         contents = h.getURL().toString();
/*      */       }
/*      */       else
/*      */       {
/* 1783 */         contents = cnts;
/*      */       }
/*      */     }
/* 1786 */     else if (h.isLocation())
/*      */     {
/* 1788 */       contents = h.getContents();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1795 */     if (c.getType() == CellType.LABEL)
/*      */     {
/* 1797 */       Label l = (Label)c;
/* 1798 */       l.setString(contents);
/* 1799 */       WritableCellFormat wcf = new WritableCellFormat(l.getCellFormat());
/* 1800 */       wcf.setFont(WritableWorkbook.HYPERLINK_FONT);
/* 1801 */       l.setCellFormat(wcf);
/*      */     }
/*      */     else
/*      */     {
/* 1805 */       Label l = new Label(h.getColumn(), h.getRow(), contents, WritableWorkbook.HYPERLINK_STYLE);
/*      */       
/* 1807 */       addCell(l);
/*      */     }
/*      */     
/*      */ 
/* 1811 */     for (int i = h.getRow(); i <= h.getLastRow(); i++)
/*      */     {
/* 1813 */       for (int j = h.getColumn(); j <= h.getLastColumn(); j++)
/*      */       {
/* 1815 */         if ((i != h.getRow()) && (j != h.getColumn()))
/*      */         {
/*      */ 
/* 1818 */           if ((this.rows.length < h.getLastColumn()) && (this.rows[i] != null))
/*      */           {
/* 1820 */             this.rows[i].removeCell(j);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1826 */     h.initialize(this);
/* 1827 */     this.hyperlinks.add(h);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range mergeCells(int col1, int row1, int col2, int row2)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1846 */     if ((col2 < col1) || (row2 < row1))
/*      */     {
/* 1848 */       logger.warn("Cannot merge cells - top left and bottom right incorrectly specified");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1853 */     if ((col2 >= this.numColumns) || (row2 >= this.numRows))
/*      */     {
/* 1855 */       addCell(new Blank(col2, row2));
/*      */     }
/*      */     
/* 1858 */     SheetRangeImpl range = new SheetRangeImpl(this, col1, row1, col2, row2);
/* 1859 */     this.mergedCells.add(range);
/*      */     
/* 1861 */     return range;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRowGroup(int row1, int row2, boolean collapsed)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1877 */     if (row2 < row1)
/*      */     {
/* 1879 */       logger.warn("Cannot merge cells - top and bottom rows incorrectly specified");
/*      */     }
/*      */     
/*      */ 
/* 1883 */     for (int i = row1; i <= row2; i++)
/*      */     {
/* 1885 */       RowRecord row = getRowRecord(i);
/* 1886 */       this.numRows = Math.max(i + 1, this.numRows);
/* 1887 */       row.incrementOutlineLevel();
/* 1888 */       row.setCollapsed(collapsed);
/* 1889 */       this.maxRowOutlineLevel = Math.max(this.maxRowOutlineLevel, row.getOutlineLevel());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unsetRowGroup(int row1, int row2)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1905 */     if (row2 < row1)
/*      */     {
/* 1907 */       logger.warn("Cannot merge cells - top and bottom rows incorrectly specified");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1912 */     if (row2 >= this.numRows)
/*      */     {
/* 1914 */       logger.warn("" + row2 + " is greater than the sheet bounds");
/*      */       
/* 1916 */       row2 = this.numRows - 1;
/*      */     }
/*      */     
/* 1919 */     for (int i = row1; i <= row2; i++)
/*      */     {
/* 1921 */       this.rows[i].decrementOutlineLevel();
/*      */     }
/*      */     
/*      */ 
/* 1925 */     this.maxRowOutlineLevel = 0;
/* 1926 */     for (int i = this.rows.length; i-- > 0;)
/*      */     {
/* 1928 */       this.maxRowOutlineLevel = Math.max(this.maxRowOutlineLevel, this.rows[i].getOutlineLevel());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnGroup(int col1, int col2, boolean collapsed)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1945 */     if (col2 < col1)
/*      */     {
/* 1947 */       logger.warn("Cannot merge cells - top and bottom rows incorrectly specified");
/*      */     }
/*      */     
/*      */ 
/* 1951 */     for (int i = col1; i <= col2; i++)
/*      */     {
/* 1953 */       ColumnInfoRecord cir = getColumnInfo(i);
/*      */       
/*      */ 
/*      */ 
/* 1957 */       if (cir == null)
/*      */       {
/* 1959 */         setColumnView(i, new CellView());
/* 1960 */         cir = getColumnInfo(i);
/*      */       }
/*      */       
/* 1963 */       cir.incrementOutlineLevel();
/* 1964 */       cir.setCollapsed(collapsed);
/* 1965 */       this.maxColumnOutlineLevel = Math.max(this.maxColumnOutlineLevel, cir.getOutlineLevel());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unsetColumnGroup(int col1, int col2)
/*      */     throws WriteException, RowsExceededException
/*      */   {
/* 1981 */     if (col2 < col1)
/*      */     {
/* 1983 */       logger.warn("Cannot merge cells - top and bottom rows incorrectly specified");
/*      */     }
/*      */     
/*      */ 
/* 1987 */     for (int i = col1; i <= col2; i++)
/*      */     {
/* 1989 */       ColumnInfoRecord cir = getColumnInfo(i);
/* 1990 */       cir.decrementOutlineLevel();
/*      */     }
/*      */     
/*      */ 
/* 1994 */     this.maxColumnOutlineLevel = 0;
/* 1995 */     for (Iterator it = this.columnFormats.iterator(); it.hasNext();)
/*      */     {
/* 1997 */       ColumnInfoRecord cir = (ColumnInfoRecord)it.next();
/* 1998 */       this.maxColumnOutlineLevel = Math.max(this.maxColumnOutlineLevel, cir.getOutlineLevel());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unmergeCells(Range r)
/*      */   {
/* 2011 */     this.mergedCells.unmergeCells(r);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setHeader(String l, String c, String r)
/*      */   {
/* 2024 */     HeaderFooter header = new HeaderFooter();
/* 2025 */     header.getLeft().append(l);
/* 2026 */     header.getCentre().append(c);
/* 2027 */     header.getRight().append(r);
/* 2028 */     this.settings.setHeader(header);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setFooter(String l, String c, String r)
/*      */   {
/* 2041 */     HeaderFooter footer = new HeaderFooter();
/* 2042 */     footer.getLeft().append(l);
/* 2043 */     footer.getCentre().append(c);
/* 2044 */     footer.getRight().append(r);
/* 2045 */     this.settings.setFooter(footer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setPageSetup(PageOrientation p)
/*      */   {
/* 2056 */     this.settings.setOrientation(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setPageSetup(PageOrientation p, double hm, double fm)
/*      */   {
/* 2069 */     this.settings.setOrientation(p);
/* 2070 */     this.settings.setHeaderMargin(hm);
/* 2071 */     this.settings.setFooterMargin(fm);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setPageSetup(PageOrientation p, PaperSize ps, double hm, double fm)
/*      */   {
/* 2086 */     this.settings.setPaperSize(ps);
/* 2087 */     this.settings.setOrientation(p);
/* 2088 */     this.settings.setHeaderMargin(hm);
/* 2089 */     this.settings.setFooterMargin(fm);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SheetSettings getSettings()
/*      */   {
/* 2099 */     return this.settings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   WorkbookSettings getWorkbookSettings()
/*      */   {
/* 2107 */     return this.workbookSettings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRowPageBreak(int row)
/*      */   {
/* 2118 */     Iterator i = this.rowBreaks.iterator();
/* 2119 */     boolean found = false;
/*      */     
/* 2121 */     while ((i.hasNext()) && (!found))
/*      */     {
/* 2123 */       if (((Integer)i.next()).intValue() == row)
/*      */       {
/* 2125 */         found = true;
/*      */       }
/*      */     }
/*      */     
/* 2129 */     if (!found)
/*      */     {
/* 2131 */       this.rowBreaks.add(new Integer(row));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addColumnPageBreak(int col)
/*      */   {
/* 2143 */     Iterator i = this.columnBreaks.iterator();
/* 2144 */     boolean found = false;
/*      */     
/* 2146 */     while ((i.hasNext()) && (!found))
/*      */     {
/* 2148 */       if (((Integer)i.next()).intValue() == col)
/*      */       {
/* 2150 */         found = true;
/*      */       }
/*      */     }
/*      */     
/* 2154 */     if (!found)
/*      */     {
/* 2156 */       this.columnBreaks.add(new Integer(col));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Chart[] getCharts()
/*      */   {
/* 2167 */     return this.sheetWriter.getCharts();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DrawingGroupObject[] getDrawings()
/*      */   {
/* 2177 */     DrawingGroupObject[] dr = new DrawingGroupObject[this.drawings.size()];
/* 2178 */     dr = (DrawingGroupObject[])this.drawings.toArray(dr);
/* 2179 */     return dr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkMergedBorders()
/*      */   {
/* 2190 */     this.sheetWriter.setWriteData(this.rows, this.rowBreaks, this.columnBreaks, this.hyperlinks, this.mergedCells, this.columnFormats, this.maxRowOutlineLevel, this.maxColumnOutlineLevel);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2198 */     this.sheetWriter.setDimensions(getRows(), getColumns());
/* 2199 */     this.sheetWriter.checkMergedBorders();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkspaceInformationRecord getWorkspaceOptions()
/*      */   {
/* 2209 */     return this.sheetWriter.getWorkspaceOptions();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void rationalize(IndexMapping xfMapping, IndexMapping fontMapping, IndexMapping formatMapping)
/*      */   {
/* 2223 */     for (Iterator i = this.columnFormats.iterator(); i.hasNext();)
/*      */     {
/* 2225 */       ColumnInfoRecord cir = (ColumnInfoRecord)i.next();
/* 2226 */       cir.rationalize(xfMapping);
/*      */     }
/*      */     
/*      */ 
/* 2230 */     for (int i = 0; i < this.rows.length; i++)
/*      */     {
/* 2232 */       if (this.rows[i] != null)
/*      */       {
/* 2234 */         this.rows[i].rationalize(xfMapping);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2239 */     Chart[] charts = getCharts();
/* 2240 */     for (int c = 0; c < charts.length; c++)
/*      */     {
/* 2242 */       charts[c].rationalize(xfMapping, fontMapping, formatMapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   WritableWorkbookImpl getWorkbook()
/*      */   {
/* 2252 */     return this.workbook;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public CellFormat getColumnFormat(int col)
/*      */   {
/* 2264 */     return getColumnView(col).getFormat();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getColumnWidth(int col)
/*      */   {
/* 2277 */     return getColumnView(col).getDimension();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int getRowHeight(int row)
/*      */   {
/* 2290 */     return getRowView(row).getDimension();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isChartOnly()
/*      */   {
/* 2300 */     return this.chartOnly;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CellView getRowView(int row)
/*      */   {
/* 2312 */     CellView cv = new CellView();
/*      */     
/*      */     try
/*      */     {
/* 2316 */       RowRecord rr = getRowRecord(row);
/*      */       
/* 2318 */       if ((rr == null) || (rr.isDefaultHeight()))
/*      */       {
/* 2320 */         cv.setDimension(this.settings.getDefaultRowHeight());
/* 2321 */         cv.setSize(this.settings.getDefaultRowHeight());
/*      */       }
/* 2323 */       else if (rr.isCollapsed())
/*      */       {
/* 2325 */         cv.setHidden(true);
/*      */       }
/*      */       else
/*      */       {
/* 2329 */         cv.setDimension(rr.getRowHeight());
/* 2330 */         cv.setSize(rr.getRowHeight());
/*      */       }
/* 2332 */       return cv;
/*      */ 
/*      */     }
/*      */     catch (RowsExceededException e)
/*      */     {
/* 2337 */       cv.setDimension(this.settings.getDefaultRowHeight());
/* 2338 */       cv.setSize(this.settings.getDefaultRowHeight()); }
/* 2339 */     return cv;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CellView getColumnView(int col)
/*      */   {
/* 2352 */     ColumnInfoRecord cir = getColumnInfo(col);
/* 2353 */     CellView cv = new CellView();
/*      */     
/* 2355 */     if (cir != null)
/*      */     {
/* 2357 */       cv.setDimension(cir.getWidth() / 256);
/* 2358 */       cv.setSize(cir.getWidth());
/* 2359 */       cv.setHidden(cir.getHidden());
/* 2360 */       cv.setFormat(cir.getCellFormat());
/*      */     }
/*      */     else
/*      */     {
/* 2364 */       cv.setDimension(this.settings.getDefaultColumnWidth() / 256);
/* 2365 */       cv.setSize(this.settings.getDefaultColumnWidth() * 256);
/*      */     }
/*      */     
/* 2368 */     return cv;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addImage(WritableImage image)
/*      */   {
/* 2378 */     boolean supported = false;
/* 2379 */     java.io.File imageFile = image.getImageFile();
/* 2380 */     String fileType = "?";
/*      */     
/* 2382 */     if (imageFile != null)
/*      */     {
/* 2384 */       String fileName = imageFile.getName();
/* 2385 */       int fileTypeIndex = fileName.lastIndexOf('.');
/* 2386 */       fileType = fileTypeIndex != -1 ? fileName.substring(fileTypeIndex + 1) : "";
/*      */       
/*      */ 
/* 2389 */       for (int i = 0; (i < imageTypes.length) && (!supported); i++)
/*      */       {
/* 2391 */         if (fileType.equalsIgnoreCase(imageTypes[i]))
/*      */         {
/* 2393 */           supported = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2399 */       supported = true;
/*      */     }
/*      */     
/* 2402 */     if (supported)
/*      */     {
/* 2404 */       this.workbook.addDrawing(image);
/* 2405 */       this.drawings.add(image);
/* 2406 */       this.images.add(image);
/*      */     }
/*      */     else
/*      */     {
/* 2410 */       StringBuffer message = new StringBuffer("Image type ");
/* 2411 */       message.append(fileType);
/* 2412 */       message.append(" not supported.  Supported types are ");
/* 2413 */       message.append(imageTypes[0]);
/* 2414 */       for (int i = 1; i < imageTypes.length; i++)
/*      */       {
/* 2416 */         message.append(", ");
/* 2417 */         message.append(imageTypes[i]);
/*      */       }
/* 2419 */       logger.warn(message.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumberOfImages()
/*      */   {
/* 2430 */     return this.images.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableImage getImage(int i)
/*      */   {
/* 2441 */     return (WritableImage)this.images.get(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getDrawing(int i)
/*      */   {
/* 2452 */     return (Image)this.images.get(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeImage(WritableImage wi)
/*      */   {
/* 2463 */     this.drawings.remove(wi);
/* 2464 */     this.images.remove(wi);
/* 2465 */     this.drawingsModified = true;
/* 2466 */     this.workbook.removeDrawing(wi);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String validateName(String n)
/*      */   {
/* 2474 */     if (n.length() > 31)
/*      */     {
/* 2476 */       logger.warn("Sheet name " + n + " too long - truncating");
/* 2477 */       n = n.substring(0, 31);
/*      */     }
/*      */     
/* 2480 */     if (n.charAt(0) == '\'')
/*      */     {
/* 2482 */       logger.warn("Sheet naming cannot start with ' - removing");
/* 2483 */       n = n.substring(1);
/*      */     }
/*      */     
/* 2486 */     for (int i = 0; i < illegalSheetNameCharacters.length; i++)
/*      */     {
/* 2488 */       String newname = n.replace(illegalSheetNameCharacters[i], '@');
/* 2489 */       if (n != newname)
/*      */       {
/* 2491 */         logger.warn(illegalSheetNameCharacters[i] + " is not a valid character within a sheet name - replacing");
/*      */       }
/*      */       
/* 2494 */       n = newname;
/*      */     }
/*      */     
/* 2497 */     return n;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addDrawing(DrawingGroupObject o)
/*      */   {
/* 2507 */     this.drawings.add(o);
/* 2508 */     Assert.verify(!(o instanceof Drawing));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void removeDrawing(DrawingGroupObject o)
/*      */   {
/* 2518 */     int origSize = this.drawings.size();
/* 2519 */     this.drawings.remove(o);
/* 2520 */     int newSize = this.drawings.size();
/* 2521 */     this.drawingsModified = true;
/* 2522 */     Assert.verify(newSize == origSize - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void removeDataValidation(CellValue cv)
/*      */   {
/* 2533 */     if (this.dataValidation != null)
/*      */     {
/* 2535 */       this.dataValidation.removeDataValidation(cv.getColumn(), cv.getRow());
/*      */     }
/*      */     
/* 2538 */     if (this.validatedCells != null)
/*      */     {
/* 2540 */       boolean result = this.validatedCells.remove(cv);
/*      */       
/* 2542 */       if (!result)
/*      */       {
/* 2544 */         logger.warn("Could not remove validated cell " + CellReferenceHelper.getCellReference(cv));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getRowPageBreaks()
/*      */   {
/* 2557 */     int[] rb = new int[this.rowBreaks.size()];
/* 2558 */     int pos = 0;
/* 2559 */     for (Iterator i = this.rowBreaks.iterator(); i.hasNext(); pos++)
/*      */     {
/* 2561 */       rb[pos] = ((Integer)i.next()).intValue();
/*      */     }
/* 2563 */     return rb;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getColumnPageBreaks()
/*      */   {
/* 2573 */     int[] rb = new int[this.columnBreaks.size()];
/* 2574 */     int pos = 0;
/* 2575 */     for (Iterator i = this.columnBreaks.iterator(); i.hasNext(); pos++)
/*      */     {
/* 2577 */       rb[pos] = ((Integer)i.next()).intValue();
/*      */     }
/* 2579 */     return rb;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addValidationCell(CellValue cv)
/*      */   {
/* 2589 */     this.validatedCells.add(cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ComboBox getComboBox()
/*      */   {
/* 2600 */     return this.comboBox;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setComboBox(ComboBox cb)
/*      */   {
/* 2610 */     this.comboBox = cb;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DataValidation getDataValidation()
/*      */   {
/* 2618 */     return this.dataValidation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autosizeColumns()
/*      */   {
/* 2626 */     Iterator i = this.autosizedColumns.iterator();
/* 2627 */     while (i.hasNext())
/*      */     {
/* 2629 */       Integer col = (Integer)i.next();
/* 2630 */       autosizeColumn(col.intValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autosizeColumn(int col)
/*      */   {
/* 2641 */     int maxWidth = 0;
/* 2642 */     ColumnInfoRecord cir = getColumnInfo(col);
/* 2643 */     Font columnFont = cir.getCellFormat().getFont();
/* 2644 */     Font defaultFont = WritableWorkbook.NORMAL_STYLE.getFont();
/*      */     
/* 2646 */     for (int i = 0; i < this.numRows; i++)
/*      */     {
/* 2648 */       Cell cell = null;
/* 2649 */       if (this.rows[i] != null)
/*      */       {
/* 2651 */         cell = this.rows[i].getCell(col);
/*      */       }
/*      */       
/* 2654 */       if (cell != null)
/*      */       {
/* 2656 */         String contents = cell.getContents();
/* 2657 */         Font font = cell.getCellFormat().getFont();
/*      */         
/* 2659 */         Font activeFont = font.equals(defaultFont) ? columnFont : font;
/*      */         
/* 2661 */         int pointSize = activeFont.getPointSize();
/* 2662 */         int numChars = contents.length();
/*      */         
/* 2664 */         if ((activeFont.isItalic()) || (activeFont.getBoldWeight() > 400))
/*      */         {
/*      */ 
/* 2667 */           numChars += 2;
/*      */         }
/*      */         
/* 2670 */         int points = numChars * pointSize;
/* 2671 */         maxWidth = Math.max(maxWidth, points * 256);
/*      */       }
/*      */     }
/* 2674 */     cir.setWidth(maxWidth / defaultFont.getPointSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void importSheet(Sheet s)
/*      */   {
/* 2685 */     this.settings = new SheetSettings(s.getSettings(), this);
/*      */     
/* 2687 */     SheetCopier si = new SheetCopier(s, this);
/* 2688 */     si.setColumnFormats(this.columnFormats);
/* 2689 */     si.setFormatRecords(this.formatRecords);
/* 2690 */     si.setHyperlinks(this.hyperlinks);
/* 2691 */     si.setMergedCells(this.mergedCells);
/* 2692 */     si.setRowBreaks(this.rowBreaks);
/* 2693 */     si.setColumnBreaks(this.columnBreaks);
/* 2694 */     si.setSheetWriter(this.sheetWriter);
/* 2695 */     si.setDrawings(this.drawings);
/* 2696 */     si.setImages(this.images);
/* 2697 */     si.setValidatedCells(this.validatedCells);
/*      */     
/* 2699 */     si.importSheet();
/*      */     
/* 2701 */     this.dataValidation = si.getDataValidation();
/* 2702 */     this.comboBox = si.getComboBox();
/* 2703 */     this.plsRecord = si.getPLSRecord();
/* 2704 */     this.chartOnly = si.isChartOnly();
/* 2705 */     this.buttonPropertySet = si.getButtonPropertySet();
/* 2706 */     this.numRows = si.getRows();
/* 2707 */     this.maxRowOutlineLevel = si.getMaxRowOutlineLevel();
/* 2708 */     this.maxColumnOutlineLevel = si.getMaxColumnOutlineLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void applySharedDataValidation(WritableCell c, int extraCols, int extraRows)
/*      */     throws WriteException
/*      */   {
/* 2724 */     if ((c.getWritableCellFeatures() == null) || (!c.getWritableCellFeatures().hasDataValidation()))
/*      */     {
/*      */ 
/* 2727 */       logger.warn("Cannot extend data validation for " + CellReferenceHelper.getCellReference(c.getColumn(), c.getRow()) + " as it has no data validation");
/*      */       
/*      */ 
/*      */ 
/* 2731 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2736 */     int startColumn = c.getColumn();
/* 2737 */     int startRow = c.getRow();
/* 2738 */     int endRow = Math.min(this.numRows - 1, startRow + extraRows);
/* 2739 */     for (int y = startRow; y <= endRow; y++)
/*      */     {
/* 2741 */       if (this.rows[y] != null)
/*      */       {
/* 2743 */         int endCol = Math.min(this.rows[y].getMaxColumn() - 1, startColumn + extraCols);
/*      */         
/* 2745 */         for (int x = startColumn; x <= endCol; x++)
/*      */         {
/*      */ 
/* 2748 */           if ((x != startColumn) || (y != startRow))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 2753 */             WritableCell c2 = this.rows[y].getCell(x);
/*      */             
/*      */ 
/* 2756 */             if ((c2 != null) && (c2.getWritableCellFeatures() != null) && (c2.getWritableCellFeatures().hasDataValidation()))
/*      */             {
/*      */ 
/*      */ 
/* 2760 */               logger.warn("Cannot apply data validation from " + CellReferenceHelper.getCellReference(startColumn, startRow) + " to " + CellReferenceHelper.getCellReference(startColumn + extraCols, startRow + extraRows) + " as cell " + CellReferenceHelper.getCellReference(x, y) + " already has a data validation");
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2770 */               return;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2777 */     WritableCellFeatures sourceDataValidation = c.getWritableCellFeatures();
/* 2778 */     sourceDataValidation.getDVParser().extendCellValidation(extraCols, extraRows);
/*      */     
/*      */ 
/*      */ 
/* 2782 */     for (int y = startRow; y <= startRow + extraRows; y++)
/*      */     {
/* 2784 */       RowRecord rowrec = getRowRecord(y);
/* 2785 */       for (int x = startColumn; x <= startColumn + extraCols; x++)
/*      */       {
/*      */ 
/* 2788 */         if ((x != startColumn) || (y != startRow))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2793 */           WritableCell c2 = rowrec.getCell(x);
/*      */           
/*      */ 
/* 2796 */           if (c2 == null)
/*      */           {
/* 2798 */             Blank b = new Blank(x, y);
/* 2799 */             WritableCellFeatures validation = new WritableCellFeatures();
/* 2800 */             validation.shareDataValidation(sourceDataValidation);
/* 2801 */             b.setCellFeatures(validation);
/* 2802 */             addCell(b);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 2807 */             WritableCellFeatures validation = c2.getWritableCellFeatures();
/*      */             
/* 2809 */             if (validation != null)
/*      */             {
/* 2811 */               validation.shareDataValidation(sourceDataValidation);
/*      */             }
/*      */             else
/*      */             {
/* 2815 */               validation = new WritableCellFeatures();
/* 2816 */               validation.shareDataValidation(sourceDataValidation);
/* 2817 */               c2.setCellFeatures(validation);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSharedDataValidation(WritableCell cell)
/*      */     throws WriteException
/*      */   {
/* 2834 */     WritableCellFeatures wcf = cell.getWritableCellFeatures();
/* 2835 */     if ((wcf == null) || (!wcf.hasDataValidation()))
/*      */     {
/*      */ 
/* 2838 */       return;
/*      */     }
/*      */     
/* 2841 */     DVParser dvp = wcf.getDVParser();
/*      */     
/*      */ 
/*      */ 
/* 2845 */     if (!dvp.extendedCellsValidation())
/*      */     {
/* 2847 */       wcf.removeDataValidation();
/* 2848 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2853 */     if (dvp.extendedCellsValidation())
/*      */     {
/* 2855 */       if ((cell.getColumn() != dvp.getFirstColumn()) || (cell.getRow() != dvp.getFirstRow()))
/*      */       {
/*      */ 
/* 2858 */         logger.warn("Cannot remove data validation from " + CellReferenceHelper.getCellReference(dvp.getFirstColumn(), dvp.getFirstRow()) + "-" + CellReferenceHelper.getCellReference(dvp.getLastColumn(), dvp.getLastRow()) + " because the selected cell " + CellReferenceHelper.getCellReference(cell) + " is not the top left cell in the range");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2867 */         return;
/*      */       }
/*      */     }
/*      */     
/* 2871 */     for (int y = dvp.getFirstRow(); y <= dvp.getLastRow(); y++)
/*      */     {
/* 2873 */       for (int x = dvp.getFirstColumn(); x <= dvp.getLastColumn(); x++)
/*      */       {
/* 2875 */         CellValue c2 = this.rows[y].getCell(x);
/*      */         
/*      */ 
/*      */ 
/* 2879 */         if (c2 != null)
/*      */         {
/* 2881 */           c2.getWritableCellFeatures().removeSharedDataValidation();
/* 2882 */           c2.removeCellFeatures();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2889 */     if (this.dataValidation != null)
/*      */     {
/* 2891 */       this.dataValidation.removeSharedDataValidation(dvp.getFirstColumn(), dvp.getFirstRow(), dvp.getLastColumn(), dvp.getLastRow());
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WritableSheetImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */