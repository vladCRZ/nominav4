/*      */ package jxl.write.biff;
/*      */ 
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.Cell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.Workbook;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.BuiltInName;
/*      */ import jxl.biff.CellReferenceHelper;
/*      */ import jxl.biff.CountryCode;
/*      */ import jxl.biff.Fonts;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.IndexMapping;
/*      */ import jxl.biff.IntegerHelper;
/*      */ import jxl.biff.RangeImpl;
/*      */ import jxl.biff.WorkbookMethods;
/*      */ import jxl.biff.XCTRecord;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingGroup;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.biff.drawing.Origin;
/*      */ import jxl.biff.formula.ExternalSheet;
/*      */ import jxl.common.Assert;
/*      */ import jxl.common.Logger;
/*      */ import jxl.format.Colour;
/*      */ import jxl.format.RGB;
/*      */ import jxl.read.biff.WorkbookParser;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableFont;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WritableWorkbookImpl
/*      */   extends WritableWorkbook
/*      */   implements ExternalSheet, WorkbookMethods
/*      */ {
/*   68 */   private static Logger logger = Logger.getLogger(WritableWorkbookImpl.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private FormattingRecords formatRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private File outputFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList sheets;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Fonts fonts;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ExternalSheetRecord externSheet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList supbooks;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList names;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private HashMap nameRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SharedStrings sharedStrings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean closeStream;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean wbProtected;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private WorkbookSettings settings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList rcirCells;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private DrawingGroup drawingGroup;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Styles styles;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean containsMacros;
/*      */   
/*      */ 
/*      */ 
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   
/*      */ 
/*      */ 
/*      */   private CountryRecord countryRecord;
/*      */   
/*      */ 
/*      */ 
/*  159 */   private static Object SYNCHRONIZER = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] addInFunctionNames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private XCTRecord[] xctRecords;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableWorkbookImpl(OutputStream os, boolean cs, WorkbookSettings ws)
/*      */     throws IOException
/*      */   {
/*  183 */     this.outputFile = new File(os, ws, null);
/*  184 */     this.sheets = new ArrayList();
/*  185 */     this.sharedStrings = new SharedStrings();
/*  186 */     this.nameRecords = new HashMap();
/*  187 */     this.closeStream = cs;
/*  188 */     this.wbProtected = false;
/*  189 */     this.containsMacros = false;
/*  190 */     this.settings = ws;
/*  191 */     this.rcirCells = new ArrayList();
/*  192 */     this.styles = new Styles();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  199 */     synchronized (SYNCHRONIZER)
/*      */     {
/*  201 */       WritableWorkbook.ARIAL_10_PT.uninitialize();
/*  202 */       WritableWorkbook.HYPERLINK_FONT.uninitialize();
/*  203 */       WritableWorkbook.NORMAL_STYLE.uninitialize();
/*  204 */       WritableWorkbook.HYPERLINK_STYLE.uninitialize();
/*  205 */       WritableWorkbook.HIDDEN_STYLE.uninitialize();
/*  206 */       DateRecord.defaultDateFormat.uninitialize();
/*      */     }
/*      */     
/*  209 */     WritableFonts wf = new WritableFonts(this);
/*  210 */     this.fonts = wf;
/*      */     
/*  212 */     WritableFormattingRecords wfr = new WritableFormattingRecords(this.fonts, this.styles);
/*      */     
/*  214 */     this.formatRecords = wfr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableWorkbookImpl(OutputStream os, Workbook w, boolean cs, WorkbookSettings ws)
/*      */     throws IOException
/*      */   {
/*  233 */     WorkbookParser wp = (WorkbookParser)w;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  240 */     synchronized (SYNCHRONIZER)
/*      */     {
/*  242 */       WritableWorkbook.ARIAL_10_PT.uninitialize();
/*  243 */       WritableWorkbook.HYPERLINK_FONT.uninitialize();
/*  244 */       WritableWorkbook.NORMAL_STYLE.uninitialize();
/*  245 */       WritableWorkbook.HYPERLINK_STYLE.uninitialize();
/*  246 */       WritableWorkbook.HIDDEN_STYLE.uninitialize();
/*  247 */       DateRecord.defaultDateFormat.uninitialize();
/*      */     }
/*      */     
/*  250 */     this.closeStream = cs;
/*  251 */     this.sheets = new ArrayList();
/*  252 */     this.sharedStrings = new SharedStrings();
/*  253 */     this.nameRecords = new HashMap();
/*  254 */     this.fonts = wp.getFonts();
/*  255 */     this.formatRecords = wp.getFormattingRecords();
/*  256 */     this.wbProtected = false;
/*  257 */     this.settings = ws;
/*  258 */     this.rcirCells = new ArrayList();
/*  259 */     this.styles = new Styles();
/*  260 */     this.outputFile = new File(os, ws, wp.getCompoundFile());
/*      */     
/*  262 */     this.containsMacros = false;
/*  263 */     if (!ws.getPropertySetsDisabled())
/*      */     {
/*  265 */       this.containsMacros = wp.containsMacros();
/*      */     }
/*      */     
/*      */ 
/*  269 */     if (wp.getCountryRecord() != null)
/*      */     {
/*  271 */       this.countryRecord = new CountryRecord(wp.getCountryRecord());
/*      */     }
/*      */     
/*      */ 
/*  275 */     this.addInFunctionNames = wp.getAddInFunctionNames();
/*      */     
/*      */ 
/*  278 */     this.xctRecords = wp.getXCTRecords();
/*      */     
/*      */ 
/*  281 */     if (wp.getExternalSheetRecord() != null)
/*      */     {
/*  283 */       this.externSheet = new ExternalSheetRecord(wp.getExternalSheetRecord());
/*      */       
/*      */ 
/*  286 */       jxl.read.biff.SupbookRecord[] readsr = wp.getSupbookRecords();
/*  287 */       this.supbooks = new ArrayList(readsr.length);
/*      */       
/*  289 */       for (int i = 0; i < readsr.length; i++)
/*      */       {
/*  291 */         jxl.read.biff.SupbookRecord readSupbook = readsr[i];
/*  292 */         if ((readSupbook.getType() == jxl.read.biff.SupbookRecord.INTERNAL) || (readSupbook.getType() == jxl.read.biff.SupbookRecord.EXTERNAL))
/*      */         {
/*      */ 
/*  295 */           this.supbooks.add(new SupbookRecord(readSupbook, this.settings));
/*      */ 
/*      */ 
/*      */         }
/*  299 */         else if (readSupbook.getType() != jxl.read.biff.SupbookRecord.ADDIN)
/*      */         {
/*  301 */           logger.warn("unsupported supbook type - ignoring");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  309 */     if (wp.getDrawingGroup() != null)
/*      */     {
/*  311 */       this.drawingGroup = new DrawingGroup(wp.getDrawingGroup());
/*      */     }
/*      */     
/*      */ 
/*  315 */     if ((this.containsMacros) && (wp.getButtonPropertySet() != null))
/*      */     {
/*  317 */       this.buttonPropertySet = new ButtonPropertySetRecord(wp.getButtonPropertySet());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  322 */     if (!this.settings.getNamesDisabled())
/*      */     {
/*  324 */       jxl.read.biff.NameRecord[] na = wp.getNameRecords();
/*  325 */       this.names = new ArrayList(na.length);
/*      */       
/*  327 */       for (int i = 0; i < na.length; i++)
/*      */       {
/*  329 */         if (na[i].isBiff8())
/*      */         {
/*  331 */           NameRecord n = new NameRecord(na[i], i);
/*  332 */           this.names.add(n);
/*  333 */           String name = n.getName();
/*  334 */           this.nameRecords.put(name, n);
/*      */         }
/*      */         else
/*      */         {
/*  338 */           logger.warn("Cannot copy Biff7 name records - ignoring");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  343 */     copyWorkbook(w);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  348 */     if (this.drawingGroup != null)
/*      */     {
/*  350 */       this.drawingGroup.updateData(wp.getDrawingGroup());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheet[] getSheets()
/*      */   {
/*  362 */     WritableSheet[] sheetArray = new WritableSheet[getNumberOfSheets()];
/*      */     
/*  364 */     for (int i = 0; i < getNumberOfSheets(); i++)
/*      */     {
/*  366 */       sheetArray[i] = getSheet(i);
/*      */     }
/*  368 */     return sheetArray;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getSheetNames()
/*      */   {
/*  378 */     String[] sheetNames = new String[getNumberOfSheets()];
/*      */     
/*  380 */     for (int i = 0; i < sheetNames.length; i++)
/*      */     {
/*  382 */       sheetNames[i] = getSheet(i).getName();
/*      */     }
/*      */     
/*  385 */     return sheetNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Sheet getReadSheet(int index)
/*      */   {
/*  397 */     return getSheet(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheet getSheet(int index)
/*      */   {
/*  408 */     return (WritableSheet)this.sheets.get(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheet getSheet(String name)
/*      */   {
/*  420 */     boolean found = false;
/*  421 */     Iterator i = this.sheets.iterator();
/*  422 */     WritableSheet s = null;
/*      */     
/*  424 */     while ((i.hasNext()) && (!found))
/*      */     {
/*  426 */       s = (WritableSheet)i.next();
/*      */       
/*  428 */       if (s.getName().equals(name))
/*      */       {
/*  430 */         found = true;
/*      */       }
/*      */     }
/*      */     
/*  434 */     return found ? s : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumberOfSheets()
/*      */   {
/*  444 */     return this.sheets.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws IOException, JxlWriteException
/*      */   {
/*  456 */     this.outputFile.close(this.closeStream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOutputFile(java.io.File fileName)
/*      */     throws IOException
/*      */   {
/*  469 */     FileOutputStream fos = new FileOutputStream(fileName);
/*  470 */     this.outputFile.setOutputFile(fos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WritableSheet createSheet(String name, int index, boolean handleRefs)
/*      */   {
/*  486 */     WritableSheet w = new WritableSheetImpl(name, this.outputFile, this.formatRecords, this.sharedStrings, this.settings, this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  493 */     int pos = index;
/*      */     
/*  495 */     if (index <= 0)
/*      */     {
/*  497 */       pos = 0;
/*  498 */       this.sheets.add(0, w);
/*      */     }
/*  500 */     else if (index > this.sheets.size())
/*      */     {
/*  502 */       pos = this.sheets.size();
/*  503 */       this.sheets.add(w);
/*      */     }
/*      */     else
/*      */     {
/*  507 */       this.sheets.add(index, w);
/*      */     }
/*      */     
/*  510 */     if ((handleRefs) && (this.externSheet != null))
/*      */     {
/*  512 */       this.externSheet.sheetInserted(pos);
/*      */     }
/*      */     
/*  515 */     if ((this.supbooks != null) && (this.supbooks.size() > 0))
/*      */     {
/*  517 */       SupbookRecord supbook = (SupbookRecord)this.supbooks.get(0);
/*  518 */       if (supbook.getType() == SupbookRecord.INTERNAL)
/*      */       {
/*  520 */         supbook.adjustInternal(this.sheets.size());
/*      */       }
/*      */     }
/*      */     
/*  524 */     return w;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheet createSheet(String name, int index)
/*      */   {
/*  538 */     return createSheet(name, index, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSheet(int index)
/*      */   {
/*  550 */     int pos = index;
/*  551 */     if (index <= 0)
/*      */     {
/*  553 */       pos = 0;
/*  554 */       this.sheets.remove(0);
/*      */     }
/*  556 */     else if (index >= this.sheets.size())
/*      */     {
/*  558 */       pos = this.sheets.size() - 1;
/*  559 */       this.sheets.remove(this.sheets.size() - 1);
/*      */     }
/*      */     else
/*      */     {
/*  563 */       this.sheets.remove(index);
/*      */     }
/*      */     
/*  566 */     if (this.externSheet != null)
/*      */     {
/*  568 */       this.externSheet.sheetRemoved(pos);
/*      */     }
/*      */     
/*  571 */     if ((this.supbooks != null) && (this.supbooks.size() > 0))
/*      */     {
/*  573 */       SupbookRecord supbook = (SupbookRecord)this.supbooks.get(0);
/*  574 */       if (supbook.getType() == SupbookRecord.INTERNAL)
/*      */       {
/*  576 */         supbook.adjustInternal(this.sheets.size());
/*      */       }
/*      */     }
/*      */     
/*  580 */     if ((this.names != null) && (this.names.size() > 0))
/*      */     {
/*  582 */       for (int i = 0; i < this.names.size(); i++)
/*      */       {
/*  584 */         NameRecord n = (NameRecord)this.names.get(i);
/*  585 */         int oldRef = n.getSheetRef();
/*  586 */         if (oldRef == pos + 1)
/*      */         {
/*  588 */           n.setSheetRef(0);
/*      */         }
/*  590 */         else if (oldRef > pos + 1)
/*      */         {
/*  592 */           if (oldRef < 1)
/*      */           {
/*  594 */             oldRef = 1;
/*      */           }
/*  596 */           n.setSheetRef(oldRef - 1);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheet moveSheet(int fromIndex, int toIndex)
/*      */   {
/*  613 */     fromIndex = Math.max(fromIndex, 0);
/*  614 */     fromIndex = Math.min(fromIndex, this.sheets.size() - 1);
/*  615 */     toIndex = Math.max(toIndex, 0);
/*  616 */     toIndex = Math.min(toIndex, this.sheets.size() - 1);
/*      */     
/*  618 */     WritableSheet sheet = (WritableSheet)this.sheets.remove(fromIndex);
/*  619 */     this.sheets.add(toIndex, sheet);
/*      */     
/*  621 */     return sheet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write()
/*      */     throws IOException
/*      */   {
/*  635 */     WritableSheetImpl wsi = null;
/*  636 */     for (int i = 0; i < getNumberOfSheets(); i++)
/*      */     {
/*  638 */       wsi = (WritableSheetImpl)getSheet(i);
/*      */       
/*      */ 
/*      */ 
/*  642 */       wsi.checkMergedBorders();
/*      */       
/*      */ 
/*  645 */       Range range = wsi.getSettings().getPrintArea();
/*  646 */       if (range != null)
/*      */       {
/*  648 */         addNameArea(BuiltInName.PRINT_AREA, wsi, range.getTopLeft().getColumn(), range.getTopLeft().getRow(), range.getBottomRight().getColumn(), range.getBottomRight().getRow(), false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  658 */       Range rangeR = wsi.getSettings().getPrintTitlesRow();
/*  659 */       Range rangeC = wsi.getSettings().getPrintTitlesCol();
/*  660 */       if ((rangeR != null) && (rangeC != null))
/*      */       {
/*  662 */         addNameArea(BuiltInName.PRINT_TITLES, wsi, rangeR.getTopLeft().getColumn(), rangeR.getTopLeft().getRow(), rangeR.getBottomRight().getColumn(), rangeR.getBottomRight().getRow(), rangeC.getTopLeft().getColumn(), rangeC.getTopLeft().getRow(), rangeC.getBottomRight().getColumn(), rangeC.getBottomRight().getRow(), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  675 */       else if (rangeR != null)
/*      */       {
/*  677 */         addNameArea(BuiltInName.PRINT_TITLES, wsi, rangeR.getTopLeft().getColumn(), rangeR.getTopLeft().getRow(), rangeR.getBottomRight().getColumn(), rangeR.getBottomRight().getRow(), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  686 */       else if (rangeC != null)
/*      */       {
/*  688 */         addNameArea(BuiltInName.PRINT_TITLES, wsi, rangeC.getTopLeft().getColumn(), rangeC.getTopLeft().getRow(), rangeC.getBottomRight().getColumn(), rangeC.getBottomRight().getRow(), false);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  699 */     if (!this.settings.getRationalizationDisabled())
/*      */     {
/*  701 */       rationalize();
/*      */     }
/*      */     
/*      */ 
/*  705 */     BOFRecord bof = new BOFRecord(BOFRecord.workbookGlobals);
/*  706 */     this.outputFile.write(bof);
/*      */     
/*      */ 
/*  709 */     if (this.settings.getTemplate())
/*      */     {
/*      */ 
/*  712 */       TemplateRecord trec = new TemplateRecord();
/*  713 */       this.outputFile.write(trec);
/*      */     }
/*      */     
/*      */ 
/*  717 */     InterfaceHeaderRecord ihr = new InterfaceHeaderRecord();
/*  718 */     this.outputFile.write(ihr);
/*      */     
/*  720 */     MMSRecord mms = new MMSRecord(0, 0);
/*  721 */     this.outputFile.write(mms);
/*      */     
/*  723 */     InterfaceEndRecord ier = new InterfaceEndRecord();
/*  724 */     this.outputFile.write(ier);
/*      */     
/*  726 */     WriteAccessRecord wr = new WriteAccessRecord(this.settings.getWriteAccess());
/*  727 */     this.outputFile.write(wr);
/*      */     
/*  729 */     CodepageRecord cp = new CodepageRecord();
/*  730 */     this.outputFile.write(cp);
/*      */     
/*  732 */     DSFRecord dsf = new DSFRecord();
/*  733 */     this.outputFile.write(dsf);
/*      */     
/*  735 */     if (this.settings.getExcel9File())
/*      */     {
/*      */ 
/*      */ 
/*  739 */       Excel9FileRecord e9rec = new Excel9FileRecord();
/*  740 */       this.outputFile.write(e9rec);
/*      */     }
/*      */     
/*  743 */     TabIdRecord tabid = new TabIdRecord(getNumberOfSheets());
/*  744 */     this.outputFile.write(tabid);
/*      */     
/*  746 */     if (this.containsMacros)
/*      */     {
/*  748 */       ObjProjRecord objproj = new ObjProjRecord();
/*  749 */       this.outputFile.write(objproj);
/*      */     }
/*      */     
/*  752 */     if (this.buttonPropertySet != null)
/*      */     {
/*  754 */       this.outputFile.write(this.buttonPropertySet);
/*      */     }
/*      */     
/*  757 */     FunctionGroupCountRecord fgcr = new FunctionGroupCountRecord();
/*  758 */     this.outputFile.write(fgcr);
/*      */     
/*      */ 
/*  761 */     WindowProtectRecord wpr = new WindowProtectRecord(this.settings.getWindowProtected());
/*      */     
/*  763 */     this.outputFile.write(wpr);
/*      */     
/*  765 */     ProtectRecord pr = new ProtectRecord(this.wbProtected);
/*  766 */     this.outputFile.write(pr);
/*      */     
/*  768 */     PasswordRecord pw = new PasswordRecord(null);
/*  769 */     this.outputFile.write(pw);
/*      */     
/*  771 */     Prot4RevRecord p4r = new Prot4RevRecord(false);
/*  772 */     this.outputFile.write(p4r);
/*      */     
/*  774 */     Prot4RevPassRecord p4rp = new Prot4RevPassRecord();
/*  775 */     this.outputFile.write(p4rp);
/*      */     
/*      */ 
/*      */ 
/*  779 */     boolean sheetSelected = false;
/*  780 */     WritableSheetImpl wsheet = null;
/*  781 */     int selectedSheetIndex = 0;
/*  782 */     for (int i = 0; (i < getNumberOfSheets()) && (!sheetSelected); i++)
/*      */     {
/*  784 */       wsheet = (WritableSheetImpl)getSheet(i);
/*  785 */       if (wsheet.getSettings().isSelected())
/*      */       {
/*  787 */         sheetSelected = true;
/*  788 */         selectedSheetIndex = i;
/*      */       }
/*      */     }
/*      */     
/*  792 */     if (!sheetSelected)
/*      */     {
/*  794 */       wsheet = (WritableSheetImpl)getSheet(0);
/*  795 */       wsheet.getSettings().setSelected(true);
/*  796 */       selectedSheetIndex = 0;
/*      */     }
/*      */     
/*  799 */     Window1Record w1r = new Window1Record(selectedSheetIndex);
/*  800 */     this.outputFile.write(w1r);
/*      */     
/*  802 */     BackupRecord bkr = new BackupRecord(false);
/*  803 */     this.outputFile.write(bkr);
/*      */     
/*  805 */     HideobjRecord ho = new HideobjRecord(this.settings.getHideobj());
/*  806 */     this.outputFile.write(ho);
/*      */     
/*  808 */     NineteenFourRecord nf = new NineteenFourRecord(false);
/*  809 */     this.outputFile.write(nf);
/*      */     
/*  811 */     PrecisionRecord pc = new PrecisionRecord(false);
/*  812 */     this.outputFile.write(pc);
/*      */     
/*  814 */     RefreshAllRecord rar = new RefreshAllRecord(this.settings.getRefreshAll());
/*  815 */     this.outputFile.write(rar);
/*      */     
/*  817 */     BookboolRecord bb = new BookboolRecord(true);
/*  818 */     this.outputFile.write(bb);
/*      */     
/*      */ 
/*  821 */     this.fonts.write(this.outputFile);
/*      */     
/*      */ 
/*  824 */     this.formatRecords.write(this.outputFile);
/*      */     
/*      */ 
/*  827 */     if (this.formatRecords.getPalette() != null)
/*      */     {
/*  829 */       this.outputFile.write(this.formatRecords.getPalette());
/*      */     }
/*      */     
/*      */ 
/*  833 */     UsesElfsRecord uer = new UsesElfsRecord();
/*  834 */     this.outputFile.write(uer);
/*      */     
/*      */ 
/*      */ 
/*  838 */     int[] boundsheetPos = new int[getNumberOfSheets()];
/*  839 */     Sheet sheet = null;
/*      */     
/*  841 */     for (int i = 0; i < getNumberOfSheets(); i++)
/*      */     {
/*  843 */       boundsheetPos[i] = this.outputFile.getPos();
/*  844 */       sheet = getSheet(i);
/*  845 */       BoundsheetRecord br = new BoundsheetRecord(sheet.getName());
/*  846 */       if (sheet.getSettings().isHidden())
/*      */       {
/*  848 */         br.setHidden();
/*      */       }
/*      */       
/*  851 */       if (((WritableSheetImpl)this.sheets.get(i)).isChartOnly())
/*      */       {
/*  853 */         br.setChartOnly();
/*      */       }
/*      */       
/*  856 */       this.outputFile.write(br);
/*      */     }
/*      */     
/*  859 */     if (this.countryRecord == null)
/*      */     {
/*  861 */       CountryCode lang = CountryCode.getCountryCode(this.settings.getExcelDisplayLanguage());
/*      */       
/*  863 */       if (lang == CountryCode.UNKNOWN)
/*      */       {
/*  865 */         logger.warn("Unknown country code " + this.settings.getExcelDisplayLanguage() + " using " + CountryCode.USA.getCode());
/*      */         
/*      */ 
/*  868 */         lang = CountryCode.USA;
/*      */       }
/*  870 */       CountryCode region = CountryCode.getCountryCode(this.settings.getExcelRegionalSettings());
/*      */       
/*  872 */       this.countryRecord = new CountryRecord(lang, region);
/*  873 */       if (region == CountryCode.UNKNOWN)
/*      */       {
/*  875 */         logger.warn("Unknown country code " + this.settings.getExcelDisplayLanguage() + " using " + CountryCode.UK.getCode());
/*      */         
/*      */ 
/*  878 */         region = CountryCode.UK;
/*      */       }
/*      */     }
/*      */     
/*  882 */     this.outputFile.write(this.countryRecord);
/*      */     
/*      */ 
/*  885 */     if ((this.addInFunctionNames != null) && (this.addInFunctionNames.length > 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  891 */       for (int i = 0; i < this.addInFunctionNames.length; i++)
/*      */       {
/*  893 */         ExternalNameRecord enr = new ExternalNameRecord(this.addInFunctionNames[i]);
/*  894 */         this.outputFile.write(enr);
/*      */       }
/*      */     }
/*      */     
/*  898 */     if (this.xctRecords != null)
/*      */     {
/*  900 */       for (int i = 0; i < this.xctRecords.length; i++)
/*      */       {
/*  902 */         this.outputFile.write(this.xctRecords[i]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  907 */     if (this.externSheet != null)
/*      */     {
/*      */ 
/*  910 */       for (int i = 0; i < this.supbooks.size(); i++)
/*      */       {
/*  912 */         SupbookRecord supbook = (SupbookRecord)this.supbooks.get(i);
/*  913 */         this.outputFile.write(supbook);
/*      */       }
/*  915 */       this.outputFile.write(this.externSheet);
/*      */     }
/*      */     
/*      */ 
/*  919 */     if (this.names != null)
/*      */     {
/*  921 */       for (int i = 0; i < this.names.size(); i++)
/*      */       {
/*  923 */         NameRecord n = (NameRecord)this.names.get(i);
/*  924 */         this.outputFile.write(n);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  929 */     if (this.drawingGroup != null)
/*      */     {
/*  931 */       this.drawingGroup.write(this.outputFile);
/*      */     }
/*      */     
/*  934 */     this.sharedStrings.write(this.outputFile);
/*      */     
/*  936 */     EOFRecord eof = new EOFRecord();
/*  937 */     this.outputFile.write(eof);
/*      */     
/*      */ 
/*      */ 
/*  941 */     for (int i = 0; i < getNumberOfSheets(); i++)
/*      */     {
/*      */ 
/*      */ 
/*  945 */       this.outputFile.setData(IntegerHelper.getFourBytes(this.outputFile.getPos()), boundsheetPos[i] + 4);
/*      */       
/*      */ 
/*      */ 
/*  949 */       wsheet = (WritableSheetImpl)getSheet(i);
/*  950 */       wsheet.write();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void copyWorkbook(Workbook w)
/*      */   {
/*  963 */     int numSheets = w.getNumberOfSheets();
/*  964 */     this.wbProtected = w.isProtected();
/*  965 */     Sheet s = null;
/*  966 */     WritableSheetImpl ws = null;
/*  967 */     for (int i = 0; i < numSheets; i++)
/*      */     {
/*  969 */       s = w.getSheet(i);
/*  970 */       ws = (WritableSheetImpl)createSheet(s.getName(), i, false);
/*  971 */       ws.copy(s);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copySheet(int s, String name, int index)
/*      */   {
/*  985 */     WritableSheet sheet = getSheet(s);
/*  986 */     WritableSheetImpl ws = (WritableSheetImpl)createSheet(name, index);
/*  987 */     ws.copy(sheet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copySheet(String s, String name, int index)
/*      */   {
/* 1000 */     WritableSheet sheet = getSheet(s);
/* 1001 */     WritableSheetImpl ws = (WritableSheetImpl)createSheet(name, index);
/* 1002 */     ws.copy(sheet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtected(boolean prot)
/*      */   {
/* 1012 */     this.wbProtected = prot;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void rationalize()
/*      */   {
/* 1021 */     IndexMapping fontMapping = this.formatRecords.rationalizeFonts();
/* 1022 */     IndexMapping formatMapping = this.formatRecords.rationalizeDisplayFormats();
/* 1023 */     IndexMapping xfMapping = this.formatRecords.rationalize(fontMapping, formatMapping);
/*      */     
/*      */ 
/* 1026 */     WritableSheetImpl wsi = null;
/* 1027 */     for (int i = 0; i < this.sheets.size(); i++)
/*      */     {
/* 1029 */       wsi = (WritableSheetImpl)this.sheets.get(i);
/* 1030 */       wsi.rationalize(xfMapping, fontMapping, formatMapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getInternalSheetIndex(String name)
/*      */   {
/* 1042 */     int index = -1;
/* 1043 */     String[] names = getSheetNames();
/* 1044 */     for (int i = 0; i < names.length; i++)
/*      */     {
/* 1046 */       if (name.equals(names[i]))
/*      */       {
/* 1048 */         index = i;
/* 1049 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1053 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getExternalSheetName(int index)
/*      */   {
/* 1064 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/* 1065 */     SupbookRecord sr = (SupbookRecord)this.supbooks.get(supbookIndex);
/*      */     
/* 1067 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/* 1069 */     if (sr.getType() == SupbookRecord.INTERNAL)
/*      */     {
/*      */ 
/* 1072 */       WritableSheet ws = getSheet(firstTab);
/*      */       
/* 1074 */       return ws.getName();
/*      */     }
/* 1076 */     if (sr.getType() == SupbookRecord.EXTERNAL)
/*      */     {
/* 1078 */       String name = sr.getFileName() + sr.getSheetName(firstTab);
/* 1079 */       return name;
/*      */     }
/*      */     
/*      */ 
/* 1083 */     logger.warn("Unknown Supbook 1");
/* 1084 */     return "[UNKNOWN]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLastExternalSheetName(int index)
/*      */   {
/* 1095 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/* 1096 */     SupbookRecord sr = (SupbookRecord)this.supbooks.get(supbookIndex);
/*      */     
/* 1098 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/* 1100 */     if (sr.getType() == SupbookRecord.INTERNAL)
/*      */     {
/*      */ 
/* 1103 */       WritableSheet ws = getSheet(lastTab);
/*      */       
/* 1105 */       return ws.getName();
/*      */     }
/* 1107 */     if (sr.getType() == SupbookRecord.EXTERNAL)
/*      */     {
/* 1109 */       Assert.verify(false);
/*      */     }
/*      */     
/*      */ 
/* 1113 */     logger.warn("Unknown Supbook 2");
/* 1114 */     return "[UNKNOWN]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public jxl.read.biff.BOFRecord getWorkbookBof()
/*      */   {
/* 1125 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getExternalSheetIndex(int index)
/*      */   {
/* 1137 */     if (this.externSheet == null)
/*      */     {
/* 1139 */       return index;
/*      */     }
/*      */     
/* 1142 */     Assert.verify(this.externSheet != null);
/*      */     
/* 1144 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/* 1146 */     return firstTab;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastExternalSheetIndex(int index)
/*      */   {
/* 1157 */     if (this.externSheet == null)
/*      */     {
/* 1159 */       return index;
/*      */     }
/*      */     
/* 1162 */     Assert.verify(this.externSheet != null);
/*      */     
/* 1164 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/* 1166 */     return lastTab;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getExternalSheetIndex(String sheetName)
/*      */   {
/* 1177 */     if (this.externSheet == null)
/*      */     {
/* 1179 */       this.externSheet = new ExternalSheetRecord();
/* 1180 */       this.supbooks = new ArrayList();
/* 1181 */       this.supbooks.add(new SupbookRecord(getNumberOfSheets(), this.settings));
/*      */     }
/*      */     
/*      */ 
/* 1185 */     boolean found = false;
/* 1186 */     Iterator i = this.sheets.iterator();
/* 1187 */     int sheetpos = 0;
/* 1188 */     WritableSheetImpl s = null;
/*      */     
/* 1190 */     while ((i.hasNext()) && (!found))
/*      */     {
/* 1192 */       s = (WritableSheetImpl)i.next();
/*      */       
/* 1194 */       if (s.getName().equals(sheetName))
/*      */       {
/* 1196 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/* 1200 */         sheetpos++;
/*      */       }
/*      */     }
/*      */     
/* 1204 */     if (found)
/*      */     {
/*      */ 
/*      */ 
/* 1208 */       SupbookRecord supbook = (SupbookRecord)this.supbooks.get(0);
/* 1209 */       if ((supbook.getType() != SupbookRecord.INTERNAL) || (supbook.getNumberOfSheets() != getNumberOfSheets()))
/*      */       {
/*      */ 
/* 1212 */         logger.warn("Cannot find sheet " + sheetName + " in supbook record");
/*      */       }
/*      */       
/* 1215 */       return this.externSheet.getIndex(0, sheetpos);
/*      */     }
/*      */     
/*      */ 
/* 1219 */     int closeSquareBracketsIndex = sheetName.lastIndexOf(']');
/* 1220 */     int openSquareBracketsIndex = sheetName.lastIndexOf('[');
/*      */     
/* 1222 */     if ((closeSquareBracketsIndex == -1) || (openSquareBracketsIndex == -1))
/*      */     {
/*      */ 
/* 1225 */       logger.warn("Square brackets");
/* 1226 */       return -1;
/*      */     }
/*      */     
/* 1229 */     String worksheetName = sheetName.substring(closeSquareBracketsIndex + 1);
/* 1230 */     String workbookName = sheetName.substring(openSquareBracketsIndex + 1, closeSquareBracketsIndex);
/*      */     
/* 1232 */     String path = sheetName.substring(0, openSquareBracketsIndex);
/* 1233 */     String fileName = path + workbookName;
/*      */     
/* 1235 */     boolean supbookFound = false;
/* 1236 */     SupbookRecord externalSupbook = null;
/* 1237 */     int supbookIndex = -1;
/* 1238 */     for (int ind = 0; (ind < this.supbooks.size()) && (!supbookFound); ind++)
/*      */     {
/* 1240 */       externalSupbook = (SupbookRecord)this.supbooks.get(ind);
/* 1241 */       if ((externalSupbook.getType() == SupbookRecord.EXTERNAL) && (externalSupbook.getFileName().equals(fileName)))
/*      */       {
/*      */ 
/* 1244 */         supbookFound = true;
/* 1245 */         supbookIndex = ind;
/*      */       }
/*      */     }
/*      */     
/* 1249 */     if (!supbookFound)
/*      */     {
/* 1251 */       externalSupbook = new SupbookRecord(fileName, this.settings);
/* 1252 */       supbookIndex = this.supbooks.size();
/* 1253 */       this.supbooks.add(externalSupbook);
/*      */     }
/*      */     
/* 1256 */     int sheetIndex = externalSupbook.getSheetIndex(worksheetName);
/*      */     
/* 1258 */     return this.externSheet.getIndex(supbookIndex, sheetIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLastExternalSheetIndex(String sheetName)
/*      */   {
/* 1268 */     if (this.externSheet == null)
/*      */     {
/* 1270 */       this.externSheet = new ExternalSheetRecord();
/* 1271 */       this.supbooks = new ArrayList();
/* 1272 */       this.supbooks.add(new SupbookRecord(getNumberOfSheets(), this.settings));
/*      */     }
/*      */     
/*      */ 
/* 1276 */     boolean found = false;
/* 1277 */     Iterator i = this.sheets.iterator();
/* 1278 */     int sheetpos = 0;
/* 1279 */     WritableSheetImpl s = null;
/*      */     
/* 1281 */     while ((i.hasNext()) && (!found))
/*      */     {
/* 1283 */       s = (WritableSheetImpl)i.next();
/*      */       
/* 1285 */       if (s.getName().equals(sheetName))
/*      */       {
/* 1287 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/* 1291 */         sheetpos++;
/*      */       }
/*      */     }
/*      */     
/* 1295 */     if (!found)
/*      */     {
/* 1297 */       return -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1302 */     SupbookRecord supbook = (SupbookRecord)this.supbooks.get(0);
/* 1303 */     Assert.verify((supbook.getType() == SupbookRecord.INTERNAL) && (supbook.getNumberOfSheets() == getNumberOfSheets()));
/*      */     
/*      */ 
/* 1306 */     return this.externSheet.getIndex(0, sheetpos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColourRGB(Colour c, int r, int g, int b)
/*      */   {
/* 1319 */     this.formatRecords.setColourRGB(c, r, g, b);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RGB getColourRGB(Colour c)
/*      */   {
/* 1329 */     return this.formatRecords.getColourRGB(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName(int index)
/*      */   {
/* 1340 */     Assert.verify((index >= 0) && (index < this.names.size()));
/* 1341 */     NameRecord n = (NameRecord)this.names.get(index);
/* 1342 */     return n.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNameIndex(String name)
/*      */   {
/* 1353 */     NameRecord nr = (NameRecord)this.nameRecords.get(name);
/* 1354 */     return nr != null ? nr.getIndex() : -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addRCIRCell(CellValue cv)
/*      */   {
/* 1365 */     this.rcirCells.add(cv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void columnInserted(WritableSheetImpl s, int col)
/*      */   {
/* 1377 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1378 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext();)
/*      */     {
/* 1380 */       CellValue cv = (CellValue)i.next();
/* 1381 */       cv.columnInserted(s, externalSheetIndex, col);
/*      */     }
/*      */     
/*      */     Iterator i;
/* 1385 */     if (this.names != null)
/*      */     {
/* 1387 */       for (i = this.names.iterator(); i.hasNext();)
/*      */       {
/* 1389 */         NameRecord nameRecord = (NameRecord)i.next();
/* 1390 */         nameRecord.columnInserted(externalSheetIndex, col);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void columnRemoved(WritableSheetImpl s, int col)
/*      */   {
/* 1404 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1405 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext();)
/*      */     {
/* 1407 */       CellValue cv = (CellValue)i.next();
/* 1408 */       cv.columnRemoved(s, externalSheetIndex, col);
/*      */     }
/*      */     
/*      */ 
/* 1412 */     ArrayList removedNames = new ArrayList();
/* 1413 */     Iterator i; if (this.names != null)
/*      */     {
/* 1415 */       for (Iterator i = this.names.iterator(); i.hasNext();)
/*      */       {
/* 1417 */         NameRecord nameRecord = (NameRecord)i.next();
/* 1418 */         boolean removeName = nameRecord.columnRemoved(externalSheetIndex, col);
/*      */         
/*      */ 
/* 1421 */         if (removeName)
/*      */         {
/* 1423 */           removedNames.add(nameRecord);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1428 */       for (i = removedNames.iterator(); i.hasNext();)
/*      */       {
/* 1430 */         NameRecord nameRecord = (NameRecord)i.next();
/* 1431 */         boolean removed = this.names.remove(nameRecord);
/* 1432 */         Assert.verify(removed, "Could not remove name " + nameRecord.getName());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void rowInserted(WritableSheetImpl s, int row)
/*      */   {
/* 1447 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/*      */     
/*      */ 
/* 1450 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext();)
/*      */     {
/* 1452 */       CellValue cv = (CellValue)i.next();
/* 1453 */       cv.rowInserted(s, externalSheetIndex, row);
/*      */     }
/*      */     
/*      */     Iterator i;
/* 1457 */     if (this.names != null)
/*      */     {
/* 1459 */       for (i = this.names.iterator(); i.hasNext();)
/*      */       {
/* 1461 */         NameRecord nameRecord = (NameRecord)i.next();
/* 1462 */         nameRecord.rowInserted(externalSheetIndex, row);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void rowRemoved(WritableSheetImpl s, int row)
/*      */   {
/* 1476 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1477 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext();)
/*      */     {
/* 1479 */       CellValue cv = (CellValue)i.next();
/* 1480 */       cv.rowRemoved(s, externalSheetIndex, row);
/*      */     }
/*      */     
/*      */ 
/* 1484 */     ArrayList removedNames = new ArrayList();
/* 1485 */     Iterator i; if (this.names != null)
/*      */     {
/* 1487 */       for (Iterator i = this.names.iterator(); i.hasNext();)
/*      */       {
/* 1489 */         NameRecord nameRecord = (NameRecord)i.next();
/* 1490 */         boolean removeName = nameRecord.rowRemoved(externalSheetIndex, row);
/*      */         
/* 1492 */         if (removeName)
/*      */         {
/* 1494 */           removedNames.add(nameRecord);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1499 */       for (i = removedNames.iterator(); i.hasNext();)
/*      */       {
/* 1501 */         NameRecord nameRecord = (NameRecord)i.next();
/* 1502 */         boolean removed = this.names.remove(nameRecord);
/* 1503 */         Assert.verify(removed, "Could not remove name " + nameRecord.getName());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableCell findCellByName(String name)
/*      */   {
/* 1520 */     NameRecord nr = (NameRecord)this.nameRecords.get(name);
/*      */     
/* 1522 */     if (nr == null)
/*      */     {
/* 1524 */       return null;
/*      */     }
/*      */     
/* 1527 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */     
/*      */ 
/* 1530 */     int sheetIndex = getExternalSheetIndex(ranges[0].getExternalSheet());
/* 1531 */     WritableSheet s = getSheet(sheetIndex);
/* 1532 */     WritableCell cell = s.getWritableCell(ranges[0].getFirstColumn(), ranges[0].getFirstRow());
/*      */     
/*      */ 
/* 1535 */     return cell;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Range[] findByName(String name)
/*      */   {
/* 1554 */     NameRecord nr = (NameRecord)this.nameRecords.get(name);
/*      */     
/* 1556 */     if (nr == null)
/*      */     {
/* 1558 */       return null;
/*      */     }
/*      */     
/* 1561 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */     
/* 1563 */     Range[] cellRanges = new Range[ranges.length];
/*      */     
/* 1565 */     for (int i = 0; i < ranges.length; i++)
/*      */     {
/* 1567 */       cellRanges[i] = new RangeImpl(this, getExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getFirstColumn(), ranges[i].getFirstRow(), getLastExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getLastColumn(), ranges[i].getLastRow());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1577 */     return cellRanges;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addDrawing(DrawingGroupObject d)
/*      */   {
/* 1587 */     if (this.drawingGroup == null)
/*      */     {
/* 1589 */       this.drawingGroup = new DrawingGroup(Origin.WRITE);
/*      */     }
/*      */     
/* 1592 */     this.drawingGroup.add(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void removeDrawing(Drawing d)
/*      */   {
/* 1602 */     Assert.verify(this.drawingGroup != null);
/*      */     
/* 1604 */     this.drawingGroup.remove(d);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   DrawingGroup getDrawingGroup()
/*      */   {
/* 1614 */     return this.drawingGroup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   DrawingGroup createDrawingGroup()
/*      */   {
/* 1626 */     if (this.drawingGroup == null)
/*      */     {
/* 1628 */       this.drawingGroup = new DrawingGroup(Origin.WRITE);
/*      */     }
/*      */     
/* 1631 */     return this.drawingGroup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getRangeNames()
/*      */   {
/* 1641 */     if (this.names == null)
/*      */     {
/* 1643 */       return new String[0];
/*      */     }
/*      */     
/* 1646 */     String[] n = new String[this.names.size()];
/* 1647 */     for (int i = 0; i < this.names.size(); i++)
/*      */     {
/* 1649 */       NameRecord nr = (NameRecord)this.names.get(i);
/* 1650 */       n[i] = nr.getName();
/*      */     }
/*      */     
/* 1653 */     return n;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRangeName(String name)
/*      */   {
/* 1663 */     int pos = 0;
/* 1664 */     boolean found = false;
/* 1665 */     for (Iterator i = this.names.iterator(); (i.hasNext()) && (!found);)
/*      */     {
/* 1667 */       NameRecord nr = (NameRecord)i.next();
/* 1668 */       if (nr.getName().equals(name))
/*      */       {
/* 1670 */         found = true;
/*      */       }
/*      */       else
/*      */       {
/* 1674 */         pos++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1681 */     if (found)
/*      */     {
/* 1683 */       this.names.remove(pos);
/* 1684 */       if (this.nameRecords.remove(name) == null)
/*      */       {
/* 1686 */         logger.warn("Could not remove " + name + " from index lookups");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Styles getStyles()
/*      */   {
/* 1698 */     return this.styles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNameArea(String name, WritableSheet sheet, int firstCol, int firstRow, int lastCol, int lastRow)
/*      */   {
/* 1718 */     addNameArea(name, sheet, firstCol, firstRow, lastCol, lastRow, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addNameArea(String name, WritableSheet sheet, int firstCol, int firstRow, int lastCol, int lastRow, boolean global)
/*      */   {
/* 1741 */     if (this.names == null)
/*      */     {
/* 1743 */       this.names = new ArrayList();
/*      */     }
/*      */     
/* 1746 */     int externalSheetIndex = getExternalSheetIndex(sheet.getName());
/*      */     
/*      */ 
/* 1749 */     NameRecord nr = new NameRecord(name, this.names.size(), externalSheetIndex, firstRow, lastRow, firstCol, lastCol, global);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1758 */     this.names.add(nr);
/*      */     
/*      */ 
/* 1761 */     this.nameRecords.put(name, nr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addNameArea(BuiltInName name, WritableSheet sheet, int firstCol, int firstRow, int lastCol, int lastRow, boolean global)
/*      */   {
/* 1784 */     if (this.names == null)
/*      */     {
/* 1786 */       this.names = new ArrayList();
/*      */     }
/*      */     
/* 1789 */     int index = getInternalSheetIndex(sheet.getName());
/* 1790 */     int externalSheetIndex = getExternalSheetIndex(sheet.getName());
/*      */     
/*      */ 
/* 1793 */     NameRecord nr = new NameRecord(name, index, externalSheetIndex, firstRow, lastRow, firstCol, lastCol, global);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1802 */     this.names.add(nr);
/*      */     
/*      */ 
/* 1805 */     this.nameRecords.put(name, nr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addNameArea(BuiltInName name, WritableSheet sheet, int firstCol, int firstRow, int lastCol, int lastRow, int firstCol2, int firstRow2, int lastCol2, int lastRow2, boolean global)
/*      */   {
/* 1836 */     if (this.names == null)
/*      */     {
/* 1838 */       this.names = new ArrayList();
/*      */     }
/*      */     
/* 1841 */     int index = getInternalSheetIndex(sheet.getName());
/* 1842 */     int externalSheetIndex = getExternalSheetIndex(sheet.getName());
/*      */     
/*      */ 
/* 1845 */     NameRecord nr = new NameRecord(name, index, externalSheetIndex, firstRow2, lastRow2, firstCol2, lastCol2, firstRow, lastRow, firstCol, lastCol, global);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1856 */     this.names.add(nr);
/*      */     
/*      */ 
/* 1859 */     this.nameRecords.put(name, nr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   WorkbookSettings getSettings()
/*      */   {
/* 1867 */     return this.settings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableCell getWritableCell(String loc)
/*      */   {
/* 1881 */     WritableSheet s = getSheet(CellReferenceHelper.getSheet(loc));
/* 1882 */     return s.getWritableCell(loc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableSheet importSheet(String name, int index, Sheet sheet)
/*      */   {
/* 1896 */     WritableSheet ws = createSheet(name, index);
/* 1897 */     ((WritableSheetImpl)ws).importSheet(sheet);
/*      */     
/* 1899 */     return ws;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WritableWorkbookImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */