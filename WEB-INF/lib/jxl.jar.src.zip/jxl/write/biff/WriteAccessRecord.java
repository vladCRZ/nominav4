/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.Workbook;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WriteAccessRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private static final String authorString = "Java Excel API";
/*    */   private String userName;
/*    */   
/*    */   public WriteAccessRecord(String userName)
/*    */   {
/* 52 */     super(Type.WRITEACCESS);
/*    */     
/* 54 */     this.data = new byte[112];
/* 55 */     String astring = "Java Excel API v" + Workbook.getVersion();
/*    */     
/*    */ 
/*    */ 
/* 59 */     StringHelper.getBytes(astring, this.data, 0);
/*    */     
/*    */ 
/* 62 */     for (int i = astring.length(); i < this.data.length; i++)
/*    */     {
/* 64 */       this.data[i] = 32;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte[] getData()
/*    */   {
/* 75 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jxl.jar!\jxl\write\biff\WriteAccessRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */