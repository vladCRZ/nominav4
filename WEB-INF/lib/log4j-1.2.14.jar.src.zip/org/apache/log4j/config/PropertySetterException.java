/*    */ package org.apache.log4j.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertySetterException
/*    */   extends Exception
/*    */ {
/*    */   protected Throwable rootCause;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PropertySetterException(String msg)
/*    */   {
/* 31 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PropertySetterException(Throwable rootCause)
/*    */   {
/* 38 */     this.rootCause = rootCause;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 46 */     String msg = super.getMessage();
/* 47 */     if ((msg == null) && (this.rootCause != null)) {
/* 48 */       msg = this.rootCause.getMessage();
/*    */     }
/* 50 */     return msg;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\config\PropertySetterException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */