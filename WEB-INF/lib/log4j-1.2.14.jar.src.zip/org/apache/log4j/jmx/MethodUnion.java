package org.apache.log4j.jmx;

import java.lang.reflect.Method;

class MethodUnion
{
  Method readMethod;
  Method writeMethod;
  
  MethodUnion(Method paramMethod1, Method paramMethod2)
  {
    this.readMethod = paramMethod1;
    this.writeMethod = paramMethod2;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\jmx\MethodUnion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */