package org.apache.log4j.net;

import org.apache.log4j.Level;
import org.apache.log4j.Priority;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.TriggeringEventEvaluator;

class DefaultEvaluator
  implements TriggeringEventEvaluator
{
  public boolean isTriggeringEvent(LoggingEvent paramLoggingEvent)
  {
    return paramLoggingEvent.getLevel().isGreaterOrEqual(Level.ERROR);
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\net\DefaultEvaluator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */