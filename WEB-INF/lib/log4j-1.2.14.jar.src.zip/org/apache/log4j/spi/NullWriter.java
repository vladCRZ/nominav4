package org.apache.log4j.spi;

import java.io.Writer;

class NullWriter
  extends Writer
{
  public void close() {}
  
  public void flush() {}
  
  public void write(char[] cbuf, int off, int len) {}
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\spi\NullWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */