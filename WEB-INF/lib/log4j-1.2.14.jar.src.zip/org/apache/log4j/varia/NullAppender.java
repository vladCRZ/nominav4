/*    */ package org.apache.log4j.varia;
/*    */ 
/*    */ import org.apache.log4j.AppenderSkeleton;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullAppender
/*    */   extends AppenderSkeleton
/*    */ {
/* 34 */   private static NullAppender instance = new NullAppender();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void activateOptions() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NullAppender getInstance()
/*    */   {
/* 50 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void close() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doAppend(LoggingEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void append(LoggingEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean requiresLayout()
/*    */   {
/* 72 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\varia\NullAppender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */