/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.OPAQUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassRef
/*     */ {
/*  42 */   static final XMLTypeClassRef XMLTYPE = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final ClassRef newInstance(String paramString)
/*     */     throws ClassNotFoundException
/*     */   {
/*  53 */     return new ClassRef(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private final ThreadLocal<Class> ref = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */   private final String className;
/*     */   
/*     */ 
/*     */ 
/*     */   private ClassRef(String paramString)
/*     */     throws ClassNotFoundException
/*     */   {
/*  73 */     this.className = paramString;
/*     */     
/*     */ 
/*     */ 
/*  77 */     this.ref.set(Class.forName(this.className, true, Thread.currentThread().getContextClassLoader()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Class get()
/*     */   {
/*  93 */     Class localClass = (Class)this.ref.get();
/*  94 */     if (localClass == null) {
/*     */       try {
/*  96 */         localClass = Class.forName(this.className, true, Thread.currentThread().getContextClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException) {
/*  99 */         NoClassDefFoundError localNoClassDefFoundError = new NoClassDefFoundError(localClassNotFoundException.getMessage());
/* 100 */         localNoClassDefFoundError.initCause(localClassNotFoundException);
/* 101 */         throw localNoClassDefFoundError;
/*     */       }
/* 103 */       this.ref.set(localClass);
/*     */     }
/* 105 */     return localClass;
/*     */   }
/*     */   
/*     */   static class XMLTypeClassRef extends ClassRef
/*     */   {
/*     */     protected final Method CREATEXML;
/*     */     
/*     */     static final XMLTypeClassRef newInstance()
/*     */     {
/*     */       try
/*     */       {
/* 116 */         return new XMLTypeClassRef();
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException) {}catch (NoClassDefFoundError localNoClassDefFoundError) {}
/*     */       
/* 120 */       return null;
/*     */     }
/*     */     
/*     */     private XMLTypeClassRef() throws ClassNotFoundException {
/* 124 */       super(null);
/* 125 */       Method localMethod = null;
/*     */       try {
/* 127 */         localMethod = get().getDeclaredMethod("createXML", new Class[] { OPAQUE.class });
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/* 130 */       this.CREATEXML = localMethod;
/*     */     }
/*     */     
/*     */     OPAQUE createXML(OPAQUE paramOPAQUE) throws SQLException
/*     */     {
/* 135 */       get();
/*     */       try {
/* 137 */         return (OPAQUE)this.CREATEXML.invoke(null, new Object[] { paramOPAQUE });
/*     */       }
/*     */       catch (IllegalAccessException localIllegalAccessException) {}catch (InvocationTargetException localInvocationTargetException) {}
/*     */       
/* 141 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 147 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\ClassRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */