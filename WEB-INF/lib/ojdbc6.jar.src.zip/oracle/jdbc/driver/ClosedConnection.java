/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.pool.OraclePooledConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClosedConnection
/*     */   extends PhysicalConnection
/*     */ {
/*     */   ClosedConnection()
/*     */   {
/*  28 */     this.lifecycle = 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void initializePassword(String paramString)
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfByte, OracleStatement paramOracleStatement)
/*     */     throws SQLException
/*     */   {
/*  44 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  45 */     localSQLException.fillInStackTrace();
/*  46 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getDefaultStreamChunkSize()
/*     */   {
/*  54 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   short doGetVersionNumber()
/*     */     throws SQLException
/*     */   {
/*  62 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  63 */     localSQLException.fillInStackTrace();
/*  64 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String doGetDatabaseProductVersion()
/*     */     throws SQLException
/*     */   {
/*  74 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  75 */     localSQLException.fillInStackTrace();
/*  76 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void doRollback()
/*     */     throws SQLException
/*     */   {
/*  86 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  87 */     localSQLException.fillInStackTrace();
/*  88 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void doCommit(int paramInt)
/*     */     throws SQLException
/*     */   {
/*  97 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  98 */     localSQLException.fillInStackTrace();
/*  99 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void doSetAutoCommit(boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/* 108 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 109 */     localSQLException.fillInStackTrace();
/* 110 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void cancelOperationOnServer()
/*     */     throws SQLException
/*     */   {
/* 119 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 120 */     localSQLException.fillInStackTrace();
/* 121 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void doAbort()
/*     */     throws SQLException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void open(OracleStatement paramOracleStatement)
/*     */     throws SQLException
/*     */   {
/* 137 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 138 */     localSQLException.fillInStackTrace();
/* 139 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void logon()
/*     */     throws SQLException
/*     */   {
/* 148 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 149 */     localSQLException.fillInStackTrace();
/* 150 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection)
/*     */     throws SQLException
/*     */   {
/* 160 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 161 */     localSQLException.fillInStackTrace();
/* 162 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt)
/*     */     throws SQLException
/*     */   {
/* 171 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 172 */     localSQLException.fillInStackTrace();
/* 173 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort)
/*     */     throws SQLException
/*     */   {
/* 182 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 183 */     localSQLException.fillInStackTrace();
/* 184 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 190 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\ClosedConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */