/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DBConversion
/*      */ {
/*      */   public static final boolean DO_CONVERSION_WITH_REPLACEMENT = true;
/*      */   public static final short ORACLE8_PROD_VERSION = 8030;
/*      */   protected short serverNCharSetId;
/*      */   protected short serverCharSetId;
/*      */   protected short clientCharSetId;
/*      */   protected CharacterSet serverCharSet;
/*      */   protected CharacterSet serverNCharSet;
/*      */   protected CharacterSet clientCharSet;
/*      */   protected CharacterSet asciiCharSet;
/*      */   protected boolean isServerCharSetFixedWidth;
/*      */   protected boolean isServerNCharSetFixedWidth;
/*      */   protected int c2sNlsRatio;
/*      */   protected int s2cNlsRatio;
/*      */   protected int sMaxCharSize;
/*      */   protected int cMaxCharSize;
/*      */   protected int maxNCharSize;
/*      */   protected boolean isServerCSMultiByte;
/*      */   private boolean isStrictASCIIConversion;
/*      */   public static final short DBCS_CHARSET = -1;
/*      */   public static final short UCS2_CHARSET = -5;
/*      */   public static final short ASCII_CHARSET = 1;
/*      */   public static final short ISO_LATIN_1_CHARSET = 31;
/*      */   public static final short AL24UTFFSS_CHARSET = 870;
/*      */   public static final short UTF8_CHARSET = 871;
/*      */   public static final short AL32UTF8_CHARSET = 873;
/*      */   public static final short AL16UTF16_CHARSET = 2000;
/*      */   
/*      */   public DBConversion(short paramShort1, short paramShort2, short paramShort3, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  117 */     this.isStrictASCIIConversion = paramBoolean;
/*  118 */     if (paramShort2 != -1)
/*      */     {
/*  120 */       init(paramShort1, paramShort2, paramShort3);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public DBConversion(short paramShort1, short paramShort2, short paramShort3)
/*      */     throws SQLException
/*      */   {
/*  129 */     this(paramShort1, paramShort2, paramShort3, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void init(short paramShort1, short paramShort2, short paramShort3)
/*      */     throws SQLException
/*      */   {
/*  140 */     switch (paramShort2)
/*      */     {
/*      */     case -5: 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 31: 
/*      */     case 178: 
/*      */     case 870: 
/*      */     case 871: 
/*      */     case 873: 
/*      */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     default: 
/*  162 */       unexpectedCharset(paramShort2);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  167 */     this.serverCharSetId = paramShort1;
/*  168 */     this.clientCharSetId = paramShort2;
/*  169 */     this.serverCharSet = CharacterSet.make(this.serverCharSetId);
/*      */     
/*  171 */     this.serverNCharSetId = paramShort3;
/*  172 */     this.serverNCharSet = CharacterSet.make(this.serverNCharSetId);
/*      */     
/*  174 */     this.clientCharSet = CharacterSet.make(this.clientCharSetId);
/*      */     
/*  176 */     this.c2sNlsRatio = CharacterSetMetaData.getRatio(paramShort1, paramShort2);
/*  177 */     this.s2cNlsRatio = CharacterSetMetaData.getRatio(paramShort2, paramShort1);
/*  178 */     this.sMaxCharSize = CharacterSetMetaData.getRatio(paramShort1, 1);
/*  179 */     this.cMaxCharSize = CharacterSetMetaData.getRatio(paramShort2, 1);
/*  180 */     this.maxNCharSize = CharacterSetMetaData.getRatio(paramShort3, 1);
/*      */     
/*  182 */     findFixedWidthInfo();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void findFixedWidthInfo()
/*      */     throws SQLException
/*      */   {
/*  193 */     this.isServerCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverCharSetId);
/*  194 */     this.isServerNCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverNCharSetId);
/*  195 */     this.isServerCSMultiByte = (this.sMaxCharSize > 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getServerCharSetId()
/*      */   {
/*  207 */     return this.serverCharSetId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getNCharSetId()
/*      */   {
/*  219 */     return this.serverNCharSetId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean IsNCharFixedWith()
/*      */   {
/*  228 */     return this.serverNCharSetId == 2000;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getClientCharSet()
/*      */   {
/*  243 */     if (this.clientCharSetId == -1) {
/*  244 */       return this.serverCharSetId;
/*      */     }
/*  246 */     return this.clientCharSetId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharacterSet getDbCharSetObj()
/*      */   {
/*  260 */     return this.serverCharSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharacterSet getDriverCharSetObj()
/*      */   {
/*  275 */     return this.clientCharSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharacterSet getDriverNCharSetObj()
/*      */   {
/*  283 */     return this.serverNCharSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final short findDriverCharSet(short paramShort1, short paramShort2)
/*      */   {
/*  346 */     short s = 0;
/*      */     
/*  348 */     switch (paramShort1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 31: 
/*      */     case 178: 
/*      */     case 873: 
/*  362 */       s = paramShort1;
/*      */       
/*  364 */       break;
/*      */     
/*      */     default: 
/*  367 */       s = paramShort2 >= 8030 ? 871 : 870;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*  373 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] stringToDriverCharBytes(String paramString, short paramShort)
/*      */     throws SQLException
/*      */   {
/*  408 */     if (paramString == null)
/*      */     {
/*  410 */       return null;
/*      */     }
/*      */     
/*  413 */     byte[] arrayOfByte = null;
/*      */     
/*  415 */     switch (paramShort)
/*      */     {
/*      */ 
/*      */ 
/*      */     case -5: 
/*      */     case 2000: 
/*  421 */       arrayOfByte = CharacterSet.stringToAL16UTF16Bytes(paramString);
/*      */       
/*      */ 
/*  424 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 2: 
/*  431 */       arrayOfByte = CharacterSet.stringToASCII(paramString);
/*      */       
/*      */ 
/*  434 */       break;
/*      */     
/*      */ 
/*      */     case 870: 
/*      */     case 871: 
/*  439 */       arrayOfByte = CharacterSet.stringToUTF(paramString);
/*      */       
/*      */ 
/*  442 */       break;
/*      */     
/*      */     case 873: 
/*  445 */       arrayOfByte = CharacterSet.stringToAL32UTF8(paramString);
/*      */       
/*      */ 
/*  448 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case -1: 
/*      */     default: 
/*  454 */       unexpectedCharset(paramShort);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  459 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] StringToCharBytes(String paramString)
/*      */     throws SQLException
/*      */   {
/*  481 */     if (paramString.length() == 0) {
/*  482 */       return null;
/*      */     }
/*  484 */     switch (this.clientCharSetId)
/*      */     {
/*      */ 
/*      */     case -1: 
/*  488 */       return this.serverCharSet.convertWithReplacement(paramString);
/*      */     
/*      */     case 2: 
/*      */     case 31: 
/*      */     case 178: 
/*  493 */       return this.clientCharSet.convertWithReplacement(paramString);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  501 */     return stringToDriverCharBytes(paramString, this.clientCharSetId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String CharBytesToString(byte[] paramArrayOfByte, int paramInt)
/*      */     throws SQLException
/*      */   {
/*  551 */     return CharBytesToString(paramArrayOfByte, paramInt, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String CharBytesToString(byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  560 */     String str = null;
/*  561 */     if (paramArrayOfByte.length == 0) {
/*  562 */       return str;
/*      */     }
/*  564 */     switch (this.clientCharSetId)
/*      */     {
/*      */ 
/*      */     case -5: 
/*  568 */       str = CharacterSet.AL16UTF16BytesToString(paramArrayOfByte, paramInt);
/*      */       
/*      */ 
/*  571 */       break;
/*      */     
/*      */ 
/*      */     case 1: 
/*  575 */       str = new String(paramArrayOfByte, 0, 0, paramInt);
/*      */       
/*  577 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*      */     case 31: 
/*      */     case 178: 
/*  585 */       if (paramBoolean) {
/*  586 */         str = this.clientCharSet.toStringWithReplacement(paramArrayOfByte, 0, paramInt);
/*      */       } else {
/*  588 */         str = this.clientCharSet.toString(paramArrayOfByte, 0, paramInt);
/*      */       }
/*  590 */       break;
/*      */     
/*      */ 
/*      */     case 870: 
/*      */     case 871: 
/*  595 */       str = CharacterSet.UTFToString(paramArrayOfByte, 0, paramInt, paramBoolean);
/*      */       
/*      */ 
/*  598 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 873: 
/*  604 */       str = CharacterSet.AL32UTF8ToString(paramArrayOfByte, 0, paramInt, paramBoolean);
/*      */       
/*  606 */       break;
/*      */     
/*      */     case -1: 
/*  609 */       str = this.serverCharSet.toStringWithReplacement(paramArrayOfByte, 0, paramInt);
/*      */       
/*  611 */       break;
/*      */     
/*      */     default: 
/*  614 */       unexpectedCharset(this.clientCharSetId);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  619 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String NCharBytesToString(byte[] paramArrayOfByte, int paramInt)
/*      */     throws SQLException
/*      */   {
/*  627 */     String str = null;
/*      */     
/*  629 */     if (this.clientCharSetId == -1)
/*      */     {
/*      */ 
/*      */ 
/*  633 */       str = this.serverNCharSet.toStringWithReplacement(paramArrayOfByte, 0, paramInt);
/*      */     }
/*      */     else
/*      */     {
/*  637 */       switch (this.serverNCharSetId)
/*      */       {
/*      */ 
/*      */ 
/*      */       case -5: 
/*      */       case 2000: 
/*  643 */         str = CharacterSet.AL16UTF16BytesToString(paramArrayOfByte, paramInt);
/*      */         
/*      */ 
/*  646 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 1: 
/*      */       case 2: 
/*  652 */         str = new String(paramArrayOfByte, 0, 0, paramInt);
/*      */         
/*  654 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 31: 
/*      */       case 178: 
/*  660 */         str = this.serverNCharSet.toStringWithReplacement(paramArrayOfByte, 0, paramInt);
/*  661 */         break;
/*      */       
/*      */ 
/*      */       case 870: 
/*      */       case 871: 
/*  666 */         str = CharacterSet.UTFToString(paramArrayOfByte, 0, paramInt);
/*      */         
/*      */ 
/*  669 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 873: 
/*  675 */         str = CharacterSet.AL32UTF8ToString(paramArrayOfByte, 0, paramInt);
/*      */         
/*  677 */         break;
/*      */       
/*      */       case -1: 
/*  680 */         str = this.serverCharSet.toStringWithReplacement(paramArrayOfByte, 0, paramInt);
/*      */         
/*  682 */         break;
/*      */       
/*      */       default: 
/*  685 */         unexpectedCharset(this.clientCharSetId);
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/*  691 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/*  718 */     return javaCharsToCHARBytes(paramArrayOfChar, paramInt, paramArrayOfByte, this.clientCharSetId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  728 */     return javaCharsToCHARBytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, this.clientCharSetId, paramInt3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/*  738 */     return javaCharsToCHARBytes(paramArrayOfChar, paramInt, paramArrayOfByte, this.serverNCharSetId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  748 */     return javaCharsToCHARBytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, this.serverNCharSetId, paramInt3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int javaCharsToCHARBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte, short paramShort)
/*      */     throws SQLException
/*      */   {
/*  758 */     return javaCharsToCHARBytes(paramArrayOfChar, 0, paramArrayOfByte, 0, paramShort, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int javaCharsToCHARBytes(char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte, int paramInt2, short paramShort, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  767 */     int i = 0;
/*      */     
/*  769 */     switch (paramShort)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -5: 
/*      */     case 2000: 
/*  777 */       i = CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, paramInt3);
/*      */       
/*      */ 
/*  780 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/*      */     case 178: 
/*  786 */       byte[] arrayOfByte = this.clientCharSet.convertWithReplacement(new String(paramArrayOfChar, paramInt1, paramInt3));
/*  787 */       System.arraycopy(arrayOfByte, 0, paramArrayOfByte, 0, arrayOfByte.length);
/*      */       
/*  789 */       i = arrayOfByte.length;
/*      */       
/*  791 */       break;
/*      */     
/*      */ 
/*      */     case 1: 
/*  795 */       i = CharacterSet.convertJavaCharsToASCIIBytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, paramInt3, this.isStrictASCIIConversion);
/*      */       
/*      */ 
/*  798 */       break;
/*      */     
/*      */     case 31: 
/*  801 */       i = CharacterSet.convertJavaCharsToISOLATIN1Bytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, paramInt3);
/*      */       
/*      */ 
/*  804 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 870: 
/*      */     case 871: 
/*  811 */       i = CharacterSet.convertJavaCharsToUTFBytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, paramInt3);
/*      */       
/*      */ 
/*  814 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 873: 
/*  820 */       i = CharacterSet.convertJavaCharsToAL32UTF8Bytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, paramInt3);
/*      */       
/*      */ 
/*  823 */       break;
/*      */     
/*      */     case -1: 
/*  826 */       i = javaCharsToDbCsBytes(paramArrayOfChar, paramInt1, paramArrayOfByte, paramInt2, paramInt3);
/*      */       
/*  828 */       break;
/*      */     
/*      */     default: 
/*  831 */       unexpectedCharset(this.clientCharSetId);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  836 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int CHARBytesToJavaChars(byte[] paramArrayOfByte, int paramInt1, char[] paramArrayOfChar, int paramInt2, int[] paramArrayOfInt, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  867 */     return _CHARBytesToJavaChars(paramArrayOfByte, paramInt1, paramArrayOfChar, paramInt2, this.clientCharSetId, paramArrayOfInt, paramInt3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int NCHARBytesToJavaChars(byte[] paramArrayOfByte, int paramInt1, char[] paramArrayOfChar, int paramInt2, int[] paramArrayOfInt, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  885 */     return _CHARBytesToJavaChars(paramArrayOfByte, paramInt1, paramArrayOfChar, paramInt2, this.serverNCharSetId, paramArrayOfInt, paramInt3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int _CHARBytesToJavaChars(byte[] paramArrayOfByte, int paramInt1, char[] paramArrayOfChar, int paramInt2, short paramShort, int[] paramArrayOfInt, int paramInt3, CharacterSet paramCharacterSet1, CharacterSet paramCharacterSet2, CharacterSet paramCharacterSet3, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  912 */     int i = 0;
/*  913 */     int j = 0;
/*      */     
/*  915 */     switch (paramShort)
/*      */     {
/*      */ 
/*      */ 
/*      */     case -5: 
/*      */     case 2000: 
/*  921 */       j = paramArrayOfInt[0] - paramArrayOfInt[0] % 2;
/*      */       
/*      */ 
/*  924 */       if (paramInt3 > paramArrayOfChar.length - paramInt2) {
/*  925 */         paramInt3 = paramArrayOfChar.length - paramInt2;
/*      */       }
/*      */       
/*      */ 
/*  929 */       if (paramInt3 * 2 < j) {
/*  930 */         j = paramInt3 * 2;
/*      */       }
/*  932 */       i = CharacterSet.convertAL16UTF16BytesToJavaChars(paramArrayOfByte, paramInt1, paramArrayOfChar, paramInt2, j, true);
/*      */       
/*      */ 
/*      */ 
/*  936 */       paramArrayOfInt[0] -= j;
/*      */       
/*  938 */       break;
/*      */     
/*      */ 
/*      */     case 1: 
/*  942 */       j = paramArrayOfInt[0];
/*      */       
/*      */ 
/*  945 */       if (paramInt3 > paramArrayOfChar.length - paramInt2) {
/*  946 */         paramInt3 = paramArrayOfChar.length - paramInt2;
/*      */       }
/*      */       
/*      */ 
/*  950 */       if (paramInt3 < j) {
/*  951 */         j = paramInt3;
/*      */       }
/*  953 */       i = CharacterSet.convertASCIIBytesToJavaChars(paramArrayOfByte, paramInt1, paramArrayOfChar, paramInt2, j);
/*      */       
/*  955 */       paramArrayOfInt[0] -= j;
/*      */       
/*  957 */       break;
/*      */     
/*      */ 
/*      */     case 31: 
/*      */     case 178: 
/*  962 */       j = paramArrayOfInt[0];
/*      */       
/*  964 */       i = paramCharacterSet1.toCharWithReplacement(paramArrayOfByte, 0, paramArrayOfChar, paramInt2, j);
/*  965 */       paramArrayOfInt[0] -= i;
/*      */       
/*  967 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 870: 
/*      */     case 871: 
/*  974 */       if (paramInt3 > paramArrayOfChar.length - paramInt2) {
/*  975 */         paramInt3 = paramArrayOfChar.length - paramInt2;
/*      */       }
/*  977 */       i = CharacterSet.convertUTFBytesToJavaChars(paramArrayOfByte, paramInt1, paramArrayOfChar, paramInt2, paramArrayOfInt, true, paramInt3);
/*      */       
/*      */ 
/*      */ 
/*  981 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 873: 
/*  986 */       if (paramInt3 > paramArrayOfChar.length - paramInt2) {
/*  987 */         paramInt3 = paramArrayOfChar.length - paramInt2;
/*      */       }
/*  989 */       i = CharacterSet.convertAL32UTF8BytesToJavaChars(paramArrayOfByte, paramInt1, paramArrayOfChar, paramInt2, paramArrayOfInt, true, paramInt3);
/*      */       
/*      */ 
/*      */ 
/*  993 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -1: 
/* 1010 */       unexpectedCharset((short)-1);
/* 1011 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 1016 */       CharacterSet localCharacterSet = paramCharacterSet3;
/*      */       
/* 1018 */       if (paramBoolean) {
/* 1019 */         localCharacterSet = paramCharacterSet2;
/*      */       }
/* 1021 */       String str = localCharacterSet.toStringWithReplacement(paramArrayOfByte, paramInt1, paramArrayOfInt[0]);
/* 1022 */       char[] arrayOfChar = str.toCharArray();
/* 1023 */       int k = arrayOfChar.length;
/*      */       
/* 1025 */       if (k > paramInt3) {
/* 1026 */         k = paramInt3;
/*      */       }
/* 1028 */       i = k;
/* 1029 */       paramArrayOfInt[0] -= k;
/*      */       
/* 1031 */       System.arraycopy(arrayOfChar, 0, paramArrayOfChar, paramInt2, k);
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 1036 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] asciiBytesToCHARBytes(byte[] paramArrayOfByte)
/*      */   {
/* 1058 */     byte[] arrayOfByte = null;
/*      */     
/*      */ 
/*      */ 
/*      */     int i;
/*      */     
/*      */ 
/*      */     int j;
/*      */     
/*      */ 
/* 1068 */     switch (this.clientCharSetId)
/*      */     {
/*      */ 
/*      */     case -5: 
/* 1072 */       arrayOfByte = new byte[paramArrayOfByte.length * 2];
/*      */       
/* 1074 */       i = 0; for (j = 0; i < paramArrayOfByte.length;)
/*      */       {
/* 1076 */         arrayOfByte[(j++)] = 0;
/* 1077 */         arrayOfByte[(j++)] = paramArrayOfByte[i];i++; continue;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1083 */         if (this.asciiCharSet == null) {
/* 1084 */           this.asciiCharSet = CharacterSet.make(1);
/*      */         }
/*      */         try
/*      */         {
/* 1088 */           arrayOfByte = this.serverCharSet.convert(this.asciiCharSet, paramArrayOfByte, 0, paramArrayOfByte.length);
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1098 */         arrayOfByte = paramArrayOfByte;
/*      */       }
/*      */     }
/*      */     
/*      */     
/* 1103 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int javaCharsToDbCsBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1140 */     int i = javaCharsToDbCsBytes(paramArrayOfChar, 0, paramArrayOfByte, 0, paramInt);
/*      */     
/* 1142 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int javaCharsToDbCsBytes(char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 1179 */     int i = 0;
/*      */     
/*      */ 
/* 1182 */     catchCharsLen(paramArrayOfChar, paramInt1, paramInt3);
/*      */     
/* 1184 */     String str = new String(paramArrayOfChar, paramInt1, paramInt3);
/* 1185 */     byte[] arrayOfByte = this.serverCharSet.convertWithReplacement(str);
/*      */     
/* 1187 */     str = null;
/*      */     
/* 1189 */     if (arrayOfByte != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1195 */       i = arrayOfByte.length;
/*      */       
/* 1197 */       catchBytesLen(paramArrayOfByte, paramInt2, i);
/* 1198 */       System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt2, i);
/*      */       
/* 1200 */       arrayOfByte = null;
/*      */     }
/*      */     
/* 1203 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int javaCharsToUcs2Bytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1236 */     int i = javaCharsToUcs2Bytes(paramArrayOfChar, 0, paramArrayOfByte, 0, paramInt);
/*      */     
/* 1238 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int javaCharsToUcs2Bytes(char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 1274 */     catchCharsLen(paramArrayOfChar, paramInt1, paramInt3);
/* 1275 */     catchBytesLen(paramArrayOfByte, paramInt2, paramInt3 * 2);
/*      */     
/* 1277 */     int k = paramInt3 + paramInt1;
/*      */     
/* 1279 */     int i = paramInt1; for (int j = paramInt2; i < k; i++)
/*      */     {
/* 1281 */       paramArrayOfByte[(j++)] = ((byte)(paramArrayOfChar[i] >> '\b' & 0xFF));
/* 1282 */       paramArrayOfByte[(j++)] = ((byte)(paramArrayOfChar[i] & 0xFF));
/*      */     }
/*      */     
/* 1285 */     return j - paramInt2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int ucs2BytesToJavaChars(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar)
/*      */     throws SQLException
/*      */   {
/* 1335 */     return CharacterSet.AL16UTF16BytesToJavaChars(paramArrayOfByte, paramInt, paramArrayOfChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] stringToAsciiBytes(String paramString)
/*      */   {
/* 1357 */     return CharacterSet.stringToASCII(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int asciiBytesToJavaChars(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar)
/*      */     throws SQLException
/*      */   {
/* 1384 */     return CharacterSet.convertASCIIBytesToJavaChars(paramArrayOfByte, 0, paramArrayOfChar, 0, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int javaCharsToAsciiBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1412 */     return CharacterSet.convertJavaCharsToASCIIBytes(paramArrayOfChar, 0, paramArrayOfByte, 0, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean isCharSetMultibyte(short paramShort)
/*      */   {
/* 1591 */     switch (paramShort)
/*      */     {
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 31: 
/* 1597 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -5: 
/*      */     case -1: 
/*      */     case 870: 
/*      */     case 871: 
/*      */     case 873: 
/* 1608 */       return true;
/*      */     }
/*      */     
/* 1611 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCharbyteSize()
/*      */   {
/* 1649 */     return _getMaxCharbyteSize(this.clientCharSetId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxNCharbyteSize()
/*      */   {
/* 1657 */     return _getMaxCharbyteSize(this.serverNCharSetId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int _getMaxCharbyteSize(short paramShort)
/*      */   {
/* 1665 */     switch (paramShort)
/*      */     {
/*      */ 
/*      */     case 1: 
/* 1669 */       return 1;
/*      */     
/*      */     case 31: 
/* 1672 */       return 1;
/*      */     
/*      */ 
/*      */     case 870: 
/*      */     case 871: 
/* 1677 */       return 3;
/*      */     
/*      */ 
/*      */     case -5: 
/*      */     case 2000: 
/* 1682 */       return 2;
/*      */     
/*      */     case -1: 
/* 1685 */       return 4;
/*      */     
/*      */     case 873: 
/* 1688 */       return 4;
/*      */     }
/*      */     
/* 1691 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUcs2CharSet()
/*      */   {
/* 1702 */     return this.clientCharSetId == -5;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int RAWBytesToHexChars(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar)
/*      */   {
/* 1714 */     int i = 0; for (int j = 0; i < paramInt; i++)
/*      */     {
/* 1716 */       paramArrayOfChar[(j++)] = ((char)RepConversion.nibbleToHex((byte)(paramArrayOfByte[i] >> 4 & 0xF)));
/*      */       
/*      */ 
/* 1719 */       paramArrayOfChar[(j++)] = ((char)RepConversion.nibbleToHex((byte)(paramArrayOfByte[i] & 0xF)));
/*      */     }
/*      */     
/*      */ 
/* 1723 */     return j;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int hexDigit2Nibble(char paramChar)
/*      */     throws SQLException
/*      */   {
/* 1739 */     int i = Character.digit(paramChar, 16);
/*      */     
/* 1741 */     if (i == -1)
/*      */     {
/*      */ 
/* 1744 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, "Invalid hex digit: " + paramChar);
/* 1745 */       localSQLException.fillInStackTrace();
/* 1746 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1750 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final byte[] hexString2Bytes(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1766 */     int i = paramString.length();
/* 1767 */     char[] arrayOfChar = new char[i];
/*      */     
/* 1769 */     paramString.getChars(0, i, arrayOfChar, 0);
/* 1770 */     return hexChars2Bytes(arrayOfChar, 0, i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final byte[] hexChars2Bytes(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1778 */     int i = 0;
/* 1779 */     int j = paramInt1;
/*      */     
/* 1781 */     if (paramInt2 == 0)
/* 1782 */       return new byte[0];
/*      */     byte[] arrayOfByte;
/* 1784 */     if (paramInt2 % 2 > 0)
/*      */     {
/* 1786 */       arrayOfByte = new byte[(paramInt2 + 1) / 2];
/* 1787 */       arrayOfByte[(i++)] = ((byte)hexDigit2Nibble(paramArrayOfChar[(j++)]));
/*      */     }
/*      */     else
/*      */     {
/* 1791 */       arrayOfByte = new byte[paramInt2 / 2];
/*      */     }
/* 1794 */     for (; 
/* 1794 */         i < arrayOfByte.length; i++)
/*      */     {
/* 1796 */       arrayOfByte[i] = ((byte)(hexDigit2Nibble(paramArrayOfChar[(j++)]) << 4 | hexDigit2Nibble(paramArrayOfChar[(j++)])));
/*      */     }
/*      */     
/* 1799 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream ConvertStream(InputStream paramInputStream, int paramInt)
/*      */   {
/* 1808 */     return new OracleConversionInputStream(this, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream ConvertStream(InputStream paramInputStream, int paramInt1, int paramInt2)
/*      */   {
/* 1817 */     return new OracleConversionInputStream(this, paramInputStream, paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream ConvertStreamInternal(InputStream paramInputStream, int paramInt1, int paramInt2)
/*      */   {
/* 1826 */     return new OracleConversionInputStreamInternal(this, paramInputStream, paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream ConvertStream(Reader paramReader, int paramInt1, int paramInt2, short paramShort)
/*      */   {
/* 1848 */     OracleConversionInputStream localOracleConversionInputStream = new OracleConversionInputStream(this, paramReader, paramInt1, paramInt2, paramShort);
/*      */     
/*      */ 
/* 1851 */     return localOracleConversionInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream ConvertStreamInternal(Reader paramReader, int paramInt1, int paramInt2, short paramShort)
/*      */   {
/* 1860 */     OracleConversionInputStreamInternal localOracleConversionInputStreamInternal = new OracleConversionInputStreamInternal(this, paramReader, paramInt1, paramInt2, paramShort);
/*      */     
/*      */ 
/* 1863 */     return localOracleConversionInputStreamInternal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader ConvertCharacterStream(InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1873 */     return new OracleConversionReader(this, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader ConvertCharacterStream(InputStream paramInputStream, int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 1882 */     OracleConversionReader localOracleConversionReader = new OracleConversionReader(this, paramInputStream, paramInt);
/*      */     
/*      */ 
/* 1885 */     localOracleConversionReader.setFormOfUse(paramShort);
/*      */     
/* 1887 */     return localOracleConversionReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream CharsToStream(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 1896 */     if (paramInt3 == 10) {
/* 1897 */       return new AsciiStream(paramArrayOfChar, paramInt1, paramInt2);
/*      */     }
/* 1899 */     if (paramInt3 == 11) {
/* 1900 */       return new UnicodeStream(paramArrayOfChar, paramInt1, paramInt2);
/*      */     }
/*      */     
/* 1903 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 39, "unknownConversion");
/* 1904 */     localSQLException.fillInStackTrace();
/* 1905 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   class AsciiStream
/*      */     extends OracleBufferedStream
/*      */   {
/*      */     AsciiStream(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     {
/* 1915 */       super();
/* 1916 */       this.currentBufferSize = this.initialBufferSize;
/* 1917 */       this.resizableBuffer = new byte[this.currentBufferSize];
/*      */       
/* 1919 */       if ((DBConversion.this.serverCharSetId == 1) || (!DBConversion.this.isStrictASCIIConversion))
/*      */       {
/* 1921 */         int i = paramInt1; for (int j = 0; j < paramInt2; j++) {
/* 1922 */           this.resizableBuffer[j] = ((byte)paramArrayOfChar[(i++)]);
/*      */         }
/*      */       }
/*      */       else {
/* 1926 */         if (DBConversion.this.asciiCharSet == null)
/* 1927 */           DBConversion.this.asciiCharSet = CharacterSet.make(1);
/* 1928 */         this.resizableBuffer = DBConversion.this.asciiCharSet.convertWithReplacement(new String(paramArrayOfChar, paramInt1, paramInt2));
/*      */       }
/*      */       
/* 1931 */       this.count = paramInt2;
/*      */     }
/*      */     
/*      */     public boolean needBytes()
/*      */     {
/* 1936 */       return (!this.closed) && (this.pos < this.count);
/*      */     }
/*      */     
/*      */     public boolean needBytes(int paramInt)
/*      */     {
/* 1941 */       return (!this.closed) && (this.pos < this.count);
/*      */     }
/*      */   }
/*      */   
/*      */   class UnicodeStream
/*      */     extends OracleBufferedStream
/*      */   {
/*      */     UnicodeStream(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     {
/* 1950 */       super();
/* 1951 */       this.currentBufferSize = this.initialBufferSize;
/* 1952 */       this.resizableBuffer = new byte[this.currentBufferSize];
/*      */       
/* 1954 */       int i = paramInt1; for (int j = 0; j < paramInt2;)
/*      */       {
/* 1956 */         int k = paramArrayOfChar[(i++)];
/*      */         
/* 1958 */         this.resizableBuffer[(j++)] = ((byte)(k >> 8 & 0xFF));
/* 1959 */         this.resizableBuffer[(j++)] = ((byte)(k & 0xFF));
/*      */       }
/*      */       
/* 1962 */       this.count = paramInt2;
/*      */     }
/*      */     
/*      */     public boolean needBytes()
/*      */     {
/* 1967 */       return (!this.closed) && (this.pos < this.count);
/*      */     }
/*      */     
/*      */     public boolean needBytes(int paramInt)
/*      */     {
/* 1972 */       return (!this.closed) && (this.pos < this.count);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final void unexpectedCharset(short paramShort)
/*      */     throws SQLException
/*      */   {
/* 1990 */     SQLException localSQLException = DatabaseError.createSqlException(null, 35, "DBConversion");
/* 1991 */     localSQLException.fillInStackTrace();
/* 1992 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final void catchBytesLen(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2023 */     if (paramInt1 + paramInt2 > paramArrayOfByte.length)
/*      */     {
/*      */ 
/* 2026 */       SQLException localSQLException = DatabaseError.createSqlException(null, 39, "catchBytesLen");
/* 2027 */       localSQLException.fillInStackTrace();
/* 2028 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final void catchCharsLen(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2059 */     if (paramInt1 + paramInt2 > paramArrayOfChar.length)
/*      */     {
/*      */ 
/* 2062 */       SQLException localSQLException = DatabaseError.createSqlException(null, 39, "catchCharsLen");
/* 2063 */       localSQLException.fillInStackTrace();
/* 2064 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int getUtfLen(char paramChar)
/*      */   {
/* 2081 */     int i = 0;
/*      */     
/* 2083 */     if ((paramChar & 0xFF80) == 0)
/*      */     {
/* 2085 */       i = 1;
/*      */     }
/* 2087 */     else if ((paramChar & 0xF800) == 0)
/*      */     {
/* 2089 */       i = 2;
/*      */     }
/*      */     else
/*      */     {
/* 2093 */       i = 3;
/*      */     }
/*      */     
/* 2096 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int encodedByteLength(String paramString, boolean paramBoolean)
/*      */   {
/* 2112 */     int i = 0;
/* 2113 */     if (paramString != null)
/*      */     {
/* 2115 */       i = paramString.length();
/* 2116 */       if (i != 0)
/*      */       {
/* 2118 */         if (paramBoolean)
/*      */         {
/* 2120 */           i = this.isServerNCharSetFixedWidth ? i * this.maxNCharSize : this.serverNCharSet.encodedByteLength(paramString);
/*      */         }
/*      */         else
/*      */         {
/* 2124 */           i = this.isServerCharSetFixedWidth ? i * this.sMaxCharSize : this.serverCharSet.encodedByteLength(paramString);
/*      */         }
/*      */       }
/*      */     }
/* 2128 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int encodedByteLength(char[] paramArrayOfChar, boolean paramBoolean)
/*      */   {
/* 2143 */     int i = 0;
/* 2144 */     if (paramArrayOfChar != null)
/*      */     {
/* 2146 */       i = paramArrayOfChar.length;
/* 2147 */       if (i != 0)
/*      */       {
/* 2149 */         if (paramBoolean)
/*      */         {
/* 2151 */           i = this.isServerNCharSetFixedWidth ? i * this.maxNCharSize : this.serverNCharSet.encodedByteLength(paramArrayOfChar);
/*      */         }
/*      */         else
/*      */         {
/* 2155 */           i = this.isServerCharSetFixedWidth ? i * this.sMaxCharSize : this.serverCharSet.encodedByteLength(paramArrayOfChar);
/*      */         }
/*      */       }
/*      */     }
/* 2159 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 2174 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2203 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\DBConversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */