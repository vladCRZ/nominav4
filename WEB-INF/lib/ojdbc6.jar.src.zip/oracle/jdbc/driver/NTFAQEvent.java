/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.aq.AQMessageProperties.DeliveryMode;
/*     */ import oracle.jdbc.aq.AQMessageProperties.MessageState;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType;
/*     */ import oracle.jdbc.aq.AQNotificationEvent.EventType;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFAQEvent
/*     */   extends AQNotificationEvent
/*     */ {
/*     */   private String registrationString;
/*     */   private int namespace;
/*     */   private byte[] payload;
/*  49 */   private String queueName = null;
/*  50 */   private byte[] messageId = null;
/*  51 */   private String consumerName = null;
/*     */   private NTFConnection conn;
/*     */   private AQMessagePropertiesI msgProp;
/*  54 */   private AQNotificationEvent.EventType eventType = AQNotificationEvent.EventType.REGULAR;
/*  55 */   private AQNotificationEvent.AdditionalEventType additionalEventType = AQNotificationEvent.AdditionalEventType.NONE;
/*     */   private ByteBuffer dataBuffer;
/*  57 */   private boolean isReady = false;
/*     */   private short databaseVersion;
/*     */   
/*     */   NTFAQEvent(NTFConnection paramNTFConnection, short paramShort)
/*     */     throws IOException
/*     */   {
/*  63 */     super(paramNTFConnection);
/*     */     
/*  65 */     this.conn = paramNTFConnection;
/*  66 */     int i = this.conn.readInt();
/*  67 */     byte[] arrayOfByte = new byte[i];
/*  68 */     this.conn.readBuffer(arrayOfByte, 0, i);
/*  69 */     this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
/*  70 */     this.databaseVersion = paramShort;
/*     */   }
/*     */   
/*     */ 
/*     */   private void initEvent()
/*     */     throws SQLException
/*     */   {
/*  77 */     int i = this.dataBuffer.get();
/*  78 */     int j = this.dataBuffer.getInt();
/*  79 */     byte[] arrayOfByte1 = new byte[j];
/*  80 */     this.dataBuffer.get(arrayOfByte1, 0, j);
/*  81 */     this.registrationString = this.conn.charset.toString(arrayOfByte1, 0, j);
/*     */     
/*     */ 
/*     */ 
/*  85 */     int k = this.dataBuffer.get();
/*  86 */     int m = this.dataBuffer.getInt();
/*  87 */     byte[] arrayOfByte2 = new byte[m];
/*  88 */     this.dataBuffer.get(arrayOfByte2, 0, m);
/*  89 */     this.namespace = arrayOfByte2[0];
/*     */     
/*     */ 
/*  92 */     int n = this.dataBuffer.get();
/*  93 */     int i1 = this.dataBuffer.getInt();
/*  94 */     if (i1 > 0)
/*     */     {
/*  96 */       this.payload = new byte[i1];
/*  97 */       this.dataBuffer.get(this.payload, 0, i1);
/*     */     }
/*     */     else {
/* 100 */       this.payload = null;
/*     */     }
/* 102 */     if (this.dataBuffer.hasRemaining())
/*     */     {
/* 104 */       int i2 = 0;
/* 105 */       if (this.databaseVersion >= 10200)
/*     */       {
/*     */ 
/* 108 */         i3 = this.dataBuffer.get();
/* 109 */         i4 = this.dataBuffer.getInt();
/* 110 */         i2 = this.dataBuffer.getInt();
/*     */       }
/*     */       
/*     */ 
/* 114 */       int i3 = this.dataBuffer.get();
/* 115 */       int i4 = this.dataBuffer.getInt();
/* 116 */       byte[] arrayOfByte3 = new byte[i4];
/* 117 */       this.dataBuffer.get(arrayOfByte3, 0, i4);
/* 118 */       this.queueName = this.conn.charset.toString(arrayOfByte3, 0, i4);
/*     */       
/*     */ 
/*     */ 
/* 122 */       int i5 = this.dataBuffer.get();
/* 123 */       int i6 = this.dataBuffer.getInt();
/* 124 */       this.messageId = new byte[i6];
/* 125 */       this.dataBuffer.get(this.messageId, 0, i6);
/*     */       
/*     */ 
/* 128 */       int i7 = this.dataBuffer.get();
/* 129 */       int i8 = this.dataBuffer.getInt();
/* 130 */       byte[] arrayOfByte4 = new byte[i8];
/* 131 */       this.dataBuffer.get(arrayOfByte4, 0, i8);
/* 132 */       this.consumerName = this.conn.charset.toString(arrayOfByte4, 0, i8);
/*     */       
/*     */ 
/*     */ 
/* 136 */       int i9 = this.dataBuffer.get();
/* 137 */       int i10 = this.dataBuffer.getInt();
/* 138 */       byte[] arrayOfByte5 = new byte[i10];
/* 139 */       this.dataBuffer.get(arrayOfByte5, 0, i10);
/*     */       
/*     */ 
/* 142 */       int i11 = this.dataBuffer.get();
/* 143 */       int i12 = this.dataBuffer.getInt();
/* 144 */       int i13 = this.dataBuffer.getInt();
/* 145 */       if (arrayOfByte5[0] == 1)
/* 146 */         i13 = -i13;
/* 147 */       int i14 = i13;
/*     */       
/*     */ 
/* 150 */       int i15 = this.dataBuffer.get();
/* 151 */       int i16 = this.dataBuffer.getInt();
/* 152 */       int i17 = this.dataBuffer.getInt();
/*     */       
/*     */ 
/* 155 */       int i18 = this.dataBuffer.get();
/* 156 */       int i19 = this.dataBuffer.getInt();
/* 157 */       byte[] arrayOfByte6 = new byte[i19];
/* 158 */       this.dataBuffer.get(arrayOfByte6, 0, i19);
/*     */       
/*     */ 
/* 161 */       int i20 = this.dataBuffer.get();
/* 162 */       int i21 = this.dataBuffer.getInt();
/* 163 */       int i22 = this.dataBuffer.getInt();
/* 164 */       if (arrayOfByte6[0] == 1)
/* 165 */         i22 = -i22;
/* 166 */       int i23 = i22;
/*     */       
/*     */ 
/* 169 */       int i24 = this.dataBuffer.get();
/* 170 */       int i25 = this.dataBuffer.getInt();
/* 171 */       int i26 = this.dataBuffer.getInt();
/*     */       
/*     */ 
/* 174 */       int i27 = this.dataBuffer.get();
/* 175 */       int i28 = this.dataBuffer.getInt();
/* 176 */       byte[] arrayOfByte7 = new byte[i28];
/* 177 */       this.dataBuffer.get(arrayOfByte7, 0, i28);
/* 178 */       TIMESTAMP localTIMESTAMP = new TIMESTAMP(arrayOfByte7);
/*     */       
/*     */ 
/* 181 */       int i29 = this.dataBuffer.get();
/* 182 */       int i30 = this.dataBuffer.getInt();
/* 183 */       byte[] arrayOfByte8 = new byte[i30];
/* 184 */       this.dataBuffer.get(arrayOfByte8, 0, i30);
/* 185 */       int i31 = arrayOfByte8[0];
/*     */       
/*     */ 
/* 188 */       int i32 = this.dataBuffer.get();
/* 189 */       int i33 = this.dataBuffer.getInt();
/* 190 */       byte[] arrayOfByte9 = new byte[i33];
/* 191 */       this.dataBuffer.get(arrayOfByte9, 0, i33);
/* 192 */       String str1 = this.conn.charset.toString(arrayOfByte9, 0, i33);
/*     */       
/*     */ 
/*     */ 
/* 196 */       int i34 = this.dataBuffer.get();
/* 197 */       int i35 = this.dataBuffer.getInt();
/* 198 */       byte[] arrayOfByte10 = new byte[i35];
/* 199 */       this.dataBuffer.get(arrayOfByte10, 0, i35);
/* 200 */       String str2 = this.conn.charset.toString(arrayOfByte10, 0, i35);
/*     */       
/*     */ 
/*     */ 
/* 204 */       int i36 = this.dataBuffer.get();
/* 205 */       int i37 = this.dataBuffer.getInt();
/* 206 */       byte[] arrayOfByte11 = null;
/* 207 */       if (i37 > 0)
/*     */       {
/* 209 */         arrayOfByte11 = new byte[i37];
/* 210 */         this.dataBuffer.get(arrayOfByte11, 0, i37);
/*     */       }
/*     */       
/*     */ 
/* 214 */       int i38 = this.dataBuffer.get();
/* 215 */       int i39 = this.dataBuffer.getInt();
/* 216 */       byte[] arrayOfByte12 = new byte[i39];
/* 217 */       this.dataBuffer.get(arrayOfByte12, 0, i39);
/* 218 */       String str3 = this.conn.charset.toString(arrayOfByte12, 0, i39);
/*     */       
/*     */ 
/*     */ 
/* 222 */       int i40 = this.dataBuffer.get();
/* 223 */       int i41 = this.dataBuffer.getInt();
/* 224 */       byte[] arrayOfByte13 = new byte[i41];
/* 225 */       this.dataBuffer.get(arrayOfByte13, 0, i41);
/* 226 */       String str4 = this.conn.charset.toString(arrayOfByte13, 0, i41);
/*     */       
/*     */ 
/*     */ 
/* 230 */       int i42 = this.dataBuffer.get();
/* 231 */       int i43 = this.dataBuffer.getInt();
/* 232 */       int i44 = this.dataBuffer.get();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 237 */       this.msgProp = new AQMessagePropertiesI();
/* 238 */       this.msgProp.setAttempts(i26);
/* 239 */       this.msgProp.setCorrelation(str2);
/* 240 */       this.msgProp.setDelay(i17);
/* 241 */       this.msgProp.setEnqueueTime(localTIMESTAMP.timestampValue());
/* 242 */       this.msgProp.setMessageState(AQMessageProperties.MessageState.getMessageState(i31));
/* 243 */       if (this.databaseVersion >= 10200)
/* 244 */         this.msgProp.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(i2));
/* 245 */       this.msgProp.setPreviousQueueMessageId(arrayOfByte11);
/* 246 */       AQAgentI localAQAgentI = new AQAgentI();
/* 247 */       localAQAgentI.setAddress(str4);
/* 248 */       localAQAgentI.setName(str3);
/* 249 */       localAQAgentI.setProtocol(i44);
/* 250 */       this.msgProp.setSender(localAQAgentI);
/*     */       
/* 252 */       this.msgProp.setPriority(i14);
/* 253 */       this.msgProp.setExpiration(i23);
/* 254 */       this.msgProp.setExceptionQueue(str1);
/*     */     }
/* 256 */     this.isReady = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public AQMessageProperties getMessageProperties()
/*     */     throws SQLException
/*     */   {
/* 263 */     if (!this.isReady)
/* 264 */       initEvent();
/* 265 */     return this.msgProp;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getRegistration()
/*     */     throws SQLException
/*     */   {
/* 272 */     if (!this.isReady)
/* 273 */       initEvent();
/* 274 */     return this.registrationString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AQNotificationEvent.EventType getEventType()
/*     */   {
/* 281 */     return this.eventType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AQNotificationEvent.AdditionalEventType getAdditionalEventType()
/*     */   {
/* 288 */     return this.additionalEventType;
/*     */   }
/*     */   
/*     */ 
/*     */   void setEventType(AQNotificationEvent.EventType paramEventType)
/*     */     throws IOException
/*     */   {
/* 295 */     this.eventType = paramEventType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setAdditionalEventType(AQNotificationEvent.AdditionalEventType paramAdditionalEventType)
/*     */   {
/* 302 */     this.additionalEventType = paramAdditionalEventType;
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getPayload()
/*     */     throws SQLException
/*     */   {
/* 309 */     if (!this.isReady)
/* 310 */       initEvent();
/* 311 */     return this.payload;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQueueName()
/*     */     throws SQLException
/*     */   {
/* 318 */     if (!this.isReady)
/* 319 */       initEvent();
/* 320 */     return this.queueName;
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getMessageId()
/*     */     throws SQLException
/*     */   {
/* 327 */     if (!this.isReady)
/* 328 */       initEvent();
/* 329 */     return this.messageId;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getConsumerName()
/*     */     throws SQLException
/*     */   {
/* 336 */     if (!this.isReady)
/* 337 */       initEvent();
/* 338 */     return this.consumerName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionInformation()
/*     */   {
/* 345 */     return this.conn.connectionDescription;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 353 */     if (!this.isReady)
/*     */     {
/*     */       try
/*     */       {
/* 357 */         initEvent();
/*     */       }
/*     */       catch (SQLException localSQLException)
/*     */       {
/* 361 */         return localSQLException.getMessage();
/*     */       }
/*     */     }
/* 364 */     StringBuffer localStringBuffer = new StringBuffer();
/* 365 */     localStringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
/* 366 */     localStringBuffer.append("Event type              : " + this.eventType + "\n");
/* 367 */     if (this.additionalEventType != AQNotificationEvent.AdditionalEventType.NONE)
/* 368 */       localStringBuffer.append("Additional event type   : " + this.additionalEventType + "\n");
/* 369 */     localStringBuffer.append("Namespace               : " + this.namespace + "\n");
/* 370 */     localStringBuffer.append("Registration            : " + this.registrationString + "\n");
/* 371 */     localStringBuffer.append("Queue name              : " + this.queueName + "\n");
/* 372 */     localStringBuffer.append("Consumer name           : " + this.consumerName + "\n");
/* 373 */     if (this.payload != null)
/*     */     {
/* 375 */       localStringBuffer.append("Payload length          : " + this.payload.length + "\n");
/* 376 */       localStringBuffer.append("Payload (first 50 bytes): " + byteBufferToHexString(this.payload, 50) + "\n");
/*     */     }
/*     */     else {
/* 379 */       localStringBuffer.append("Payload                 : null\n"); }
/* 380 */     localStringBuffer.append("Message ID              : " + byteBufferToHexString(this.messageId, 50) + "\n");
/* 381 */     if (this.msgProp != null)
/* 382 */       localStringBuffer.append(this.msgProp.toString());
/* 383 */     return localStringBuffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   static final String byteBufferToHexString(byte[] paramArrayOfByte, int paramInt)
/*     */   {
/* 389 */     if (paramArrayOfByte == null) {
/* 390 */       return null;
/*     */     }
/* 392 */     int i = 0;
/* 393 */     int j = 1;
/* 394 */     StringBuffer localStringBuffer = new StringBuffer();
/* 395 */     while ((i < paramArrayOfByte.length) && (i < paramInt))
/*     */     {
/* 397 */       if (j == 0) {
/* 398 */         localStringBuffer.append(' ');
/*     */       } else
/* 400 */         j = 0;
/* 401 */       str = Integer.toHexString(paramArrayOfByte[i] & 0xFF);
/* 402 */       if (str.length() == 1)
/* 403 */         str = "0" + str;
/* 404 */       localStringBuffer.append(str);
/* 405 */       i++;
/*     */     }
/* 407 */     String str = localStringBuffer.toString();
/* 408 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 413 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\NTFAQEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */