/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType;
/*     */ import oracle.jdbc.aq.AQNotificationEvent.EventType;
/*     */ import oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType;
/*     */ import oracle.jdbc.dcn.DatabaseChangeEvent.EventType;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFConnection
/*     */   extends Thread
/*     */ {
/*     */   private static final int NS_HEADER_SIZE = 10;
/*     */   private static final int INTERRUPT_SIGNAL = -2;
/*     */   private SocketChannel channel;
/*  72 */   private ByteBuffer inBuffer = null;
/*  73 */   private ByteBuffer outBuffer = null;
/*     */   
/*     */ 
/*     */   private int currentNSPacketLength;
/*     */   
/*     */ 
/*     */   private int currentNSPacketType;
/*     */   
/*     */ 
/*     */   private ByteBuffer currentNSPacketDataBuffer;
/*     */   
/*  84 */   private boolean needsToBeClosed = false;
/*     */   
/*     */   private NTFManager ntfManager;
/*     */   
/*  88 */   private Selector selector = null;
/*  89 */   private Iterator iterator = null;
/*  90 */   private SelectionKey aKey = null;
/*     */   
/*     */   int remotePort;
/*     */   
/*     */   String remoteAddress;
/*     */   
/*     */   String remoteName;
/*     */   int localPort;
/*     */   String localAddress;
/*     */   String localName;
/*     */   String connectionDescription;
/* 101 */   CharacterSet charset = null;
/*     */   
/*     */   static final int NSPTCN = 1;
/*     */   
/*     */   static final int NSPTAC = 2;
/*     */   
/*     */   static final int NSPTAK = 3;
/*     */   
/*     */   static final int NSPTRF = 4;
/*     */   static final int NSPTRD = 5;
/*     */   static final int NSPTDA = 6;
/*     */   static final int NSPTNL = 7;
/*     */   static final int NSPTAB = 9;
/*     */   static final int NSPTRS = 11;
/*     */   static final int NSPTMK = 12;
/*     */   static final int NSPTAT = 13;
/*     */   static final int NSPTCNL = 14;
/*     */   static final int NSPTHI = 19;
/*     */   static final short KPDNFY_TIMEOUT = 1;
/*     */   static final short KPDNFY_GROUPING = 2;
/*     */   
/*     */   NTFConnection(NTFManager paramNTFManager, SocketChannel paramSocketChannel)
/*     */   {
/*     */     try
/*     */     {
/* 126 */       this.ntfManager = paramNTFManager;
/* 127 */       this.channel = paramSocketChannel;
/* 128 */       this.channel.configureBlocking(false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */       this.inBuffer = ByteBuffer.allocate(4096);
/* 141 */       this.outBuffer = ByteBuffer.allocate(2048);
/* 142 */       Socket localSocket = this.channel.socket();
/* 143 */       InetAddress localInetAddress1 = localSocket.getInetAddress();
/* 144 */       InetAddress localInetAddress2 = localSocket.getLocalAddress();
/* 145 */       this.remotePort = localSocket.getPort();
/* 146 */       this.localPort = localSocket.getLocalPort();
/* 147 */       this.remoteAddress = localInetAddress1.getHostAddress();
/* 148 */       this.remoteName = localInetAddress1.getHostName();
/* 149 */       this.localAddress = localInetAddress2.getHostAddress();
/* 150 */       this.localName = localInetAddress2.getHostName();
/* 151 */       this.connectionDescription = ("local=" + this.localName + "/" + this.localAddress + ":" + this.localPort + ", remote=" + this.remoteName + "/" + this.remoteAddress + ":" + this.remotePort);
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 168 */       this.selector = Selector.open();
/* 169 */       this.channel.register(this.selector, 1);
/*     */       
/* 171 */       int i = 0;
/* 172 */       this.inBuffer.limit(0);
/*     */       
/* 174 */       while (!this.needsToBeClosed)
/*     */       {
/*     */ 
/* 177 */         if (!this.inBuffer.hasRemaining()) {
/*     */           do {
/* 179 */             i = readFromNetwork();
/* 180 */           } while (i == 0);
/*     */         }
/* 182 */         if (i == -1) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 188 */         if (i != -2)
/*     */         {
/* 190 */           unmarshalOneNSPacket(); }
/*     */       }
/* 192 */       this.selector.close();
/* 193 */       this.channel.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readFromNetwork()
/*     */     throws IOException
/*     */   {
/* 226 */     this.inBuffer.compact();
/*     */     
/*     */     for (;;)
/*     */     {
/* 230 */       if ((this.iterator == null) || (!this.iterator.hasNext()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 235 */         this.selector.select();
/*     */         
/*     */ 
/*     */ 
/* 239 */         if (this.needsToBeClosed)
/*     */         {
/* 241 */           return -2;
/*     */         }
/*     */         
/* 244 */         this.iterator = this.selector.selectedKeys().iterator();
/*     */       } else {
/* 246 */         this.aKey = ((SelectionKey)this.iterator.next());
/* 247 */         if ((this.aKey.readyOps() & 0x1) == 1) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */     int i = this.channel.read(this.inBuffer);
/* 261 */     if (i > 0)
/*     */     {
/*     */ 
/* 264 */       this.inBuffer.flip();
/*     */     }
/*     */     
/*     */ 
/* 268 */     this.iterator.remove();
/*     */     
/* 270 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getNextNSPacket()
/*     */     throws IOException
/*     */   {
/* 284 */     while ((!this.inBuffer.hasRemaining()) || (this.inBuffer.remaining() < 10)) {
/* 285 */       readFromNetwork();
/*     */     }
/* 287 */     this.currentNSPacketLength = this.inBuffer.getShort();
/*     */     
/* 289 */     this.inBuffer.position(this.inBuffer.position() + 2);
/* 290 */     this.currentNSPacketType = this.inBuffer.get();
/*     */     
/* 292 */     this.inBuffer.position(this.inBuffer.position() + 5);
/*     */     
/*     */ 
/*     */ 
/* 296 */     while (this.inBuffer.remaining() < this.currentNSPacketLength - 10) {
/* 297 */       readFromNetwork();
/*     */     }
/*     */     
/* 300 */     int i = this.inBuffer.limit();
/* 301 */     int j = this.inBuffer.position() + this.currentNSPacketLength - 10;
/*     */     
/*     */ 
/*     */ 
/* 305 */     this.inBuffer.limit(j);
/* 306 */     this.currentNSPacketDataBuffer = this.inBuffer.slice();
/* 307 */     this.inBuffer.limit(i);
/*     */     
/* 309 */     this.inBuffer.position(j);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void unmarshalOneNSPacket()
/*     */     throws IOException
/*     */   {
/* 325 */     getNextNSPacket();
/*     */     
/*     */ 
/*     */ 
/* 329 */     if (this.currentNSPacketDataBuffer.hasRemaining())
/*     */     {
/* 331 */       switch (this.currentNSPacketType)
/*     */       {
/*     */ 
/*     */ 
/*     */       case 1: 
/* 336 */         byte[] arrayOfByte1 = { 0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 0, 0, 8, 0, Byte.MAX_VALUE, -1, 1, 0, 0, 0, 0, 24, 65, 1 };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 341 */         this.outBuffer.clear();
/* 342 */         this.outBuffer.put(arrayOfByte1);
/* 343 */         this.outBuffer.limit(24);
/* 344 */         this.outBuffer.rewind();
/* 345 */         this.channel.write(this.outBuffer);
/* 346 */         break;
/*     */       
/*     */       case 6: 
/* 349 */         if ((this.currentNSPacketDataBuffer.get(0) == -34) && (this.currentNSPacketDataBuffer.get(1) == -83))
/*     */         {
/*     */ 
/*     */ 
/* 353 */           byte[] arrayOfByte2 = { 0, Byte.MAX_VALUE, 0, 0, 6, 0, 0, 0, 0, 0, -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, 0, 31, 0, 14, 0, 1, -34, -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0 };
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 371 */           this.outBuffer.clear();
/* 372 */           this.outBuffer.put(arrayOfByte2);
/* 373 */           this.outBuffer.limit(arrayOfByte2.length);
/* 374 */           this.outBuffer.rewind();
/* 375 */           this.channel.write(this.outBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 420 */           unmarshalNSDataPacket();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void unmarshalNSDataPacket()
/*     */     throws IOException
/*     */   {
/* 494 */     int i = readShort();
/*     */     
/*     */ 
/* 497 */     int j = readInt();
/*     */     
/* 499 */     int k = readByte();
/* 500 */     int m = readInt();
/* 501 */     int n = readShort();
/* 502 */     if ((this.charset == null) || (this.charset.getOracleId() != n)) {
/* 503 */       this.charset = CharacterSet.make(n);
/*     */     }
/*     */     
/* 506 */     int i1 = readByte();
/* 507 */     int i2 = readInt();
/* 508 */     int i3 = readShort();
/*     */     
/*     */ 
/* 511 */     int i4 = readByte();
/* 512 */     int i5 = readInt();
/* 513 */     int i6 = readShort();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 518 */     int i7 = (j - 21) / 9;
/* 519 */     int[] arrayOfInt = new int[i7];
/* 520 */     for (int i8 = 0; i8 < i7; i8++)
/*     */     {
/* 522 */       int i9 = readByte();
/* 523 */       i10 = readInt();
/* 524 */       byte[] arrayOfByte = new byte[i10];
/* 525 */       readBuffer(arrayOfByte, 0, i10);
/*     */       
/*     */ 
/*     */ 
/* 529 */       for (int i11 = 0; i11 < i10; i11++) {
/* 530 */         if (i11 < 4)
/* 531 */           arrayOfInt[i8] |= (arrayOfByte[i11] & 0xFF) << 8 * (i10 - i11 - 1);
/*     */       }
/*     */     }
/* 534 */     NTFDCNEvent localNTFDCNEvent = null;
/* 535 */     NTFAQEvent localNTFAQEvent = null;
/* 536 */     int i10 = 0;
/* 537 */     short s = 0;
/* 538 */     NTFRegistration[] arrayOfNTFRegistration = null;
/*     */     int i13;
/* 540 */     if (i >= 2)
/*     */     {
/*     */ 
/* 543 */       i12 = readShort();
/* 544 */       arrayOfNTFRegistration = new NTFRegistration[arrayOfInt.length];
/* 545 */       for (i13 = 0; i13 < arrayOfInt.length; i13++)
/*     */       {
/* 547 */         arrayOfNTFRegistration[i13] = this.ntfManager.getRegistration(arrayOfInt[i13]);
/* 548 */         if (arrayOfNTFRegistration[i13] != null)
/*     */         {
/* 550 */           i10 = arrayOfNTFRegistration[i13].getNamespace();
/* 551 */           s = arrayOfNTFRegistration[i13].getDatabaseVersion();
/*     */         }
/*     */       }
/*     */       
/* 555 */       if (i10 == 2)
/*     */       {
/*     */ 
/* 558 */         localNTFDCNEvent = new NTFDCNEvent(this, s);
/*     */       }
/* 560 */       else if (i10 == 1)
/*     */       {
/*     */ 
/* 563 */         localNTFAQEvent = new NTFAQEvent(this, s);
/*     */       }
/* 565 */       else if (i10 != 0) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 578 */     int i12 = 0;
/* 579 */     if (i >= 3)
/*     */     {
/*     */ 
/* 582 */       i13 = readShort();
/* 583 */       int i14 = readInt();
/* 584 */       int i15 = readByte();
/* 585 */       int i16 = readInt();
/* 586 */       i12 = readShort();
/* 587 */       if ((i10 == 2) && (localNTFDCNEvent != null))
/*     */       {
/*     */ 
/* 590 */         localNTFDCNEvent.setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType.getEventType(i12));
/*     */         
/*     */ 
/* 593 */         if (i12 == 1) {
/* 594 */           localNTFDCNEvent.setEventType(DatabaseChangeEvent.EventType.DEREG);
/*     */         }
/* 596 */       } else if ((i10 == 1) && (localNTFAQEvent != null))
/*     */       {
/*     */ 
/* 599 */         localNTFAQEvent.setAdditionalEventType(AQNotificationEvent.AdditionalEventType.getEventType(i12));
/*     */         
/*     */ 
/* 602 */         if (i12 == 1) {
/* 603 */           localNTFAQEvent.setEventType(AQNotificationEvent.EventType.DEREG);
/*     */         }
/*     */       }
/*     */     }
/* 607 */     if ((i <= 3) || 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 612 */       (arrayOfNTFRegistration != null))
/*     */     {
/* 614 */       if (i10 == 2) {
/* 615 */         for (i13 = 0; i13 < arrayOfNTFRegistration.length; i13++)
/* 616 */           if ((arrayOfNTFRegistration[i13] != null) && (localNTFDCNEvent != null))
/*     */           {
/* 618 */             arrayOfNTFRegistration[i13].notify(localNTFDCNEvent); }
/*     */       }
/* 620 */       if (i10 == 1) {
/* 621 */         for (i13 = 0; i13 < arrayOfNTFRegistration.length; i13++) {
/* 622 */           if ((arrayOfNTFRegistration[i13] != null) && (localNTFAQEvent != null))
/*     */           {
/* 624 */             arrayOfNTFRegistration[i13].notify(localNTFAQEvent);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void closeThisConnection()
/*     */   {
/* 637 */     this.needsToBeClosed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte readByte()
/*     */     throws IOException
/*     */   {
/* 648 */     byte b = 0;
/* 649 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/* 650 */       b = this.currentNSPacketDataBuffer.get();
/*     */     }
/*     */     else {
/* 653 */       getNextNSPacket();
/* 654 */       b = this.currentNSPacketDataBuffer.get();
/*     */     }
/* 656 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   short readShort()
/*     */     throws IOException
/*     */   {
/* 665 */     short s = 0;
/* 666 */     if (this.currentNSPacketDataBuffer.remaining() >= 2) {
/* 667 */       s = this.currentNSPacketDataBuffer.getShort();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 673 */       int i = readByte() & 0xFF;
/* 674 */       int j = readByte() & 0xFF;
/* 675 */       s = (short)(i << 8 | j);
/*     */     }
/* 677 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int readInt()
/*     */     throws IOException
/*     */   {
/* 686 */     int i = 0;
/* 687 */     if (this.currentNSPacketDataBuffer.remaining() >= 4) {
/* 688 */       i = this.currentNSPacketDataBuffer.getInt();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 694 */       int j = readByte() & 0xFF;
/* 695 */       int k = readByte() & 0xFF;
/* 696 */       int m = readByte() & 0xFF;
/* 697 */       int n = readByte() & 0xFF;
/* 698 */       i = j << 24 | k << 16 | m << 8 | n;
/*     */     }
/* 700 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   long readLong()
/*     */     throws IOException
/*     */   {
/* 709 */     long l1 = 0L;
/* 710 */     if (this.currentNSPacketDataBuffer.remaining() >= 8) {
/* 711 */       l1 = this.currentNSPacketDataBuffer.getLong();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 717 */       long l2 = readByte() & 0xFF;
/* 718 */       long l3 = readByte() & 0xFF;
/* 719 */       long l4 = readByte() & 0xFF;
/* 720 */       long l5 = readByte() & 0xFF;
/* 721 */       long l6 = readByte() & 0xFF;
/* 722 */       long l7 = readByte() & 0xFF;
/* 723 */       long l8 = readByte() & 0xFF;
/* 724 */       long l9 = readByte() & 0xFF;
/* 725 */       l1 = l2 << 56 | l3 << 48 | l4 << 40 | l5 << 32 | l6 << 24 | l7 << 16 | l8 << 8 | l9;
/*     */     }
/* 727 */     return l1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void readBuffer(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */     throws IOException
/*     */   {
/* 738 */     if (this.currentNSPacketDataBuffer.remaining() >= paramInt2) {
/* 739 */       this.currentNSPacketDataBuffer.get(paramArrayOfByte, paramInt1, paramInt2);
/*     */     }
/*     */     else {
/* 742 */       int i = 0;
/* 743 */       int j = 0;
/* 744 */       int k = 0;
/* 745 */       int m = this.currentNSPacketDataBuffer.remaining();
/* 746 */       this.currentNSPacketDataBuffer.get(paramArrayOfByte, paramInt1, m);
/* 747 */       paramInt1 += m;
/* 748 */       j += m;
/* 749 */       while (i == 0)
/*     */       {
/* 751 */         getNextNSPacket();
/* 752 */         m = this.currentNSPacketDataBuffer.remaining();
/* 753 */         k = Math.min(m, paramInt2 - j);
/* 754 */         this.currentNSPacketDataBuffer.get(paramArrayOfByte, paramInt1, k);
/* 755 */         paramInt1 += k;
/* 756 */         j += k;
/* 757 */         if (j == paramInt2) {
/* 758 */           i = 1;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String packetToString(ByteBuffer paramByteBuffer)
/*     */     throws IOException
/*     */   {
/* 770 */     int i = 0;
/*     */     
/* 772 */     char[] arrayOfChar = new char[8];
/* 773 */     StringBuffer localStringBuffer = new StringBuffer();
/* 774 */     int k = paramByteBuffer.position();
/*     */     
/* 776 */     while (paramByteBuffer.hasRemaining()) {
/* 777 */       int j = paramByteBuffer.get();
/* 778 */       String str = Integer.toHexString(j & 0xFF);
/* 779 */       str = str.toUpperCase();
/* 780 */       if (str.length() == 1)
/* 781 */         str = "0" + str;
/* 782 */       localStringBuffer.append(str);
/* 783 */       localStringBuffer.append(' ');
/* 784 */       if ((j > 32) && (j < 127)) {
/* 785 */         arrayOfChar[i] = ((char)j);
/*     */       } else
/* 787 */         arrayOfChar[i] = '.';
/* 788 */       i++;
/* 789 */       if (i == 8) {
/* 790 */         localStringBuffer.append('|');
/* 791 */         localStringBuffer.append(arrayOfChar);
/* 792 */         localStringBuffer.append('|');
/* 793 */         localStringBuffer.append('\n');
/* 794 */         i = 0;
/*     */       }
/*     */     }
/* 797 */     if (i != 0) {
/* 798 */       int m = 8 - i;
/* 799 */       for (int n = 0; n < m * 3; n++)
/* 800 */         localStringBuffer.append(' ');
/* 801 */       localStringBuffer.append('|');
/* 802 */       localStringBuffer.append(arrayOfChar, 0, i);
/* 803 */       for (n = 0; n < m; n++)
/* 804 */         localStringBuffer.append(' ');
/* 805 */       localStringBuffer.append('|');
/* 806 */       localStringBuffer.append('\n');
/*     */     }
/* 808 */     localStringBuffer.append("\nEnd of Packet\n\n");
/* 809 */     paramByteBuffer.position(k);
/* 810 */     return localStringBuffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 815 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\NTFConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */