/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.JAVA_STRUCT;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamedTypeAccessor
/*     */   extends TypeAccessor
/*     */ {
/*     */   private static final Class xmlType;
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/*  38 */     init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
/*  39 */     initForDataAccess(paramInt, 0, paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString)
/*     */     throws SQLException
/*     */   {
/*  49 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*  50 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*  52 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType)
/*     */     throws SQLException
/*     */   {
/*  62 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*     */     
/*  64 */     this.describeOtype = paramOracleType;
/*     */     
/*  66 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*     */ 
/*  69 */     this.internalOtype = paramOracleType;
/*     */     
/*  71 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */   
/*     */ 
/*     */   OracleType otypeFromName(String paramString)
/*     */     throws SQLException
/*     */   {
/*  78 */     if (!this.outBind) {
/*  79 */       return TypeDescriptor.getTypeDescriptor(paramString, this.statement.connection).getPickler();
/*     */     }
/*  81 */     if (this.externalType == 2003) {
/*  82 */       return ArrayDescriptor.createDescriptor(paramString, this.statement.connection).getOracleTypeCOLLECTION();
/*     */     }
/*  84 */     if ((this.externalType == 2007) || (this.externalType == 2009))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */       return OpaqueDescriptor.createDescriptor(paramString, this.statement.connection).getPickler();
/*     */     }
/*     */     
/*  94 */     return StructDescriptor.createDescriptor(paramString, this.statement.connection).getOracleTypeADT();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString)
/*     */     throws SQLException
/*     */   {
/* 103 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*     */     
/* 105 */     this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 121 */     return getObject(paramInt, this.statement.connection.getTypeMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 131 */     Class localClass = null;
/*     */     try {
/* 133 */       localClass = Class.forName("oracle.xdb.XMLType");
/*     */     }
/*     */     catch (Throwable localThrowable) {}
/* 136 */     xmlType = localClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt, Map paramMap)
/*     */     throws SQLException
/*     */   {
/*     */     Object localObject1;
/*     */     
/*     */ 
/* 148 */     if (this.rowSpaceIndicator == null)
/*     */     {
/* 150 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 151 */       ((SQLException)localObject1).fillInStackTrace();
/* 152 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 158 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */     {
/*     */ 
/*     */ 
/* 162 */       if (this.externalType == 0)
/*     */       {
/* 164 */         localObject1 = getOracleObject(paramInt);
/*     */         
/*     */ 
/*     */ 
/* 168 */         if (localObject1 == null) {
/* 169 */           return null;
/*     */         }
/* 171 */         if ((localObject1 instanceof STRUCT)) {
/* 172 */           return ((STRUCT)localObject1).toJdbc(paramMap);
/*     */         }
/* 174 */         if ((localObject1 instanceof OPAQUE)) {
/* 175 */           Object localObject2 = ((OPAQUE)localObject1).toJdbc(paramMap);
/* 176 */           return localObject2;
/*     */         }
/*     */         
/* 179 */         return ((Datum)localObject1).toJdbc();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 184 */       switch (this.externalType)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */       case 2008: 
/* 190 */         paramMap = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 2000: 
/*     */       case 2002: 
/*     */       case 2003: 
/*     */       case 2007: 
/* 199 */         localObject1 = getOracleObject(paramInt);
/*     */         
/*     */ 
/*     */ 
/* 203 */         if (localObject1 == null) {
/* 204 */           return null;
/*     */         }
/* 206 */         if ((localObject1 instanceof STRUCT)) {
/* 207 */           return ((STRUCT)localObject1).toJdbc(paramMap);
/*     */         }
/* 209 */         return ((Datum)localObject1).toJdbc();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 2009: 
/* 215 */         localObject1 = getOracleObject(paramInt);
/* 216 */         if (localObject1 == null) {
/* 217 */           return null;
/*     */         }
/*     */         try {
/* 220 */           return (SQLXML)localObject1;
/*     */ 
/*     */         }
/*     */         catch (ClassCastException localClassCastException)
/*     */         {
/* 225 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 226 */           localSQLException.fillInStackTrace();
/* 227 */           throw localSQLException;
/*     */         }
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */ 
/* 234 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 235 */       localSQLException.fillInStackTrace();
/* 236 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Datum getOracleObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 259 */     Object localObject1 = null;
/*     */     
/*     */ 
/* 262 */     if (this.rowSpaceIndicator == null)
/*     */     {
/* 264 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 265 */       ((SQLException)localObject2).fillInStackTrace();
/* 266 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     Object localObject2 = pickledBytes(paramInt);
/*     */     
/* 275 */     if ((localObject2 == null) || (localObject2.length == 0))
/*     */     {
/* 277 */       return null;
/*     */     }
/*     */     
/* 280 */     PhysicalConnection localPhysicalConnection = this.statement.connection;
/* 281 */     OracleTypeADT localOracleTypeADT = (OracleTypeADT)this.internalOtype;
/* 282 */     TypeDescriptor localTypeDescriptor = TypeDescriptor.getTypeDescriptor(localOracleTypeADT.getFullName(), localPhysicalConnection, (byte[])localObject2, 0L);
/*     */     
/*     */ 
/* 285 */     switch (localTypeDescriptor.getTypeCode())
/*     */     {
/*     */ 
/*     */     case 2003: 
/* 289 */       localObject1 = new ARRAY((ArrayDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 291 */       break;
/*     */     
/*     */     case 2002: 
/* 294 */       localObject1 = new STRUCT((StructDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 296 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 2009: 
/* 302 */       localObject1 = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection));
/*     */       
/* 304 */       break;
/*     */     
/*     */ 
/*     */     case 2007: 
/* 308 */       localObject1 = new OPAQUE((OpaqueDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 310 */       break;
/*     */     
/*     */     case 2008: 
/* 313 */       localObject1 = new JAVA_STRUCT((StructDescriptor)localTypeDescriptor, (byte[])localObject2, localPhysicalConnection);
/*     */       
/* 315 */       break;
/*     */     
/*     */     case 2004: 
/*     */     case 2005: 
/*     */     case 2006: 
/*     */     default: 
/* 321 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/* 322 */       localSQLException.fillInStackTrace();
/* 323 */       throw localSQLException;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 330 */     return (Datum)localObject1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ARRAY getARRAY(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 346 */     return (ARRAY)getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   STRUCT getSTRUCT(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 362 */     return (STRUCT)getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OPAQUE getOPAQUE(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 378 */     return (OPAQUE)getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */   boolean isNull(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 385 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 389 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 390 */       ((SQLException)localObject).fillInStackTrace();
/* 391 */       throw ((Throwable)localObject);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 396 */     Object localObject = pickledBytes(paramInt);
/* 397 */     return (localObject == null) || (localObject.length == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLXML getSQLXML(int paramInt)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 413 */       OPAQUE localOPAQUE = (OPAQUE)getOracleObject(paramInt);
/* 414 */       if (localOPAQUE == null) return null;
/* 415 */       return (SQLXML)localOPAQUE;
/*     */     }
/*     */     catch (ClassCastException localClassCastException)
/*     */     {
/* 419 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 420 */       localSQLException.fillInStackTrace();
/* 421 */       throw localSQLException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 430 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\NamedTypeAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */