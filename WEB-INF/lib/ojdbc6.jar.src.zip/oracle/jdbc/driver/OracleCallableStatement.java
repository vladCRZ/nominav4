/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.sql.ANYDATA;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleCallableStatement
/*      */   extends OraclePreparedStatement
/*      */   implements oracle.jdbc.internal.OracleCallableStatement
/*      */ {
/*   56 */   boolean atLeastOneOrdinalParameter = false;
/*   57 */   boolean atLeastOneNamedParameter = false;
/*      */   
/*      */ 
/*   60 */   String[] namedParameters = new String[8];
/*      */   
/*      */ 
/*   63 */   int parameterCount = 0;
/*      */   
/*      */ 
/*   66 */   final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   87 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  105 */     super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);
/*      */     
/*      */ 
/*  108 */     this.statementType = 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*      */     throws SQLException
/*      */   {
/*  121 */     int i = paramInt1 - 1;
/*  122 */     SQLException localSQLException; if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*      */     {
/*  124 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  125 */       localSQLException.fillInStackTrace();
/*  126 */       throw localSQLException;
/*      */     }
/*      */     
/*  129 */     if (paramInt2 == 0)
/*      */     {
/*  131 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  132 */       localSQLException.fillInStackTrace();
/*  133 */       throw localSQLException;
/*      */     }
/*  135 */     int j = getInternalType(paramInt2);
/*      */     
/*  137 */     resetBatch();
/*  138 */     this.currentRowNeedToPrepareBinds = true;
/*      */     
/*  140 */     if (this.currentRowBindAccessors == null) {
/*  141 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/*      */     
/*  144 */     switch (paramInt2)
/*      */     {
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/*      */     case 70: 
/*      */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case -16: 
/*      */     case -15: 
/*      */     case -9: 
/*  160 */       this.currentRowFormOfUse[i] = 2;
/*  161 */       break;
/*      */     case 2011: 
/*  163 */       paramInt4 = 0;
/*  164 */       this.currentRowFormOfUse[i] = 2;
/*  165 */       break;
/*      */     case 2009: 
/*  167 */       paramInt4 = 0;
/*  168 */       paramString = "SYS.XMLTYPE";
/*  169 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/*  174 */       paramInt4 = 0;
/*      */     }
/*      */     
/*      */     
/*  178 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/*  212 */     if ((paramString == null) || (paramString.length() == 0))
/*      */     {
/*  214 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*  215 */       localSQLException.fillInStackTrace();
/*  216 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  222 */     synchronized (this.connection) {
/*  223 */       registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  252 */     synchronized (this.connection)
/*      */     {
/*  254 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  283 */     synchronized (this.connection)
/*      */     {
/*  285 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  302 */     synchronized (this.connection)
/*      */     {
/*  304 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  321 */     synchronized (this.connection)
/*      */     {
/*  323 */       registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isOracleBatchStyle()
/*      */   {
/*  332 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetBatch()
/*      */   {
/*  342 */     this.batch = 1;
/*      */   }
/*      */   
/*      */   public void setExecuteBatch(int paramInt)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   /* Error */
/*      */   public int sendBatch()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 26	oracle/jdbc/driver/OracleCallableStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 30	oracle/jdbc/driver/OracleCallableStatement:validRows	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #371	-> byte code offset #0
/*      */     //   Java source line #374	-> byte code offset #7
/*      */     //   Java source line #376	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleCallableStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  393 */     registerOutParameter(paramInt1, paramInt2, 0, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/*  405 */     registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  413 */     return wasNullValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  423 */     if (this.closed)
/*      */     {
/*  425 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  426 */       ((SQLException)localObject).fillInStackTrace();
/*  427 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  430 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  433 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  434 */       ((SQLException)localObject).fillInStackTrace();
/*  435 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  439 */     Object localObject = null;
/*  440 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  445 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  446 */       localSQLException.fillInStackTrace();
/*  447 */       throw localSQLException;
/*      */     }
/*      */     
/*  450 */     this.lastIndex = paramInt;
/*      */     
/*  452 */     if (this.streamList != null) {
/*  453 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  456 */     return ((Accessor)localObject).getString(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  466 */     if (this.closed)
/*      */     {
/*  468 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  469 */       ((SQLException)localObject).fillInStackTrace();
/*  470 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  473 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  476 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  477 */       ((SQLException)localObject).fillInStackTrace();
/*  478 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  482 */     Object localObject = null;
/*  483 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  488 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  489 */       localSQLException.fillInStackTrace();
/*  490 */       throw localSQLException;
/*      */     }
/*      */     
/*  493 */     this.lastIndex = paramInt;
/*      */     
/*  495 */     if (this.streamList != null) {
/*  496 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  499 */     return ((Accessor)localObject).getOracleObject(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ROWID getROWID(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  509 */     if (this.closed)
/*      */     {
/*  511 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  512 */       ((SQLException)localObject).fillInStackTrace();
/*  513 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  516 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  519 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  520 */       ((SQLException)localObject).fillInStackTrace();
/*  521 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  525 */     Object localObject = null;
/*  526 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  531 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  532 */       localSQLException.fillInStackTrace();
/*  533 */       throw localSQLException;
/*      */     }
/*      */     
/*  536 */     this.lastIndex = paramInt;
/*      */     
/*  538 */     if (this.streamList != null) {
/*  539 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  542 */     return ((Accessor)localObject).getROWID(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  552 */     if (this.closed)
/*      */     {
/*  554 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  555 */       ((SQLException)localObject).fillInStackTrace();
/*  556 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  559 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  562 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  563 */       ((SQLException)localObject).fillInStackTrace();
/*  564 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  568 */     Object localObject = null;
/*  569 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  574 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  575 */       localSQLException.fillInStackTrace();
/*  576 */       throw localSQLException;
/*      */     }
/*      */     
/*  579 */     this.lastIndex = paramInt;
/*      */     
/*  581 */     if (this.streamList != null) {
/*  582 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  585 */     return ((Accessor)localObject).getNUMBER(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  595 */     if (this.closed)
/*      */     {
/*  597 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  598 */       ((SQLException)localObject).fillInStackTrace();
/*  599 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  602 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  605 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  606 */       ((SQLException)localObject).fillInStackTrace();
/*  607 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  611 */     Object localObject = null;
/*  612 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  617 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  618 */       localSQLException.fillInStackTrace();
/*  619 */       throw localSQLException;
/*      */     }
/*      */     
/*  622 */     this.lastIndex = paramInt;
/*      */     
/*  624 */     if (this.streamList != null) {
/*  625 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  628 */     return ((Accessor)localObject).getDATE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public INTERVALYM getINTERVALYM(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  638 */     if (this.closed)
/*      */     {
/*  640 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  641 */       ((SQLException)localObject).fillInStackTrace();
/*  642 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  645 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  648 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  649 */       ((SQLException)localObject).fillInStackTrace();
/*  650 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  654 */     Object localObject = null;
/*  655 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  660 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  661 */       localSQLException.fillInStackTrace();
/*  662 */       throw localSQLException;
/*      */     }
/*      */     
/*  665 */     this.lastIndex = paramInt;
/*      */     
/*  667 */     if (this.streamList != null) {
/*  668 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  671 */     return ((Accessor)localObject).getINTERVALYM(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public INTERVALDS getINTERVALDS(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  681 */     if (this.closed)
/*      */     {
/*  683 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  684 */       ((SQLException)localObject).fillInStackTrace();
/*  685 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  688 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  691 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  692 */       ((SQLException)localObject).fillInStackTrace();
/*  693 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  697 */     Object localObject = null;
/*  698 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  703 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  704 */       localSQLException.fillInStackTrace();
/*  705 */       throw localSQLException;
/*      */     }
/*      */     
/*  708 */     this.lastIndex = paramInt;
/*      */     
/*  710 */     if (this.streamList != null) {
/*  711 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  714 */     return ((Accessor)localObject).getINTERVALDS(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  724 */     if (this.closed)
/*      */     {
/*  726 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  727 */       ((SQLException)localObject).fillInStackTrace();
/*  728 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  731 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  734 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  735 */       ((SQLException)localObject).fillInStackTrace();
/*  736 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  740 */     Object localObject = null;
/*  741 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  746 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  747 */       localSQLException.fillInStackTrace();
/*  748 */       throw localSQLException;
/*      */     }
/*      */     
/*  751 */     this.lastIndex = paramInt;
/*      */     
/*  753 */     if (this.streamList != null) {
/*  754 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  757 */     return ((Accessor)localObject).getTIMESTAMP(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  767 */     if (this.closed)
/*      */     {
/*  769 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  770 */       ((SQLException)localObject).fillInStackTrace();
/*  771 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  774 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  777 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  778 */       ((SQLException)localObject).fillInStackTrace();
/*  779 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  783 */     Object localObject = null;
/*  784 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  789 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  790 */       localSQLException.fillInStackTrace();
/*  791 */       throw localSQLException;
/*      */     }
/*      */     
/*  794 */     this.lastIndex = paramInt;
/*      */     
/*  796 */     if (this.streamList != null) {
/*  797 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  800 */     return ((Accessor)localObject).getTIMESTAMPTZ(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  810 */     if (this.closed)
/*      */     {
/*  812 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  813 */       ((SQLException)localObject).fillInStackTrace();
/*  814 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  817 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  820 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  821 */       ((SQLException)localObject).fillInStackTrace();
/*  822 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  826 */     Object localObject = null;
/*  827 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  832 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  833 */       localSQLException.fillInStackTrace();
/*  834 */       throw localSQLException;
/*      */     }
/*      */     
/*  837 */     this.lastIndex = paramInt;
/*      */     
/*  839 */     if (this.streamList != null) {
/*  840 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  843 */     return ((Accessor)localObject).getTIMESTAMPLTZ(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public REF getREF(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  853 */     if (this.closed)
/*      */     {
/*  855 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  856 */       ((SQLException)localObject).fillInStackTrace();
/*  857 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  860 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  863 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  864 */       ((SQLException)localObject).fillInStackTrace();
/*  865 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  869 */     Object localObject = null;
/*  870 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  875 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  876 */       localSQLException.fillInStackTrace();
/*  877 */       throw localSQLException;
/*      */     }
/*      */     
/*  880 */     this.lastIndex = paramInt;
/*      */     
/*  882 */     if (this.streamList != null) {
/*  883 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  886 */     return ((Accessor)localObject).getREF(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ARRAY getARRAY(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  896 */     if (this.closed)
/*      */     {
/*  898 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  899 */       ((SQLException)localObject).fillInStackTrace();
/*  900 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  903 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  906 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  907 */       ((SQLException)localObject).fillInStackTrace();
/*  908 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  912 */     Object localObject = null;
/*  913 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  918 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  919 */       localSQLException.fillInStackTrace();
/*  920 */       throw localSQLException;
/*      */     }
/*      */     
/*  923 */     this.lastIndex = paramInt;
/*      */     
/*  925 */     if (this.streamList != null) {
/*  926 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  929 */     return ((Accessor)localObject).getARRAY(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public STRUCT getSTRUCT(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  939 */     if (this.closed)
/*      */     {
/*  941 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  942 */       ((SQLException)localObject).fillInStackTrace();
/*  943 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  946 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  949 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  950 */       ((SQLException)localObject).fillInStackTrace();
/*  951 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  955 */     Object localObject = null;
/*  956 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  961 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  962 */       localSQLException.fillInStackTrace();
/*  963 */       throw localSQLException;
/*      */     }
/*      */     
/*  966 */     this.lastIndex = paramInt;
/*      */     
/*  968 */     if (this.streamList != null) {
/*  969 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  972 */     return ((Accessor)localObject).getSTRUCT(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OPAQUE getOPAQUE(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  982 */     if (this.closed)
/*      */     {
/*  984 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  985 */       ((SQLException)localObject).fillInStackTrace();
/*  986 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  989 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/*  992 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  993 */       ((SQLException)localObject).fillInStackTrace();
/*  994 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  998 */     Object localObject = null;
/*  999 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1004 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1005 */       localSQLException.fillInStackTrace();
/* 1006 */       throw localSQLException;
/*      */     }
/*      */     
/* 1009 */     this.lastIndex = paramInt;
/*      */     
/* 1011 */     if (this.streamList != null) {
/* 1012 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1015 */     return ((Accessor)localObject).getOPAQUE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CHAR getCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1025 */     if (this.closed)
/*      */     {
/* 1027 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1028 */       ((SQLException)localObject).fillInStackTrace();
/* 1029 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1032 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1035 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1036 */       ((SQLException)localObject).fillInStackTrace();
/* 1037 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1041 */     Object localObject = null;
/* 1042 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1047 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1048 */       localSQLException.fillInStackTrace();
/* 1049 */       throw localSQLException;
/*      */     }
/*      */     
/* 1052 */     this.lastIndex = paramInt;
/*      */     
/* 1054 */     if (this.streamList != null) {
/* 1055 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1058 */     return ((Accessor)localObject).getCHAR(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1069 */     if (this.closed)
/*      */     {
/* 1071 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1072 */       ((SQLException)localObject).fillInStackTrace();
/* 1073 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1076 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1079 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1080 */       ((SQLException)localObject).fillInStackTrace();
/* 1081 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1085 */     Object localObject = null;
/* 1086 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1091 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1092 */       localSQLException.fillInStackTrace();
/* 1093 */       throw localSQLException;
/*      */     }
/*      */     
/* 1096 */     this.lastIndex = paramInt;
/*      */     
/* 1098 */     if (this.streamList != null) {
/* 1099 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1102 */     return ((Accessor)localObject).getCharacterStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1112 */     if (this.closed)
/*      */     {
/* 1114 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1115 */       ((SQLException)localObject).fillInStackTrace();
/* 1116 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1119 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1122 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1123 */       ((SQLException)localObject).fillInStackTrace();
/* 1124 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1128 */     Object localObject = null;
/* 1129 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1134 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1135 */       localSQLException.fillInStackTrace();
/* 1136 */       throw localSQLException;
/*      */     }
/*      */     
/* 1139 */     this.lastIndex = paramInt;
/*      */     
/* 1141 */     if (this.streamList != null) {
/* 1142 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1145 */     return ((Accessor)localObject).getRAW(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BLOB getBLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1156 */     if (this.closed)
/*      */     {
/* 1158 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1159 */       ((SQLException)localObject).fillInStackTrace();
/* 1160 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1163 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1166 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1167 */       ((SQLException)localObject).fillInStackTrace();
/* 1168 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1172 */     Object localObject = null;
/* 1173 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1178 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1179 */       localSQLException.fillInStackTrace();
/* 1180 */       throw localSQLException;
/*      */     }
/*      */     
/* 1183 */     this.lastIndex = paramInt;
/*      */     
/* 1185 */     if (this.streamList != null) {
/* 1186 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1189 */     return ((Accessor)localObject).getBLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CLOB getCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1199 */     if (this.closed)
/*      */     {
/* 1201 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1202 */       ((SQLException)localObject).fillInStackTrace();
/* 1203 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1206 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1209 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1210 */       ((SQLException)localObject).fillInStackTrace();
/* 1211 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1215 */     Object localObject = null;
/* 1216 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1221 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1222 */       localSQLException.fillInStackTrace();
/* 1223 */       throw localSQLException;
/*      */     }
/*      */     
/* 1226 */     this.lastIndex = paramInt;
/*      */     
/* 1228 */     if (this.streamList != null) {
/* 1229 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1232 */     return ((Accessor)localObject).getCLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BFILE getBFILE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1242 */     if (this.closed)
/*      */     {
/* 1244 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1245 */       ((SQLException)localObject).fillInStackTrace();
/* 1246 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1249 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1252 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1253 */       ((SQLException)localObject).fillInStackTrace();
/* 1254 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1258 */     Object localObject = null;
/* 1259 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1264 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1265 */       localSQLException.fillInStackTrace();
/* 1266 */       throw localSQLException;
/*      */     }
/*      */     
/* 1269 */     this.lastIndex = paramInt;
/*      */     
/* 1271 */     if (this.streamList != null) {
/* 1272 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1275 */     return ((Accessor)localObject).getBFILE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BFILE getBfile(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1285 */     if (this.closed)
/*      */     {
/* 1287 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1288 */       ((SQLException)localObject).fillInStackTrace();
/* 1289 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1292 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1295 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1296 */       ((SQLException)localObject).fillInStackTrace();
/* 1297 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1301 */     Object localObject = null;
/* 1302 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1307 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1308 */       localSQLException.fillInStackTrace();
/* 1309 */       throw localSQLException;
/*      */     }
/*      */     
/* 1312 */     this.lastIndex = paramInt;
/*      */     
/* 1314 */     if (this.streamList != null) {
/* 1315 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1318 */     return ((Accessor)localObject).getBFILE(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1328 */     if (this.closed)
/*      */     {
/* 1330 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1331 */       ((SQLException)localObject).fillInStackTrace();
/* 1332 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1335 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1338 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1339 */       ((SQLException)localObject).fillInStackTrace();
/* 1340 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1344 */     Object localObject = null;
/* 1345 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1350 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1351 */       localSQLException.fillInStackTrace();
/* 1352 */       throw localSQLException;
/*      */     }
/*      */     
/* 1355 */     this.lastIndex = paramInt;
/*      */     
/* 1357 */     if (this.streamList != null) {
/* 1358 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1361 */     return ((Accessor)localObject).getBoolean(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1371 */     if (this.closed)
/*      */     {
/* 1373 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1374 */       ((SQLException)localObject).fillInStackTrace();
/* 1375 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1378 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1381 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1382 */       ((SQLException)localObject).fillInStackTrace();
/* 1383 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1387 */     Object localObject = null;
/* 1388 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1393 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1394 */       localSQLException.fillInStackTrace();
/* 1395 */       throw localSQLException;
/*      */     }
/*      */     
/* 1398 */     this.lastIndex = paramInt;
/*      */     
/* 1400 */     if (this.streamList != null) {
/* 1401 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1404 */     return ((Accessor)localObject).getByte(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1414 */     if (this.closed)
/*      */     {
/* 1416 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1417 */       ((SQLException)localObject).fillInStackTrace();
/* 1418 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1421 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1424 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1425 */       ((SQLException)localObject).fillInStackTrace();
/* 1426 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1430 */     Object localObject = null;
/* 1431 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1436 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1437 */       localSQLException.fillInStackTrace();
/* 1438 */       throw localSQLException;
/*      */     }
/*      */     
/* 1441 */     this.lastIndex = paramInt;
/*      */     
/* 1443 */     if (this.streamList != null) {
/* 1444 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1447 */     return ((Accessor)localObject).getShort(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1457 */     if (this.closed)
/*      */     {
/* 1459 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1460 */       ((SQLException)localObject).fillInStackTrace();
/* 1461 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1464 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1467 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1468 */       ((SQLException)localObject).fillInStackTrace();
/* 1469 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1473 */     Object localObject = null;
/* 1474 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1479 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1480 */       localSQLException.fillInStackTrace();
/* 1481 */       throw localSQLException;
/*      */     }
/*      */     
/* 1484 */     this.lastIndex = paramInt;
/*      */     
/* 1486 */     if (this.streamList != null) {
/* 1487 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1490 */     return ((Accessor)localObject).getInt(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1500 */     if (this.closed)
/*      */     {
/* 1502 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1503 */       ((SQLException)localObject).fillInStackTrace();
/* 1504 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1507 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1510 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1511 */       ((SQLException)localObject).fillInStackTrace();
/* 1512 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1516 */     Object localObject = null;
/* 1517 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1522 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1523 */       localSQLException.fillInStackTrace();
/* 1524 */       throw localSQLException;
/*      */     }
/*      */     
/* 1527 */     this.lastIndex = paramInt;
/*      */     
/* 1529 */     if (this.streamList != null) {
/* 1530 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1533 */     return ((Accessor)localObject).getLong(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1543 */     if (this.closed)
/*      */     {
/* 1545 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1546 */       ((SQLException)localObject).fillInStackTrace();
/* 1547 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1550 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1553 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1554 */       ((SQLException)localObject).fillInStackTrace();
/* 1555 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1559 */     Object localObject = null;
/* 1560 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1565 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1566 */       localSQLException.fillInStackTrace();
/* 1567 */       throw localSQLException;
/*      */     }
/*      */     
/* 1570 */     this.lastIndex = paramInt;
/*      */     
/* 1572 */     if (this.streamList != null) {
/* 1573 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1576 */     return ((Accessor)localObject).getFloat(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1586 */     if (this.closed)
/*      */     {
/* 1588 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1589 */       ((SQLException)localObject).fillInStackTrace();
/* 1590 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1593 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1596 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1597 */       ((SQLException)localObject).fillInStackTrace();
/* 1598 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1602 */     Object localObject = null;
/* 1603 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1608 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1609 */       localSQLException.fillInStackTrace();
/* 1610 */       throw localSQLException;
/*      */     }
/*      */     
/* 1613 */     this.lastIndex = paramInt;
/*      */     
/* 1615 */     if (this.streamList != null) {
/* 1616 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1619 */     return ((Accessor)localObject).getDouble(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1629 */     if (this.closed)
/*      */     {
/* 1631 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1632 */       ((SQLException)localObject).fillInStackTrace();
/* 1633 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1636 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1639 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1640 */       ((SQLException)localObject).fillInStackTrace();
/* 1641 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1645 */     Object localObject = null;
/* 1646 */     if ((paramInt1 <= 0) || (paramInt1 > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt1 - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1651 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1652 */       localSQLException.fillInStackTrace();
/* 1653 */       throw localSQLException;
/*      */     }
/*      */     
/* 1656 */     this.lastIndex = paramInt1;
/*      */     
/* 1658 */     if (this.streamList != null) {
/* 1659 */       closeUsedStreams(paramInt1);
/*      */     }
/*      */     
/* 1662 */     return ((Accessor)localObject).getBigDecimal(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1672 */     if (this.closed)
/*      */     {
/* 1674 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1675 */       ((SQLException)localObject).fillInStackTrace();
/* 1676 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1679 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1682 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1683 */       ((SQLException)localObject).fillInStackTrace();
/* 1684 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1688 */     Object localObject = null;
/* 1689 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1694 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1695 */       localSQLException.fillInStackTrace();
/* 1696 */       throw localSQLException;
/*      */     }
/*      */     
/* 1699 */     this.lastIndex = paramInt;
/*      */     
/* 1701 */     if (this.streamList != null) {
/* 1702 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1705 */     return ((Accessor)localObject).getBytes(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] privateGetBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1715 */     if (this.closed)
/*      */     {
/* 1717 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1718 */       ((SQLException)localObject).fillInStackTrace();
/* 1719 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1722 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1725 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1726 */       ((SQLException)localObject).fillInStackTrace();
/* 1727 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1731 */     Object localObject = null;
/* 1732 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1737 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1738 */       localSQLException.fillInStackTrace();
/* 1739 */       throw localSQLException;
/*      */     }
/*      */     
/* 1742 */     this.lastIndex = paramInt;
/*      */     
/* 1744 */     if (this.streamList != null) {
/* 1745 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1748 */     return ((Accessor)localObject).privateGetBytes(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1758 */     if (this.closed)
/*      */     {
/* 1760 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1761 */       ((SQLException)localObject).fillInStackTrace();
/* 1762 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1765 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1768 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1769 */       ((SQLException)localObject).fillInStackTrace();
/* 1770 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1774 */     Object localObject = null;
/* 1775 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1780 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1781 */       localSQLException.fillInStackTrace();
/* 1782 */       throw localSQLException;
/*      */     }
/*      */     
/* 1785 */     this.lastIndex = paramInt;
/*      */     
/* 1787 */     if (this.streamList != null) {
/* 1788 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1791 */     return ((Accessor)localObject).getDate(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1801 */     if (this.closed)
/*      */     {
/* 1803 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1804 */       ((SQLException)localObject).fillInStackTrace();
/* 1805 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1808 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1811 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1812 */       ((SQLException)localObject).fillInStackTrace();
/* 1813 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1817 */     Object localObject = null;
/* 1818 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1823 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1824 */       localSQLException.fillInStackTrace();
/* 1825 */       throw localSQLException;
/*      */     }
/*      */     
/* 1828 */     this.lastIndex = paramInt;
/*      */     
/* 1830 */     if (this.streamList != null) {
/* 1831 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1834 */     return ((Accessor)localObject).getTime(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1844 */     if (this.closed)
/*      */     {
/* 1846 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1847 */       ((SQLException)localObject).fillInStackTrace();
/* 1848 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1851 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1854 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1855 */       ((SQLException)localObject).fillInStackTrace();
/* 1856 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1860 */     Object localObject = null;
/* 1861 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1866 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1867 */       localSQLException.fillInStackTrace();
/* 1868 */       throw localSQLException;
/*      */     }
/*      */     
/* 1871 */     this.lastIndex = paramInt;
/*      */     
/* 1873 */     if (this.streamList != null) {
/* 1874 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1877 */     return ((Accessor)localObject).getTimestamp(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1887 */     if (this.closed)
/*      */     {
/* 1889 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1890 */       ((SQLException)localObject).fillInStackTrace();
/* 1891 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1894 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1897 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1898 */       ((SQLException)localObject).fillInStackTrace();
/* 1899 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1903 */     Object localObject = null;
/* 1904 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1909 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1910 */       localSQLException.fillInStackTrace();
/* 1911 */       throw localSQLException;
/*      */     }
/*      */     
/* 1914 */     this.lastIndex = paramInt;
/*      */     
/* 1916 */     if (this.streamList != null) {
/* 1917 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1920 */     return ((Accessor)localObject).getAsciiStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1930 */     if (this.closed)
/*      */     {
/* 1932 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1933 */       ((SQLException)localObject).fillInStackTrace();
/* 1934 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1937 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1940 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1941 */       ((SQLException)localObject).fillInStackTrace();
/* 1942 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1946 */     Object localObject = null;
/* 1947 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1952 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1953 */       localSQLException.fillInStackTrace();
/* 1954 */       throw localSQLException;
/*      */     }
/*      */     
/* 1957 */     this.lastIndex = paramInt;
/*      */     
/* 1959 */     if (this.streamList != null) {
/* 1960 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1963 */     return ((Accessor)localObject).getUnicodeStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1973 */     if (this.closed)
/*      */     {
/* 1975 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1976 */       ((SQLException)localObject).fillInStackTrace();
/* 1977 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 1980 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 1983 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1984 */       ((SQLException)localObject).fillInStackTrace();
/* 1985 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 1989 */     Object localObject = null;
/* 1990 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1995 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1996 */       localSQLException.fillInStackTrace();
/* 1997 */       throw localSQLException;
/*      */     }
/*      */     
/* 2000 */     this.lastIndex = paramInt;
/*      */     
/* 2002 */     if (this.streamList != null) {
/* 2003 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2006 */     return ((Accessor)localObject).getBinaryStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2016 */     if (this.closed)
/*      */     {
/* 2018 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2019 */       ((SQLException)localObject).fillInStackTrace();
/* 2020 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2023 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2026 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2027 */       ((SQLException)localObject).fillInStackTrace();
/* 2028 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2032 */     Object localObject = null;
/* 2033 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2038 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2039 */       localSQLException.fillInStackTrace();
/* 2040 */       throw localSQLException;
/*      */     }
/*      */     
/* 2043 */     this.lastIndex = paramInt;
/*      */     
/* 2045 */     if (this.streamList != null) {
/* 2046 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2049 */     return ((Accessor)localObject).getObject(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAnyDataEmbeddedObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2058 */     Object localObject1 = null;
/* 2059 */     Object localObject2 = getObject(paramInt);
/* 2060 */     if ((localObject2 instanceof ANYDATA))
/*      */     {
/* 2062 */       Datum localDatum = ((ANYDATA)localObject2).accessDatum();
/* 2063 */       if (localDatum != null) localObject1 = localDatum.toJdbc();
/*      */     }
/* 2065 */     return localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/* 2075 */     if (this.closed)
/*      */     {
/* 2077 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2078 */       ((SQLException)localObject).fillInStackTrace();
/* 2079 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2082 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2085 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2086 */       ((SQLException)localObject).fillInStackTrace();
/* 2087 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2091 */     Object localObject = null;
/* 2092 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2097 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2098 */       localSQLException.fillInStackTrace();
/* 2099 */       throw localSQLException;
/*      */     }
/*      */     
/* 2102 */     this.lastIndex = paramInt;
/*      */     
/* 2104 */     if (this.streamList != null) {
/* 2105 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2108 */     return ((Accessor)localObject).getCustomDatum(this.currentRank, paramCustomDatumFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/* 2118 */     if (this.closed)
/*      */     {
/* 2120 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2121 */       ((SQLException)localObject).fillInStackTrace();
/* 2122 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2125 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2128 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2129 */       ((SQLException)localObject).fillInStackTrace();
/* 2130 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2134 */     Object localObject = null;
/* 2135 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2140 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2141 */       localSQLException.fillInStackTrace();
/* 2142 */       throw localSQLException;
/*      */     }
/*      */     
/* 2145 */     this.lastIndex = paramInt;
/*      */     
/* 2147 */     if (this.streamList != null) {
/* 2148 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2151 */     return ((Accessor)localObject).getORAData(this.currentRank, paramORADataFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCursor(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2161 */     if (this.closed)
/*      */     {
/* 2163 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2164 */       ((SQLException)localObject).fillInStackTrace();
/* 2165 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2168 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2171 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2172 */       ((SQLException)localObject).fillInStackTrace();
/* 2173 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2177 */     Object localObject = null;
/* 2178 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2183 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2184 */       localSQLException.fillInStackTrace();
/* 2185 */       throw localSQLException;
/*      */     }
/*      */     
/* 2188 */     this.lastIndex = paramInt;
/*      */     
/* 2190 */     if (this.streamList != null) {
/* 2191 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2194 */     return ((Accessor)localObject).getCursor(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/* 2201 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2204 */       super.clearParameters();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 2225 */     if (this.closed)
/*      */     {
/* 2227 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2228 */       ((SQLException)localObject).fillInStackTrace();
/* 2229 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2232 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2235 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2236 */       ((SQLException)localObject).fillInStackTrace();
/* 2237 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2241 */     Object localObject = null;
/* 2242 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2247 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2248 */       localSQLException.fillInStackTrace();
/* 2249 */       throw localSQLException;
/*      */     }
/*      */     
/* 2252 */     this.lastIndex = paramInt;
/*      */     
/* 2254 */     if (this.streamList != null) {
/* 2255 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2258 */     return ((Accessor)localObject).getObject(this.currentRank, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2268 */     if (this.closed)
/*      */     {
/* 2270 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2271 */       ((SQLException)localObject).fillInStackTrace();
/* 2272 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2275 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2278 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2279 */       ((SQLException)localObject).fillInStackTrace();
/* 2280 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2284 */     Object localObject = null;
/* 2285 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2290 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2291 */       localSQLException.fillInStackTrace();
/* 2292 */       throw localSQLException;
/*      */     }
/*      */     
/* 2295 */     this.lastIndex = paramInt;
/*      */     
/* 2297 */     if (this.streamList != null) {
/* 2298 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2301 */     return ((Accessor)localObject).getREF(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2311 */     if (this.closed)
/*      */     {
/* 2313 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2314 */       ((SQLException)localObject).fillInStackTrace();
/* 2315 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2318 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2321 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2322 */       ((SQLException)localObject).fillInStackTrace();
/* 2323 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2327 */     Object localObject = null;
/* 2328 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2333 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2334 */       localSQLException.fillInStackTrace();
/* 2335 */       throw localSQLException;
/*      */     }
/*      */     
/* 2338 */     this.lastIndex = paramInt;
/*      */     
/* 2340 */     if (this.streamList != null) {
/* 2341 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2344 */     return ((Accessor)localObject).getBLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2354 */     if (this.closed)
/*      */     {
/* 2356 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2357 */       ((SQLException)localObject).fillInStackTrace();
/* 2358 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2361 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2364 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2365 */       ((SQLException)localObject).fillInStackTrace();
/* 2366 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2370 */     Object localObject = null;
/* 2371 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2376 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2377 */       localSQLException.fillInStackTrace();
/* 2378 */       throw localSQLException;
/*      */     }
/*      */     
/* 2381 */     this.lastIndex = paramInt;
/*      */     
/* 2383 */     if (this.streamList != null) {
/* 2384 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2387 */     return ((Accessor)localObject).getCLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2397 */     if (this.closed)
/*      */     {
/* 2399 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2400 */       ((SQLException)localObject).fillInStackTrace();
/* 2401 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2404 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2407 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2408 */       ((SQLException)localObject).fillInStackTrace();
/* 2409 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2413 */     Object localObject = null;
/* 2414 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2419 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2420 */       localSQLException.fillInStackTrace();
/* 2421 */       throw localSQLException;
/*      */     }
/*      */     
/* 2424 */     this.lastIndex = paramInt;
/*      */     
/* 2426 */     if (this.streamList != null) {
/* 2427 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2430 */     return ((Accessor)localObject).getARRAY(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2440 */     if (this.closed)
/*      */     {
/* 2442 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2443 */       ((SQLException)localObject).fillInStackTrace();
/* 2444 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2447 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2450 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2451 */       ((SQLException)localObject).fillInStackTrace();
/* 2452 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2456 */     Object localObject = null;
/* 2457 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2462 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2463 */       localSQLException.fillInStackTrace();
/* 2464 */       throw localSQLException;
/*      */     }
/*      */     
/* 2467 */     this.lastIndex = paramInt;
/*      */     
/* 2469 */     if (this.streamList != null) {
/* 2470 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2473 */     return ((Accessor)localObject).getBigDecimal(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2483 */     if (this.closed)
/*      */     {
/* 2485 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2486 */       ((SQLException)localObject).fillInStackTrace();
/* 2487 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2490 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2493 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2494 */       ((SQLException)localObject).fillInStackTrace();
/* 2495 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2499 */     Object localObject = null;
/* 2500 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2505 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2506 */       localSQLException.fillInStackTrace();
/* 2507 */       throw localSQLException;
/*      */     }
/*      */     
/* 2510 */     this.lastIndex = paramInt;
/*      */     
/* 2512 */     if (this.streamList != null) {
/* 2513 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2516 */     return ((Accessor)localObject).getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2526 */     if (this.closed)
/*      */     {
/* 2528 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2529 */       ((SQLException)localObject).fillInStackTrace();
/* 2530 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2533 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2536 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2537 */       ((SQLException)localObject).fillInStackTrace();
/* 2538 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2542 */     Object localObject = null;
/* 2543 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2548 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2549 */       localSQLException.fillInStackTrace();
/* 2550 */       throw localSQLException;
/*      */     }
/*      */     
/* 2553 */     this.lastIndex = paramInt;
/*      */     
/* 2555 */     if (this.streamList != null) {
/* 2556 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2559 */     return ((Accessor)localObject).getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 2569 */     if (this.closed)
/*      */     {
/* 2571 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2572 */       ((SQLException)localObject).fillInStackTrace();
/* 2573 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2576 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2579 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2580 */       ((SQLException)localObject).fillInStackTrace();
/* 2581 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2585 */     Object localObject = null;
/* 2586 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2591 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2592 */       localSQLException.fillInStackTrace();
/* 2593 */       throw localSQLException;
/*      */     }
/*      */     
/* 2596 */     this.lastIndex = paramInt;
/*      */     
/* 2598 */     if (this.streamList != null) {
/* 2599 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2602 */     return ((Accessor)localObject).getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/* 2648 */     if (this.currentRowBindAccessors != null)
/*      */     {
/*      */ 
/* 2651 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
/* 2652 */       localSQLException.fillInStackTrace();
/* 2653 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 2657 */     super.addBatch();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void alwaysOnClose()
/*      */     throws SQLException
/*      */   {
/* 2667 */     this.sqlObject.resetNamedParameters();
/*      */     
/*      */ 
/* 2670 */     this.namedParameters = new String[8];
/* 2671 */     this.parameterCount = 0;
/* 2672 */     this.atLeastOneOrdinalParameter = false;
/* 2673 */     this.atLeastOneNamedParameter = false;
/*      */     
/* 2675 */     super.alwaysOnClose();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2712 */     registerOutParameterInternal(paramString, paramInt, 0, -1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2745 */     registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2790 */     registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2798 */     int i = addNamedPara(paramString1);
/* 2799 */     registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2824 */     if (this.closed)
/*      */     {
/* 2826 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2827 */       ((SQLException)localObject).fillInStackTrace();
/* 2828 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2831 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2834 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2835 */       ((SQLException)localObject).fillInStackTrace();
/* 2836 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2840 */     Object localObject = null;
/* 2841 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2846 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2847 */       localSQLException.fillInStackTrace();
/* 2848 */       throw localSQLException;
/*      */     }
/*      */     
/* 2851 */     this.lastIndex = paramInt;
/*      */     
/* 2853 */     if (this.streamList != null) {
/* 2854 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2857 */     return ((Accessor)localObject).getURL(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStringForClob(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 2884 */     int i = addNamedPara(paramString1);
/* 2885 */     if ((paramString2 == null) || (paramString2.length() == 0))
/*      */     {
/* 2887 */       setNull(i, 2005);
/* 2888 */       return;
/*      */     }
/* 2890 */     setStringForClob(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStringForClob(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2909 */     if ((paramString == null) || (paramString.length() == 0))
/*      */     {
/* 2911 */       setNull(paramInt, 2005);
/* 2912 */       return;
/*      */     }
/* 2914 */     synchronized (this.connection) {
/* 2915 */       setStringForClobCritical(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2940 */     int i = addNamedPara(paramString);
/* 2941 */     setBytesForBlob(i, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2959 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0))
/*      */     {
/* 2961 */       setNull(paramInt, 2004);
/* 2962 */       return;
/*      */     }
/* 2964 */     synchronized (this.connection) {
/* 2965 */       setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(String paramString)
/*      */     throws SQLException
/*      */   {
/* 2994 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 2997 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2998 */       ((SQLException)localObject).fillInStackTrace();
/* 2999 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3003 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3006 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3008 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3011 */     i++;
/*      */     
/* 3013 */     Accessor localAccessor = null;
/* 3014 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3019 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3020 */       localSQLException.fillInStackTrace();
/* 3021 */       throw localSQLException;
/*      */     }
/*      */     
/* 3024 */     this.lastIndex = i;
/*      */     
/* 3026 */     if (this.streamList != null) {
/* 3027 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3030 */     return localAccessor.getString(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3051 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3054 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3055 */       ((SQLException)localObject).fillInStackTrace();
/* 3056 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3060 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3063 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3065 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3068 */     i++;
/*      */     
/* 3070 */     Accessor localAccessor = null;
/* 3071 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3076 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3077 */       localSQLException.fillInStackTrace();
/* 3078 */       throw localSQLException;
/*      */     }
/*      */     
/* 3081 */     this.lastIndex = i;
/*      */     
/* 3083 */     if (this.streamList != null) {
/* 3084 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3087 */     return localAccessor.getBoolean(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3108 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3111 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3112 */       ((SQLException)localObject).fillInStackTrace();
/* 3113 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3117 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3120 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3122 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3125 */     i++;
/*      */     
/* 3127 */     Accessor localAccessor = null;
/* 3128 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3133 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3134 */       localSQLException.fillInStackTrace();
/* 3135 */       throw localSQLException;
/*      */     }
/*      */     
/* 3138 */     this.lastIndex = i;
/*      */     
/* 3140 */     if (this.streamList != null) {
/* 3141 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3144 */     return localAccessor.getByte(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3165 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3168 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3169 */       ((SQLException)localObject).fillInStackTrace();
/* 3170 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3174 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3177 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3179 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3182 */     i++;
/*      */     
/* 3184 */     Accessor localAccessor = null;
/* 3185 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3190 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3191 */       localSQLException.fillInStackTrace();
/* 3192 */       throw localSQLException;
/*      */     }
/*      */     
/* 3195 */     this.lastIndex = i;
/*      */     
/* 3197 */     if (this.streamList != null) {
/* 3198 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3201 */     return localAccessor.getShort(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3223 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3226 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3227 */       ((SQLException)localObject).fillInStackTrace();
/* 3228 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3232 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3235 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3237 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3240 */     i++;
/*      */     
/* 3242 */     Accessor localAccessor = null;
/* 3243 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3248 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3249 */       localSQLException.fillInStackTrace();
/* 3250 */       throw localSQLException;
/*      */     }
/*      */     
/* 3253 */     this.lastIndex = i;
/*      */     
/* 3255 */     if (this.streamList != null) {
/* 3256 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3259 */     return localAccessor.getInt(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3281 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3284 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3285 */       ((SQLException)localObject).fillInStackTrace();
/* 3286 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3290 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3293 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3295 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3298 */     i++;
/*      */     
/* 3300 */     Accessor localAccessor = null;
/* 3301 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3306 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3307 */       localSQLException.fillInStackTrace();
/* 3308 */       throw localSQLException;
/*      */     }
/*      */     
/* 3311 */     this.lastIndex = i;
/*      */     
/* 3313 */     if (this.streamList != null) {
/* 3314 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3317 */     return localAccessor.getLong(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3338 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3341 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3342 */       ((SQLException)localObject).fillInStackTrace();
/* 3343 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3347 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3350 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3352 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3355 */     i++;
/*      */     
/* 3357 */     Accessor localAccessor = null;
/* 3358 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3363 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3364 */       localSQLException.fillInStackTrace();
/* 3365 */       throw localSQLException;
/*      */     }
/*      */     
/* 3368 */     this.lastIndex = i;
/*      */     
/* 3370 */     if (this.streamList != null) {
/* 3371 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3374 */     return localAccessor.getFloat(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3395 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3398 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3399 */       ((SQLException)localObject).fillInStackTrace();
/* 3400 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3404 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3407 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3409 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3412 */     i++;
/*      */     
/* 3414 */     Accessor localAccessor = null;
/* 3415 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3420 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3421 */       localSQLException.fillInStackTrace();
/* 3422 */       throw localSQLException;
/*      */     }
/*      */     
/* 3425 */     this.lastIndex = i;
/*      */     
/* 3427 */     if (this.streamList != null) {
/* 3428 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3431 */     return localAccessor.getDouble(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3453 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3456 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3457 */       ((SQLException)localObject).fillInStackTrace();
/* 3458 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3462 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3465 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3467 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3470 */     i++;
/*      */     
/* 3472 */     Accessor localAccessor = null;
/* 3473 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3478 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3479 */       localSQLException.fillInStackTrace();
/* 3480 */       throw localSQLException;
/*      */     }
/*      */     
/* 3483 */     this.lastIndex = i;
/*      */     
/* 3485 */     if (this.streamList != null) {
/* 3486 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3489 */     return localAccessor.getBytes(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3510 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3513 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3514 */       ((SQLException)localObject).fillInStackTrace();
/* 3515 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3519 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3522 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3524 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3527 */     i++;
/*      */     
/* 3529 */     Accessor localAccessor = null;
/* 3530 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3535 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3536 */       localSQLException.fillInStackTrace();
/* 3537 */       throw localSQLException;
/*      */     }
/*      */     
/* 3540 */     this.lastIndex = i;
/*      */     
/* 3542 */     if (this.streamList != null) {
/* 3543 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3546 */     return localAccessor.getDate(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3567 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3570 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3571 */       ((SQLException)localObject).fillInStackTrace();
/* 3572 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3576 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3579 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3581 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3584 */     i++;
/*      */     
/* 3586 */     Accessor localAccessor = null;
/* 3587 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3592 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3593 */       localSQLException.fillInStackTrace();
/* 3594 */       throw localSQLException;
/*      */     }
/*      */     
/* 3597 */     this.lastIndex = i;
/*      */     
/* 3599 */     if (this.streamList != null) {
/* 3600 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3603 */     return localAccessor.getTime(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3624 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3627 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3628 */       ((SQLException)localObject).fillInStackTrace();
/* 3629 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3633 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3636 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3638 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3641 */     i++;
/*      */     
/* 3643 */     Accessor localAccessor = null;
/* 3644 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3649 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3650 */       localSQLException.fillInStackTrace();
/* 3651 */       throw localSQLException;
/*      */     }
/*      */     
/* 3654 */     this.lastIndex = i;
/*      */     
/* 3656 */     if (this.streamList != null) {
/* 3657 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3660 */     return localAccessor.getTimestamp(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3688 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3691 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3692 */       ((SQLException)localObject).fillInStackTrace();
/* 3693 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3697 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3700 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3702 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3705 */     i++;
/*      */     
/* 3707 */     Accessor localAccessor = null;
/* 3708 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3713 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3714 */       localSQLException.fillInStackTrace();
/* 3715 */       throw localSQLException;
/*      */     }
/*      */     
/* 3718 */     this.lastIndex = i;
/*      */     
/* 3720 */     if (this.streamList != null) {
/* 3721 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3724 */     return localAccessor.getObject(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3746 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3749 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3750 */       ((SQLException)localObject).fillInStackTrace();
/* 3751 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3755 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3758 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3760 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3763 */     i++;
/*      */     
/* 3765 */     Accessor localAccessor = null;
/* 3766 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3771 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3772 */       localSQLException.fillInStackTrace();
/* 3773 */       throw localSQLException;
/*      */     }
/*      */     
/* 3776 */     this.lastIndex = i;
/*      */     
/* 3778 */     if (this.streamList != null) {
/* 3779 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3782 */     return localAccessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3791 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3794 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3795 */       ((SQLException)localObject).fillInStackTrace();
/* 3796 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3800 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3803 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3805 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3808 */     i++;
/*      */     
/* 3810 */     Accessor localAccessor = null;
/* 3811 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3816 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3817 */       localSQLException.fillInStackTrace();
/* 3818 */       throw localSQLException;
/*      */     }
/*      */     
/* 3821 */     this.lastIndex = i;
/*      */     
/* 3823 */     if (this.streamList != null) {
/* 3824 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3827 */     return localAccessor.getBigDecimal(this.currentRank, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String paramString, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 3855 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3858 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3859 */       ((SQLException)localObject).fillInStackTrace();
/* 3860 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3864 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3867 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3869 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3872 */     i++;
/*      */     
/* 3874 */     Accessor localAccessor = null;
/* 3875 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3880 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3881 */       localSQLException.fillInStackTrace();
/* 3882 */       throw localSQLException;
/*      */     }
/*      */     
/* 3885 */     this.lastIndex = i;
/*      */     
/* 3887 */     if (this.streamList != null) {
/* 3888 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3891 */     return localAccessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3913 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3916 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3917 */       ((SQLException)localObject).fillInStackTrace();
/* 3918 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3922 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3925 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3927 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3930 */     i++;
/*      */     
/* 3932 */     Accessor localAccessor = null;
/* 3933 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3938 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3939 */       localSQLException.fillInStackTrace();
/* 3940 */       throw localSQLException;
/*      */     }
/*      */     
/* 3943 */     this.lastIndex = i;
/*      */     
/* 3945 */     if (this.streamList != null) {
/* 3946 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 3949 */     return localAccessor.getREF(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Blob getBlob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3971 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 3974 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3975 */       ((SQLException)localObject).fillInStackTrace();
/* 3976 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3980 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 3983 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 3985 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 3988 */     i++;
/*      */     
/* 3990 */     Accessor localAccessor = null;
/* 3991 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3996 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3997 */       localSQLException.fillInStackTrace();
/* 3998 */       throw localSQLException;
/*      */     }
/*      */     
/* 4001 */     this.lastIndex = i;
/*      */     
/* 4003 */     if (this.streamList != null) {
/* 4004 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4007 */     return localAccessor.getBLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Clob getClob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4028 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4031 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4032 */       ((SQLException)localObject).fillInStackTrace();
/* 4033 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4037 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4040 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4042 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4045 */     i++;
/*      */     
/* 4047 */     Accessor localAccessor = null;
/* 4048 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4053 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4054 */       localSQLException.fillInStackTrace();
/* 4055 */       throw localSQLException;
/*      */     }
/*      */     
/* 4058 */     this.lastIndex = i;
/*      */     
/* 4060 */     if (this.streamList != null) {
/* 4061 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4064 */     return localAccessor.getCLOB(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4086 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4089 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4090 */       ((SQLException)localObject).fillInStackTrace();
/* 4091 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4095 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4098 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4100 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4103 */     i++;
/*      */     
/* 4105 */     Accessor localAccessor = null;
/* 4106 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4111 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4112 */       localSQLException.fillInStackTrace();
/* 4113 */       throw localSQLException;
/*      */     }
/*      */     
/* 4116 */     this.lastIndex = i;
/*      */     
/* 4118 */     if (this.streamList != null) {
/* 4119 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4122 */     return localAccessor.getARRAY(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4152 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4155 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4156 */       ((SQLException)localObject).fillInStackTrace();
/* 4157 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4161 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4164 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4166 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4169 */     i++;
/*      */     
/* 4171 */     Accessor localAccessor = null;
/* 4172 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4177 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4178 */       localSQLException.fillInStackTrace();
/* 4179 */       throw localSQLException;
/*      */     }
/*      */     
/* 4182 */     this.lastIndex = i;
/*      */     
/* 4184 */     if (this.streamList != null) {
/* 4185 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4188 */     return localAccessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4218 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4221 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4222 */       ((SQLException)localObject).fillInStackTrace();
/* 4223 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4227 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4230 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4232 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4235 */     i++;
/*      */     
/* 4237 */     Accessor localAccessor = null;
/* 4238 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4243 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4244 */       localSQLException.fillInStackTrace();
/* 4245 */       throw localSQLException;
/*      */     }
/*      */     
/* 4248 */     this.lastIndex = i;
/*      */     
/* 4250 */     if (this.streamList != null) {
/* 4251 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4254 */     return localAccessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4285 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4288 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4289 */       ((SQLException)localObject).fillInStackTrace();
/* 4290 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4294 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4297 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4299 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4302 */     i++;
/*      */     
/* 4304 */     Accessor localAccessor = null;
/* 4305 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4310 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4311 */       localSQLException.fillInStackTrace();
/* 4312 */       throw localSQLException;
/*      */     }
/*      */     
/* 4315 */     this.lastIndex = i;
/*      */     
/* 4317 */     if (this.streamList != null) {
/* 4318 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4321 */     return localAccessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4345 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 4348 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4349 */       ((SQLException)localObject).fillInStackTrace();
/* 4350 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 4354 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 4357 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 4359 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 4362 */     i++;
/*      */     
/* 4364 */     Accessor localAccessor = null;
/* 4365 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4370 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4371 */       localSQLException.fillInStackTrace();
/* 4372 */       throw localSQLException;
/*      */     }
/*      */     
/* 4375 */     this.lastIndex = i;
/*      */     
/* 4377 */     if (this.streamList != null) {
/* 4378 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 4381 */     return localAccessor.getURL(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public InputStream getAsciiStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4391 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4392 */     localSQLException.fillInStackTrace();
/* 4393 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/* 4432 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4435 */       int i = paramInt1 - 1;
/* 4436 */       if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*      */       {
/* 4438 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4439 */         localSQLException.fillInStackTrace();
/* 4440 */         throw localSQLException;
/*      */       }
/*      */       
/* 4443 */       int j = getInternalType(paramInt3);
/*      */       
/* 4445 */       resetBatch();
/* 4446 */       this.currentRowNeedToPrepareBinds = true;
/*      */       
/* 4448 */       if (this.currentRowBindAccessors == null) {
/* 4449 */         this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */       }
/* 4451 */       this.currentRowBindAccessors[i] = allocateIndexTableAccessor(paramInt3, j, paramInt4, paramInt2, this.currentRowFormOfUse[i], true);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4459 */       this.hasIbtBind = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4476 */     return new PlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getPlsqlIndexTable(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4500 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4503 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4505 */       PlsqlIndexTableAccessor localPlsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[(paramInt - 1)];
/*      */       
/*      */ 
/* 4508 */       int i = localPlsqlIndexTableAccessor.elementInternalType;
/*      */       
/* 4510 */       Object localObject1 = null;
/*      */       
/* 4512 */       switch (i)
/*      */       {
/*      */       case 9: 
/* 4515 */         localObject1 = new String[arrayOfDatum.length];
/* 4516 */         break;
/*      */       case 6: 
/* 4518 */         localObject1 = new BigDecimal[arrayOfDatum.length];
/* 4519 */         break;
/*      */       
/*      */       default: 
/* 4522 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
/* 4523 */         localSQLException.fillInStackTrace();
/* 4524 */         throw localSQLException;
/*      */       }
/*      */       
/*      */       
/* 4528 */       for (int j = 0; j < localObject1.length; j++) {
/* 4529 */         localObject1[j] = ((arrayOfDatum[j] != null) && (arrayOfDatum[j].getLength() != 0L) ? arrayOfDatum[j].toJdbc() : null);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4534 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass)
/*      */     throws SQLException
/*      */   {
/* 4554 */     synchronized (this.connection)
/*      */     {
/* 4556 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4558 */       if ((paramClass == null) || (!paramClass.isPrimitive()))
/*      */       {
/* 4560 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4561 */         ((SQLException)localObject1).fillInStackTrace();
/* 4562 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 4565 */       Object localObject1 = paramClass.getName();
/*      */       int i;
/* 4567 */       if (((String)localObject1).equals("byte"))
/*      */       {
/* 4569 */         localObject2 = new byte[arrayOfDatum.length];
/* 4570 */         for (i = 0; i < arrayOfDatum.length; i++)
/* 4571 */           localObject2[i] = (arrayOfDatum[i] != null ? arrayOfDatum[i].byteValue() : 0);
/* 4572 */         return localObject2;
/*      */       }
/* 4574 */       if (((String)localObject1).equals("char"))
/*      */       {
/* 4576 */         localObject2 = new char[arrayOfDatum.length];
/* 4577 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4578 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? (char)arrayOfDatum[i].intValue() : 0);
/*      */         }
/* 4580 */         return localObject2;
/*      */       }
/* 4582 */       if (((String)localObject1).equals("double"))
/*      */       {
/* 4584 */         localObject2 = new double[arrayOfDatum.length];
/* 4585 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4586 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].doubleValue() : 0.0D);
/*      */         }
/* 4588 */         return localObject2;
/*      */       }
/* 4590 */       if (((String)localObject1).equals("float"))
/*      */       {
/* 4592 */         localObject2 = new float[arrayOfDatum.length];
/* 4593 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4594 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].floatValue() : 0.0F);
/*      */         }
/* 4596 */         return localObject2;
/*      */       }
/* 4598 */       if (((String)localObject1).equals("int"))
/*      */       {
/* 4600 */         localObject2 = new int[arrayOfDatum.length];
/* 4601 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4602 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].intValue() : 0);
/*      */         }
/* 4604 */         return localObject2;
/*      */       }
/* 4606 */       if (((String)localObject1).equals("long"))
/*      */       {
/* 4608 */         localObject2 = new long[arrayOfDatum.length];
/* 4609 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4610 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].longValue() : 0L);
/*      */         }
/* 4612 */         return localObject2;
/*      */       }
/* 4614 */       if (((String)localObject1).equals("short"))
/*      */       {
/* 4616 */         localObject2 = new short[arrayOfDatum.length];
/* 4617 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4618 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? (short)arrayOfDatum[i].intValue() : 0);
/*      */         }
/* 4620 */         return localObject2;
/*      */       }
/* 4622 */       if (((String)localObject1).equals("boolean"))
/*      */       {
/* 4624 */         localObject2 = new boolean[arrayOfDatum.length];
/* 4625 */         for (i = 0; i < arrayOfDatum.length; i++) {
/* 4626 */           localObject2[i] = ((arrayOfDatum[i] != null) && (arrayOfDatum[i].getLength() != 0L) ? arrayOfDatum[i].booleanValue() : 0);
/*      */         }
/* 4628 */         return localObject2;
/*      */       }
/*      */       
/*      */ 
/* 4632 */       Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4633 */       ((SQLException)localObject2).fillInStackTrace();
/* 4634 */       throw ((Throwable)localObject2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4652 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4656 */       if (this.closed)
/*      */       {
/* 4658 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4659 */         ((SQLException)localObject1).fillInStackTrace();
/* 4660 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 4663 */       if (this.atLeastOneNamedParameter)
/*      */       {
/*      */ 
/* 4666 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4667 */         ((SQLException)localObject1).fillInStackTrace();
/* 4668 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*      */ 
/* 4672 */       Object localObject1 = null;
/* 4673 */       if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject1 = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 4678 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4679 */         localSQLException.fillInStackTrace();
/* 4680 */         throw localSQLException;
/*      */       }
/*      */       
/* 4683 */       this.lastIndex = paramInt;
/*      */       
/* 4685 */       if (this.streamList != null) {
/* 4686 */         closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 4689 */       return ((Accessor)localObject1).getOraclePlsqlIndexTable(this.currentRank);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/* 4704 */     synchronized (this.connection) {
/* 4705 */       ensureOpen();
/* 4706 */       if ((this.atLeastOneNamedParameter) && (this.atLeastOneOrdinalParameter))
/*      */       {
/* 4708 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4709 */         localSQLException.fillInStackTrace();
/* 4710 */         throw localSQLException;
/*      */       }
/* 4712 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4713 */         this.needToParse = true;
/* 4714 */       return super.execute();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/* 4728 */     synchronized (this.connection)
/*      */     {
/* 4730 */       ensureOpen();
/* 4731 */       if ((this.atLeastOneNamedParameter) && (this.atLeastOneOrdinalParameter))
/*      */       {
/* 4733 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4734 */         localSQLException.fillInStackTrace();
/* 4735 */         throw localSQLException;
/*      */       }
/* 4737 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4738 */         this.needToParse = true;
/* 4739 */       return super.executeUpdate();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/* 4746 */     if (this.outBindAccessors != null)
/*      */     {
/* 4748 */       int i = this.outBindAccessors.length;
/*      */       
/* 4750 */       for (int j = 0; j < i; j++)
/*      */       {
/* 4752 */         if (this.outBindAccessors[j] != null)
/*      */         {
/* 4754 */           this.outBindAccessors[j].rowSpaceByte = null;
/* 4755 */           this.outBindAccessors[j].rowSpaceChar = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4760 */     super.releaseBuffers();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void doLocalInitialization()
/*      */   {
/* 4767 */     if (this.outBindAccessors != null)
/*      */     {
/* 4769 */       int i = this.outBindAccessors.length;
/*      */       
/* 4771 */       for (int j = 0; j < i; j++)
/*      */       {
/* 4773 */         if (this.outBindAccessors[j] != null)
/*      */         {
/* 4775 */           this.outBindAccessors[j].rowSpaceByte = this.bindBytes;
/* 4776 */           this.outBindAccessors[j].rowSpaceChar = this.bindChars;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 4791 */     this.atLeastOneOrdinalParameter = true;
/* 4792 */     setArrayInternal(paramInt, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 4799 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4803 */       this.atLeastOneOrdinalParameter = true;
/* 4804 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 4812 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4816 */       this.atLeastOneOrdinalParameter = true;
/* 4817 */       setBlobInternal(paramInt, paramBlob);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4825 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4829 */       this.atLeastOneOrdinalParameter = true;
/* 4830 */       setBooleanInternal(paramInt, paramBoolean);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 4838 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4842 */       this.atLeastOneOrdinalParameter = true;
/* 4843 */       setByteInternal(paramInt, paramByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 4851 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4855 */       this.atLeastOneOrdinalParameter = true;
/* 4856 */       setBytesInternal(paramInt, paramArrayOfByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 4864 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4868 */       this.atLeastOneOrdinalParameter = true;
/* 4869 */       setClobInternal(paramInt, paramClob);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDate(int paramInt, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 4877 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4881 */       this.atLeastOneOrdinalParameter = true;
/* 4882 */       setDateInternal(paramInt, paramDate);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 4890 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4894 */       this.atLeastOneOrdinalParameter = true;
/* 4895 */       setDateInternal(paramInt, paramDate, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 4903 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4907 */       this.atLeastOneOrdinalParameter = true;
/* 4908 */       setDoubleInternal(paramInt, paramDouble);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 4916 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4920 */       this.atLeastOneOrdinalParameter = true;
/* 4921 */       setFloatInternal(paramInt, paramFloat);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 4929 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4933 */       this.atLeastOneOrdinalParameter = true;
/* 4934 */       setIntInternal(paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 4942 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4946 */       this.atLeastOneOrdinalParameter = true;
/* 4947 */       setLongInternal(paramInt, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNClob(int paramInt, NClob paramNClob)
/*      */     throws SQLException
/*      */   {
/* 4955 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4959 */       this.atLeastOneOrdinalParameter = true;
/* 4960 */       setNClobInternal(paramInt, paramNClob);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 4968 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4972 */       this.atLeastOneOrdinalParameter = true;
/* 4973 */       setNStringInternal(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 4982 */     this.atLeastOneOrdinalParameter = true;
/* 4983 */     setObjectInternal(paramInt, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 4991 */     this.atLeastOneOrdinalParameter = true;
/* 4992 */     setObjectInternal(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 5000 */     this.atLeastOneOrdinalParameter = true;
/* 5001 */     setRefInternal(paramInt, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setRowId(int paramInt, RowId paramRowId)
/*      */     throws SQLException
/*      */   {
/* 5008 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5012 */       this.atLeastOneOrdinalParameter = true;
/* 5013 */       setRowIdInternal(paramInt, paramRowId);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 5021 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5025 */       this.atLeastOneOrdinalParameter = true;
/* 5026 */       setShortInternal(paramInt, paramShort);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSQLXML(int paramInt, SQLXML paramSQLXML)
/*      */     throws SQLException
/*      */   {
/* 5034 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5038 */       this.atLeastOneOrdinalParameter = true;
/* 5039 */       setSQLXMLInternal(paramInt, paramSQLXML);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 5047 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5051 */       this.atLeastOneOrdinalParameter = true;
/* 5052 */       setStringInternal(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 5060 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5064 */       this.atLeastOneOrdinalParameter = true;
/* 5065 */       setTimeInternal(paramInt, paramTime);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5073 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5077 */       this.atLeastOneOrdinalParameter = true;
/* 5078 */       setTimeInternal(paramInt, paramTime, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 5086 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5090 */       this.atLeastOneOrdinalParameter = true;
/* 5091 */       setTimestampInternal(paramInt, paramTimestamp);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5099 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5103 */       this.atLeastOneOrdinalParameter = true;
/* 5104 */       setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(int paramInt, URL paramURL)
/*      */     throws SQLException
/*      */   {
/* 5112 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5116 */       this.atLeastOneOrdinalParameter = true;
/* 5117 */       setURLInternal(paramInt, paramURL);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY)
/*      */     throws SQLException
/*      */   {
/* 5126 */     this.atLeastOneOrdinalParameter = true;
/* 5127 */     setARRAYInternal(paramInt, paramARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 5134 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5138 */       this.atLeastOneOrdinalParameter = true;
/* 5139 */       setBFILEInternal(paramInt, paramBFILE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBfile(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 5147 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5151 */       this.atLeastOneOrdinalParameter = true;
/* 5152 */       setBfileInternal(paramInt, paramBFILE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 5160 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5164 */       this.atLeastOneOrdinalParameter = true;
/* 5165 */       setBinaryFloatInternal(paramInt, paramFloat);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT)
/*      */     throws SQLException
/*      */   {
/* 5173 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5177 */       this.atLeastOneOrdinalParameter = true;
/* 5178 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 5186 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5190 */       this.atLeastOneOrdinalParameter = true;
/* 5191 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE)
/*      */     throws SQLException
/*      */   {
/* 5199 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5203 */       this.atLeastOneOrdinalParameter = true;
/* 5204 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 5212 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5216 */       this.atLeastOneOrdinalParameter = true;
/* 5217 */       setBLOBInternal(paramInt, paramBLOB);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR)
/*      */     throws SQLException
/*      */   {
/* 5225 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5229 */       this.atLeastOneOrdinalParameter = true;
/* 5230 */       setCHARInternal(paramInt, paramCHAR);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 5238 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5242 */       this.atLeastOneOrdinalParameter = true;
/* 5243 */       setCLOBInternal(paramInt, paramCLOB);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet)
/*      */     throws SQLException
/*      */   {
/* 5251 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5255 */       this.atLeastOneOrdinalParameter = true;
/* 5256 */       setCursorInternal(paramInt, paramResultSet);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum)
/*      */     throws SQLException
/*      */   {
/* 5265 */     this.atLeastOneOrdinalParameter = true;
/* 5266 */     setCustomDatumInternal(paramInt, paramCustomDatum);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDATE(int paramInt, DATE paramDATE)
/*      */     throws SQLException
/*      */   {
/* 5273 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5277 */       this.atLeastOneOrdinalParameter = true;
/* 5278 */       setDATEInternal(paramInt, paramDATE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFixedCHAR(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 5286 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5290 */       this.atLeastOneOrdinalParameter = true;
/* 5291 */       setFixedCHARInternal(paramInt, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS)
/*      */     throws SQLException
/*      */   {
/* 5299 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5303 */       this.atLeastOneOrdinalParameter = true;
/* 5304 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM)
/*      */     throws SQLException
/*      */   {
/* 5312 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5316 */       this.atLeastOneOrdinalParameter = true;
/* 5317 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER)
/*      */     throws SQLException
/*      */   {
/* 5325 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5329 */       this.atLeastOneOrdinalParameter = true;
/* 5330 */       setNUMBERInternal(paramInt, paramNUMBER);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE)
/*      */     throws SQLException
/*      */   {
/* 5339 */     this.atLeastOneOrdinalParameter = true;
/* 5340 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOracleObject(int paramInt, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 5348 */     this.atLeastOneOrdinalParameter = true;
/* 5349 */     setOracleObjectInternal(paramInt, paramDatum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setORAData(int paramInt, ORAData paramORAData)
/*      */     throws SQLException
/*      */   {
/* 5357 */     this.atLeastOneOrdinalParameter = true;
/* 5358 */     setORADataInternal(paramInt, paramORAData);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setRAW(int paramInt, RAW paramRAW)
/*      */     throws SQLException
/*      */   {
/* 5365 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5369 */       this.atLeastOneOrdinalParameter = true;
/* 5370 */       setRAWInternal(paramInt, paramRAW);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setREF(int paramInt, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 5379 */     this.atLeastOneOrdinalParameter = true;
/* 5380 */     setREFInternal(paramInt, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRefType(int paramInt, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 5388 */     this.atLeastOneOrdinalParameter = true;
/* 5389 */     setRefTypeInternal(paramInt, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setROWID(int paramInt, ROWID paramROWID)
/*      */     throws SQLException
/*      */   {
/* 5396 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5400 */       this.atLeastOneOrdinalParameter = true;
/* 5401 */       setROWIDInternal(paramInt, paramROWID);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT)
/*      */     throws SQLException
/*      */   {
/* 5410 */     this.atLeastOneOrdinalParameter = true;
/* 5411 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*      */     throws SQLException
/*      */   {
/* 5418 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5422 */       this.atLeastOneOrdinalParameter = true;
/* 5423 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*      */     throws SQLException
/*      */   {
/* 5431 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5435 */       this.atLeastOneOrdinalParameter = true;
/* 5436 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP)
/*      */     throws SQLException
/*      */   {
/* 5444 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5448 */       this.atLeastOneOrdinalParameter = true;
/* 5449 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBlob(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 5457 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5461 */       this.atLeastOneOrdinalParameter = true;
/* 5462 */       setBlobInternal(paramInt, paramInputStream);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5470 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 5473 */       if (paramLong < 0L)
/*      */       {
/* 5475 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 5476 */         localSQLException.fillInStackTrace();
/* 5477 */         throw localSQLException;
/*      */       }
/*      */       
/* 5480 */       this.atLeastOneOrdinalParameter = true;
/* 5481 */       setBlobInternal(paramInt, paramInputStream, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setClob(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 5489 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5493 */       this.atLeastOneOrdinalParameter = true;
/* 5494 */       setClobInternal(paramInt, paramReader);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setClob(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5502 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5506 */       if (paramLong < 0L)
/*      */       {
/* 5508 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 5509 */         localSQLException.fillInStackTrace();
/* 5510 */         throw localSQLException;
/*      */       }
/* 5512 */       this.atLeastOneOrdinalParameter = true;
/* 5513 */       setClobInternal(paramInt, paramReader, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNClob(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 5521 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5525 */       this.atLeastOneOrdinalParameter = true;
/* 5526 */       setNClobInternal(paramInt, paramReader);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNClob(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5534 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5538 */       this.atLeastOneOrdinalParameter = true;
/* 5539 */       setNClobInternal(paramInt, paramReader, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 5547 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5551 */       this.atLeastOneOrdinalParameter = true;
/* 5552 */       setAsciiStreamInternal(paramInt, paramInputStream);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5560 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5564 */       this.atLeastOneOrdinalParameter = true;
/* 5565 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5573 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5577 */       this.atLeastOneOrdinalParameter = true;
/* 5578 */       setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 5586 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5590 */       this.atLeastOneOrdinalParameter = true;
/* 5591 */       setBinaryStreamInternal(paramInt, paramInputStream);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5599 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5603 */       this.atLeastOneOrdinalParameter = true;
/* 5604 */       setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5612 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5616 */       this.atLeastOneOrdinalParameter = true;
/* 5617 */       setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCharacterStream(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 5625 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5629 */       this.atLeastOneOrdinalParameter = true;
/* 5630 */       setCharacterStreamInternal(paramInt, paramReader);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5638 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5642 */       this.atLeastOneOrdinalParameter = true;
/* 5643 */       setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5651 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5655 */       this.atLeastOneOrdinalParameter = true;
/* 5656 */       setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 5664 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5668 */       this.atLeastOneOrdinalParameter = true;
/* 5669 */       setNCharacterStreamInternal(paramInt, paramReader);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5677 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5681 */       this.atLeastOneOrdinalParameter = true;
/* 5682 */       setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 5690 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 5694 */       this.atLeastOneOrdinalParameter = true;
/* 5695 */       setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(String paramString, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 5707 */     int i = addNamedPara(paramString);
/* 5708 */     setArrayInternal(i, paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 5718 */     int i = addNamedPara(paramString);
/* 5719 */     setBigDecimalInternal(i, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(String paramString, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 5729 */     int i = addNamedPara(paramString);
/* 5730 */     setBlobInternal(i, paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoolean(String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 5740 */     int i = addNamedPara(paramString);
/* 5741 */     setBooleanInternal(i, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setByte(String paramString, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 5751 */     int i = addNamedPara(paramString);
/* 5752 */     setByteInternal(i, paramByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytes(String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 5762 */     int i = addNamedPara(paramString);
/* 5763 */     setBytesInternal(i, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(String paramString, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 5773 */     int i = addNamedPara(paramString);
/* 5774 */     setClobInternal(i, paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(String paramString, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 5784 */     int i = addNamedPara(paramString);
/* 5785 */     setDateInternal(i, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5795 */     int i = addNamedPara(paramString);
/* 5796 */     setDateInternal(i, paramDate, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDouble(String paramString, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 5806 */     int i = addNamedPara(paramString);
/* 5807 */     setDoubleInternal(i, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFloat(String paramString, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 5817 */     int i = addNamedPara(paramString);
/* 5818 */     setFloatInternal(i, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInt(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5828 */     int i = addNamedPara(paramString);
/* 5829 */     setIntInternal(i, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLong(String paramString, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 5839 */     int i = addNamedPara(paramString);
/* 5840 */     setLongInternal(i, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNClob(String paramString, NClob paramNClob)
/*      */     throws SQLException
/*      */   {
/* 5850 */     int i = addNamedPara(paramString);
/* 5851 */     setNClobInternal(i, paramNClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNString(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 5861 */     int i = addNamedPara(paramString1);
/* 5862 */     setNStringInternal(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 5872 */     int i = addNamedPara(paramString);
/* 5873 */     setObjectInternal(i, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5883 */     int i = addNamedPara(paramString);
/* 5884 */     setObjectInternal(i, paramObject, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRef(String paramString, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 5894 */     int i = addNamedPara(paramString);
/* 5895 */     setRefInternal(i, paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRowId(String paramString, RowId paramRowId)
/*      */     throws SQLException
/*      */   {
/* 5905 */     int i = addNamedPara(paramString);
/* 5906 */     setRowIdInternal(i, paramRowId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(String paramString, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 5916 */     int i = addNamedPara(paramString);
/* 5917 */     setShortInternal(i, paramShort);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSQLXML(String paramString, SQLXML paramSQLXML)
/*      */     throws SQLException
/*      */   {
/* 5927 */     int i = addNamedPara(paramString);
/* 5928 */     setSQLXMLInternal(i, paramSQLXML);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setString(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 5938 */     int i = addNamedPara(paramString1);
/* 5939 */     setStringInternal(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(String paramString, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 5949 */     int i = addNamedPara(paramString);
/* 5950 */     setTimeInternal(i, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5960 */     int i = addNamedPara(paramString);
/* 5961 */     setTimeInternal(i, paramTime, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 5971 */     int i = addNamedPara(paramString);
/* 5972 */     setTimestampInternal(i, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 5982 */     int i = addNamedPara(paramString);
/* 5983 */     setTimestampInternal(i, paramTimestamp, paramCalendar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURL(String paramString, URL paramURL)
/*      */     throws SQLException
/*      */   {
/* 5993 */     int i = addNamedPara(paramString);
/* 5994 */     setURLInternal(i, paramURL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY)
/*      */     throws SQLException
/*      */   {
/* 6004 */     int i = addNamedPara(paramString);
/* 6005 */     setARRAYInternal(i, paramARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBFILE(String paramString, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 6015 */     int i = addNamedPara(paramString);
/* 6016 */     setBFILEInternal(i, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBfile(String paramString, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 6026 */     int i = addNamedPara(paramString);
/* 6027 */     setBfileInternal(i, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryFloat(String paramString, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 6037 */     int i = addNamedPara(paramString);
/* 6038 */     setBinaryFloatInternal(i, paramFloat);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT)
/*      */     throws SQLException
/*      */   {
/* 6048 */     int i = addNamedPara(paramString);
/* 6049 */     setBinaryFloatInternal(i, paramBINARY_FLOAT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryDouble(String paramString, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 6059 */     int i = addNamedPara(paramString);
/* 6060 */     setBinaryDoubleInternal(i, paramDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE)
/*      */     throws SQLException
/*      */   {
/* 6070 */     int i = addNamedPara(paramString);
/* 6071 */     setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBLOB(String paramString, BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 6081 */     int i = addNamedPara(paramString);
/* 6082 */     setBLOBInternal(i, paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCHAR(String paramString, CHAR paramCHAR)
/*      */     throws SQLException
/*      */   {
/* 6092 */     int i = addNamedPara(paramString);
/* 6093 */     setCHARInternal(i, paramCHAR);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCLOB(String paramString, CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 6103 */     int i = addNamedPara(paramString);
/* 6104 */     setCLOBInternal(i, paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursor(String paramString, ResultSet paramResultSet)
/*      */     throws SQLException
/*      */   {
/* 6114 */     int i = addNamedPara(paramString);
/* 6115 */     setCursorInternal(i, paramResultSet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum)
/*      */     throws SQLException
/*      */   {
/* 6125 */     int i = addNamedPara(paramString);
/* 6126 */     setCustomDatumInternal(i, paramCustomDatum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDATE(String paramString, DATE paramDATE)
/*      */     throws SQLException
/*      */   {
/* 6136 */     int i = addNamedPara(paramString);
/* 6137 */     setDATEInternal(i, paramDATE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFixedCHAR(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 6147 */     int i = addNamedPara(paramString1);
/* 6148 */     setFixedCHARInternal(i, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS)
/*      */     throws SQLException
/*      */   {
/* 6158 */     int i = addNamedPara(paramString);
/* 6159 */     setINTERVALDSInternal(i, paramINTERVALDS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM)
/*      */     throws SQLException
/*      */   {
/* 6169 */     int i = addNamedPara(paramString);
/* 6170 */     setINTERVALYMInternal(i, paramINTERVALYM);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER)
/*      */     throws SQLException
/*      */   {
/* 6180 */     int i = addNamedPara(paramString);
/* 6181 */     setNUMBERInternal(i, paramNUMBER);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE)
/*      */     throws SQLException
/*      */   {
/* 6191 */     int i = addNamedPara(paramString);
/* 6192 */     setOPAQUEInternal(i, paramOPAQUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOracleObject(String paramString, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 6202 */     int i = addNamedPara(paramString);
/* 6203 */     setOracleObjectInternal(i, paramDatum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setORAData(String paramString, ORAData paramORAData)
/*      */     throws SQLException
/*      */   {
/* 6213 */     int i = addNamedPara(paramString);
/* 6214 */     setORADataInternal(i, paramORAData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRAW(String paramString, RAW paramRAW)
/*      */     throws SQLException
/*      */   {
/* 6224 */     int i = addNamedPara(paramString);
/* 6225 */     setRAWInternal(i, paramRAW);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setREF(String paramString, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 6235 */     int i = addNamedPara(paramString);
/* 6236 */     setREFInternal(i, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRefType(String paramString, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 6246 */     int i = addNamedPara(paramString);
/* 6247 */     setRefTypeInternal(i, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setROWID(String paramString, ROWID paramROWID)
/*      */     throws SQLException
/*      */   {
/* 6257 */     int i = addNamedPara(paramString);
/* 6258 */     setROWIDInternal(i, paramROWID);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT)
/*      */     throws SQLException
/*      */   {
/* 6268 */     int i = addNamedPara(paramString);
/* 6269 */     setSTRUCTInternal(i, paramSTRUCT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*      */     throws SQLException
/*      */   {
/* 6279 */     int i = addNamedPara(paramString);
/* 6280 */     setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ)
/*      */     throws SQLException
/*      */   {
/* 6290 */     int i = addNamedPara(paramString);
/* 6291 */     setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP)
/*      */     throws SQLException
/*      */   {
/* 6301 */     int i = addNamedPara(paramString);
/* 6302 */     setTIMESTAMPInternal(i, paramTIMESTAMP);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(String paramString, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 6312 */     int i = addNamedPara(paramString);
/* 6313 */     setBlobInternal(i, paramInputStream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(String paramString, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6322 */     if (paramLong < 0L)
/*      */     {
/* 6324 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 6325 */       localSQLException.fillInStackTrace();
/* 6326 */       throw localSQLException;
/*      */     }
/*      */     
/* 6329 */     int i = addNamedPara(paramString);
/* 6330 */     setBlobInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(String paramString, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 6340 */     int i = addNamedPara(paramString);
/* 6341 */     setClobInternal(i, paramReader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClob(String paramString, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6351 */     if (paramLong < 0L)
/*      */     {
/* 6353 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 6354 */       localSQLException.fillInStackTrace();
/* 6355 */       throw localSQLException;
/*      */     }
/* 6357 */     int i = addNamedPara(paramString);
/* 6358 */     setClobInternal(i, paramReader, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNClob(String paramString, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 6368 */     int i = addNamedPara(paramString);
/* 6369 */     setNClobInternal(i, paramReader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNClob(String paramString, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6379 */     int i = addNamedPara(paramString);
/* 6380 */     setNClobInternal(i, paramReader, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 6390 */     int i = addNamedPara(paramString);
/* 6391 */     setAsciiStreamInternal(i, paramInputStream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6401 */     int i = addNamedPara(paramString);
/* 6402 */     setAsciiStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6412 */     int i = addNamedPara(paramString);
/* 6413 */     setAsciiStreamInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 6423 */     int i = addNamedPara(paramString);
/* 6424 */     setBinaryStreamInternal(i, paramInputStream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6434 */     int i = addNamedPara(paramString);
/* 6435 */     setBinaryStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6445 */     int i = addNamedPara(paramString);
/* 6446 */     setBinaryStreamInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(String paramString, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 6456 */     int i = addNamedPara(paramString);
/* 6457 */     setCharacterStreamInternal(i, paramReader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6467 */     int i = addNamedPara(paramString);
/* 6468 */     setCharacterStreamInternal(i, paramReader, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(String paramString, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6478 */     int i = addNamedPara(paramString);
/* 6479 */     setCharacterStreamInternal(i, paramReader, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNCharacterStream(String paramString, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 6489 */     int i = addNamedPara(paramString);
/* 6490 */     setNCharacterStreamInternal(i, paramReader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNCharacterStream(String paramString, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 6500 */     int i = addNamedPara(paramString);
/* 6501 */     setNCharacterStreamInternal(i, paramReader, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6511 */     int i = addNamedPara(paramString);
/* 6512 */     setUnicodeStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(String paramString1, int paramInt, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 6523 */     int i = addNamedPara(paramString1);
/* 6524 */     setNullInternal(i, paramInt, paramString2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6535 */     int i = addNamedPara(paramString);
/* 6536 */     setNullInternal(i, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor)
/*      */     throws SQLException
/*      */   {
/* 6545 */     int i = addNamedPara(paramString);
/* 6546 */     setStructDescriptorInternal(i, paramStructDescriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 6557 */     int i = addNamedPara(paramString);
/* 6558 */     setObjectInternal(i, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */     throws SQLException
/*      */   {
/* 6570 */     synchronized (this.connection)
/*      */     {
/* 6572 */       this.atLeastOneOrdinalParameter = true;
/* 6573 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int addNamedPara(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6591 */     if (this.closed)
/*      */     {
/* 6593 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6594 */       ((SQLException)localObject).fillInStackTrace();
/* 6595 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 6598 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/* 6600 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6602 */       if (localObject == this.namedParameters[i]) {
/* 6603 */         return i + 1;
/*      */       }
/*      */     }
/* 6606 */     if (this.parameterCount >= this.namedParameters.length)
/*      */     {
/* 6608 */       String[] arrayOfString = new String[this.namedParameters.length * 2];
/* 6609 */       System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
/* 6610 */       this.namedParameters = arrayOfString;
/*      */     }
/*      */     
/* 6613 */     this.namedParameters[(this.parameterCount++)] = localObject;
/*      */     
/* 6615 */     this.atLeastOneNamedParameter = true;
/* 6616 */     return this.parameterCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6626 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6629 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6630 */       ((SQLException)localObject).fillInStackTrace();
/* 6631 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6635 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6638 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6640 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6643 */     i++;
/*      */     
/* 6645 */     Accessor localAccessor = null;
/* 6646 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6651 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6652 */       localSQLException.fillInStackTrace();
/* 6653 */       throw localSQLException;
/*      */     }
/*      */     
/* 6656 */     this.lastIndex = i;
/*      */     
/* 6658 */     if (this.streamList != null) {
/* 6659 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6662 */     return localAccessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getUnicodeStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6670 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6673 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6674 */       ((SQLException)localObject).fillInStackTrace();
/* 6675 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6679 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6682 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6684 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6687 */     i++;
/*      */     
/* 6689 */     Accessor localAccessor = null;
/* 6690 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6695 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6696 */       localSQLException.fillInStackTrace();
/* 6697 */       throw localSQLException;
/*      */     }
/*      */     
/* 6700 */     this.lastIndex = i;
/*      */     
/* 6702 */     if (this.streamList != null) {
/* 6703 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6706 */     return localAccessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6714 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6717 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6718 */       ((SQLException)localObject).fillInStackTrace();
/* 6719 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6723 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6726 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6728 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6731 */     i++;
/*      */     
/* 6733 */     Accessor localAccessor = null;
/* 6734 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6739 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6740 */       localSQLException.fillInStackTrace();
/* 6741 */       throw localSQLException;
/*      */     }
/*      */     
/* 6744 */     this.lastIndex = i;
/*      */     
/* 6746 */     if (this.streamList != null) {
/* 6747 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6750 */     return localAccessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowId getRowId(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6763 */     if (this.closed)
/*      */     {
/* 6765 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6766 */       ((SQLException)localObject).fillInStackTrace();
/* 6767 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 6770 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6773 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6774 */       ((SQLException)localObject).fillInStackTrace();
/* 6775 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6779 */     Object localObject = null;
/* 6780 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6785 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6786 */       localSQLException.fillInStackTrace();
/* 6787 */       throw localSQLException;
/*      */     }
/*      */     
/* 6790 */     this.lastIndex = paramInt;
/*      */     
/* 6792 */     if (this.streamList != null) {
/* 6793 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 6796 */     return ((Accessor)localObject).getROWID(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public RowId getRowId(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6804 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6807 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6808 */       ((SQLException)localObject).fillInStackTrace();
/* 6809 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6813 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6816 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6818 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6821 */     i++;
/*      */     
/* 6823 */     Accessor localAccessor = null;
/* 6824 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6829 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6830 */       localSQLException.fillInStackTrace();
/* 6831 */       throw localSQLException;
/*      */     }
/*      */     
/* 6834 */     this.lastIndex = i;
/*      */     
/* 6836 */     if (this.streamList != null) {
/* 6837 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6840 */     return localAccessor.getROWID(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public NClob getNClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6849 */     if (this.closed)
/*      */     {
/* 6851 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6852 */       ((SQLException)localObject).fillInStackTrace();
/* 6853 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 6856 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6859 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6860 */       ((SQLException)localObject).fillInStackTrace();
/* 6861 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6865 */     Object localObject = null;
/* 6866 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6871 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6872 */       localSQLException.fillInStackTrace();
/* 6873 */       throw localSQLException;
/*      */     }
/*      */     
/* 6876 */     this.lastIndex = paramInt;
/*      */     
/* 6878 */     if (this.streamList != null) {
/* 6879 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 6882 */     return ((Accessor)localObject).getNClob(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public NClob getNClob(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6890 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6893 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6894 */       ((SQLException)localObject).fillInStackTrace();
/* 6895 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6899 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6902 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6904 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6907 */     i++;
/*      */     
/* 6909 */     Accessor localAccessor = null;
/* 6910 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6915 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6916 */       localSQLException.fillInStackTrace();
/* 6917 */       throw localSQLException;
/*      */     }
/*      */     
/* 6920 */     this.lastIndex = i;
/*      */     
/* 6922 */     if (this.streamList != null) {
/* 6923 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 6926 */     return localAccessor.getNClob(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public SQLXML getSQLXML(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 6934 */     if (this.closed)
/*      */     {
/* 6936 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6937 */       ((SQLException)localObject).fillInStackTrace();
/* 6938 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 6941 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6944 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6945 */       ((SQLException)localObject).fillInStackTrace();
/* 6946 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6950 */     Object localObject = null;
/* 6951 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6956 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6957 */       localSQLException.fillInStackTrace();
/* 6958 */       throw localSQLException;
/*      */     }
/*      */     
/* 6961 */     this.lastIndex = paramInt;
/*      */     
/* 6963 */     if (this.streamList != null) {
/* 6964 */       closeUsedStreams(paramInt);
/*      */     }
/* 6966 */     return ((Accessor)localObject).getSQLXML(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public SQLXML getSQLXML(String paramString)
/*      */     throws SQLException
/*      */   {
/* 6974 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 6977 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6978 */       ((SQLException)localObject).fillInStackTrace();
/* 6979 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 6983 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 6986 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 6988 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 6991 */     i++;
/*      */     
/* 6993 */     Accessor localAccessor = null;
/* 6994 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 6999 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7000 */       localSQLException.fillInStackTrace();
/* 7001 */       throw localSQLException;
/*      */     }
/*      */     
/* 7004 */     this.lastIndex = i;
/*      */     
/* 7006 */     if (this.streamList != null) {
/* 7007 */       closeUsedStreams(i);
/*      */     }
/* 7009 */     return localAccessor.getSQLXML(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 7018 */     if (this.closed)
/*      */     {
/* 7020 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 7021 */       ((SQLException)localObject).fillInStackTrace();
/* 7022 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 7025 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 7028 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7029 */       ((SQLException)localObject).fillInStackTrace();
/* 7030 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 7034 */     Object localObject = null;
/* 7035 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 7040 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 7041 */       localSQLException.fillInStackTrace();
/* 7042 */       throw localSQLException;
/*      */     }
/*      */     
/* 7045 */     this.lastIndex = paramInt;
/*      */     
/* 7047 */     if (this.streamList != null) {
/* 7048 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 7051 */     return ((Accessor)localObject).getNString(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getNString(String paramString)
/*      */     throws SQLException
/*      */   {
/* 7059 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 7062 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7063 */       ((SQLException)localObject).fillInStackTrace();
/* 7064 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 7068 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 7071 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 7073 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 7076 */     i++;
/*      */     
/* 7078 */     Accessor localAccessor = null;
/* 7079 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 7084 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7085 */       localSQLException.fillInStackTrace();
/* 7086 */       throw localSQLException;
/*      */     }
/*      */     
/* 7089 */     this.lastIndex = i;
/*      */     
/* 7091 */     if (this.streamList != null) {
/* 7092 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 7095 */     return localAccessor.getNString(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getNCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 7104 */     if (this.closed)
/*      */     {
/* 7106 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 7107 */       ((SQLException)localObject).fillInStackTrace();
/* 7108 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 7111 */     if (this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 7114 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7115 */       ((SQLException)localObject).fillInStackTrace();
/* 7116 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 7120 */     Object localObject = null;
/* 7121 */     if ((paramInt <= 0) || (paramInt > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localObject = this.outBindAccessors[(paramInt - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 7126 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 7127 */       localSQLException.fillInStackTrace();
/* 7128 */       throw localSQLException;
/*      */     }
/*      */     
/* 7131 */     this.lastIndex = paramInt;
/*      */     
/* 7133 */     if (this.streamList != null) {
/* 7134 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 7137 */     return ((Accessor)localObject).getNCharacterStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Reader getNCharacterStream(String paramString)
/*      */     throws SQLException
/*      */   {
/* 7145 */     if (!this.atLeastOneNamedParameter)
/*      */     {
/*      */ 
/* 7148 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7149 */       ((SQLException)localObject).fillInStackTrace();
/* 7150 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 7154 */     Object localObject = paramString.toUpperCase().intern();
/*      */     
/*      */ 
/* 7157 */     for (int i = 0; i < this.parameterCount; i++)
/*      */     {
/* 7159 */       if (localObject == this.namedParameters[i])
/*      */         break;
/*      */     }
/* 7162 */     i++;
/*      */     
/* 7164 */     Accessor localAccessor = null;
/* 7165 */     if ((i <= 0) || (i > this.numberOfBindPositions) || (this.outBindAccessors == null) || ((localAccessor = this.outBindAccessors[(i - 1)]) == null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 7170 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7171 */       localSQLException.fillInStackTrace();
/* 7172 */       throw localSQLException;
/*      */     }
/*      */     
/* 7175 */     this.lastIndex = i;
/*      */     
/* 7177 */     if (this.streamList != null) {
/* 7178 */       closeUsedStreams(i);
/*      */     }
/*      */     
/* 7181 */     return localAccessor.getNCharacterStream(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7188 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\OracleCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */