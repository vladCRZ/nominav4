/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import oracle.jdbc.OracleDatabaseMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDriver
/*     */   implements Driver
/*     */ {
/*     */   public static final String oracle_string = "oracle";
/*     */   public static final String jdbc_string = "jdbc";
/*     */   public static final String protocol_string = "protocol";
/*     */   public static final String user_string = "user";
/*     */   public static final String password_string = "password";
/*     */   public static final String database_string = "database";
/*     */   public static final String server_string = "server";
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String access_string = "access";
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String protocolFullName_string = "protocolFullName";
/*     */   public static final String logon_as_internal_str = "internal_logon";
/*     */   public static final String proxy_client_name = "oracle.jdbc.proxyClientName";
/*     */   public static final String prefetch_string = "prefetch";
/*     */   public static final String row_prefetch_string = "rowPrefetch";
/*     */   public static final String default_row_prefetch_string = "defaultRowPrefetch";
/*     */   public static final String batch_string = "batch";
/*     */   public static final String execute_batch_string = "executeBatch";
/*     */   public static final String default_execute_batch_string = "defaultExecuteBatch";
/*     */   public static final String process_escapes_string = "processEscapes";
/*     */   public static final String accumulate_batch_result = "AccumulateBatchResult";
/*     */   public static final String j2ee_compliance = "oracle.jdbc.J2EE13Compliant";
/*     */   public static final String v8compatible_string = "V8Compatible";
/*     */   public static final String permit_timestamp_date_mismatch_string = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
/*     */   public static final String StreamChunkSize_string = "oracle.jdbc.StreamChunkSize";
/*     */   public static final String prelim_auth_string = "prelim_auth";
/*     */   public static final String SetFloatAndDoubleUseBinary_string = "SetFloatAndDoubleUseBinary";
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final String xa_trans_loose = "oracle.jdbc.XATransLoose";
/*     */   public static final String tcp_no_delay = "oracle.jdbc.TcpNoDelay";
/*     */   public static final String read_timeout = "oracle.jdbc.ReadTimeout";
/*     */   public static final String defaultnchar_string = "oracle.jdbc.defaultNChar";
/*     */   public static final String defaultncharprop_string = "defaultNChar";
/*     */   public static final String useFetchSizeWithLongColumn_prop_string = "useFetchSizeWithLongColumn";
/*     */   public static final String useFetchSizeWithLongColumn_string = "oracle.jdbc.useFetchSizeWithLongColumn";
/*     */   public static final String remarks_string = "remarks";
/*     */   public static final String report_remarks_string = "remarksReporting";
/*     */   public static final String synonyms_string = "synonyms";
/*     */   public static final String include_synonyms_string = "includeSynonyms";
/*     */   public static final String restrict_getTables_string = "restrictGetTables";
/*     */   public static final String fixed_string_string = "fixedString";
/*     */   public static final String dll_string = "oracle.jdbc.ocinativelibrary";
/*     */   public static final String nls_lang_backdoor = "oracle.jdbc.ociNlsLangBackwardCompatible";
/*     */   public static final String disable_defineColumnType_string = "disableDefineColumnType";
/*     */   public static final String convert_nchar_literals_string = "oracle.jdbc.convertNcharLiterals";
/*     */   public static final String dataSizeUnitsPropertyName = "";
/*     */   public static final String dataSizeBytes = "";
/*     */   public static final String dataSizeChars = "";
/*     */   public static final String set_new_password_string = "OCINewPassword";
/*     */   public static final String retain_v9_bind_behavior_string = "oracle.jdbc.RetainV9LongBindBehavior";
/*     */   public static final String no_caching_buffers = "oracle.jdbc.FreeMemoryOnEnterImplicitCache";
/*     */   static final int EXTENSION_TYPE_ORACLE_ERROR = -3;
/*     */   static final int EXTENSION_TYPE_GEN_ERROR = -2;
/*     */   static final int EXTENSION_TYPE_TYPE4_CLIENT = 0;
/*     */   static final int EXTENSION_TYPE_TYPE4_SERVER = 1;
/*     */   static final int EXTENSION_TYPE_TYPE2_CLIENT = 2;
/*     */   static final int EXTENSION_TYPE_TYPE2_SERVER = 3;
/*     */   private static final int NUMBER_OF_EXTENSION_TYPES = 4;
/* 142 */   private OracleDriverExtension[] driverExtensions = new OracleDriverExtension[4];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String DRIVER_PACKAGE_STRING = "driver";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */   private static final String[] driverExtensionClassNames = { "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T2CDriverExtension", "oracle.jdbc.driver.T2SDriverExtension" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Properties driverAccess;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */   protected static Connection defaultConn = null;
/* 178 */   private static OracleDriver defaultDriver = null;
/*     */   public static final Map<String, ClassRef> systemTypeMap;
/*     */   private static final String DEFAULT_CONNECTION_PROPERTIES_RESOURCE_NAME = "/oracle/jdbc/defaultConnectionProperties.properties";
/*     */   protected static final Properties DEFAULT_CONNECTION_PROPERTIES;
/*     */   
/*     */   static {
/*     */     try {
/* 185 */       if (defaultDriver == null)
/*     */       {
/* 187 */         defaultDriver = new oracle.jdbc.OracleDriver();
/* 188 */         DriverManager.registerDriver(defaultDriver);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Object run()
/*     */         {
/* 199 */           OracleDriver.registerMBeans();
/* 200 */           return null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 215 */       });
/* 216 */       Timestamp localTimestamp = Timestamp.valueOf("2000-01-01 00:00:00.0");
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 221 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "SQLException in static block.", localSQLException);
/*     */ 
/*     */     }
/*     */     catch (RuntimeException localRuntimeException)
/*     */     {
/*     */ 
/* 227 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "RuntimeException in static block.", localRuntimeException);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 241 */       ClassRef localClassRef = ClassRef.newInstance("oracle.security.pki.OraclePKIProvider");
/* 242 */       Object localObject = localClassRef.get().newInstance();
/*     */     }
/*     */     catch (Throwable localThrowable) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     systemTypeMap = new Hashtable(3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 260 */       systemTypeMap.put("SYS.XMLTYPE", ClassRef.newInstance("oracle.xdb.XMLTypeFactory"));
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException1) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 270 */       systemTypeMap.put("SYS.ANYDATA", ClassRef.newInstance("oracle.sql.AnyDataFactory"));
/* 271 */       systemTypeMap.put("SYS.ANYTYPE", ClassRef.newInstance("oracle.sql.TypeDescriptorFactory"));
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException2) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */     DEFAULT_CONNECTION_PROPERTIES = new Properties();
/*     */     try
/*     */     {
/* 289 */       InputStream localInputStream = PhysicalConnection.class.getResourceAsStream("/oracle/jdbc/defaultConnectionProperties.properties");
/* 290 */       if (localInputStream != null) { DEFAULT_CONNECTION_PROPERTIES.load(localInputStream);
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerMBeans()
/*     */   {
/*     */     try
/*     */     {
/* 308 */       MBeanServer localMBeanServer = null;
/*     */       Object localObject1;
/*     */       Object localObject3;
/* 311 */       try { ClassRef localClassRef = ClassRef.newInstance("oracle.as.jmx.framework.PortableMBeanFactory");
/* 312 */         localObject1 = localClassRef.get().getConstructor(new Class[0]);
/* 313 */         Object localObject2 = ((Constructor)localObject1).newInstance(new Object[0]);
/* 314 */         localObject3 = localClassRef.get().getMethod("getMBeanServer", new Class[0]);
/* 315 */         localMBeanServer = (MBeanServer)((Method)localObject3).invoke(localObject2, new Object[0]);
/*     */ 
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException)
/*     */       {
/* 320 */         localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {
/* 323 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but not the getMBeanServer method.", localNoSuchMethodException);
/*     */         
/*     */ 
/*     */ 
/* 327 */         localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/*     */       catch (InstantiationException localInstantiationException) {
/* 330 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not create an instance.", localInstantiationException);
/*     */         
/*     */ 
/*     */ 
/* 334 */         localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/*     */       catch (IllegalAccessException localIllegalAccessException) {
/* 337 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not access the getMBeanServer method.", localIllegalAccessException);
/*     */         
/*     */ 
/*     */ 
/* 341 */         localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/*     */       catch (InvocationTargetException localInvocationTargetException) {
/* 344 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but the getMBeanServer method threw an exception.", localInvocationTargetException);
/*     */         
/*     */ 
/*     */ 
/* 348 */         localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 350 */       if (localMBeanServer != null) {
/* 351 */         ClassLoader localClassLoader = OracleDriver.class.getClassLoader();
/* 352 */         localObject1 = localClassLoader == null ? "nullLoader" : localClassLoader.getClass().getName();
/* 353 */         int i = 0;
/*     */         for (;;) {
/* 355 */           localObject3 = (String)localObject1 + "@" + Integer.toHexString((localClassLoader == null ? 0 : localClassLoader.hashCode()) + i++);
/*     */           
/* 357 */           ObjectName localObjectName = new ObjectName("com.oracle.jdbc:type=diagnosability,name=" + (String)localObject3);
/*     */           try
/*     */           {
/* 360 */             localMBeanServer.registerMBean(new OracleDiagnosabilityMBean(), localObjectName);
/*     */ 
/*     */           }
/*     */           catch (InstanceAlreadyExistsException localInstanceAlreadyExistsException) {}
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 368 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBears are registered.");
/*     */       }
/*     */     }
/*     */     catch (JMException localJMException)
/*     */     {
/* 373 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", localJMException);
/*     */ 
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/*     */ 
/* 379 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", localThrowable);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection connect(String paramString, Properties paramProperties)
/*     */     throws SQLException
/*     */   {
/* 413 */     if (paramString.regionMatches(0, "jdbc:default:connection", 0, 23))
/*     */     {
/* 415 */       String str = "jdbc:oracle:kprb";
/* 416 */       int j = paramString.length();
/*     */       
/* 418 */       if (j > 23) {
/* 419 */         paramString = str.concat(paramString.substring(23, paramString.length()));
/*     */       } else {
/* 421 */         paramString = str.concat(":");
/*     */       }
/* 423 */       str = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 433 */     int i = oracleDriverExtensionTypeFromURL(paramString);
/*     */     
/* 435 */     if (i == -2) {
/* 436 */       return null;
/*     */     }
/* 438 */     if (i == -3)
/*     */     {
/* 440 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
/* 441 */       ((SQLException)localObject1).fillInStackTrace();
/* 442 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/* 445 */     Object localObject1 = null;
/*     */     
/* 447 */     localObject1 = this.driverExtensions[i];
/*     */     
/* 449 */     if (localObject1 == null)
/*     */     {
/*     */       try
/*     */       {
/*     */ 
/* 454 */         synchronized (this)
/*     */         {
/* 456 */           if (localObject1 == null)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 462 */             localObject1 = (OracleDriverExtension)Class.forName(driverExtensionClassNames[i]).newInstance();
/*     */             
/* 464 */             this.driverExtensions[i] = localObject1;
/*     */           }
/*     */           else
/*     */           {
/* 468 */             localObject1 = this.driverExtensions[i];
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception localException)
/*     */       {
/* 476 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localException);
/* 477 */         ((SQLException)localObject3).fillInStackTrace();
/* 478 */         throw ((Throwable)localObject3);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 485 */     if (paramProperties == null) {
/* 486 */       paramProperties = new Properties();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 497 */     Enumeration localEnumeration = DriverManager.getDrivers();
/*     */     
/*     */ 
/* 500 */     while (localEnumeration.hasMoreElements())
/*     */     {
/* 502 */       localObject3 = (Driver)localEnumeration.nextElement();
/*     */       
/* 504 */       if ((localObject3 instanceof OracleDriver)) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 509 */     while (localEnumeration.hasMoreElements())
/*     */     {
/* 511 */       localObject3 = (Driver)localEnumeration.nextElement();
/*     */       
/* 513 */       if ((localObject3 instanceof OracleDriver)) {
/* 514 */         DriverManager.deregisterDriver((Driver)localObject3);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 521 */     Object localObject3 = (PhysicalConnection)((OracleDriverExtension)localObject1).getConnection(paramString, paramProperties);
/*     */     
/*     */ 
/* 524 */     ((PhysicalConnection)localObject3).protocolId = i;
/*     */     
/* 526 */     return (Connection)localObject3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection defaultConnection()
/*     */     throws SQLException
/*     */   {
/* 539 */     if ((defaultConn == null) || (defaultConn.isClosed()))
/*     */     {
/* 541 */       synchronized (OracleDriver.class)
/*     */       {
/* 543 */         if ((defaultConn == null) || (defaultConn.isClosed()))
/*     */         {
/* 545 */           defaultConn = connect("jdbc:oracle:kprb:", new Properties());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 550 */     return defaultConn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int oracleDriverExtensionTypeFromURL(String paramString)
/*     */   {
/* 575 */     int i = paramString.indexOf(':');
/*     */     
/* 577 */     if (i == -1) {
/* 578 */       return -2;
/*     */     }
/* 580 */     if (!paramString.regionMatches(true, 0, "jdbc", 0, i)) {
/* 581 */       return -2;
/*     */     }
/* 583 */     i++;
/*     */     
/* 585 */     int j = paramString.indexOf(':', i);
/*     */     
/* 587 */     if (j == -1) {
/* 588 */       return -2;
/*     */     }
/* 590 */     if (!paramString.regionMatches(true, i, "oracle", 0, j - i))
/*     */     {
/* 592 */       return -2;
/*     */     }
/* 594 */     j++;
/*     */     
/* 596 */     int k = paramString.indexOf(':', j);
/*     */     
/* 598 */     String str = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 605 */     if (k == -1) {
/* 606 */       return -3;
/*     */     }
/* 608 */     str = paramString.substring(j, k);
/*     */     
/* 610 */     if (str.equals("thin")) {
/* 611 */       return 0;
/*     */     }
/* 613 */     if ((str.equals("oci8")) || (str.equals("oci"))) {
/* 614 */       return 2;
/*     */     }
/*     */     
/*     */ 
/* 618 */     return -3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean acceptsURL(String paramString)
/*     */   {
/* 638 */     if (paramString.startsWith("jdbc:oracle:"))
/*     */     {
/* 640 */       return oracleDriverExtensionTypeFromURL(paramString) > -2;
/*     */     }
/*     */     
/* 643 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties)
/*     */     throws SQLException
/*     */   {
/* 651 */     Class localClass = null;
/*     */     try
/*     */     {
/* 654 */       localClass = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     
/*     */ 
/* 659 */     int i = 0;
/* 660 */     Object localObject1 = new String[''];
/* 661 */     Object localObject2 = new String[''];
/*     */     
/* 663 */     Field[] arrayOfField = localClass.getFields();
/* 664 */     for (int j = 0; j < arrayOfField.length; j++)
/*     */     {
/* 666 */       if ((arrayOfField[j].getName().startsWith("CONNECTION_PROPERTY_")) && (!arrayOfField[j].getName().endsWith("_DEFAULT")) && (!arrayOfField[j].getName().endsWith("_ACCESSMODE")))
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/* 672 */           String str1 = (String)arrayOfField[j].get(null);
/* 673 */           Field localField = localClass.getField(arrayOfField[j].getName() + "_DEFAULT");
/* 674 */           String str2 = (String)localField.get(null);
/* 675 */           if (i == localObject1.length)
/*     */           {
/* 677 */             String[] arrayOfString1 = new String[localObject1.length * 2];
/* 678 */             String[] arrayOfString2 = new String[localObject1.length * 2];
/* 679 */             System.arraycopy(localObject1, 0, arrayOfString1, 0, localObject1.length);
/* 680 */             System.arraycopy(localObject2, 0, arrayOfString2, 0, localObject1.length);
/* 681 */             localObject1 = arrayOfString1;
/* 682 */             localObject2 = arrayOfString2;
/*     */           }
/* 684 */           localObject1[i] = str1;
/* 685 */           localObject2[i] = str2;
/* 686 */           i++;
/*     */         }
/*     */         catch (IllegalAccessException localIllegalAccessException) {}catch (NoSuchFieldException localNoSuchFieldException) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 694 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[i];
/* 695 */     for (int k = 0; k < i; k++)
/* 696 */       arrayOfDriverPropertyInfo[k] = new DriverPropertyInfo(localObject1[k], localObject2[k]);
/* 697 */     return arrayOfDriverPropertyInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMajorVersion()
/*     */   {
/* 704 */     return OracleDatabaseMetaData.getDriverMajorVersionInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMinorVersion()
/*     */   {
/* 711 */     return OracleDatabaseMetaData.getDriverMinorVersionInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean jdbcCompliant()
/*     */   {
/* 718 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String processSqlEscapes(String paramString)
/*     */     throws SQLException
/*     */   {
/* 733 */     OracleSql localOracleSql = new OracleSql(null);
/*     */     
/*     */ 
/*     */ 
/* 737 */     localOracleSql.initialize(paramString);
/*     */     
/* 739 */     return localOracleSql.parse(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCompileTime()
/*     */   {
/* 754 */     return "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getSystemPropertyFastConnectionFailover(String paramString)
/*     */   {
/* 761 */     return PhysicalConnection.getSystemPropertyFastConnectionFailover(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 776 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 781 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\OracleDriver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */