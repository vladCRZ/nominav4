/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.BufferedInputStream;
/*       */ import java.io.BufferedReader;
/*       */ import java.io.ByteArrayInputStream;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.io.StringReader;
/*       */ import java.math.BigDecimal;
/*       */ import java.net.URL;
/*       */ import java.sql.Array;
/*       */ import java.sql.BatchUpdateException;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Date;
/*       */ import java.sql.NClob;
/*       */ import java.sql.ParameterMetaData;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.RowId;
/*       */ import java.sql.SQLData;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Locale;
/*       */ import java.util.TimeZone;
/*       */ import oracle.jdbc.internal.ObjectData;
/*       */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeNUMBER;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.OpaqueDescriptor;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ abstract class OraclePreparedStatement
/*       */   extends OracleStatement
/*       */   implements oracle.jdbc.internal.OraclePreparedStatement, ScrollRsetStatement
/*       */ {
/*       */   int numberOfBindRowsAllocated;
/*   102 */   static Binder theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
/*       */   
/*   104 */   static Binder theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
/*       */   
/*   106 */   Binder theVarnumNullBinder = theStaticVarnumNullBinder;
/*       */   
/*   108 */   static Binder theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
/*       */   
/*   110 */   Binder theBooleanBinder = theStaticBooleanBinder;
/*       */   
/*   112 */   static Binder theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
/*       */   
/*   114 */   Binder theByteBinder = theStaticByteBinder;
/*       */   
/*   116 */   static Binder theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
/*       */   
/*   118 */   Binder theShortBinder = theStaticShortBinder;
/*       */   
/*   120 */   static Binder theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
/*       */   
/*   122 */   Binder theIntBinder = theStaticIntBinder;
/*       */   
/*   124 */   static Binder theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
/*       */   
/*   126 */   Binder theLongBinder = theStaticLongBinder;
/*       */   
/*   128 */   static Binder theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
/*       */   
/*   130 */   Binder theFloatBinder = null;
/*       */   
/*   132 */   static Binder theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
/*       */   
/*   134 */   Binder theDoubleBinder = null;
/*       */   
/*   136 */   static Binder theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
/*       */   
/*   138 */   Binder theBigDecimalBinder = theStaticBigDecimalBinder;
/*       */   
/*   140 */   static Binder theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
/*       */   
/*   142 */   static Binder theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
/*       */   
/*   144 */   Binder theVarcharNullBinder = theStaticVarcharNullBinder;
/*       */   
/*   146 */   static Binder theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
/*       */   
/*   148 */   Binder theStringBinder = theStaticStringBinder;
/*       */   
/*   150 */   static Binder theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
/*       */   
/*   152 */   static Binder theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
/*       */   
/*   154 */   static Binder theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
/*       */   
/*   156 */   static Binder theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
/*       */   
/*       */   Binder theSetCHARBinder;
/*   159 */   Binder theSetCHARNullBinder = theStaticSetCHARNullBinder;
/*       */   
/*   161 */   static Binder theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
/*       */   
/*   163 */   static Binder theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
/*       */   
/*   165 */   static Binder theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
/*       */   
/*   167 */   Binder theFixedCHARBinder = theStaticFixedCHARBinder;
/*   168 */   Binder theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
/*       */   
/*   170 */   static Binder theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
/*       */   
/*   172 */   static Binder theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
/*       */   
/*   174 */   static Binder theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
/*       */   
/*   176 */   Binder theDateBinder = theStaticDateBinder;
/*   177 */   Binder theDateNullBinder = theStaticDateNullBinder;
/*       */   
/*   179 */   static Binder theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
/*       */   
/*   181 */   static Binder theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
/*       */   
/*   183 */   Binder theTimeBinder = theStaticTimeBinder;
/*       */   
/*   185 */   static Binder theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
/*       */   
/*   187 */   static Binder theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
/*       */   
/*   189 */   static Binder theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
/*       */   
/*   191 */   Binder theTimestampBinder = theStaticTimestampBinder;
/*   192 */   Binder theTimestampNullBinder = theStaticTimestampNullBinder;
/*       */   
/*   194 */   static Binder theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
/*       */   
/*   196 */   Binder theOracleNumberBinder = theStaticOracleNumberBinder;
/*       */   
/*   198 */   static Binder theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
/*       */   
/*   200 */   Binder theOracleDateBinder = theStaticOracleDateBinder;
/*       */   
/*   202 */   static Binder theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
/*       */   
/*   204 */   Binder theOracleTimestampBinder = theStaticOracleTimestampBinder;
/*       */   
/*   206 */   static Binder theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
/*       */   
/*   208 */   static Binder theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
/*       */   
/*   210 */   static Binder theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
/*       */   
/*   212 */   Binder theTSTZBinder = theStaticTSTZBinder;
/*   213 */   Binder theTSTZNullBinder = theStaticTSTZNullBinder;
/*       */   
/*   215 */   static Binder theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
/*       */   
/*   217 */   static Binder theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
/*       */   
/*   219 */   static Binder theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
/*       */   
/*   221 */   Binder theTSLTZBinder = theStaticTSLTZBinder;
/*   222 */   Binder theTSLTZNullBinder = theStaticTSLTZNullBinder;
/*       */   
/*   224 */   static Binder theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
/*       */   
/*   226 */   static Binder theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
/*       */   
/*   228 */   static Binder theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
/*       */   
/*   230 */   static Binder theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
/*       */   
/*   232 */   static Binder theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
/*       */   
/*       */   Binder theRowidBinder;
/*   235 */   Binder theRowidNullBinder = theStaticRowidNullBinder;
/*       */   
/*       */   Binder theURowidBinder;
/*   238 */   Binder theURowidNullBinder = theStaticURowidNullBinder;
/*       */   
/*   240 */   static Binder theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
/*       */   
/*   242 */   static Binder theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
/*       */   
/*   244 */   static Binder theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
/*       */   
/*   246 */   Binder theIntervalDSBinder = theStaticIntervalDSBinder;
/*   247 */   Binder theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
/*       */   
/*   249 */   static Binder theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
/*       */   
/*   251 */   static Binder theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
/*       */   
/*   253 */   static Binder theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
/*       */   
/*   255 */   Binder theIntervalYMBinder = theStaticIntervalYMBinder;
/*   256 */   Binder theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
/*       */   
/*   258 */   static Binder theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
/*       */   
/*   260 */   static Binder theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
/*       */   
/*   262 */   static Binder theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
/*       */   
/*   264 */   Binder theBfileBinder = theStaticBfileBinder;
/*   265 */   Binder theBfileNullBinder = theStaticBfileNullBinder;
/*       */   
/*   267 */   static Binder theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
/*       */   
/*   269 */   static Binder theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
/*       */   
/*   271 */   static Binder theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
/*       */   
/*   273 */   Binder theBlobBinder = theStaticBlobBinder;
/*   274 */   Binder theBlobNullBinder = theStaticBlobNullBinder;
/*       */   
/*   276 */   static Binder theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
/*       */   
/*   278 */   static Binder theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
/*       */   
/*   280 */   static Binder theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
/*       */   
/*   282 */   Binder theClobBinder = theStaticClobBinder;
/*   283 */   Binder theClobNullBinder = theStaticClobNullBinder;
/*       */   
/*   285 */   static Binder theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
/*       */   
/*   287 */   static Binder theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
/*       */   
/*   289 */   static Binder theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
/*       */   
/*   291 */   Binder theRawBinder = theStaticRawBinder;
/*   292 */   Binder theRawNullBinder = theStaticRawNullBinder;
/*       */   
/*   294 */   static Binder theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
/*       */   
/*   296 */   static Binder theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
/*       */   
/*   298 */   Binder thePlsqlRawBinder = theStaticPlsqlRawBinder;
/*       */   
/*   300 */   static Binder theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
/*       */   
/*   302 */   static Binder theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
/*       */   
/*   304 */   static Binder theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
/*       */   
/*   306 */   Binder theBinaryFloatBinder = theStaticBinaryFloatBinder;
/*   307 */   Binder theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
/*       */   
/*   309 */   static Binder theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
/*       */   
/*   311 */   static Binder theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
/*       */   
/*   313 */   static Binder theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
/*       */   
/*   315 */   Binder theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
/*   316 */   Binder theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
/*       */   
/*   318 */   static Binder theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
/*       */   
/*   320 */   static Binder theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
/*       */   
/*   322 */   static Binder theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
/*       */   
/*   324 */   Binder theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
/*   325 */   Binder theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
/*       */   
/*   327 */   static Binder theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
/*       */   
/*   329 */   static Binder theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
/*       */   
/*   331 */   static Binder theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   333 */   Binder theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
/*   334 */   Binder theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   336 */   static Binder theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
/*       */   
/*   338 */   Binder theLongStreamBinder = theStaticLongStreamBinder;
/*       */   
/*   340 */   static Binder theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
/*       */   
/*   342 */   Binder theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
/*   343 */   static Binder theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
/*       */   
/*       */ 
/*   346 */   static Binder theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
/*       */   
/*   348 */   Binder theLongRawStreamBinder = theStaticLongRawStreamBinder;
/*       */   
/*   350 */   static Binder theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
/*       */   
/*   352 */   Binder theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
/*   353 */   static Binder theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
/*       */   
/*       */ 
/*   356 */   static Binder theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
/*       */   
/*   358 */   static Binder theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
/*       */   
/*   360 */   static Binder theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
/*       */   
/*   362 */   Binder theNamedTypeBinder = theStaticNamedTypeBinder;
/*   363 */   Binder theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
/*       */   
/*   365 */   static Binder theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
/*       */   
/*   367 */   static Binder theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
/*       */   
/*   369 */   static Binder theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
/*       */   
/*   371 */   Binder theRefTypeBinder = theStaticRefTypeBinder;
/*   372 */   Binder theRefTypeNullBinder = theStaticRefTypeNullBinder;
/*       */   
/*   374 */   static Binder theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
/*       */   
/*   376 */   static Binder theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
/*       */   
/*   378 */   static Binder theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
/*       */   
/*   380 */   Binder thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
/*   381 */   Binder thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
/*       */   
/*   383 */   static Binder theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
/*       */   
/*   385 */   Binder theOutBinder = theStaticOutBinder;
/*       */   
/*   387 */   static Binder theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
/*       */   
/*   389 */   Binder theReturnParamBinder = theStaticReturnParamBinder;
/*       */   
/*   391 */   static Binder theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
/*       */   
/*   393 */   static Binder theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
/*       */   
/*   395 */   static Binder theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
/*       */   
/*   397 */   static Binder theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   404 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*   405 */   private static final Calendar UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
/*       */   
/*   407 */   protected Calendar cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
/*       */   
/*       */   public static final int TypeBinder_BYTELEN = 24;
/*       */   
/*   411 */   char[] digits = new char[20];
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Binder[][] binders;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int[][] parameterInt;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   long[][] parameterLong;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   float[][] parameterFloat;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   double[][] parameterDouble;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   BigDecimal[][] parameterBigDecimal;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   String[][] parameterString;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Date[][] parameterDate;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Time[][] parameterTime;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Timestamp[][] parameterTimestamp;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   byte[][][] parameterDatum;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleTypeADT[][] parameterOtype;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   CLOB[] lastBoundClobs;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   BLOB[] lastBoundBlobs;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PlsqlIbtBindInfo[][] parameterPlsqlIbt;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Binder[] currentRowBinders;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int[] currentRowCharLens;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Accessor[] currentRowBindAccessors;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   short[] currentRowFormOfUse;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*   529 */   boolean currentRowNeedToPrepareBinds = true;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int[] currentBatchCharLens;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Accessor[] currentBatchBindAccessors;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   short[] currentBatchFormOfUse;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean currentBatchNeedToPrepareBinds;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PushedBatch pushedBatches;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PushedBatch pushedBatchesTail;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   869 */   int cachedBindByteSize = 0;
/*   870 */   int cachedBindCharSize = 0;
/*   871 */   int cachedBindIndicatorSize = 0;
/*       */   
/*       */ 
/*       */ 
/*       */   int totalBindByteLength;
/*       */   
/*       */ 
/*       */ 
/*       */   int totalBindCharLength;
/*       */   
/*       */ 
/*       */ 
/*       */   int totalBindIndicatorLength;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_TYPE_OFFSET = 0;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
/*       */   
/*       */ 
/*       */   static final int BIND_METADATA_PER_POSITION_SIZE = 10;
/*       */   
/*       */ 
/*       */   static final int SETLOB_NO_LENGTH = -1;
/*       */   
/*       */ 
/*       */   int bindBufferCapacity;
/*       */   
/*       */ 
/*       */   int numberOfBoundRows;
/*       */   
/*       */ 
/*       */   int indicatorsOffset;
/*       */   
/*       */ 
/*       */   int valueLengthsOffset;
/*       */   
/*       */ 
/*       */   boolean preparedAllBinds;
/*       */   
/*       */ 
/*       */   boolean preparedCharBinds;
/*       */   
/*       */ 
/*       */   Binder[] lastBinders;
/*       */   
/*       */ 
/*       */   byte[] lastBoundBytes;
/*       */   
/*       */ 
/*       */   int lastBoundByteOffset;
/*       */   
/*       */ 
/*       */   char[] lastBoundChars;
/*       */   
/*       */ 
/*       */   int lastBoundCharOffset;
/*       */   
/*       */ 
/*       */   int[] lastBoundByteOffsets;
/*       */   
/*       */ 
/*       */   int[] lastBoundCharOffsets;
/*       */   
/*       */ 
/*       */   int[] lastBoundByteLens;
/*       */   
/*       */ 
/*       */   int[] lastBoundCharLens;
/*       */   
/*       */ 
/*       */   short[] lastBoundInds;
/*       */   
/*       */ 
/*       */   short[] lastBoundLens;
/*       */   
/*       */ 
/*   991 */   boolean lastBoundNeeded = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   byte[][] lastBoundTypeBytes;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleTypeADT[] lastBoundTypeOtypes;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   InputStream[] lastBoundStream;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final int STREAM_MAX_BYTES_SQL = Integer.MAX_VALUE;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxRawBytesSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxRawBytesPlsql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsCharsSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsNCharsSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsBytesPlsql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1092 */   private int maxCharSize = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1098 */   private int maxNCharSize = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1106 */   private int charMaxCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1114 */   private int charMaxNCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1121 */   private int maxVcsCharsPlsql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1128 */   private int maxVcsNCharsPlsql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1134 */   int maxIbtVarcharElementLength = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1142 */   private int maxStreamCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1150 */   private int maxStreamNCharsSql = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1156 */   protected boolean isServerCharSetFixedWidth = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1162 */   private boolean isServerNCharSetFixedWidth = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int minVcsBindSize;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int prematureBatchCount;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1213 */   boolean checkBindTypes = true;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean scrollRsetTypeSolved;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  1233 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */     
/*       */ 
/*  1236 */     this.cacheState = 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*       */     throws SQLException
/*       */   {
/*  1248 */     super(paramPhysicalConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */     
/*       */ 
/*       */ 
/*  1252 */     this.cacheState = 1;
/*       */     
/*  1254 */     if (paramInt1 > 1) {
/*  1255 */       setOracleBatchStyle();
/*       */     }
/*  1257 */     this.theSetCHARBinder = (paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder);
/*       */     
/*       */ 
/*       */ 
/*  1261 */     this.theURowidBinder = (this.theRowidBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1267 */     this.statementType = 1;
/*  1268 */     this.currentRow = -1;
/*  1269 */     this.needToParse = true;
/*       */     
/*  1271 */     this.processEscapes = paramPhysicalConnection.processEscapes;
/*  1272 */     this.sqlObject.initialize(paramString);
/*       */     
/*  1274 */     this.sqlKind = this.sqlObject.getSqlKind();
/*       */     
/*  1276 */     this.clearParameters = true;
/*  1277 */     this.scrollRsetTypeSolved = false;
/*  1278 */     this.prematureBatchCount = 0;
/*       */     
/*  1280 */     initializeBinds();
/*       */     
/*  1282 */     this.minVcsBindSize = paramPhysicalConnection.minVcsBindSize;
/*  1283 */     this.maxRawBytesSql = paramPhysicalConnection.maxRawBytesSql;
/*  1284 */     this.maxRawBytesPlsql = paramPhysicalConnection.maxRawBytesPlsql;
/*  1285 */     this.maxVcsCharsSql = paramPhysicalConnection.maxVcsCharsSql;
/*  1286 */     this.maxVcsNCharsSql = paramPhysicalConnection.maxVcsNCharsSql;
/*  1287 */     this.maxVcsBytesPlsql = paramPhysicalConnection.maxVcsBytesPlsql;
/*  1288 */     this.maxIbtVarcharElementLength = paramPhysicalConnection.maxIbtVarcharElementLength;
/*  1289 */     this.maxCharSize = this.connection.conversion.sMaxCharSize;
/*  1290 */     this.maxNCharSize = this.connection.conversion.maxNCharSize;
/*  1291 */     this.maxVcsCharsPlsql = (this.maxVcsBytesPlsql / this.maxCharSize);
/*  1292 */     this.maxVcsNCharsPlsql = (this.maxVcsBytesPlsql / this.maxNCharSize);
/*  1293 */     this.maxStreamCharsSql = (Integer.MAX_VALUE / this.maxCharSize);
/*  1294 */     this.maxStreamNCharsSql = (this.maxRawBytesSql / this.maxNCharSize);
/*  1295 */     this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth;
/*  1296 */     this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void allocBinds(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  1312 */     int i = paramInt > this.numberOfBindRowsAllocated ? 1 : 0;
/*       */     
/*       */ 
/*       */ 
/*  1316 */     initializeIndicatorSubRange();
/*       */     
/*       */ 
/*       */ 
/*  1320 */     int j = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1327 */     int k = paramInt * this.numberOfBindPositions;
/*       */     
/*       */ 
/*  1330 */     int m = j + 2 * k;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1336 */     if (m > this.totalBindIndicatorLength)
/*       */     {
/*  1338 */       short[] arrayOfShort = this.bindIndicators;
/*  1339 */       i1 = this.bindIndicatorOffset;
/*       */       
/*  1341 */       this.bindIndicatorOffset = 0;
/*  1342 */       this.bindIndicators = new short[m];
/*  1343 */       this.totalBindIndicatorLength = m;
/*       */       
/*  1345 */       if ((arrayOfShort != null) && (i != 0))
/*       */       {
/*       */ 
/*  1348 */         System.arraycopy(arrayOfShort, i1, this.bindIndicators, this.bindIndicatorOffset, j);
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  1353 */     this.bindIndicatorSubRange += this.bindIndicatorOffset;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1360 */     this.bindIndicators[(this.bindIndicatorSubRange + 0)] = ((short)this.numberOfBindPositions);
/*       */     
/*       */ 
/*       */ 
/*  1364 */     this.indicatorsOffset = (this.bindIndicatorOffset + j);
/*  1365 */     this.valueLengthsOffset = (this.indicatorsOffset + k);
/*       */     
/*  1367 */     int n = this.indicatorsOffset;
/*  1368 */     int i1 = this.valueLengthsOffset;
/*  1369 */     int i2 = this.bindIndicatorSubRange + 5;
/*       */     
/*       */ 
/*       */ 
/*  1373 */     for (int i3 = 0; i3 < this.numberOfBindPositions; i3++)
/*       */     {
/*       */ 
/*       */ 
/*  1377 */       this.bindIndicators[(i2 + 5)] = ((short)(n >> 16));
/*       */       
/*       */ 
/*  1380 */       this.bindIndicators[(i2 + 6)] = ((short)(n & 0xFFFF));
/*       */       
/*       */ 
/*  1383 */       this.bindIndicators[(i2 + 7)] = ((short)(i1 >> 16));
/*       */       
/*  1385 */       this.bindIndicators[(i2 + 8)] = ((short)(i1 & 0xFFFF));
/*       */       
/*       */ 
/*       */ 
/*  1389 */       n += paramInt;
/*  1390 */       i1 += paramInt;
/*  1391 */       i2 += 10;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void initializeBinds()
/*       */     throws SQLException
/*       */   {
/*  1411 */     this.numberOfBindPositions = this.sqlObject.getParameterCount();
/*  1412 */     this.numReturnParams = this.sqlObject.getReturnParameterCount();
/*       */     
/*  1414 */     if (this.numberOfBindPositions == 0)
/*       */     {
/*       */ 
/*       */ 
/*  1418 */       this.currentRowNeedToPrepareBinds = false;
/*       */       
/*  1420 */       return;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1426 */     this.numberOfBindRowsAllocated = this.batch;
/*       */     
/*       */ 
/*  1429 */     this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     
/*  1431 */     this.currentRowBinders = this.binders[0];
/*       */     
/*  1433 */     this.currentRowCharLens = new int[this.numberOfBindPositions];
/*  1434 */     this.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/*  1436 */     this.currentRowFormOfUse = new short[this.numberOfBindPositions];
/*  1437 */     this.currentBatchFormOfUse = new short[this.numberOfBindPositions];
/*       */     
/*  1439 */     this.lastBoundClobs = new CLOB[this.numberOfBindPositions];
/*  1440 */     this.lastBoundBlobs = new BLOB[this.numberOfBindPositions];
/*       */     
/*  1442 */     int i = 1;
/*       */     
/*  1444 */     if (this.connection.defaultnchar) {
/*  1445 */       i = 2;
/*       */     }
/*  1447 */     for (int j = 0; j < this.numberOfBindPositions; j++)
/*       */     {
/*  1449 */       this.currentRowFormOfUse[j] = i;
/*  1450 */       this.currentBatchFormOfUse[j] = i;
/*       */     }
/*       */     
/*  1453 */     this.lastBinders = new Binder[this.numberOfBindPositions];
/*  1454 */     this.lastBoundCharLens = new int[this.numberOfBindPositions];
/*  1455 */     this.lastBoundByteOffsets = new int[this.numberOfBindPositions];
/*  1456 */     this.lastBoundCharOffsets = new int[this.numberOfBindPositions];
/*  1457 */     this.lastBoundByteLens = new int[this.numberOfBindPositions];
/*  1458 */     this.lastBoundInds = new short[this.numberOfBindPositions];
/*  1459 */     this.lastBoundLens = new short[this.numberOfBindPositions];
/*       */     
/*  1461 */     this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][];
/*  1462 */     this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions];
/*       */     
/*       */ 
/*  1465 */     allocBinds(this.numberOfBindRowsAllocated);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void growBinds(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  1484 */     Binder[][] arrayOfBinder = this.binders;
/*       */     
/*  1486 */     this.binders = new Binder[paramInt][];
/*       */     
/*       */ 
/*  1489 */     if (arrayOfBinder != null) {
/*  1490 */       System.arraycopy(arrayOfBinder, 0, this.binders, 0, this.numberOfBindRowsAllocated);
/*       */     }
/*       */     
/*       */ 
/*  1494 */     for (int i = this.numberOfBindRowsAllocated; i < paramInt; 
/*  1495 */         i++) {
/*  1496 */       this.binders[i] = new Binder[this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1502 */     allocBinds(paramInt);
/*       */     
/*       */     Object localObject;
/*       */     
/*  1506 */     if (this.parameterInt != null)
/*       */     {
/*  1508 */       localObject = this.parameterInt;
/*       */       
/*  1510 */       this.parameterInt = new int[paramInt][];
/*       */       
/*  1512 */       System.arraycopy(localObject, 0, this.parameterInt, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1515 */       for (i = this.numberOfBindRowsAllocated; 
/*  1516 */           i < paramInt; i++) {
/*  1517 */         this.parameterInt[i] = new int[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1520 */     if (this.parameterLong != null)
/*       */     {
/*  1522 */       localObject = this.parameterLong;
/*       */       
/*  1524 */       this.parameterLong = new long[paramInt][];
/*       */       
/*  1526 */       System.arraycopy(localObject, 0, this.parameterLong, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1529 */       for (i = this.numberOfBindRowsAllocated; 
/*  1530 */           i < paramInt; i++) {
/*  1531 */         this.parameterLong[i] = new long[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1534 */     if (this.parameterFloat != null)
/*       */     {
/*  1536 */       localObject = this.parameterFloat;
/*       */       
/*  1538 */       this.parameterFloat = new float[paramInt][];
/*       */       
/*  1540 */       System.arraycopy(localObject, 0, this.parameterFloat, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1543 */       for (i = this.numberOfBindRowsAllocated; 
/*  1544 */           i < paramInt; i++) {
/*  1545 */         this.parameterFloat[i] = new float[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1548 */     if (this.parameterDouble != null)
/*       */     {
/*  1550 */       localObject = this.parameterDouble;
/*       */       
/*  1552 */       this.parameterDouble = new double[paramInt][];
/*       */       
/*  1554 */       System.arraycopy(localObject, 0, this.parameterDouble, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1557 */       for (i = this.numberOfBindRowsAllocated; 
/*  1558 */           i < paramInt; i++) {
/*  1559 */         this.parameterDouble[i] = new double[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1562 */     if (this.parameterBigDecimal != null)
/*       */     {
/*  1564 */       localObject = this.parameterBigDecimal;
/*       */       
/*  1566 */       this.parameterBigDecimal = new BigDecimal[paramInt][];
/*       */       
/*       */ 
/*  1569 */       System.arraycopy(localObject, 0, this.parameterBigDecimal, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1572 */       for (i = this.numberOfBindRowsAllocated; 
/*  1573 */           i < paramInt; i++) {
/*  1574 */         this.parameterBigDecimal[i] = new BigDecimal[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1577 */     if (this.parameterString != null)
/*       */     {
/*  1579 */       localObject = this.parameterString;
/*       */       
/*  1581 */       this.parameterString = new String[paramInt][];
/*       */       
/*  1583 */       System.arraycopy(localObject, 0, this.parameterString, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1586 */       for (i = this.numberOfBindRowsAllocated; 
/*  1587 */           i < paramInt; i++) {
/*  1588 */         this.parameterString[i] = new String[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1591 */     if (this.parameterDate != null)
/*       */     {
/*  1593 */       localObject = this.parameterDate;
/*       */       
/*  1595 */       this.parameterDate = new Date[paramInt][];
/*       */       
/*  1597 */       System.arraycopy(localObject, 0, this.parameterDate, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1600 */       for (i = this.numberOfBindRowsAllocated; 
/*  1601 */           i < paramInt; i++) {
/*  1602 */         this.parameterDate[i] = new Date[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1605 */     if (this.parameterTime != null)
/*       */     {
/*  1607 */       localObject = this.parameterTime;
/*       */       
/*  1609 */       this.parameterTime = new Time[paramInt][];
/*       */       
/*  1611 */       System.arraycopy(localObject, 0, this.parameterTime, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1614 */       for (i = this.numberOfBindRowsAllocated; 
/*  1615 */           i < paramInt; i++) {
/*  1616 */         this.parameterTime[i] = new Time[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1619 */     if (this.parameterTimestamp != null)
/*       */     {
/*  1621 */       localObject = this.parameterTimestamp;
/*       */       
/*  1623 */       this.parameterTimestamp = new Timestamp[paramInt][];
/*       */       
/*  1625 */       System.arraycopy(localObject, 0, this.parameterTimestamp, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1628 */       for (i = this.numberOfBindRowsAllocated; 
/*  1629 */           i < paramInt; i++) {
/*  1630 */         this.parameterTimestamp[i] = new Timestamp[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1633 */     if (this.parameterDatum != null)
/*       */     {
/*  1635 */       localObject = this.parameterDatum;
/*       */       
/*  1637 */       this.parameterDatum = new byte[paramInt][][];
/*       */       
/*  1639 */       System.arraycopy(localObject, 0, this.parameterDatum, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1642 */       for (i = this.numberOfBindRowsAllocated; 
/*  1643 */           i < paramInt; i++) {
/*  1644 */         this.parameterDatum[i] = new byte[this.numberOfBindPositions][];
/*       */       }
/*       */     }
/*  1647 */     if (this.parameterOtype != null)
/*       */     {
/*  1649 */       localObject = this.parameterOtype;
/*       */       
/*  1651 */       this.parameterOtype = new OracleTypeADT[paramInt][];
/*       */       
/*  1653 */       System.arraycopy(localObject, 0, this.parameterOtype, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1656 */       for (i = this.numberOfBindRowsAllocated; 
/*  1657 */           i < paramInt; i++) {
/*  1658 */         this.parameterOtype[i] = new OracleTypeADT[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1661 */     if (this.parameterStream != null)
/*       */     {
/*  1663 */       localObject = this.parameterStream;
/*       */       
/*  1665 */       this.parameterStream = new InputStream[paramInt][];
/*       */       
/*  1667 */       System.arraycopy(localObject, 0, this.parameterStream, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1670 */       for (i = this.numberOfBindRowsAllocated; 
/*  1671 */           i < paramInt; i++) {
/*  1672 */         this.parameterStream[i] = new InputStream[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1675 */     if (this.userStream != null)
/*       */     {
/*  1677 */       localObject = this.userStream;
/*       */       
/*  1679 */       this.userStream = new Object[paramInt][];
/*       */       
/*  1681 */       System.arraycopy(localObject, 0, this.userStream, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1684 */       for (i = this.numberOfBindRowsAllocated; 
/*  1685 */           i < paramInt; i++) {
/*  1686 */         this.userStream[i] = new Object[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*  1689 */     if (this.parameterPlsqlIbt != null)
/*       */     {
/*  1691 */       localObject = this.parameterPlsqlIbt;
/*       */       
/*  1693 */       this.parameterPlsqlIbt = new PlsqlIbtBindInfo[paramInt][];
/*       */       
/*       */ 
/*  1696 */       System.arraycopy(localObject, 0, this.parameterPlsqlIbt, 0, this.numberOfBindRowsAllocated);
/*       */       
/*       */ 
/*  1699 */       for (i = this.numberOfBindRowsAllocated; 
/*  1700 */           i < paramInt; i++) {
/*  1701 */         this.parameterPlsqlIbt[i] = new PlsqlIbtBindInfo[this.numberOfBindPositions];
/*       */       }
/*       */     }
/*       */     
/*  1705 */     this.numberOfBindRowsAllocated = paramInt;
/*       */     
/*       */ 
/*  1708 */     this.currentRowNeedToPrepareBinds = true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void processCompletedBindRow(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  1782 */     if (this.numberOfBindPositions == 0)
/*       */     {
/*       */ 
/*  1785 */       return;
/*       */     }
/*       */     
/*  1788 */     int j = 0;
/*  1789 */     int k = 0;
/*  1790 */     int m = 0;
/*  1791 */     int n = this.currentRank == this.firstRowInBatch ? 1 : 0;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1798 */     Binder[] arrayOfBinder = this.currentRank == 0 ? this.lastBinders : this.lastBinders[0] == null ? null : this.binders[(this.currentRank - 1)];
/*       */     
/*       */     Object localObject2;
/*       */     Object localObject3;
/*  1802 */     if (this.currentRowBindAccessors == null)
/*       */     {
/*  1804 */       int i1 = (this.isAutoGeneratedKey) && (this.clearParameters) ? 1 : 0;
/*       */       
/*       */ 
/*  1807 */       if (arrayOfBinder == null)
/*       */       {
/*       */ 
/*       */ 
/*  1811 */         for (i = 0; i < this.numberOfBindPositions; i++) {
/*  1812 */           if (this.currentRowBinders[i] == null)
/*       */           {
/*  1814 */             if (i1 != 0)
/*       */             {
/*  1816 */               registerReturnParamsForAutoKey();
/*  1817 */               i1 = 0;
/*       */             }
/*       */             else {
/*  1820 */               localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1821 */               ((SQLException)localObject2).fillInStackTrace();
/*  1822 */               throw ((Throwable)localObject2);
/*       */             } }
/*       */         }
/*       */       }
/*  1826 */       if (this.checkBindTypes)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*  1831 */         localObject2 = this.parameterOtype == null ? null : this.currentRank == 0 ? this.lastBoundTypeOtypes : this.parameterOtype[(this.currentRank - 1)];
/*       */         
/*       */ 
/*       */ 
/*  1835 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  1837 */           if ((this.currentRowBinders[i] == null) && (i1 != 0))
/*       */           {
/*  1839 */             registerReturnParamsForAutoKey();
/*  1840 */             i1 = 0;
/*       */           }
/*  1842 */           localObject3 = this.currentRowBinders[i];
/*       */           
/*  1844 */           if (localObject3 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  1849 */             if (this.clearParameters)
/*       */             {
/*  1851 */               SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1852 */               localSQLException2.fillInStackTrace();
/*  1853 */               throw localSQLException2;
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1862 */             this.currentRowBinders[i] = arrayOfBinder[i].copyingBinder();
/*       */             
/*       */ 
/*  1865 */             if (this.currentRank == 0) {
/*  1866 */               this.currentRowBinders[i].lastBoundValueCleanup(this, i);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1873 */             this.currentRowCharLens[i] = -1;
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1879 */             k = 1;
/*       */           }
/*       */           else
/*       */           {
/*  1883 */             int i6 = ((Binder)localObject3).type;
/*       */             
/*  1885 */             if ((i6 == arrayOfBinder[i].type) && (((i6 != 109) && (i6 != 111)) || (this.parameterOtype[this.currentRank][i].isInHierarchyOf(localObject2[i])))) { if (i6 == 9) { if ((((Binder)localObject3).bytelen == 0 ? 1 : 0) == (arrayOfBinder[i].bytelen == 0 ? 1 : 0)) {}
/*       */               }
/*       */               
/*       */ 
/*       */ 
/*       */ 
/*       */             }
/*       */             else
/*       */             {
/*  1894 */               j = 1;
/*       */             }
/*       */           }
/*  1897 */           if (this.currentBatchFormOfUse[i] != this.currentRowFormOfUse[i])
/*       */           {
/*       */ 
/*       */ 
/*  1901 */             j = 1;
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  1910 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  1912 */           localObject2 = this.currentRowBinders[i];
/*       */           
/*  1914 */           if (localObject2 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  1919 */             if (this.clearParameters)
/*       */             {
/*  1921 */               localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1922 */               ((SQLException)localObject3).fillInStackTrace();
/*  1923 */               throw ((Throwable)localObject3);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1932 */             this.currentRowBinders[i] = arrayOfBinder[i].copyingBinder();
/*       */             
/*       */ 
/*  1935 */             if (this.currentRank == 0) {
/*  1936 */               this.currentRowBinders[i].lastBoundValueCleanup(this, i);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*  1942 */             this.currentRowCharLens[i] = -1;
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1948 */             k = 1;
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*  1953 */       if ((k != 0) && ((n != 0) || (this.m_batchStyle == 2)))
/*       */       {
/*  1955 */         this.lastBoundNeeded = true;
/*       */       }
/*       */     }
/*       */     else
/*       */     {
/*       */       Object localObject1;
/*  1961 */       if (arrayOfBinder == null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  1967 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  1969 */           localObject1 = this.currentRowBinders[i];
/*  1970 */           localObject2 = this.currentRowBindAccessors[i];
/*       */           
/*  1972 */           if (localObject1 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  1977 */             if (localObject2 == null)
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*  1982 */               localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  1983 */               ((SQLException)localObject3).fillInStackTrace();
/*  1984 */               throw ((Throwable)localObject3);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*  1990 */             this.currentRowBinders[i] = this.theOutBinder;
/*       */           }
/*  1992 */           else if ((localObject2 != null) && (((Accessor)localObject2).defineType != ((Binder)localObject1).type))
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2000 */             if ((!this.connection.permitTimestampDateMismatch) || (((Binder)localObject1).type != 180) || (((Accessor)localObject2).defineType != 12))
/*       */             {
/*       */ 
/*       */ 
/*  2004 */               m = 1;
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*  2009 */       if (this.checkBindTypes)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2016 */         localObject1 = this.parameterOtype == null ? null : this.currentRank == 0 ? this.lastBoundTypeOtypes : this.parameterOtype[(this.currentRank - 1)];
/*       */         
/*       */ 
/*       */ 
/*  2020 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2022 */           localObject2 = this.currentRowBinders[i];
/*  2023 */           localObject3 = this.currentRowBindAccessors[i];
/*       */           
/*  2025 */           if (localObject2 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2031 */             if ((this.clearParameters) && (arrayOfBinder[i] != this.theOutBinder))
/*       */             {
/*       */ 
/*  2034 */               SQLException localSQLException3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  2035 */               localSQLException3.fillInStackTrace();
/*  2036 */               throw localSQLException3;
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2047 */             localObject2 = arrayOfBinder[i];
/*  2048 */             this.currentRowBinders[i] = localObject2;
/*  2049 */             this.currentRowCharLens[i] = -1;
/*       */             
/*  2051 */             if (localObject2 != this.theOutBinder)
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2057 */               k = 1;
/*       */             }
/*       */           }
/*       */           else {
/*  2061 */             int i7 = ((Binder)localObject2).type;
/*       */             
/*  2063 */             if ((i7 == arrayOfBinder[i].type) && (((i7 != 109) && (i7 != 111)) || (this.parameterOtype[this.currentRank][i].isInHierarchyOf(localObject1[i])))) { if (i7 == 9) { if ((((Binder)localObject2).bytelen == 0 ? 1 : 0) == (arrayOfBinder[i].bytelen == 0 ? 1 : 0)) {}
/*       */               }
/*       */               
/*       */ 
/*       */ 
/*       */ 
/*       */             }
/*       */             else
/*       */             {
/*  2072 */               j = 1;
/*       */             }
/*       */           }
/*  2075 */           if (this.currentBatchFormOfUse[i] != this.currentRowFormOfUse[i])
/*       */           {
/*       */ 
/*       */ 
/*  2079 */             j = 1;
/*       */           }
/*  2081 */           Accessor localAccessor = this.currentBatchBindAccessors[i];
/*       */           
/*  2083 */           if (localObject3 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2089 */             localObject3 = localAccessor;
/*  2090 */             this.currentRowBindAccessors[i] = localObject3;
/*       */           }
/*  2092 */           else if ((localAccessor != null) && (((Accessor)localObject3).defineType != localAccessor.defineType))
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  2097 */             j = 1;
/*       */           }
/*  2099 */           if ((localObject3 != null) && (localObject2 != this.theOutBinder) && (((Accessor)localObject3).defineType != ((Binder)localObject2).type))
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2108 */             if ((!this.connection.permitTimestampDateMismatch) || (((Binder)localObject2).type != 180) || (((Accessor)localObject3).defineType != 12))
/*       */             {
/*       */ 
/*       */ 
/*  2112 */               m = 1;
/*       */             }
/*       */             
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  2123 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2125 */           localObject1 = this.currentRowBinders[i];
/*       */           
/*  2127 */           if (localObject1 == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2133 */             if ((this.clearParameters) && (arrayOfBinder[i] != this.theOutBinder))
/*       */             {
/*  2135 */               localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i + 1));
/*  2136 */               ((SQLException)localObject2).fillInStackTrace();
/*  2137 */               throw ((Throwable)localObject2);
/*       */             }
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2147 */             localObject1 = arrayOfBinder[i];
/*  2148 */             this.currentRowBinders[i] = localObject1;
/*  2149 */             this.currentRowCharLens[i] = -1;
/*       */             
/*  2151 */             if (localObject1 != this.theOutBinder)
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2157 */               k = 1;
/*       */             }
/*       */           }
/*  2160 */           if (this.currentRowBindAccessors[i] == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  2165 */             this.currentRowBindAccessors[i] = this.currentBatchBindAccessors[i];
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2177 */       if ((k != 0) && (n != 0)) {
/*  2178 */         this.lastBoundNeeded = true;
/*       */       }
/*       */     }
/*  2181 */     if (j != 0)
/*       */     {
/*       */ 
/*       */ 
/*  2185 */       if (n == 0)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2191 */         if (this.m_batchStyle == 2)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2198 */           pushBatch(false);
/*       */ 
/*       */ 
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*       */ 
/*       */ 
/*  2207 */           int i2 = this.validRows;
/*       */           
/*  2209 */           this.prematureBatchCount = sendBatch();
/*  2210 */           this.validRows = i2;
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  2215 */           for (i = 0; i < this.numberOfBindPositions; i++) {
/*  2216 */             this.currentRowBinders[i].lastBoundValueCleanup(this, i);
/*       */           }
/*       */           
/*       */ 
/*  2220 */           if (k != 0) {
/*  2221 */             this.lastBoundNeeded = true;
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*  2227 */       this.needToParse = true;
/*       */       
/*       */ 
/*       */ 
/*  2231 */       this.currentRowNeedToPrepareBinds = true;
/*       */       
/*       */ 
/*  2234 */       this.needToPrepareDefineBuffer = true;
/*       */     }
/*  2236 */     else if (paramBoolean)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2242 */       pushBatch(false);
/*       */       
/*       */ 
/*       */ 
/*  2246 */       this.needToParse = false;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2254 */       this.currentBatchNeedToPrepareBinds = false;
/*       */     }
/*       */     
/*  2257 */     if (m != 0)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2264 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12);
/*  2265 */       localSQLException1.fillInStackTrace();
/*  2266 */       throw localSQLException1;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2278 */     for (int i = 0; i < this.numberOfBindPositions; i++)
/*       */     {
/*  2280 */       int i3 = this.currentRowCharLens[i];
/*       */       
/*  2282 */       if ((i3 == -1) && (this.currentRank == this.firstRowInBatch)) {
/*  2283 */         i3 = this.lastBoundCharLens[i];
/*       */       }
/*  2285 */       if (this.currentBatchCharLens[i] < i3) {
/*  2286 */         this.currentBatchCharLens[i] = i3;
/*       */       }
/*  2288 */       this.currentRowCharLens[i] = 0;
/*  2289 */       this.currentBatchFormOfUse[i] = this.currentRowFormOfUse[i];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2294 */     if (this.currentRowNeedToPrepareBinds) {
/*  2295 */       this.currentBatchNeedToPrepareBinds = true;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2304 */     if (this.currentRowBindAccessors != null)
/*       */     {
/*  2306 */       Accessor[] arrayOfAccessor = this.currentBatchBindAccessors;
/*       */       
/*  2308 */       this.currentBatchBindAccessors = this.currentRowBindAccessors;
/*       */       
/*  2310 */       if (arrayOfAccessor == null) {
/*  2311 */         arrayOfAccessor = new Accessor[this.numberOfBindPositions];
/*       */       } else {
/*  2313 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*  2314 */           arrayOfAccessor[i] = null;
/*       */       }
/*  2316 */       this.currentRowBindAccessors = arrayOfAccessor;
/*       */     }
/*       */     
/*  2319 */     int i4 = this.currentRank + 1;
/*       */     
/*  2321 */     if (i4 < paramInt)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  2326 */       if (i4 >= this.numberOfBindRowsAllocated)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2332 */         int i5 = this.numberOfBindRowsAllocated << 1;
/*       */         
/*  2334 */         if (i5 <= i4) {
/*  2335 */           i5 = i4 + 1;
/*       */         }
/*  2337 */         growBinds(i5);
/*       */         
/*  2339 */         this.currentBatchNeedToPrepareBinds = true;
/*       */         
/*  2341 */         if (this.pushedBatches != null) {
/*  2342 */           this.pushedBatches.current_batch_need_to_prepare_binds = true;
/*       */         }
/*       */       }
/*       */       
/*  2346 */       this.currentRowBinders = this.binders[i4];
/*       */ 
/*       */ 
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*       */ 
/*  2355 */       setupBindBuffers(0, paramInt);
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2362 */       this.currentRowBinders = this.binders[0];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2367 */     this.currentRowNeedToPrepareBinds = false;
/*       */     
/*  2369 */     this.clearParameters = false;
/*       */   }
/*       */   
/*       */ 
/*       */   void processPlsqlIndexTabBinds(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  2376 */     int i = 0;
/*  2377 */     int j = 0;
/*  2378 */     int k = 0;
/*  2379 */     int m = 0;
/*       */     
/*  2381 */     Binder[] arrayOfBinder = this.binders[paramInt];
/*  2382 */     PlsqlIbtBindInfo[] arrayOfPlsqlIbtBindInfo = this.parameterPlsqlIbt == null ? null : this.parameterPlsqlIbt[paramInt];
/*       */     
/*       */     Accessor localAccessor3;
/*       */     
/*  2386 */     for (Accessor localAccessor1 = 0; localAccessor1 < this.numberOfBindPositions; localAccessor1++)
/*       */     {
/*  2388 */       Binder localBinder1 = arrayOfBinder[localAccessor1];
/*  2389 */       localAccessor3 = this.currentBatchBindAccessors == null ? null : this.currentBatchBindAccessors[localAccessor1];
/*       */       
/*  2391 */       PlsqlIndexTableAccessor localPlsqlIndexTableAccessor1 = (localAccessor3 == null) || (localAccessor3.defineType != 998) ? null : (PlsqlIndexTableAccessor)localAccessor3;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2397 */       if (localBinder1.type == 998)
/*       */       {
/*  2399 */         PlsqlIbtBindInfo localPlsqlIbtBindInfo1 = arrayOfPlsqlIbtBindInfo[localAccessor1];
/*       */         
/*  2401 */         if (localPlsqlIndexTableAccessor1 != null)
/*       */         {
/*  2403 */           if (localPlsqlIbtBindInfo1.element_internal_type != localPlsqlIndexTableAccessor1.elementInternalType)
/*       */           {
/*       */ 
/*  2406 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12);
/*  2407 */             localSQLException.fillInStackTrace();
/*  2408 */             throw localSQLException;
/*       */           }
/*       */           
/*  2411 */           if (localPlsqlIbtBindInfo1.maxLen < localPlsqlIndexTableAccessor1.maxNumberOfElements) {
/*  2412 */             localPlsqlIbtBindInfo1.maxLen = localPlsqlIndexTableAccessor1.maxNumberOfElements;
/*       */           }
/*  2414 */           if (localPlsqlIbtBindInfo1.elemMaxLen < localPlsqlIndexTableAccessor1.elementMaxLen) {
/*  2415 */             localPlsqlIbtBindInfo1.elemMaxLen = localPlsqlIndexTableAccessor1.elementMaxLen;
/*       */           }
/*  2417 */           if (localPlsqlIbtBindInfo1.ibtByteLength > 0) {
/*  2418 */             localPlsqlIbtBindInfo1.ibtByteLength = (localPlsqlIbtBindInfo1.elemMaxLen * localPlsqlIbtBindInfo1.maxLen);
/*       */           }
/*       */           else {
/*  2421 */             localPlsqlIbtBindInfo1.ibtCharLength = (localPlsqlIbtBindInfo1.elemMaxLen * localPlsqlIbtBindInfo1.maxLen);
/*       */           }
/*       */         }
/*       */         
/*  2425 */         i++;
/*  2426 */         k += localPlsqlIbtBindInfo1.ibtByteLength;
/*  2427 */         m += localPlsqlIbtBindInfo1.ibtCharLength;
/*  2428 */         j += localPlsqlIbtBindInfo1.maxLen;
/*       */       }
/*  2430 */       else if (localPlsqlIndexTableAccessor1 != null)
/*       */       {
/*  2432 */         i++;
/*  2433 */         k += localPlsqlIndexTableAccessor1.ibtByteLength;
/*  2434 */         m += localPlsqlIndexTableAccessor1.ibtCharLength;
/*  2435 */         j += localPlsqlIndexTableAccessor1.maxNumberOfElements;
/*       */       }
/*       */     }
/*       */     
/*  2439 */     if (i == 0) {
/*  2440 */       return;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2467 */     this.ibtBindIndicatorSize = (6 + i * 8 + j * 2);
/*       */     
/*       */ 
/*  2470 */     this.ibtBindIndicators = new short[this.ibtBindIndicatorSize];
/*  2471 */     this.ibtBindIndicatorOffset = 0;
/*       */     
/*  2473 */     if (k > 0)
/*  2474 */       this.ibtBindBytes = new byte[k];
/*  2475 */     this.ibtBindByteOffset = 0;
/*       */     
/*  2477 */     if (m > 0)
/*  2478 */       this.ibtBindChars = new char[m];
/*  2479 */     this.ibtBindCharOffset = 0;
/*       */     
/*  2481 */     localAccessor1 = this.ibtBindByteOffset;
/*  2482 */     Accessor localAccessor2 = this.ibtBindCharOffset;
/*       */     
/*  2484 */     int n = this.ibtBindIndicatorOffset;
/*  2485 */     int i1 = n + 6 + i * 8;
/*       */     
/*  2487 */     this.ibtBindIndicators[(n++)] = ((short)(i >> 16));
/*  2488 */     this.ibtBindIndicators[(n++)] = ((short)(i & 0xFFFF));
/*       */     
/*  2490 */     this.ibtBindIndicators[(n++)] = ((short)(k >> 16));
/*  2491 */     this.ibtBindIndicators[(n++)] = ((short)(k & 0xFFFF));
/*  2492 */     this.ibtBindIndicators[(n++)] = ((short)(m >> 16));
/*  2493 */     this.ibtBindIndicators[(n++)] = ((short)(m & 0xFFFF));
/*       */     
/*       */ 
/*  2496 */     for (int i2 = 0; i2 < this.numberOfBindPositions; i2++)
/*       */     {
/*  2498 */       Binder localBinder2 = arrayOfBinder[i2];
/*  2499 */       Accessor localAccessor4 = this.currentBatchBindAccessors == null ? null : this.currentBatchBindAccessors[i2];
/*       */       
/*  2501 */       PlsqlIndexTableAccessor localPlsqlIndexTableAccessor2 = (localAccessor4 == null) || (localAccessor4.defineType != 998) ? null : (PlsqlIndexTableAccessor)localAccessor4;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2507 */       if (localBinder2.type == 998)
/*       */       {
/*  2509 */         PlsqlIbtBindInfo localPlsqlIbtBindInfo2 = arrayOfPlsqlIbtBindInfo[i2];
/*  2510 */         int i4 = localPlsqlIbtBindInfo2.maxLen;
/*       */         
/*  2512 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIbtBindInfo2.element_internal_type);
/*       */         
/*  2514 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIbtBindInfo2.elemMaxLen);
/*  2515 */         this.ibtBindIndicators[(n++)] = ((short)(i4 >> 16));
/*  2516 */         this.ibtBindIndicators[(n++)] = ((short)(i4 & 0xFFFF));
/*  2517 */         this.ibtBindIndicators[(n++)] = ((short)(localPlsqlIbtBindInfo2.curLen >> 16));
/*  2518 */         this.ibtBindIndicators[(n++)] = ((short)(localPlsqlIbtBindInfo2.curLen & 0xFFFF));
/*       */         
/*  2520 */         if (localPlsqlIbtBindInfo2.ibtByteLength > 0)
/*       */         {
/*  2522 */           localAccessor3 = localAccessor1;
/*  2523 */           localAccessor1 += localPlsqlIbtBindInfo2.ibtByteLength;
/*       */         }
/*       */         else
/*       */         {
/*  2527 */           localAccessor3 = localAccessor2;
/*  2528 */           localAccessor2 += localPlsqlIbtBindInfo2.ibtCharLength;
/*       */         }
/*       */         
/*  2531 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 >> 16));
/*  2532 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 & 0xFFFF));
/*  2533 */         localPlsqlIbtBindInfo2.ibtValueIndex = localAccessor3;
/*       */         
/*  2535 */         localPlsqlIbtBindInfo2.ibtIndicatorIndex = i1;
/*  2536 */         localPlsqlIbtBindInfo2.ibtLengthIndex = (i1 + i4);
/*       */         
/*  2538 */         if (localPlsqlIndexTableAccessor2 != null)
/*       */         {
/*  2540 */           localPlsqlIndexTableAccessor2.ibtIndicatorIndex = localPlsqlIbtBindInfo2.ibtIndicatorIndex;
/*  2541 */           localPlsqlIndexTableAccessor2.ibtLengthIndex = localPlsqlIbtBindInfo2.ibtLengthIndex;
/*  2542 */           localPlsqlIndexTableAccessor2.ibtMetaIndex = (n - 8);
/*  2543 */           localPlsqlIndexTableAccessor2.ibtValueIndex = localAccessor3;
/*       */         }
/*       */         
/*  2546 */         i1 += 2 * i4;
/*       */       }
/*  2548 */       else if (localPlsqlIndexTableAccessor2 != null)
/*       */       {
/*       */ 
/*  2551 */         int i3 = localPlsqlIndexTableAccessor2.maxNumberOfElements;
/*       */         
/*  2553 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIndexTableAccessor2.elementInternalType);
/*       */         
/*  2555 */         this.ibtBindIndicators[(n++)] = ((short)localPlsqlIndexTableAccessor2.elementMaxLen);
/*  2556 */         this.ibtBindIndicators[(n++)] = ((short)(i3 >> 16));
/*  2557 */         this.ibtBindIndicators[(n++)] = ((short)(i3 & 0xFFFF));
/*  2558 */         this.ibtBindIndicators[(n++)] = 0;
/*  2559 */         this.ibtBindIndicators[(n++)] = 0;
/*       */         
/*  2561 */         if (localPlsqlIndexTableAccessor2.ibtByteLength > 0)
/*       */         {
/*  2563 */           localAccessor3 = localAccessor1;
/*  2564 */           localAccessor1 += localPlsqlIndexTableAccessor2.ibtByteLength;
/*       */         }
/*       */         else
/*       */         {
/*  2568 */           localAccessor3 = localAccessor2;
/*  2569 */           localAccessor2 += localPlsqlIndexTableAccessor2.ibtCharLength;
/*       */         }
/*       */         
/*  2572 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 >> 16));
/*  2573 */         this.ibtBindIndicators[(n++)] = ((short)(localAccessor3 & 0xFFFF));
/*  2574 */         localPlsqlIndexTableAccessor2.ibtValueIndex = localAccessor3;
/*       */         
/*  2576 */         localPlsqlIndexTableAccessor2.ibtIndicatorIndex = i1;
/*  2577 */         localPlsqlIndexTableAccessor2.ibtLengthIndex = (i1 + i3);
/*  2578 */         localPlsqlIndexTableAccessor2.ibtMetaIndex = (n - 8);
/*       */         
/*  2580 */         i1 += 2 * i3;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void initializeBindSubRanges(int paramInt1, int paramInt2)
/*       */   {
/*  2605 */     this.bindByteSubRange = 0;
/*  2606 */     this.bindCharSubRange = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   int calculateIndicatorSubRangeSize()
/*       */   {
/*  2614 */     return 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   short getInoutIndicator(int paramInt)
/*       */   {
/*  2621 */     return 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void initializeIndicatorSubRange()
/*       */   {
/*  2628 */     this.bindIndicatorSubRange = calculateIndicatorSubRangeSize();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void prepareBindPreambles(int paramInt1, int paramInt2) {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setupBindBuffers(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*       */     try
/*       */     {
/*  2691 */       if (this.numberOfBindPositions == 0)
/*       */       {
/*  2693 */         if (paramInt2 != 0)
/*       */         {
/*  2695 */           if (this.bindIndicators == null) { allocBinds(paramInt2);
/*       */           }
/*  2697 */           this.numberOfBoundRows = paramInt2;
/*  2698 */           this.bindIndicators[(this.bindIndicatorSubRange + 3)] = ((short)((this.numberOfBoundRows & 0xFFFF0000) >> 16));
/*       */           
/*       */ 
/*  2701 */           this.bindIndicators[(this.bindIndicatorSubRange + 4)] = ((short)(this.numberOfBoundRows & 0xFFFF));
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*  2706 */         return;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2713 */       this.preparedAllBinds = this.currentBatchNeedToPrepareBinds;
/*  2714 */       this.preparedCharBinds = false;
/*       */       
/*       */ 
/*       */ 
/*  2718 */       this.currentBatchNeedToPrepareBinds = false;
/*       */       
/*       */ 
/*  2721 */       this.numberOfBoundRows = paramInt2;
/*  2722 */       this.bindIndicators[(this.bindIndicatorSubRange + 3)] = ((short)((this.numberOfBoundRows & 0xFFFF0000) >> 16));
/*       */       
/*       */ 
/*  2725 */       this.bindIndicators[(this.bindIndicatorSubRange + 4)] = ((short)(this.numberOfBoundRows & 0xFFFF));
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2733 */       int j = this.bindBufferCapacity;
/*       */       
/*  2735 */       if (this.numberOfBoundRows > this.bindBufferCapacity)
/*       */       {
/*  2737 */         j = this.numberOfBoundRows;
/*  2738 */         this.preparedAllBinds = true;
/*       */       }
/*       */       
/*  2741 */       if (this.currentBatchBindAccessors != null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2748 */         if (this.outBindAccessors == null) {
/*  2749 */           this.outBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */         }
/*  2751 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2753 */           Accessor localAccessor1 = this.currentBatchBindAccessors[i];
/*       */           
/*  2755 */           this.outBindAccessors[i] = localAccessor1;
/*       */           
/*  2757 */           if (localAccessor1 != null)
/*       */           {
/*  2759 */             m = localAccessor1.charLength;
/*       */             
/*  2761 */             if ((m == 0) || (this.currentBatchCharLens[i] < m))
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*  2766 */               this.currentBatchCharLens[i] = m;
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*  2772 */       int k = 0;
/*  2773 */       int m = 0;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2779 */       int n = this.bindIndicatorSubRange + 5;
/*       */       
/*  2781 */       int i1 = n;
/*       */       
/*  2783 */       if (this.preparedAllBinds)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*  2788 */         this.preparedCharBinds = true;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2794 */         Binder[] arrayOfBinder = this.binders[paramInt1];
/*       */         
/*  2796 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2798 */           Binder localBinder = arrayOfBinder[i];
/*       */           
/*       */ 
/*  2801 */           i6 = this.currentBatchCharLens[i];
/*       */           
/*  2803 */           if (localBinder == this.theOutBinder)
/*       */           {
/*  2805 */             Accessor localAccessor2 = this.currentBatchBindAccessors[i];
/*  2806 */             i5 = localAccessor2.byteLength;
/*  2807 */             i4 = (short)localAccessor2.defineType;
/*       */           }
/*       */           else
/*       */           {
/*  2811 */             i5 = localBinder.bytelen;
/*  2812 */             i4 = localBinder.type;
/*       */           }
/*       */           
/*  2815 */           m += i5;
/*  2816 */           k += i6;
/*  2817 */           this.bindIndicators[(i1 + 0)] = i4;
/*  2818 */           this.bindIndicators[(i1 + 1)] = ((short)i5);
/*       */           
/*  2820 */           this.bindIndicators[(i1 + 2)] = ((short)i6);
/*       */           
/*  2822 */           this.bindIndicators[(i1 + 9)] = this.currentBatchFormOfUse[i];
/*       */           
/*  2824 */           i1 += 10;
/*       */         }
/*       */       } else {
/*  2827 */         if (this.preparedCharBinds)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2833 */           for (i = 0; i < this.numberOfBindPositions; i++)
/*       */           {
/*  2835 */             i2 = this.currentBatchCharLens[i];
/*       */             
/*  2837 */             k += i2;
/*  2838 */             this.bindIndicators[(i1 + 2)] = ((short)i2);
/*       */             
/*  2840 */             i1 += 10;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2855 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*  2857 */           i2 = i1 + 2;
/*  2858 */           i3 = this.currentBatchCharLens[i];
/*  2859 */           i4 = this.bindIndicators[i2];
/*  2860 */           i5 = (this.bindIndicators[(i1 + 5)] << 16) + (this.bindIndicators[(i1 + 6)] & 0xFFFF);
/*       */           
/*       */ 
/*  2863 */           i6 = this.bindIndicators[i5] == -1 ? 1 : 0;
/*       */           
/*       */ 
/*       */ 
/*  2867 */           if ((i6 != 0) && (i3 > 1))
/*       */           {
/*  2869 */             this.preparedCharBinds = true;
/*       */           }
/*       */           
/*  2872 */           if ((i4 >= i3) && (!this.preparedCharBinds))
/*       */           {
/*  2874 */             this.currentBatchCharLens[i] = i4;
/*  2875 */             k += i4;
/*       */           }
/*       */           else
/*       */           {
/*  2879 */             this.bindIndicators[i2] = ((short)i3);
/*  2880 */             k += i3;
/*  2881 */             this.preparedCharBinds = true;
/*       */           }
/*       */           
/*  2884 */           i1 += 10;
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2896 */       if (this.preparedCharBinds) {
/*  2897 */         initializeBindSubRanges(this.numberOfBoundRows, j);
/*       */       }
/*  2899 */       if (this.preparedAllBinds)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2905 */         i2 = this.bindByteSubRange + m * j;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*  2910 */         if ((this.lastBoundNeeded) || (i2 > this.totalBindByteLength))
/*       */         {
/*       */ 
/*       */ 
/*  2914 */           this.bindByteOffset = 0;
/*  2915 */           this.bindBytes = this.connection.getByteBuffer(i2);
/*       */           
/*       */ 
/*  2918 */           this.totalBindByteLength = i2;
/*       */         }
/*       */         
/*       */ 
/*  2922 */         this.bindBufferCapacity = j;
/*       */         
/*       */ 
/*  2925 */         this.bindIndicators[(this.bindIndicatorSubRange + 1)] = ((short)((this.bindBufferCapacity & 0xFFFF0000) >> 16));
/*       */         
/*       */ 
/*  2928 */         this.bindIndicators[(this.bindIndicatorSubRange + 2)] = ((short)(this.bindBufferCapacity & 0xFFFF));
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  2934 */       if (this.preparedCharBinds)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2940 */         i2 = this.bindCharSubRange + k * this.bindBufferCapacity;
/*       */         
/*       */ 
/*       */ 
/*  2944 */         if ((this.lastBoundNeeded) || (i2 > this.totalBindCharLength))
/*       */         {
/*       */ 
/*       */ 
/*  2948 */           this.bindCharOffset = 0;
/*  2949 */           this.bindChars = this.connection.getCharBuffer(i2);
/*       */           
/*       */ 
/*  2952 */           this.totalBindCharLength = i2;
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*  2957 */         this.bindByteSubRange += this.bindByteOffset;
/*  2958 */         this.bindCharSubRange += this.bindCharOffset;
/*       */       }
/*       */       
/*       */ 
/*  2962 */       int i2 = this.bindByteSubRange;
/*  2963 */       int i3 = this.bindCharSubRange;
/*  2964 */       int i4 = this.indicatorsOffset;
/*  2965 */       int i5 = this.valueLengthsOffset;
/*       */       
/*  2967 */       i1 = n;
/*       */       
/*  2969 */       if (this.preparedCharBinds)
/*       */       {
/*  2971 */         if (this.currentBatchBindAccessors == null)
/*       */         {
/*       */ 
/*       */ 
/*  2975 */           for (i = 0; i < this.numberOfBindPositions; i++)
/*       */           {
/*       */ 
/*       */ 
/*  2979 */             i6 = this.bindIndicators[(i1 + 1)];
/*       */             
/*  2981 */             i7 = this.currentBatchCharLens[i];
/*       */             
/*  2983 */             i8 = i7 == 0 ? i2 : i3;
/*       */             
/*       */ 
/*  2986 */             this.bindIndicators[(i1 + 3)] = ((short)(i8 >> 16));
/*       */             
/*       */ 
/*  2989 */             this.bindIndicators[(i1 + 4)] = ((short)(i8 & 0xFFFF));
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*  2994 */             i2 += i6 * this.bindBufferCapacity;
/*  2995 */             i3 += i7 * this.bindBufferCapacity;
/*  2996 */             i1 += 10;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3005 */         for (i = 0; i < this.numberOfBindPositions; i++)
/*       */         {
/*       */ 
/*       */ 
/*  3009 */           i6 = this.bindIndicators[(i1 + 1)];
/*       */           
/*  3011 */           i7 = this.currentBatchCharLens[i];
/*       */           
/*  3013 */           i8 = i7 == 0 ? i2 : i3;
/*       */           
/*       */ 
/*  3016 */           this.bindIndicators[(i1 + 3)] = ((short)(i8 >> 16));
/*       */           
/*       */ 
/*  3019 */           this.bindIndicators[(i1 + 4)] = ((short)(i8 & 0xFFFF));
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  3024 */           localObject = this.currentBatchBindAccessors[i];
/*       */           
/*  3026 */           if (localObject != null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/*  3031 */             if (i7 > 0)
/*       */             {
/*  3033 */               ((Accessor)localObject).columnIndex = i3;
/*  3034 */               ((Accessor)localObject).charLength = i7;
/*       */             }
/*       */             else
/*       */             {
/*  3038 */               ((Accessor)localObject).columnIndex = i2;
/*  3039 */               ((Accessor)localObject).byteLength = i6;
/*       */             }
/*       */             
/*  3042 */             ((Accessor)localObject).lengthIndex = i5;
/*  3043 */             ((Accessor)localObject).indicatorIndex = i4;
/*  3044 */             ((Accessor)localObject).rowSpaceByte = this.bindBytes;
/*  3045 */             ((Accessor)localObject).rowSpaceChar = this.bindChars;
/*  3046 */             ((Accessor)localObject).rowSpaceIndicator = this.bindIndicators;
/*       */             
/*  3048 */             if ((((Accessor)localObject).defineType == 109) || (((Accessor)localObject).defineType == 111))
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/*  3053 */               ((Accessor)localObject).setOffsets(this.bindBufferCapacity);
/*       */             }
/*       */           }
/*       */           
/*       */ 
/*  3058 */           i2 += i6 * this.bindBufferCapacity;
/*  3059 */           i3 += i7 * this.bindBufferCapacity;
/*  3060 */           i4 += this.numberOfBindRowsAllocated;
/*  3061 */           i5 += this.numberOfBindRowsAllocated;
/*  3062 */           i1 += 10;
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*  3068 */         i2 = this.bindByteSubRange;
/*  3069 */         i3 = this.bindCharSubRange;
/*  3070 */         i4 = this.indicatorsOffset;
/*  3071 */         i5 = this.valueLengthsOffset;
/*  3072 */         i1 = n;
/*       */       }
/*       */       
/*       */ 
/*  3076 */       int i6 = this.bindBufferCapacity - this.numberOfBoundRows;
/*  3077 */       int i7 = this.numberOfBoundRows - 1;
/*  3078 */       int i8 = i7 + paramInt1;
/*  3079 */       Object localObject = this.binders[i8];
/*       */       
/*  3081 */       if (this.parameterOtype != null)
/*       */       {
/*  3083 */         System.arraycopy(this.parameterDatum[i8], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions);
/*       */         
/*  3085 */         System.arraycopy(this.parameterOtype[i8], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions);
/*       */       }
/*       */       
/*       */ 
/*  3089 */       if (this.hasIbtBind) {
/*  3090 */         processPlsqlIndexTabBinds(paramInt1);
/*       */       }
/*  3092 */       if ((this.numReturnParams > 0) && ((this.returnParamAccessors == null) || (this.returnParamAccessors.length < this.numReturnParams)))
/*       */       {
/*       */ 
/*       */ 
/*  3096 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173);
/*  3097 */         localSQLException2.fillInStackTrace();
/*  3098 */         throw localSQLException2;
/*       */       }
/*       */       
/*  3101 */       if (this.returnParamAccessors != null) { processDmlReturningBind();
/*       */       }
/*  3103 */       boolean bool = (!this.sqlKind.isPlsqlOrCall()) || (this.currentRowBindAccessors == null);
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3113 */       for (int i = 0; i < this.numberOfBindPositions; i++)
/*       */       {
/*       */ 
/*       */ 
/*  3117 */         int i9 = this.bindIndicators[(i1 + 1)];
/*       */         
/*  3119 */         int i10 = this.currentBatchCharLens[i];
/*       */         
/*       */ 
/*  3122 */         this.lastBinders[i] = localObject[i];
/*  3123 */         this.lastBoundByteLens[i] = i9;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3132 */         for (int i11 = 0; i11 < this.numberOfBoundRows; 
/*  3133 */             i11++)
/*       */         {
/*  3135 */           int i12 = paramInt1 + i11;
/*       */           
/*  3137 */           this.binders[i12][i].bind(this, i, i11, i12, this.bindBytes, this.bindChars, this.bindIndicators, i9, i10, i2, i3, i5 + i11, i4 + i11, bool);
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3144 */           this.binders[i12][i] = null;
/*  3145 */           if (this.userStream != null) { this.userStream[i11][i] = null;
/*       */           }
/*  3147 */           i2 += i9;
/*  3148 */           i3 += i10;
/*       */         }
/*       */         
/*       */ 
/*  3152 */         this.lastBoundByteOffsets[i] = (i2 - i9);
/*  3153 */         this.lastBoundCharOffsets[i] = (i3 - i10);
/*  3154 */         this.lastBoundInds[i] = this.bindIndicators[(i4 + i7)];
/*  3155 */         this.lastBoundLens[i] = this.bindIndicators[(i5 + i7)];
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*  3160 */         this.lastBoundCharLens[i] = 0;
/*       */         
/*       */ 
/*  3163 */         i2 += i6 * i9;
/*  3164 */         i3 += i6 * i10;
/*  3165 */         i4 += this.numberOfBindRowsAllocated;
/*  3166 */         i5 += this.numberOfBindRowsAllocated;
/*  3167 */         i1 += 10;
/*       */       }
/*       */       
/*       */ 
/*  3171 */       this.lastBoundBytes = this.bindBytes;
/*  3172 */       this.lastBoundByteOffset = this.bindByteOffset;
/*  3173 */       this.lastBoundChars = this.bindChars;
/*  3174 */       this.lastBoundCharOffset = this.bindCharOffset;
/*  3175 */       if (this.parameterStream != null) {
/*  3176 */         this.lastBoundStream = this.parameterStream[(paramInt1 + this.numberOfBoundRows - 1)];
/*       */       }
/*       */       
/*       */ 
/*  3180 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/*  3182 */       this.currentBatchCharLens = this.lastBoundCharLens;
/*  3183 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/*       */ 
/*  3186 */       this.lastBoundNeeded = false;
/*       */       
/*       */ 
/*       */ 
/*  3190 */       prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity);
/*       */ 
/*       */ 
/*       */     }
/*       */     catch (NullPointerException localNullPointerException)
/*       */     {
/*       */ 
/*  3197 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  3198 */       localSQLException1.fillInStackTrace();
/*  3199 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void releaseBuffers()
/*       */   {
/*  3211 */     this.cachedBindCharSize = (this.bindChars != null ? this.bindChars.length : 0);
/*  3212 */     if (this.bindChars != this.lastBoundChars) this.connection.cacheBuffer(this.lastBoundChars);
/*  3213 */     this.lastBoundChars = null;
/*  3214 */     this.connection.cacheBuffer(this.bindChars);
/*  3215 */     this.bindChars = null;
/*       */     
/*  3217 */     this.cachedBindByteSize = (this.bindBytes != null ? this.bindBytes.length : 0);
/*  3218 */     if (this.bindBytes != this.lastBoundBytes) this.connection.cacheBuffer(this.lastBoundBytes);
/*  3219 */     this.lastBoundBytes = null;
/*  3220 */     this.connection.cacheBuffer(this.bindBytes);
/*  3221 */     this.bindBytes = null;
/*       */     
/*  3223 */     super.releaseBuffers();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void enterImplicitCache()
/*       */     throws SQLException
/*       */   {
/*  3241 */     alwaysOnClose();
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  3246 */     if (!this.connection.isClosed())
/*       */     {
/*  3248 */       cleanAllTempLobs();
/*       */     }
/*       */     
/*  3251 */     if (this.connection.clearStatementMetaData)
/*       */     {
/*  3253 */       this.lastBoundBytes = null;
/*  3254 */       this.lastBoundChars = null;
/*       */     }
/*       */     
/*  3257 */     clearParameters();
/*       */     
/*       */ 
/*       */ 
/*  3261 */     this.cacheState = 2;
/*  3262 */     this.creationState = 1;
/*       */     
/*       */ 
/*       */ 
/*  3266 */     this.currentResultSet = null;
/*  3267 */     this.lastIndex = 0;
/*       */     
/*  3269 */     this.queryTimeout = 0;
/*  3270 */     this.autoRollback = 2;
/*       */     
/*       */ 
/*  3273 */     this.rowPrefetchChanged = false;
/*  3274 */     this.currentRank = 0;
/*  3275 */     this.currentRow = -1;
/*  3276 */     this.validRows = 0;
/*  3277 */     this.maxRows = 0;
/*  3278 */     this.totalRowsVisited = 0;
/*  3279 */     this.maxFieldSize = 0;
/*  3280 */     this.gotLastBatch = false;
/*  3281 */     this.clearParameters = true;
/*  3282 */     this.scrollRset = null;
/*  3283 */     this.defaultFetchDirection = 1000;
/*  3284 */     this.defaultTimeZone = null;
/*  3285 */     this.defaultCalendar = null;
/*  3286 */     this.checkSum = 0L;
/*  3287 */     this.checkSumComputationFailure = false;
/*       */     
/*  3289 */     if (this.sqlKind.isOTHER())
/*       */     {
/*  3291 */       this.needToParse = true;
/*  3292 */       this.needToPrepareDefineBuffer = true;
/*  3293 */       this.columnsDefinedByUser = false;
/*       */     }
/*       */     
/*  3296 */     releaseBuffers();
/*       */     
/*       */ 
/*  3299 */     this.definedColumnType = null;
/*  3300 */     this.definedColumnSize = null;
/*  3301 */     this.definedColumnFormOfUse = null;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  3306 */     if (this.accessors != null)
/*       */     {
/*  3308 */       int i = this.accessors.length;
/*       */       
/*  3310 */       for (int j = 0; j < i; j++)
/*       */       {
/*  3312 */         if (this.accessors[j] != null)
/*       */         {
/*  3314 */           this.accessors[j].rowSpaceByte = null;
/*  3315 */           this.accessors[j].rowSpaceChar = null;
/*  3316 */           this.accessors[j].rowSpaceIndicator = null;
/*  3317 */           if (this.columnsDefinedByUser) {
/*  3318 */             this.accessors[j].externalType = 0;
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  3325 */     this.fixedString = this.connection.getDefaultFixedString();
/*  3326 */     this.defaultRowPrefetch = this.rowPrefetch;
/*  3327 */     this.rowPrefetchInLastFetch = -1;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3333 */     if (this.connection.clearStatementMetaData)
/*       */     {
/*       */ 
/*       */ 
/*  3337 */       this.sqlStringChanged = true;
/*  3338 */       this.needToParse = true;
/*  3339 */       this.needToPrepareDefineBuffer = true;
/*  3340 */       this.columnsDefinedByUser = false;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  3345 */       if (this.userRsetType == 0)
/*       */       {
/*  3347 */         this.userRsetType = 1;
/*  3348 */         this.realRsetType = 1;
/*       */       }
/*  3350 */       this.currentRowNeedToPrepareBinds = true;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void enterExplicitCache()
/*       */     throws SQLException
/*       */   {
/*  3368 */     this.cacheState = 2;
/*  3369 */     this.creationState = 2;
/*  3370 */     this.defaultTimeZone = null;
/*       */     
/*  3372 */     alwaysOnClose();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitImplicitCacheToActive()
/*       */     throws SQLException
/*       */   {
/*  3387 */     this.cacheState = 1;
/*  3388 */     this.closed = false;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3395 */     if (this.rowPrefetch != this.connection.getDefaultRowPrefetch())
/*       */     {
/*  3397 */       if (this.streamList == null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3405 */         this.rowPrefetch = this.connection.getDefaultRowPrefetch();
/*  3406 */         this.defaultRowPrefetch = this.rowPrefetch;
/*       */         
/*       */ 
/*  3409 */         this.rowPrefetchChanged = true;
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3418 */     if (this.batch != this.connection.getDefaultExecuteBatch())
/*       */     {
/*  3420 */       resetBatch();
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3428 */     this.processEscapes = this.connection.processEscapes;
/*       */     
/*  3430 */     if (this.cachedDefineIndicatorSize != 0)
/*       */     {
/*  3432 */       this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
/*  3433 */       this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
/*  3434 */       this.defineIndicators = new short[this.cachedDefineIndicatorSize];
/*  3435 */       if (this.accessors != null)
/*       */       {
/*  3437 */         int i = this.accessors.length;
/*       */         
/*  3439 */         for (int j = 0; j < i; j++)
/*       */         {
/*  3441 */           if (this.accessors[j] != null)
/*       */           {
/*  3443 */             this.accessors[j].rowSpaceByte = this.defineBytes;
/*  3444 */             this.accessors[j].rowSpaceChar = this.defineChars;
/*  3445 */             this.accessors[j].rowSpaceIndicator = this.defineIndicators;
/*       */           }
/*       */         }
/*  3448 */         doInitializationAfterDefineBufferRestore();
/*       */       }
/*       */     }
/*       */     
/*  3452 */     if ((this.cachedBindCharSize != 0) || (this.cachedBindByteSize != 0))
/*       */     {
/*  3454 */       if (this.cachedBindByteSize > 0)
/*  3455 */         this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);
/*  3456 */       if (this.cachedBindCharSize > 0)
/*  3457 */         this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);
/*  3458 */       doLocalInitialization();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doLocalInitialization() {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doInitializationAfterDefineBufferRestore() {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitExplicitCacheToActive()
/*       */     throws SQLException
/*       */   {
/*  3490 */     this.cacheState = 1;
/*  3491 */     this.closed = false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitImplicitCacheToClose()
/*       */     throws SQLException
/*       */   {
/*  3506 */     this.cacheState = 0;
/*  3507 */     this.closed = false;
/*       */     
/*  3509 */     synchronized (this.connection) {
/*  3510 */       hardClose();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void exitExplicitCacheToClose()
/*       */     throws SQLException
/*       */   {
/*  3526 */     this.cacheState = 0;
/*  3527 */     this.closed = false;
/*       */     
/*  3529 */     synchronized (this.connection) {
/*  3530 */       hardClose();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void closeWithKey(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3546 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3551 */       closeOrCache(paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   int executeInternal()
/*       */     throws SQLException
/*       */   {
/*  3559 */     this.noMoreUpdateCounts = false;
/*  3560 */     this.checkSum = 0L;
/*  3561 */     this.checkSumComputationFailure = false;
/*       */     
/*  3563 */     ensureOpen();
/*       */     
/*       */ 
/*  3566 */     if ((this.currentRank > 0) && (this.m_batchStyle == 2))
/*       */     {
/*       */ 
/*  3569 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/*  3570 */       localSQLException.fillInStackTrace();
/*  3571 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  3575 */     int i = this.userRsetType == 1 ? 1 : 0;
/*       */     
/*  3577 */     prepareForNewResults(true, false);
/*       */     
/*  3579 */     processCompletedBindRow(this.sqlKind.isSELECT() ? 1 : this.batch, false);
/*       */     
/*  3581 */     if ((i == 0) && (!this.scrollRsetTypeSolved)) {
/*  3582 */       return doScrollPstmtExecuteUpdate() + this.prematureBatchCount;
/*       */     }
/*  3584 */     doExecuteWithTimeout();
/*       */     
/*  3586 */     int j = (this.prematureBatchCount != 0) && (this.validRows > 0) ? 1 : 0;
/*       */     
/*  3588 */     if (i == 0)
/*       */     {
/*  3590 */       this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*  3591 */       this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
/*       */       
/*       */ 
/*       */ 
/*  3595 */       if (!this.connection.accumulateBatchResult) {
/*  3596 */         j = 0;
/*       */       }
/*       */     }
/*  3599 */     if (j != 0)
/*       */     {
/*       */ 
/*  3602 */       this.validRows += this.prematureBatchCount;
/*  3603 */       this.prematureBatchCount = 0;
/*       */     }
/*  3605 */     if (this.sqlKind.isOTHER()) this.needToParse = true;
/*  3606 */     return this.validRows;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public ResultSet executeQuery()
/*       */     throws SQLException
/*       */   {
/*  3620 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3626 */       this.executionType = 1;
/*       */       
/*  3628 */       executeInternal();
/*       */       
/*  3630 */       if (this.userRsetType == 1)
/*       */       {
/*  3632 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*       */         
/*  3634 */         return this.currentResultSet;
/*       */       }
/*       */       
/*       */ 
/*  3638 */       if (this.scrollRset == null)
/*       */       {
/*  3640 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*  3641 */         this.scrollRset = this.currentResultSet;
/*       */       }
/*       */       
/*  3644 */       return this.scrollRset;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int executeUpdate()
/*       */     throws SQLException
/*       */   {
/*  3658 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3663 */       this.executionType = 2;
/*       */       
/*  3665 */       return executeInternal();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean execute()
/*       */     throws SQLException
/*       */   {
/*  3678 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3683 */       this.executionType = 3;
/*       */       
/*  3685 */       executeInternal();
/*       */       
/*  3687 */       return this.sqlKind.isSELECT();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void slideDownCurrentRow(int paramInt)
/*       */   {
/*  3705 */     if (this.binders != null)
/*       */     {
/*  3707 */       this.binders[paramInt] = this.binders[0];
/*  3708 */       this.binders[0] = this.currentRowBinders;
/*       */     }
/*       */     
/*       */     Object localObject;
/*  3712 */     if (this.parameterInt != null)
/*       */     {
/*  3714 */       localObject = this.parameterInt[0];
/*       */       
/*  3716 */       this.parameterInt[0] = this.parameterInt[paramInt];
/*  3717 */       this.parameterInt[paramInt] = localObject;
/*       */     }
/*       */     
/*  3720 */     if (this.parameterLong != null)
/*       */     {
/*  3722 */       localObject = this.parameterLong[0];
/*       */       
/*  3724 */       this.parameterLong[0] = this.parameterLong[paramInt];
/*  3725 */       this.parameterLong[paramInt] = localObject;
/*       */     }
/*       */     
/*  3728 */     if (this.parameterFloat != null)
/*       */     {
/*  3730 */       localObject = this.parameterFloat[0];
/*       */       
/*  3732 */       this.parameterFloat[0] = this.parameterFloat[paramInt];
/*  3733 */       this.parameterFloat[paramInt] = localObject;
/*       */     }
/*       */     
/*  3736 */     if (this.parameterDouble != null)
/*       */     {
/*  3738 */       localObject = this.parameterDouble[0];
/*       */       
/*  3740 */       this.parameterDouble[0] = this.parameterDouble[paramInt];
/*  3741 */       this.parameterDouble[paramInt] = localObject;
/*       */     }
/*       */     
/*  3744 */     if (this.parameterBigDecimal != null)
/*       */     {
/*  3746 */       localObject = this.parameterBigDecimal[0];
/*       */       
/*  3748 */       this.parameterBigDecimal[0] = this.parameterBigDecimal[paramInt];
/*  3749 */       this.parameterBigDecimal[paramInt] = localObject;
/*       */     }
/*       */     
/*  3752 */     if (this.parameterString != null)
/*       */     {
/*  3754 */       localObject = this.parameterString[0];
/*       */       
/*  3756 */       this.parameterString[0] = this.parameterString[paramInt];
/*  3757 */       this.parameterString[paramInt] = localObject;
/*       */     }
/*       */     
/*  3760 */     if (this.parameterDate != null)
/*       */     {
/*  3762 */       localObject = this.parameterDate[0];
/*       */       
/*  3764 */       this.parameterDate[0] = this.parameterDate[paramInt];
/*  3765 */       this.parameterDate[paramInt] = localObject;
/*       */     }
/*       */     
/*  3768 */     if (this.parameterTime != null)
/*       */     {
/*  3770 */       localObject = this.parameterTime[0];
/*       */       
/*  3772 */       this.parameterTime[0] = this.parameterTime[paramInt];
/*  3773 */       this.parameterTime[paramInt] = localObject;
/*       */     }
/*       */     
/*  3776 */     if (this.parameterTimestamp != null)
/*       */     {
/*  3778 */       localObject = this.parameterTimestamp[0];
/*       */       
/*  3780 */       this.parameterTimestamp[0] = this.parameterTimestamp[paramInt];
/*  3781 */       this.parameterTimestamp[paramInt] = localObject;
/*       */     }
/*       */     
/*  3784 */     if (this.parameterDatum != null)
/*       */     {
/*  3786 */       localObject = this.parameterDatum[0];
/*       */       
/*  3788 */       this.parameterDatum[0] = this.parameterDatum[paramInt];
/*  3789 */       this.parameterDatum[paramInt] = localObject;
/*       */     }
/*       */     
/*  3792 */     if (this.parameterOtype != null)
/*       */     {
/*  3794 */       localObject = this.parameterOtype[0];
/*       */       
/*  3796 */       this.parameterOtype[0] = this.parameterOtype[paramInt];
/*  3797 */       this.parameterOtype[paramInt] = localObject;
/*       */     }
/*       */     
/*  3800 */     if (this.parameterStream != null)
/*       */     {
/*  3802 */       localObject = this.parameterStream[0];
/*       */       
/*  3804 */       this.parameterStream[0] = this.parameterStream[paramInt];
/*  3805 */       this.parameterStream[paramInt] = localObject;
/*       */     }
/*       */     
/*  3808 */     if (this.userStream != null)
/*       */     {
/*  3810 */       localObject = this.userStream[0];
/*       */       
/*  3812 */       this.userStream[0] = this.userStream[paramInt];
/*  3813 */       this.userStream[paramInt] = localObject;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void resetBatch()
/*       */   {
/*  3821 */     this.batch = this.connection.getDefaultExecuteBatch();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int sendBatch()
/*       */     throws SQLException
/*       */   {
/*  3851 */     if (isJdbcBatchStyle())
/*       */     {
/*  3853 */       return 0;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  3858 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       try
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3870 */         ensureOpen();
/*       */         
/*       */ 
/*       */ 
/*  3874 */         if (this.currentRank <= 0) {
/*  3875 */           i = this.connection.accumulateBatchResult ? 0 : this.validRows;
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3925 */           this.currentRank = 0;return i;
/*       */         }
/*  3883 */         int i = this.batch;
/*       */         
/*       */         try
/*       */         {
/*  3887 */           j = this.currentRank;
/*       */           
/*  3889 */           if (this.batch != this.currentRank) {
/*  3890 */             this.batch = this.currentRank;
/*       */           }
/*  3892 */           setupBindBuffers(0, this.currentRank);
/*       */           
/*  3894 */           this.currentRank -= 1;
/*       */           
/*  3896 */           doExecuteWithTimeout();
/*       */           
/*       */ 
/*       */ 
/*  3900 */           slideDownCurrentRow(j);
/*       */ 
/*       */         }
/*       */         finally
/*       */         {
/*  3905 */           if (this.batch != i) {
/*  3906 */             this.batch = i;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*  3911 */         if (this.connection.accumulateBatchResult)
/*       */         {
/*       */ 
/*  3914 */           this.validRows += this.prematureBatchCount;
/*  3915 */           this.prematureBatchCount = 0;
/*       */         }
/*       */         
/*  3918 */         int j = this.validRows;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3925 */         this.currentRank = 0;return j; } finally { this.currentRank = 0;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setExecuteBatch(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  3966 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  3969 */       setOracleBatchStyle();
/*  3970 */       set_execute_batch(paramInt);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void set_execute_batch(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  3981 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  3984 */       if (paramInt <= 0)
/*       */       {
/*  3986 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  3987 */         localSQLException.fillInStackTrace();
/*  3988 */         throw localSQLException;
/*       */       }
/*       */       
/*  3991 */       if (paramInt == this.batch) {
/*  3992 */         return;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  3998 */       if (this.currentRank > 0)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*  4003 */         i = this.validRows;
/*       */         
/*  4005 */         this.prematureBatchCount = sendBatch();
/*  4006 */         this.validRows = i;
/*       */       }
/*       */       
/*  4009 */       int i = this.batch;
/*       */       
/*  4011 */       this.batch = paramInt;
/*       */       
/*  4013 */       if (this.numberOfBindRowsAllocated < this.batch) {
/*  4014 */         growBinds(this.batch);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public final int getExecuteBatch()
/*       */   {
/*  4028 */     return this.batch;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  4060 */     synchronized (this.connection)
/*       */     {
/*       */       SQLException localSQLException;
/*  4063 */       if (paramInt3 < 0)
/*       */       {
/*  4065 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  4066 */         localSQLException.fillInStackTrace();
/*  4067 */         throw localSQLException;
/*       */       }
/*       */       
/*  4070 */       if (paramInt1 < 1)
/*       */       {
/*  4072 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4073 */         localSQLException.fillInStackTrace();
/*  4074 */         throw localSQLException;
/*       */       }
/*       */       
/*  4077 */       switch (paramInt2)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       case -7: 
/*       */       case -6: 
/*       */       case -5: 
/*       */       case 2: 
/*       */       case 3: 
/*       */       case 4: 
/*       */       case 5: 
/*       */       case 6: 
/*       */       case 7: 
/*       */       case 8: 
/*  4102 */         paramInt2 = 6;
/*       */         
/*  4104 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 1: 
/*  4109 */         paramInt2 = 96;
/*       */         
/*  4111 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 12: 
/*  4116 */         paramInt2 = 1;
/*       */         
/*  4118 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       case 91: 
/*       */       case 92: 
/*  4125 */         paramInt2 = 12;
/*       */         
/*  4127 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -103: 
/*  4132 */         paramInt2 = 182;
/*       */         
/*  4134 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -104: 
/*  4139 */         paramInt2 = 183;
/*       */         
/*  4141 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       case -100: 
/*       */       case 93: 
/*  4148 */         paramInt2 = 180;
/*       */         
/*  4150 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -101: 
/*  4155 */         paramInt2 = 181;
/*       */         
/*  4157 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -102: 
/*  4162 */         paramInt2 = 231;
/*       */         
/*  4164 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       case -3: 
/*       */       case -2: 
/*  4171 */         paramInt2 = 23;
/*       */         
/*  4173 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 100: 
/*  4178 */         paramInt2 = 100;
/*       */         
/*  4180 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 101: 
/*  4185 */         paramInt2 = 101;
/*       */         
/*  4187 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -8: 
/*  4192 */         paramInt2 = 104;
/*       */         
/*  4194 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 2004: 
/*  4199 */         paramInt2 = 113;
/*       */         
/*  4201 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 2005: 
/*  4206 */         paramInt2 = 112;
/*       */         
/*  4208 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -13: 
/*  4213 */         paramInt2 = 114;
/*       */         
/*  4215 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case -10: 
/*  4220 */         paramInt2 = 102;
/*       */         
/*  4222 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 0: 
/*  4227 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  4228 */         localSQLException.fillInStackTrace();
/*  4229 */         throw localSQLException;
/*       */       
/*       */ 
/*       */ 
/*       */       default: 
/*  4234 */         localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4235 */         localSQLException.fillInStackTrace();
/*  4236 */         throw localSQLException;
/*       */       }
/*       */       
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  4274 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  4279 */       int i = this.connection.getNlsRatio();
/*       */       
/*  4281 */       if ((paramInt2 == 1) || (paramInt2 == 12)) {
/*  4282 */         defineParameterTypeBytes(paramInt1, paramInt2, paramInt3 * i);
/*       */       } else {
/*  4284 */         defineParameterTypeBytes(paramInt1, paramInt2, paramInt3);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  4298 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*  4302 */       defineParameterTypeBytes(paramInt1, paramInt2, paramInt3);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public ResultSetMetaData getMetaData()
/*       */     throws SQLException
/*       */   {
/*  4319 */     if (this.sqlObject.getSqlKind().isSELECT()) {
/*  4320 */       return new OracleResultSetMetaData(this.connection, this);
/*       */     }
/*  4322 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNull(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  4361 */     setNullInternal(paramInt1, paramInt2, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNullInternal(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  4369 */     int i = paramInt1 - 1;
/*       */     
/*  4371 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  4373 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4374 */       localSQLException.fillInStackTrace();
/*  4375 */       throw localSQLException;
/*       */     }
/*       */     
/*  4378 */     if ((paramInt2 == 2002) || (paramInt2 == 2008) || (paramInt2 == 2003) || (paramInt2 == 2007) || (paramInt2 == 2009) || (paramInt2 == 2006))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  4389 */       synchronized (this.connection) {
/*  4390 */         setNullCritical(i, paramInt2, paramString);
/*       */         
/*  4392 */         this.currentRowCharLens[i] = 0;
/*       */       }
/*       */       
/*       */     }
/*       */     else
/*       */     {
/*  4398 */       setNullInternal(paramInt1, paramInt2);
/*       */       
/*  4400 */       return;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNullInternal(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4408 */     synchronized (this.connection)
/*       */     {
/*  4410 */       setNullCritical(paramInt1, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNullCritical(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  4419 */     Object localObject1 = null;
/*  4420 */     Binder localBinder = this.theNamedTypeNullBinder;
/*       */     Object localObject2;
/*  4422 */     switch (paramInt2)
/*       */     {
/*       */ 
/*       */     case 2006: 
/*  4426 */       localBinder = this.theRefTypeNullBinder;
/*       */     
/*       */ 
/*       */ 
/*       */     case 2002: 
/*       */     case 2008: 
/*  4432 */       localObject2 = StructDescriptor.createDescriptor(paramString, this.connection);
/*       */       
/*       */ 
/*  4435 */       localObject1 = ((StructDescriptor)localObject2).getOracleTypeADT();
/*       */       
/*  4437 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */     case 2003: 
/*  4442 */       localObject2 = ArrayDescriptor.createDescriptor(paramString, this.connection);
/*       */       
/*       */ 
/*  4445 */       localObject1 = ((ArrayDescriptor)localObject2).getOracleTypeCOLLECTION();
/*       */       
/*  4447 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2007: 
/*       */     case 2009: 
/*  4457 */       localObject2 = OpaqueDescriptor.createDescriptor(paramString, this.connection);
/*       */       
/*       */ 
/*  4460 */       localObject1 = (OracleTypeADT)((OpaqueDescriptor)localObject2).getPickler();
/*       */       
/*  4462 */       break;
/*       */     }
/*       */     
/*       */     
/*  4466 */     this.currentRowBinders[paramInt1] = localBinder;
/*       */     
/*  4468 */     if (this.parameterDatum == null) {
/*  4469 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  4474 */     this.parameterDatum[this.currentRank][paramInt1] = null;
/*       */     
/*  4476 */     if (localObject1 != null) {
/*  4477 */       ((OracleTypeADT)localObject1).getTOID();
/*       */     }
/*  4479 */     if (this.parameterOtype == null) {
/*  4480 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*  4483 */     this.parameterOtype[this.currentRank][paramInt1] = localObject1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNullAtName(String paramString1, int paramInt, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  4502 */     String str = paramString1.intern();
/*  4503 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  4504 */     int i = 0;
/*  4505 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  4507 */     for (int k = 0; k < j; k++) {
/*  4508 */       if (arrayOfString[k] == str)
/*       */       {
/*  4510 */         setNullInternal(k + 1, paramInt, paramString2);
/*       */         
/*  4512 */         i = 1;
/*       */       }
/*       */     }
/*  4515 */     if (i == 0)
/*       */     {
/*  4517 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/*  4518 */       localSQLException.fillInStackTrace();
/*  4519 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNull(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4538 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4541 */       setNullCritical(paramInt1, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNullCritical(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4549 */     int i = paramInt1 - 1;
/*       */     
/*  4551 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  4553 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4554 */       ((SQLException)localObject).fillInStackTrace();
/*  4555 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  4558 */     Object localObject = null;
/*  4559 */     int j = getInternalType(paramInt2);
/*       */     SQLException localSQLException;
/*  4561 */     switch (j)
/*       */     {
/*       */ 
/*       */     case 6: 
/*  4565 */       localObject = this.theVarnumNullBinder;
/*       */       
/*  4567 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 1: 
/*       */     case 8: 
/*       */     case 96: 
/*       */     case 995: 
/*  4576 */       localObject = this.theVarcharNullBinder;
/*  4577 */       this.currentRowCharLens[i] = 1;
/*       */       
/*  4579 */       break;
/*       */     
/*       */     case 999: 
/*  4582 */       localObject = this.theFixedCHARNullBinder;
/*       */       
/*  4584 */       break;
/*       */     
/*       */     case 12: 
/*  4587 */       localObject = this.theDateNullBinder;
/*       */       
/*  4589 */       break;
/*       */     
/*       */ 
/*       */     case 180: 
/*  4593 */       localObject = this.theTimestampNullBinder;
/*       */       
/*  4595 */       break;
/*       */     
/*       */     case 181: 
/*  4598 */       localObject = this.theTSTZNullBinder;
/*       */       
/*  4600 */       break;
/*       */     
/*       */     case 231: 
/*  4603 */       localObject = this.theTSLTZNullBinder;
/*       */       
/*  4605 */       break;
/*       */     
/*       */     case 104: 
/*  4608 */       localObject = getRowidNullBinder(i);
/*       */       
/*  4610 */       break;
/*       */     
/*       */     case 183: 
/*  4613 */       localObject = this.theIntervalDSNullBinder;
/*       */       
/*  4615 */       break;
/*       */     
/*       */     case 182: 
/*  4618 */       localObject = this.theIntervalYMNullBinder;
/*       */       
/*  4620 */       break;
/*       */     
/*       */ 
/*       */     case 23: 
/*       */     case 24: 
/*  4625 */       localObject = this.theRawNullBinder;
/*       */       
/*  4627 */       break;
/*       */     
/*       */     case 100: 
/*  4630 */       localObject = this.theBinaryFloatNullBinder;
/*       */       
/*  4632 */       break;
/*       */     
/*       */     case 101: 
/*  4635 */       localObject = this.theBinaryDoubleNullBinder;
/*       */       
/*  4637 */       break;
/*       */     
/*       */     case 113: 
/*  4640 */       localObject = this.theBlobNullBinder;
/*       */       
/*  4642 */       break;
/*       */     
/*       */     case 112: 
/*  4645 */       localObject = this.theClobNullBinder;
/*       */       
/*  4647 */       break;
/*       */     
/*       */     case 114: 
/*  4650 */       localObject = this.theBfileNullBinder;
/*       */       
/*  4652 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */     case 109: 
/*       */     case 111: 
/*  4658 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "sqlType=" + paramInt2);
/*  4659 */       localSQLException.fillInStackTrace();
/*  4660 */       throw localSQLException;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 102: 
/*       */     case 998: 
/*       */     default: 
/*  4671 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "sqlType=" + paramInt2);
/*  4672 */       localSQLException.fillInStackTrace();
/*  4673 */       throw localSQLException;
/*       */     }
/*       */     
/*       */     
/*  4677 */     this.currentRowBinders[i] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   Binder getRowidNullBinder(int paramInt)
/*       */   {
/*  4684 */     return this.theRowidNullBinder;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNullAtName(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4700 */     String str = paramString.intern();
/*  4701 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  4702 */     int i = 0;
/*  4703 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  4705 */     for (int k = 0; k < j; k++) {
/*  4706 */       if (arrayOfString[k] == str)
/*       */       {
/*  4708 */         setNull(k + 1, paramInt);
/*       */         
/*  4710 */         i = 1;
/*       */       }
/*       */     }
/*  4713 */     if (i == 0)
/*       */     {
/*  4715 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  4716 */       localSQLException.fillInStackTrace();
/*  4717 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBoolean(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4733 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4736 */       setBooleanInternal(paramInt, paramBoolean);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBooleanInternal(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4744 */     int i = paramInt - 1;
/*       */     
/*  4746 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4748 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4749 */       localSQLException.fillInStackTrace();
/*  4750 */       throw localSQLException;
/*       */     }
/*       */     
/*  4753 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4755 */     this.currentRowBinders[i] = this.theBooleanBinder;
/*       */     
/*  4757 */     if (this.parameterInt == null) {
/*  4758 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4762 */     this.parameterInt[this.currentRank][i] = (paramBoolean ? 1 : 0);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setByte(int paramInt, byte paramByte)
/*       */     throws SQLException
/*       */   {
/*  4775 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4778 */       setByteInternal(paramInt, paramByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setByteInternal(int paramInt, byte paramByte)
/*       */     throws SQLException
/*       */   {
/*  4786 */     int i = paramInt - 1;
/*       */     
/*  4788 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4790 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4791 */       localSQLException.fillInStackTrace();
/*  4792 */       throw localSQLException;
/*       */     }
/*       */     
/*  4795 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4797 */     this.currentRowBinders[i] = this.theByteBinder;
/*       */     
/*  4799 */     if (this.parameterInt == null) {
/*  4800 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4804 */     this.parameterInt[this.currentRank][i] = paramByte;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setShort(int paramInt, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  4818 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4821 */       setShortInternal(paramInt, paramShort);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setShortInternal(int paramInt, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  4829 */     int i = paramInt - 1;
/*       */     
/*  4831 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4833 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4834 */       localSQLException.fillInStackTrace();
/*  4835 */       throw localSQLException;
/*       */     }
/*       */     
/*  4838 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4840 */     this.currentRowBinders[i] = this.theShortBinder;
/*       */     
/*  4842 */     if (this.parameterInt == null) {
/*  4843 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4847 */     this.parameterInt[this.currentRank][i] = paramShort;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setInt(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4861 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4864 */       setIntInternal(paramInt1, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setIntInternal(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  4872 */     int i = paramInt1 - 1;
/*       */     
/*  4874 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  4876 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4877 */       localSQLException.fillInStackTrace();
/*  4878 */       throw localSQLException;
/*       */     }
/*       */     
/*  4881 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4883 */     this.currentRowBinders[i] = this.theIntBinder;
/*       */     
/*  4885 */     if (this.parameterInt == null) {
/*  4886 */       this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  4890 */     this.parameterInt[this.currentRank][i] = paramInt2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setLong(int paramInt, long paramLong)
/*       */     throws SQLException
/*       */   {
/*  4903 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4906 */       setLongInternal(paramInt, paramLong);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setLongInternal(int paramInt, long paramLong)
/*       */     throws SQLException
/*       */   {
/*  4914 */     int i = paramInt - 1;
/*       */     
/*  4916 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4918 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4919 */       localSQLException.fillInStackTrace();
/*  4920 */       throw localSQLException;
/*       */     }
/*       */     
/*  4923 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4925 */     this.currentRowBinders[i] = this.theLongBinder;
/*       */     
/*  4927 */     if (this.parameterLong == null) {
/*  4928 */       this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  4933 */     this.parameterLong[this.currentRank][i] = paramLong;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFloat(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  4947 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  4950 */       setFloatInternal(paramInt, paramFloat);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setFloatInternal(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  4958 */     int i = paramInt - 1;
/*       */     
/*  4960 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  4962 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  4963 */       localSQLException.fillInStackTrace();
/*  4964 */       throw localSQLException;
/*       */     }
/*       */     
/*  4967 */     if (this.theFloatBinder == null)
/*       */     {
/*  4969 */       this.theFloatBinder = theStaticFloatBinder;
/*  4970 */       if (this.connection.setFloatAndDoubleUseBinary) {
/*  4971 */         this.theFloatBinder = theStaticBinaryFloatBinder;
/*       */       }
/*       */     }
/*  4974 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  4976 */     this.currentRowBinders[i] = this.theFloatBinder;
/*       */     
/*  4978 */     if (this.theFloatBinder == theStaticFloatBinder)
/*       */     {
/*  4980 */       if (this.parameterDouble == null) {
/*  4981 */         this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  4986 */       this.parameterDouble[this.currentRank][i] = paramFloat;
/*       */     }
/*       */     else
/*       */     {
/*  4990 */       if (this.parameterFloat == null) {
/*  4991 */         this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  4996 */       this.parameterFloat[this.currentRank][i] = paramFloat;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryFloat(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  5012 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5015 */       setBinaryFloatInternal(paramInt, paramFloat);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBinaryFloatInternal(int paramInt, float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  5023 */     int i = paramInt - 1;
/*       */     
/*  5025 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5027 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5028 */       localSQLException.fillInStackTrace();
/*  5029 */       throw localSQLException;
/*       */     }
/*       */     
/*  5032 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  5034 */     this.currentRowBinders[i] = this.theBinaryFloatBinder;
/*       */     
/*  5036 */     if (this.parameterFloat == null) {
/*  5037 */       this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5042 */     this.parameterFloat[this.currentRank][i] = paramFloat;
/*       */   }
/*       */   
/*       */ 
/*       */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT)
/*       */     throws SQLException
/*       */   {
/*  5049 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5052 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryFloatInternal(int paramInt, BINARY_FLOAT paramBINARY_FLOAT)
/*       */     throws SQLException
/*       */   {
/*  5061 */     int i = paramInt - 1;
/*       */     
/*  5063 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5065 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5066 */       localSQLException.fillInStackTrace();
/*  5067 */       throw localSQLException;
/*       */     }
/*       */     
/*  5070 */     if (paramBINARY_FLOAT == null)
/*       */     {
/*  5072 */       this.currentRowBinders[i] = this.theBINARY_FLOATNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  5076 */       this.currentRowBinders[i] = this.theBINARY_FLOATBinder;
/*       */       
/*  5078 */       if (this.parameterDatum == null)
/*       */       {
/*  5080 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5085 */       this.parameterDatum[this.currentRank][i] = paramBINARY_FLOAT.getBytes();
/*       */     }
/*       */     
/*  5088 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDouble(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5103 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5106 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBinaryDoubleInternal(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5114 */     int i = paramInt - 1;
/*       */     
/*  5116 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5118 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5119 */       localSQLException.fillInStackTrace();
/*  5120 */       throw localSQLException;
/*       */     }
/*       */     
/*  5123 */     this.currentRowBinders[i] = this.theBinaryDoubleBinder;
/*       */     
/*  5125 */     if (this.parameterDouble == null) {
/*  5126 */       this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*  5129 */     this.currentRowCharLens[i] = 0;
/*       */     
/*       */ 
/*       */ 
/*  5133 */     this.parameterDouble[this.currentRank][i] = paramDouble;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE)
/*       */     throws SQLException
/*       */   {
/*  5149 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5152 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryDoubleInternal(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE)
/*       */     throws SQLException
/*       */   {
/*  5161 */     int i = paramInt - 1;
/*       */     
/*  5163 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5165 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5166 */       localSQLException.fillInStackTrace();
/*  5167 */       throw localSQLException;
/*       */     }
/*       */     
/*  5170 */     if (paramBINARY_DOUBLE == null)
/*       */     {
/*  5172 */       this.currentRowBinders[i] = this.theBINARY_DOUBLENullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  5176 */       this.currentRowBinders[i] = this.theBINARY_DOUBLEBinder;
/*       */       
/*  5178 */       if (this.parameterDatum == null)
/*       */       {
/*  5180 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5185 */       this.parameterDatum[this.currentRank][i] = paramBINARY_DOUBLE.getBytes();
/*       */     }
/*       */     
/*  5188 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDouble(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5203 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5206 */       setDoubleInternal(paramInt, paramDouble);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setDoubleInternal(int paramInt, double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  5214 */     int i = paramInt - 1;
/*       */     
/*  5216 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5218 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5219 */       localSQLException.fillInStackTrace();
/*  5220 */       throw localSQLException;
/*       */     }
/*       */     
/*  5223 */     if (this.theDoubleBinder == null)
/*       */     {
/*  5225 */       this.theDoubleBinder = theStaticDoubleBinder;
/*  5226 */       if (this.connection.setFloatAndDoubleUseBinary) {
/*  5227 */         this.theDoubleBinder = theStaticBinaryDoubleBinder;
/*       */       }
/*       */     }
/*  5230 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  5232 */     this.currentRowBinders[i] = this.theDoubleBinder;
/*       */     
/*  5234 */     if (this.parameterDouble == null) {
/*  5235 */       this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5240 */     this.parameterDouble[this.currentRank][i] = paramDouble;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/*  5254 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5257 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBigDecimalInternal(int paramInt, BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/*  5265 */     int i = paramInt - 1;
/*       */     
/*  5267 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5269 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5270 */       localSQLException.fillInStackTrace();
/*  5271 */       throw localSQLException;
/*       */     }
/*       */     
/*  5274 */     if (paramBigDecimal == null) {
/*  5275 */       this.currentRowBinders[i] = this.theVarnumNullBinder;
/*       */     }
/*       */     else {
/*  5278 */       this.currentRowBinders[i] = this.theBigDecimalBinder;
/*       */       
/*  5280 */       if (this.parameterBigDecimal == null) {
/*  5281 */         this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5286 */       this.parameterBigDecimal[this.currentRank][i] = paramBigDecimal;
/*       */     }
/*       */     
/*  5289 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*  5294 */   int SetBigStringTryClob = 0;
/*       */   
/*       */ 
/*       */   static final int BSTYLE_UNKNOWN = 0;
/*       */   
/*       */ 
/*       */   static final int BSTYLE_ORACLE = 1;
/*       */   
/*       */ 
/*       */   static final int BSTYLE_JDBC = 2;
/*       */   
/*       */ 
/*       */   public void setString(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5309 */     setStringInternal(paramInt, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setStringInternal(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5317 */     int i = paramInt - 1;
/*  5318 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5320 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5321 */       localSQLException.fillInStackTrace();
/*  5322 */       throw localSQLException;
/*       */     }
/*       */     
/*  5325 */     int j = paramString != null ? paramString.length() : 0;
/*       */     
/*  5327 */     if (j == 0) {
/*  5328 */       basicBindNullString(paramInt);
/*       */     } else {
/*       */       int k;
/*  5331 */       if (this.currentRowFormOfUse[(paramInt - 1)] == 1)
/*       */       {
/*  5333 */         if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  5335 */           if ((j > this.maxVcsBytesPlsql) || ((j > this.maxVcsCharsPlsql) && (this.isServerCharSetFixedWidth)))
/*       */           {
/*       */ 
/*  5338 */             setStringForClobCritical(paramInt, paramString);
/*       */           }
/*  5340 */           else if (j > this.maxVcsCharsPlsql)
/*       */           {
/*  5342 */             k = this.connection.conversion.encodedByteLength(paramString, false);
/*  5343 */             if (k > this.maxVcsBytesPlsql)
/*       */             {
/*  5345 */               setStringForClobCritical(paramInt, paramString);
/*       */             }
/*       */             else {
/*  5348 */               basicBindString(paramInt, paramString);
/*       */             }
/*       */           } else {
/*  5351 */             basicBindString(paramInt, paramString);
/*       */           }
/*       */           
/*       */         }
/*  5355 */         else if (j <= this.maxVcsCharsSql) {
/*  5356 */           basicBindString(paramInt, paramString);
/*  5357 */         } else if (j <= this.maxStreamCharsSql) {
/*  5358 */           basicBindCharacterStream(paramInt, new StringReader(paramString), j, true);
/*       */         } else {
/*  5360 */           setStringForClobCritical(paramInt, paramString);
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  5365 */       else if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  5367 */         if ((j > this.maxVcsBytesPlsql) || ((j > this.maxVcsNCharsPlsql) && (this.isServerNCharSetFixedWidth)))
/*       */         {
/*       */ 
/*  5370 */           setStringForClobCritical(paramInt, paramString);
/*       */         }
/*  5372 */         else if (j > this.maxVcsNCharsPlsql)
/*       */         {
/*  5374 */           k = this.connection.conversion.encodedByteLength(paramString, true);
/*  5375 */           if (k > this.maxVcsBytesPlsql)
/*       */           {
/*  5377 */             setStringForClobCritical(paramInt, paramString);
/*       */           }
/*       */           else {
/*  5380 */             basicBindString(paramInt, paramString);
/*       */           }
/*       */         } else {
/*  5383 */           basicBindString(paramInt, paramString);
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  5388 */       else if (j <= this.maxVcsCharsSql) {
/*  5389 */         basicBindString(paramInt, paramString);
/*  5390 */       } else if (j <= this.maxStreamNCharsSql)
/*       */       {
/*       */ 
/*  5393 */         setStringForClobCritical(paramInt, paramString);
/*       */       }
/*       */       else {
/*  5396 */         setStringForClobCritical(paramInt, paramString);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void basicBindNullString(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  5406 */     synchronized (this.connection)
/*       */     {
/*  5408 */       int i = paramInt - 1;
/*  5409 */       this.currentRowBinders[i] = this.theVarcharNullBinder;
/*       */       
/*  5411 */       if (this.sqlKind.isPlsqlOrCall()) {
/*  5412 */         this.currentRowCharLens[i] = this.minVcsBindSize;
/*       */       } else {
/*  5414 */         this.currentRowCharLens[i] = 1;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */   void basicBindString(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5422 */     synchronized (this.connection)
/*       */     {
/*  5424 */       int i = paramInt - 1;
/*  5425 */       this.currentRowBinders[i] = this.theStringBinder;
/*  5426 */       int j = paramString.length();
/*       */       
/*  5428 */       if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  5430 */         int k = this.connection.minVcsBindSize;
/*  5431 */         int m = j + 1;
/*       */         
/*  5433 */         this.currentRowCharLens[i] = (m < k ? k : m);
/*       */       }
/*       */       else {
/*  5436 */         this.currentRowCharLens[i] = (j + 1);
/*       */       }
/*  5438 */       if (this.parameterString == null) {
/*  5439 */         this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  5442 */       this.parameterString[this.currentRank][i] = paramString;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStringForClob(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5461 */     if (paramString == null)
/*       */     {
/*  5463 */       setNull(paramInt, 1);
/*  5464 */       return;
/*       */     }
/*  5466 */     int i = paramString.length();
/*  5467 */     if (i == 0)
/*       */     {
/*  5469 */       setNull(paramInt, 1);
/*  5470 */       return;
/*       */     }
/*       */     
/*  5473 */     if (this.sqlKind.isPlsqlOrCall())
/*       */     {
/*  5475 */       if (i <= this.maxVcsCharsPlsql)
/*       */       {
/*  5477 */         setStringInternal(paramInt, paramString);
/*       */       }
/*       */       else
/*       */       {
/*  5481 */         setStringForClobCritical(paramInt, paramString);
/*       */       }
/*       */       
/*       */ 
/*       */     }
/*  5486 */     else if (i <= this.maxVcsCharsSql)
/*       */     {
/*  5488 */       setStringInternal(paramInt, paramString);
/*       */     }
/*       */     else
/*       */     {
/*  5492 */       setStringForClobCritical(paramInt, paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setStringForClobCritical(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5501 */     synchronized (this.connection) {
/*  5502 */       CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[(paramInt - 1)]);
/*       */       
/*       */ 
/*  5505 */       localCLOB.setString(1L, paramString);
/*  5506 */       addToTempLobsToFree(localCLOB);
/*  5507 */       this.lastBoundClobs[(paramInt - 1)] = localCLOB;
/*  5508 */       setCLOBInternal(paramInt, localCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setReaderContentsForClobCritical(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  5518 */     synchronized (this.connection)
/*       */     {
/*       */       try
/*       */       {
/*  5522 */         if ((paramReader = isReaderEmpty(paramReader)) == null)
/*       */         {
/*  5524 */           if (paramBoolean)
/*       */           {
/*  5526 */             throw new IOException(paramLong + " char of CLOB data cannot be read");
/*       */           }
/*  5528 */           setCLOBInternal(paramInt, null);
/*  5529 */           return;
/*       */         }
/*       */         
/*       */       }
/*       */       catch (IOException localIOException1)
/*       */       {
/*  5535 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/*  5536 */         ((SQLException)localObject1).fillInStackTrace();
/*  5537 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*  5541 */       CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[(paramInt - 1)]);
/*       */       
/*       */ 
/*  5544 */       Object localObject1 = (OracleClobWriter)localCLOB.setCharacterStream(1L);
/*  5545 */       int i = localCLOB.getBufferSize();
/*  5546 */       char[] arrayOfChar = new char[i];
/*  5547 */       long l = 0L;
/*  5548 */       int j = 0;
/*       */       
/*       */ 
/*  5551 */       l = paramBoolean ? paramLong : Long.MAX_VALUE;
/*       */       
/*       */       try
/*       */       {
/*  5555 */         while (l > 0L)
/*       */         {
/*  5557 */           if (l >= i) {
/*  5558 */             j = paramReader.read(arrayOfChar);
/*       */           } else {
/*  5560 */             j = paramReader.read(arrayOfChar, 0, (int)l);
/*       */           }
/*  5562 */           if (j == -1)
/*       */           {
/*  5564 */             if (!paramBoolean)
/*       */               break;
/*  5566 */             throw new IOException(l + " char of CLOB data cannot be read");
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  5572 */           ((OracleClobWriter)localObject1).write(arrayOfChar, 0, j);
/*       */           
/*  5574 */           l -= j;
/*       */         }
/*  5576 */         ((OracleClobWriter)localObject1).flush();
/*       */ 
/*       */       }
/*       */       catch (IOException localIOException2)
/*       */       {
/*  5581 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/*  5582 */         localSQLException.fillInStackTrace();
/*  5583 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*  5587 */       addToTempLobsToFree(localCLOB);
/*  5588 */       this.lastBoundClobs[(paramInt - 1)] = localCLOB;
/*  5589 */       setCLOBInternal(paramInt, localCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setAsciiStreamContentsForClobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  5599 */     synchronized (this.connection)
/*       */     {
/*       */       try
/*       */       {
/*  5603 */         if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null)
/*       */         {
/*  5605 */           if (paramBoolean)
/*       */           {
/*  5607 */             throw new IOException(paramLong + " byte of CLOB data cannot be read");
/*       */           }
/*  5609 */           setCLOBInternal(paramInt, null);
/*  5610 */           return;
/*       */         }
/*       */         
/*       */       }
/*       */       catch (IOException localIOException1)
/*       */       {
/*  5616 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/*  5617 */         ((SQLException)localObject1).fillInStackTrace();
/*  5618 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*  5621 */       CLOB localCLOB = CLOB.createTemporary(this.connection, true, 10, this.currentRowFormOfUse[(paramInt - 1)]);
/*       */       
/*       */ 
/*  5624 */       Object localObject1 = (OracleClobWriter)localCLOB.setCharacterStream(1L);
/*  5625 */       int i = localCLOB.getBufferSize();
/*  5626 */       byte[] arrayOfByte = new byte[i];
/*  5627 */       char[] arrayOfChar = new char[i];
/*  5628 */       int j = 0;
/*       */       
/*  5630 */       long l = paramBoolean ? paramLong : Long.MAX_VALUE;
/*       */       
/*       */       try
/*       */       {
/*  5634 */         while (l > 0L)
/*       */         {
/*  5636 */           if (l >= i) {
/*  5637 */             j = paramInputStream.read(arrayOfByte);
/*       */           } else {
/*  5639 */             j = paramInputStream.read(arrayOfByte, 0, (int)l);
/*       */           }
/*  5641 */           if (j == -1)
/*       */           {
/*  5643 */             if (!paramBoolean)
/*       */               break;
/*  5645 */             throw new IOException(l + " byte of CLOB data cannot be read");
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  5652 */           DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*  5653 */           ((OracleClobWriter)localObject1).write(arrayOfChar, 0, j);
/*       */           
/*  5655 */           l -= j;
/*       */         }
/*  5657 */         ((OracleClobWriter)localObject1).flush();
/*       */ 
/*       */       }
/*       */       catch (IOException localIOException2)
/*       */       {
/*  5662 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/*  5663 */         localSQLException.fillInStackTrace();
/*  5664 */         throw localSQLException;
/*       */       }
/*       */       
/*  5667 */       addToTempLobsToFree(localCLOB);
/*  5668 */       this.lastBoundClobs[(paramInt - 1)] = localCLOB;
/*  5669 */       setCLOBInternal(paramInt, localCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStringForClobAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  5687 */     String str = paramString1.intern();
/*  5688 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  5689 */     int i = 0;
/*  5690 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  5692 */     for (int k = 0; k < j; k++) {
/*  5693 */       if (arrayOfString[k] == str)
/*       */       {
/*  5695 */         setStringForClob(k + 1, paramString2);
/*       */         
/*  5697 */         i = 1;
/*       */       }
/*       */     }
/*  5700 */     if (i == 0)
/*       */     {
/*  5702 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/*  5703 */       localSQLException.fillInStackTrace();
/*  5704 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFixedCHAR(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5722 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5725 */       setFixedCHARInternal(paramInt, paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setFixedCHARInternal(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5733 */     int i = paramInt - 1;
/*       */     
/*  5735 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5737 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5738 */       localSQLException1.fillInStackTrace();
/*  5739 */       throw localSQLException1;
/*       */     }
/*       */     
/*  5742 */     int j = 0;
/*       */     
/*  5744 */     if (paramString != null) {
/*  5745 */       j = paramString.length();
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5750 */     if (j > 32766)
/*       */     {
/*  5752 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157);
/*  5753 */       localSQLException2.fillInStackTrace();
/*  5754 */       throw localSQLException2;
/*       */     }
/*       */     
/*  5757 */     if (paramString == null)
/*       */     {
/*  5759 */       this.currentRowBinders[i] = this.theFixedCHARNullBinder;
/*  5760 */       this.currentRowCharLens[i] = 1;
/*       */     }
/*       */     else
/*       */     {
/*  5764 */       this.currentRowBinders[i] = this.theFixedCHARBinder;
/*  5765 */       this.currentRowCharLens[i] = (j + 1);
/*       */       
/*  5767 */       if (this.parameterString == null) {
/*  5768 */         this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  5771 */       this.parameterString[this.currentRank][i] = paramString;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/*  5791 */     synchronized (this.connection)
/*       */     {
/*  5793 */       setCursorInternal(paramInt, paramResultSet);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setCursorInternal(int paramInt, ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/*  5802 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5803 */     localSQLException.fillInStackTrace();
/*  5804 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setROWID(int paramInt, ROWID paramROWID)
/*       */     throws SQLException
/*       */   {
/*  5822 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  5825 */       setROWIDInternal(paramInt, paramROWID);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setROWIDInternal(int paramInt, ROWID paramROWID)
/*       */     throws SQLException
/*       */   {
/*  5833 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*       */     {
/*  5835 */       if (paramROWID == null)
/*       */       {
/*  5837 */         setNull(paramInt, 12);
/*       */       }
/*       */       else {
/*  5840 */         setStringInternal(paramInt, paramROWID.stringValue());
/*       */       }
/*       */       
/*  5843 */       return;
/*       */     }
/*       */     
/*  5846 */     int i = paramInt - 1;
/*       */     
/*  5848 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5850 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5851 */       localSQLException.fillInStackTrace();
/*  5852 */       throw localSQLException;
/*       */     }
/*       */     
/*  5855 */     if ((paramROWID == null) || (paramROWID.shareBytes() == null))
/*       */     {
/*  5857 */       this.currentRowBinders[i] = this.theRowidNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  5861 */       this.currentRowBinders[i] = (T4CRowidAccessor.isUROWID(paramROWID.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder);
/*       */       
/*  5863 */       if (this.parameterDatum == null)
/*       */       {
/*  5865 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  5870 */       this.parameterDatum[this.currentRank][i] = paramROWID.getBytes();
/*       */     }
/*       */     
/*  5873 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setArray(int paramInt, Array paramArray)
/*       */     throws SQLException
/*       */   {
/*  5892 */     setARRAYInternal(paramInt, (ARRAY)paramArray);
/*       */   }
/*       */   
/*       */ 
/*       */   void setArrayInternal(int paramInt, Array paramArray)
/*       */     throws SQLException
/*       */   {
/*  5899 */     setARRAYInternal(paramInt, (ARRAY)paramArray);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setARRAY(int paramInt, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/*  5917 */     setARRAYInternal(paramInt, paramARRAY);
/*       */   }
/*       */   
/*       */ 
/*       */   void setARRAYInternal(int paramInt, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/*  5924 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  5926 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  5928 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  5929 */       localSQLException.fillInStackTrace();
/*  5930 */       throw localSQLException;
/*       */     }
/*       */     
/*  5933 */     if (paramARRAY == null)
/*       */     {
/*       */ 
/*  5936 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5937 */       localSQLException.fillInStackTrace();
/*  5938 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5943 */     synchronized (this.connection) {
/*  5944 */       setArrayCritical(i, paramARRAY);
/*       */       
/*  5946 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setArrayCritical(int paramInt, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/*  5963 */     ArrayDescriptor localArrayDescriptor = paramARRAY.getDescriptor();
/*       */     
/*  5965 */     if (localArrayDescriptor == null)
/*       */     {
/*       */ 
/*       */ 
/*  5969 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
/*  5970 */       ((SQLException)localObject).fillInStackTrace();
/*  5971 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5976 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  5978 */     if (this.parameterDatum == null)
/*       */     {
/*  5980 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  5985 */     this.parameterDatum[this.currentRank][paramInt] = paramARRAY.toBytes();
/*       */     
/*  5987 */     Object localObject = localArrayDescriptor.getOracleTypeCOLLECTION();
/*       */     
/*  5989 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  5991 */     if (this.parameterOtype == null)
/*       */     {
/*  5993 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  5997 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/*  6015 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*       */   }
/*       */   
/*       */ 
/*       */   void setOPAQUEInternal(int paramInt, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/*  6022 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  6024 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6026 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6027 */       localSQLException.fillInStackTrace();
/*  6028 */       throw localSQLException;
/*       */     }
/*       */     
/*  6031 */     if (paramOPAQUE == null)
/*       */     {
/*       */ 
/*  6034 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6035 */       localSQLException.fillInStackTrace();
/*  6036 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6041 */     synchronized (this.connection) {
/*  6042 */       setOPAQUECritical(i, paramOPAQUE);
/*       */       
/*  6044 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setOPAQUECritical(int paramInt, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/*  6061 */     OpaqueDescriptor localOpaqueDescriptor = paramOPAQUE.getDescriptor();
/*       */     
/*  6063 */     if (localOpaqueDescriptor == null)
/*       */     {
/*       */ 
/*       */ 
/*  6067 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
/*  6068 */       ((SQLException)localObject).fillInStackTrace();
/*  6069 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6074 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6076 */     if (this.parameterDatum == null)
/*       */     {
/*  6078 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6083 */     this.parameterDatum[this.currentRank][paramInt] = paramOPAQUE.toBytes();
/*       */     
/*  6085 */     Object localObject = (OracleTypeADT)localOpaqueDescriptor.getPickler();
/*       */     
/*  6087 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  6089 */     if (this.parameterOtype == null)
/*       */     {
/*  6091 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6095 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML)
/*       */     throws SQLException
/*       */   {
/*  6115 */     if (paramSQLXML == null)
/*       */     {
/*       */ 
/*  6118 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6119 */       localSQLException.fillInStackTrace();
/*  6120 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6125 */     setOPAQUEInternal(paramInt, (OPAQUE)paramSQLXML);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6146 */     setStructDescriptorInternal(paramInt, paramStructDescriptor);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setStructDescriptorInternal(int paramInt, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6154 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  6156 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6158 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6159 */       localSQLException.fillInStackTrace();
/*  6160 */       throw localSQLException;
/*       */     }
/*       */     
/*  6163 */     if (paramStructDescriptor == null)
/*       */     {
/*  6165 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6166 */       localSQLException.fillInStackTrace();
/*  6167 */       throw localSQLException;
/*       */     }
/*       */     
/*  6170 */     synchronized (this.connection) {
/*  6171 */       setStructDescriptorCritical(i, paramStructDescriptor);
/*       */       
/*  6173 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setStructDescriptorCritical(int paramInt, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6189 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6191 */     if (this.parameterDatum == null) {
/*  6192 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*  6195 */     OracleTypeADT localOracleTypeADT = paramStructDescriptor.getOracleTypeADT();
/*       */     
/*  6197 */     localOracleTypeADT.getTOID();
/*       */     
/*  6199 */     if (this.parameterOtype == null) {
/*  6200 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6204 */     this.parameterOtype[this.currentRank][paramInt] = localOracleTypeADT;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  6223 */     String str = paramString.intern();
/*  6224 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  6225 */     int i = 0;
/*  6226 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  6228 */     for (int k = 0; k < j; k++) {
/*  6229 */       if (arrayOfString[k] == str)
/*       */       {
/*  6231 */         setStructDescriptorInternal(k + 1, paramStructDescriptor);
/*       */         
/*  6233 */         i = 1;
/*       */       }
/*       */     }
/*  6236 */     if (i == 0)
/*       */     {
/*  6238 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  6239 */       localSQLException.fillInStackTrace();
/*  6240 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setPreBindsCompelete()
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/*  6269 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*       */   }
/*       */   
/*       */ 
/*       */   void setSTRUCTInternal(int paramInt, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/*  6276 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  6278 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6280 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6281 */       localSQLException.fillInStackTrace();
/*  6282 */       throw localSQLException;
/*       */     }
/*       */     
/*  6285 */     if (paramSTRUCT == null)
/*       */     {
/*       */ 
/*  6288 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6289 */       localSQLException.fillInStackTrace();
/*  6290 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6295 */     synchronized (this.connection) {
/*  6296 */       setSTRUCTCritical(i, paramSTRUCT);
/*       */       
/*  6298 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setSTRUCTCritical(int paramInt, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/*  6316 */     StructDescriptor localStructDescriptor = paramSTRUCT.getDescriptor();
/*       */     
/*  6318 */     if (localStructDescriptor == null)
/*       */     {
/*       */ 
/*       */ 
/*  6322 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
/*  6323 */       ((SQLException)localObject).fillInStackTrace();
/*  6324 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6329 */     this.currentRowBinders[paramInt] = this.theNamedTypeBinder;
/*       */     
/*  6331 */     if (this.parameterDatum == null)
/*       */     {
/*  6333 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6338 */     this.parameterDatum[this.currentRank][paramInt] = paramSTRUCT.toBytes();
/*       */     
/*       */ 
/*       */ 
/*  6342 */     Object localObject = localStructDescriptor.getOracleTypeADT();
/*       */     
/*  6344 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  6346 */     if (this.parameterOtype == null)
/*       */     {
/*  6348 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  6352 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRAW(int paramInt, RAW paramRAW)
/*       */     throws SQLException
/*       */   {
/*  6370 */     setRAWInternal(paramInt, paramRAW);
/*       */   }
/*       */   
/*       */ 
/*       */   void setRAWInternal(int paramInt, RAW paramRAW)
/*       */     throws SQLException
/*       */   {
/*  6377 */     int i = 0;
/*  6378 */     synchronized (this.connection) {
/*  6379 */       int j = paramInt - 1;
/*       */       
/*  6381 */       if ((j < 0) || (paramInt > this.numberOfBindPositions))
/*       */       {
/*  6383 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6384 */         localSQLException.fillInStackTrace();
/*  6385 */         throw localSQLException;
/*       */       }
/*       */       
/*  6388 */       this.currentRowCharLens[j] = 0;
/*       */       
/*  6390 */       if (paramRAW == null) {
/*  6391 */         this.currentRowBinders[j] = this.theRawNullBinder;
/*       */       } else
/*  6393 */         i = 1;
/*       */     }
/*  6395 */     if (i != 0) {
/*  6396 */       setBytesInternal(paramInt, paramRAW.getBytes());
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCHAR(int paramInt, CHAR paramCHAR)
/*       */     throws SQLException
/*       */   {
/*  6412 */     synchronized (this.connection)
/*       */     {
/*  6414 */       setCHARInternal(paramInt, paramCHAR);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setCHARInternal(int paramInt, CHAR paramCHAR)
/*       */     throws SQLException
/*       */   {
/*  6422 */     int i = paramInt - 1;
/*       */     
/*  6424 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6426 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6427 */       localSQLException.fillInStackTrace();
/*  6428 */       throw localSQLException;
/*       */     }
/*       */     
/*  6431 */     if ((paramCHAR == null) || (paramCHAR.getLength() == 0L))
/*       */     {
/*       */ 
/*  6434 */       this.currentRowBinders[i] = this.theSetCHARNullBinder;
/*  6435 */       this.currentRowCharLens[i] = 1;
/*       */     }
/*       */     else
/*       */     {
/*  6439 */       int j = (short)paramCHAR.oracleId();
/*  6440 */       this.currentRowBinders[i] = this.theSetCHARBinder;
/*       */       
/*  6442 */       if (this.parameterDatum == null)
/*       */       {
/*  6444 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*  6448 */       CharacterSet localCharacterSet = this.currentRowFormOfUse[i] == 2 ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj;
/*       */       
/*       */ 
/*       */ 
/*       */       byte[] arrayOfByte1;
/*       */       
/*       */ 
/*  6455 */       if ((localCharacterSet != null) && (localCharacterSet.getOracleId() != j))
/*       */       {
/*  6457 */         byte[] arrayOfByte2 = paramCHAR.shareBytes();
/*       */         
/*  6459 */         arrayOfByte1 = localCharacterSet.convert(paramCHAR.getCharacterSet(), arrayOfByte2, 0, arrayOfByte2.length);
/*       */       }
/*       */       else {
/*  6462 */         arrayOfByte1 = paramCHAR.getBytes();
/*       */       }
/*  6464 */       this.parameterDatum[this.currentRank][i] = arrayOfByte1;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  6470 */       this.currentRowCharLens[i] = ((arrayOfByte1.length + 1 >> 1) + 1);
/*       */     }
/*       */     
/*       */ 
/*  6474 */     if (this.sqlKind.isPlsqlOrCall())
/*       */     {
/*       */ 
/*       */ 
/*  6478 */       if (this.currentRowCharLens[i] < this.minVcsBindSize) {
/*  6479 */         this.currentRowCharLens[i] = this.minVcsBindSize;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDATE(int paramInt, DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/*  6502 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6505 */       setDATEInternal(paramInt, paramDATE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setDATEInternal(int paramInt, DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/*  6513 */     int i = paramInt - 1;
/*       */     
/*  6515 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6517 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6518 */       localSQLException.fillInStackTrace();
/*  6519 */       throw localSQLException;
/*       */     }
/*       */     
/*  6522 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6524 */     if (paramDATE == null)
/*       */     {
/*  6526 */       this.currentRowBinders[i] = this.theDateNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  6530 */       this.currentRowBinders[i] = this.theOracleDateBinder;
/*       */       
/*  6532 */       if (this.parameterDatum == null)
/*       */       {
/*  6534 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6539 */       this.parameterDatum[this.currentRank][i] = paramDATE.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNUMBER(int paramInt, NUMBER paramNUMBER)
/*       */     throws SQLException
/*       */   {
/*  6556 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6559 */       setNUMBERInternal(paramInt, paramNUMBER);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNUMBERInternal(int paramInt, NUMBER paramNUMBER)
/*       */     throws SQLException
/*       */   {
/*  6567 */     int i = paramInt - 1;
/*       */     
/*  6569 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6571 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6572 */       localSQLException.fillInStackTrace();
/*  6573 */       throw localSQLException;
/*       */     }
/*       */     
/*  6576 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6578 */     if (paramNUMBER == null)
/*       */     {
/*  6580 */       this.currentRowBinders[i] = this.theVarnumNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  6584 */       this.currentRowBinders[i] = this.theOracleNumberBinder;
/*       */       
/*  6586 */       if (this.parameterDatum == null)
/*       */       {
/*  6588 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6593 */       this.parameterDatum[this.currentRank][i] = paramNUMBER.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBLOB(int paramInt, BLOB paramBLOB)
/*       */     throws SQLException
/*       */   {
/*  6610 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6613 */       setBLOBInternal(paramInt, paramBLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBLOBInternal(int paramInt, BLOB paramBLOB)
/*       */     throws SQLException
/*       */   {
/*  6621 */     int i = paramInt - 1;
/*       */     
/*  6623 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6625 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6626 */       localSQLException.fillInStackTrace();
/*  6627 */       throw localSQLException;
/*       */     }
/*       */     
/*  6630 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6632 */     if (paramBLOB == null) {
/*  6633 */       this.currentRowBinders[i] = this.theBlobNullBinder;
/*       */     }
/*       */     else {
/*  6636 */       this.currentRowBinders[i] = this.theBlobBinder;
/*       */       
/*  6638 */       if (this.parameterDatum == null) {
/*  6639 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6644 */       this.parameterDatum[this.currentRank][i] = paramBLOB.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlob(int paramInt, Blob paramBlob)
/*       */     throws SQLException
/*       */   {
/*  6661 */     synchronized (this.connection)
/*       */     {
/*  6663 */       setBLOBInternal(paramInt, (BLOB)paramBlob);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBlobInternal(int paramInt, Blob paramBlob)
/*       */     throws SQLException
/*       */   {
/*  6671 */     setBLOBInternal(paramInt, (BLOB)paramBlob);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCLOB(int paramInt, CLOB paramCLOB)
/*       */     throws SQLException
/*       */   {
/*  6688 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6691 */       setCLOBInternal(paramInt, paramCLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setCLOBInternal(int paramInt, CLOB paramCLOB)
/*       */     throws SQLException
/*       */   {
/*  6699 */     int i = paramInt - 1;
/*       */     
/*  6701 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6703 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6704 */       localSQLException.fillInStackTrace();
/*  6705 */       throw localSQLException;
/*       */     }
/*       */     
/*  6708 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6710 */     if (paramCLOB == null) {
/*  6711 */       this.currentRowBinders[i] = this.theClobNullBinder;
/*       */     }
/*       */     else {
/*  6714 */       this.currentRowBinders[i] = this.theClobBinder;
/*       */       
/*  6716 */       if (this.parameterDatum == null) {
/*  6717 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6722 */       this.parameterDatum[this.currentRank][i] = paramCLOB.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClob(int paramInt, Clob paramClob)
/*       */     throws SQLException
/*       */   {
/*  6739 */     synchronized (this.connection)
/*       */     {
/*  6741 */       setCLOBInternal(paramInt, (CLOB)paramClob);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setClobInternal(int paramInt, Clob paramClob)
/*       */     throws SQLException
/*       */   {
/*  6749 */     setCLOBInternal(paramInt, (CLOB)paramClob);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBFILE(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6765 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  6768 */       setBFILEInternal(paramInt, paramBFILE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBFILEInternal(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6776 */     int i = paramInt - 1;
/*       */     
/*  6778 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6780 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6781 */       localSQLException.fillInStackTrace();
/*  6782 */       throw localSQLException;
/*       */     }
/*       */     
/*  6785 */     this.currentRowCharLens[i] = 0;
/*       */     
/*  6787 */     if (paramBFILE == null) {
/*  6788 */       this.currentRowBinders[i] = this.theBfileNullBinder;
/*       */     }
/*       */     else {
/*  6791 */       this.currentRowBinders[i] = this.theBfileBinder;
/*       */       
/*  6793 */       if (this.parameterDatum == null) {
/*  6794 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  6799 */       this.parameterDatum[this.currentRank][i] = paramBFILE.getBytes();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBfile(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6816 */     synchronized (this.connection)
/*       */     {
/*  6818 */       setBFILEInternal(paramInt, paramBFILE);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setBfileInternal(int paramInt, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/*  6826 */     setBFILEInternal(paramInt, paramBFILE);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytes(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6842 */     setBytesInternal(paramInt, paramArrayOfByte);
/*       */   }
/*       */   
/*       */ 
/*       */   void setBytesInternal(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6849 */     int i = paramInt - 1;
/*       */     
/*  6851 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  6853 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  6854 */       localSQLException.fillInStackTrace();
/*  6855 */       throw localSQLException;
/*       */     }
/*  6857 */     int j = paramArrayOfByte != null ? paramArrayOfByte.length : 0;
/*  6858 */     if (j == 0)
/*       */     {
/*  6860 */       setNullInternal(paramInt, -2);
/*       */ 
/*       */ 
/*       */     }
/*  6864 */     else if (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK)
/*       */     {
/*  6866 */       if (j > this.maxRawBytesPlsql) {
/*  6867 */         setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */       } else {
/*  6869 */         basicBindBytes(paramInt, paramArrayOfByte);
/*       */       }
/*  6871 */     } else if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*       */     {
/*  6873 */       if (j > this.maxRawBytesPlsql) {
/*  6874 */         setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */       } else {
/*  6876 */         basicBindBytes(paramInt, paramArrayOfByte);
/*       */       }
/*       */       
/*       */     }
/*  6880 */     else if (j > this.maxRawBytesSql)
/*       */     {
/*  6882 */       bindBytesAsStream(paramInt, paramArrayOfByte);
/*       */     }
/*       */     else {
/*  6885 */       basicBindBytes(paramInt, paramArrayOfByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void bindBytesAsStream(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6894 */     int i = paramArrayOfByte.length;
/*  6895 */     byte[] arrayOfByte = new byte[i];
/*  6896 */     System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, i);
/*  6897 */     set_execute_batch(1);
/*  6898 */     basicBindBinaryStream(paramInt, new ByteArrayInputStream(arrayOfByte), i, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void basicBindBytes(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6906 */     synchronized (this.connection)
/*       */     {
/*  6908 */       int i = paramInt - 1;
/*  6909 */       Binder localBinder = this.sqlKind.isPlsqlOrCall() ? this.thePlsqlRawBinder : this.theRawBinder;
/*  6910 */       this.currentRowBinders[i] = localBinder;
/*       */       
/*  6912 */       if (this.parameterDatum == null) {
/*  6913 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*  6916 */       this.parameterDatum[this.currentRank][i] = paramArrayOfByte;
/*  6917 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  6927 */     basicBindBinaryStream(paramInt1, paramInputStream, paramInt2, false);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  6935 */     synchronized (this.connection)
/*       */     {
/*  6937 */       int i = paramInt1 - 1;
/*       */       
/*  6939 */       if (paramBoolean) {
/*  6940 */         this.currentRowBinders[i] = this.theLongRawStreamForBytesBinder;
/*       */       } else {
/*  6942 */         this.currentRowBinders[i] = this.theLongRawStreamBinder;
/*       */       }
/*  6944 */       if (this.parameterStream == null) {
/*  6945 */         this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  6948 */       this.parameterStream[this.currentRank][i] = (paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramInputStream, 6, paramInt2) : this.connection.conversion.ConvertStream(paramInputStream, 6, paramInt2));
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  6953 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6973 */     if (paramArrayOfByte == null)
/*       */     {
/*  6975 */       setNull(paramInt, -2);
/*  6976 */       return;
/*       */     }
/*  6978 */     int i = paramArrayOfByte.length;
/*  6979 */     if (i == 0)
/*       */     {
/*  6981 */       setNull(paramInt, -2);
/*  6982 */       return;
/*       */     }
/*  6984 */     if (this.sqlKind.isPlsqlOrCall())
/*       */     {
/*  6986 */       if (i <= this.maxRawBytesPlsql)
/*       */       {
/*  6988 */         setBytes(paramInt, paramArrayOfByte);
/*       */       }
/*       */       else
/*       */       {
/*  6992 */         setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */       }
/*       */       
/*       */ 
/*       */     }
/*  6997 */     else if (i <= this.maxRawBytesSql)
/*       */     {
/*  6999 */       setBytes(paramInt, paramArrayOfByte);
/*       */ 
/*       */ 
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*       */ 
/*  7008 */       setBytesForBlobCritical(paramInt, paramArrayOfByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBytesForBlobCritical(int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  7018 */     BLOB localBLOB = BLOB.createTemporary(this.connection, true, 10);
/*       */     
/*  7020 */     localBLOB.putBytes(1L, paramArrayOfByte);
/*  7021 */     addToTempLobsToFree(localBLOB);
/*  7022 */     this.lastBoundBlobs[(paramInt - 1)] = localBLOB;
/*  7023 */     setBLOBInternal(paramInt, localBLOB);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBinaryStreamContentsForBlobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7034 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */       try
/*       */       {
/*  7039 */         if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null)
/*       */         {
/*  7041 */           if (paramBoolean)
/*       */           {
/*  7043 */             throw new IOException(paramLong + " byte of BLOB data cannot be read");
/*       */           }
/*  7045 */           setBLOBInternal(paramInt, null);
/*  7046 */           return;
/*       */         }
/*       */         
/*       */       }
/*       */       catch (IOException localIOException1)
/*       */       {
/*  7052 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/*  7053 */         ((SQLException)localObject1).fillInStackTrace();
/*  7054 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*  7058 */       BLOB localBLOB = BLOB.createTemporary(this.connection, true, 10);
/*       */       
/*       */ 
/*  7061 */       Object localObject1 = (OracleBlobOutputStream)localBLOB.setBinaryStream(1L);
/*       */       
/*  7063 */       int i = localBLOB.getBufferSize();
/*  7064 */       byte[] arrayOfByte = new byte[i];
/*  7065 */       long l = 0L;
/*  7066 */       int j = 0;
/*       */       
/*       */ 
/*  7069 */       l = paramBoolean ? paramLong : Long.MAX_VALUE;
/*       */       
/*       */       try
/*       */       {
/*  7073 */         while (l > 0L)
/*       */         {
/*  7075 */           if (l >= i) {
/*  7076 */             j = paramInputStream.read(arrayOfByte);
/*       */           } else {
/*  7078 */             j = paramInputStream.read(arrayOfByte, 0, (int)l);
/*       */           }
/*  7080 */           if (j == -1)
/*       */           {
/*  7082 */             if (!paramBoolean)
/*       */               break;
/*  7084 */             throw new IOException(l + " byte of BLOB data cannot be read");
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*  7090 */           ((OracleBlobOutputStream)localObject1).write(arrayOfByte, 0, j);
/*  7091 */           l -= j;
/*       */         }
/*  7093 */         ((OracleBlobOutputStream)localObject1).flush();
/*       */ 
/*       */       }
/*       */       catch (IOException localIOException2)
/*       */       {
/*  7098 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/*  7099 */         localSQLException.fillInStackTrace();
/*  7100 */         throw localSQLException;
/*       */       }
/*       */       
/*  7103 */       addToTempLobsToFree(localBLOB);
/*  7104 */       this.lastBoundBlobs[(paramInt - 1)] = localBLOB;
/*  7105 */       setBLOBInternal(paramInt, localBLOB);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  7123 */     String str = paramString.intern();
/*  7124 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  7125 */     int i = 0;
/*  7126 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  7128 */     for (int k = 0; k < j; k++) {
/*  7129 */       if (arrayOfString[k] == str)
/*       */       {
/*  7131 */         setBytesForBlob(k + 1, paramArrayOfByte);
/*       */         
/*  7133 */         i = 1;
/*       */       }
/*       */     }
/*  7136 */     if (i == 0)
/*       */     {
/*  7138 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  7139 */       localSQLException.fillInStackTrace();
/*  7140 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setInternalBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7154 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7157 */       setInternalBytesInternal(paramInt1, paramArrayOfByte, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setInternalBytesInternal(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7169 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7170 */     localSQLException.fillInStackTrace();
/*  7171 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDate(int paramInt, Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  7186 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7189 */       setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, getDefaultCalendar()));
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setDateInternal(int paramInt, Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  7199 */     setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, getDefaultCalendar()));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTime(int paramInt, Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  7215 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7218 */       setTimeInternal(paramInt, paramTime);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setTimeInternal(int paramInt, Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  7226 */     int i = paramInt - 1;
/*       */     
/*  7228 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7230 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7231 */       localSQLException.fillInStackTrace();
/*  7232 */       throw localSQLException;
/*       */     }
/*       */     
/*  7235 */     if (paramTime == null) {
/*  7236 */       this.currentRowBinders[i] = this.theDateNullBinder;
/*       */     }
/*       */     else {
/*  7239 */       this.currentRowBinders[i] = this.theTimeBinder;
/*       */       
/*  7241 */       if (this.parameterTime == null) {
/*  7242 */         this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7247 */       this.parameterTime[this.currentRank][i] = paramTime;
/*       */     }
/*       */     
/*  7250 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  7265 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7268 */       setTimestampInternal(paramInt, paramTimestamp);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  7278 */     int i = paramInt - 1;
/*       */     
/*  7280 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7282 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*       */       
/*  7284 */       localSQLException.fillInStackTrace();
/*  7285 */       throw localSQLException;
/*       */     }
/*       */     
/*  7288 */     if (paramTimestamp == null) {
/*  7289 */       this.currentRowBinders[i] = this.theTimestampNullBinder;
/*       */     }
/*       */     else {
/*  7292 */       this.currentRowBinders[i] = this.theTimestampBinder;
/*       */       
/*  7294 */       if (this.parameterTimestamp == null) {
/*  7295 */         this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7300 */       this.parameterTimestamp[this.currentRank][i] = paramTimestamp;
/*       */     }
/*       */     
/*  7303 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM)
/*       */     throws SQLException
/*       */   {
/*  7324 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7327 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setINTERVALYMInternal(int paramInt, INTERVALYM paramINTERVALYM)
/*       */     throws SQLException
/*       */   {
/*  7335 */     int i = paramInt - 1;
/*       */     
/*  7337 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7339 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7340 */       localSQLException.fillInStackTrace();
/*  7341 */       throw localSQLException;
/*       */     }
/*       */     
/*  7344 */     if (paramINTERVALYM == null)
/*       */     {
/*  7346 */       this.currentRowBinders[i] = this.theIntervalYMNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7350 */       this.currentRowBinders[i] = this.theIntervalYMBinder;
/*       */       
/*  7352 */       if (this.parameterDatum == null)
/*       */       {
/*  7354 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7359 */       this.parameterDatum[this.currentRank][i] = paramINTERVALYM.getBytes();
/*       */     }
/*       */     
/*  7362 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS)
/*       */     throws SQLException
/*       */   {
/*  7383 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7386 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setINTERVALDSInternal(int paramInt, INTERVALDS paramINTERVALDS)
/*       */     throws SQLException
/*       */   {
/*  7394 */     int i = paramInt - 1;
/*       */     
/*  7396 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7398 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7399 */       localSQLException.fillInStackTrace();
/*  7400 */       throw localSQLException;
/*       */     }
/*       */     
/*  7403 */     if (paramINTERVALDS == null)
/*       */     {
/*  7405 */       this.currentRowBinders[i] = this.theIntervalDSNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7409 */       this.currentRowBinders[i] = this.theIntervalDSBinder;
/*       */       
/*  7411 */       if (this.parameterDatum == null)
/*       */       {
/*  7413 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7418 */       this.parameterDatum[this.currentRank][i] = paramINTERVALDS.getBytes();
/*       */     }
/*       */     
/*  7421 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP)
/*       */     throws SQLException
/*       */   {
/*  7442 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7445 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setTIMESTAMPInternal(int paramInt, TIMESTAMP paramTIMESTAMP)
/*       */     throws SQLException
/*       */   {
/*  7453 */     int i = paramInt - 1;
/*       */     
/*  7455 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7457 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7458 */       localSQLException.fillInStackTrace();
/*  7459 */       throw localSQLException;
/*       */     }
/*       */     
/*  7462 */     if (paramTIMESTAMP == null)
/*       */     {
/*  7464 */       this.currentRowBinders[i] = this.theTimestampNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7468 */       this.currentRowBinders[i] = this.theOracleTimestampBinder;
/*       */       
/*  7470 */       if (this.parameterDatum == null)
/*       */       {
/*  7472 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7477 */       this.parameterDatum[this.currentRank][i] = paramTIMESTAMP.getBytes();
/*       */     }
/*       */     
/*  7480 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*       */     throws SQLException
/*       */   {
/*  7501 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7504 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTIMESTAMPTZInternal(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*       */     throws SQLException
/*       */   {
/*  7513 */     int i = paramInt - 1;
/*       */     
/*  7515 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7517 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7518 */       localSQLException.fillInStackTrace();
/*  7519 */       throw localSQLException;
/*       */     }
/*       */     
/*  7522 */     if (paramTIMESTAMPTZ == null)
/*       */     {
/*  7524 */       this.currentRowBinders[i] = this.theTSTZNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7528 */       this.currentRowBinders[i] = this.theTSTZBinder;
/*       */       
/*  7530 */       if (this.parameterDatum == null)
/*       */       {
/*  7532 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7537 */       this.parameterDatum[this.currentRank][i] = paramTIMESTAMPTZ.getBytes();
/*       */     }
/*       */     
/*  7540 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*       */     throws SQLException
/*       */   {
/*  7565 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7568 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTIMESTAMPLTZInternal(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*       */     throws SQLException
/*       */   {
/*  7577 */     if (this.connection.getSessionTimeZone() == null)
/*       */     {
/*       */ 
/*  7580 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105);
/*  7581 */       localSQLException1.fillInStackTrace();
/*  7582 */       throw localSQLException1;
/*       */     }
/*       */     
/*       */ 
/*  7586 */     int i = paramInt - 1;
/*       */     
/*  7588 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7590 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7591 */       localSQLException2.fillInStackTrace();
/*  7592 */       throw localSQLException2;
/*       */     }
/*       */     
/*  7595 */     if (paramTIMESTAMPLTZ == null)
/*       */     {
/*  7597 */       this.currentRowBinders[i] = this.theTSLTZNullBinder;
/*       */     }
/*       */     else
/*       */     {
/*  7601 */       this.currentRowBinders[i] = this.theTSLTZBinder;
/*       */       
/*  7603 */       if (this.parameterDatum == null)
/*       */       {
/*  7605 */         this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7610 */       this.parameterDatum[this.currentRank][i] = paramTIMESTAMPLTZ.getBytes();
/*       */     }
/*       */     
/*  7613 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private Reader isReaderEmpty(Reader paramReader)
/*       */     throws IOException
/*       */   {
/*  7624 */     if (!paramReader.markSupported())
/*  7625 */       paramReader = new BufferedReader(paramReader, 5);
/*  7626 */     paramReader.mark(100);
/*  7627 */     int i; if ((i = paramReader.read()) == -1) {
/*  7628 */       return null;
/*       */     }
/*       */     
/*  7631 */     paramReader.reset();
/*  7632 */     return paramReader;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   private InputStream isInputStreamEmpty(InputStream paramInputStream)
/*       */     throws IOException
/*       */   {
/*  7640 */     if (!paramInputStream.markSupported())
/*  7641 */       paramInputStream = new BufferedInputStream(paramInputStream, 5);
/*  7642 */     paramInputStream.mark(100);
/*  7643 */     int i; if ((i = paramInputStream.read()) == -1) {
/*  7644 */       return null;
/*       */     }
/*       */     
/*  7647 */     paramInputStream.reset();
/*  7648 */     return paramInputStream;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7674 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7677 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setAsciiStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7686 */     setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7694 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  7696 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  7698 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7699 */       localSQLException.fillInStackTrace();
/*  7700 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  7706 */     set_execute_batch(1);
/*  7707 */     checkUserStreamForDuplicates(paramInputStream, i);
/*  7708 */     if (paramInputStream == null) {
/*  7709 */       basicBindNullString(paramInt);
/*  7710 */     } else { if ((this.userRsetType != 1) && ((paramLong > this.maxVcsCharsSql) || (!paramBoolean)))
/*       */       {
/*  7712 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  7713 */         localSQLException.fillInStackTrace();
/*  7714 */         throw localSQLException;
/*       */       }
/*  7716 */       if (!paramBoolean) {
/*  7717 */         setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*  7718 */       } else if (this.currentRowFormOfUse[i] == 1)
/*       */       {
/*  7720 */         if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  7722 */           if (paramLong <= this.maxVcsCharsPlsql)
/*       */           {
/*  7724 */             setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */           }
/*       */           else
/*       */           {
/*  7728 */             setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */           }
/*       */           
/*       */ 
/*       */         }
/*  7733 */         else if (paramLong <= this.maxVcsCharsSql)
/*       */         {
/*  7735 */           setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */         }
/*  7737 */         else if (paramLong > 2147483647L)
/*       */         {
/*  7739 */           setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */         }
/*       */         else
/*       */         {
/*  7743 */           basicBindAsciiStream(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  7749 */       else if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  7751 */         if (paramLong <= this.maxVcsNCharsPlsql)
/*       */         {
/*  7753 */           setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */         }
/*       */         else
/*       */         {
/*  7757 */           setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  7762 */       else if (paramLong <= this.maxVcsNCharsSql)
/*       */       {
/*  7764 */         setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong);
/*       */       }
/*       */       else
/*       */       {
/*  7768 */         setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void basicBindAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7779 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  7782 */       if (this.userRsetType != 1)
/*       */       {
/*  7784 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  7785 */         localSQLException.fillInStackTrace();
/*  7786 */         throw localSQLException;
/*       */       }
/*  7788 */       int i = paramInt1 - 1;
/*  7789 */       this.currentRowBinders[i] = this.theLongStreamBinder;
/*       */       
/*  7791 */       if (this.parameterStream == null) {
/*  7792 */         this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*       */       
/*  7795 */       this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 5, paramInt2);
/*       */       
/*       */ 
/*       */ 
/*  7799 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setAsciiStreamContentsForStringInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7807 */     byte[] arrayOfByte = new byte[paramInt2];
/*  7808 */     int i = 0;
/*  7809 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  7816 */       while ((j > 0) && ((k = paramInputStream.read(arrayOfByte, i, j)) != -1))
/*       */       {
/*  7818 */         i += k;
/*  7819 */         j -= k;
/*       */       }
/*       */       
/*       */ 
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  7826 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  7827 */       localSQLException.fillInStackTrace();
/*  7828 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  7833 */     if (i == 0) {
/*  7834 */       basicBindNullString(paramInt1);
/*       */     }
/*  7836 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/*  7838 */     DBConversion.asciiBytesToJavaChars(arrayOfByte, i, arrayOfChar);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  7843 */     basicBindString(paramInt1, new String(arrayOfChar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7870 */     setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7878 */     setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void checkUserStreamForDuplicates(Object paramObject, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  7886 */     if (paramObject == null)
/*       */     {
/*  7888 */       return;
/*       */     }
/*  7890 */     if (this.userStream != null)
/*       */     {
/*  7892 */       for (Object[] arrayOfObject1 : this.userStream)
/*       */       {
/*  7894 */         for (Object localObject : arrayOfObject1)
/*       */         {
/*  7896 */           if (localObject == paramObject)
/*       */           {
/*       */ 
/*  7899 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(paramInt + 1));
/*  7900 */             localSQLException.fillInStackTrace();
/*  7901 */             throw localSQLException;
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */       }
/*       */       
/*       */     } else {
/*  7909 */       this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*  7911 */     this.userStream[this.currentRank][paramInt] = paramObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7919 */     synchronized (this.connection)
/*       */     {
/*  7921 */       int i = paramInt - 1;
/*       */       SQLException localSQLException;
/*  7923 */       if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */       {
/*  7925 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  7926 */         localSQLException.fillInStackTrace();
/*  7927 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  7932 */       set_execute_batch(1);
/*       */       
/*  7934 */       checkUserStreamForDuplicates(paramInputStream, i);
/*       */       
/*  7936 */       if (paramInputStream == null) {
/*  7937 */         setRAWInternal(paramInt, null);
/*  7938 */       } else { if ((this.userRsetType != 1) && ((paramLong > this.maxRawBytesSql) || (!paramBoolean)))
/*       */         {
/*       */ 
/*  7941 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  7942 */           localSQLException.fillInStackTrace();
/*  7943 */           throw localSQLException;
/*       */         }
/*  7945 */         if (!paramBoolean) {
/*  7946 */           setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */         }
/*  7948 */         else if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  7950 */           if (paramLong > this.maxRawBytesPlsql)
/*       */           {
/*  7952 */             setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*  7957 */             setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong);
/*       */ 
/*       */           }
/*       */           
/*       */ 
/*       */         }
/*  7963 */         else if (paramLong > 2147483647L)
/*       */         {
/*  7965 */           setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean);
/*       */ 
/*       */         }
/*  7968 */         else if (paramLong > this.maxRawBytesSql)
/*       */         {
/*  7970 */           basicBindBinaryStream(paramInt, paramInputStream, (int)paramLong);
/*       */         }
/*       */         else
/*       */         {
/*  7974 */           setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong);
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBinaryStreamContentsForByteArrayInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7988 */     Object localObject = new byte[paramInt2];
/*  7989 */     int i = 0;
/*  7990 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  7997 */       while ((j > 0) && ((k = paramInputStream.read((byte[])localObject, i, j)) != -1))
/*       */       {
/*  7999 */         i += k;
/*  8000 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  8006 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  8007 */       localSQLException.fillInStackTrace();
/*  8008 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  8012 */     if (i != paramInt2)
/*       */     {
/*  8014 */       byte[] arrayOfByte = new byte[i];
/*       */       
/*  8016 */       System.arraycopy(localObject, 0, arrayOfByte, 0, i);
/*       */       
/*  8018 */       localObject = arrayOfByte;
/*       */     }
/*       */     
/*  8021 */     setBytesInternal(paramInt1, (byte[])localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8052 */     setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setUnicodeStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8060 */     synchronized (this.connection)
/*       */     {
/*  8062 */       int i = paramInt1 - 1;
/*       */       Object localObject1;
/*  8064 */       if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */       {
/*  8066 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  8067 */         ((SQLException)localObject1).fillInStackTrace();
/*  8068 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  8074 */       set_execute_batch(1);
/*  8075 */       checkUserStreamForDuplicates(paramInputStream, i);
/*  8076 */       if (paramInputStream == null) {
/*  8077 */         setStringInternal(paramInt1, null);
/*  8078 */       } else { if ((this.userRsetType != 1) && (paramInt2 > this.maxVcsCharsSql))
/*       */         {
/*  8080 */           localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  8081 */           ((SQLException)localObject1).fillInStackTrace();
/*  8082 */           throw ((Throwable)localObject1);
/*       */         }
/*  8084 */         if ((this.sqlKind.isPlsqlOrCall()) || (paramInt2 <= this.maxVcsCharsSql))
/*       */         {
/*  8086 */           localObject1 = new byte[paramInt2];
/*  8087 */           int j = 0;
/*  8088 */           int k = paramInt2;
/*       */           
/*       */ 
/*       */           try
/*       */           {
/*       */             int m;
/*       */             
/*  8095 */             while ((k > 0) && ((m = paramInputStream.read((byte[])localObject1, j, k)) != -1))
/*       */             {
/*  8097 */               j += m;
/*  8098 */               k -= m;
/*       */             }
/*       */             
/*       */           }
/*       */           catch (IOException localIOException)
/*       */           {
/*  8104 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  8105 */             localSQLException.fillInStackTrace();
/*  8106 */             throw localSQLException;
/*       */           }
/*       */           
/*       */ 
/*  8110 */           char[] arrayOfChar = new char[j >> 1];
/*       */           
/*  8112 */           DBConversion.ucs2BytesToJavaChars((byte[])localObject1, j, arrayOfChar);
/*       */           
/*       */ 
/*  8115 */           setStringInternal(paramInt1, new String(arrayOfChar));
/*       */         }
/*       */         else
/*       */         {
/*  8119 */           this.currentRowBinders[i] = this.theLongStreamBinder;
/*       */           
/*  8121 */           if (this.parameterStream == null) {
/*  8122 */             this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */           }
/*       */           
/*  8125 */           this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 4, paramInt2);
/*       */           
/*       */ 
/*       */ 
/*  8129 */           this.currentRowCharLens[i] = 0;
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/*  8149 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8155 */       setObjectInternal(paramInt, this.connection.toDatum(paramCustomDatum));
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setCustomDatumInternal(int paramInt, CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/*  8163 */     synchronized (this.connection)
/*       */     {
/*  8165 */       Datum localDatum = this.connection.toDatum(paramCustomDatum);
/*  8166 */       int i = sqlTypeForObject(localDatum);
/*       */       
/*  8168 */       setObjectCritical(paramInt, localDatum, i, 0);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setORAData(int paramInt, ORAData paramORAData)
/*       */     throws SQLException
/*       */   {
/*  8188 */     setORADataInternal(paramInt, paramORAData);
/*       */   }
/*       */   
/*       */   void setORADataInternal(int paramInt, ORAData paramORAData)
/*       */     throws SQLException
/*       */   {
/*  8194 */     synchronized (this.connection)
/*       */     {
/*  8196 */       Datum localDatum = paramORAData.toDatum(this.connection);
/*  8197 */       int i = sqlTypeForObject(localDatum);
/*       */       
/*  8199 */       setObjectCritical(paramInt, localDatum, i, 0);
/*       */       
/*  8201 */       if ((i == 2002) || (i == 2008) || (i == 2003))
/*       */       {
/*       */ 
/*       */ 
/*  8205 */         this.currentRowCharLens[(paramInt - 1)] = 0;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  8235 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*  8238 */       setObjectInternal(paramInt1, paramObject, paramInt2, paramInt3);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  8250 */     if ((paramObject == null) && (paramInt2 != 2002) && (paramInt2 != 2008) && (paramInt2 != 2003) && (paramInt2 != 2007) && (paramInt2 != 2006) && (paramInt2 != 2009))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8263 */       setNullInternal(paramInt1, paramInt2);
/*       */ 
/*       */ 
/*       */     }
/*  8267 */     else if ((paramInt2 == 2002) || (paramInt2 == 2008) || (paramInt2 == 2003) || (paramInt2 == 2009))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8278 */       setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3);
/*       */       
/*  8280 */       this.currentRowCharLens[(paramInt1 - 1)] = 0;
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*  8286 */       setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setObjectCritical(int paramInt1, Object paramObject, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8311 */     switch (paramInt2)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case -15: 
/*  8318 */       setFormOfUse(paramInt1, (short)2);
/*       */     
/*       */ 
/*       */     case 1: 
/*  8322 */       if ((paramObject instanceof CHAR)) {
/*  8323 */         setCHARInternal(paramInt1, (CHAR)paramObject);
/*  8324 */       } else if ((paramObject instanceof String)) {
/*  8325 */         setStringInternal(paramInt1, (String)paramObject);
/*  8326 */       } else if ((paramObject instanceof Boolean)) {
/*  8327 */         setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*  8329 */       else if ((paramObject instanceof Integer)) {
/*  8330 */         setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue());
/*  8331 */       } else if ((paramObject instanceof Long)) {
/*  8332 */         setStringInternal(paramInt1, "" + ((Long)paramObject).longValue());
/*  8333 */       } else if ((paramObject instanceof Float)) {
/*  8334 */         setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue());
/*  8335 */       } else if ((paramObject instanceof Double)) {
/*  8336 */         setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue());
/*  8337 */       } else if ((paramObject instanceof BigDecimal)) {
/*  8338 */         setStringInternal(paramInt1, ((BigDecimal)paramObject).toString());
/*  8339 */       } else if ((paramObject instanceof Date)) {
/*  8340 */         setStringInternal(paramInt1, "" + ((Date)paramObject).toString());
/*  8341 */       } else if ((paramObject instanceof Time)) {
/*  8342 */         setStringInternal(paramInt1, "" + ((Time)paramObject).toString());
/*  8343 */       } else if ((paramObject instanceof Timestamp)) {
/*  8344 */         setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString());
/*       */       }
/*       */       else {
/*  8347 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8349 */         localSQLException.fillInStackTrace();
/*  8350 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       break;
/*       */     case -9: 
/*  8359 */       setFormOfUse(paramInt1, (short)2);
/*       */     
/*       */ 
/*       */     case 12: 
/*  8363 */       if ((paramObject instanceof String)) {
/*  8364 */         setStringInternal(paramInt1, (String)paramObject);
/*  8365 */       } else if ((paramObject instanceof Boolean)) {
/*  8366 */         setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*  8368 */       else if ((paramObject instanceof Integer)) {
/*  8369 */         setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue());
/*  8370 */       } else if ((paramObject instanceof Long)) {
/*  8371 */         setStringInternal(paramInt1, "" + ((Long)paramObject).longValue());
/*  8372 */       } else if ((paramObject instanceof Float)) {
/*  8373 */         setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue());
/*  8374 */       } else if ((paramObject instanceof Double)) {
/*  8375 */         setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue());
/*  8376 */       } else if ((paramObject instanceof BigDecimal)) {
/*  8377 */         setStringInternal(paramInt1, ((BigDecimal)paramObject).toString());
/*  8378 */       } else if ((paramObject instanceof Date)) {
/*  8379 */         setStringInternal(paramInt1, "" + ((Date)paramObject).toString());
/*  8380 */       } else if ((paramObject instanceof Time)) {
/*  8381 */         setStringInternal(paramInt1, "" + ((Time)paramObject).toString());
/*  8382 */       } else if ((paramObject instanceof Timestamp)) {
/*  8383 */         setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString());
/*       */       }
/*       */       else {
/*  8386 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8388 */         localSQLException.fillInStackTrace();
/*  8389 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 999: 
/*  8395 */       setFixedCHARInternal(paramInt1, (String)paramObject);
/*       */       
/*  8397 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case -16: 
/*  8403 */       setFormOfUse(paramInt1, (short)2);
/*       */     
/*       */ 
/*       */     case -1: 
/*  8407 */       if ((paramObject instanceof String)) {
/*  8408 */         setStringInternal(paramInt1, (String)paramObject);
/*  8409 */       } else if ((paramObject instanceof Boolean)) {
/*  8410 */         setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */ 
/*       */       }
/*  8413 */       else if ((paramObject instanceof Integer)) {
/*  8414 */         setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue());
/*       */       }
/*  8416 */       else if ((paramObject instanceof Long)) {
/*  8417 */         setStringInternal(paramInt1, "" + ((Long)paramObject).longValue());
/*       */       }
/*  8419 */       else if ((paramObject instanceof Float)) {
/*  8420 */         setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue());
/*       */       }
/*  8422 */       else if ((paramObject instanceof Double)) {
/*  8423 */         setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue());
/*       */       }
/*  8425 */       else if ((paramObject instanceof BigDecimal)) {
/*  8426 */         setStringInternal(paramInt1, ((BigDecimal)paramObject).toString());
/*  8427 */       } else if ((paramObject instanceof Date)) {
/*  8428 */         setStringInternal(paramInt1, "" + ((Date)paramObject).toString());
/*  8429 */       } else if ((paramObject instanceof Time)) {
/*  8430 */         setStringInternal(paramInt1, "" + ((Time)paramObject).toString());
/*  8431 */       } else if ((paramObject instanceof Timestamp)) {
/*  8432 */         setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString());
/*       */       }
/*       */       else
/*       */       {
/*  8436 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8438 */         localSQLException.fillInStackTrace();
/*  8439 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 2: 
/*  8446 */       if ((paramObject instanceof NUMBER)) {
/*  8447 */         setNUMBERInternal(paramInt1, (NUMBER)paramObject);
/*  8448 */       } else if ((paramObject instanceof Integer)) {
/*  8449 */         setIntInternal(paramInt1, ((Integer)paramObject).intValue());
/*  8450 */       } else if ((paramObject instanceof Long)) {
/*  8451 */         setLongInternal(paramInt1, ((Long)paramObject).longValue());
/*  8452 */       } else if ((paramObject instanceof Float)) {
/*  8453 */         setFloatInternal(paramInt1, ((Float)paramObject).floatValue());
/*  8454 */       } else if ((paramObject instanceof Double)) {
/*  8455 */         setDoubleInternal(paramInt1, ((Double)paramObject).doubleValue());
/*  8456 */       } else if ((paramObject instanceof BigDecimal)) {
/*  8457 */         setBigDecimalInternal(paramInt1, (BigDecimal)paramObject);
/*  8458 */       } else if ((paramObject instanceof String)) {
/*  8459 */         setNUMBERInternal(paramInt1, new NUMBER((String)paramObject, paramInt3));
/*  8460 */       } else if ((paramObject instanceof Boolean)) {
/*  8461 */         setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0);
/*  8462 */       } else if ((paramObject instanceof Short)) {
/*  8463 */         setShortInternal(paramInt1, ((Short)paramObject).shortValue());
/*  8464 */       } else if ((paramObject instanceof Byte)) {
/*  8465 */         setByteInternal(paramInt1, ((Byte)paramObject).byteValue());
/*       */       }
/*       */       else {
/*  8468 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8470 */         localSQLException.fillInStackTrace();
/*  8471 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 3: 
/*  8477 */       if ((paramObject instanceof BigDecimal)) {
/*  8478 */         setBigDecimalInternal(paramInt1, (BigDecimal)paramObject);
/*  8479 */       } else if ((paramObject instanceof Number)) {
/*  8480 */         setBigDecimalInternal(paramInt1, new BigDecimal(((Number)paramObject).doubleValue()));
/*       */       }
/*  8482 */       else if ((paramObject instanceof NUMBER)) {
/*  8483 */         setBigDecimalInternal(paramInt1, ((NUMBER)paramObject).bigDecimalValue());
/*  8484 */       } else if ((paramObject instanceof String)) {
/*  8485 */         setBigDecimalInternal(paramInt1, new BigDecimal((String)paramObject));
/*  8486 */       } else if ((paramObject instanceof Boolean)) {
/*  8487 */         setBigDecimalInternal(paramInt1, new BigDecimal(((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D));
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  8492 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8494 */         localSQLException.fillInStackTrace();
/*  8495 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -7: 
/*  8501 */       if ((paramObject instanceof Boolean)) {
/*  8502 */         setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*  8504 */       else if ((paramObject instanceof String)) {
/*  8505 */         setByteInternal(paramInt1, (byte)(("true".equalsIgnoreCase((String)paramObject)) || ("1".equals(paramObject)) ? 1 : 0));
/*       */ 
/*       */ 
/*       */       }
/*  8509 */       else if ((paramObject instanceof Number)) {
/*  8510 */         setIntInternal(paramInt1, ((Number)paramObject).byteValue() != 0 ? 1 : 0);
/*       */       }
/*       */       else {
/*  8513 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8515 */         localSQLException.fillInStackTrace();
/*  8516 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       break;
/*       */     case -6: 
/*  8524 */       if ((paramObject instanceof Number)) {
/*  8525 */         setByteInternal(paramInt1, ((Number)paramObject).byteValue());
/*  8526 */       } else if ((paramObject instanceof String)) {
/*  8527 */         setByteInternal(paramInt1, Byte.parseByte((String)paramObject));
/*  8528 */       } else if ((paramObject instanceof Boolean)) {
/*  8529 */         setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*       */       else
/*       */       {
/*  8533 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8535 */         localSQLException.fillInStackTrace();
/*  8536 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 5: 
/*  8544 */       if ((paramObject instanceof Number)) {
/*  8545 */         setShortInternal(paramInt1, ((Number)paramObject).shortValue());
/*  8546 */       } else if ((paramObject instanceof String)) {
/*  8547 */         setShortInternal(paramInt1, Short.parseShort((String)paramObject));
/*  8548 */       } else if ((paramObject instanceof Boolean)) {
/*  8549 */         setShortInternal(paramInt1, (short)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*       */       }
/*       */       else
/*       */       {
/*  8553 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8555 */         localSQLException.fillInStackTrace();
/*  8556 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 4: 
/*  8562 */       if ((paramObject instanceof Number)) {
/*  8563 */         setIntInternal(paramInt1, ((Number)paramObject).intValue());
/*  8564 */       } else if ((paramObject instanceof String)) {
/*  8565 */         setIntInternal(paramInt1, Integer.parseInt((String)paramObject));
/*  8566 */       } else if ((paramObject instanceof Boolean)) {
/*  8567 */         setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0);
/*       */       }
/*       */       else {
/*  8570 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8572 */         localSQLException.fillInStackTrace();
/*  8573 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -5: 
/*  8579 */       if ((paramObject instanceof Number)) {
/*  8580 */         setLongInternal(paramInt1, ((Number)paramObject).longValue());
/*  8581 */       } else if ((paramObject instanceof String)) {
/*  8582 */         setLongInternal(paramInt1, Long.parseLong((String)paramObject));
/*  8583 */       } else if ((paramObject instanceof Boolean)) {
/*  8584 */         setLongInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1L : 0L);
/*       */       }
/*       */       else {
/*  8587 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8589 */         localSQLException.fillInStackTrace();
/*  8590 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 7: 
/*  8596 */       if ((paramObject instanceof Number)) {
/*  8597 */         setFloatInternal(paramInt1, ((Number)paramObject).floatValue());
/*  8598 */       } else if ((paramObject instanceof String)) {
/*  8599 */         setFloatInternal(paramInt1, Float.valueOf((String)paramObject).floatValue());
/*  8600 */       } else if ((paramObject instanceof Boolean)) {
/*  8601 */         setFloatInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0F : 0.0F);
/*       */       }
/*       */       else {
/*  8604 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8606 */         localSQLException.fillInStackTrace();
/*  8607 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */       break;
/*       */     case 6: 
/*       */     case 8: 
/*  8615 */       if ((paramObject instanceof Number)) {
/*  8616 */         setDoubleInternal(paramInt1, ((Number)paramObject).doubleValue());
/*  8617 */       } else if ((paramObject instanceof String)) {
/*  8618 */         setDoubleInternal(paramInt1, Double.valueOf((String)paramObject).doubleValue());
/*       */       }
/*  8620 */       else if ((paramObject instanceof Boolean)) {
/*  8621 */         setDoubleInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D);
/*       */       }
/*       */       else
/*       */       {
/*  8625 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8627 */         localSQLException.fillInStackTrace();
/*  8628 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -2: 
/*  8634 */       if ((paramObject instanceof RAW)) {
/*  8635 */         setRAWInternal(paramInt1, (RAW)paramObject);
/*       */       } else {
/*  8637 */         setBytesInternal(paramInt1, (byte[])paramObject);
/*       */       }
/*  8639 */       break;
/*       */     
/*       */     case -3: 
/*  8642 */       setBytesInternal(paramInt1, (byte[])paramObject);
/*       */       
/*  8644 */       break;
/*       */     
/*       */     case -4: 
/*  8647 */       setBytesInternal(paramInt1, (byte[])paramObject);
/*       */       
/*  8649 */       break;
/*       */     
/*       */     case 91: 
/*  8652 */       if ((paramObject instanceof DATE)) {
/*  8653 */         setDATEInternal(paramInt1, (DATE)paramObject);
/*  8654 */       } else if ((paramObject instanceof Date)) {
/*  8655 */         setDATEInternal(paramInt1, new DATE(paramObject, getDefaultCalendar()));
/*  8656 */       } else if ((paramObject instanceof Timestamp)) {
/*  8657 */         setDATEInternal(paramInt1, new DATE((Timestamp)paramObject));
/*  8658 */       } else if ((paramObject instanceof String)) {
/*  8659 */         setDateInternal(paramInt1, Date.valueOf((String)paramObject));
/*       */       }
/*       */       else {
/*  8662 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8664 */         localSQLException.fillInStackTrace();
/*  8665 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 92: 
/*  8671 */       if ((paramObject instanceof Time)) {
/*  8672 */         setTimeInternal(paramInt1, (Time)paramObject);
/*  8673 */       } else if ((paramObject instanceof Timestamp)) {
/*  8674 */         setTimeInternal(paramInt1, new Time(((Timestamp)paramObject).getTime()));
/*       */       }
/*  8676 */       else if ((paramObject instanceof Date)) {
/*  8677 */         setTimeInternal(paramInt1, new Time(((Date)paramObject).getTime()));
/*  8678 */       } else if ((paramObject instanceof String)) {
/*  8679 */         setTimeInternal(paramInt1, Time.valueOf((String)paramObject));
/*       */       }
/*       */       else {
/*  8682 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8684 */         localSQLException.fillInStackTrace();
/*  8685 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case 93: 
/*  8691 */       if ((paramObject instanceof TIMESTAMP)) {
/*  8692 */         setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject);
/*  8693 */       } else if ((paramObject instanceof Timestamp)) {
/*  8694 */         setTimestampInternal(paramInt1, (Timestamp)paramObject);
/*  8695 */       } else if ((paramObject instanceof Date)) {
/*  8696 */         setTIMESTAMPInternal(paramInt1, new TIMESTAMP((Date)paramObject));
/*  8697 */       } else if ((paramObject instanceof DATE)) {
/*  8698 */         setTIMESTAMPInternal(paramInt1, new TIMESTAMP(((DATE)paramObject).timestampValue()));
/*  8699 */       } else if ((paramObject instanceof String)) {
/*  8700 */         setTimestampInternal(paramInt1, Timestamp.valueOf((String)paramObject));
/*       */       }
/*       */       else {
/*  8703 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/*       */         
/*  8705 */         localSQLException.fillInStackTrace();
/*  8706 */         throw localSQLException;
/*       */       }
/*       */       
/*       */ 
/*       */       break;
/*       */     case -100: 
/*  8712 */       setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject);
/*       */       
/*  8714 */       break;
/*       */     
/*       */     case -101: 
/*  8717 */       setTIMESTAMPTZInternal(paramInt1, (TIMESTAMPTZ)paramObject);
/*       */       
/*  8719 */       break;
/*       */     
/*       */     case -102: 
/*  8722 */       setTIMESTAMPLTZInternal(paramInt1, (TIMESTAMPLTZ)paramObject);
/*       */       
/*  8724 */       break;
/*       */     
/*       */     case -103: 
/*  8727 */       setINTERVALYMInternal(paramInt1, (INTERVALYM)paramObject);
/*       */       
/*  8729 */       break;
/*       */     
/*       */     case -104: 
/*  8732 */       setINTERVALDSInternal(paramInt1, (INTERVALDS)paramObject);
/*       */       
/*  8734 */       break;
/*       */     
/*       */     case -8: 
/*  8737 */       setROWIDInternal(paramInt1, (ROWID)paramObject);
/*       */       
/*  8739 */       break;
/*       */     
/*       */     case 100: 
/*  8742 */       setBinaryFloatInternal(paramInt1, (BINARY_FLOAT)paramObject);
/*       */       
/*  8744 */       break;
/*       */     
/*       */     case 101: 
/*  8747 */       setBinaryDoubleInternal(paramInt1, (BINARY_DOUBLE)paramObject);
/*       */       
/*  8749 */       break;
/*       */     
/*       */     case 2004: 
/*  8752 */       setBLOBInternal(paramInt1, (BLOB)paramObject);
/*       */       
/*  8754 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2005: 
/*       */     case 2011: 
/*  8762 */       setCLOBInternal(paramInt1, (CLOB)paramObject);
/*  8763 */       if (((CLOB)paramObject).isNCLOB())
/*       */       {
/*  8765 */         setFormOfUse(paramInt1, (short)2);
/*       */       }
/*       */       
/*       */       break;
/*       */     case -13: 
/*  8770 */       setBFILEInternal(paramInt1, (BFILE)paramObject);
/*       */       
/*  8772 */       break;
/*       */     
/*       */ 
/*       */     case 2002: 
/*       */     case 2008: 
/*  8777 */       setSTRUCTInternal(paramInt1, STRUCT.toSTRUCT(paramObject, this.connection));
/*       */       
/*  8779 */       break;
/*       */     
/*       */     case 2003: 
/*  8782 */       setARRAYInternal(paramInt1, ARRAY.toARRAY(paramObject, this.connection));
/*       */       
/*       */ 
/*  8785 */       break;
/*       */     
/*       */     case 2007: 
/*  8788 */       setOPAQUEInternal(paramInt1, (OPAQUE)paramObject);
/*       */       
/*  8790 */       break;
/*       */     
/*       */     case 2006: 
/*  8793 */       setREFInternal(paramInt1, (REF)paramObject);
/*       */       
/*  8795 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2009: 
/*  8801 */       setSQLXMLInternal(paramInt1, (SQLXML)paramObject);
/*       */       
/*  8803 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */     default: 
/*  8808 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  8809 */       localSQLException.fillInStackTrace();
/*  8810 */       throw localSQLException;
/*       */     }
/*       */     
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8831 */     String str = paramString.intern();
/*  8832 */     String[] arrayOfString = this.sqlObject.getParameterList();
/*  8833 */     int i = 0;
/*  8834 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/*  8836 */     for (int k = 0; k < j; k++) {
/*  8837 */       if (arrayOfString[k] == str)
/*       */       {
/*  8839 */         setObjectInternal(k + 1, paramObject);
/*       */         
/*  8841 */         i = 1;
/*       */       }
/*       */     }
/*  8844 */     if (i == 0)
/*       */     {
/*  8846 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  8847 */       localSQLException.fillInStackTrace();
/*  8848 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8868 */     setObjectInternal(paramInt1, paramObject, paramInt2, 0);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  8877 */     setObjectInternal(paramInt1, paramObject, paramInt2, 0);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRefType(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8893 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */   
/*       */ 
/*       */   void setRefTypeInternal(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8900 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRef(int paramInt, Ref paramRef)
/*       */     throws SQLException
/*       */   {
/*  8917 */     setREFInternal(paramInt, (REF)paramRef);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setRefInternal(int paramInt, Ref paramRef)
/*       */     throws SQLException
/*       */   {
/*  8925 */     setREFInternal(paramInt, (REF)paramRef);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setREF(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8942 */     setREFInternal(paramInt, paramREF);
/*       */   }
/*       */   
/*       */ 
/*       */   void setREFInternal(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8949 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  8951 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  8953 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  8954 */       localSQLException.fillInStackTrace();
/*  8955 */       throw localSQLException;
/*       */     }
/*       */     
/*  8958 */     if (paramREF == null)
/*       */     {
/*       */ 
/*  8961 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  8962 */       localSQLException.fillInStackTrace();
/*  8963 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  8969 */     setREFCritical(i, paramREF);
/*       */     
/*  8971 */     this.currentRowCharLens[i] = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setREFCritical(int paramInt, REF paramREF)
/*       */     throws SQLException
/*       */   {
/*  8988 */     StructDescriptor localStructDescriptor = paramREF.getDescriptor();
/*       */     
/*       */ 
/*  8991 */     if (localStructDescriptor == null)
/*       */     {
/*  8993 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52);
/*  8994 */       ((SQLException)localObject).fillInStackTrace();
/*  8995 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*  8999 */     this.currentRowBinders[paramInt] = this.theRefTypeBinder;
/*       */     
/*  9001 */     if (this.parameterDatum == null)
/*       */     {
/*  9003 */       this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  9008 */     this.parameterDatum[this.currentRank][paramInt] = paramREF.getBytes();
/*       */     
/*  9010 */     Object localObject = localStructDescriptor.getOracleTypeADT();
/*       */     
/*  9012 */     ((OracleTypeADT)localObject).getTOID();
/*       */     
/*  9014 */     if (this.parameterOtype == null)
/*       */     {
/*  9016 */       this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*       */ 
/*  9020 */     this.parameterOtype[this.currentRank][paramInt] = localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObject(int paramInt, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  9041 */     setObjectInternal(paramInt, paramObject);
/*       */   }
/*       */   
/*       */ 
/*       */   void setObjectInternal(int paramInt, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  9048 */     if ((paramObject instanceof ORAData))
/*       */     {
/*  9050 */       setORADataInternal(paramInt, (ORAData)paramObject);
/*       */     }
/*  9052 */     else if ((paramObject instanceof CustomDatum))
/*       */     {
/*  9054 */       setCustomDatumInternal(paramInt, (CustomDatum)paramObject);
/*       */     }
/*       */     else
/*       */     {
/*  9058 */       int i = sqlTypeForObject(paramObject);
/*       */       
/*  9060 */       setObjectInternal(paramInt, paramObject, i, 0);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOracleObject(int paramInt, Datum paramDatum)
/*       */     throws SQLException
/*       */   {
/*  9078 */     setObjectInternal(paramInt, paramDatum);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setOracleObjectInternal(int paramInt, Datum paramDatum)
/*       */     throws SQLException
/*       */   {
/*  9086 */     setObjectInternal(paramInt, paramDatum);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*       */     throws SQLException
/*       */   {
/*  9113 */     synchronized (this.connection)
/*       */     {
/*  9115 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setPlsqlIndexTableInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*       */     throws SQLException
/*       */   {
/*  9129 */     int i = paramInt1 - 1;
/*       */     SQLException localSQLException;
/*  9131 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*  9133 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9134 */       localSQLException.fillInStackTrace();
/*  9135 */       throw localSQLException;
/*       */     }
/*       */     
/*  9138 */     if (paramObject == null)
/*       */     {
/*  9140 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271);
/*  9141 */       localSQLException.fillInStackTrace();
/*  9142 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  9147 */     int j = getInternalType(paramInt4);
/*       */     
/*  9149 */     Object localObject1 = null;
/*       */     
/*       */     Object localObject2;
/*  9152 */     switch (j)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */     case 1: 
/*       */     case 96: 
/*  9159 */       localObject2 = null;
/*  9160 */       int k = 0;
/*       */       
/*       */       Object localObject3;
/*  9163 */       if ((paramObject instanceof CHAR[]))
/*       */       {
/*  9165 */         localObject3 = (CHAR[])paramObject;
/*  9166 */         k = localObject3.length;
/*       */         
/*  9168 */         localObject2 = new String[k];
/*       */         
/*  9170 */         for (int n = 0; n < k; n++)
/*       */         {
/*  9172 */           Object localObject5 = localObject3[n];
/*  9173 */           if (localObject5 != null) {
/*  9174 */             localObject2[n] = ((CHAR)localObject5).getString();
/*       */           }
/*       */         }
/*  9177 */       } else if ((paramObject instanceof String[]))
/*       */       {
/*  9179 */         localObject2 = (String[])paramObject;
/*  9180 */         k = localObject2.length;
/*       */       }
/*       */       else {
/*  9183 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*  9184 */         ((SQLException)localObject3).fillInStackTrace();
/*  9185 */         throw ((Throwable)localObject3);
/*       */       }
/*       */       
/*       */ 
/*  9189 */       if ((paramInt5 == 0) && (localObject2 != null)) {
/*  9190 */         for (int m = 0; m < k; m++)
/*       */         {
/*  9192 */           Object localObject4 = localObject2[m];
/*  9193 */           if ((localObject4 != null) && (paramInt5 < ((String)localObject4).length()))
/*  9194 */             paramInt5 = ((String)localObject4).length();
/*       */         }
/*       */       }
/*  9197 */       localObject1 = localObject2;
/*       */       
/*  9199 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2: 
/*       */     case 6: 
/*  9206 */       localObject1 = OracleTypeNUMBER.toNUMBERArray(paramObject, this.connection, 1L, paramInt3);
/*       */       
/*       */ 
/*  9209 */       if ((paramInt5 == 0) && (localObject1 != null))
/*       */       {
/*  9211 */         paramInt5 = 22;
/*       */       }
/*       */       
/*  9214 */       this.currentRowCharLens[i] = 0;
/*       */       
/*  9216 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     default: 
/*  9235 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
/*  9236 */       ((SQLException)localObject2).fillInStackTrace();
/*  9237 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */     
/*  9241 */     if ((localObject1.length == 0) && (paramInt2 == 0))
/*       */     {
/*  9243 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272);
/*  9244 */       ((SQLException)localObject2).fillInStackTrace();
/*  9245 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*  9248 */     this.currentRowBinders[i] = this.thePlsqlIbtBinder;
/*       */     
/*  9250 */     if (this.parameterPlsqlIbt == null) {
/*  9251 */       this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */     }
/*       */     
/*  9254 */     this.parameterPlsqlIbt[this.currentRank][i] = new PlsqlIbtBindInfo((Object[])localObject1, paramInt2, paramInt3, j, paramInt5);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9261 */     this.hasIbtBind = true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setPlsqlIndexTableAtName(String paramString, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*       */     throws SQLException
/*       */   {
/*  9284 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*  9288 */       String str = paramString.intern();
/*  9289 */       String[] arrayOfString = this.sqlObject.getParameterList();
/*  9290 */       int i = 0;
/*  9291 */       int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */       
/*  9293 */       for (int k = 0; k < j; k++) {
/*  9294 */         if (arrayOfString[k] == str)
/*       */         {
/*  9296 */           setPlsqlIndexTableInternal(k + 1, paramObject, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */           
/*       */ 
/*  9299 */           i = 1;
/*       */         }
/*       */       }
/*  9302 */       if (i == 0)
/*       */       {
/*  9304 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/*  9305 */         localSQLException.fillInStackTrace();
/*  9306 */         throw localSQLException;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void endOfResultSet(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9328 */     if (!paramBoolean)
/*       */     {
/*       */ 
/*       */ 
/*  9332 */       prepareForNewResults(false, false); }
/*  9333 */     this.rowPrefetchInLastFetch = -1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int sqlTypeForObject(Object paramObject)
/*       */   {
/*  9345 */     if (paramObject == null)
/*       */     {
/*  9347 */       return 0;
/*       */     }
/*       */     
/*  9350 */     if (!(paramObject instanceof Datum))
/*       */     {
/*  9352 */       if ((paramObject instanceof String))
/*       */       {
/*       */ 
/*  9355 */         return this.fixedString ? 999 : 12;
/*       */       }
/*  9357 */       if ((paramObject instanceof BigDecimal)) {
/*  9358 */         return 2;
/*       */       }
/*  9360 */       if ((paramObject instanceof Boolean)) {
/*  9361 */         return -7;
/*       */       }
/*  9363 */       if ((paramObject instanceof Integer)) {
/*  9364 */         return 4;
/*       */       }
/*  9366 */       if ((paramObject instanceof Long)) {
/*  9367 */         return -5;
/*       */       }
/*  9369 */       if ((paramObject instanceof Float)) {
/*  9370 */         return 7;
/*       */       }
/*  9372 */       if ((paramObject instanceof Double)) {
/*  9373 */         return 8;
/*       */       }
/*  9375 */       if ((paramObject instanceof byte[])) {
/*  9376 */         return -3;
/*       */       }
/*       */       
/*       */ 
/*  9380 */       if ((paramObject instanceof Short)) {
/*  9381 */         return 5;
/*       */       }
/*  9383 */       if ((paramObject instanceof Byte)) {
/*  9384 */         return -6;
/*       */       }
/*  9386 */       if ((paramObject instanceof Date)) {
/*  9387 */         return 91;
/*       */       }
/*  9389 */       if ((paramObject instanceof Time)) {
/*  9390 */         return 92;
/*       */       }
/*  9392 */       if ((paramObject instanceof Timestamp)) {
/*  9393 */         return 93;
/*       */       }
/*  9395 */       if ((paramObject instanceof SQLData)) {
/*  9396 */         return 2002;
/*       */       }
/*  9398 */       if ((paramObject instanceof ObjectData)) {
/*  9399 */         return 2002;
/*       */       }
/*       */     }
/*       */     else {
/*  9403 */       if ((paramObject instanceof BINARY_FLOAT)) {
/*  9404 */         return 100;
/*       */       }
/*  9406 */       if ((paramObject instanceof BINARY_DOUBLE)) {
/*  9407 */         return 101;
/*       */       }
/*  9409 */       if ((paramObject instanceof BLOB)) {
/*  9410 */         return 2004;
/*       */       }
/*  9412 */       if ((paramObject instanceof CLOB)) {
/*  9413 */         return 2005;
/*       */       }
/*  9415 */       if ((paramObject instanceof BFILE)) {
/*  9416 */         return -13;
/*       */       }
/*  9418 */       if ((paramObject instanceof ROWID)) {
/*  9419 */         return -8;
/*       */       }
/*  9421 */       if ((paramObject instanceof NUMBER)) {
/*  9422 */         return 2;
/*       */       }
/*  9424 */       if ((paramObject instanceof DATE)) {
/*  9425 */         return 91;
/*       */       }
/*  9427 */       if ((paramObject instanceof TIMESTAMP)) {
/*  9428 */         return 93;
/*       */       }
/*  9430 */       if ((paramObject instanceof TIMESTAMPTZ)) {
/*  9431 */         return -101;
/*       */       }
/*  9433 */       if ((paramObject instanceof TIMESTAMPLTZ)) {
/*  9434 */         return -102;
/*       */       }
/*  9436 */       if ((paramObject instanceof REF)) {
/*  9437 */         return 2006;
/*       */       }
/*  9439 */       if ((paramObject instanceof CHAR)) {
/*  9440 */         return 1;
/*       */       }
/*  9442 */       if ((paramObject instanceof RAW)) {
/*  9443 */         return -2;
/*       */       }
/*  9445 */       if ((paramObject instanceof ARRAY)) {
/*  9446 */         return 2003;
/*       */       }
/*  9448 */       if ((paramObject instanceof STRUCT)) {
/*  9449 */         return 2002;
/*       */       }
/*  9451 */       if ((paramObject instanceof OPAQUE)) {
/*  9452 */         return 2007;
/*       */       }
/*  9454 */       if ((paramObject instanceof INTERVALYM)) {
/*  9455 */         return -103;
/*       */       }
/*  9457 */       if ((paramObject instanceof INTERVALDS)) {
/*  9458 */         return -104;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*  9463 */       if ((paramObject instanceof SQLXML)) {
/*  9464 */         return 2009;
/*       */       }
/*       */     }
/*       */     
/*  9468 */     return 1111;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void clearParameters()
/*       */     throws SQLException
/*       */   {
/*  9481 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9487 */       this.clearParameters = true;
/*       */       
/*  9489 */       for (int i = 0; i < this.numberOfBindPositions; i++) {
/*  9490 */         this.currentRowBinders[i] = null;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void printByteArray(byte[] paramArrayOfByte)
/*       */   {
/*  9501 */     if (paramArrayOfByte != null)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9508 */       int j = paramArrayOfByte.length;
/*       */       
/*  9510 */       for (int i = 0; i < j; i++)
/*       */       {
/*  9512 */         int k = paramArrayOfByte[i] & 0xFF;
/*       */         
/*  9514 */         if (k >= 16) {}
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  9561 */     setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  9570 */     setCharacterStreamInternal(paramInt1, paramReader, paramInt2, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9578 */     int i = paramInt - 1;
/*       */     SQLException localSQLException;
/*  9580 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/*  9582 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  9583 */       localSQLException.fillInStackTrace();
/*  9584 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  9590 */     set_execute_batch(1);
/*  9591 */     checkUserStreamForDuplicates(paramReader, i);
/*  9592 */     if (paramReader == null) {
/*  9593 */       basicBindNullString(paramInt);
/*  9594 */     } else { if ((this.userRsetType != 1) && ((paramLong > this.maxVcsCharsSql) || (!paramBoolean)))
/*       */       {
/*  9596 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
/*  9597 */         localSQLException.fillInStackTrace();
/*  9598 */         throw localSQLException;
/*       */       }
/*  9600 */       if (!paramBoolean)
/*       */       {
/*  9602 */         setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */       }
/*  9604 */       else if (this.currentRowFormOfUse[i] == 1)
/*       */       {
/*  9606 */         if (this.sqlKind.isPlsqlOrCall())
/*       */         {
/*  9608 */           if ((paramLong > this.maxVcsBytesPlsql) || ((paramLong > this.maxVcsCharsPlsql) && (this.isServerCharSetFixedWidth)))
/*       */           {
/*       */ 
/*  9611 */             setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */           }
/*  9613 */           else if (paramLong <= this.maxVcsCharsPlsql)
/*       */           {
/*  9615 */             setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */ 
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*       */ 
/*  9622 */             setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, false);
/*       */           }
/*       */           
/*       */ 
/*       */         }
/*  9627 */         else if (paramLong <= this.maxVcsCharsSql)
/*       */         {
/*  9629 */           setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */         }
/*  9631 */         else if (paramLong > 2147483647L)
/*       */         {
/*  9633 */           setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */         }
/*       */         else
/*       */         {
/*  9637 */           basicBindCharacterStream(paramInt, paramReader, (int)paramLong, false);
/*       */ 
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  9643 */       else if (this.sqlKind.isPlsqlOrCall())
/*       */       {
/*  9645 */         if ((paramLong > this.maxVcsBytesPlsql) || ((paramLong > this.maxVcsNCharsPlsql) && (this.isServerCharSetFixedWidth)))
/*       */         {
/*       */ 
/*  9648 */           setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */         }
/*  9650 */         else if (paramLong <= this.maxVcsNCharsPlsql)
/*       */         {
/*  9652 */           setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */         }
/*       */         else
/*       */         {
/*  9656 */           setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, true);
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*  9661 */       else if (paramLong <= this.maxVcsNCharsSql)
/*       */       {
/*  9663 */         setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong);
/*       */       }
/*       */       else
/*       */       {
/*  9667 */         setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void basicBindCharacterStream(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9678 */     synchronized (this.connection)
/*       */     {
/*  9680 */       int i = paramInt1 - 1;
/*  9681 */       if (paramBoolean) {
/*  9682 */         this.currentRowBinders[i] = this.theLongStreamForStringBinder;
/*       */       } else
/*  9684 */         this.currentRowBinders[i] = this.theLongStreamBinder;
/*  9685 */       if (this.parameterStream == null) {
/*  9686 */         this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];
/*       */       }
/*  9688 */       this.parameterStream[this.currentRank][i] = (paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]) : this.connection.conversion.ConvertStream(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]));
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9695 */       this.currentRowCharLens[i] = 0;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setReaderContentsForStringOrClobInVariableWidthCase(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9715 */     Object localObject = new char[paramInt2];
/*  9716 */     int i = 0;
/*  9717 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  9724 */       while ((j > 0) && ((k = paramReader.read((char[])localObject, i, j)) != -1))
/*       */       {
/*  9726 */         i += k;
/*  9727 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  9733 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  9734 */       localSQLException.fillInStackTrace();
/*  9735 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  9739 */     if (i != paramInt2)
/*       */     {
/*  9741 */       char[] arrayOfChar = new char[i];
/*       */       
/*  9743 */       System.arraycopy(localObject, 0, arrayOfChar, 0, i);
/*       */       
/*  9745 */       localObject = arrayOfChar;
/*       */     }
/*  9747 */     int m = this.connection.conversion.encodedByteLength((char[])localObject, paramBoolean);
/*       */     
/*  9749 */     if (m < this.maxVcsBytesPlsql)
/*       */     {
/*  9751 */       setStringInternal(paramInt1, new String((char[])localObject));
/*       */     }
/*       */     else
/*       */     {
/*  9755 */       setStringForClobCritical(paramInt1, new String((char[])localObject));
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setReaderContentsForStringInternal(int paramInt1, Reader paramReader, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  9765 */     Object localObject = new char[paramInt2];
/*  9766 */     int i = 0;
/*  9767 */     int j = paramInt2;
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*       */       int k;
/*       */       
/*  9774 */       while ((j > 0) && ((k = paramReader.read((char[])localObject, i, j)) != -1))
/*       */       {
/*  9776 */         i += k;
/*  9777 */         j -= k;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (IOException localIOException)
/*       */     {
/*  9783 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  9784 */       localSQLException.fillInStackTrace();
/*  9785 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  9789 */     if (i != paramInt2)
/*       */     {
/*  9791 */       char[] arrayOfChar = new char[i];
/*       */       
/*  9793 */       System.arraycopy(localObject, 0, arrayOfChar, 0, i);
/*       */       
/*  9795 */       localObject = arrayOfChar;
/*       */     }
/*  9797 */     setStringInternal(paramInt1, new String((char[])localObject));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9815 */     setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setDateInternal(int paramInt, Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9823 */     setDATEInternal(paramInt, paramDate == null ? null : new DATE(paramDate, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9840 */     setDATEInternal(paramInt, paramTime == null ? null : new DATE(paramTime, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTimeInternal(int paramInt, Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9848 */     setDATEInternal(paramInt, paramTime == null ? null : new DATE(paramTime, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9865 */     setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9873 */     setTIMESTAMPInternal(paramInt, paramTimestamp == null ? null : new TIMESTAMP(paramTimestamp, paramCalendar));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCheckBindTypes(boolean paramBoolean)
/*       */   {
/*  9890 */     this.checkBindTypes = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  9919 */   int m_batchStyle = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void setOracleBatchStyle()
/*       */     throws SQLException
/*       */   {
/*  9930 */     if (this.m_batchStyle == 2)
/*       */     {
/*       */ 
/*  9933 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
/*  9934 */       localSQLException.fillInStackTrace();
/*  9935 */       throw localSQLException;
/*       */     }
/*       */     
/*  9938 */     if (this.m_batchStyle == 0) {}
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  9943 */     this.m_batchStyle = 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   boolean isOracleBatchStyle()
/*       */   {
/*  9950 */     return this.m_batchStyle == 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void setJdbcBatchStyle()
/*       */     throws SQLException
/*       */   {
/*  9963 */     if (this.m_batchStyle == 1)
/*       */     {
/*       */ 
/*  9966 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
/*  9967 */       localSQLException.fillInStackTrace();
/*  9968 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  9972 */     this.m_batchStyle = 2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void checkIfJdbcBatchExists()
/*       */     throws SQLException
/*       */   {
/*  9988 */     if (doesJdbcBatchExist())
/*       */     {
/*       */ 
/*  9991 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/*  9992 */       localSQLException.fillInStackTrace();
/*  9993 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean doesJdbcBatchExist()
/*       */   {
/* 10002 */     if ((this.currentRank > 0) && (this.m_batchStyle == 2)) {
/* 10003 */       return true;
/*       */     }
/* 10005 */     return false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   boolean isJdbcBatchStyle()
/*       */   {
/* 10012 */     return this.m_batchStyle == 2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void addBatch()
/*       */     throws SQLException
/*       */   {
/* 10033 */     synchronized (this.connection)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10048 */       setJdbcBatchStyle();
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10058 */       processCompletedBindRow(this.currentRank + 2, (this.currentRank > 0) && (this.sqlKind.isPlsqlOrCall()));
/*       */       
/*       */ 
/*       */ 
/* 10062 */       this.currentRank += 1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void addBatch(String paramString)
/*       */     throws SQLException
/*       */   {
/* 10072 */     synchronized (this.connection)
/*       */     {
/*       */ 
/* 10075 */       SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10076 */       localSQLException.fillInStackTrace();
/* 10077 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void clearBatch()
/*       */     throws SQLException
/*       */   {
/* 10096 */     synchronized (this.connection)
/*       */     {
/* 10098 */       for (int i = this.currentRank - 1; i >= 0; i--) {
/* 10099 */         for (int j = 0; j < this.numberOfBindPositions; j++)
/* 10100 */           this.binders[i][j] = null;
/*       */       }
/* 10102 */       this.currentRank = 0;
/*       */       
/* 10104 */       if (this.binders != null) {
/* 10105 */         this.currentRowBinders = this.binders[0];
/*       */       }
/* 10107 */       this.pushedBatches = null;
/* 10108 */       this.pushedBatchesTail = null;
/* 10109 */       this.firstRowInBatch = 0;
/*       */       
/* 10111 */       this.clearParameters = true;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void executeForRowsWithTimeout(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/* 10124 */     if (this.queryTimeout > 0)
/*       */     {
/*       */       try
/*       */       {
/* 10128 */         this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/* 10129 */         this.isExecuting = true;
/* 10130 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally
/*       */       {
/* 10134 */         this.connection.getTimeout().cancelTimeout();
/* 10135 */         this.isExecuting = false;
/*       */       }
/*       */       
/*       */     }
/*       */     else {
/*       */       try
/*       */       {
/* 10142 */         this.isExecuting = true;
/* 10143 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally
/*       */       {
/* 10147 */         this.isExecuting = false;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int[] executeBatch()
/*       */     throws SQLException
/*       */   {
/* 10174 */     synchronized (this.connection)
/*       */     {
/*       */ 
/* 10177 */       int[] arrayOfInt = new int[this.currentRank];
/* 10178 */       this.checkSum = 0L;
/* 10179 */       this.checkSumComputationFailure = false;
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10185 */       int i = 0;
/*       */       
/* 10187 */       cleanOldTempLobs();
/* 10188 */       setJdbcBatchStyle();
/*       */       
/* 10190 */       if (this.currentRank > 0)
/*       */       {
/*       */ 
/*       */ 
/* 10194 */         ensureOpen();
/*       */         
/*       */ 
/* 10197 */         prepareForNewResults(true, true);
/*       */         
/* 10199 */         if (this.sqlKind.isSELECT())
/*       */         {
/*       */ 
/* 10202 */           BatchUpdateException localBatchUpdateException1 = DatabaseError.createBatchUpdateException(80, 0, null);
/* 10203 */           localBatchUpdateException1.fillInStackTrace();
/* 10204 */           throw localBatchUpdateException1;
/*       */         }
/*       */         
/*       */ 
/*       */ 
/* 10209 */         this.noMoreUpdateCounts = false;
/*       */         
/* 10211 */         int j = 0;
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         try
/*       */         {
/* 10223 */           this.connection.registerHeartbeat();
/*       */           
/* 10225 */           this.connection.needLine();
/*       */           
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10231 */           if (!this.isOpen)
/*       */           {
/* 10233 */             this.connection.open(this);
/*       */             
/* 10235 */             this.isOpen = true;
/*       */           }
/*       */           
/*       */ 
/*       */ 
/*       */ 
/* 10241 */           int k = this.currentRank;
/*       */           
/* 10243 */           if (this.pushedBatches == null)
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/* 10248 */             setupBindBuffers(0, this.currentRank);
/* 10249 */             executeForRowsWithTimeout(false);
/*       */ 
/*       */ 
/*       */           }
/*       */           else
/*       */           {
/*       */ 
/*       */ 
/* 10257 */             if (this.currentRank > this.firstRowInBatch)
/*       */             {
/*       */ 
/*       */ 
/* 10261 */               pushBatch(true);
/*       */             }
/* 10263 */             boolean bool = this.needToParse;
/*       */             
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             do
/*       */             {
/* 10271 */               localObject1 = this.pushedBatches;
/*       */               
/* 10273 */               this.currentBatchCharLens = ((PushedBatch)localObject1).currentBatchCharLens;
/* 10274 */               this.lastBoundCharLens = ((PushedBatch)localObject1).lastBoundCharLens;
/* 10275 */               this.lastBoundNeeded = ((PushedBatch)localObject1).lastBoundNeeded;
/* 10276 */               this.currentBatchBindAccessors = ((PushedBatch)localObject1).currentBatchBindAccessors;
/* 10277 */               this.needToParse = ((PushedBatch)localObject1).need_to_parse;
/* 10278 */               this.currentBatchNeedToPrepareBinds = ((PushedBatch)localObject1).current_batch_need_to_prepare_binds;
/*       */               
/* 10280 */               this.firstRowInBatch = ((PushedBatch)localObject1).first_row_in_batch;
/*       */               
/* 10282 */               setupBindBuffers(((PushedBatch)localObject1).first_row_in_batch, ((PushedBatch)localObject1).number_of_rows_to_be_bound);
/*       */               
/*       */ 
/*       */ 
/*       */ 
/* 10287 */               this.currentRank = ((PushedBatch)localObject1).number_of_rows_to_be_bound;
/*       */               
/* 10289 */               executeForRowsWithTimeout(false);
/*       */               
/* 10291 */               j += this.validRows;
/* 10292 */               if (this.sqlKind.isPlsqlOrCall())
/*       */               {
/* 10294 */                 arrayOfInt[(i++)] = this.validRows;
/*       */               }
/*       */               
/* 10297 */               this.pushedBatches = ((PushedBatch)localObject1).next;
/*       */ 
/*       */             }
/* 10300 */             while (this.pushedBatches != null);
/*       */             
/*       */ 
/* 10303 */             this.pushedBatchesTail = null;
/* 10304 */             this.firstRowInBatch = 0;
/*       */             
/* 10306 */             this.needToParse = bool;
/*       */           }
/*       */           
/*       */ 
/*       */ 
/* 10311 */           slideDownCurrentRow(k);
/*       */ 
/*       */ 
/*       */         }
/*       */         catch (SQLException localSQLException)
/*       */         {
/*       */ 
/*       */ 
/* 10319 */           int m = this.currentRank;
/* 10320 */           clearBatch();
/* 10321 */           this.needToParse = true;
/*       */           
/* 10323 */           if (!this.sqlKind.isPlsqlOrCall())
/*       */           {
/*       */ 
/*       */ 
/*       */ 
/* 10328 */             if ((this.numberOfExecutedElementsInBatch != -1) && (this.numberOfExecutedElementsInBatch != m))
/*       */             {
/*       */ 
/*       */ 
/*       */ 
/* 10333 */               arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 10334 */               for (i = 0; i < this.numberOfExecutedElementsInBatch;) {
/* 10335 */                 arrayOfInt[i] = -2;i++; continue;
/*       */                 
/*       */ 
/* 10338 */                 for (i = 0; i < arrayOfInt.length; i++)
/* 10339 */                   arrayOfInt[i] = -3;
/*       */               } } }
/* 10341 */           resetCurrentRowBinders();
/*       */           
/*       */ 
/* 10344 */           Object localObject1 = DatabaseError.createBatchUpdateException(localSQLException, this.sqlKind.isPlsqlOrCall() ? i : arrayOfInt.length, arrayOfInt);
/* 10345 */           ((BatchUpdateException)localObject1).fillInStackTrace();
/* 10346 */           throw ((Throwable)localObject1);
/*       */ 
/*       */         }
/*       */         finally
/*       */         {
/* 10351 */           if ((this.sqlKind.isPlsqlOrCall()) || (j > this.validRows)) {
/* 10352 */             this.validRows = j;
/*       */           }
/* 10354 */           checkValidRowsStatus();
/*       */           
/* 10356 */           this.currentRank = 0;
/*       */         }
/*       */         
/* 10359 */         if (this.validRows < 0)
/*       */         {
/* 10361 */           for (i = 0; i < arrayOfInt.length; i++) {
/* 10362 */             arrayOfInt[i] = -3;
/*       */           }
/*       */           
/* 10365 */           BatchUpdateException localBatchUpdateException2 = DatabaseError.createBatchUpdateException(81, 0, arrayOfInt);
/* 10366 */           localBatchUpdateException2.fillInStackTrace();
/* 10367 */           throw localBatchUpdateException2;
/*       */         }
/*       */         
/* 10370 */         if (!this.sqlKind.isPlsqlOrCall())
/*       */         {
/* 10372 */           for (i = 0; i < arrayOfInt.length; i++) {
/* 10373 */             arrayOfInt[i] = -2;
/*       */           }
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/* 10381 */       this.connection.registerHeartbeat();
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10387 */       return arrayOfInt;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void pushBatch(boolean paramBoolean)
/*       */   {
/* 10395 */     PushedBatch localPushedBatch = new PushedBatch();
/*       */     
/* 10397 */     localPushedBatch.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10399 */     System.arraycopy(this.currentBatchCharLens, 0, localPushedBatch.currentBatchCharLens, 0, this.numberOfBindPositions);
/*       */     
/*       */ 
/* 10402 */     localPushedBatch.lastBoundCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10404 */     System.arraycopy(this.lastBoundCharLens, 0, localPushedBatch.lastBoundCharLens, 0, this.numberOfBindPositions);
/*       */     
/*       */ 
/* 10407 */     if (this.currentBatchBindAccessors != null)
/*       */     {
/* 10409 */       localPushedBatch.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       
/* 10411 */       System.arraycopy(this.currentBatchBindAccessors, 0, localPushedBatch.currentBatchBindAccessors, 0, this.numberOfBindPositions);
/*       */     }
/*       */     
/*       */ 
/* 10415 */     localPushedBatch.lastBoundNeeded = this.lastBoundNeeded;
/* 10416 */     localPushedBatch.need_to_parse = this.needToParse;
/* 10417 */     localPushedBatch.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
/* 10418 */     localPushedBatch.first_row_in_batch = this.firstRowInBatch;
/* 10419 */     localPushedBatch.number_of_rows_to_be_bound = (this.currentRank - this.firstRowInBatch);
/*       */     
/* 10421 */     if (this.pushedBatches == null) {
/* 10422 */       this.pushedBatches = localPushedBatch;
/*       */     } else {
/* 10424 */       this.pushedBatchesTail.next = localPushedBatch;
/*       */     }
/* 10426 */     this.pushedBatchesTail = localPushedBatch;
/*       */     
/* 10428 */     if (!paramBoolean)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10434 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/* 10436 */       this.currentBatchCharLens = this.lastBoundCharLens;
/* 10437 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/* 10439 */       this.lastBoundNeeded = false;
/*       */       
/* 10441 */       for (int i = 0; i < this.numberOfBindPositions; i++) {
/* 10442 */         this.currentBatchCharLens[i] = 0;
/*       */       }
/* 10444 */       this.firstRowInBatch = this.currentRank;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int doScrollPstmtExecuteUpdate()
/*       */     throws SQLException
/*       */   {
/* 10458 */     doScrollExecuteCommon();
/*       */     
/* 10460 */     if (this.sqlKind.isSELECT()) {
/* 10461 */       this.scrollRsetTypeSolved = true;
/*       */     }
/* 10463 */     return this.validRows;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int copyBinds(Statement paramStatement, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10478 */     if (this.numberOfBindPositions > 0)
/*       */     {
/* 10480 */       OraclePreparedStatement localOraclePreparedStatement = (OraclePreparedStatement)paramStatement;
/*       */       
/* 10482 */       int i = this.bindIndicatorSubRange + 5;
/*       */       
/* 10484 */       int j = this.bindByteSubRange;
/* 10485 */       int k = this.bindCharSubRange;
/* 10486 */       int m = this.indicatorsOffset;
/* 10487 */       int n = this.valueLengthsOffset;
/*       */       
/* 10489 */       for (int i1 = 0; i1 < this.numberOfBindPositions; i1++)
/*       */       {
/* 10491 */         short s = this.bindIndicators[(i + 0)];
/*       */         
/* 10493 */         int i2 = this.bindIndicators[(i + 1)];
/*       */         
/* 10495 */         int i3 = this.bindIndicators[(i + 2)];
/*       */         
/*       */ 
/* 10498 */         int i4 = i1 + paramInt;
/*       */         
/*       */ 
/*       */ 
/* 10502 */         if (localOraclePreparedStatement.parameterDatum == null) {
/* 10503 */           localOraclePreparedStatement.parameterDatum = new byte[localOraclePreparedStatement.numberOfBindRowsAllocated][localOraclePreparedStatement.numberOfBindPositions][];
/*       */         }
/*       */         
/* 10506 */         if (localOraclePreparedStatement.parameterOtype == null) {
/* 10507 */           localOraclePreparedStatement.parameterOtype = new OracleTypeADT[localOraclePreparedStatement.numberOfBindRowsAllocated][localOraclePreparedStatement.numberOfBindPositions];
/*       */         }
/*       */         
/* 10510 */         if (this.bindIndicators[m] == -1)
/*       */         {
/* 10512 */           localOraclePreparedStatement.currentRowBinders[i4] = copiedNullBinder(s, i2);
/*       */           
/* 10514 */           if (i3 > 0)
/* 10515 */             localOraclePreparedStatement.currentRowCharLens[i4] = 1;
/*       */         } else { Object localObject;
/* 10517 */           if ((s == 109) || (s == 111))
/*       */           {
/* 10519 */             localOraclePreparedStatement.currentRowBinders[i4] = (s == 109 ? this.theNamedTypeBinder : this.theRefTypeBinder);
/*       */             
/*       */ 
/*       */ 
/*       */ 
/* 10524 */             localObject = this.parameterDatum[0][i1];
/* 10525 */             int i5 = localObject.length;
/* 10526 */             byte[] arrayOfByte = new byte[i5];
/*       */             
/* 10528 */             localOraclePreparedStatement.parameterDatum[0][i4] = arrayOfByte;
/*       */             
/* 10530 */             System.arraycopy(localObject, 0, arrayOfByte, 0, i5);
/*       */             
/* 10532 */             localOraclePreparedStatement.parameterOtype[0][i4] = this.parameterOtype[0][i1];
/*       */           }
/* 10534 */           else if (i2 > 0)
/*       */           {
/* 10536 */             localOraclePreparedStatement.currentRowBinders[i4] = copiedByteBinder(s, this.bindBytes, j, i2, this.bindIndicators[n]);
/*       */ 
/*       */           }
/* 10539 */           else if (i3 > 0)
/*       */           {
/* 10541 */             localOraclePreparedStatement.currentRowBinders[i4] = copiedCharBinder(s, this.bindChars, k, i3, this.bindIndicators[n], getInoutIndicator(i1));
/*       */             
/* 10543 */             localOraclePreparedStatement.currentRowCharLens[i4] = i3;
/*       */           }
/*       */           else
/*       */           {
/* 10547 */             localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + s);
/* 10548 */             ((SQLException)localObject).fillInStackTrace();
/* 10549 */             throw ((Throwable)localObject);
/*       */           }
/*       */         }
/* 10552 */         j += this.bindBufferCapacity * i2;
/* 10553 */         k += this.bindBufferCapacity * i3;
/* 10554 */         m += this.numberOfBindRowsAllocated;
/* 10555 */         n += this.numberOfBindRowsAllocated;
/* 10556 */         i += 10;
/*       */       }
/*       */     }
/*       */     
/* 10560 */     return this.numberOfBindPositions;
/*       */   }
/*       */   
/*       */ 
/*       */   Binder copiedNullBinder(short paramShort, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10567 */     return new CopiedNullBinder(paramShort, paramInt);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   Binder copiedByteBinder(short paramShort1, byte[] paramArrayOfByte, int paramInt1, int paramInt2, short paramShort2)
/*       */     throws SQLException
/*       */   {
/* 10575 */     byte[] arrayOfByte = new byte[paramInt2];
/*       */     
/* 10577 */     System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
/*       */     
/* 10579 */     return new CopiedByteBinder(paramShort1, paramInt2, arrayOfByte, paramShort2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   Binder copiedCharBinder(short paramShort1, char[] paramArrayOfChar, int paramInt1, int paramInt2, short paramShort2, short paramShort3)
/*       */     throws SQLException
/*       */   {
/* 10587 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/* 10589 */     System.arraycopy(paramArrayOfChar, paramInt1, arrayOfChar, 0, paramInt2);
/*       */     
/* 10591 */     return new CopiedCharBinder(paramShort1, arrayOfChar, paramShort2, paramShort3);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   protected void hardClose()
/*       */     throws SQLException
/*       */   {
/* 10599 */     super.hardClose();
/*       */     
/* 10601 */     this.connection.cacheBuffer(this.bindBytes);
/* 10602 */     this.bindBytes = null;
/* 10603 */     this.connection.cacheBuffer(this.bindChars);
/* 10604 */     this.bindChars = null;
/* 10605 */     this.bindIndicators = null;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/* 10610 */     if (!this.connection.isClosed())
/*       */     {
/* 10612 */       cleanAllTempLobs();
/*       */     }
/*       */     
/* 10615 */     this.lastBoundBytes = null;
/* 10616 */     this.lastBoundChars = null;
/*       */     
/* 10618 */     clearParameters();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   protected void alwaysOnClose()
/*       */     throws SQLException
/*       */   {
/* 10630 */     if (this.currentRank > 0)
/*       */     {
/* 10632 */       if (this.m_batchStyle == 2) {
/* 10633 */         clearBatch();
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*       */ 
/* 10639 */         int i = this.validRows;
/*       */         
/* 10641 */         this.prematureBatchCount = sendBatch();
/* 10642 */         this.validRows = i;
/*       */       }
/*       */     }
/*       */     
/* 10646 */     super.alwaysOnClose();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDisableStmtCaching(boolean paramBoolean)
/*       */   {
/* 10659 */     synchronized (this.connection)
/*       */     {
/* 10661 */       if (paramBoolean == true) {
/* 10662 */         this.cacheState = 3;
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFormOfUse(int paramInt, short paramShort)
/*       */   {
/* 10672 */     synchronized (this.connection)
/*       */     {
/*       */ 
/* 10675 */       int i = paramInt - 1;
/*       */       
/* 10677 */       if (this.currentRowFormOfUse[i] != paramShort)
/*       */       {
/* 10679 */         this.currentRowFormOfUse[i] = paramShort;
/*       */         
/*       */         Accessor localAccessor;
/*       */         
/* 10683 */         if (this.currentRowBindAccessors != null)
/*       */         {
/* 10685 */           localAccessor = this.currentRowBindAccessors[i];
/*       */           
/* 10687 */           if (localAccessor != null) {
/* 10688 */             localAccessor.setFormOfUse(paramShort);
/*       */           }
/*       */         }
/*       */         
/* 10692 */         if (this.returnParamAccessors != null)
/*       */         {
/* 10694 */           localAccessor = this.returnParamAccessors[i];
/*       */           
/* 10696 */           if (localAccessor != null) {
/* 10697 */             localAccessor.setFormOfUse(paramShort);
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setURL(int paramInt, URL paramURL)
/*       */     throws SQLException
/*       */   {
/* 10724 */     setURLInternal(paramInt, paramURL);
/*       */   }
/*       */   
/*       */ 
/*       */   void setURLInternal(int paramInt, URL paramURL)
/*       */     throws SQLException
/*       */   {
/* 10731 */     setStringInternal(paramInt, paramURL.toString());
/*       */   }
/*       */   
/*       */ 
/*       */   public ParameterMetaData getParameterMetaData()
/*       */     throws SQLException
/*       */   {
/* 10738 */     return new OracleParameterMetaData(this.sqlObject.getParameterCount());
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public oracle.jdbc.OracleParameterMetaData OracleGetParameterMetaData()
/*       */     throws SQLException
/*       */   {
/* 10761 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10762 */     localSQLException.fillInStackTrace();
/* 10763 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException1;
/*       */     
/* 10773 */     if (this.numberOfBindPositions <= 0)
/*       */     {
/* 10775 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10776 */       localSQLException1.fillInStackTrace();
/* 10777 */       throw localSQLException1;
/*       */     }
/*       */     
/* 10780 */     if (this.numReturnParams <= 0)
/*       */     {
/* 10782 */       this.numReturnParams = this.sqlObject.getReturnParameterCount();
/* 10783 */       if (this.numReturnParams <= 0)
/*       */       {
/* 10785 */         localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10786 */         localSQLException1.fillInStackTrace();
/* 10787 */         throw localSQLException1;
/*       */       }
/*       */     }
/*       */     
/* 10791 */     int i = paramInt1 - 1;
/* 10792 */     if ((i < this.numberOfBindPositions - this.numReturnParams) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/*       */ 
/* 10795 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10796 */       localSQLException2.fillInStackTrace();
/* 10797 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10800 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10802 */     short s = 0;
/* 10803 */     if ((this.currentRowFormOfUse != null) && (this.currentRowFormOfUse[i] != 0)) {
/* 10804 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10806 */     registerReturnParameterInternal(i, j, paramInt2, -1, s, null);
/*       */     
/*       */ 
/* 10809 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/* 10820 */     if (this.numberOfBindPositions <= 0)
/*       */     {
/* 10822 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10823 */       localSQLException1.fillInStackTrace();
/* 10824 */       throw localSQLException1;
/*       */     }
/*       */     
/* 10827 */     int i = paramInt1 - 1;
/* 10828 */     SQLException localSQLException2; if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/* 10830 */       localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10831 */       localSQLException2.fillInStackTrace();
/* 10832 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10835 */     if ((paramInt2 != 1) && (paramInt2 != 12) && (paramInt2 != -1) && (paramInt2 != -2) && (paramInt2 != -3) && (paramInt2 != -4) && (paramInt2 != 12))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10844 */       localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10845 */       localSQLException2.fillInStackTrace();
/* 10846 */       throw localSQLException2;
/*       */     }
/*       */     
/*       */ 
/* 10850 */     if (paramInt3 <= 0)
/*       */     {
/*       */ 
/* 10853 */       localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10854 */       localSQLException2.fillInStackTrace();
/* 10855 */       throw localSQLException2;
/*       */     }
/*       */     
/*       */ 
/* 10859 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10861 */     short s = 0;
/* 10862 */     if ((this.currentRowFormOfUse != null) && (this.currentRowFormOfUse[i] != 0)) {
/* 10863 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10865 */     registerReturnParameterInternal(i, j, paramInt2, paramInt3, s, null);
/*       */     
/*       */ 
/* 10868 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/* 10879 */     if (this.numberOfBindPositions <= 0)
/*       */     {
/* 10881 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10882 */       localSQLException1.fillInStackTrace();
/* 10883 */       throw localSQLException1;
/*       */     }
/*       */     
/* 10886 */     int i = paramInt1 - 1;
/* 10887 */     if ((i < 0) || (paramInt1 > this.numberOfBindPositions))
/*       */     {
/* 10889 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10890 */       localSQLException2.fillInStackTrace();
/* 10891 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10894 */     int j = getInternalTypeForDmlReturning(paramInt2);
/* 10895 */     if ((j != 111) && (j != 109))
/*       */     {
/*       */ 
/*       */ 
/* 10899 */       SQLException localSQLException3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10900 */       localSQLException3.fillInStackTrace();
/* 10901 */       throw localSQLException3;
/*       */     }
/*       */     
/*       */ 
/* 10905 */     registerReturnParameterInternal(i, j, paramInt2, -1, (short)0, paramString);
/*       */     
/*       */ 
/* 10908 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */   
/*       */ 
/*       */   public ResultSet getReturnResultSet()
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException;
/* 10916 */     if (this.closed)
/*       */     {
/* 10918 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 10919 */       localSQLException.fillInStackTrace();
/* 10920 */       throw localSQLException;
/*       */     }
/*       */     
/* 10923 */     if ((this.returnParamAccessors == null) || (this.numReturnParams == 0))
/*       */     {
/* 10925 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 10926 */       localSQLException.fillInStackTrace();
/* 10927 */       throw localSQLException;
/*       */     }
/*       */     
/* 10930 */     if ((this.returnResultSet == null) || (this.numReturnParams == 0) || (!this.isOpen))
/*       */     {
/*       */ 
/*       */ 
/* 10934 */       this.returnResultSet = new OracleReturnResultSet(this);
/*       */     }
/*       */     
/* 10937 */     return this.returnResultSet;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int getInternalTypeForDmlReturning(int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10951 */     int i = 0;
/*       */     
/* 10953 */     switch (paramInt)
/*       */     {
/*       */     case -7: 
/*       */     case -6: 
/*       */     case -5: 
/*       */     case 2: 
/*       */     case 3: 
/*       */     case 4: 
/*       */     case 5: 
/*       */     case 6: 
/*       */     case 7: 
/*       */     case 8: 
/* 10965 */       i = 6;
/* 10966 */       break;
/*       */     
/*       */     case 100: 
/* 10969 */       i = 100;
/* 10970 */       break;
/*       */     
/*       */     case 101: 
/* 10973 */       i = 101;
/* 10974 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case -15: 
/*       */     case 1: 
/* 10982 */       i = 96;
/* 10983 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case -9: 
/*       */     case 12: 
/* 10991 */       i = 1;
/* 10992 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case -16: 
/*       */     case -1: 
/* 11000 */       i = 8;
/* 11001 */       break;
/*       */     
/*       */     case 91: 
/*       */     case 92: 
/* 11005 */       i = 12;
/* 11006 */       break;
/*       */     
/*       */     case 93: 
/* 11009 */       i = 180;
/* 11010 */       break;
/*       */     
/*       */     case -101: 
/* 11013 */       i = 181;
/* 11014 */       break;
/*       */     
/*       */     case -102: 
/* 11017 */       i = 231;
/* 11018 */       break;
/*       */     
/*       */     case -103: 
/* 11021 */       i = 182;
/* 11022 */       break;
/*       */     
/*       */     case -104: 
/* 11025 */       i = 183;
/* 11026 */       break;
/*       */     
/*       */     case -3: 
/*       */     case -2: 
/* 11030 */       i = 23;
/* 11031 */       break;
/*       */     
/*       */     case -4: 
/* 11034 */       i = 24;
/* 11035 */       break;
/*       */     
/*       */     case -8: 
/* 11038 */       i = 104;
/* 11039 */       break;
/*       */     
/*       */     case 2004: 
/* 11042 */       i = 113;
/* 11043 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2005: 
/*       */     case 2011: 
/* 11051 */       i = 112;
/* 11052 */       break;
/*       */     
/*       */     case -13: 
/* 11055 */       i = 114;
/* 11056 */       break;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     case 2002: 
/*       */     case 2003: 
/*       */     case 2007: 
/*       */     case 2008: 
/*       */     case 2009: 
/* 11067 */       i = 109;
/* 11068 */       break;
/*       */     
/*       */     case 2006: 
/* 11071 */       i = 111;
/* 11072 */       break;
/*       */     
/*       */     case 70: 
/* 11075 */       i = 1;
/* 11076 */       break;
/*       */     
/*       */ 
/*       */     default: 
/* 11080 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 11081 */       localSQLException.fillInStackTrace();
/* 11082 */       throw localSQLException;
/*       */     }
/*       */     
/*       */     
/*       */ 
/* 11087 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void registerReturnParamsForAutoKey()
/*       */     throws SQLException
/*       */   {
/* 11095 */     int[] arrayOfInt1 = this.autoKeyInfo.returnTypes;
/* 11096 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 11097 */     int[] arrayOfInt2 = this.autoKeyInfo.columnIndexes;
/*       */     
/* 11099 */     int i = arrayOfInt1.length;
/*       */     
/*       */ 
/* 11102 */     int j = this.numberOfBindPositions - i;
/*       */     
/*       */ 
/* 11105 */     for (int k = 0; k < i; k++)
/*       */     {
/* 11107 */       int m = j + k;
/* 11108 */       this.currentRowBinders[m] = this.theReturnParamBinder;
/*       */       
/* 11110 */       short s = this.connection.defaultnchar ? 2 : 1;
/*       */       
/*       */ 
/* 11113 */       if ((arrayOfShort != null) && (arrayOfInt2 != null))
/*       */       {
/* 11115 */         if (arrayOfShort[(arrayOfInt2[k] - 1)] == 2)
/*       */         {
/*       */ 
/* 11118 */           s = 2;
/* 11119 */           setFormOfUse(m + 1, s);
/*       */         }
/*       */       }
/*       */       
/* 11123 */       checkTypeForAutoKey(arrayOfInt1[k]);
/*       */       
/* 11125 */       String str = null;
/* 11126 */       if (arrayOfInt1[k] == 111) {
/* 11127 */         str = this.autoKeyInfo.tableTypeNames[(arrayOfInt2[k] - 1)];
/*       */       }
/* 11129 */       registerReturnParameterInternal(m, arrayOfInt1[k], arrayOfInt1[k], -1, s, str);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void cleanOldTempLobs()
/*       */   {
/* 11139 */     if ((this.m_batchStyle != 1) || (this.currentRank == this.batch - 1))
/*       */     {
/* 11141 */       super.cleanOldTempLobs();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void resetOnExceptionDuringExecute()
/*       */   {
/* 11148 */     super.resetOnExceptionDuringExecute();
/* 11149 */     this.currentRank = 0;
/* 11150 */     this.currentBatchNeedToPrepareBinds = true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void resetCurrentRowBinders()
/*       */   {
/* 11159 */     Binder[] arrayOfBinder = this.currentRowBinders;
/* 11160 */     if ((this.binders != null) && (this.currentRowBinders != null) && (arrayOfBinder != this.binders[0]))
/*       */     {
/*       */ 
/*       */ 
/* 11164 */       this.currentRowBinders = this.binders[0];
/* 11165 */       this.binders[this.numberOfBoundRows] = arrayOfBinder;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 11184 */     setAsciiStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11199 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 11213 */     setBinaryStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11228 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlob(int paramInt, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 11241 */     setBlobInternal(paramInt, paramInputStream);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11255 */     if (paramLong < 0L)
/*       */     {
/* 11257 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 11258 */       localSQLException.fillInStackTrace();
/* 11259 */       throw localSQLException;
/*       */     }
/* 11261 */     setBlobInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStream(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11275 */     setCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11290 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClob(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11304 */     if (paramLong < 0L)
/*       */     {
/* 11306 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 11307 */       localSQLException.fillInStackTrace();
/* 11308 */       throw localSQLException;
/*       */     }
/* 11310 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClob(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11324 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRowId(int paramInt, RowId paramRowId)
/*       */     throws SQLException
/*       */   {
/* 11339 */     setRowIdInternal(paramInt, paramRowId);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11355 */     setNCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11371 */     setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNClob(int paramInt, NClob paramNClob)
/*       */     throws SQLException
/*       */   {
/* 11386 */     setNClobInternal(paramInt, paramNClob);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNClob(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11402 */     setNClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNClob(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11417 */     setNClobInternal(paramInt, paramReader);
/*       */   }
/*       */   
/*       */ 
/*       */   public void setSQLXML(int paramInt, SQLXML paramSQLXML)
/*       */     throws SQLException
/*       */   {
/* 11424 */     setSQLXMLInternal(paramInt, paramSQLXML);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNString(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/* 11439 */     setNStringInternal(paramInt, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 11447 */     setAsciiStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11455 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 11463 */     setBinaryStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11471 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11480 */     int i = paramInt - 1;
/*       */     
/* 11482 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/* 11484 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11485 */       localSQLException.fillInStackTrace();
/* 11486 */       throw localSQLException;
/*       */     }
/*       */     
/* 11489 */     if (paramInputStream == null) {
/* 11490 */       setNullInternal(paramInt, 2004);
/*       */     } else {
/* 11492 */       setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramLong != -1L);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 11501 */     setBlobInternal(paramInt, paramInputStream, -1L);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11509 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11517 */     setCharacterStreamInternal(paramInt, paramReader, paramLong, true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setClobInternal(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11525 */     setClobInternal(paramInt, paramReader, -1L);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setClobInternal(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11533 */     int i = paramInt - 1;
/*       */     
/* 11535 */     if ((i < 0) || (paramInt > this.numberOfBindPositions))
/*       */     {
/* 11537 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11538 */       localSQLException.fillInStackTrace();
/* 11539 */       throw localSQLException;
/*       */     }
/*       */     
/* 11542 */     if (paramReader == null) {
/* 11543 */       setNullInternal(paramInt, 2005);
/*       */     } else {
/* 11545 */       setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramLong != -1L);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11553 */     setFormOfUse(paramInt, (short)2);
/* 11554 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11562 */     setFormOfUse(paramInt, (short)2);
/* 11563 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNClobInternal(int paramInt, NClob paramNClob)
/*       */     throws SQLException
/*       */   {
/* 11571 */     setFormOfUse(paramInt, (short)2);
/* 11572 */     setClobInternal(paramInt, paramNClob);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNClobInternal(int paramInt, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 11580 */     setFormOfUse(paramInt, (short)2);
/* 11581 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNClobInternal(int paramInt, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11589 */     setFormOfUse(paramInt, (short)2);
/* 11590 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setNStringInternal(int paramInt, String paramString)
/*       */     throws SQLException
/*       */   {
/* 11598 */     setFormOfUse(paramInt, (short)2);
/* 11599 */     setStringInternal(paramInt, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void setRowIdInternal(int paramInt, RowId paramRowId)
/*       */     throws SQLException
/*       */   {
/* 11607 */     setROWIDInternal(paramInt, (ROWID)paramRowId);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setArrayAtName(String paramString, Array paramArray)
/*       */     throws SQLException
/*       */   {
/* 11634 */     String str = paramString.intern();
/* 11635 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11636 */     int i = 0;
/* 11637 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11639 */     for (int k = 0; k < j; k++) {
/* 11640 */       if (arrayOfString[k] == str)
/*       */       {
/* 11642 */         setArray(k + 1, paramArray);
/*       */         
/* 11644 */         i = 1;
/*       */       }
/*       */     }
/* 11647 */     if (i == 0)
/*       */     {
/* 11649 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11650 */       localSQLException.fillInStackTrace();
/* 11651 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/* 11671 */     String str = paramString.intern();
/* 11672 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11673 */     int i = 0;
/* 11674 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11676 */     for (int k = 0; k < j; k++) {
/* 11677 */       if (arrayOfString[k] == str)
/*       */       {
/* 11679 */         setBigDecimal(k + 1, paramBigDecimal);
/*       */         
/* 11681 */         i = 1;
/*       */       }
/*       */     }
/* 11684 */     if (i == 0)
/*       */     {
/* 11686 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11687 */       localSQLException.fillInStackTrace();
/* 11688 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlobAtName(String paramString, Blob paramBlob)
/*       */     throws SQLException
/*       */   {
/* 11708 */     String str = paramString.intern();
/* 11709 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11710 */     int i = 0;
/* 11711 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11713 */     for (int k = 0; k < j; k++) {
/* 11714 */       if (arrayOfString[k] == str)
/*       */       {
/* 11716 */         setBlob(k + 1, paramBlob);
/*       */         
/* 11718 */         i = 1;
/*       */       }
/*       */     }
/* 11721 */     if (i == 0)
/*       */     {
/* 11723 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11724 */       localSQLException.fillInStackTrace();
/* 11725 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBooleanAtName(String paramString, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/* 11745 */     String str = paramString.intern();
/* 11746 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11747 */     int i = 0;
/* 11748 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11750 */     for (int k = 0; k < j; k++) {
/* 11751 */       if (arrayOfString[k] == str)
/*       */       {
/* 11753 */         setBoolean(k + 1, paramBoolean);
/*       */         
/* 11755 */         i = 1;
/*       */       }
/*       */     }
/* 11758 */     if (i == 0)
/*       */     {
/* 11760 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11761 */       localSQLException.fillInStackTrace();
/* 11762 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setByteAtName(String paramString, byte paramByte)
/*       */     throws SQLException
/*       */   {
/* 11782 */     String str = paramString.intern();
/* 11783 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11784 */     int i = 0;
/* 11785 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11787 */     for (int k = 0; k < j; k++) {
/* 11788 */       if (arrayOfString[k] == str)
/*       */       {
/* 11790 */         setByte(k + 1, paramByte);
/*       */         
/* 11792 */         i = 1;
/*       */       }
/*       */     }
/* 11795 */     if (i == 0)
/*       */     {
/* 11797 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11798 */       localSQLException.fillInStackTrace();
/* 11799 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBytesAtName(String paramString, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/* 11819 */     String str = paramString.intern();
/* 11820 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11821 */     int i = 0;
/* 11822 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11824 */     for (int k = 0; k < j; k++) {
/* 11825 */       if (arrayOfString[k] == str)
/*       */       {
/* 11827 */         setBytes(k + 1, paramArrayOfByte);
/*       */         
/* 11829 */         i = 1;
/*       */       }
/*       */     }
/* 11832 */     if (i == 0)
/*       */     {
/* 11834 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11835 */       localSQLException.fillInStackTrace();
/* 11836 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClobAtName(String paramString, Clob paramClob)
/*       */     throws SQLException
/*       */   {
/* 11856 */     String str = paramString.intern();
/* 11857 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11858 */     int i = 0;
/* 11859 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11861 */     for (int k = 0; k < j; k++) {
/* 11862 */       if (arrayOfString[k] == str)
/*       */       {
/* 11864 */         setClob(k + 1, paramClob);
/*       */         
/* 11866 */         i = 1;
/*       */       }
/*       */     }
/* 11869 */     if (i == 0)
/*       */     {
/* 11871 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11872 */       localSQLException.fillInStackTrace();
/* 11873 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDateAtName(String paramString, Date paramDate)
/*       */     throws SQLException
/*       */   {
/* 11893 */     String str = paramString.intern();
/* 11894 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11895 */     int i = 0;
/* 11896 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11898 */     for (int k = 0; k < j; k++) {
/* 11899 */       if (arrayOfString[k] == str)
/*       */       {
/* 11901 */         setDate(k + 1, paramDate);
/*       */         
/* 11903 */         i = 1;
/*       */       }
/*       */     }
/* 11906 */     if (i == 0)
/*       */     {
/* 11908 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11909 */       localSQLException.fillInStackTrace();
/* 11910 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/* 11930 */     String str = paramString.intern();
/* 11931 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11932 */     int i = 0;
/* 11933 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11935 */     for (int k = 0; k < j; k++) {
/* 11936 */       if (arrayOfString[k] == str)
/*       */       {
/* 11938 */         setDate(k + 1, paramDate, paramCalendar);
/*       */         
/* 11940 */         i = 1;
/*       */       }
/*       */     }
/* 11943 */     if (i == 0)
/*       */     {
/* 11945 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11946 */       localSQLException.fillInStackTrace();
/* 11947 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDoubleAtName(String paramString, double paramDouble)
/*       */     throws SQLException
/*       */   {
/* 11967 */     String str = paramString.intern();
/* 11968 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11969 */     int i = 0;
/* 11970 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11972 */     for (int k = 0; k < j; k++) {
/* 11973 */       if (arrayOfString[k] == str)
/*       */       {
/* 11975 */         setDouble(k + 1, paramDouble);
/*       */         
/* 11977 */         i = 1;
/*       */       }
/*       */     }
/* 11980 */     if (i == 0)
/*       */     {
/* 11982 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11983 */       localSQLException.fillInStackTrace();
/* 11984 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFloatAtName(String paramString, float paramFloat)
/*       */     throws SQLException
/*       */   {
/* 12004 */     String str = paramString.intern();
/* 12005 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12006 */     int i = 0;
/* 12007 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12009 */     for (int k = 0; k < j; k++) {
/* 12010 */       if (arrayOfString[k] == str)
/*       */       {
/* 12012 */         setFloat(k + 1, paramFloat);
/*       */         
/* 12014 */         i = 1;
/*       */       }
/*       */     }
/* 12017 */     if (i == 0)
/*       */     {
/* 12019 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12020 */       localSQLException.fillInStackTrace();
/* 12021 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setIntAtName(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 12041 */     String str = paramString.intern();
/* 12042 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12043 */     int i = 0;
/* 12044 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12046 */     for (int k = 0; k < j; k++) {
/* 12047 */       if (arrayOfString[k] == str)
/*       */       {
/* 12049 */         setInt(k + 1, paramInt);
/*       */         
/* 12051 */         i = 1;
/*       */       }
/*       */     }
/* 12054 */     if (i == 0)
/*       */     {
/* 12056 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12057 */       localSQLException.fillInStackTrace();
/* 12058 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setLongAtName(String paramString, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 12078 */     String str = paramString.intern();
/* 12079 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12080 */     int i = 0;
/* 12081 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12083 */     for (int k = 0; k < j; k++) {
/* 12084 */       if (arrayOfString[k] == str)
/*       */       {
/* 12086 */         setLong(k + 1, paramLong);
/*       */         
/* 12088 */         i = 1;
/*       */       }
/*       */     }
/* 12091 */     if (i == 0)
/*       */     {
/* 12093 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12094 */       localSQLException.fillInStackTrace();
/* 12095 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNClobAtName(String paramString, NClob paramNClob)
/*       */     throws SQLException
/*       */   {
/* 12115 */     String str = paramString.intern();
/* 12116 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12117 */     int i = 0;
/* 12118 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12120 */     for (int k = 0; k < j; k++) {
/* 12121 */       if (arrayOfString[k] == str)
/*       */       {
/* 12123 */         setNClob(k + 1, paramNClob);
/*       */         
/* 12125 */         i = 1;
/*       */       }
/*       */     }
/* 12128 */     if (i == 0)
/*       */     {
/* 12130 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12131 */       localSQLException.fillInStackTrace();
/* 12132 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNStringAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/* 12152 */     String str = paramString1.intern();
/* 12153 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12154 */     int i = 0;
/* 12155 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12157 */     for (int k = 0; k < j; k++) {
/* 12158 */       if (arrayOfString[k] == str)
/*       */       {
/* 12160 */         setNString(k + 1, paramString2);
/*       */         
/* 12162 */         i = 1;
/*       */       }
/*       */     }
/* 12165 */     if (i == 0)
/*       */     {
/* 12167 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12168 */       localSQLException.fillInStackTrace();
/* 12169 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObjectAtName(String paramString, Object paramObject)
/*       */     throws SQLException
/*       */   {
/* 12189 */     String str = paramString.intern();
/* 12190 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12191 */     int i = 0;
/* 12192 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12194 */     for (int k = 0; k < j; k++) {
/* 12195 */       if (arrayOfString[k] == str)
/*       */       {
/* 12197 */         setObject(k + 1, paramObject);
/*       */         
/* 12199 */         i = 1;
/*       */       }
/*       */     }
/* 12202 */     if (i == 0)
/*       */     {
/* 12204 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12205 */       localSQLException.fillInStackTrace();
/* 12206 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 12226 */     String str = paramString.intern();
/* 12227 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12228 */     int i = 0;
/* 12229 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12231 */     for (int k = 0; k < j; k++) {
/* 12232 */       if (arrayOfString[k] == str)
/*       */       {
/* 12234 */         setObject(k + 1, paramObject, paramInt);
/*       */         
/* 12236 */         i = 1;
/*       */       }
/*       */     }
/* 12239 */     if (i == 0)
/*       */     {
/* 12241 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12242 */       localSQLException.fillInStackTrace();
/* 12243 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRefAtName(String paramString, Ref paramRef)
/*       */     throws SQLException
/*       */   {
/* 12263 */     String str = paramString.intern();
/* 12264 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12265 */     int i = 0;
/* 12266 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12268 */     for (int k = 0; k < j; k++) {
/* 12269 */       if (arrayOfString[k] == str)
/*       */       {
/* 12271 */         setRef(k + 1, paramRef);
/*       */         
/* 12273 */         i = 1;
/*       */       }
/*       */     }
/* 12276 */     if (i == 0)
/*       */     {
/* 12278 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12279 */       localSQLException.fillInStackTrace();
/* 12280 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRowIdAtName(String paramString, RowId paramRowId)
/*       */     throws SQLException
/*       */   {
/* 12300 */     String str = paramString.intern();
/* 12301 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12302 */     int i = 0;
/* 12303 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12305 */     for (int k = 0; k < j; k++) {
/* 12306 */       if (arrayOfString[k] == str)
/*       */       {
/* 12308 */         setRowId(k + 1, paramRowId);
/*       */         
/* 12310 */         i = 1;
/*       */       }
/*       */     }
/* 12313 */     if (i == 0)
/*       */     {
/* 12315 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12316 */       localSQLException.fillInStackTrace();
/* 12317 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setShortAtName(String paramString, short paramShort)
/*       */     throws SQLException
/*       */   {
/* 12337 */     String str = paramString.intern();
/* 12338 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12339 */     int i = 0;
/* 12340 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12342 */     for (int k = 0; k < j; k++) {
/* 12343 */       if (arrayOfString[k] == str)
/*       */       {
/* 12345 */         setShort(k + 1, paramShort);
/*       */         
/* 12347 */         i = 1;
/*       */       }
/*       */     }
/* 12350 */     if (i == 0)
/*       */     {
/* 12352 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12353 */       localSQLException.fillInStackTrace();
/* 12354 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setSQLXMLAtName(String paramString, SQLXML paramSQLXML)
/*       */     throws SQLException
/*       */   {
/* 12374 */     String str = paramString.intern();
/* 12375 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12376 */     int i = 0;
/* 12377 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12379 */     for (int k = 0; k < j; k++) {
/* 12380 */       if (arrayOfString[k] == str)
/*       */       {
/* 12382 */         setSQLXML(k + 1, paramSQLXML);
/*       */         
/* 12384 */         i = 1;
/*       */       }
/*       */     }
/* 12387 */     if (i == 0)
/*       */     {
/* 12389 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12390 */       localSQLException.fillInStackTrace();
/* 12391 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setStringAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/* 12411 */     String str = paramString1.intern();
/* 12412 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12413 */     int i = 0;
/* 12414 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12416 */     for (int k = 0; k < j; k++) {
/* 12417 */       if (arrayOfString[k] == str)
/*       */       {
/* 12419 */         setString(k + 1, paramString2);
/*       */         
/* 12421 */         i = 1;
/*       */       }
/*       */     }
/* 12424 */     if (i == 0)
/*       */     {
/* 12426 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12427 */       localSQLException.fillInStackTrace();
/* 12428 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimeAtName(String paramString, Time paramTime)
/*       */     throws SQLException
/*       */   {
/* 12448 */     String str = paramString.intern();
/* 12449 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12450 */     int i = 0;
/* 12451 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12453 */     for (int k = 0; k < j; k++) {
/* 12454 */       if (arrayOfString[k] == str)
/*       */       {
/* 12456 */         setTime(k + 1, paramTime);
/*       */         
/* 12458 */         i = 1;
/*       */       }
/*       */     }
/* 12461 */     if (i == 0)
/*       */     {
/* 12463 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12464 */       localSQLException.fillInStackTrace();
/* 12465 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/* 12485 */     String str = paramString.intern();
/* 12486 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12487 */     int i = 0;
/* 12488 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12490 */     for (int k = 0; k < j; k++) {
/* 12491 */       if (arrayOfString[k] == str)
/*       */       {
/* 12493 */         setTime(k + 1, paramTime, paramCalendar);
/*       */         
/* 12495 */         i = 1;
/*       */       }
/*       */     }
/* 12498 */     if (i == 0)
/*       */     {
/* 12500 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12501 */       localSQLException.fillInStackTrace();
/* 12502 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/* 12522 */     String str = paramString.intern();
/* 12523 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12524 */     int i = 0;
/* 12525 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12527 */     for (int k = 0; k < j; k++) {
/* 12528 */       if (arrayOfString[k] == str)
/*       */       {
/* 12530 */         setTimestamp(k + 1, paramTimestamp);
/*       */         
/* 12532 */         i = 1;
/*       */       }
/*       */     }
/* 12535 */     if (i == 0)
/*       */     {
/* 12537 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12538 */       localSQLException.fillInStackTrace();
/* 12539 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/* 12559 */     String str = paramString.intern();
/* 12560 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12561 */     int i = 0;
/* 12562 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12564 */     for (int k = 0; k < j; k++) {
/* 12565 */       if (arrayOfString[k] == str)
/*       */       {
/* 12567 */         setTimestamp(k + 1, paramTimestamp, paramCalendar);
/*       */         
/* 12569 */         i = 1;
/*       */       }
/*       */     }
/* 12572 */     if (i == 0)
/*       */     {
/* 12574 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12575 */       localSQLException.fillInStackTrace();
/* 12576 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setURLAtName(String paramString, URL paramURL)
/*       */     throws SQLException
/*       */   {
/* 12596 */     String str = paramString.intern();
/* 12597 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12598 */     int i = 0;
/* 12599 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12601 */     for (int k = 0; k < j; k++) {
/* 12602 */       if (arrayOfString[k] == str)
/*       */       {
/* 12604 */         setURL(k + 1, paramURL);
/*       */         
/* 12606 */         i = 1;
/*       */       }
/*       */     }
/* 12609 */     if (i == 0)
/*       */     {
/* 12611 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12612 */       localSQLException.fillInStackTrace();
/* 12613 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setARRAYAtName(String paramString, ARRAY paramARRAY)
/*       */     throws SQLException
/*       */   {
/* 12633 */     String str = paramString.intern();
/* 12634 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12635 */     int i = 0;
/* 12636 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12638 */     for (int k = 0; k < j; k++) {
/* 12639 */       if (arrayOfString[k] == str)
/*       */       {
/* 12641 */         setARRAY(k + 1, paramARRAY);
/*       */         
/* 12643 */         i = 1;
/*       */       }
/*       */     }
/* 12646 */     if (i == 0)
/*       */     {
/* 12648 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12649 */       localSQLException.fillInStackTrace();
/* 12650 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBFILEAtName(String paramString, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/* 12670 */     String str = paramString.intern();
/* 12671 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12672 */     int i = 0;
/* 12673 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12675 */     for (int k = 0; k < j; k++) {
/* 12676 */       if (arrayOfString[k] == str)
/*       */       {
/* 12678 */         setBFILE(k + 1, paramBFILE);
/*       */         
/* 12680 */         i = 1;
/*       */       }
/*       */     }
/* 12683 */     if (i == 0)
/*       */     {
/* 12685 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12686 */       localSQLException.fillInStackTrace();
/* 12687 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBfileAtName(String paramString, BFILE paramBFILE)
/*       */     throws SQLException
/*       */   {
/* 12707 */     String str = paramString.intern();
/* 12708 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12709 */     int i = 0;
/* 12710 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12712 */     for (int k = 0; k < j; k++) {
/* 12713 */       if (arrayOfString[k] == str)
/*       */       {
/* 12715 */         setBfile(k + 1, paramBFILE);
/*       */         
/* 12717 */         i = 1;
/*       */       }
/*       */     }
/* 12720 */     if (i == 0)
/*       */     {
/* 12722 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12723 */       localSQLException.fillInStackTrace();
/* 12724 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryFloatAtName(String paramString, float paramFloat)
/*       */     throws SQLException
/*       */   {
/* 12744 */     String str = paramString.intern();
/* 12745 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12746 */     int i = 0;
/* 12747 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12749 */     for (int k = 0; k < j; k++) {
/* 12750 */       if (arrayOfString[k] == str)
/*       */       {
/* 12752 */         setBinaryFloat(k + 1, paramFloat);
/*       */         
/* 12754 */         i = 1;
/*       */       }
/*       */     }
/* 12757 */     if (i == 0)
/*       */     {
/* 12759 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12760 */       localSQLException.fillInStackTrace();
/* 12761 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT)
/*       */     throws SQLException
/*       */   {
/* 12781 */     String str = paramString.intern();
/* 12782 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12783 */     int i = 0;
/* 12784 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12786 */     for (int k = 0; k < j; k++) {
/* 12787 */       if (arrayOfString[k] == str)
/*       */       {
/* 12789 */         setBinaryFloat(k + 1, paramBINARY_FLOAT);
/*       */         
/* 12791 */         i = 1;
/*       */       }
/*       */     }
/* 12794 */     if (i == 0)
/*       */     {
/* 12796 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12797 */       localSQLException.fillInStackTrace();
/* 12798 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDoubleAtName(String paramString, double paramDouble)
/*       */     throws SQLException
/*       */   {
/* 12818 */     String str = paramString.intern();
/* 12819 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12820 */     int i = 0;
/* 12821 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12823 */     for (int k = 0; k < j; k++) {
/* 12824 */       if (arrayOfString[k] == str)
/*       */       {
/* 12826 */         setBinaryDouble(k + 1, paramDouble);
/*       */         
/* 12828 */         i = 1;
/*       */       }
/*       */     }
/* 12831 */     if (i == 0)
/*       */     {
/* 12833 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12834 */       localSQLException.fillInStackTrace();
/* 12835 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE)
/*       */     throws SQLException
/*       */   {
/* 12855 */     String str = paramString.intern();
/* 12856 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12857 */     int i = 0;
/* 12858 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12860 */     for (int k = 0; k < j; k++) {
/* 12861 */       if (arrayOfString[k] == str)
/*       */       {
/* 12863 */         setBinaryDouble(k + 1, paramBINARY_DOUBLE);
/*       */         
/* 12865 */         i = 1;
/*       */       }
/*       */     }
/* 12868 */     if (i == 0)
/*       */     {
/* 12870 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12871 */       localSQLException.fillInStackTrace();
/* 12872 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBLOBAtName(String paramString, BLOB paramBLOB)
/*       */     throws SQLException
/*       */   {
/* 12892 */     String str = paramString.intern();
/* 12893 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12894 */     int i = 0;
/* 12895 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12897 */     for (int k = 0; k < j; k++) {
/* 12898 */       if (arrayOfString[k] == str)
/*       */       {
/* 12900 */         setBLOB(k + 1, paramBLOB);
/*       */         
/* 12902 */         i = 1;
/*       */       }
/*       */     }
/* 12905 */     if (i == 0)
/*       */     {
/* 12907 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12908 */       localSQLException.fillInStackTrace();
/* 12909 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCHARAtName(String paramString, CHAR paramCHAR)
/*       */     throws SQLException
/*       */   {
/* 12929 */     String str = paramString.intern();
/* 12930 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12931 */     int i = 0;
/* 12932 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12934 */     for (int k = 0; k < j; k++) {
/* 12935 */       if (arrayOfString[k] == str)
/*       */       {
/* 12937 */         setCHAR(k + 1, paramCHAR);
/*       */         
/* 12939 */         i = 1;
/*       */       }
/*       */     }
/* 12942 */     if (i == 0)
/*       */     {
/* 12944 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12945 */       localSQLException.fillInStackTrace();
/* 12946 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCLOBAtName(String paramString, CLOB paramCLOB)
/*       */     throws SQLException
/*       */   {
/* 12966 */     String str = paramString.intern();
/* 12967 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12968 */     int i = 0;
/* 12969 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12971 */     for (int k = 0; k < j; k++) {
/* 12972 */       if (arrayOfString[k] == str)
/*       */       {
/* 12974 */         setCLOB(k + 1, paramCLOB);
/*       */         
/* 12976 */         i = 1;
/*       */       }
/*       */     }
/* 12979 */     if (i == 0)
/*       */     {
/* 12981 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12982 */       localSQLException.fillInStackTrace();
/* 12983 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCursorAtName(String paramString, ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/* 13003 */     String str = paramString.intern();
/* 13004 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13005 */     int i = 0;
/* 13006 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13008 */     for (int k = 0; k < j; k++) {
/* 13009 */       if (arrayOfString[k] == str)
/*       */       {
/* 13011 */         setCursor(k + 1, paramResultSet);
/*       */         
/* 13013 */         i = 1;
/*       */       }
/*       */     }
/* 13016 */     if (i == 0)
/*       */     {
/* 13018 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13019 */       localSQLException.fillInStackTrace();
/* 13020 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/* 13040 */     String str = paramString.intern();
/* 13041 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13042 */     int i = 0;
/* 13043 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13045 */     for (int k = 0; k < j; k++) {
/* 13046 */       if (arrayOfString[k] == str)
/*       */       {
/* 13048 */         setCustomDatum(k + 1, paramCustomDatum);
/*       */         
/* 13050 */         i = 1;
/*       */       }
/*       */     }
/* 13053 */     if (i == 0)
/*       */     {
/* 13055 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13056 */       localSQLException.fillInStackTrace();
/* 13057 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDATEAtName(String paramString, DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/* 13077 */     String str = paramString.intern();
/* 13078 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13079 */     int i = 0;
/* 13080 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13082 */     for (int k = 0; k < j; k++) {
/* 13083 */       if (arrayOfString[k] == str)
/*       */       {
/* 13085 */         setDATE(k + 1, paramDATE);
/*       */         
/* 13087 */         i = 1;
/*       */       }
/*       */     }
/* 13090 */     if (i == 0)
/*       */     {
/* 13092 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13093 */       localSQLException.fillInStackTrace();
/* 13094 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setFixedCHARAtName(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/* 13114 */     String str = paramString1.intern();
/* 13115 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13116 */     int i = 0;
/* 13117 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13119 */     for (int k = 0; k < j; k++) {
/* 13120 */       if (arrayOfString[k] == str)
/*       */       {
/* 13122 */         setFixedCHAR(k + 1, paramString2);
/*       */         
/* 13124 */         i = 1;
/*       */       }
/*       */     }
/* 13127 */     if (i == 0)
/*       */     {
/* 13129 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 13130 */       localSQLException.fillInStackTrace();
/* 13131 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS)
/*       */     throws SQLException
/*       */   {
/* 13151 */     String str = paramString.intern();
/* 13152 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13153 */     int i = 0;
/* 13154 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13156 */     for (int k = 0; k < j; k++) {
/* 13157 */       if (arrayOfString[k] == str)
/*       */       {
/* 13159 */         setINTERVALDS(k + 1, paramINTERVALDS);
/*       */         
/* 13161 */         i = 1;
/*       */       }
/*       */     }
/* 13164 */     if (i == 0)
/*       */     {
/* 13166 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13167 */       localSQLException.fillInStackTrace();
/* 13168 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM)
/*       */     throws SQLException
/*       */   {
/* 13188 */     String str = paramString.intern();
/* 13189 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13190 */     int i = 0;
/* 13191 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13193 */     for (int k = 0; k < j; k++) {
/* 13194 */       if (arrayOfString[k] == str)
/*       */       {
/* 13196 */         setINTERVALYM(k + 1, paramINTERVALYM);
/*       */         
/* 13198 */         i = 1;
/*       */       }
/*       */     }
/* 13201 */     if (i == 0)
/*       */     {
/* 13203 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13204 */       localSQLException.fillInStackTrace();
/* 13205 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER)
/*       */     throws SQLException
/*       */   {
/* 13225 */     String str = paramString.intern();
/* 13226 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13227 */     int i = 0;
/* 13228 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13230 */     for (int k = 0; k < j; k++) {
/* 13231 */       if (arrayOfString[k] == str)
/*       */       {
/* 13233 */         setNUMBER(k + 1, paramNUMBER);
/*       */         
/* 13235 */         i = 1;
/*       */       }
/*       */     }
/* 13238 */     if (i == 0)
/*       */     {
/* 13240 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13241 */       localSQLException.fillInStackTrace();
/* 13242 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE)
/*       */     throws SQLException
/*       */   {
/* 13262 */     String str = paramString.intern();
/* 13263 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13264 */     int i = 0;
/* 13265 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13267 */     for (int k = 0; k < j; k++) {
/* 13268 */       if (arrayOfString[k] == str)
/*       */       {
/* 13270 */         setOPAQUE(k + 1, paramOPAQUE);
/*       */         
/* 13272 */         i = 1;
/*       */       }
/*       */     }
/* 13275 */     if (i == 0)
/*       */     {
/* 13277 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13278 */       localSQLException.fillInStackTrace();
/* 13279 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setOracleObjectAtName(String paramString, Datum paramDatum)
/*       */     throws SQLException
/*       */   {
/* 13299 */     String str = paramString.intern();
/* 13300 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13301 */     int i = 0;
/* 13302 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13304 */     for (int k = 0; k < j; k++) {
/* 13305 */       if (arrayOfString[k] == str)
/*       */       {
/* 13307 */         setOracleObject(k + 1, paramDatum);
/*       */         
/* 13309 */         i = 1;
/*       */       }
/*       */     }
/* 13312 */     if (i == 0)
/*       */     {
/* 13314 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13315 */       localSQLException.fillInStackTrace();
/* 13316 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setORADataAtName(String paramString, ORAData paramORAData)
/*       */     throws SQLException
/*       */   {
/* 13336 */     String str = paramString.intern();
/* 13337 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13338 */     int i = 0;
/* 13339 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13341 */     for (int k = 0; k < j; k++) {
/* 13342 */       if (arrayOfString[k] == str)
/*       */       {
/* 13344 */         setORAData(k + 1, paramORAData);
/*       */         
/* 13346 */         i = 1;
/*       */       }
/*       */     }
/* 13349 */     if (i == 0)
/*       */     {
/* 13351 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13352 */       localSQLException.fillInStackTrace();
/* 13353 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRAWAtName(String paramString, RAW paramRAW)
/*       */     throws SQLException
/*       */   {
/* 13373 */     String str = paramString.intern();
/* 13374 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13375 */     int i = 0;
/* 13376 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13378 */     for (int k = 0; k < j; k++) {
/* 13379 */       if (arrayOfString[k] == str)
/*       */       {
/* 13381 */         setRAW(k + 1, paramRAW);
/*       */         
/* 13383 */         i = 1;
/*       */       }
/*       */     }
/* 13386 */     if (i == 0)
/*       */     {
/* 13388 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13389 */       localSQLException.fillInStackTrace();
/* 13390 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setREFAtName(String paramString, REF paramREF)
/*       */     throws SQLException
/*       */   {
/* 13410 */     String str = paramString.intern();
/* 13411 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13412 */     int i = 0;
/* 13413 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13415 */     for (int k = 0; k < j; k++) {
/* 13416 */       if (arrayOfString[k] == str)
/*       */       {
/* 13418 */         setREF(k + 1, paramREF);
/*       */         
/* 13420 */         i = 1;
/*       */       }
/*       */     }
/* 13423 */     if (i == 0)
/*       */     {
/* 13425 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13426 */       localSQLException.fillInStackTrace();
/* 13427 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRefTypeAtName(String paramString, REF paramREF)
/*       */     throws SQLException
/*       */   {
/* 13447 */     String str = paramString.intern();
/* 13448 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13449 */     int i = 0;
/* 13450 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13452 */     for (int k = 0; k < j; k++) {
/* 13453 */       if (arrayOfString[k] == str)
/*       */       {
/* 13455 */         setRefType(k + 1, paramREF);
/*       */         
/* 13457 */         i = 1;
/*       */       }
/*       */     }
/* 13460 */     if (i == 0)
/*       */     {
/* 13462 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13463 */       localSQLException.fillInStackTrace();
/* 13464 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setROWIDAtName(String paramString, ROWID paramROWID)
/*       */     throws SQLException
/*       */   {
/* 13484 */     String str = paramString.intern();
/* 13485 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13486 */     int i = 0;
/* 13487 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13489 */     for (int k = 0; k < j; k++) {
/* 13490 */       if (arrayOfString[k] == str)
/*       */       {
/* 13492 */         setROWID(k + 1, paramROWID);
/*       */         
/* 13494 */         i = 1;
/*       */       }
/*       */     }
/* 13497 */     if (i == 0)
/*       */     {
/* 13499 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13500 */       localSQLException.fillInStackTrace();
/* 13501 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT)
/*       */     throws SQLException
/*       */   {
/* 13521 */     String str = paramString.intern();
/* 13522 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13523 */     int i = 0;
/* 13524 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13526 */     for (int k = 0; k < j; k++) {
/* 13527 */       if (arrayOfString[k] == str)
/*       */       {
/* 13529 */         setSTRUCT(k + 1, paramSTRUCT);
/*       */         
/* 13531 */         i = 1;
/*       */       }
/*       */     }
/* 13534 */     if (i == 0)
/*       */     {
/* 13536 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13537 */       localSQLException.fillInStackTrace();
/* 13538 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*       */     throws SQLException
/*       */   {
/* 13558 */     String str = paramString.intern();
/* 13559 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13560 */     int i = 0;
/* 13561 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13563 */     for (int k = 0; k < j; k++) {
/* 13564 */       if (arrayOfString[k] == str)
/*       */       {
/* 13566 */         setTIMESTAMPLTZ(k + 1, paramTIMESTAMPLTZ);
/*       */         
/* 13568 */         i = 1;
/*       */       }
/*       */     }
/* 13571 */     if (i == 0)
/*       */     {
/* 13573 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13574 */       localSQLException.fillInStackTrace();
/* 13575 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ)
/*       */     throws SQLException
/*       */   {
/* 13595 */     String str = paramString.intern();
/* 13596 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13597 */     int i = 0;
/* 13598 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13600 */     for (int k = 0; k < j; k++) {
/* 13601 */       if (arrayOfString[k] == str)
/*       */       {
/* 13603 */         setTIMESTAMPTZ(k + 1, paramTIMESTAMPTZ);
/*       */         
/* 13605 */         i = 1;
/*       */       }
/*       */     }
/* 13608 */     if (i == 0)
/*       */     {
/* 13610 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13611 */       localSQLException.fillInStackTrace();
/* 13612 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP)
/*       */     throws SQLException
/*       */   {
/* 13632 */     String str = paramString.intern();
/* 13633 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13634 */     int i = 0;
/* 13635 */     int j = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13637 */     for (int k = 0; k < j; k++) {
/* 13638 */       if (arrayOfString[k] == str)
/*       */       {
/* 13640 */         setTIMESTAMP(k + 1, paramTIMESTAMP);
/*       */         
/* 13642 */         i = 1;
/*       */       }
/*       */     }
/* 13645 */     if (i == 0)
/*       */     {
/* 13647 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13648 */       localSQLException.fillInStackTrace();
/* 13649 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 13671 */     String str = paramString.intern();
/* 13672 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13673 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13674 */     int j = 1;
/*       */     
/* 13676 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13678 */       if (arrayOfString[k] == str)
/*       */       {
/* 13680 */         if (j != 0)
/*       */         {
/* 13682 */           setBlob(k + 1, paramInputStream);
/*       */           
/* 13684 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13689 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13690 */           localSQLException2.fillInStackTrace();
/* 13691 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13696 */     if (j != 0)
/*       */     {
/* 13698 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13699 */       localSQLException1.fillInStackTrace();
/* 13700 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 13720 */     String str = paramString.intern();
/* 13721 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13722 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13723 */     int j = 1;
/*       */     
/* 13725 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13727 */       if (arrayOfString[k] == str)
/*       */       {
/* 13729 */         if (j != 0)
/*       */         {
/* 13731 */           setBlob(k + 1, paramInputStream, paramLong);
/*       */           
/* 13733 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13738 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13739 */           localSQLException2.fillInStackTrace();
/* 13740 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13745 */     if (j != 0)
/*       */     {
/* 13747 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13748 */       localSQLException1.fillInStackTrace();
/* 13749 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClobAtName(String paramString, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 13769 */     String str = paramString.intern();
/* 13770 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13771 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13772 */     int j = 1;
/*       */     
/* 13774 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13776 */       if (arrayOfString[k] == str)
/*       */       {
/* 13778 */         if (j != 0)
/*       */         {
/* 13780 */           setClob(k + 1, paramReader);
/*       */           
/* 13782 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13787 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13788 */           localSQLException2.fillInStackTrace();
/* 13789 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13794 */     if (j != 0)
/*       */     {
/* 13796 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13797 */       localSQLException1.fillInStackTrace();
/* 13798 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setClobAtName(String paramString, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 13818 */     String str = paramString.intern();
/* 13819 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13820 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13821 */     int j = 1;
/*       */     
/* 13823 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13825 */       if (arrayOfString[k] == str)
/*       */       {
/* 13827 */         if (j != 0)
/*       */         {
/* 13829 */           setClob(k + 1, paramReader, paramLong);
/*       */           
/* 13831 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13836 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13837 */           localSQLException2.fillInStackTrace();
/* 13838 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13843 */     if (j != 0)
/*       */     {
/* 13845 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13846 */       localSQLException1.fillInStackTrace();
/* 13847 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNClobAtName(String paramString, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 13867 */     String str = paramString.intern();
/* 13868 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13869 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13870 */     int j = 1;
/*       */     
/* 13872 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13874 */       if (arrayOfString[k] == str)
/*       */       {
/* 13876 */         if (j != 0)
/*       */         {
/* 13878 */           setNClob(k + 1, paramReader);
/*       */           
/* 13880 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13885 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13886 */           localSQLException2.fillInStackTrace();
/* 13887 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13892 */     if (j != 0)
/*       */     {
/* 13894 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13895 */       localSQLException1.fillInStackTrace();
/* 13896 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNClobAtName(String paramString, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 13916 */     String str = paramString.intern();
/* 13917 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13918 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13919 */     int j = 1;
/*       */     
/* 13921 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13923 */       if (arrayOfString[k] == str)
/*       */       {
/* 13925 */         if (j != 0)
/*       */         {
/* 13927 */           setNClob(k + 1, paramReader, paramLong);
/*       */           
/* 13929 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13934 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13935 */           localSQLException2.fillInStackTrace();
/* 13936 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13941 */     if (j != 0)
/*       */     {
/* 13943 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13944 */       localSQLException1.fillInStackTrace();
/* 13945 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 13965 */     String str = paramString.intern();
/* 13966 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13967 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13968 */     int j = 1;
/*       */     
/* 13970 */     for (int k = 0; k < i; k++)
/*       */     {
/* 13972 */       if (arrayOfString[k] == str)
/*       */       {
/* 13974 */         if (j != 0)
/*       */         {
/* 13976 */           setAsciiStream(k + 1, paramInputStream);
/*       */           
/* 13978 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 13983 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13984 */           localSQLException2.fillInStackTrace();
/* 13985 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 13990 */     if (j != 0)
/*       */     {
/* 13992 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13993 */       localSQLException1.fillInStackTrace();
/* 13994 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 14014 */     String str = paramString.intern();
/* 14015 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14016 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14017 */     int j = 1;
/*       */     
/* 14019 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14021 */       if (arrayOfString[k] == str)
/*       */       {
/* 14023 */         if (j != 0)
/*       */         {
/* 14025 */           setAsciiStream(k + 1, paramInputStream, paramInt);
/*       */           
/* 14027 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14032 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14033 */           localSQLException2.fillInStackTrace();
/* 14034 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14039 */     if (j != 0)
/*       */     {
/* 14041 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14042 */       localSQLException1.fillInStackTrace();
/* 14043 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 14063 */     String str = paramString.intern();
/* 14064 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14065 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14066 */     int j = 1;
/*       */     
/* 14068 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14070 */       if (arrayOfString[k] == str)
/*       */       {
/* 14072 */         if (j != 0)
/*       */         {
/* 14074 */           setAsciiStream(k + 1, paramInputStream, paramLong);
/*       */           
/* 14076 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14081 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14082 */           localSQLException2.fillInStackTrace();
/* 14083 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14088 */     if (j != 0)
/*       */     {
/* 14090 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14091 */       localSQLException1.fillInStackTrace();
/* 14092 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream)
/*       */     throws SQLException
/*       */   {
/* 14112 */     String str = paramString.intern();
/* 14113 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14114 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14115 */     int j = 1;
/*       */     
/* 14117 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14119 */       if (arrayOfString[k] == str)
/*       */       {
/* 14121 */         if (j != 0)
/*       */         {
/* 14123 */           setBinaryStream(k + 1, paramInputStream);
/*       */           
/* 14125 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14130 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14131 */           localSQLException2.fillInStackTrace();
/* 14132 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14137 */     if (j != 0)
/*       */     {
/* 14139 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14140 */       localSQLException1.fillInStackTrace();
/* 14141 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 14161 */     String str = paramString.intern();
/* 14162 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14163 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14164 */     int j = 1;
/*       */     
/* 14166 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14168 */       if (arrayOfString[k] == str)
/*       */       {
/* 14170 */         if (j != 0)
/*       */         {
/* 14172 */           setBinaryStream(k + 1, paramInputStream, paramInt);
/*       */           
/* 14174 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14179 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14180 */           localSQLException2.fillInStackTrace();
/* 14181 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14186 */     if (j != 0)
/*       */     {
/* 14188 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14189 */       localSQLException1.fillInStackTrace();
/* 14190 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 14210 */     String str = paramString.intern();
/* 14211 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14212 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14213 */     int j = 1;
/*       */     
/* 14215 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14217 */       if (arrayOfString[k] == str)
/*       */       {
/* 14219 */         if (j != 0)
/*       */         {
/* 14221 */           setBinaryStream(k + 1, paramInputStream, paramLong);
/*       */           
/* 14223 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14228 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14229 */           localSQLException2.fillInStackTrace();
/* 14230 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14235 */     if (j != 0)
/*       */     {
/* 14237 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14238 */       localSQLException1.fillInStackTrace();
/* 14239 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 14259 */     String str = paramString.intern();
/* 14260 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14261 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14262 */     int j = 1;
/*       */     
/* 14264 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14266 */       if (arrayOfString[k] == str)
/*       */       {
/* 14268 */         if (j != 0)
/*       */         {
/* 14270 */           setCharacterStream(k + 1, paramReader);
/*       */           
/* 14272 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14277 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14278 */           localSQLException2.fillInStackTrace();
/* 14279 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14284 */     if (j != 0)
/*       */     {
/* 14286 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14287 */       localSQLException1.fillInStackTrace();
/* 14288 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 14308 */     String str = paramString.intern();
/* 14309 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14310 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14311 */     int j = 1;
/*       */     
/* 14313 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14315 */       if (arrayOfString[k] == str)
/*       */       {
/* 14317 */         if (j != 0)
/*       */         {
/* 14319 */           setCharacterStream(k + 1, paramReader, paramInt);
/*       */           
/* 14321 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14326 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14327 */           localSQLException2.fillInStackTrace();
/* 14328 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14333 */     if (j != 0)
/*       */     {
/* 14335 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14336 */       localSQLException1.fillInStackTrace();
/* 14337 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 14357 */     String str = paramString.intern();
/* 14358 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14359 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14360 */     int j = 1;
/*       */     
/* 14362 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14364 */       if (arrayOfString[k] == str)
/*       */       {
/* 14366 */         if (j != 0)
/*       */         {
/* 14368 */           setCharacterStream(k + 1, paramReader, paramLong);
/*       */           
/* 14370 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14375 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14376 */           localSQLException2.fillInStackTrace();
/* 14377 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14382 */     if (j != 0)
/*       */     {
/* 14384 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14385 */       localSQLException1.fillInStackTrace();
/* 14386 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader)
/*       */     throws SQLException
/*       */   {
/* 14406 */     String str = paramString.intern();
/* 14407 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14408 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14409 */     int j = 1;
/*       */     
/* 14411 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14413 */       if (arrayOfString[k] == str)
/*       */       {
/* 14415 */         if (j != 0)
/*       */         {
/* 14417 */           setNCharacterStream(k + 1, paramReader);
/*       */           
/* 14419 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14424 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14425 */           localSQLException2.fillInStackTrace();
/* 14426 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14431 */     if (j != 0)
/*       */     {
/* 14433 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14434 */       localSQLException1.fillInStackTrace();
/* 14435 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader, long paramLong)
/*       */     throws SQLException
/*       */   {
/* 14455 */     String str = paramString.intern();
/* 14456 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14457 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14458 */     int j = 1;
/*       */     
/* 14460 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14462 */       if (arrayOfString[k] == str)
/*       */       {
/* 14464 */         if (j != 0)
/*       */         {
/* 14466 */           setNCharacterStream(k + 1, paramReader, paramLong);
/*       */           
/* 14468 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14473 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14474 */           localSQLException2.fillInStackTrace();
/* 14475 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14480 */     if (j != 0)
/*       */     {
/* 14482 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14483 */       localSQLException1.fillInStackTrace();
/* 14484 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt)
/*       */     throws SQLException
/*       */   {
/* 14504 */     String str = paramString.intern();
/* 14505 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14506 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14507 */     int j = 1;
/*       */     
/* 14509 */     for (int k = 0; k < i; k++)
/*       */     {
/* 14511 */       if (arrayOfString[k] == str)
/*       */       {
/* 14513 */         if (j != 0)
/*       */         {
/* 14515 */           setUnicodeStream(k + 1, paramInputStream, paramInt);
/*       */           
/* 14517 */           j = 0;
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/* 14522 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14523 */           localSQLException2.fillInStackTrace();
/* 14524 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */     }
/*       */     
/* 14529 */     if (j != 0)
/*       */     {
/* 14531 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14532 */       localSQLException1.fillInStackTrace();
/* 14533 */       throw localSQLException1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 14542 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*       */   public static final boolean TRACE = false;
/*       */   
/*       */   class PushedBatch
/*       */   {
/*       */     int[] currentBatchCharLens;
/*       */     int[] lastBoundCharLens;
/*       */     Accessor[] currentBatchBindAccessors;
/*       */     boolean lastBoundNeeded;
/*       */     boolean need_to_parse;
/*       */     boolean current_batch_need_to_prepare_binds;
/*       */     int first_row_in_batch;
/*       */     int number_of_rows_to_be_bound;
/*       */     PushedBatch next;
/*       */     
/*       */     PushedBatch() {}
/*       */   }
/*       */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\OraclePreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */