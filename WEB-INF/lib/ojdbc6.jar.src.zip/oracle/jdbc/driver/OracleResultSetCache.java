package oracle.jdbc.driver;

public abstract interface OracleResultSetCache
  extends oracle.jdbc.internal.OracleResultSetCache
{}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\OracleResultSetCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */