/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleSavepoint
/*     */   implements oracle.jdbc.OracleSavepoint
/*     */ {
/*     */   private static final int MAX_ID_VALUE = 65535;
/*     */   private static final int INVALID_ID_VALUE = -1;
/*     */   static final int NAMED_SAVEPOINT_TYPE = 2;
/*     */   static final int UNNAMED_SAVEPOINT_TYPE = 1;
/*     */   static final int UNKNOWN_SAVEPOINT_TYPE = 0;
/*  32 */   private static int s_seedId = 0;
/*  33 */   private int m_id = -1;
/*  34 */   private String m_name = null;
/*  35 */   private int m_type = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OracleSavepoint()
/*     */   {
/*  46 */     this.m_type = 1;
/*  47 */     this.m_id = getNextId();
/*  48 */     this.m_name = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OracleSavepoint(String paramString)
/*     */     throws SQLException
/*     */   {
/*  62 */     if ((paramString != null) && (paramString.length() != 0) && (!OracleSql.isValidObjectName(paramString)))
/*     */     {
/*     */ 
/*     */ 
/*  66 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  67 */       localSQLException.fillInStackTrace();
/*  68 */       throw localSQLException;
/*     */     }
/*     */     
/*  71 */     this.m_type = 2;
/*  72 */     this.m_name = paramString;
/*  73 */     this.m_id = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSavepointId()
/*     */     throws SQLException
/*     */   {
/*  90 */     if (this.m_type == 2)
/*     */     {
/*  92 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 118);
/*  93 */       localSQLException.fillInStackTrace();
/*  94 */       throw localSQLException;
/*     */     }
/*     */     
/*  97 */     return this.m_id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSavepointName()
/*     */     throws SQLException
/*     */   {
/* 114 */     if (this.m_type == 1)
/*     */     {
/* 116 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 119);
/* 117 */       localSQLException.fillInStackTrace();
/* 118 */       throw localSQLException;
/*     */     }
/*     */     
/* 121 */     return this.m_name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getType()
/*     */   {
/* 132 */     return this.m_type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized int getNextId()
/*     */   {
/* 139 */     s_seedId = (s_seedId + 1) % 65535;
/*     */     
/* 141 */     return s_seedId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 156 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 161 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\OracleSavepoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */