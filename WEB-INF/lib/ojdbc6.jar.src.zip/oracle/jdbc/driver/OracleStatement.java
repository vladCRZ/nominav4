/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleStatement
/*      */   implements oracle.jdbc.internal.OracleStatement, ScrollRsetStatement
/*      */ {
/*      */   static final int PLAIN_STMT = 0;
/*      */   static final int PREP_STMT = 1;
/*      */   static final int CALL_STMT = 2;
/*      */   int cursorId;
/*      */   int numberOfDefinePositions;
/*      */   int definesBatchSize;
/*      */   Accessor[] accessors;
/*      */   int defineByteSubRange;
/*      */   int defineCharSubRange;
/*      */   int defineIndicatorSubRange;
/*      */   int defineLengthSubRange;
/*      */   byte[] defineBytes;
/*      */   char[] defineChars;
/*      */   short[] defineIndicators;
/*      */   
/*      */   abstract void doDescribe(boolean paramBoolean)
/*      */     throws SQLException;
/*      */   
/*      */   abstract void executeForDescribe()
/*      */     throws SQLException;
/*      */   
/*      */   abstract void executeForRows(boolean paramBoolean)
/*      */     throws SQLException;
/*      */   
/*      */   abstract void fetch()
/*      */     throws SQLException;
/*      */   
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  292 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
/*  293 */     localSQLException.fillInStackTrace();
/*  294 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract void doClose()
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   abstract void closeQuery()
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int cursorIfRefCursor()
/*      */     throws SQLException
/*      */   {
/*  330 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
/*  331 */     localSQLException.fillInStackTrace();
/*  332 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  357 */   boolean described = false;
/*  358 */   boolean describedWithNames = false;
/*      */   
/*      */ 
/*      */   byte[] defineMetaData;
/*      */   
/*      */ 
/*      */   int defineMetaDataSubRange;
/*      */   
/*      */ 
/*      */   static final int METADATALENGTH = 1;
/*      */   
/*      */ 
/*      */   int rowsProcessed;
/*      */   
/*      */ 
/*  373 */   int cachedDefineByteSize = 0;
/*  374 */   int cachedDefineCharSize = 0;
/*  375 */   int cachedDefineIndicatorSize = 0;
/*  376 */   int cachedDefineMetaDataSize = 0;
/*      */   
/*      */ 
/*  379 */   OracleStatement children = null;
/*  380 */   OracleStatement parent = null;
/*      */   
/*      */ 
/*  383 */   OracleStatement nextChild = null;
/*      */   
/*      */ 
/*      */   OracleStatement next;
/*      */   
/*      */ 
/*      */   OracleStatement prev;
/*      */   
/*      */ 
/*      */   long c_state;
/*      */   
/*      */ 
/*      */   int numberOfBindPositions;
/*      */   
/*      */ 
/*      */   byte[] bindBytes;
/*      */   
/*      */ 
/*      */   char[] bindChars;
/*      */   
/*      */ 
/*      */   short[] bindIndicators;
/*      */   
/*      */   int bindByteOffset;
/*      */   
/*      */   int bindCharOffset;
/*      */   
/*      */   int bindIndicatorOffset;
/*      */   
/*      */   int bindByteSubRange;
/*      */   
/*      */   int bindCharSubRange;
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   Object[][] userStream;
/*      */   
/*      */   int firstRowInBatch;
/*      */   
/*  426 */   boolean hasIbtBind = false;
/*      */   
/*      */ 
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */ 
/*      */   char[] ibtBindChars;
/*      */   
/*      */ 
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */ 
/*      */   int ibtBindByteOffset;
/*      */   
/*      */ 
/*      */   int ibtBindCharOffset;
/*      */   
/*      */ 
/*      */   int ibtBindIndicatorOffset;
/*      */   
/*      */ 
/*      */   int ibtBindIndicatorSize;
/*      */   
/*  449 */   ByteBuffer[] nioBuffers = null;
/*  450 */   Object[] lobPrefetchMetaData = null;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean hasStream;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] tmpByteArray;
/*      */   
/*      */ 
/*  461 */   int sizeTmpByteArray = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   byte[] tmpBindsByteArray;
/*      */   
/*      */ 
/*      */ 
/*  469 */   boolean needToSendOalToFetch = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  476 */   int[] definedColumnType = null;
/*  477 */   int[] definedColumnSize = null;
/*  478 */   int[] definedColumnFormOfUse = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  484 */   T4CTTIoac[] oacdefSent = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  491 */   int[] nbPostPonedColumns = null;
/*  492 */   int[][] indexOfPostPonedColumn = (int[][])null;
/*      */   
/*      */ 
/*      */ 
/*  496 */   boolean aFetchWasDoneDuringDescribe = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  503 */   boolean implicitDefineForLobPrefetchDone = false;
/*      */   
/*  505 */   long checkSum = 0L;
/*  506 */   boolean checkSumComputationFailure = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  528 */   int accessorByteOffset = 0;
/*  529 */   int accessorCharOffset = 0;
/*  530 */   int accessorShortOffset = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int VALID_ROWS_UNINIT = -999;
/*      */   
/*      */ 
/*      */ 
/*      */   PhysicalConnection connection;
/*      */   
/*      */ 
/*      */   OracleInputStream streamList;
/*      */   
/*      */ 
/*      */   OracleInputStream nextStream;
/*      */   
/*      */ 
/*      */   OracleResultSetImpl currentResultSet;
/*      */   
/*      */ 
/*      */   boolean processEscapes;
/*      */   
/*      */ 
/*      */   boolean convertNcharLiterals;
/*      */   
/*      */ 
/*      */   int queryTimeout;
/*      */   
/*      */ 
/*      */   int batch;
/*      */   
/*      */ 
/*  562 */   int numberOfExecutedElementsInBatch = -1;
/*      */   
/*      */   int currentRank;
/*      */   
/*      */   int currentRow;
/*      */   
/*      */   int validRows;
/*      */   
/*      */   int maxFieldSize;
/*      */   
/*      */   int maxRows;
/*      */   
/*      */   int totalRowsVisited;
/*      */   
/*      */   int rowPrefetch;
/*      */   
/*  578 */   int rowPrefetchInLastFetch = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int defaultRowPrefetch;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean rowPrefetchChanged;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int defaultLobPrefetchSize;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean gotLastBatch;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean clearParameters;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean closed;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean sqlStringChanged;
/*      */   
/*      */ 
/*      */ 
/*      */   OracleSql sqlObject;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean needToParse;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean needToPrepareDefineBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean columnsDefinedByUser;
/*      */   
/*      */ 
/*      */ 
/*  629 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.SELECT;
/*  630 */   byte sqlKindByte = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   int autoRollback;
/*      */   
/*      */ 
/*      */ 
/*      */   int defaultFetchDirection;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean serverCursor;
/*      */   
/*      */ 
/*      */ 
/*  646 */   boolean fixedString = false;
/*      */   
/*      */ 
/*  649 */   boolean noMoreUpdateCounts = false;
/*      */   
/*      */ 
/*  652 */   boolean isExecuting = false;
/*      */   
/*      */   OracleStatementWrapper wrapper;
/*      */   
/*      */   static final byte EXECUTE_NONE = -1;
/*      */   
/*      */   static final byte EXECUTE_QUERY = 1;
/*      */   
/*      */   static final byte EXECUTE_UPDATE = 2;
/*      */   
/*      */   static final byte EXECUTE_NORMAL = 3;
/*  663 */   byte executionType = -1;
/*      */   
/*      */ 
/*      */   OracleResultSet scrollRset;
/*      */   
/*      */ 
/*      */   oracle.jdbc.OracleResultSetCache rsetCache;
/*      */   
/*      */   int userRsetType;
/*      */   
/*      */   int realRsetType;
/*      */   
/*      */   boolean needToAddIdentifier;
/*      */   
/*      */   SQLWarning sqlWarning;
/*      */   
/*  679 */   int cacheState = 3;
/*      */   
/*      */ 
/*  682 */   int creationState = 0;
/*      */   
/*  684 */   boolean isOpen = false;
/*      */   
/*      */ 
/*      */ 
/*  688 */   int statementType = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  694 */   boolean columnSetNull = false;
/*      */   
/*      */   int[] returnParamMeta;
/*      */   
/*      */   static final int DMLR_METADATA_PREFIX_SIZE = 3;
/*      */   
/*      */   static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
/*      */   
/*      */   static final int DMLR_METADATA_TYPE_OFFSET = 0;
/*      */   
/*      */   static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
/*      */   
/*      */   static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
/*      */   
/*      */   static final int DMLR_METADATA_FORM_OF_USE_OFFSET = 3;
/*      */   
/*      */   static final int DMLR_METADATA_PER_POSITION_SIZE = 4;
/*      */   
/*      */   Accessor[] returnParamAccessors;
/*      */   
/*      */   boolean returnParamsFetched;
/*      */   
/*      */   int rowsDmlReturned;
/*      */   
/*      */   int numReturnParams;
/*      */   
/*      */   byte[] returnParamBytes;
/*      */   char[] returnParamChars;
/*      */   short[] returnParamIndicators;
/*      */   int returnParamRowBytes;
/*      */   int returnParamRowChars;
/*      */   OracleReturnResultSet returnResultSet;
/*      */   boolean isAutoGeneratedKey;
/*      */   AutoKeyInfo autoKeyInfo;
/*  732 */   TimeZone defaultTimeZone = null;
/*  733 */   String defaultTimeZoneName = null;
/*      */   
/*  735 */   Calendar defaultCalendar = null;
/*  736 */   Calendar gmtCalendar = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  748 */   long inScn = 0L;
/*      */   int lastIndex;
/*      */   
/*      */   public void setSnapshotSCN(long paramLong) throws SQLException {
/*  752 */     doSetSnapshotSCN(paramLong);
/*      */   }
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  758 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  759 */     localSQLException.fillInStackTrace();
/*  760 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  782 */     this(paramPhysicalConnection, paramInt1, paramInt2, -1, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */     throws SQLException
/*      */   {
/*  797 */     this.connection = paramPhysicalConnection;
/*      */     
/*  799 */     this.connection.needLine();
/*      */     
/*      */ 
/*      */ 
/*  803 */     this.connection.registerHeartbeat();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  808 */     this.connection.addStatement(this);
/*      */     
/*  810 */     this.sqlObject = new OracleSql(this.connection.conversion);
/*      */     
/*      */ 
/*      */ 
/*  814 */     this.processEscapes = this.connection.processEscapes;
/*  815 */     this.convertNcharLiterals = this.connection.convertNcharLiterals;
/*  816 */     this.autoRollback = 2;
/*  817 */     this.gotLastBatch = false;
/*  818 */     this.closed = false;
/*  819 */     this.clearParameters = true;
/*  820 */     this.serverCursor = false;
/*  821 */     this.needToAddIdentifier = false;
/*  822 */     this.defaultFetchDirection = 1000;
/*  823 */     this.fixedString = this.connection.getDefaultFixedString();
/*  824 */     this.rowPrefetchChanged = false;
/*  825 */     this.rowPrefetch = paramInt2;
/*  826 */     this.defaultRowPrefetch = paramInt2;
/*  827 */     if (this.connection.getVersionNumber() >= 11000) {
/*  828 */       this.defaultLobPrefetchSize = this.connection.defaultLobPrefetchSize;
/*      */     } else
/*  830 */       this.defaultLobPrefetchSize = -1;
/*  831 */     this.batch = paramInt1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  837 */     this.sqlStringChanged = true;
/*  838 */     this.needToParse = true;
/*  839 */     this.needToPrepareDefineBuffer = true;
/*  840 */     this.columnsDefinedByUser = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  848 */     if ((paramInt3 != -1) || (paramInt4 != -1))
/*      */     {
/*  850 */       this.realRsetType = 0;
/*  851 */       this.userRsetType = ResultSetUtil.getRsetTypeCode(paramInt3, paramInt4);
/*      */       
/*      */ 
/*  854 */       this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType);
/*      */     }
/*      */     else
/*      */     {
/*  858 */       this.userRsetType = 1;
/*  859 */       this.realRsetType = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initializeDefineSubRanges()
/*      */   {
/*  882 */     this.defineByteSubRange = 0;
/*  883 */     this.defineCharSubRange = 0;
/*  884 */     this.defineIndicatorSubRange = 0;
/*  885 */     this.defineMetaDataSubRange = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareDefinePreambles() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareAccessors()
/*      */     throws SQLException
/*      */   {
/*  918 */     byte[] arrayOfByte1 = null;
/*  919 */     char[] arrayOfChar = null;
/*  920 */     short[] arrayOfShort = null;
/*  921 */     boolean bool = false;
/*  922 */     byte[] arrayOfByte2 = null;
/*      */     
/*  924 */     if (this.accessors == null)
/*      */     {
/*  926 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  927 */       localSQLException1.fillInStackTrace();
/*  928 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  934 */     int i = 0;
/*  935 */     int j = 0;
/*  936 */     int k = 0;
/*  937 */     Accessor localAccessor; for (int m = 0; m < this.numberOfDefinePositions; m++)
/*      */     {
/*  939 */       localAccessor = this.accessors[m];
/*      */       
/*  941 */       if (localAccessor == null)
/*      */       {
/*  943 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  944 */         localSQLException2.fillInStackTrace();
/*  945 */         throw localSQLException2;
/*      */       }
/*  947 */       switch (localAccessor.internalType)
/*      */       {
/*      */       case 8: 
/*      */       case 24: 
/*  951 */         this.hasStream = true;
/*      */       }
/*      */       
/*      */       
/*  955 */       i += localAccessor.byteLength;
/*  956 */       j += localAccessor.charLength;
/*  957 */       k += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  962 */     if ((this.streamList != null) && (!this.connection.useFetchSizeWithLongColumn)) {
/*  963 */       this.rowPrefetch = 1;
/*      */     }
/*  965 */     m = this.rowPrefetch;
/*      */     
/*  967 */     this.definesBatchSize = m;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  975 */     initializeDefineSubRanges();
/*      */     
/*      */ 
/*  978 */     int n = k * m;
/*  979 */     if ((this.defineMetaData == null) || (this.defineMetaData.length < n))
/*      */     {
/*  981 */       if (this.defineMetaData != null)
/*  982 */         arrayOfByte2 = this.defineMetaData;
/*  983 */       this.defineMetaData = new byte[n];
/*      */     }
/*      */     
/*      */ 
/*  987 */     this.cachedDefineByteSize = (this.defineByteSubRange + i * m);
/*      */     
/*  989 */     if ((this.defineBytes == null) || (this.defineBytes.length < this.cachedDefineByteSize))
/*      */     {
/*  991 */       if (this.defineBytes != null) arrayOfByte1 = this.defineBytes;
/*  992 */       this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
/*      */     }
/*      */     
/*  995 */     this.defineByteSubRange += this.accessorByteOffset;
/*      */     
/*      */ 
/*  998 */     this.cachedDefineCharSize = (this.defineCharSubRange + j * m);
/*      */     
/* 1000 */     if (((this.defineChars == null) || (this.defineChars.length < this.cachedDefineCharSize)) && (this.cachedDefineCharSize > 0))
/*      */     {
/*      */ 
/* 1003 */       if (this.defineChars != null) { arrayOfChar = this.defineChars;
/*      */       }
/* 1005 */       this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
/*      */     }
/*      */     
/* 1008 */     this.defineCharSubRange += this.accessorCharOffset;
/*      */     
/*      */ 
/*      */ 
/* 1012 */     int i1 = this.numberOfDefinePositions * m;
/* 1013 */     int i2 = this.defineIndicatorSubRange + i1 + i1;
/*      */     
/*      */ 
/* 1016 */     if ((this.defineIndicators == null) || (this.defineIndicators.length < i2))
/*      */     {
/*      */ 
/* 1019 */       if (this.defineIndicators != null) arrayOfShort = this.defineIndicators;
/* 1020 */       this.defineIndicators = new short[i2];
/* 1021 */     } else if (this.defineIndicators.length >= i2)
/*      */     {
/* 1023 */       bool = true;
/* 1024 */       arrayOfShort = this.defineIndicators;
/*      */     }
/*      */     
/* 1027 */     this.defineIndicatorSubRange += this.accessorShortOffset;
/*      */     
/* 1029 */     int i3 = this.defineIndicatorSubRange + i1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1035 */     for (int i4 = 0; i4 < this.numberOfDefinePositions; i4++)
/*      */     {
/* 1037 */       localAccessor = this.accessors[i4];
/*      */       
/* 1039 */       localAccessor.lengthIndexLastRow = localAccessor.lengthIndex;
/* 1040 */       localAccessor.indicatorIndexLastRow = localAccessor.indicatorIndex;
/* 1041 */       localAccessor.columnIndexLastRow = localAccessor.columnIndex;
/*      */       
/* 1043 */       localAccessor.setOffsets(m);
/*      */       
/* 1045 */       localAccessor.lengthIndex = i3;
/* 1046 */       localAccessor.indicatorIndex = this.defineIndicatorSubRange;
/* 1047 */       localAccessor.metaDataIndex = this.defineMetaDataSubRange;
/* 1048 */       localAccessor.rowSpaceByte = this.defineBytes;
/* 1049 */       localAccessor.rowSpaceChar = this.defineChars;
/* 1050 */       localAccessor.rowSpaceIndicator = this.defineIndicators;
/* 1051 */       localAccessor.rowSpaceMetaData = this.defineMetaData;
/* 1052 */       this.defineIndicatorSubRange += m;
/* 1053 */       i3 += m;
/* 1054 */       this.defineMetaDataSubRange += m * 1;
/*      */     }
/*      */     
/* 1057 */     prepareDefinePreambles();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1065 */     if ((this.rowPrefetchInLastFetch != -1) && (this.rowPrefetch != this.rowPrefetchInLastFetch))
/*      */     {
/* 1067 */       if (arrayOfChar == null) arrayOfChar = this.defineChars;
/* 1068 */       if (arrayOfByte1 == null) arrayOfByte1 = this.defineBytes;
/* 1069 */       if (arrayOfShort == null) arrayOfShort = this.defineIndicators;
/* 1070 */       saveDefineBuffersIfRequired(arrayOfChar, arrayOfByte1, arrayOfShort, bool);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean checkAccessorsUsable()
/*      */     throws SQLException
/*      */   {
/* 1086 */     int i = this.accessors.length;
/*      */     
/* 1088 */     if (i < this.numberOfDefinePositions) {
/* 1089 */       return false;
/*      */     }
/* 1091 */     int j = 1;
/* 1092 */     int k = 0;
/* 1093 */     boolean bool = false;
/*      */     
/* 1095 */     for (int m = 0; m < this.numberOfDefinePositions; m++)
/*      */     {
/* 1097 */       Accessor localAccessor = this.accessors[m];
/*      */       
/* 1099 */       if ((localAccessor == null) || (localAccessor.externalType == 0)) {
/* 1100 */         j = 0;
/*      */       } else {
/* 1102 */         k = 1;
/*      */       }
/*      */     }
/* 1105 */     if (j != 0)
/*      */     {
/*      */ 
/* 1108 */       bool = true;
/* 1109 */     } else { if (k != 0)
/*      */       {
/*      */ 
/*      */ 
/* 1113 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1114 */         localSQLException.fillInStackTrace();
/* 1115 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1121 */       this.columnsDefinedByUser = false;
/*      */     }
/* 1123 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeMaybeDescribe()
/*      */     throws SQLException
/*      */   {
/* 1132 */     int i = 1;
/*      */     
/* 1134 */     if (this.rowPrefetchChanged)
/*      */     {
/* 1136 */       if ((this.streamList == null) && (this.rowPrefetch != this.definesBatchSize)) {
/* 1137 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/* 1139 */       this.rowPrefetchChanged = false;
/*      */     }
/*      */     
/* 1142 */     if (!this.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */ 
/* 1146 */       if (this.accessors == null)
/*      */       {
/*      */ 
/*      */ 
/* 1150 */         this.needToPrepareDefineBuffer = true;
/* 1151 */       } else if (this.columnsDefinedByUser) {
/* 1152 */         this.needToPrepareDefineBuffer = (!checkAccessorsUsable());
/*      */       }
/*      */     }
/* 1155 */     boolean bool = false;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1160 */       this.isExecuting = true;
/*      */       
/* 1162 */       if (this.needToPrepareDefineBuffer)
/*      */       {
/*      */ 
/* 1165 */         if (!this.columnsDefinedByUser)
/*      */         {
/* 1167 */           executeForDescribe();
/*      */           
/* 1169 */           bool = true;
/*      */           
/*      */ 
/*      */ 
/* 1173 */           if (this.aFetchWasDoneDuringDescribe) {
/* 1174 */             i = 0;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1180 */         if (this.needToPrepareDefineBuffer)
/*      */         {
/*      */ 
/*      */ 
/* 1184 */           prepareAccessors();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1189 */       int j = this.accessors.length;
/*      */       
/* 1191 */       for (int k = this.numberOfDefinePositions; k < j; k++)
/*      */       {
/* 1193 */         Accessor localAccessor = this.accessors[k];
/*      */         
/* 1195 */         if (localAccessor != null)
/* 1196 */           localAccessor.rowSpaceIndicator = null;
/*      */       }
/* 1198 */       if (i != 0) {
/* 1199 */         executeForRows(bool);
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException)
/*      */     {
/* 1204 */       this.needToParse = true;
/* 1205 */       throw localSQLException;
/*      */     }
/*      */     finally
/*      */     {
/* 1209 */       this.isExecuting = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void adjustGotLastBatch() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doExecuteWithTimeout()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1246 */       cleanOldTempLobs();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1253 */       this.connection.registerHeartbeat();
/*      */       
/*      */ 
/* 1256 */       this.rowsProcessed = 0;
/*      */       SQLException localSQLException1;
/* 1258 */       if (this.sqlKind.isSELECT())
/*      */       {
/* 1260 */         if ((this.connection.j2ee13Compliant) && (this.executionType == 2))
/*      */         {
/* 1262 */           localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 129);
/* 1263 */           localSQLException1.fillInStackTrace();
/* 1264 */           throw localSQLException1;
/*      */         }
/*      */         
/* 1267 */         this.connection.needLine();
/*      */         
/* 1269 */         if (!this.isOpen)
/*      */         {
/* 1271 */           this.connection.open(this);
/*      */           
/* 1273 */           this.isOpen = true;
/*      */         }
/*      */         
/* 1276 */         if (this.queryTimeout != 0)
/*      */         {
/*      */           try
/*      */           {
/* 1280 */             this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/* 1281 */             executeMaybeDescribe();
/*      */           }
/*      */           finally
/*      */           {
/* 1285 */             this.connection.getTimeout().cancelTimeout();
/*      */           }
/*      */           
/*      */         } else {
/* 1289 */           executeMaybeDescribe();
/*      */         }
/* 1291 */         checkValidRowsStatus();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1296 */         if (this.serverCursor) {
/* 1297 */           adjustGotLastBatch();
/*      */         }
/*      */       }
/*      */       else {
/* 1301 */         if ((this.connection.j2ee13Compliant) && (!this.sqlKind.isPlsqlOrCall()) && (this.executionType == 1))
/*      */         {
/*      */ 
/* 1304 */           localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 128);
/* 1305 */           localSQLException1.fillInStackTrace();
/* 1306 */           throw localSQLException1;
/*      */         }
/*      */         
/* 1309 */         this.currentRank += 1;
/*      */         
/* 1311 */         if (this.currentRank >= this.batch)
/*      */         {
/*      */           try
/*      */           {
/* 1315 */             this.connection.needLine();
/*      */             
/* 1317 */             if (!this.isOpen)
/*      */             {
/* 1319 */               this.connection.open(this);
/*      */               
/* 1321 */               this.isOpen = true;
/*      */             }
/*      */             
/* 1324 */             if (this.queryTimeout != 0) {
/* 1325 */               this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/*      */             }
/* 1327 */             this.isExecuting = true;
/*      */             
/* 1329 */             executeForRows(false);
/*      */           }
/*      */           catch (SQLException localSQLException2)
/*      */           {
/* 1333 */             this.needToParse = true;
/* 1334 */             if (this.batch > 1)
/*      */             {
/* 1336 */               clearBatch();
/*      */               
/*      */               int[] arrayOfInt;
/*      */               
/*      */               int i;
/*      */               
/* 1342 */               if ((this.numberOfExecutedElementsInBatch != -1) && (this.numberOfExecutedElementsInBatch < this.batch))
/*      */               {
/*      */ 
/* 1345 */                 arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 1346 */                 for (i = 0; i < arrayOfInt.length; i++) {
/* 1347 */                   arrayOfInt[i] = -2;
/*      */                 }
/*      */               }
/*      */               else {
/* 1351 */                 arrayOfInt = new int[this.batch];
/* 1352 */                 for (i = 0; i < arrayOfInt.length; i++) {
/* 1353 */                   arrayOfInt[i] = -3;
/*      */                 }
/*      */               }
/* 1356 */               BatchUpdateException localBatchUpdateException = DatabaseError.createBatchUpdateException(localSQLException2, arrayOfInt.length, arrayOfInt);
/* 1357 */               localBatchUpdateException.fillInStackTrace();
/* 1358 */               throw localBatchUpdateException;
/*      */             }
/*      */             
/* 1361 */             resetCurrentRowBinders();
/*      */             
/* 1363 */             throw localSQLException2;
/*      */           }
/*      */           finally
/*      */           {
/* 1367 */             if (this.queryTimeout != 0) {
/* 1368 */               this.connection.getTimeout().cancelTimeout();
/*      */             }
/* 1370 */             this.currentRank = 0;
/* 1371 */             this.isExecuting = false;
/*      */             
/* 1373 */             checkValidRowsStatus();
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException3)
/*      */     {
/*      */ 
/*      */ 
/* 1391 */       resetOnExceptionDuringExecute();
/* 1392 */       throw localSQLException3;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1402 */     this.connection.registerHeartbeat();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetOnExceptionDuringExecute()
/*      */   {
/* 1411 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void resetCurrentRowBinders() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void open()
/*      */     throws SQLException
/*      */   {
/* 1433 */     if (!this.isOpen)
/*      */     {
/* 1435 */       this.connection.needLine();
/* 1436 */       this.connection.open(this);
/*      */       
/* 1438 */       this.isOpen = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet executeQuery(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1457 */     synchronized (this.connection)
/*      */     {
/* 1459 */       Object localObject1 = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1467 */         this.executionType = 1;
/*      */         
/*      */ 
/*      */ 
/* 1471 */         this.noMoreUpdateCounts = false;
/*      */         
/* 1473 */         ensureOpen();
/* 1474 */         checkIfJdbcBatchExists();
/*      */         
/* 1476 */         sendBatch();
/*      */         
/*      */ 
/* 1479 */         this.hasStream = false;
/*      */         
/*      */ 
/* 1482 */         this.sqlObject.initialize(paramString);
/*      */         
/* 1484 */         this.sqlKind = this.sqlObject.getSqlKind();
/* 1485 */         this.needToParse = true;
/*      */         
/* 1487 */         prepareForNewResults(true, true);
/*      */         
/* 1489 */         if (this.userRsetType == 1)
/*      */         {
/* 1491 */           doExecuteWithTimeout();
/*      */           
/* 1493 */           this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1494 */           localObject1 = this.currentResultSet;
/*      */         }
/*      */         else
/*      */         {
/* 1498 */           localObject1 = doScrollStmtExecuteQuery();
/*      */           
/* 1500 */           if (localObject1 == null)
/*      */           {
/* 1502 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1503 */             localObject1 = this.currentResultSet;
/*      */           }
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 1509 */         this.executionType = -1;
/*      */       }
/*      */       
/* 1512 */       return (ResultSet)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeWithKey(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1525 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1526 */     localSQLException.fillInStackTrace();
/* 1527 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/* 1559 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 1563 */       closeOrCache(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void closeOrCache(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1571 */     if (this.closed) {
/* 1572 */       return;
/*      */     }
/*      */     
/* 1575 */     if (this.connection.lifecycle == 2) {
/* 1576 */       this.connection.needLineUnchecked();
/*      */     } else {
/* 1578 */       this.connection.needLine();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1587 */     if ((this.statementType != 0) && (this.cacheState != 0) && (this.cacheState != 3) && (this.connection.isStatementCacheInitialized()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1598 */       if (paramString == null)
/*      */       {
/* 1600 */         if (this.connection.getImplicitCachingEnabled())
/*      */         {
/* 1602 */           this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/* 1611 */           this.cacheState = 0;
/*      */           
/* 1613 */           hardClose();
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1619 */       else if (this.connection.getExplicitCachingEnabled())
/*      */       {
/* 1621 */         this.connection.cacheExplicitStatement((OraclePreparedStatement)this, paramString);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/* 1629 */         this.cacheState = 0;
/*      */         
/* 1631 */         hardClose();
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1640 */       hardClose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void hardClose()
/*      */     throws SQLException
/*      */   {
/* 1650 */     hardClose(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void hardClose(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1661 */     alwaysOnClose();
/*      */     
/* 1663 */     this.describedWithNames = false;
/* 1664 */     this.described = false;
/*      */     
/*      */ 
/* 1667 */     this.connection.removeStatement(this);
/*      */     
/* 1669 */     cleanupDefines();
/*      */     
/* 1671 */     if ((this.isOpen) && (paramBoolean) && ((this.connection.lifecycle == 1) || (this.connection.lifecycle == 16) || (this.connection.lifecycle == 2)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1680 */       this.connection.registerHeartbeat();
/*      */       
/*      */ 
/* 1683 */       doClose();
/*      */       
/* 1685 */       this.isOpen = false;
/*      */     }
/*      */     
/* 1688 */     this.sqlObject = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void alwaysOnClose()
/*      */     throws SQLException
/*      */   {
/* 1705 */     Object localObject = this.children;
/*      */     
/* 1707 */     while (localObject != null)
/*      */     {
/* 1709 */       OracleStatement localOracleStatement = ((OracleStatement)localObject).nextChild;
/*      */       
/* 1711 */       ((OracleStatement)localObject).close();
/*      */       
/* 1713 */       localObject = localOracleStatement;
/*      */     }
/*      */     
/* 1716 */     if (this.parent != null)
/*      */     {
/* 1718 */       this.parent.removeChild(this);
/*      */     }
/*      */     
/* 1721 */     this.closed = true;
/*      */     
/*      */ 
/* 1724 */     if ((this.connection.lifecycle == 1) || (this.connection.lifecycle == 2))
/*      */     {
/*      */ 
/*      */ 
/* 1728 */       if (this.currentResultSet != null)
/*      */       {
/* 1730 */         this.currentResultSet.internal_close(false);
/*      */         
/* 1732 */         this.currentResultSet = null;
/*      */       }
/*      */       
/* 1735 */       if (this.scrollRset != null)
/*      */       {
/* 1737 */         this.scrollRset.close();
/*      */         
/* 1739 */         this.scrollRset = null;
/*      */       }
/*      */       
/* 1742 */       if (this.returnResultSet != null)
/*      */       {
/* 1744 */         this.returnResultSet.close();
/* 1745 */         this.returnResultSet = null;
/*      */       }
/*      */     }
/*      */     
/* 1749 */     clearWarnings();
/*      */     
/* 1751 */     this.m_batchItems = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeLeaveCursorOpen()
/*      */     throws SQLException
/*      */   {
/* 1767 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1773 */       if (this.closed)
/*      */       {
/* 1775 */         return;
/*      */       }
/*      */       
/* 1778 */       hardClose(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1797 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1802 */       setNonAutoKey();
/* 1803 */       return executeUpdateInternal(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int executeUpdateInternal(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1814 */       if (this.executionType == -1) {
/* 1815 */         this.executionType = 2;
/*      */       }
/*      */       
/* 1818 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1820 */       ensureOpen();
/* 1821 */       checkIfJdbcBatchExists();
/*      */       
/* 1823 */       sendBatch();
/*      */       
/*      */ 
/* 1826 */       this.hasStream = false;
/*      */       
/*      */ 
/* 1829 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1831 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1832 */       this.needToParse = true;
/*      */       
/* 1834 */       prepareForNewResults(true, true);
/*      */       
/* 1836 */       if (this.userRsetType == 1)
/*      */       {
/* 1838 */         doExecuteWithTimeout();
/*      */       }
/*      */       else
/*      */       {
/* 1842 */         doScrollStmtExecuteQuery();
/*      */       }
/*      */       
/* 1845 */       return this.validRows;
/*      */     }
/*      */     finally
/*      */     {
/* 1849 */       this.executionType = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1865 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1870 */       setNonAutoKey();
/* 1871 */       return executeInternal(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   boolean executeInternal(String paramString)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1882 */       this.executionType = 3;
/*      */       
/* 1884 */       this.checkSum = 0L;
/* 1885 */       this.checkSumComputationFailure = false;
/*      */       
/*      */ 
/* 1888 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1890 */       ensureOpen();
/* 1891 */       checkIfJdbcBatchExists();
/*      */       
/* 1893 */       sendBatch();
/*      */       
/*      */ 
/*      */ 
/* 1897 */       this.hasStream = false;
/*      */       
/*      */ 
/* 1900 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1902 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1903 */       this.needToParse = true;
/*      */       
/* 1905 */       prepareForNewResults(true, true);
/*      */       
/* 1907 */       if (this.userRsetType == 1)
/*      */       {
/* 1909 */         doExecuteWithTimeout();
/*      */       }
/*      */       else
/*      */       {
/* 1913 */         doScrollStmtExecuteQuery();
/*      */       }
/*      */       
/* 1916 */       return this.sqlKind.isSELECT();
/*      */     }
/*      */     finally
/*      */     {
/* 1920 */       this.executionType = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   int getNumberOfColumns()
/*      */     throws SQLException
/*      */   {
/* 1928 */     ensureOpen();
/* 1929 */     if (!this.described)
/*      */     {
/* 1931 */       synchronized (this.connection) {
/* 1932 */         doDescribe(false);
/*      */         
/* 1934 */         this.described = true;
/*      */       }
/*      */     }
/*      */     
/* 1938 */     return this.numberOfDefinePositions;
/*      */   }
/*      */   
/*      */ 
/*      */   Accessor[] getDescription()
/*      */     throws SQLException
/*      */   {
/* 1945 */     ensureOpen();
/* 1946 */     if (!this.described)
/*      */     {
/* 1948 */       synchronized (this.connection) {
/* 1949 */         doDescribe(false);
/*      */         
/* 1951 */         this.described = true;
/*      */       }
/*      */     }
/*      */     
/* 1955 */     return this.accessors;
/*      */   }
/*      */   
/*      */ 
/*      */   Accessor[] getDescriptionWithNames()
/*      */     throws SQLException
/*      */   {
/* 1962 */     ensureOpen();
/* 1963 */     if (!this.describedWithNames)
/*      */     {
/* 1965 */       synchronized (this.connection) {
/* 1966 */         doDescribe(true);
/*      */         
/* 1968 */         this.described = true;
/* 1969 */         this.describedWithNames = true;
/*      */       }
/*      */     }
/*      */     
/* 1973 */     return this.accessors;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleStatement.SqlKind getSqlKind()
/*      */     throws SQLException
/*      */   {
/* 1986 */     return this.sqlObject.getSqlKind();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/* 2006 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2009 */       freeLine();
/*      */       
/* 2011 */       this.streamList = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2018 */       this.columnsDefinedByUser = false;
/* 2019 */       this.needToPrepareDefineBuffer = true;
/*      */       
/*      */ 
/* 2022 */       this.numberOfDefinePositions = 0;
/* 2023 */       this.definesBatchSize = 0;
/*      */       
/* 2025 */       this.described = false;
/* 2026 */       this.describedWithNames = false;
/*      */       
/* 2028 */       cleanupDefines();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2050 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, (short)1, paramBoolean, paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2061 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */     
/*      */     SQLException localSQLException;
/* 2066 */     if (paramInt1 < 1)
/*      */     {
/* 2068 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2069 */       localSQLException.fillInStackTrace();
/* 2070 */       throw localSQLException;
/*      */     }
/*      */     
/* 2073 */     if (paramInt2 == 0)
/*      */     {
/* 2075 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2076 */       localSQLException.fillInStackTrace();
/* 2077 */       throw localSQLException;
/*      */     }
/*      */     
/* 2080 */     int i = paramInt1 - 1;
/* 2081 */     int j = this.maxFieldSize > 0 ? this.maxFieldSize : -1;
/*      */     Object localObject1;
/* 2083 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/* 2087 */       if ((paramInt2 == 1) || (paramInt2 == 12) || (paramInt2 == -15) || (paramInt2 == -9))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2094 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2101 */       if (paramInt3 < 0)
/*      */       {
/* 2103 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/* 2104 */         ((SQLException)localObject1).fillInStackTrace();
/* 2105 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 2108 */       if (((j == -1) && (paramInt3 > 0)) || ((j > 0) && (paramInt3 < j)))
/*      */       {
/* 2110 */         j = paramInt3;
/*      */       }
/*      */     }
/* 2113 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/* 2115 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/* 2116 */       ((SQLException)localObject1).fillInStackTrace();
/* 2117 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/* 2120 */     if (!this.columnsDefinedByUser)
/*      */     {
/*      */ 
/*      */ 
/* 2124 */       clearDefines();
/*      */       
/* 2126 */       this.columnsDefinedByUser = true;
/*      */     }
/*      */     
/* 2129 */     if (this.numberOfDefinePositions < paramInt1)
/*      */     {
/* 2131 */       if ((this.accessors == null) || (this.accessors.length < paramInt1))
/*      */       {
/* 2133 */         localObject1 = new Accessor[paramInt1 << 1];
/*      */         
/* 2135 */         if (this.accessors != null) {
/* 2136 */           System.arraycopy(this.accessors, 0, localObject1, 0, this.numberOfDefinePositions);
/*      */         }
/* 2138 */         this.accessors = ((Accessor[])localObject1);
/*      */       }
/*      */       
/* 2141 */       this.numberOfDefinePositions = paramInt1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2148 */     switch (paramInt2) {
/*      */     case -16: 
/*      */     case -15: 
/*      */     case -9: 
/*      */     case 2011: 
/* 2153 */       paramShort = 2;
/* 2154 */       break;
/*      */     case 2009: 
/* 2156 */       paramString = "SYS.XMLTYPE";
/* 2157 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2164 */     int k = getInternalType(paramInt2);
/*      */     
/* 2166 */     if (((k == 109) || (k == 111)) && ((paramString == null) || (paramString.equals(""))))
/*      */     {
/*      */ 
/* 2169 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
/* 2170 */       ((SQLException)localObject2).fillInStackTrace();
/* 2171 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/* 2174 */     Object localObject2 = this.accessors[i];
/* 2175 */     int m = 1;
/*      */     
/* 2177 */     if (localObject2 != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2182 */       int n = ((Accessor)localObject2).useForDataAccessIfPossible(k, paramInt2, j, paramString);
/*      */       
/*      */ 
/* 2185 */       if (n == 0)
/*      */       {
/* 2187 */         paramShort = ((Accessor)localObject2).formOfUse;
/* 2188 */         localObject2 = null;
/*      */         
/* 2190 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2192 */       else if (n == 1)
/*      */       {
/* 2194 */         localObject2 = null;
/*      */         
/* 2196 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2198 */       else if (n == 2) {
/* 2199 */         m = 0;
/*      */       }
/*      */     }
/* 2202 */     if (m != 0) {
/* 2203 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/* 2205 */     if (localObject2 == null)
/*      */     {
/* 2207 */       this.accessors[i] = allocateAccessor(k, paramInt2, paramInt1, j, paramShort, paramString, false);
/*      */       
/* 2209 */       this.described = false;
/* 2210 */       this.describedWithNames = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     Object localObject;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2252 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/* 2256 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2258 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2259 */         localSQLException.fillInStackTrace();
/* 2260 */         throw localSQLException;
/*      */       }
/*      */       
/* 2263 */       return new CharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 8: 
/* 2266 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2268 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2269 */         localSQLException.fillInStackTrace();
/* 2270 */         throw localSQLException;
/*      */       }
/*      */       
/* 2273 */       if (!paramBoolean) {
/* 2274 */         return new LongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */       }
/*      */     
/*      */ 
/*      */     case 1: 
/* 2279 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2281 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2282 */         localSQLException.fillInStackTrace();
/* 2283 */         throw localSQLException;
/*      */       }
/*      */       
/* 2286 */       return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 2: 
/* 2289 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2291 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2292 */         localSQLException.fillInStackTrace();
/* 2293 */         throw localSQLException;
/*      */       }
/*      */       
/* 2296 */       return new NumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 6: 
/* 2299 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2301 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2302 */         localSQLException.fillInStackTrace();
/* 2303 */         throw localSQLException;
/*      */       }
/*      */       
/* 2306 */       return new VarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 24: 
/* 2309 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2311 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2312 */         localSQLException.fillInStackTrace();
/* 2313 */         throw localSQLException;
/*      */       }
/*      */       
/* 2316 */       if (!paramBoolean) {
/* 2317 */         return new LongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/* 2323 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2325 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2326 */         localSQLException.fillInStackTrace();
/* 2327 */         throw localSQLException;
/*      */       }
/*      */       
/* 2330 */       if (paramBoolean) {
/* 2331 */         return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
/*      */       }
/* 2333 */       return new RawAccessor(this, paramInt4, paramShort, paramInt2, false);
/*      */     
/*      */     case 100: 
/* 2336 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2338 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2339 */         localSQLException.fillInStackTrace();
/* 2340 */         throw localSQLException;
/*      */       }
/*      */       
/* 2343 */       return new BinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 101: 
/* 2347 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2349 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2350 */         localSQLException.fillInStackTrace();
/* 2351 */         throw localSQLException;
/*      */       }
/*      */       
/* 2354 */       return new BinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 104: 
/* 2358 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2360 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2361 */         localSQLException.fillInStackTrace();
/* 2362 */         throw localSQLException;
/*      */       }
/* 2364 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/* 2366 */         paramInt4 = 18;
/* 2367 */         localObject = new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/* 2368 */         ((Accessor)localObject).definedColumnType = -8;
/* 2369 */         return (Accessor)localObject;
/*      */       }
/* 2371 */       return new RowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 102: 
/* 2374 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2376 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2377 */         localSQLException.fillInStackTrace();
/* 2378 */         throw localSQLException;
/*      */       }
/*      */       
/* 2381 */       return new ResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 12: 
/* 2384 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2386 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2387 */         localSQLException.fillInStackTrace();
/* 2388 */         throw localSQLException;
/*      */       }
/*      */       
/* 2391 */       return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */     case 113: 
/* 2394 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2396 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2397 */         localSQLException.fillInStackTrace();
/* 2398 */         throw localSQLException;
/*      */       }
/*      */       
/* 2401 */       localObject = new BlobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2402 */       if (!paramBoolean)
/* 2403 */         ((Accessor)localObject).lobPrefetchSizeForThisColumn = paramInt4;
/* 2404 */       return (Accessor)localObject;
/*      */     
/*      */     case 112: 
/* 2407 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2409 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2410 */         localSQLException.fillInStackTrace();
/* 2411 */         throw localSQLException;
/*      */       }
/*      */       
/* 2414 */       localObject = new ClobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2415 */       if (!paramBoolean)
/* 2416 */         ((Accessor)localObject).lobPrefetchSizeForThisColumn = paramInt4;
/* 2417 */       return (Accessor)localObject;
/*      */     
/*      */     case 114: 
/* 2420 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2422 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2423 */         localSQLException.fillInStackTrace();
/* 2424 */         throw localSQLException;
/*      */       }
/*      */       
/* 2427 */       localObject = new BfileAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/*      */ 
/* 2431 */       return (Accessor)localObject;
/*      */     
/*      */     case 109: 
/* 2434 */       if (paramString == null) {
/* 2435 */         if (paramBoolean)
/*      */         {
/* 2437 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2438 */           localSQLException.fillInStackTrace();
/* 2439 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 2443 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2444 */         localSQLException.fillInStackTrace();
/* 2445 */         throw localSQLException;
/*      */       }
/*      */       
/* 2448 */       localObject = new NamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/* 2451 */       ((Accessor)localObject).initMetadata();
/*      */       
/* 2453 */       return (Accessor)localObject;
/*      */     
/*      */     case 111: 
/* 2456 */       if (paramString == null) {
/* 2457 */         if (paramBoolean)
/*      */         {
/* 2459 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2460 */           localSQLException.fillInStackTrace();
/* 2461 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 2465 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2466 */         localSQLException.fillInStackTrace();
/* 2467 */         throw localSQLException;
/*      */       }
/*      */       
/* 2470 */       localObject = new RefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */ 
/* 2473 */       ((Accessor)localObject).initMetadata();
/*      */       
/* 2475 */       return (Accessor)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/* 2480 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2482 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2483 */         localSQLException.fillInStackTrace();
/* 2484 */         throw localSQLException;
/*      */       }
/*      */       
/* 2487 */       return new TimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 181: 
/* 2491 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2493 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2494 */         localSQLException.fillInStackTrace();
/* 2495 */         throw localSQLException;
/*      */       }
/*      */       
/* 2498 */       return new TimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 231: 
/* 2502 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2504 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2505 */         localSQLException.fillInStackTrace();
/* 2506 */         throw localSQLException;
/*      */       }
/*      */       
/* 2509 */       return new TimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 182: 
/* 2513 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2515 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2516 */         localSQLException.fillInStackTrace();
/* 2517 */         throw localSQLException;
/*      */       }
/*      */       
/* 2520 */       return new IntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */     case 183: 
/* 2524 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/* 2526 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2527 */         localSQLException.fillInStackTrace();
/* 2528 */         throw localSQLException;
/*      */       }
/*      */       
/* 2531 */       return new IntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/* 2550 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 2551 */       localSQLException.fillInStackTrace();
/* 2552 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 2557 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2558 */     localSQLException.fillInStackTrace();
/* 2559 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2611 */     synchronized (this.connection)
/*      */     {
/* 2613 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2629 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2648 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, paramShort, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2719 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 2722 */       defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 2793 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2833 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2839 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setCursorId(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2855 */     this.cursorId = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2870 */     if (paramBoolean1)
/*      */     {
/* 2872 */       if (paramInt <= 0)
/*      */       {
/* 2874 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/* 2875 */         localSQLException.fillInStackTrace();
/* 2876 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2881 */       if (paramInt < 0)
/*      */       {
/* 2883 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchSize");
/* 2884 */         localSQLException.fillInStackTrace();
/* 2885 */         throw localSQLException;
/*      */       }
/* 2887 */       if (paramInt == 0) {
/* 2888 */         paramInt = this.connection.getDefaultRowPrefetch();
/*      */       }
/*      */     }
/*      */     
/* 2892 */     if (paramBoolean2)
/*      */     {
/* 2894 */       if (paramInt != this.defaultRowPrefetch)
/*      */       {
/* 2896 */         this.defaultRowPrefetch = paramInt;
/*      */         
/*      */ 
/*      */ 
/* 2900 */         if ((this.currentResultSet == null) || (this.currentResultSet.closed)) {
/* 2901 */           this.rowPrefetchChanged = true;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 2908 */     else if ((paramInt != this.rowPrefetch) && (this.streamList == null))
/*      */     {
/*      */ 
/* 2911 */       this.rowPrefetch = paramInt;
/* 2912 */       this.rowPrefetchChanged = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRowPrefetch(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2939 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 2943 */       setPrefetchInternal(paramInt, true, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLobPrefetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2956 */     synchronized (this.connection)
/*      */     {
/* 2958 */       if (paramInt < -1)
/*      */       {
/* 2960 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/* 2961 */         localSQLException.fillInStackTrace();
/* 2962 */         throw localSQLException;
/*      */       }
/* 2964 */       this.defaultLobPrefetchSize = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getLobPrefetchSize()
/*      */   {
/* 2972 */     return this.defaultLobPrefetchSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getPrefetchInternal(boolean paramBoolean)
/*      */   {
/* 2989 */     int i = paramBoolean ? this.defaultRowPrefetch : this.rowPrefetch;
/*      */     
/* 2991 */     return i;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getRowPrefetch()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 69	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: iconst_1
/*      */     //   9: invokevirtual 285	oracle/jdbc/driver/OracleStatement:getPrefetchInternal	(Z)I
/*      */     //   12: aload_1
/*      */     //   13: monitorexit
/*      */     //   14: ireturn
/*      */     //   15: astore_2
/*      */     //   16: aload_1
/*      */     //   17: monitorexit
/*      */     //   18: aload_2
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3006	-> byte code offset #0
/*      */     //   Java source line #3009	-> byte code offset #7
/*      */     //   Java source line #3011	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleStatement
/*      */     //   5	12	1	Ljava/lang/Object;	Object
/*      */     //   15	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public void setFixedString(boolean paramBoolean)
/*      */   {
/* 3036 */     this.fixedString = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFixedString()
/*      */   {
/* 3061 */     return this.fixedString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void check_row_prefetch_changed()
/*      */     throws SQLException
/*      */   {
/* 3076 */     if (this.rowPrefetchChanged)
/*      */     {
/* 3078 */       if (this.streamList == null)
/*      */       {
/* 3080 */         prepareAccessors();
/*      */         
/* 3082 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/*      */       
/* 3085 */       this.rowPrefetchChanged = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setDefinesInitialized(boolean paramBoolean) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void printState(String paramString)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkValidRowsStatus()
/*      */     throws SQLException
/*      */   {
/* 3122 */     if (this.validRows == -2)
/*      */     {
/*      */ 
/*      */ 
/* 3126 */       this.validRows = 1;
/* 3127 */       this.connection.holdLine(this);
/*      */       
/*      */ 
/* 3130 */       OracleInputStream localOracleInputStream = this.streamList;
/*      */       
/* 3132 */       while (localOracleInputStream != null)
/*      */       {
/* 3134 */         if (localOracleInputStream.hasBeenOpen) {
/* 3135 */           localOracleInputStream = localOracleInputStream.accessor.initForNewRow();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3142 */         localOracleInputStream.closed = false;
/* 3143 */         localOracleInputStream.hasBeenOpen = true;
/*      */         
/*      */ 
/*      */ 
/* 3147 */         localOracleInputStream = localOracleInputStream.nextStream;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3152 */       this.nextStream = this.streamList;
/*      */ 
/*      */     }
/* 3155 */     else if (this.sqlKind.isSELECT())
/*      */     {
/* 3157 */       if (this.validRows < this.rowPrefetch) {
/* 3158 */         this.gotLastBatch = true;
/*      */       }
/* 3160 */     } else if (!this.sqlKind.isPlsqlOrCall())
/*      */     {
/* 3162 */       this.rowsProcessed = this.validRows;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanupDefines()
/*      */   {
/* 3170 */     if (this.accessors != null) {
/* 3171 */       for (int i = 0; i < this.accessors.length; i++)
/* 3172 */         this.accessors[i] = null;
/*      */     }
/* 3174 */     this.accessors = null;
/*      */     
/*      */ 
/* 3177 */     this.connection.cacheBuffer(this.defineBytes);
/* 3178 */     this.defineBytes = null;
/* 3179 */     this.connection.cacheBuffer(this.defineChars);
/* 3180 */     this.defineChars = null;
/* 3181 */     this.defineIndicators = null;
/* 3182 */     this.defineMetaData = null;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 69	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 207	oracle/jdbc/driver/OracleStatement:maxFieldSize	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3189	-> byte code offset #0
/*      */     //   Java source line #3191	-> byte code offset #7
/*      */     //   Java source line #3193	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public void setMaxFieldSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3198 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3201 */       if (paramInt < 0)
/*      */       {
/* 3203 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3204 */         localSQLException.fillInStackTrace();
/* 3205 */         throw localSQLException;
/*      */       }
/*      */       
/* 3208 */       this.maxFieldSize = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxRows()
/*      */     throws SQLException
/*      */   {
/* 3216 */     return this.maxRows;
/*      */   }
/*      */   
/*      */   public void setMaxRows(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3222 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3225 */       if (paramInt < 0)
/*      */       {
/* 3227 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3228 */         localSQLException.fillInStackTrace();
/* 3229 */         throw localSQLException;
/*      */       }
/*      */       
/* 3232 */       this.maxRows = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setEscapeProcessing(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3240 */     synchronized (this.connection)
/*      */     {
/* 3242 */       this.processEscapes = paramBoolean;
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 69	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 150	oracle/jdbc/driver/OracleStatement:queryTimeout	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3256	-> byte code offset #0
/*      */     //   Java source line #3258	-> byte code offset #7
/*      */     //   Java source line #3260	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public void setQueryTimeout(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3273 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3276 */       if (paramInt < 0)
/*      */       {
/* 3278 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3279 */         localSQLException.fillInStackTrace();
/* 3280 */         throw localSQLException;
/*      */       }
/*      */       
/* 3283 */       this.queryTimeout = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/* 3296 */     doCancel();
/*      */   }
/*      */   
/*      */ 
/*      */   boolean doCancel()
/*      */     throws SQLException
/*      */   {
/* 3303 */     boolean bool = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3308 */     if (this.closed) {
/* 3309 */       return bool;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3321 */     if (this.connection.statementHoldingLine != null) {
/* 3322 */       freeLine();
/* 3323 */     } else if (this.isExecuting)
/*      */     {
/* 3325 */       bool = true;
/* 3326 */       this.connection.cancelOperationOnServer();
/*      */     }
/*      */     
/* 3329 */     OracleStatement localOracleStatement = this.children;
/* 3330 */     while (localOracleStatement != null) {
/* 3331 */       bool = (bool) || (localOracleStatement.doCancel());
/* 3332 */       localOracleStatement = localOracleStatement.nextChild;
/*      */     }
/*      */     
/* 3335 */     this.connection.releaseLineForCancel();
/* 3336 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 3353 */     return this.sqlWarning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/* 3363 */     this.sqlWarning = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void foundPlsqlCompilerWarning()
/*      */     throws SQLException
/*      */   {
/* 3371 */     SQLWarning localSQLWarning = DatabaseError.addSqlWarning(this.sqlWarning, "Found Plsql compiler warnings.", 24439);
/*      */     
/* 3373 */     if (this.sqlWarning != null)
/*      */     {
/* 3375 */       this.sqlWarning.setNextWarning(localSQLWarning);
/*      */     }
/*      */     else
/*      */     {
/* 3379 */       this.sqlWarning = localSQLWarning;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursorName(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3391 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 3392 */     localSQLException.fillInStackTrace();
/* 3393 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/* 3406 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 3409 */       if (this.userRsetType == 1)
/*      */       {
/* 3411 */         if (this.sqlKind.isSELECT())
/*      */         {
/* 3413 */           if (this.currentResultSet == null) {
/* 3414 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*      */           }
/* 3416 */           return this.currentResultSet;
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/* 3421 */         return this.scrollRset;
/*      */       }
/*      */       
/* 3424 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 3441 */     synchronized (this.connection)
/*      */     {
/* 3443 */       int i = -1;
/*      */       
/* 3445 */       switch (this.sqlKind)
/*      */       {
/*      */       case UNINITIALIZED: 
/*      */       case SELECT_FOR_UPDATE: 
/*      */       case SELECT: 
/*      */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case ALTER_SESSION: 
/*      */       case OTHER: 
/* 3456 */         if (!this.noMoreUpdateCounts) {
/* 3457 */           i = this.rowsProcessed;
/*      */         }
/* 3459 */         this.noMoreUpdateCounts = true;
/*      */         
/* 3461 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case PLSQL_BLOCK: 
/*      */       case CALL_BLOCK: 
/* 3467 */         this.noMoreUpdateCounts = true;
/*      */         
/* 3469 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case DELETE: 
/*      */       case INSERT: 
/*      */       case MERGE: 
/*      */       case UPDATE: 
/* 3477 */         if (!this.noMoreUpdateCounts) {
/* 3478 */           i = this.rowsProcessed;
/*      */         }
/* 3480 */         this.noMoreUpdateCounts = true;
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 3485 */       return i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/* 3497 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int sendBatch()
/*      */     throws SQLException
/*      */   {
/* 3508 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2)
/*      */     throws SQLException
/*      */   {
/* 3519 */     clearWarnings();
/*      */     
/* 3521 */     if (this.streamList != null)
/*      */     {
/*      */       Object localObject;
/*      */       
/* 3525 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 3529 */           this.nextStream.close();
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3534 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3535 */           ((SQLException)localObject).fillInStackTrace();
/* 3536 */           throw ((Throwable)localObject);
/*      */         }
/*      */         
/*      */ 
/* 3540 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */       
/* 3543 */       if (paramBoolean2)
/*      */       {
/*      */ 
/* 3546 */         OracleInputStream localOracleInputStream = this.streamList;
/* 3547 */         localObject = null;
/*      */         
/* 3549 */         this.streamList = null;
/*      */         
/* 3551 */         while (localOracleInputStream != null)
/*      */         {
/* 3553 */           if (!localOracleInputStream.hasBeenOpen)
/*      */           {
/* 3555 */             if (localObject == null) {
/* 3556 */               this.streamList = localOracleInputStream;
/*      */             } else {
/* 3558 */               ((OracleInputStream)localObject).nextStream = localOracleInputStream;
/*      */             }
/* 3560 */             localObject = localOracleInputStream;
/*      */           }
/*      */           
/* 3563 */           localOracleInputStream = localOracleInputStream.nextStream;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3568 */     if (this.currentResultSet != null)
/*      */     {
/* 3570 */       this.currentResultSet.internal_close(true);
/*      */       
/* 3572 */       this.currentResultSet = null;
/*      */     }
/*      */     
/* 3575 */     this.currentRow = -1;
/* 3576 */     this.checkSum = 0L;
/* 3577 */     this.checkSumComputationFailure = false;
/* 3578 */     this.validRows = 0;
/* 3579 */     if (paramBoolean1)
/* 3580 */       this.totalRowsVisited = 0;
/* 3581 */     this.gotLastBatch = false;
/*      */     
/* 3583 */     if ((this.needToParse) && (!this.columnsDefinedByUser))
/*      */     {
/* 3585 */       if ((paramBoolean2) && (this.numberOfDefinePositions != 0)) {
/* 3586 */         this.numberOfDefinePositions = 0;
/*      */       }
/* 3588 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/*      */     
/*      */ 
/* 3592 */     if ((paramBoolean1) && (this.rowPrefetch != this.defaultRowPrefetch) && (this.streamList == null))
/*      */     {
/*      */ 
/*      */ 
/* 3596 */       this.rowPrefetch = this.defaultRowPrefetch;
/* 3597 */       this.rowPrefetchChanged = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reopenStreams()
/*      */     throws SQLException
/*      */   {
/* 3611 */     OracleInputStream localOracleInputStream = this.streamList;
/*      */     
/* 3613 */     while (localOracleInputStream != null)
/*      */     {
/* 3615 */       if (localOracleInputStream.hasBeenOpen) {
/* 3616 */         localOracleInputStream = localOracleInputStream.accessor.initForNewRow();
/*      */       }
/* 3618 */       localOracleInputStream.closed = false;
/* 3619 */       localOracleInputStream.hasBeenOpen = true;
/* 3620 */       localOracleInputStream = localOracleInputStream.nextStream;
/*      */     }
/*      */     
/* 3623 */     this.nextStream = this.streamList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void endOfResultSet(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3635 */     if (!paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/* 3639 */       prepareForNewResults(false, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3644 */     clearDefines();
/* 3645 */     this.rowPrefetchInLastFetch = -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean wasNullValue()
/*      */     throws SQLException
/*      */   {
/* 3670 */     if (this.lastIndex == 0)
/*      */     {
/* 3672 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/* 3673 */       localSQLException.fillInStackTrace();
/* 3674 */       throw localSQLException;
/*      */     }
/*      */     
/* 3677 */     if (this.sqlKind.isSELECT()) {
/* 3678 */       return this.accessors[(this.lastIndex - 1)].isNull(this.currentRow);
/*      */     }
/* 3680 */     return this.outBindAccessors[(this.lastIndex - 1)].isNull(this.currentRank);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getColumnIndex(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3694 */     ensureOpen();
/* 3695 */     if (!this.describedWithNames)
/*      */     {
/* 3697 */       synchronized (this.connection) {
/* 3698 */         doDescribe(true);
/*      */         
/* 3700 */         this.described = true;
/* 3701 */         this.describedWithNames = true;
/*      */       }
/*      */     }
/*      */     
/* 3705 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/* 3706 */       if (this.accessors[i].columnName.equalsIgnoreCase(paramString)) {
/* 3707 */         return i + 1;
/*      */       }
/*      */     }
/* 3710 */     ??? = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3711 */     ((SQLException)???).fillInStackTrace();
/* 3712 */     throw ((Throwable)???);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getJDBCType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3720 */     int i = 0;
/* 3721 */     switch (paramInt)
/*      */     {
/*      */     case 6: 
/* 3724 */       i = 2;
/* 3725 */       break;
/*      */     case 100: 
/* 3727 */       i = 100;
/* 3728 */       break;
/*      */     case 101: 
/* 3730 */       i = 101;
/* 3731 */       break;
/*      */     case 999: 
/* 3733 */       i = 999;
/* 3734 */       break;
/*      */     case 96: 
/* 3736 */       i = 1;
/* 3737 */       break;
/*      */     case 1: 
/* 3739 */       i = 12;
/* 3740 */       break;
/*      */     case 8: 
/* 3742 */       i = -1;
/* 3743 */       break;
/*      */     case 12: 
/* 3745 */       i = 91;
/* 3746 */       break;
/*      */     case 180: 
/* 3748 */       i = 93;
/* 3749 */       break;
/*      */     case 181: 
/* 3751 */       i = -101;
/* 3752 */       break;
/*      */     case 231: 
/* 3754 */       i = -102;
/* 3755 */       break;
/*      */     case 182: 
/* 3757 */       i = -103;
/* 3758 */       break;
/*      */     case 183: 
/* 3760 */       i = -104;
/* 3761 */       break;
/*      */     case 23: 
/* 3763 */       i = -2;
/* 3764 */       break;
/*      */     case 24: 
/* 3766 */       i = -4;
/* 3767 */       break;
/*      */     case 104: 
/* 3769 */       i = -8;
/* 3770 */       break;
/*      */     case 113: 
/* 3772 */       i = 2004;
/* 3773 */       break;
/*      */     case 112: 
/* 3775 */       i = 2005;
/* 3776 */       break;
/*      */     case 114: 
/* 3778 */       i = -13;
/* 3779 */       break;
/*      */     case 102: 
/* 3781 */       i = -10;
/* 3782 */       break;
/*      */     case 109: 
/* 3784 */       i = 2002;
/* 3785 */       break;
/*      */     case 111: 
/* 3787 */       i = 2006;
/* 3788 */       break;
/*      */     case 998: 
/* 3790 */       i = -14;
/* 3791 */       break;
/*      */     case 995: 
/* 3793 */       i = 0;
/* 3794 */       break;
/*      */     default: 
/* 3796 */       i = paramInt;
/*      */     }
/*      */     
/* 3799 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */   int getInternalType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3806 */     int i = 0;
/*      */     
/* 3808 */     switch (paramInt)
/*      */     {
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 3820 */       i = 6;
/* 3821 */       break;
/*      */     
/*      */     case 100: 
/* 3824 */       i = 100;
/* 3825 */       break;
/*      */     
/*      */     case 101: 
/* 3828 */       i = 101;
/* 3829 */       break;
/*      */     
/*      */     case 999: 
/* 3832 */       i = 999;
/* 3833 */       break;
/*      */     
/*      */     case 1: 
/* 3836 */       i = 96;
/* 3837 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -15: 
/*      */     case -9: 
/*      */     case 12: 
/* 3846 */       i = 1;
/* 3847 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -16: 
/*      */     case -1: 
/* 3855 */       i = 8;
/* 3856 */       break;
/*      */     
/*      */     case 91: 
/*      */     case 92: 
/* 3860 */       i = 12;
/* 3861 */       break;
/*      */     
/*      */     case -100: 
/*      */     case 93: 
/* 3865 */       i = 180;
/* 3866 */       break;
/*      */     
/*      */     case -101: 
/* 3869 */       i = 181;
/* 3870 */       break;
/*      */     
/*      */     case -102: 
/* 3873 */       i = 231;
/* 3874 */       break;
/*      */     
/*      */ 
/*      */     case -103: 
/* 3878 */       i = 182;
/* 3879 */       break;
/*      */     
/*      */     case -104: 
/* 3882 */       i = 183;
/* 3883 */       break;
/*      */     
/*      */     case -3: 
/*      */     case -2: 
/* 3887 */       i = 23;
/* 3888 */       break;
/*      */     
/*      */     case -4: 
/* 3891 */       i = 24;
/* 3892 */       break;
/*      */     
/*      */     case -8: 
/* 3895 */       i = 104;
/* 3896 */       break;
/*      */     
/*      */     case 2004: 
/* 3899 */       i = 113;
/* 3900 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2005: 
/*      */     case 2011: 
/* 3908 */       i = 112;
/* 3909 */       break;
/*      */     
/*      */     case -13: 
/* 3912 */       i = 114;
/* 3913 */       break;
/*      */     
/*      */     case -10: 
/* 3916 */       i = 102;
/* 3917 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2002: 
/*      */     case 2003: 
/*      */     case 2007: 
/*      */     case 2008: 
/*      */     case 2009: 
/* 3928 */       i = 109;
/* 3929 */       break;
/*      */     
/*      */     case 2006: 
/* 3932 */       i = 111;
/* 3933 */       break;
/*      */     
/*      */     case -14: 
/* 3936 */       i = 998;
/* 3937 */       break;
/*      */     
/*      */     case 70: 
/* 3940 */       i = 1;
/* 3941 */       break;
/*      */     
/*      */     case 0: 
/* 3944 */       i = 995;
/* 3945 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 3949 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.toString(paramInt));
/* 3950 */       localSQLException.fillInStackTrace();
/* 3951 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/* 3955 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void describe()
/*      */     throws SQLException
/*      */   {
/* 3973 */     synchronized (this.connection)
/*      */     {
/* 3975 */       ensureOpen();
/* 3976 */       if (!this.described)
/*      */       {
/* 3978 */         doDescribe(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void freeLine()
/*      */     throws SQLException
/*      */   {
/* 3987 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 3991 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 3995 */           this.nextStream.close();
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 4000 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4001 */           localSQLException.fillInStackTrace();
/* 4002 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 4006 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeUsedStreams(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4019 */     while ((this.nextStream != null) && (this.nextStream.columnIndex < paramInt))
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 4025 */         this.nextStream.close();
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 4030 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4031 */         localSQLException.fillInStackTrace();
/* 4032 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/* 4036 */       this.nextStream = this.nextStream.nextStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final void ensureOpen()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/* 4048 */     if (this.connection.lifecycle != 1)
/*      */     {
/* 4050 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4051 */       localSQLException.fillInStackTrace();
/* 4052 */       throw localSQLException;
/*      */     }
/* 4054 */     if (this.closed)
/*      */     {
/* 4056 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4057 */       localSQLException.fillInStackTrace();
/* 4058 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4092 */     synchronized (this.connection)
/*      */     {
/* 4094 */       if (paramInt == 1000)
/*      */       {
/*      */ 
/* 4097 */         this.defaultFetchDirection = paramInt;
/*      */       }
/* 4099 */       else if ((paramInt == 1001) || (paramInt == 1002))
/*      */       {
/*      */ 
/* 4102 */         this.defaultFetchDirection = 1000;
/* 4103 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 4109 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 4110 */         localSQLException.fillInStackTrace();
/* 4111 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 4134 */     return this.defaultFetchDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4153 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4156 */       setPrefetchInternal(paramInt, false, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 4179 */     return getPrefetchInternal(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/* 4191 */     return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/* 4203 */     return ResultSetUtil.getScrollType(this.userRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 4218 */     return this.connection.getWrapper();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResultSetCache(oracle.jdbc.OracleResultSetCache paramOracleResultSetCache)
/*      */     throws SQLException
/*      */   {
/* 4231 */     synchronized (this.connection)
/*      */     {
/*      */       try
/*      */       {
/* 4235 */         if (paramOracleResultSetCache == null)
/*      */         {
/* 4237 */           SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4238 */           localSQLException1.fillInStackTrace();
/* 4239 */           throw localSQLException1;
/*      */         }
/*      */         
/* 4242 */         if (this.rsetCache != null) {
/* 4243 */           this.rsetCache.close();
/*      */         }
/* 4245 */         this.rsetCache = paramOracleResultSetCache;
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 4250 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4251 */         localSQLException2.fillInStackTrace();
/* 4252 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache)
/*      */     throws SQLException
/*      */   {
/* 4269 */     synchronized (this.connection)
/*      */     {
/* 4271 */       setResultSetCache(paramOracleResultSetCache);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public OracleResultSetCache getResultSetCache()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 69	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 321	oracle/jdbc/driver/OracleStatement:rsetCache	Loracle/jdbc/OracleResultSetCache;
/*      */     //   11: checkcast 324	oracle/jdbc/driver/OracleResultSetCache
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: areturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #4282	-> byte code offset #0
/*      */     //   Java source line #4284	-> byte code offset #7
/*      */     //   Java source line #4286	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	OracleStatement
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   boolean isOracleBatchStyle()
/*      */   {
/* 4293 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4312 */   Vector m_batchItems = new Vector();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void initBatch() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int getBatchSize()
/*      */   {
/* 4324 */     return this.m_batchItems.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addBatchItem(String paramString)
/*      */   {
/* 4331 */     this.m_batchItems.addElement(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   String getBatchItem(int paramInt)
/*      */   {
/* 4338 */     return (String)this.m_batchItems.elementAt(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void clearBatchItems()
/*      */   {
/* 4345 */     this.m_batchItems.removeAllElements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkIfJdbcBatchExists()
/*      */     throws SQLException
/*      */   {
/* 4361 */     if (getBatchSize() > 0)
/*      */     {
/*      */ 
/* 4364 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/* 4365 */       localSQLException.fillInStackTrace();
/* 4366 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch(String paramString)
/*      */     throws SQLException
/*      */   {
/* 4392 */     synchronized (this.connection)
/*      */     {
/* 4394 */       addBatchItem(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearBatch()
/*      */     throws SQLException
/*      */   {
/* 4409 */     synchronized (this.connection)
/*      */     {
/* 4411 */       clearBatchItems();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 4442 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*      */ 
/* 4446 */       cleanOldTempLobs();
/* 4447 */       int i = 0;
/* 4448 */       int j = getBatchSize();
/* 4449 */       this.checkSum = 0L;
/* 4450 */       this.checkSumComputationFailure = false;
/*      */       
/*      */ 
/*      */ 
/* 4454 */       if (j <= 0)
/*      */       {
/*      */ 
/*      */ 
/* 4458 */         return new int[0];
/*      */       }
/*      */       
/* 4461 */       int[] arrayOfInt = new int[j];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4467 */       ensureOpen();
/*      */       
/*      */ 
/* 4470 */       prepareForNewResults(true, true);
/*      */       
/* 4472 */       int k = this.numberOfDefinePositions;
/* 4473 */       String str = this.sqlObject.getOriginalSql();
/* 4474 */       OracleStatement.SqlKind localSqlKind = this.sqlKind;
/*      */       
/*      */ 
/* 4477 */       this.noMoreUpdateCounts = false;
/*      */       
/* 4479 */       int m = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 4488 */         this.connection.registerHeartbeat();
/*      */         
/* 4490 */         this.connection.needLine();
/*      */         
/* 4492 */         for (i = 0; i < j; i++)
/*      */         {
/* 4494 */           this.sqlObject.initialize(getBatchItem(i));
/*      */           
/* 4496 */           this.sqlKind = this.sqlObject.getSqlKind();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4502 */           this.needToParse = true;
/* 4503 */           this.numberOfDefinePositions = 0;
/*      */           
/*      */ 
/* 4506 */           this.rowsProcessed = 0;
/* 4507 */           this.currentRank = 1;
/*      */           
/* 4509 */           if (this.sqlKind.isSELECT())
/*      */           {
/*      */ 
/* 4512 */             BatchUpdateException localBatchUpdateException1 = DatabaseError.createBatchUpdateException(80, "invalid SELECT batch command " + i, i, arrayOfInt);
/*      */             
/* 4514 */             localBatchUpdateException1.fillInStackTrace();
/* 4515 */             throw localBatchUpdateException1;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4520 */           if (!this.isOpen)
/*      */           {
/* 4522 */             this.connection.open(this);
/*      */             
/* 4524 */             this.isOpen = true;
/*      */           }
/*      */           
/* 4527 */           int n = -1;
/*      */           
/*      */           try
/*      */           {
/* 4531 */             if (this.queryTimeout != 0) {
/* 4532 */               this.connection.getTimeout().setTimeout(this.queryTimeout * 1000, this);
/*      */             }
/* 4534 */             this.isExecuting = true;
/*      */             
/* 4536 */             executeForRows(false);
/*      */             
/* 4538 */             if (this.validRows > 0) {
/* 4539 */               m += this.validRows;
/*      */             }
/* 4541 */             n = this.validRows;
/*      */           }
/*      */           catch (SQLException localSQLException2)
/*      */           {
/* 4545 */             this.needToParse = true;
/* 4546 */             resetCurrentRowBinders();
/* 4547 */             throw localSQLException2;
/*      */           }
/*      */           finally
/*      */           {
/* 4551 */             if (this.queryTimeout != 0) {
/* 4552 */               this.connection.getTimeout().cancelTimeout();
/*      */             }
/* 4554 */             this.validRows = m;
/*      */             
/* 4556 */             checkValidRowsStatus();
/*      */             
/* 4558 */             this.isExecuting = false;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4563 */           arrayOfInt[i] = n;
/*      */           
/* 4565 */           if (arrayOfInt[i] < 0)
/*      */           {
/*      */ 
/* 4568 */             localBatchUpdateException2 = DatabaseError.createBatchUpdateException(81, "command return value " + arrayOfInt[i], i, arrayOfInt);
/*      */             
/* 4570 */             localBatchUpdateException2.fillInStackTrace();
/* 4571 */             throw localBatchUpdateException2;
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       catch (SQLException localSQLException1)
/*      */       {
/* 4578 */         if ((localSQLException1 instanceof BatchUpdateException))
/*      */         {
/* 4580 */           throw localSQLException1;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4585 */         BatchUpdateException localBatchUpdateException2 = DatabaseError.createBatchUpdateException(81, localSQLException1.getMessage(), i, arrayOfInt);
/* 4586 */         localBatchUpdateException2.fillInStackTrace();
/* 4587 */         throw localBatchUpdateException2;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/* 4593 */         clearBatchItems();
/*      */         
/* 4595 */         this.numberOfDefinePositions = k;
/*      */         
/* 4597 */         if (str != null)
/*      */         {
/* 4599 */           this.sqlObject.initialize(str);
/*      */           
/* 4601 */           this.sqlKind = localSqlKind;
/*      */         }
/*      */         
/* 4604 */         this.currentRank = 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4611 */       this.connection.registerHeartbeat();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4617 */       return arrayOfInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int copyBinds(Statement paramStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4638 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyCloseRset()
/*      */     throws SQLException
/*      */   {
/* 4649 */     this.scrollRset = null;
/* 4650 */     endOfResultSet(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getOriginalSql()
/*      */     throws SQLException
/*      */   {
/* 4660 */     return this.sqlObject.getOriginalSql();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doScrollExecuteCommon()
/*      */     throws SQLException
/*      */   {
/* 4670 */     if (this.scrollRset != null)
/*      */     {
/* 4672 */       this.scrollRset.close();
/*      */       
/* 4674 */       this.scrollRset = null;
/*      */     }
/*      */     
/*      */ 
/* 4678 */     if (!this.sqlKind.isSELECT())
/*      */     {
/* 4680 */       doExecuteWithTimeout();
/*      */       
/* 4682 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4688 */     if (!this.needToAddIdentifier)
/*      */     {
/*      */ 
/*      */ 
/* 4692 */       doExecuteWithTimeout();
/*      */       
/* 4694 */       this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4695 */       this.realRsetType = this.userRsetType;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/* 4703 */         this.sqlObject.setIncludeRowid(true);
/*      */         
/* 4705 */         this.needToParse = true;
/*      */         
/*      */ 
/*      */ 
/* 4709 */         prepareForNewResults(true, false);
/*      */         
/* 4711 */         if (this.columnsDefinedByUser)
/*      */         {
/* 4713 */           Accessor[] arrayOfAccessor = this.accessors;
/*      */           
/* 4715 */           if ((this.accessors == null) || (this.accessors.length <= this.numberOfDefinePositions)) {
/* 4716 */             this.accessors = new Accessor[this.numberOfDefinePositions + 1];
/*      */           }
/* 4718 */           if (arrayOfAccessor != null) {
/* 4719 */             for (i = this.numberOfDefinePositions; i > 0; i--)
/*      */             {
/* 4721 */               localAccessor = arrayOfAccessor[(i - 1)];
/*      */               
/* 4723 */               this.accessors[i] = localAccessor;
/*      */               
/* 4725 */               if (localAccessor.isColumnNumberAware)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 4730 */                 localAccessor.updateColumnNumber(i);
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 4735 */           allocateRowidAccessor();
/*      */           
/* 4737 */           this.numberOfDefinePositions += 1;
/*      */         }
/*      */         
/* 4740 */         doExecuteWithTimeout();
/*      */         
/* 4742 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4743 */         this.realRsetType = this.userRsetType;
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/*      */         int i;
/*      */         
/*      */ 
/*      */         Accessor localAccessor;
/*      */         
/* 4752 */         if (this.userRsetType > 3) {
/* 4753 */           this.realRsetType = 3;
/*      */         } else {
/* 4755 */           this.realRsetType = 1;
/*      */         }
/* 4757 */         this.sqlObject.setIncludeRowid(false);
/*      */         
/* 4759 */         this.needToParse = true;
/*      */         
/*      */ 
/*      */ 
/* 4763 */         prepareForNewResults(true, false);
/*      */         
/* 4765 */         if (this.columnsDefinedByUser)
/*      */         {
/* 4767 */           this.needToPrepareDefineBuffer = true;
/* 4768 */           this.numberOfDefinePositions -= 1;
/*      */           
/* 4770 */           System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions);
/*      */           
/* 4772 */           this.accessors[this.numberOfDefinePositions] = null;
/*      */           
/* 4774 */           for (i = 0; i < this.numberOfDefinePositions; i++)
/*      */           {
/* 4776 */             localAccessor = this.accessors[i];
/*      */             
/* 4778 */             if (localAccessor.isColumnNumberAware)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 4783 */               localAccessor.updateColumnNumber(i);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4790 */         moveAllTempLobsToFree();
/* 4791 */         doExecuteWithTimeout();
/*      */         
/* 4793 */         this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 4794 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, localSQLException.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4802 */     this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/* 4816 */     this.accessors[0] = new RowidAccessor(this, 128, 1, -8, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleResultSet doScrollStmtExecuteQuery()
/*      */     throws SQLException
/*      */   {
/* 4825 */     doScrollExecuteCommon();
/*      */     
/* 4827 */     return this.scrollRset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void processDmlReturningBind()
/*      */     throws SQLException
/*      */   {
/* 4837 */     if (this.returnResultSet != null) { this.returnResultSet.close();
/*      */     }
/* 4839 */     this.returnParamsFetched = false;
/* 4840 */     this.returnParamRowBytes = 0;
/* 4841 */     this.returnParamRowChars = 0;
/*      */     
/* 4843 */     int i = 0;
/* 4844 */     for (int j = 0; j < this.numberOfBindPositions; j++)
/*      */     {
/* 4846 */       Accessor localAccessor = this.returnParamAccessors[j];
/*      */       
/* 4848 */       if (localAccessor != null)
/*      */       {
/* 4850 */         i++;
/*      */         
/* 4852 */         if (localAccessor.charLength > 0)
/*      */         {
/* 4854 */           this.returnParamRowChars += localAccessor.charLength;
/*      */         }
/*      */         else
/*      */         {
/* 4858 */           this.returnParamRowBytes += localAccessor.byteLength;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4863 */     if (this.isAutoGeneratedKey)
/*      */     {
/* 4865 */       this.numReturnParams = i;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 4870 */       if (this.numReturnParams <= 0) {
/* 4871 */         this.numReturnParams = this.sqlObject.getReturnParameterCount();
/*      */       }
/* 4873 */       if (this.numReturnParams != i)
/*      */       {
/* 4875 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173);
/* 4876 */         localSQLException.fillInStackTrace();
/* 4877 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4882 */     this.returnParamMeta[0] = this.numReturnParams;
/* 4883 */     this.returnParamMeta[1] = this.returnParamRowBytes;
/* 4884 */     this.returnParamMeta[2] = this.returnParamRowChars;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateDmlReturnStorage()
/*      */   {
/* 4892 */     if (this.rowsDmlReturned == 0) { return;
/*      */     }
/* 4894 */     int i = this.returnParamRowBytes * this.rowsDmlReturned;
/* 4895 */     int j = this.returnParamRowChars * this.rowsDmlReturned;
/* 4896 */     int k = 2 * this.numReturnParams * this.rowsDmlReturned;
/*      */     
/* 4898 */     this.returnParamBytes = new byte[i];
/* 4899 */     this.returnParamChars = new char[j];
/* 4900 */     this.returnParamIndicators = new short[k];
/*      */     
/*      */ 
/* 4903 */     for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */     {
/* 4905 */       Accessor localAccessor = this.returnParamAccessors[m];
/*      */       
/*      */ 
/* 4908 */       if ((localAccessor != null) && ((localAccessor.internalType == 111) || (localAccessor.internalType == 109)))
/*      */       {
/*      */ 
/*      */ 
/* 4912 */         TypeAccessor localTypeAccessor = (TypeAccessor)localAccessor;
/* 4913 */         if ((localTypeAccessor.pickledBytes == null) || (localTypeAccessor.pickledBytes.length < this.rowsDmlReturned))
/*      */         {
/* 4915 */           localTypeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetchDmlReturnParams()
/*      */     throws SQLException
/*      */   {
/* 4929 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4930 */     localSQLException.fillInStackTrace();
/* 4931 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setupReturnParamAccessors()
/*      */   {
/* 4941 */     if (this.rowsDmlReturned == 0) { return;
/*      */     }
/* 4943 */     int i = 0;
/* 4944 */     int j = 0;
/* 4945 */     int k = 0;
/* 4946 */     int m = this.numReturnParams * this.rowsDmlReturned;
/*      */     
/* 4948 */     for (int n = 0; n < this.numberOfBindPositions; n++)
/*      */     {
/* 4950 */       Accessor localAccessor = this.returnParamAccessors[n];
/*      */       
/* 4952 */       if (localAccessor != null)
/*      */       {
/* 4954 */         if (localAccessor.charLength > 0)
/*      */         {
/* 4956 */           localAccessor.rowSpaceChar = this.returnParamChars;
/* 4957 */           localAccessor.columnIndex = j;
/* 4958 */           j += this.rowsDmlReturned * localAccessor.charLength;
/*      */         }
/*      */         else
/*      */         {
/* 4962 */           localAccessor.rowSpaceByte = this.returnParamBytes;
/* 4963 */           localAccessor.columnIndex = i;
/* 4964 */           i += this.rowsDmlReturned * localAccessor.byteLength;
/*      */         }
/*      */         
/* 4967 */         localAccessor.rowSpaceIndicator = this.returnParamIndicators;
/* 4968 */         localAccessor.indicatorIndex = k;
/* 4969 */         k += this.rowsDmlReturned;
/* 4970 */         localAccessor.lengthIndex = m;
/* 4971 */         m += this.rowsDmlReturned;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void registerReturnParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString)
/*      */     throws SQLException
/*      */   {
/* 4987 */     if (this.returnParamAccessors == null) {
/* 4988 */       this.returnParamAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/* 4990 */     if (this.returnParamMeta == null)
/*      */     {
/* 4992 */       this.returnParamMeta = new int[3 + this.numberOfBindPositions * 4];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5001 */     switch (paramInt3) {
/*      */     case -16: 
/*      */     case -15: 
/*      */     case -9: 
/*      */     case 2011: 
/* 5006 */       paramShort = 2;
/* 5007 */       break;
/*      */     case 2009: 
/* 5009 */       paramString = "SYS.XMLTYPE";
/* 5010 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5019 */     Accessor localAccessor = allocateAccessor(paramInt2, paramInt3, paramInt1 + 1, paramInt4, paramShort, paramString, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5027 */     localAccessor.isDMLReturnedParam = true;
/* 5028 */     this.returnParamAccessors[paramInt1] = localAccessor;
/*      */     
/* 5030 */     int i = localAccessor.charLength > 0 ? 1 : 0;
/*      */     
/*      */ 
/* 5033 */     this.returnParamMeta[(3 + paramInt1 * 4 + 0)] = localAccessor.defineType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5038 */     this.returnParamMeta[(3 + paramInt1 * 4 + 1)] = (i != 0 ? 1 : 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5043 */     this.returnParamMeta[(3 + paramInt1 * 4 + 2)] = (i != 0 ? localAccessor.charLength : localAccessor.byteLength);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5048 */     this.returnParamMeta[(3 + paramInt1 * 4 + 3)] = paramShort;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public int creationState()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 69	oracle/jdbc/driver/OracleStatement:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 48	oracle/jdbc/driver/OracleStatement:creationState	I
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: ireturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5069	-> byte code offset #0
/*      */     //   Java source line #5071	-> byte code offset #7
/*      */     //   Java source line #5073	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	OracleStatement
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public boolean isColumnSetNull(int paramInt)
/*      */   {
/* 5090 */     return this.columnSetNull;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5108 */     if (!this.described) {
/* 5109 */       describe();
/*      */     }
/* 5111 */     int i = paramInt - 1;
/* 5112 */     if ((i < 0) || (i >= this.numberOfDefinePositions))
/*      */     {
/* 5114 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 5115 */       localSQLException.fillInStackTrace();
/* 5116 */       throw localSQLException;
/*      */     }
/*      */     
/* 5119 */     boolean bool = this.accessors[i].formOfUse == 2;
/*      */     
/*      */ 
/* 5122 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void addChild(OracleStatement paramOracleStatement)
/*      */   {
/* 5130 */     paramOracleStatement.nextChild = this.children;
/* 5131 */     this.children = paramOracleStatement;
/* 5132 */     paramOracleStatement.parent = this;
/*      */   }
/*      */   
/*      */ 
/*      */   void removeChild(OracleStatement paramOracleStatement)
/*      */   {
/* 5138 */     if (paramOracleStatement == this.children) {
/* 5139 */       this.children = paramOracleStatement.nextChild;
/*      */     }
/*      */     else {
/* 5142 */       OracleStatement localOracleStatement = this.children;
/* 5143 */       while (localOracleStatement.nextChild != paramOracleStatement) {
/* 5144 */         localOracleStatement = localOracleStatement.nextChild;
/*      */       }
/* 5146 */       localOracleStatement.nextChild = paramOracleStatement.nextChild;
/*      */     }
/* 5148 */     paramOracleStatement.parent = null;
/* 5149 */     paramOracleStatement.nextChild = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5186 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 5187 */     localSQLException.fillInStackTrace();
/* 5188 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5209 */     if (this.closed)
/*      */     {
/* 5211 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 5212 */       localSQLException.fillInStackTrace();
/* 5213 */       throw localSQLException;
/*      */     }
/*      */     
/* 5216 */     if (!this.isAutoGeneratedKey)
/*      */     {
/* 5218 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 5219 */       localSQLException.fillInStackTrace();
/* 5220 */       throw localSQLException;
/*      */     }
/*      */     
/* 5223 */     if ((this.returnParamAccessors == null) || (this.numReturnParams == 0))
/*      */     {
/* 5225 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 5226 */       localSQLException.fillInStackTrace();
/* 5227 */       throw localSQLException;
/*      */     }
/*      */     
/* 5230 */     if (this.returnResultSet == null)
/*      */     {
/* 5232 */       this.returnResultSet = new OracleReturnResultSet(this);
/*      */     }
/*      */     
/* 5235 */     return this.returnResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5268 */     this.autoKeyInfo = new AutoKeyInfo(paramString);
/* 5269 */     if ((paramInt == 2) || (!this.autoKeyInfo.isInsertSqlStmt()))
/*      */     {
/*      */ 
/* 5272 */       this.autoKeyInfo = null;
/* 5273 */       return executeUpdate(paramString);
/*      */     }
/*      */     
/* 5276 */     if (paramInt != 1)
/*      */     {
/* 5278 */       this.autoKeyInfo = null;
/*      */       
/* 5280 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5281 */       localSQLException.fillInStackTrace();
/* 5282 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 5286 */     synchronized (this.connection) {
/* 5287 */       this.isAutoGeneratedKey = true;
/* 5288 */       String str = this.autoKeyInfo.getNewSql();
/* 5289 */       this.numberOfBindPositions = 1;
/*      */       
/*      */ 
/* 5292 */       autoKeyRegisterReturnParams();
/*      */       
/* 5294 */       processDmlReturningBind();
/*      */       
/* 5296 */       return executeUpdateInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 5325 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0))
/*      */     {
/* 5327 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5328 */       localSQLException.fillInStackTrace();
/* 5329 */       throw localSQLException;
/*      */     }
/*      */     
/* 5332 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/* 5333 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5335 */       this.autoKeyInfo = null;
/* 5336 */       return executeUpdate(paramString);
/*      */     }
/*      */     
/* 5339 */     synchronized (this.connection) {
/* 5340 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5343 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5345 */       String str = this.autoKeyInfo.getNewSql();
/* 5346 */       this.numberOfBindPositions = paramArrayOfInt.length;
/*      */       
/*      */ 
/* 5349 */       autoKeyRegisterReturnParams();
/*      */       
/* 5351 */       processDmlReturningBind();
/*      */       
/* 5353 */       return executeUpdateInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String paramString, String[] paramArrayOfString)
/*      */     throws SQLException
/*      */   {
/* 5381 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
/*      */     {
/* 5383 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5384 */       localSQLException.fillInStackTrace();
/* 5385 */       throw localSQLException;
/*      */     }
/*      */     
/* 5388 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/* 5389 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5391 */       this.autoKeyInfo = null;
/* 5392 */       return executeUpdate(paramString);
/*      */     }
/*      */     
/* 5395 */     synchronized (this.connection) {
/* 5396 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5399 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5401 */       String str = this.autoKeyInfo.getNewSql();
/* 5402 */       this.numberOfBindPositions = paramArrayOfString.length;
/*      */       
/*      */ 
/* 5405 */       autoKeyRegisterReturnParams();
/*      */       
/* 5407 */       processDmlReturningBind();
/*      */       
/* 5409 */       return executeUpdateInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5456 */     this.autoKeyInfo = new AutoKeyInfo(paramString);
/* 5457 */     if ((paramInt == 2) || (!this.autoKeyInfo.isInsertSqlStmt()))
/*      */     {
/*      */ 
/* 5460 */       this.autoKeyInfo = null;
/* 5461 */       return execute(paramString);
/*      */     }
/*      */     
/* 5464 */     if (paramInt != 1)
/*      */     {
/* 5466 */       this.autoKeyInfo = null;
/*      */       
/* 5468 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5469 */       localSQLException.fillInStackTrace();
/* 5470 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 5474 */     synchronized (this.connection) {
/* 5475 */       this.isAutoGeneratedKey = true;
/* 5476 */       String str = this.autoKeyInfo.getNewSql();
/* 5477 */       this.numberOfBindPositions = 1;
/*      */       
/*      */ 
/* 5480 */       autoKeyRegisterReturnParams();
/*      */       
/* 5482 */       processDmlReturningBind();
/*      */       
/* 5484 */       return executeInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 5530 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0))
/*      */     {
/* 5532 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5533 */       localSQLException.fillInStackTrace();
/* 5534 */       throw localSQLException;
/*      */     }
/*      */     
/* 5537 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/* 5538 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5540 */       this.autoKeyInfo = null;
/* 5541 */       return execute(paramString);
/*      */     }
/*      */     
/* 5544 */     synchronized (this.connection) {
/* 5545 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5548 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5550 */       String str = this.autoKeyInfo.getNewSql();
/* 5551 */       this.numberOfBindPositions = paramArrayOfInt.length;
/*      */       
/*      */ 
/* 5554 */       autoKeyRegisterReturnParams();
/*      */       
/* 5556 */       processDmlReturningBind();
/*      */       
/* 5558 */       return executeInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String paramString, String[] paramArrayOfString)
/*      */     throws SQLException
/*      */   {
/* 5605 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
/*      */     {
/* 5607 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 5608 */       localSQLException.fillInStackTrace();
/* 5609 */       throw localSQLException;
/*      */     }
/*      */     
/* 5612 */     this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/* 5613 */     if (!this.autoKeyInfo.isInsertSqlStmt())
/*      */     {
/* 5615 */       this.autoKeyInfo = null;
/* 5616 */       return execute(paramString);
/*      */     }
/*      */     
/* 5619 */     synchronized (this.connection) {
/* 5620 */       this.isAutoGeneratedKey = true;
/*      */       
/*      */ 
/* 5623 */       this.connection.doDescribeTable(this.autoKeyInfo);
/*      */       
/* 5625 */       String str = this.autoKeyInfo.getNewSql();
/* 5626 */       this.numberOfBindPositions = paramArrayOfString.length;
/*      */       
/*      */ 
/* 5629 */       autoKeyRegisterReturnParams();
/*      */       
/* 5631 */       processDmlReturningBind();
/*      */       
/* 5633 */       return executeInternal(str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 5653 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getcacheState()
/*      */   {
/* 5660 */     return this.cacheState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getstatementType()
/*      */   {
/* 5667 */     return this.statementType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getserverCursor()
/*      */   {
/* 5674 */     return this.serverCursor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void initializeIndicatorSubRange()
/*      */   {
/* 5682 */     this.bindIndicatorSubRange = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autoKeyRegisterReturnParams()
/*      */     throws SQLException
/*      */   {
/* 5693 */     initializeIndicatorSubRange();
/*      */     
/* 5695 */     int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5701 */     int j = i + 2 * this.numberOfBindPositions;
/*      */     
/*      */ 
/*      */ 
/* 5705 */     this.bindIndicators = new short[j];
/*      */     
/* 5707 */     int k = this.bindIndicatorSubRange;
/*      */     
/* 5709 */     this.bindIndicators[(k + 0)] = ((short)this.numberOfBindPositions);
/*      */     
/*      */ 
/*      */ 
/* 5713 */     this.bindIndicators[(k + 1)] = 0;
/*      */     
/*      */ 
/*      */ 
/* 5717 */     this.bindIndicators[(k + 2)] = 1;
/*      */     
/*      */ 
/*      */ 
/* 5721 */     this.bindIndicators[(k + 3)] = 0;
/*      */     
/*      */ 
/*      */ 
/* 5725 */     this.bindIndicators[(k + 4)] = 1;
/*      */     
/*      */ 
/*      */ 
/* 5729 */     k += 5;
/*      */     
/*      */ 
/* 5732 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 5733 */     int[] arrayOfInt = this.autoKeyInfo.columnIndexes;
/*      */     
/* 5735 */     for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */     {
/* 5737 */       this.bindIndicators[(k + 0)] = 994;
/*      */       
/*      */ 
/*      */ 
/* 5741 */       short s = this.connection.defaultnchar ? 2 : 1;
/*      */       
/*      */ 
/* 5744 */       if ((arrayOfShort != null) && (arrayOfInt != null))
/*      */       {
/* 5746 */         if (arrayOfShort[(arrayOfInt[m] - 1)] == 2)
/*      */         {
/*      */ 
/* 5749 */           s = 2;
/* 5750 */           this.bindIndicators[(k + 9)] = s;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5756 */       k += 10;
/*      */       
/*      */ 
/* 5759 */       checkTypeForAutoKey(this.autoKeyInfo.returnTypes[m]);
/*      */       
/* 5761 */       String str = null;
/* 5762 */       if (this.autoKeyInfo.returnTypes[m] == 111) {
/* 5763 */         str = this.autoKeyInfo.tableTypeNames[(arrayOfInt[m] - 1)];
/*      */       }
/*      */       
/* 5766 */       registerReturnParameterInternal(m, this.autoKeyInfo.returnTypes[m], this.autoKeyInfo.returnTypes[m], -1, s, str);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void setNonAutoKey()
/*      */   {
/* 5776 */     this.isAutoGeneratedKey = false;
/* 5777 */     this.numberOfBindPositions = 0;
/* 5778 */     this.bindIndicators = null;
/* 5779 */     this.returnParamMeta = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 5796 */     if (paramArrayOfChar != this.defineChars) this.connection.cacheBuffer(paramArrayOfChar);
/* 5797 */     if (paramArrayOfByte != this.defineBytes) { this.connection.cacheBuffer(paramArrayOfByte);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   final void checkTypeForAutoKey(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 5805 */     if (paramInt == 109)
/*      */     {
/* 5807 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 5);
/* 5808 */       localSQLException.fillInStackTrace();
/* 5809 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 5814 */   ArrayList tempClobsToFree = null;
/* 5815 */   ArrayList tempBlobsToFree = null;
/*      */   
/* 5817 */   ArrayList oldTempClobsToFree = null;
/* 5818 */   ArrayList oldTempBlobsToFree = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void moveAllTempLobsToFree()
/*      */   {
/* 5830 */     if (this.oldTempClobsToFree != null)
/*      */     {
/* 5832 */       if (this.tempClobsToFree == null) {
/* 5833 */         this.tempClobsToFree = this.oldTempClobsToFree;
/*      */       } else {
/* 5835 */         this.tempClobsToFree.add(this.oldTempClobsToFree);
/*      */       }
/* 5837 */       this.oldTempClobsToFree = null;
/*      */     }
/*      */     
/* 5840 */     if (this.oldTempBlobsToFree != null)
/*      */     {
/* 5842 */       if (this.tempBlobsToFree == null) {
/* 5843 */         this.tempBlobsToFree = this.oldTempBlobsToFree;
/*      */       } else {
/* 5845 */         this.tempBlobsToFree.add(this.oldTempBlobsToFree);
/*      */       }
/* 5847 */       this.oldTempBlobsToFree = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void moveTempLobsToFree(CLOB paramCLOB)
/*      */   {
/*      */     int i;
/*      */     
/* 5857 */     if ((this.oldTempClobsToFree != null) && 
/* 5858 */       ((i = this.oldTempClobsToFree.indexOf(paramCLOB)) != -1))
/*      */     {
/* 5860 */       addToTempLobsToFree(paramCLOB);
/* 5861 */       this.oldTempClobsToFree.remove(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void moveTempLobsToFree(BLOB paramBLOB)
/*      */   {
/*      */     int i;
/*      */     
/* 5871 */     if ((this.oldTempBlobsToFree != null) && 
/* 5872 */       ((i = this.oldTempBlobsToFree.indexOf(paramBLOB)) != -1))
/*      */     {
/* 5874 */       addToTempLobsToFree(paramBLOB);
/* 5875 */       this.oldTempBlobsToFree.remove(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void addToTempLobsToFree(CLOB paramCLOB)
/*      */   {
/* 5884 */     if (this.tempClobsToFree == null)
/* 5885 */       this.tempClobsToFree = new ArrayList();
/* 5886 */     this.tempClobsToFree.add(paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToTempLobsToFree(BLOB paramBLOB)
/*      */   {
/* 5893 */     if (this.tempBlobsToFree == null)
/* 5894 */       this.tempBlobsToFree = new ArrayList();
/* 5895 */     this.tempBlobsToFree.add(paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToOldTempLobsToFree(CLOB paramCLOB)
/*      */   {
/* 5902 */     if (this.oldTempClobsToFree == null)
/* 5903 */       this.oldTempClobsToFree = new ArrayList();
/* 5904 */     this.oldTempClobsToFree.add(paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToOldTempLobsToFree(BLOB paramBLOB)
/*      */   {
/* 5911 */     if (this.oldTempBlobsToFree == null)
/* 5912 */       this.oldTempBlobsToFree = new ArrayList();
/* 5913 */     this.oldTempBlobsToFree.add(paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanAllTempLobs()
/*      */   {
/* 5920 */     cleanTempClobs(this.tempClobsToFree);
/* 5921 */     this.tempClobsToFree = null;
/* 5922 */     cleanTempBlobs(this.tempBlobsToFree);
/* 5923 */     this.tempBlobsToFree = null;
/* 5924 */     cleanTempClobs(this.oldTempClobsToFree);
/* 5925 */     this.oldTempClobsToFree = null;
/* 5926 */     cleanTempBlobs(this.oldTempBlobsToFree);
/* 5927 */     this.oldTempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanOldTempLobs()
/*      */   {
/* 5934 */     cleanTempClobs(this.oldTempClobsToFree);
/* 5935 */     cleanTempBlobs(this.oldTempBlobsToFree);
/* 5936 */     this.oldTempClobsToFree = this.tempClobsToFree;
/* 5937 */     this.tempClobsToFree = null;
/* 5938 */     this.oldTempBlobsToFree = this.tempBlobsToFree;
/* 5939 */     this.tempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanTempClobs(ArrayList paramArrayList)
/*      */   {
/* 5946 */     if (paramArrayList != null)
/*      */     {
/* 5948 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 5950 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 5954 */           ((CLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cleanTempBlobs(ArrayList paramArrayList)
/*      */   {
/* 5969 */     if (paramArrayList != null)
/*      */     {
/* 5971 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 5973 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 5977 */           ((BLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   TimeZone getDefaultTimeZone()
/*      */     throws SQLException
/*      */   {
/* 5997 */     return getDefaultTimeZone(false);
/*      */   }
/*      */   
/*      */   TimeZone getDefaultTimeZone(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 6003 */     if (this.defaultTimeZone == null)
/*      */     {
/*      */       try {
/* 6006 */         this.defaultTimeZone = this.connection.getDefaultTimeZone();
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */       
/*      */ 
/* 6011 */       if (this.defaultTimeZone == null) {
/* 6012 */         this.defaultTimeZone = TimeZone.getDefault();
/*      */       }
/*      */     }
/* 6015 */     return this.defaultTimeZone;
/*      */   }
/*      */   
/*      */ 
/* 6019 */   NTFDCNRegistration registration = null;
/* 6020 */   String[] dcnTableName = null;
/* 6021 */   long dcnQueryId = -1L;
/*      */   static final byte IS_UNINITIALIZED = 0;
/*      */   static final byte IS_SELECT = 1;
/*      */   
/*      */   public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException {
/* 6026 */     this.registration = ((NTFDCNRegistration)paramDatabaseChangeRegistration);
/*      */   }
/*      */   
/*      */   public String[] getRegisteredTableNames() throws SQLException
/*      */   {
/* 6031 */     return this.dcnTableName;
/*      */   }
/*      */   
/*      */   public long getRegisteredQueryId() throws SQLException {
/* 6035 */     return this.dcnQueryId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Calendar getDefaultCalendar()
/*      */     throws SQLException
/*      */   {
/* 6043 */     if (this.defaultCalendar == null)
/*      */     {
/* 6045 */       this.defaultCalendar = Calendar.getInstance(getDefaultTimeZone());
/*      */     }
/*      */     
/* 6048 */     return this.defaultCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/* 6054 */     this.cachedDefineIndicatorSize = (this.defineIndicators != null ? this.defineIndicators.length : 0);
/* 6055 */     this.cachedDefineMetaDataSize = (this.defineMetaData != null ? this.defineMetaData.length : 0);
/* 6056 */     this.connection.cacheBuffer(this.defineChars);
/* 6057 */     this.defineChars = null;
/* 6058 */     this.connection.cacheBuffer(this.defineBytes);
/* 6059 */     this.defineBytes = null;
/* 6060 */     this.defineIndicators = null;
/* 6061 */     this.defineMetaData = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isClosed()
/*      */     throws SQLException
/*      */   {
/* 6069 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPoolable()
/*      */     throws SQLException
/*      */   {
/* 6081 */     if (this.closed)
/*      */     {
/* 6083 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6084 */       localSQLException.fillInStackTrace();
/* 6085 */       throw localSQLException;
/*      */     }
/*      */     
/* 6088 */     return this.cacheState != 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPoolable(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 6104 */     if (this.closed)
/*      */     {
/* 6106 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6107 */       localSQLException.fillInStackTrace();
/* 6108 */       throw localSQLException;
/*      */     }
/*      */     
/* 6111 */     if (paramBoolean) {
/* 6112 */       this.cacheState = 1;
/*      */     }
/*      */     else {
/* 6115 */       this.cacheState = 3;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWrapperFor(Class<?> paramClass)
/*      */     throws SQLException
/*      */   {
/* 6131 */     if (paramClass.isInterface()) { return paramClass.isInstance(this);
/*      */     }
/* 6133 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 6134 */     localSQLException.fillInStackTrace();
/* 6135 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final byte IS_DELETE = 2;
/*      */   
/*      */ 
/*      */   static final byte IS_INSERT = 4;
/*      */   
/*      */ 
/*      */   static final byte IS_MERGE = 8;
/*      */   
/*      */ 
/*      */   public <T> T unwrap(Class<T> paramClass)
/*      */     throws SQLException
/*      */   {
/* 6152 */     if ((paramClass.isInterface()) && (paramClass.isInstance(this))) { return this;
/*      */     }
/* 6154 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 6155 */     localSQLException.fillInStackTrace();
/* 6156 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */   static final byte IS_UPDATE = 16;
/*      */   
/*      */   static final byte IS_PLSQL_BLOCK = 32;
/*      */   
/*      */   static final byte IS_CALL_BLOCK = 64;
/*      */   
/*      */   static final byte IS_OTHER = -128;
/*      */   
/*      */   static final byte IS_DML = 30;
/*      */   
/*      */   static final byte IS_PLSQL = 96;
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 6173 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Calendar getGMTCalendar()
/*      */   {
/* 6184 */     if (this.gmtCalendar == null)
/*      */     {
/* 6186 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
/*      */     }
/*      */     
/*      */ 
/* 6190 */     return this.gmtCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void extractNioDefineBuffers(int paramInt)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void internalClose()
/*      */     throws SQLException
/*      */   {
/* 6215 */     this.closed = true;
/* 6216 */     if (this.currentResultSet != null) {
/* 6217 */       this.currentResultSet.closed = true;
/*      */     }
/* 6219 */     cleanupDefines();
/* 6220 */     this.bindBytes = null;
/* 6221 */     this.bindChars = null;
/* 6222 */     this.bindIndicators = null;
/*      */     
/* 6224 */     this.outBindAccessors = null;
/* 6225 */     this.parameterStream = ((InputStream[][])null);
/* 6226 */     this.userStream = ((Object[][])null);
/*      */     
/* 6228 */     this.ibtBindBytes = null;
/* 6229 */     this.ibtBindChars = null;
/* 6230 */     this.ibtBindIndicators = null;
/*      */     
/* 6232 */     this.lobPrefetchMetaData = null;
/* 6233 */     this.tmpByteArray = null;
/*      */     
/* 6235 */     this.definedColumnType = null;
/* 6236 */     this.definedColumnSize = null;
/* 6237 */     this.definedColumnFormOfUse = null;
/*      */     
/*      */ 
/*      */ 
/* 6241 */     if (this.wrapper != null) {
/* 6242 */       this.wrapper.close();
/*      */     }
/*      */   }
/*      */   
/*      */   void calculateCheckSum() throws SQLException {
/* 6247 */     if (!this.connection.calculateChecksum) {
/* 6248 */       return;
/*      */     }
/* 6250 */     if (this.accessors != null) {
/* 6251 */       accessorChecksum(this.accessors);
/*      */     }
/* 6253 */     if (this.outBindAccessors != null) {
/* 6254 */       accessorChecksum(this.outBindAccessors);
/*      */     }
/* 6256 */     if ((this.returnParamAccessors != null) && (this.returnParamsFetched)) {
/* 6257 */       accessorChecksum(this.returnParamAccessors);
/*      */     }
/* 6259 */     long l = CRC64.updateChecksum(this.checkSum, this.validRows);
/* 6260 */     this.checkSum = l;
/*      */   }
/*      */   
/*      */   void accessorChecksum(Accessor[] paramArrayOfAccessor) throws SQLException
/*      */   {
/* 6265 */     long l = this.checkSum;
/* 6266 */     int i = 0;
/* 6267 */     int j = 0;
/*      */     
/*      */ 
/* 6270 */     for (Accessor localAccessor : paramArrayOfAccessor)
/*      */     {
/* 6272 */       if (localAccessor != null)
/*      */       {
/* 6274 */         switch (localAccessor.internalType)
/*      */         {
/*      */         case 112: 
/*      */         case 113: 
/*      */         case 114: 
/* 6279 */           if (i == 0) {
/* 6280 */             j = 1;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         case 8: 
/*      */         case 24: 
/* 6287 */           j = 0;
/*      */           
/* 6289 */           break;
/*      */         
/*      */         default: 
/* 6292 */           j = 0;
/*      */           
/*      */ 
/*      */ 
/* 6296 */           i++;
/* 6297 */           for (int n = 0; n < this.validRows; n++)
/*      */           {
/* 6299 */             if (localAccessor.rowSpaceIndicator != null)
/* 6300 */               l = localAccessor.updateChecksum(l, n);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 6305 */     if (j != 0) {
/* 6306 */       this.checkSumComputationFailure = true;
/*      */     }
/* 6308 */     this.checkSum = l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public long getChecksum()
/*      */     throws SQLException
/*      */   {
/* 6316 */     if (this.checkSumComputationFailure)
/*      */     {
/* 6318 */       SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 6319 */       localSQLException.fillInStackTrace();
/* 6320 */       throw localSQLException;
/*      */     }
/*      */     
/* 6323 */     return this.checkSum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte convertSqlKindEnumToByte(OracleStatement.SqlKind paramSqlKind)
/*      */   {
/* 6340 */     switch (paramSqlKind)
/*      */     {
/*      */     case DELETE: 
/* 6343 */       return 2;
/*      */     
/*      */     case INSERT: 
/* 6346 */       return 4;
/*      */     
/*      */     case MERGE: 
/* 6349 */       return 8;
/*      */     
/*      */     case UPDATE: 
/* 6352 */       return 16;
/*      */     
/*      */     case ALTER_SESSION: 
/*      */     case OTHER: 
/* 6356 */       return Byte.MIN_VALUE;
/*      */     
/*      */     case PLSQL_BLOCK: 
/* 6359 */       return 32;
/*      */     
/*      */     case CALL_BLOCK: 
/* 6362 */       return 64;
/*      */     
/*      */     case SELECT_FOR_UPDATE: 
/*      */     case SELECT: 
/* 6366 */       return 1;
/*      */     }
/*      */     
/* 6369 */     if (paramSqlKind.isPlsqlOrCall())
/* 6370 */       return 96;
/* 6371 */     if (paramSqlKind.isDML()) {
/* 6372 */       return 30;
/*      */     }
/* 6374 */     return 0;
/*      */   }
/*      */   
/*      */   static final OracleStatement.SqlKind convertSqlKindByteToEnum(byte paramByte)
/*      */   {
/* 6379 */     switch (paramByte)
/*      */     {
/*      */     case 2: 
/* 6382 */       return OracleStatement.SqlKind.DELETE;
/*      */     
/*      */     case 4: 
/* 6385 */       return OracleStatement.SqlKind.INSERT;
/*      */     
/*      */     case 8: 
/* 6388 */       return OracleStatement.SqlKind.MERGE;
/*      */     
/*      */     case 16: 
/* 6391 */       return OracleStatement.SqlKind.UPDATE;
/*      */     
/*      */     case -128: 
/* 6394 */       return OracleStatement.SqlKind.OTHER;
/*      */     
/*      */     case 32: 
/* 6397 */       return OracleStatement.SqlKind.PLSQL_BLOCK;
/*      */     
/*      */     case 64: 
/* 6400 */       return OracleStatement.SqlKind.CALL_BLOCK;
/*      */     
/*      */     case 1: 
/* 6403 */       return OracleStatement.SqlKind.SELECT;
/*      */     }
/*      */     
/*      */     
/* 6407 */     return OracleStatement.SqlKind.UNINITIALIZED;
/*      */   }
/*      */   
/*      */ 
/* 6411 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\OracleStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */