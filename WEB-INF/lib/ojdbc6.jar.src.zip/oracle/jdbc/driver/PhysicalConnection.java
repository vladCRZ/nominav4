/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.lang.reflect.Field;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.InetAddress;
/*       */ import java.net.UnknownHostException;
/*       */ import java.sql.Array;
/*       */ import java.sql.CallableStatement;
/*       */ import java.sql.Connection;
/*       */ import java.sql.Date;
/*       */ import java.sql.DriverManager;
/*       */ import java.sql.NClob;
/*       */ import java.sql.PreparedStatement;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLWarning;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Savepoint;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Calendar;
/*       */ import java.util.EnumSet;
/*       */ import java.util.Enumeration;
/*       */ import java.util.Hashtable;
/*       */ import java.util.Iterator;
/*       */ import java.util.Map;
/*       */ import java.util.Properties;
/*       */ import java.util.TimeZone;
/*       */ import java.util.Vector;
/*       */ import java.util.concurrent.Executor;
/*       */ import java.util.regex.Pattern;
/*       */ import oracle.jdbc.OracleConnection.CommitOption;
/*       */ import oracle.jdbc.OracleConnection.DatabaseShutdownMode;
/*       */ import oracle.jdbc.OracleConnection.DatabaseStartupMode;
/*       */ import oracle.jdbc.OracleOCIFailover;
/*       */ import oracle.jdbc.OracleSQLPermission;
/*       */ import oracle.jdbc.aq.AQDequeueOptions;
/*       */ import oracle.jdbc.aq.AQEnqueueOptions;
/*       */ import oracle.jdbc.aq.AQMessage;
/*       */ import oracle.jdbc.aq.AQNotificationRegistration;
/*       */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*       */ import oracle.jdbc.internal.KeywordValueLong;
/*       */ import oracle.jdbc.internal.OracleConnection.BufferCacheStatistics;
/*       */ import oracle.jdbc.internal.OracleConnection.InstanceProperty;
/*       */ import oracle.jdbc.internal.OracleConnection.TransactionState;
/*       */ import oracle.jdbc.internal.OracleConnection.XSOperationCode;
/*       */ import oracle.jdbc.internal.XSEventListener;
/*       */ import oracle.jdbc.internal.XSNamespace;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeCLOB;
/*       */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*       */ import oracle.jdbc.pool.OraclePooledConnection;
/*       */ import oracle.net.nt.CustomSSLSocketFactory;
/*       */ import oracle.security.pki.OracleSecretStore;
/*       */ import oracle.security.pki.OracleWallet;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NCLOB;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.SQLName;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ import oracle.sql.TIMEZONETAB;
/*       */ import oracle.sql.TypeDescriptor;
/*       */ 
/*       */ abstract class PhysicalConnection extends OracleConnection
/*       */ {
/*       */   public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
/*       */   public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
/*       */   public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
/*       */   public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
/*       */   public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
/*    89 */   static final CRC64 CHECKSUM = new CRC64();
/*       */   public static final char slash_character = '/';
/*       */   public static final char at_sign_character = '@';
/*       */   public static final char left_square_bracket_character = '[';
/*       */   public static final char right_square_bracket_character = ']';
/*    94 */   static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*    99 */   long outScn = 0L;
/*       */   
/*   101 */   char[][] charOutput = new char[1][];
/*   102 */   byte[][] byteOutput = new byte[1][];
/*   103 */   short[][] shortOutput = new short[1][];
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   109 */   Properties sessionProperties = null;
/*       */   
/*       */   boolean retainV9BindBehavior;
/*       */   
/*       */   String userName;
/*       */   
/*       */   String database;
/*       */   
/*       */   boolean autocommit;
/*       */   
/*       */   String protocol;
/*       */   
/*       */   int streamChunkSize;
/*       */   
/*       */   boolean setFloatAndDoubleUseBinary;
/*       */   String ocidll;
/*       */   String thinVsessionTerminal;
/*       */   String thinVsessionMachine;
/*       */   String thinVsessionOsuser;
/*       */   String thinVsessionProgram;
/*       */   String thinVsessionProcess;
/*       */   String thinVsessionIname;
/*       */   String thinVsessionEname;
/*       */   String thinNetProfile;
/*       */   String thinNetAuthenticationServices;
/*       */   String thinNetAuthenticationKrb5Mutual;
/*       */   String thinNetAuthenticationKrb5CcName;
/*       */   String thinNetEncryptionLevel;
/*       */   String thinNetEncryptionTypes;
/*       */   String thinNetChecksumLevel;
/*       */   String thinNetChecksumTypes;
/*       */   String thinNetCryptoSeed;
/*       */   boolean thinTcpNoDelay;
/*       */   String thinReadTimeout;
/*       */   String thinNetConnectTimeout;
/*       */   boolean thinNetDisableOutOfBandBreak;
/*       */   boolean thinNetUseZeroCopyIO;
/*       */   boolean thinNetEnableSDP;
/*       */   boolean use1900AsYearForTime;
/*       */   boolean timestamptzInGmt;
/*       */   boolean timezoneAsRegion;
/*       */   String thinSslServerDnMatch;
/*       */   String thinSslVersion;
/*       */   String thinSslCipherSuites;
/*       */   String thinJavaxNetSslKeystore;
/*       */   String thinJavaxNetSslKeystoretype;
/*       */   String thinJavaxNetSslKeystorepassword;
/*       */   String thinJavaxNetSslTruststore;
/*       */   String thinJavaxNetSslTruststoretype;
/*       */   String thinJavaxNetSslTruststorepassword;
/*       */   String thinSslKeymanagerfactoryAlgorithm;
/*       */   String thinSslTrustmanagerfactoryAlgorithm;
/*       */   String thinNetOldsyntax;
/*       */   String thinNamingContextInitial;
/*       */   String thinNamingProviderUrl;
/*       */   String thinNamingSecurityAuthentication;
/*       */   String thinNamingSecurityPrincipal;
/*       */   String thinNamingSecurityCredentials;
/*       */   String walletLocation;
/*       */   String walletPassword;
/*       */   String proxyClientName;
/*       */   boolean useNio;
/*       */   String ociDriverCharset;
/*       */   String editionName;
/*       */   String logonCap;
/*       */   String internalLogon;
/*       */   boolean createDescriptorUseCurrentSchemaForSchemaName;
/*       */   long ociSvcCtxHandle;
/*       */   long ociEnvHandle;
/*       */   long ociErrHandle;
/*       */   boolean prelimAuth;
/*       */   boolean nlsLangBackdoor;
/*       */   String setNewPassword;
/*       */   boolean spawnNewThreadToCancel;
/*       */   int defaultExecuteBatch;
/*       */   int defaultRowPrefetch;
/*       */   int defaultLobPrefetchSize;
/*       */   boolean enableDataInLocator;
/*       */   boolean enableReadDataInLocator;
/*       */   boolean overrideEnableReadDataInLocator;
/*       */   boolean reportRemarks;
/*       */   boolean includeSynonyms;
/*       */   boolean restrictGettables;
/*       */   boolean accumulateBatchResult;
/*       */   boolean useFetchSizeWithLongColumn;
/*       */   boolean processEscapes;
/*       */   boolean fixedString;
/*       */   boolean defaultnchar;
/*       */   boolean permitTimestampDateMismatch;
/*       */   String resourceManagerId;
/*       */   boolean disableDefinecolumntype;
/*       */   boolean convertNcharLiterals;
/*       */   boolean j2ee13Compliant;
/*       */   boolean mapDateToTimestamp;
/*       */   boolean useThreadLocalBufferCache;
/*       */   String driverNameAttribute;
/*       */   int maxCachedBufferSize;
/*       */   int implicitStatementCacheSize;
/*       */   boolean lobStreamPosStandardCompliant;
/*       */   boolean isStrictAsciiConversion;
/*       */   boolean thinForceDnsLoadBalancing;
/*       */   boolean calculateChecksum;
/*       */   boolean enableJavaNetFastPath;
/*       */   boolean enableTempLobRefCnt;
/*       */   boolean keepAlive;
/*       */   String url;
/*       */   String savedUser;
/*       */   int commitOption;
/*   217 */   int ociConnectionPoolMinLimit = 0;
/*   218 */   int ociConnectionPoolMaxLimit = 0;
/*   219 */   int ociConnectionPoolIncrement = 0;
/*   220 */   int ociConnectionPoolTimeout = 0;
/*   221 */   boolean ociConnectionPoolNoWait = false;
/*   222 */   boolean ociConnectionPoolTransactionDistributed = false;
/*   223 */   String ociConnectionPoolLogonMode = null;
/*   224 */   boolean ociConnectionPoolIsPooling = false;
/*   225 */   Object ociConnectionPoolObject = null;
/*   226 */   Object ociConnectionPoolConnID = null;
/*   227 */   String ociConnectionPoolProxyType = null;
/*   228 */   Integer ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
/*   229 */   Object ociConnectionPoolProxyRoles = null;
/*   230 */   String ociConnectionPoolProxyUserName = null;
/*   231 */   String ociConnectionPoolProxyPassword = null;
/*   232 */   String ociConnectionPoolProxyDistinguishedName = null;
/*   233 */   Object ociConnectionPoolProxyCertificate = null;
/*       */   
/*   235 */   static NTFManager ntfManager = new NTFManager();
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   246 */   public int protocolId = -3;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleTimeout timeout;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   DBConversion conversion;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean xaWantsError;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean usingXA;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*   271 */   int txnMode = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   byte[] fdo;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   Boolean bigEndian;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleStatement statements;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   int lifecycle;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   static final int OPEN = 1;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   static final int CLOSING = 2;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   static final int CLOSED = 4;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   static final int ABORTED = 8;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   static final int BLOCKED = 16;
/*       */   
/*       */ 
/*       */ 
/*   320 */   boolean clientIdSet = false;
/*   321 */   String clientId = null;
/*       */   
/*       */ 
/*       */ 
/*       */   int txnLevel;
/*       */   
/*       */ 
/*       */ 
/*       */   Map map;
/*       */   
/*       */ 
/*       */ 
/*       */   Map javaObjectMap;
/*       */   
/*       */ 
/*       */ 
/*   337 */   final Hashtable[] descriptorCacheStack = new Hashtable[2];
/*       */   
/*   339 */   int dci = 0;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleStatement statementHoldingLine;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   351 */   oracle.jdbc.OracleDatabaseMetaData databaseMetaData = null;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   LogicalConnection logicalConnectionAttached;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*   361 */   boolean isProxy = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*   366 */   OracleSql sqlObj = null;
/*       */   
/*       */ 
/*   369 */   SQLWarning sqlWarning = null;
/*       */   
/*       */ 
/*   372 */   boolean readOnly = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*   377 */   LRUStatementCache statementCache = null;
/*       */   
/*       */ 
/*   380 */   boolean clearStatementMetaData = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   386 */   OracleCloseCallback closeCallback = null;
/*   387 */   Object privateData = null;
/*       */   
/*       */ 
/*   390 */   Statement savepointStatement = null;
/*       */   
/*       */ 
/*   393 */   boolean isUsable = true;
/*       */   
/*   395 */   TimeZone defaultTimeZone = null;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   420 */   final int[] endToEndMaxLength = new int[4];
/*       */   
/*   422 */   boolean endToEndAnyChanged = false;
/*   423 */   final boolean[] endToEndHasChanged = new boolean[4];
/*   424 */   short endToEndECIDSequenceNumber = Short.MIN_VALUE;
/*       */   
/*       */ 
/*       */   static final int DMS_NONE = 0;
/*       */   
/*       */ 
/*       */   static final int DMS_10G = 1;
/*       */   
/*       */   static final int DMS_11 = 2;
/*       */   
/*   434 */   String[] endToEndValues = null;
/*   435 */   final int whichDMS = 0;
/*       */   
/*       */ 
/*       */ 
/*   439 */   oracle.jdbc.OracleConnection wrapper = null;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int minVcsBindSize;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxRawBytesSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxRawBytesPlsql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsCharsSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsNCharsSql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxVcsBytesPlsql;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int maxIbtVarcharElementLength;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   492 */   String instanceName = null;
/*       */   OracleDriverExtension driverExtension;
/*       */   static final String uninitializedMarker = "";
/*   495 */   String databaseProductVersion = "";
/*   496 */   short versionNumber = -1;
/*       */   
/*       */   int namedTypeAccessorByteLen;
/*       */   
/*       */   int refTypeAccessorByteLen;
/*       */   
/*       */   CharacterSet setCHARCharSetObj;
/*       */   CharacterSet setCHARNCharSetObj;
/*   504 */   boolean plsqlCompilerWarnings = false;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   protected PhysicalConnection() {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   PhysicalConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension)
/*       */     throws SQLException
/*       */   {
/*   527 */     readConnectionProperties(paramString, paramProperties);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*   533 */     this.driverExtension = paramOracleDriverExtension;
/*       */     
/*       */ 
/*   536 */     initialize(null, null, null);
/*       */     
/*   538 */     this.logicalConnectionAttached = null;
/*       */     
/*       */     try
/*       */     {
/*   542 */       needLine();
/*       */       
/*       */ 
/*       */ 
/*   546 */       logon();
/*       */       
/*   548 */       setAutoCommit(this.autocommit);
/*       */       
/*       */ 
/*   551 */       if (getVersionNumber() >= 11202)
/*       */       {
/*   553 */         this.minVcsBindSize = 4001;
/*   554 */         this.maxRawBytesSql = 4000;
/*   555 */         this.maxRawBytesPlsql = 32766;
/*   556 */         this.maxVcsCharsSql = 32766;
/*   557 */         this.maxVcsNCharsSql = 32766;
/*   558 */         this.maxVcsBytesPlsql = 32766;
/*   559 */         this.maxIbtVarcharElementLength = 32766;
/*       */         
/*   561 */         this.endToEndMaxLength[0] = 64;
/*   562 */         this.endToEndMaxLength[1] = 64;
/*   563 */         this.endToEndMaxLength[2] = 64;
/*   564 */         this.endToEndMaxLength[3] = 64;
/*       */       }
/*   566 */       else if (getVersionNumber() >= 11000)
/*       */       {
/*   568 */         this.minVcsBindSize = 4001;
/*   569 */         this.maxRawBytesSql = 4000;
/*   570 */         this.maxRawBytesPlsql = 32766;
/*   571 */         this.maxVcsCharsSql = 32766;
/*   572 */         this.maxVcsNCharsSql = 32766;
/*   573 */         this.maxVcsBytesPlsql = 32766;
/*   574 */         this.maxIbtVarcharElementLength = 32766;
/*       */         
/*   576 */         this.endToEndMaxLength[0] = 32;
/*   577 */         this.endToEndMaxLength[1] = 64;
/*   578 */         this.endToEndMaxLength[2] = 64;
/*   579 */         this.endToEndMaxLength[3] = 48;
/*       */       }
/*   581 */       else if (getVersionNumber() >= 10000)
/*       */       {
/*   583 */         this.minVcsBindSize = 4001;
/*   584 */         this.maxRawBytesSql = 2000;
/*   585 */         this.maxRawBytesPlsql = 32512;
/*   586 */         this.maxVcsCharsSql = 32766;
/*   587 */         this.maxVcsNCharsSql = 32766;
/*   588 */         this.maxVcsBytesPlsql = 32512;
/*   589 */         this.maxIbtVarcharElementLength = 32766;
/*       */         
/*   591 */         this.endToEndMaxLength[0] = 32;
/*   592 */         this.endToEndMaxLength[1] = 64;
/*   593 */         this.endToEndMaxLength[2] = 64;
/*   594 */         this.endToEndMaxLength[3] = 48;
/*       */       }
/*   596 */       else if (getVersionNumber() >= 9200)
/*       */       {
/*   598 */         this.minVcsBindSize = 4001;
/*   599 */         this.maxRawBytesSql = 2000;
/*   600 */         this.maxRawBytesPlsql = 32512;
/*   601 */         this.maxVcsCharsSql = 32766;
/*   602 */         this.maxVcsNCharsSql = 32766;
/*   603 */         this.maxVcsBytesPlsql = 32512;
/*   604 */         this.maxIbtVarcharElementLength = 32766;
/*       */         
/*   606 */         this.endToEndMaxLength[0] = 32;
/*   607 */         this.endToEndMaxLength[1] = 64;
/*   608 */         this.endToEndMaxLength[2] = 64;
/*   609 */         this.endToEndMaxLength[3] = 48;
/*       */       }
/*       */       else
/*       */       {
/*   613 */         this.minVcsBindSize = 4001;
/*   614 */         this.maxRawBytesSql = 2000;
/*   615 */         this.maxRawBytesPlsql = 2000;
/*   616 */         this.maxVcsCharsSql = 4000;
/*   617 */         this.maxVcsNCharsSql = 4000;
/*   618 */         this.maxVcsBytesPlsql = 4000;
/*   619 */         this.maxIbtVarcharElementLength = 4000;
/*       */         
/*   621 */         this.endToEndMaxLength[0] = 32;
/*   622 */         this.endToEndMaxLength[1] = 64;
/*   623 */         this.endToEndMaxLength[2] = 64;
/*   624 */         this.endToEndMaxLength[3] = 48;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*   630 */       initializeSetCHARCharSetObjs();
/*       */       
/*       */ 
/*   633 */       if (this.implicitStatementCacheSize > 0) {
/*   634 */         setStatementCacheSize(this.implicitStatementCacheSize);
/*   635 */         setImplicitCachingEnabled(true);
/*       */ 
/*       */ 
/*       */       }
/*       */       
/*       */ 
/*       */ 
/*       */     }
/*       */     catch (SQLException localSQLException1)
/*       */     {
/*       */ 
/*       */ 
/*   647 */       this.lifecycle = 2;
/*       */       try
/*       */       {
/*   650 */         logoff();
/*       */       }
/*       */       catch (SQLException localSQLException2) {}
/*   653 */       this.lifecycle = 4;
/*       */       
/*   655 */       throw localSQLException1;
/*       */     }
/*       */     
/*       */ 
/*   659 */     this.txnMode = 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final String propertyVariableName(String paramString)
/*       */   {
/*   675 */     char[] arrayOfChar = new char[paramString.length()];
/*   676 */     paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*   677 */     String str = "";
/*   678 */     for (int i = 0; i < arrayOfChar.length; i++)
/*       */     {
/*   680 */       if (Character.isUpperCase(arrayOfChar[i]))
/*   681 */         str = str + "_";
/*   682 */       str = str + Character.toUpperCase(arrayOfChar[i]);
/*       */     }
/*   684 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private void initializeUserDefaults(Properties paramProperties)
/*       */   {
/*   699 */     for (String str : OracleDriver.DEFAULT_CONNECTION_PROPERTIES.stringPropertyNames()) {
/*   700 */       if (!paramProperties.containsKey(str)) {
/*   701 */         paramProperties.setProperty(str, OracleDriver.DEFAULT_CONNECTION_PROPERTIES.getProperty(str));
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private void readConnectionProperties(String paramString, Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/*   730 */     initializeUserDefaults(paramProperties);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*   735 */     String str1 = null;
/*       */     
/*       */ 
/*   738 */     str1 = null;
/*   739 */     if (paramProperties != null)
/*       */     {
/*   741 */       str1 = paramProperties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
/*       */     }
/*   743 */     if (str1 == null)
/*   744 */       str1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", null);
/*   745 */     if (str1 == null) {
/*   746 */       str1 = "false";
/*       */     }
/*       */     
/*   749 */     this.retainV9BindBehavior = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*   752 */     str1 = null;
/*   753 */     if (paramProperties != null)
/*       */     {
/*   755 */       str1 = paramProperties.getProperty("user");
/*   756 */       if (str1 == null)
/*   757 */         str1 = paramProperties.getProperty("oracle.jdbc.user");
/*       */     }
/*   759 */     if (str1 == null)
/*   760 */       str1 = getSystemProperty("oracle.jdbc.user", null);
/*   761 */     if (str1 == null) {
/*   762 */       str1 = null;
/*       */     }
/*       */     
/*   765 */     this.userName = str1;
/*       */     
/*       */ 
/*   768 */     str1 = null;
/*   769 */     if (paramProperties != null)
/*       */     {
/*   771 */       str1 = paramProperties.getProperty("database");
/*   772 */       if (str1 == null)
/*   773 */         str1 = paramProperties.getProperty("oracle.jdbc.database");
/*       */     }
/*   775 */     if (str1 == null)
/*   776 */       str1 = getSystemProperty("oracle.jdbc.database", null);
/*   777 */     if (str1 == null) {
/*   778 */       str1 = null;
/*       */     }
/*       */     
/*   781 */     this.database = str1;
/*       */     
/*       */ 
/*   784 */     str1 = null;
/*   785 */     if (paramProperties != null)
/*       */     {
/*   787 */       str1 = paramProperties.getProperty("autoCommit");
/*   788 */       if (str1 == null)
/*   789 */         str1 = paramProperties.getProperty("oracle.jdbc.autoCommit");
/*       */     }
/*   791 */     if (str1 == null)
/*   792 */       str1 = getSystemProperty("oracle.jdbc.autoCommit", null);
/*   793 */     if (str1 == null) {
/*   794 */       str1 = "true";
/*       */     }
/*       */     
/*   797 */     this.autocommit = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*   800 */     str1 = null;
/*   801 */     if (paramProperties != null)
/*       */     {
/*   803 */       str1 = paramProperties.getProperty("protocol");
/*   804 */       if (str1 == null)
/*   805 */         str1 = paramProperties.getProperty("oracle.jdbc.protocol");
/*       */     }
/*   807 */     if (str1 == null)
/*   808 */       str1 = getSystemProperty("oracle.jdbc.protocol", null);
/*   809 */     if (str1 == null) {
/*   810 */       str1 = null;
/*       */     }
/*       */     
/*   813 */     this.protocol = str1;
/*       */     
/*       */ 
/*   816 */     str1 = null;
/*   817 */     if (paramProperties != null)
/*       */     {
/*   819 */       str1 = paramProperties.getProperty("oracle.jdbc.StreamChunkSize");
/*       */     }
/*   821 */     if (str1 == null)
/*   822 */       str1 = getSystemProperty("oracle.jdbc.StreamChunkSize", null);
/*   823 */     if (str1 == null) {
/*   824 */       str1 = "16384";
/*       */     }
/*       */     try {
/*   827 */       this.streamChunkSize = Integer.parseInt(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException1)
/*       */     {
/*   832 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
/*   833 */       ((SQLException)localObject2).fillInStackTrace();
/*   834 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*   840 */     str1 = null;
/*   841 */     if (paramProperties != null)
/*       */     {
/*   843 */       str1 = paramProperties.getProperty("SetFloatAndDoubleUseBinary");
/*   844 */       if (str1 == null)
/*   845 */         str1 = paramProperties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary");
/*       */     }
/*   847 */     if (str1 == null)
/*   848 */       str1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", null);
/*   849 */     if (str1 == null) {
/*   850 */       str1 = "false";
/*       */     }
/*       */     
/*   853 */     this.setFloatAndDoubleUseBinary = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*   856 */     str1 = null;
/*   857 */     if (paramProperties != null)
/*       */     {
/*   859 */       str1 = paramProperties.getProperty("oracle.jdbc.ocinativelibrary");
/*       */     }
/*   861 */     if (str1 == null)
/*   862 */       str1 = getSystemProperty("oracle.jdbc.ocinativelibrary", null);
/*   863 */     if (str1 == null) {
/*   864 */       str1 = null;
/*       */     }
/*       */     
/*   867 */     this.ocidll = str1;
/*       */     
/*       */ 
/*   870 */     str1 = null;
/*   871 */     if (paramProperties != null)
/*       */     {
/*   873 */       str1 = paramProperties.getProperty("v$session.terminal");
/*   874 */       if (str1 == null)
/*   875 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.terminal");
/*       */     }
/*   877 */     if (str1 == null)
/*   878 */       str1 = getSystemProperty("oracle.jdbc.v$session.terminal", null);
/*   879 */     if (str1 == null) {
/*   880 */       str1 = "unknown";
/*       */     }
/*       */     
/*   883 */     this.thinVsessionTerminal = str1;
/*       */     
/*       */ 
/*   886 */     str1 = null;
/*   887 */     if (paramProperties != null)
/*       */     {
/*   889 */       str1 = paramProperties.getProperty("v$session.machine");
/*   890 */       if (str1 == null)
/*   891 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.machine");
/*       */     }
/*   893 */     if (str1 == null)
/*   894 */       str1 = getSystemProperty("oracle.jdbc.v$session.machine", null);
/*   895 */     if (str1 == null) {
/*   896 */       str1 = null;
/*       */     }
/*       */     
/*   899 */     this.thinVsessionMachine = str1;
/*       */     
/*       */ 
/*   902 */     str1 = null;
/*   903 */     if (paramProperties != null)
/*       */     {
/*   905 */       str1 = paramProperties.getProperty("v$session.osuser");
/*   906 */       if (str1 == null)
/*   907 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.osuser");
/*       */     }
/*   909 */     if (str1 == null)
/*   910 */       str1 = getSystemProperty("oracle.jdbc.v$session.osuser", null);
/*   911 */     if (str1 == null) {
/*   912 */       str1 = null;
/*       */     }
/*       */     
/*   915 */     this.thinVsessionOsuser = str1;
/*       */     
/*       */ 
/*   918 */     str1 = null;
/*   919 */     if (paramProperties != null)
/*       */     {
/*   921 */       str1 = paramProperties.getProperty("v$session.program");
/*   922 */       if (str1 == null)
/*   923 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.program");
/*       */     }
/*   925 */     if (str1 == null)
/*   926 */       str1 = getSystemProperty("oracle.jdbc.v$session.program", null);
/*   927 */     if (str1 == null) {
/*   928 */       str1 = "JDBC Thin Client";
/*       */     }
/*       */     
/*   931 */     this.thinVsessionProgram = str1;
/*       */     
/*       */ 
/*   934 */     str1 = null;
/*   935 */     if (paramProperties != null)
/*       */     {
/*   937 */       str1 = paramProperties.getProperty("v$session.process");
/*   938 */       if (str1 == null)
/*   939 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.process");
/*       */     }
/*   941 */     if (str1 == null)
/*   942 */       str1 = getSystemProperty("oracle.jdbc.v$session.process", null);
/*   943 */     if (str1 == null) {
/*   944 */       str1 = "1234";
/*       */     }
/*       */     
/*   947 */     this.thinVsessionProcess = str1;
/*       */     
/*       */ 
/*   950 */     str1 = null;
/*   951 */     if (paramProperties != null)
/*       */     {
/*   953 */       str1 = paramProperties.getProperty("v$session.iname");
/*   954 */       if (str1 == null)
/*   955 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.iname");
/*       */     }
/*   957 */     if (str1 == null)
/*   958 */       str1 = getSystemProperty("oracle.jdbc.v$session.iname", null);
/*   959 */     if (str1 == null) {
/*   960 */       str1 = "jdbc_ttc_impl";
/*       */     }
/*       */     
/*   963 */     this.thinVsessionIname = str1;
/*       */     
/*       */ 
/*   966 */     str1 = null;
/*   967 */     if (paramProperties != null)
/*       */     {
/*   969 */       str1 = paramProperties.getProperty("v$session.ename");
/*   970 */       if (str1 == null)
/*   971 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.ename");
/*       */     }
/*   973 */     if (str1 == null)
/*   974 */       str1 = getSystemProperty("oracle.jdbc.v$session.ename", null);
/*   975 */     if (str1 == null) {
/*   976 */       str1 = null;
/*       */     }
/*       */     
/*   979 */     this.thinVsessionEname = str1;
/*       */     
/*       */ 
/*   982 */     str1 = null;
/*   983 */     if (paramProperties != null)
/*       */     {
/*   985 */       str1 = paramProperties.getProperty("oracle.net.profile");
/*       */     }
/*   987 */     if (str1 == null)
/*   988 */       str1 = getSystemProperty("oracle.net.profile", null);
/*   989 */     if (str1 == null) {
/*   990 */       str1 = null;
/*       */     }
/*       */     
/*   993 */     this.thinNetProfile = str1;
/*       */     
/*       */ 
/*   996 */     str1 = null;
/*   997 */     if (paramProperties != null)
/*       */     {
/*   999 */       str1 = paramProperties.getProperty("oracle.net.authentication_services");
/*       */     }
/*  1001 */     if (str1 == null)
/*  1002 */       str1 = getSystemProperty("oracle.net.authentication_services", null);
/*  1003 */     if (str1 == null) {
/*  1004 */       str1 = null;
/*       */     }
/*       */     
/*  1007 */     this.thinNetAuthenticationServices = str1;
/*       */     
/*       */ 
/*  1010 */     str1 = null;
/*  1011 */     if (paramProperties != null)
/*       */     {
/*  1013 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_mutual_authentication");
/*       */     }
/*  1015 */     if (str1 == null)
/*  1016 */       str1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", null);
/*  1017 */     if (str1 == null) {
/*  1018 */       str1 = null;
/*       */     }
/*       */     
/*  1021 */     this.thinNetAuthenticationKrb5Mutual = str1;
/*       */     
/*       */ 
/*  1024 */     str1 = null;
/*  1025 */     if (paramProperties != null)
/*       */     {
/*  1027 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_cc_name");
/*       */     }
/*  1029 */     if (str1 == null)
/*  1030 */       str1 = getSystemProperty("oracle.net.kerberos5_cc_name", null);
/*  1031 */     if (str1 == null) {
/*  1032 */       str1 = null;
/*       */     }
/*       */     
/*  1035 */     this.thinNetAuthenticationKrb5CcName = str1;
/*       */     
/*       */ 
/*  1038 */     str1 = null;
/*  1039 */     if (paramProperties != null)
/*       */     {
/*  1041 */       str1 = paramProperties.getProperty("oracle.net.encryption_client");
/*       */     }
/*  1043 */     if (str1 == null)
/*  1044 */       str1 = getSystemProperty("oracle.net.encryption_client", null);
/*  1045 */     if (str1 == null) {
/*  1046 */       str1 = null;
/*       */     }
/*       */     
/*  1049 */     this.thinNetEncryptionLevel = str1;
/*       */     
/*       */ 
/*  1052 */     str1 = null;
/*  1053 */     if (paramProperties != null)
/*       */     {
/*  1055 */       str1 = paramProperties.getProperty("oracle.net.encryption_types_client");
/*       */     }
/*  1057 */     if (str1 == null)
/*  1058 */       str1 = getSystemProperty("oracle.net.encryption_types_client", null);
/*  1059 */     if (str1 == null) {
/*  1060 */       str1 = null;
/*       */     }
/*       */     
/*  1063 */     this.thinNetEncryptionTypes = str1;
/*       */     
/*       */ 
/*  1066 */     str1 = null;
/*  1067 */     if (paramProperties != null)
/*       */     {
/*  1069 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_client");
/*       */     }
/*  1071 */     if (str1 == null)
/*  1072 */       str1 = getSystemProperty("oracle.net.crypto_checksum_client", null);
/*  1073 */     if (str1 == null) {
/*  1074 */       str1 = null;
/*       */     }
/*       */     
/*  1077 */     this.thinNetChecksumLevel = str1;
/*       */     
/*       */ 
/*  1080 */     str1 = null;
/*  1081 */     if (paramProperties != null)
/*       */     {
/*  1083 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_types_client");
/*       */     }
/*  1085 */     if (str1 == null)
/*  1086 */       str1 = getSystemProperty("oracle.net.crypto_checksum_types_client", null);
/*  1087 */     if (str1 == null) {
/*  1088 */       str1 = null;
/*       */     }
/*       */     
/*  1091 */     this.thinNetChecksumTypes = str1;
/*       */     
/*       */ 
/*  1094 */     str1 = null;
/*  1095 */     if (paramProperties != null)
/*       */     {
/*  1097 */       str1 = paramProperties.getProperty("oracle.net.crypto_seed");
/*       */     }
/*  1099 */     if (str1 == null)
/*  1100 */       str1 = getSystemProperty("oracle.net.crypto_seed", null);
/*  1101 */     if (str1 == null) {
/*  1102 */       str1 = null;
/*       */     }
/*       */     
/*  1105 */     this.thinNetCryptoSeed = str1;
/*       */     
/*       */ 
/*  1108 */     str1 = null;
/*  1109 */     if (paramProperties != null)
/*       */     {
/*  1111 */       str1 = paramProperties.getProperty("oracle.jdbc.TcpNoDelay");
/*       */     }
/*  1113 */     if (str1 == null)
/*  1114 */       str1 = getSystemProperty("oracle.jdbc.TcpNoDelay", null);
/*  1115 */     if (str1 == null) {
/*  1116 */       str1 = "false";
/*       */     }
/*       */     
/*  1119 */     this.thinTcpNoDelay = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1122 */     str1 = null;
/*  1123 */     if (paramProperties != null)
/*       */     {
/*  1125 */       str1 = paramProperties.getProperty("oracle.jdbc.ReadTimeout");
/*       */     }
/*  1127 */     if (str1 == null)
/*  1128 */       str1 = getSystemProperty("oracle.jdbc.ReadTimeout", null);
/*  1129 */     if (str1 == null) {
/*  1130 */       str1 = null;
/*       */     }
/*       */     
/*  1133 */     this.thinReadTimeout = str1;
/*       */     
/*       */ 
/*  1136 */     str1 = null;
/*  1137 */     if (paramProperties != null)
/*       */     {
/*  1139 */       str1 = paramProperties.getProperty("oracle.net.CONNECT_TIMEOUT");
/*       */     }
/*  1141 */     if (str1 == null)
/*  1142 */       str1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", null);
/*  1143 */     if (str1 == null) {
/*  1144 */       str1 = null;
/*       */     }
/*       */     
/*  1147 */     this.thinNetConnectTimeout = str1;
/*       */     
/*       */ 
/*  1150 */     str1 = null;
/*  1151 */     if (paramProperties != null)
/*       */     {
/*  1153 */       str1 = paramProperties.getProperty("oracle.net.disableOob");
/*       */     }
/*  1155 */     if (str1 == null)
/*  1156 */       str1 = getSystemProperty("oracle.net.disableOob", null);
/*  1157 */     if (str1 == null) {
/*  1158 */       str1 = "false";
/*       */     }
/*       */     
/*  1161 */     this.thinNetDisableOutOfBandBreak = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1164 */     str1 = null;
/*  1165 */     if (paramProperties != null)
/*       */     {
/*  1167 */       str1 = paramProperties.getProperty("oracle.net.useZeroCopyIO");
/*       */     }
/*  1169 */     if (str1 == null)
/*  1170 */       str1 = getSystemProperty("oracle.net.useZeroCopyIO", null);
/*  1171 */     if (str1 == null) {
/*  1172 */       str1 = "true";
/*       */     }
/*       */     
/*  1175 */     this.thinNetUseZeroCopyIO = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1178 */     str1 = null;
/*  1179 */     if (paramProperties != null)
/*       */     {
/*  1181 */       str1 = paramProperties.getProperty("oracle.net.SDP");
/*       */     }
/*  1183 */     if (str1 == null)
/*  1184 */       str1 = getSystemProperty("oracle.net.SDP", null);
/*  1185 */     if (str1 == null) {
/*  1186 */       str1 = "false";
/*       */     }
/*       */     
/*  1189 */     this.thinNetEnableSDP = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1192 */     str1 = null;
/*  1193 */     if (paramProperties != null)
/*       */     {
/*  1195 */       str1 = paramProperties.getProperty("oracle.jdbc.use1900AsYearForTime");
/*       */     }
/*  1197 */     if (str1 == null)
/*  1198 */       str1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", null);
/*  1199 */     if (str1 == null) {
/*  1200 */       str1 = "false";
/*       */     }
/*       */     
/*  1203 */     this.use1900AsYearForTime = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1206 */     str1 = null;
/*  1207 */     if (paramProperties != null)
/*       */     {
/*  1209 */       str1 = paramProperties.getProperty("oracle.jdbc.timestampTzInGmt");
/*       */     }
/*  1211 */     if (str1 == null)
/*  1212 */       str1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", null);
/*  1213 */     if (str1 == null) {
/*  1214 */       str1 = "true";
/*       */     }
/*       */     
/*  1217 */     this.timestamptzInGmt = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1220 */     str1 = null;
/*  1221 */     if (paramProperties != null)
/*       */     {
/*  1223 */       str1 = paramProperties.getProperty("oracle.jdbc.timezoneAsRegion");
/*       */     }
/*  1225 */     if (str1 == null)
/*  1226 */       str1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", null);
/*  1227 */     if (str1 == null) {
/*  1228 */       str1 = "true";
/*       */     }
/*       */     
/*  1231 */     this.timezoneAsRegion = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1234 */     str1 = null;
/*  1235 */     if (paramProperties != null)
/*       */     {
/*  1237 */       str1 = paramProperties.getProperty("oracle.net.ssl_server_dn_match");
/*       */     }
/*  1239 */     if (str1 == null)
/*  1240 */       str1 = getSystemProperty("oracle.net.ssl_server_dn_match", null);
/*  1241 */     if (str1 == null) {
/*  1242 */       str1 = null;
/*       */     }
/*       */     
/*  1245 */     this.thinSslServerDnMatch = str1;
/*       */     
/*       */ 
/*  1248 */     str1 = null;
/*  1249 */     if (paramProperties != null)
/*       */     {
/*  1251 */       str1 = paramProperties.getProperty("oracle.net.ssl_version");
/*       */     }
/*  1253 */     if (str1 == null)
/*  1254 */       str1 = getSystemProperty("oracle.net.ssl_version", null);
/*  1255 */     if (str1 == null) {
/*  1256 */       str1 = null;
/*       */     }
/*       */     
/*  1259 */     this.thinSslVersion = str1;
/*       */     
/*       */ 
/*  1262 */     str1 = null;
/*  1263 */     if (paramProperties != null)
/*       */     {
/*  1265 */       str1 = paramProperties.getProperty("oracle.net.ssl_cipher_suites");
/*       */     }
/*  1267 */     if (str1 == null)
/*  1268 */       str1 = getSystemProperty("oracle.net.ssl_cipher_suites", null);
/*  1269 */     if (str1 == null) {
/*  1270 */       str1 = null;
/*       */     }
/*       */     
/*  1273 */     this.thinSslCipherSuites = str1;
/*       */     
/*       */ 
/*  1276 */     str1 = null;
/*  1277 */     if (paramProperties != null)
/*       */     {
/*  1279 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStore");
/*       */     }
/*  1281 */     if (str1 == null)
/*  1282 */       str1 = getSystemProperty("javax.net.ssl.keyStore", null);
/*  1283 */     if (str1 == null) {
/*  1284 */       str1 = null;
/*       */     }
/*       */     
/*  1287 */     this.thinJavaxNetSslKeystore = str1;
/*       */     
/*       */ 
/*  1290 */     str1 = null;
/*  1291 */     if (paramProperties != null)
/*       */     {
/*  1293 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStoreType");
/*       */     }
/*  1295 */     if (str1 == null)
/*  1296 */       str1 = getSystemProperty("javax.net.ssl.keyStoreType", null);
/*  1297 */     if (str1 == null) {
/*  1298 */       str1 = null;
/*       */     }
/*       */     
/*  1301 */     this.thinJavaxNetSslKeystoretype = str1;
/*       */     
/*       */ 
/*  1304 */     str1 = null;
/*  1305 */     if (paramProperties != null)
/*       */     {
/*  1307 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStorePassword");
/*       */     }
/*  1309 */     if (str1 == null)
/*  1310 */       str1 = getSystemProperty("javax.net.ssl.keyStorePassword", null);
/*  1311 */     if (str1 == null) {
/*  1312 */       str1 = null;
/*       */     }
/*       */     
/*  1315 */     this.thinJavaxNetSslKeystorepassword = str1;
/*       */     
/*       */ 
/*  1318 */     str1 = null;
/*  1319 */     if (paramProperties != null)
/*       */     {
/*  1321 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStore");
/*       */     }
/*  1323 */     if (str1 == null)
/*  1324 */       str1 = getSystemProperty("javax.net.ssl.trustStore", null);
/*  1325 */     if (str1 == null) {
/*  1326 */       str1 = null;
/*       */     }
/*       */     
/*  1329 */     this.thinJavaxNetSslTruststore = str1;
/*       */     
/*       */ 
/*  1332 */     str1 = null;
/*  1333 */     if (paramProperties != null)
/*       */     {
/*  1335 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStoreType");
/*       */     }
/*  1337 */     if (str1 == null)
/*  1338 */       str1 = getSystemProperty("javax.net.ssl.trustStoreType", null);
/*  1339 */     if (str1 == null) {
/*  1340 */       str1 = null;
/*       */     }
/*       */     
/*  1343 */     this.thinJavaxNetSslTruststoretype = str1;
/*       */     
/*       */ 
/*  1346 */     str1 = null;
/*  1347 */     if (paramProperties != null)
/*       */     {
/*  1349 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStorePassword");
/*       */     }
/*  1351 */     if (str1 == null)
/*  1352 */       str1 = getSystemProperty("javax.net.ssl.trustStorePassword", null);
/*  1353 */     if (str1 == null) {
/*  1354 */       str1 = null;
/*       */     }
/*       */     
/*  1357 */     this.thinJavaxNetSslTruststorepassword = str1;
/*       */     
/*       */ 
/*  1360 */     str1 = null;
/*  1361 */     if (paramProperties != null)
/*       */     {
/*  1363 */       str1 = paramProperties.getProperty("ssl.keyManagerFactory.algorithm");
/*  1364 */       if (str1 == null)
/*  1365 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm");
/*       */     }
/*  1367 */     if (str1 == null)
/*  1368 */       str1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", null);
/*  1369 */     if (str1 == null) {
/*  1370 */       str1 = null;
/*       */     }
/*       */     
/*  1373 */     this.thinSslKeymanagerfactoryAlgorithm = str1;
/*       */     
/*       */ 
/*  1376 */     str1 = null;
/*  1377 */     if (paramProperties != null)
/*       */     {
/*  1379 */       str1 = paramProperties.getProperty("ssl.trustManagerFactory.algorithm");
/*  1380 */       if (str1 == null)
/*  1381 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm");
/*       */     }
/*  1383 */     if (str1 == null)
/*  1384 */       str1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", null);
/*  1385 */     if (str1 == null) {
/*  1386 */       str1 = null;
/*       */     }
/*       */     
/*  1389 */     this.thinSslTrustmanagerfactoryAlgorithm = str1;
/*       */     
/*       */ 
/*  1392 */     str1 = null;
/*  1393 */     if (paramProperties != null)
/*       */     {
/*  1395 */       str1 = paramProperties.getProperty("oracle.net.oldSyntax");
/*       */     }
/*  1397 */     if (str1 == null)
/*  1398 */       str1 = getSystemProperty("oracle.net.oldSyntax", null);
/*  1399 */     if (str1 == null) {
/*  1400 */       str1 = null;
/*       */     }
/*       */     
/*  1403 */     this.thinNetOldsyntax = str1;
/*       */     
/*       */ 
/*  1406 */     str1 = null;
/*  1407 */     if (paramProperties != null)
/*       */     {
/*  1409 */       str1 = paramProperties.getProperty("java.naming.factory.initial");
/*       */     }
/*  1411 */     if (str1 == null) {
/*  1412 */       str1 = null;
/*       */     }
/*       */     
/*  1415 */     this.thinNamingContextInitial = str1;
/*       */     
/*       */ 
/*  1418 */     str1 = null;
/*  1419 */     if (paramProperties != null)
/*       */     {
/*  1421 */       str1 = paramProperties.getProperty("java.naming.provider.url");
/*       */     }
/*  1423 */     if (str1 == null) {
/*  1424 */       str1 = null;
/*       */     }
/*       */     
/*  1427 */     this.thinNamingProviderUrl = str1;
/*       */     
/*       */ 
/*  1430 */     str1 = null;
/*  1431 */     if (paramProperties != null)
/*       */     {
/*  1433 */       str1 = paramProperties.getProperty("java.naming.security.authentication");
/*       */     }
/*  1435 */     if (str1 == null) {
/*  1436 */       str1 = null;
/*       */     }
/*       */     
/*  1439 */     this.thinNamingSecurityAuthentication = str1;
/*       */     
/*       */ 
/*  1442 */     str1 = null;
/*  1443 */     if (paramProperties != null)
/*       */     {
/*  1445 */       str1 = paramProperties.getProperty("java.naming.security.principal");
/*       */     }
/*  1447 */     if (str1 == null) {
/*  1448 */       str1 = null;
/*       */     }
/*       */     
/*  1451 */     this.thinNamingSecurityPrincipal = str1;
/*       */     
/*       */ 
/*  1454 */     str1 = null;
/*  1455 */     if (paramProperties != null)
/*       */     {
/*  1457 */       str1 = paramProperties.getProperty("java.naming.security.credentials");
/*       */     }
/*  1459 */     if (str1 == null) {
/*  1460 */       str1 = null;
/*       */     }
/*       */     
/*  1463 */     this.thinNamingSecurityCredentials = str1;
/*       */     
/*       */ 
/*  1466 */     str1 = null;
/*  1467 */     if (paramProperties != null)
/*       */     {
/*  1469 */       str1 = paramProperties.getProperty("oracle.net.wallet_location");
/*       */     }
/*  1471 */     if (str1 == null)
/*  1472 */       str1 = getSystemProperty("oracle.net.wallet_location", null);
/*  1473 */     if (str1 == null) {
/*  1474 */       str1 = null;
/*       */     }
/*       */     
/*  1477 */     this.walletLocation = str1;
/*       */     
/*       */ 
/*  1480 */     str1 = null;
/*  1481 */     if (paramProperties != null)
/*       */     {
/*  1483 */       str1 = paramProperties.getProperty("oracle.net.wallet_password");
/*       */     }
/*  1485 */     if (str1 == null)
/*  1486 */       str1 = getSystemProperty("oracle.net.wallet_password", null);
/*  1487 */     if (str1 == null) {
/*  1488 */       str1 = null;
/*       */     }
/*       */     
/*  1491 */     this.walletPassword = str1;
/*       */     
/*       */ 
/*  1494 */     str1 = null;
/*  1495 */     if (paramProperties != null)
/*       */     {
/*  1497 */       str1 = paramProperties.getProperty("oracle.jdbc.proxyClientName");
/*       */     }
/*  1499 */     if (str1 == null)
/*  1500 */       str1 = getSystemProperty("oracle.jdbc.proxyClientName", null);
/*  1501 */     if (str1 == null) {
/*  1502 */       str1 = null;
/*       */     }
/*       */     
/*  1505 */     this.proxyClientName = str1;
/*       */     
/*       */ 
/*  1508 */     str1 = null;
/*  1509 */     if (paramProperties != null)
/*       */     {
/*  1511 */       str1 = paramProperties.getProperty("oracle.jdbc.useNio");
/*       */     }
/*  1513 */     if (str1 == null)
/*  1514 */       str1 = getSystemProperty("oracle.jdbc.useNio", null);
/*  1515 */     if (str1 == null) {
/*  1516 */       str1 = "false";
/*       */     }
/*       */     
/*  1519 */     this.useNio = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1522 */     str1 = null;
/*  1523 */     if (paramProperties != null)
/*       */     {
/*  1525 */       str1 = paramProperties.getProperty("JDBCDriverCharSetId");
/*  1526 */       if (str1 == null)
/*  1527 */         str1 = paramProperties.getProperty("oracle.jdbc.JDBCDriverCharSetId");
/*       */     }
/*  1529 */     if (str1 == null)
/*  1530 */       str1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", null);
/*  1531 */     if (str1 == null) {
/*  1532 */       str1 = null;
/*       */     }
/*       */     
/*  1535 */     this.ociDriverCharset = str1;
/*       */     
/*       */ 
/*  1538 */     str1 = null;
/*  1539 */     if (paramProperties != null)
/*       */     {
/*  1541 */       str1 = paramProperties.getProperty("oracle.jdbc.editionName");
/*       */     }
/*  1543 */     if (str1 == null)
/*  1544 */       str1 = getSystemProperty("oracle.jdbc.editionName", null);
/*  1545 */     if (str1 == null) {
/*  1546 */       str1 = null;
/*       */     }
/*       */     
/*  1549 */     this.editionName = str1;
/*       */     
/*       */ 
/*  1552 */     str1 = null;
/*  1553 */     if (paramProperties != null)
/*       */     {
/*  1555 */       str1 = paramProperties.getProperty("oracle.jdbc.thinLogonCapability");
/*       */     }
/*  1557 */     if (str1 == null)
/*  1558 */       str1 = getSystemProperty("oracle.jdbc.thinLogonCapability", null);
/*  1559 */     if (str1 == null) {
/*  1560 */       str1 = "o5";
/*       */     }
/*       */     
/*  1563 */     this.logonCap = str1;
/*       */     
/*       */ 
/*  1566 */     str1 = null;
/*  1567 */     if (paramProperties != null)
/*       */     {
/*  1569 */       str1 = paramProperties.getProperty("internal_logon");
/*  1570 */       if (str1 == null)
/*  1571 */         str1 = paramProperties.getProperty("oracle.jdbc.internal_logon");
/*       */     }
/*  1573 */     if (str1 == null)
/*  1574 */       str1 = getSystemProperty("oracle.jdbc.internal_logon", null);
/*  1575 */     if (str1 == null) {
/*  1576 */       str1 = null;
/*       */     }
/*       */     
/*  1579 */     this.internalLogon = str1;
/*       */     
/*       */ 
/*  1582 */     str1 = null;
/*  1583 */     if (paramProperties != null)
/*       */     {
/*  1585 */       str1 = paramProperties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
/*       */     }
/*  1587 */     if (str1 == null)
/*  1588 */       str1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", null);
/*  1589 */     if (str1 == null) {
/*  1590 */       str1 = "false";
/*       */     }
/*       */     
/*  1593 */     this.createDescriptorUseCurrentSchemaForSchemaName = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1596 */     str1 = null;
/*  1597 */     if (paramProperties != null)
/*       */     {
/*  1599 */       str1 = paramProperties.getProperty("OCISvcCtxHandle");
/*  1600 */       if (str1 == null)
/*  1601 */         str1 = paramProperties.getProperty("oracle.jdbc.OCISvcCtxHandle");
/*       */     }
/*  1603 */     if (str1 == null)
/*  1604 */       str1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", null);
/*  1605 */     if (str1 == null) {
/*  1606 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1609 */       this.ociSvcCtxHandle = Long.parseLong(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException2)
/*       */     {
/*  1614 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
/*  1615 */       ((SQLException)localObject2).fillInStackTrace();
/*  1616 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1622 */     str1 = null;
/*  1623 */     if (paramProperties != null)
/*       */     {
/*  1625 */       str1 = paramProperties.getProperty("OCIEnvHandle");
/*  1626 */       if (str1 == null)
/*  1627 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIEnvHandle");
/*       */     }
/*  1629 */     if (str1 == null)
/*  1630 */       str1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", null);
/*  1631 */     if (str1 == null) {
/*  1632 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1635 */       this.ociEnvHandle = Long.parseLong(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException3)
/*       */     {
/*  1640 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
/*  1641 */       ((SQLException)localObject2).fillInStackTrace();
/*  1642 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1648 */     str1 = null;
/*  1649 */     if (paramProperties != null)
/*       */     {
/*  1651 */       str1 = paramProperties.getProperty("OCIErrHandle");
/*  1652 */       if (str1 == null)
/*  1653 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIErrHandle");
/*       */     }
/*  1655 */     if (str1 == null)
/*  1656 */       str1 = getSystemProperty("oracle.jdbc.OCIErrHandle", null);
/*  1657 */     if (str1 == null) {
/*  1658 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1661 */       this.ociErrHandle = Long.parseLong(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException4)
/*       */     {
/*  1666 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
/*  1667 */       ((SQLException)localObject2).fillInStackTrace();
/*  1668 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1674 */     str1 = null;
/*  1675 */     if (paramProperties != null)
/*       */     {
/*  1677 */       str1 = paramProperties.getProperty("prelim_auth");
/*  1678 */       if (str1 == null)
/*  1679 */         str1 = paramProperties.getProperty("oracle.jdbc.prelim_auth");
/*       */     }
/*  1681 */     if (str1 == null)
/*  1682 */       str1 = getSystemProperty("oracle.jdbc.prelim_auth", null);
/*  1683 */     if (str1 == null) {
/*  1684 */       str1 = "false";
/*       */     }
/*       */     
/*  1687 */     this.prelimAuth = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1690 */     str1 = null;
/*  1691 */     if (paramProperties != null)
/*       */     {
/*  1693 */       str1 = paramProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
/*       */     }
/*  1695 */     if (str1 == null)
/*  1696 */       str1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", null);
/*  1697 */     if (str1 == null) {
/*  1698 */       str1 = "false";
/*       */     }
/*       */     
/*  1701 */     this.nlsLangBackdoor = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1704 */     str1 = null;
/*  1705 */     if (paramProperties != null)
/*       */     {
/*  1707 */       str1 = paramProperties.getProperty("OCINewPassword");
/*  1708 */       if (str1 == null)
/*  1709 */         str1 = paramProperties.getProperty("oracle.jdbc.OCINewPassword");
/*       */     }
/*  1711 */     if (str1 == null)
/*  1712 */       str1 = getSystemProperty("oracle.jdbc.OCINewPassword", null);
/*  1713 */     if (str1 == null) {
/*  1714 */       str1 = null;
/*       */     }
/*       */     
/*  1717 */     this.setNewPassword = str1;
/*       */     
/*       */ 
/*  1720 */     str1 = null;
/*  1721 */     if (paramProperties != null)
/*       */     {
/*  1723 */       str1 = paramProperties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
/*       */     }
/*  1725 */     if (str1 == null)
/*  1726 */       str1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", null);
/*  1727 */     if (str1 == null) {
/*  1728 */       str1 = "false";
/*       */     }
/*       */     
/*  1731 */     this.spawnNewThreadToCancel = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1734 */     str1 = null;
/*  1735 */     if (paramProperties != null)
/*       */     {
/*  1737 */       str1 = paramProperties.getProperty("defaultExecuteBatch");
/*  1738 */       if (str1 == null)
/*  1739 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultExecuteBatch");
/*       */     }
/*  1741 */     if (str1 == null)
/*  1742 */       str1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", null);
/*  1743 */     if (str1 == null) {
/*  1744 */       str1 = "1";
/*       */     }
/*       */     try {
/*  1747 */       this.defaultExecuteBatch = Integer.parseInt(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException5)
/*       */     {
/*  1752 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
/*  1753 */       ((SQLException)localObject2).fillInStackTrace();
/*  1754 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1760 */     str1 = null;
/*  1761 */     if (paramProperties != null)
/*       */     {
/*  1763 */       str1 = paramProperties.getProperty("defaultRowPrefetch");
/*  1764 */       if (str1 == null)
/*  1765 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultRowPrefetch");
/*       */     }
/*  1767 */     if (str1 == null)
/*  1768 */       str1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", null);
/*  1769 */     if (str1 == null) {
/*  1770 */       str1 = "10";
/*       */     }
/*       */     try {
/*  1773 */       this.defaultRowPrefetch = Integer.parseInt(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException6)
/*       */     {
/*  1778 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
/*  1779 */       ((SQLException)localObject2).fillInStackTrace();
/*  1780 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1786 */     str1 = null;
/*  1787 */     if (paramProperties != null)
/*       */     {
/*  1789 */       str1 = paramProperties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
/*       */     }
/*  1791 */     if (str1 == null)
/*  1792 */       str1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", null);
/*  1793 */     if (str1 == null) {
/*  1794 */       str1 = "4000";
/*       */     }
/*       */     try {
/*  1797 */       this.defaultLobPrefetchSize = Integer.parseInt(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException7)
/*       */     {
/*  1802 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
/*  1803 */       ((SQLException)localObject2).fillInStackTrace();
/*  1804 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  1810 */     str1 = null;
/*  1811 */     if (paramProperties != null)
/*       */     {
/*  1813 */       str1 = paramProperties.getProperty("oracle.jdbc.enableDataInLocator");
/*       */     }
/*  1815 */     if (str1 == null)
/*  1816 */       str1 = getSystemProperty("oracle.jdbc.enableDataInLocator", null);
/*  1817 */     if (str1 == null) {
/*  1818 */       str1 = "true";
/*       */     }
/*       */     
/*  1821 */     this.enableDataInLocator = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1824 */     str1 = null;
/*  1825 */     if (paramProperties != null)
/*       */     {
/*  1827 */       str1 = paramProperties.getProperty("oracle.jdbc.enableReadDataInLocator");
/*       */     }
/*  1829 */     if (str1 == null)
/*  1830 */       str1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", null);
/*  1831 */     if (str1 == null) {
/*  1832 */       str1 = "true";
/*       */     }
/*       */     
/*  1835 */     this.enableReadDataInLocator = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1838 */     str1 = null;
/*  1839 */     if (paramProperties != null)
/*       */     {
/*  1841 */       str1 = paramProperties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
/*       */     }
/*  1843 */     if (str1 == null)
/*  1844 */       str1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", null);
/*  1845 */     if (str1 == null) {
/*  1846 */       str1 = "false";
/*       */     }
/*       */     
/*  1849 */     this.overrideEnableReadDataInLocator = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1852 */     str1 = null;
/*  1853 */     if (paramProperties != null)
/*       */     {
/*  1855 */       str1 = paramProperties.getProperty("remarksReporting");
/*  1856 */       if (str1 == null)
/*  1857 */         str1 = paramProperties.getProperty("oracle.jdbc.remarksReporting");
/*       */     }
/*  1859 */     if (str1 == null)
/*  1860 */       str1 = getSystemProperty("oracle.jdbc.remarksReporting", null);
/*  1861 */     if (str1 == null) {
/*  1862 */       str1 = "false";
/*       */     }
/*       */     
/*  1865 */     this.reportRemarks = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1868 */     str1 = null;
/*  1869 */     if (paramProperties != null)
/*       */     {
/*  1871 */       str1 = paramProperties.getProperty("includeSynonyms");
/*  1872 */       if (str1 == null)
/*  1873 */         str1 = paramProperties.getProperty("oracle.jdbc.includeSynonyms");
/*       */     }
/*  1875 */     if (str1 == null)
/*  1876 */       str1 = getSystemProperty("oracle.jdbc.includeSynonyms", null);
/*  1877 */     if (str1 == null) {
/*  1878 */       str1 = "false";
/*       */     }
/*       */     
/*  1881 */     this.includeSynonyms = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1884 */     str1 = null;
/*  1885 */     if (paramProperties != null)
/*       */     {
/*  1887 */       str1 = paramProperties.getProperty("restrictGetTables");
/*  1888 */       if (str1 == null)
/*  1889 */         str1 = paramProperties.getProperty("oracle.jdbc.restrictGetTables");
/*       */     }
/*  1891 */     if (str1 == null)
/*  1892 */       str1 = getSystemProperty("oracle.jdbc.restrictGetTables", null);
/*  1893 */     if (str1 == null) {
/*  1894 */       str1 = "false";
/*       */     }
/*       */     
/*  1897 */     this.restrictGettables = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1900 */     str1 = null;
/*  1901 */     if (paramProperties != null)
/*       */     {
/*  1903 */       str1 = paramProperties.getProperty("AccumulateBatchResult");
/*  1904 */       if (str1 == null)
/*  1905 */         str1 = paramProperties.getProperty("oracle.jdbc.AccumulateBatchResult");
/*       */     }
/*  1907 */     if (str1 == null)
/*  1908 */       str1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", null);
/*  1909 */     if (str1 == null) {
/*  1910 */       str1 = "true";
/*       */     }
/*       */     
/*  1913 */     this.accumulateBatchResult = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1916 */     str1 = null;
/*  1917 */     if (paramProperties != null)
/*       */     {
/*  1919 */       str1 = paramProperties.getProperty("useFetchSizeWithLongColumn");
/*  1920 */       if (str1 == null)
/*  1921 */         str1 = paramProperties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn");
/*       */     }
/*  1923 */     if (str1 == null)
/*  1924 */       str1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", null);
/*  1925 */     if (str1 == null) {
/*  1926 */       str1 = "false";
/*       */     }
/*       */     
/*  1929 */     this.useFetchSizeWithLongColumn = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1932 */     str1 = null;
/*  1933 */     if (paramProperties != null)
/*       */     {
/*  1935 */       str1 = paramProperties.getProperty("processEscapes");
/*  1936 */       if (str1 == null)
/*  1937 */         str1 = paramProperties.getProperty("oracle.jdbc.processEscapes");
/*       */     }
/*  1939 */     if (str1 == null)
/*  1940 */       str1 = getSystemProperty("oracle.jdbc.processEscapes", null);
/*  1941 */     if (str1 == null) {
/*  1942 */       str1 = "true";
/*       */     }
/*       */     
/*  1945 */     this.processEscapes = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1948 */     str1 = null;
/*  1949 */     if (paramProperties != null)
/*       */     {
/*  1951 */       str1 = paramProperties.getProperty("fixedString");
/*  1952 */       if (str1 == null)
/*  1953 */         str1 = paramProperties.getProperty("oracle.jdbc.fixedString");
/*       */     }
/*  1955 */     if (str1 == null)
/*  1956 */       str1 = getSystemProperty("oracle.jdbc.fixedString", null);
/*  1957 */     if (str1 == null) {
/*  1958 */       str1 = "false";
/*       */     }
/*       */     
/*  1961 */     this.fixedString = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1964 */     str1 = null;
/*  1965 */     if (paramProperties != null)
/*       */     {
/*  1967 */       str1 = paramProperties.getProperty("defaultNChar");
/*  1968 */       if (str1 == null)
/*  1969 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultNChar");
/*       */     }
/*  1971 */     if (str1 == null)
/*  1972 */       str1 = getSystemProperty("oracle.jdbc.defaultNChar", null);
/*  1973 */     if (str1 == null) {
/*  1974 */       str1 = "false";
/*       */     }
/*       */     
/*  1977 */     this.defaultnchar = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1980 */     str1 = null;
/*  1981 */     if (paramProperties != null)
/*       */     {
/*  1983 */       str1 = paramProperties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
/*       */     }
/*  1985 */     if (str1 == null)
/*  1986 */       str1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", null);
/*  1987 */     if (str1 == null) {
/*  1988 */       str1 = "false";
/*       */     }
/*       */     
/*  1991 */     this.permitTimestampDateMismatch = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  1994 */     str1 = null;
/*  1995 */     if (paramProperties != null)
/*       */     {
/*  1997 */       str1 = paramProperties.getProperty("RessourceManagerId");
/*  1998 */       if (str1 == null)
/*  1999 */         str1 = paramProperties.getProperty("oracle.jdbc.RessourceManagerId");
/*       */     }
/*  2001 */     if (str1 == null)
/*  2002 */       str1 = getSystemProperty("oracle.jdbc.RessourceManagerId", null);
/*  2003 */     if (str1 == null) {
/*  2004 */       str1 = "0000";
/*       */     }
/*       */     
/*  2007 */     this.resourceManagerId = str1;
/*       */     
/*       */ 
/*  2010 */     str1 = null;
/*  2011 */     if (paramProperties != null)
/*       */     {
/*  2013 */       str1 = paramProperties.getProperty("disableDefineColumnType");
/*  2014 */       if (str1 == null)
/*  2015 */         str1 = paramProperties.getProperty("oracle.jdbc.disableDefineColumnType");
/*       */     }
/*  2017 */     if (str1 == null)
/*  2018 */       str1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", null);
/*  2019 */     if (str1 == null) {
/*  2020 */       str1 = "false";
/*       */     }
/*       */     
/*  2023 */     this.disableDefinecolumntype = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2026 */     str1 = null;
/*  2027 */     if (paramProperties != null)
/*       */     {
/*  2029 */       str1 = paramProperties.getProperty("oracle.jdbc.convertNcharLiterals");
/*       */     }
/*  2031 */     if (str1 == null)
/*  2032 */       str1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", null);
/*  2033 */     if (str1 == null) {
/*  2034 */       str1 = "false";
/*       */     }
/*       */     
/*  2037 */     this.convertNcharLiterals = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2040 */     str1 = null;
/*  2041 */     if (paramProperties != null)
/*       */     {
/*  2043 */       str1 = paramProperties.getProperty("oracle.jdbc.J2EE13Compliant");
/*       */     }
/*  2045 */     if (str1 == null)
/*  2046 */       str1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", null);
/*  2047 */     if (str1 == null) {
/*  2048 */       str1 = "false";
/*       */     }
/*       */     
/*  2051 */     this.j2ee13Compliant = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2054 */     str1 = null;
/*  2055 */     if (paramProperties != null)
/*       */     {
/*  2057 */       str1 = paramProperties.getProperty("oracle.jdbc.mapDateToTimestamp");
/*       */     }
/*  2059 */     if (str1 == null)
/*  2060 */       str1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", null);
/*  2061 */     if (str1 == null) {
/*  2062 */       str1 = "true";
/*       */     }
/*       */     
/*  2065 */     this.mapDateToTimestamp = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2068 */     str1 = null;
/*  2069 */     if (paramProperties != null)
/*       */     {
/*  2071 */       str1 = paramProperties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
/*       */     }
/*  2073 */     if (str1 == null)
/*  2074 */       str1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", null);
/*  2075 */     if (str1 == null) {
/*  2076 */       str1 = "false";
/*       */     }
/*       */     
/*  2079 */     this.useThreadLocalBufferCache = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2082 */     str1 = null;
/*  2083 */     if (paramProperties != null)
/*       */     {
/*  2085 */       str1 = paramProperties.getProperty("oracle.jdbc.driverNameAttribute");
/*       */     }
/*  2087 */     if (str1 == null)
/*  2088 */       str1 = getSystemProperty("oracle.jdbc.driverNameAttribute", null);
/*  2089 */     if (str1 == null) {
/*  2090 */       str1 = null;
/*       */     }
/*       */     
/*  2093 */     this.driverNameAttribute = str1;
/*       */     
/*       */ 
/*  2096 */     str1 = null;
/*  2097 */     if (paramProperties != null)
/*       */     {
/*  2099 */       str1 = paramProperties.getProperty("oracle.jdbc.maxCachedBufferSize");
/*       */     }
/*  2101 */     if (str1 == null)
/*  2102 */       str1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", null);
/*  2103 */     if (str1 == null) {
/*  2104 */       str1 = "30";
/*       */     }
/*       */     try {
/*  2107 */       this.maxCachedBufferSize = Integer.parseInt(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException8)
/*       */     {
/*  2112 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
/*  2113 */       ((SQLException)localObject2).fillInStackTrace();
/*  2114 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2120 */     str1 = null;
/*  2121 */     if (paramProperties != null)
/*       */     {
/*  2123 */       str1 = paramProperties.getProperty("oracle.jdbc.implicitStatementCacheSize");
/*       */     }
/*  2125 */     if (str1 == null)
/*  2126 */       str1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", null);
/*  2127 */     if (str1 == null) {
/*  2128 */       str1 = "0";
/*       */     }
/*       */     try {
/*  2131 */       this.implicitStatementCacheSize = Integer.parseInt(str1);
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException9)
/*       */     {
/*  2136 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
/*  2137 */       ((SQLException)localObject2).fillInStackTrace();
/*  2138 */       throw ((Throwable)localObject2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2144 */     str1 = null;
/*  2145 */     if (paramProperties != null)
/*       */     {
/*  2147 */       str1 = paramProperties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
/*       */     }
/*  2149 */     if (str1 == null)
/*  2150 */       str1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", null);
/*  2151 */     if (str1 == null) {
/*  2152 */       str1 = "false";
/*       */     }
/*       */     
/*  2155 */     this.lobStreamPosStandardCompliant = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2158 */     str1 = null;
/*  2159 */     if (paramProperties != null)
/*       */     {
/*  2161 */       str1 = paramProperties.getProperty("oracle.jdbc.strictASCIIConversion");
/*       */     }
/*  2163 */     if (str1 == null)
/*  2164 */       str1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", null);
/*  2165 */     if (str1 == null) {
/*  2166 */       str1 = "false";
/*       */     }
/*       */     
/*  2169 */     this.isStrictAsciiConversion = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2172 */     str1 = null;
/*  2173 */     if (paramProperties != null)
/*       */     {
/*  2175 */       str1 = paramProperties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
/*       */     }
/*  2177 */     if (str1 == null)
/*  2178 */       str1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", null);
/*  2179 */     if (str1 == null) {
/*  2180 */       str1 = "false";
/*       */     }
/*       */     
/*  2183 */     this.thinForceDnsLoadBalancing = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2186 */     str1 = null;
/*  2187 */     if (paramProperties != null)
/*       */     {
/*  2189 */       str1 = paramProperties.getProperty("oracle.jdbc.calculateChecksum");
/*       */     }
/*  2191 */     if (str1 == null)
/*  2192 */       str1 = getSystemProperty("oracle.jdbc.calculateChecksum", null);
/*  2193 */     if (str1 == null) {
/*  2194 */       str1 = "false";
/*       */     }
/*       */     
/*  2197 */     this.calculateChecksum = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2200 */     str1 = null;
/*  2201 */     if (paramProperties != null)
/*       */     {
/*  2203 */       str1 = paramProperties.getProperty("oracle.jdbc.enableJavaNetFastPath");
/*       */     }
/*  2205 */     if (str1 == null)
/*  2206 */       str1 = getSystemProperty("oracle.jdbc.enableJavaNetFastPath", null);
/*  2207 */     if (str1 == null) {
/*  2208 */       str1 = "false";
/*       */     }
/*       */     
/*  2211 */     this.enableJavaNetFastPath = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2214 */     str1 = null;
/*  2215 */     if (paramProperties != null)
/*       */     {
/*  2217 */       str1 = paramProperties.getProperty("oracle.jdbc.enableTempLobRefCnt");
/*       */     }
/*  2219 */     if (str1 == null)
/*  2220 */       str1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", null);
/*  2221 */     if (str1 == null) {
/*  2222 */       str1 = "true";
/*       */     }
/*       */     
/*  2225 */     this.enableTempLobRefCnt = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*  2228 */     str1 = null;
/*  2229 */     if (paramProperties != null)
/*       */     {
/*  2231 */       str1 = paramProperties.getProperty("oracle.net.keepAlive");
/*       */     }
/*  2233 */     if (str1 == null)
/*  2234 */       str1 = getSystemProperty("oracle.net.keepAlive", null);
/*  2235 */     if (str1 == null) {
/*  2236 */       str1 = "false";
/*       */     }
/*       */     
/*  2239 */     this.keepAlive = ((str1 != null) && (str1.equalsIgnoreCase("true")));
/*       */     
/*       */ 
/*       */ 
/*  2243 */     str1 = null;
/*  2244 */     if (paramProperties != null)
/*  2245 */       str1 = paramProperties.getProperty("oracle.jdbc.commitOption");
/*  2246 */     if (str1 == null)
/*  2247 */       str1 = getSystemProperty("oracle.jdbc.commitOption", null);
/*  2248 */     Object localObject1; Object localObject3; if (str1 != null)
/*       */     {
/*  2250 */       this.commitOption = 0;
/*  2251 */       localObject1 = str1.split(",");
/*  2252 */       if ((localObject1 != null) && (localObject1.length > 0))
/*       */       {
/*  2254 */         for (localObject3 : localObject1) {
/*  2255 */           if (((String)localObject3).trim() != "") {
/*  2256 */             this.commitOption |= OracleConnection.CommitOption.valueOf(((String)localObject3).trim()).getCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  2263 */     this.includeSynonyms = parseConnectionProperty_boolean(paramProperties, "synonyms", (byte)3, this.includeSynonyms);
/*       */     
/*       */ 
/*  2266 */     this.reportRemarks = parseConnectionProperty_boolean(paramProperties, "remarks", (byte)3, this.reportRemarks);
/*       */     
/*       */ 
/*  2269 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "prefetch", (byte)3, this.defaultRowPrefetch);
/*       */     
/*       */ 
/*  2272 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);
/*       */     
/*       */ 
/*  2275 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "batch", (byte)3, this.defaultExecuteBatch);
/*       */     
/*       */ 
/*  2278 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "executeBatch", (byte)3, this.defaultExecuteBatch);
/*       */     
/*       */ 
/*  2281 */     this.proxyClientName = parseConnectionProperty_String(paramProperties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2287 */     if (this.defaultRowPrefetch <= 0) {
/*  2288 */       this.defaultRowPrefetch = Integer.parseInt("10");
/*       */     }
/*  2290 */     if (this.defaultExecuteBatch <= 0) {
/*  2291 */       this.defaultExecuteBatch = Integer.parseInt("1");
/*       */     }
/*  2293 */     if (this.defaultLobPrefetchSize < -1)
/*       */     {
/*  2295 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/*  2296 */       ((SQLException)localObject1).fillInStackTrace();
/*  2297 */       throw ((Throwable)localObject1);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2304 */     if (this.streamChunkSize > 0) {
/*  2305 */       this.streamChunkSize = Math.max(4096, this.streamChunkSize);
/*       */     } else {
/*  2307 */       this.streamChunkSize = Integer.parseInt("16384");
/*       */     }
/*       */     
/*       */ 
/*  2311 */     if (this.thinVsessionOsuser == null)
/*       */     {
/*  2313 */       this.thinVsessionOsuser = getSystemProperty("user.name", null);
/*  2314 */       if (this.thinVsessionOsuser == null) {
/*  2315 */         this.thinVsessionOsuser = "jdbcuser";
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2322 */     if (this.thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT)
/*       */     {
/*  2324 */       int i = DriverManager.getLoginTimeout();
/*  2325 */       if (i != 0) {
/*  2326 */         this.thinNetConnectTimeout = ("" + i * 1000);
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2334 */     this.url = paramString;
/*  2335 */     Hashtable localHashtable = parseUrl(this.url, this.walletLocation, this.walletPassword);
/*       */     
/*  2337 */     if (this.userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
/*  2338 */       this.userName = ((String)localHashtable.get("user"));
/*  2339 */     Object localObject2 = new String[1];
/*  2340 */     String[] arrayOfString = new String[1];
/*  2341 */     this.userName = parseLoginOption(this.userName, paramProperties, (String[])localObject2, arrayOfString);
/*  2342 */     if (localObject2[0] != null)
/*  2343 */       this.internalLogon = localObject2[0];
/*  2344 */     if (arrayOfString[0] != null) {
/*  2345 */       this.proxyClientName = arrayOfString[0];
/*       */     }
/*  2347 */     String str2 = paramProperties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
/*       */     
/*  2349 */     if (str2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
/*  2350 */       str2 = (String)localHashtable.get("password");
/*  2351 */     initializePassword(str2);
/*       */     
/*  2353 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2354 */       this.database = paramProperties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
/*       */     }
/*  2356 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2357 */       this.database = ((String)localHashtable.get("database"));
/*       */     }
/*  2359 */     this.protocol = ((String)localHashtable.get("protocol"));
/*       */     
/*       */ 
/*  2362 */     if (this.protocol == null)
/*       */     {
/*       */ 
/*  2365 */       localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
/*  2366 */       ((SQLException)localObject3).fillInStackTrace();
/*  2367 */       throw ((Throwable)localObject3);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2372 */     if ((this.protocol.equals("oci8")) || (this.protocol.equals("oci"))) {
/*  2373 */       this.database = translateConnStr(this.database);
/*       */     }
/*       */     
/*  2376 */     if (paramProperties.getProperty("is_connection_pooling") == "true")
/*       */     {
/*       */ 
/*  2379 */       if (this.database == null) {
/*  2380 */         this.database = "";
/*       */       }
/*       */     }
/*  2383 */     if ((this.userName != null) && (!this.userName.startsWith("\"")))
/*       */     {
/*       */ 
/*  2386 */       localObject3 = this.userName.toCharArray();
/*  2387 */       for (int m = 0; m < localObject3.length; m++)
/*  2388 */         localObject3[m] = Character.toUpperCase(localObject3[m]);
/*  2389 */       this.userName = String.copyValueOf((char[])localObject3);
/*       */     }
/*       */     
/*       */ 
/*  2393 */     this.xaWantsError = false;
/*  2394 */     this.usingXA = false;
/*       */     
/*  2396 */     readOCIConnectionPoolProperties(paramProperties);
/*  2397 */     validateConnectionProperties();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   private void readOCIConnectionPoolProperties(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/*  2406 */     this.ociConnectionPoolMinLimit = parseConnectionProperty_int(paramProperties, "connpool_min_limit", (byte)1, 0);
/*       */     
/*       */ 
/*  2409 */     this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(paramProperties, "connpool_max_limit", (byte)1, 0);
/*       */     
/*       */ 
/*  2412 */     this.ociConnectionPoolIncrement = parseConnectionProperty_int(paramProperties, "connpool_increment", (byte)1, 0);
/*       */     
/*       */ 
/*  2415 */     this.ociConnectionPoolTimeout = parseConnectionProperty_int(paramProperties, "connpool_timeout", (byte)1, 0);
/*       */     
/*       */ 
/*  2418 */     this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(paramProperties, "connpool_nowait", (byte)1, false);
/*       */     
/*       */ 
/*  2421 */     this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(paramProperties, "transactions_distributed", (byte)1, false);
/*       */     
/*       */ 
/*  2424 */     this.ociConnectionPoolLogonMode = parseConnectionProperty_String(paramProperties, "connection_pool", (byte)1, null);
/*       */     
/*       */ 
/*  2427 */     this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(paramProperties, "is_connection_pooling", (byte)1, false);
/*       */     
/*       */ 
/*  2430 */     this.ociConnectionPoolObject = parseConnectionProperty_Object(paramProperties, "connpool_object", null);
/*       */     
/*  2432 */     this.ociConnectionPoolConnID = parseConnectionProperty_Object(paramProperties, "connection_id", null);
/*       */     
/*  2434 */     this.ociConnectionPoolProxyType = parseConnectionProperty_String(paramProperties, "proxytype", (byte)1, null);
/*       */     
/*       */ 
/*  2437 */     this.ociConnectionPoolProxyNumRoles = ((Integer)parseConnectionProperty_Object(paramProperties, "proxy_num_roles", Integer.valueOf(0)));
/*       */     
/*  2439 */     this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(paramProperties, "proxy_roles", null);
/*       */     
/*  2441 */     this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(paramProperties, "proxy_user_name", (byte)1, null);
/*       */     
/*       */ 
/*  2444 */     this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(paramProperties, "proxy_password", (byte)1, null);
/*       */     
/*       */ 
/*  2447 */     this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(paramProperties, "proxy_distinguished_name", (byte)1, null);
/*       */     
/*       */ 
/*  2450 */     this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(paramProperties, "proxy_certificate", null);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2457 */   private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void validateConnectionProperties()
/*       */     throws SQLException
/*       */   {
/*  2467 */     if ((this.driverNameAttribute != null) && (!driverNameAttributePattern.matcher(this.driverNameAttribute).matches()))
/*       */     {
/*       */ 
/*  2470 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
/*  2471 */       localSQLException.fillInStackTrace();
/*  2472 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final Object parseConnectionProperty_Object(Properties paramProperties, String paramString, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  2489 */     Object localObject1 = paramObject;
/*  2490 */     if (paramProperties != null)
/*       */     {
/*  2492 */       Object localObject2 = paramProperties.get(paramString);
/*  2493 */       if (localObject2 != null)
/*  2494 */         localObject1 = localObject2;
/*       */     }
/*  2496 */     return localObject1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final String parseConnectionProperty_String(Properties paramProperties, String paramString1, byte paramByte, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  2525 */     String str = null;
/*  2526 */     if (((paramByte == 1) || (paramByte == 3)) && (paramProperties != null))
/*       */     {
/*       */ 
/*  2529 */       str = paramProperties.getProperty(paramString1);
/*  2530 */       if ((str == null) && (!paramString1.startsWith("oracle.")) && (!paramString1.startsWith("java.")) && (!paramString1.startsWith("javax.")))
/*  2531 */         str = paramProperties.getProperty("oracle.jdbc." + paramString1);
/*       */     }
/*  2533 */     if ((str == null) && ((paramByte == 2) || (paramByte == 3)))
/*       */     {
/*       */ 
/*  2536 */       if ((paramString1.startsWith("oracle.")) || (paramString1.startsWith("java.")) || (paramString1.startsWith("javax."))) {
/*  2537 */         str = getSystemProperty(paramString1, null);
/*       */       } else
/*  2539 */         str = getSystemProperty("oracle.jdbc." + paramString1, null);
/*       */     }
/*  2541 */     if (str == null)
/*  2542 */       str = paramString2;
/*  2543 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final int parseConnectionProperty_int(Properties paramProperties, String paramString, byte paramByte, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  2554 */     int i = paramInt;
/*  2555 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, null);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2560 */     if (str != null)
/*       */     {
/*       */       try
/*       */       {
/*  2564 */         i = Integer.parseInt(str);
/*       */ 
/*       */       }
/*       */       catch (NumberFormatException localNumberFormatException)
/*       */       {
/*       */ 
/*  2570 */         SQLException localSQLException = DatabaseError.createSqlException(null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2571 */         localSQLException.fillInStackTrace();
/*  2572 */         throw localSQLException;
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  2577 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final long parseConnectionProperty_long(Properties paramProperties, String paramString, byte paramByte, long paramLong)
/*       */     throws SQLException
/*       */   {
/*  2588 */     long l = paramLong;
/*  2589 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, null);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2594 */     if (str != null)
/*       */     {
/*       */       try
/*       */       {
/*  2598 */         l = Long.parseLong(str);
/*       */ 
/*       */       }
/*       */       catch (NumberFormatException localNumberFormatException)
/*       */       {
/*       */ 
/*  2604 */         SQLException localSQLException = DatabaseError.createSqlException(null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2605 */         localSQLException.fillInStackTrace();
/*  2606 */         throw localSQLException;
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  2611 */     return l;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final boolean parseConnectionProperty_boolean(Properties paramProperties, String paramString, byte paramByte, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  2622 */     boolean bool = paramBoolean;
/*  2623 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, null);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2628 */     if (str != null)
/*       */     {
/*  2630 */       if (str.equalsIgnoreCase("false")) {
/*  2631 */         bool = false;
/*  2632 */       } else if (str.equalsIgnoreCase("true"))
/*  2633 */         bool = true;
/*       */     }
/*  2635 */     return bool;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static String parseLoginOption(String paramString, Properties paramProperties, String[] paramArrayOfString1, String[] paramArrayOfString2)
/*       */   {
/*  2655 */     int j = 0;
/*  2656 */     String str1 = null;
/*  2657 */     String str2 = null;
/*       */     
/*       */ 
/*  2660 */     if (paramString == null) {
/*  2661 */       return null;
/*       */     }
/*  2663 */     int k = paramString.length();
/*       */     
/*  2665 */     if (k == 0) {
/*  2666 */       return null;
/*       */     }
/*       */     
/*  2669 */     int i = paramString.indexOf('[');
/*  2670 */     if (i > 0) {
/*  2671 */       j = paramString.indexOf(']');
/*  2672 */       str2 = paramString.substring(i + 1, j);
/*  2673 */       str2 = str2.trim();
/*       */       
/*  2675 */       if (str2.length() > 0) {
/*  2676 */         paramArrayOfString2[0] = str2;
/*       */       }
/*       */       
/*  2679 */       paramString = paramString.substring(0, i) + paramString.substring(j + 1, k);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2684 */     String str3 = paramString.toLowerCase();
/*       */     
/*       */ 
/*  2687 */     i = str3.lastIndexOf(" as ");
/*       */     
/*  2689 */     if ((i == -1) || (i < str3.lastIndexOf("\""))) {
/*  2690 */       return paramString;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  2695 */     str1 = paramString.substring(0, i);
/*       */     
/*  2697 */     i += 4;
/*       */     
/*       */ 
/*  2700 */     while ((i < k) && (str3.charAt(i) == ' ')) {
/*  2701 */       i++;
/*       */     }
/*  2703 */     if (i == k) {
/*  2704 */       return paramString;
/*       */     }
/*  2706 */     String str4 = str3.substring(i).trim();
/*       */     
/*  2708 */     if (str4.length() > 0) {
/*  2709 */       paramArrayOfString1[0] = str4;
/*       */     }
/*  2711 */     return str1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final Hashtable parseUrl(String paramString1, String paramString2, String paramString3)
/*       */     throws SQLException
/*       */   {
/*  2732 */     Hashtable localHashtable = new Hashtable(5);
/*  2733 */     int i = paramString1.indexOf(':', paramString1.indexOf(58) + 1) + 1;
/*  2734 */     int j = paramString1.length();
/*       */     
/*       */ 
/*  2737 */     if (i == j) {
/*  2738 */       return localHashtable;
/*       */     }
/*  2740 */     int k = paramString1.indexOf(':', i);
/*       */     
/*       */ 
/*  2743 */     if (k == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2749 */       return localHashtable;
/*       */     }
/*       */     
/*       */ 
/*  2753 */     localHashtable.put("protocol", paramString1.substring(i, k));
/*       */     
/*  2755 */     int m = k + 1;
/*  2756 */     int n = paramString1.indexOf('/', m);
/*       */     
/*  2758 */     int i1 = paramString1.indexOf('@', m);
/*       */     
/*       */ 
/*       */     Object localObject;
/*       */     
/*  2763 */     if ((i1 > m) && (m > i) && (n == -1))
/*       */     {
/*       */ 
/*  2766 */       localObject = DatabaseError.createSqlException(null, 67);
/*  2767 */       ((SQLException)localObject).fillInStackTrace();
/*  2768 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*  2772 */     if (i1 == -1) {
/*  2773 */       i1 = j;
/*       */     }
/*  2775 */     if (n == -1) {
/*  2776 */       n = i1;
/*       */     }
/*  2778 */     if ((n < i1) && (n != m) && (i1 != m))
/*       */     {
/*  2780 */       localHashtable.put("user", paramString1.substring(m, n));
/*  2781 */       localHashtable.put("password", paramString1.substring(n + 1, i1));
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  2787 */     if ((n <= i1) && ((n == m) || (i1 == m)))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  2794 */       if (i1 < j)
/*       */       {
/*  2796 */         localObject = paramString1.substring(i1 + 1);
/*  2797 */         String[] arrayOfString = getSecretStoreCredentials((String)localObject, paramString2, paramString3);
/*  2798 */         if ((arrayOfString[0] != null) || (arrayOfString[1] != null))
/*       */         {
/*  2800 */           localHashtable.put("user", arrayOfString[0]);
/*  2801 */           localHashtable.put("password", arrayOfString[1]);
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  2807 */     if (i1 < j) {
/*  2808 */       localHashtable.put("database", paramString1.substring(i1 + 1));
/*       */     }
/*  2810 */     return localHashtable;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final String[] getSecretStoreCredentials(String paramString1, String paramString2, String paramString3)
/*       */     throws SQLException
/*       */   {
/*  2971 */     String[] arrayOfString = new String[2];
/*  2972 */     arrayOfString[0] = null;
/*  2973 */     arrayOfString[1] = null;
/*       */     
/*  2975 */     if (paramString2 != null)
/*       */     {
/*       */       try
/*       */       {
/*  2979 */         if (paramString2.startsWith("(")) {
/*  2980 */           paramString2 = "file:" + CustomSSLSocketFactory.processWalletLocation(paramString2);
/*       */         }
/*  2982 */         OracleWallet localOracleWallet = new OracleWallet();
/*  2983 */         if (localOracleWallet.exists(paramString2))
/*       */         {
/*       */ 
/*       */ 
/*  2987 */           localObject = null;
/*  2988 */           if (paramString3 != null) {
/*  2989 */             localObject = paramString3.toCharArray();
/*       */           }
/*       */           
/*       */ 
/*  2993 */           localOracleWallet.open(paramString2, (char[])localObject);
/*  2994 */           OracleSecretStore localOracleSecretStore = localOracleWallet.getSecretStore();
/*       */           
/*       */ 
/*       */ 
/*  2998 */           if (localOracleSecretStore.containsAlias("oracle.security.client.default_username")) {
/*  2999 */             arrayOfString[0] = new String(localOracleSecretStore.getSecret("oracle.security.client.default_username"));
/*       */           }
/*  3001 */           if (localOracleSecretStore.containsAlias("oracle.security.client.default_password")) {
/*  3002 */             arrayOfString[1] = new String(localOracleSecretStore.getSecret("oracle.security.client.default_password"));
/*       */           }
/*       */           
/*  3005 */           Enumeration localEnumeration = localOracleWallet.getSecretStore().internalAliases();
/*       */           
/*  3007 */           String str1 = null;
/*  3008 */           while (localEnumeration.hasMoreElements())
/*       */           {
/*  3010 */             str1 = (String)localEnumeration.nextElement();
/*  3011 */             if ((str1.startsWith("oracle.security.client.connect_string")) && 
/*       */             
/*  3013 */               (paramString1.equalsIgnoreCase(new String(localOracleSecretStore.getSecret(str1)))))
/*       */             {
/*       */ 
/*  3016 */               String str2 = str1.substring("oracle.security.client.connect_string".length());
/*  3017 */               arrayOfString[0] = new String(localOracleSecretStore.getSecret("oracle.security.client.username" + str2));
/*       */               
/*  3019 */               arrayOfString[1] = new String(localOracleSecretStore.getSecret("oracle.security.client.password" + str2));
/*       */             }
/*       */             
/*       */           }
/*       */           
/*       */         }
/*       */         
/*       */ 
/*       */       }
/*       */       catch (NoClassDefFoundError localNoClassDefFoundError)
/*       */       {
/*  3030 */         localObject = DatabaseError.createSqlException(null, 167, localNoClassDefFoundError);
/*  3031 */         ((SQLException)localObject).fillInStackTrace();
/*  3032 */         throw ((Throwable)localObject);
/*       */ 
/*       */       }
/*       */       catch (Exception localException)
/*       */       {
/*  3037 */         if ((localException instanceof RuntimeException)) { throw ((RuntimeException)localException);
/*       */         }
/*       */         
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3047 */         Object localObject = DatabaseError.createSqlException(null, 168, localException);
/*  3048 */         ((SQLException)localObject).fillInStackTrace();
/*  3049 */         throw ((Throwable)localObject);
/*       */       }
/*       */     }
/*       */     
/*       */ 
/*  3054 */     return arrayOfString;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private String translateConnStr(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3073 */     int i = 0;
/*  3074 */     int j = 0;
/*       */     
/*  3076 */     if ((paramString == null) || (paramString.equals(""))) {
/*  3077 */       return paramString;
/*       */     }
/*       */     
/*  3080 */     if (paramString.indexOf(')') != -1) {
/*  3081 */       return paramString;
/*       */     }
/*  3083 */     int k = 0;
/*  3084 */     if (paramString.indexOf('[') != -1)
/*       */     {
/*       */ 
/*  3087 */       i = paramString.indexOf(']');
/*  3088 */       if (i == -1)
/*       */       {
/*  3090 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3091 */         ((SQLException)localObject).fillInStackTrace();
/*  3092 */         throw ((Throwable)localObject);
/*       */       }
/*  3094 */       k = 1;
/*       */     }
/*       */     
/*  3097 */     i = paramString.indexOf(':', i);
/*  3098 */     if (i == -1)
/*  3099 */       return paramString;
/*  3100 */     j = paramString.indexOf(':', i + 1);
/*  3101 */     if (j == -1) {
/*  3102 */       return paramString;
/*       */     }
/*       */     
/*  3105 */     if (paramString.indexOf(':', j + 1) != -1)
/*       */     {
/*       */ 
/*  3108 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3109 */       ((SQLException)localObject).fillInStackTrace();
/*  3110 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*  3114 */     Object localObject = null;
/*  3115 */     if (k != 0) {
/*  3116 */       localObject = paramString.substring(1, i - 1);
/*       */     } else {
/*  3118 */       localObject = paramString.substring(0, i);
/*       */     }
/*  3120 */     String str2 = paramString.substring(i + 1, j);
/*  3121 */     String str3 = paramString.substring(j + 1, paramString.length());
/*       */     
/*  3123 */     String str1 = "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + (String)localObject + ")(PORT=" + str2 + "))(CONNECT_DATA=(SID=" + str3 + ")))";
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3129 */     return str1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   protected static String getSystemPropertyPollInterval()
/*       */   {
/*  3136 */     return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   static String getSystemPropertyFastConnectionFailover(String paramString)
/*       */   {
/*  3145 */     return getSystemProperty("oracle.jdbc.FastConnectionFailover", paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   static String getSystemPropertyJserverVersion()
/*       */   {
/*  3153 */     return getSystemProperty("oracle.jserver.version", null);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   private static String getSystemProperty(String paramString1, String paramString2)
/*       */   {
/*  3160 */     if (paramString1 != null)
/*       */     {
/*  3162 */       final String str1 = paramString1;
/*  3163 */       final String str2 = paramString2;
/*  3164 */       String[] arrayOfString = { paramString2 };
/*  3165 */       java.security.AccessController.doPrivileged(new java.security.PrivilegedAction()
/*       */       {
/*       */         public Object run()
/*       */         {
/*  3169 */           this.val$rets[0] = System.getProperty(str1, str2);
/*  3170 */           return null;
/*       */         }
/*  3172 */       });
/*  3173 */       return arrayOfString[0];
/*       */     }
/*       */     
/*  3176 */     return paramString2;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   abstract void initializePassword(String paramString)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */   public Properties getProperties()
/*       */   {
/*  3187 */     Properties localProperties = new Properties();
/*       */     try
/*       */     {
/*  3190 */       Class localClass1 = null;
/*  3191 */       Class localClass2 = null;
/*       */       try
/*       */       {
/*  3194 */         localClass1 = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*  3195 */         localClass2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
/*       */       }
/*       */       catch (ClassNotFoundException localClassNotFoundException) {}
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3204 */       Field[] arrayOfField = localClass2.getDeclaredFields();
/*  3205 */       for (int i = 0; i < arrayOfField.length; i++)
/*       */       {
/*  3207 */         int j = arrayOfField[i].getModifiers();
/*  3208 */         if (!java.lang.reflect.Modifier.isStatic(j))
/*       */         {
/*       */ 
/*  3211 */           String str1 = arrayOfField[i].getName();
/*       */           
/*       */ 
/*  3214 */           String str2 = "CONNECTION_PROPERTY_" + propertyVariableName(str1);
/*       */           
/*       */ 
/*       */ 
/*  3218 */           Field localField = null;
/*       */           
/*       */           try
/*       */           {
/*  3222 */             localField = localClass1.getField(str2);
/*       */           }
/*       */           catch (NoSuchFieldException localNoSuchFieldException)
/*       */           {
/*       */             continue;
/*       */           }
/*       */           
/*       */ 
/*  3230 */           if (!str2.matches(".*PASSWORD.*"))
/*       */           {
/*       */ 
/*  3233 */             String str3 = (String)localField.get(null);
/*  3234 */             String str4 = arrayOfField[i].getType().getName();
/*  3235 */             if (str4.equals("boolean"))
/*       */             {
/*  3237 */               boolean bool = arrayOfField[i].getBoolean(this);
/*  3238 */               if (bool) {
/*  3239 */                 localProperties.setProperty(str3, "true");
/*       */               } else {
/*  3241 */                 localProperties.setProperty(str3, "false");
/*       */               }
/*  3243 */             } else if (str4.equals("int"))
/*       */             {
/*  3245 */               int k = arrayOfField[i].getInt(this);
/*  3246 */               localProperties.setProperty(str3, Integer.toString(k));
/*       */             }
/*  3248 */             else if (str4.equals("long"))
/*       */             {
/*  3250 */               long l = arrayOfField[i].getLong(this);
/*  3251 */               localProperties.setProperty(str3, Long.toString(l));
/*       */             }
/*  3253 */             else if (str4.equals("java.lang.String"))
/*       */             {
/*  3255 */               String str5 = (String)arrayOfField[i].get(this);
/*  3256 */               if (str5 != null) {
/*  3257 */                 localProperties.setProperty(str3, str5);
/*       */               }
/*       */             }
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     catch (IllegalAccessException localIllegalAccessException) {}
/*       */     
/*  3266 */     return localProperties;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public synchronized Connection _getPC()
/*       */   {
/*  3287 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized oracle.jdbc.internal.OracleConnection getPhysicalConnection()
/*       */   {
/*  3303 */     return this;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean isLogicalConnection()
/*       */   {
/*  3316 */     return false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void initialize(Hashtable paramHashtable, Map paramMap1, Map paramMap2)
/*       */     throws SQLException
/*       */   {
/*  3329 */     this.clearStatementMetaData = false;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3335 */     if (paramHashtable != null) {
/*  3336 */       this.descriptorCacheStack[this.dci] = paramHashtable;
/*       */     } else {
/*  3338 */       this.descriptorCacheStack[this.dci] = new Hashtable(10);
/*       */     }
/*  3340 */     this.map = paramMap1;
/*       */     
/*  3342 */     if (paramMap2 != null) {
/*  3343 */       this.javaObjectMap = paramMap2;
/*       */     } else {
/*  3345 */       this.javaObjectMap = new Hashtable(10);
/*       */     }
/*  3347 */     this.lifecycle = 1;
/*  3348 */     this.txnLevel = 2;
/*       */     
/*       */ 
/*  3351 */     this.clientIdSet = false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void initializeSetCHARCharSetObjs()
/*       */   {
/*  3359 */     this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
/*  3360 */     this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   OracleTimeout getTimeout()
/*       */     throws SQLException
/*       */   {
/*  3374 */     if (this.timeout == null)
/*       */     {
/*  3376 */       this.timeout = OracleTimeout.newTimeout(this.url);
/*       */     }
/*       */     
/*  3379 */     return this.timeout;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Statement createStatement()
/*       */     throws SQLException
/*       */   {
/*  3398 */     return createStatement(-1, -1);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Statement createStatement(int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  3420 */     if (this.lifecycle != 1)
/*       */     {
/*  3422 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3423 */       ((SQLException)localObject).fillInStackTrace();
/*  3424 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3427 */     Object localObject = null;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3433 */     localObject = this.driverExtension.allocateStatement(this, paramInt1, paramInt2);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3440 */     return new OracleStatementWrapper((oracle.jdbc.OracleStatement)localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized PreparedStatement prepareStatement(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3461 */     return prepareStatement(paramString, -1, -1);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public synchronized PreparedStatement prepareStatementWithKey(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3482 */     if (this.lifecycle != 1)
/*       */     {
/*  3484 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3485 */       ((SQLException)localObject).fillInStackTrace();
/*  3486 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3489 */     if (paramString == null) {
/*  3490 */       return null;
/*       */     }
/*  3492 */     if (!isStatementCacheInitialized())
/*       */     {
/*  3494 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3495 */       ((SQLException)localObject).fillInStackTrace();
/*  3496 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3503 */     Object localObject = null;
/*       */     
/*  3505 */     localObject = (OraclePreparedStatement)this.statementCache.searchExplicitCache(paramString);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3516 */     if (localObject != null) {
/*  3517 */       localObject = new OraclePreparedStatementWrapper((oracle.jdbc.OraclePreparedStatement)localObject);
/*       */     }
/*  3519 */     return (PreparedStatement)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  3550 */     if ((paramString == null) || (paramString.length() == 0))
/*       */     {
/*  3552 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3553 */       ((SQLException)localObject).fillInStackTrace();
/*  3554 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3557 */     if (this.lifecycle != 1)
/*       */     {
/*  3559 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3560 */       ((SQLException)localObject).fillInStackTrace();
/*  3561 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3564 */     Object localObject = null;
/*       */     
/*       */ 
/*  3567 */     if (this.statementCache != null) {
/*  3568 */       localObject = (OraclePreparedStatement)this.statementCache.searchImplicitCache(paramString, 1, (paramInt1 != -1) || (paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  3574 */     if (localObject == null) {
/*  3575 */       localObject = this.driverExtension.allocatePreparedStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3587 */     return new OraclePreparedStatementWrapper((oracle.jdbc.OraclePreparedStatement)localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized CallableStatement prepareCall(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3606 */     return prepareCall(paramString, -1, -1);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  3635 */     if ((paramString == null) || (paramString.length() == 0))
/*       */     {
/*  3637 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3638 */       ((SQLException)localObject).fillInStackTrace();
/*  3639 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3642 */     if (this.lifecycle != 1)
/*       */     {
/*  3644 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3645 */       ((SQLException)localObject).fillInStackTrace();
/*  3646 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3649 */     Object localObject = null;
/*       */     
/*  3651 */     if (this.statementCache != null) {
/*  3652 */       localObject = (OracleCallableStatement)this.statementCache.searchImplicitCache(paramString, 2, (paramInt1 != -1) || (paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  3658 */     if (localObject == null) {
/*  3659 */       localObject = this.driverExtension.allocateCallableStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3670 */     return new OracleCallableStatementWrapper((oracle.jdbc.OracleCallableStatement)localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized CallableStatement prepareCallWithKey(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3690 */     if (this.lifecycle != 1)
/*       */     {
/*  3692 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3693 */       ((SQLException)localObject).fillInStackTrace();
/*  3694 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3697 */     if (paramString == null) {
/*  3698 */       return null;
/*       */     }
/*  3700 */     if (!isStatementCacheInitialized())
/*       */     {
/*  3702 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3703 */       ((SQLException)localObject).fillInStackTrace();
/*  3704 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3711 */     Object localObject = null;
/*       */     
/*  3713 */     localObject = (OracleCallableStatement)this.statementCache.searchExplicitCache(paramString);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3723 */     if (localObject != null) {
/*  3724 */       localObject = new OracleCallableStatementWrapper((oracle.jdbc.OracleCallableStatement)localObject);
/*       */     }
/*  3726 */     return (CallableStatement)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String nativeSQL(String paramString)
/*       */     throws SQLException
/*       */   {
/*  3738 */     if (this.sqlObj == null)
/*       */     {
/*  3740 */       this.sqlObj = new OracleSql(this.conversion);
/*       */     }
/*       */     
/*  3743 */     this.sqlObj.initialize(paramString);
/*       */     
/*  3745 */     String str = this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
/*       */     
/*  3747 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setAutoCommit(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  3757 */     if (paramBoolean) {
/*  3758 */       disallowGlobalTxnMode(116);
/*       */     }
/*  3760 */     if (this.lifecycle != 1)
/*       */     {
/*  3762 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3763 */       localSQLException.fillInStackTrace();
/*  3764 */       throw localSQLException;
/*       */     }
/*       */     
/*  3767 */     needLine();
/*  3768 */     doSetAutoCommit(paramBoolean);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public boolean getAutoCommit()
/*       */     throws SQLException
/*       */   {
/*  3776 */     return this.autocommit;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void cancel()
/*       */     throws SQLException
/*       */   {
/*  3795 */     OracleStatement localOracleStatement = this.statements;
/*       */     
/*  3797 */     if ((this.lifecycle != 1) && (this.lifecycle != 16))
/*       */     {
/*  3799 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3800 */       localSQLException1.fillInStackTrace();
/*  3801 */       throw localSQLException1;
/*       */     }
/*       */     
/*  3804 */     int i = 0;
/*       */     
/*  3806 */     while (localOracleStatement != null)
/*       */     {
/*       */ 
/*       */ 
/*       */       try
/*       */       {
/*       */ 
/*       */ 
/*  3814 */         if (localOracleStatement.doCancel()) {
/*  3815 */           i = 1;
/*       */         }
/*       */       }
/*       */       catch (SQLException localSQLException2) {}
/*       */       
/*       */ 
/*  3821 */       localOracleStatement = localOracleStatement.next;
/*       */     }
/*       */     
/*       */ 
/*  3825 */     if (i == 0) {
/*  3826 */       cancelOperationOnServer();
/*       */     }
/*       */   }
/*       */   
/*       */   public void commit(EnumSet<OracleConnection.CommitOption> paramEnumSet)
/*       */     throws SQLException
/*       */   {
/*  3833 */     int i = 0;
/*  3834 */     Object localObject; if (paramEnumSet != null)
/*       */     {
/*  3836 */       if (((paramEnumSet.contains(OracleConnection.CommitOption.WRITEBATCH)) && (paramEnumSet.contains(OracleConnection.CommitOption.WRITEIMMED))) || ((paramEnumSet.contains(OracleConnection.CommitOption.WAIT)) && (paramEnumSet.contains(OracleConnection.CommitOption.NOWAIT))))
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3842 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3843 */         ((SQLException)localObject).fillInStackTrace();
/*  3844 */         throw ((Throwable)localObject);
/*       */       }
/*       */       
/*       */ 
/*  3848 */       for (localObject = paramEnumSet.iterator(); ((Iterator)localObject).hasNext();) { OracleConnection.CommitOption localCommitOption = (OracleConnection.CommitOption)((Iterator)localObject).next();
/*  3849 */         i |= localCommitOption.getCode();
/*       */       } }
/*  3851 */     commit(i);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void commit(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  3862 */     disallowGlobalTxnMode(114);
/*       */     
/*  3864 */     if (this.lifecycle != 1)
/*       */     {
/*  3866 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3867 */       ((SQLException)localObject).fillInStackTrace();
/*  3868 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  3871 */     Object localObject = this.statements;
/*       */     
/*  3873 */     while (localObject != null)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  3878 */       if (!((OracleStatement)localObject).closed) {
/*  3879 */         ((OracleStatement)localObject).sendBatch();
/*       */       }
/*  3881 */       localObject = ((OracleStatement)localObject).next;
/*       */     }
/*  3883 */     if ((((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0) && ((paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0)) || (((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0) && ((paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0)))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3889 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3890 */       localSQLException.fillInStackTrace();
/*  3891 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3898 */     registerHeartbeat();
/*       */     
/*  3900 */     needLine();
/*  3901 */     doCommit(paramInt);
/*       */   }
/*       */   
/*       */   public void commit()
/*       */     throws SQLException
/*       */   {
/*  3907 */     commit(this.commitOption);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void rollback()
/*       */     throws SQLException
/*       */   {
/*  3916 */     disallowGlobalTxnMode(115);
/*       */     
/*  3918 */     if (this.lifecycle != 1)
/*       */     {
/*  3920 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3921 */       ((SQLException)localObject).fillInStackTrace();
/*  3922 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*  3926 */     Object localObject = this.statements;
/*       */     
/*  3928 */     while (localObject != null)
/*       */     {
/*  3930 */       if (((OracleStatement)localObject).isOracleBatchStyle()) {
/*  3931 */         ((OracleStatement)localObject).clearBatch();
/*       */       }
/*  3933 */       localObject = ((OracleStatement)localObject).next;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  3940 */     registerHeartbeat();
/*       */     
/*  3942 */     needLine();
/*  3943 */     doRollback();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void close()
/*       */     throws SQLException
/*       */   {
/*  3957 */     if ((this.lifecycle == 2) || (this.lifecycle == 4)) {
/*  3958 */       return;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  3963 */     needLineUnchecked();
/*       */     
/*       */     try
/*       */     {
/*  3967 */       if (this.closeCallback != null) {
/*  3968 */         this.closeCallback.beforeClose(this, this.privateData);
/*       */       }
/*  3970 */       closeStatementCache();
/*  3971 */       closeStatements(false);
/*       */       
/*  3973 */       if (this.lifecycle == 1) { this.lifecycle = 2;
/*       */       }
/*       */       
/*  3976 */       if (this.isProxy)
/*       */       {
/*  3978 */         close(1);
/*       */       }
/*       */       
/*  3981 */       if (this.timeZoneTab != null) {
/*  3982 */         this.timeZoneTab.freeInstance();
/*       */       }
/*  3984 */       logoff();
/*  3985 */       cleanup();
/*       */       
/*  3987 */       if (this.timeout != null) {
/*  3988 */         this.timeout.close();
/*       */       }
/*  3990 */       if (this.closeCallback != null) {
/*  3991 */         this.closeCallback.afterClose(this.privateData);
/*       */       }
/*       */     }
/*       */     finally {
/*  3995 */       this.lifecycle = 4;
/*  3996 */       this.isUsable = false;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getDataIntegrityAlgorithmName()
/*       */     throws SQLException
/*       */   {
/*  4007 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4008 */     localSQLException.fillInStackTrace();
/*  4009 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */   public String getEncryptionAlgorithmName()
/*       */     throws SQLException
/*       */   {
/*  4016 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4017 */     localSQLException.fillInStackTrace();
/*  4018 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */   public String getAuthenticationAdaptorName()
/*       */     throws SQLException
/*       */   {
/*  4025 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4026 */     localSQLException.fillInStackTrace();
/*  4027 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void closeInternal(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4037 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4038 */     localSQLException.fillInStackTrace();
/*  4039 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void cleanupAndClose(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4050 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4051 */     localSQLException.fillInStackTrace();
/*  4052 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void cleanupAndClose()
/*       */     throws SQLException
/*       */   {
/*  4063 */     if (this.lifecycle != 1) {
/*  4064 */       return;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  4069 */     this.lifecycle = 16;
/*       */     
/*       */ 
/*  4072 */     cancel();
/*       */   }
/*       */   
/*       */ 
/*       */   synchronized void closeLogicalConnection()
/*       */     throws SQLException
/*       */   {
/*  4079 */     if ((this.lifecycle == 1) || (this.lifecycle == 16) || (this.lifecycle == 2))
/*       */     {
/*       */ 
/*       */ 
/*  4083 */       this.savepointStatement = null;
/*  4084 */       closeStatements(true);
/*       */       
/*  4086 */       if (this.clientIdSet) {
/*  4087 */         clearClientIdentifier(this.clientId);
/*       */       }
/*  4089 */       this.logicalConnectionAttached = null;
/*  4090 */       this.lifecycle = 1;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void close(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/*  4110 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4111 */     localSQLException.fillInStackTrace();
/*  4112 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void close(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4128 */     if ((paramInt & 0x1000) != 0)
/*       */     {
/*  4130 */       close();
/*       */       
/*  4132 */       return;
/*       */     }
/*       */     
/*  4135 */     if (((paramInt & 0x1) != 0) && (this.isProxy))
/*       */     {
/*  4137 */       purgeStatementCache();
/*  4138 */       closeStatements(false);
/*  4139 */       this.descriptorCacheStack[(this.dci--)] = null;
/*       */       
/*  4141 */       closeProxySession();
/*       */       
/*  4143 */       this.isProxy = false;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*  4150 */   private static final OracleSQLPermission CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort");
/*       */   static final String DATABASE_NAME = "DATABASE_NAME";
/*       */   static final String SERVER_HOST = "SERVER_HOST";
/*       */   
/*       */   public void abort() throws SQLException {
/*  4155 */     SecurityManager localSecurityManager = System.getSecurityManager();
/*  4156 */     if (localSecurityManager != null) {
/*  4157 */       localSecurityManager.checkPermission(CALL_ABORT_PERMISSION);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  4162 */     if ((this.lifecycle == 4) || (this.lifecycle == 8)) {
/*  4163 */       return;
/*       */     }
/*       */     
/*  4166 */     this.lifecycle = 8;
/*       */     
/*       */ 
/*  4169 */     doAbort();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   abstract void doAbort()
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */   void closeProxySession()
/*       */     throws SQLException
/*       */   {
/*  4182 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4183 */     localSQLException.fillInStackTrace();
/*  4184 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Properties getServerSessionInfo()
/*       */     throws SQLException
/*       */   {
/*  4201 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4202 */     localSQLException.fillInStackTrace();
/*  4203 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void applyConnectionAttributes(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/*  4216 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4217 */     localSQLException.fillInStackTrace();
/*  4218 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Properties getConnectionAttributes()
/*       */     throws SQLException
/*       */   {
/*  4231 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4232 */     localSQLException.fillInStackTrace();
/*  4233 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Properties getUnMatchedConnectionAttributes()
/*       */     throws SQLException
/*       */   {
/*  4246 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4247 */     localSQLException.fillInStackTrace();
/*  4248 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4262 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4263 */     localSQLException.fillInStackTrace();
/*  4264 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4277 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4278 */     localSQLException.fillInStackTrace();
/*  4279 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public OracleConnectionCacheCallback getConnectionCacheCallbackObj()
/*       */     throws SQLException
/*       */   {
/*  4292 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4293 */     localSQLException.fillInStackTrace();
/*  4294 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Object getConnectionCacheCallbackPrivObj()
/*       */     throws SQLException
/*       */   {
/*  4306 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4307 */     localSQLException.fillInStackTrace();
/*  4308 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getConnectionCacheCallbackFlag()
/*       */     throws SQLException
/*       */   {
/*  4320 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4321 */     localSQLException.fillInStackTrace();
/*  4322 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setConnectionReleasePriority(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4335 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4336 */     localSQLException.fillInStackTrace();
/*  4337 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getConnectionReleasePriority()
/*       */     throws SQLException
/*       */   {
/*  4349 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4350 */     localSQLException.fillInStackTrace();
/*  4351 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean isClosed()
/*       */     throws SQLException
/*       */   {
/*  4364 */     return this.lifecycle != 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized boolean isProxySession()
/*       */   {
/*  4371 */     return this.isProxy;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void openProxySession(int paramInt, Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/*  4380 */     int i = 1;
/*       */     
/*  4382 */     if (this.isProxy)
/*       */     {
/*  4384 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
/*  4385 */       ((SQLException)localObject1).fillInStackTrace();
/*  4386 */       throw ((Throwable)localObject1);
/*       */     }
/*       */     
/*  4389 */     Object localObject1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  4390 */     String str1 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  4391 */     String str2 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*       */     
/*  4393 */     Object localObject2 = paramProperties.get("PROXY_CERTIFICATE");
/*       */     Object localObject3;
/*  4395 */     if (paramInt == 1)
/*       */     {
/*  4397 */       if ((localObject1 == null) && (str1 == null))
/*       */       {
/*  4399 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4400 */         ((SQLException)localObject3).fillInStackTrace();
/*  4401 */         throw ((Throwable)localObject3);
/*       */       }
/*       */     }
/*  4404 */     else if (paramInt == 2)
/*       */     {
/*  4406 */       if (str2 == null)
/*       */       {
/*  4408 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4409 */         ((SQLException)localObject3).fillInStackTrace();
/*  4410 */         throw ((Throwable)localObject3);
/*       */       }
/*       */     }
/*  4413 */     else if (paramInt == 3)
/*       */     {
/*  4415 */       if (localObject2 == null)
/*       */       {
/*  4417 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4418 */         ((SQLException)localObject3).fillInStackTrace();
/*  4419 */         throw ((Throwable)localObject3);
/*       */       }
/*       */       
/*       */       try
/*       */       {
/*  4424 */         localObject3 = (byte[])localObject2;
/*       */ 
/*       */       }
/*       */       catch (ClassCastException localClassCastException)
/*       */       {
/*  4429 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4430 */         localSQLException2.fillInStackTrace();
/*  4431 */         throw localSQLException2;
/*       */       }
/*       */       
/*       */     }
/*       */     else
/*       */     {
/*  4437 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4438 */       localSQLException1.fillInStackTrace();
/*  4439 */       throw localSQLException1;
/*       */     }
/*       */     
/*  4442 */     purgeStatementCache();
/*  4443 */     closeStatements(false);
/*       */     
/*       */ 
/*       */     try
/*       */     {
/*  4448 */       doProxySession(paramInt, paramProperties);
/*  4449 */       this.dci += 1;
/*       */       
/*  4451 */       i = 0;
/*       */ 
/*       */     }
/*       */     finally
/*       */     {
/*  4456 */       if (i == 1) {
/*  4457 */         closeProxySession();
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void doProxySession(int paramInt, Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/*  4468 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4469 */     localSQLException.fillInStackTrace();
/*  4470 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void cleanup()
/*       */   {
/*  4480 */     this.fdo = null;
/*  4481 */     this.conversion = null;
/*  4482 */     this.statements = null;
/*  4483 */     this.descriptorCacheStack[this.dci] = null;
/*  4484 */     this.map = null;
/*  4485 */     this.javaObjectMap = null;
/*  4486 */     this.statementHoldingLine = null;
/*  4487 */     this.sqlObj = null;
/*  4488 */     this.isProxy = false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized java.sql.DatabaseMetaData getMetaData()
/*       */     throws SQLException
/*       */   {
/*  4505 */     if (this.lifecycle != 1)
/*       */     {
/*  4507 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4508 */       localSQLException.fillInStackTrace();
/*  4509 */       throw localSQLException;
/*       */     }
/*       */     
/*  4512 */     if (this.databaseMetaData == null) {
/*  4513 */       this.databaseMetaData = new OracleDatabaseMetaData(this);
/*       */     }
/*  4515 */     return this.databaseMetaData;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setReadOnly(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4532 */     this.readOnly = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean isReadOnly()
/*       */     throws SQLException
/*       */   {
/*  4548 */     return this.readOnly;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCatalog(String paramString)
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getCatalog()
/*       */     throws SQLException
/*       */   {
/*  4570 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setTransactionIsolation(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4580 */     if (this.txnLevel == paramInt) {
/*  4581 */       return;
/*       */     }
/*  4583 */     Statement localStatement = createStatement();
/*       */     
/*       */     try
/*       */     {
/*  4587 */       switch (paramInt)
/*       */       {
/*       */ 
/*       */ 
/*       */       case 2: 
/*  4592 */         localStatement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
/*       */         
/*  4594 */         this.txnLevel = 2;
/*       */         
/*  4596 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       case 8: 
/*  4601 */         localStatement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
/*       */         
/*  4603 */         this.txnLevel = 8;
/*       */         
/*  4605 */         break;
/*       */       
/*       */ 
/*       */ 
/*       */       default: 
/*  4610 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
/*  4611 */         localSQLException.fillInStackTrace();
/*  4612 */         throw localSQLException;
/*       */       
/*       */ 
/*       */       }
/*       */       
/*       */     }
/*       */     finally
/*       */     {
/*  4620 */       localStatement.close();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int getTransactionIsolation()
/*       */     throws SQLException
/*       */   {
/*  4629 */     return this.txnLevel;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setAutoClose(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  4642 */     if (!paramBoolean)
/*       */     {
/*  4644 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
/*  4645 */       localSQLException.fillInStackTrace();
/*  4646 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getAutoClose()
/*       */     throws SQLException
/*       */   {
/*  4658 */     return true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public SQLWarning getWarnings()
/*       */     throws SQLException
/*       */   {
/*  4668 */     return this.sqlWarning;
/*       */   }
/*       */   
/*       */ 
/*       */   public void clearWarnings()
/*       */     throws SQLException
/*       */   {
/*  4675 */     this.sqlWarning = null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public void setWarnings(SQLWarning paramSQLWarning)
/*       */   {
/*  4682 */     this.sqlWarning = paramSQLWarning;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDefaultRowPrefetch(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4726 */     if (paramInt <= 0)
/*       */     {
/*  4728 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/*  4729 */       localSQLException.fillInStackTrace();
/*  4730 */       throw localSQLException;
/*       */     }
/*       */     
/*  4733 */     this.defaultRowPrefetch = paramInt;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getDefaultRowPrefetch()
/*       */   {
/*  4760 */     return this.defaultRowPrefetch;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public boolean getTimestamptzInGmt()
/*       */   {
/*  4767 */     return this.timestamptzInGmt;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public boolean getUse1900AsYearForTime()
/*       */   {
/*  4774 */     return this.use1900AsYearForTime;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setDefaultExecuteBatch(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  4816 */     if (paramInt <= 0)
/*       */     {
/*  4818 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  4819 */       localSQLException.fillInStackTrace();
/*  4820 */       throw localSQLException;
/*       */     }
/*       */     
/*  4823 */     this.defaultExecuteBatch = paramInt;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized int getDefaultExecuteBatch()
/*       */   {
/*  4851 */     return this.defaultExecuteBatch;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setRemarksReporting(boolean paramBoolean)
/*       */   {
/*  4874 */     this.reportRemarks = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean getRemarksReporting()
/*       */   {
/*  4887 */     return this.reportRemarks;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setIncludeSynonyms(boolean paramBoolean)
/*       */   {
/*  4908 */     this.includeSynonyms = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized String[] getEndToEndMetrics()
/*       */     throws SQLException
/*       */   {
/*       */     String[] arrayOfString;
/*       */     
/*       */ 
/*       */ 
/*  4922 */     if (this.endToEndValues == null)
/*       */     {
/*  4924 */       arrayOfString = null;
/*       */     }
/*       */     else
/*       */     {
/*  4928 */       arrayOfString = new String[this.endToEndValues.length];
/*       */       
/*  4930 */       System.arraycopy(this.endToEndValues, 0, arrayOfString, 0, this.endToEndValues.length);
/*       */     }
/*  4932 */     return arrayOfString;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public short getEndToEndECIDSequenceNumber()
/*       */     throws SQLException
/*       */   {
/*  4950 */     return this.endToEndECIDSequenceNumber;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setEndToEndMetrics(String[] paramArrayOfString, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  4965 */     String[] arrayOfString = new String[paramArrayOfString.length];
/*       */     
/*  4967 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
/*  4968 */     setEndToEndMetricsInternal(arrayOfString, paramShort);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void setEndToEndMetricsInternal(String[] paramArrayOfString, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  4983 */     if (paramArrayOfString != this.endToEndValues)
/*       */     {
/*  4985 */       if (paramArrayOfString.length != 4)
/*       */       {
/*       */ 
/*       */ 
/*  4989 */         SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
/*  4990 */         localSQLException1.fillInStackTrace();
/*  4991 */         throw localSQLException1;
/*       */       }
/*       */       
/*       */       String str;
/*  4995 */       for (int i = 0; i < 4; i++)
/*       */       {
/*  4997 */         str = paramArrayOfString[i];
/*       */         
/*  4999 */         if ((str != null) && (str.length() > this.endToEndMaxLength[i]))
/*       */         {
/*       */ 
/*  5002 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, str);
/*  5003 */           localSQLException2.fillInStackTrace();
/*  5004 */           throw localSQLException2;
/*       */         }
/*       */       }
/*       */       
/*       */ 
/*  5009 */       if (this.endToEndValues != null)
/*       */       {
/*  5011 */         for (i = 0; i < 4; i++)
/*       */         {
/*  5013 */           str = paramArrayOfString[i];
/*       */           
/*  5015 */           if (((str == null) && (this.endToEndValues[i] != null)) || ((str != null) && (!str.equals(this.endToEndValues[i]))))
/*       */           {
/*       */ 
/*  5018 */             this.endToEndHasChanged[i] = true;
/*  5019 */             this.endToEndAnyChanged = true;
/*       */           }
/*       */         }
/*       */         
/*       */ 
/*  5024 */         this.endToEndHasChanged[0] |= this.endToEndHasChanged[3];
/*       */ 
/*       */       }
/*       */       else
/*       */       {
/*  5029 */         for (i = 0; i < 4; i++)
/*       */         {
/*  5031 */           this.endToEndHasChanged[i] = true;
/*       */         }
/*       */         
/*  5034 */         this.endToEndAnyChanged = true;
/*       */       }
/*       */       
/*       */ 
/*  5038 */       this.endToEndValues = paramArrayOfString;
/*       */     }
/*       */     
/*  5041 */     this.endToEndECIDSequenceNumber = paramShort;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void updateSystemContext()
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void resetSystemContext() {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void updateSystemContext11()
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getIncludeSynonyms()
/*       */   {
/*  5100 */     return this.includeSynonyms;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setRestrictGetTables(boolean paramBoolean)
/*       */   {
/*  5141 */     this.restrictGettables = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getRestrictGetTables()
/*       */   {
/*  5157 */     return this.restrictGettables;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDefaultFixedString(boolean paramBoolean)
/*       */   {
/*  5186 */     this.fixedString = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setDefaultNChar(boolean paramBoolean)
/*       */   {
/*  5195 */     this.defaultnchar = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getDefaultFixedString()
/*       */   {
/*  5223 */     return this.fixedString;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getNlsRatio()
/*       */   {
/*  5236 */     return 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int getC2SNlsRatio()
/*       */   {
/*  5243 */     return 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void addStatement(OracleStatement paramOracleStatement)
/*       */   {
/*  5252 */     if (paramOracleStatement.next != null) {
/*  5253 */       throw new Error("add_statement called twice on " + paramOracleStatement);
/*       */     }
/*  5255 */     paramOracleStatement.next = this.statements;
/*       */     
/*  5257 */     if (this.statements != null) {
/*  5258 */       this.statements.prev = paramOracleStatement;
/*       */     }
/*  5260 */     this.statements = paramOracleStatement;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void removeStatement(OracleStatement paramOracleStatement)
/*       */   {
/*  5279 */     OracleStatement localOracleStatement1 = paramOracleStatement.prev;
/*  5280 */     OracleStatement localOracleStatement2 = paramOracleStatement.next;
/*       */     
/*  5282 */     if (localOracleStatement1 == null)
/*       */     {
/*  5284 */       if (this.statements != paramOracleStatement) {
/*  5285 */         return;
/*       */       }
/*  5287 */       this.statements = localOracleStatement2;
/*       */     }
/*       */     else {
/*  5290 */       localOracleStatement1.next = localOracleStatement2;
/*       */     }
/*  5292 */     if (localOracleStatement2 != null) {
/*  5293 */       localOracleStatement2.prev = localOracleStatement1;
/*       */     }
/*  5295 */     paramOracleStatement.next = null;
/*  5296 */     paramOracleStatement.prev = null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void closeStatements(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  5318 */     Object localObject = this.statements;
/*       */     OracleStatement localOracleStatement;
/*  5320 */     while (localObject != null)
/*       */     {
/*  5322 */       localOracleStatement = ((OracleStatement)localObject).nextChild;
/*       */       
/*  5324 */       if (((OracleStatement)localObject).serverCursor)
/*       */       {
/*  5326 */         ((OracleStatement)localObject).close();
/*  5327 */         removeStatement((OracleStatement)localObject);
/*       */       }
/*       */       
/*  5330 */       localObject = localOracleStatement;
/*       */     }
/*       */     
/*       */ 
/*  5334 */     localObject = this.statements;
/*       */     
/*  5336 */     while (localObject != null)
/*       */     {
/*  5338 */       localOracleStatement = ((OracleStatement)localObject).next;
/*       */       
/*  5340 */       if (paramBoolean) {
/*  5341 */         ((OracleStatement)localObject).close();
/*       */       } else
/*  5343 */         ((OracleStatement)localObject).hardClose();
/*  5344 */       removeStatement((OracleStatement)localObject);
/*       */       
/*  5346 */       localObject = localOracleStatement;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   final void purgeStatementCache()
/*       */     throws SQLException
/*       */   {
/*  5357 */     if (isStatementCacheInitialized())
/*       */     {
/*  5359 */       this.statementCache.purgeImplicitCache();
/*  5360 */       this.statementCache.purgeExplicitCache();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   final void closeStatementCache()
/*       */     throws SQLException
/*       */   {
/*  5370 */     if (isStatementCacheInitialized())
/*       */     {
/*       */ 
/*       */ 
/*  5374 */       this.statementCache.close();
/*       */       
/*  5376 */       this.statementCache = null;
/*  5377 */       this.clearStatementMetaData = true;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   void needLine()
/*       */     throws SQLException
/*       */   {
/*  5386 */     if (this.lifecycle != 1)
/*       */     {
/*  5388 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5389 */       localSQLException.fillInStackTrace();
/*  5390 */       throw localSQLException;
/*       */     }
/*       */     
/*  5393 */     needLineUnchecked();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void needLineUnchecked()
/*       */     throws SQLException
/*       */   {
/*  5403 */     if (this.statementHoldingLine != null)
/*       */     {
/*  5405 */       this.statementHoldingLine.freeLine();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   synchronized void holdLine(oracle.jdbc.internal.OracleStatement paramOracleStatement)
/*       */   {
/*  5413 */     holdLine((OracleStatement)paramOracleStatement);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement)
/*       */   {
/*  5422 */     this.statementHoldingLine = paramOracleStatement;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void releaseLine()
/*       */   {
/*  5430 */     releaseLineForCancel();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void releaseLineForCancel()
/*       */   {
/*  5439 */     this.statementHoldingLine = null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized void startup(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  5447 */     if (this.lifecycle != 1)
/*       */     {
/*  5449 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5450 */       localSQLException.fillInStackTrace();
/*  5451 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  5455 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5456 */     localSQLException.fillInStackTrace();
/*  5457 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */   public synchronized void startup(OracleConnection.DatabaseStartupMode paramDatabaseStartupMode)
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException;
/*  5465 */     if (this.lifecycle != 1)
/*       */     {
/*  5467 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5468 */       localSQLException.fillInStackTrace();
/*  5469 */       throw localSQLException;
/*       */     }
/*  5471 */     if (paramDatabaseStartupMode == null)
/*       */     {
/*  5473 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5474 */       localSQLException.fillInStackTrace();
/*  5475 */       throw localSQLException;
/*       */     }
/*       */     
/*  5478 */     needLine();
/*  5479 */     doStartup(paramDatabaseStartupMode.getMode());
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void doStartup(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  5488 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5489 */     localSQLException.fillInStackTrace();
/*  5490 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */   public synchronized void shutdown(OracleConnection.DatabaseShutdownMode paramDatabaseShutdownMode)
/*       */     throws SQLException
/*       */   {
/*       */     SQLException localSQLException;
/*       */     
/*  5499 */     if (this.lifecycle != 1)
/*       */     {
/*  5501 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5502 */       localSQLException.fillInStackTrace();
/*  5503 */       throw localSQLException;
/*       */     }
/*  5505 */     if (paramDatabaseShutdownMode == null)
/*       */     {
/*  5507 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5508 */       localSQLException.fillInStackTrace();
/*  5509 */       throw localSQLException;
/*       */     }
/*       */     
/*  5512 */     needLine();
/*  5513 */     doShutdown(paramDatabaseShutdownMode.getMode());
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   void doShutdown(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  5522 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5523 */     localSQLException.fillInStackTrace();
/*  5524 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void archive(int paramInt1, int paramInt2, String paramString)
/*       */     throws SQLException
/*       */   {
/*  5535 */     if (this.lifecycle != 1)
/*       */     {
/*  5537 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5538 */       localSQLException.fillInStackTrace();
/*  5539 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  5543 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5544 */     localSQLException.fillInStackTrace();
/*  5545 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void registerSQLType(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  5559 */     if ((paramString1 == null) || (paramString2 == null))
/*       */     {
/*  5561 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5562 */       localSQLException1.fillInStackTrace();
/*  5563 */       throw localSQLException1;
/*       */     }
/*       */     
/*       */     try
/*       */     {
/*  5568 */       registerSQLType(paramString1, Class.forName(paramString2));
/*       */ 
/*       */     }
/*       */     catch (ClassNotFoundException localClassNotFoundException)
/*       */     {
/*  5573 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Class not found: " + paramString2);
/*  5574 */       localSQLException2.fillInStackTrace();
/*  5575 */       throw localSQLException2;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void registerSQLType(String paramString, Class paramClass)
/*       */     throws SQLException
/*       */   {
/*  5586 */     if ((paramString == null) || (paramClass == null))
/*       */     {
/*  5588 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5589 */       localSQLException.fillInStackTrace();
/*  5590 */       throw localSQLException;
/*       */     }
/*       */     
/*  5593 */     if (this.map == null) { this.map = new Hashtable(10);
/*       */     }
/*  5595 */     this.map.put(paramString, paramClass);
/*  5596 */     this.map.put(paramClass.getName(), paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized String getSQLType(Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  5604 */     if ((paramObject != null) && (this.map != null))
/*       */     {
/*  5606 */       String str = paramObject.getClass().getName();
/*       */       
/*  5608 */       return (String)this.map.get(str);
/*       */     }
/*       */     
/*  5611 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized Object getJavaObject(String paramString)
/*       */     throws SQLException
/*       */   {
/*  5619 */     Object localObject = null;
/*       */     
/*       */     try
/*       */     {
/*  5623 */       if ((paramString != null) && (this.map != null))
/*       */       {
/*  5625 */         Class localClass = (Class)this.map.get(paramString);
/*       */         
/*  5627 */         localObject = localClass.newInstance();
/*       */       }
/*       */     }
/*       */     catch (IllegalAccessException localIllegalAccessException)
/*       */     {
/*  5632 */       localIllegalAccessException.printStackTrace();
/*       */     }
/*       */     catch (InstantiationException localInstantiationException)
/*       */     {
/*  5636 */       localInstantiationException.printStackTrace();
/*       */     }
/*       */     
/*  5639 */     return localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void putDescriptor(String paramString, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  5652 */     if ((paramString != null) && (paramObject != null))
/*       */     {
/*  5654 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5655 */         this.descriptorCacheStack[this.dci] = new Hashtable(10);
/*       */       }
/*  5657 */       ((TypeDescriptor)paramObject).fixupConnection(this);
/*  5658 */       this.descriptorCacheStack[this.dci].put(paramString, paramObject);
/*       */     }
/*       */     else
/*       */     {
/*  5662 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5663 */       localSQLException.fillInStackTrace();
/*  5664 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Object getDescriptor(String paramString)
/*       */   {
/*  5676 */     Object localObject = null;
/*       */     
/*  5678 */     if (paramString != null) {
/*  5679 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5680 */         localObject = this.descriptorCacheStack[this.dci].get(paramString);
/*  5681 */       if ((localObject == null) && (this.dci == 1) && (this.descriptorCacheStack[0] != null)) {
/*  5682 */         localObject = this.descriptorCacheStack[0].get(paramString);
/*       */       }
/*       */     }
/*  5685 */     return localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public synchronized void removeDecriptor(String paramString)
/*       */   {
/*  5697 */     removeDescriptor(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void removeDescriptor(String paramString)
/*       */   {
/*  5711 */     if ((paramString != null) && (this.descriptorCacheStack[this.dci] != null))
/*  5712 */       this.descriptorCacheStack[this.dci].remove(paramString);
/*  5713 */     if ((paramString != null) && (this.dci == 1) && (this.descriptorCacheStack[0] != null)) {
/*  5714 */       this.descriptorCacheStack[0].remove(paramString);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void removeAllDescriptor()
/*       */   {
/*  5725 */     for (int i = 0; i <= this.dci; i++) {
/*  5726 */       if (this.descriptorCacheStack[i] != null) {
/*  5727 */         this.descriptorCacheStack[i].clear();
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int numberOfDescriptorCacheEntries()
/*       */   {
/*  5744 */     int i = 0;
/*  5745 */     for (int j = 0; j <= this.dci; j++) {
/*  5746 */       if (this.descriptorCacheStack[j] != null)
/*  5747 */         i += this.descriptorCacheStack[j].size();
/*       */     }
/*  5749 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Enumeration descriptorCacheKeys()
/*       */   {
/*  5762 */     if (this.dci == 0) {
/*  5763 */       if (this.descriptorCacheStack[this.dci] != null) {
/*  5764 */         return this.descriptorCacheStack[this.dci].keys();
/*       */       }
/*  5766 */       return null;
/*       */     }
/*  5768 */     if ((this.descriptorCacheStack[0] == null) && (this.descriptorCacheStack[1] != null))
/*  5769 */       return this.descriptorCacheStack[1].keys();
/*  5770 */     if ((this.descriptorCacheStack[1] == null) && (this.descriptorCacheStack[0] != null))
/*  5771 */       return this.descriptorCacheStack[0].keys();
/*  5772 */     if ((this.descriptorCacheStack[0] == null) && (this.descriptorCacheStack[1] == null)) {
/*  5773 */       return null;
/*       */     }
/*  5775 */     Vector localVector = new Vector(this.descriptorCacheStack[1].keySet());
/*  5776 */     localVector.addAll(this.descriptorCacheStack[0].keySet());
/*  5777 */     return localVector.elements();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void putDescriptor(byte[] paramArrayOfByte, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  5791 */     if ((paramArrayOfByte != null) && (paramObject != null))
/*       */     {
/*  5793 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5794 */         this.descriptorCacheStack[this.dci] = new Hashtable(10);
/*       */       }
/*  5796 */       this.descriptorCacheStack[this.dci].put(new ByteArrayKey(paramArrayOfByte), paramObject);
/*       */     }
/*       */     else
/*       */     {
/*  5800 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5801 */       localSQLException.fillInStackTrace();
/*  5802 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Object getDescriptor(byte[] paramArrayOfByte)
/*       */   {
/*  5814 */     Object localObject = null;
/*       */     
/*  5816 */     if (paramArrayOfByte != null) {
/*  5817 */       ByteArrayKey localByteArrayKey = new ByteArrayKey(paramArrayOfByte);
/*  5818 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5819 */         localObject = this.descriptorCacheStack[this.dci].get(localByteArrayKey);
/*  5820 */       if ((localObject == null) && (this.dci == 1) && (this.descriptorCacheStack[0] != null)) {
/*  5821 */         localObject = this.descriptorCacheStack[0].get(localByteArrayKey);
/*       */       }
/*       */     }
/*  5824 */     return localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void removeDecriptor(byte[] paramArrayOfByte)
/*       */   {
/*  5836 */     if (paramArrayOfByte != null) {
/*  5837 */       ByteArrayKey localByteArrayKey = new ByteArrayKey(paramArrayOfByte);
/*  5838 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5839 */         this.descriptorCacheStack[this.dci].remove(localByteArrayKey);
/*  5840 */       if ((this.dci == 1) && (this.descriptorCacheStack[0] != null)) {
/*  5841 */         this.descriptorCacheStack[0].remove(localByteArrayKey);
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public short getJdbcCsId()
/*       */     throws SQLException
/*       */   {
/*  5864 */     if (this.conversion == null)
/*       */     {
/*       */ 
/*  5867 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5868 */       localSQLException.fillInStackTrace();
/*  5869 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  5873 */     return this.conversion.getClientCharSet();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public short getDbCsId()
/*       */     throws SQLException
/*       */   {
/*  5888 */     if (this.conversion == null)
/*       */     {
/*       */ 
/*  5891 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5892 */       localSQLException.fillInStackTrace();
/*  5893 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  5897 */     return this.conversion.getServerCharSetId();
/*       */   }
/*       */   
/*       */ 
/*       */   public short getNCsId()
/*       */     throws SQLException
/*       */   {
/*  5904 */     if (this.conversion == null)
/*       */     {
/*       */ 
/*  5907 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5908 */       localSQLException.fillInStackTrace();
/*  5909 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  5913 */     return this.conversion.getNCharSetId();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public short getStructAttrCsId()
/*       */     throws SQLException
/*       */   {
/*  5929 */     return getDbCsId();
/*       */   }
/*       */   
/*       */ 
/*       */   public short getStructAttrNCsId()
/*       */     throws SQLException
/*       */   {
/*  5936 */     return getNCsId();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Map getTypeMap()
/*       */   {
/*  5946 */     if (this.map == null) this.map = new Hashtable(10);
/*  5947 */     return this.map;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized void setTypeMap(Map paramMap)
/*       */   {
/*  5954 */     this.map = paramMap;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setUsingXAFlag(boolean paramBoolean)
/*       */   {
/*  5962 */     this.usingXA = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized boolean getUsingXAFlag()
/*       */   {
/*  5969 */     return this.usingXA;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setXAErrorFlag(boolean paramBoolean)
/*       */   {
/*  5977 */     this.xaWantsError = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized boolean getXAErrorFlag()
/*       */   {
/*  5984 */     return this.xaWantsError;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   String getPropertyFromDatabase(String paramString)
/*       */     throws SQLException
/*       */   {
/*  5992 */     String str = null;
/*  5993 */     Statement localStatement = null;
/*  5994 */     ResultSet localResultSet = null;
/*       */     try
/*       */     {
/*  5997 */       localStatement = createStatement();
/*  5998 */       localStatement.setFetchSize(1);
/*  5999 */       localResultSet = localStatement.executeQuery(paramString);
/*  6000 */       if (localResultSet.next()) {
/*  6001 */         str = localResultSet.getString(1);
/*       */       }
/*       */     }
/*       */     finally {
/*  6005 */       if (localResultSet != null)
/*  6006 */         localResultSet.close();
/*  6007 */       if (localStatement != null)
/*  6008 */         localStatement.close();
/*       */     }
/*  6010 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized String getUserName()
/*       */     throws SQLException
/*       */   {
/*  6018 */     if (this.userName == null) {
/*  6019 */       this.userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
/*       */     }
/*  6021 */     return this.userName;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getCurrentSchema()
/*       */     throws SQLException
/*       */   {
/*  6037 */     return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getDefaultSchemaNameForNamedTypes()
/*       */     throws SQLException
/*       */   {
/*  6055 */     String str = null;
/*       */     
/*  6057 */     if (this.createDescriptorUseCurrentSchemaForSchemaName) {
/*  6058 */       str = getCurrentSchema();
/*       */     } else {
/*  6060 */       str = getUserName();
/*       */     }
/*  6062 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setStartTime(long paramLong)
/*       */     throws SQLException
/*       */   {
/*  6080 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6081 */     localSQLException.fillInStackTrace();
/*  6082 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized long getStartTime()
/*       */     throws SQLException
/*       */   {
/*  6098 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6099 */     localSQLException.fillInStackTrace();
/*  6100 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void registerHeartbeat()
/*       */     throws SQLException
/*       */   {
/*  6113 */     if (this.logicalConnectionAttached != null) {
/*  6114 */       this.logicalConnectionAttached.registerHeartbeat();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getHeartbeatNoChangeCount()
/*       */     throws SQLException
/*       */   {
/*  6126 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6127 */     localSQLException.fillInStackTrace();
/*  6128 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized byte[] getFDO(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  6140 */     if ((this.fdo == null) && (paramBoolean))
/*       */     {
/*  6142 */       CallableStatement localCallableStatement = null;
/*       */       
/*       */       try
/*       */       {
/*  6146 */         localCallableStatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
/*       */         
/*       */ 
/*  6149 */         localCallableStatement.registerOutParameter(1, 2);
/*  6150 */         localCallableStatement.registerOutParameter(2, -4);
/*  6151 */         localCallableStatement.execute();
/*       */         
/*  6153 */         this.fdo = localCallableStatement.getBytes(2);
/*       */       }
/*       */       finally
/*       */       {
/*  6157 */         if (localCallableStatement != null) {
/*  6158 */           localCallableStatement.close();
/*       */         }
/*  6160 */         localCallableStatement = null;
/*       */       }
/*       */     }
/*       */     
/*  6164 */     return this.fdo;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setFDO(byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  6175 */     this.fdo = paramArrayOfByte;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean getBigEndian()
/*       */     throws SQLException
/*       */   {
/*  6186 */     if (this.bigEndian == null)
/*       */     {
/*  6188 */       int[] arrayOfInt = oracle.jdbc.oracore.Util.toJavaUnsignedBytes(getFDO(true));
/*       */       
/*       */ 
/*       */ 
/*  6192 */       int i = arrayOfInt[(6 + arrayOfInt[5] + arrayOfInt[6] + 5)];
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  6197 */       int j = (byte)(i & 0x10);
/*       */       
/*  6199 */       if (j < 0) {
/*  6200 */         j += 256;
/*       */       }
/*  6202 */       if (j > 0) {
/*  6203 */         this.bigEndian = Boolean.TRUE;
/*       */       } else {
/*  6205 */         this.bigEndian = Boolean.FALSE;
/*       */       }
/*       */     }
/*  6208 */     return this.bigEndian.booleanValue();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setHoldability(int paramInt)
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getHoldability()
/*       */     throws SQLException
/*       */   {
/*  6261 */     return 1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Savepoint setSavepoint()
/*       */     throws SQLException
/*       */   {
/*  6270 */     return oracleSetSavepoint();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Savepoint setSavepoint(String paramString)
/*       */     throws SQLException
/*       */   {
/*  6280 */     return oracleSetSavepoint(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void rollback(Savepoint paramSavepoint)
/*       */     throws SQLException
/*       */   {
/*  6291 */     disallowGlobalTxnMode(122);
/*       */     
/*       */ 
/*  6294 */     if (this.autocommit)
/*       */     {
/*  6296 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6297 */       ((SQLException)localObject).fillInStackTrace();
/*  6298 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6303 */     if (this.savepointStatement == null)
/*       */     {
/*  6305 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6308 */     Object localObject = null;
/*       */     
/*       */     try
/*       */     {
/*  6312 */       localObject = paramSavepoint.getSavepointName();
/*       */     }
/*       */     catch (SQLException localSQLException)
/*       */     {
/*  6316 */       localObject = "ORACLE_SVPT_" + paramSavepoint.getSavepointId();
/*       */     }
/*       */     
/*  6319 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + (String)localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void releaseSavepoint(Savepoint paramSavepoint)
/*       */     throws SQLException
/*       */   {
/*  6329 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6330 */     localSQLException.fillInStackTrace();
/*  6331 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   static final String INSTANCE_NAME = "INSTANCE_NAME";
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   static final String SERVICE_NAME = "SERVICE_NAME";
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  6377 */     return createStatement(paramInt1, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   Hashtable clientData;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private BufferCacheStore connectionBufferCacheStore;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private int pingResult;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  6428 */     return prepareStatement(paramString, paramInt1, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/*  6476 */     return prepareCall(paramString, paramInt1, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  6526 */     AutoKeyInfo localAutoKeyInfo = new AutoKeyInfo(paramString);
/*  6527 */     if ((paramInt == 2) || (!localAutoKeyInfo.isInsertSqlStmt()))
/*       */     {
/*  6529 */       return prepareStatement(paramString);
/*       */     }
/*  6531 */     if (paramInt != 1)
/*       */     {
/*  6533 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6534 */       ((SQLException)localObject).fillInStackTrace();
/*  6535 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  6538 */     Object localObject = localAutoKeyInfo.getNewSql();
/*  6539 */     oracle.jdbc.OraclePreparedStatement localOraclePreparedStatement = (oracle.jdbc.OraclePreparedStatement)prepareStatement((String)localObject);
/*  6540 */     OraclePreparedStatement localOraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)localOraclePreparedStatement).preparedStatement;
/*       */     
/*  6542 */     localOraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6543 */     localOraclePreparedStatement1.autoKeyInfo = localAutoKeyInfo;
/*  6544 */     localOraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6545 */     return localOraclePreparedStatement;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfInt)
/*       */     throws SQLException
/*       */   {
/*  6594 */     AutoKeyInfo localAutoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfInt);
/*       */     
/*  6596 */     if (!localAutoKeyInfo.isInsertSqlStmt()) { return prepareStatement(paramString);
/*       */     }
/*  6598 */     if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0))
/*       */     {
/*  6600 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6601 */       ((SQLException)localObject).fillInStackTrace();
/*  6602 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6607 */     doDescribeTable(localAutoKeyInfo);
/*       */     
/*  6609 */     Object localObject = localAutoKeyInfo.getNewSql();
/*  6610 */     oracle.jdbc.OraclePreparedStatement localOraclePreparedStatement = (oracle.jdbc.OraclePreparedStatement)prepareStatement((String)localObject);
/*  6611 */     OraclePreparedStatement localOraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)localOraclePreparedStatement).preparedStatement;
/*       */     
/*  6613 */     localOraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6614 */     localOraclePreparedStatement1.autoKeyInfo = localAutoKeyInfo;
/*  6615 */     localOraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6616 */     return localOraclePreparedStatement;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString)
/*       */     throws SQLException
/*       */   {
/*  6666 */     AutoKeyInfo localAutoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*  6667 */     if (!localAutoKeyInfo.isInsertSqlStmt()) { return prepareStatement(paramString);
/*       */     }
/*  6669 */     if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
/*       */     {
/*  6671 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6672 */       ((SQLException)localObject).fillInStackTrace();
/*  6673 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*  6677 */     doDescribeTable(localAutoKeyInfo);
/*       */     
/*  6679 */     Object localObject = localAutoKeyInfo.getNewSql();
/*  6680 */     oracle.jdbc.OraclePreparedStatement localOraclePreparedStatement = (oracle.jdbc.OraclePreparedStatement)prepareStatement((String)localObject);
/*  6681 */     OraclePreparedStatement localOraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)localOraclePreparedStatement).preparedStatement;
/*       */     
/*  6683 */     localOraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6684 */     localOraclePreparedStatement1.autoKeyInfo = localAutoKeyInfo;
/*  6685 */     localOraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6686 */     return localOraclePreparedStatement;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized oracle.jdbc.OracleSavepoint oracleSetSavepoint()
/*       */     throws SQLException
/*       */   {
/*  6712 */     disallowGlobalTxnMode(117);
/*       */     
/*       */ 
/*  6715 */     if (this.autocommit)
/*       */     {
/*  6717 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6718 */       ((SQLException)localObject).fillInStackTrace();
/*  6719 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6724 */     if (this.savepointStatement == null)
/*       */     {
/*  6726 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6729 */     Object localObject = new OracleSavepoint();
/*       */     
/*  6731 */     String str = "SAVEPOINT ORACLE_SVPT_" + ((OracleSavepoint)localObject).getSavepointId();
/*       */     
/*  6733 */     this.savepointStatement.executeUpdate(str);
/*       */     
/*       */ 
/*  6736 */     return (oracle.jdbc.OracleSavepoint)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized oracle.jdbc.OracleSavepoint oracleSetSavepoint(String paramString)
/*       */     throws SQLException
/*       */   {
/*  6763 */     disallowGlobalTxnMode(117);
/*       */     
/*       */ 
/*  6766 */     if (this.autocommit)
/*       */     {
/*  6768 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6769 */       ((SQLException)localObject).fillInStackTrace();
/*  6770 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6775 */     if (this.savepointStatement == null)
/*       */     {
/*  6777 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6780 */     Object localObject = new OracleSavepoint(paramString);
/*       */     
/*  6782 */     String str = "SAVEPOINT " + ((OracleSavepoint)localObject).getSavepointName();
/*       */     
/*  6784 */     this.savepointStatement.executeUpdate(str);
/*       */     
/*       */ 
/*  6787 */     return (oracle.jdbc.OracleSavepoint)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void oracleRollback(oracle.jdbc.OracleSavepoint paramOracleSavepoint)
/*       */     throws SQLException
/*       */   {
/*  6815 */     disallowGlobalTxnMode(115);
/*       */     
/*       */ 
/*  6818 */     if (this.autocommit)
/*       */     {
/*  6820 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6821 */       ((SQLException)localObject).fillInStackTrace();
/*  6822 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  6827 */     if (this.savepointStatement == null)
/*       */     {
/*  6829 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6832 */     Object localObject = null;
/*       */     
/*       */     try
/*       */     {
/*  6836 */       localObject = paramOracleSavepoint.getSavepointName();
/*       */     }
/*       */     catch (SQLException localSQLException)
/*       */     {
/*  6840 */       localObject = "ORACLE_SVPT_" + paramOracleSavepoint.getSavepointId();
/*       */     }
/*       */     
/*  6843 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + (String)localObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void oracleReleaseSavepoint(oracle.jdbc.OracleSavepoint paramOracleSavepoint)
/*       */     throws SQLException
/*       */   {
/*  6871 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6872 */     localSQLException.fillInStackTrace();
/*  6873 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void disallowGlobalTxnMode(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  6894 */     if (this.txnMode == 1)
/*       */     {
/*  6896 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/*  6897 */       localSQLException.fillInStackTrace();
/*  6898 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setTxnMode(int paramInt)
/*       */   {
/*  6912 */     this.txnMode = paramInt;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int getTxnMode()
/*       */   {
/*  6919 */     return this.txnMode;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Object getClientData(Object paramObject)
/*       */   {
/*  6948 */     if (this.clientData == null)
/*       */     {
/*  6950 */       return null;
/*       */     }
/*       */     
/*  6953 */     return this.clientData.get(paramObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Object setClientData(Object paramObject1, Object paramObject2)
/*       */   {
/*  6980 */     if (this.clientData == null)
/*       */     {
/*  6982 */       this.clientData = new Hashtable();
/*       */     }
/*       */     
/*  6985 */     return this.clientData.put(paramObject1, paramObject2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Object removeClientData(Object paramObject)
/*       */   {
/*  7006 */     if (this.clientData == null)
/*       */     {
/*  7008 */       return null;
/*       */     }
/*       */     
/*  7011 */     return this.clientData.remove(paramObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public oracle.sql.BlobDBAccess createBlobDBAccess()
/*       */     throws SQLException
/*       */   {
/*  7019 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7020 */     localSQLException.fillInStackTrace();
/*  7021 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public oracle.sql.ClobDBAccess createClobDBAccess()
/*       */     throws SQLException
/*       */   {
/*  7030 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7031 */     localSQLException.fillInStackTrace();
/*  7032 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public oracle.sql.BfileDBAccess createBfileDBAccess()
/*       */     throws SQLException
/*       */   {
/*  7041 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7042 */     localSQLException.fillInStackTrace();
/*  7043 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void printState()
/*       */   {
/*       */     try
/*       */     {
/*  7069 */       int i = getJdbcCsId();
/*       */       
/*       */ 
/*  7072 */       int j = getDbCsId();
/*       */       
/*       */ 
/*  7075 */       int k = getStructAttrCsId();
/*       */ 
/*       */     }
/*       */     catch (SQLException localSQLException)
/*       */     {
/*  7080 */       localSQLException.printStackTrace();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getProtocolType()
/*       */   {
/*  7092 */     return this.protocol;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getURL()
/*       */   {
/*  7103 */     return this.url;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public synchronized void setStmtCacheSize(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  7117 */     setStatementCacheSize(paramInt);
/*  7118 */     setImplicitCachingEnabled(true);
/*  7119 */     setExplicitCachingEnabled(true);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7134 */     setStatementCacheSize(paramInt);
/*  7135 */     setImplicitCachingEnabled(true);
/*       */     
/*       */ 
/*  7138 */     setExplicitCachingEnabled(true);
/*       */     
/*  7140 */     this.clearStatementMetaData = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public synchronized int getStmtCacheSize()
/*       */   {
/*  7154 */     int i = 0;
/*       */     
/*       */     try
/*       */     {
/*  7158 */       i = getStatementCacheSize();
/*       */     }
/*       */     catch (SQLException localSQLException) {}
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  7166 */     if (i == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  7171 */       i = 0;
/*       */     }
/*       */     
/*  7174 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setStatementCacheSize(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  7195 */     if (this.statementCache == null)
/*       */     {
/*  7197 */       this.statementCache = new LRUStatementCache(paramInt);
/*       */ 
/*       */ 
/*       */     }
/*       */     else
/*       */     {
/*       */ 
/*  7204 */       this.statementCache.resize(paramInt);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized int getStatementCacheSize()
/*       */     throws SQLException
/*       */   {
/*  7223 */     if (this.statementCache == null) {
/*  7224 */       return -1;
/*       */     }
/*  7226 */     return this.statementCache.getCacheSize();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setImplicitCachingEnabled(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7249 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  7254 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  7261 */     this.statementCache.setImplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean getImplicitCachingEnabled()
/*       */     throws SQLException
/*       */   {
/*  7280 */     if (this.statementCache == null) {
/*  7281 */       return false;
/*       */     }
/*  7283 */     return this.statementCache.getImplicitCachingEnabled();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setExplicitCachingEnabled(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  7306 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*  7311 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  7318 */     this.statementCache.setExplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean getExplicitCachingEnabled()
/*       */     throws SQLException
/*       */   {
/*  7337 */     if (this.statementCache == null) {
/*  7338 */       return false;
/*       */     }
/*  7340 */     return this.statementCache.getExplicitCachingEnabled();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void purgeImplicitCache()
/*       */     throws SQLException
/*       */   {
/*  7359 */     if (this.statementCache != null) {
/*  7360 */       this.statementCache.purgeImplicitCache();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void purgeExplicitCache()
/*       */     throws SQLException
/*       */   {
/*  7379 */     if (this.statementCache != null) {
/*  7380 */       this.statementCache.purgeExplicitCache();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized PreparedStatement getStatementWithKey(String paramString)
/*       */     throws SQLException
/*       */   {
/*  7402 */     if (this.statementCache != null)
/*       */     {
/*  7404 */       OracleStatement localOracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */       
/*       */ 
/*  7407 */       if ((localOracleStatement == null) || (localOracleStatement.statementType == 1)) {
/*  7408 */         return (PreparedStatement)localOracleStatement;
/*       */       }
/*       */       
/*       */ 
/*  7412 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7413 */       localSQLException.fillInStackTrace();
/*  7414 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  7419 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized CallableStatement getCallWithKey(String paramString)
/*       */     throws SQLException
/*       */   {
/*  7441 */     if (this.statementCache != null)
/*       */     {
/*  7443 */       OracleStatement localOracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */       
/*       */ 
/*  7446 */       if ((localOracleStatement == null) || (localOracleStatement.statementType == 2)) {
/*  7447 */         return (CallableStatement)localOracleStatement;
/*       */       }
/*       */       
/*       */ 
/*  7451 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7452 */       localSQLException.fillInStackTrace();
/*  7453 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  7458 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void cacheImplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2)
/*       */     throws SQLException
/*       */   {
/*  7474 */     if (this.statementCache == null)
/*       */     {
/*  7476 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7477 */       localSQLException.fillInStackTrace();
/*  7478 */       throw localSQLException;
/*       */     }
/*       */     
/*  7481 */     this.statementCache.addToImplicitCache(paramOraclePreparedStatement, paramString, paramInt1, paramInt2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void cacheExplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString)
/*       */     throws SQLException
/*       */   {
/*  7498 */     if (this.statementCache == null)
/*       */     {
/*  7500 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7501 */       localSQLException.fillInStackTrace();
/*  7502 */       throw localSQLException;
/*       */     }
/*       */     
/*  7505 */     this.statementCache.addToExplicitCache(paramOraclePreparedStatement, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean isStatementCacheInitialized()
/*       */   {
/*  7520 */     if (this.statementCache == null)
/*  7521 */       return false;
/*  7522 */     if (this.statementCache.getCacheSize() == 0) {
/*  7523 */       return false;
/*       */     }
/*  7525 */     return true;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private static final class BufferCacheStore
/*       */   {
/*  7561 */     static int MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
/*       */     final BufferCache<byte[]> byteBufferCache;
/*       */     final BufferCache<char[]> charBufferCache;
/*       */     
/*       */     BufferCacheStore() {
/*  7566 */       this(MAX_CACHED_BUFFER_SIZE);
/*       */     }
/*       */     
/*       */     BufferCacheStore(int paramInt) {
/*  7570 */       this.byteBufferCache = new BufferCache(paramInt);
/*  7571 */       this.charBufferCache = new BufferCache(paramInt);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private BufferCacheStore getBufferCacheStore()
/*       */   {
/*  7582 */     if (this.useThreadLocalBufferCache) {
/*  7583 */       if (threadLocalBufferCacheStore == null)
/*       */       {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  7596 */         BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
/*  7597 */         threadLocalBufferCacheStore = new ThreadLocal()
/*       */         {
/*       */           protected PhysicalConnection.BufferCacheStore initialValue()
/*       */           {
/*  7601 */             return new PhysicalConnection.BufferCacheStore();
/*       */           }
/*       */         };
/*       */       }
/*  7605 */       return (BufferCacheStore)threadLocalBufferCacheStore.get();
/*       */     }
/*       */     
/*  7608 */     if (this.connectionBufferCacheStore == null)
/*       */     {
/*  7610 */       this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
/*       */     }
/*  7612 */     return this.connectionBufferCacheStore;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void cacheBuffer(byte[] paramArrayOfByte)
/*       */   {
/*  7623 */     if (paramArrayOfByte != null) {
/*  7624 */       BufferCacheStore localBufferCacheStore = getBufferCacheStore();
/*  7625 */       localBufferCacheStore.byteBufferCache.put(paramArrayOfByte);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void cacheBuffer(char[] paramArrayOfChar)
/*       */   {
/*  7637 */     if (paramArrayOfChar != null) {
/*  7638 */       BufferCacheStore localBufferCacheStore = getBufferCacheStore();
/*  7639 */       localBufferCacheStore.charBufferCache.put(paramArrayOfChar);
/*       */     }
/*       */   }
/*       */   
/*       */   public void cacheBufferSync(char[] paramArrayOfChar)
/*       */   {
/*  7645 */     synchronized (this) {
/*  7646 */       cacheBuffer(paramArrayOfChar);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   byte[] getByteBuffer(int paramInt)
/*       */   {
/*  7658 */     BufferCacheStore localBufferCacheStore = getBufferCacheStore();
/*  7659 */     return (byte[])localBufferCacheStore.byteBufferCache.get(Byte.TYPE, paramInt);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   char[] getCharBuffer(int paramInt)
/*       */   {
/*  7671 */     BufferCacheStore localBufferCacheStore = getBufferCacheStore();
/*  7672 */     return (char[])localBufferCacheStore.charBufferCache.get(Character.TYPE, paramInt);
/*       */   }
/*       */   
/*       */   /* Error */
/*       */   public char[] getCharBufferSync(int paramInt)
/*       */   {
/*       */     // Byte code:
/*       */     //   0: aload_0
/*       */     //   1: dup
/*       */     //   2: astore_2
/*       */     //   3: monitorenter
/*       */     //   4: aload_0
/*       */     //   5: iload_1
/*       */     //   6: invokevirtual 745	oracle/jdbc/driver/PhysicalConnection:getCharBuffer	(I)[C
/*       */     //   9: aload_2
/*       */     //   10: monitorexit
/*       */     //   11: areturn
/*       */     //   12: astore_3
/*       */     //   13: aload_2
/*       */     //   14: monitorexit
/*       */     //   15: aload_3
/*       */     //   16: athrow
/*       */     // Line number table:
/*       */     //   Java source line #7677	-> byte code offset #0
/*       */     //   Java source line #7678	-> byte code offset #4
/*       */     //   Java source line #7679	-> byte code offset #12
/*       */     // Local variable table:
/*       */     //   start	length	slot	name	signature
/*       */     //   0	17	0	this	PhysicalConnection
/*       */     //   0	17	1	paramInt	int
/*       */     //   2	12	2	Ljava/lang/Object;	Object
/*       */     //   12	4	3	localObject1	Object
/*       */     // Exception table:
/*       */     //   from	to	target	type
/*       */     //   4	11	12	finally
/*       */     //   12	15	12	finally
/*       */   }
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics()
/*       */   {
/*  7689 */     BufferCacheStore localBufferCacheStore = getBufferCacheStore();
/*  7690 */     return localBufferCacheStore.byteBufferCache.getStatistics();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics()
/*       */   {
/*  7701 */     BufferCacheStore localBufferCacheStore = getBufferCacheStore();
/*  7702 */     return localBufferCacheStore.charBufferCache.getStatistics();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  7725 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7726 */     localSQLException.fillInStackTrace();
/*  7727 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getDatabaseProductVersion()
/*       */     throws SQLException
/*       */   {
/*  7740 */     if (this.databaseProductVersion == "")
/*       */     {
/*  7742 */       needLine();
/*       */       
/*  7744 */       this.databaseProductVersion = doGetDatabaseProductVersion();
/*       */     }
/*       */     
/*  7747 */     return this.databaseProductVersion;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public synchronized boolean getReportRemarks()
/*       */   {
/*  7754 */     return this.reportRemarks;
/*       */   }
/*       */   
/*       */ 
/*       */   public short getVersionNumber()
/*       */     throws SQLException
/*       */   {
/*  7761 */     if (this.versionNumber == -1)
/*       */     {
/*  7763 */       synchronized (this)
/*       */       {
/*  7765 */         if (this.versionNumber == -1)
/*       */         {
/*  7767 */           needLine();
/*       */           
/*  7769 */           this.versionNumber = doGetVersionNumber();
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*  7774 */     return this.versionNumber;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject)
/*       */   {
/*  7782 */     this.closeCallback = paramOracleCloseCallback;
/*  7783 */     this.privateData = paramObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setCreateStatementAsRefCursor(boolean paramBoolean) {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getCreateStatementAsRefCursor()
/*       */   {
/*  7831 */     return false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int pingDatabase()
/*       */     throws SQLException
/*       */   {
/*  7842 */     if (this.lifecycle != 1)
/*  7843 */       return -1;
/*  7844 */     return doPingDatabase();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public int pingDatabase(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  7857 */     if (this.lifecycle != 1)
/*  7858 */       return -1;
/*  7859 */     if (paramInt == 0) {
/*  7860 */       return pingDatabase();
/*       */     }
/*       */     try
/*       */     {
/*  7864 */       this.pingResult = -2;
/*  7865 */       Thread localThread = new Thread(new Runnable() {
/*       */         public void run() {
/*       */           try {
/*  7868 */             PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
/*       */           }
/*       */           catch (Throwable localThrowable) {}
/*       */         }
/*  7872 */       });
/*  7873 */       localThread.start();
/*  7874 */       localThread.join(paramInt * 1000);
/*  7875 */       return this.pingResult;
/*       */     }
/*       */     catch (InterruptedException localInterruptedException) {}
/*  7878 */     return -3;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   int doPingDatabase()
/*       */     throws SQLException
/*       */   {
/*  7887 */     Statement localStatement = null;
/*       */     
/*       */     try
/*       */     {
/*  7891 */       localStatement = createStatement();
/*       */       
/*  7893 */       ((oracle.jdbc.OracleStatement)localStatement).defineColumnType(1, 12, 1);
/*  7894 */       localStatement.executeQuery("SELECT 'x' FROM DUAL");
/*       */     }
/*       */     catch (SQLException localSQLException)
/*       */     {
/*  7898 */       return -1;
/*       */     }
/*       */     finally
/*       */     {
/*  7902 */       if (localStatement != null) {
/*  7903 */         localStatement.close();
/*       */       }
/*       */     }
/*  7906 */     return 0;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized Map getJavaObjectTypeMap()
/*       */   {
/*  7922 */     return this.javaObjectMap;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setJavaObjectTypeMap(Map paramMap)
/*       */   {
/*  7932 */     this.javaObjectMap = paramMap;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void clearClientIdentifier(String paramString)
/*       */     throws SQLException
/*       */   {
/*  7947 */     if ((paramString != null) && (paramString.length() != 0))
/*       */     {
/*       */ 
/*       */ 
/*  7951 */       String[] arrayOfString = getEndToEndMetrics();
/*       */       
/*  7953 */       if ((arrayOfString != null) && (paramString.equals(arrayOfString[1])))
/*       */       {
/*       */ 
/*  7956 */         arrayOfString[1] = null;
/*       */         
/*  7958 */         setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public void setClientIdentifier(String paramString)
/*       */     throws SQLException
/*       */   {
/*  7980 */     String[] arrayOfString = getEndToEndMetrics();
/*       */     
/*  7982 */     if (arrayOfString == null)
/*       */     {
/*  7984 */       arrayOfString = new String[4];
/*       */     }
/*       */     
/*       */ 
/*  7988 */     arrayOfString[1] = paramString;
/*       */     
/*  7990 */     setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*  8002 */   String sessionTimeZone = null;
/*  8003 */   String databaseTimeZone = null;
/*  8004 */   Calendar dbTzCalendar = null;
/*       */   
/*       */ 
/*       */ 
/*       */   static final String RAW_STR = "RAW";
/*       */   
/*       */ 
/*       */ 
/*       */   static final String SYS_RAW_STR = "SYS.RAW";
/*       */   
/*       */ 
/*       */ 
/*       */   static final String SYS_ANYDATA_STR = "SYS.ANYDATA";
/*       */   
/*       */ 
/*       */ 
/*       */   static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setSessionTimeZone(String paramString)
/*       */     throws SQLException
/*       */   {
/*  8028 */     Statement localStatement = null;
/*  8029 */     Object localObject1 = null;
/*       */     
/*       */     try
/*       */     {
/*  8033 */       localStatement = createStatement();
/*       */       
/*       */ 
/*  8036 */       localStatement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + paramString + "'");
/*       */       
/*       */ 
/*       */ 
/*       */ 
/*  8041 */       if (this.dbTzCalendar == null) {
/*  8042 */         setDbTzCalendar(getDatabaseTimeZone());
/*       */       }
/*       */     }
/*       */     catch (SQLException localSQLException)
/*       */     {
/*  8047 */       throw localSQLException;
/*       */     }
/*       */     finally
/*       */     {
/*  8051 */       if (localStatement != null) {
/*  8052 */         localStatement.close();
/*       */       }
/*       */     }
/*  8055 */     this.sessionTimeZone = paramString;
/*       */   }
/*       */   
/*       */   public String getDatabaseTimeZone()
/*       */     throws SQLException
/*       */   {
/*  8061 */     if (this.databaseTimeZone == null)
/*       */     {
/*  8063 */       this.databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");
/*       */     }
/*       */     
/*  8066 */     return this.databaseTimeZone;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getSessionTimeZone()
/*       */   {
/*  8080 */     return this.sessionTimeZone;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   private static String to2DigitString(int paramInt)
/*       */   {
/*       */     String str;
/*       */     
/*  8089 */     if (paramInt < 10) {
/*  8090 */       str = "0" + paramInt;
/*       */     } else {
/*  8092 */       str = "" + paramInt;
/*       */     }
/*  8094 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public String tzToOffset(String paramString)
/*       */   {
/*  8102 */     if (paramString == null) {
/*  8103 */       return paramString;
/*       */     }
/*  8105 */     int i = paramString.charAt(0);
/*       */     
/*  8107 */     if ((i != 45) && (i != 43))
/*       */     {
/*       */ 
/*  8110 */       TimeZone localTimeZone = TimeZone.getTimeZone(paramString);
/*       */       
/*  8112 */       int j = localTimeZone.getOffset(System.currentTimeMillis());
/*       */       
/*  8114 */       if (j != 0)
/*       */       {
/*  8116 */         int k = j / 60000;
/*  8117 */         int m = k / 60;
/*  8118 */         k -= m * 60;
/*       */         
/*  8120 */         if (j > 0)
/*       */         {
/*  8122 */           paramString = "+" + to2DigitString(m) + ":" + to2DigitString(k);
/*       */ 
/*       */         }
/*       */         else
/*       */         {
/*  8127 */           paramString = "-" + to2DigitString(-m) + ":" + to2DigitString(-k);
/*       */         }
/*       */         
/*       */       }
/*       */       else
/*       */       {
/*  8133 */         paramString = "+00:00";
/*       */       }
/*       */     }
/*       */     
/*  8137 */     return paramString;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public String getSessionTimeZoneOffset()
/*       */     throws SQLException
/*       */   {
/*  8147 */     String str = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL");
/*       */     
/*       */ 
/*  8150 */     if (str != null)
/*       */     {
/*  8152 */       str = tzToOffset(str.trim());
/*       */     }
/*       */     
/*  8155 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private void setDbTzCalendar(String paramString)
/*       */   {
/*  8170 */     int i = paramString.charAt(0);
/*       */     
/*  8172 */     if ((i == 45) || (i == 43)) {
/*  8173 */       paramString = "GMT" + paramString;
/*       */     }
/*  8175 */     TimeZone localTimeZone = TimeZone.getTimeZone(paramString);
/*       */     
/*  8177 */     this.dbTzCalendar = new java.util.GregorianCalendar(localTimeZone);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Calendar getDbTzCalendar()
/*       */     throws SQLException
/*       */   {
/*  8192 */     if (this.dbTzCalendar == null)
/*       */     {
/*       */ 
/*  8195 */       setDbTzCalendar(getDatabaseTimeZone());
/*       */     }
/*       */     
/*  8198 */     return this.dbTzCalendar;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setAccumulateBatchResult(boolean paramBoolean)
/*       */   {
/*  8215 */     this.accumulateBatchResult = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean isAccumulateBatchResult()
/*       */   {
/*  8233 */     return this.accumulateBatchResult;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setJ2EE13Compliant(boolean paramBoolean)
/*       */   {
/*  8250 */     this.j2ee13Compliant = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getJ2EE13Compliant()
/*       */   {
/*  8267 */     return this.j2ee13Compliant;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Class classForNameAndSchema(String paramString1, String paramString2)
/*       */     throws ClassNotFoundException
/*       */   {
/*  8284 */     return Class.forName(paramString1);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Class safelyGetClassForName(String paramString)
/*       */     throws ClassNotFoundException
/*       */   {
/*  8304 */     return Class.forName(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getHeapAllocSize()
/*       */     throws SQLException
/*       */   {
/*  8318 */     if (this.lifecycle != 1)
/*       */     {
/*  8320 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  8321 */       localSQLException.fillInStackTrace();
/*  8322 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  8326 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8327 */     localSQLException.fillInStackTrace();
/*  8328 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getOCIEnvHeapAllocSize()
/*       */     throws SQLException
/*       */   {
/*  8342 */     if (this.lifecycle != 1)
/*       */     {
/*  8344 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  8345 */       localSQLException.fillInStackTrace();
/*  8346 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*  8350 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8351 */     localSQLException.fillInStackTrace();
/*  8352 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public static OracleConnection unwrapCompletely(oracle.jdbc.OracleConnection paramOracleConnection)
/*       */   {
/*  8367 */     Object localObject1 = paramOracleConnection;
/*  8368 */     Object localObject2 = localObject1;
/*       */     
/*       */     for (;;)
/*       */     {
/*  8372 */       if (localObject2 == null) {
/*  8373 */         return (OracleConnection)localObject1;
/*       */       }
/*  8375 */       localObject1 = localObject2;
/*  8376 */       localObject2 = ((oracle.jdbc.OracleConnection)localObject1).unwrap();
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public void setWrapper(oracle.jdbc.OracleConnection paramOracleConnection)
/*       */   {
/*  8384 */     this.wrapper = paramOracleConnection;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public oracle.jdbc.OracleConnection unwrap()
/*       */   {
/*  8391 */     return null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public oracle.jdbc.OracleConnection getWrapper()
/*       */   {
/*  8398 */     if (this.wrapper != null) {
/*  8399 */       return this.wrapper;
/*       */     }
/*  8401 */     return this;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   static oracle.jdbc.internal.OracleConnection _physicalConnectionWithin(Connection paramConnection)
/*       */   {
/*  8419 */     OracleConnection localOracleConnection = null;
/*       */     
/*       */ 
/*       */ 
/*  8423 */     if (paramConnection != null)
/*       */     {
/*  8425 */       localOracleConnection = unwrapCompletely((oracle.jdbc.OracleConnection)paramConnection);
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*  8430 */     return localOracleConnection;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public oracle.jdbc.internal.OracleConnection physicalConnectionWithin()
/*       */   {
/*  8437 */     return this;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public long getTdoCState(String paramString1, String paramString2)
/*       */     throws SQLException
/*       */   {
/*  8445 */     return 0L;
/*       */   }
/*       */   
/*       */   public void getOracleTypeADT(OracleTypeADT paramOracleTypeADT)
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */   public Datum toDatum(CustomDatum paramCustomDatum)
/*       */     throws SQLException
/*       */   {
/*  8455 */     return paramCustomDatum.toDatum(this);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public short getNCharSet()
/*       */   {
/*  8462 */     return this.conversion.getNCharSetId();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap)
/*       */     throws SQLException
/*       */   {
/*  8470 */     return new ArrayDataResultSet(this, paramArrayOfDatum, paramLong, paramInt, paramMap);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap)
/*       */     throws SQLException
/*       */   {
/*  8478 */     return new ArrayDataResultSet(this, paramARRAY, paramLong, paramInt, paramMap);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfByte, long paramLong, int paramInt, Map paramMap)
/*       */     throws SQLException
/*       */   {
/*  8488 */     return new ArrayLocatorResultSet(this, paramArrayDescriptor, paramArrayOfByte, paramLong, paramInt, paramMap);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public java.sql.ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor)
/*       */     throws SQLException
/*       */   {
/*  8496 */     return new StructMetaData(paramStructDescriptor);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int CHARBytesToJavaChars(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar)
/*       */     throws SQLException
/*       */   {
/*  8504 */     int[] arrayOfInt = new int[1];
/*       */     
/*  8506 */     arrayOfInt[0] = paramInt;
/*       */     
/*  8508 */     return this.conversion.CHARBytesToJavaChars(paramArrayOfByte, 0, paramArrayOfChar, 0, arrayOfInt, paramArrayOfChar.length);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public int NCHARBytesToJavaChars(byte[] paramArrayOfByte, int paramInt, char[] paramArrayOfChar)
/*       */     throws SQLException
/*       */   {
/*  8517 */     int[] arrayOfInt = new int[1];
/*       */     
/*  8519 */     return this.conversion.NCHARBytesToJavaChars(paramArrayOfByte, 0, paramArrayOfChar, 0, arrayOfInt, paramArrayOfChar.length);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean IsNCharFixedWith()
/*       */   {
/*  8527 */     return this.conversion.IsNCharFixedWith();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public short getDriverCharSet()
/*       */   {
/*  8534 */     return this.conversion.getClientCharSet();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int getMaxCharSize()
/*       */     throws SQLException
/*       */   {
/*  8542 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58);
/*  8543 */     localSQLException.fillInStackTrace();
/*  8544 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public int getMaxCharbyteSize()
/*       */   {
/*  8552 */     return this.conversion.getMaxCharbyteSize();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int getMaxNCharbyteSize()
/*       */   {
/*  8559 */     return this.conversion.getMaxNCharbyteSize();
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public boolean isCharSetMultibyte(short paramShort)
/*       */   {
/*  8566 */     return DBConversion.isCharSetMultibyte(paramShort);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int javaCharsToCHARBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8574 */     return this.conversion.javaCharsToCHARBytes(paramArrayOfChar, paramInt, paramArrayOfByte);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public int javaCharsToNCHARBytes(char[] paramArrayOfChar, int paramInt, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8582 */     return this.conversion.javaCharsToNCHARBytes(paramArrayOfChar, paramInt, paramArrayOfByte);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public abstract void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */   final void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection, String paramString)
/*       */     throws SQLException
/*       */   {
/*  8594 */     Hashtable localHashtable = new Hashtable();
/*       */     
/*  8596 */     localHashtable.put("obj_type_map", this.javaObjectMap);
/*       */     
/*  8598 */     Properties localProperties = new Properties();
/*       */     
/*  8600 */     localProperties.put("user", this.userName);
/*  8601 */     localProperties.put("password", paramString);
/*       */     
/*  8603 */     localProperties.put("connection_url", this.url);
/*  8604 */     localProperties.put("connect_auto_commit", "" + this.autocommit);
/*       */     
/*       */ 
/*  8607 */     localProperties.put("trans_isolation", "" + this.txnLevel);
/*       */     
/*  8609 */     if (getStatementCacheSize() != -1)
/*       */     {
/*  8611 */       localProperties.put("stmt_cache_size", "" + getStatementCacheSize());
/*       */       
/*  8613 */       localProperties.put("implicit_cache_enabled", "" + getImplicitCachingEnabled());
/*       */       
/*  8615 */       localProperties.put("explict_cache_enabled", "" + getExplicitCachingEnabled());
/*       */     }
/*       */     
/*       */ 
/*  8619 */     localProperties.put("defaultExecuteBatch", "" + this.defaultExecuteBatch);
/*  8620 */     localProperties.put("defaultRowPrefetch", "" + this.defaultRowPrefetch);
/*  8621 */     localProperties.put("remarksReporting", "" + this.reportRemarks);
/*  8622 */     localProperties.put("AccumulateBatchResult", "" + this.accumulateBatchResult);
/*  8623 */     localProperties.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant);
/*  8624 */     localProperties.put("processEscapes", "" + this.processEscapes);
/*       */     
/*  8626 */     localProperties.put("restrictGetTables", "" + this.restrictGettables);
/*  8627 */     localProperties.put("includeSynonyms", "" + this.includeSynonyms);
/*  8628 */     localProperties.put("fixedString", "" + this.fixedString);
/*       */     
/*  8630 */     localHashtable.put("connection_properties", localProperties);
/*       */     
/*  8632 */     paramOraclePooledConnection.setProperties(localHashtable);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Properties getDBAccessProperties()
/*       */     throws SQLException
/*       */   {
/*  8659 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8660 */     localSQLException.fillInStackTrace();
/*  8661 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Properties getOCIHandles()
/*       */     throws SQLException
/*       */   {
/*  8678 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8679 */     localSQLException.fillInStackTrace();
/*  8680 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract void logon()
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void logoff()
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract void open(OracleStatement paramOracleStatement)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract void cancelOperationOnServer()
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract void doSetAutoCommit(boolean paramBoolean)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract void doCommit(int paramInt)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract void doRollback()
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract String doGetDatabaseProductVersion()
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   abstract short doGetVersionNumber()
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   int getDefaultStreamChunkSize()
/*       */   {
/*  8780 */     return this.streamChunkSize;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   abstract OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfByte, OracleStatement paramOracleStatement)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */   public oracle.jdbc.internal.OracleStatement refCursorCursorToStatement(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  8792 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  8793 */     localSQLException.fillInStackTrace();
/*  8794 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  8807 */     if ((this.logicalConnectionAttached != null) || (paramOraclePooledConnection.getPhysicalHandle() != this))
/*       */     {
/*  8809 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143);
/*  8810 */       ((SQLException)localObject).fillInStackTrace();
/*  8811 */       throw ((Throwable)localObject);
/*       */     }
/*       */     
/*  8814 */     Object localObject = new LogicalConnection(paramOraclePooledConnection, this, paramBoolean);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*  8819 */     this.logicalConnectionAttached = ((LogicalConnection)localObject);
/*       */     
/*  8821 */     return (Connection)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt)
/*       */     throws SQLException
/*       */   {}
/*       */   
/*       */ 
/*       */   public CLOB createClob(byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8834 */     Object localObject = new CLOB(this, paramArrayOfByte);
/*  8835 */     if (((CLOB)localObject).isNCLOB())
/*       */     {
/*  8837 */       localObject = new NCLOB((CLOB)localObject);
/*       */     }
/*       */     
/*  8840 */     return (CLOB)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8849 */     Object localObject = new CLOB(this, paramArrayOfByte, true);
/*  8850 */     if (((CLOB)localObject).isNCLOB())
/*       */     {
/*  8852 */       localObject = new NCLOB((CLOB)localObject);
/*       */     }
/*       */     
/*  8855 */     return (CLOB)localObject;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public CLOB createClob(byte[] paramArrayOfByte, short paramShort)
/*       */     throws SQLException
/*       */   {
/*  8866 */     if (paramShort == 2) {
/*  8867 */       return new NCLOB(this, paramArrayOfByte);
/*       */     }
/*       */     
/*       */ 
/*  8871 */     return new CLOB(this, paramArrayOfByte, paramShort);
/*       */   }
/*       */   
/*       */ 
/*       */   public BLOB createBlob(byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8878 */     return new BLOB(this, paramArrayOfByte);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8886 */     return new BLOB(this, paramArrayOfByte, true);
/*       */   }
/*       */   
/*       */ 
/*       */   public BFILE createBfile(byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/*  8893 */     return new BFILE(this, paramArrayOfByte);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public ARRAY createARRAY(String paramString, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  8912 */     ArrayDescriptor localArrayDescriptor = ArrayDescriptor.createDescriptor(paramString, this);
/*  8913 */     return new ARRAY(localArrayDescriptor, this, paramObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Array createOracleArray(String paramString, Object paramObject)
/*       */     throws SQLException
/*       */   {
/*  8933 */     return createARRAY(paramString, paramObject);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public BINARY_DOUBLE createBINARY_DOUBLE(double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  8950 */     return new BINARY_DOUBLE(paramDouble);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public BINARY_FLOAT createBINARY_FLOAT(float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  8965 */     return new BINARY_FLOAT(paramFloat);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  8980 */     return new DATE(paramDate);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  8995 */     return new DATE(paramTime);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  9010 */     return new DATE(paramTimestamp);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9028 */     return new DATE(paramDate);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9046 */     return new DATE(paramTime);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9064 */     return new DATE(paramTimestamp);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DATE createDATE(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9079 */     return new DATE(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public INTERVALDS createINTERVALDS(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9094 */     return new INTERVALDS(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public INTERVALYM createINTERVALYM(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9109 */     return new INTERVALYM(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/*  9124 */     return new NUMBER(paramBoolean);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(byte paramByte)
/*       */     throws SQLException
/*       */   {
/*  9139 */     return new NUMBER(paramByte);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(short paramShort)
/*       */     throws SQLException
/*       */   {
/*  9154 */     return new NUMBER(paramShort);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(int paramInt)
/*       */     throws SQLException
/*       */   {
/*  9169 */     return new NUMBER(paramInt);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(long paramLong)
/*       */     throws SQLException
/*       */   {
/*  9184 */     return new NUMBER(paramLong);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(float paramFloat)
/*       */     throws SQLException
/*       */   {
/*  9199 */     return new NUMBER(paramFloat);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(double paramDouble)
/*       */     throws SQLException
/*       */   {
/*  9214 */     return new NUMBER(paramDouble);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(BigDecimal paramBigDecimal)
/*       */     throws SQLException
/*       */   {
/*  9229 */     return new NUMBER(paramBigDecimal);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(BigInteger paramBigInteger)
/*       */     throws SQLException
/*       */   {
/*  9244 */     return new NUMBER(paramBigInteger);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NUMBER createNUMBER(String paramString, int paramInt)
/*       */     throws SQLException
/*       */   {
/*  9260 */     return new NUMBER(paramString, paramInt);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public Array createArrayOf(String paramString, Object[] paramArrayOfObject)
/*       */     throws SQLException
/*       */   {
/*  9282 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  9283 */     localSQLException.fillInStackTrace();
/*  9284 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public java.sql.Struct createStruct(String paramString, Object[] paramArrayOfObject)
/*       */     throws SQLException
/*       */   {
/*       */     try
/*       */     {
/*  9303 */       StructDescriptor localStructDescriptor = StructDescriptor.createDescriptor(paramString, this);
/*  9304 */       return new oracle.sql.STRUCT(localStructDescriptor, this, paramArrayOfObject);
/*       */     }
/*       */     catch (SQLException localSQLException)
/*       */     {
/*  9308 */       if (localSQLException.getErrorCode() == 17049)
/*  9309 */         removeAllDescriptor();
/*  9310 */       throw localSQLException;
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMP createTIMESTAMP(Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  9326 */     return new TIMESTAMP(paramDate);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMP createTIMESTAMP(DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/*  9341 */     return new TIMESTAMP(paramDATE);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMP createTIMESTAMP(Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  9356 */     return new TIMESTAMP(paramTime);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMP createTIMESTAMP(Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  9371 */     return new TIMESTAMP(paramTimestamp);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMP createTIMESTAMP(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9386 */     return new TIMESTAMP(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate)
/*       */     throws SQLException
/*       */   {
/*  9401 */     return new TIMESTAMPTZ(this, paramDate);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9420 */     return new TIMESTAMPTZ(this, paramDate, paramCalendar);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime)
/*       */     throws SQLException
/*       */   {
/*  9435 */     return new TIMESTAMPTZ(this, paramTime);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9454 */     return new TIMESTAMPTZ(this, paramTime, paramCalendar);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp)
/*       */     throws SQLException
/*       */   {
/*  9469 */     return new TIMESTAMPTZ(this, paramTimestamp);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9488 */     return new TIMESTAMPTZ(this, paramTimestamp, paramCalendar);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9503 */     return new TIMESTAMPTZ(this, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(String paramString, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9522 */     return new TIMESTAMPTZ(this, paramString, paramCalendar);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPTZ createTIMESTAMPTZ(DATE paramDATE)
/*       */     throws SQLException
/*       */   {
/*  9533 */     return new TIMESTAMPTZ(this, paramDATE);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPLTZ createTIMESTAMPLTZ(Date paramDate, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9552 */     return new TIMESTAMPLTZ(this, paramCalendar, paramDate);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPLTZ createTIMESTAMPLTZ(Time paramTime, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9571 */     return new TIMESTAMPLTZ(this, paramCalendar, paramTime);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp paramTimestamp, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9590 */     return new TIMESTAMPLTZ(this, paramCalendar, paramTimestamp);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPLTZ createTIMESTAMPLTZ(String paramString, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9609 */     return new TIMESTAMPLTZ(this, paramCalendar, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE paramDATE, Calendar paramCalendar)
/*       */     throws SQLException
/*       */   {
/*  9628 */     return new TIMESTAMPLTZ(this, paramCalendar, paramDATE);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public abstract BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public abstract CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort)
/*       */     throws SQLException;
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public java.sql.Blob createBlob()
/*       */     throws SQLException
/*       */   {
/*  9652 */     if (this.lifecycle != 1)
/*       */     {
/*  9654 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  9655 */       localSQLException.fillInStackTrace();
/*  9656 */       throw localSQLException;
/*       */     }
/*       */     
/*  9659 */     return createTemporaryBlob(this, true, 10);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public java.sql.Clob createClob()
/*       */     throws SQLException
/*       */   {
/*  9673 */     if (this.lifecycle != 1)
/*       */     {
/*  9675 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  9676 */       localSQLException.fillInStackTrace();
/*  9677 */       throw localSQLException;
/*       */     }
/*       */     
/*  9680 */     return createTemporaryClob(this, true, 10, (short)1);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public NClob createNClob()
/*       */     throws SQLException
/*       */   {
/*  9695 */     if (this.lifecycle != 1)
/*       */     {
/*  9697 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  9698 */       localSQLException.fillInStackTrace();
/*  9699 */       throw localSQLException;
/*       */     }
/*       */     
/*  9702 */     return (NClob)createTemporaryClob(this, true, 10, (short)2);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public SQLXML createSQLXML()
/*       */     throws SQLException
/*       */   {
/*  9717 */     if (this.lifecycle != 1)
/*       */     {
/*  9719 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  9720 */       localSQLException.fillInStackTrace();
/*  9721 */       throw localSQLException;
/*       */     }
/*       */     
/*  9724 */     return (SQLXML)new oracle.xdb.XMLType(this, (String)null);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean isDescriptorSharable(oracle.jdbc.internal.OracleConnection paramOracleConnection)
/*       */     throws SQLException
/*       */   {
/*  9741 */     PhysicalConnection localPhysicalConnection1 = this;
/*  9742 */     PhysicalConnection localPhysicalConnection2 = (PhysicalConnection)paramOracleConnection.getPhysicalConnection();
/*       */     
/*  9744 */     return (localPhysicalConnection1 == localPhysicalConnection2) || (localPhysicalConnection1.url.equals(localPhysicalConnection2.url)) || ((localPhysicalConnection2.protocol != null) && (localPhysicalConnection2.protocol.equals("kprb")));
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   boolean useLittleEndianSetCHARBinder()
/*       */     throws SQLException
/*       */   {
/*  9753 */     return false;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setPlsqlWarnings(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9774 */     if (paramString == null)
/*       */     {
/*  9776 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9777 */       ((SQLException)localObject1).fillInStackTrace();
/*  9778 */       throw ((Throwable)localObject1);
/*       */     }
/*       */     
/*  9781 */     if ((paramString != null) && ((paramString = paramString.trim()).length() > 0) && (!OracleSql.isValidPlsqlWarning(paramString)))
/*       */     {
/*       */ 
/*       */ 
/*  9785 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  9786 */       ((SQLException)localObject1).fillInStackTrace();
/*  9787 */       throw ((Throwable)localObject1);
/*       */     }
/*       */     
/*  9790 */     Object localObject1 = "ALTER SESSION SET PLSQL_WARNINGS=" + paramString;
/*       */     
/*  9792 */     String str = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'";
/*       */     
/*       */ 
/*  9795 */     Statement localStatement = null;
/*       */     try
/*       */     {
/*  9798 */       localStatement = createStatement(-1, -1);
/*       */       
/*  9800 */       localStatement.execute((String)localObject1);
/*       */       
/*  9802 */       if (paramString.equals("'DISABLE:ALL'"))
/*       */       {
/*  9804 */         this.plsqlCompilerWarnings = false;
/*       */       }
/*       */       else
/*       */       {
/*  9808 */         localStatement.execute(str);
/*       */         
/*  9810 */         this.plsqlCompilerWarnings = true;
/*       */       }
/*       */     }
/*       */     finally {
/*  9814 */       if (localStatement != null) {
/*  9815 */         localStatement.close();
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void internalClose()
/*       */     throws SQLException
/*       */   {
/*  9828 */     this.lifecycle = 4;
/*       */     
/*  9830 */     Object localObject = this.statements;
/*       */     OracleStatement localOracleStatement;
/*  9832 */     while (localObject != null)
/*       */     {
/*  9834 */       localOracleStatement = ((OracleStatement)localObject).nextChild;
/*       */       
/*  9836 */       if (((OracleStatement)localObject).serverCursor)
/*       */       {
/*  9838 */         ((OracleStatement)localObject).internalClose();
/*  9839 */         removeStatement((OracleStatement)localObject);
/*       */       }
/*       */       
/*  9842 */       localObject = localOracleStatement;
/*       */     }
/*       */     
/*  9845 */     localObject = this.statements;
/*       */     
/*  9847 */     while (localObject != null)
/*       */     {
/*  9849 */       localOracleStatement = ((OracleStatement)localObject).next;
/*  9850 */       ((OracleStatement)localObject).internalClose();
/*  9851 */       localObject = localOracleStatement;
/*       */     }
/*       */     
/*  9854 */     this.statements = null;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public javax.transaction.xa.XAResource getXAResource()
/*       */     throws SQLException
/*       */   {
/*  9870 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164);
/*  9871 */     localSQLException.fillInStackTrace();
/*  9872 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo)
/*       */     throws SQLException
/*       */   {
/*  9885 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  9886 */     localSQLException.fillInStackTrace();
/*  9887 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void setApplicationContext(String paramString1, String paramString2, String paramString3)
/*       */     throws SQLException
/*       */   {
/*  9900 */     if ((paramString1 == null) || (paramString2 == null) || (paramString3 == null))
/*       */     {
/*       */ 
/*  9903 */       throw new NullPointerException(); }
/*       */     SQLException localSQLException;
/*  9905 */     if (paramString1.equals(""))
/*       */     {
/*  9907 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170);
/*       */       
/*  9909 */       localSQLException.fillInStackTrace();
/*  9910 */       throw localSQLException;
/*       */     }
/*       */     
/*  9913 */     if (paramString1.compareToIgnoreCase("CLIENTCONTEXT") != 0)
/*       */     {
/*  9915 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 174);
/*       */       
/*  9917 */       localSQLException.fillInStackTrace();
/*  9918 */       throw localSQLException;
/*       */     }
/*       */     
/*  9921 */     if (paramString2.length() > 30)
/*       */     {
/*  9923 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171);
/*       */       
/*  9925 */       localSQLException.fillInStackTrace();
/*  9926 */       throw localSQLException;
/*       */     }
/*       */     
/*  9929 */     if (paramString3.length() > 4000)
/*       */     {
/*  9931 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172);
/*       */       
/*  9933 */       localSQLException.fillInStackTrace();
/*  9934 */       throw localSQLException;
/*       */     }
/*       */     
/*  9937 */     doSetApplicationContext(paramString1, paramString2, paramString3);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3)
/*       */     throws SQLException
/*       */   {
/*  9950 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  9951 */     localSQLException.fillInStackTrace();
/*  9952 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void clearAllApplicationContext(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9963 */     if (paramString == null)
/*  9964 */       throw new NullPointerException();
/*  9965 */     if (paramString.equals(""))
/*       */     {
/*  9967 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170);
/*       */       
/*  9969 */       localSQLException.fillInStackTrace();
/*  9970 */       throw localSQLException;
/*       */     }
/*       */     
/*  9973 */     doClearAllApplicationContext(paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doClearAllApplicationContext(String paramString)
/*       */     throws SQLException
/*       */   {
/*  9983 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  9984 */     localSQLException.fillInStackTrace();
/*  9985 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfInt)
/*       */     throws SQLException
/*       */   {
/*  9999 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10000 */     localSQLException.fillInStackTrace();
/* 10001 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfByte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfInt)
/*       */     throws SQLException
/*       */   {
/* 10015 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10016 */     localSQLException.fillInStackTrace();
/* 10017 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfByte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2)
/*       */     throws SQLException
/*       */   {
/* 10029 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10030 */     localSQLException.fillInStackTrace();
/* 10031 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfByte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1)
/*       */     throws SQLException
/*       */   {
/* 10044 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10045 */     localSQLException.fillInStackTrace();
/* 10046 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfByte, XSNamespace[] paramArrayOfXSNamespace)
/*       */     throws SQLException
/*       */   {
/* 10057 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10058 */     localSQLException.fillInStackTrace();
/* 10059 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void enqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessage paramAQMessage)
/*       */     throws SQLException
/*       */   {
/* 10070 */     AQMessageI localAQMessageI = (AQMessageI)paramAQMessage;
/*       */     
/* 10072 */     byte[][] arrayOfByte = new byte[1][];
/*       */     
/*       */ 
/*       */ 
/* 10076 */     doEnqueue(paramString, paramAQEnqueueOptions, localAQMessageI.getMessagePropertiesI(), localAQMessageI.getPayloadTOID(), localAQMessageI.getPayload(), arrayOfByte, localAQMessageI.isRAWPayload());
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10087 */     if (arrayOfByte[0] != null) {
/* 10088 */       localAQMessageI.setMessageId(arrayOfByte[0]);
/*       */     }
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public AQMessage dequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfByte)
/*       */     throws SQLException
/*       */   {
/* 10098 */     byte[][] arrayOfByte1 = new byte[1][];
/* 10099 */     AQMessagePropertiesI localAQMessagePropertiesI = new AQMessagePropertiesI();
/* 10100 */     byte[][] arrayOfByte2 = new byte[1][];
/* 10101 */     boolean bool = false;
/*       */     
/*       */ 
/*       */ 
/*       */ 
/* 10106 */     bool = doDequeue(paramString, paramAQDequeueOptions, localAQMessagePropertiesI, paramArrayOfByte, arrayOfByte2, arrayOfByte1, AQMessageI.compareToid(paramArrayOfByte, TypeDescriptor.RAWTOID));
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10118 */     AQMessageI localAQMessageI = null;
/* 10119 */     if (bool)
/*       */     {
/* 10121 */       localAQMessageI = new AQMessageI(localAQMessagePropertiesI, this);
/* 10122 */       localAQMessageI.setPayload(arrayOfByte2[0], paramArrayOfByte);
/* 10123 */       localAQMessageI.setMessageId(arrayOfByte1[0]);
/*       */     }
/* 10125 */     return localAQMessageI;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public AQMessage dequeue(String paramString1, AQDequeueOptions paramAQDequeueOptions, String paramString2)
/*       */     throws SQLException
/*       */   {
/* 10139 */     byte[] arrayOfByte = null;
/* 10140 */     TypeDescriptor localTypeDescriptor = null;
/* 10141 */     if (("RAW".equals(paramString2)) || ("SYS.RAW".equals(paramString2)))
/*       */     {
/* 10143 */       arrayOfByte = TypeDescriptor.RAWTOID;
/* 10144 */     } else if ("SYS.ANYDATA".equals(paramString2)) {
/* 10145 */       arrayOfByte = TypeDescriptor.ANYDATATOID;
/* 10146 */     } else if ("SYS.XMLTYPE".equals(paramString2)) {
/* 10147 */       arrayOfByte = TypeDescriptor.XMLTYPETOID;
/*       */     }
/*       */     else {
/* 10150 */       localTypeDescriptor = TypeDescriptor.getTypeDescriptor(paramString2, this);
/* 10151 */       arrayOfByte = ((OracleTypeADT)localTypeDescriptor.getPickler()).getTOID();
/*       */     }
/* 10153 */     AQMessageI localAQMessageI = (AQMessageI)dequeue(paramString1, paramAQDequeueOptions, arrayOfByte);
/* 10154 */     if (localAQMessageI != null)
/*       */     {
/* 10156 */       localAQMessageI.setTypeName(paramString2);
/* 10157 */       localAQMessageI.setTypeDescriptor(localTypeDescriptor);
/*       */     }
/* 10159 */     return localAQMessageI;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/* 10177 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10178 */     localSQLException.fillInStackTrace();
/* 10179 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1, byte[][] paramArrayOfByte2, boolean paramBoolean)
/*       */     throws SQLException
/*       */   {
/* 10201 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10202 */     localSQLException.fillInStackTrace();
/* 10203 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   /**
/*       */    * @deprecated
/*       */    */
/*       */   public boolean isV8Compatible()
/*       */     throws SQLException
/*       */   {
/* 10221 */     return this.mapDateToTimestamp;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean getMapDateToTimestamp()
/*       */   {
/* 10234 */     return this.mapDateToTimestamp;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty)
/*       */     throws SQLException
/*       */   {
/* 10242 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10243 */     localSQLException.fillInStackTrace();
/* 10244 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public AQNotificationRegistration[] registerAQNotification(String[] paramArrayOfString, Properties[] paramArrayOfProperties, Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/* 10254 */     String str = readNTFlocalhost(paramProperties);
/* 10255 */     int i = readNTFtcpport(paramProperties);
/*       */     
/* 10257 */     NTFAQRegistration[] arrayOfNTFAQRegistration = doRegisterAQNotification(paramArrayOfString, str, i, paramArrayOfProperties);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10263 */     return (AQNotificationRegistration[])arrayOfNTFAQRegistration;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties)
/*       */     throws SQLException
/*       */   {
/* 10274 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10275 */     localSQLException.fillInStackTrace();
/* 10276 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void unregisterAQNotification(AQNotificationRegistration paramAQNotificationRegistration)
/*       */     throws SQLException
/*       */   {
/* 10286 */     NTFAQRegistration localNTFAQRegistration = (NTFAQRegistration)paramAQNotificationRegistration;
/* 10287 */     doUnregisterAQNotification(localNTFAQRegistration);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration)
/*       */     throws SQLException
/*       */   {
/* 10297 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10298 */     localSQLException.fillInStackTrace();
/* 10299 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */   private String readNTFlocalhost(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/* 10307 */     String str = null;
/*       */     try
/*       */     {
/* 10310 */       str = paramProperties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress());
/*       */ 
/*       */     }
/*       */     catch (UnknownHostException localUnknownHostException)
/*       */     {
/*       */ 
/* 10316 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240);
/*       */       
/* 10318 */       localSQLException.fillInStackTrace();
/* 10319 */       throw localSQLException;
/*       */ 
/*       */ 
/*       */     }
/*       */     catch (SecurityException localSecurityException)
/*       */     {
/*       */ 
/*       */ 
/* 10327 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241);
/*       */       
/* 10329 */       localSQLException.fillInStackTrace();
/* 10330 */       throw localSQLException;
/*       */     }
/*       */     
/* 10333 */     return str;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   private int readNTFtcpport(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/* 10343 */     int i = 0;
/*       */     try
/*       */     {
/* 10346 */       i = Integer.parseInt(paramProperties.getProperty("NTF_LOCAL_TCP_PORT", "0"));
/*       */       
/*       */ 
/*       */ 
/* 10350 */       if (i < 0)
/*       */       {
/* 10352 */         SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242);
/*       */         
/* 10354 */         localSQLException1.fillInStackTrace();
/* 10355 */         throw localSQLException1;
/*       */       }
/*       */       
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException)
/*       */     {
/* 10361 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242);
/*       */       
/* 10363 */       localSQLException2.fillInStackTrace();
/* 10364 */       throw localSQLException2;
/*       */     }
/*       */     
/* 10367 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */   int readNTFtimeout(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/* 10374 */     int i = 0;
/*       */     try
/*       */     {
/* 10377 */       i = Integer.parseInt(paramProperties.getProperty("NTF_TIMEOUT", "0"));
/*       */ 
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException)
/*       */     {
/* 10382 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243);
/*       */       
/* 10384 */       localSQLException.fillInStackTrace();
/* 10385 */       throw localSQLException;
/*       */     }
/*       */     
/* 10388 */     return i;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/* 10397 */     String str = readNTFlocalhost(paramProperties);
/* 10398 */     int i = readNTFtcpport(paramProperties);
/* 10399 */     int j = readNTFtimeout(paramProperties);
/* 10400 */     int k = 0;
/*       */     
/*       */     try
/*       */     {
/* 10404 */       k = Integer.parseInt(paramProperties.getProperty("DCN_NOTIFY_CHANGELAG", "0"));
/*       */     }
/*       */     catch (NumberFormatException localNumberFormatException)
/*       */     {
/* 10408 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244);
/*       */       
/* 10410 */       localSQLException.fillInStackTrace();
/* 10411 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/*       */ 
/*       */ 
/* 10417 */     NTFDCNRegistration localNTFDCNRegistration = doRegisterDatabaseChangeNotification(str, i, paramProperties, j, k);
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/* 10424 */     ntfManager.addRegistration(localNTFDCNRegistration);
/* 10425 */     return localNTFDCNRegistration;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3)
/*       */     throws SQLException
/*       */   {
/* 10534 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10535 */     localSQLException.fillInStackTrace();
/* 10536 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public DatabaseChangeRegistration getDatabaseChangeRegistration(int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10601 */     NTFDCNRegistration localNTFDCNRegistration = new NTFDCNRegistration(this.instanceName, paramInt, this.userName, this.versionNumber);
/* 10602 */     return localNTFDCNRegistration;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration paramDatabaseChangeRegistration)
/*       */     throws SQLException
/*       */   {
/* 10612 */     NTFDCNRegistration localNTFDCNRegistration = (NTFDCNRegistration)paramDatabaseChangeRegistration;
/* 10613 */     if (localNTFDCNRegistration.getDatabaseName().compareToIgnoreCase(this.instanceName) != 0)
/*       */     {
/*       */ 
/*       */ 
/* 10617 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245);
/*       */       
/* 10619 */       localSQLException.fillInStackTrace();
/* 10620 */       throw localSQLException;
/*       */     }
/*       */     
/*       */ 
/* 10624 */     doUnregisterDatabaseChangeNotification(localNTFDCNRegistration);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration)
/*       */     throws SQLException
/*       */   {
/* 10634 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10635 */     localSQLException.fillInStackTrace();
/* 10636 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void unregisterDatabaseChangeNotification(int paramInt)
/*       */     throws SQLException
/*       */   {
/* 10646 */     String str = null;
/*       */     try
/*       */     {
/* 10649 */       str = InetAddress.getLocalHost().getHostAddress();
/*       */     }
/*       */     catch (Exception localException) {}
/*       */     
/*       */ 
/*       */ 
/* 10655 */     unregisterDatabaseChangeNotification(paramInt, str, 47632);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void unregisterDatabaseChangeNotification(int paramInt1, String paramString, int paramInt2)
/*       */     throws SQLException
/*       */   {
/* 10664 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt2 + "))?PR=0";
/*       */     
/* 10666 */     unregisterDatabaseChangeNotification(paramInt1, str);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public void unregisterDatabaseChangeNotification(long paramLong, String paramString)
/*       */     throws SQLException
/*       */   {
/* 10675 */     doUnregisterDatabaseChangeNotification(paramLong, paramString);
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void doUnregisterDatabaseChangeNotification(long paramLong, String paramString)
/*       */     throws SQLException
/*       */   {
/* 10701 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10702 */     localSQLException.fillInStackTrace();
/* 10703 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener)
/*       */     throws SQLException
/*       */   {
/* 10713 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10714 */     localSQLException.fillInStackTrace();
/* 10715 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor)
/*       */     throws SQLException
/*       */   {
/* 10726 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10727 */     localSQLException.fillInStackTrace();
/* 10728 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public void removeXSEventListener(XSEventListener paramXSEventListener)
/*       */     throws SQLException
/*       */   {
/* 10738 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10739 */     localSQLException.fillInStackTrace();
/* 10740 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema()
/*       */     throws SQLException
/*       */   {
/* 10751 */     TypeDescriptor[] arrayOfTypeDescriptor = null;
/* 10752 */     Statement localStatement = null;
/*       */     try
/*       */     {
/* 10755 */       localStatement = createStatement();
/* 10756 */       ResultSet localResultSet = localStatement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())");
/*       */       
/* 10758 */       arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(localResultSet);
/* 10759 */       localResultSet.close();
/*       */     }
/*       */     catch (SQLException localSQLException1)
/*       */     {
/* 10763 */       if (localSQLException1.getErrorCode() == 904)
/*       */       {
/*       */ 
/* 10766 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165);
/* 10767 */         localSQLException2.fillInStackTrace();
/* 10768 */         throw localSQLException2;
/*       */       }
/*       */       
/*       */ 
/*       */ 
/* 10773 */       throw localSQLException1;
/*       */ 
/*       */     }
/*       */     finally
/*       */     {
/* 10778 */       if (localStatement != null) localStatement.close();
/*       */     }
/* 10780 */     return arrayOfTypeDescriptor;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String[] paramArrayOfString)
/*       */     throws SQLException
/*       */   {
/* 10790 */     String str = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))";
/* 10791 */     TypeDescriptor[] arrayOfTypeDescriptor = null;
/* 10792 */     PreparedStatement localPreparedStatement = null;
/*       */     try
/*       */     {
/* 10795 */       localPreparedStatement = prepareStatement(str);
/* 10796 */       int i = paramArrayOfString.length;
/* 10797 */       localObject1 = new StringBuffer(i * 8);
/* 10798 */       for (int j = 0; j < i; j++)
/*       */       {
/* 10800 */         ((StringBuffer)localObject1).append(paramArrayOfString[j]);
/* 10801 */         if (j < i - 1) ((StringBuffer)localObject1).append(',');
/*       */       }
/* 10803 */       localPreparedStatement.setString(1, ((StringBuffer)localObject1).toString());
/* 10804 */       ResultSet localResultSet = localPreparedStatement.executeQuery();
/* 10805 */       arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(localResultSet);
/* 10806 */       localResultSet.close();
/*       */     }
/*       */     catch (SQLException localSQLException) {
/*       */       Object localObject1;
/* 10810 */       if (localSQLException.getErrorCode() == 904)
/*       */       {
/*       */ 
/* 10813 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165);
/* 10814 */         ((SQLException)localObject1).fillInStackTrace();
/* 10815 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*       */ 
/* 10820 */       throw localSQLException;
/*       */ 
/*       */     }
/*       */     finally
/*       */     {
/* 10825 */       if (localPreparedStatement != null) localPreparedStatement.close();
/*       */     }
/* 10827 */     return arrayOfTypeDescriptor;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TypeDescriptor[] getTypeDescriptorsFromList(String[][] paramArrayOfString)
/*       */     throws SQLException
/*       */   {
/* 10838 */     TypeDescriptor[] arrayOfTypeDescriptor = null;
/* 10839 */     PreparedStatement localPreparedStatement = null;
/* 10840 */     int i = paramArrayOfString.length;
/* 10841 */     StringBuffer localStringBuffer1 = new StringBuffer(i * 8);
/* 10842 */     StringBuffer localStringBuffer2 = new StringBuffer(i * 8);
/* 10843 */     for (int j = 0; j < i; j++)
/*       */     {
/* 10845 */       localStringBuffer1.append(paramArrayOfString[j][0]);
/* 10846 */       localStringBuffer2.append(paramArrayOfString[j][1]);
/* 10847 */       if (j < i - 1)
/*       */       {
/* 10849 */         localStringBuffer1.append(',');
/* 10850 */         localStringBuffer2.append(',');
/*       */       }
/*       */     }
/*       */     
/*       */     try
/*       */     {
/* 10856 */       String str = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))";
/*       */       
/* 10858 */       localPreparedStatement = prepareStatement(str);
/* 10859 */       localPreparedStatement.setString(1, localStringBuffer1.toString());
/* 10860 */       localPreparedStatement.setString(2, localStringBuffer2.toString());
/*       */       
/* 10862 */       localObject1 = localPreparedStatement.executeQuery();
/* 10863 */       arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet((ResultSet)localObject1);
/* 10864 */       ((ResultSet)localObject1).close();
/*       */     }
/*       */     catch (SQLException localSQLException) {
/*       */       Object localObject1;
/* 10868 */       if (localSQLException.getErrorCode() == 904)
/*       */       {
/*       */ 
/* 10871 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165);
/* 10872 */         ((SQLException)localObject1).fillInStackTrace();
/* 10873 */         throw ((Throwable)localObject1);
/*       */       }
/*       */       
/*       */ 
/*       */ 
/* 10878 */       throw localSQLException;
/*       */ 
/*       */     }
/*       */     finally
/*       */     {
/* 10883 */       if (localPreparedStatement != null) localPreparedStatement.close();
/*       */     }
/* 10885 */     return arrayOfTypeDescriptor;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet paramResultSet)
/*       */     throws SQLException
/*       */   {
/* 10906 */     ArrayList localArrayList = new ArrayList();
/* 10907 */     Object localObject2; while (paramResultSet.next())
/*       */     {
/* 10909 */       localObject1 = paramResultSet.getString(1);
/* 10910 */       String str1 = paramResultSet.getString(2);
/* 10911 */       localObject2 = paramResultSet.getBytes(3);
/* 10912 */       String str2 = paramResultSet.getString(4);
/* 10913 */       int j = paramResultSet.getInt(5);
/* 10914 */       byte[] arrayOfByte = paramResultSet.getBytes(6);
/* 10915 */       SQLName localSQLName = new SQLName((String)localObject1, str1, this);
/* 10916 */       Object localObject3; if (str2.equals("OBJECT"))
/*       */       {
/* 10918 */         localObject3 = StructDescriptor.createDescriptor(localSQLName, (byte[])localObject2, j, arrayOfByte, this);
/*       */         
/*       */ 
/*       */ 
/* 10922 */         putDescriptor((byte[])localObject2, localObject3);
/* 10923 */         putDescriptor(((TypeDescriptor)localObject3).getName(), localObject3);
/* 10924 */         localArrayList.add(localObject3);
/*       */       }
/* 10926 */       else if (str2.equals("COLLECTION"))
/*       */       {
/* 10928 */         localObject3 = ArrayDescriptor.createDescriptor(localSQLName, (byte[])localObject2, j, arrayOfByte, this);
/*       */         
/*       */ 
/*       */ 
/* 10932 */         putDescriptor((byte[])localObject2, localObject3);
/* 10933 */         putDescriptor(((TypeDescriptor)localObject3).getName(), localObject3);
/* 10934 */         localArrayList.add(localObject3);
/*       */       }
/*       */     }
/* 10937 */     Object localObject1 = new TypeDescriptor[localArrayList.size()];
/* 10938 */     for (int i = 0; i < localArrayList.size(); i++)
/*       */     {
/* 10940 */       localObject2 = (TypeDescriptor)localArrayList.get(i);
/* 10941 */       localObject1[i] = localObject2;
/*       */     }
/* 10943 */     return (TypeDescriptor[])localObject1;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized boolean isUsable()
/*       */   {
/* 10955 */     return this.isUsable;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public synchronized void setUsable(boolean paramBoolean)
/*       */   {
/* 10970 */     this.isUsable = paramBoolean;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   void queryFCFProperties(Properties paramProperties)
/*       */     throws SQLException
/*       */   {
/* 10988 */     Statement localStatement = null;
/* 10989 */     ResultSet localResultSet = null;
/* 10990 */     String str1 = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual";
/*       */     
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     try
/*       */     {
/* 10998 */       localStatement = createStatement();
/* 10999 */       localStatement.setFetchSize(1);
/* 11000 */       localResultSet = localStatement.executeQuery(str1);
/* 11001 */       while (localResultSet.next())
/*       */       {
/* 11003 */         String str2 = null;
/* 11004 */         str2 = localResultSet.getString(1);
/* 11005 */         if (str2 != null) {
/* 11006 */           paramProperties.put("INSTANCE_NAME", str2.trim());
/*       */         }
/* 11008 */         str2 = localResultSet.getString(2);
/* 11009 */         if (str2 != null) {
/* 11010 */           paramProperties.put("SERVER_HOST", str2.trim());
/*       */         }
/*       */         
/*       */ 
/* 11014 */         str2 = localResultSet.getString(3);
/* 11015 */         if (str2 != null) {
/* 11016 */           paramProperties.put("SERVICE_NAME", str2.trim());
/*       */         }
/* 11018 */         str2 = localResultSet.getString(4);
/* 11019 */         if (str2 != null) {
/* 11020 */           paramProperties.put("DATABASE_NAME", str2.trim());
/*       */         }
/*       */       }
/*       */     } finally {
/* 11024 */       if (localResultSet != null)
/* 11025 */         localResultSet.close();
/* 11026 */       if (localStatement != null) {
/* 11027 */         localStatement.close();
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*       */   public void setDefaultTimeZone(TimeZone paramTimeZone)
/*       */     throws SQLException
/*       */   {
/* 11035 */     this.defaultTimeZone = paramTimeZone;
/*       */   }
/*       */   
/*       */ 
/*       */   public TimeZone getDefaultTimeZone()
/*       */     throws SQLException
/*       */   {
/* 11042 */     return this.defaultTimeZone;
/*       */   }
/*       */   
/*       */ 
/* 11046 */   int timeZoneVersionNumber = -1;
/* 11047 */   TIMEZONETAB timeZoneTab = null;
/*       */   
/*       */   public int getTimezoneVersionNumber() throws SQLException
/*       */   {
/* 11051 */     return this.timeZoneVersionNumber;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public TIMEZONETAB getTIMEZONETAB()
/*       */     throws SQLException
/*       */   {
/* 11061 */     if (this.timeZoneTab == null) {
/* 11062 */       this.timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());
/*       */     }
/* 11064 */     return this.timeZoneTab;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean isDataInLocatorEnabled()
/*       */     throws SQLException
/*       */   {
/* 11078 */     return (getVersionNumber() >= 10200 ? 1 : 0) & (getVersionNumber() < 11000 ? 1 : 0) & this.enableReadDataInLocator | this.overrideEnableReadDataInLocator;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/*       */ 
/*       */   public boolean isLobStreamPosStandardCompliant()
/*       */     throws SQLException
/*       */   {
/* 11087 */     return this.lobStreamPosStandardCompliant;
/*       */   }
/*       */   
/*       */ 
/*       */   public long getCurrentSCN()
/*       */     throws SQLException
/*       */   {
/* 11094 */     return doGetCurrentSCN();
/*       */   }
/*       */   
/*       */   long doGetCurrentSCN()
/*       */     throws SQLException
/*       */   {
/* 11100 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11101 */     localSQLException.fillInStackTrace();
/* 11102 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */   void doSetSnapshotSCN(long paramLong)
/*       */     throws SQLException
/*       */   {
/* 11109 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11110 */     localSQLException.fillInStackTrace();
/* 11111 */     throw localSQLException;
/*       */   }
/*       */   
/*       */   public EnumSet<OracleConnection.TransactionState> getTransactionState()
/*       */     throws SQLException
/*       */   {
/* 11117 */     return doGetTransactionState();
/*       */   }
/*       */   
/*       */   EnumSet<OracleConnection.TransactionState> doGetTransactionState()
/*       */     throws SQLException
/*       */   {
/* 11123 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11124 */     localSQLException.fillInStackTrace();
/* 11125 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */   public boolean isConnectionSocketKeepAlive()
/*       */     throws java.net.SocketException, SQLException
/*       */   {
/* 11132 */     SQLException localSQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11133 */     localSQLException.fillInStackTrace();
/* 11134 */     throw localSQLException;
/*       */   }
/*       */   
/*       */ 
/*       */ 
/* 11139 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*       */   public static final boolean TRACE = false;
/*       */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\PhysicalConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */