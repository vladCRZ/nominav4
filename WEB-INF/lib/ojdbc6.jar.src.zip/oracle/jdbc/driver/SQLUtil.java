/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.OracleNamedType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*      */ import oracle.jdbc.oracore.OracleTypeOPAQUE;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.OpaqueDescriptor;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLUtil
/*      */ {
/*      */   public static Object SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, Class paramClass, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*   87 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*   88 */     Object localObject = SQLToJava(paramOracleConnection, localDatum, paramClass, paramMap);
/*      */     
/*   90 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static CustomDatum SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/*  128 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*  129 */     CustomDatum localCustomDatum = paramCustomDatumFactory.create(localDatum, paramInt);
/*      */     
/*  131 */     return localCustomDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ORAData SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt, String paramString, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/*  169 */     Datum localDatum = makeDatum(paramOracleConnection, paramArrayOfByte, paramInt, paramString, 0);
/*  170 */     ORAData localORAData = paramORADataFactory.create(localDatum, paramInt);
/*      */     
/*  172 */     return localORAData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object SQLToJava(OracleConnection paramOracleConnection, Datum paramDatum, Class paramClass, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  212 */     Object localObject = null;
/*      */     
/*  214 */     if ((paramDatum instanceof STRUCT))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */       if (paramClass == null)
/*      */       {
/*  222 */         localObject = paramMap != null ? ((STRUCT)paramDatum).toJdbc(paramMap) : paramDatum.toJdbc();
/*      */       }
/*      */       else
/*      */       {
/*  226 */         localObject = paramMap != null ? ((STRUCT)paramDatum).toClass(paramClass, paramMap) : ((STRUCT)paramDatum).toClass(paramClass);
/*      */       }
/*      */       
/*      */     }
/*  230 */     else if (paramClass == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  236 */       localObject = paramDatum.toJdbc();
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  244 */       int i = classNumber(paramClass);
/*      */       
/*  246 */       switch (i)
/*      */       {
/*      */ 
/*      */       case 0: 
/*  250 */         localObject = paramDatum.stringValue();
/*      */         
/*  252 */         break;
/*      */       
/*      */       case 1: 
/*  255 */         localObject = Boolean.valueOf(paramDatum.longValue() != 0L);
/*      */         
/*  257 */         break;
/*      */       
/*      */       case 2: 
/*  260 */         localObject = Integer.valueOf((int)paramDatum.longValue());
/*      */         
/*  262 */         break;
/*      */       
/*      */       case 3: 
/*  265 */         localObject = Long.valueOf(paramDatum.longValue());
/*      */         
/*  267 */         break;
/*      */       
/*      */       case 4: 
/*  270 */         localObject = Float.valueOf(paramDatum.bigDecimalValue().floatValue());
/*      */         
/*  272 */         break;
/*      */       
/*      */       case 5: 
/*  275 */         localObject = Double.valueOf(paramDatum.bigDecimalValue().doubleValue());
/*      */         
/*  277 */         break;
/*      */       
/*      */       case 6: 
/*  280 */         localObject = paramDatum.bigDecimalValue();
/*      */         
/*  282 */         break;
/*      */       
/*      */       case 7: 
/*  285 */         localObject = paramDatum.dateValue();
/*      */         
/*  287 */         break;
/*      */       
/*      */       case 8: 
/*  290 */         localObject = paramDatum.timeValue();
/*      */         
/*  292 */         break;
/*      */       
/*      */       case 9: 
/*  295 */         localObject = paramDatum.timestampValue();
/*      */         
/*  297 */         break;
/*      */       
/*      */ 
/*      */       case -1: 
/*      */       default: 
/*  302 */         localObject = paramDatum.toJdbc();
/*      */         
/*  304 */         if (!paramClass.isInstance(localObject))
/*      */         {
/*      */ 
/*      */ 
/*  308 */           SQLException localSQLException = DatabaseError.createSqlException(null, 59, "invalid data conversion");
/*  309 */           localSQLException.fillInStackTrace();
/*  310 */           throw localSQLException;
/*      */         }
/*      */         
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*  318 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] JavaToSQL(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/*  356 */     if (paramObject == null)
/*      */     {
/*      */ 
/*  359 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  367 */     Object localObject = null;
/*      */     
/*  369 */     if ((paramObject instanceof Datum))
/*      */     {
/*  371 */       localObject = (Datum)paramObject;
/*      */     }
/*  373 */     else if ((paramObject instanceof ORAData))
/*      */     {
/*  375 */       localObject = ((ORAData)paramObject).toDatum(paramOracleConnection);
/*      */     }
/*  377 */     else if ((paramObject instanceof CustomDatum))
/*      */     {
/*  379 */       localObject = paramOracleConnection.toDatum((CustomDatum)paramObject);
/*      */     }
/*  381 */     else if ((paramObject instanceof SQLData))
/*      */     {
/*  383 */       localObject = STRUCT.toSTRUCT(paramObject, paramOracleConnection);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  390 */     if (localObject != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  400 */       if (!checkDatumType((Datum)localObject, paramInt, paramString))
/*      */       {
/*  402 */         localObject = null;
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  415 */       localObject = makeDatum(paramOracleConnection, paramObject, paramInt, paramString);
/*      */     }
/*      */     
/*  418 */     byte[] arrayOfByte = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  423 */     if (localObject != null)
/*      */     {
/*  425 */       if ((localObject instanceof STRUCT)) {
/*  426 */         arrayOfByte = ((STRUCT)localObject).toBytes();
/*  427 */       } else if ((localObject instanceof ARRAY)) {
/*  428 */         arrayOfByte = ((ARRAY)localObject).toBytes();
/*  429 */       } else if ((localObject instanceof OPAQUE)) {
/*  430 */         arrayOfByte = ((OPAQUE)localObject).toBytes();
/*      */       } else {
/*  432 */         arrayOfByte = ((Datum)localObject).shareBytes();
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  438 */       SQLException localSQLException = DatabaseError.createSqlException(null, 1, "attempt to convert a Datum to incompatible SQL type");
/*  439 */       localSQLException.fillInStackTrace();
/*  440 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  444 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt1, String paramString, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  486 */     Object localObject1 = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  501 */     int i = paramOracleConnection.getDbCsId();
/*  502 */     int j = paramOracleConnection.getJdbcCsId();
/*  503 */     int k = CharacterSetMetaData.getRatio(j, i);
/*      */     Object localObject2;
/*  505 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 96: 
/*  514 */       if ((paramInt2 != 0) && (paramInt2 < paramArrayOfByte.length) && (k == 1))
/*      */       {
/*  516 */         localObject1 = new CHAR(paramArrayOfByte, 0, paramInt2, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  521 */         localObject1 = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */       }
/*      */       
/*  524 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*  531 */       localObject1 = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */       
/*      */ 
/*  534 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/*  539 */       localObject1 = new NUMBER(paramArrayOfByte);
/*      */       
/*  541 */       break;
/*      */     
/*      */     case 100: 
/*  544 */       localObject1 = new BINARY_FLOAT(paramArrayOfByte);
/*      */       
/*  546 */       break;
/*      */     
/*      */     case 101: 
/*  549 */       localObject1 = new BINARY_DOUBLE(paramArrayOfByte);
/*      */       
/*  551 */       break;
/*      */     
/*      */ 
/*      */     case 23: 
/*      */     case 24: 
/*  556 */       localObject1 = new RAW(paramArrayOfByte);
/*      */       
/*  558 */       break;
/*      */     
/*      */     case 104: 
/*  561 */       localObject1 = new ROWID(paramArrayOfByte);
/*      */       
/*  563 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 102: 
/*  571 */       localObject2 = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet?");
/*  572 */       ((SQLException)localObject2).fillInStackTrace();
/*  573 */       throw ((Throwable)localObject2);
/*      */     
/*      */ 
/*      */     case 12: 
/*  577 */       localObject1 = new DATE(paramArrayOfByte);
/*      */       
/*  579 */       break;
/*      */     
/*      */     case 182: 
/*  582 */       localObject1 = new INTERVALYM(paramArrayOfByte);
/*      */       
/*  584 */       break;
/*      */     
/*      */     case 183: 
/*  587 */       localObject1 = new INTERVALDS(paramArrayOfByte);
/*      */       
/*  589 */       break;
/*      */     
/*      */     case 180: 
/*  592 */       localObject1 = new TIMESTAMP(paramArrayOfByte);
/*      */       
/*  594 */       break;
/*      */     
/*      */     case 181: 
/*  597 */       localObject1 = new TIMESTAMPTZ(paramArrayOfByte);
/*      */       
/*  599 */       break;
/*      */     
/*      */     case 231: 
/*  602 */       localObject1 = new TIMESTAMPLTZ(paramArrayOfByte);
/*      */       
/*  604 */       break;
/*      */     
/*      */     case 113: 
/*  607 */       localObject1 = paramOracleConnection.createBlob(paramArrayOfByte);
/*      */       
/*  609 */       break;
/*      */     
/*      */     case 112: 
/*  612 */       localObject1 = paramOracleConnection.createClob(paramArrayOfByte);
/*      */       
/*  614 */       break;
/*      */     
/*      */     case 114: 
/*  617 */       localObject1 = paramOracleConnection.createBfile(paramArrayOfByte);
/*      */       
/*  619 */       break;
/*      */     
/*      */ 
/*      */     case 109: 
/*  623 */       localObject2 = TypeDescriptor.getTypeDescriptor(paramString, paramOracleConnection, paramArrayOfByte, 0L);
/*      */       
/*      */ 
/*  626 */       switch (((TypeDescriptor)localObject2).getTypeCode())
/*      */       {
/*      */       case 2002: 
/*  629 */         localObject1 = new STRUCT((StructDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */         
/*  631 */         break;
/*      */       
/*      */       case 2003: 
/*  634 */         localObject1 = new ARRAY((ArrayDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */         
/*  636 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2009: 
/*  642 */         localObject1 = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)localObject2, paramArrayOfByte, paramOracleConnection));
/*      */         
/*  644 */         break;
/*      */       
/*      */ 
/*      */       case 2007: 
/*  648 */         localObject1 = new OPAQUE((OpaqueDescriptor)localObject2, paramArrayOfByte, paramOracleConnection);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*  654 */       break;
/*      */     
/*      */ 
/*      */     case 111: 
/*  658 */       localObject2 = getTypeDescriptor(paramString, paramOracleConnection);
/*      */       
/*  660 */       if ((localObject2 instanceof StructDescriptor))
/*      */       {
/*  662 */         localObject1 = new REF((StructDescriptor)localObject2, paramOracleConnection, paramArrayOfByte);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  668 */         SQLException localSQLException = DatabaseError.createSqlException(null, 1, "program error: REF points to a non-STRUCT");
/*  669 */         localSQLException.fillInStackTrace();
/*  670 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  675 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/*  680 */       localObject2 = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
/*  681 */       ((SQLException)localObject2).fillInStackTrace();
/*  682 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  687 */     return (Datum)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeNDatum(OracleConnection paramOracleConnection, byte[] paramArrayOfByte, int paramInt1, String paramString, short paramShort, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  703 */     Object localObject = null;
/*      */     
/*  705 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 96: 
/*  713 */       int i = paramInt2 * CharacterSetMetaData.getRatio(paramOracleConnection.getNCharSet(), 1);
/*      */       
/*      */ 
/*      */ 
/*  717 */       if ((paramInt2 != 0) && (i < paramArrayOfByte.length)) {
/*  718 */         localObject = new CHAR(paramArrayOfByte, 0, paramInt2, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */       }
/*      */       else {
/*  721 */         localObject = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */       }
/*      */       
/*  724 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*  731 */       localObject = new CHAR(paramArrayOfByte, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */       
/*      */ 
/*  734 */       break;
/*      */     
/*      */     case 112: 
/*  737 */       localObject = paramOracleConnection.createClob(paramArrayOfByte, paramShort);
/*      */       
/*  739 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/*  744 */       SQLException localSQLException = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
/*  745 */       localSQLException.fillInStackTrace();
/*  746 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  751 */     return (Datum)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/*  785 */     return makeDatum(paramOracleConnection, paramObject, paramInt, paramString, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  799 */     Object localObject1 = null;
/*      */     Object localObject2;
/*  801 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*      */     case 96: 
/*  811 */       localObject1 = new CHAR(paramObject, CharacterSet.make(paramBoolean ? paramOracleConnection.getNCharSet() : paramOracleConnection.getJdbcCsId()));
/*      */       
/*      */ 
/*  814 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/*  819 */       localObject1 = new NUMBER(paramObject);
/*      */       
/*  821 */       break;
/*      */     
/*      */     case 100: 
/*  824 */       if ((paramObject instanceof String)) {
/*  825 */         localObject1 = new BINARY_FLOAT((String)paramObject);
/*  826 */       } else if ((paramObject instanceof Boolean)) {
/*  827 */         localObject1 = new BINARY_FLOAT((Boolean)paramObject);
/*      */       } else {
/*  829 */         localObject1 = new BINARY_FLOAT((Float)paramObject);
/*      */       }
/*  831 */       break;
/*      */     
/*      */     case 101: 
/*  834 */       if ((paramObject instanceof String)) {
/*  835 */         localObject1 = new BINARY_DOUBLE((String)paramObject);
/*  836 */       } else if ((paramObject instanceof Boolean)) {
/*  837 */         localObject1 = new BINARY_DOUBLE((Boolean)paramObject);
/*      */       } else {
/*  839 */         localObject1 = new BINARY_DOUBLE((Double)paramObject);
/*      */       }
/*  841 */       break;
/*      */     
/*      */ 
/*      */     case 23: 
/*      */     case 24: 
/*  846 */       localObject1 = new RAW(paramObject);
/*      */       
/*  848 */       break;
/*      */     
/*      */     case 104: 
/*  851 */       if ((paramObject instanceof String)) {
/*  852 */         localObject1 = new ROWID((String)paramObject);
/*  853 */       } else if ((paramObject instanceof byte[])) {
/*  854 */         localObject1 = new ROWID((byte[])paramObject);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 102: 
/*  864 */       localObject2 = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet");
/*  865 */       ((SQLException)localObject2).fillInStackTrace();
/*  866 */       throw ((Throwable)localObject2);
/*      */     
/*      */ 
/*      */     case 12: 
/*  870 */       localObject1 = new DATE(paramObject);
/*      */       
/*  872 */       break;
/*      */     
/*      */     case 180: 
/*  875 */       if ((paramObject instanceof TIMESTAMP))
/*      */       {
/*  877 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  879 */       else if ((paramObject instanceof Timestamp)) {
/*  880 */         localObject1 = new TIMESTAMP((Timestamp)paramObject);
/*  881 */       } else if ((paramObject instanceof Date)) {
/*  882 */         localObject1 = new TIMESTAMP((Date)paramObject);
/*  883 */       } else if ((paramObject instanceof Time)) {
/*  884 */         localObject1 = new TIMESTAMP((Time)paramObject);
/*  885 */       } else if ((paramObject instanceof DATE)) {
/*  886 */         localObject1 = new TIMESTAMP((DATE)paramObject);
/*  887 */       } else if ((paramObject instanceof String)) {
/*  888 */         localObject1 = new TIMESTAMP((String)paramObject);
/*  889 */       } else if ((paramObject instanceof byte[])) {
/*  890 */         localObject1 = new TIMESTAMP((byte[])paramObject);
/*      */       }
/*      */       
/*      */       break;
/*      */     case 181: 
/*  895 */       if ((paramObject instanceof TIMESTAMPTZ))
/*      */       {
/*  897 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  899 */       else if ((paramObject instanceof Timestamp)) {
/*  900 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (Timestamp)paramObject);
/*  901 */       } else if ((paramObject instanceof Date)) {
/*  902 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (Date)paramObject);
/*  903 */       } else if ((paramObject instanceof Time)) {
/*  904 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (Time)paramObject);
/*  905 */       } else if ((paramObject instanceof DATE)) {
/*  906 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (DATE)paramObject);
/*  907 */       } else if ((paramObject instanceof String)) {
/*  908 */         localObject1 = new TIMESTAMPTZ(paramOracleConnection, (String)paramObject);
/*  909 */       } else if ((paramObject instanceof byte[])) {
/*  910 */         localObject1 = new TIMESTAMPTZ((byte[])paramObject);
/*      */       }
/*      */       
/*      */       break;
/*      */     case 231: 
/*  915 */       if ((paramObject instanceof TIMESTAMPLTZ))
/*      */       {
/*  917 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  919 */       else if ((paramObject instanceof Timestamp)) {
/*  920 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (Timestamp)paramObject);
/*  921 */       } else if ((paramObject instanceof Date)) {
/*  922 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (Date)paramObject);
/*  923 */       } else if ((paramObject instanceof Time)) {
/*  924 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (Time)paramObject);
/*  925 */       } else if ((paramObject instanceof DATE)) {
/*  926 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (DATE)paramObject);
/*  927 */       } else if ((paramObject instanceof String)) {
/*  928 */         localObject1 = new TIMESTAMPLTZ(paramOracleConnection, (String)paramObject);
/*  929 */       } else if ((paramObject instanceof byte[])) {
/*  930 */         localObject1 = new TIMESTAMPLTZ((byte[])paramObject);
/*      */       }
/*      */       
/*      */       break;
/*      */     case 113: 
/*  935 */       if ((paramObject instanceof BLOB))
/*      */       {
/*  937 */         localObject1 = (Datum)paramObject;
/*      */       }
/*  939 */       if ((paramObject instanceof byte[]))
/*      */       {
/*  941 */         localObject1 = new RAW((byte[])paramObject);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 112: 
/*  947 */       if ((paramObject instanceof CLOB))
/*      */       {
/*  949 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*  952 */       if ((paramObject instanceof String))
/*      */       {
/*  954 */         localObject2 = CharacterSet.make(paramBoolean ? paramOracleConnection.getNCharSet() : paramOracleConnection.getJdbcCsId());
/*  955 */         localObject1 = new CHAR((String)paramObject, (CharacterSet)localObject2); }
/*  956 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 114: 
/*  961 */       if ((paramObject instanceof BFILE))
/*      */       {
/*  963 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 109: 
/*  969 */       if (((paramObject instanceof STRUCT)) || ((paramObject instanceof ARRAY)) || ((paramObject instanceof OPAQUE)))
/*      */       {
/*      */ 
/*  972 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 111: 
/*  978 */       if ((paramObject instanceof REF))
/*      */       {
/*  980 */         localObject1 = (Datum)paramObject;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  989 */     if (localObject1 == null)
/*      */     {
/*      */ 
/*      */ 
/*  993 */       localObject2 = DatabaseError.createSqlException(null, 1, "Unable to construct a Datum from the specified input");
/*  994 */       ((SQLException)localObject2).fillInStackTrace();
/*  995 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/*      */ 
/*  999 */     return (Datum)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int classNumber(Class paramClass)
/*      */   {
/* 1016 */     int i = -1;
/* 1017 */     Integer localInteger = (Integer)classTable.get(paramClass);
/*      */     
/* 1019 */     if (localInteger != null)
/*      */     {
/* 1021 */       i = localInteger.intValue();
/*      */     }
/*      */     
/* 1024 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object getTypeDescriptor(String paramString, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/* 1058 */     Object localObject = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1063 */     SQLName localSQLName = new SQLName(paramString, paramOracleConnection);
/* 1064 */     String str = localSQLName.getName();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1069 */     localObject = paramOracleConnection.getDescriptor(str);
/*      */     
/* 1071 */     if (localObject != null)
/*      */     {
/*      */ 
/* 1074 */       return localObject;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1080 */     OracleTypeADT localOracleTypeADT = new OracleTypeADT(str, paramOracleConnection);
/* 1081 */     localOracleTypeADT.init(paramOracleConnection);
/*      */     
/* 1083 */     OracleNamedType localOracleNamedType = localOracleTypeADT.cleanup();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1088 */     switch (localOracleNamedType.getTypeCode())
/*      */     {
/*      */ 
/*      */ 
/*      */     case 2003: 
/* 1093 */       localObject = new ArrayDescriptor(localSQLName, (OracleTypeCOLLECTION)localOracleNamedType, paramOracleConnection);
/*      */       
/*      */ 
/*      */ 
/* 1097 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2002: 
/*      */     case 2008: 
/* 1103 */       localObject = new StructDescriptor(localSQLName, (OracleTypeADT)localOracleNamedType, paramOracleConnection);
/*      */       
/*      */ 
/*      */ 
/* 1107 */       break;
/*      */     
/*      */ 
/*      */     case 2007: 
/* 1111 */       localObject = new OpaqueDescriptor(localSQLName, (OracleTypeOPAQUE)localOracleNamedType, paramOracleConnection);
/*      */       
/*      */ 
/*      */ 
/* 1115 */       break;
/*      */     case 2004: 
/*      */     case 2005: 
/*      */     case 2006: 
/*      */     default: 
/* 1120 */       SQLException localSQLException = DatabaseError.createSqlException(null, 1, "Unrecognized type code");
/* 1121 */       localSQLException.fillInStackTrace();
/* 1122 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1129 */     paramOracleConnection.putDescriptor(str, localObject);
/*      */     
/* 1131 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean checkDatumType(Datum paramDatum, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1161 */     boolean bool = false;
/*      */     
/* 1163 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*      */     case 8: 
/*      */     case 96: 
/* 1171 */       bool = paramDatum instanceof CHAR;
/*      */       
/* 1173 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 6: 
/* 1178 */       bool = paramDatum instanceof NUMBER;
/*      */       
/* 1180 */       break;
/*      */     
/*      */     case 100: 
/* 1183 */       bool = paramDatum instanceof BINARY_FLOAT;
/*      */       
/* 1185 */       break;
/*      */     
/*      */     case 101: 
/* 1188 */       bool = paramDatum instanceof BINARY_DOUBLE;
/*      */       
/* 1190 */       break;
/*      */     
/*      */ 
/*      */     case 23: 
/*      */     case 24: 
/* 1195 */       bool = paramDatum instanceof RAW;
/*      */       
/* 1197 */       break;
/*      */     
/*      */     case 104: 
/* 1200 */       bool = paramDatum instanceof ROWID;
/*      */       
/* 1202 */       break;
/*      */     
/*      */     case 12: 
/* 1205 */       bool = paramDatum instanceof DATE;
/*      */       
/* 1207 */       break;
/*      */     
/*      */     case 180: 
/* 1210 */       bool = paramDatum instanceof TIMESTAMP;
/*      */       
/* 1212 */       break;
/*      */     
/*      */     case 181: 
/* 1215 */       bool = paramDatum instanceof TIMESTAMPTZ;
/*      */       
/* 1217 */       break;
/*      */     
/*      */     case 231: 
/* 1220 */       bool = paramDatum instanceof TIMESTAMPLTZ;
/*      */       
/* 1222 */       break;
/*      */     
/*      */     case 113: 
/* 1225 */       bool = paramDatum instanceof BLOB;
/*      */       
/* 1227 */       break;
/*      */     
/*      */     case 112: 
/* 1230 */       bool = paramDatum instanceof CLOB;
/*      */       
/* 1232 */       break;
/*      */     
/*      */     case 114: 
/* 1235 */       bool = paramDatum instanceof BFILE;
/*      */       
/* 1237 */       break;
/*      */     
/*      */     case 111: 
/* 1240 */       bool = ((paramDatum instanceof REF)) && (((REF)paramDatum).getBaseTypeName().equals(paramString));
/*      */       
/*      */ 
/* 1243 */       break;
/*      */     
/*      */     case 109: 
/* 1246 */       if ((paramDatum instanceof STRUCT))
/*      */       {
/* 1248 */         bool = ((STRUCT)paramDatum).isInHierarchyOf(paramString);
/*      */       }
/* 1250 */       else if ((paramDatum instanceof ARRAY))
/*      */       {
/* 1252 */         bool = ((ARRAY)paramDatum).getSQLTypeName().equals(paramString);
/*      */       }
/* 1254 */       else if ((paramDatum instanceof OPAQUE))
/*      */       {
/* 1256 */         bool = ((OPAQUE)paramDatum).getSQLTypeName().equals(paramString);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 102: 
/*      */     default: 
/* 1264 */       bool = false;
/*      */     }
/*      */     
/* 1267 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean implementsInterface(Class paramClass1, Class paramClass2)
/*      */   {
/* 1287 */     if (paramClass1 == null)
/*      */     {
/* 1289 */       return false;
/*      */     }
/*      */     
/* 1292 */     if (paramClass1 == paramClass2)
/*      */     {
/* 1294 */       return true;
/*      */     }
/*      */     
/* 1297 */     Class[] arrayOfClass = paramClass1.getInterfaces();
/*      */     
/* 1299 */     for (int i = 0; i < arrayOfClass.length; i++)
/*      */     {
/* 1301 */       if (implementsInterface(arrayOfClass[i], paramClass2))
/*      */       {
/* 1303 */         return true;
/*      */       }
/*      */     }
/*      */     
/* 1307 */     return implementsInterface(paramClass1.getSuperclass(), paramClass2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeOracleDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 1338 */     return makeOracleDatum(paramOracleConnection, paramObject, paramInt, paramString, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Datum makeOracleDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1353 */     Datum localDatum = makeDatum(paramOracleConnection, paramObject, getInternalType(paramInt), paramString, paramBoolean);
/*      */     
/*      */ 
/* 1356 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static int getInternalType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1364 */     int i = 0;
/*      */     
/* 1366 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 1388 */       i = 6;
/*      */       
/* 1390 */       break;
/*      */     
/*      */     case 100: 
/* 1393 */       i = 100;
/*      */       
/* 1395 */       break;
/*      */     
/*      */     case 101: 
/* 1398 */       i = 101;
/*      */       
/* 1400 */       break;
/*      */     
/*      */     case 999: 
/* 1403 */       i = 999;
/*      */       
/* 1405 */       break;
/*      */     
/*      */     case 1: 
/* 1408 */       i = 96;
/*      */       
/* 1410 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case -15: 
/* 1416 */       i = 96;
/* 1417 */       break;
/*      */     
/*      */ 
/*      */     case 12: 
/* 1421 */       i = 1;
/*      */       
/* 1423 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case -9: 
/* 1429 */       i = 1;
/* 1430 */       break;
/*      */     
/*      */ 
/*      */     case -1: 
/* 1434 */       i = 8;
/*      */       
/* 1436 */       break;
/*      */     
/*      */ 
/*      */     case 91: 
/*      */     case 92: 
/* 1441 */       i = 12;
/*      */       
/* 1443 */       break;
/*      */     
/*      */ 
/*      */     case -100: 
/*      */     case 93: 
/* 1448 */       i = 180;
/*      */       
/* 1450 */       break;
/*      */     
/*      */     case -101: 
/* 1453 */       i = 181;
/*      */       
/* 1455 */       break;
/*      */     
/*      */     case -102: 
/* 1458 */       i = 231;
/*      */       
/* 1460 */       break;
/*      */     
/*      */     case -104: 
/* 1463 */       i = 183;
/*      */       
/* 1465 */       break;
/*      */     
/*      */     case -103: 
/* 1468 */       i = 182;
/*      */       
/* 1470 */       break;
/*      */     
/*      */ 
/*      */     case -3: 
/*      */     case -2: 
/* 1475 */       i = 23;
/*      */       
/* 1477 */       break;
/*      */     
/*      */     case -4: 
/* 1480 */       i = 24;
/*      */       
/* 1482 */       break;
/*      */     
/*      */     case -8: 
/* 1485 */       i = 104;
/*      */       
/* 1487 */       break;
/*      */     
/*      */     case 2004: 
/* 1490 */       i = 113;
/*      */       
/* 1492 */       break;
/*      */     
/*      */     case 2005: 
/* 1495 */       i = 112;
/*      */       
/* 1497 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2011: 
/* 1503 */       i = 112;
/*      */       
/* 1505 */       break;
/*      */     
/*      */     case -13: 
/* 1508 */       i = 114;
/*      */       
/* 1510 */       break;
/*      */     
/*      */     case -10: 
/* 1513 */       i = 102;
/*      */       
/* 1515 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2002: 
/*      */     case 2003: 
/*      */     case 2007: 
/*      */     case 2008: 
/* 1524 */       i = 109;
/*      */       
/* 1526 */       break;
/*      */     
/*      */     case 2006: 
/* 1529 */       i = 111;
/*      */       
/* 1531 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 1536 */       SQLException localSQLException = DatabaseError.createSqlException(null, 4, "get_internal_type");
/* 1537 */       localSQLException.fillInStackTrace();
/* 1538 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/* 1542 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 1557 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1737 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   private static final int CLASS_NOT_FOUND = -1;
/*      */   
/*      */   private static final int CLASS_STRING = 0;
/*      */   
/*      */   private static final int CLASS_BOOLEAN = 1;
/*      */   
/*      */   private static final int CLASS_INTEGER = 2;
/*      */   
/*      */   private static final int CLASS_LONG = 3;
/*      */   
/*      */   private static final int CLASS_FLOAT = 4;
/*      */   private static final int CLASS_DOUBLE = 5;
/*      */   private static final int CLASS_BIGDECIMAL = 6;
/*      */   private static final int CLASS_DATE = 7;
/*      */   private static final int CLASS_TIME = 8;
/*      */   private static final int CLASS_TIMESTAMP = 9;
/*      */   private static final int TOTAL_CLASSES = 10;
/* 1760 */   private static Hashtable classTable = new Hashtable(10);
/*      */   
/*      */   static {
/*      */     try {
/* 1764 */       classTable.put(Class.forName("java.lang.String"), Integer.valueOf(0));
/*      */       
/* 1766 */       classTable.put(Class.forName("java.lang.Boolean"), Integer.valueOf(1));
/*      */       
/* 1768 */       classTable.put(Class.forName("java.lang.Integer"), Integer.valueOf(2));
/*      */       
/* 1770 */       classTable.put(Class.forName("java.lang.Long"), Integer.valueOf(3));
/* 1771 */       classTable.put(Class.forName("java.lang.Float"), Integer.valueOf(4));
/*      */       
/* 1773 */       classTable.put(Class.forName("java.lang.Double"), Integer.valueOf(5));
/*      */       
/* 1775 */       classTable.put(Class.forName("java.math.BigDecimal"), Integer.valueOf(6));
/*      */       
/* 1777 */       classTable.put(Class.forName("java.sql.Date"), Integer.valueOf(7));
/* 1778 */       classTable.put(Class.forName("java.sql.Time"), Integer.valueOf(8));
/* 1779 */       classTable.put(Class.forName("java.sql.Timestamp"), Integer.valueOf(9));
/*      */     }
/*      */     catch (ClassNotFoundException localClassNotFoundException) {}
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\SQLUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */