/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.util.Locale;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.OracleOCIFailover;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleConnection.InstanceProperty;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCLOB;
/*      */ import oracle.jdbc.pool.OracleOCIConnectionPool;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.ZONEIDMAP;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class T2CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*   60 */   static final long JDBC_OCI_LIBRARY_VERSION = Long.parseLong("11.2.0.3.0".replaceAll("\\.", ""));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   66 */   short[] queryMetaData1 = null;
/*   67 */   byte[] queryMetaData2 = null;
/*   68 */   int queryMetaData1Offset = 0;
/*   69 */   int queryMetaData2Offset = 0;
/*      */   private String password;
/*   71 */   int fatalErrorNumber = 0;
/*   72 */   String fatalErrorMessage = null;
/*      */   
/*      */   static final int QMD_dbtype = 0;
/*      */   
/*      */   static final int QMD_dbsize = 1;
/*      */   
/*      */   static final int QMD_nullok = 2;
/*      */   
/*      */   static final int QMD_precision = 3;
/*      */   
/*      */   static final int QMD_scale = 4;
/*      */   
/*      */   static final int QMD_formOfUse = 5;
/*      */   
/*      */   static final int QMD_columnNameLength = 6;
/*      */   
/*      */   static final int QMD_tdo0 = 7;
/*      */   
/*      */   static final int QMD_tdo1 = 8;
/*      */   
/*      */   static final int QMD_tdo2 = 9;
/*      */   
/*      */   static final int QMD_tdo3 = 10;
/*      */   
/*      */   static final int QMD_charLength = 11;
/*      */   
/*      */   static final int QMD_typeNameLength = 12;
/*      */   
/*      */   static final int T2C_LOCATOR_MAX_LEN = 16;
/*      */   static final int T2C_LINEARIZED_LOCATOR_MAX_LEN = 4000;
/*      */   static final int T2C_LINEARIZED_BFILE_LOCATOR_MAX_LEN = 530;
/*      */   static final int METADATA1_INDICES_PER_COLUMN = 13;
/*      */   protected static final int SIZEOF_QUERYMETADATA2 = 8;
/*      */   static final String defaultDriverNameAttribute = "jdbcoci";
/*  106 */   int queryMetaData1Size = 100;
/*  107 */   int queryMetaData2Size = 800;
/*      */   
/*      */   long m_nativeState;
/*      */   
/*      */   short m_clientCharacterSet;
/*      */   
/*      */   byte byteAlign;
/*      */   
/*      */   private static final int EOJ_SUCCESS = 0;
/*      */   
/*      */   private static final int EOJ_ERROR = -1;
/*      */   
/*      */   private static final int EOJ_WARNING = 1;
/*      */   
/*      */   private static final int EOJ_GET_STORAGE_ERROR = -4;
/*      */   
/*      */   private static final int EOJ_ORA3113_SERVER_NORMAL = -6;
/*      */   
/*      */   private static final String OCILIBRARY = "ocijdbc11";
/*  126 */   private int logon_mode = 0;
/*      */   
/*      */   static final int LOGON_MODE_DEFAULT = 0;
/*      */   
/*      */   static final int LOGON_MODE_SYSDBA = 2;
/*      */   
/*      */   static final int LOGON_MODE_SYSOPER = 4;
/*      */   
/*      */   static final int LOGON_MODE_SYSASM = 32768;
/*      */   
/*      */   static final int LOGON_MODE_CONNECTION_POOL = 5;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_CONNECTION = 6;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_PROXY_CONNECTION = 7;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_ALIASED_CONNECTION = 8;
/*      */   
/*      */   static final int T2C_PROXYTYPE_NONE = 0;
/*      */   
/*      */   static final int T2C_PROXYTYPE_USER_NAME = 1;
/*      */   
/*      */   static final int T2C_PROXYTYPE_DISTINGUISHED_NAME = 2;
/*      */   static final int T2C_PROXYTYPE_CERTIFICATE = 3;
/*      */   static final int T2C_CONNECTION_FLAG_DEFAULT_LOB_PREFETCH = 0;
/*      */   static final int T2C_CONNECTION_FLAG_PRELIM_AUTH = 1;
/*      */   private static boolean isLibraryLoaded;
/*  153 */   OracleOCIFailover appCallback = null;
/*  154 */   Object appCallbackObject = null;
/*      */   
/*      */   private Properties nativeInfo;
/*      */   ByteBuffer nioBufferForLob;
/*      */   
/*      */   protected T2CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension)
/*      */     throws SQLException
/*      */   {
/*  162 */     super(paramString, paramProperties, paramOracleDriverExtension);
/*      */     
/*      */ 
/*  165 */     initialize();
/*      */   }
/*      */   
/*      */ 
/*      */   final void initializePassword(String paramString)
/*      */     throws SQLException
/*      */   {
/*  172 */     this.password = paramString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void initialize()
/*      */   {
/*  179 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void allocQueryMetaDataBuffers()
/*      */   {
/*  211 */     this.queryMetaData1Offset = 0;
/*  212 */     this.queryMetaData1 = new short[this.queryMetaData1Size * 13];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  217 */     this.queryMetaData2Offset = 0;
/*  218 */     this.queryMetaData2 = new byte[this.queryMetaData2Size];
/*      */     
/*  220 */     this.namedTypeAccessorByteLen = 0;
/*  221 */     this.refTypeAccessorByteLen = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void reallocateQueryMetaData(int paramInt1, int paramInt2)
/*      */   {
/*  228 */     this.queryMetaData1 = null;
/*  229 */     this.queryMetaData2 = null;
/*      */     
/*  231 */     this.queryMetaData1Size = Math.max(paramInt1, this.queryMetaData1Size);
/*  232 */     this.queryMetaData2Size = Math.max(paramInt2, this.queryMetaData2Size);
/*      */     
/*  234 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void logon()
/*      */     throws SQLException
/*      */   {
/*  258 */     if (this.database == null)
/*      */     {
/*  260 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 64);
/*  261 */       localSQLException.fillInStackTrace();
/*  262 */       throw localSQLException;
/*      */     }
/*      */     
/*  265 */     if (!isLibraryLoaded) {
/*  266 */       loadNativeLibrary(this.ocidll);
/*      */     }
/*      */     
/*      */ 
/*  270 */     if (this.ociConnectionPoolIsPooling)
/*      */     {
/*  272 */       processOCIConnectionPooling();
/*      */     }
/*      */     else
/*      */     {
/*  276 */       long l1 = this.ociSvcCtxHandle;
/*  277 */       long l2 = this.ociEnvHandle;
/*  278 */       long l3 = this.ociErrHandle;
/*      */       
/*      */ 
/*  281 */       if ((l1 != 0L) && (l2 != 0L))
/*      */       {
/*      */ 
/*  284 */         if (this.ociDriverCharset != null) {
/*  285 */           this.m_clientCharacterSet = new Integer(this.ociDriverCharset).shortValue();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  290 */           localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  291 */           ((SQLException)localObject1).fillInStackTrace();
/*  292 */           throw ((Throwable)localObject1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  298 */         this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */         
/*      */ 
/*  301 */         localObject1 = new short[5];
/*  302 */         localObject2 = new long[] { this.defaultLobPrefetchSize };
/*      */         
/*  304 */         this.sqlWarning = checkError(t2cUseConnection(this.m_nativeState, l2, l1, l3, (short[])localObject1, (long[])localObject2), this.sqlWarning);
/*      */         
/*      */ 
/*      */ 
/*  308 */         this.conversion = new DBConversion(localObject1[0], this.m_clientCharacterSet, localObject1[1]);
/*  309 */         this.byteAlign = ((byte)(localObject1[2] & 0xFF));
/*  310 */         this.timeZoneVersionNumber = ((localObject1[3] << 16) + (localObject1[4] & 0xFFFF));
/*      */         
/*  312 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  317 */       if (this.internalLogon == null) {
/*  318 */         this.logon_mode = 0;
/*  319 */       } else if (this.internalLogon.equalsIgnoreCase("SYSDBA")) {
/*  320 */         this.logon_mode = 2;
/*  321 */       } else if (this.internalLogon.equalsIgnoreCase("SYSOPER")) {
/*  322 */         this.logon_mode = 4;
/*  323 */       } else if (this.internalLogon.equalsIgnoreCase("SYSASM")) {
/*  324 */         this.logon_mode = 32768;
/*      */       }
/*  326 */       Object localObject1 = null;
/*  327 */       Object localObject2 = null;
/*  328 */       byte[] arrayOfByte1 = null;
/*  329 */       String str1 = this.setNewPassword;
/*  330 */       byte[] arrayOfByte2 = new byte[0];
/*  331 */       byte[] arrayOfByte3 = new byte[0];
/*  332 */       byte[] arrayOfByte4 = new byte[0];
/*      */       
/*  334 */       if (this.nlsLangBackdoor)
/*      */       {
/*      */ 
/*  337 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  342 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       }
/*      */       
/*  345 */       if (str1 != null) {
/*  346 */         arrayOfByte2 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet);
/*      */       }
/*  348 */       if (this.editionName != null) {
/*  349 */         arrayOfByte3 = DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */       }
/*  351 */       if (this.driverNameAttribute == null) {
/*  352 */         arrayOfByte4 = DBConversion.stringToDriverCharBytes("jdbcoci", this.m_clientCharacterSet);
/*      */       } else {
/*  354 */         arrayOfByte4 = DBConversion.stringToDriverCharBytes(this.driverNameAttribute, this.m_clientCharacterSet);
/*      */       }
/*  356 */       localObject1 = this.userName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*  359 */       localObject2 = this.proxyClientName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.proxyClientName, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*  362 */       arrayOfByte1 = this.password == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*  365 */       byte[] arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */       
/*  367 */       short[] arrayOfShort = new short[5];
/*  368 */       String str2 = null;
/*  369 */       byte[] arrayOfByte6 = (str2 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault())) != null ? str2.getBytes() : null;
/*      */       
/*  371 */       byte[] arrayOfByte7 = (str2 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault())) != null ? str2.getBytes() : null;
/*      */       
/*      */ 
/*  374 */       if ((arrayOfByte6 == null) || (arrayOfByte7 == null))
/*      */       {
/*  376 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/*  377 */         ((SQLException)localObject3).fillInStackTrace();
/*  378 */         throw ((Throwable)localObject3);
/*      */       }
/*      */       
/*  381 */       Object localObject3 = TimeZone.getDefault();
/*  382 */       String str3 = ((TimeZone)localObject3).getID();
/*      */       
/*  384 */       if ((!ZONEIDMAP.isValidRegion(str3)) || (!this.timezoneAsRegion))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  393 */         int i = ((TimeZone)localObject3).getOffset(System.currentTimeMillis());
/*  394 */         int j = i / 3600000;
/*  395 */         int k = i / 60000 % 60;
/*      */         
/*  397 */         str3 = (j < 0 ? "" + j : new StringBuilder().append("+").append(j).toString()) + (k < 10 ? ":0" + k : new StringBuilder().append(":").append(k).toString());
/*      */       }
/*      */       
/*      */ 
/*  401 */       doSetSessionTimeZone(str3);
/*      */       
/*      */ 
/*  404 */       this.sessionTimeZone = str3;
/*      */       
/*      */ 
/*  407 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*  410 */       long[] arrayOfLong = { this.defaultLobPrefetchSize, this.prelimAuth ? 1 : 0 };
/*      */       
/*  412 */       if (this.m_nativeState == 0L)
/*      */       {
/*  414 */         this.sqlWarning = checkError(t2cCreateState((byte[])localObject1, localObject1.length, (byte[])localObject2, localObject2.length, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.m_clientCharacterSet, this.logon_mode, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  429 */         this.sqlWarning = checkError(t2cLogon(this.m_nativeState, (byte[])localObject1, localObject1.length, (byte[])localObject2, localObject2.length, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */       this.conversion = new DBConversion(arrayOfShort[0], this.m_clientCharacterSet, arrayOfShort[1]);
/*  444 */       this.byteAlign = ((byte)(arrayOfShort[2] & 0xFF));
/*  445 */       this.timeZoneVersionNumber = ((arrayOfShort[3] << 16) + (arrayOfShort[4] & 0xFFFF));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void logoff()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  464 */       if (this.lifecycle == 2)
/*      */       {
/*  466 */         checkError(t2cLogoff(this.m_nativeState));
/*      */       }
/*      */     }
/*      */     catch (NullPointerException localNullPointerException) {}
/*      */     
/*  471 */     this.m_nativeState = 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void open(OracleStatement paramOracleStatement)
/*      */     throws SQLException
/*      */   {
/*  489 */     byte[] arrayOfByte = paramOracleStatement.sqlObject.getSql(paramOracleStatement.processEscapes, paramOracleStatement.convertNcharLiterals).getBytes();
/*      */     
/*      */ 
/*  492 */     checkError(t2cCreateStatement(this.m_nativeState, 0L, arrayOfByte, arrayOfByte.length, paramOracleStatement, false, paramOracleStatement.rowPrefetch));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cancelOperationOnServer()
/*      */     throws SQLException
/*      */   {
/*  508 */     checkError(t2cCancel(this.m_nativeState));
/*      */   }
/*      */   
/*      */ 
/*      */   native int t2cAbort(long paramLong);
/*      */   
/*      */   void doAbort()
/*      */     throws SQLException
/*      */   {
/*  517 */     checkError(t2cAbort(this.m_nativeState));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doSetAutoCommit(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  534 */     checkError(t2cSetAutoCommit(this.m_nativeState, paramBoolean));
/*  535 */     this.autocommit = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doCommit(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  551 */     checkError(t2cCommit(this.m_nativeState, paramInt));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doRollback()
/*      */     throws SQLException
/*      */   {
/*  567 */     checkError(t2cRollback(this.m_nativeState));
/*      */   }
/*      */   
/*      */ 
/*      */   synchronized int doPingDatabase()
/*      */     throws SQLException
/*      */   {
/*  574 */     if (t2cPingDatabase(this.m_nativeState) == 0) {
/*  575 */       return 0;
/*      */     }
/*  577 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */   protected String doGetDatabaseProductVersion()
/*      */     throws SQLException
/*      */   {
/*  584 */     byte[] arrayOfByte = t2cGetProductionVersion(this.m_nativeState);
/*      */     
/*  586 */     return this.conversion.CharBytesToString(arrayOfByte, arrayOfByte.length);
/*      */   }
/*      */   
/*      */ 
/*      */   protected short doGetVersionNumber()
/*      */     throws SQLException
/*      */   {
/*  593 */     short s = 0;
/*      */     
/*      */     try
/*      */     {
/*  597 */       String str1 = doGetDatabaseProductVersion();
/*      */       
/*  599 */       StringTokenizer localStringTokenizer = new StringTokenizer(str1.trim(), " .", false);
/*  600 */       String str2 = null;
/*  601 */       int i = 0;
/*  602 */       int j = 0;
/*      */       
/*  604 */       while (localStringTokenizer.hasMoreTokens())
/*      */       {
/*  606 */         str2 = localStringTokenizer.nextToken();
/*      */         
/*      */         try
/*      */         {
/*  610 */           j = Integer.decode(str2).shortValue();
/*  611 */           s = (short)(s * 10 + j);
/*  612 */           i++;
/*      */           
/*      */ 
/*  615 */           if (i == 4) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException) {}
/*      */       }
/*      */     }
/*      */     catch (NoSuchElementException localNoSuchElementException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  630 */     if (s == -1) {
/*  631 */       s = 0;
/*      */     }
/*      */     
/*  634 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ClobDBAccess createClobDBAccess()
/*      */   {
/*  641 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BlobDBAccess createBlobDBAccess()
/*      */   {
/*  648 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BfileDBAccess createBfileDBAccess()
/*      */   {
/*  655 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */   protected SQLWarning checkError(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  662 */     return checkError(paramInt, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected SQLWarning checkError(int paramInt, SQLWarning paramSQLWarning)
/*      */     throws SQLException
/*      */   {
/*      */     Object localObject1;
/*      */     
/*  672 */     switch (paramInt)
/*      */     {
/*      */     case 0: 
/*      */       break;
/*      */     
/*      */ 
/*      */     case -1: 
/*      */     case 1: 
/*  680 */       localObject1 = new T2CError();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  686 */       int i = -1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  691 */       if ((this.lifecycle == 1) || (this.lifecycle == 16))
/*      */       {
/*  693 */         i = t2cDescribeError(this.m_nativeState, (T2CError)localObject1, ((T2CError)localObject1).m_errorMessage);
/*      */       }
/*      */       else {
/*  696 */         if (this.fatalErrorNumber != 0)
/*      */         {
/*      */ 
/*  699 */           localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 269);
/*  700 */           ((SQLException)localObject2).fillInStackTrace();
/*  701 */           throw ((Throwable)localObject2);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  706 */         localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  707 */         ((SQLException)localObject2).fillInStackTrace();
/*  708 */         throw ((Throwable)localObject2);
/*      */       }
/*      */       
/*  711 */       Object localObject2 = null;
/*  712 */       if (i != -1)
/*      */       {
/*      */ 
/*      */ 
/*  716 */         int j = 0;
/*      */         
/*  718 */         while ((j < ((T2CError)localObject1).m_errorMessage.length) && (localObject1.m_errorMessage[j] != 0)) {
/*  719 */           j++;
/*      */         }
/*  721 */         if (this.conversion == null) throw new Error("conversion == null");
/*  722 */         if (localObject1 == null) throw new Error("l_error == null");
/*  723 */         localObject2 = this.conversion.CharBytesToString(((T2CError)localObject1).m_errorMessage, j, true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  730 */       switch (((T2CError)localObject1).m_errorNumber)
/*      */       {
/*      */       case 28: 
/*      */       case 600: 
/*      */       case 1012: 
/*      */       case 1041: 
/*  736 */         internalClose();
/*  737 */         break;
/*      */       
/*      */ 
/*      */       case 902: 
/*  741 */         removeAllDescriptor();
/*  742 */         break;
/*      */       
/*      */       case 3113: 
/*      */       case 3114: 
/*  746 */         close();
/*  747 */         break;
/*      */       case -6: 
/*  749 */         ((T2CError)localObject1).m_errorNumber = 3113;
/*      */       }
/*      */       
/*      */       
/*      */       SQLException localSQLException;
/*  754 */       if (i == -1)
/*      */       {
/*  756 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Fetch error message failed!");
/*  757 */         localSQLException.fillInStackTrace();
/*  758 */         throw localSQLException;
/*      */       }
/*      */       
/*  761 */       if (paramInt == -1)
/*      */       {
/*      */ 
/*  764 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (String)localObject2, ((T2CError)localObject1).m_errorNumber);
/*  765 */         localSQLException.fillInStackTrace();
/*  766 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  771 */       paramSQLWarning = DatabaseError.addSqlWarning(paramSQLWarning, (String)localObject2, ((T2CError)localObject1).m_errorNumber);
/*      */       
/*      */ 
/*  774 */       break;
/*      */     
/*      */ 
/*      */     case -4: 
/*  778 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254);
/*  779 */       ((SQLException)localObject1).fillInStackTrace();
/*  780 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  787 */     return paramSQLWarning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfByte, OracleStatement paramOracleStatement)
/*      */     throws SQLException
/*      */   {
/*  795 */     T2CStatement localT2CStatement = new T2CStatement(this, 1, this.defaultRowPrefetch, -1, -1);
/*      */     
/*  797 */     localT2CStatement.needToParse = false;
/*  798 */     localT2CStatement.serverCursor = true;
/*  799 */     localT2CStatement.isOpen = true;
/*  800 */     localT2CStatement.processEscapes = false;
/*      */     
/*  802 */     localT2CStatement.prepareForNewResults(true, false);
/*  803 */     localT2CStatement.sqlObject.initialize("select unknown as ref cursor from whatever");
/*      */     
/*  805 */     localT2CStatement.sqlKind = OracleStatement.SqlKind.SELECT;
/*      */     
/*  807 */     checkError(t2cCreateStatement(this.m_nativeState, paramOracleStatement.c_state, paramArrayOfByte, paramArrayOfByte.length, localT2CStatement, true, this.defaultRowPrefetch));
/*      */     
/*      */ 
/*      */ 
/*  811 */     paramOracleStatement.addChild(localT2CStatement);
/*  812 */     return localT2CStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/*  821 */     int i = 0;
/*      */     
/*  823 */     if (paramOracleTypeCLOB != null)
/*      */     {
/*  825 */       String[] arrayOfString1 = new String[1];
/*  826 */       String[] arrayOfString2 = new String[1];
/*      */       
/*  828 */       SQLName.parse(paramOracleTypeADT.getFullName(), arrayOfString1, arrayOfString2, true);
/*      */       
/*  830 */       String str = "\"" + arrayOfString1[0] + "\".\"" + arrayOfString2[0] + "\"";
/*      */       
/*      */ 
/*  833 */       byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*      */       
/*  835 */       int j = t2cGetFormOfUse(this.m_nativeState, paramOracleTypeCLOB, arrayOfByte, arrayOfByte.length, paramInt);
/*      */       
/*      */ 
/*      */ 
/*  839 */       if (j < 0) {
/*  840 */         checkError(j);
/*      */       }
/*      */       
/*  843 */       paramOracleTypeCLOB.setForm(j);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getTdoCState(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/*  858 */     String str = "\"" + paramString1 + "\".\"" + paramString2 + "\"";
/*  859 */     byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*  860 */     int[] arrayOfInt = new int[1];
/*  861 */     long l = t2cGetTDO(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfInt);
/*  862 */     if (l == 0L)
/*      */     {
/*  864 */       checkError(arrayOfInt[0]);
/*      */     }
/*  866 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public Properties getDBAccessProperties()
/*      */     throws SQLException
/*      */   {
/*  882 */     return getOCIHandles();
/*      */   }
/*      */   
/*      */   public synchronized Properties getOCIHandles()
/*      */     throws SQLException
/*      */   {
/*      */     Object localObject;
/*  889 */     if (this.lifecycle != 1)
/*      */     {
/*  891 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  892 */       ((SQLException)localObject).fillInStackTrace();
/*  893 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*  896 */     if (this.nativeInfo == null)
/*      */     {
/*  898 */       localObject = new long[3];
/*      */       
/*      */ 
/*  901 */       checkError(t2cGetHandles(this.m_nativeState, (long[])localObject));
/*      */       
/*      */ 
/*  904 */       this.nativeInfo = new Properties();
/*      */       
/*  906 */       this.nativeInfo.put("OCIEnvHandle", String.valueOf(localObject[0]));
/*  907 */       this.nativeInfo.put("OCISvcCtxHandle", String.valueOf(localObject[1]));
/*  908 */       this.nativeInfo.put("OCIErrHandle", String.valueOf(localObject[2]));
/*  909 */       this.nativeInfo.put("ClientCharSet", String.valueOf(this.m_clientCharacterSet));
/*      */     }
/*      */     
/*  912 */     return this.nativeInfo;
/*      */   }
/*      */   
/*      */ 
/*      */   public Properties getServerSessionInfo()
/*      */     throws SQLException
/*      */   {
/*  919 */     if (this.lifecycle != 1)
/*      */     {
/*  921 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  922 */       localSQLException.fillInStackTrace();
/*  923 */       throw localSQLException;
/*      */     }
/*      */     
/*  926 */     if (this.sessionProperties == null) {
/*  927 */       this.sessionProperties = new Properties();
/*      */     }
/*      */     
/*      */ 
/*  931 */     if (getVersionNumber() < 10200) {
/*  932 */       queryFCFProperties(this.sessionProperties);
/*      */     } else {
/*  934 */       checkError(t2cGetServerSessionInfo(this.m_nativeState, this.sessionProperties));
/*      */     }
/*  936 */     return this.sessionProperties;
/*      */   }
/*      */   
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty)
/*      */     throws SQLException
/*      */   {
/*  942 */     byte b = 0;
/*  943 */     if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED)
/*      */     {
/*  945 */       b = t2cGetAsmVolProperty(this.m_nativeState);
/*      */     }
/*  947 */     else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE)
/*      */     {
/*  949 */       b = t2cGetInstanceType(this.m_nativeState);
/*      */     }
/*  951 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Properties getConnectionPoolInfo()
/*      */     throws SQLException
/*      */   {
/*  961 */     if (this.lifecycle != 1)
/*      */     {
/*  963 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  964 */       ((SQLException)localObject).fillInStackTrace();
/*  965 */       throw ((Throwable)localObject);
/*      */     }
/*  967 */     Object localObject = new Properties();
/*      */     
/*  969 */     checkError(t2cGetConnPoolInfo(this.m_nativeState, (Properties)localObject));
/*      */     
/*  971 */     return (Properties)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionPoolInfo(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
/*      */     throws SQLException
/*      */   {
/*  981 */     checkError(t2cSetConnPoolInfo(this.m_nativeState, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ociPasswordChange(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLException
/*      */   {
/*  991 */     if (this.lifecycle != 1)
/*      */     {
/*  993 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  994 */       ((SQLException)localObject).fillInStackTrace();
/*  995 */       throw ((Throwable)localObject);
/*      */     }
/*  997 */     Object localObject = paramString1 == null ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString1, this.m_clientCharacterSet);
/*      */     
/*      */ 
/*      */ 
/* 1001 */     byte[] arrayOfByte1 = paramString2 == null ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString2, this.m_clientCharacterSet);
/*      */     
/*      */ 
/* 1004 */     byte[] arrayOfByte2 = paramString3 == null ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString3, this.m_clientCharacterSet);
/*      */     
/*      */ 
/* 1007 */     this.sqlWarning = checkError(t2cPasswordChange(this.m_nativeState, (byte[])localObject, localObject.length, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length), this.sqlWarning);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processOCIConnectionPooling()
/*      */     throws SQLException
/*      */   {
/* 1018 */     if (this.lifecycle != 1)
/*      */     {
/* 1020 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1021 */       ((SQLException)localObject1).fillInStackTrace();
/* 1022 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/*      */ 
/* 1026 */     Object localObject1 = null;
/*      */     
/* 1028 */     if (this.ociConnectionPoolLogonMode == "connection_pool")
/*      */     {
/* 1030 */       if (this.nlsLangBackdoor)
/*      */       {
/*      */ 
/* 1033 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1038 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       }
/*      */     }
/*      */     else {
/* 1042 */       localObject1 = (T2CConnection)this.ociConnectionPoolObject;
/* 1043 */       this.m_clientCharacterSet = ((T2CConnection)localObject1).m_clientCharacterSet;
/*      */     }
/*      */     
/* 1046 */     byte[] arrayOfByte1 = null;
/*      */     
/* 1048 */     byte[] arrayOfByte2 = this.password == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */     
/*      */ 
/* 1051 */     byte[] arrayOfByte3 = this.editionName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */     
/*      */ 
/* 1054 */     byte[] arrayOfByte4 = DBConversion.stringToDriverCharBytes(this.driverNameAttribute == null ? "jdbcoci" : this.driverNameAttribute, this.m_clientCharacterSet);
/*      */     
/*      */ 
/*      */ 
/* 1058 */     byte[] arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */     
/* 1060 */     byte[] arrayOfByte6 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault()).getBytes();
/*      */     
/* 1062 */     byte[] arrayOfByte7 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault()).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 1066 */     if ((arrayOfByte6 == null) || (arrayOfByte7 == null))
/*      */     {
/* 1068 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/* 1069 */       ((SQLException)localObject2).fillInStackTrace();
/* 1070 */       throw ((Throwable)localObject2);
/*      */     }
/*      */     
/* 1073 */     Object localObject2 = new short[5];
/* 1074 */     long[] arrayOfLong = { this.defaultLobPrefetchSize };
/*      */     Object localObject3;
/* 1076 */     if (this.ociConnectionPoolLogonMode == "connection_pool")
/*      */     {
/* 1078 */       arrayOfByte1 = this.userName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1084 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */       
/*      */ 
/* 1087 */       this.logon_mode = 5;
/*      */       
/* 1089 */       if (this.lifecycle == 1)
/*      */       {
/* 1091 */         localObject3 = new int[6];
/*      */         
/* 1093 */         OracleOCIConnectionPool.readPoolConfig(this.ociConnectionPoolMinLimit, this.ociConnectionPoolMaxLimit, this.ociConnectionPoolIncrement, this.ociConnectionPoolTimeout, this.ociConnectionPoolNoWait, this.ociConnectionPoolTransactionDistributed, (int[])localObject3);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1101 */         this.sqlWarning = checkError(t2cCreateConnPool(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte5, arrayOfByte5.length, this.m_clientCharacterSet, this.logon_mode, localObject3[0], localObject3[1], localObject3[2], localObject3[3], localObject3[4], localObject3[5]), this.sqlWarning);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1112 */         this.versionNumber = 10000;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1118 */         localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 0, "Internal Error: ");
/* 1119 */         ((SQLException)localObject3).fillInStackTrace();
/* 1120 */         throw ((Throwable)localObject3);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1125 */     else if (this.ociConnectionPoolLogonMode == "connpool_connection")
/*      */     {
/* 1127 */       this.logon_mode = 6;
/*      */       
/* 1129 */       arrayOfByte1 = this.userName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1135 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */       
/*      */ 
/* 1138 */       this.sqlWarning = checkError(t2cConnPoolLogon(((T2CConnection)localObject1).m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, null, null, 0, null, 0, null, 0, null, 0, null, 0, (short[])localObject2, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/* 1171 */     else if (this.ociConnectionPoolLogonMode == "connpool_alias_connection")
/*      */     {
/* 1173 */       this.logon_mode = 8;
/*      */       
/*      */ 
/* 1176 */       localObject3 = null;
/*      */       
/* 1178 */       localObject3 = (byte[])this.ociConnectionPoolConnID;
/*      */       
/*      */ 
/* 1181 */       arrayOfByte1 = this.userName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1187 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */       
/*      */ 
/* 1190 */       this.sqlWarning = checkError(t2cConnPoolLogon(((T2CConnection)localObject1).m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, null, null, 0, null, 0, null, 0, null, 0, (byte[])localObject3, localObject3 == null ? 0 : localObject3.length, (short[])localObject2, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/* 1223 */     else if (this.ociConnectionPoolLogonMode == "connpool_proxy_connection")
/*      */     {
/* 1225 */       this.logon_mode = 7;
/*      */       
/*      */ 
/* 1228 */       localObject3 = this.ociConnectionPoolProxyType;
/*      */       
/*      */ 
/* 1231 */       int i = this.ociConnectionPoolProxyNumRoles.intValue();
/*      */       
/* 1233 */       String[] arrayOfString = null;
/*      */       
/* 1235 */       if (i > 0)
/*      */       {
/* 1237 */         arrayOfString = (String[])this.ociConnectionPoolProxyRoles;
/*      */       }
/*      */       
/*      */ 
/* 1241 */       byte[] arrayOfByte8 = null;
/* 1242 */       byte[] arrayOfByte9 = null;
/* 1243 */       byte[] arrayOfByte10 = null;
/* 1244 */       byte[] arrayOfByte11 = null;
/*      */       
/*      */ 
/* 1247 */       int j = 0;
/*      */       
/*      */       String str;
/* 1250 */       if (localObject3 == "proxytype_user_name")
/*      */       {
/* 1252 */         j = 1;
/*      */         
/* 1254 */         str = this.ociConnectionPoolProxyUserName;
/*      */         
/* 1256 */         if (str != null) {
/* 1257 */           arrayOfByte8 = str.getBytes();
/*      */         }
/* 1259 */         str = this.ociConnectionPoolProxyPassword;
/*      */         
/* 1261 */         if (str != null) {
/* 1262 */           arrayOfByte9 = str.getBytes();
/*      */         }
/* 1264 */       } else if (localObject3 == "proxytype_distinguished_name")
/*      */       {
/*      */ 
/* 1267 */         j = 2;
/*      */         
/* 1269 */         str = this.ociConnectionPoolProxyDistinguishedName;
/*      */         
/* 1271 */         if (str != null) {
/* 1272 */           arrayOfByte10 = str.getBytes();
/*      */         }
/* 1274 */       } else if (localObject3 == "proxytype_certificate")
/*      */       {
/* 1276 */         j = 3;
/*      */         
/* 1278 */         arrayOfByte11 = (byte[])this.ociConnectionPoolProxyCertificate;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1284 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107);
/* 1285 */         localSQLException.fillInStackTrace();
/* 1286 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1291 */       arrayOfByte1 = this.userName == null ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1297 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */       
/*      */ 
/* 1300 */       this.sqlWarning = checkError(t2cConnPoolLogon(((T2CConnection)localObject1).m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, j, i, arrayOfString, arrayOfByte8, arrayOfByte8 == null ? 0 : arrayOfByte8.length, arrayOfByte9, arrayOfByte9 == null ? 0 : arrayOfByte9.length, arrayOfByte10, arrayOfByte10 == null ? 0 : arrayOfByte10.length, arrayOfByte11, arrayOfByte11 == null ? 0 : arrayOfByte11.length, null, 0, (short[])localObject2, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1327 */       localObject3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "connection-pool-logon");
/* 1328 */       ((SQLException)localObject3).fillInStackTrace();
/* 1329 */       throw ((Throwable)localObject3);
/*      */     }
/*      */     
/*      */ 
/* 1333 */     this.conversion = new DBConversion(localObject2[0], this.m_clientCharacterSet, localObject2[1]);
/* 1334 */     this.byteAlign = ((byte)(localObject2[2] & 0xFF));
/* 1335 */     this.timeZoneVersionNumber = ((localObject2[3] << 16) + (localObject2[4] & 0xFFFF));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDescriptorSharable(OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/* 1351 */     T2CConnection localT2CConnection = this;
/* 1352 */     PhysicalConnection localPhysicalConnection = (PhysicalConnection)paramOracleConnection.getPhysicalConnection();
/*      */     
/* 1354 */     return localT2CConnection == localPhysicalConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cBlobRead(long paramLong1, byte[] paramArrayOfByte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, boolean paramBoolean, ByteBuffer paramByteBuffer);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cClobRead(long paramLong1, byte[] paramArrayOfByte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfChar, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, ByteBuffer paramByteBuffer);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cBlobWrite(long paramLong1, byte[] paramArrayOfByte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, byte[][] paramArrayOfByte);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cClobWrite(long paramLong1, byte[] paramArrayOfByte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfChar, int paramInt3, byte[][] paramArrayOfByte1, boolean paramBoolean);
/*      */   
/*      */ 
/*      */ 
/*      */   native long t2cLobGetLength(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cBfileOpen(long paramLong, byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cBfileIsOpen(long paramLong, byte[] paramArrayOfByte, int paramInt, boolean[] paramArrayOfBoolean);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cBfileExists(long paramLong, byte[] paramArrayOfByte, int paramInt, boolean[] paramArrayOfBoolean);
/*      */   
/*      */ 
/*      */ 
/*      */   native String t2cBfileGetName(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   native String t2cBfileGetDirAlias(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cBfileClose(long paramLong, byte[] paramArrayOfByte, int paramInt, byte[][] paramArrayOfByte1);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cLobGetChunkSize(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cLobTrim(long paramLong1, int paramInt1, long paramLong2, byte[] paramArrayOfByte, int paramInt2, byte[][] paramArrayOfByte1);
/*      */   
/*      */ 
/*      */   native int t2cLobCreateTemporary(long paramLong, int paramInt1, boolean paramBoolean, int paramInt2, short paramShort, byte[][] paramArrayOfByte);
/*      */   
/*      */ 
/*      */   native int t2cLobFreeTemporary(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2, byte[][] paramArrayOfByte1);
/*      */   
/*      */ 
/*      */   native int t2cLobIsTemporary(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2, boolean[] paramArrayOfBoolean);
/*      */   
/*      */ 
/*      */   native int t2cLobOpen(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, byte[][] paramArrayOfByte1);
/*      */   
/*      */ 
/*      */   native int t2cLobIsOpen(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2, boolean[] paramArrayOfBoolean);
/*      */   
/*      */ 
/*      */   native int t2cLobClose(long paramLong, int paramInt1, byte[] paramArrayOfByte, int paramInt2, byte[][] paramArrayOfByte1);
/*      */   
/*      */ 
/*      */   private long lobLength(byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1431 */     long l = 0L;
/* 1432 */     l = t2cLobGetLength(this.m_nativeState, paramArrayOfByte, paramArrayOfByte.length);
/*      */     
/* 1434 */     checkError((int)l);
/*      */     
/* 1436 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int blobRead(byte[] paramArrayOfByte1, long paramLong, int paramInt, byte[] paramArrayOfByte2, boolean paramBoolean, ByteBuffer paramByteBuffer)
/*      */     throws SQLException
/*      */   {
/* 1451 */     int i = 0;
/*      */     
/* 1453 */     i = t2cBlobRead(this.m_nativeState, paramArrayOfByte1, paramArrayOfByte1.length, paramLong, paramInt, paramArrayOfByte2, paramArrayOfByte2.length, paramBoolean, paramByteBuffer);
/*      */     
/*      */ 
/* 1456 */     checkError(i);
/*      */     
/* 1458 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int blobWrite(byte[] paramArrayOfByte1, long paramLong, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1473 */     int i = 0;
/*      */     
/* 1475 */     i = t2cBlobWrite(this.m_nativeState, paramArrayOfByte1, paramArrayOfByte1.length, paramLong, paramInt2, paramArrayOfByte2, paramInt1, paramArrayOfByte);
/*      */     
/*      */ 
/* 1478 */     checkError(i);
/*      */     
/* 1480 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int clobWrite(byte[] paramArrayOfByte, long paramLong, char[] paramArrayOfChar, byte[][] paramArrayOfByte1, boolean paramBoolean, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1496 */     int i = 0;
/*      */     
/* 1498 */     i = t2cClobWrite(this.m_nativeState, paramArrayOfByte, paramArrayOfByte.length, paramLong, paramInt2, paramArrayOfChar, paramInt1, paramArrayOfByte1, paramBoolean);
/*      */     
/*      */ 
/* 1501 */     checkError(i);
/*      */     
/* 1503 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int lobGetChunkSize(byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1511 */     int i = 0;
/* 1512 */     i = t2cLobGetChunkSize(this.m_nativeState, paramArrayOfByte, paramArrayOfByte.length);
/*      */     
/* 1514 */     checkError(i);
/*      */     
/* 1516 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long length(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1529 */     byte[] arrayOfByte = null;
/*      */     
/* 1531 */     checkTrue(this.lifecycle == 1, 8);
/* 1532 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1535 */     return lobLength(arrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfByte, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1553 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 1556 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1557 */       localSQLException.fillInStackTrace();
/* 1558 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1562 */     long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfByte, paramLong);
/*      */     
/* 1564 */     l = l == 0L ? -1L : l;
/*      */     
/* 1566 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1584 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 1587 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1588 */       localSQLException.fillInStackTrace();
/* 1589 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1593 */     long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong);
/*      */     
/* 1595 */     l = l == 0L ? -1L : l;
/*      */     
/* 1597 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1613 */     byte[] arrayOfByte = null;
/*      */     
/* 1615 */     checkTrue(this.lifecycle == 1, 8);
/* 1616 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1619 */     if ((paramInt <= 0) || (paramArrayOfByte == null)) {
/* 1620 */       return 0;
/*      */     }
/* 1622 */     if (paramInt > paramArrayOfByte.length) {
/* 1623 */       paramInt = paramArrayOfByte.length;
/*      */     }
/* 1625 */     if (this.useNio)
/*      */     {
/* 1627 */       i = paramArrayOfByte.length;
/* 1628 */       if ((this.nioBufferForLob == null) || (this.nioBufferForLob.capacity() < i)) {
/* 1629 */         this.nioBufferForLob = ByteBuffer.allocateDirect(i);
/*      */       } else {
/* 1631 */         this.nioBufferForLob.rewind();
/*      */       }
/*      */     }
/* 1634 */     int i = blobRead(arrayOfByte, paramLong, paramInt, paramArrayOfByte, this.useNio, this.nioBufferForLob);
/* 1635 */     if (this.useNio)
/*      */     {
/* 1637 */       this.nioBufferForLob.get(paramArrayOfByte);
/*      */     }
/*      */     
/* 1640 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized String getName(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1654 */     byte[] arrayOfByte = null;
/* 1655 */     String str = null;
/*      */     
/* 1657 */     checkTrue(this.lifecycle == 1, 8);
/* 1658 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1661 */     str = t2cBfileGetName(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1663 */     checkError(str.length());
/*      */     
/* 1665 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized String getDirAlias(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1679 */     byte[] arrayOfByte = null;
/* 1680 */     String str = null;
/*      */     
/* 1682 */     checkTrue(this.lifecycle == 1, 8);
/* 1683 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1686 */     str = t2cBfileGetDirAlias(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1688 */     checkError(str.length());
/*      */     
/* 1690 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void openFile(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1703 */     byte[] arrayOfByte = null;
/*      */     
/* 1705 */     checkTrue(this.lifecycle == 1, 8);
/* 1706 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1709 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1711 */     checkError(t2cBfileOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 1714 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1731 */     byte[] arrayOfByte = null;
/*      */     
/* 1733 */     checkTrue(this.lifecycle == 1, 8);
/* 1734 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1737 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1739 */     checkError(t2cBfileIsOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 1741 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean fileExists(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1757 */     byte[] arrayOfByte = null;
/*      */     
/* 1759 */     checkTrue(this.lifecycle == 1, 8);
/* 1760 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1763 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1765 */     checkError(t2cBfileExists(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 1767 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void closeFile(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1780 */     byte[] arrayOfByte = null;
/*      */     
/* 1782 */     checkTrue(this.lifecycle == 1, 8);
/* 1783 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1786 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1788 */     checkError(t2cBfileClose(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 1791 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(BFILE paramBFILE, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1806 */     byte[] arrayOfByte = null;
/*      */     
/* 1808 */     checkTrue(this.lifecycle == 1, 8);
/* 1809 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 1812 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1814 */     checkError(t2cLobOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */     
/*      */ 
/* 1817 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1830 */     byte[] arrayOfByte = null;
/*      */     
/* 1832 */     checkTrue(this.lifecycle == 1, 8);
/* 1833 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 1836 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1838 */     checkError(t2cLobClose(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 1841 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isOpen(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1855 */     byte[] arrayOfByte = null;
/*      */     
/* 1857 */     checkTrue(this.lifecycle == 1, 8);
/* 1858 */     checkTrue((paramBFILE != null) && ((arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 1861 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1863 */     checkError(t2cLobIsOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/*      */ 
/* 1866 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1886 */     if (paramLong == 0L)
/*      */     {
/* 1888 */       return new OracleBlobInputStream(paramBFILE, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 1892 */     return new OracleBlobInputStream(paramBFILE, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1912 */     checkTrue((paramBFILE != null) && (paramBFILE.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 1915 */     OracleConversionInputStream localOracleConversionInputStream = new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */     
/* 1917 */     return localOracleConversionInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newConversionReader(BFILE paramBFILE, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1937 */     checkTrue((paramBFILE != null) && (paramBFILE.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 1940 */     OracleConversionReader localOracleConversionReader = new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */     
/* 1942 */     return localOracleConversionReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long length(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 1956 */     byte[] arrayOfByte = null;
/*      */     
/* 1958 */     checkTrue(this.lifecycle == 1, 8);
/* 1959 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 1962 */     return lobLength(arrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(BLOB paramBLOB, byte[] paramArrayOfByte, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1981 */     checkTrue(this.lifecycle == 1, 8);
/* 1982 */     checkTrue((paramBLOB != null) && (paramBLOB.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 1985 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 1988 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1989 */       localSQLException.fillInStackTrace();
/* 1990 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1994 */     long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfByte, paramLong);
/*      */     
/* 1996 */     l = l == 0L ? -1L : l;
/* 1997 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2014 */     checkTrue(this.lifecycle == 1, 8);
/* 2015 */     checkTrue((paramBLOB1 != null) && (paramBLOB1.shareBytes() != null), 54);
/*      */     
/* 2017 */     checkTrue((paramBLOB2 != null) && (paramBLOB2.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 2020 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2023 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2024 */       localSQLException.fillInStackTrace();
/* 2025 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 2029 */     long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong);
/*      */     
/* 2031 */     l = l == 0L ? -1L : l;
/* 2032 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2049 */     byte[] arrayOfByte1 = null;
/* 2050 */     int i = 0;
/*      */     
/* 2052 */     checkTrue(this.lifecycle == 1, 8);
/* 2053 */     checkTrue((paramBLOB != null) && ((arrayOfByte1 = paramBLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 2056 */     if ((paramInt <= 0) || (paramArrayOfByte == null)) {
/* 2057 */       return 0;
/*      */     }
/* 2059 */     if (paramInt > paramArrayOfByte.length) {
/* 2060 */       paramInt = paramArrayOfByte.length;
/*      */     }
/* 2062 */     long l = -1L;
/*      */     byte[] arrayOfByte2;
/* 2064 */     int j; if (paramBLOB.isActivePrefetch())
/*      */     {
/* 2066 */       arrayOfByte2 = paramBLOB.getPrefetchedData();
/* 2067 */       l = paramBLOB.length();
/* 2068 */       if ((arrayOfByte2 != null) && (arrayOfByte2 != null) && (paramLong <= arrayOfByte2.length))
/*      */       {
/*      */ 
/* 2071 */         j = Math.min(arrayOfByte2.length - (int)paramLong + 1, paramInt);
/*      */         
/* 2073 */         System.arraycopy(arrayOfByte2, (int)paramLong - 1, paramArrayOfByte, 0, j);
/*      */         
/* 2075 */         i += j;
/*      */       }
/*      */     }
/*      */     
/* 2079 */     if ((i < paramInt) && ((l == -1L) || (paramLong - 1L + i < l)))
/*      */     {
/*      */ 
/*      */ 
/* 2083 */       arrayOfByte2 = paramArrayOfByte;
/* 2084 */       j = i;
/* 2085 */       int k = ((l > 0L) && (l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2087 */       if (i > 0)
/*      */       {
/* 2089 */         arrayOfByte2 = new byte[k];
/*      */       }
/*      */       
/* 2092 */       if (this.useNio)
/*      */       {
/* 2094 */         int m = paramArrayOfByte.length;
/* 2095 */         if ((this.nioBufferForLob == null) || (this.nioBufferForLob.capacity() < m))
/*      */         {
/* 2097 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2099 */           this.nioBufferForLob.rewind();
/*      */         }
/*      */       }
/* 2102 */       i += blobRead(arrayOfByte1, paramLong + i, k, arrayOfByte2, this.useNio, this.nioBufferForLob);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2108 */       if (this.useNio)
/*      */       {
/* 2110 */         this.nioBufferForLob.get(arrayOfByte2);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2115 */       if (j > 0)
/*      */       {
/* 2117 */         System.arraycopy(arrayOfByte2, 0, paramArrayOfByte, j, arrayOfByte2.length);
/*      */       }
/*      */     }
/*      */     
/* 2121 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2143 */     checkTrue((paramLong != 0L) || (paramInt2 > 0), 68);
/*      */     
/* 2145 */     checkTrue(paramLong >= 0L, 68);
/* 2146 */     if ((paramArrayOfByte == null) || (paramInt2 <= 0)) {
/* 2147 */       return 0;
/*      */     }
/* 2149 */     int i = 0;
/*      */     
/* 2151 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0) || (paramInt2 <= 0)) {
/* 2152 */       i = 0;
/*      */     }
/*      */     else {
/* 2155 */       byte[] arrayOfByte = null;
/*      */       
/* 2157 */       checkTrue(this.lifecycle == 1, 8);
/* 2158 */       checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */       
/*      */ 
/* 2161 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2163 */       paramBLOB.setActivePrefetch(false);
/* 2164 */       paramBLOB.clearCachedData();
/* 2165 */       i = blobWrite(arrayOfByte, paramLong, paramArrayOfByte, arrayOfByte1, paramInt1, paramInt2);
/*      */       
/*      */ 
/* 2168 */       paramBLOB.setLocator(arrayOfByte1[0]);
/*      */     }
/*      */     
/* 2171 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getChunkSize(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2183 */     byte[] arrayOfByte = null;
/*      */     
/* 2185 */     checkTrue(this.lifecycle == 1, 8);
/* 2186 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 2189 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2203 */     byte[] arrayOfByte = null;
/*      */     
/* 2205 */     checkTrue(this.lifecycle == 1, 8);
/* 2206 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2209 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2211 */     paramBLOB.setActivePrefetch(false);
/* 2212 */     paramBLOB.clearCachedData();
/* 2213 */     checkError(t2cLobTrim(this.m_nativeState, 113, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 2216 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2235 */     BLOB localBLOB = null;
/*      */     
/* 2237 */     checkTrue(this.lifecycle == 1, 8);
/*      */     
/* 2239 */     localBLOB = new BLOB((PhysicalConnection)paramConnection);
/*      */     
/* 2241 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2243 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 113, paramBoolean, paramInt, (short)0, arrayOfByte));
/*      */     
/*      */ 
/* 2246 */     localBLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 2248 */     return localBLOB;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2264 */       byte[] arrayOfByte = null;
/*      */       
/* 2266 */       checkTrue(this.lifecycle == 1, 8);
/* 2267 */       checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */       
/*      */ 
/* 2270 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2272 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */       
/*      */ 
/* 2275 */       paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */     }
/*      */     catch (SQLException localSQLException) {
/* 2278 */       if ((paramBoolean & localSQLException.getErrorCode() == 64201)) {
/* 2279 */         LobPlsqlUtil.freeTemporaryLob(this, paramBLOB, 2004);
/*      */       } else {
/* 2281 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isTemporary(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2297 */     byte[] arrayOfByte = null;
/*      */     
/* 2299 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2302 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2304 */     checkError(t2cLobIsTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/*      */ 
/* 2307 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2320 */     byte[] arrayOfByte = null;
/*      */     
/* 2322 */     checkTrue(this.lifecycle == 1, 8);
/* 2323 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2326 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2328 */     checkError(t2cLobOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */     
/*      */ 
/* 2331 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2344 */     byte[] arrayOfByte = null;
/*      */     
/* 2346 */     checkTrue(this.lifecycle == 1, 8);
/* 2347 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2350 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2352 */     checkError(t2cLobClose(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 2355 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isOpen(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2369 */     byte[] arrayOfByte = null;
/*      */     
/* 2371 */     checkTrue(this.lifecycle == 1, 8);
/* 2372 */     checkTrue((paramBLOB != null) && ((arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2375 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2377 */     checkError(t2cLobIsOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/*      */ 
/* 2380 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2399 */     if (paramLong == 0L)
/*      */     {
/* 2401 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 2405 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2)
/*      */     throws SQLException
/*      */   {
/* 2428 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2449 */     if (paramLong == 0L)
/*      */     {
/* 2451 */       if ((paramBoolean & this.lobStreamPosStandardCompliant))
/*      */       {
/*      */ 
/* 2454 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2455 */         localSQLException.fillInStackTrace();
/* 2456 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2461 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2466 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2487 */     checkTrue((paramBLOB != null) && (paramBLOB.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 2490 */     OracleConversionInputStream localOracleConversionInputStream = new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */     
/* 2492 */     return localOracleConversionInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2511 */     checkTrue((paramBLOB != null) && (paramBLOB.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 2514 */     OracleConversionReader localOracleConversionReader = new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */     
/* 2516 */     return localOracleConversionReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long length(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 2534 */     byte[] arrayOfByte = null;
/*      */     
/* 2536 */     checkTrue(this.lifecycle == 1, 8);
/* 2537 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 2540 */     return lobLength(arrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(CLOB paramCLOB, String paramString, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2558 */     if (paramString == null)
/*      */     {
/* 2560 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2561 */       ((SQLException)localObject).fillInStackTrace();
/* 2562 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 2565 */     checkTrue(this.lifecycle == 1, 8);
/* 2566 */     checkTrue((paramCLOB != null) && (paramCLOB.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 2569 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2572 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2573 */       ((SQLException)localObject).fillInStackTrace();
/* 2574 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 2578 */     Object localObject = new char[paramString.length()];
/*      */     
/* 2580 */     paramString.getChars(0, localObject.length, (char[])localObject, 0);
/*      */     
/* 2582 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, (char[])localObject, paramLong);
/*      */     
/* 2584 */     l = l == 0L ? -1L : l;
/* 2585 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2602 */     checkTrue(this.lifecycle == 1, 8);
/* 2603 */     checkTrue((paramCLOB1 != null) && (paramCLOB1.shareBytes() != null), 54);
/*      */     
/* 2605 */     checkTrue((paramCLOB2 != null) && (paramCLOB2.shareBytes() != null), 54);
/*      */     
/*      */ 
/* 2608 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2611 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2612 */       localSQLException.fillInStackTrace();
/* 2613 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 2617 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 2619 */     l = l == 0L ? -1L : l;
/* 2620 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfChar)
/*      */     throws SQLException
/*      */   {
/* 2637 */     byte[] arrayOfByte = null;
/*      */     
/* 2639 */     checkTrue(this.lifecycle == 1, 8);
/* 2640 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 2643 */     if ((paramInt <= 0) || (paramArrayOfChar == null)) {
/* 2644 */       return 0;
/*      */     }
/* 2646 */     if (paramInt > paramArrayOfChar.length) {
/* 2647 */       paramInt = paramArrayOfChar.length;
/*      */     }
/* 2649 */     int i = 0;
/*      */     
/*      */ 
/* 2652 */     long l = -1L;
/*      */     char[] arrayOfChar;
/*      */     int j;
/* 2655 */     if (paramCLOB.isActivePrefetch())
/*      */     {
/* 2657 */       l = paramCLOB.length();
/* 2658 */       arrayOfChar = paramCLOB.getPrefetchedData();
/* 2659 */       if ((arrayOfChar != null) && (paramLong <= arrayOfChar.length))
/*      */       {
/*      */ 
/* 2662 */         j = Math.min(arrayOfChar.length - (int)paramLong + 1, paramInt);
/*      */         
/*      */ 
/* 2665 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfChar, 0, j);
/*      */         
/* 2667 */         i += j;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2672 */     if ((i < paramInt) && ((l == -1L) || (paramLong - 1L + i < l)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2677 */       arrayOfChar = paramArrayOfChar;
/* 2678 */       j = i;
/* 2679 */       int k = ((l > 0L) && (l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2681 */       if (i > 0)
/*      */       {
/* 2683 */         arrayOfChar = new char[k];
/*      */       }
/*      */       
/* 2686 */       if (this.useNio)
/*      */       {
/*      */ 
/*      */ 
/* 2690 */         int m = paramArrayOfChar.length * 2;
/* 2691 */         if ((this.nioBufferForLob == null) || (this.nioBufferForLob.capacity() < m)) {
/* 2692 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2694 */           this.nioBufferForLob.rewind();
/*      */         }
/*      */       }
/* 2697 */       i += t2cClobRead(this.m_nativeState, arrayOfByte, arrayOfByte.length, paramLong + i, k, arrayOfChar, arrayOfChar.length, paramCLOB.isNCLOB(), this.useNio, this.nioBufferForLob);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2709 */       if (this.useNio)
/*      */       {
/* 2711 */         ByteBuffer localByteBuffer = this.nioBufferForLob.order(ByteOrder.LITTLE_ENDIAN);
/* 2712 */         CharBuffer localCharBuffer = localByteBuffer.asCharBuffer();
/* 2713 */         localCharBuffer.get(arrayOfChar);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2718 */       if (j > 0)
/*      */       {
/* 2720 */         System.arraycopy(arrayOfChar, 0, paramArrayOfChar, j, arrayOfChar.length);
/*      */       }
/*      */       
/* 2723 */       checkError(i);
/*      */     }
/*      */     
/* 2726 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2747 */     byte[] arrayOfByte = null;
/*      */     
/* 2749 */     checkTrue(this.lifecycle == 1, 8);
/* 2750 */     checkTrue(paramLong >= 0L, 68);
/*      */     
/* 2752 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 2755 */     if (paramArrayOfChar == null) {
/* 2756 */       return 0;
/*      */     }
/* 2758 */     byte[][] arrayOfByte1 = new byte[1][];
/* 2759 */     paramCLOB.setActivePrefetch(false);
/* 2760 */     paramCLOB.clearCachedData();
/* 2761 */     int i = clobWrite(arrayOfByte, paramLong, paramArrayOfChar, arrayOfByte1, paramCLOB.isNCLOB(), paramInt1, paramInt2);
/*      */     
/*      */ 
/* 2764 */     paramCLOB.setLocator(arrayOfByte1[0]);
/*      */     
/* 2766 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getChunkSize(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 2778 */     byte[] arrayOfByte = null;
/*      */     
/* 2780 */     checkTrue(this.lifecycle == 1, 8);
/* 2781 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */     
/*      */ 
/* 2784 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2798 */     byte[] arrayOfByte = null;
/*      */     
/* 2800 */     checkTrue(this.lifecycle == 1, 8);
/* 2801 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2804 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2806 */     paramCLOB.setActivePrefetch(false);
/* 2807 */     paramCLOB.clearCachedData();
/* 2808 */     checkError(t2cLobTrim(this.m_nativeState, 112, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 2811 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2831 */     Object localObject = null;
/*      */     
/* 2833 */     checkTrue(this.lifecycle == 1, 8);
/*      */     
/* 2835 */     if (paramShort == 1) {
/* 2836 */       localObject = new CLOB((PhysicalConnection)paramConnection);
/*      */     }
/*      */     else {
/* 2839 */       localObject = new NCLOB((PhysicalConnection)paramConnection);
/*      */     }
/*      */     
/* 2842 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2844 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 112, paramBoolean, paramInt, paramShort, arrayOfByte));
/*      */     
/*      */ 
/* 2847 */     ((CLOB)localObject).setShareBytes(arrayOfByte[0]);
/*      */     
/* 2849 */     return (CLOB)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2864 */       byte[] arrayOfByte = null;
/*      */       
/* 2866 */       checkTrue(this.lifecycle == 1, 8);
/* 2867 */       checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */       
/*      */ 
/* 2870 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2872 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */       
/*      */ 
/* 2875 */       paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */     }
/*      */     catch (SQLException localSQLException) {
/* 2878 */       if ((paramBoolean & localSQLException.getErrorCode() == 64201)) {
/* 2879 */         LobPlsqlUtil.freeTemporaryLob(this, paramCLOB, 2005);
/*      */       } else {
/* 2881 */         throw localSQLException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isTemporary(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 2898 */     byte[] arrayOfByte = null;
/*      */     
/* 2900 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2903 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2905 */     checkError(t2cLobIsTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/*      */ 
/* 2908 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2921 */     byte[] arrayOfByte = null;
/*      */     
/* 2923 */     checkTrue(this.lifecycle == 1, 8);
/* 2924 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2927 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2929 */     checkError(t2cLobOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */     
/*      */ 
/* 2932 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 2945 */     byte[] arrayOfByte = null;
/*      */     
/* 2947 */     checkTrue(this.lifecycle == 1, 8);
/* 2948 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2951 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2953 */     checkError(t2cLobClose(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */     
/*      */ 
/* 2956 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isOpen(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 2970 */     byte[] arrayOfByte = null;
/*      */     
/* 2972 */     checkTrue(this.lifecycle == 1, 8);
/* 2973 */     checkTrue((paramCLOB != null) && ((arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */     
/*      */ 
/* 2976 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2978 */     checkError(t2cLobIsOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/*      */ 
/* 2981 */     return arrayOfBoolean[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3001 */     if (paramLong == 0L)
/*      */     {
/* 3003 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 3007 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3028 */     if (paramLong == 0L)
/*      */     {
/* 3030 */       if ((paramBoolean & this.lobStreamPosStandardCompliant))
/*      */       {
/*      */ 
/* 3033 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3034 */         localSQLException.fillInStackTrace();
/* 3035 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3040 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3045 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3065 */     if (paramLong == 0L)
/*      */     {
/* 3067 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 3071 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2)
/*      */     throws SQLException
/*      */   {
/* 3092 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3112 */     if (paramLong == 0L)
/*      */     {
/* 3114 */       if ((paramBoolean & this.lobStreamPosStandardCompliant))
/*      */       {
/*      */ 
/* 3117 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3118 */         localSQLException.fillInStackTrace();
/* 3119 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3124 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3129 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 3156 */     this.appCallback = paramOracleOCIFailover;
/* 3157 */     this.appCallbackObject = paramObject;
/*      */     
/* 3159 */     checkError(t2cRegisterTAFCallback(this.m_nativeState));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized int callTAFCallbackMethod(int paramInt1, int paramInt2)
/*      */   {
/* 3169 */     int i = 0;
/*      */     
/*      */ 
/* 3172 */     if (this.appCallback != null) {
/* 3173 */       i = this.appCallback.callbackFn(this, this.appCallbackObject, paramInt1, paramInt2);
/*      */     }
/* 3175 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHeapAllocSize()
/*      */     throws SQLException
/*      */   {
/* 3189 */     if (this.lifecycle != 1)
/*      */     {
/* 3191 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3192 */       localSQLException1.fillInStackTrace();
/* 3193 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3198 */     int i = t2cGetHeapAllocSize(this.m_nativeState);
/*      */     
/* 3200 */     if (i < 0)
/*      */     {
/* 3202 */       if (i == 64537)
/*      */       {
/* 3204 */         localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3205 */         localSQLException2.fillInStackTrace();
/* 3206 */         throw localSQLException2;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3212 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3213 */       localSQLException2.fillInStackTrace();
/* 3214 */       throw localSQLException2;
/*      */     }
/*      */     
/*      */ 
/* 3218 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOCIEnvHeapAllocSize()
/*      */     throws SQLException
/*      */   {
/* 3231 */     if (this.lifecycle != 1)
/*      */     {
/* 3233 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3234 */       localSQLException1.fillInStackTrace();
/* 3235 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3240 */     int i = t2cGetOciEnvHeapAllocSize(this.m_nativeState);
/*      */     
/* 3242 */     if (i < 0)
/*      */     {
/* 3244 */       if (i == 64537)
/*      */       {
/* 3246 */         localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3247 */         localSQLException2.fillInStackTrace();
/* 3248 */         throw localSQLException2;
/*      */       }
/*      */       
/* 3251 */       checkError(i);
/*      */       
/*      */ 
/*      */ 
/* 3255 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3256 */       localSQLException2.fillInStackTrace();
/* 3257 */       throw localSQLException2;
/*      */     }
/*      */     
/*      */ 
/* 3261 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final short getClientCharSetId()
/*      */   {
/* 3270 */     return 871;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static short getDriverCharSetIdFromNLS_LANG(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3286 */     if (!isLibraryLoaded) {
/* 3287 */       loadNativeLibrary(paramString);
/*      */     }
/*      */     
/* 3290 */     short s = t2cGetDriverCharSetFromNlsLang();
/*      */     
/*      */ 
/* 3293 */     if (s < 0)
/*      */     {
/* 3295 */       SQLException localSQLException = DatabaseError.createSqlException(null, 8);
/* 3296 */       localSQLException.fillInStackTrace();
/* 3297 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 3301 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doProxySession(int paramInt, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/* 3314 */     byte[][] arrayOfByte = (byte[][])null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3320 */     int i = 0;
/*      */     
/* 3322 */     this.savedUser = this.userName;
/* 3323 */     this.userName = null;
/*      */     byte[] arrayOfByte4;
/* 3325 */     byte[] arrayOfByte3; byte[] arrayOfByte2; byte[] arrayOfByte1 = arrayOfByte2 = arrayOfByte3 = arrayOfByte4 = new byte[0];
/*      */     
/* 3327 */     switch (paramInt)
/*      */     {
/*      */     case 1: 
/* 3330 */       this.userName = paramProperties.getProperty("PROXY_USER_NAME");
/* 3331 */       String str1 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/* 3332 */       if (this.userName != null) {
/* 3333 */         arrayOfByte1 = DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */       }
/* 3335 */       if (str1 != null)
/* 3336 */         arrayOfByte2 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet);
/*      */       break;
/*      */     case 2: 
/* 3339 */       String str2 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/* 3340 */       if (str2 != null) {
/* 3341 */         arrayOfByte3 = DBConversion.stringToDriverCharBytes(str2, this.m_clientCharacterSet);
/*      */       }
/*      */       break;
/*      */     case 3: 
/* 3345 */       Object localObject = paramProperties.get("PROXY_CERTIFICATE");
/* 3346 */       arrayOfByte4 = (byte[])localObject;
/*      */     }
/*      */     
/* 3349 */     String[] arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     
/* 3351 */     if (arrayOfString != null)
/*      */     {
/* 3353 */       i = arrayOfString.length;
/* 3354 */       arrayOfByte = new byte[i][];
/* 3355 */       for (int j = 0; j < i; j++)
/*      */       {
/* 3357 */         if (arrayOfString[j] == null)
/*      */         {
/* 3359 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/* 3360 */           localSQLException.fillInStackTrace();
/* 3361 */           throw localSQLException;
/*      */         }
/*      */         
/* 3364 */         arrayOfByte[j] = DBConversion.stringToDriverCharBytes(arrayOfString[j], this.m_clientCharacterSet);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3369 */     this.sqlWarning = checkError(t2cDoProxySession(this.m_nativeState, paramInt, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, i, arrayOfByte), this.sqlWarning);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3383 */     this.isProxy = true;
/*      */   }
/*      */   
/*      */ 
/*      */   void closeProxySession()
/*      */     throws SQLException
/*      */   {
/* 3390 */     checkError(t2cCloseProxySession(this.m_nativeState));
/* 3391 */     this.userName = this.savedUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo)
/*      */     throws SQLException
/*      */   {
/* 3399 */     String str = paramAutoKeyInfo.getTableName();
/*      */     
/* 3401 */     byte[] arrayOfByte = DBConversion.stringToDriverCharBytes(str, this.m_clientCharacterSet);
/*      */     
/*      */     int i;
/*      */     
/*      */     int j;
/*      */     
/*      */     do
/*      */     {
/* 3409 */       i = 0;
/* 3410 */       j = t2cDescribeTable(this.m_nativeState, arrayOfByte, arrayOfByte.length, this.queryMetaData1, this.queryMetaData2, this.queryMetaData1Offset, this.queryMetaData2Offset, this.queryMetaData1Size, this.queryMetaData2Size);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3420 */       if (j == -1)
/*      */       {
/* 3422 */         checkError(j);
/*      */       }
/*      */       
/*      */ 
/* 3426 */       if (j == T2CStatement.T2C_EXTEND_BUFFER)
/*      */       {
/* 3428 */         i = 1;
/*      */         
/* 3430 */         reallocateQueryMetaData(this.queryMetaData1Size * 2, this.queryMetaData2Size * 2);
/*      */       }
/*      */       
/* 3433 */     } while (i != 0);
/*      */     
/* 3435 */     processDescribeTableData(j, paramAutoKeyInfo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processDescribeTableData(int paramInt, AutoKeyInfo paramAutoKeyInfo)
/*      */     throws SQLException
/*      */   {
/* 3444 */     short[] arrayOfShort = this.queryMetaData1;
/* 3445 */     byte[] arrayOfByte = this.queryMetaData2;
/* 3446 */     int i = this.queryMetaData1Offset;
/* 3447 */     int j = this.queryMetaData2Offset;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3461 */     paramAutoKeyInfo.allocateSpaceForDescribedData(paramInt);
/*      */     
/* 3463 */     for (int i5 = 0; i5 < paramInt; i5++)
/*      */     {
/* 3465 */       int m = arrayOfShort[(i + 0)];
/* 3466 */       int k = arrayOfShort[(i + 6)];
/* 3467 */       String str1 = bytes2String(arrayOfByte, j, k, this.conversion);
/*      */       
/*      */ 
/* 3470 */       int n = arrayOfShort[(i + 1)];
/* 3471 */       int i1 = arrayOfShort[(i + 11)];
/* 3472 */       boolean bool = arrayOfShort[(i + 2)] != 0;
/* 3473 */       short s = arrayOfShort[(i + 5)];
/* 3474 */       int i2 = arrayOfShort[(i + 3)];
/* 3475 */       int i3 = arrayOfShort[(i + 4)];
/* 3476 */       int i4 = arrayOfShort[(i + 12)];
/*      */       
/* 3478 */       j += k;
/* 3479 */       i += 13;
/*      */       
/* 3481 */       String str2 = null;
/* 3482 */       if (i4 > 0)
/*      */       {
/* 3484 */         str2 = bytes2String(arrayOfByte, j, i4, this.conversion);
/*      */         
/* 3486 */         j += i4;
/*      */       }
/*      */       
/*      */ 
/* 3490 */       paramAutoKeyInfo.fillDescribedData(i5, str1, m, i1 > 0 ? i1 : n, bool, s, i2, i3, str2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLException
/*      */   {
/* 3504 */     checkError(t2cSetApplicationContext(this.m_nativeState, paramString1, paramString2, paramString3));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClearAllApplicationContext(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3513 */     checkError(t2cClearAllApplicationContext(this.m_nativeState, paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void doStartup(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3521 */     checkError(t2cStartupDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void doShutdown(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3529 */     checkError(t2cShutdownDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final void loadNativeLibrary(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3541 */     if ((paramString == null) || (paramString.equals("ocijdbc11")))
/*      */     {
/* 3543 */       synchronized (T2CConnection.class)
/*      */       {
/* 3545 */         if (!isLibraryLoaded)
/*      */         {
/* 3547 */           AccessController.doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public Object run()
/*      */             {
/* 3551 */               System.loadLibrary("ocijdbc11");
/* 3552 */               int i = T2CConnection.getLibraryVersionNumber();
/* 3553 */               if (i != T2CConnection.JDBC_OCI_LIBRARY_VERSION) {
/* 3554 */                 throw new Error("Incompatible version of libocijdbc[Jdbc:" + T2CConnection.JDBC_OCI_LIBRARY_VERSION + ", Jdbc-OCI:" + i);
/*      */               }
/*      */               
/* 3557 */               return null;
/*      */             }
/* 3559 */           });
/* 3560 */           isLibraryLoaded = true;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */     }
/*      */     else {
/* 3567 */       synchronized (T2CConnection.class)
/*      */       {
/*      */         try
/*      */         {
/* 3571 */           System.loadLibrary(paramString);
/* 3572 */           isLibraryLoaded = true;
/*      */         }
/*      */         catch (SecurityException localSecurityException)
/*      */         {
/* 3576 */           if (!isLibraryLoaded)
/*      */           {
/* 3578 */             System.loadLibrary(paramString);
/* 3579 */             isLibraryLoaded = true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void checkTrue(boolean paramBoolean, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3592 */     if (!paramBoolean)
/*      */     {
/* 3594 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/* 3595 */       localSQLException.fillInStackTrace();
/* 3596 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   boolean useLittleEndianSetCHARBinder()
/*      */     throws SQLException
/*      */   {
/* 3604 */     return t2cPlatformIsLittleEndian(this.m_nativeState);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 3612 */     super.getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final char[] getCharArray(String paramString)
/*      */   {
/* 3619 */     char[] arrayOfChar = null;
/*      */     
/* 3621 */     if (paramString == null)
/*      */     {
/* 3623 */       arrayOfChar = new char[0];
/*      */     }
/*      */     else
/*      */     {
/* 3627 */       arrayOfChar = new char[paramString.length()];
/*      */       
/* 3629 */       paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*      */     }
/*      */     
/* 3632 */     return arrayOfChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String bytes2String(byte[] paramArrayOfByte, int paramInt1, int paramInt2, DBConversion paramDBConversion)
/*      */     throws SQLException
/*      */   {
/* 3642 */     byte[] arrayOfByte = new byte[paramInt2];
/* 3643 */     System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/* 3645 */     return paramDBConversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void disableNio()
/*      */   {
/* 3653 */     this.useNio = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static synchronized void doSetSessionTimeZone(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3661 */     t2cSetSessionTimeZone(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static native int getLibraryVersionNumber();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static native short t2cGetServerSessionInfo(long paramLong, Properties paramProperties);
/*      */   
/*      */ 
/*      */ 
/*      */   static native short t2cGetDriverCharSetFromNlsLang();
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cDescribeError(long paramLong, T2CError paramT2CError, byte[] paramArrayOfByte);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cCreateState(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3, byte[] paramArrayOfByte4, int paramInt4, byte[] paramArrayOfByte5, int paramInt5, byte[] paramArrayOfByte6, int paramInt6, byte[] paramArrayOfByte7, int paramInt7, short paramShort, int paramInt8, short[] paramArrayOfShort, byte[] paramArrayOfByte8, byte[] paramArrayOfByte9, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cLogon(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3, byte[] paramArrayOfByte4, int paramInt4, byte[] paramArrayOfByte5, int paramInt5, byte[] paramArrayOfByte6, int paramInt6, byte[] paramArrayOfByte7, int paramInt7, int paramInt8, short[] paramArrayOfShort, byte[] paramArrayOfByte8, byte[] paramArrayOfByte9, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cLogoff(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cCancel(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native byte t2cGetAsmVolProperty(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native byte t2cGetInstanceType(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cCreateStatement(long paramLong1, long paramLong2, byte[] paramArrayOfByte, int paramInt1, OracleStatement paramOracleStatement, boolean paramBoolean, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cSetAutoCommit(long paramLong, boolean paramBoolean);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cCommit(long paramLong, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cRollback(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cPingDatabase(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native byte[] t2cGetProductionVersion(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cGetVersionNumber(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   private native int t2cGetDefaultStreamChunkSize(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cGetFormOfUse(long paramLong, OracleTypeCLOB paramOracleTypeCLOB, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   native long t2cGetTDO(long paramLong, byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cCreateConnPool(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3, short paramShort, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cConnPoolLogon(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3, byte[] paramArrayOfByte4, int paramInt4, byte[] paramArrayOfByte5, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String[] paramArrayOfString, byte[] paramArrayOfByte6, int paramInt9, byte[] paramArrayOfByte7, int paramInt10, byte[] paramArrayOfByte8, int paramInt11, byte[] paramArrayOfByte9, int paramInt12, byte[] paramArrayOfByte10, int paramInt13, short[] paramArrayOfShort, byte[] paramArrayOfByte11, byte[] paramArrayOfByte12, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cGetConnPoolInfo(long paramLong, Properties paramProperties);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cSetConnPoolInfo(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cPasswordChange(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3);
/*      */   
/*      */ 
/*      */ 
/*      */   protected native byte[] t2cGetConnectionId(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cGetHandles(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cUseConnection(long paramLong1, long paramLong2, long paramLong3, long paramLong4, short[] paramArrayOfShort, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native boolean t2cPlatformIsLittleEndian(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cRegisterTAFCallback(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cGetHeapAllocSize(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cGetOciEnvHeapAllocSize(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cDoProxySession(long paramLong, int paramInt1, byte[] paramArrayOfByte1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, byte[] paramArrayOfByte3, int paramInt4, byte[] paramArrayOfByte4, int paramInt5, int paramInt6, byte[][] paramArrayOfByte);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cCloseProxySession(long paramLong);
/*      */   
/*      */ 
/*      */ 
/*      */   static native int t2cDescribeTable(long paramLong, byte[] paramArrayOfByte1, int paramInt1, short[] paramArrayOfShort, byte[] paramArrayOfByte2, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cSetApplicationContext(long paramLong, String paramString1, String paramString2, String paramString3);
/*      */   
/*      */ 
/*      */ 
/*      */   native int t2cClearAllApplicationContext(long paramLong, String paramString);
/*      */   
/*      */ 
/*      */   native int t2cStartupDatabase(long paramLong, int paramInt);
/*      */   
/*      */ 
/*      */   native int t2cShutdownDatabase(long paramLong, int paramInt);
/*      */   
/*      */ 
/*      */   static native void t2cSetSessionTimeZone(String paramString);
/*      */   
/*      */ 
/*      */   public void incrementTempLobReferenceCount(byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/* 3830 */   public int decrementTempLobReferenceCount(byte[] paramArrayOfByte)
/* 3830 */     throws SQLException { return 0; }
/*      */   
/* 3832 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T2CConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */