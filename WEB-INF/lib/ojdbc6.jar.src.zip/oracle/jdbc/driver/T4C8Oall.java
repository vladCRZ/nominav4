/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4C8Oall
/*      */   extends T4CTTIfun
/*      */ {
/*  124 */   Vector<IOException> nonFatalIOExceptions = null;
/*      */   
/*  126 */   static final byte[] EMPTY_BYTES = new byte[0];
/*      */   
/*      */ 
/*      */   static final int UOPF_PRS = 1;
/*      */   
/*      */ 
/*      */   static final int UOPF_BND = 8;
/*      */   
/*      */   static final int UOPF_EXE = 32;
/*      */   
/*      */   static final int UOPF_FEX = 512;
/*      */   
/*      */   static final int UOPF_FCH = 64;
/*      */   
/*      */   static final int UOPF_CAN = 128;
/*      */   
/*      */   static final int UOPF_COM = 256;
/*      */   
/*      */   static final int UOPF_DSY = 8192;
/*      */   
/*      */   static final int UOPF_SIO = 1024;
/*      */   
/*      */   static final int UOPF_NPL = 32768;
/*      */   
/*      */   static final int UOPF_DFN = 16;
/*      */   
/*      */   static final int EXE_COMMIT_ON_SUCCESS = 1;
/*      */   
/*      */   static final int EXE_LEAVE_CUR_MAPPED = 2;
/*      */   
/*      */   static final int EXE_BATCH_DML_ERRORS = 4;
/*      */   
/*      */   static final int EXE_SCROL_READ_ONLY = 8;
/*      */   
/*      */   static final int AL8KW_MAXLANG = 63;
/*      */   
/*      */   static final int AL8KW_TIMEZONE = 163;
/*      */   
/*      */   static final int AL8KW_ERR_OVLAP = 164;
/*      */   
/*      */   static final int AL8KW_SESSION_ID = 165;
/*      */   
/*      */   static final int AL8KW_SERIAL_NUM = 166;
/*      */   
/*      */   static final int AL8KW_TAG_FOUND = 167;
/*      */   
/*      */   static final int AL8KW_SCHEMA_NAME = 168;
/*      */   
/*      */   static final int AL8KW_SCHEMA_ID = 169;
/*      */   
/*      */   static final int AL8KW_ENABLED_ROLES = 170;
/*      */   
/*      */   static final int AL8KW_AUX_SESSSTATE = 171;
/*      */   
/*  180 */   static final String[] NLS_KEYS = { "AUTH_NLS_LXCCURRENCY", "AUTH_NLS_LXCISOCURR", "AUTH_NLS_LXCNUMERICS", null, null, null, null, "AUTH_NLS_LXCDATEFM", "AUTH_NLS_LXCDATELANG", "AUTH_NLS_LXCTERRITORY", "SESSION_NLS_LXCCHARSET", "AUTH_NLS_LXCSORT", "AUTH_NLS_LXCCALENDAR", null, null, null, "AUTH_NLS_LXLAN", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "AUTH_NLS_LXCSORT", null, "AUTH_NLS_LXCUNIONCUR", null, null, null, null, "AUTH_NLS_LXCTIMEFM", "AUTH_NLS_LXCSTMPFM", "AUTH_NLS_LXCTTZNFM", "AUTH_NLS_LXCSTZNFM", "SESSION_NLS_LXCNLSLENSEM", "SESSION_NLS_LXCNCHAREXCP", "SESSION_NLS_LXCNCHARIMP" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDIREGIDFLAG = 120;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDIREGIDSET = 181;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDIMAXTIMEFIELD = 60;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int rowsProcessed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int numberOfDefinePositions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long options;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int cursor;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */   byte[] sqlStmt = new byte[0];
/*  268 */   final long[] al8i4 = new long[13];
/*      */   
/*      */ 
/*  271 */   boolean plsql = false;
/*      */   
/*      */ 
/*      */   Accessor[] definesAccessors;
/*      */   
/*      */ 
/*      */   int definesLength;
/*      */   
/*      */ 
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */ 
/*      */   int numberOfBindPositions;
/*      */   
/*      */ 
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   byte[][][] parameterDatum;
/*      */   
/*      */   OracleTypeADT[][] parameterOtype;
/*      */   
/*      */   short[] bindIndicators;
/*      */   
/*      */   byte[] bindBytes;
/*      */   
/*      */   char[] bindChars;
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */   
/*      */   byte[] tmpBindsByteArray;
/*      */   
/*      */   DBConversion conversion;
/*      */   
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */   char[] ibtBindChars;
/*      */   
/*      */   short[] ibtBindIndicators;
/*      */   
/*  310 */   boolean sendBindsDefinition = false;
/*      */   
/*      */   OracleStatement oracleStatement;
/*      */   
/*      */   short dbCharSet;
/*      */   
/*      */   short NCharSet;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4C8TTIrxh rxh;
/*      */   
/*      */   T4CTTIdcb dcb;
/*      */   
/*      */   OracleStatement.SqlKind typeOfStatement;
/*  325 */   int defCols = 0;
/*      */   
/*      */ 
/*      */   int rowsToFetch;
/*      */   
/*      */ 
/*  331 */   boolean aFetchWasDone = false;
/*      */   
/*      */   T4CTTIoac[] oacdefBindsSent;
/*      */   
/*      */   T4CTTIoac[] oacdefDefines;
/*      */   
/*      */   int[] definedColumnSize;
/*      */   
/*      */   int[] definedColumnType;
/*      */   
/*      */   int[] definedColumnFormOfUse;
/*  342 */   NTFDCNRegistration registration = null;
/*      */   
/*      */   static final int AL8TXCUR = 1;
/*      */   
/*      */   static final int AL8TXDON = 2;
/*      */   static final int AL8TXRON = 4;
/*      */   
/*      */   T4C8Oall(T4CConnection paramT4CConnection)
/*      */   {
/*  351 */     super(paramT4CConnection, (byte)3);
/*      */     
/*  353 */     setFunCode((short)94);
/*  354 */     this.rxh = new T4C8TTIrxh(paramT4CConnection);
/*  355 */     this.rxd = new T4CTTIrxd(paramT4CConnection);
/*  356 */     this.dcb = new T4CTTIdcb(paramT4CConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOALL(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, OracleStatement.SqlKind paramSqlKind, int paramInt1, byte[] paramArrayOfByte1, int paramInt2, Accessor[] paramArrayOfAccessor1, int paramInt3, Accessor[] paramArrayOfAccessor2, int paramInt4, byte[] paramArrayOfByte2, char[] paramArrayOfChar1, short[] paramArrayOfShort1, int paramInt5, DBConversion paramDBConversion, byte[] paramArrayOfByte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfByte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfByte4, char[] paramArrayOfChar2, short[] paramArrayOfShort2, T4CTTIoac[] paramArrayOfT4CTTIoac, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, NTFDCNRegistration paramNTFDCNRegistration)
/*      */     throws SQLException, IOException
/*      */   {
/*  381 */     this.typeOfStatement = paramSqlKind;
/*  382 */     this.cursor = paramInt1;
/*  383 */     this.sqlStmt = (paramBoolean1 ? paramArrayOfByte1 : EMPTY_BYTES);
/*  384 */     this.rowsToFetch = paramInt2;
/*  385 */     this.outBindAccessors = paramArrayOfAccessor1;
/*  386 */     this.numberOfBindPositions = paramInt3;
/*  387 */     this.definesAccessors = paramArrayOfAccessor2;
/*  388 */     this.definesLength = paramInt4;
/*  389 */     this.bindBytes = paramArrayOfByte2;
/*  390 */     this.bindChars = paramArrayOfChar1;
/*  391 */     this.bindIndicators = paramArrayOfShort1;
/*  392 */     this.bindIndicatorSubRange = paramInt5;
/*  393 */     this.conversion = paramDBConversion;
/*  394 */     this.tmpBindsByteArray = paramArrayOfByte3;
/*  395 */     this.parameterStream = paramArrayOfInputStream;
/*  396 */     this.parameterDatum = paramArrayOfByte;
/*  397 */     this.parameterOtype = paramArrayOfOracleTypeADT;
/*  398 */     this.oracleStatement = paramOracleStatement;
/*  399 */     this.ibtBindBytes = paramArrayOfByte4;
/*  400 */     this.ibtBindChars = paramArrayOfChar2;
/*  401 */     this.ibtBindIndicators = paramArrayOfShort2;
/*  402 */     this.oacdefBindsSent = paramArrayOfT4CTTIoac;
/*  403 */     this.definedColumnType = paramArrayOfInt1;
/*  404 */     this.definedColumnSize = paramArrayOfInt2;
/*  405 */     this.definedColumnFormOfUse = paramArrayOfInt3;
/*  406 */     this.registration = paramNTFDCNRegistration;
/*      */     
/*      */ 
/*  409 */     this.dbCharSet = paramDBConversion.getServerCharSetId();
/*  410 */     this.NCharSet = paramDBConversion.getNCharSetId();
/*      */     
/*      */ 
/*  413 */     int i = 0;
/*  414 */     if (this.bindIndicators != null) {
/*  415 */       i = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */     }
/*      */     
/*      */     SQLException localSQLException1;
/*  419 */     if (paramArrayOfByte1 == null)
/*      */     {
/*      */ 
/*  422 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 431);
/*  423 */       localSQLException1.fillInStackTrace();
/*  424 */       throw localSQLException1;
/*      */     }
/*      */     
/*  427 */     if ((!this.typeOfStatement.isDML()) && (i > 1))
/*      */     {
/*      */ 
/*      */ 
/*  431 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
/*  432 */       localSQLException1.fillInStackTrace();
/*  433 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  438 */     this.rowsProcessed = 0;
/*  439 */     this.options = 0L;
/*  440 */     this.plsql = this.typeOfStatement.isPlsqlOrCall();
/*  441 */     this.sendBindsDefinition = false;
/*      */     
/*      */ 
/*  444 */     if (this.receiveState != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  449 */       this.receiveState = 0;
/*      */     }
/*      */     
/*  452 */     this.rxh.init();
/*  453 */     this.rxd.init();
/*  454 */     this.oer.init();
/*      */     
/*      */ 
/*  457 */     if (paramBoolean5) {
/*  458 */       initDefinesDefinition();
/*      */     }
/*  460 */     if ((this.numberOfBindPositions > 0) && (this.bindIndicators != null))
/*      */     {
/*  462 */       if (this.oacdefBindsSent == null)
/*  463 */         this.oacdefBindsSent = new T4CTTIoac[this.numberOfBindPositions];
/*  464 */       this.sendBindsDefinition = initBindsDefinition(this.oacdefBindsSent);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  474 */     this.options = setOptions(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean5);
/*      */     
/*  476 */     if ((this.options & 1L) > 0L) {
/*  477 */       this.al8i4[0] = 1L;
/*      */     } else {
/*  479 */       this.al8i4[0] = 0L;
/*      */     }
/*      */     
/*  482 */     if ((this.plsql) || (this.typeOfStatement.isOTHER())) {
/*  483 */       this.al8i4[1] = 1L;
/*  484 */     } else if (paramBoolean4)
/*      */     {
/*  486 */       if ((paramBoolean3) && (this.oracleStatement.connection.useFetchSizeWithLongColumn)) {
/*  487 */         this.al8i4[1] = this.rowsToFetch;
/*      */       } else {
/*  489 */         this.al8i4[1] = 0L;
/*      */       }
/*  491 */     } else if (this.typeOfStatement.isDML())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  497 */       this.al8i4[1] = (i == 0 ? this.oracleStatement.batch : i);
/*      */     }
/*  499 */     else if ((paramBoolean3) && (!paramBoolean4))
/*      */     {
/*  501 */       this.al8i4[1] = this.rowsToFetch;
/*      */     } else {
/*  503 */       this.al8i4[1] = 0L;
/*      */     }
/*      */     
/*  506 */     if (this.typeOfStatement.isSELECT()) {
/*  507 */       this.al8i4[7] = 1L;
/*      */     } else {
/*  509 */       this.al8i4[7] = 0L;
/*      */     }
/*  511 */     long l = this.oracleStatement.inScn;
/*  512 */     int j = (int)l;
/*  513 */     int k = (int)(l >> 32);
/*  514 */     this.al8i4[5] = j;
/*  515 */     this.al8i4[6] = k;
/*      */     
/*  517 */     this.rowsProcessed = 0;
/*  518 */     this.aFetchWasDone = false;
/*      */     
/*      */ 
/*  521 */     this.rxd.setNumberOfColumns(this.definesLength);
/*      */     
/*  523 */     if (((this.options & 0x40) != 0L) && ((this.options & 0x20) == 0L) && ((this.options & 1L) == 0L) && ((this.options & 0x8) == 0L) && ((this.options & 0x10) == 0L) && (!this.oracleStatement.needToSendOalToFetch))
/*      */     {
/*      */ 
/*  526 */       setFunCode((short)5);
/*      */     } else {
/*  528 */       setFunCode((short)94);
/*      */     }
/*  530 */     this.nonFatalIOExceptions = null;
/*  531 */     doRPC();
/*      */     
/*      */ 
/*      */ 
/*  535 */     if ((this.options & 0x20) != 0L) {
/*  536 */       this.oracleStatement.inScn = 0L;
/*      */     }
/*      */     
/*  539 */     this.ibtBindIndicators = null;
/*  540 */     this.ibtBindChars = null;
/*  541 */     this.ibtBindBytes = null;
/*  542 */     this.tmpBindsByteArray = null;
/*  543 */     this.outBindAccessors = null;
/*  544 */     this.bindBytes = null;
/*  545 */     this.bindChars = null;
/*  546 */     this.bindIndicators = null;
/*  547 */     this.oracleStatement = null;
/*      */     
/*  549 */     if (this.nonFatalIOExceptions != null)
/*      */     {
/*  551 */       IOException localIOException = (IOException)this.nonFatalIOExceptions.get(0);
/*      */       try
/*      */       {
/*  554 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
/*  555 */         localSQLException2.fillInStackTrace();
/*  556 */         throw localSQLException2;
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (SQLException localSQLException3)
/*      */       {
/*      */ 
/*      */ 
/*  564 */         localSQLException3.initCause(localIOException);
/*  565 */         throw localSQLException3;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readBVC()
/*      */     throws IOException, SQLException
/*      */   {
/*  579 */     int i = this.meg.unmarshalUB2();
/*      */     
/*      */ 
/*  582 */     this.rxd.unmarshalBVC(i);
/*      */   }
/*      */   
/*      */ 
/*      */   void readIOV()
/*      */     throws IOException, SQLException
/*      */   {
/*  589 */     T4CTTIiov localT4CTTIiov = new T4CTTIiov(this.connection, this.rxh, this.rxd);
/*      */     
/*  591 */     localT4CTTIiov.init();
/*  592 */     localT4CTTIiov.unmarshalV10();
/*      */     
/*      */ 
/*  595 */     if ((this.oracleStatement.returnParamAccessors == null) && (!localT4CTTIiov.isIOVectorEmpty()))
/*      */     {
/*      */ 
/*  598 */       byte[] arrayOfByte = localT4CTTIiov.getIOVector();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  603 */       this.outBindAccessors = localT4CTTIiov.processRXD(this.outBindAccessors, this.numberOfBindPositions, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.conversion, this.tmpBindsByteArray, arrayOfByte, this.parameterStream, this.parameterDatum, this.parameterOtype, this.oracleStatement, null, null, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readRXH()
/*      */     throws IOException, SQLException
/*      */   {
/*  619 */     this.rxh.init();
/*  620 */     this.rxh.unmarshalV10(this.rxd);
/*      */     SQLException localSQLException1;
/*  622 */     if (this.rxh.uacBufLength > 0)
/*      */     {
/*      */ 
/*  625 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 405);
/*  626 */       localSQLException1.fillInStackTrace();
/*  627 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*  631 */     if ((this.rxh.rxhflg & 0x8) == 8)
/*      */     {
/*      */ 
/*      */ 
/*  635 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 449);
/*  636 */       localSQLException1.fillInStackTrace();
/*  637 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*  641 */     if ((this.rxh.rxhflg & 0x10) == 16)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  647 */       for (int i = 0; i < this.definesAccessors.length; i++)
/*      */       {
/*  649 */         if ((this.definesAccessors[i].udskpos >= 0) && (this.definesAccessors[i].udskpos != i))
/*      */         {
/*      */ 
/*  652 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 450);
/*  653 */           localSQLException2.fillInStackTrace();
/*  654 */           throw localSQLException2;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean readRXD()
/*      */     throws IOException, SQLException
/*      */   {
/*  670 */     this.aFetchWasDone = true;
/*      */     
/*      */ 
/*  673 */     if ((this.oracleStatement.returnParamAccessors != null) && (this.numberOfBindPositions > 0))
/*      */     {
/*      */ 
/*  676 */       int i = 0;
/*  677 */       for (int j = 0; j < this.oracleStatement.numberOfBindPositions; j++)
/*      */       {
/*  679 */         Accessor localAccessor = this.oracleStatement.returnParamAccessors[j];
/*  680 */         if (localAccessor != null)
/*      */         {
/*  682 */           int k = (int)this.meg.unmarshalUB4();
/*  683 */           if (i == 0)
/*      */           {
/*  685 */             this.oracleStatement.rowsDmlReturned = k;
/*  686 */             this.oracleStatement.allocateDmlReturnStorage();
/*  687 */             this.oracleStatement.setupReturnParamAccessors();
/*  688 */             i = 1;
/*      */           }
/*      */           
/*  691 */           for (int m = 0; m < k; m++)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  696 */             localAccessor.unmarshalOneRow(); }
/*      */         }
/*      */       }
/*  699 */       this.oracleStatement.returnParamsFetched = true;
/*      */ 
/*      */     }
/*  702 */     else if ((this.iovProcessed) || ((this.outBindAccessors != null) && (this.definesAccessors == null)))
/*      */     {
/*      */ 
/*      */ 
/*  706 */       if (this.rxd.unmarshal(this.outBindAccessors, this.numberOfBindPositions))
/*      */       {
/*  708 */         return true;
/*      */       }
/*      */       
/*      */     }
/*  712 */     else if (this.rxd.unmarshal(this.definesAccessors, this.definesLength))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  718 */       return true;
/*      */     }
/*      */     
/*  721 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readRPA()
/*      */     throws IOException, SQLException
/*      */   {
/*  747 */     int i = this.meg.unmarshalUB2();
/*  748 */     int[] arrayOfInt = new int[i];
/*      */     
/*  750 */     for (int j = 0; j < i; j++) {
/*  751 */       arrayOfInt[j] = ((int)this.meg.unmarshalUB4());
/*      */     }
/*  753 */     j = arrayOfInt[0];
/*  754 */     int k = arrayOfInt[1];
/*  755 */     long l1 = j & 0xFFFFFFFF | (k & 0xFFFFFFFF) << 32;
/*      */     
/*      */ 
/*  758 */     if (l1 != 0L) {
/*  759 */       this.oracleStatement.connection.outScn = l1;
/*      */     }
/*      */     
/*      */ 
/*  763 */     this.cursor = arrayOfInt[2];
/*      */     
/*      */ 
/*  766 */     int m = this.meg.unmarshalUB2();
/*      */     
/*  768 */     byte[] arrayOfByte1 = null;
/*  769 */     if (m > 0) {
/*  770 */       arrayOfByte1 = this.meg.unmarshalNBytes(m);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  779 */     int n = this.meg.unmarshalUB2();
/*      */     
/*  781 */     KeywordValue[] arrayOfKeywordValue = new KeywordValue[n];
/*  782 */     for (String str1 = 0; str1 < n; str1++) {
/*  783 */       arrayOfKeywordValue[str1] = KeywordValueI.unmarshal(this.meg);
/*      */     }
/*  785 */     this.connection.updateSessionProperties(arrayOfKeywordValue);
/*      */     
/*      */ 
/*  788 */     this.oracleStatement.dcnQueryId = -1L;
/*  789 */     this.oracleStatement.dcnTableName = null;
/*  790 */     if (this.connection.getTTCVersion() >= 4)
/*      */     {
/*  792 */       str1 = (int)this.meg.unmarshalUB4();
/*  793 */       byte[] arrayOfByte2 = this.meg.unmarshalNBytes(str1);
/*  794 */       if ((str1 > 0) && (this.registration != null))
/*      */       {
/*  796 */         int i1 = 0;
/*  797 */         Properties localProperties = this.registration.getRegistrationOptions();
/*  798 */         if (localProperties != null)
/*      */         {
/*  800 */           str2 = localProperties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION");
/*  801 */           if ((str2 != null) && (str2.compareToIgnoreCase("true") == 0))
/*  802 */             i1 = 1;
/*      */         }
/*  804 */         String str2 = str1;
/*  805 */         int i2; if (i1 != 0) {
/*  806 */           i2 = str1 - 8;
/*      */         }
/*  808 */         String str3 = new String(arrayOfByte2, 0, i2);
/*  809 */         char[] arrayOfChar = { '\000' };
/*  810 */         String[] arrayOfString = str3.split(new String(arrayOfChar));
/*  811 */         this.registration.addTablesName(arrayOfString, arrayOfString.length);
/*      */         
/*  813 */         this.oracleStatement.dcnTableName = arrayOfString;
/*      */         
/*  815 */         if (i1 != 0)
/*      */         {
/*      */ 
/*  818 */           int i3 = arrayOfByte2[(str1 - 1)] & 0xFF | (arrayOfByte2[(str1 - 2)] & 0xFF) << 8 | (arrayOfByte2[(str1 - 3)] & 0xFF) << 16 | (arrayOfByte2[(str1 - 4)] & 0xFF) << 24;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  823 */           int i4 = arrayOfByte2[(str1 - 5)] & 0xFF | (arrayOfByte2[(str1 - 6)] & 0xFF) << 8 | (arrayOfByte2[(str1 - 7)] & 0xFF) << 16 | (arrayOfByte2[(str1 - 8)] & 0xFF) << 24;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  828 */           long l2 = i4 & 0xFFFFFFFF | (i3 & 0xFFFFFFFF) << 32;
/*  829 */           this.oracleStatement.dcnQueryId = l2;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readDCB()
/*      */     throws IOException, SQLException
/*      */   {
/*  842 */     this.dcb.init(this.oracleStatement, 0);
/*      */     
/*  844 */     this.definesAccessors = this.dcb.receive(this.definesAccessors);
/*  845 */     this.numberOfDefinePositions = this.dcb.numuds;
/*  846 */     this.definesLength = this.numberOfDefinePositions;
/*      */     
/*  848 */     this.rxd.setNumberOfColumns(this.numberOfDefinePositions);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void processError()
/*      */     throws SQLException
/*      */   {
/*  860 */     this.cursor = this.oer.currCursorID;
/*      */     
/*      */ 
/*      */ 
/*  864 */     this.rowsProcessed = this.oer.getCurRowNumber();
/*      */     
/*      */ 
/*  867 */     if ((this.typeOfStatement.isSELECT()) && (this.oer.retCode == 1403))
/*      */     {
/*  869 */       this.aFetchWasDone = true;
/*      */     }
/*  871 */     if ((!this.typeOfStatement.isSELECT()) || ((this.typeOfStatement.isSELECT()) && (this.oer.retCode != 1403)))
/*      */     {
/*      */ 
/*  874 */       if ((this.oracleStatement.connection.calculateChecksum) && (this.oer.retCode != 0))
/*      */       {
/*  876 */         long l = this.oer.updateChecksum(this.oracleStatement.checkSum);
/*  877 */         this.oracleStatement.checkSum = l;
/*      */       }
/*  879 */       this.oer.processError(this.oracleStatement);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getCursorId()
/*      */   {
/*  892 */     return this.cursor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void continueReadRow(int paramInt, OracleStatement paramOracleStatement)
/*      */     throws SQLException, IOException
/*      */   {
/*      */     try
/*      */     {
/*  909 */       this.oracleStatement = paramOracleStatement;
/*      */       
/*      */ 
/*      */ 
/*  913 */       this.receiveState = 2;
/*      */       
/*  915 */       if (this.rxd.unmarshal(this.definesAccessors, paramInt, this.definesLength))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  921 */         this.receiveState = 3;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  927 */         resumeReceive();
/*      */       }
/*      */     }
/*      */     finally {
/*  931 */       this.oracleStatement = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getNumRows()
/*      */   {
/*  945 */     int i = 0;
/*      */     
/*  947 */     if (this.typeOfStatement == null)
/*  948 */       return i;
/*  949 */     if (this.receiveState == 3) {
/*  950 */       i = -2;
/*      */     }
/*      */     else {
/*  953 */       switch (this.typeOfStatement)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case DELETE: 
/*      */       case INSERT: 
/*      */       case MERGE: 
/*      */       case UPDATE: 
/*      */       case ALTER_SESSION: 
/*      */       case OTHER: 
/*      */       case PLSQL_BLOCK: 
/*      */       case CALL_BLOCK: 
/*  967 */         i = this.rowsProcessed;
/*      */         
/*  969 */         break;
/*      */       
/*      */       case SELECT_FOR_UPDATE: 
/*      */       case SELECT: 
/*  973 */         i = (this.definesAccessors != null) && (this.definesLength > 0) ? this.definesAccessors[0].lastRowProcessed : 0;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  980 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void marshal()
/*      */     throws IOException
/*      */   {
/*  994 */     if (getFunCode() == 5)
/*      */     {
/*  996 */       this.meg.marshalSWORD(this.cursor);
/*  997 */       this.meg.marshalSWORD((int)this.al8i4[1]);
/*      */     }
/*      */     else
/*      */     {
/* 1001 */       if (this.oracleStatement.needToSendOalToFetch) {
/* 1002 */         this.oracleStatement.needToSendOalToFetch = false;
/*      */       }
/* 1004 */       marshalPisdef();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1010 */       this.meg.marshalCHR(this.sqlStmt);
/*      */       
/*      */ 
/* 1013 */       this.meg.marshalUB4Array(this.al8i4);
/*      */       
/*      */ 
/* 1016 */       int[] arrayOfInt = new int[this.numberOfBindPositions];
/*      */       
/* 1018 */       for (int i = 0; i < this.numberOfBindPositions; i++)
/*      */       {
/* 1020 */         arrayOfInt[i] = this.oacdefBindsSent[i].oacmxl;
/*      */       }
/*      */       
/*      */ 
/* 1024 */       if (((this.options & 0x8) != 0L) && (this.numberOfBindPositions > 0) && (this.bindIndicators != null) && (this.sendBindsDefinition))
/*      */       {
/* 1026 */         marshalBindsTypes(this.oacdefBindsSent);
/*      */       }
/*      */       
/*      */ 
/* 1030 */       if ((this.connection.getTTCVersion() >= 2) && ((this.options & 0x10) != 0L))
/*      */       {
/* 1032 */         for (i = 0; i < this.defCols; i++) {
/* 1033 */           this.oacdefDefines[i].marshal();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1039 */       if (((this.options & 0x20) != 0L) && (this.numberOfBindPositions > 0) && (this.bindIndicators != null))
/*      */       {
/* 1041 */         this.nonFatalIOExceptions = marshalBinds(arrayOfInt);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void marshalPisdef()
/*      */     throws IOException
/*      */   {
/* 1061 */     this.meg.marshalUB4(this.options);
/*      */     
/*      */ 
/* 1064 */     this.meg.marshalSWORD(this.cursor);
/*      */     
/*      */ 
/*      */ 
/* 1068 */     if (this.sqlStmt.length == 0) {
/* 1069 */       this.meg.marshalNULLPTR();
/*      */     } else {
/* 1071 */       this.meg.marshalPTR();
/*      */     }
/*      */     
/* 1074 */     this.meg.marshalSWORD(this.sqlStmt.length);
/*      */     
/*      */ 
/*      */ 
/* 1078 */     if (this.al8i4.length == 0) {
/* 1079 */       this.meg.marshalNULLPTR();
/*      */     } else {
/* 1081 */       this.meg.marshalPTR();
/*      */     }
/*      */     
/* 1084 */     this.meg.marshalSWORD(this.al8i4.length);
/*      */     
/*      */ 
/*      */ 
/* 1088 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/* 1091 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/* 1094 */     if (((this.options & 0x40) == 0L) && ((this.options & 0x20) != 0L) && ((this.options & 1L) != 0L) && (this.typeOfStatement.isSELECT()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1100 */       this.meg.marshalUB4(Long.MAX_VALUE);
/* 1101 */       this.meg.marshalUB4(this.rowsToFetch);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1106 */       this.meg.marshalUB4(0L);
/*      */       
/* 1108 */       this.meg.marshalUB4(0L);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1113 */     if (!this.typeOfStatement.isPlsqlOrCall()) {
/* 1114 */       this.meg.marshalUB4(2147483647L);
/*      */     } else {
/* 1116 */       this.meg.marshalUB4(32760L);
/*      */     }
/*      */     
/* 1119 */     if (((this.options & 0x8) != 0L) && (this.numberOfBindPositions > 0) && (this.sendBindsDefinition))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1124 */       this.meg.marshalPTR();
/*      */       
/*      */ 
/* 1127 */       this.meg.marshalSWORD(this.numberOfBindPositions);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 1133 */       this.meg.marshalNULLPTR();
/*      */       
/*      */ 
/* 1136 */       this.meg.marshalSWORD(0);
/*      */     }
/*      */     
/*      */ 
/* 1140 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/* 1143 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/* 1146 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/* 1149 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/* 1152 */     this.meg.marshalNULLPTR();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1157 */     if (this.connection.getTTCVersion() >= 2)
/*      */     {
/* 1159 */       if ((this.defCols > 0) && ((this.options & 0x10) != 0L))
/*      */       {
/*      */ 
/*      */ 
/* 1163 */         this.meg.marshalPTR();
/*      */         
/*      */ 
/* 1166 */         this.meg.marshalSWORD(this.defCols);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1172 */         this.meg.marshalNULLPTR();
/*      */         
/*      */ 
/* 1175 */         this.meg.marshalSWORD(0);
/*      */       }
/*      */     }
/*      */     
/* 1179 */     if (this.connection.getTTCVersion() >= 4)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1188 */       int i = 0;
/* 1189 */       int j = 0;
/* 1190 */       if (this.registration != null)
/*      */       {
/* 1192 */         long l = this.registration.getRegId();
/* 1193 */         i = (int)(l & 0xFFFFFFFFFFFFFFFF);
/* 1194 */         j = (int)((l & 0xFFFFFFFF00000000) >> 32);
/*      */       }
/*      */       
/*      */ 
/* 1198 */       this.meg.marshalUB4(i);
/*      */       
/* 1200 */       this.meg.marshalNULLPTR();
/* 1201 */       this.meg.marshalPTR();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1222 */       if (this.connection.getTTCVersion() >= 5)
/*      */       {
/* 1224 */         this.meg.marshalNULLPTR();
/* 1225 */         this.meg.marshalUB4(0L);
/* 1226 */         this.meg.marshalNULLPTR();
/* 1227 */         this.meg.marshalUB4(0L);
/*      */         
/* 1229 */         this.meg.marshalUB4(j);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean initBindsDefinition(T4CTTIoac[] paramArrayOfT4CTTIoac)
/*      */     throws SQLException, IOException
/*      */   {
/* 1244 */     boolean bool = false;
/*      */     
/* 1246 */     if (paramArrayOfT4CTTIoac.length != this.numberOfBindPositions)
/*      */     {
/* 1248 */       bool = true;
/* 1249 */       paramArrayOfT4CTTIoac = new T4CTTIoac[this.numberOfBindPositions];
/*      */     }
/*      */     
/*      */ 
/* 1253 */     short[] arrayOfShort = this.bindIndicators;
/*      */     
/*      */ 
/* 1256 */     int j = 0;
/*      */     
/*      */ 
/* 1259 */     int m = 0;
/*      */     
/*      */ 
/* 1262 */     for (int n = 0; n < this.numberOfBindPositions; n++)
/*      */     {
/* 1264 */       T4CTTIoac localT4CTTIoac = new T4CTTIoac(this.connection);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1269 */       int i = this.bindIndicatorSubRange + 5 + 10 * n;
/*      */       
/*      */ 
/*      */ 
/* 1273 */       short s = arrayOfShort[(i + 9)];
/*      */       
/*      */ 
/* 1276 */       int k = arrayOfShort[(i + 0)] & 0xFFFF;
/*      */       
/*      */ 
/*      */       Object localObject;
/*      */       
/* 1281 */       switch (k)
/*      */       {
/*      */ 
/*      */       case 8: 
/*      */       case 24: 
/* 1286 */         if (this.plsql) {
/* 1287 */           j = 32760;
/*      */         } else {
/* 1289 */           j = Integer.MAX_VALUE;
/*      */         }
/* 1291 */         localT4CTTIoac.init((short)k, j);
/* 1292 */         localT4CTTIoac.setFormOfUse(s);
/* 1293 */         localT4CTTIoac.setCharset(s == 2 ? this.NCharSet : this.dbCharSet);
/*      */         
/* 1295 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 998: 
/* 1300 */         if ((this.outBindAccessors != null) && (this.outBindAccessors[n] != null))
/*      */         {
/* 1302 */           PlsqlIndexTableAccessor localPlsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[n];
/* 1303 */           localT4CTTIoac.init((short)localPlsqlIndexTableAccessor.elementInternalType, localPlsqlIndexTableAccessor.elementMaxLen);
/* 1304 */           localT4CTTIoac.setMal(localPlsqlIndexTableAccessor.maxNumberOfElements);
/* 1305 */           localT4CTTIoac.addFlg((short)64);
/* 1306 */           m++;
/*      */         }
/* 1308 */         else if (this.ibtBindIndicators[(6 + m * 8)] != 0)
/*      */         {
/* 1310 */           int i1 = this.ibtBindIndicators[(6 + m * 8)];
/* 1311 */           int i3 = (this.ibtBindIndicators[(6 + m * 8 + 2)] & 0xFFFF) << 16 | this.ibtBindIndicators[(6 + m * 8 + 3)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/* 1315 */           j = this.ibtBindIndicators[(6 + m * 8 + 1)] * this.conversion.sMaxCharSize;
/*      */           
/* 1317 */           localT4CTTIoac.init((short)i1, j);
/* 1318 */           localT4CTTIoac.setMal(i3);
/* 1319 */           localT4CTTIoac.addFlg((short)64);
/* 1320 */           m++;
/*      */         }
/*      */         else
/*      */         {
/* 1324 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding PLSQL index-by table but no type defined", -1);
/* 1325 */           ((SQLException)localObject).fillInStackTrace();
/* 1326 */           throw ((Throwable)localObject);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 109: 
/*      */       case 111: 
/* 1334 */         if ((this.outBindAccessors != null) && (this.outBindAccessors[n] != null))
/*      */         {
/* 1336 */           if (this.outBindAccessors[n].internalOtype != null)
/*      */           {
/* 1338 */             localT4CTTIoac.init((short)k, k == 109 ? 11 : 4000);
/*      */             
/* 1340 */             localT4CTTIoac.setADT((OracleTypeADT)((TypeAccessor)this.outBindAccessors[n]).internalOtype);
/*      */           }
/*      */           
/*      */         }
/* 1344 */         else if ((this.parameterOtype != null) && (this.parameterOtype[this.oracleStatement.firstRowInBatch] != null))
/*      */         {
/*      */ 
/* 1347 */           localT4CTTIoac.init((short)k, k == 109 ? 11 : 4000);
/* 1348 */           localT4CTTIoac.setADT(this.parameterOtype[this.oracleStatement.firstRowInBatch][n]);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1354 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding NAMED_TYPE but no type defined", -1);
/* 1355 */           ((SQLException)localObject).fillInStackTrace();
/* 1356 */           throw ((Throwable)localObject);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 994: 
/* 1364 */         localObject = this.oracleStatement.returnParamMeta;
/* 1365 */         k = localObject[(3 + n * 4 + 0)];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1370 */         j = localObject[(3 + n * 4 + 2)];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1375 */         s = (short)localObject[(3 + n * 4 + 3)];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1380 */         if ((k == 109) || (k == 111))
/*      */         {
/* 1382 */           TypeAccessor localTypeAccessor = (TypeAccessor)this.oracleStatement.returnParamAccessors[n];
/*      */           
/*      */ 
/* 1385 */           localT4CTTIoac.init((short)k, k == 109 ? 11 : 4000);
/*      */           
/* 1387 */           localT4CTTIoac.setADT((OracleTypeADT)localTypeAccessor.internalOtype);
/*      */         }
/*      */         else
/*      */         {
/* 1391 */           localT4CTTIoac.init((short)k, j);
/* 1392 */           localT4CTTIoac.setFormOfUse(s);
/* 1393 */           localT4CTTIoac.setCharset(s == 2 ? this.NCharSet : this.dbCharSet);
/*      */         }
/*      */         
/*      */ 
/* 1397 */         break;
/*      */       
/*      */       case 180: 
/* 1400 */         j = arrayOfShort[(i + 1)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/* 1404 */         localT4CTTIoac.init((short)k, j);
/* 1405 */         localT4CTTIoac.addFlg2(134217728);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1413 */         localT4CTTIoac.setTimestampFractionalSecondsPrecision((short)9);
/*      */         
/* 1415 */         int i2 = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1420 */         if (i2 == 1)
/*      */         {
/* 1422 */           int i4 = ((arrayOfShort[(i + 7)] & 0xFFFF) << 16) + (arrayOfShort[(i + 8)] & 0xFFFF);
/*      */           
/*      */ 
/* 1425 */           int i5 = arrayOfShort[i4];
/*      */           
/* 1427 */           if (i5 == 7)
/*      */           {
/* 1429 */             localT4CTTIoac.setTimestampFractionalSecondsPrecision((short)0);
/*      */           }
/*      */         }
/*      */         
/* 1433 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       default: 
/* 1440 */         j = arrayOfShort[(i + 1)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1447 */         if (j == 0)
/*      */         {
/* 1449 */           j = arrayOfShort[(i + 2)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/* 1453 */           if (k == 996) {
/* 1454 */             j *= 2;
/*      */           }
/* 1456 */           else if (j > 1) {
/* 1457 */             j--;
/*      */           }
/*      */           
/* 1460 */           if (s == 2) {
/* 1461 */             j *= this.conversion.maxNCharSize;
/*      */           }
/*      */           
/*      */ 
/* 1465 */           if ((this.typeOfStatement == OracleStatement.SqlKind.PLSQL_BLOCK) || ((this.connection.versionNumber >= 10200) && (this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK)))
/*      */           {
/*      */ 
/*      */ 
/* 1469 */             if (j == 0) {
/* 1470 */               j = 32766;
/*      */             } else {
/* 1472 */               j *= this.conversion.sMaxCharSize;
/*      */             }
/* 1474 */           } else if (this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1481 */             if (j < 4001) {
/* 1482 */               j = 4001;
/*      */             }
/*      */             
/*      */ 
/*      */           }
/* 1487 */           else if (s != 2)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1498 */             if ((((T4CConnection)this.oracleStatement.connection).retainV9BindBehavior) && (j <= 4000))
/*      */             {
/*      */ 
/*      */ 
/* 1502 */               j = Math.min(j * this.conversion.sMaxCharSize, 4000);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1507 */               j *= this.conversion.sMaxCharSize;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1513 */           if (j == 0) {
/* 1514 */             j = 32;
/*      */           }
/*      */         }
/* 1517 */         localT4CTTIoac.init((short)k, j);
/* 1518 */         localT4CTTIoac.setFormOfUse(s);
/* 1519 */         localT4CTTIoac.setCharset(s == 2 ? this.NCharSet : this.dbCharSet);
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1524 */       if ((paramArrayOfT4CTTIoac[n] == null) || (!localT4CTTIoac.isOldSufficient(paramArrayOfT4CTTIoac[n])))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1531 */         paramArrayOfT4CTTIoac[n] = localT4CTTIoac;
/* 1532 */         bool = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1538 */     if (bool) {
/* 1539 */       this.oracleStatement.nbPostPonedColumns[0] = 0;
/*      */     }
/* 1541 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initDefinesDefinition()
/*      */     throws SQLException, IOException
/*      */   {
/* 1555 */     this.defCols = 0;
/*      */     
/* 1557 */     for (int i = 0; i < this.definedColumnType.length; i++)
/*      */     {
/* 1559 */       if (this.definedColumnType[i] == 0)
/*      */         break;
/* 1561 */       this.defCols += 1;
/*      */     }
/* 1563 */     this.oacdefDefines = new T4CTTIoac[this.defCols];
/* 1564 */     i = 0;
/* 1565 */     int j = 0;
/* 1566 */     int k = 0;
/* 1567 */     short s1 = 0;
/* 1568 */     for (int m = 0; m < this.oacdefDefines.length; m++)
/*      */     {
/* 1570 */       this.oacdefDefines[m] = new T4CTTIoac(this.connection);
/* 1571 */       s1 = (short)this.oracleStatement.getInternalType(this.definedColumnType[m]);
/* 1572 */       j = Integer.MAX_VALUE;
/* 1573 */       i = 0;
/* 1574 */       k = 0;
/* 1575 */       short s2 = 1;
/* 1576 */       if ((this.definedColumnFormOfUse != null) && (this.definedColumnFormOfUse.length > m) && (this.definedColumnFormOfUse[m] == 2))
/*      */       {
/*      */ 
/*      */ 
/* 1580 */         s2 = 2;
/*      */       }
/* 1582 */       if (s1 == 8) {
/* 1583 */         s1 = 1;
/* 1584 */       } else if (s1 == 24) {
/* 1585 */         s1 = 23;
/* 1586 */       } else if ((s1 == 1) || (s1 == 96))
/*      */       {
/*      */ 
/* 1589 */         s1 = 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1595 */         j = 4000 * this.conversion.sMaxCharSize;
/*      */         
/* 1597 */         if ((this.definedColumnSize != null) && (this.definedColumnSize.length > m) && (this.definedColumnSize[m] > 0))
/*      */         {
/*      */ 
/*      */ 
/* 1601 */           j = this.definedColumnSize[m] * this.conversion.sMaxCharSize;
/*      */         }
/* 1603 */       } else if ((this.connection.useLobPrefetch) && ((s1 == 113) || (s1 == 112) || (s1 == 114)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1608 */         j = 0;
/* 1609 */         i = 33554432;
/* 1610 */         if ((this.definedColumnSize != null) && (this.definedColumnSize.length > m) && (this.definedColumnSize[m] > 0))
/*      */         {
/*      */ 
/*      */ 
/* 1614 */           k = this.definedColumnSize[m];
/*      */         }
/* 1616 */       } else if (s1 == 23) {
/* 1617 */         j = 4000;
/*      */       }
/* 1619 */       this.oacdefDefines[m].init(s1, j);
/* 1620 */       this.oacdefDefines[m].addFlg2(i);
/* 1621 */       this.oacdefDefines[m].setMxlc(k);
/* 1622 */       this.oacdefDefines[m].setFormOfUse(s2);
/* 1623 */       this.oacdefDefines[m].setCharset(s2 == 2 ? this.NCharSet : this.dbCharSet);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void marshalBindsTypes(T4CTTIoac[] paramArrayOfT4CTTIoac)
/*      */     throws IOException
/*      */   {
/* 1633 */     if (paramArrayOfT4CTTIoac == null) {
/* 1634 */       return;
/*      */     }
/* 1636 */     for (int i = 0; i < paramArrayOfT4CTTIoac.length; i++)
/*      */     {
/* 1638 */       paramArrayOfT4CTTIoac[i].marshal();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Vector<IOException> marshalBinds(int[] paramArrayOfInt)
/*      */     throws IOException
/*      */   {
/* 1655 */     Vector localVector1 = null;
/* 1656 */     int i = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1664 */     for (int j = 0; j < i; j++)
/*      */     {
/* 1666 */       int k = this.oracleStatement.firstRowInBatch + j;
/* 1667 */       InputStream[] arrayOfInputStream = null;
/* 1668 */       if (this.parameterStream != null)
/* 1669 */         arrayOfInputStream = this.parameterStream[k];
/* 1670 */       byte[][] arrayOfByte = (byte[][])null;
/* 1671 */       if (this.parameterDatum != null)
/* 1672 */         arrayOfByte = this.parameterDatum[k];
/* 1673 */       OracleTypeADT[] arrayOfOracleTypeADT = null;
/* 1674 */       if (this.parameterOtype != null) {
/* 1675 */         arrayOfOracleTypeADT = this.parameterOtype[k];
/*      */       }
/*      */       
/* 1678 */       Vector localVector2 = this.rxd.marshal(this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.tmpBindsByteArray, this.conversion, arrayOfInputStream, arrayOfByte, arrayOfOracleTypeADT, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, null, j, paramArrayOfInt, this.plsql, this.oracleStatement.returnParamMeta, this.oracleStatement.nbPostPonedColumns, this.oracleStatement.indexOfPostPonedColumn);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1687 */       if (localVector2 != null)
/*      */       {
/* 1689 */         if (localVector1 == null)
/* 1690 */           localVector1 = new Vector();
/* 1691 */         localVector1.addAll(localVector2);
/*      */       }
/*      */     }
/* 1694 */     return localVector1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   long setOptions(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
/*      */     throws SQLException
/*      */   {
/* 1703 */     long l = 0L;
/*      */     
/*      */ 
/* 1706 */     if ((paramBoolean1) && (!paramBoolean2) && (!paramBoolean3)) {
/* 1707 */       l |= 1L;
/* 1708 */     } else if ((paramBoolean1) && (paramBoolean2) && (!paramBoolean3)) {
/* 1709 */       l = 32801L;
/* 1710 */     } else { if ((paramBoolean2) && (paramBoolean3))
/*      */       {
/* 1712 */         if (paramBoolean1) {
/* 1713 */           l |= 1L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1718 */       switch (this.typeOfStatement)
/*      */       {
/*      */ 
/*      */       case SELECT_FOR_UPDATE: 
/*      */       case SELECT: 
/* 1723 */         l |= 0x8060;
/*      */         
/* 1725 */         break;
/*      */       
/*      */ 
/*      */       case PLSQL_BLOCK: 
/*      */       case CALL_BLOCK: 
/* 1730 */         if (this.numberOfBindPositions > 0)
/*      */         {
/*      */ 
/* 1733 */           l |= 0x420 | (this.oracleStatement.connection.autocommit ? 256 : 0);
/*      */           
/*      */ 
/* 1736 */           if (this.sendBindsDefinition) {
/* 1737 */             l |= 0x8;
/*      */           }
/*      */         } else {
/* 1740 */           l |= 0x20 | (this.oracleStatement.connection.autocommit ? 256 : 0);
/*      */         }
/*      */         
/*      */ 
/* 1744 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case DELETE: 
/*      */       case INSERT: 
/*      */       case MERGE: 
/*      */       case UPDATE: 
/*      */       case ALTER_SESSION: 
/*      */       case OTHER: 
/* 1755 */         if (this.oracleStatement.returnParamAccessors != null) {
/* 1756 */           l |= 0x420 | (this.oracleStatement.connection.autocommit ? 256 : 0);
/*      */         }
/*      */         else {
/* 1759 */           l |= 0x8020 | (this.oracleStatement.connection.autocommit ? 256 : 0);
/*      */         }
/*      */         
/* 1762 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       default: 
/* 1767 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
/* 1768 */         localSQLException.fillInStackTrace();
/* 1769 */         throw localSQLException;
/*      */         
/*      */ 
/*      */ 
/* 1773 */         if ((!paramBoolean1) && (!paramBoolean2) && (paramBoolean3)) {
/* 1774 */           l = 32832L;
/*      */         }
/*      */         else
/*      */         {
/* 1778 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
/* 1779 */           localSQLException.fillInStackTrace();
/* 1780 */           throw localSQLException;
/*      */         }
/*      */         break; }
/*      */       
/*      */     }
/* 1785 */     if (!this.typeOfStatement.isPlsqlOrCall())
/*      */     {
/*      */ 
/*      */ 
/* 1789 */       if ((paramBoolean1) || (paramBoolean2) || (!paramBoolean3))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1796 */         if ((this.numberOfBindPositions > 0) && (this.sendBindsDefinition)) {
/* 1797 */           l |= 0x8;
/*      */         }
/*      */       }
/* 1800 */       if ((this.connection.versionNumber >= 9000) && (paramBoolean4))
/*      */       {
/* 1802 */         l |= 0x10;
/*      */       }
/*      */     }
/*      */     
/* 1806 */     l &= 0xFFFFFFFFFFFFFFFF;
/*      */     
/*      */ 
/* 1809 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 1824 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1829 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4C8Oall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */