/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIBlob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   T4C8TTIBlob(T4CConnection paramT4CConnection)
/*     */   {
/* 115 */     super(paramT4CConnection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 139 */     if (paramInt == 12)
/*     */     {
/* 141 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 142 */       ((SQLException)localObject).fillInStackTrace();
/* 143 */       throw ((Throwable)localObject);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     Object localObject = null;
/*     */     
/*     */ 
/* 151 */     initializeLobdef();
/*     */     
/*     */ 
/* 154 */     this.lobops = 272L;
/* 155 */     this.sourceLobLocator = new byte[86];
/* 156 */     this.sourceLobLocator[1] = 84;
/*     */     
/*     */ 
/* 159 */     this.characterSet = 1;
/*     */     
/*     */ 
/*     */ 
/* 163 */     this.destinationOffset = 113L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 168 */     this.destinationLength = paramInt;
/*     */     
/* 170 */     this.lobamt = paramInt;
/* 171 */     this.sendLobamt = true;
/*     */     
/*     */ 
/* 174 */     this.nullO2U = true;
/*     */     
/* 176 */     if (this.connection.versionNumber >= 9000)
/*     */     {
/* 178 */       this.lobscn = new int[1];
/* 179 */       this.lobscn[0] = (paramBoolean ? 1 : 0);
/* 180 */       this.lobscnl = 1;
/*     */     }
/*     */     
/* 183 */     doRPC();
/*     */     
/*     */ 
/*     */ 
/* 187 */     if (this.sourceLobLocator != null)
/*     */     {
/* 189 */       localObject = new BLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */     }
/*     */     
/*     */ 
/* 193 */     return (Datum)localObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean open(byte[] paramArrayOfByte, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 211 */     boolean bool = false;
/*     */     
/*     */ 
/*     */ 
/* 215 */     int i = 2;
/*     */     
/* 217 */     if (paramInt == 0) {
/* 218 */       i = 1;
/*     */     }
/* 220 */     bool = _open(paramArrayOfByte, i, 32768);
/*     */     
/* 222 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean close(byte[] paramArrayOfByte)
/*     */     throws SQLException, IOException
/*     */   {
/* 240 */     boolean bool = false;
/*     */     
/* 242 */     bool = _close(paramArrayOfByte, 65536);
/*     */     
/* 244 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isOpen(byte[] paramArrayOfByte)
/*     */     throws SQLException, IOException
/*     */   {
/* 262 */     boolean bool = false;
/*     */     
/* 264 */     bool = _isOpen(paramArrayOfByte, 69632);
/*     */     
/* 266 */     return bool;
/*     */   }
/*     */   
/*     */ 
/* 270 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4C8TTIBlob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */