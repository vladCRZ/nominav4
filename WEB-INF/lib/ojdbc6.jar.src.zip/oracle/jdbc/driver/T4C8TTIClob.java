/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NCLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIClob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   int[] nBytes;
/*     */   
/*     */   T4C8TTIClob(T4CConnection paramT4CConnection)
/*     */   {
/* 147 */     super(paramT4CConnection);
/*     */     
/* 149 */     this.nBytes = new int[1];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long read(byte[] paramArrayOfByte, long paramLong1, long paramLong2, boolean paramBoolean, char[] paramArrayOfChar, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 184 */     long l1 = 0L;
/* 185 */     long l2 = paramLong2;
/* 186 */     int i = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */     byte[] arrayOfByte = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 203 */       initializeLobdef();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 211 */       if ((paramArrayOfByte[6] & 0x80) == 128) {
/* 212 */         i = 1;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */       int j = 0;
/* 220 */       if (i == 1) {
/* 221 */         j = (int)paramLong2 * 2;
/*     */       } else {
/* 223 */         j = (int)paramLong2 * 3;
/*     */       }
/*     */       
/* 226 */       arrayOfByte = this.connection.getByteBuffer(j);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 234 */       if ((paramArrayOfByte[7] & 0x40) > 0) {
/* 235 */         this.littleEndianClob = true;
/*     */       }
/*     */       
/*     */ 
/* 239 */       this.lobops = 2L;
/* 240 */       this.sourceLobLocator = paramArrayOfByte;
/* 241 */       this.sourceOffset = paramLong1;
/* 242 */       this.lobamt = paramLong2;
/* 243 */       this.sendLobamt = true;
/* 244 */       this.outBuffer = arrayOfByte;
/*     */       
/* 246 */       doRPC();
/*     */       
/* 248 */       l2 = this.lobamt;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */       long l3 = 0L;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 259 */       if (i == 1)
/*     */       {
/* 261 */         if (this.connection.versionNumber < 10101)
/*     */         {
/*     */ 
/*     */ 
/* 265 */           DBConversion.ucs2BytesToJavaChars(this.outBuffer, (int)this.lobBytesRead, paramArrayOfChar);
/*     */ 
/*     */         }
/* 268 */         else if (this.littleEndianClob)
/*     */         {
/* 270 */           CharacterSet.convertAL16UTF16LEBytesToJavaChars(this.outBuffer, 0, paramArrayOfChar, paramInt, (int)this.lobBytesRead, true);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 275 */           CharacterSet.convertAL16UTF16BytesToJavaChars(this.outBuffer, 0, paramArrayOfChar, paramInt, (int)this.lobBytesRead, true);
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */       }
/* 283 */       else if (!paramBoolean)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 288 */         this.nBytes[0] = ((int)this.lobBytesRead);
/*     */         
/* 290 */         this.meg.conv.CHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfChar, paramInt, this.nBytes, paramArrayOfChar.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 301 */         this.nBytes[0] = ((int)this.lobBytesRead);
/*     */         
/* 303 */         this.meg.conv.NCHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfChar, paramInt, this.nBytes, paramArrayOfChar.length);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 310 */       this.outBuffer = null;
/* 311 */       this.connection.cacheBuffer(arrayOfByte);
/*     */     }
/*     */     
/* 314 */     return l2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long write(byte[] paramArrayOfByte, long paramLong1, boolean paramBoolean, char[] paramArrayOfChar, long paramLong2, long paramLong3)
/*     */     throws SQLException, IOException
/*     */   {
/* 356 */     int i = 0;
/* 357 */     if ((paramArrayOfByte[6] & 0x80) == 128) {
/* 358 */       i = 1;
/*     */     }
/* 360 */     if ((paramArrayOfByte[7] & 0x40) == 64) {
/* 361 */       this.littleEndianClob = true;
/*     */     }
/*     */     
/*     */ 
/* 365 */     long l1 = 0L;
/* 366 */     byte[] arrayOfByte = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 372 */     if (i == 1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 377 */       arrayOfByte = new byte[(int)paramLong3 * 2];
/*     */       
/* 379 */       if (this.connection.versionNumber < 10101)
/*     */       {
/* 381 */         DBConversion.javaCharsToUcs2Bytes(paramArrayOfChar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/* 383 */       else if (this.littleEndianClob)
/*     */       {
/* 385 */         CharacterSet.convertJavaCharsToAL16UTF16LEBytes(paramArrayOfChar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/*     */       else
/*     */       {
/* 389 */         CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfChar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 397 */       arrayOfByte = new byte[(int)paramLong3 * 3];
/*     */       
/* 399 */       if (!paramBoolean)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 404 */         l1 = this.meg.conv.javaCharsToCHARBytes(paramArrayOfChar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 412 */         l1 = this.meg.conv.javaCharsToNCHARBytes(paramArrayOfChar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 419 */     initializeLobdef();
/*     */     
/*     */ 
/* 422 */     this.lobops = 64L;
/* 423 */     this.sourceLobLocator = paramArrayOfByte;
/* 424 */     this.sourceOffset = paramLong1;
/* 425 */     this.lobamt = paramLong3;
/* 426 */     this.sendLobamt = true;
/* 427 */     this.inBuffer = arrayOfByte;
/* 428 */     this.inBufferOffset = 0L;
/*     */     
/*     */ 
/*     */ 
/* 432 */     if (i == 1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 437 */       if (this.connection.versionNumber < 10101) {
/* 438 */         this.inBufferNumBytes = paramLong3;
/*     */       } else {
/* 440 */         this.inBufferNumBytes = (paramLong3 * 2L);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 447 */       this.inBufferNumBytes = l1;
/*     */     }
/* 449 */     doRPC();
/*     */     
/* 451 */     long l2 = this.lobamt;
/*     */     
/* 453 */     return l2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 473 */     return createTemporaryLob(paramConnection, paramBoolean, paramInt, (short)1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort)
/*     */     throws SQLException, IOException
/*     */   {
/* 488 */     if (paramInt == 12)
/*     */     {
/* 490 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 491 */       ((SQLException)localObject).fillInStackTrace();
/* 492 */       throw ((Throwable)localObject);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 497 */     Object localObject = null;
/*     */     
/*     */ 
/* 500 */     initializeLobdef();
/*     */     
/*     */ 
/* 503 */     this.lobops = 272L;
/* 504 */     this.sourceLobLocator = new byte[86];
/* 505 */     this.sourceLobLocator[1] = 84;
/*     */     
/*     */ 
/* 508 */     if (paramShort == 1) {
/* 509 */       this.sourceOffset = 1L;
/*     */     } else {
/* 511 */       this.sourceOffset = 2L;
/*     */     }
/*     */     
/*     */ 
/* 515 */     this.destinationOffset = 112L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 524 */     this.destinationLength = paramInt;
/*     */     
/* 526 */     this.lobamt = paramInt;
/* 527 */     this.sendLobamt = true;
/*     */     
/*     */ 
/* 530 */     this.nullO2U = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 535 */     this.characterSet = (paramShort == 2 ? this.meg.conv.getNCharSetId() : this.meg.conv.getServerCharSetId());
/*     */     
/* 537 */     if (this.connection.versionNumber >= 9000)
/*     */     {
/* 539 */       this.lobscn = new int[1];
/* 540 */       this.lobscn[0] = (paramBoolean ? 1 : 0);
/* 541 */       this.lobscnl = 1;
/*     */     }
/*     */     
/* 544 */     doRPC();
/*     */     
/*     */ 
/*     */ 
/* 548 */     if (this.sourceLobLocator != null)
/*     */     {
/* 550 */       if (paramShort == 1) {
/* 551 */         localObject = new CLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */       }
/*     */       else
/*     */       {
/* 555 */         localObject = new NCLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */       }
/*     */     }
/*     */     
/* 559 */     return (Datum)localObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean open(byte[] paramArrayOfByte, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 578 */     boolean bool = false;
/*     */     
/*     */ 
/*     */ 
/* 582 */     int i = 2;
/*     */     
/* 584 */     if (paramInt == 0) {
/* 585 */       i = 1;
/*     */     }
/* 587 */     bool = _open(paramArrayOfByte, i, 32768);
/*     */     
/* 589 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean close(byte[] paramArrayOfByte)
/*     */     throws SQLException, IOException
/*     */   {
/* 607 */     boolean bool = false;
/*     */     
/* 609 */     bool = _close(paramArrayOfByte, 65536);
/*     */     
/* 611 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isOpen(byte[] paramArrayOfByte)
/*     */     throws SQLException, IOException
/*     */   {
/* 630 */     boolean bool = false;
/*     */     
/* 632 */     bool = _isOpen(paramArrayOfByte, 69632);
/*     */     
/* 634 */     return bool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 639 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4C8TTIClob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */