/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CCallableStatement
/*      */   extends OracleCallableStatement
/*      */ {
/*      */   T4CCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   28 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*   30 */     this.t4Connection = ((T4CConnection)paramPhysicalConnection);
/*   31 */     this.nbPostPonedColumns = new int[1];
/*   32 */     this.nbPostPonedColumns[0] = 0;
/*   33 */     this.indexOfPostPonedColumn = new int[1][3];
/*      */     
/*   35 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   36 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   37 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   38 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   44 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CConnection t4Connection;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
/*      */     throws SQLException, IOException
/*      */   {
/*   64 */     if ((paramBoolean1) || (paramBoolean4) || (!paramBoolean2)) {
/*   65 */       this.oacdefSent = null;
/*      */     }
/*   67 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.doOall8");
/*      */     
/*   69 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED)
/*      */     {
/*      */ 
/*      */ 
/*   73 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   74 */       localSQLException1.fillInStackTrace();
/*   75 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*   79 */     if (paramBoolean3) {
/*   80 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   82 */     int i = this.numberOfDefinePositions;
/*      */     
/*   84 */     if (this.sqlKind.isDML()) {
/*   85 */       i = 0;
/*      */     }
/*      */     int j;
/*   88 */     if (this.accessors != null)
/*   89 */       for (j = 0; j < this.accessors.length; j++)
/*   90 */         if (this.accessors[j] != null)
/*   91 */           this.accessors[j].lastRowProcessed = 0;
/*   92 */     if (this.outBindAccessors != null)
/*   93 */       for (j = 0; j < this.outBindAccessors.length; j++)
/*   94 */         if (this.outBindAccessors[j] != null)
/*   95 */           this.outBindAccessors[j].lastRowProcessed = 0;
/*   96 */     if (this.returnParamAccessors != null) {
/*   97 */       for (j = 0; j < this.returnParamAccessors.length; j++) {
/*   98 */         if (this.returnParamAccessors[j] != null) {
/*   99 */           this.returnParamAccessors[j].lastRowProcessed = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int i1;
/*      */     int i2;
/*  106 */     if (this.bindIndicators != null)
/*      */     {
/*  108 */       j = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */       
/*      */ 
/*  111 */       int k = 0;
/*      */       
/*  113 */       if (this.ibtBindChars != null) {
/*  114 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  116 */       for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */       {
/*  118 */         int n = this.bindIndicatorSubRange + 5 + 10 * m;
/*      */         
/*      */ 
/*      */ 
/*  122 */         i1 = this.bindIndicators[(n + 2)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/*  126 */         if (i1 != 0)
/*      */         {
/*      */ 
/*  129 */           i2 = this.bindIndicators[(n + 9)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/*  133 */           if (i2 == 2)
/*      */           {
/*  135 */             k = Math.max(i1 * this.connection.conversion.maxNCharSize, k);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  140 */             k = Math.max(i1 * this.connection.conversion.cMaxCharSize, k);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  146 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  148 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  150 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  152 */         this.tmpBindsByteArray = null;
/*  153 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  165 */       this.tmpBindsByteArray = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  170 */     int[] arrayOfInt1 = this.definedColumnType;
/*  171 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  172 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */     if ((paramBoolean5) && (paramBoolean4) && (this.sqlObject.includeRowid))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  183 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  184 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  185 */       arrayOfInt1[0] = -8;
/*  186 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  187 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  188 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  189 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  195 */     allocateTmpByteArray();
/*      */     
/*  197 */     T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */     
/*  199 */     this.t4Connection.sendPiggyBackedMessages();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  204 */       localT4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  216 */       i1 = localT4C8Oall.getCursorId();
/*  217 */       if (i1 != 0) {
/*  218 */         this.cursorId = i1;
/*      */       }
/*  220 */       this.oacdefSent = localT4C8Oall.oacdefBindsSent;
/*      */     }
/*      */     catch (SQLException localSQLException2)
/*      */     {
/*  224 */       i2 = localT4C8Oall.getCursorId();
/*  225 */       if (i2 != 0) {
/*  226 */         this.cursorId = i2;
/*      */       }
/*  228 */       if (localSQLException2.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/*  231 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  236 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray()
/*      */   {
/*  246 */     if (this.tmpByteArray == null)
/*      */     {
/*      */ 
/*  249 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  251 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length)
/*      */     {
/*      */ 
/*      */ 
/*  255 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/*  267 */     super.releaseBuffers();
/*  268 */     this.tmpByteArray = null;
/*  269 */     this.tmpBindsByteArray = null;
/*      */     
/*  271 */     this.t4Connection.all8.bindChars = null;
/*  272 */     this.t4Connection.all8.bindBytes = null;
/*  273 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */   
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/*  280 */     this.accessors[0] = new T4CRowidAccessor(this, 128, 1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {
/*  293 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/*  304 */     if (this.connection.disableDefinecolumntype)
/*      */     {
/*      */ 
/*  307 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  312 */     if ((paramInt2 == -15) || (paramInt2 == -9) || (paramInt2 == -16))
/*      */     {
/*  314 */       paramShort = 2;
/*      */     }
/*      */     
/*      */ 
/*      */     SQLException localSQLException;
/*      */     
/*  320 */     if (paramInt1 < 1)
/*      */     {
/*  322 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  323 */       localSQLException.fillInStackTrace();
/*  324 */       throw localSQLException;
/*      */     }
/*  326 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*  330 */       if ((paramInt2 == 1) || (paramInt2 == 12) || (paramInt2 == -15) || (paramInt2 == -9))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  336 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  342 */     else if (paramInt3 < 0)
/*      */     {
/*  344 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  345 */       localSQLException.fillInStackTrace();
/*  346 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  350 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/*  352 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  353 */       localSQLException.fillInStackTrace();
/*  354 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  361 */     int i = paramInt1 - 1;
/*      */     int[] arrayOfInt;
/*  363 */     if ((this.definedColumnType == null) || (this.definedColumnType.length <= i))
/*      */     {
/*  365 */       if (this.definedColumnType == null)
/*      */       {
/*  367 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  379 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  381 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */         
/*      */ 
/*  384 */         this.definedColumnType = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  390 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  392 */     if ((this.definedColumnSize == null) || (this.definedColumnSize.length <= i))
/*      */     {
/*  394 */       if (this.definedColumnSize == null) {
/*  395 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  398 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  400 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */         
/*      */ 
/*  403 */         this.definedColumnSize = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  407 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  409 */     if ((this.definedColumnFormOfUse == null) || (this.definedColumnFormOfUse.length <= i))
/*      */     {
/*  411 */       if (this.definedColumnFormOfUse == null) {
/*  412 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  415 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  417 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */         
/*      */ 
/*  420 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  424 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  426 */     if ((this.accessors != null) && (i < this.accessors.length) && (this.accessors[i] != null))
/*      */     {
/*  428 */       this.accessors[i].definedColumnSize = paramInt3;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  433 */       if (((this.accessors[i].internalType == 96) || (this.accessors[i].internalType == 1)) && ((paramInt2 == 1) || (paramInt2 == 12)))
/*      */       {
/*      */ 
/*      */ 
/*  437 */         if (paramInt3 <= this.accessors[i].oacmxl)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */           this.needToPrepareDefineBuffer = true;
/*  444 */           this.columnsDefinedByUser = true;
/*      */           
/*  446 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  447 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/*  456 */     synchronized (this.connection)
/*      */     {
/*  458 */       super.clearDefines();
/*  459 */       this.definedColumnType = null;
/*  460 */       this.definedColumnSize = null;
/*  461 */       this.definedColumnFormOfUse = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  479 */     int i = this.rowPrefetchInLastFetch < this.rowPrefetch ? 1 : 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  508 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  517 */       paramArrayOfShort = new short[this.defineIndicators.length];
/*  518 */       j = this.accessors[0].lengthIndexLastRow;
/*  519 */       int k = this.accessors[0].indicatorIndexLastRow;
/*      */       
/*  521 */       int i1 = i != 0 ? this.accessors.length : 1;
/*  522 */       for (; i != 0 ? i1 >= 1 : i1 <= this.accessors.length; 
/*  523 */           i1 += (i != 0 ? -1 : 1))
/*      */       {
/*  525 */         int m = j + this.rowPrefetchInLastFetch * i1 - 1;
/*  526 */         int n = k + this.rowPrefetchInLastFetch * i1 - 1;
/*  527 */         paramArrayOfShort[n] = this.defineIndicators[n];
/*  528 */         paramArrayOfShort[m] = this.defineIndicators[m];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  535 */     int j = i != 0 ? this.accessors.length - 1 : 0;
/*  536 */     for (; i != 0 ? j > -1 : j < this.accessors.length; 
/*  537 */         j += (i != 0 ? -1 : 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  544 */       this.accessors[j].saveDataFromOldDefineBuffers(paramArrayOfByte, paramArrayOfChar, paramArrayOfShort, this.rowPrefetchInLastFetch != -1 ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  551 */     super.saveDefineBuffersIfRequired(paramArrayOfChar, paramArrayOfByte, paramArrayOfShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  561 */     this.inScn = paramLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  581 */     Object localObject = null;
/*      */     SQLException localSQLException;
/*  583 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/*  587 */       localObject = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  590 */       break;
/*      */     
/*      */     case 8: 
/*  593 */       if (!paramBoolean)
/*      */       {
/*  595 */         localObject = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  598 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*  603 */       localObject = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  606 */       break;
/*      */     
/*      */     case 2: 
/*  609 */       localObject = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  612 */       break;
/*      */     
/*      */     case 6: 
/*  615 */       localObject = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  618 */       break;
/*      */     
/*      */     case 24: 
/*  621 */       if (!paramBoolean)
/*      */       {
/*  623 */         localObject = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  626 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/*  631 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/*  633 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  634 */         localSQLException.fillInStackTrace();
/*  635 */         throw localSQLException;
/*      */       }
/*      */       
/*  638 */       if (paramBoolean) {
/*  639 */         localObject = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       else {
/*  642 */         localObject = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*  645 */       break;
/*      */     
/*      */     case 100: 
/*  648 */       localObject = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  651 */       break;
/*      */     
/*      */     case 101: 
/*  654 */       localObject = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  657 */       break;
/*      */     
/*      */     case 104: 
/*  660 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  666 */         localObject = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         
/*      */ 
/*      */ 
/*  670 */         ((Accessor)localObject).definedColumnType = -8;
/*      */       }
/*      */       else {
/*  673 */         localObject = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*      */ 
/*  677 */       break;
/*      */     
/*      */     case 102: 
/*  680 */       localObject = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  683 */       break;
/*      */     
/*      */     case 12: 
/*  686 */       localObject = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  689 */       break;
/*      */     
/*      */     case 113: 
/*  692 */       localObject = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  695 */       break;
/*      */     
/*      */     case 112: 
/*  698 */       localObject = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  701 */       break;
/*      */     
/*      */     case 114: 
/*  704 */       localObject = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  707 */       break;
/*      */     
/*      */     case 109: 
/*  710 */       localObject = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  713 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  715 */       break;
/*      */     
/*      */     case 111: 
/*  718 */       localObject = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  721 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  723 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/*  728 */       localObject = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  731 */       break;
/*      */     
/*      */     case 181: 
/*  734 */       localObject = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  737 */       break;
/*      */     
/*      */     case 231: 
/*  740 */       localObject = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  743 */       break;
/*      */     
/*      */     case 182: 
/*  746 */       localObject = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  749 */       break;
/*      */     
/*      */     case 183: 
/*  752 */       localObject = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  755 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/*  768 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  769 */       localSQLException.fillInStackTrace();
/*  770 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*  774 */     return (Accessor)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doDescribe(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  801 */     if (!this.isOpen)
/*      */     {
/*      */ 
/*  804 */       this.connection.open(this);
/*  805 */       this.isOpen = true;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  811 */       this.t4Connection.needLine();
/*  812 */       this.t4Connection.sendPiggyBackedMessages();
/*  813 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  814 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  816 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  818 */       for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  819 */         this.accessors[i].initMetadata();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/*  823 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*      */ 
/*  826 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  827 */       localSQLException.fillInStackTrace();
/*  828 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  832 */     this.describedWithNames = true;
/*  833 */     this.described = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForDescribe()
/*      */     throws SQLException
/*      */   {
/*  868 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.execute_for_describe");
/*      */     try
/*      */     {
/*  871 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  877 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  881 */         doOall8(true, true, false, true, this.definedColumnType != null);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/*  887 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  891 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*  893 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  894 */       localSQLException2.fillInStackTrace();
/*  895 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  900 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  901 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     
/*  904 */     this.needToParse = false;
/*      */     
/*      */ 
/*  907 */     if (this.connection.calculateChecksum) {
/*  908 */       if (this.validRows > 0) {
/*  909 */         calculateCheckSum();
/*  910 */       } else if (this.rowsProcessed > 0) {
/*  911 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  913 */         this.checkSum = l;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  923 */     if (this.definedColumnType == null) {
/*  924 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  926 */     this.aFetchWasDoneDuringDescribe = false;
/*  927 */     if (this.t4Connection.all8.aFetchWasDone)
/*      */     {
/*  929 */       this.aFetchWasDoneDuringDescribe = true;
/*  930 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*      */     
/*      */ 
/*  934 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  935 */       this.accessors[i].initMetadata();
/*      */     }
/*  937 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForRows(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  979 */         boolean bool = false;
/*  980 */         if (this.columnsDefinedByUser) {
/*  981 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1001 */         else if ((this.t4Connection.useLobPrefetch) && (this.accessors != null) && (this.defaultLobPrefetchSize != -1) && (!this.implicitDefineForLobPrefetchDone) && (!this.aFetchWasDoneDuringDescribe) && (this.definedColumnType == null))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1009 */           int i = 0;
/* 1010 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1011 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1013 */           for (int j = 0; j < this.accessors.length; j++)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1018 */             arrayOfInt1[j] = getJDBCType(this.accessors[j].internalType);
/* 1019 */             if ((this.accessors[j].internalType == 113) || (this.accessors[j].internalType == 112) || (this.accessors[j].internalType == 114))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1025 */               i = 1;
/* 1026 */               this.accessors[j].lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1027 */               arrayOfInt2[j] = this.defaultLobPrefetchSize;
/*      */             }
/*      */           }
/*      */           
/* 1031 */           if (i != 0)
/*      */           {
/* 1033 */             this.definedColumnType = arrayOfInt1;
/* 1034 */             this.definedColumnSize = arrayOfInt2;
/* 1035 */             bool = true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1041 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1043 */         this.needToParse = false;
/* 1044 */         if (bool) {
/* 1045 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       }
/*      */       finally {
/* 1049 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1054 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1058 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/* 1059 */       calculateCheckSum();
/*      */       
/* 1061 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1062 */       localSQLException2.fillInStackTrace();
/* 1063 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetch()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1090 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1094 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1098 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException1)
/*      */         {
/* 1102 */           ((T4CConnection)this.connection).handleIOException(localIOException1);
/*      */           
/* 1104 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/* 1105 */           localSQLException.fillInStackTrace();
/* 1106 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1110 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1116 */       doOall8(false, false, true, false, false);
/*      */       
/* 1118 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 1122 */       ((T4CConnection)this.connection).handleIOException(localIOException2);
/*      */       
/* 1124 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/* 1125 */       localSQLException.fillInStackTrace();
/* 1126 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1132 */     calculateCheckSum();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1147 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1149 */         T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */         
/* 1151 */         localT4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1156 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1158 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1159 */       localSQLException2.fillInStackTrace();
/* 1160 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1165 */       if (localSQLException1.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/* 1168 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1173 */         throw localSQLException1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClose()
/*      */     throws SQLException
/*      */   {
/* 1197 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.do_close");
/*      */     
/*      */     try
/*      */     {
/* 1201 */       if (this.cursorId != 0)
/*      */       {
/* 1203 */         this.t4Connection.cursorToClose[(this.t4Connection.cursorToCloseOffset++)] = this.cursorId;
/*      */         
/*      */ 
/* 1206 */         if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length)
/*      */         {
/*      */ 
/* 1209 */           this.t4Connection.sendPiggyBackedMessages();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1215 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1217 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1218 */       localSQLException.fillInStackTrace();
/* 1219 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1223 */     this.tmpByteArray = null;
/* 1224 */     this.tmpBindsByteArray = null;
/* 1225 */     this.definedColumnType = null;
/* 1226 */     this.definedColumnSize = null;
/* 1227 */     this.definedColumnFormOfUse = null;
/* 1228 */     this.oacdefSent = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeQuery()
/*      */     throws SQLException
/*      */   {
/* 1248 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.closeQuery");
/*      */     
/*      */ 
/* 1251 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1255 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1259 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 1263 */           ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */           
/* 1265 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1266 */           localSQLException.fillInStackTrace();
/* 1267 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1271 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Binder getRowidNullBinder(int paramInt)
/*      */   {
/* 1320 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */     {
/*      */ 
/* 1323 */       this.currentRowCharLens[paramInt] = 1;
/* 1324 */       return this.theVarcharNullBinder;
/*      */     }
/*      */     
/* 1327 */     return this.theRowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1341 */     return new T4CPlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1351 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */