/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.net.SocketException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.zip.CRC32;
/*      */ import oracle.jdbc.NotificationRegistration.RegistrationState;
/*      */ import oracle.jdbc.OracleConnection.CommitOption;
/*      */ import oracle.jdbc.OracleConnection.DatabaseShutdownMode;
/*      */ import oracle.jdbc.OracleConnection.DatabaseStartupMode;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQEnqueueOptions;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleConnection.InstanceProperty;
/*      */ import oracle.jdbc.internal.OracleConnection.TransactionState;
/*      */ import oracle.jdbc.internal.OracleConnection.XSOperationCode;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NSProtocol;
/*      */ import oracle.net.ns.NetException;
/*      */ import oracle.net.ns.SessionAtts;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*      */   static final short MIN_TTCVER_SUPPORTED = 4;
/*      */   static final short V8_TTCVER_SUPPORTED = 5;
/*      */   static final short MAX_TTCVER_SUPPORTED = 6;
/*      */   static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
/*      */   static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
/*      */   static final int STREAM_CHUNK_SIZE = 255;
/*      */   static final int REFCURSOR_SIZE = 5;
/*   94 */   long LOGON_MODE = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */   static final long SYSDBA = 8L;
/*      */   
/*      */ 
/*      */ 
/*      */   static final long SYSOPER = 16L;
/*      */   
/*      */ 
/*      */ 
/*      */   static final long SYSASM = 128L;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean isLoggedOn;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean useZeroCopyIO;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean useLobPrefetch;
/*      */   
/*      */ 
/*      */ 
/*      */   private String password;
/*      */   
/*      */ 
/*      */ 
/*      */   Communication net;
/*      */   
/*      */ 
/*      */   int eocs;
/*      */   
/*      */ 
/*  132 */   private NTFEventListener[] xsListeners = new NTFEventListener[0];
/*      */   
/*      */   boolean readAsNonStream;
/*      */   
/*      */   T4CTTIoer oer;
/*      */   
/*      */   T4CMAREngine mare;
/*      */   
/*      */   T4C8TTIpro pro;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4CTTIsto sto;
/*      */   
/*      */   T4CTTIspfp spfp;
/*      */   
/*      */   T4CTTIoauthenticate auth;
/*      */   
/*      */   T4C8Odscrarr describe;
/*      */   
/*      */   T4C8Oall all8;
/*      */   
/*      */   T4C8Oclose close8;
/*      */   T4C7Ocommoncall commoncall;
/*      */   T4Caqe aqe;
/*      */   T4Caqdq aqdq;
/*      */   T4C8TTIBfile bfileMsg;
/*      */   T4C8TTIBlob blobMsg;
/*      */   T4C8TTIClob clobMsg;
/*      */   T4CTTIoses oses;
/*      */   T4CTTIoping oping;
/*      */   T4CTTIokpn okpn;
/*  164 */   byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */   T4CTTIOtxen otxen;
/*      */   
/*      */   T4CTTIOtxse otxse;
/*      */   
/*      */   T4CTTIk2rpc k2rpc;
/*      */   
/*      */   T4CTTIoscid oscid;
/*      */   
/*      */   T4CTTIokeyval okeyval;
/*      */   
/*      */   T4CTTIoxsscs oxsscs;
/*      */   
/*      */   T4CTTIoxssro oxssro;
/*      */   
/*      */   T4CTTIoxsspo oxsspo;
/*      */   
/*      */   T4CTTIxsnsop xsnsop;
/*      */   
/*      */   int[] cursorToClose;
/*      */   
/*      */   int cursorToCloseOffset;
/*      */   
/*      */   int[] queryToClose;
/*      */   
/*      */   int queryToCloseOffset;
/*      */   
/*      */   int[] lusFunctionId2;
/*      */   
/*      */   byte[][] lusSessionId2;
/*      */   
/*      */   KeywordValueLong[][] lusInKeyVal2;
/*      */   
/*      */   int[] lusInFlags2;
/*      */   
/*      */   int lusOffset2;
/*      */   
/*      */   int sessionId;
/*      */   
/*      */   int serialNumber;
/*      */   
/*      */   byte negotiatedTTCversion;
/*      */   
/*      */   byte[] serverRuntimeCapabilities;
/*      */   
/*      */   byte[] serverCompileTimeCapabilities;
/*      */   
/*      */   Hashtable namespaces;
/*      */   
/*      */   byte[] internalName;
/*      */   
/*      */   byte[] externalName;
/*      */   
/*      */   static final int FREE = -1;
/*      */   static final int SEND = 1;
/*      */   static final int RECEIVE = 2;
/*  221 */   int pipeState = -1;
/*  222 */   boolean sentCancel = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension)
/*      */     throws SQLException
/*      */   {
/*  236 */     super(paramString, paramProperties, paramOracleDriverExtension);
/*      */     
/*  238 */     this.cursorToClose = new int[4];
/*  239 */     this.cursorToCloseOffset = 0;
/*      */     
/*      */ 
/*  242 */     this.queryToClose = new int[10];
/*  243 */     this.queryToCloseOffset = 0;
/*      */     
/*  245 */     this.lusFunctionId2 = new int[10];
/*  246 */     this.lusSessionId2 = new byte[10][];
/*  247 */     this.lusInKeyVal2 = new KeywordValueLong[10][];
/*  248 */     this.lusInFlags2 = new int[10];
/*  249 */     this.lusOffset2 = 0;
/*      */     
/*  251 */     this.minVcsBindSize = 0;
/*  252 */     this.streamChunkSize = 255;
/*      */     
/*  254 */     this.namespaces = new Hashtable(5);
/*      */   }
/*      */   
/*      */   final void initializePassword(String paramString)
/*      */     throws SQLException
/*      */   {
/*  260 */     this.password = paramString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void logon()
/*      */     throws SQLException
/*      */   {
/*  291 */     Object localObject1 = null;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  296 */       if (this.isLoggedOn)
/*      */       {
/*      */ 
/*  299 */         SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 428);
/*  300 */         localSQLException1.fillInStackTrace();
/*  301 */         throw localSQLException1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */       if (this.database == null)
/*      */       {
/*  310 */         this.database = "localhost:1521:orcl";
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  320 */       connect(this.database);
/*      */       
/*  322 */       this.all8 = new T4C8Oall(this);
/*  323 */       this.okpn = new T4CTTIokpn(this);
/*  324 */       this.close8 = new T4C8Oclose(this);
/*  325 */       this.sto = new T4CTTIsto(this);
/*  326 */       this.spfp = new T4CTTIspfp(this);
/*  327 */       this.commoncall = new T4C7Ocommoncall(this);
/*  328 */       this.describe = new T4C8Odscrarr(this);
/*  329 */       this.bfileMsg = new T4C8TTIBfile(this);
/*  330 */       this.blobMsg = new T4C8TTIBlob(this);
/*  331 */       this.clobMsg = new T4C8TTIClob(this);
/*  332 */       this.otxen = new T4CTTIOtxen(this);
/*  333 */       this.otxse = new T4CTTIOtxse(this);
/*  334 */       this.oping = new T4CTTIoping(this);
/*  335 */       this.k2rpc = new T4CTTIk2rpc(this);
/*  336 */       this.oses = new T4CTTIoses(this);
/*  337 */       this.okeyval = new T4CTTIokeyval(this);
/*  338 */       this.oxssro = new T4CTTIoxssro(this);
/*  339 */       this.oxsspo = new T4CTTIoxsspo(this);
/*  340 */       this.oxsscs = new T4CTTIoxsscs(this);
/*  341 */       this.xsnsop = new T4CTTIxsnsop(this);
/*  342 */       this.aqe = new T4Caqe(this);
/*  343 */       this.aqdq = new T4Caqdq(this);
/*  344 */       this.oscid = new T4CTTIoscid(this);
/*      */       
/*      */ 
/*  347 */       this.LOGON_MODE = 0L;
/*  348 */       if (this.internalLogon != null)
/*      */       {
/*      */ 
/*      */ 
/*  352 */         if (this.internalLogon.equalsIgnoreCase("sysoper"))
/*      */         {
/*  354 */           this.LOGON_MODE = 64L;
/*      */         }
/*  356 */         else if (this.internalLogon.equalsIgnoreCase("sysdba"))
/*      */         {
/*  358 */           this.LOGON_MODE = 32L;
/*      */         }
/*  360 */         else if (this.internalLogon.equalsIgnoreCase("sysasm"))
/*      */         {
/*  362 */           this.LOGON_MODE = 4194304L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  367 */       if (this.prelimAuth) {
/*  368 */         this.LOGON_MODE |= 0x80;
/*      */       }
/*  370 */       this.auth = new T4CTTIoauthenticate(this, this.resourceManagerId, this.serverCompileTimeCapabilities);
/*      */       
/*  372 */       if ((this.userName != null) && (this.userName.length() != 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  385 */           this.auth.doOSESSKEY(this.userName, this.LOGON_MODE);
/*      */         }
/*      */         catch (SQLException localSQLException2)
/*      */         {
/*  389 */           if (localSQLException2.getErrorCode() == 1017)
/*      */           {
/*  391 */             localObject1 = localSQLException2;
/*  392 */             this.userName = null;
/*      */           }
/*      */           else
/*      */           {
/*  396 */             throw localSQLException2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  401 */       this.auth.doOAUTH(this.userName, this.password, this.LOGON_MODE);
/*      */       
/*  403 */       this.sessionId = getSessionId();
/*  404 */       this.serialNumber = getSerialNumber();
/*  405 */       this.internalName = this.auth.internalName;
/*  406 */       this.externalName = this.auth.externalName;
/*  407 */       this.instanceName = this.sessionProperties.getProperty("AUTH_INSTANCENAME");
/*      */       
/*  409 */       if (!this.prelimAuth)
/*      */       {
/*      */ 
/*  412 */         T4C7Oversion localT4C7Oversion = new T4C7Oversion(this);
/*  413 */         localT4C7Oversion.doOVERSION();
/*      */         
/*  415 */         localObject2 = localT4C7Oversion.getVersion();
/*      */         try
/*      */         {
/*  418 */           this.databaseProductVersion = new String((byte[])localObject2, "UTF8");
/*      */ 
/*      */ 
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */         {
/*      */ 
/*  425 */           SQLException localSQLException4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localUnsupportedEncodingException);
/*  426 */           localSQLException4.fillInStackTrace();
/*  427 */           throw localSQLException4;
/*      */         }
/*      */         
/*      */ 
/*  431 */         this.versionNumber = localT4C7Oversion.getVersionNumber();
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  438 */         this.versionNumber = 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  447 */       this.isLoggedOn = true;
/*      */       
/*      */ 
/*      */ 
/*  451 */       if (getVersionNumber() < 11000) {
/*  452 */         this.enableTempLobRefCnt = false;
/*      */       }
/*      */     }
/*      */     catch (NetException localNetException)
/*      */     {
/*  457 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localNetException);
/*  458 */       ((SQLException)localObject2).fillInStackTrace();
/*  459 */       throw ((Throwable)localObject2);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  464 */       handleIOException(localIOException);
/*      */       
/*  466 */       Object localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  467 */       ((SQLException)localObject2).fillInStackTrace();
/*  468 */       throw ((Throwable)localObject2);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException3)
/*      */     {
/*      */ 
/*  475 */       if (localObject1 != null)
/*      */       {
/*  477 */         localSQLException3.initCause((Throwable)localObject1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  485 */         this.net.disconnect();
/*      */       }
/*      */       catch (Exception localException) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  492 */       this.isLoggedOn = false;
/*      */       
/*  494 */       throw localSQLException3;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void handleIOException(IOException paramIOException)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  504 */       this.pipeState = -1;
/*  505 */       this.net.disconnect();
/*  506 */       this.net = null;
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  513 */     this.isLoggedOn = false;
/*  514 */     this.lifecycle = 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void logoff()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  538 */       assertLoggedOn("T4CConnection.logoff");
/*  539 */       if (this.lifecycle == 8) {
/*      */         return;
/*      */       }
/*  542 */       sendPiggyBackedMessages();
/*  543 */       this.commoncall.doOLOGOFF();
/*  544 */       this.net.disconnect();
/*  545 */       this.net = null;
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  550 */       handleIOException(localIOException);
/*      */       
/*  552 */       if (this.lifecycle != 8)
/*      */       {
/*      */ 
/*  555 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  556 */         localSQLException.fillInStackTrace();
/*  557 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  566 */         if (this.net != null) {
/*  567 */           this.net.disconnect();
/*      */         }
/*      */       }
/*      */       catch (Exception localException4) {}
/*      */       
/*      */ 
/*      */ 
/*  574 */       this.isLoggedOn = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CMAREngine getMarshalEngine()
/*      */   {
/*  583 */     return this.mare;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doCommit(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  604 */     assertLoggedOn("T4CConnection.do_commit");
/*      */     try
/*      */     {
/*  607 */       sendPiggyBackedMessages();
/*  608 */       if (paramInt == 0)
/*      */       {
/*  610 */         this.commoncall.doOCOMMIT();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  628 */         int i = 0;
/*  629 */         if ((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0) {
/*  630 */           i = i | 0x2 | 0x1;
/*      */         }
/*  632 */         else if ((paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) {
/*  633 */           i |= 0x2;
/*      */         }
/*  635 */         if ((paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0) {
/*  636 */           i = i | 0x8 | 0x4;
/*      */         }
/*  638 */         else if ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0) {
/*  639 */           i |= 0x8;
/*      */         }
/*  641 */         this.otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, i);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  650 */         int j = this.otxen.getOutStateFromServer();
/*      */         
/*  652 */         if ((j == 2) || (j == 4)) {}
/*      */       }
/*      */       
/*      */ 
/*      */       SQLException localSQLException;
/*      */       
/*      */       return;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  662 */       handleIOException(localIOException);
/*      */       
/*  664 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  665 */       localSQLException.fillInStackTrace();
/*  666 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doRollback()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  692 */       assertLoggedOn("T4CConnection.do_rollback");
/*  693 */       sendPiggyBackedMessages();
/*  694 */       this.commoncall.doOROLLBACK();
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  699 */       handleIOException(localIOException);
/*      */       
/*  701 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  702 */       localSQLException.fillInStackTrace();
/*  703 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doSetAutoCommit(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  727 */     this.autocommit = paramBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(OracleStatement paramOracleStatement)
/*      */     throws SQLException
/*      */   {
/*  764 */     assertLoggedOn("T4CConnection.open");
/*  765 */     paramOracleStatement.setCursorId(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized String doGetDatabaseProductVersion()
/*      */     throws SQLException
/*      */   {
/*  779 */     assertLoggedOn("T4CConnection.do_getDatabaseProductVersion");
/*      */     
/*  781 */     T4C7Oversion localT4C7Oversion = new T4C7Oversion(this);
/*      */     try
/*      */     {
/*  784 */       localT4C7Oversion.doOVERSION();
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  789 */       handleIOException(localIOException);
/*      */       
/*  791 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  792 */       ((SQLException)localObject).fillInStackTrace();
/*  793 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  797 */     String str = null;
/*      */     
/*  799 */     Object localObject = localT4C7Oversion.getVersion();
/*      */     try
/*      */     {
/*  802 */       str = new String((byte[])localObject, "UTF8");
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*      */     {
/*      */ 
/*  809 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localUnsupportedEncodingException);
/*  810 */       localSQLException.fillInStackTrace();
/*  811 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  815 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized short doGetVersionNumber()
/*      */     throws SQLException
/*      */   {
/*  828 */     assertLoggedOn("T4CConnection.do_getVersionNumber");
/*      */     
/*  830 */     T4C7Oversion localT4C7Oversion = new T4C7Oversion(this);
/*      */     try
/*      */     {
/*  833 */       localT4C7Oversion.doOVERSION();
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  838 */       handleIOException(localIOException);
/*      */       
/*  840 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  841 */       localSQLException.fillInStackTrace();
/*  842 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  846 */     return localT4C7Oversion.getVersionNumber();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfByte, OracleStatement paramOracleStatement)
/*      */     throws SQLException
/*      */   {
/*  854 */     T4CStatement localT4CStatement = new T4CStatement(this, -1, -1);
/*      */     
/*      */     try
/*      */     {
/*  858 */       int i = this.mare.unmarshalRefCursor(paramArrayOfByte);
/*      */       
/*  860 */       localT4CStatement.setCursorId(i);
/*      */       
/*  862 */       localT4CStatement.isOpen = true;
/*      */       
/*      */ 
/*      */ 
/*  866 */       localT4CStatement.sqlObject = paramOracleStatement.sqlObject;
/*      */       
/*  868 */       localT4CStatement.serverCursor = true;
/*  869 */       paramOracleStatement.addChild(localT4CStatement);
/*  870 */       localT4CStatement.prepareForNewResults(true, false);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  875 */       handleIOException(localIOException);
/*      */       
/*  877 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  878 */       localSQLException.fillInStackTrace();
/*  879 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  884 */     localT4CStatement.sqlStringChanged = false;
/*  885 */     localT4CStatement.needToParse = false;
/*      */     
/*  887 */     return localT4CStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cancelOperationOnServer()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  902 */       switch (this.pipeState)
/*      */       {
/*      */ 
/*      */       case -1: 
/*  906 */         return;
/*      */       case 1: 
/*  908 */         this.net.sendBreak();
/*  909 */         break;
/*      */       case 2: 
/*  911 */         this.net.sendInterrupt();
/*      */       }
/*      */       
/*  914 */       this.sentCancel = true;
/*      */ 
/*      */     }
/*      */     catch (NetException localNetException)
/*      */     {
/*      */ 
/*  920 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localNetException);
/*  921 */       localSQLException.fillInStackTrace();
/*  922 */       throw localSQLException;
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/*  929 */       handleIOException(localIOException);
/*      */       
/*  931 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  932 */       localSQLException.fillInStackTrace();
/*  933 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void connect(String paramString)
/*      */     throws IOException, SQLException
/*      */   {
/*  978 */     if (paramString == null)
/*      */     {
/*      */ 
/*      */ 
/*  982 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
/*  983 */       ((SQLException)localObject).fillInStackTrace();
/*  984 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  989 */     Object localObject = new Properties();
/*  990 */     if (this.thinNetProfile != null)
/*  991 */       ((Properties)localObject).setProperty("oracle.net.profile", this.thinNetProfile);
/*  992 */     if (this.thinNetAuthenticationServices != null) {
/*  993 */       ((Properties)localObject).setProperty("oracle.net.authentication_services", this.thinNetAuthenticationServices);
/*      */     }
/*  995 */     if (this.thinNetAuthenticationKrb5Mutual != null) {
/*  996 */       ((Properties)localObject).setProperty("oracle.net.kerberos5_mutual_authentication", this.thinNetAuthenticationKrb5Mutual);
/*      */     }
/*  998 */     if (this.thinNetAuthenticationKrb5CcName != null) {
/*  999 */       ((Properties)localObject).setProperty("oracle.net.kerberos5_cc_name", this.thinNetAuthenticationKrb5CcName);
/*      */     }
/* 1001 */     if (this.thinNetEncryptionLevel != null) {
/* 1002 */       ((Properties)localObject).setProperty("oracle.net.encryption_client", this.thinNetEncryptionLevel);
/*      */     }
/* 1004 */     if (this.thinNetEncryptionTypes != null) {
/* 1005 */       ((Properties)localObject).setProperty("oracle.net.encryption_types_client", this.thinNetEncryptionTypes);
/*      */     }
/* 1007 */     if (this.thinNetChecksumLevel != null) {
/* 1008 */       ((Properties)localObject).setProperty("oracle.net.crypto_checksum_client", this.thinNetChecksumLevel);
/*      */     }
/* 1010 */     if (this.thinNetChecksumTypes != null) {
/* 1011 */       ((Properties)localObject).setProperty("oracle.net.crypto_checksum_types_client", this.thinNetChecksumTypes);
/*      */     }
/* 1013 */     if (this.thinNetCryptoSeed != null)
/* 1014 */       ((Properties)localObject).setProperty("oracle.net.crypto_seed", this.thinNetCryptoSeed);
/* 1015 */     if (this.thinTcpNoDelay)
/* 1016 */       ((Properties)localObject).setProperty("TCP.NODELAY", "YES");
/* 1017 */     if (this.thinReadTimeout != null) {
/* 1018 */       ((Properties)localObject).setProperty("oracle.net.READ_TIMEOUT", this.thinReadTimeout);
/*      */     }
/* 1020 */     if (this.thinNetConnectTimeout != null) {
/* 1021 */       ((Properties)localObject).setProperty("oracle.net.CONNECT_TIMEOUT", this.thinNetConnectTimeout);
/*      */     }
/* 1023 */     if (this.thinSslServerDnMatch != null) {
/* 1024 */       ((Properties)localObject).setProperty("oracle.net.ssl_server_dn_match", this.thinSslServerDnMatch);
/*      */     }
/* 1026 */     if (this.walletLocation != null) {
/* 1027 */       ((Properties)localObject).setProperty("oracle.net.wallet_location", this.walletLocation);
/*      */     }
/* 1029 */     if (this.walletPassword != null) {
/* 1030 */       ((Properties)localObject).setProperty("oracle.net.wallet_password", this.walletPassword);
/*      */     }
/* 1032 */     if (this.thinSslVersion != null) {
/* 1033 */       ((Properties)localObject).setProperty("oracle.net.ssl_version", this.thinSslVersion);
/*      */     }
/* 1035 */     if (this.thinSslCipherSuites != null) {
/* 1036 */       ((Properties)localObject).setProperty("oracle.net.ssl_cipher_suites", this.thinSslCipherSuites);
/*      */     }
/* 1038 */     if (this.thinJavaxNetSslKeystore != null) {
/* 1039 */       ((Properties)localObject).setProperty("javax.net.ssl.keyStore", this.thinJavaxNetSslKeystore);
/*      */     }
/* 1041 */     if (this.thinJavaxNetSslKeystoretype != null) {
/* 1042 */       ((Properties)localObject).setProperty("javax.net.ssl.keyStoreType", this.thinJavaxNetSslKeystoretype);
/*      */     }
/* 1044 */     if (this.thinJavaxNetSslKeystorepassword != null) {
/* 1045 */       ((Properties)localObject).setProperty("javax.net.ssl.keyStorePassword", this.thinJavaxNetSslKeystorepassword);
/*      */     }
/* 1047 */     if (this.thinJavaxNetSslTruststore != null) {
/* 1048 */       ((Properties)localObject).setProperty("javax.net.ssl.trustStore", this.thinJavaxNetSslTruststore);
/*      */     }
/* 1050 */     if (this.thinJavaxNetSslTruststoretype != null) {
/* 1051 */       ((Properties)localObject).setProperty("javax.net.ssl.trustStoreType", this.thinJavaxNetSslTruststoretype);
/*      */     }
/* 1053 */     if (this.thinJavaxNetSslTruststorepassword != null) {
/* 1054 */       ((Properties)localObject).setProperty("javax.net.ssl.trustStorePassword", this.thinJavaxNetSslTruststorepassword);
/*      */     }
/* 1056 */     if (this.thinSslKeymanagerfactoryAlgorithm != null) {
/* 1057 */       ((Properties)localObject).setProperty("ssl.keyManagerFactory.algorithm", this.thinSslKeymanagerfactoryAlgorithm);
/*      */     }
/* 1059 */     if (this.thinSslTrustmanagerfactoryAlgorithm != null) {
/* 1060 */       ((Properties)localObject).setProperty("ssl.trustManagerFactory.algorithm", this.thinSslTrustmanagerfactoryAlgorithm);
/*      */     }
/* 1062 */     if (this.thinNetOldsyntax != null)
/* 1063 */       ((Properties)localObject).setProperty("oracle.net.oldSyntax", this.thinNetOldsyntax);
/* 1064 */     if (this.thinNamingContextInitial != null)
/* 1065 */       ((Properties)localObject).setProperty("java.naming.factory.initial", this.thinNamingContextInitial);
/* 1066 */     if (this.thinNamingProviderUrl != null)
/* 1067 */       ((Properties)localObject).setProperty("java.naming.provider.url", this.thinNamingProviderUrl);
/* 1068 */     if (this.thinNamingSecurityAuthentication != null) {
/* 1069 */       ((Properties)localObject).setProperty("java.naming.security.authentication", this.thinNamingSecurityAuthentication);
/*      */     }
/* 1071 */     if (this.thinNamingSecurityPrincipal != null) {
/* 1072 */       ((Properties)localObject).setProperty("java.naming.security.principal", this.thinNamingSecurityPrincipal);
/*      */     }
/* 1074 */     if (this.thinNamingSecurityCredentials != null) {
/* 1075 */       ((Properties)localObject).setProperty("java.naming.security.credentials", this.thinNamingSecurityCredentials);
/*      */     }
/* 1077 */     if (this.thinNetDisableOutOfBandBreak) {
/* 1078 */       ((Properties)localObject).setProperty("DISABLE_OOB", "" + this.thinNetDisableOutOfBandBreak);
/*      */     }
/* 1080 */     if (this.thinNetEnableSDP) {
/* 1081 */       ((Properties)localObject).setProperty("oracle.net.SDP", "" + this.thinNetEnableSDP);
/*      */     }
/* 1083 */     ((Properties)localObject).setProperty("USE_ZERO_COPY_IO", "" + this.thinNetUseZeroCopyIO);
/*      */     
/* 1085 */     ((Properties)localObject).setProperty("FORCE_DNS_LOAD_BALANCING", "" + this.thinForceDnsLoadBalancing);
/*      */     
/* 1087 */     ((Properties)localObject).setProperty("ENABLE_JAVANET_FASTPATH", "" + this.enableJavaNetFastPath);
/*      */     
/*      */ 
/* 1090 */     ((Properties)localObject).setProperty("oracle.jdbc.v$session.osuser", this.thinVsessionOsuser);
/* 1091 */     ((Properties)localObject).setProperty("oracle.jdbc.v$session.program", this.thinVsessionProgram);
/* 1092 */     ((Properties)localObject).setProperty("T4CConnection.hashCode", Integer.toHexString(hashCode()).toUpperCase());
/*      */     
/*      */ 
/* 1095 */     ((Properties)localObject).setProperty("oracle.net.keepAlive", Boolean.toString(this.keepAlive));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1100 */     this.net = new NSProtocol();
/*      */     
/* 1102 */     this.net.connect(paramString, (Properties)localObject);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1112 */     this.mare = new T4CMAREngine(this.net, this.enableJavaNetFastPath);
/* 1113 */     this.oer = new T4CTTIoer(this);
/* 1114 */     this.mare.setConnectionDuringExceptionHandling(this);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1120 */     this.pro = new T4C8TTIpro(this);
/*      */     
/* 1122 */     this.pro.marshal();
/*      */     
/* 1124 */     this.serverCompileTimeCapabilities = this.pro.receive();
/* 1125 */     this.serverRuntimeCapabilities = this.pro.getServerRuntimeCapabilities();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1130 */     short s1 = this.pro.getOracleVersion();
/* 1131 */     short s2 = this.pro.getCharacterSet();
/* 1132 */     short s3 = DBConversion.findDriverCharSet(s2, s1);
/*      */     
/*      */ 
/* 1135 */     this.conversion = new DBConversion(s2, s3, this.pro.getncharCHARSET(), this.isStrictAsciiConversion);
/*      */     
/*      */ 
/* 1138 */     this.mare.types.setServerConversion(s3 != s2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1143 */     if (DBConversion.isCharSetMultibyte(s3))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1149 */       if (DBConversion.isCharSetMultibyte(this.pro.getCharacterSet())) {
/* 1150 */         this.mare.types.setFlags((byte)1);
/*      */       } else {
/* 1152 */         this.mare.types.setFlags((byte)2);
/*      */       }
/*      */     } else {
/* 1155 */       this.mare.types.setFlags(this.pro.getFlags());
/*      */     }
/* 1157 */     this.mare.conv = this.conversion;
/*      */     
/*      */ 
/*      */ 
/* 1161 */     T4C8TTIdty localT4C8TTIdty = new T4C8TTIdty(this, this.serverCompileTimeCapabilities, this.serverRuntimeCapabilities, (this.logonCap != null) && (this.logonCap.trim().equals("o3")), this.thinNetUseZeroCopyIO);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1166 */     localT4C8TTIdty.doRPC();
/*      */     
/*      */ 
/*      */ 
/* 1170 */     this.negotiatedTTCversion = this.serverCompileTimeCapabilities[7];
/* 1171 */     if (localT4C8TTIdty.jdbcThinCompileTimeCapabilities[7] < this.serverCompileTimeCapabilities[7]) {
/* 1172 */       this.negotiatedTTCversion = localT4C8TTIdty.jdbcThinCompileTimeCapabilities[7];
/*      */     }
/*      */     
/*      */ 
/* 1176 */     if ((this.serverRuntimeCapabilities != null) && (this.serverRuntimeCapabilities.length > 6) && ((this.serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0) && (this.thinNetUseZeroCopyIO) && ((this.net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0) && (getDataIntegrityAlgorithmName().equals("")) && (getEncryptionAlgorithmName().equals("")))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1187 */       this.useZeroCopyIO = true;
/*      */     } else {
/* 1189 */       this.useZeroCopyIO = false;
/*      */     }
/*      */     
/*      */ 
/* 1193 */     if ((this.serverCompileTimeCapabilities.length > 23) && ((this.serverCompileTimeCapabilities[23] & 0x40) != 0) && ((localT4C8TTIdty.jdbcThinCompileTimeCapabilities[23] & 0x40) != 0))
/*      */     {
/*      */ 
/* 1196 */       this.useLobPrefetch = true;
/*      */     } else {
/* 1198 */       this.useLobPrefetch = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isZeroCopyIOEnabled()
/*      */   {
/* 1209 */     return this.useZeroCopyIO;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final T4CTTIoer getT4CTTIoer()
/*      */   {
/* 1228 */     return this.oer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final byte getTTCVersion()
/*      */   {
/* 1238 */     return this.negotiatedTTCversion;
/*      */   }
/*      */   
/*      */ 
/*      */   void doStartup(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1247 */       int i = 0;
/* 1248 */       if (paramInt == OracleConnection.DatabaseStartupMode.FORCE.getMode()) {
/* 1249 */         i = 16;
/* 1250 */       } else if (paramInt == OracleConnection.DatabaseStartupMode.RESTRICT.getMode())
/* 1251 */         i = 1;
/* 1252 */       this.spfp.doOSPFPPUT();
/* 1253 */       this.sto.doOV6STRT(i);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1257 */       handleIOException(localIOException);
/*      */       
/* 1259 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1260 */       localSQLException.fillInStackTrace();
/* 1261 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void doShutdown(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1273 */       int i = 4;
/*      */       
/* 1275 */       if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL.getMode()) {
/* 1276 */         i = 128;
/* 1277 */       } else if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode()) {
/* 1278 */         i = 256;
/* 1279 */       } else if (paramInt == OracleConnection.DatabaseShutdownMode.IMMEDIATE.getMode()) {
/* 1280 */         i = 2;
/* 1281 */       } else if (paramInt == OracleConnection.DatabaseShutdownMode.FINAL.getMode()) {
/* 1282 */         i = 8;
/* 1283 */       } else if (paramInt == OracleConnection.DatabaseShutdownMode.ABORT.getMode()) {
/* 1284 */         i = 64;
/*      */       }
/* 1286 */       sendPiggyBackedMessages();
/* 1287 */       this.sto.doOV6STOP(i);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1291 */       handleIOException(localIOException);
/*      */       
/* 1293 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1294 */       localSQLException.fillInStackTrace();
/* 1295 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void sendPiggyBackedMessages()
/*      */     throws SQLException, IOException
/*      */   {
/* 1304 */     sendPiggyBackedClose();
/*      */     
/*      */ 
/*      */ 
/* 1308 */     if ((this.endToEndAnyChanged) && (getTTCVersion() >= 3))
/*      */     {
/*      */ 
/* 1311 */       this.oscid.doOSCID(this.endToEndHasChanged, this.endToEndValues, this.endToEndECIDSequenceNumber);
/*      */       
/*      */ 
/* 1314 */       for (int i = 0; i < 4; i++) {
/* 1315 */         if (this.endToEndHasChanged[i] != 0)
/* 1316 */           this.endToEndHasChanged[i] = false;
/*      */       }
/*      */     }
/* 1319 */     this.endToEndAnyChanged = false;
/*      */     
/* 1321 */     if (!this.namespaces.isEmpty())
/*      */     {
/* 1323 */       if (getTTCVersion() >= 4)
/*      */       {
/* 1325 */         Object[] arrayOfObject = this.namespaces.values().toArray();
/* 1326 */         for (int k = 0; k < arrayOfObject.length; k++)
/*      */         {
/* 1328 */           this.okeyval.doOKEYVAL((Namespace)arrayOfObject[k]);
/*      */         }
/*      */       }
/* 1331 */       this.namespaces.clear();
/*      */     }
/*      */     
/*      */ 
/* 1335 */     if (this.lusOffset2 > 0)
/*      */     {
/* 1337 */       for (int j = 0; j < this.lusOffset2; j++) {
/* 1338 */         this.oxsspo.doOXSSPO(this.lusFunctionId2[j], this.lusSessionId2[j], this.lusInKeyVal2[j], this.lusInFlags2[j]);
/*      */       }
/*      */       
/*      */ 
/* 1342 */       this.lusOffset2 = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendPiggyBackedClose()
/*      */     throws SQLException, IOException
/*      */   {
/* 1353 */     if (this.queryToCloseOffset > 0)
/*      */     {
/* 1355 */       this.close8.doOCANA(this.queryToClose, this.queryToCloseOffset);
/* 1356 */       this.queryToCloseOffset = 0;
/*      */     }
/*      */     
/*      */ 
/* 1360 */     if (this.cursorToCloseOffset > 0)
/*      */     {
/* 1362 */       this.close8.doOCCA(this.cursorToClose, this.cursorToCloseOffset);
/* 1363 */       this.cursorToCloseOffset = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void doProxySession(int paramInt, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1373 */       sendPiggyBackedMessages();
/*      */       
/*      */ 
/*      */ 
/* 1377 */       this.auth.doOAUTH(paramInt, paramProperties, this.sessionId, this.serialNumber);
/*      */       
/* 1379 */       int i = getSessionId();
/* 1380 */       int j = getSerialNumber();
/*      */       
/*      */ 
/* 1383 */       this.oses.doO80SES(i, j, 1);
/*      */       
/* 1385 */       this.savedUser = this.userName;
/*      */       
/* 1387 */       if (paramInt == 1) {
/* 1388 */         this.userName = paramProperties.getProperty("PROXY_USER_NAME");
/*      */       } else {
/* 1390 */         this.userName = null;
/*      */       }
/* 1392 */       this.isProxy = true;
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/* 1398 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1399 */       localSQLException.fillInStackTrace();
/* 1400 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeProxySession()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1412 */       sendPiggyBackedMessages();
/* 1413 */       this.commoncall.doOLOGOFF();
/*      */       
/* 1415 */       this.oses.doO80SES(this.sessionId, this.serialNumber, 1);
/*      */       
/* 1417 */       this.userName = this.savedUser;
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/* 1423 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1424 */       localSQLException.fillInStackTrace();
/* 1425 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateSessionProperties(KeywordValue[] paramArrayOfKeywordValue)
/*      */     throws SQLException
/*      */   {
/* 1435 */     for (int i = 0; i < paramArrayOfKeywordValue.length; i++)
/*      */     {
/* 1437 */       int j = paramArrayOfKeywordValue[i].getKeyword();
/* 1438 */       byte[] arrayOfByte = paramArrayOfKeywordValue[i].getBinaryValue();
/* 1439 */       if (j < T4C8Oall.NLS_KEYS.length)
/*      */       {
/* 1441 */         String str1 = T4C8Oall.NLS_KEYS[j];
/* 1442 */         if (str1 != null)
/*      */         {
/* 1444 */           if (arrayOfByte != null)
/*      */           {
/* 1446 */             this.sessionProperties.setProperty(str1, this.mare.conv.CharBytesToString(arrayOfByte, arrayOfByte.length));
/*      */ 
/*      */ 
/*      */           }
/* 1450 */           else if (paramArrayOfKeywordValue[i].getTextValue() != null)
/*      */           {
/* 1452 */             this.sessionProperties.setProperty(str1, paramArrayOfKeywordValue[i].getTextValue().trim());
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 1457 */       else if (j == 163)
/*      */       {
/* 1459 */         if (arrayOfByte != null)
/*      */         {
/*      */ 
/* 1462 */           int k = arrayOfByte[4];
/* 1463 */           int m = arrayOfByte[5];
/*      */           
/* 1465 */           if ((arrayOfByte[4] & 0xFF) > 120)
/*      */           {
/* 1467 */             k = (arrayOfByte[4] & 0xFF) - 181;
/* 1468 */             m = (arrayOfByte[5] & 0xFF) - 60;
/*      */           }
/*      */           else {
/* 1471 */             k = (arrayOfByte[4] & 0xFF) - 60;
/* 1472 */             m = (arrayOfByte[5] & 0xFF) - 60;
/*      */           }
/*      */           
/* 1475 */           String str2 = (k > 0 ? "+" : "") + k + (m <= 9 ? ":0" : ":") + m;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1480 */           this.sessionProperties.setProperty("SESSION_TIME_ZONE", str2);
/*      */         }
/*      */         
/*      */       }
/* 1484 */       else if (j != 165)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1497 */         if (j != 166)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1509 */           if (j != 167)
/*      */           {
/*      */ 
/*      */ 
/* 1513 */             if (j != 168)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1526 */               if (j != 169)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1538 */                 if (j != 170)
/*      */                 {
/*      */ 
/* 1541 */                   if (j != 171) {}
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Properties getServerSessionInfo()
/*      */     throws SQLException
/*      */   {
/* 1556 */     if ((getVersionNumber() >= 10000) && (getVersionNumber() < 10200))
/* 1557 */       queryFCFProperties(this.sessionProperties);
/* 1558 */     return this.sessionProperties;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getSessionTimeZoneOffset()
/*      */     throws SQLException
/*      */   {
/* 1565 */     String str = getServerSessionInfo().getProperty("SESSION_TIME_ZONE");
/* 1566 */     if (str == null)
/*      */     {
/* 1568 */       str = super.getSessionTimeZoneOffset();
/*      */     }
/*      */     else
/*      */     {
/* 1572 */       str = tzToOffset(str);
/*      */     }
/* 1574 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getSessionId()
/*      */   {
/* 1581 */     int i = -1;
/* 1582 */     String str = this.sessionProperties.getProperty("AUTH_SESSION_ID");
/*      */     
/*      */     try
/*      */     {
/* 1586 */       i = Integer.parseInt(str);
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException) {}
/* 1589 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getSerialNumber()
/*      */   {
/* 1596 */     int i = -1;
/* 1597 */     String str = this.sessionProperties.getProperty("AUTH_SERIAL_NUM");
/*      */     
/*      */     try
/*      */     {
/* 1601 */       i = Integer.parseInt(str);
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException) {}
/* 1604 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty)
/*      */     throws SQLException
/*      */   {
/* 1613 */     byte b = 0;
/* 1614 */     SQLException localSQLException; if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED)
/*      */     {
/*      */ 
/* 1617 */       if ((this.serverRuntimeCapabilities == null) || (this.serverRuntimeCapabilities.length < 6))
/*      */       {
/* 1619 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256);
/* 1620 */         localSQLException.fillInStackTrace();
/* 1621 */         throw localSQLException;
/*      */       }
/*      */       
/* 1624 */       b = this.serverRuntimeCapabilities[5];
/*      */     }
/* 1626 */     else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE)
/*      */     {
/*      */ 
/* 1629 */       if ((this.serverRuntimeCapabilities == null) || (this.serverRuntimeCapabilities.length < 4))
/*      */       {
/* 1631 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256);
/* 1632 */         localSQLException.fillInStackTrace();
/* 1633 */         throw localSQLException;
/*      */       }
/*      */       
/* 1636 */       b = this.serverRuntimeCapabilities[3];
/*      */     }
/*      */     
/* 1639 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized BlobDBAccess createBlobDBAccess()
/*      */     throws SQLException
/*      */   {
/* 1659 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized ClobDBAccess createClobDBAccess()
/*      */     throws SQLException
/*      */   {
/* 1667 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized BfileDBAccess createBfileDBAccess()
/*      */     throws SQLException
/*      */   {
/* 1675 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long length(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1696 */     assertLoggedOn("length");
/* 1697 */     assertNotNull(paramBFILE.shareBytes(), "length");
/*      */     
/* 1699 */     needLine();
/*      */     
/* 1701 */     long l = 0L;
/*      */     
/*      */     try
/*      */     {
/* 1705 */       l = this.bfileMsg.getLength(paramBFILE.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1710 */       handleIOException(localIOException);
/*      */       
/* 1712 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1713 */       localSQLException.fillInStackTrace();
/* 1714 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1719 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfByte, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1736 */     assertNotNull(paramBFILE.shareBytes(), "position");
/*      */     
/* 1738 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 1741 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1742 */       localSQLException.fillInStackTrace();
/* 1743 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1748 */     long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfByte, paramLong);
/*      */     
/* 1750 */     l = l == 0L ? -1L : l;
/*      */     
/* 1752 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 1769 */     assertNotNull(paramBFILE1.shareBytes(), "position");
/*      */     
/* 1771 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 1774 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1775 */       localSQLException.fillInStackTrace();
/* 1776 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1781 */     long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong);
/*      */     
/* 1783 */     l = l == 0L ? -1L : l;
/*      */     
/* 1785 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 1801 */     assertLoggedOn("getBytes");
/* 1802 */     assertNotNull(paramBFILE.shareBytes(), "getBytes");
/*      */     
/*      */     SQLException localSQLException1;
/* 1805 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 1808 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()");
/* 1809 */       localSQLException1.fillInStackTrace();
/* 1810 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1816 */     if ((paramInt <= 0) || (paramArrayOfByte == null)) {
/* 1817 */       return 0;
/*      */     }
/* 1819 */     if (this.pipeState != -1)
/*      */     {
/*      */ 
/* 1822 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()");
/* 1823 */       localSQLException1.fillInStackTrace();
/* 1824 */       throw localSQLException1;
/*      */     }
/*      */     
/* 1827 */     needLine();
/*      */     
/* 1829 */     long l = 0L;
/*      */     
/* 1831 */     if (paramInt != 0)
/*      */     {
/*      */       try
/*      */       {
/* 1835 */         l = this.bfileMsg.read(paramBFILE.shareBytes(), paramLong, paramInt, paramArrayOfByte, 0);
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 1840 */         handleIOException(localIOException);
/*      */         
/* 1842 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1843 */         localSQLException2.fillInStackTrace();
/* 1844 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1850 */     return (int)l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1864 */     assertLoggedOn("getName");
/* 1865 */     assertNotNull(paramBFILE.shareBytes(), "getName");
/*      */     
/* 1867 */     String str = LobPlsqlUtil.fileGetName(paramBFILE);
/*      */     
/* 1869 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDirAlias(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1883 */     assertLoggedOn("getDirAlias");
/* 1884 */     assertNotNull(paramBFILE.shareBytes(), "getDirAlias");
/*      */     
/* 1886 */     String str = LobPlsqlUtil.fileGetDirAlias(paramBFILE);
/*      */     
/* 1888 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void openFile(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1901 */     assertLoggedOn("openFile");
/* 1902 */     assertNotNull(paramBFILE.shareBytes(), "openFile");
/*      */     
/* 1904 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 1908 */       this.bfileMsg.open(paramBFILE.shareBytes(), 11);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1913 */       handleIOException(localIOException);
/*      */       
/* 1915 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1916 */       localSQLException.fillInStackTrace();
/* 1917 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1936 */     assertLoggedOn("openFile");
/* 1937 */     assertNotNull(paramBFILE.shareBytes(), "openFile");
/*      */     
/* 1939 */     needLine();
/*      */     
/* 1941 */     boolean bool = false;
/*      */     
/*      */     try
/*      */     {
/* 1945 */       bool = this.bfileMsg.isOpen(paramBFILE.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1950 */       handleIOException(localIOException);
/*      */       
/* 1952 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1953 */       localSQLException.fillInStackTrace();
/* 1954 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1959 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean fileExists(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 1975 */     assertLoggedOn("fileExists");
/* 1976 */     assertNotNull(paramBFILE.shareBytes(), "fileExists");
/*      */     
/* 1978 */     needLine();
/*      */     
/* 1980 */     boolean bool = false;
/*      */     
/*      */     try
/*      */     {
/* 1984 */       bool = this.bfileMsg.doesExist(paramBFILE.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1989 */       handleIOException(localIOException);
/*      */       
/* 1991 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1992 */       localSQLException.fillInStackTrace();
/* 1993 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1998 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void closeFile(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 2011 */     assertLoggedOn("closeFile");
/* 2012 */     assertNotNull(paramBFILE.shareBytes(), "closeFile");
/*      */     
/* 2014 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 2018 */       this.bfileMsg.close(paramBFILE.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2023 */       handleIOException(localIOException);
/*      */       
/* 2025 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2026 */       localSQLException.fillInStackTrace();
/* 2027 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(BFILE paramBFILE, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2045 */     assertLoggedOn("open");
/* 2046 */     assertNotNull(paramBFILE.shareBytes(), "open");
/*      */     
/* 2048 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 2052 */       this.bfileMsg.open(paramBFILE.shareBytes(), paramInt);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2057 */       handleIOException(localIOException);
/*      */       
/* 2059 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2060 */       localSQLException.fillInStackTrace();
/* 2061 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 2075 */     assertLoggedOn("close");
/* 2076 */     assertNotNull(paramBFILE.shareBytes(), "close");
/*      */     
/* 2078 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 2082 */       this.bfileMsg.close(paramBFILE.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2087 */       handleIOException(localIOException);
/*      */       
/* 2089 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2090 */       localSQLException.fillInStackTrace();
/* 2091 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isOpen(BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 2106 */     assertLoggedOn("isOpen");
/* 2107 */     assertNotNull(paramBFILE.shareBytes(), "isOpen");
/*      */     
/* 2109 */     needLine();
/*      */     
/* 2111 */     boolean bool = false;
/*      */     
/*      */     try
/*      */     {
/* 2115 */       bool = this.bfileMsg.isOpen(paramBFILE.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2120 */       handleIOException(localIOException);
/*      */       
/* 2122 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2123 */       localSQLException.fillInStackTrace();
/* 2124 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 2128 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2147 */     if (paramLong == 0L)
/*      */     {
/* 2149 */       return new OracleBlobInputStream(paramBFILE, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 2153 */     return new OracleBlobInputStream(paramBFILE, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2172 */     assertNotNull(paramBFILE.shareBytes(), "newConversionInputStream");
/*      */     
/* 2174 */     OracleConversionInputStream localOracleConversionInputStream = new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */     
/* 2176 */     return localOracleConversionInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newConversionReader(BFILE paramBFILE, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2194 */     assertNotNull(paramBFILE.shareBytes(), "newConversionReader");
/*      */     
/* 2196 */     OracleConversionReader localOracleConversionReader = new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */     
/*      */ 
/* 2199 */     return localOracleConversionReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long length(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2221 */     assertLoggedOn("length");
/* 2222 */     assertNotNull(paramBLOB.shareBytes(), "length");
/*      */     
/* 2224 */     needLine();
/*      */     
/* 2226 */     long l = 0L;
/*      */     
/*      */     try
/*      */     {
/* 2230 */       l = this.blobMsg.getLength(paramBLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2235 */       handleIOException(localIOException);
/*      */       
/* 2237 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2238 */       localSQLException.fillInStackTrace();
/* 2239 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2244 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long position(BLOB paramBLOB, byte[] paramArrayOfByte, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2261 */     assertLoggedOn("position");
/* 2262 */     assertNotNull(paramBLOB.shareBytes(), "position");
/*      */     
/*      */ 
/* 2265 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2268 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2269 */       localSQLException.fillInStackTrace();
/* 2270 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2275 */     long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfByte, paramLong);
/*      */     
/* 2277 */     l = l == 0L ? -1L : l;
/*      */     
/* 2279 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2295 */     assertLoggedOn("position");
/* 2296 */     assertNotNull(paramBLOB1.shareBytes(), "position");
/* 2297 */     assertNotNull(paramBLOB2.shareBytes(), "position");
/*      */     
/*      */ 
/* 2300 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2303 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2304 */       localSQLException.fillInStackTrace();
/* 2305 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2310 */     long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong);
/*      */     
/* 2312 */     l = l == 0L ? -1L : l;
/*      */     
/* 2314 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2331 */     assertLoggedOn("getBytes");
/* 2332 */     assertNotNull(paramBLOB.shareBytes(), "getBytes");
/*      */     
/*      */     SQLException localSQLException1;
/* 2335 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2338 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()");
/* 2339 */       localSQLException1.fillInStackTrace();
/* 2340 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2347 */     if (this.pipeState != -1)
/*      */     {
/*      */ 
/* 2350 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()");
/* 2351 */       localSQLException1.fillInStackTrace();
/* 2352 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/* 2356 */     if ((paramInt <= 0) || (paramArrayOfByte == null)) {
/* 2357 */       return 0;
/*      */     }
/*      */     
/* 2360 */     long l1 = 0L;
/*      */     
/* 2362 */     long l2 = -1L;
/*      */     
/* 2364 */     if (paramBLOB.isActivePrefetch())
/*      */     {
/* 2366 */       byte[] arrayOfByte = paramBLOB.getPrefetchedData();
/* 2367 */       int i = paramBLOB.getPrefetchedDataSize();
/* 2368 */       l2 = paramBLOB.length();
/* 2369 */       int j = 0;
/*      */       
/* 2371 */       if (arrayOfByte != null) {
/* 2372 */         j = Math.min(i, arrayOfByte.length);
/*      */       }
/* 2374 */       if ((j > 0) && (paramLong <= j))
/*      */       {
/*      */ 
/*      */ 
/* 2378 */         int k = Math.min(j - (int)paramLong + 1, paramInt);
/*      */         
/*      */ 
/* 2381 */         System.arraycopy(arrayOfByte, (int)paramLong - 1, paramArrayOfByte, 0, k);
/* 2382 */         l1 += k;
/*      */       }
/*      */     }
/*      */     
/* 2386 */     if ((l1 < paramInt) && ((l2 == -1L) || (paramLong - 1L + l1 < l2)))
/*      */     {
/* 2388 */       needLine();
/*      */       
/*      */       try
/*      */       {
/* 2392 */         l1 += this.blobMsg.read(paramBLOB.shareBytes(), paramLong + l1, paramInt - l1, paramArrayOfByte, (int)l1);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */ 
/*      */ 
/* 2401 */         handleIOException(localIOException);
/*      */         
/* 2403 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2404 */         localSQLException2.fillInStackTrace();
/* 2405 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2412 */     return (int)l1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2432 */     assertLoggedOn("putBytes");
/* 2433 */     assertNotNull(paramBLOB.shareBytes(), "putBytes");
/*      */     
/*      */ 
/* 2436 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 2439 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putBytes()");
/* 2440 */       localSQLException1.fillInStackTrace();
/* 2441 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2446 */     if ((paramArrayOfByte == null) || (paramInt2 <= 0)) {
/* 2447 */       return 0;
/*      */     }
/* 2449 */     needLine();
/*      */     
/* 2451 */     long l = 0L;
/*      */     
/* 2453 */     if (paramInt2 != 0)
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/* 2458 */         paramBLOB.setActivePrefetch(false);
/* 2459 */         paramBLOB.clearCachedData();
/* 2460 */         l = this.blobMsg.write(paramBLOB.shareBytes(), paramLong, paramArrayOfByte, paramInt1, paramInt2);
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */ 
/* 2466 */         handleIOException(localIOException);
/*      */         
/* 2468 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2469 */         localSQLException2.fillInStackTrace();
/* 2470 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2476 */     return (int)l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getChunkSize(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2488 */     assertLoggedOn("getChunkSize");
/* 2489 */     assertNotNull(paramBLOB.shareBytes(), "getChunkSize");
/*      */     
/* 2491 */     needLine();
/*      */     
/* 2493 */     long l = 0L;
/*      */     
/*      */     try
/*      */     {
/* 2497 */       l = this.blobMsg.getChunkSize(paramBLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2502 */       handleIOException(localIOException);
/*      */       
/* 2504 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2505 */       localSQLException.fillInStackTrace();
/* 2506 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2511 */     return (int)l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2525 */     assertLoggedOn("trim");
/* 2526 */     assertNotNull(paramBLOB.shareBytes(), "trim");
/*      */     
/*      */ 
/* 2529 */     if (paramLong < 0L)
/*      */     {
/*      */ 
/* 2532 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
/* 2533 */       localSQLException1.fillInStackTrace();
/* 2534 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2539 */     needLine();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2544 */       paramBLOB.setActivePrefetch(false);
/* 2545 */       paramBLOB.clearCachedData();
/* 2546 */       this.blobMsg.trim(paramBLOB.shareBytes(), paramLong);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2551 */       handleIOException(localIOException);
/*      */       
/* 2553 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2554 */       localSQLException2.fillInStackTrace();
/* 2555 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2577 */     assertLoggedOn("createTemporaryBlob");
/*      */     
/* 2579 */     needLine();
/*      */     
/* 2581 */     BLOB localBLOB = null;
/*      */     
/*      */     try
/*      */     {
/* 2585 */       localBLOB = (BLOB)this.blobMsg.createTemporaryLob(this, paramBoolean, paramInt);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2590 */       handleIOException(localIOException);
/*      */       
/* 2592 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2593 */       localSQLException.fillInStackTrace();
/* 2594 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2599 */     return localBLOB;
/*      */   }
/*      */   
/*      */ 
/* 2603 */   private final CRC32 checksumEngine = new CRC32();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2620 */   private final Hashtable<Long, Integer> tempLobRefCount = new Hashtable();
/*      */   static final int MAX_SIZE_VSESSION_OSUSER = 30;
/*      */   static final int MAX_SIZE_VSESSION_PROCESS = 24;
/*      */   
/* 2624 */   private final synchronized Long getLocatorHash(byte[] paramArrayOfByte) { this.checksumEngine.reset();
/* 2625 */     this.checksumEngine.update(paramArrayOfByte, 12, 8);
/* 2626 */     long l = this.checksumEngine.getValue();
/* 2627 */     return Long.valueOf(l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final synchronized int decrementTempLobReferenceCount(byte[] paramArrayOfByte)
/*      */   {
/* 2635 */     int i = 0;
/* 2636 */     if ((this.enableTempLobRefCnt) && (paramArrayOfByte != null) && (paramArrayOfByte.length > 20) && (((paramArrayOfByte[7] & 0x1) > 0) || ((paramArrayOfByte[4] & 0x40) > 0)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2642 */       Long localLong = getLocatorHash(paramArrayOfByte);
/* 2643 */       Integer localInteger = (Integer)this.tempLobRefCount.get(localLong);
/* 2644 */       if (localInteger != null)
/*      */       {
/* 2646 */         i = localInteger.intValue() - 1;
/* 2647 */         if (i == 0) {
/* 2648 */           this.tempLobRefCount.remove(localLong);
/*      */         } else {
/* 2650 */           this.tempLobRefCount.put(localLong, Integer.valueOf(i));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2659 */     return i;
/*      */   }
/*      */   
/*      */   public final synchronized void incrementTempLobReferenceCount(byte[] paramArrayOfByte) {
/* 2663 */     if ((this.enableTempLobRefCnt) && (paramArrayOfByte != null) && (paramArrayOfByte.length >= 20) && (((paramArrayOfByte[7] & 0x1) > 0) || ((paramArrayOfByte[4] & 0x40) > 0)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2669 */       Long localLong = getLocatorHash(paramArrayOfByte);
/* 2670 */       Integer localInteger = (Integer)this.tempLobRefCount.get(localLong);
/*      */       
/* 2672 */       if (localInteger != null)
/*      */       {
/* 2674 */         int i = localInteger.intValue();
/* 2675 */         this.tempLobRefCount.put(localLong, Integer.valueOf(i + 1));
/*      */       }
/*      */       else
/*      */       {
/* 2679 */         this.tempLobRefCount.put(localLong, Integer.valueOf(1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2695 */     assertLoggedOn("freeTemporary");
/* 2696 */     assertNotNull(paramBLOB.shareBytes(), "freeTemporary");
/*      */     
/* 2698 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 2702 */       this.blobMsg.freeTemporaryLob(paramBLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2707 */       handleIOException(localIOException);
/*      */       
/* 2709 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2710 */       localSQLException.fillInStackTrace();
/* 2711 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTemporary(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2730 */     assertNotNull(paramBLOB.shareBytes(), "isTemporary");
/*      */     
/*      */ 
/*      */ 
/* 2734 */     boolean bool = false;
/* 2735 */     byte[] arrayOfByte = paramBLOB.shareBytes();
/*      */     
/* 2737 */     if (((arrayOfByte[7] & 0x1) > 0) || ((arrayOfByte[4] & 0x40) > 0)) {
/* 2738 */       bool = true;
/*      */     }
/* 2740 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2753 */     assertLoggedOn("open");
/* 2754 */     assertNotNull(paramBLOB.shareBytes(), "open");
/*      */     
/* 2756 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 2760 */       this.blobMsg.open(paramBLOB.shareBytes(), paramInt);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2765 */       handleIOException(localIOException);
/*      */       
/* 2767 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2768 */       localSQLException.fillInStackTrace();
/* 2769 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2784 */     assertLoggedOn("close");
/* 2785 */     assertNotNull(paramBLOB.shareBytes(), "close");
/*      */     
/* 2787 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 2791 */       this.blobMsg.close(paramBLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2796 */       handleIOException(localIOException);
/*      */       
/* 2798 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2799 */       localSQLException.fillInStackTrace();
/* 2800 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isOpen(BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 2816 */     assertLoggedOn("isOpen");
/* 2817 */     assertNotNull(paramBLOB.shareBytes(), "isOpen");
/*      */     
/* 2819 */     needLine();
/*      */     
/* 2821 */     boolean bool = false;
/*      */     
/*      */     try
/*      */     {
/* 2825 */       bool = this.blobMsg.isOpen(paramBLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2830 */       handleIOException(localIOException);
/*      */       
/* 2832 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2833 */       localSQLException.fillInStackTrace();
/* 2834 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2839 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2858 */     if (paramLong == 0L)
/*      */     {
/* 2860 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 2864 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2)
/*      */     throws SQLException
/*      */   {
/* 2887 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2907 */     if (paramLong == 0L)
/*      */     {
/* 2909 */       if ((paramBoolean & this.lobStreamPosStandardCompliant))
/*      */       {
/*      */ 
/* 2912 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2913 */         localSQLException.fillInStackTrace();
/* 2914 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2919 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2924 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2943 */     assertNotNull(paramBLOB.shareBytes(), "newConversionInputStream");
/*      */     
/* 2945 */     OracleConversionInputStream localOracleConversionInputStream = new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */     
/*      */ 
/* 2948 */     return localOracleConversionInputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2966 */     assertNotNull(paramBLOB.shareBytes(), "newConversionReader");
/*      */     
/* 2968 */     OracleConversionReader localOracleConversionReader = new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */     
/*      */ 
/* 2971 */     return localOracleConversionReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long length(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 2996 */     assertLoggedOn("length");
/* 2997 */     assertNotNull(paramCLOB.shareBytes(), "length");
/*      */     
/* 2999 */     needLine();
/*      */     
/* 3001 */     long l = 0L;
/*      */     
/*      */     try
/*      */     {
/* 3005 */       l = this.clobMsg.getLength(paramCLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3010 */       handleIOException(localIOException);
/*      */       
/* 3012 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3013 */       localSQLException.fillInStackTrace();
/* 3014 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3019 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long position(CLOB paramCLOB, String paramString, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3036 */     if (paramString == null)
/*      */     {
/* 3038 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3039 */       ((SQLException)localObject).fillInStackTrace();
/* 3040 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 3043 */     assertLoggedOn("position");
/* 3044 */     assertNotNull(paramCLOB.shareBytes(), "position");
/*      */     
/*      */ 
/* 3047 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 3050 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3051 */       ((SQLException)localObject).fillInStackTrace();
/* 3052 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3057 */     Object localObject = new char[paramString.length()];
/*      */     
/* 3059 */     paramString.getChars(0, localObject.length, (char[])localObject, 0);
/*      */     
/* 3061 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, (char[])localObject, paramLong);
/*      */     
/* 3063 */     l = l == 0L ? -1L : l;
/*      */     
/* 3065 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3081 */     if (paramCLOB2 == null)
/*      */     {
/* 3083 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3084 */       localSQLException.fillInStackTrace();
/* 3085 */       throw localSQLException;
/*      */     }
/*      */     
/* 3088 */     assertLoggedOn("position");
/* 3089 */     assertNotNull(paramCLOB1.shareBytes(), "position");
/* 3090 */     assertNotNull(paramCLOB2.shareBytes(), "position");
/*      */     
/* 3092 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 3095 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3096 */       localSQLException.fillInStackTrace();
/* 3097 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 3101 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 3103 */     l = l == 0L ? -1L : l;
/*      */     
/* 3105 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfChar)
/*      */     throws SQLException
/*      */   {
/* 3122 */     assertLoggedOn("getChars");
/* 3123 */     assertNotNull(paramCLOB.shareBytes(), "getChars");
/*      */     SQLException localSQLException1;
/* 3125 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 3128 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getChars()");
/* 3129 */       localSQLException1.fillInStackTrace();
/* 3130 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3136 */     if (this.pipeState != -1)
/*      */     {
/*      */ 
/* 3139 */       localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getChars()");
/* 3140 */       localSQLException1.fillInStackTrace();
/* 3141 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3146 */     if ((paramInt <= 0) || (paramArrayOfChar == null)) {
/* 3147 */       return 0;
/*      */     }
/*      */     
/* 3150 */     long l1 = 0L;
/*      */     
/*      */ 
/* 3153 */     long l2 = -1L;
/*      */     
/*      */ 
/* 3156 */     if (paramCLOB.isActivePrefetch())
/*      */     {
/* 3158 */       l2 = paramCLOB.length();
/* 3159 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 3160 */       int i = paramCLOB.getPrefetchedDataSize();
/*      */       
/* 3162 */       int j = 0;
/* 3163 */       if (arrayOfChar != null) {
/* 3164 */         j = Math.min(i, arrayOfChar.length);
/*      */       }
/* 3166 */       if ((j > 0) && (paramLong <= j))
/*      */       {
/*      */ 
/*      */ 
/* 3170 */         int k = Math.min(j - (int)paramLong + 1, paramInt);
/*      */         
/*      */ 
/*      */ 
/* 3174 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfChar, 0, k);
/* 3175 */         l1 += k;
/*      */       }
/*      */     }
/*      */     
/* 3179 */     if ((l1 < paramInt) && ((l2 == -1L) || (paramLong - 1L + l1 < l2)))
/*      */     {
/*      */ 
/* 3182 */       needLine();
/*      */       try
/*      */       {
/* 3185 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3187 */         l1 += this.clobMsg.read(paramCLOB.shareBytes(), (int)paramLong + l1, paramInt - l1, bool, paramArrayOfChar, (int)l1);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 3197 */         handleIOException(localIOException);
/*      */         
/* 3199 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3200 */         localSQLException2.fillInStackTrace();
/* 3201 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3208 */     return (int)l1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3228 */     assertLoggedOn("putChars");
/* 3229 */     assertNotNull(paramCLOB.shareBytes(), "putChars");
/*      */     
/* 3231 */     if (paramLong < 1L)
/*      */     {
/*      */ 
/* 3234 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putChars()");
/* 3235 */       localSQLException1.fillInStackTrace();
/* 3236 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/* 3240 */     if ((paramArrayOfChar == null) || (paramInt2 <= 0)) {
/* 3241 */       return 0;
/*      */     }
/* 3243 */     needLine();
/*      */     
/* 3245 */     long l = 0L;
/*      */     
/* 3247 */     if (paramInt2 != 0)
/*      */     {
/*      */       try
/*      */       {
/* 3251 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3253 */         paramCLOB.setActivePrefetch(false);
/* 3254 */         paramCLOB.clearCachedData();
/* 3255 */         l = this.clobMsg.write(paramCLOB.shareBytes(), paramLong, bool, paramArrayOfChar, paramInt1, paramInt2);
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */ 
/* 3261 */         handleIOException(localIOException);
/*      */         
/* 3263 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3264 */         localSQLException2.fillInStackTrace();
/* 3265 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3271 */     return (int)l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getChunkSize(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 3283 */     assertLoggedOn("getChunkSize");
/* 3284 */     assertNotNull(paramCLOB.shareBytes(), "getChunkSize");
/*      */     
/* 3286 */     needLine();
/*      */     
/* 3288 */     long l = 0L;
/*      */     
/*      */     try
/*      */     {
/* 3292 */       l = this.clobMsg.getChunkSize(paramCLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3297 */       handleIOException(localIOException);
/*      */       
/* 3299 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3300 */       localSQLException.fillInStackTrace();
/* 3301 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3306 */     return (int)l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3320 */     assertLoggedOn("trim");
/* 3321 */     assertNotNull(paramCLOB.shareBytes(), "trim");
/*      */     
/*      */ 
/* 3324 */     if (paramLong < 0L)
/*      */     {
/*      */ 
/* 3327 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
/* 3328 */       localSQLException1.fillInStackTrace();
/* 3329 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3334 */     needLine();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 3339 */       paramCLOB.setActivePrefetch(false);
/* 3340 */       paramCLOB.clearCachedData();
/* 3341 */       this.clobMsg.trim(paramCLOB.shareBytes(), paramLong);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3346 */       handleIOException(localIOException);
/*      */       
/* 3348 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3349 */       localSQLException2.fillInStackTrace();
/* 3350 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 3373 */     assertLoggedOn("createTemporaryClob");
/*      */     
/*      */ 
/* 3376 */     if ((paramShort != 2) && (paramShort != 1))
/*      */     {
/*      */ 
/*      */ 
/* 3380 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 3381 */       ((SQLException)localObject).fillInStackTrace();
/* 3382 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3386 */     needLine();
/*      */     
/* 3388 */     Object localObject = null;
/*      */     
/*      */     try
/*      */     {
/* 3392 */       localObject = (CLOB)this.clobMsg.createTemporaryLob(this, paramBoolean, paramInt, paramShort);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/* 3398 */       handleIOException(localIOException);
/*      */       
/* 3400 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3401 */       localSQLException.fillInStackTrace();
/* 3402 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3407 */     return (CLOB)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3422 */     assertLoggedOn("freeTemporary");
/* 3423 */     assertNotNull(paramCLOB.shareBytes(), "freeTemporary");
/*      */     
/* 3425 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 3429 */       this.clobMsg.freeTemporaryLob(paramCLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3434 */       handleIOException(localIOException);
/*      */       
/* 3436 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3437 */       localSQLException.fillInStackTrace();
/* 3438 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTemporary(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 3459 */     boolean bool = false;
/* 3460 */     byte[] arrayOfByte = paramCLOB.shareBytes();
/*      */     
/* 3462 */     if (((arrayOfByte[7] & 0x1) > 0) || ((arrayOfByte[4] & 0x40) > 0)) {
/* 3463 */       bool = true;
/*      */     }
/* 3465 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3478 */     assertLoggedOn("open");
/* 3479 */     assertNotNull(paramCLOB.shareBytes(), "open");
/*      */     
/* 3481 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 3485 */       this.clobMsg.open(paramCLOB.shareBytes(), paramInt);
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3490 */       handleIOException(localIOException);
/*      */       
/* 3492 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3493 */       localSQLException.fillInStackTrace();
/* 3494 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 3509 */     assertLoggedOn("close");
/* 3510 */     assertNotNull(paramCLOB.shareBytes(), "close");
/*      */     
/* 3512 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 3516 */       this.clobMsg.close(paramCLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3521 */       handleIOException(localIOException);
/*      */       
/* 3523 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3524 */       localSQLException.fillInStackTrace();
/* 3525 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isOpen(CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 3541 */     assertLoggedOn("isOpen");
/* 3542 */     assertNotNull(paramCLOB.shareBytes(), "isOpen");
/*      */     
/* 3544 */     boolean bool = false;
/*      */     
/* 3546 */     needLine();
/*      */     
/*      */     try
/*      */     {
/* 3550 */       bool = this.clobMsg.isOpen(paramCLOB.shareBytes());
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3555 */       handleIOException(localIOException);
/*      */       
/* 3557 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3558 */       localSQLException.fillInStackTrace();
/* 3559 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3564 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3583 */     if (paramLong == 0L)
/*      */     {
/* 3585 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 3589 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3610 */     if (paramLong == 0L)
/*      */     {
/* 3612 */       if ((paramBoolean & this.lobStreamPosStandardCompliant))
/*      */       {
/*      */ 
/* 3615 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3616 */         localSQLException.fillInStackTrace();
/* 3617 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3622 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3627 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3647 */     if (paramLong == 0L)
/*      */     {
/* 3649 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/* 3653 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2)
/*      */     throws SQLException
/*      */   {
/* 3674 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3693 */     if (paramLong == 0L)
/*      */     {
/* 3695 */       if ((paramBoolean & this.lobStreamPosStandardCompliant))
/*      */       {
/*      */ 
/* 3698 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3699 */         localSQLException.fillInStackTrace();
/* 3700 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3705 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3710 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MAX_SIZE_VSESSION_MACHINE = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MAX_SIZE_VSESSION_TERMINAL = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MAX_SIZE_VSESSION_PROGRAM = 48;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void assertLoggedOn(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3736 */     if (!this.isLoggedOn)
/*      */     {
/*      */ 
/* 3739 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 430);
/* 3740 */       localSQLException.fillInStackTrace();
/* 3741 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void assertNotNull(byte[] paramArrayOfByte, String paramString)
/*      */     throws NullPointerException
/*      */   {
/* 3759 */     if (paramArrayOfByte == null)
/*      */     {
/* 3761 */       throw new NullPointerException("bytes are null");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void internalClose()
/*      */     throws SQLException
/*      */   {
/* 3770 */     super.internalClose();
/*      */     
/* 3772 */     this.isLoggedOn = false;
/*      */     try
/*      */     {
/* 3775 */       if (this.net != null) {
/* 3776 */         this.net.disconnect();
/*      */       }
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void doAbort()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3790 */       this.net.abort();
/*      */ 
/*      */     }
/*      */     catch (NetException localNetException)
/*      */     {
/*      */ 
/* 3796 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localNetException);
/* 3797 */       localSQLException.fillInStackTrace();
/* 3798 */       throw localSQLException;
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/* 3805 */       handleIOException(localIOException);
/*      */       
/* 3807 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3808 */       localSQLException.fillInStackTrace();
/* 3809 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo)
/*      */     throws SQLException
/*      */   {
/* 3820 */     T4CStatement localT4CStatement = new T4CStatement(this, -1, -1);
/* 3821 */     localT4CStatement.open();
/*      */     
/* 3823 */     String str1 = paramAutoKeyInfo.getTableName();
/* 3824 */     String str2 = "SELECT * FROM " + str1;
/*      */     
/* 3826 */     localT4CStatement.sqlObject.initialize(str2);
/*      */     
/* 3828 */     Accessor[] arrayOfAccessor = null;
/*      */     Object localObject;
/*      */     try
/*      */     {
/* 3832 */       this.describe.doODNY(localT4CStatement, 0, arrayOfAccessor, localT4CStatement.sqlObject.getSqlBytes(false, false));
/* 3833 */       arrayOfAccessor = this.describe.getAccessors();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3837 */       handleIOException(localIOException);
/*      */       
/* 3839 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3840 */       ((SQLException)localObject).fillInStackTrace();
/* 3841 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/* 3845 */     int i = this.describe.numuds;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3856 */     paramAutoKeyInfo.allocateSpaceForDescribedData(i);
/*      */     
/* 3858 */     for (int i1 = 0; i1 < i; i1++)
/*      */     {
/* 3860 */       Accessor localAccessor = arrayOfAccessor[i1];
/* 3861 */       localObject = localAccessor.columnName;
/* 3862 */       int j = localAccessor.describeType;
/* 3863 */       int k = localAccessor.describeMaxLength;
/* 3864 */       boolean bool = localAccessor.nullable;
/* 3865 */       short s = localAccessor.formOfUse;
/* 3866 */       int m = localAccessor.precision;
/* 3867 */       int n = localAccessor.scale;
/* 3868 */       String str3 = localAccessor.describeTypeName;
/*      */       
/* 3870 */       paramAutoKeyInfo.fillDescribedData(i1, (String)localObject, j, k, bool, s, m, n, str3);
/*      */     }
/*      */     
/*      */ 
/* 3874 */     localT4CStatement.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3)
/*      */     throws SQLException
/*      */   {
/* 3885 */     Namespace localNamespace = (Namespace)this.namespaces.get(paramString1);
/* 3886 */     if (localNamespace == null)
/*      */     {
/* 3888 */       localNamespace = new Namespace(paramString1);
/* 3889 */       this.namespaces.put(paramString1, localNamespace);
/*      */     }
/* 3891 */     localNamespace.setAttribute(paramString2, paramString3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClearAllApplicationContext(String paramString)
/*      */     throws SQLException
/*      */   {
/* 3900 */     Namespace localNamespace = new Namespace(paramString);
/* 3901 */     localNamespace.clear();
/* 3902 */     this.namespaces.put(paramString, localNamespace);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 3910 */     super.getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   final void getPasswordInternal(T4CXAResource paramT4CXAResource)
/*      */     throws SQLException
/*      */   {
/* 3918 */     paramT4CXAResource.setPasswordInternal(this.password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[][] paramArrayOfByte, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3936 */       needLine();
/* 3937 */       sendPiggyBackedMessages();
/* 3938 */       this.aqe.doOAQEQ(paramString, paramAQEnqueueOptions, paramAQMessagePropertiesI, paramArrayOfByte2, paramArrayOfByte1, paramBoolean);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3945 */       if (paramAQEnqueueOptions.getRetrieveMessageId()) {
/* 3946 */         paramArrayOfByte[0] = this.aqe.getMessageId();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3950 */       handleIOException(localIOException);
/*      */       
/* 3952 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3953 */       localSQLException.fillInStackTrace();
/* 3954 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1, byte[][] paramArrayOfByte2, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3971 */     boolean bool = false;
/*      */     try
/*      */     {
/* 3974 */       needLine();
/* 3975 */       sendPiggyBackedMessages();
/* 3976 */       this.aqdq.doOAQDQ(paramString, paramAQDequeueOptions, paramArrayOfByte, paramBoolean, paramAQMessagePropertiesI);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3982 */       paramArrayOfByte1[0] = this.aqdq.getPayload();
/* 3983 */       paramArrayOfByte2[0] = this.aqdq.getDequeuedMessageId();
/* 3984 */       bool = this.aqdq.hasAMessageBeenDequeued();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 3988 */       handleIOException(localIOException);
/*      */       
/* 3990 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3991 */       localSQLException.fillInStackTrace();
/* 3992 */       throw localSQLException;
/*      */     }
/*      */     
/* 3995 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */   synchronized int doPingDatabase()
/*      */     throws SQLException
/*      */   {
/* 4002 */     if (this.versionNumber >= 10102)
/*      */     {
/*      */       try
/*      */       {
/* 4006 */         needLine();
/* 4007 */         sendPiggyBackedMessages();
/* 4008 */         this.oping.doOPING();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 4012 */         return -1;
/*      */       }
/*      */       catch (SQLException localSQLException)
/*      */       {
/* 4016 */         return -1;
/*      */       }
/* 4018 */       return 0;
/*      */     }
/*      */     
/*      */ 
/* 4022 */     return super.doPingDatabase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties)
/*      */     throws SQLException
/*      */   {
/* 4035 */     int i = paramArrayOfString.length;
/* 4036 */     int[] arrayOfInt1 = new int[i];
/* 4037 */     byte[][] arrayOfByte = new byte[i][];
/* 4038 */     int[] arrayOfInt2 = new int[i];
/* 4039 */     int[] arrayOfInt3 = new int[i];
/* 4040 */     int[] arrayOfInt4 = new int[i];
/* 4041 */     int[] arrayOfInt5 = new int[i];
/* 4042 */     int[] arrayOfInt6 = new int[i];
/* 4043 */     int[] arrayOfInt7 = new int[i];
/* 4044 */     long[] arrayOfLong = new long[i];
/* 4045 */     byte[] arrayOfByte1 = new byte[i];
/* 4046 */     int[] arrayOfInt8 = new int[i];
/* 4047 */     byte[] arrayOfByte2 = new byte[i];
/* 4048 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[i];
/* 4049 */     int[] arrayOfInt9 = new int[i];
/*      */     
/* 4051 */     boolean bool1 = false;
/* 4052 */     if (paramInt == 0)
/*      */     {
/*      */ 
/* 4055 */       bool1 = true;
/* 4056 */       paramInt = 47632;
/*      */     }
/*      */     
/* 4059 */     for (int j = 0; j < i; j++)
/*      */     {
/* 4061 */       arrayOfInt1[j] = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4062 */       arrayOfByte[j] = new byte[4];
/* 4063 */       arrayOfByte[j][0] = ((byte)((arrayOfInt1[j] & 0xFF000000) >> 24));
/* 4064 */       arrayOfByte[j][1] = ((byte)((arrayOfInt1[j] & 0xFF0000) >> 16));
/* 4065 */       arrayOfByte[j][2] = ((byte)((arrayOfInt1[j] & 0xFF00) >> 8));
/* 4066 */       arrayOfByte[j][3] = ((byte)(arrayOfInt1[j] & 0xFF));
/* 4067 */       arrayOfInt2[j] = 1;
/* 4068 */       arrayOfInt3[j] = 23;
/*      */       
/*      */ 
/* 4071 */       if ((paramArrayOfProperties.length > j) && (paramArrayOfProperties[j] != null))
/*      */       {
/* 4073 */         if (paramArrayOfProperties[j].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4075 */           arrayOfInt4[j] |= 0x1; }
/* 4076 */         if (paramArrayOfProperties[j].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4078 */           arrayOfInt4[j] |= 0x10; }
/* 4079 */         if (paramArrayOfProperties[j].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4081 */           arrayOfInt4[j] |= 0x2; }
/* 4082 */         arrayOfInt5[j] = readNTFtimeout(paramArrayOfProperties[j]);
/*      */       }
/*      */     }
/*      */     
/* 4086 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9, paramArrayOfProperties);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4093 */     int[] arrayOfInt10 = new int[1];
/* 4094 */     arrayOfInt10[0] = paramInt;
/*      */     
/*      */ 
/*      */ 
/* 4098 */     boolean bool2 = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt10, bool1);
/* 4099 */     paramInt = arrayOfInt10[0];
/*      */     
/* 4101 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt + "))?PR=0";
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 4108 */         int k = bool2 ? 1 : 0;
/* 4109 */         sendPiggyBackedMessages();
/* 4110 */         this.okpn.doOKPN(1, k, this.userName, str, i, arrayOfInt2, paramArrayOfString, arrayOfByte, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfLong, arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4134 */         handleIOException(localIOException);
/*      */         
/* 4136 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4137 */         localSQLException2.fillInStackTrace();
/* 4138 */         throw localSQLException2;
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 4144 */       if (bool2) {
/* 4145 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt);
/*      */       }
/* 4147 */       throw localSQLException1;
/*      */     }
/* 4149 */     NTFAQRegistration[] arrayOfNTFAQRegistration = new NTFAQRegistration[i];
/*      */     
/* 4151 */     for (int m = 0; m < i; m++) {
/* 4152 */       arrayOfNTFAQRegistration[m] = new NTFAQRegistration(arrayOfInt1[m], true, this.instanceName, this.userName, paramString, paramInt, paramArrayOfProperties[m], paramArrayOfString[m], this.versionNumber);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4162 */     for (m = 0; m < arrayOfNTFAQRegistration.length; m++)
/* 4163 */       PhysicalConnection.ntfManager.addRegistration(arrayOfNTFAQRegistration[m]);
/* 4164 */     return arrayOfNTFAQRegistration;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setNtfGroupingOptions(byte[] paramArrayOfByte1, int[] paramArrayOfInt1, byte[] paramArrayOfByte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfInt2, Properties[] paramArrayOfProperties)
/*      */     throws SQLException
/*      */   {
/* 4183 */     for (int i = 0; i < paramArrayOfProperties.length; i++)
/*      */     {
/* 4185 */       String str1 = paramArrayOfProperties[i].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
/* 4186 */       String str2 = paramArrayOfProperties[i].getProperty("NTF_GROUPING_VALUE");
/* 4187 */       String str3 = paramArrayOfProperties[i].getProperty("NTF_GROUPING_TYPE");
/* 4188 */       TIMESTAMPTZ localTIMESTAMPTZ = null;
/* 4189 */       if (paramArrayOfProperties[i].get("NTF_GROUPING_START_TIME") != null)
/* 4190 */         localTIMESTAMPTZ = (TIMESTAMPTZ)paramArrayOfProperties[i].get("NTF_GROUPING_START_TIME");
/* 4191 */       String str4 = paramArrayOfProperties[i].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
/*      */       
/*      */       SQLException localSQLException;
/* 4194 */       if ((str1.compareTo("NTF_GROUPING_CLASS_TIME") != 0) && (str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0))
/*      */       {
/*      */ 
/*      */ 
/* 4198 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4199 */         localSQLException.fillInStackTrace();
/* 4200 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4205 */       if ((str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0) && (getTTCVersion() < 5))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 4210 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4211 */         localSQLException.fillInStackTrace();
/* 4212 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4218 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") == 0)
/*      */       {
/* 4220 */         paramArrayOfByte1[i] = 1;
/*      */         
/* 4222 */         paramArrayOfInt1[i] = 600;
/* 4223 */         if (str2 != null) {
/* 4224 */           paramArrayOfInt1[i] = Integer.parseInt(str2);
/*      */         }
/* 4226 */         paramArrayOfByte2[i] = 1;
/* 4227 */         if (str3 != null)
/*      */         {
/* 4229 */           if (str3.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0) {
/* 4230 */             paramArrayOfByte2[i] = 1;
/* 4231 */           } else if (str3.compareTo("NTF_GROUPING_TYPE_LAST") == 0) {
/* 4232 */             paramArrayOfByte2[i] = 2;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 4238 */             localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4239 */             localSQLException.fillInStackTrace();
/* 4240 */             throw localSQLException;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 4245 */         paramArrayOfTIMESTAMPTZ[i] = localTIMESTAMPTZ;
/* 4246 */         if (str4.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0) {
/* 4247 */           paramArrayOfInt2[i] = 0;
/*      */         } else {
/* 4249 */           paramArrayOfInt2[i] = Integer.parseInt(str4);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration)
/*      */     throws SQLException
/*      */   {
/* 4261 */     String str1 = paramNTFAQRegistration.getClientHost();
/* 4262 */     int i = paramNTFAQRegistration.getClientTCPPort();
/* 4263 */     if (str1 == null) {
/* 4264 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4274 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFAQRegistration);
/* 4275 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFAQRegistration.getJdbcRegId());
/* 4276 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFAQRegistration.getClientTCPPort());
/* 4277 */     paramNTFAQRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4279 */     String str2 = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + i + "))?PR=0";
/*      */     
/*      */ 
/* 4282 */     int[] arrayOfInt1 = { 1 };
/* 4283 */     String[] arrayOfString = new String[1];
/* 4284 */     arrayOfString[0] = paramNTFAQRegistration.getQueueName();
/* 4285 */     int[] arrayOfInt2 = { 0 };
/* 4286 */     int[] arrayOfInt3 = { 0 };
/* 4287 */     int[] arrayOfInt4 = { 0 };
/* 4288 */     int[] arrayOfInt5 = { 0 };
/* 4289 */     int[] arrayOfInt6 = { 0 };
/* 4290 */     long[] arrayOfLong = { 0L };
/* 4291 */     byte[] arrayOfByte1 = { 0 };
/* 4292 */     int[] arrayOfInt7 = { 0 };
/* 4293 */     byte[] arrayOfByte2 = { 0 };
/* 4294 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4295 */     int[] arrayOfInt8 = { 0 };
/* 4296 */     byte[][] arrayOfByte = new byte[1][];
/* 4297 */     int j = paramNTFAQRegistration.getJdbcRegId();
/* 4298 */     arrayOfByte[0] = new byte[4];
/* 4299 */     arrayOfByte[0][0] = ((byte)((j & 0xFF000000) >> 24));
/* 4300 */     arrayOfByte[0][1] = ((byte)((j & 0xFF0000) >> 16));
/* 4301 */     arrayOfByte[0][2] = ((byte)((j & 0xFF00) >> 8));
/* 4302 */     arrayOfByte[0][3] = ((byte)(j & 0xFF));
/*      */     try
/*      */     {
/* 4305 */       sendPiggyBackedMessages();
/* 4306 */       this.okpn.doOKPN(2, 0, this.userName, str2, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4330 */       handleIOException(localIOException);
/*      */       
/* 4332 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4333 */       localSQLException.fillInStackTrace();
/* 4334 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3)
/*      */     throws SQLException
/*      */   {
/* 4350 */     int i = 0;
/* 4351 */     int j = 0;
/* 4352 */     int k = 0;
/* 4353 */     int m = 0;
/* 4354 */     int n = 0;
/* 4355 */     Object localObject = null;
/* 4356 */     int i1 = 0;
/* 4357 */     boolean bool1 = false;
/* 4358 */     if (paramInt1 == 0)
/*      */     {
/*      */ 
/* 4361 */       bool1 = true;
/* 4362 */       paramInt1 = 47632;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4367 */     if (paramProperties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4369 */       j |= 0x1; }
/* 4370 */     if (paramProperties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4372 */       j |= 0x10;
/*      */     }
/*      */     
/*      */ 
/* 4376 */     if (paramProperties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4378 */       i |= 0x10;
/*      */     }
/*      */     
/* 4381 */     if (paramProperties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4383 */       i |= 0x20;
/*      */     }
/*      */     
/* 4386 */     if (paramProperties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4388 */       i |= 0x40;
/*      */     }
/* 4390 */     int i2 = 0;
/* 4391 */     int i3 = 0;
/* 4392 */     int i4 = 0;
/* 4393 */     if (paramProperties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4395 */       i2 = 1; }
/* 4396 */     if (paramProperties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4398 */       i3 = 1; }
/* 4399 */     if (paramProperties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4401 */       i4 = 1;
/*      */     }
/* 4403 */     if ((i2 != 0) || (i3 != 0) || (i4 != 0))
/*      */     {
/* 4405 */       i |= 0xF;
/*      */       
/*      */ 
/*      */ 
/* 4409 */       if (i2 != 0)
/* 4410 */         i -= 2;
/* 4411 */       if (i3 != 0)
/* 4412 */         i -= 4;
/* 4413 */       if (i4 != 0) {
/* 4414 */         i -= 8;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4420 */     byte[] arrayOfByte1 = new byte[1];
/* 4421 */     int[] arrayOfInt1 = new int[1];
/* 4422 */     byte[] arrayOfByte2 = new byte[1];
/* 4423 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[1];
/* 4424 */     int[] arrayOfInt2 = new int[1];
/* 4425 */     Properties[] arrayOfProperties = { paramProperties };
/* 4426 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2, arrayOfProperties);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4442 */     int[] arrayOfInt3 = new int[1];
/* 4443 */     arrayOfInt3[0] = paramInt1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4448 */     boolean bool2 = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt3, bool1);
/* 4449 */     paramInt1 = arrayOfInt3[0];
/*      */     
/* 4451 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt1 + "))?PR=0";
/*      */     
/*      */ 
/*      */ 
/* 4455 */     int[] arrayOfInt4 = { 2 };
/* 4456 */     String[] arrayOfString = new String[1];
/* 4457 */     int[] arrayOfInt5 = { 23 };
/*      */     
/*      */ 
/* 4460 */     int[] arrayOfInt6 = { j };
/* 4461 */     int[] arrayOfInt7 = { paramInt2 };
/* 4462 */     int[] arrayOfInt8 = { i };
/* 4463 */     int[] arrayOfInt9 = { paramInt3 };
/* 4464 */     long[] arrayOfLong = { 0L };
/* 4465 */     int i5 = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4466 */     byte[][] arrayOfByte = new byte[1][];
/* 4467 */     arrayOfByte[0] = new byte[4];
/* 4468 */     arrayOfByte[0][0] = ((byte)((i5 & 0xFF000000) >> 24));
/* 4469 */     arrayOfByte[0][1] = ((byte)((i5 & 0xFF0000) >> 16));
/* 4470 */     arrayOfByte[0][2] = ((byte)((i5 & 0xFF00) >> 8));
/* 4471 */     arrayOfByte[0][3] = ((byte)(i5 & 0xFF));
/* 4472 */     long l = 0L;
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 4477 */         int i6 = bool2 ? 1 : 0;
/* 4478 */         sendPiggyBackedMessages();
/* 4479 */         this.okpn.doOKPN(1, i6, this.userName, str, 1, arrayOfInt4, arrayOfString, arrayOfByte, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfInt8, arrayOfInt9, arrayOfLong, arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4500 */         l = this.okpn.getRegistrationId();
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 4504 */         handleIOException(localIOException);
/*      */         
/* 4506 */         SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4507 */         localSQLException2.fillInStackTrace();
/* 4508 */         throw localSQLException2;
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 4514 */       if (bool2) {
/* 4515 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt1);
/*      */       }
/* 4517 */       throw localSQLException1;
/*      */     }
/* 4519 */     NTFDCNRegistration localNTFDCNRegistration = new NTFDCNRegistration(i5, true, this.instanceName, l, this.userName, paramString, paramInt1, paramProperties, this.versionNumber);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4530 */     return localNTFDCNRegistration;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doUnregisterDatabaseChangeNotification(long paramLong, String paramString)
/*      */     throws SQLException
/*      */   {
/* 4543 */     int[] arrayOfInt1 = { 2 };
/* 4544 */     String[] arrayOfString = new String[1];
/* 4545 */     int[] arrayOfInt2 = { 0 };
/* 4546 */     int[] arrayOfInt3 = { 0 };
/* 4547 */     int[] arrayOfInt4 = { 0 };
/* 4548 */     int[] arrayOfInt5 = { 0 };
/* 4549 */     int[] arrayOfInt6 = { 0 };
/* 4550 */     byte[] arrayOfByte1 = { 0 };
/* 4551 */     int[] arrayOfInt7 = { 0 };
/* 4552 */     byte[] arrayOfByte2 = { 0 };
/* 4553 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4554 */     int[] arrayOfInt8 = { 0 };
/* 4555 */     long[] arrayOfLong = { paramLong };
/* 4556 */     byte[][] arrayOfByte = new byte[1][];
/*      */     try
/*      */     {
/* 4559 */       sendPiggyBackedMessages();
/* 4560 */       this.okpn.doOKPN(2, 0, null, paramString, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4584 */       handleIOException(localIOException);
/*      */       
/* 4586 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4587 */       localSQLException.fillInStackTrace();
/* 4588 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration)
/*      */     throws SQLException
/*      */   {
/* 4601 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFDCNRegistration);
/* 4602 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFDCNRegistration.getJdbcRegId());
/* 4603 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFDCNRegistration.getClientTCPPort());
/* 4604 */     paramNTFDCNRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4606 */     doUnregisterDatabaseChangeNotification(paramNTFDCNRegistration.getRegId(), "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramNTFDCNRegistration.getClientHost() + ")(PORT=" + paramNTFDCNRegistration.getClientTCPPort() + "))?PR=0");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDataIntegrityAlgorithmName()
/*      */     throws SQLException
/*      */   {
/* 4616 */     return this.net.getDataIntegrityName();
/*      */   }
/*      */   
/*      */ 
/*      */   public String getEncryptionAlgorithmName()
/*      */     throws SQLException
/*      */   {
/* 4623 */     return this.net.getEncryptionName();
/*      */   }
/*      */   
/*      */ 
/*      */   public String getAuthenticationAdaptorName()
/*      */     throws SQLException
/*      */   {
/* 4630 */     return this.net.getAuthenticationAdaptorName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void validateConnectionProperties()
/*      */     throws SQLException
/*      */   {
/* 4645 */     super.validateConnectionProperties();
/*      */     
/* 4647 */     String str = ".*[\\00\\(\\)].*";
/* 4648 */     SQLException localSQLException; if ((this.thinVsessionOsuser != null) && ((this.thinVsessionOsuser.matches(str)) || (this.thinVsessionOsuser.length() > 30)))
/*      */     {
/*      */ 
/*      */ 
/* 4652 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.osuser' and value is '" + this.thinVsessionOsuser + "'");
/* 4653 */       localSQLException.fillInStackTrace();
/* 4654 */       throw localSQLException;
/*      */     }
/*      */     
/* 4657 */     if ((this.thinVsessionTerminal != null) && ((this.thinVsessionTerminal.matches(str)) || (this.thinVsessionTerminal.length() > 30)))
/*      */     {
/*      */ 
/*      */ 
/* 4661 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.terminal' and value is '" + this.thinVsessionTerminal + "'");
/* 4662 */       localSQLException.fillInStackTrace();
/* 4663 */       throw localSQLException;
/*      */     }
/*      */     
/* 4666 */     if ((this.thinVsessionMachine != null) && ((this.thinVsessionMachine.matches(str)) || (this.thinVsessionMachine.length() > 64)))
/*      */     {
/*      */ 
/*      */ 
/* 4670 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.machine' and value is '" + this.thinVsessionMachine + "'");
/* 4671 */       localSQLException.fillInStackTrace();
/* 4672 */       throw localSQLException;
/*      */     }
/*      */     
/* 4675 */     if ((this.thinVsessionProgram != null) && ((this.thinVsessionProgram.matches(str)) || (this.thinVsessionProgram.length() > 48)))
/*      */     {
/*      */ 
/*      */ 
/* 4679 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.program' and value is '" + this.thinVsessionProgram + "'");
/* 4680 */       localSQLException.fillInStackTrace();
/* 4681 */       throw localSQLException;
/*      */     }
/*      */     
/* 4684 */     if ((this.thinVsessionProcess != null) && ((this.thinVsessionProcess.matches(str)) || (this.thinVsessionProcess.length() > 24)))
/*      */     {
/*      */ 
/*      */ 
/* 4688 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.process' and value is '" + this.thinVsessionProcess + "'");
/* 4689 */       localSQLException.fillInStackTrace();
/* 4690 */       throw localSQLException;
/*      */     }
/*      */     
/* 4693 */     if ((this.thinVsessionIname != null) && (this.thinVsessionIname.matches(str)))
/*      */     {
/* 4695 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.iname' and value is '" + this.thinVsessionIname + "'");
/* 4696 */       localSQLException.fillInStackTrace();
/* 4697 */       throw localSQLException;
/*      */     }
/*      */     
/* 4700 */     if ((this.thinVsessionEname != null) && (this.thinVsessionEname.matches(str)))
/*      */     {
/* 4702 */       localSQLException = DatabaseError.createSqlException(null, 190, "Property is 'v$session.ename' and value is '" + this.thinVsessionEname + "'");
/* 4703 */       localSQLException.fillInStackTrace();
/* 4704 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 4710 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   
/*      */ 
/*      */ 
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 4725 */     if ((paramArrayOfKeywordValueLong1.length != 1) || (paramArrayOfInt.length != 1))
/*      */     {
/* 4727 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4728 */       ((SQLException)localObject).fillInStackTrace();
/* 4729 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/* 4732 */     Object localObject = null;
/*      */     try
/*      */     {
/* 4735 */       sendPiggyBackedMessages();
/* 4736 */       this.oxsscs.doOXSSCS(paramString, paramArrayOfKeywordValueLong, paramInt);
/* 4737 */       localObject = this.oxsscs.getSessionId();
/* 4738 */       paramArrayOfKeywordValueLong1[0] = this.oxsscs.getOutKV();
/* 4739 */       paramArrayOfInt[0] = this.oxsscs.getOutFlags();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 4743 */       handleIOException(localIOException);
/*      */       
/* 4745 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4746 */       localSQLException.fillInStackTrace();
/* 4747 */       throw localSQLException;
/*      */     }
/*      */     
/* 4750 */     return (byte[])localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfByte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 4766 */     XSNamespace[] arrayOfXSNamespace = null;
/*      */     try
/*      */     {
/* 4769 */       if (paramBoolean)
/* 4770 */         sendPiggyBackedMessages();
/* 4771 */       this.xsnsop.doOXSNS(paramXSOperationCode, paramArrayOfByte, paramArrayOfXSNamespace, paramBoolean);
/* 4772 */       if (paramBoolean) {
/* 4773 */         arrayOfXSNamespace = this.xsnsop.getNamespaces();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/* 4777 */       handleIOException(localIOException);
/*      */       
/* 4779 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4780 */       localSQLException.fillInStackTrace();
/* 4781 */       throw localSQLException;
/*      */     }
/*      */     
/* 4784 */     if ((paramArrayOfXSNamespace1 != null) && (paramArrayOfXSNamespace1.length > 0)) {
/* 4785 */       paramArrayOfXSNamespace1[0] = arrayOfXSNamespace;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfByte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1)
/*      */     throws SQLException
/*      */   {
/* 4799 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfByte, paramArrayOfXSNamespace, paramArrayOfXSNamespace1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfByte, XSNamespace[] paramArrayOfXSNamespace)
/*      */     throws SQLException
/*      */   {
/* 4811 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfByte, paramArrayOfXSNamespace, (XSNamespace[][])null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfByte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 4823 */     if ((paramArrayOfKeywordValueLong1.length != 1) || (paramArrayOfInt.length != 1))
/*      */     {
/* 4825 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4826 */       localSQLException1.fillInStackTrace();
/* 4827 */       throw localSQLException1;
/*      */     }
/*      */     try
/*      */     {
/* 4831 */       sendPiggyBackedMessages();
/* 4832 */       this.oxssro.doOXSSRO(paramInt1, paramArrayOfByte, paramArrayOfKeywordValueLong, paramInt2);
/* 4833 */       paramArrayOfKeywordValueLong1[0] = this.oxssro.getOutKV();
/* 4834 */       paramArrayOfInt[0] = this.oxssro.getOutFlags();
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 4838 */       handleIOException(localIOException);
/*      */       
/* 4840 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 4841 */       localSQLException2.fillInStackTrace();
/* 4842 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfByte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 4855 */     if (this.lusOffset2 == this.lusFunctionId2.length)
/*      */     {
/* 4857 */       int i = this.lusFunctionId2.length;
/* 4858 */       int[] arrayOfInt1 = new int[i * 2];
/* 4859 */       System.arraycopy(this.lusFunctionId2, 0, arrayOfInt1, 0, i);
/* 4860 */       byte[][] arrayOfByte = new byte[i * 2][];
/* 4861 */       System.arraycopy(this.lusSessionId2, 0, arrayOfByte, 0, i);
/* 4862 */       KeywordValueLong[][] arrayOfKeywordValueLong = new KeywordValueLong[i * 2][];
/* 4863 */       System.arraycopy(this.lusInKeyVal2, 0, arrayOfKeywordValueLong, 0, i);
/* 4864 */       int[] arrayOfInt2 = new int[i * 2];
/* 4865 */       System.arraycopy(this.lusInFlags2, 0, arrayOfInt2, 0, i);
/* 4866 */       this.lusFunctionId2 = arrayOfInt1;
/* 4867 */       this.lusSessionId2 = arrayOfByte;
/* 4868 */       this.lusInKeyVal2 = arrayOfKeywordValueLong;
/* 4869 */       this.lusInFlags2 = arrayOfInt2;
/*      */     }
/* 4871 */     this.lusFunctionId2[this.lusOffset2] = paramInt1;
/* 4872 */     this.lusSessionId2[this.lusOffset2] = paramArrayOfByte;
/* 4873 */     this.lusInKeyVal2[this.lusOffset2] = paramArrayOfKeywordValueLong;
/* 4874 */     this.lusInFlags2[this.lusOffset2] = paramInt2;
/* 4875 */     this.lusOffset2 += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor)
/*      */     throws SQLException
/*      */   {
/* 4886 */     if (this.lifecycle != 1)
/*      */     {
/* 4888 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4889 */       ((SQLException)localObject1).fillInStackTrace();
/* 4890 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/* 4893 */     Object localObject1 = new NTFEventListener(paramXSEventListener);
/* 4894 */     ((NTFEventListener)localObject1).setExecutor(paramExecutor);
/* 4895 */     synchronized (this.xsListeners)
/*      */     {
/* 4897 */       int i = this.xsListeners.length;
/* 4898 */       for (int j = 0; j < i; j++) {
/* 4899 */         if (this.xsListeners[j].getXSEventListener() == paramXSEventListener)
/*      */         {
/*      */ 
/*      */ 
/* 4903 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 4904 */           localSQLException.fillInStackTrace();
/* 4905 */           throw localSQLException;
/*      */         }
/*      */       }
/*      */       
/* 4909 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 4910 */       System.arraycopy(this.xsListeners, 0, arrayOfNTFEventListener, 0, i);
/*      */       
/* 4912 */       arrayOfNTFEventListener[i] = localObject1;
/*      */       
/* 4914 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener)
/*      */     throws SQLException
/*      */   {
/* 4925 */     addXSEventListener(paramXSEventListener, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeXSEventListener(XSEventListener paramXSEventListener)
/*      */     throws SQLException
/*      */   {
/* 4933 */     synchronized (this.xsListeners)
/*      */     {
/*      */ 
/* 4936 */       int i = 0;
/* 4937 */       int j = this.xsListeners.length;
/*      */       
/* 4939 */       for (i = 0; i < j; i++)
/* 4940 */         if (this.xsListeners[i].getXSEventListener() == paramXSEventListener)
/*      */           break;
/* 4942 */       if (i == j)
/*      */       {
/*      */ 
/*      */ 
/* 4946 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 4947 */         ((SQLException)localObject1).fillInStackTrace();
/* 4948 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*      */ 
/* 4952 */       Object localObject1 = new NTFEventListener[j - 1];
/* 4953 */       int k = 0;
/* 4954 */       for (i = 0; i < j; i++) {
/* 4955 */         if (this.xsListeners[i].getXSEventListener() != paramXSEventListener) {
/* 4956 */           localObject1[(k++)] = this.xsListeners[i];
/*      */         }
/*      */       }
/* 4959 */       this.xsListeners = ((NTFEventListener[])localObject1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void notify(final NTFXSEvent paramNTFXSEvent)
/*      */   {
/* 4972 */     NTFEventListener[] arrayOfNTFEventListener = this.xsListeners;
/*      */     
/*      */ 
/*      */ 
/* 4976 */     int i = arrayOfNTFEventListener.length;
/* 4977 */     for (int j = 0; j < i; j++)
/*      */     {
/* 4979 */       Executor localExecutor = arrayOfNTFEventListener[j].getExecutor();
/* 4980 */       if (localExecutor != null)
/*      */       {
/* 4982 */         final XSEventListener localXSEventListener = arrayOfNTFEventListener[j].getXSEventListener();
/*      */         
/* 4984 */         localExecutor.execute(new Runnable() {
/*      */           public void run() {
/* 4986 */             localXSEventListener.onXSEvent(paramNTFXSEvent);
/*      */           }
/*      */         });
/*      */       }
/*      */       else
/*      */       {
/* 4992 */         arrayOfNTFEventListener[j].getXSEventListener().onXSEvent(paramNTFXSEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final boolean hasServerCompileTimeCapability(int paramInt1, int paramInt2)
/*      */   {
/* 5015 */     boolean bool = false;
/* 5016 */     if ((this.serverCompileTimeCapabilities != null) && (this.serverCompileTimeCapabilities.length > paramInt1) && ((this.serverCompileTimeCapabilities[paramInt1] & paramInt2) != 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 5021 */       bool = true;
/*      */     }
/* 5023 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   long doGetCurrentSCN()
/*      */     throws SQLException
/*      */   {
/* 5031 */     return this.outScn;
/*      */   }
/*      */   
/*      */ 
/*      */   EnumSet<OracleConnection.TransactionState> doGetTransactionState()
/*      */     throws SQLException
/*      */   {
/* 5038 */     EnumSet localEnumSet = EnumSet.noneOf(OracleConnection.TransactionState.class);
/* 5039 */     if ((this.eocs & 0x1) != 0)
/*      */     {
/* 5041 */       localEnumSet.add(OracleConnection.TransactionState.TRANSACTION_READONLY);
/*      */     }
/* 5043 */     if ((this.eocs & 0x2) != 0)
/*      */     {
/* 5045 */       localEnumSet.add(OracleConnection.TransactionState.TRANSACTION_STARTED);
/*      */     }
/* 5047 */     if ((this.eocs & 0x4) != 0)
/*      */     {
/* 5049 */       localEnumSet.add(OracleConnection.TransactionState.TRANSACTION_ENDED);
/*      */     }
/* 5051 */     if ((this.eocs & 0x400) != 0)
/*      */     {
/* 5053 */       localEnumSet.add(OracleConnection.TransactionState.TRANSACTION_INTENTION);
/*      */     }
/* 5055 */     return localEnumSet;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isConnectionSocketKeepAlive()
/*      */     throws SocketException
/*      */   {
/* 5062 */     return this.net.isConnectionSocketKeepAlive();
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */