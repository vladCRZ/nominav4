/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*      */   T4CPreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*   29 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*      */ 
/*   32 */     this.nbPostPonedColumns = new int[1];
/*   33 */     this.nbPostPonedColumns[0] = 0;
/*   34 */     this.indexOfPostPonedColumn = new int[1][3];
/*   35 */     this.t4Connection = ((T4CConnection)paramPhysicalConnection);
/*      */     
/*   37 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   38 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   39 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   40 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   47 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CConnection t4Connection;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
/*      */     throws SQLException, IOException
/*      */   {
/*   67 */     if ((paramBoolean1) || (paramBoolean4) || (!paramBoolean2)) {
/*   68 */       this.oacdefSent = null;
/*      */     }
/*   70 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
/*      */     
/*   72 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED)
/*      */     {
/*      */ 
/*      */ 
/*   76 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   77 */       localSQLException1.fillInStackTrace();
/*   78 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*   82 */     if (paramBoolean3) {
/*   83 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   85 */     int i = this.numberOfDefinePositions;
/*      */     
/*   87 */     if (this.sqlKind.isDML()) {
/*   88 */       i = 0;
/*      */     }
/*      */     int j;
/*   91 */     if (this.accessors != null)
/*   92 */       for (j = 0; j < this.accessors.length; j++)
/*   93 */         if (this.accessors[j] != null)
/*   94 */           this.accessors[j].lastRowProcessed = 0;
/*   95 */     if (this.outBindAccessors != null)
/*   96 */       for (j = 0; j < this.outBindAccessors.length; j++)
/*   97 */         if (this.outBindAccessors[j] != null)
/*   98 */           this.outBindAccessors[j].lastRowProcessed = 0;
/*   99 */     if (this.returnParamAccessors != null) {
/*  100 */       for (j = 0; j < this.returnParamAccessors.length; j++) {
/*  101 */         if (this.returnParamAccessors[j] != null) {
/*  102 */           this.returnParamAccessors[j].lastRowProcessed = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int i1;
/*      */     int i2;
/*  109 */     if (this.bindIndicators != null)
/*      */     {
/*  111 */       j = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */       
/*      */ 
/*  114 */       int k = 0;
/*      */       
/*  116 */       if (this.ibtBindChars != null) {
/*  117 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  119 */       for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */       {
/*  121 */         int n = this.bindIndicatorSubRange + 5 + 10 * m;
/*      */         
/*      */ 
/*      */ 
/*  125 */         i1 = this.bindIndicators[(n + 2)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/*  129 */         if (i1 != 0)
/*      */         {
/*      */ 
/*  132 */           i2 = this.bindIndicators[(n + 9)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/*  136 */           if (i2 == 2)
/*      */           {
/*  138 */             k = Math.max(i1 * this.connection.conversion.maxNCharSize, k);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  143 */             k = Math.max(i1 * this.connection.conversion.cMaxCharSize, k);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  149 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  151 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  153 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  155 */         this.tmpBindsByteArray = null;
/*  156 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  168 */       this.tmpBindsByteArray = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  173 */     int[] arrayOfInt1 = this.definedColumnType;
/*  174 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  175 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  181 */     if ((paramBoolean5) && (paramBoolean4) && (this.sqlObject.includeRowid))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  186 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  187 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  188 */       arrayOfInt1[0] = -8;
/*  189 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  190 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  191 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  192 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  198 */     allocateTmpByteArray();
/*      */     
/*  200 */     T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */     
/*  202 */     this.t4Connection.sendPiggyBackedMessages();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  207 */       localT4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  219 */       i1 = localT4C8Oall.getCursorId();
/*  220 */       if (i1 != 0) {
/*  221 */         this.cursorId = i1;
/*      */       }
/*  223 */       this.oacdefSent = localT4C8Oall.oacdefBindsSent;
/*      */     }
/*      */     catch (SQLException localSQLException2)
/*      */     {
/*  227 */       i2 = localT4C8Oall.getCursorId();
/*  228 */       if (i2 != 0) {
/*  229 */         this.cursorId = i2;
/*      */       }
/*  231 */       if (localSQLException2.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/*  234 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  239 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray()
/*      */   {
/*  249 */     if (this.tmpByteArray == null)
/*      */     {
/*      */ 
/*  252 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  254 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length)
/*      */     {
/*      */ 
/*      */ 
/*  258 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/*  270 */     super.releaseBuffers();
/*  271 */     this.tmpByteArray = null;
/*  272 */     this.tmpBindsByteArray = null;
/*      */     
/*  274 */     this.t4Connection.all8.bindChars = null;
/*  275 */     this.t4Connection.all8.bindBytes = null;
/*  276 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */   
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/*  283 */     this.accessors[0] = new T4CRowidAccessor(this, 128, 1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {
/*  296 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/*  307 */     if (this.connection.disableDefinecolumntype)
/*      */     {
/*      */ 
/*  310 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  315 */     if ((paramInt2 == -15) || (paramInt2 == -9) || (paramInt2 == -16))
/*      */     {
/*  317 */       paramShort = 2;
/*      */     }
/*      */     
/*      */ 
/*      */     SQLException localSQLException;
/*      */     
/*  323 */     if (paramInt1 < 1)
/*      */     {
/*  325 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  326 */       localSQLException.fillInStackTrace();
/*  327 */       throw localSQLException;
/*      */     }
/*  329 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*  333 */       if ((paramInt2 == 1) || (paramInt2 == 12) || (paramInt2 == -15) || (paramInt2 == -9))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  339 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  345 */     else if (paramInt3 < 0)
/*      */     {
/*  347 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  348 */       localSQLException.fillInStackTrace();
/*  349 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  353 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/*  355 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  356 */       localSQLException.fillInStackTrace();
/*  357 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  364 */     int i = paramInt1 - 1;
/*      */     int[] arrayOfInt;
/*  366 */     if ((this.definedColumnType == null) || (this.definedColumnType.length <= i))
/*      */     {
/*  368 */       if (this.definedColumnType == null)
/*      */       {
/*  370 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  382 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  384 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */         
/*      */ 
/*  387 */         this.definedColumnType = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  393 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  395 */     if ((this.definedColumnSize == null) || (this.definedColumnSize.length <= i))
/*      */     {
/*  397 */       if (this.definedColumnSize == null) {
/*  398 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  401 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  403 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */         
/*      */ 
/*  406 */         this.definedColumnSize = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  410 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  412 */     if ((this.definedColumnFormOfUse == null) || (this.definedColumnFormOfUse.length <= i))
/*      */     {
/*  414 */       if (this.definedColumnFormOfUse == null) {
/*  415 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  418 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  420 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */         
/*      */ 
/*  423 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  427 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  429 */     if ((this.accessors != null) && (i < this.accessors.length) && (this.accessors[i] != null))
/*      */     {
/*  431 */       this.accessors[i].definedColumnSize = paramInt3;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  436 */       if (((this.accessors[i].internalType == 96) || (this.accessors[i].internalType == 1)) && ((paramInt2 == 1) || (paramInt2 == 12)))
/*      */       {
/*      */ 
/*      */ 
/*  440 */         if (paramInt3 <= this.accessors[i].oacmxl)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  446 */           this.needToPrepareDefineBuffer = true;
/*  447 */           this.columnsDefinedByUser = true;
/*      */           
/*  449 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  450 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/*  459 */     synchronized (this.connection)
/*      */     {
/*  461 */       super.clearDefines();
/*  462 */       this.definedColumnType = null;
/*  463 */       this.definedColumnSize = null;
/*  464 */       this.definedColumnFormOfUse = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  482 */     int i = this.rowPrefetchInLastFetch < this.rowPrefetch ? 1 : 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  511 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  520 */       paramArrayOfShort = new short[this.defineIndicators.length];
/*  521 */       j = this.accessors[0].lengthIndexLastRow;
/*  522 */       int k = this.accessors[0].indicatorIndexLastRow;
/*      */       
/*  524 */       int i1 = i != 0 ? this.accessors.length : 1;
/*  525 */       for (; i != 0 ? i1 >= 1 : i1 <= this.accessors.length; 
/*  526 */           i1 += (i != 0 ? -1 : 1))
/*      */       {
/*  528 */         int m = j + this.rowPrefetchInLastFetch * i1 - 1;
/*  529 */         int n = k + this.rowPrefetchInLastFetch * i1 - 1;
/*  530 */         paramArrayOfShort[n] = this.defineIndicators[n];
/*  531 */         paramArrayOfShort[m] = this.defineIndicators[m];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  538 */     int j = i != 0 ? this.accessors.length - 1 : 0;
/*  539 */     for (; i != 0 ? j > -1 : j < this.accessors.length; 
/*  540 */         j += (i != 0 ? -1 : 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  547 */       this.accessors[j].saveDataFromOldDefineBuffers(paramArrayOfByte, paramArrayOfChar, paramArrayOfShort, this.rowPrefetchInLastFetch != -1 ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  554 */     super.saveDefineBuffersIfRequired(paramArrayOfChar, paramArrayOfByte, paramArrayOfShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  564 */     this.inScn = paramLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  584 */     Object localObject = null;
/*      */     SQLException localSQLException;
/*  586 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/*  590 */       localObject = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  593 */       break;
/*      */     
/*      */     case 8: 
/*  596 */       if (!paramBoolean)
/*      */       {
/*  598 */         localObject = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  601 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*  606 */       localObject = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  609 */       break;
/*      */     
/*      */     case 2: 
/*  612 */       localObject = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  615 */       break;
/*      */     
/*      */     case 6: 
/*  618 */       localObject = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  621 */       break;
/*      */     
/*      */     case 24: 
/*  624 */       if (!paramBoolean)
/*      */       {
/*  626 */         localObject = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  629 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/*  634 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/*  636 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  637 */         localSQLException.fillInStackTrace();
/*  638 */         throw localSQLException;
/*      */       }
/*      */       
/*  641 */       if (paramBoolean) {
/*  642 */         localObject = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       else {
/*  645 */         localObject = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*  648 */       break;
/*      */     
/*      */     case 100: 
/*  651 */       localObject = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  654 */       break;
/*      */     
/*      */     case 101: 
/*  657 */       localObject = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  660 */       break;
/*      */     
/*      */     case 104: 
/*  663 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  669 */         localObject = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         
/*      */ 
/*      */ 
/*  673 */         ((Accessor)localObject).definedColumnType = -8;
/*      */       }
/*      */       else {
/*  676 */         localObject = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*      */ 
/*  680 */       break;
/*      */     
/*      */     case 102: 
/*  683 */       localObject = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  686 */       break;
/*      */     
/*      */     case 12: 
/*  689 */       localObject = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  692 */       break;
/*      */     
/*      */     case 113: 
/*  695 */       localObject = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  698 */       break;
/*      */     
/*      */     case 112: 
/*  701 */       localObject = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  704 */       break;
/*      */     
/*      */     case 114: 
/*  707 */       localObject = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  710 */       break;
/*      */     
/*      */     case 109: 
/*  713 */       localObject = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  716 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  718 */       break;
/*      */     
/*      */     case 111: 
/*  721 */       localObject = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  724 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  726 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/*  731 */       localObject = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  734 */       break;
/*      */     
/*      */     case 181: 
/*  737 */       localObject = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  740 */       break;
/*      */     
/*      */     case 231: 
/*  743 */       localObject = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  746 */       break;
/*      */     
/*      */     case 182: 
/*  749 */       localObject = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  752 */       break;
/*      */     
/*      */     case 183: 
/*  755 */       localObject = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  758 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/*  771 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  772 */       localSQLException.fillInStackTrace();
/*  773 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*  777 */     return (Accessor)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doDescribe(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  804 */     if (!this.isOpen)
/*      */     {
/*      */ 
/*  807 */       this.connection.open(this);
/*  808 */       this.isOpen = true;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  814 */       this.t4Connection.needLine();
/*  815 */       this.t4Connection.sendPiggyBackedMessages();
/*  816 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  817 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  819 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  821 */       for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  822 */         this.accessors[i].initMetadata();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/*  826 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*      */ 
/*  829 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  830 */       localSQLException.fillInStackTrace();
/*  831 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  835 */     this.describedWithNames = true;
/*  836 */     this.described = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForDescribe()
/*      */     throws SQLException
/*      */   {
/*  871 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
/*      */     try
/*      */     {
/*  874 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  880 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  884 */         doOall8(true, true, false, true, this.definedColumnType != null);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/*  890 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  894 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*  896 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  897 */       localSQLException2.fillInStackTrace();
/*  898 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  903 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  904 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     
/*  907 */     this.needToParse = false;
/*      */     
/*      */ 
/*  910 */     if (this.connection.calculateChecksum) {
/*  911 */       if (this.validRows > 0) {
/*  912 */         calculateCheckSum();
/*  913 */       } else if (this.rowsProcessed > 0) {
/*  914 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  916 */         this.checkSum = l;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  926 */     if (this.definedColumnType == null) {
/*  927 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  929 */     this.aFetchWasDoneDuringDescribe = false;
/*  930 */     if (this.t4Connection.all8.aFetchWasDone)
/*      */     {
/*  932 */       this.aFetchWasDoneDuringDescribe = true;
/*  933 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*      */     
/*      */ 
/*  937 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  938 */       this.accessors[i].initMetadata();
/*      */     }
/*  940 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForRows(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  982 */         boolean bool = false;
/*  983 */         if (this.columnsDefinedByUser) {
/*  984 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1004 */         else if ((this.t4Connection.useLobPrefetch) && (this.accessors != null) && (this.defaultLobPrefetchSize != -1) && (!this.implicitDefineForLobPrefetchDone) && (!this.aFetchWasDoneDuringDescribe) && (this.definedColumnType == null))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1012 */           int i = 0;
/* 1013 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1014 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1016 */           for (int j = 0; j < this.accessors.length; j++)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1021 */             arrayOfInt1[j] = getJDBCType(this.accessors[j].internalType);
/* 1022 */             if ((this.accessors[j].internalType == 113) || (this.accessors[j].internalType == 112) || (this.accessors[j].internalType == 114))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1028 */               i = 1;
/* 1029 */               this.accessors[j].lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1030 */               arrayOfInt2[j] = this.defaultLobPrefetchSize;
/*      */             }
/*      */           }
/*      */           
/* 1034 */           if (i != 0)
/*      */           {
/* 1036 */             this.definedColumnType = arrayOfInt1;
/* 1037 */             this.definedColumnSize = arrayOfInt2;
/* 1038 */             bool = true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1044 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1046 */         this.needToParse = false;
/* 1047 */         if (bool) {
/* 1048 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       }
/*      */       finally {
/* 1052 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1057 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1061 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/* 1062 */       calculateCheckSum();
/*      */       
/* 1064 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1065 */       localSQLException2.fillInStackTrace();
/* 1066 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetch()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1093 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1097 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1101 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException1)
/*      */         {
/* 1105 */           ((T4CConnection)this.connection).handleIOException(localIOException1);
/*      */           
/* 1107 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/* 1108 */           localSQLException.fillInStackTrace();
/* 1109 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1113 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1119 */       doOall8(false, false, true, false, false);
/*      */       
/* 1121 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 1125 */       ((T4CConnection)this.connection).handleIOException(localIOException2);
/*      */       
/* 1127 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/* 1128 */       localSQLException.fillInStackTrace();
/* 1129 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1135 */     calculateCheckSum();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1150 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1152 */         T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */         
/* 1154 */         localT4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1159 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1161 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1162 */       localSQLException2.fillInStackTrace();
/* 1163 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1168 */       if (localSQLException1.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/* 1171 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1176 */         throw localSQLException1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClose()
/*      */     throws SQLException
/*      */   {
/* 1200 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
/*      */     
/*      */     try
/*      */     {
/* 1204 */       if (this.cursorId != 0)
/*      */       {
/* 1206 */         this.t4Connection.cursorToClose[(this.t4Connection.cursorToCloseOffset++)] = this.cursorId;
/*      */         
/*      */ 
/* 1209 */         if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length)
/*      */         {
/*      */ 
/* 1212 */           this.t4Connection.sendPiggyBackedMessages();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1218 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1220 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1221 */       localSQLException.fillInStackTrace();
/* 1222 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1226 */     this.tmpByteArray = null;
/* 1227 */     this.tmpBindsByteArray = null;
/* 1228 */     this.definedColumnType = null;
/* 1229 */     this.definedColumnSize = null;
/* 1230 */     this.definedColumnFormOfUse = null;
/* 1231 */     this.oacdefSent = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeQuery()
/*      */     throws SQLException
/*      */   {
/* 1251 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
/*      */     
/*      */ 
/* 1254 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1258 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1262 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 1266 */           ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */           
/* 1268 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1269 */           localSQLException.fillInStackTrace();
/* 1270 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1274 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Binder getRowidNullBinder(int paramInt)
/*      */   {
/* 1323 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */     {
/*      */ 
/* 1326 */       this.currentRowCharLens[paramInt] = 1;
/* 1327 */       return this.theVarcharNullBinder;
/*      */     }
/*      */     
/* 1330 */     return this.theRowidNullBinder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doLocalInitialization()
/*      */   {
/* 1339 */     super.doLocalInitialization();
/*      */     
/* 1341 */     this.t4Connection.all8.bindChars = this.bindChars;
/* 1342 */     this.t4Connection.all8.bindBytes = this.bindBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1348 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CPreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */