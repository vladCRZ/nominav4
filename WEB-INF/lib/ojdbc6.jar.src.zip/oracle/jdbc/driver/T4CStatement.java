/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CStatement
/*      */   extends OracleStatement
/*      */ {
/*   23 */   static final byte[][][] parameterDatum = (byte[][][])null;
/*   24 */   static final OracleTypeADT[][] parameterOtype = (OracleTypeADT[][])null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   33 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CConnection t4Connection;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
/*      */     throws SQLException, IOException
/*      */   {
/*   53 */     if ((paramBoolean1) || (paramBoolean4) || (!paramBoolean2)) {
/*   54 */       this.oacdefSent = null;
/*      */     }
/*   56 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.doOall8");
/*      */     
/*   58 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED)
/*      */     {
/*      */ 
/*      */ 
/*   62 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   63 */       localSQLException1.fillInStackTrace();
/*   64 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*   68 */     if (paramBoolean3) {
/*   69 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   71 */     int i = this.numberOfDefinePositions;
/*      */     
/*   73 */     if (this.sqlKind.isDML()) {
/*   74 */       i = 0;
/*      */     }
/*      */     int j;
/*   77 */     if (this.accessors != null)
/*   78 */       for (j = 0; j < this.accessors.length; j++)
/*   79 */         if (this.accessors[j] != null)
/*   80 */           this.accessors[j].lastRowProcessed = 0;
/*   81 */     if (this.outBindAccessors != null)
/*   82 */       for (j = 0; j < this.outBindAccessors.length; j++)
/*   83 */         if (this.outBindAccessors[j] != null)
/*   84 */           this.outBindAccessors[j].lastRowProcessed = 0;
/*   85 */     if (this.returnParamAccessors != null) {
/*   86 */       for (j = 0; j < this.returnParamAccessors.length; j++) {
/*   87 */         if (this.returnParamAccessors[j] != null) {
/*   88 */           this.returnParamAccessors[j].lastRowProcessed = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int i1;
/*      */     int i2;
/*   95 */     if (this.bindIndicators != null)
/*      */     {
/*   97 */       j = ((this.bindIndicators[(this.bindIndicatorSubRange + 3)] & 0xFFFF) << 16) + (this.bindIndicators[(this.bindIndicatorSubRange + 4)] & 0xFFFF);
/*      */       
/*      */ 
/*  100 */       int k = 0;
/*      */       
/*  102 */       if (this.ibtBindChars != null) {
/*  103 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  105 */       for (int m = 0; m < this.numberOfBindPositions; m++)
/*      */       {
/*  107 */         int n = this.bindIndicatorSubRange + 5 + 10 * m;
/*      */         
/*      */ 
/*      */ 
/*  111 */         i1 = this.bindIndicators[(n + 2)] & 0xFFFF;
/*      */         
/*      */ 
/*      */ 
/*  115 */         if (i1 != 0)
/*      */         {
/*      */ 
/*  118 */           i2 = this.bindIndicators[(n + 9)] & 0xFFFF;
/*      */           
/*      */ 
/*      */ 
/*  122 */           if (i2 == 2)
/*      */           {
/*  124 */             k = Math.max(i1 * this.connection.conversion.maxNCharSize, k);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  129 */             k = Math.max(i1 * this.connection.conversion.cMaxCharSize, k);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  135 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  137 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  139 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  141 */         this.tmpBindsByteArray = null;
/*  142 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  154 */       this.tmpBindsByteArray = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  159 */     int[] arrayOfInt1 = this.definedColumnType;
/*  160 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  161 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */     if ((paramBoolean5) && (paramBoolean4) && (this.sqlObject.includeRowid))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  172 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  173 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  174 */       arrayOfInt1[0] = -8;
/*  175 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  176 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  177 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  178 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  184 */     allocateTmpByteArray();
/*      */     
/*  186 */     T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */     
/*  188 */     this.t4Connection.sendPiggyBackedMessages();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  193 */       localT4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, parameterDatum, parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  205 */       i1 = localT4C8Oall.getCursorId();
/*  206 */       if (i1 != 0) {
/*  207 */         this.cursorId = i1;
/*      */       }
/*  209 */       this.oacdefSent = localT4C8Oall.oacdefBindsSent;
/*      */     }
/*      */     catch (SQLException localSQLException2)
/*      */     {
/*  213 */       i2 = localT4C8Oall.getCursorId();
/*  214 */       if (i2 != 0) {
/*  215 */         this.cursorId = i2;
/*      */       }
/*  217 */       if (localSQLException2.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/*  220 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  225 */         throw localSQLException2;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void allocateTmpByteArray()
/*      */   {
/*  235 */     if (this.tmpByteArray == null)
/*      */     {
/*      */ 
/*  238 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  240 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length)
/*      */     {
/*      */ 
/*      */ 
/*  244 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void releaseBuffers()
/*      */   {
/*  256 */     super.releaseBuffers();
/*  257 */     this.tmpByteArray = null;
/*  258 */     this.tmpBindsByteArray = null;
/*      */     
/*  260 */     this.t4Connection.all8.bindChars = null;
/*  261 */     this.t4Connection.all8.bindBytes = null;
/*  262 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */   
/*      */ 
/*      */   void allocateRowidAccessor()
/*      */     throws SQLException
/*      */   {
/*  269 */     this.accessors[0] = new T4CRowidAccessor(this, 128, 1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void reparseOnRedefineIfNeeded()
/*      */     throws SQLException
/*      */   {
/*  282 */     this.needToParse = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString)
/*      */     throws SQLException
/*      */   {
/*  293 */     if (this.connection.disableDefinecolumntype)
/*      */     {
/*      */ 
/*  296 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  301 */     if ((paramInt2 == -15) || (paramInt2 == -9) || (paramInt2 == -16))
/*      */     {
/*  303 */       paramShort = 2;
/*      */     }
/*      */     
/*      */ 
/*      */     SQLException localSQLException;
/*      */     
/*  309 */     if (paramInt1 < 1)
/*      */     {
/*  311 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  312 */       localSQLException.fillInStackTrace();
/*  313 */       throw localSQLException;
/*      */     }
/*  315 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*  319 */       if ((paramInt2 == 1) || (paramInt2 == 12) || (paramInt2 == -15) || (paramInt2 == -9))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  325 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  331 */     else if (paramInt3 < 0)
/*      */     {
/*  333 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  334 */       localSQLException.fillInStackTrace();
/*  335 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  339 */     if ((this.currentResultSet != null) && (!this.currentResultSet.closed))
/*      */     {
/*  341 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  342 */       localSQLException.fillInStackTrace();
/*  343 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  350 */     int i = paramInt1 - 1;
/*      */     int[] arrayOfInt;
/*  352 */     if ((this.definedColumnType == null) || (this.definedColumnType.length <= i))
/*      */     {
/*  354 */       if (this.definedColumnType == null)
/*      */       {
/*  356 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  368 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  370 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */         
/*      */ 
/*  373 */         this.definedColumnType = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  379 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  381 */     if ((this.definedColumnSize == null) || (this.definedColumnSize.length <= i))
/*      */     {
/*  383 */       if (this.definedColumnSize == null) {
/*  384 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  387 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  389 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */         
/*      */ 
/*  392 */         this.definedColumnSize = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  396 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  398 */     if ((this.definedColumnFormOfUse == null) || (this.definedColumnFormOfUse.length <= i))
/*      */     {
/*  400 */       if (this.definedColumnFormOfUse == null) {
/*  401 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       }
/*      */       else {
/*  404 */         arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  406 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */         
/*      */ 
/*  409 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       }
/*      */     }
/*      */     
/*  413 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  415 */     if ((this.accessors != null) && (i < this.accessors.length) && (this.accessors[i] != null))
/*      */     {
/*  417 */       this.accessors[i].definedColumnSize = paramInt3;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  422 */       if (((this.accessors[i].internalType == 96) || (this.accessors[i].internalType == 1)) && ((paramInt2 == 1) || (paramInt2 == 12)))
/*      */       {
/*      */ 
/*      */ 
/*  426 */         if (paramInt3 <= this.accessors[i].oacmxl)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  432 */           this.needToPrepareDefineBuffer = true;
/*  433 */           this.columnsDefinedByUser = true;
/*      */           
/*  435 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  436 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearDefines()
/*      */     throws SQLException
/*      */   {
/*  445 */     synchronized (this.connection)
/*      */     {
/*  447 */       super.clearDefines();
/*  448 */       this.definedColumnType = null;
/*  449 */       this.definedColumnSize = null;
/*  450 */       this.definedColumnFormOfUse = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfChar, byte[] paramArrayOfByte, short[] paramArrayOfShort, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  468 */     int i = this.rowPrefetchInLastFetch < this.rowPrefetch ? 1 : 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  497 */     if (paramBoolean)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  506 */       paramArrayOfShort = new short[this.defineIndicators.length];
/*  507 */       j = this.accessors[0].lengthIndexLastRow;
/*  508 */       int k = this.accessors[0].indicatorIndexLastRow;
/*      */       
/*  510 */       int i1 = i != 0 ? this.accessors.length : 1;
/*  511 */       for (; i != 0 ? i1 >= 1 : i1 <= this.accessors.length; 
/*  512 */           i1 += (i != 0 ? -1 : 1))
/*      */       {
/*  514 */         int m = j + this.rowPrefetchInLastFetch * i1 - 1;
/*  515 */         int n = k + this.rowPrefetchInLastFetch * i1 - 1;
/*  516 */         paramArrayOfShort[n] = this.defineIndicators[n];
/*  517 */         paramArrayOfShort[m] = this.defineIndicators[m];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  524 */     int j = i != 0 ? this.accessors.length - 1 : 0;
/*  525 */     for (; i != 0 ? j > -1 : j < this.accessors.length; 
/*  526 */         j += (i != 0 ? -1 : 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  533 */       this.accessors[j].saveDataFromOldDefineBuffers(paramArrayOfByte, paramArrayOfChar, paramArrayOfShort, this.rowPrefetchInLastFetch != -1 ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  540 */     super.saveDefineBuffersIfRequired(paramArrayOfChar, paramArrayOfByte, paramArrayOfShort, paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doSetSnapshotSCN(long paramLong)
/*      */     throws SQLException
/*      */   {
/*  550 */     this.inScn = paramLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  570 */     Object localObject = null;
/*      */     SQLException localSQLException;
/*  572 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */     case 96: 
/*  576 */       localObject = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  579 */       break;
/*      */     
/*      */     case 8: 
/*  582 */       if (!paramBoolean)
/*      */       {
/*  584 */         localObject = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  587 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*  592 */       localObject = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  595 */       break;
/*      */     
/*      */     case 2: 
/*  598 */       localObject = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  601 */       break;
/*      */     
/*      */     case 6: 
/*  604 */       localObject = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  607 */       break;
/*      */     
/*      */     case 24: 
/*  610 */       if (!paramBoolean)
/*      */       {
/*  612 */         localObject = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       
/*  615 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/*  620 */       if ((paramBoolean) && (paramString != null))
/*      */       {
/*  622 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  623 */         localSQLException.fillInStackTrace();
/*  624 */         throw localSQLException;
/*      */       }
/*      */       
/*  627 */       if (paramBoolean) {
/*  628 */         localObject = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */       }
/*      */       else {
/*  631 */         localObject = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*  634 */       break;
/*      */     
/*      */     case 100: 
/*  637 */       localObject = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  640 */       break;
/*      */     
/*      */     case 101: 
/*  643 */       localObject = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  646 */       break;
/*      */     
/*      */     case 104: 
/*  649 */       if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  655 */         localObject = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         
/*      */ 
/*      */ 
/*  659 */         ((Accessor)localObject).definedColumnType = -8;
/*      */       }
/*      */       else {
/*  662 */         localObject = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       }
/*      */       
/*      */ 
/*  666 */       break;
/*      */     
/*      */     case 102: 
/*  669 */       localObject = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  672 */       break;
/*      */     
/*      */     case 12: 
/*  675 */       localObject = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  678 */       break;
/*      */     
/*      */     case 113: 
/*  681 */       localObject = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  684 */       break;
/*      */     
/*      */     case 112: 
/*  687 */       localObject = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  690 */       break;
/*      */     
/*      */     case 114: 
/*  693 */       localObject = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  696 */       break;
/*      */     
/*      */     case 109: 
/*  699 */       localObject = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  702 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  704 */       break;
/*      */     
/*      */     case 111: 
/*  707 */       localObject = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  710 */       ((Accessor)localObject).initMetadata();
/*      */       
/*  712 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 180: 
/*  717 */       localObject = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  720 */       break;
/*      */     
/*      */     case 181: 
/*  723 */       localObject = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  726 */       break;
/*      */     
/*      */     case 231: 
/*  729 */       localObject = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  732 */       break;
/*      */     
/*      */     case 182: 
/*  735 */       localObject = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  738 */       break;
/*      */     
/*      */     case 183: 
/*  741 */       localObject = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */       
/*      */ 
/*  744 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 995: 
/*  757 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  758 */       localSQLException.fillInStackTrace();
/*  759 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*  763 */     return (Accessor)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doDescribe(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  790 */     if (!this.isOpen)
/*      */     {
/*      */ 
/*      */ 
/*  794 */       SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/*  795 */       localSQLException1.fillInStackTrace();
/*  796 */       throw localSQLException1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  803 */       this.t4Connection.needLine();
/*  804 */       this.t4Connection.sendPiggyBackedMessages();
/*  805 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  806 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  808 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  810 */       for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  811 */         this.accessors[i].initMetadata();
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {
/*  815 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*      */ 
/*  818 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  819 */       localSQLException2.fillInStackTrace();
/*  820 */       throw localSQLException2;
/*      */     }
/*      */     
/*      */ 
/*  824 */     this.describedWithNames = true;
/*  825 */     this.described = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForDescribe()
/*      */     throws SQLException
/*      */   {
/*  860 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.execute_for_describe");
/*      */     try
/*      */     {
/*  863 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  869 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  873 */         doOall8(true, true, false, true, this.definedColumnType != null);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/*  879 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/*  883 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/*  885 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  886 */       localSQLException2.fillInStackTrace();
/*  887 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  892 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  893 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     
/*  896 */     this.needToParse = false;
/*      */     
/*      */ 
/*  899 */     if (this.connection.calculateChecksum) {
/*  900 */       if (this.validRows > 0) {
/*  901 */         calculateCheckSum();
/*  902 */       } else if (this.rowsProcessed > 0) {
/*  903 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  905 */         this.checkSum = l;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  915 */     if (this.definedColumnType == null) {
/*  916 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  918 */     this.aFetchWasDoneDuringDescribe = false;
/*  919 */     if (this.t4Connection.all8.aFetchWasDone)
/*      */     {
/*  921 */       this.aFetchWasDoneDuringDescribe = true;
/*  922 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*      */     
/*      */ 
/*  926 */     for (int i = 0; i < this.numberOfDefinePositions; i++) {
/*  927 */       this.accessors[i].initMetadata();
/*      */     }
/*  929 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void executeForRows(boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  971 */         boolean bool = false;
/*  972 */         if (this.columnsDefinedByUser) {
/*  973 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  993 */         else if ((this.t4Connection.useLobPrefetch) && (this.accessors != null) && (this.defaultLobPrefetchSize != -1) && (!this.implicitDefineForLobPrefetchDone) && (!this.aFetchWasDoneDuringDescribe) && (this.definedColumnType == null))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1001 */           int i = 0;
/* 1002 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1003 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1005 */           for (int j = 0; j < this.accessors.length; j++)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1010 */             arrayOfInt1[j] = getJDBCType(this.accessors[j].internalType);
/* 1011 */             if ((this.accessors[j].internalType == 113) || (this.accessors[j].internalType == 112) || (this.accessors[j].internalType == 114))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1017 */               i = 1;
/* 1018 */               this.accessors[j].lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1019 */               arrayOfInt2[j] = this.defaultLobPrefetchSize;
/*      */             }
/*      */           }
/*      */           
/* 1023 */           if (i != 0)
/*      */           {
/* 1025 */             this.definedColumnType = arrayOfInt1;
/* 1026 */             this.definedColumnSize = arrayOfInt2;
/* 1027 */             bool = true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1033 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1035 */         this.needToParse = false;
/* 1036 */         if (bool) {
/* 1037 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       }
/*      */       finally {
/* 1041 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1046 */       throw localSQLException1;
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1050 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/* 1051 */       calculateCheckSum();
/*      */       
/* 1053 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1054 */       localSQLException2.fillInStackTrace();
/* 1055 */       throw localSQLException2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fetch()
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1082 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1086 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1090 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException1)
/*      */         {
/* 1094 */           ((T4CConnection)this.connection).handleIOException(localIOException1);
/*      */           
/* 1096 */           localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException1);
/* 1097 */           localSQLException.fillInStackTrace();
/* 1098 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1102 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1108 */       doOall8(false, false, true, false, false);
/*      */       
/* 1110 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/*      */     catch (IOException localIOException2)
/*      */     {
/* 1114 */       ((T4CConnection)this.connection).handleIOException(localIOException2);
/*      */       
/* 1116 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException2);
/* 1117 */       localSQLException.fillInStackTrace();
/* 1118 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1124 */     calculateCheckSum();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void continueReadRow(int paramInt)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1139 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1141 */         T4C8Oall localT4C8Oall = this.t4Connection.all8;
/*      */         
/* 1143 */         localT4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1148 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1150 */       SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1151 */       localSQLException2.fillInStackTrace();
/* 1152 */       throw localSQLException2;
/*      */ 
/*      */     }
/*      */     catch (SQLException localSQLException1)
/*      */     {
/* 1157 */       if (localSQLException1.getErrorCode() == DatabaseError.getVendorCode(110))
/*      */       {
/*      */ 
/* 1160 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1165 */         throw localSQLException1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doClose()
/*      */     throws SQLException
/*      */   {
/* 1189 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.do_close");
/*      */     
/*      */     try
/*      */     {
/* 1193 */       if (this.cursorId != 0)
/*      */       {
/* 1195 */         this.t4Connection.cursorToClose[(this.t4Connection.cursorToCloseOffset++)] = this.cursorId;
/*      */         
/*      */ 
/* 1198 */         if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length)
/*      */         {
/*      */ 
/* 1201 */           this.t4Connection.sendPiggyBackedMessages();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 1207 */       ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */       
/* 1209 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1210 */       localSQLException.fillInStackTrace();
/* 1211 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/* 1215 */     this.tmpByteArray = null;
/* 1216 */     this.tmpBindsByteArray = null;
/* 1217 */     this.definedColumnType = null;
/* 1218 */     this.definedColumnSize = null;
/* 1219 */     this.definedColumnFormOfUse = null;
/* 1220 */     this.oacdefSent = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void closeQuery()
/*      */     throws SQLException
/*      */   {
/* 1240 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.closeQuery");
/*      */     
/*      */ 
/* 1243 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */ 
/* 1247 */       while (this.nextStream != null)
/*      */       {
/*      */         try
/*      */         {
/* 1251 */           this.nextStream.close();
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 1255 */           ((T4CConnection)this.connection).handleIOException(localIOException);
/*      */           
/* 1257 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 1258 */           localSQLException.fillInStackTrace();
/* 1259 */           throw localSQLException;
/*      */         }
/*      */         
/*      */ 
/* 1263 */         this.nextStream = this.nextStream.nextStream;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 1314 */     super(paramPhysicalConnection, 1, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/* 1316 */     this.nbPostPonedColumns = new int[1];
/* 1317 */     this.nbPostPonedColumns[0] = 0;
/* 1318 */     this.indexOfPostPonedColumn = new int[1][3];
/* 1319 */     this.t4Connection = ((T4CConnection)paramPhysicalConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1324 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */