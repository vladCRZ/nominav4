/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.net.ano.AuthenticationService;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.SessionAtts;
/*      */ import oracle.net.nt.TcpsNTAdapter;
/*      */ import oracle.security.o3logon.O3LoginClientHelper;
/*      */ import oracle.security.o5logon.O5Logon;
/*      */ import oracle.sql.ZONEIDMAP;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4CTTIoauthenticate
/*      */   extends T4CTTIfun
/*      */ {
/*      */   byte[] terminal;
/*      */   byte[] enableTempLobRefCnt;
/*      */   byte[] machine;
/*      */   byte[] sysUserName;
/*      */   byte[] processID;
/*      */   byte[] programName;
/*      */   byte[] encryptedSK;
/*      */   byte[] internalName;
/*      */   byte[] externalName;
/*      */   byte[] alterSession;
/*      */   byte[] aclValue;
/*      */   byte[] clientname;
/*   86 */   byte[] editionName = null;
/*      */   
/*      */   byte[] driverName;
/*      */   
/*      */   String ressourceManagerId;
/*      */   
/*      */   boolean bUseO5Logon;
/*      */   
/*      */   int verifierType;
/*      */   
/*      */   static final int ZTVT_ORCL_7 = 2361;
/*      */   
/*      */   static final int ZTVT_SSH1 = 6949;
/*      */   static final int ZTVT_NTV = 7809;
/*      */   static final int ZTVT_SMD5 = 59694;
/*      */   static final int ZTVT_MD5 = 40674;
/*      */   static final int ZTVT_SH1 = 45394;
/*      */   byte[] salt;
/*      */   byte[] encryptedKB;
/*  105 */   boolean isSessionTZ = true;
/*      */   
/*      */   static final int SERVER_VERSION_81 = 8100;
/*      */   
/*      */   static final int KPZ_LOGON = 1;
/*      */   
/*      */   static final int KPZ_CPW = 2;
/*      */   
/*      */   static final int KPZ_SRVAUTH = 4;
/*      */   
/*      */   static final int KPZ_ENCRYPTED_PASSWD = 256;
/*      */   
/*      */   static final int KPZ_LOGON_MIGRATE = 16;
/*      */   
/*      */   static final int KPZ_LOGON_SYSDBA = 32;
/*      */   
/*      */   static final int KPZ_LOGON_SYSOPER = 64;
/*      */   
/*      */   static final int KPZ_LOGON_SYSASM = 4194304;
/*      */   
/*      */   static final int KPZ_LOGON_PRELIMAUTH = 128;
/*      */   
/*      */   static final int KPZ_PASSWD_ENCRYPTED = 256;
/*      */   
/*      */   static final int KPZ_LOGON_DBCONC = 512;
/*      */   
/*      */   static final int KPZ_PROXY_AUTH = 1024;
/*      */   
/*      */   static final int KPZ_SESSION_CACHE = 2048;
/*      */   
/*      */   static final int KPZ_PASSWD_IS_VFR = 4096;
/*      */   
/*      */   static final int KPZ_SESSION_QCACHE = 8388608;
/*      */   
/*      */   static final String AUTH_TERMINAL = "AUTH_TERMINAL";
/*      */   
/*      */   static final String AUTH_PROGRAM_NM = "AUTH_PROGRAM_NM";
/*      */   
/*      */   static final String AUTH_MACHINE = "AUTH_MACHINE";
/*      */   
/*      */   static final String AUTH_PID = "AUTH_PID";
/*      */   
/*      */   static final String AUTH_SID = "AUTH_SID";
/*      */   
/*      */   static final String AUTH_SESSKEY = "AUTH_SESSKEY";
/*      */   
/*      */   static final String AUTH_VFR_DATA = "AUTH_VFR_DATA";
/*      */   
/*      */   static final String AUTH_PASSWORD = "AUTH_PASSWORD";
/*      */   
/*      */   static final String AUTH_INTERNALNAME = "AUTH_INTERNALNAME_";
/*      */   
/*      */   static final String AUTH_EXTERNALNAME = "AUTH_EXTERNALNAME_";
/*      */   
/*      */   static final String AUTH_ACL = "AUTH_ACL";
/*      */   
/*      */   static final String AUTH_ALTER_SESSION = "AUTH_ALTER_SESSION";
/*      */   
/*      */   static final String AUTH_INITIAL_CLIENT_ROLE = "INITIAL_CLIENT_ROLE";
/*      */   
/*      */   static final String AUTH_VERSION_SQL = "AUTH_VERSION_SQL";
/*      */   
/*      */   static final String AUTH_VERSION_NO = "AUTH_VERSION_NO";
/*      */   
/*      */   static final String AUTH_XACTION_TRAITS = "AUTH_XACTION_TRAITS";
/*      */   
/*      */   static final String AUTH_VERSION_STATUS = "AUTH_VERSION_STATUS";
/*      */   
/*      */   static final String AUTH_SERIAL_NUM = "AUTH_SERIAL_NUM";
/*      */   
/*      */   static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
/*      */   static final String AUTH_CLIENT_CERTIFICATE = "AUTH_CLIENT_CERTIFICATE";
/*      */   static final String AUTH_PROXY_CLIENT_NAME = "PROXY_CLIENT_NAME";
/*      */   static final String AUTH_CLIENT_DN = "AUTH_CLIENT_DISTINGUISHED_NAME";
/*      */   static final String AUTH_INSTANCENAME = "AUTH_INSTANCENAME";
/*      */   static final String AUTH_DBNAME = "AUTH_DBNAME";
/*      */   static final String AUTH_INSTANCE_NO = "AUTH_INSTANCE_NO";
/*      */   static final String AUTH_SC_SERVER_HOST = "AUTH_SC_SERVER_HOST";
/*      */   static final String AUTH_SC_INSTANCE_NAME = "AUTH_SC_INSTANCE_NAME";
/*      */   static final String AUTH_SC_INSTANCE_ID = "AUTH_SC_INSTANCE_ID";
/*      */   static final String AUTH_SC_INSTANCE_START_TIME = "AUTH_SC_INSTANCE_START_TIME";
/*      */   static final String AUTH_SC_DBUNIQUE_NAME = "AUTH_SC_DBUNIQUE_NAME";
/*      */   static final String AUTH_SC_SERVICE_NAME = "AUTH_SC_SERVICE_NAME";
/*      */   static final String AUTH_SC_SVC_FLAGS = "AUTH_SC_SVC_FLAGS";
/*      */   static final String AUTH_SESSION_CLIENT_CSET = "SESSION_CLIENT_CHARSET";
/*      */   static final String AUTH_SESSION_CLIENT_LTYPE = "SESSION_CLIENT_LIB_TYPE";
/*      */   static final String AUTH_SESSION_CLIENT_DRVNM = "SESSION_CLIENT_DRIVER_NAME";
/*      */   static final String AUTH_SESSION_CLIENT_VSN = "SESSION_CLIENT_VERSION";
/*      */   static final String AUTH_NLS_LXLAN = "AUTH_NLS_LXLAN";
/*      */   static final String AUTH_NLS_LXCTERRITORY = "AUTH_NLS_LXCTERRITORY";
/*      */   static final String AUTH_NLS_LXCCURRENCY = "AUTH_NLS_LXCCURRENCY";
/*      */   static final String AUTH_NLS_LXCISOCURR = "AUTH_NLS_LXCISOCURR";
/*      */   static final String AUTH_NLS_LXCNUMERICS = "AUTH_NLS_LXCNUMERICS";
/*      */   static final String AUTH_NLS_LXCDATEFM = "AUTH_NLS_LXCDATEFM";
/*      */   static final String AUTH_NLS_LXCDATELANG = "AUTH_NLS_LXCDATELANG";
/*      */   static final String AUTH_NLS_LXCSORT = "AUTH_NLS_LXCSORT";
/*      */   static final String AUTH_NLS_LXCCALENDAR = "AUTH_NLS_LXCCALENDAR";
/*      */   static final String AUTH_NLS_LXCUNIONCUR = "AUTH_NLS_LXCUNIONCUR";
/*      */   static final String AUTH_NLS_LXCTIMEFM = "AUTH_NLS_LXCTIMEFM";
/*      */   static final String AUTH_NLS_LXCSTMPFM = "AUTH_NLS_LXCSTMPFM";
/*      */   static final String AUTH_NLS_LXCTTZNFM = "AUTH_NLS_LXCTTZNFM";
/*      */   static final String AUTH_NLS_LXCSTZNFM = "AUTH_NLS_LXCSTZNFM";
/*      */   static final String SESSION_CLIENT_LOBATTR = "SESSION_CLIENT_LOBATTR";
/*      */   static final String DRIVER_NAME_DEFAULT = "jdbcthin";
/*      */   static final int KPU_LIB_UNKN = 0;
/*      */   static final int KPU_LIB_DEF = 1;
/*      */   static final int KPU_LIB_EI = 2;
/*      */   static final int KPU_LIB_XE = 3;
/*      */   static final int KPU_LIB_ICUS = 4;
/*      */   static final int KPU_LIB_OCI = 5;
/*      */   static final int KPU_LIB_THIN = 10;
/*      */   static final String AUTH_ORA_EDITION = "AUTH_ORA_EDITION";
/*      */   static final String AUTH_COPYRIGHT = "AUTH_COPYRIGHT";
/*      */   static final String COPYRIGHT_STR = "\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.";
/*      */   static final String SESSION_TIME_ZONE = "SESSION_TIME_ZONE";
/*      */   static final String SESSION_NLS_LXCCHARSET = "SESSION_NLS_LXCCHARSET";
/*      */   static final String SESSION_NLS_LXCNLSLENSEM = "SESSION_NLS_LXCNLSLENSEM";
/*      */   static final String SESSION_NLS_LXCNCHAREXCP = "SESSION_NLS_LXCNCHAREXCP";
/*      */   static final String SESSION_NLS_LXCNCHARIMP = "SESSION_NLS_LXCNCHARIMP";
/*  224 */   String sessionTimeZone = null;
/*  225 */   byte[] serverCompileTimeCapabilities = null;
/*      */   
/*      */ 
/*      */   T4CTTIoauthenticate(T4CConnection paramT4CConnection, String paramString, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/*  231 */     super(paramT4CConnection, (byte)3);
/*      */     
/*  233 */     this.ressourceManagerId = paramString;
/*  234 */     this.serverCompileTimeCapabilities = paramArrayOfByte;
/*  235 */     setSessionFields(paramT4CConnection);
/*      */     
/*      */ 
/*      */ 
/*  239 */     this.isSessionTZ = true;
/*      */     
/*  241 */     this.bUseO5Logon = false;
/*      */   }
/*      */   
/*      */ 
/*  245 */   private T4CKvaldfList keyValList = null;
/*  246 */   private byte[] user = null;
/*      */   
/*      */   private long logonMode;
/*      */   
/*  250 */   private byte[][] outKeys = (byte[][])null;
/*  251 */   private byte[][] outValues = (byte[][])null;
/*  252 */   private int[] outFlags = new int[0];
/*  253 */   private int outNbPairs = 0;
/*      */   
/*      */ 
/*      */   void marshal()
/*      */     throws IOException
/*      */   {
/*  259 */     if ((this.user != null) && (this.user.length > 0))
/*      */     {
/*  261 */       this.meg.marshalPTR();
/*  262 */       this.meg.marshalSB4(this.user.length);
/*      */     }
/*      */     else
/*      */     {
/*  266 */       this.meg.marshalNULLPTR();
/*  267 */       this.meg.marshalSB4(0);
/*      */     }
/*  269 */     this.meg.marshalUB4(this.logonMode);
/*  270 */     this.meg.marshalPTR();
/*      */     
/*  272 */     this.meg.marshalUB4(this.keyValList.size());
/*  273 */     this.meg.marshalPTR();
/*  274 */     this.meg.marshalPTR();
/*      */     
/*      */ 
/*  277 */     if ((this.user != null) && (this.user.length > 0))
/*  278 */       this.meg.marshalCHR(this.user);
/*  279 */     this.meg.marshalKEYVAL(this.keyValList.getKeys(), this.keyValList.getValues(), this.keyValList.getFlags(), this.keyValList.size());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void doOAUTH(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong, String paramString, boolean paramBoolean, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, byte[][] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws IOException, SQLException
/*      */   {
/*  295 */     setFunCode((short)115);
/*      */     
/*  297 */     this.user = paramArrayOfByte1;
/*      */     
/*      */ 
/*  300 */     this.logonMode = (paramLong | 1L);
/*      */     
/*      */ 
/*  303 */     if (paramBoolean) {
/*  304 */       this.logonMode |= 0x400;
/*      */     }
/*  306 */     if ((paramArrayOfByte1 != null) && (paramArrayOfByte1.length != 0) && (paramArrayOfByte2 != null) && (paramString != "RADIUS"))
/*      */     {
/*      */ 
/*      */ 
/*  310 */       this.logonMode |= 0x100;
/*      */     }
/*  312 */     this.keyValList = new T4CKvaldfList(this.meg.conv);
/*      */     
/*  314 */     if (paramArrayOfByte2 != null) {
/*  315 */       this.keyValList.add("AUTH_PASSWORD", paramArrayOfByte2);
/*      */     }
/*  317 */     if (paramArrayOfByte != null) {
/*  318 */       for (int i = 0; i < paramArrayOfByte.length; i++)
/*  319 */         this.keyValList.add("INITIAL_CLIENT_ROLE", paramArrayOfByte[i]);
/*      */     }
/*  321 */     if (paramArrayOfByte3 != null) {
/*  322 */       this.keyValList.add("AUTH_CLIENT_DISTINGUISHED_NAME", paramArrayOfByte3);
/*      */     }
/*  324 */     if (paramArrayOfByte4 != null) {
/*  325 */       this.keyValList.add("AUTH_CLIENT_CERTIFICATE", paramArrayOfByte4);
/*      */     }
/*  327 */     this.keyValList.add("AUTH_TERMINAL", this.terminal);
/*      */     
/*  329 */     if ((this.bUseO5Logon) && (this.encryptedKB != null)) {
/*  330 */       this.keyValList.add("AUTH_SESSKEY", this.encryptedKB, (byte)1);
/*      */     }
/*  332 */     if (this.programName != null) {
/*  333 */       this.keyValList.add("AUTH_PROGRAM_NM", this.programName);
/*      */     }
/*  335 */     if (this.clientname != null) {
/*  336 */       this.keyValList.add("PROXY_CLIENT_NAME", this.clientname);
/*      */     }
/*  338 */     this.keyValList.add("AUTH_MACHINE", this.machine);
/*  339 */     this.keyValList.add("AUTH_PID", this.processID);
/*      */     
/*  341 */     if (!this.ressourceManagerId.equals("0000"))
/*      */     {
/*  343 */       byte[] arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_INTERNALNAME_");
/*      */       
/*      */ 
/*  346 */       arrayOfByte[(arrayOfByte.length - 1)] = 0;
/*  347 */       this.keyValList.add(arrayOfByte, this.internalName);
/*      */       
/*  349 */       arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_EXTERNALNAME_");
/*  350 */       arrayOfByte[(arrayOfByte.length - 1)] = 0;
/*  351 */       this.keyValList.add(arrayOfByte, this.externalName);
/*      */     }
/*      */     
/*  354 */     this.keyValList.add("AUTH_ACL", this.aclValue);
/*      */     
/*  356 */     this.keyValList.add("AUTH_ALTER_SESSION", this.alterSession, (byte)1);
/*      */     
/*  358 */     if (this.editionName != null) {
/*  359 */       this.keyValList.add("AUTH_ORA_EDITION", this.editionName);
/*      */     }
/*      */     
/*      */ 
/*  363 */     this.keyValList.add("SESSION_CLIENT_LOBATTR", this.enableTempLobRefCnt);
/*      */     
/*  365 */     this.keyValList.add("SESSION_CLIENT_DRIVER_NAME", this.driverName);
/*  366 */     this.keyValList.add("SESSION_CLIENT_VERSION", this.meg.conv.StringToCharBytes(Integer.toString(versionStringToInt(this.connection.getMetaData().getDriverVersion()), 10)));
/*      */     
/*  368 */     if (paramInt1 != -1) {
/*  369 */       this.keyValList.add("AUTH_SESSION_ID", this.meg.conv.StringToCharBytes(Integer.toString(paramInt1)));
/*      */     }
/*  371 */     if (paramInt2 != -1) {
/*  372 */       this.keyValList.add("AUTH_SERIAL_NUM", this.meg.conv.StringToCharBytes(Integer.toString(paramInt2)));
/*      */     }
/*  374 */     this.keyValList.add("AUTH_COPYRIGHT", this.meg.conv.StringToCharBytes("\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation."));
/*      */     
/*  376 */     this.outNbPairs = 0;
/*  377 */     this.outKeys = ((byte[][])null);
/*  378 */     this.outValues = ((byte[][])null);
/*  379 */     this.outFlags = new int[0];
/*  380 */     doRPC();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOSESSKEY(String paramString, long paramLong)
/*      */     throws IOException, SQLException
/*      */   {
/*  389 */     setFunCode((short)118);
/*  390 */     this.user = this.meg.conv.StringToCharBytes(paramString);
/*  391 */     this.logonMode = (paramLong | 1L);
/*      */     
/*  393 */     this.keyValList = new T4CKvaldfList(this.meg.conv);
/*  394 */     this.keyValList.add("AUTH_TERMINAL", this.terminal);
/*  395 */     if (this.programName != null)
/*  396 */       this.keyValList.add("AUTH_PROGRAM_NM", this.programName);
/*  397 */     this.keyValList.add("AUTH_MACHINE", this.machine);
/*  398 */     this.keyValList.add("AUTH_PID", this.processID);
/*  399 */     this.keyValList.add("AUTH_SID", this.sysUserName);
/*  400 */     this.outNbPairs = 0;
/*  401 */     this.outKeys = ((byte[][])null);
/*  402 */     this.outValues = ((byte[][])null);
/*  403 */     this.outFlags = new int[0];
/*  404 */     doRPC();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void readRPA()
/*      */     throws IOException, SQLException
/*      */   {
/*  416 */     this.outNbPairs = this.meg.unmarshalUB2();
/*      */     
/*  418 */     this.outKeys = new byte[this.outNbPairs][];
/*  419 */     this.outValues = new byte[this.outNbPairs][];
/*      */     
/*      */ 
/*  422 */     this.outFlags = this.meg.unmarshalKEYVAL(this.outKeys, this.outValues, this.outNbPairs);
/*      */   }
/*      */   
/*      */ 
/*      */   void processError()
/*      */     throws SQLException
/*      */   {
/*  429 */     if (getFunCode() == 118)
/*      */     {
/*  431 */       if ((this.oer.getRetCode() != 28035) || (this.connection.net.getAuthenticationAdaptorName() != "RADIUS"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  441 */         this.oer.processError();
/*      */       }
/*      */     }
/*      */     else {
/*  445 */       super.processError();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void processRPA() throws SQLException
/*      */   {
/*      */     Object localObject;
/*  452 */     if (getFunCode() == 115)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  458 */       localObject = new Properties();
/*      */       
/*  460 */       for (int j = 0; j < this.outNbPairs; j++)
/*      */       {
/*  462 */         String str2 = this.meg.conv.CharBytesToString(this.outKeys[j], this.outKeys[j].length).trim();
/*  463 */         String str3 = "";
/*  464 */         if (this.outValues[j] != null) {
/*  465 */           str3 = this.meg.conv.CharBytesToString(this.outValues[j], this.outValues[j].length).trim();
/*      */         }
/*  467 */         ((Properties)localObject).setProperty(str2, str3);
/*      */       }
/*      */       
/*  470 */       String str1 = ((Properties)localObject).getProperty("AUTH_VERSION_NO");
/*  471 */       if (str1 != null)
/*      */       {
/*      */         try
/*      */         {
/*  475 */           int n = new Integer(str1).intValue();
/*      */         }
/*      */         catch (NumberFormatException localNumberFormatException) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  483 */       ((Properties)localObject).setProperty("SERVER_HOST", ((Properties)localObject).getProperty("AUTH_SC_SERVER_HOST", ""));
/*      */       
/*      */ 
/*      */ 
/*  487 */       ((Properties)localObject).setProperty("INSTANCE_NAME", ((Properties)localObject).getProperty("AUTH_SC_INSTANCE_NAME", ""));
/*      */       
/*      */ 
/*      */ 
/*  491 */       ((Properties)localObject).setProperty("DATABASE_NAME", ((Properties)localObject).getProperty("AUTH_SC_DBUNIQUE_NAME", ""));
/*      */       
/*      */ 
/*      */ 
/*  495 */       ((Properties)localObject).setProperty("SERVICE_NAME", ((Properties)localObject).getProperty("AUTH_SC_SERVICE_NAME", ""));
/*      */       
/*      */ 
/*      */ 
/*  499 */       ((Properties)localObject).setProperty("SESSION_TIME_ZONE", this.sessionTimeZone);
/*      */       
/*  501 */       this.connection.sessionProperties = ((Properties)localObject);
/*      */     }
/*  503 */     else if (getFunCode() == 118)
/*      */     {
/*  505 */       if (this.connection.net.getAuthenticationAdaptorName() != "RADIUS")
/*      */       {
/*      */ 
/*  508 */         if ((this.outKeys == null) || (this.outKeys.length < 1))
/*      */         {
/*  510 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
/*  511 */           ((SQLException)localObject).fillInStackTrace();
/*  512 */           throw ((Throwable)localObject);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  520 */         int i = -1;
/*  521 */         for (int k = 0; k < this.outKeys.length; k++)
/*  522 */           if (new String(this.outKeys[k]).equals("AUTH_SESSKEY"))
/*      */           {
/*  524 */             i = k;
/*  525 */             break;
/*      */           }
/*  527 */         if (i == -1)
/*      */         {
/*  529 */           SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
/*  530 */           localSQLException1.fillInStackTrace();
/*  531 */           throw localSQLException1;
/*      */         }
/*  533 */         this.encryptedSK = this.outValues[i];
/*      */         
/*  535 */         int m = -1;
/*  536 */         for (int i1 = 0; i1 < this.outKeys.length; i1++) {
/*  537 */           if (new String(this.outKeys[i1]).equals("AUTH_VFR_DATA"))
/*      */           {
/*  539 */             m = i1;
/*  540 */             break;
/*      */           }
/*      */         }
/*  543 */         if (m != -1)
/*      */         {
/*  545 */           this.bUseO5Logon = true;
/*  546 */           this.salt = this.outValues[m];
/*  547 */           this.verifierType = this.outFlags[m];
/*      */         }
/*      */         
/*  550 */         if (!this.bUseO5Logon)
/*      */         {
/*      */ 
/*  553 */           if ((this.encryptedSK == null) || (this.encryptedSK.length != 16))
/*      */           {
/*  555 */             SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
/*  556 */             localSQLException2.fillInStackTrace();
/*  557 */             throw localSQLException2;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  566 */   O5Logon o5logonHelper = new O5Logon();
/*      */   
/*      */   void doOAUTH(String paramString1, String paramString2, long paramLong) throws IOException, SQLException
/*      */   {
/*  570 */     byte[] arrayOfByte1 = null;
/*  571 */     if ((paramString1 != null) && (paramString1.length() > 0)) {
/*  572 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(paramString1);
/*      */     }
/*  574 */     byte[] arrayOfByte2 = null;
/*  575 */     byte[] arrayOfByte3 = null;
/*  576 */     byte[] arrayOfByte4 = null;
/*      */     
/*  578 */     String str1 = this.connection.net.getAuthenticationAdaptorName();
/*      */     
/*      */     Object localObject1;
/*      */     Object localObject2;
/*  582 */     if ((paramString1 != null) && (paramString1.length() != 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  587 */       if ((str1 != "RADIUS") && (this.encryptedSK.length > 16) && (!this.bUseO5Logon))
/*      */       {
/*      */ 
/*      */ 
/*  591 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  592 */         ((SQLException)localObject1).fillInStackTrace();
/*  593 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*  596 */       if ((this.bUseO5Logon) && ((this.encryptedSK == null) || ((this.encryptedSK.length != 64) && (this.encryptedSK.length != 96))))
/*      */       {
/*      */ 
/*  599 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  600 */         ((SQLException)localObject1).fillInStackTrace();
/*  601 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  611 */       localObject1 = paramString1.trim();
/*  612 */       localObject2 = null;
/*  613 */       if (paramString2 != null)
/*      */       {
/*      */ 
/*  616 */         localObject2 = paramString2.trim();
/*      */       }
/*  618 */       paramString2 = null;
/*      */       
/*  620 */       Object localObject3 = localObject1;
/*  621 */       Object localObject4 = localObject2;
/*      */       
/*  623 */       if ((((String)localObject1).startsWith("\"")) || (((String)localObject1).endsWith("\""))) {
/*  624 */         localObject3 = removeQuotes((String)localObject1);
/*      */       }
/*  626 */       if ((localObject2 != null) && ((((String)localObject2).startsWith("\"")) || (((String)localObject2).endsWith("\""))))
/*      */       {
/*  628 */         localObject4 = removeQuotes((String)localObject2);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  634 */       if (localObject4 != null)
/*  635 */         arrayOfByte2 = this.meg.conv.StringToCharBytes((String)localObject4);
/*      */       Object localObject5;
/*  637 */       if (str1 != "RADIUS")
/*      */       {
/*  639 */         if (arrayOfByte2 == null)
/*      */         {
/*  641 */           arrayOfByte4 = null;
/*      */         } else { byte[] arrayOfByte5;
/*  643 */           if (this.bUseO5Logon)
/*      */           {
/*  645 */             this.encryptedKB = new byte[this.encryptedSK.length];
/*  646 */             for (int k = 0; k < this.encryptedKB.length; k++) this.encryptedKB[k] = 1;
/*  647 */             localObject5 = new int[1];
/*  648 */             arrayOfByte5 = new byte['Ā'];
/*  649 */             for (int n = 0; n < 256; n++) arrayOfByte5[n] = 0;
/*      */             try
/*      */             {
/*  652 */               this.o5logonHelper.generateOAuthResponse(this.verifierType, this.salt, (String)localObject3, (String)localObject4, arrayOfByte2, this.encryptedSK, this.encryptedKB, arrayOfByte5, (int[])localObject5, this.meg.conv.isServerCSMultiByte, this.serverCompileTimeCapabilities[4]);
/*      */             }
/*      */             catch (Exception localException2) {}
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  674 */             arrayOfByte4 = new byte[localObject5[0]];
/*  675 */             System.arraycopy(arrayOfByte5, 0, arrayOfByte4, 0, localObject5[0]);
/*      */           }
/*      */           else
/*      */           {
/*  679 */             localObject5 = new O3LoginClientHelper(this.meg.conv.isServerCSMultiByte);
/*      */             
/*  681 */             arrayOfByte5 = ((O3LoginClientHelper)localObject5).getSessionKey((String)localObject3, (String)localObject4, this.encryptedSK);
/*      */             
/*      */ 
/*      */             int i;
/*      */             
/*      */ 
/*  687 */             if (arrayOfByte2.length % 8 > 0) {
/*  688 */               i = (byte)(8 - arrayOfByte2.length % 8);
/*      */             } else {
/*  690 */               i = 0;
/*      */             }
/*  692 */             arrayOfByte3 = new byte[arrayOfByte2.length + i];
/*      */             
/*  694 */             System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  699 */             byte[] arrayOfByte6 = ((O3LoginClientHelper)localObject5).getEPasswd(arrayOfByte5, arrayOfByte3);
/*      */             
/*      */ 
/*  702 */             arrayOfByte4 = new byte[2 * arrayOfByte3.length + 1];
/*      */             
/*      */ 
/*  705 */             if (arrayOfByte4.length < 2 * arrayOfByte6.length)
/*      */             {
/*  707 */               SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  708 */               localSQLException.fillInStackTrace();
/*  709 */               throw localSQLException;
/*      */             }
/*      */             
/*  712 */             RepConversion.bArray2Nibbles(arrayOfByte6, arrayOfByte4);
/*      */             
/*      */ 
/*  715 */             arrayOfByte4[(arrayOfByte4.length - 1)] = RepConversion.nibbleToHex(i);
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*  721 */       else if (arrayOfByte2 != null)
/*      */       {
/*  723 */         if ((this.connection.net.getSessionAttributes().getNTAdapter() instanceof TcpsNTAdapter))
/*      */         {
/*  725 */           arrayOfByte4 = arrayOfByte2;
/*      */         }
/*      */         else
/*      */         {
/*      */           int j;
/*      */           
/*      */ 
/*      */ 
/*  733 */           if ((arrayOfByte2.length + 1) % 8 > 0) {
/*  734 */             j = (byte)(8 - (arrayOfByte2.length + 1) % 8);
/*      */           } else {
/*  736 */             j = 0;
/*      */           }
/*  738 */           arrayOfByte3 = new byte[arrayOfByte2.length + 1 + j];
/*      */           
/*  740 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*  741 */           localObject5 = AuthenticationService.obfuscatePasswordForRadius(arrayOfByte3);
/*      */           
/*      */ 
/*  744 */           arrayOfByte4 = new byte[localObject5.length * 2];
/*      */           
/*  746 */           for (int i2 = 0; i2 < localObject5.length; i2++)
/*      */           {
/*  748 */             int m = (byte)((localObject5[i2] & 0xF0) >> 4);
/*  749 */             int i1 = (byte)(localObject5[i2] & 0xF);
/*  750 */             arrayOfByte4[(i2 * 2)] = ((byte)(m < 10 ? m + 48 : m - 10 + 97));
/*      */             
/*  752 */             arrayOfByte4[(i2 * 2 + 1)] = ((byte)(i1 < 10 ? i1 + 48 : i1 - 10 + 97));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  760 */     doOAUTH(arrayOfByte1, arrayOfByte4, paramLong, str1, false, null, null, (byte[][])null, -1, -1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  771 */     if ((str1 != "RADIUS") && (this.bUseO5Logon))
/*      */     {
/*  773 */       String str2 = this.connection.sessionProperties.getProperty("AUTH_SVR_RESPONSE");
/*      */       try {
/*  775 */         if (!this.o5logonHelper.validateServerIdentity(str2))
/*      */         {
/*      */ 
/*  778 */           localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  779 */           ((SQLException)localObject1).fillInStackTrace();
/*  780 */           throw ((Throwable)localObject1);
/*      */         }
/*      */       }
/*      */       catch (Exception localException1)
/*      */       {
/*  785 */         localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  786 */         ((SQLException)localObject2).fillInStackTrace();
/*  787 */         throw ((Throwable)localObject2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doOAUTH(int paramInt1, Properties paramProperties, int paramInt2, int paramInt3)
/*      */     throws IOException, SQLException
/*      */   {
/*  799 */     byte[] arrayOfByte1 = null;
/*  800 */     byte[] arrayOfByte2 = null;
/*  801 */     String[] arrayOfString = null;
/*  802 */     byte[][] arrayOfByte = (byte[][])null;
/*  803 */     byte[] arrayOfByte3 = null;
/*      */     Object localObject;
/*  805 */     String str; if (paramInt1 == 1)
/*      */     {
/*  807 */       localObject = paramProperties.getProperty("PROXY_USER_NAME");
/*  808 */       str = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  809 */       if (str != null)
/*  810 */         localObject = (String)localObject + "/" + str;
/*  811 */       arrayOfByte3 = this.meg.conv.StringToCharBytes((String)localObject);
/*      */     }
/*  813 */     else if (paramInt1 == 2)
/*      */     {
/*  815 */       localObject = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*      */       
/*      */ 
/*  818 */       arrayOfByte1 = this.meg.conv.StringToCharBytes((String)localObject);
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/*  824 */         arrayOfByte2 = (byte[])paramProperties.get("PROXY_CERTIFICATE");
/*      */         
/*  826 */         localObject = new StringBuffer();
/*      */         
/*      */ 
/*      */ 
/*  830 */         for (int k = 0; k < arrayOfByte2.length; k++)
/*      */         {
/*  832 */           str = Integer.toHexString(0xFF & arrayOfByte2[k]);
/*  833 */           int j = str.length();
/*      */           
/*  835 */           if (j == 0) {
/*  836 */             ((StringBuffer)localObject).append("00");
/*  837 */           } else if (j == 1)
/*      */           {
/*  839 */             ((StringBuffer)localObject).append('0');
/*  840 */             ((StringBuffer)localObject).append(str);
/*      */           }
/*      */           else {
/*  843 */             ((StringBuffer)localObject).append(str);
/*      */           }
/*      */         }
/*  846 */         arrayOfByte2 = ((StringBuffer)localObject).toString().getBytes();
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  854 */       arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     }
/*      */     catch (Exception localException2) {}
/*      */     
/*  858 */     if (arrayOfString != null)
/*      */     {
/*  860 */       arrayOfByte = new byte[arrayOfString.length][];
/*      */       
/*  862 */       for (int i = 0; i < arrayOfString.length; i++) {
/*  863 */         arrayOfByte[i] = this.meg.conv.StringToCharBytes(arrayOfString[i]);
/*      */       }
/*      */     }
/*  866 */     doOAUTH(arrayOfByte3, null, 0L, null, true, arrayOfByte1, arrayOfByte2, arrayOfByte, paramInt2, paramInt3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setSessionFields(T4CConnection paramT4CConnection)
/*      */     throws SQLException
/*      */   {
/*  890 */     String str1 = this.connection.thinVsessionTerminal;
/*  891 */     String str2 = this.connection.thinVsessionMachine;
/*  892 */     String str3 = this.connection.thinVsessionOsuser;
/*  893 */     String str4 = this.connection.thinVsessionProgram;
/*  894 */     String str5 = this.connection.thinVsessionProcess;
/*  895 */     String str6 = this.connection.thinVsessionIname;
/*  896 */     String str7 = this.connection.thinVsessionEname;
/*  897 */     String str8 = this.connection.proxyClientName;
/*  898 */     String str9 = this.connection.driverNameAttribute;
/*  899 */     String str10 = this.connection.editionName;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  912 */       if (this.connection.enableTempLobRefCnt) {
/*  913 */         this.enableTempLobRefCnt = new String("1").getBytes("US-ASCII");
/*      */       }
/*      */       else {
/*  916 */         this.enableTempLobRefCnt = new String("0").getBytes("US-ASCII");
/*      */       }
/*      */     }
/*      */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  924 */     if (str2 == null)
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/*  929 */         str2 = InetAddress.getLocalHost().getHostName();
/*      */       }
/*      */       catch (Exception localException)
/*      */       {
/*  933 */         str2 = "jdbcclient";
/*      */       }
/*      */     }
/*      */     
/*  937 */     if (str7 == null) {
/*  938 */       str7 = "jdbc_" + this.ressourceManagerId;
/*      */     }
/*  940 */     if (str9 == null) {
/*  941 */       str9 = "jdbcthin";
/*      */     }
/*      */     
/*  944 */     this.terminal = this.meg.conv.StringToCharBytes(str1);
/*  945 */     this.machine = this.meg.conv.StringToCharBytes(str2);
/*  946 */     this.sysUserName = this.meg.conv.StringToCharBytes(str3);
/*  947 */     this.programName = this.meg.conv.StringToCharBytes(str4);
/*  948 */     this.processID = this.meg.conv.StringToCharBytes(str5);
/*  949 */     this.internalName = this.meg.conv.StringToCharBytes(str6);
/*  950 */     this.externalName = this.meg.conv.StringToCharBytes(str7);
/*  951 */     if (str8 != null)
/*  952 */       this.clientname = this.meg.conv.StringToCharBytes(str8);
/*  953 */     if (str10 != null)
/*  954 */       this.editionName = this.meg.conv.StringToCharBytes(str10);
/*  955 */     this.driverName = this.meg.conv.StringToCharBytes(str9);
/*      */     
/*  957 */     TimeZone localTimeZone = TimeZone.getDefault();
/*      */     
/*      */ 
/*  960 */     String str11 = localTimeZone.getID();
/*      */     
/*  962 */     if ((!ZONEIDMAP.isValidRegion(str11)) || (!paramT4CConnection.timezoneAsRegion))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  971 */       int i = localTimeZone.getOffset(System.currentTimeMillis());
/*  972 */       int j = i / 3600000;
/*  973 */       int k = i / 60000 % 60;
/*      */       
/*  975 */       str11 = (j < 0 ? "" + j : new StringBuilder().append("+").append(j).toString()) + (k < 10 ? ":0" + k : new StringBuilder().append(":").append(k).toString());
/*      */     }
/*      */     
/*      */ 
/*  979 */     this.sessionTimeZone = str11;
/*  980 */     paramT4CConnection.sessionTimeZone = str11;
/*      */     
/*  982 */     String str12 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault());
/*      */     
/*  984 */     String str13 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault());
/*      */     
/*      */ 
/*  987 */     if ((str12 == null) || (str13 == null))
/*      */     {
/*  989 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/*  990 */       localSQLException.fillInStackTrace();
/*  991 */       throw localSQLException;
/*      */     }
/*      */     
/*  994 */     this.alterSession = this.meg.conv.StringToCharBytes("ALTER SESSION SET " + (this.isSessionTZ ? "TIME_ZONE='" + this.sessionTimeZone + "'" : "") + " NLS_LANGUAGE='" + str12 + "' NLS_TERRITORY='" + str13 + "' ");
/*      */     
/*      */ 
/*      */ 
/*  998 */     this.aclValue = this.meg.conv.StringToCharBytes("4400");
/*  999 */     this.alterSession[(this.alterSession.length - 1)] = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String removeQuotes(String paramString)
/*      */   {
/* 1013 */     int i = 0;int j = paramString.length() - 1;
/*      */     
/* 1015 */     for (int k = 0; k < paramString.length(); k++)
/*      */     {
/* 1017 */       if (paramString.charAt(k) != '"')
/*      */       {
/* 1019 */         i = k;
/*      */         
/* 1021 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1025 */     for (k = paramString.length() - 1; k >= 0; k--)
/*      */     {
/* 1027 */       if (paramString.charAt(k) != '"')
/*      */       {
/* 1029 */         j = k;
/*      */         
/* 1031 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1035 */     String str = paramString.substring(i, j + 1);
/*      */     
/* 1037 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int versionStringToInt(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1064 */     String[] arrayOfString = paramString.split("\\.");
/* 1065 */     int i = Integer.parseInt(arrayOfString[0].replaceAll("\\D", ""));
/* 1066 */     int j = Integer.parseInt(arrayOfString[1].replaceAll("\\D", ""));
/* 1067 */     int k = Integer.parseInt(arrayOfString[2].replaceAll("\\D", ""));
/* 1068 */     int m = Integer.parseInt(arrayOfString[3].replaceAll("\\D", ""));
/* 1069 */     int n = Integer.parseInt(arrayOfString[4].replaceAll("\\D", ""));
/* 1070 */     int i1 = i << 24 | j << 20 | k << 12 | m << 8 | n;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1075 */     return i1;
/*      */   }
/*      */   
/*      */ 
/*      */   private String versionIntToString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1082 */     int i = (paramInt & 0xFF000000) >> 24 & 0xFF;
/* 1083 */     int j = (paramInt & 0xF00000) >> 20 & 0xFF;
/* 1084 */     int k = (paramInt & 0xFF000) >> 12 & 0xFF;
/* 1085 */     int m = (paramInt & 0xF00) >> 8 & 0xFF;
/* 1086 */     int n = paramInt & 0xFF;
/* 1087 */     String str = "" + i + "." + j + "." + k + "." + m + "." + n;
/* 1088 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 1103 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1108 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CTTIoauthenticate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */