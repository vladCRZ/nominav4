/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.BitSet;
/*     */ import java.util.Vector;
/*     */ import oracle.jdbc.OracleResultSetMetaData.SecurityAttribute;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIrxd
/*     */   extends T4CTTIMsg
/*     */ {
/*  46 */   static final byte[] NO_BYTES = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */   byte[] buffer;
/*     */   
/*     */ 
/*     */   byte[] bufferCHAR;
/*     */   
/*     */ 
/*  56 */   BitSet bvcColSent = null;
/*  57 */   int nbOfColumns = 0;
/*  58 */   boolean bvcFound = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isFirstCol;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final byte TTICMD_UNAUTHORIZED = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   T4CTTIrxd(T4CConnection paramT4CConnection)
/*     */   {
/*  78 */     super(paramT4CConnection, (byte)7);
/*     */     
/*  80 */     this.isFirstCol = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void init()
/*     */   {
/*  87 */     this.isFirstCol = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setNumberOfColumns(int paramInt)
/*     */   {
/*  94 */     this.nbOfColumns = paramInt;
/*  95 */     this.bvcFound = false;
/*     */     
/*  97 */     if ((this.bvcColSent == null) || (this.bvcColSent.length() < this.nbOfColumns)) {
/*  98 */       this.bvcColSent = new BitSet(this.nbOfColumns);
/*     */     } else {
/* 100 */       this.bvcColSent.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void unmarshalBVC(int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 108 */     int i = 0;
/*     */     
/*     */ 
/* 111 */     for (int j = 0; j < this.bvcColSent.length(); j++) {
/* 112 */       this.bvcColSent.clear(j);
/*     */     }
/*     */     
/* 115 */     j = this.nbOfColumns / 8 + (this.nbOfColumns % 8 != 0 ? 1 : 0);
/*     */     
/*     */ 
/* 118 */     for (int k = 0; k < j; k++)
/*     */     {
/* 120 */       int m = (byte)(this.meg.unmarshalUB1() & 0xFF);
/*     */       
/* 122 */       for (int n = 0; n < 8; n++)
/*     */       {
/* 124 */         if ((m & 1 << n) != 0)
/*     */         {
/* 126 */           this.bvcColSent.set(k * 8 + n);
/*     */           
/* 128 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 133 */     if (i != paramInt)
/*     */     {
/*     */ 
/* 136 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
/*     */       
/* 138 */       localSQLException.fillInStackTrace();
/* 139 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/* 143 */     this.bvcFound = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void readBitVector(byte[] paramArrayOfByte)
/*     */     throws SQLException, IOException
/*     */   {
/* 156 */     for (int i = 0; i < this.bvcColSent.length(); i++) {
/* 157 */       this.bvcColSent.clear(i);
/*     */     }
/* 159 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
/* 160 */       this.bvcFound = false;
/*     */     }
/*     */     else {
/* 163 */       for (i = 0; i < paramArrayOfByte.length; i++) {
/* 164 */         int j = paramArrayOfByte[i];
/* 165 */         for (int k = 0; k < 8; k++) {
/* 166 */           if ((j & 1 << k) != 0)
/* 167 */             this.bvcColSent.set(i * 8 + k);
/*     */         }
/*     */       }
/* 170 */       this.bvcFound = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Vector<IOException> marshal(byte[] paramArrayOfByte1, char[] paramArrayOfChar1, short[] paramArrayOfShort1, int paramInt1, byte[] paramArrayOfByte2, DBConversion paramDBConversion, InputStream[] paramArrayOfInputStream, byte[][] paramArrayOfByte, OracleTypeADT[] paramArrayOfOracleTypeADT, byte[] paramArrayOfByte3, char[] paramArrayOfChar2, short[] paramArrayOfShort2, byte[] paramArrayOfByte4, int paramInt2, int[] paramArrayOfInt1, boolean paramBoolean, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[][] paramArrayOfInt)
/*     */     throws IOException
/*     */   {
/* 198 */     Vector localVector = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 203 */       marshalTTCcode();
/*     */       
/*     */ 
/* 206 */       int i = paramArrayOfShort1[(paramInt1 + 0)] & 0xFFFF;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */       int i10 = 0;
/* 229 */       int i11 = paramArrayOfInt3[0];
/* 230 */       Object localObject1 = paramArrayOfInt[0];
/*     */       
/* 232 */       int i12 = 0;
/*     */       int i14;
/* 234 */       int j; int i7; int k; int i9; int m; int i8; int i22; int i23; int i4; int i6; int i5; int i1; int i3; int i17; int i19; for (int i13 = 0; i13 < i; i13++)
/*     */       {
/* 236 */         if ((i10 < i11) && (localObject1[i10] == i13))
/*     */         {
/*     */ 
/* 239 */           i10++;
/*     */         }
/*     */         else
/*     */         {
/* 243 */           i14 = 0;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 248 */           j = paramInt1 + 5 + 10 * i13;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 253 */           i7 = paramArrayOfShort1[(j + 0)] & 0xFFFF;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 258 */           if ((paramArrayOfByte4 != null) && ((paramArrayOfByte4[i13] & 0x20) == 0))
/*     */           {
/*     */ 
/*     */ 
/* 262 */             if (i7 == 998) {
/* 263 */               i12++;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 268 */             k = ((paramArrayOfShort1[(j + 7)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 8)] & 0xFFFF) + paramInt2;
/*     */             
/*     */ 
/*     */ 
/* 272 */             i9 = ((paramArrayOfShort1[(j + 5)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 6)] & 0xFFFF) + paramInt2;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 277 */             m = paramArrayOfShort1[k] & 0xFFFF;
/*     */             
/* 279 */             i8 = paramArrayOfShort1[i9];
/*     */             
/* 281 */             if (i7 == 116)
/*     */             {
/* 283 */               this.meg.marshalUB1((short)1);
/* 284 */               this.meg.marshalUB1((short)0);
/*     */             }
/*     */             else
/*     */             {
/* 288 */               if (i7 == 994)
/*     */               {
/* 290 */                 i8 = -1;
/* 291 */                 int i15 = paramArrayOfInt2[(3 + i13 * 4 + 0)];
/*     */                 
/*     */ 
/*     */ 
/* 295 */                 if (i15 == 109) {
/* 296 */                   i14 = 1;
/*     */                 }
/* 298 */               } else if ((i7 == 8) || (i7 == 24) || ((!paramBoolean) && (paramArrayOfInt1 != null) && (paramArrayOfInt1.length > i13) && (paramArrayOfInt1[i13] > 4000)))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 315 */                 if (i11 >= localObject1.length)
/*     */                 {
/* 317 */                   int[] arrayOfInt = new int[localObject1.length << 1];
/*     */                   
/*     */ 
/* 320 */                   System.arraycopy(localObject1, 0, arrayOfInt, 0, localObject1.length);
/*     */                   
/*     */ 
/*     */ 
/* 324 */                   localObject1 = arrayOfInt;
/*     */                 }
/*     */                 
/* 327 */                 localObject1[(i11++)] = i13;
/*     */                 
/*     */ 
/*     */ 
/* 331 */                 continue;
/*     */               }
/*     */               
/*     */ 
/* 335 */               if (i8 == -1)
/*     */               {
/* 337 */                 if ((i7 == 109) || (i14 != 0))
/*     */                 {
/*     */ 
/* 340 */                   this.meg.marshalDALC(NO_BYTES);
/* 341 */                   this.meg.marshalDALC(NO_BYTES);
/* 342 */                   this.meg.marshalDALC(NO_BYTES);
/* 343 */                   this.meg.marshalUB2(0);
/* 344 */                   this.meg.marshalUB4(0L);
/* 345 */                   this.meg.marshalUB2(1);
/*     */                   
/* 347 */                   continue;
/*     */                 }
/* 349 */                 if (i7 == 998)
/*     */                 {
/* 351 */                   i12++;
/* 352 */                   this.meg.marshalUB4(0L);
/* 353 */                   continue;
/*     */                 }
/* 355 */                 if ((i7 == 112) || (i7 == 113) || (i7 == 114))
/*     */                 {
/* 357 */                   this.meg.marshalUB4(0L);
/* 358 */                   continue;
/*     */                 }
/* 360 */                 if ((i7 != 8) && (i7 != 24))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 369 */                   this.meg.marshalUB1((short)0);
/*     */                   
/* 371 */                   continue;
/*     */                 } }
/*     */               int i18;
/*     */               int i24;
/* 375 */               if (i7 == 998)
/*     */               {
/*     */ 
/* 378 */                 int i16 = (paramArrayOfShort2[(6 + i12 * 8 + 4)] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfShort2[(6 + i12 * 8 + 5)] & 0xFFFF;
/*     */                 
/*     */ 
/* 381 */                 i18 = (paramArrayOfShort2[(6 + i12 * 8 + 6)] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfShort2[(6 + i12 * 8 + 7)] & 0xFFFF;
/*     */                 
/*     */ 
/* 384 */                 int i20 = paramArrayOfShort2[(6 + i12 * 8)] & 0xFFFF;
/* 385 */                 i22 = paramArrayOfShort2[(6 + i12 * 8 + 1)] & 0xFFFF;
/*     */                 
/* 387 */                 this.meg.marshalUB4(i16);
/*     */                 
/* 389 */                 for (i23 = 0; i23 < i16; i23++)
/*     */                 {
/* 391 */                   i24 = i18 + i23 * i22;
/*     */                   
/* 393 */                   if (i20 == 9)
/*     */                   {
/* 395 */                     i4 = paramArrayOfChar2[i24] / '\002';
/* 396 */                     i6 = 0;
/* 397 */                     i6 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfChar2, i24 + 1, paramArrayOfByte2, 0, i4);
/*     */                     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */                     this.meg.marshalCLR(paramArrayOfByte2, i6);
/*     */                   }
/*     */                   else
/*     */                   {
/* 407 */                     m = paramArrayOfByte3[i24];
/*     */                     
/* 409 */                     if (m < 1) {
/* 410 */                       this.meg.marshalUB1((short)0);
/*     */                     } else {
/* 412 */                       this.meg.marshalCLR(paramArrayOfByte3, i24 + 1, m);
/*     */                     }
/*     */                   }
/*     */                 }
/* 416 */                 i12++;
/*     */ 
/*     */ 
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/*     */ 
/*     */ 
/* 425 */                 int n = paramArrayOfShort1[(j + 1)] & 0xFFFF;
/*     */                 
/*     */ 
/*     */ 
/* 429 */                 if (n != 0)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 435 */                   int i2 = ((paramArrayOfShort1[(j + 3)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 4)] & 0xFFFF) + n * paramInt2;
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 442 */                   if (i7 == 6)
/*     */                   {
/* 444 */                     i2++;
/* 445 */                     m--;
/*     */                   }
/* 447 */                   else if (i7 == 9)
/*     */                   {
/* 449 */                     i2 += 2;
/*     */                     
/* 451 */                     m -= 2;
/*     */                   }
/* 453 */                   else if ((i7 == 114) || (i7 == 113) || (i7 == 112))
/*     */                   {
/*     */ 
/* 456 */                     this.meg.marshalUB4(m);
/*     */                   }
/*     */                   
/*     */                   Object localObject2;
/* 460 */                   if ((i7 == 109) || (i7 == 111))
/*     */                   {
/* 462 */                     if (paramArrayOfByte == null)
/*     */                     {
/*     */ 
/* 465 */                       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
/*     */                       
/* 467 */                       ((SQLException)localObject2).fillInStackTrace();
/* 468 */                       throw ((Throwable)localObject2);
/*     */                     }
/*     */                     
/*     */ 
/* 472 */                     localObject2 = paramArrayOfByte[i13];
/*     */                     
/* 474 */                     m = localObject2 == null ? 0 : localObject2.length;
/*     */                     
/* 476 */                     if (i7 == 109)
/*     */                     {
/* 478 */                       this.meg.marshalDALC(NO_BYTES);
/* 479 */                       this.meg.marshalDALC(NO_BYTES);
/* 480 */                       this.meg.marshalDALC(NO_BYTES);
/* 481 */                       this.meg.marshalUB2(0);
/*     */                       
/* 483 */                       this.meg.marshalUB4(m);
/* 484 */                       this.meg.marshalUB2(1);
/*     */                     }
/*     */                     
/* 487 */                     if (m > 0) {
/* 488 */                       this.meg.marshalCLR((byte[])localObject2, 0, m);
/*     */                     }
/* 490 */                   } else if (i7 == 104)
/*     */                   {
/*     */ 
/*     */ 
/* 494 */                     i2 += 2;
/*     */                     
/* 496 */                     localObject2 = T4CRowidAccessor.stringToRowid(paramArrayOfByte1, i2, 18);
/*     */                     
/* 498 */                     i18 = 14;
/* 499 */                     long l1 = localObject2[0];
/* 500 */                     i23 = (int)localObject2[1];
/* 501 */                     i24 = 0;
/* 502 */                     long l2 = localObject2[2];
/* 503 */                     int i25 = (int)localObject2[3];
/*     */                     
/*     */ 
/* 506 */                     if ((l1 == 0L) && (i23 == 0) && (l2 == 0L) && (i25 == 0))
/*     */                     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 512 */                       this.meg.marshalUB1((short)0);
/*     */                     }
/*     */                     else
/*     */                     {
/* 516 */                       this.meg.marshalUB1(i18);
/* 517 */                       this.meg.marshalUB4(l1);
/* 518 */                       this.meg.marshalUB2(i23);
/* 519 */                       this.meg.marshalUB1(i24);
/* 520 */                       this.meg.marshalUB4(l2);
/* 521 */                       this.meg.marshalUB2(i25);
/*     */                     }
/*     */                   }
/* 524 */                   else if (i7 == 208)
/*     */                   {
/*     */ 
/*     */ 
/* 528 */                     i2 += 2;
/* 529 */                     m -= 2;
/* 530 */                     this.meg.marshalUB4(m);
/* 531 */                     this.meg.marshalCLR(paramArrayOfByte1, i2, m);
/*     */ 
/*     */ 
/*     */                   }
/* 535 */                   else if (m < 1) {
/* 536 */                     this.meg.marshalUB1((short)0);
/*     */                   } else {
/* 538 */                     this.meg.marshalCLR(paramArrayOfByte1, i2, m);
/*     */ 
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */                 }
/*     */                 else
/*     */                 {
/*     */ 
/* 548 */                   i5 = paramArrayOfShort1[(j + 9)] & 0xFFFF;
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 555 */                   i1 = paramArrayOfShort1[(j + 2)] & 0xFFFF;
/*     */                   
/*     */ 
/* 558 */                   i3 = ((paramArrayOfShort1[(j + 3)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 4)] & 0xFFFF) + i1 * paramInt2 + 1;
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/* 563 */                   if (i7 == 996)
/*     */                   {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 572 */                     i17 = paramArrayOfChar1[(i3 - 1)];
/*     */                     
/* 574 */                     if ((this.bufferCHAR == null) || (this.bufferCHAR.length < i17)) {
/* 575 */                       this.bufferCHAR = new byte[i17];
/*     */                     }
/* 577 */                     for (i19 = 0; i19 < i17; i19++)
/*     */                     {
/* 579 */                       this.bufferCHAR[i19] = ((byte)((paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF00) >> '\b' & 0xFF));
/*     */                       
/*     */ 
/*     */ 
/* 583 */                       if (i19 < i17 - 1)
/*     */                       {
/* 585 */                         this.bufferCHAR[(i19 + 1)] = ((byte)(paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF & 0xFF));
/*     */                         
/*     */ 
/* 588 */                         i19++;
/*     */                       }
/*     */                     }
/*     */                     
/* 592 */                     this.meg.marshalCLR(this.bufferCHAR, i17);
/*     */                     
/* 594 */                     if (this.bufferCHAR.length > 4000) {
/* 595 */                       this.bufferCHAR = null;
/*     */ 
/*     */                     }
/*     */                     
/*     */ 
/*     */ 
/*     */                   }
/*     */                   else
/*     */                   {
/*     */ 
/*     */ 
/* 606 */                     if (i7 == 96)
/*     */                     {
/*     */ 
/*     */ 
/* 610 */                       i4 = m / 2;
/* 611 */                       i3--;
/*     */                     }
/*     */                     else
/*     */                     {
/* 615 */                       i4 = (m - 2) / 2;
/*     */                     }
/*     */                     
/*     */ 
/* 619 */                     i6 = 0;
/*     */                     
/*     */ 
/*     */ 
/*     */ 
/* 624 */                     if (i5 == 2)
/*     */                     {
/* 626 */                       i6 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */ 
/*     */                     }
/*     */                     else
/*     */                     {
/* 631 */                       i6 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */                     }
/*     */                     
/*     */ 
/*     */ 
/*     */ 
/* 637 */                     this.meg.marshalCLR(paramArrayOfByte2, i6);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 647 */       if (i11 > 0)
/*     */       {
/* 649 */         for (i13 = 0; i13 < i11; i13++)
/*     */         {
/* 651 */           i14 = localObject1[i13];
/*     */           
/* 653 */           j = paramInt1 + 5 + 10 * i14;
/*     */           
/*     */ 
/*     */ 
/* 657 */           i7 = paramArrayOfShort1[(j + 0)] & 0xFFFF;
/*     */           
/*     */ 
/*     */ 
/* 661 */           k = ((paramArrayOfShort1[(j + 7)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 8)] & 0xFFFF) + paramInt2;
/*     */           
/*     */ 
/*     */ 
/* 665 */           i9 = ((paramArrayOfShort1[(j + 5)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 6)] & 0xFFFF) + paramInt2;
/*     */           
/*     */ 
/*     */ 
/* 669 */           i8 = paramArrayOfShort1[i9];
/* 670 */           m = paramArrayOfShort1[k] & 0xFFFF;
/*     */           
/* 672 */           i1 = paramArrayOfShort1[(j + 2)] & 0xFFFF;
/*     */           
/*     */ 
/* 675 */           i3 = ((paramArrayOfShort1[(j + 3)] & 0xFFFF) << 16) + (paramArrayOfShort1[(j + 4)] & 0xFFFF) + i1 * paramInt2 + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 680 */           if (i8 == -1)
/*     */           {
/* 682 */             this.meg.marshalUB1((short)0);
/*     */ 
/*     */ 
/*     */           }
/* 686 */           else if (i7 == 996)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 695 */             i17 = paramArrayOfChar1[(i3 - 1)];
/*     */             
/* 697 */             if ((this.bufferCHAR == null) || (this.bufferCHAR.length < i17)) {
/* 698 */               this.bufferCHAR = new byte[i17];
/*     */             }
/* 700 */             for (i19 = 0; i19 < i17; i19++)
/*     */             {
/* 702 */               this.bufferCHAR[i19] = ((byte)((paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF00) >> '\b' & 0xFF));
/*     */               
/*     */ 
/*     */ 
/* 706 */               if (i19 < i17 - 1)
/*     */               {
/* 708 */                 this.bufferCHAR[(i19 + 1)] = ((byte)(paramArrayOfChar1[(i3 + i19 / 2)] & 0xFF & 0xFF));
/*     */                 
/* 710 */                 i19++;
/*     */               }
/*     */             }
/*     */             
/* 714 */             this.meg.marshalCLR(this.bufferCHAR, i17);
/*     */             
/* 716 */             if (this.bufferCHAR.length > 4000) {
/* 717 */               this.bufferCHAR = null;
/*     */             }
/* 719 */           } else if ((i7 != 8) && (i7 != 24))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 726 */             if (i7 == 96)
/*     */             {
/*     */ 
/*     */ 
/* 730 */               i4 = m / 2;
/* 731 */               i3--;
/*     */             }
/*     */             else
/*     */             {
/* 735 */               i4 = (m - 2) / 2;
/*     */             }
/*     */             
/* 738 */             i5 = paramArrayOfShort1[(j + 9)] & 0xFFFF;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 743 */             i6 = 0;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 748 */             if (i5 == 2)
/*     */             {
/* 750 */               i6 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/* 755 */               i6 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfChar1, i3, paramArrayOfByte2, 0, i4);
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 761 */             this.meg.marshalCLR(paramArrayOfByte2, i6);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 766 */             i17 = i14;
/*     */             
/*     */ 
/* 769 */             if (paramArrayOfInputStream != null)
/*     */             {
/* 771 */               InputStream localInputStream = paramArrayOfInputStream[i17];
/*     */               
/* 773 */               if (localInputStream != null)
/*     */               {
/*     */ 
/*     */ 
/* 777 */                 int i21 = 64;
/*     */                 
/* 779 */                 if (this.buffer == null) {
/* 780 */                   this.buffer = new byte[i21];
/*     */                 }
/* 782 */                 i22 = 0;
/*     */                 
/*     */ 
/* 785 */                 this.meg.marshalUB1((short)254);
/*     */                 
/* 787 */                 i23 = 0;
/*     */                 
/* 789 */                 while ((i23 == 0) && (!this.connection.sentCancel))
/*     */                 {
/*     */                   try {
/* 792 */                     i22 = localInputStream.read(this.buffer, 0, i21);
/*     */                   } catch (IOException localIOException2) {
/* 794 */                     i22 = -1;
/* 795 */                     if (localVector == null)
/* 796 */                       localVector = new Vector();
/* 797 */                     localVector.add(localIOException2);
/*     */                   }
/*     */                   
/* 800 */                   if (i22 == -1) {
/* 801 */                     i23 = 1;
/*     */                   }
/* 803 */                   if (i22 > 0)
/*     */                   {
/*     */ 
/*     */ 
/* 807 */                     this.meg.marshalUB1((short)(i22 & 0xFF));
/*     */                     
/*     */ 
/* 810 */                     this.meg.marshalB1Array(this.buffer, 0, i22);
/*     */                   }
/*     */                 }
/*     */                 
/*     */ 
/* 815 */                 this.meg.marshalUB1((short)0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 832 */       paramArrayOfInt3[0] = i11;
/* 833 */       paramArrayOfInt[0] = localObject1;
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/* 837 */       IOException localIOException1 = new IOException();
/* 838 */       localIOException1.initCause(localSQLException);
/* 839 */       throw localIOException1;
/*     */     }
/*     */     
/* 842 */     return localVector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt)
/*     */     throws SQLException, IOException
/*     */   {
/* 853 */     return unmarshal(paramArrayOfAccessor, 0, paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2)
/*     */     throws SQLException, IOException
/*     */   {
/* 870 */     if (paramInt1 == 0) {
/* 871 */       this.isFirstCol = true;
/*     */     }
/* 873 */     for (int i = paramInt1; (i < paramInt2) && (i < paramArrayOfAccessor.length); i++)
/*     */     {
/* 875 */       if (paramArrayOfAccessor[i] != null)
/*     */       {
/*     */         int j;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         int k;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 892 */         if (paramArrayOfAccessor[i].physicalColumnIndex < 0)
/*     */         {
/*     */ 
/*     */ 
/* 896 */           j = 0;
/*     */           
/* 898 */           for (k = 0; (k < paramInt2) && (k < paramArrayOfAccessor.length); k++)
/*     */           {
/* 900 */             if (paramArrayOfAccessor[k] != null)
/*     */             {
/* 902 */               paramArrayOfAccessor[k].physicalColumnIndex = j;
/*     */               
/* 904 */               if (!paramArrayOfAccessor[k].isUseLess) {
/* 905 */                 j++;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 910 */         if ((this.bvcFound) && (!paramArrayOfAccessor[i].isUseLess) && (!this.bvcColSent.get(paramArrayOfAccessor[i].physicalColumnIndex)))
/*     */         {
/*     */ 
/*     */ 
/* 914 */           paramArrayOfAccessor[i].copyRow();
/*     */         }
/*     */         else
/*     */         {
/* 918 */           j = 0;
/*     */           
/*     */ 
/*     */ 
/* 922 */           if ((paramArrayOfAccessor[i].statement.statementType != 2) && (!paramArrayOfAccessor[i].statement.sqlKind.isPlsqlOrCall()))
/*     */           {
/*     */ 
/* 925 */             k = paramArrayOfAccessor[i].metaDataIndex + paramArrayOfAccessor[i].lastRowProcessed * 1;
/*     */             
/* 927 */             if (paramArrayOfAccessor[i].securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) {
/* 928 */               j = (byte)this.meg.unmarshalUB1();
/*     */             }
/* 930 */             paramArrayOfAccessor[i].rowSpaceMetaData[k] = j;
/*     */           }
/*     */           
/* 933 */           if (paramArrayOfAccessor[i].unmarshalOneRow()) {
/* 934 */             return true;
/*     */           }
/* 936 */           this.isFirstCol = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 941 */     this.bvcFound = false;
/*     */     
/* 943 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2, int paramInt3)
/*     */     throws SQLException, IOException
/*     */   {
/* 952 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 967 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 972 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CTTIrxd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */