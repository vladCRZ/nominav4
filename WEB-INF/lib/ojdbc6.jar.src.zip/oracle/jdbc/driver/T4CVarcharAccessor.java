/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormatSymbols;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Properties;
/*      */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CVarcharAccessor
/*      */   extends VarcharAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int t4MaxLength = 4000;
/*      */   static final int t4CallMaxLength = 4001;
/*      */   static final int t4PlsqlMaxLength = 32766;
/*      */   static final int t4SqlMinLength = 32;
/*   64 */   boolean underlyingLong = false;
/*      */   
/*      */ 
/*      */   T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine)
/*      */     throws SQLException
/*      */   {
/*   70 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */     
/*   72 */     this.mare = paramT4CMAREngine;
/*      */     
/*   74 */     calculateSizeTmpByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine)
/*      */     throws SQLException
/*      */   {
/*   84 */     super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*      */     
/*      */ 
/*      */ 
/*   88 */     this.mare = paramT4CMAREngine;
/*   89 */     this.definedColumnType = paramInt8;
/*   90 */     this.definedColumnSize = paramInt9;
/*      */     
/*   92 */     calculateSizeTmpByteArray();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */     this.oacmxl = paramInt7;
/*      */     
/*  100 */     if (this.oacmxl == -1)
/*      */     {
/*  102 */       this.underlyingLong = true;
/*  103 */       this.oacmxl = 4000;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void processIndicator(int paramInt)
/*      */     throws IOException, SQLException
/*      */   {
/*  112 */     if (((this.internalType == 1) && (this.describeType == 112)) || ((this.internalType == 23) && (this.describeType == 113)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  119 */       this.mare.unmarshalUB2();
/*  120 */       this.mare.unmarshalUB2();
/*      */     }
/*  122 */     else if (this.statement.connection.versionNumber < 9200)
/*      */     {
/*      */ 
/*      */ 
/*  126 */       this.mare.unmarshalSB2();
/*      */       
/*  128 */       if (!this.statement.sqlKind.isPlsqlOrCall()) {
/*  129 */         this.mare.unmarshalSB2();
/*      */       }
/*  131 */     } else if ((this.statement.sqlKind.isPlsqlOrCall()) || (this.isDMLReturnedParam))
/*      */     {
/*  133 */       this.mare.processIndicator(paramInt <= 0, paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */   final int[] meta = new int[1];
/*  142 */   final int[] tmp = new int[1];
/*  143 */   final int[] escapeSequenceArr = new int[1];
/*  144 */   final boolean[] readHeaderArr = new boolean[1];
/*  145 */   final boolean[] readAsNonStreamArr = new boolean[1];
/*      */   static final int NONE = -1;
/*      */   static final int DAY = 1;
/*      */   static final int MM_MONTH = 2;
/*      */   static final int FULL_MONTH = 3;
/*      */   
/*      */   boolean unmarshalOneRow()
/*      */     throws SQLException, IOException
/*      */   {
/*  154 */     if (this.isUseLess)
/*      */     {
/*  156 */       this.lastRowProcessed += 1;
/*      */       
/*  158 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  162 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*  163 */     int j = this.lengthIndex + this.lastRowProcessed;
/*      */     
/*      */ 
/*      */ 
/*  167 */     byte[] arrayOfByte1 = this.statement.tmpByteArray;
/*  168 */     int k = this.columnIndex + this.lastRowProcessed * this.charLength;
/*      */     
/*  170 */     if (!this.underlyingLong)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  175 */       if (this.rowSpaceIndicator == null)
/*      */       {
/*      */ 
/*      */ 
/*  179 */         byte[] arrayOfByte2 = new byte['㺀'];
/*      */         
/*  181 */         this.mare.unmarshalCLR(arrayOfByte2, 0, this.meta);
/*  182 */         processIndicator(this.meta[0]);
/*      */         
/*  184 */         this.lastRowProcessed += 1;
/*      */         
/*  186 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  191 */       if (this.isNullByDescribe)
/*      */       {
/*  193 */         this.rowSpaceIndicator[i] = -1;
/*  194 */         this.rowSpaceIndicator[j] = 0;
/*  195 */         this.lastRowProcessed += 1;
/*      */         
/*  197 */         if (this.statement.connection.versionNumber < 9200) {
/*  198 */           processIndicator(0);
/*      */         }
/*  200 */         return false;
/*      */       }
/*      */       
/*  203 */       if (this.statement.maxFieldSize > 0) {
/*  204 */         this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta, this.statement.maxFieldSize);
/*      */       } else {
/*  206 */         this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  212 */       this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
/*      */       
/*      */ 
/*  215 */       if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0]))
/*      */       {
/*      */ 
/*      */ 
/*  219 */         this.meta[0] = 0;
/*      */         
/*  221 */         this.mare.processIndicator(false, 0);
/*      */         
/*  223 */         m = this.mare.unmarshalUB2();
/*      */       }
/*      */       else
/*      */       {
/*  227 */         m = 0;
/*  228 */         int n = 0;
/*  229 */         byte[] arrayOfByte3 = arrayOfByte1;
/*  230 */         int i1 = 0;
/*      */         
/*  232 */         this.readHeaderArr[0] = true;
/*  233 */         this.readAsNonStreamArr[0] = false;
/*      */         
/*  235 */         while (m != -1)
/*      */         {
/*  237 */           if ((arrayOfByte3 == arrayOfByte1) && (n + 255 > arrayOfByte1.length))
/*      */           {
/*      */ 
/*      */ 
/*  241 */             arrayOfByte3 = new byte['ÿ'];
/*      */           }
/*  243 */           if (arrayOfByte3 == arrayOfByte1) {
/*  244 */             i1 = n;
/*      */           } else {
/*  246 */             i1 = 0;
/*      */           }
/*  248 */           m = T4CLongAccessor.readStreamFromWire(arrayOfByte3, i1, 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
/*      */           
/*      */ 
/*      */ 
/*  252 */           if ((this.statement.connection.calculateChecksum) && (m != -1))
/*      */           {
/*      */ 
/*  255 */             long l = CRC64.updateChecksum(this.statement.checkSum, arrayOfByte3, i1, m);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  260 */             this.statement.checkSum = l;
/*      */           }
/*      */           
/*      */ 
/*  264 */           if (m != -1)
/*      */           {
/*  266 */             if (arrayOfByte3 == arrayOfByte1) {
/*  267 */               n += m;
/*  268 */             } else if (arrayOfByte1.length - n > 0)
/*      */             {
/*      */ 
/*      */ 
/*  272 */               int i2 = arrayOfByte1.length - n;
/*      */               
/*  274 */               System.arraycopy(arrayOfByte3, 0, arrayOfByte1, n, i2);
/*      */               
/*      */ 
/*  277 */               n += i2;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  282 */         if (arrayOfByte3 != arrayOfByte1) {
/*  283 */           arrayOfByte3 = null;
/*      */         }
/*  285 */         this.meta[0] = n;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  290 */     this.tmp[0] = this.meta[0];
/*      */     
/*  292 */     int m = 0;
/*      */     
/*  294 */     if (this.formOfUse == 2) {
/*  295 */       m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte1, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */       m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte1, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*      */     }
/*      */     
/*      */ 
/*  312 */     this.rowSpaceChar[k] = ((char)(m * 2));
/*      */     
/*      */ 
/*      */ 
/*  316 */     if (!this.underlyingLong) {
/*  317 */       processIndicator(this.meta[0]);
/*      */     }
/*  319 */     if (this.meta[0] == 0)
/*      */     {
/*      */ 
/*      */ 
/*  323 */       this.rowSpaceIndicator[i] = -1;
/*  324 */       this.rowSpaceIndicator[j] = 0;
/*      */     }
/*      */     else
/*      */     {
/*  328 */       this.rowSpaceIndicator[j] = ((short)(this.meta[0] * 2));
/*      */       
/*      */ 
/*      */ 
/*  332 */       this.rowSpaceIndicator[i] = 0;
/*      */     }
/*      */     
/*  335 */     this.lastRowProcessed += 1;
/*      */     
/*  337 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void copyRow()
/*      */     throws SQLException, IOException
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*  348 */     if (this.lastRowProcessed == 0) {
/*  349 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*      */     } else {
/*  351 */       i = this.lastRowProcessed - 1;
/*      */     }
/*      */     
/*  354 */     int j = this.columnIndex + this.lastRowProcessed * this.charLength;
/*  355 */     int k = this.columnIndex + i * this.charLength;
/*  356 */     int m = this.indicatorIndex + this.lastRowProcessed;
/*  357 */     int n = this.indicatorIndex + i;
/*  358 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/*  359 */     int i2 = this.lengthIndex + i;
/*  360 */     int i3 = this.rowSpaceIndicator[i2];
/*  361 */     int i4 = this.metaDataIndex + this.lastRowProcessed * 1;
/*      */     
/*  363 */     int i5 = this.metaDataIndex + i * 1;
/*      */     
/*      */ 
/*      */ 
/*  367 */     this.rowSpaceIndicator[i1] = ((short)i3);
/*  368 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*      */     
/*      */ 
/*  371 */     if (!this.isNullByDescribe)
/*      */     {
/*  373 */       System.arraycopy(this.rowSpaceChar, k, this.rowSpaceChar, j, this.rowSpaceChar[k] / '\002' + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  378 */     System.arraycopy(this.rowSpaceMetaData, i5, this.rowSpaceMetaData, i4, 1);
/*      */     
/*      */ 
/*      */ 
/*  382 */     this.lastRowProcessed += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfByte, char[] paramArrayOfChar, short[] paramArrayOfShort, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  395 */     int i = this.columnIndex + (paramInt2 - 1) * this.charLength;
/*      */     
/*  397 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.charLength;
/*      */     
/*  399 */     int k = this.indicatorIndex + paramInt2 - 1;
/*  400 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/*  401 */     int n = this.lengthIndex + paramInt2 - 1;
/*  402 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/*  403 */     int i2 = paramArrayOfShort[i1];
/*      */     
/*  405 */     this.rowSpaceIndicator[n] = ((short)i2);
/*  406 */     this.rowSpaceIndicator[k] = paramArrayOfShort[m];
/*      */     
/*      */ 
/*  409 */     if (i2 != 0)
/*      */     {
/*  411 */       System.arraycopy(paramArrayOfChar, j, this.rowSpaceChar, i, paramArrayOfChar[j] / '\002' + 1);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  416 */       this.rowSpaceChar[i] = '\000';
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final int MON_MONTH = 4;
/*      */   
/*      */ 
/*      */   static final int YY_YEAR = 5;
/*      */   
/*      */ 
/*      */   static final int RR_YEAR = 6;
/*      */   
/*      */ 
/*      */   static final int HH_HOUR = 7;
/*      */   
/*      */ 
/*      */   void calculateSizeTmpByteArray()
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/*  439 */     if (this.formOfUse == 2)
/*      */     {
/*      */ 
/*      */ 
/*  443 */       i = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
/*      */     }
/*      */     else
/*      */     {
/*  447 */       i = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
/*      */     }
/*      */     
/*  450 */     if (this.statement.sizeTmpByteArray < i) {
/*  451 */       this.statement.sizeTmpByteArray = i;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  464 */     String str = super.getString(paramInt);
/*      */     
/*  466 */     if ((str != null) && (this.definedColumnSize > 0) && (str.length() > this.definedColumnSize))
/*      */     {
/*  468 */       str = str.substring(0, this.definedColumnSize);
/*      */     }
/*  470 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  480 */     NUMBER localNUMBER = null;
/*      */     
/*  482 */     if (this.definedColumnType == 0) {
/*  483 */       localNUMBER = super.getNUMBER(paramInt);
/*      */     }
/*      */     else {
/*  486 */       String str = getString(paramInt);
/*  487 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  496 */         return StringToNUMBER(str);
/*      */       }
/*      */     }
/*      */     
/*  500 */     return localNUMBER;
/*      */   }
/*      */   
/*      */ 
/*      */   DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  507 */     DATE localDATE = null;
/*      */     
/*  509 */     if (this.definedColumnType == 0) {
/*  510 */       localDATE = super.getDATE(paramInt);
/*      */     }
/*      */     else {
/*  513 */       Date localDate = getDate(paramInt);
/*  514 */       if (localDate != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  523 */         localDATE = new DATE(localDate);
/*      */       }
/*      */     }
/*      */     
/*  527 */     return localDATE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  535 */     TIMESTAMP localTIMESTAMP = null;
/*      */     
/*  537 */     if (this.definedColumnType == 0) {
/*  538 */       localTIMESTAMP = super.getTIMESTAMP(paramInt);
/*      */     }
/*      */     else {
/*  541 */       String str = getString(paramInt);
/*  542 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */         int[] arrayOfInt = new int[1];
/*  553 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*      */         
/*      */ 
/*  556 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  557 */         localTimestamp.setNanos(arrayOfInt[0]);
/*  558 */         localTIMESTAMP = new TIMESTAMP(localTimestamp);
/*      */       }
/*      */     }
/*      */     
/*  562 */     return localTIMESTAMP;
/*      */   }
/*      */   
/*      */ 
/*      */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  569 */     TIMESTAMPTZ localTIMESTAMPTZ = null;
/*      */     
/*  571 */     if (this.definedColumnType == 0) {
/*  572 */       localTIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt);
/*      */     }
/*      */     else {
/*  575 */       String str = getString(paramInt);
/*  576 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  587 */         int[] arrayOfInt = new int[1];
/*  588 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */         
/*      */ 
/*  591 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  592 */         localTimestamp.setNanos(arrayOfInt[0]);
/*  593 */         localTIMESTAMPTZ = new TIMESTAMPTZ(this.statement.connection, localTimestamp, localCalendar);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  599 */     return localTIMESTAMPTZ;
/*      */   }
/*      */   
/*      */ 
/*      */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  606 */     TIMESTAMPLTZ localTIMESTAMPLTZ = null;
/*      */     
/*  608 */     if (this.definedColumnType == 0) {
/*  609 */       localTIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt);
/*      */     }
/*      */     else {
/*  612 */       String str = getString(paramInt);
/*  613 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  624 */         int[] arrayOfInt = new int[1];
/*  625 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */         
/*      */ 
/*  628 */         Timestamp localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  629 */         localTimestamp.setNanos(arrayOfInt[0]);
/*  630 */         localTIMESTAMPLTZ = new TIMESTAMPLTZ(this.statement.connection, localTimestamp, localCalendar);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  636 */     return localTIMESTAMPLTZ;
/*      */   }
/*      */   
/*      */ 
/*      */   RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  643 */     RAW localRAW = null;
/*      */     
/*  645 */     if (this.definedColumnType == 0) {
/*  646 */       localRAW = super.getRAW(paramInt);
/*      */     }
/*      */     else {
/*  649 */       if (this.rowSpaceIndicator == null)
/*      */       {
/*      */ 
/*      */ 
/*  653 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  654 */         localSQLException.fillInStackTrace();
/*  655 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  661 */       if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */       {
/*  663 */         if ((this.definedColumnType == -2) || (this.definedColumnType == -3) || (this.definedColumnType == -4))
/*      */         {
/*      */ 
/*  666 */           localRAW = new RAW(getBytesFromHexChars(paramInt));
/*      */         } else {
/*  668 */           localRAW = new RAW(super.getBytes(paramInt));
/*      */         }
/*      */       }
/*      */     }
/*  672 */     return localRAW;
/*      */   }
/*      */   
/*      */ 
/*      */   Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  679 */     if (this.definedColumnType == 0) {
/*  680 */       return super.getOracleObject(paramInt);
/*      */     }
/*      */     
/*  683 */     Datum localDatum = null;
/*      */     SQLException localSQLException;
/*  685 */     if (this.rowSpaceIndicator == null)
/*      */     {
/*  687 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  688 */       localSQLException.fillInStackTrace();
/*  689 */       throw localSQLException;
/*      */     }
/*      */     
/*  692 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/*  694 */       switch (this.definedColumnType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -16: 
/*      */       case -15: 
/*      */       case -9: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*  707 */         return super.getOracleObject(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -7: 
/*      */       case -6: 
/*      */       case -5: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 16: 
/*  730 */         return getNUMBER(paramInt);
/*      */       
/*      */       case 91: 
/*  733 */         return getDATE(paramInt);
/*      */       
/*      */       case 92: 
/*  736 */         return getDATE(paramInt);
/*      */       
/*      */       case 93: 
/*  739 */         return getTIMESTAMP(paramInt);
/*      */       
/*      */       case -101: 
/*  742 */         return getTIMESTAMPTZ(paramInt);
/*      */       
/*      */       case -102: 
/*  745 */         return getTIMESTAMPLTZ(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*  752 */         return getRAW(paramInt);
/*      */       
/*      */       case -8: 
/*  755 */         return getROWID(paramInt);
/*      */       }
/*      */       
/*      */       
/*  759 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  760 */       localSQLException.fillInStackTrace();
/*  761 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  767 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  776 */     if (this.definedColumnType == 0) {
/*  777 */       return super.getBytes(paramInt);
/*      */     }
/*  779 */     Datum localDatum = getOracleObject(paramInt);
/*  780 */     if (localDatum != null) {
/*  781 */       return localDatum.shareBytes();
/*      */     }
/*  783 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  791 */     boolean bool = false;
/*      */     
/*  793 */     if (this.definedColumnType == 0) {
/*  794 */       bool = super.getBoolean(paramInt);
/*      */     }
/*      */     else {
/*  797 */       bool = getNUMBER(paramInt).booleanValue();
/*      */     }
/*      */     
/*  800 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   byte getByte(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  808 */     byte b = 0;
/*      */     
/*  810 */     if (this.definedColumnType == 0) {
/*  811 */       b = super.getByte(paramInt);
/*      */     }
/*      */     else {
/*  814 */       b = getNUMBER(paramInt).byteValue();
/*      */     }
/*      */     
/*  817 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  825 */     int i = 0;
/*      */     
/*  827 */     if (this.definedColumnType == 0) {
/*  828 */       i = super.getInt(paramInt);
/*      */     }
/*      */     else {
/*  831 */       i = getNUMBER(paramInt).intValue();
/*      */     }
/*      */     
/*  834 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  842 */     short s = 0;
/*      */     
/*  844 */     if (this.definedColumnType == 0) {
/*  845 */       s = super.getShort(paramInt);
/*      */     }
/*      */     else {
/*  848 */       s = getNUMBER(paramInt).shortValue();
/*      */     }
/*      */     
/*  851 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  859 */     long l = 0L;
/*      */     
/*  861 */     if (this.definedColumnType == 0) {
/*  862 */       l = super.getLong(paramInt);
/*      */     }
/*      */     else {
/*  865 */       l = getNUMBER(paramInt).longValue();
/*      */     }
/*      */     
/*  868 */     return l;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  876 */     float f = 0.0F;
/*      */     
/*  878 */     if (this.definedColumnType == 0) {
/*  879 */       f = super.getFloat(paramInt);
/*      */     }
/*      */     else {
/*  882 */       f = getNUMBER(paramInt).floatValue();
/*      */     }
/*      */     
/*  885 */     return f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  893 */     double d = 0.0D;
/*      */     
/*  895 */     if (this.definedColumnType == 0) {
/*  896 */       d = super.getDouble(paramInt);
/*      */     }
/*      */     else {
/*  899 */       d = getNUMBER(paramInt).doubleValue();
/*      */     }
/*      */     
/*  902 */     return d;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  912 */     Date localDate = null;
/*      */     
/*  914 */     if (this.definedColumnType == 0) {
/*  915 */       localDate = super.getDate(paramInt);
/*      */     }
/*      */     else {
/*  918 */       String str = getString(paramInt);
/*  919 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  928 */         int[] arrayOfInt = new int[1];
/*      */         
/*  930 */         localDate = new Date(DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  936 */     return localDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  944 */     Timestamp localTimestamp = null;
/*      */     
/*  946 */     if (this.definedColumnType == 0) {
/*  947 */       localTimestamp = super.getTimestamp(paramInt);
/*      */     }
/*      */     else {
/*  950 */       String str = getString(paramInt);
/*  951 */       if (str != null)
/*      */       {
/*  953 */         int[] arrayOfInt = new int[1];
/*  954 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*      */         
/*      */ 
/*  957 */         localTimestamp = new Timestamp(localCalendar.getTimeInMillis());
/*  958 */         localTimestamp.setNanos(arrayOfInt[0]);
/*      */       }
/*      */     }
/*      */     
/*  962 */     return localTimestamp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  970 */     Time localTime = null;
/*      */     
/*  972 */     if (this.definedColumnType == 0) {
/*  973 */       localTime = super.getTime(paramInt);
/*      */     }
/*      */     else {
/*  976 */       String str = getString(paramInt);
/*  977 */       if (str != null)
/*      */       {
/*  979 */         int[] arrayOfInt = new int[1];
/*  980 */         Calendar localCalendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */         
/*      */ 
/*  983 */         localTime = new Time(localCalendar.getTimeInMillis());
/*      */       }
/*      */     }
/*      */     
/*  987 */     return localTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  996 */     if (this.definedColumnType == 0) {
/*  997 */       return super.getObject(paramInt);
/*      */     }
/*      */     
/* 1000 */     Object localObject = null;
/*      */     SQLException localSQLException;
/* 1002 */     if (this.rowSpaceIndicator == null)
/*      */     {
/* 1004 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1005 */       localSQLException.fillInStackTrace();
/* 1006 */       throw localSQLException;
/*      */     }
/*      */     
/* 1009 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*      */     {
/* 1011 */       switch (this.definedColumnType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case -16: 
/*      */       case -15: 
/*      */       case -9: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 1024 */         return getString(paramInt);
/*      */       
/*      */ 
/*      */       case 2: 
/*      */       case 3: 
/* 1029 */         return getBigDecimal(paramInt);
/*      */       
/*      */       case 4: 
/* 1032 */         return Integer.valueOf(getInt(paramInt));
/*      */       
/*      */       case -6: 
/* 1035 */         return Byte.valueOf(getByte(paramInt));
/*      */       
/*      */       case 5: 
/* 1038 */         return Short.valueOf(getShort(paramInt));
/*      */       
/*      */ 
/*      */       case -7: 
/*      */       case 16: 
/* 1043 */         return Boolean.valueOf(getBoolean(paramInt));
/*      */       
/*      */       case -5: 
/* 1046 */         return Long.valueOf(getLong(paramInt));
/*      */       
/*      */       case 7: 
/* 1049 */         return Float.valueOf(getFloat(paramInt));
/*      */       
/*      */ 
/*      */       case 6: 
/*      */       case 8: 
/* 1054 */         return Double.valueOf(getDouble(paramInt));
/*      */       
/*      */       case 91: 
/* 1057 */         return getDate(paramInt);
/*      */       
/*      */       case 92: 
/* 1060 */         return getTime(paramInt);
/*      */       
/*      */       case 93: 
/* 1063 */         return getTimestamp(paramInt);
/*      */       
/*      */       case -101: 
/* 1066 */         return getTIMESTAMPTZ(paramInt);
/*      */       
/*      */       case -102: 
/* 1069 */         return getTIMESTAMPLTZ(paramInt);
/*      */       
/*      */ 
/*      */ 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/* 1076 */         return getBytesFromHexChars(paramInt);
/*      */       
/*      */       case -8: 
/* 1079 */         return getROWID(paramInt);
/*      */       }
/*      */       
/*      */       
/* 1083 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1084 */       localSQLException.fillInStackTrace();
/* 1085 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1091 */     return localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final NUMBER StringToNUMBER(String paramString)
/*      */     throws SQLException
/*      */   {
/* 1100 */     return new NUMBER(new BigDecimal(paramString));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final int HH24_HOUR = 8;
/*      */   
/*      */ 
/*      */   static final int MINUTE = 9;
/*      */   
/*      */ 
/*      */   static final int SECOND = 10;
/*      */   
/*      */ 
/*      */   static final int NSECOND = 11;
/*      */   
/*      */ 
/*      */   static final int AM = 12;
/*      */   
/*      */ 
/*      */   static final int TZR = 13;
/*      */   
/*      */   static final int TZH = 14;
/*      */   
/*      */   static final int TZM = 15;
/*      */   
/*      */   static final Calendar DATEStringToCalendar(String paramString1, String paramString2, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/* 1129 */     char[] arrayOfChar = (paramString2 + " ").toCharArray();
/* 1130 */     paramString1 = paramString1 + " ";
/*      */     
/*      */ 
/* 1133 */     int i = Math.min(paramString1.length(), arrayOfChar.length);
/*      */     
/* 1135 */     int j = -1;
/* 1136 */     int k = -1;
/*      */     
/* 1138 */     int m = 0;
/* 1139 */     int n = 0;
/*      */     
/* 1141 */     String str1 = 0;
/* 1142 */     int i1 = 0;
/*      */     
/* 1144 */     int i2 = 0;
/* 1145 */     int i3 = 0;
/* 1146 */     int i4 = 0;
/*      */     
/* 1148 */     int i5 = 0;
/* 1149 */     int i6 = 0;
/* 1150 */     int i7 = 0;
/* 1151 */     int i8 = 0;
/*      */     
/* 1153 */     String str2 = null;
/* 1154 */     String str3 = null;
/*      */     
/* 1156 */     int i9 = 0;
/*      */     
/*      */ 
/* 1159 */     String[] arrayOfString1 = null;
/* 1160 */     String[] arrayOfString2 = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1178 */     for (int i10 = 0; i10 < i; i10++)
/*      */     {
/* 1180 */       switch (arrayOfChar[i10])
/*      */       {
/*      */       case 'R': 
/*      */       case 'r': 
/* 1184 */         if (j != 6)
/*      */         {
/* 1186 */           j = 6;
/* 1187 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'Y': 
/*      */       case 'y': 
/* 1193 */         if (j != 5)
/*      */         {
/* 1195 */           j = 5;
/* 1196 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'D': 
/*      */       case 'd': 
/* 1202 */         if (j != 1)
/*      */         {
/* 1204 */           j = 1;
/* 1205 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'M': 
/*      */       case 'm': 
/* 1211 */         if ((j != 2) || (j != 4) || (j != 3) || (j != 9))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1217 */           m = i10;
/*      */           
/* 1219 */           if ((i10 + 4 < i) && ((arrayOfChar[(i10 + 1)] == 'O') || (arrayOfChar[(i10 + 1)] == 'o')) && ((arrayOfChar[(i10 + 2)] == 'N') || (arrayOfChar[(i10 + 2)] == 'n')) && ((arrayOfChar[(i10 + 3)] == 'T') || (arrayOfChar[(i10 + 3)] == 't')) && ((arrayOfChar[(i10 + 4)] == 'H') || (arrayOfChar[(i10 + 4)] == 'h')))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1225 */             j = 3;
/* 1226 */             i10 += 4;
/* 1227 */           } else if ((i10 + 2 < i) && ((arrayOfChar[(i10 + 1)] == 'O') || (arrayOfChar[(i10 + 1)] == 'o')) && ((arrayOfChar[(i10 + 2)] == 'N') || (arrayOfChar[(i10 + 2)] == 'n')))
/*      */           {
/*      */ 
/*      */ 
/* 1231 */             j = 4;
/* 1232 */             i10 += 2;
/* 1233 */           } else if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'M') || (arrayOfChar[(i10 + 1)] == 'm')))
/*      */           {
/*      */ 
/* 1236 */             j = 2;
/* 1237 */             i10++;
/* 1238 */           } else if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'I') || (arrayOfChar[(i10 + 1)] == 'i')))
/*      */           {
/*      */ 
/* 1241 */             j = 9;
/* 1242 */             i10++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 'H': 
/*      */       case 'h': 
/* 1251 */         if (j != 7)
/*      */         {
/* 1253 */           j = 7;
/* 1254 */           m = i10;
/* 1255 */         } else if ((i10 + 2 < i) && ((arrayOfChar[(i10 + 1)] == '2') || (arrayOfChar[(i10 + 4)] == '4')))
/*      */         {
/*      */ 
/* 1258 */           j = 8;
/* 1259 */           i10 += 2;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'S': 
/*      */       case 's': 
/* 1265 */         if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'S') || (arrayOfChar[(i10 + 1)] == 's')))
/*      */         {
/*      */ 
/* 1268 */           j = 10;
/* 1269 */           m = i10;
/* 1270 */           i10++;
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 'F': 
/*      */       case 'f': 
/* 1277 */         if (j != 11)
/*      */         {
/* 1279 */           j = 11;
/* 1280 */           m = i10;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'A': 
/*      */       case 'a': 
/* 1286 */         if ((i10 + 1 < i) && ((arrayOfChar[(i10 + 1)] == 'M') || (arrayOfChar[(i10 + 1)] == 'm')))
/*      */         {
/*      */ 
/* 1289 */           j = 12;
/* 1290 */           m = i10;
/* 1291 */           i10++;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 'T': 
/*      */       case 't': 
/* 1297 */         if ((i10 + 2 < i) && ((arrayOfChar[(i10 + 1)] == 'Z') || (arrayOfChar[(i10 + 1)] == 'z')) && ((arrayOfChar[(i10 + 2)] == 'R') || (arrayOfChar[(i10 + 2)] == 'r')))
/*      */         {
/*      */ 
/*      */ 
/* 1301 */           j = 13;
/* 1302 */           m = i10;
/* 1303 */           i10 += 2;
/*      */         }
/*      */         break;
/*      */       case 'B': case 'C': case 'E': case 'G': case 'I': case 'J': case 'K': case 'L': case 'N': case 'O': 
/*      */       case 'P': case 'Q': case 'U': case 'V': case 'W': case 'X': case 'Z': case '[': case '\\': case ']': 
/*      */       case '^': case '_': case '`': case 'b': case 'c': case 'e': case 'g': case 'i': case 'j': case 'k': 
/*      */       case 'l': case 'n': case 'o': case 'p': case 'q': case 'u': case 'v': case 'w': case 'x': default: 
/* 1310 */         i9 = 1;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1321 */       if ((i9 != 0) && (j != -1))
/*      */       {
/* 1323 */         int i11 = i10 - m;
/* 1324 */         int i12 = m - n;
/* 1325 */         str1 = i1 + i12;
/*      */         
/* 1327 */         i1 = str1 + i11;
/* 1328 */         Object localObject; String str4; int i15; switch (j)
/*      */         {
/*      */         case 1: 
/* 1331 */           i2 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1332 */           break;
/*      */         
/*      */         case 2: 
/* 1335 */           i3 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1336 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 3: 
/* 1341 */           int i16 = str1;
/* 1342 */           i1 = str1;
/* 1343 */           for (i16 = str1; i16 < paramString1.length(); i16++)
/* 1344 */             if (paramString1.charAt(i16) == arrayOfChar[i10])
/*      */               break;
/* 1346 */           i1 = i16;
/*      */           
/* 1348 */           localObject = null;
/* 1349 */           if (i1 != str1) {
/* 1350 */             localObject = paramString1.substring(str1, i1);
/*      */             
/*      */ 
/*      */ 
/* 1354 */             localObject = ((String)localObject).trim();
/*      */             
/* 1356 */             if (arrayOfString2 == null)
/* 1357 */               arrayOfString2 = new DateFormatSymbols().getMonths();
/* 1358 */             for (i3 = 0; i3 < arrayOfString2.length; i3++) {
/* 1359 */               if (((String)localObject).equalsIgnoreCase(arrayOfString2[i3]))
/*      */                 break;
/*      */             }
/* 1362 */             if (i3 >= 12)
/*      */             {
/* 1364 */               SQLException localSQLException = DatabaseError.createSqlException(null, 59);
/* 1365 */               localSQLException.fillInStackTrace();
/* 1366 */               throw localSQLException;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1375 */           break;
/*      */         
/*      */         case 4: 
/* 1378 */           int i13 = str1;
/* 1379 */           i1 = str1;
/* 1380 */           for (int i14 = str1; i14 < paramString1.length(); i14++)
/* 1381 */             if (paramString1.charAt(i14) == arrayOfChar[i10])
/*      */               break;
/* 1383 */           i1 = i14;
/*      */           
/* 1385 */           str4 = null;
/* 1386 */           if (i1 != str1) {
/* 1387 */             str4 = paramString1.substring(str1, i1);
/*      */             
/*      */ 
/*      */ 
/* 1391 */             str4 = str4.trim();
/*      */             
/* 1393 */             if (arrayOfString1 == null)
/* 1394 */               arrayOfString1 = new DateFormatSymbols().getShortMonths();
/* 1395 */             for (i3 = 0; i3 < arrayOfString1.length; i3++) {
/* 1396 */               if (str4.equalsIgnoreCase(arrayOfString1[i3]))
/*      */                 break;
/*      */             }
/* 1399 */             if (i3 >= 12)
/*      */             {
/* 1401 */               localObject = DatabaseError.createSqlException(null, 59);
/* 1402 */               ((SQLException)localObject).fillInStackTrace();
/* 1403 */               throw ((Throwable)localObject);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1412 */           break;
/*      */         
/*      */         case 5: 
/* 1415 */           i4 = Integer.parseInt(paramString1.substring(str1, i1));
/*      */           
/*      */ 
/*      */ 
/* 1419 */           if (i11 == 2) {
/* 1420 */             i4 += 2000;
/*      */           }
/*      */           break;
/*      */         case 6: 
/* 1424 */           i4 = Integer.parseInt(paramString1.substring(str1, i1));
/*      */           
/*      */ 
/*      */ 
/* 1428 */           if ((i11 == 2) && (i4 < 50)) {
/* 1429 */             i4 += 2000;
/*      */           } else
/* 1431 */             i4 += 1900;
/* 1432 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 7: 
/*      */         case 8: 
/* 1438 */           i1 = str1 + 2;
/* 1439 */           i5 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1440 */           break;
/*      */         
/*      */         case 9: 
/* 1443 */           i6 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1444 */           break;
/*      */         
/*      */         case 10: 
/* 1447 */           i7 = Integer.parseInt(paramString1.substring(str1, i1));
/* 1448 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 11: 
/* 1457 */           str4 = str1;
/* 1458 */           i1 = str1;
/* 1459 */           for (str4 = str1; str4 < paramString1.length(); str4++)
/* 1460 */             if (((i15 = paramString1.charAt(str4)) < '0') || (i15 > 57))
/*      */               break;
/* 1462 */           i1 += str4 - str1;
/*      */           
/* 1464 */           if (i1 != str1) {
/* 1465 */             i8 = Integer.parseInt(paramString1.substring(str1, i1));
/*      */           }
/*      */           break;
/*      */         case 12: 
/* 1469 */           if (i1 > 0) {
/* 1470 */             str2 = paramString1.substring(str1, i1);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 13: 
/* 1480 */           int i17 = str1;
/* 1481 */           i1 = str1;
/* 1482 */           for (int i18 = str1; i18 < paramString1.length(); i18++) {
/* 1483 */             if ((((i15 = paramString1.charAt(i18)) < '0') || (i15 > 57)) && ((i15 < 97) || (i15 > 122)) && ((i15 < 65) || (i15 > 90))) {
/*      */               break;
/*      */             }
/*      */             
/*      */ 
/* 1488 */             i1 = i18;
/*      */           }
/* 1490 */           if (i1 != str1) {
/* 1491 */             str3 = paramString1.substring(str1, i1);
/*      */           }
/*      */           
/*      */           break;
/*      */         default: 
/* 1496 */           System.out.println("\n\n\n             ***** ERROR(1) ****\n");
/*      */         }
/*      */         
/*      */         
/* 1500 */         n = i10;
/* 1501 */         j = -1;
/* 1502 */         i9 = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1509 */     GregorianCalendar localGregorianCalendar = new GregorianCalendar(i4, i3, i2, i5, i6, i7);
/* 1510 */     if (str2 != null) {
/* 1511 */       localGregorianCalendar.set(9, str2.equalsIgnoreCase("AM") ? 0 : 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1516 */     if ((str3 == null) || 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1522 */       (i8 != 0)) {
/* 1523 */       paramArrayOfInt[0] = i8;
/*      */     }
/* 1525 */     return localGregorianCalendar;
/*      */   }
/*      */   
/*      */ 
/* 1529 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\T4CVarcharAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */