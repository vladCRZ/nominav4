/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.OffsetDST;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestampltzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/*  35 */     init(paramOracleStatement, 231, 231, paramShort, paramBoolean);
/*  36 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort)
/*     */     throws SQLException
/*     */   {
/*  45 */     init(paramOracleStatement, 231, 231, paramShort, false);
/*  46 */     initForDescribe(231, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  48 */     initForDataAccess(0, paramInt1, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString)
/*     */     throws SQLException
/*     */   {
/*  56 */     if (paramInt1 != 0) {
/*  57 */       this.externalType = paramInt1;
/*     */     }
/*  59 */     this.internalTypeMaxLength = 11;
/*     */     
/*  61 */     if ((paramInt2 > 0) && (paramInt2 < this.internalTypeMaxLength)) {
/*  62 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  64 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   String getString(int paramInt)
/*     */     throws SQLException
/*     */   {
/*  72 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/*  76 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  77 */       ((SQLException)localObject1).fillInStackTrace();
/*  78 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  84 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] == -1) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     Object localObject1 = this.statement.connection.getDbTzCalendar();
/*     */     
/*     */ 
/*     */ 
/*  92 */     String str1 = this.statement.connection.getSessionTimeZone();
/*     */     
/*  94 */     if (str1 == null)
/*     */     {
/*     */ 
/*  97 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/*  98 */       ((SQLException)localObject2).fillInStackTrace();
/*  99 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/* 103 */     Object localObject2 = TimeZone.getTimeZone(str1);
/*     */     
/* 105 */     Calendar localCalendar = Calendar.getInstance((TimeZone)localObject2);
/*     */     
/* 107 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 108 */     int j = this.rowSpaceIndicator[(this.lengthIndex + paramInt)];
/*     */     
/* 110 */     int k = ((this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */     
/*     */ 
/* 113 */     ((Calendar)localObject1).set(1, k);
/* 114 */     ((Calendar)localObject1).set(2, oracleMonth(i));
/* 115 */     ((Calendar)localObject1).set(5, oracleDay(i));
/* 116 */     ((Calendar)localObject1).set(11, oracleHour(i));
/* 117 */     ((Calendar)localObject1).set(12, oracleMin(i));
/* 118 */     ((Calendar)localObject1).set(13, oracleSec(i));
/* 119 */     ((Calendar)localObject1).set(14, 0);
/*     */     
/*     */ 
/* 122 */     TimeZoneAdjust((Calendar)localObject1, localCalendar);
/*     */     
/*     */ 
/* 125 */     k = localCalendar.get(1);
/*     */     
/* 127 */     int m = localCalendar.get(2) + 1;
/* 128 */     int n = localCalendar.get(5);
/* 129 */     int i1 = localCalendar.get(11);
/* 130 */     int i2 = localCalendar.get(12);
/* 131 */     int i3 = localCalendar.get(13);
/* 132 */     int i4 = 0;
/* 133 */     boolean bool = i1 < 12;
/* 134 */     String str2 = localCalendar.getTimeZone().getID();
/* 135 */     if ((str2.length() > 3) && (str2.startsWith("GMT"))) {
/* 136 */       str2 = str2.substring(3);
/*     */     }
/* 138 */     if (j == 11)
/*     */     {
/* 140 */       i4 = oracleNanos(i);
/*     */     }
/*     */     
/* 143 */     return toText(k, m, n, i1, i2, i3, i4, bool, str2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Date getDate(int paramInt, Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 154 */     return getDate(paramInt);
/*     */   }
/*     */   
/*     */   Date getDate(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 160 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 164 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 165 */       ((SQLException)localObject1).fillInStackTrace();
/* 166 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 172 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] == -1) {
/* 173 */       return null;
/*     */     }
/*     */     
/* 176 */     Object localObject1 = this.statement.connection.getDbTzCalendar();
/*     */     
/*     */ 
/*     */ 
/* 180 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 182 */     if (str == null)
/*     */     {
/*     */ 
/* 185 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 186 */       ((SQLException)localObject2).fillInStackTrace();
/* 187 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/* 191 */     Object localObject2 = TimeZone.getTimeZone(str);
/*     */     
/* 193 */     Calendar localCalendar = Calendar.getInstance((TimeZone)localObject2);
/*     */     
/* 195 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 196 */     int j = ((this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */     
/*     */ 
/* 199 */     ((Calendar)localObject1).set(1, j);
/* 200 */     ((Calendar)localObject1).set(2, oracleMonth(i));
/* 201 */     ((Calendar)localObject1).set(5, oracleDay(i));
/* 202 */     ((Calendar)localObject1).set(11, oracleHour(i));
/* 203 */     ((Calendar)localObject1).set(12, oracleMin(i));
/* 204 */     ((Calendar)localObject1).set(13, oracleSec(i));
/* 205 */     ((Calendar)localObject1).set(14, 0);
/*     */     
/* 207 */     long l = TimeZoneAdjustUTC((Calendar)localObject1);
/*     */     
/* 209 */     return new Date(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Time getTime(int paramInt, Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 218 */     return getTime(paramInt);
/*     */   }
/*     */   
/*     */   Time getTime(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 224 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 228 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 229 */       ((SQLException)localObject1).fillInStackTrace();
/* 230 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 235 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] == -1) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     Object localObject1 = this.statement.connection.getDbTzCalendar();
/*     */     
/*     */ 
/*     */ 
/* 243 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 245 */     if (str == null)
/*     */     {
/*     */ 
/* 248 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 249 */       ((SQLException)localObject2).fillInStackTrace();
/* 250 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/* 254 */     Object localObject2 = TimeZone.getTimeZone(str);
/*     */     
/* 256 */     Calendar localCalendar = Calendar.getInstance((TimeZone)localObject2);
/*     */     
/* 258 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 259 */     int j = ((this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */     
/*     */ 
/* 262 */     ((Calendar)localObject1).set(1, j);
/* 263 */     ((Calendar)localObject1).set(2, oracleMonth(i));
/* 264 */     ((Calendar)localObject1).set(5, oracleDay(i));
/* 265 */     ((Calendar)localObject1).set(11, oracleHour(i));
/* 266 */     ((Calendar)localObject1).set(12, oracleMin(i));
/* 267 */     ((Calendar)localObject1).set(13, oracleSec(i));
/* 268 */     ((Calendar)localObject1).set(14, 0);
/*     */     
/*     */ 
/* 271 */     long l = TimeZoneAdjustUTC((Calendar)localObject1);
/*     */     
/* 273 */     return new Time(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 283 */     return getTimestamp(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */   Timestamp getTimestamp(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 290 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 294 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 295 */       ((SQLException)localObject1).fillInStackTrace();
/* 296 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 302 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] == -1) {
/* 303 */       return null;
/*     */     }
/*     */     
/* 306 */     Object localObject1 = this.statement.connection.getDbTzCalendar();
/*     */     
/*     */ 
/*     */ 
/* 310 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 312 */     if (str == null)
/*     */     {
/*     */ 
/* 315 */       localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 316 */       ((SQLException)localObject2).fillInStackTrace();
/* 317 */       throw ((Throwable)localObject2);
/*     */     }
/*     */     
/*     */ 
/* 321 */     Object localObject2 = TimeZone.getTimeZone(str);
/* 322 */     Calendar localCalendar = Calendar.getInstance((TimeZone)localObject2);
/*     */     
/* 324 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 325 */     int j = this.rowSpaceIndicator[(this.lengthIndex + paramInt)];
/*     */     
/* 327 */     int k = ((this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */     
/*     */ 
/* 330 */     ((Calendar)localObject1).set(1, k);
/* 331 */     ((Calendar)localObject1).set(2, oracleMonth(i));
/* 332 */     ((Calendar)localObject1).set(5, oracleDay(i));
/* 333 */     ((Calendar)localObject1).set(11, oracleHour(i));
/* 334 */     ((Calendar)localObject1).set(12, oracleMin(i));
/* 335 */     ((Calendar)localObject1).set(13, oracleSec(i));
/* 336 */     ((Calendar)localObject1).set(14, 0);
/*     */     
/*     */ 
/* 339 */     long l = TimeZoneAdjustUTC((Calendar)localObject1);
/*     */     
/* 341 */     Timestamp localTimestamp = new Timestamp(l);
/*     */     
/* 343 */     if (j == 11)
/*     */     {
/* 345 */       localTimestamp.setNanos(oracleNanos(i));
/*     */     }
/*     */     
/* 348 */     return localTimestamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 356 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Datum getOracleObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 364 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Object getObject(int paramInt, Map paramMap)
/*     */     throws SQLException
/*     */   {
/* 372 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 380 */     TIMESTAMPLTZ localTIMESTAMPLTZ = null;
/*     */     
/* 382 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 386 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 387 */       localSQLException.fillInStackTrace();
/* 388 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 394 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */     {
/* 396 */       int i = this.rowSpaceIndicator[(this.lengthIndex + paramInt)];
/* 397 */       int j = this.columnIndex + this.byteLength * paramInt;
/* 398 */       byte[] arrayOfByte = new byte[i];
/*     */       
/* 400 */       System.arraycopy(this.rowSpaceByte, j, arrayOfByte, 0, i);
/*     */       
/* 402 */       localTIMESTAMPLTZ = new TIMESTAMPLTZ(arrayOfByte);
/*     */     }
/*     */     
/* 405 */     return localTIMESTAMPLTZ;
/*     */   }
/*     */   
/*     */ 
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 412 */     TIMESTAMPTZ localTIMESTAMPTZ = null;
/*     */     
/* 414 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/* 418 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 419 */       localSQLException.fillInStackTrace();
/* 420 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 426 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*     */     {
/* 428 */       int i = this.rowSpaceIndicator[(this.lengthIndex + paramInt)];
/* 429 */       int j = this.columnIndex + this.byteLength * paramInt;
/* 430 */       byte[] arrayOfByte = new byte[i];
/*     */       
/* 432 */       System.arraycopy(this.rowSpaceByte, j, arrayOfByte, 0, i);
/*     */       
/* 434 */       localTIMESTAMPTZ = TIMESTAMPLTZ.toTIMESTAMPTZ(this.statement.connection, arrayOfByte);
/*     */     }
/*     */     
/* 437 */     return localTIMESTAMPTZ;
/*     */   }
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 443 */     TIMESTAMPTZ localTIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 444 */     return TIMESTAMPTZ.toTIMESTAMP(this.statement.connection, localTIMESTAMPTZ.getBytes());
/*     */   }
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException
/*     */   {
/* 449 */     TIMESTAMPTZ localTIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 450 */     return TIMESTAMPTZ.toDATE(this.statement.connection, localTIMESTAMPTZ.getBytes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void TimeZoneAdjust(Calendar paramCalendar1, Calendar paramCalendar2)
/*     */     throws SQLException
/*     */   {
/* 460 */     String str1 = paramCalendar1.getTimeZone().getID();
/* 461 */     String str2 = paramCalendar2.getTimeZone().getID();
/*     */     
/*     */ 
/* 464 */     if (!str2.equals(str1))
/*     */     {
/* 466 */       OffsetDST localOffsetDST = new OffsetDST();
/*     */       
/*     */ 
/* 469 */       k = getZoneOffset(paramCalendar1, localOffsetDST);
/*     */       
/* 471 */       m = localOffsetDST.getOFFSET();
/*     */       
/*     */ 
/* 474 */       paramCalendar1.add(11, -(m / 3600000));
/* 475 */       paramCalendar1.add(12, -(m % 3600000) / 60000);
/*     */       
/*     */ 
/*     */       int i;
/*     */       
/*     */ 
/* 481 */       if ((str2.equals("Custom")) || ((str2.startsWith("GMT")) && (str2.length() > 3)))
/*     */       {
/*     */ 
/*     */ 
/* 485 */         i = paramCalendar2.getTimeZone().getRawOffset();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 490 */         n = ZONEIDMAP.getID(str2);
/*     */         
/* 492 */         if (!ZONEIDMAP.isValidID(n))
/*     */         {
/* 494 */           localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 495 */           ((SQLException)localObject).fillInStackTrace();
/* 496 */           throw ((Throwable)localObject);
/*     */         }
/*     */         
/* 499 */         Object localObject = this.statement.connection.getTIMEZONETAB();
/* 500 */         if (((TIMEZONETAB)localObject).checkID(n))
/*     */         {
/* 502 */           ((TIMEZONETAB)localObject).updateTable(this.statement.connection, n);
/*     */         }
/*     */         
/* 505 */         Calendar localCalendar = this.statement.getGMTCalendar();
/*     */         
/* 507 */         localCalendar.set(1, paramCalendar1.get(1));
/* 508 */         localCalendar.set(2, paramCalendar1.get(2));
/* 509 */         localCalendar.set(5, paramCalendar1.get(5));
/* 510 */         localCalendar.set(11, paramCalendar1.get(11));
/* 511 */         localCalendar.set(12, paramCalendar1.get(12));
/* 512 */         localCalendar.set(13, paramCalendar1.get(13));
/* 513 */         localCalendar.set(14, paramCalendar1.get(14));
/*     */         
/*     */ 
/* 516 */         i = ((TIMEZONETAB)localObject).getOffset(localCalendar, n);
/*     */       }
/*     */       
/*     */ 
/* 520 */       paramCalendar1.add(11, i / 3600000);
/* 521 */       paramCalendar1.add(12, i % 3600000 / 60000);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 528 */     if (((str2.equals("Custom")) && (str1.equals("Custom"))) || ((str2.startsWith("GMT")) && (str2.length() > 3) && (str1.startsWith("GMT")) && (str1.length() > 3)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 533 */       j = paramCalendar1.getTimeZone().getRawOffset();
/* 534 */       k = paramCalendar2.getTimeZone().getRawOffset();
/* 535 */       m = 0;
/*     */       
/*     */ 
/* 538 */       if (j != k)
/*     */       {
/*     */ 
/* 541 */         m = j - k;
/* 542 */         m = m > 0 ? m : -m;
/*     */       }
/*     */       
/* 545 */       if (j > k) {
/* 546 */         m = -m;
/*     */       }
/* 548 */       paramCalendar1.add(11, m / 3600000);
/* 549 */       paramCalendar1.add(12, m % 3600000 / 60000);
/*     */     }
/*     */     
/*     */ 
/* 553 */     int j = paramCalendar1.get(1);
/* 554 */     int k = paramCalendar1.get(2);
/* 555 */     int m = paramCalendar1.get(5);
/* 556 */     int n = paramCalendar1.get(11);
/* 557 */     int i1 = paramCalendar1.get(12);
/* 558 */     int i2 = paramCalendar1.get(13);
/* 559 */     int i3 = paramCalendar1.get(14);
/*     */     
/*     */ 
/* 562 */     paramCalendar2.set(1, j);
/* 563 */     paramCalendar2.set(2, k);
/* 564 */     paramCalendar2.set(5, m);
/* 565 */     paramCalendar2.set(11, n);
/* 566 */     paramCalendar2.set(12, i1);
/* 567 */     paramCalendar2.set(13, i2);
/* 568 */     paramCalendar2.set(14, i3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long TimeZoneAdjustUTC(Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 578 */     String str = paramCalendar.getTimeZone().getID();
/*     */     
/* 580 */     if ((str.equals("Custom")) || ((str.startsWith("GMT")) && (str.length() > 3)))
/*     */     {
/*     */ 
/*     */ 
/* 584 */       int i = paramCalendar.getTimeZone().getRawOffset();
/* 585 */       paramCalendar.add(11, -(i / 3600000));
/* 586 */       paramCalendar.add(12, -(i % 3600000) / 60000);
/*     */     }
/* 588 */     else if ((!str.equals("GMT")) && (!str.equals("UTC")))
/*     */     {
/* 590 */       OffsetDST localOffsetDST = new OffsetDST();
/*     */       
/*     */ 
/* 593 */       k = getZoneOffset(paramCalendar, localOffsetDST);
/*     */       
/* 595 */       m = localOffsetDST.getOFFSET();
/*     */       
/*     */ 
/*     */ 
/* 599 */       paramCalendar.add(11, -(m / 3600000));
/* 600 */       paramCalendar.add(12, -(m % 3600000) / 60000);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 608 */     int j = paramCalendar.get(1);
/* 609 */     int k = paramCalendar.get(2);
/* 610 */     int m = paramCalendar.get(5);
/* 611 */     int n = paramCalendar.get(11);
/* 612 */     int i1 = paramCalendar.get(12);
/* 613 */     int i2 = paramCalendar.get(13);
/* 614 */     int i3 = paramCalendar.get(14);
/*     */     
/* 616 */     Calendar localCalendar = this.statement.getGMTCalendar();
/*     */     
/*     */ 
/* 619 */     localCalendar.set(1, j);
/* 620 */     localCalendar.set(2, k);
/* 621 */     localCalendar.set(5, m);
/* 622 */     localCalendar.set(11, n);
/* 623 */     localCalendar.set(12, i1);
/* 624 */     localCalendar.set(13, i2);
/* 625 */     localCalendar.set(14, i3);
/*     */     
/* 627 */     long l = localCalendar.getTimeInMillis();
/*     */     
/* 629 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   byte getZoneOffset(Calendar paramCalendar, OffsetDST paramOffsetDST)
/*     */     throws SQLException
/*     */   {
/* 637 */     byte b = 0;
/*     */     
/*     */ 
/* 640 */     String str = paramCalendar.getTimeZone().getID();
/*     */     
/*     */ 
/* 643 */     if ((str == "Custom") || ((str.startsWith("GMT")) && (str.length() > 3)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 648 */       paramOffsetDST.setOFFSET(paramCalendar.getTimeZone().getRawOffset());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 654 */       int i = ZONEIDMAP.getID(str);
/*     */       
/* 656 */       if (!ZONEIDMAP.isValidID(i))
/*     */       {
/* 658 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 659 */         ((SQLException)localObject).fillInStackTrace();
/* 660 */         throw ((Throwable)localObject);
/*     */       }
/*     */       
/* 663 */       Object localObject = this.statement.connection.getTIMEZONETAB();
/* 664 */       if (((TIMEZONETAB)localObject).checkID(i)) {
/* 665 */         ((TIMEZONETAB)localObject).updateTable(this.statement.connection, i);
/*     */       }
/*     */       
/*     */ 
/* 669 */       b = ((TIMEZONETAB)localObject).getLocalOffset(paramCalendar, i, paramOffsetDST);
/*     */     }
/*     */     
/* 672 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 677 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\TimestampltzAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */