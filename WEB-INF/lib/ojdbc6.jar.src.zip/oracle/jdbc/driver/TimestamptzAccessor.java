/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestamptzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   static final int maxLength = 13;
/*  31 */   TimestampTzConverter tstzConverter = null;
/*     */   
/*     */ 
/*     */   TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean)
/*     */     throws SQLException
/*     */   {
/*  37 */     init(paramOracleStatement, 181, 181, paramShort, paramBoolean);
/*  38 */     initForDataAccess(paramInt2, paramInt1, null);
/*     */     
/*  40 */     if (this.statement.connection.timestamptzInGmt) {
/*  41 */       this.tstzConverter = new GmtTimestampTzConverter();
/*     */     } else {
/*  43 */       this.tstzConverter = new OldTimestampTzConverter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort)
/*     */     throws SQLException
/*     */   {
/*  52 */     init(paramOracleStatement, 181, 181, paramShort, false);
/*  53 */     initForDescribe(181, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  55 */     initForDataAccess(0, paramInt1, null);
/*     */     
/*  57 */     if (this.statement.connection.timestamptzInGmt) {
/*  58 */       this.tstzConverter = new GmtTimestampTzConverter();
/*     */     } else {
/*  60 */       this.tstzConverter = new OldTimestampTzConverter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString)
/*     */     throws SQLException
/*     */   {
/*  68 */     if (paramInt1 != 0) {
/*  69 */       this.externalType = paramInt1;
/*     */     }
/*  71 */     this.internalTypeMaxLength = 13;
/*     */     
/*  73 */     if ((paramInt2 > 0) && (paramInt2 < this.internalTypeMaxLength)) {
/*  74 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  76 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   String getString(int paramInt)
/*     */     throws SQLException
/*     */   {
/*  84 */     if (this.rowSpaceIndicator == null)
/*     */     {
/*     */ 
/*     */ 
/*  88 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  89 */       localSQLException.fillInStackTrace();
/*  90 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  96 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] == -1) {
/*  97 */       return null;
/*     */     }
/*  99 */     int i = this.columnIndex + this.byteLength * paramInt;
/*     */     
/*     */ 
/* 102 */     int j = 0;
/*     */     String str;
/* 104 */     if ((oracleTZ1(i) & REGIONIDBIT) != 0)
/*     */     {
/* 106 */       j = getHighOrderbits(oracleTZ1(i));
/* 107 */       j += getLowOrderbits(oracleTZ2(i));
/*     */       
/*     */ 
/* 110 */       TIMEZONETAB localTIMEZONETAB1 = this.statement.connection.getTIMEZONETAB();
/* 111 */       if (localTIMEZONETAB1.checkID(j)) {
/* 112 */         localTIMEZONETAB1.updateTable(this.statement.connection, j);
/*     */       }
/* 114 */       str = ZONEIDMAP.getRegion(j);
/*     */     }
/*     */     else
/*     */     {
/* 118 */       int k = oracleTZ1(i) - OFFSET_HOUR;
/* 119 */       m = oracleTZ2(i) - OFFSET_MINUTE;
/*     */       
/* 121 */       str = "GMT" + (k < 0 ? "-" : "+") + Math.abs(k) + ":" + (m < 10 ? "0" : "") + m;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     Calendar localCalendar = this.statement.getGMTCalendar();
/*     */     
/* 131 */     int m = ((this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */     
/*     */ 
/* 134 */     localCalendar.set(1, m);
/* 135 */     localCalendar.set(2, oracleMonth(i));
/* 136 */     localCalendar.set(5, oracleDay(i));
/* 137 */     localCalendar.set(11, oracleHour(i));
/* 138 */     localCalendar.set(12, oracleMin(i));
/* 139 */     localCalendar.set(13, oracleSec(i));
/* 140 */     localCalendar.set(14, 0);
/*     */     
/* 142 */     if ((oracleTZ1(i) & REGIONIDBIT) != 0)
/*     */     {
/* 144 */       TIMEZONETAB localTIMEZONETAB2 = this.statement.connection.getTIMEZONETAB();
/*     */       
/*     */ 
/* 147 */       i1 = localTIMEZONETAB2.getOffset(localCalendar, j);
/*     */       
/*     */ 
/* 150 */       localCalendar.add(14, i1);
/*     */     }
/*     */     else
/*     */     {
/* 154 */       localCalendar.add(10, oracleTZ1(i) - OFFSET_HOUR);
/* 155 */       localCalendar.add(12, oracleTZ2(i) - OFFSET_MINUTE);
/*     */     }
/*     */     
/*     */ 
/* 159 */     m = localCalendar.get(1);
/*     */     
/* 161 */     int n = localCalendar.get(2) + 1;
/* 162 */     int i1 = localCalendar.get(5);
/* 163 */     int i2 = localCalendar.get(11);
/* 164 */     int i3 = localCalendar.get(12);
/* 165 */     int i4 = localCalendar.get(13);
/* 166 */     boolean bool = i2 < 12;
/* 167 */     if ((str.length() > 3) && (str.startsWith("GMT"))) {
/* 168 */       str = str.substring(3);
/*     */     }
/* 170 */     int i5 = oracleNanos(i);
/*     */     
/* 172 */     return toText(m, n, i1, i2, i3, i4, i5, bool, str);
/*     */   }
/*     */   
/*     */ 
/*     */   java.sql.Date getDate(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 179 */     return this.tstzConverter.getDate(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   java.sql.Date getDate(int paramInt, Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 187 */     return getDate(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */   Time getTime(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 194 */     return this.tstzConverter.getTime(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Time getTime(int paramInt, Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 202 */     return getTime(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */   Timestamp getTimestamp(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 209 */     return this.tstzConverter.getTimestamp(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*     */     throws SQLException
/*     */   {
/* 217 */     return getTimestamp(paramInt);
/*     */   }
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException
/*     */   {
/* 222 */     return this.tstzConverter.getObject(paramInt);
/*     */   }
/*     */   
/*     */   Datum getOracleObject(int paramInt)
/*     */     throws SQLException
/*     */   {
/* 228 */     return this.tstzConverter.getOracleObject(paramInt);
/*     */   }
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException
/*     */   {
/* 233 */     TIMESTAMPTZ localTIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
/* 234 */     return TIMESTAMPTZ.toDATE(this.statement.connection, localTIMESTAMPTZ.getBytes());
/*     */   }
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException
/*     */   {
/* 239 */     TIMESTAMPTZ localTIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
/* 240 */     return TIMESTAMPTZ.toTIMESTAMP(this.statement.connection, localTIMESTAMPTZ.getBytes());
/*     */   }
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException
/*     */   {
/* 245 */     return this.tstzConverter.getTIMESTAMPTZ(paramInt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 251 */   static int OFFSET_HOUR = 20;
/* 252 */   static int OFFSET_MINUTE = 60;
/*     */   
/*     */ 
/* 255 */   static byte REGIONIDBIT = Byte.MIN_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int setHighOrderbits(int paramInt)
/*     */   {
/* 265 */     return (paramInt & 0x1FC0) >> 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static int setLowOrderbits(int paramInt)
/*     */   {
/* 273 */     return (paramInt & 0x3F) << 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getHighOrderbits(int paramInt)
/*     */   {
/* 281 */     return (paramInt & 0x7F) << 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static int getLowOrderbits(int paramInt)
/*     */   {
/* 288 */     return (paramInt & 0xFC) >> 2;
/*     */   }
/*     */   
/*     */ 
/*     */   class OldTimestampTzConverter
/*     */     extends TimestamptzAccessor.TimestampTzConverter
/*     */   {
/*     */     OldTimestampTzConverter()
/*     */     {
/* 297 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */     java.sql.Date getDate(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 304 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 308 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 309 */         localSQLException.fillInStackTrace();
/* 310 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 316 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] == -1) {
/* 317 */         return null;
/*     */       }
/* 319 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/*     */       
/* 321 */       TimeZone localTimeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 322 */       Calendar localCalendar = Calendar.getInstance(localTimeZone);
/*     */       
/* 324 */       int j = ((TimestamptzAccessor.this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */       
/*     */ 
/* 327 */       localCalendar.set(1, j);
/* 328 */       localCalendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 329 */       localCalendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 330 */       localCalendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 331 */       localCalendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 332 */       localCalendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 333 */       localCalendar.set(14, 0);
/*     */       
/* 335 */       if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0)
/*     */       {
/*     */ 
/*     */ 
/* 339 */         int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
/* 340 */         k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
/*     */         
/* 342 */         TIMEZONETAB localTIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/*     */         
/* 344 */         if (localTIMEZONETAB.checkID(k)) {
/* 345 */           localTIMEZONETAB.updateTable(TimestamptzAccessor.this.statement.connection, k);
/*     */         }
/* 347 */         int m = localTIMEZONETAB.getOffset(localCalendar, k);
/*     */         
/* 349 */         boolean bool1 = localTimeZone.inDaylightTime(localCalendar.getTime());
/* 350 */         boolean bool2 = localTimeZone.inDaylightTime(new java.util.Date(localCalendar.getTimeInMillis() + m));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 357 */         if ((!bool1) && (bool2))
/*     */         {
/* 359 */           localCalendar.add(14, -1 * localTimeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 367 */         else if ((bool1) && (!bool2))
/*     */         {
/* 369 */           localCalendar.add(14, localTimeZone.getDSTSavings());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 374 */         localCalendar.add(10, m / 3600000);
/* 375 */         localCalendar.add(12, m % 3600000 / 60000);
/*     */       }
/*     */       else
/*     */       {
/* 379 */         localCalendar.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
/* 380 */         localCalendar.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       }
/*     */       
/*     */ 
/* 384 */       long l = localCalendar.getTimeInMillis();
/*     */       
/*     */ 
/* 387 */       return new java.sql.Date(l);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Time getTime(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 395 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 399 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 400 */         localSQLException.fillInStackTrace();
/* 401 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 407 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] == -1) {
/* 408 */         return null;
/*     */       }
/* 410 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/*     */       
/* 412 */       TimeZone localTimeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 413 */       Calendar localCalendar = Calendar.getInstance(localTimeZone);
/*     */       
/* 415 */       int j = ((TimestamptzAccessor.this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */       
/*     */ 
/* 418 */       localCalendar.set(1, j);
/* 419 */       localCalendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 420 */       localCalendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 421 */       localCalendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 422 */       localCalendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 423 */       localCalendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 424 */       localCalendar.set(14, 0);
/*     */       
/* 426 */       if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0)
/*     */       {
/*     */ 
/*     */ 
/* 430 */         int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
/* 431 */         k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
/*     */         
/* 433 */         TIMEZONETAB localTIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/*     */         
/* 435 */         if (localTIMEZONETAB.checkID(k)) {
/* 436 */           localTIMEZONETAB.updateTable(TimestamptzAccessor.this.statement.connection, k);
/*     */         }
/* 438 */         int m = localTIMEZONETAB.getOffset(localCalendar, k);
/*     */         
/* 440 */         boolean bool1 = localTimeZone.inDaylightTime(localCalendar.getTime());
/* 441 */         boolean bool2 = localTimeZone.inDaylightTime(new java.util.Date(localCalendar.getTimeInMillis() + m));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 448 */         if ((!bool1) && (bool2))
/*     */         {
/* 450 */           localCalendar.add(14, -1 * localTimeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 458 */         else if ((bool1) && (!bool2))
/*     */         {
/* 460 */           localCalendar.add(14, localTimeZone.getDSTSavings());
/*     */         }
/*     */         
/*     */ 
/* 464 */         localCalendar.add(10, m / 3600000);
/* 465 */         localCalendar.add(12, m % 3600000 / 60000);
/*     */       }
/*     */       else
/*     */       {
/* 469 */         localCalendar.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
/* 470 */         localCalendar.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       }
/*     */       
/*     */ 
/* 474 */       long l = localCalendar.getTimeInMillis();
/*     */       
/*     */ 
/* 477 */       return new Time(l);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Timestamp getTimestamp(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 485 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 489 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 490 */         localSQLException.fillInStackTrace();
/* 491 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 497 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] == -1) {
/* 498 */         return null;
/*     */       }
/* 500 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/*     */       
/* 502 */       TimeZone localTimeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 503 */       Calendar localCalendar1 = Calendar.getInstance(localTimeZone);
/* 504 */       Calendar localCalendar2 = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 506 */       int j = ((TimestamptzAccessor.this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */       
/*     */ 
/* 509 */       localCalendar1.set(1, j);
/* 510 */       localCalendar1.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 511 */       localCalendar1.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 512 */       localCalendar1.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 513 */       localCalendar1.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 514 */       localCalendar1.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 515 */       localCalendar1.set(14, 0);
/*     */       
/* 517 */       localCalendar2.set(1, j);
/* 518 */       localCalendar2.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 519 */       localCalendar2.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 520 */       localCalendar2.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 521 */       localCalendar2.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 522 */       localCalendar2.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 523 */       localCalendar2.set(14, 0);
/*     */       
/* 525 */       if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0)
/*     */       {
/*     */ 
/*     */ 
/* 529 */         int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
/* 530 */         k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
/*     */         
/*     */ 
/* 533 */         TIMEZONETAB localTIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/* 534 */         if (localTIMEZONETAB.checkID(k)) {
/* 535 */           localTIMEZONETAB.updateTable(TimestamptzAccessor.this.statement.connection, k);
/*     */         }
/* 537 */         int m = localTIMEZONETAB.getOffset(localCalendar2, k);
/*     */         
/* 539 */         boolean bool1 = localTimeZone.inDaylightTime(localCalendar1.getTime());
/* 540 */         boolean bool2 = localTimeZone.inDaylightTime(new java.util.Date(localCalendar1.getTimeInMillis() + m));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 547 */         if ((!bool1) && (bool2))
/*     */         {
/*     */ 
/* 550 */           localCalendar1.add(14, -1 * localTimeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 558 */         else if ((bool1) && (!bool2))
/*     */         {
/* 560 */           localCalendar1.add(14, localTimeZone.getDSTSavings());
/*     */         }
/*     */         
/*     */ 
/* 564 */         localCalendar1.add(10, m / 3600000);
/* 565 */         localCalendar1.add(12, m % 3600000 / 60000);
/*     */       }
/*     */       else
/*     */       {
/* 569 */         localCalendar1.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
/* 570 */         localCalendar1.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       }
/*     */       
/*     */ 
/* 574 */       long l = localCalendar1.getTimeInMillis();
/*     */       
/*     */ 
/* 577 */       Timestamp localTimestamp = new Timestamp(l);
/*     */       
/*     */ 
/* 580 */       int n = TimestamptzAccessor.this.oracleNanos(i);
/*     */       
/*     */ 
/* 583 */       localTimestamp.setNanos(n);
/*     */       
/* 585 */       return localTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 593 */       TIMESTAMPTZ localTIMESTAMPTZ = null;
/*     */       
/* 595 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 599 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 600 */         localSQLException.fillInStackTrace();
/* 601 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 607 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] != -1)
/*     */       {
/* 609 */         int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/* 610 */         byte[] arrayOfByte = new byte[13];
/*     */         
/* 612 */         System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, i, arrayOfByte, 0, 13);
/*     */         
/* 614 */         localTIMESTAMPTZ = new TIMESTAMPTZ(arrayOfByte);
/*     */       }
/*     */       
/* 617 */       return localTIMESTAMPTZ;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class GmtTimestampTzConverter
/*     */     extends TimestamptzAccessor.TimestampTzConverter
/*     */   {
/*     */     GmtTimestampTzConverter()
/*     */     {
/* 627 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     java.sql.Date getDate(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 635 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 639 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 640 */         localSQLException.fillInStackTrace();
/* 641 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 647 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] == -1) {
/* 648 */         return null;
/*     */       }
/* 650 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/*     */       
/* 652 */       Calendar localCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 654 */       int j = ((TimestamptzAccessor.this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */       
/*     */ 
/* 657 */       localCalendar.set(1, j);
/* 658 */       localCalendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 659 */       localCalendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 660 */       localCalendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 661 */       localCalendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 662 */       localCalendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 663 */       localCalendar.set(14, 0);
/*     */       
/*     */ 
/* 666 */       long l = localCalendar.getTimeInMillis();
/*     */       
/*     */ 
/* 669 */       return new java.sql.Date(l);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Time getTime(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 677 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 681 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 682 */         localSQLException.fillInStackTrace();
/* 683 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 689 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] == -1) {
/* 690 */         return null;
/*     */       }
/* 692 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/*     */       
/* 694 */       Calendar localCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 696 */       int j = ((TimestamptzAccessor.this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */       
/*     */ 
/* 699 */       localCalendar.set(1, j);
/* 700 */       localCalendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 701 */       localCalendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 702 */       localCalendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 703 */       localCalendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 704 */       localCalendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 705 */       localCalendar.set(14, 0);
/*     */       
/* 707 */       return new Time(localCalendar.getTimeInMillis());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Timestamp getTimestamp(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 715 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 719 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 720 */         localSQLException.fillInStackTrace();
/* 721 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 727 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] == -1) {
/* 728 */         return null;
/*     */       }
/* 730 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/*     */       
/* 732 */       Calendar localCalendar = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 734 */       int j = ((TimestamptzAccessor.this.rowSpaceByte[(0 + i)] & 0xFF) - 100) * 100 + (TimestamptzAccessor.this.rowSpaceByte[(1 + i)] & 0xFF) - 100;
/*     */       
/*     */ 
/* 737 */       localCalendar.set(1, j);
/* 738 */       localCalendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 739 */       localCalendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 740 */       localCalendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 741 */       localCalendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 742 */       localCalendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 743 */       localCalendar.set(14, 0);
/*     */       
/*     */ 
/* 746 */       long l = localCalendar.getTimeInMillis();
/*     */       
/*     */ 
/* 749 */       Timestamp localTimestamp = new Timestamp(l);
/*     */       
/*     */ 
/* 752 */       int k = TimestamptzAccessor.this.oracleNanos(i);
/*     */       
/*     */ 
/* 755 */       localTimestamp.setNanos(k);
/*     */       
/* 757 */       return localTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 765 */       TIMESTAMPTZ localTIMESTAMPTZ = null;
/*     */       
/* 767 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null)
/*     */       {
/*     */ 
/*     */ 
/* 771 */         SQLException localSQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 772 */         localSQLException.fillInStackTrace();
/* 773 */         throw localSQLException;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 779 */       if (TimestamptzAccessor.this.rowSpaceIndicator[(TimestamptzAccessor.this.indicatorIndex + paramInt)] != -1)
/*     */       {
/* 781 */         int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * paramInt;
/* 782 */         byte[] arrayOfByte = new byte[13];
/*     */         
/* 784 */         System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, i, arrayOfByte, 0, 13);
/*     */         
/* 786 */         localTIMESTAMPTZ = new TIMESTAMPTZ(arrayOfByte);
/*     */       }
/*     */       
/* 789 */       return localTIMESTAMPTZ;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   abstract class TimestampTzConverter
/*     */   {
/*     */     TimestampTzConverter() {}
/*     */     
/*     */ 
/*     */     abstract java.sql.Date getDate(int paramInt)
/*     */       throws SQLException;
/*     */     
/*     */ 
/*     */     abstract Time getTime(int paramInt)
/*     */       throws SQLException;
/*     */     
/*     */     abstract Timestamp getTimestamp(int paramInt)
/*     */       throws SQLException;
/*     */     
/*     */     Object getObject(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 812 */       return getTIMESTAMPTZ(paramInt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Datum getOracleObject(int paramInt)
/*     */       throws SQLException
/*     */     {
/* 820 */       return getTIMESTAMPTZ(paramInt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Object getObject(int paramInt, Map paramMap)
/*     */       throws SQLException
/*     */     {
/* 828 */       return getTIMESTAMPTZ(paramInt);
/*     */     }
/*     */     
/*     */ 
/*     */     abstract TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*     */       throws SQLException;
/*     */   }
/*     */   
/*     */ 
/* 837 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\TimestamptzAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */