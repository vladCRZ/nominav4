/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleResultSet.AuthorizationIndicator;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class UpdatableResultSet
/*      */   extends BaseResultSet
/*      */ {
/*      */   static final int concurrencyType = 1008;
/*      */   static final int BEGIN_COLUMN_INDEX = 1;
/*      */   static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*      */   static final int MAX_BYTE_BUFFER_SIZE = 1024;
/*      */   PhysicalConnection connection;
/*      */   OracleResultSet resultSet;
/*      */   boolean isCachedRset;
/*      */   ScrollRsetStatement scrollStmt;
/*      */   ResultSetMetaData rsetMetaData;
/*      */   private int rsetType;
/*      */   private int columnCount;
/*      */   private OraclePreparedStatement deleteStmt;
/*      */   private OraclePreparedStatement insertStmt;
/*      */   private OraclePreparedStatement updateStmt;
/*      */   private int[] indexColsChanged;
/*      */   private Object[] rowBuffer;
/*      */   private boolean[] m_nullIndicator;
/*      */   private int[][] typeInfo;
/*      */   private boolean isInserting;
/*      */   private boolean isUpdating;
/*      */   private int wasNull;
/*      */   private static final int VALUE_NULL = 1;
/*      */   private static final int VALUE_NOT_NULL = 2;
/*      */   private static final int VALUE_UNKNOWN = 3;
/*      */   private static final int VALUE_IN_RSET = 4;
/*      */   private static final int ASCII_STREAM = 1;
/*      */   private static final int BINARY_STREAM = 2;
/*      */   private static final int UNICODE_STREAM = 3;
/*  100 */   private static int _MIN_STREAM_SIZE = 4000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   UpdatableResultSet(ScrollRsetStatement paramScrollRsetStatement, ScrollableResultSet paramScrollableResultSet, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  113 */     init(paramScrollRsetStatement, paramScrollableResultSet, paramInt1, paramInt2);
/*      */     
/*      */ 
/*  116 */     paramScrollableResultSet.resetBeginColumnIndex();
/*  117 */     getInternalMetadata();
/*      */     
/*  119 */     this.isCachedRset = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   UpdatableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  130 */     init(paramScrollRsetStatement, paramOracleResultSetImpl, paramInt1, paramInt2);
/*  131 */     getInternalMetadata();
/*      */     
/*  133 */     this.isCachedRset = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init(ScrollRsetStatement paramScrollRsetStatement, OracleResultSet paramOracleResultSet, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  145 */     if ((paramScrollRsetStatement == null) || (paramOracleResultSet == null) || (paramInt2 != 1008))
/*      */     {
/*  147 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  148 */       localSQLException.fillInStackTrace();
/*  149 */       throw localSQLException;
/*      */     }
/*      */     
/*  152 */     this.connection = ((OracleStatement)paramScrollRsetStatement).connection;
/*  153 */     this.resultSet = paramOracleResultSet;
/*  154 */     this.scrollStmt = paramScrollRsetStatement;
/*  155 */     this.rsetType = paramInt1;
/*  156 */     this.deleteStmt = null;
/*  157 */     this.insertStmt = null;
/*  158 */     this.updateStmt = null;
/*  159 */     this.indexColsChanged = null;
/*  160 */     this.rowBuffer = null;
/*  161 */     this.m_nullIndicator = null;
/*  162 */     this.typeInfo = ((int[][])null);
/*  163 */     this.isInserting = false;
/*  164 */     this.isUpdating = false;
/*  165 */     this.wasNull = -1;
/*  166 */     this.rsetMetaData = null;
/*  167 */     this.columnCount = 0;
/*      */   }
/*      */   
/*      */   void ensureOpen() throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*  173 */     if (this.closed)
/*      */     {
/*  175 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  176 */       localSQLException.fillInStackTrace();
/*  177 */       throw localSQLException;
/*      */     }
/*      */     
/*  180 */     if ((this.resultSet == null) || (this.scrollStmt == null) || (((OracleStatement)this.scrollStmt).closed))
/*      */     {
/*      */ 
/*  183 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  184 */       localSQLException.fillInStackTrace();
/*  185 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  199 */     if (this.closed) return;
/*  200 */     synchronized (this.connection)
/*      */     {
/*      */ 
/*  203 */       super.close();
/*      */       
/*  205 */       if (this.resultSet != null)
/*  206 */         this.resultSet.close();
/*  207 */       if (this.insertStmt != null)
/*  208 */         this.insertStmt.close();
/*  209 */       if (this.updateStmt != null)
/*  210 */         this.updateStmt.close();
/*  211 */       if (this.deleteStmt != null)
/*  212 */         this.deleteStmt.close();
/*  213 */       if (this.scrollStmt != null) {
/*  214 */         this.scrollStmt.notifyCloseRset();
/*      */       }
/*  216 */       cancelRowInserts();
/*      */       
/*  218 */       this.connection = LogicalConnection.closedConnection;
/*  219 */       this.resultSet = null;
/*  220 */       this.scrollStmt = null;
/*  221 */       this.rsetMetaData = null;
/*  222 */       this.scrollStmt = null;
/*  223 */       this.deleteStmt = null;
/*  224 */       this.insertStmt = null;
/*  225 */       this.updateStmt = null;
/*  226 */       this.indexColsChanged = null;
/*  227 */       this.rowBuffer = null;
/*  228 */       this.m_nullIndicator = null;
/*  229 */       this.typeInfo = ((int[][])null);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  236 */     synchronized (this.connection)
/*      */     {
/*  238 */       ensureOpen();
/*  239 */       switch (this.wasNull)
/*      */       {
/*      */ 
/*      */       case 1: 
/*  243 */         return true;
/*      */       
/*      */       case 2: 
/*  246 */         return false;
/*      */       
/*      */       case 4: 
/*  249 */         return this.resultSet.wasNull();
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*  255 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/*  256 */       localSQLException.fillInStackTrace();
/*  257 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getFirstUserColumnIndex()
/*      */   {
/*  276 */     return 1;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 15	oracle/jdbc/driver/UpdatableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   11: checkcast 40	java/sql/Statement
/*      */     //   14: aload_1
/*      */     //   15: monitorexit
/*      */     //   16: areturn
/*      */     //   17: astore_2
/*      */     //   18: aload_1
/*      */     //   19: monitorexit
/*      */     //   20: aload_2
/*      */     //   21: athrow
/*      */     // Line number table:
/*      */     //   Java source line #283	-> byte code offset #0
/*      */     //   Java source line #285	-> byte code offset #7
/*      */     //   Java source line #287	-> byte code offset #17
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	22	0	this	UpdatableResultSet
/*      */     //   5	14	1	Ljava/lang/Object;	Object
/*      */     //   17	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	16	17	finally
/*      */     //   17	20	17	finally
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  293 */     SQLWarning localSQLWarning1 = this.resultSet.getWarnings();
/*      */     
/*  295 */     if (this.sqlWarning == null) {
/*  296 */       return localSQLWarning1;
/*      */     }
/*      */     
/*  299 */     SQLWarning localSQLWarning2 = this.sqlWarning;
/*      */     
/*  301 */     while (localSQLWarning2.getNextWarning() != null) {
/*  302 */       localSQLWarning2 = localSQLWarning2.getNextWarning();
/*      */     }
/*  304 */     localSQLWarning2.setNextWarning(localSQLWarning1);
/*      */     
/*      */ 
/*  307 */     return this.sqlWarning;
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  314 */     this.sqlWarning = null;
/*      */     
/*  316 */     this.resultSet.clearWarnings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/*  326 */     synchronized (this.connection)
/*      */     {
/*  328 */       ensureOpen();
/*  329 */       cancelRowChanges();
/*      */       
/*  331 */       return this.resultSet.next();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  338 */     synchronized (this.connection)
/*      */     {
/*  340 */       ensureOpen();
/*  341 */       return this.resultSet.isBeforeFirst();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  348 */     synchronized (this.connection)
/*      */     {
/*  350 */       ensureOpen();
/*  351 */       return this.resultSet.isAfterLast();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  358 */     synchronized (this.connection)
/*      */     {
/*  360 */       ensureOpen();
/*  361 */       return this.resultSet.isFirst();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  368 */     synchronized (this.connection)
/*      */     {
/*  370 */       ensureOpen();
/*  371 */       return this.resultSet.isLast();
/*      */     }
/*      */   }
/*      */   
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  378 */     synchronized (this.connection)
/*      */     {
/*  380 */       ensureOpen();
/*  381 */       cancelRowChanges();
/*  382 */       this.resultSet.beforeFirst();
/*      */     }
/*      */   }
/*      */   
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/*  389 */     synchronized (this.connection)
/*      */     {
/*  391 */       ensureOpen();
/*  392 */       cancelRowChanges();
/*  393 */       this.resultSet.afterLast();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/*  400 */     synchronized (this.connection)
/*      */     {
/*  402 */       ensureOpen();
/*  403 */       cancelRowChanges();
/*      */       
/*  405 */       return this.resultSet.first();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/*  412 */     synchronized (this.connection)
/*      */     {
/*  414 */       ensureOpen();
/*  415 */       cancelRowChanges();
/*      */       
/*  417 */       return this.resultSet.last();
/*      */     }
/*      */   }
/*      */   
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/*  424 */     synchronized (this.connection)
/*      */     {
/*  426 */       ensureOpen();
/*  427 */       return this.resultSet.getRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean absolute(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  434 */     synchronized (this.connection)
/*      */     {
/*  436 */       cancelRowChanges();
/*      */       
/*  438 */       return this.resultSet.absolute(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean relative(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  445 */     synchronized (this.connection)
/*      */     {
/*  447 */       ensureOpen();
/*  448 */       cancelRowChanges();
/*      */       
/*  450 */       return this.resultSet.relative(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/*  457 */     synchronized (this.connection)
/*      */     {
/*  459 */       ensureOpen();
/*  460 */       cancelRowChanges();
/*      */       
/*  462 */       return this.resultSet.previous();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum getOracleObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  473 */     synchronized (this.connection)
/*      */     {
/*  475 */       ensureOpen();
/*  476 */       Datum localDatum = null;
/*      */       
/*  478 */       setIsNull(3);
/*      */       
/*  480 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  483 */         setIsNull(localDatum == null);
/*      */         
/*  485 */         localDatum = getRowBufferDatumAt(paramInt);
/*      */       }
/*      */       else
/*      */       {
/*  489 */         setIsNull(4);
/*      */         
/*  491 */         localDatum = this.resultSet.getOracleObject(paramInt + 1);
/*      */       }
/*      */       
/*  494 */       return localDatum;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getString(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  501 */     synchronized (this.connection)
/*      */     {
/*  503 */       ensureOpen();
/*  504 */       String str = null;
/*      */       
/*  506 */       setIsNull(3);
/*      */       
/*  508 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  511 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  513 */         setIsNull(localDatum == null);
/*      */         
/*  515 */         if (localDatum != null) {
/*  516 */           str = localDatum.stringValue(this.connection);
/*      */         }
/*      */       }
/*      */       else {
/*  520 */         setIsNull(4);
/*      */         
/*  522 */         str = this.resultSet.getString(paramInt + 1);
/*      */       }
/*      */       
/*  525 */       return str;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getBoolean(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  532 */     synchronized (this.connection)
/*      */     {
/*  534 */       ensureOpen();
/*  535 */       boolean bool = false;
/*      */       
/*  537 */       setIsNull(3);
/*      */       
/*  539 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  542 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  544 */         setIsNull(localDatum == null);
/*      */         
/*  546 */         if (localDatum != null) {
/*  547 */           bool = localDatum.booleanValue();
/*      */         }
/*      */       }
/*      */       else {
/*  551 */         setIsNull(4);
/*      */         
/*  553 */         bool = this.resultSet.getBoolean(paramInt + 1);
/*      */       }
/*      */       
/*  556 */       return bool;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  564 */     return this.resultSet.getAuthorizationIndicator(paramInt + 1);
/*      */   }
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException
/*      */   {
/*  569 */     synchronized (this.connection)
/*      */     {
/*  571 */       ensureOpen();
/*  572 */       byte b = 0;
/*      */       
/*  574 */       setIsNull(3);
/*      */       
/*  576 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  579 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  581 */         setIsNull(localDatum == null);
/*      */         
/*  583 */         if (localDatum != null) {
/*  584 */           b = localDatum.byteValue();
/*      */         }
/*      */       }
/*      */       else {
/*  588 */         setIsNull(4);
/*      */         
/*  590 */         b = this.resultSet.getByte(paramInt + 1);
/*      */       }
/*      */       
/*  593 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */   public short getShort(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  600 */     synchronized (this.connection)
/*      */     {
/*  602 */       ensureOpen();
/*  603 */       short s = 0;
/*      */       
/*  605 */       setIsNull(3);
/*      */       
/*  607 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  610 */         long l = getLong(paramInt);
/*      */         
/*  612 */         if ((l > 65537L) || (l < -65538L))
/*      */         {
/*  614 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  615 */           localSQLException.fillInStackTrace();
/*  616 */           throw localSQLException;
/*      */         }
/*      */         
/*  619 */         s = (short)(int)l;
/*      */       }
/*      */       else
/*      */       {
/*  623 */         setIsNull(4);
/*      */         
/*  625 */         s = this.resultSet.getShort(paramInt + 1);
/*      */       }
/*      */       
/*  628 */       return s;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getInt(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  635 */     synchronized (this.connection)
/*      */     {
/*  637 */       ensureOpen();
/*  638 */       int i = 0;
/*      */       
/*  640 */       setIsNull(3);
/*      */       
/*  642 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  645 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  647 */         setIsNull(localDatum == null);
/*      */         
/*  649 */         if (localDatum != null) {
/*  650 */           i = localDatum.intValue();
/*      */         }
/*      */       }
/*      */       else {
/*  654 */         setIsNull(4);
/*      */         
/*  656 */         i = this.resultSet.getInt(paramInt + 1);
/*      */       }
/*      */       
/*  659 */       return i;
/*      */     }
/*      */   }
/*      */   
/*      */   public long getLong(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  666 */     synchronized (this.connection)
/*      */     {
/*  668 */       ensureOpen();
/*  669 */       long l = 0L;
/*      */       
/*  671 */       setIsNull(3);
/*      */       
/*  673 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  676 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  678 */         setIsNull(localDatum == null);
/*      */         
/*  680 */         if (localDatum != null) {
/*  681 */           l = localDatum.longValue();
/*      */         }
/*      */       }
/*      */       else {
/*  685 */         setIsNull(4);
/*      */         
/*  687 */         l = this.resultSet.getLong(paramInt + 1);
/*      */       }
/*      */       
/*  690 */       return l;
/*      */     }
/*      */   }
/*      */   
/*      */   public float getFloat(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  697 */     synchronized (this.connection)
/*      */     {
/*  699 */       ensureOpen();
/*  700 */       float f = 0.0F;
/*      */       
/*  702 */       setIsNull(3);
/*      */       
/*  704 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  707 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  709 */         setIsNull(localDatum == null);
/*      */         
/*  711 */         if (localDatum != null) {
/*  712 */           f = localDatum.floatValue();
/*      */         }
/*      */       }
/*      */       else {
/*  716 */         setIsNull(4);
/*      */         
/*  718 */         f = this.resultSet.getFloat(paramInt + 1);
/*      */       }
/*      */       
/*  721 */       return f;
/*      */     }
/*      */   }
/*      */   
/*      */   public double getDouble(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  728 */     synchronized (this.connection)
/*      */     {
/*  730 */       ensureOpen();
/*  731 */       double d = 0.0D;
/*      */       
/*  733 */       setIsNull(3);
/*      */       
/*  735 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  738 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  740 */         setIsNull(localDatum == null);
/*      */         
/*  742 */         if (localDatum != null) {
/*  743 */           d = localDatum.doubleValue();
/*      */         }
/*      */       }
/*      */       else {
/*  747 */         setIsNull(4);
/*      */         
/*  749 */         d = this.resultSet.getDouble(paramInt + 1);
/*      */       }
/*      */       
/*  752 */       return d;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  760 */     synchronized (this.connection)
/*      */     {
/*  762 */       ensureOpen();
/*  763 */       BigDecimal localBigDecimal = null;
/*      */       
/*  765 */       setIsNull(3);
/*      */       
/*  767 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt1))))
/*      */       {
/*      */ 
/*  770 */         Datum localDatum = getRowBufferDatumAt(paramInt1);
/*      */         
/*  772 */         setIsNull(localDatum == null);
/*      */         
/*  774 */         if (localDatum != null) {
/*  775 */           localBigDecimal = localDatum.bigDecimalValue();
/*      */         }
/*      */       }
/*      */       else {
/*  779 */         setIsNull(4);
/*      */         
/*  781 */         localBigDecimal = this.resultSet.getBigDecimal(paramInt1 + 1);
/*      */       }
/*      */       
/*  784 */       return localBigDecimal;
/*      */     }
/*      */   }
/*      */   
/*      */   public byte[] getBytes(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  791 */     synchronized (this.connection)
/*      */     {
/*  793 */       ensureOpen();
/*  794 */       byte[] arrayOfByte = null;
/*      */       
/*  796 */       setIsNull(3);
/*      */       
/*  798 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  801 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  803 */         setIsNull(localDatum == null);
/*      */         
/*  805 */         if (localDatum != null) {
/*  806 */           arrayOfByte = localDatum.getBytes();
/*      */         }
/*      */       }
/*      */       else {
/*  810 */         setIsNull(4);
/*      */         
/*  812 */         arrayOfByte = this.resultSet.getBytes(paramInt + 1);
/*      */       }
/*      */       
/*  815 */       return arrayOfByte;
/*      */     }
/*      */   }
/*      */   
/*      */   public Date getDate(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  822 */     synchronized (this.connection)
/*      */     {
/*  824 */       ensureOpen();
/*  825 */       Date localDate = null;
/*      */       
/*  827 */       setIsNull(3);
/*      */       
/*  829 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  832 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  834 */         setIsNull(localDatum == null);
/*      */         
/*  836 */         if (localDatum != null) {
/*  837 */           localDate = localDatum.dateValue();
/*      */         }
/*      */       }
/*      */       else {
/*  841 */         setIsNull(4);
/*      */         
/*  843 */         localDate = this.resultSet.getDate(paramInt + 1);
/*      */       }
/*      */       
/*  846 */       return localDate;
/*      */     }
/*      */   }
/*      */   
/*      */   public Time getTime(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  853 */     synchronized (this.connection)
/*      */     {
/*  855 */       ensureOpen();
/*  856 */       Time localTime = null;
/*      */       
/*  858 */       setIsNull(3);
/*      */       
/*  860 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  863 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  865 */         setIsNull(localDatum == null);
/*      */         
/*  867 */         if (localDatum != null) {
/*  868 */           localTime = localDatum.timeValue();
/*      */         }
/*      */       }
/*      */       else {
/*  872 */         setIsNull(4);
/*      */         
/*  874 */         localTime = this.resultSet.getTime(paramInt + 1);
/*      */       }
/*      */       
/*  877 */       return localTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  885 */     synchronized (this.connection)
/*      */     {
/*  887 */       ensureOpen();
/*  888 */       Timestamp localTimestamp = null;
/*      */       
/*  890 */       setIsNull(3);
/*      */       
/*  892 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  895 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/*  897 */         setIsNull(localDatum == null);
/*      */         
/*  899 */         if (localDatum != null) {
/*  900 */           localTimestamp = localDatum.timestampValue();
/*      */         }
/*      */       }
/*      */       else {
/*  904 */         setIsNull(4);
/*      */         
/*  906 */         localTimestamp = this.resultSet.getTimestamp(paramInt + 1);
/*      */       }
/*      */       
/*  909 */       return localTimestamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getAsciiStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  917 */     synchronized (this.connection)
/*      */     {
/*  919 */       ensureOpen();
/*  920 */       InputStream localInputStream = null;
/*      */       
/*  922 */       setIsNull(3);
/*      */       
/*  924 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  927 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/*  929 */         setIsNull(localObject1 == null);
/*      */         
/*  931 */         if (localObject1 != null)
/*      */         {
/*  933 */           if ((localObject1 instanceof InputStream))
/*      */           {
/*  935 */             localInputStream = (InputStream)localObject1;
/*      */           }
/*      */           else
/*      */           {
/*  939 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */             
/*  941 */             localInputStream = localDatum.asciiStreamValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  947 */         setIsNull(4);
/*      */         
/*  949 */         localInputStream = this.resultSet.getAsciiStream(paramInt + 1);
/*      */       }
/*      */       
/*  952 */       return localInputStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getUnicodeStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  960 */     synchronized (this.connection)
/*      */     {
/*  962 */       ensureOpen();
/*  963 */       InputStream localInputStream = null;
/*      */       
/*  965 */       setIsNull(3);
/*      */       
/*  967 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/*  970 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/*  972 */         setIsNull(localObject1 == null);
/*      */         
/*  974 */         if (localObject1 != null)
/*      */         {
/*  976 */           if ((localObject1 instanceof InputStream))
/*      */           {
/*  978 */             localInputStream = (InputStream)localObject1;
/*      */           }
/*      */           else
/*      */           {
/*  982 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*  983 */             DBConversion localDBConversion = this.connection.conversion;
/*  984 */             byte[] arrayOfByte = localDatum.shareBytes();
/*      */             
/*  986 */             if ((localDatum instanceof RAW))
/*      */             {
/*  988 */               localInputStream = localDBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */ 
/*      */             }
/*  991 */             else if ((localDatum instanceof CHAR))
/*      */             {
/*  993 */               localInputStream = localDBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  998 */               SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/*  999 */               localSQLException.fillInStackTrace();
/* 1000 */               throw localSQLException;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1007 */         setIsNull(4);
/*      */         
/* 1009 */         localInputStream = this.resultSet.getUnicodeStream(paramInt + 1);
/*      */       }
/*      */       
/* 1012 */       return localInputStream;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InputStream getBinaryStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1020 */     synchronized (this.connection)
/*      */     {
/* 1022 */       ensureOpen();
/* 1023 */       InputStream localInputStream = null;
/*      */       
/* 1025 */       setIsNull(3);
/*      */       
/* 1027 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1030 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/* 1032 */         setIsNull(localObject1 == null);
/*      */         
/* 1034 */         if (localObject1 != null)
/*      */         {
/* 1036 */           if ((localObject1 instanceof InputStream))
/*      */           {
/* 1038 */             localInputStream = (InputStream)localObject1;
/*      */           }
/*      */           else
/*      */           {
/* 1042 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */             
/* 1044 */             localInputStream = localDatum.binaryStreamValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1050 */         setIsNull(4);
/*      */         
/* 1052 */         localInputStream = this.resultSet.getBinaryStream(paramInt + 1);
/*      */       }
/*      */       
/* 1055 */       return localInputStream;
/*      */     }
/*      */   }
/*      */   
/*      */   public Object getObject(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1062 */     synchronized (this.connection)
/*      */     {
/* 1064 */       ensureOpen();
/* 1065 */       Object localObject1 = null;
/*      */       
/* 1067 */       setIsNull(3);
/*      */       
/* 1069 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1072 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1074 */         setIsNull(localDatum == null);
/*      */         
/* 1076 */         if (localDatum != null) {
/* 1077 */           localObject1 = localDatum.toJdbc();
/*      */         }
/*      */       }
/*      */       else {
/* 1081 */         setIsNull(4);
/*      */         
/* 1083 */         localObject1 = this.resultSet.getObject(paramInt + 1);
/*      */       }
/*      */       
/* 1086 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1095 */     synchronized (this.connection)
/*      */     {
/* 1097 */       ensureOpen();
/* 1098 */       Reader localReader = null;
/*      */       
/* 1100 */       setIsNull(3);
/*      */       
/* 1102 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1105 */         Object localObject1 = getRowBufferAt(paramInt);
/*      */         
/* 1107 */         setIsNull(localObject1 == null);
/*      */         
/* 1109 */         if (localObject1 != null)
/*      */         {
/* 1111 */           if ((localObject1 instanceof Reader))
/*      */           {
/* 1113 */             localReader = (Reader)localObject1;
/*      */           }
/*      */           else
/*      */           {
/* 1117 */             Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */             
/* 1119 */             localReader = localDatum.characterStreamValue();
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1125 */         setIsNull(4);
/*      */         
/* 1127 */         localReader = this.resultSet.getCharacterStream(paramInt + 1);
/*      */       }
/*      */       
/* 1130 */       return localReader;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1139 */     synchronized (this.connection)
/*      */     {
/* 1141 */       ensureOpen();
/* 1142 */       BigDecimal localBigDecimal = null;
/*      */       
/* 1144 */       setIsNull(3);
/*      */       
/* 1146 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1149 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1151 */         setIsNull(localDatum == null);
/*      */         
/* 1153 */         if (localDatum != null) {
/* 1154 */           localBigDecimal = localDatum.bigDecimalValue();
/*      */         }
/*      */       }
/*      */       else {
/* 1158 */         setIsNull(4);
/*      */         
/* 1160 */         localBigDecimal = this.resultSet.getBigDecimal(paramInt + 1);
/*      */       }
/*      */       
/* 1163 */       return localBigDecimal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getObject(int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1172 */     synchronized (this.connection)
/*      */     {
/* 1174 */       ensureOpen();
/* 1175 */       Object localObject1 = null;
/*      */       
/* 1177 */       setIsNull(3);
/*      */       
/* 1179 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1182 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1184 */         setIsNull(localDatum == null);
/*      */         
/* 1186 */         if (localDatum != null)
/*      */         {
/* 1188 */           if ((localDatum instanceof STRUCT)) {
/* 1189 */             localObject1 = ((STRUCT)localDatum).toJdbc(paramMap);
/*      */           } else {
/* 1191 */             localObject1 = localDatum.toJdbc();
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1196 */         setIsNull(4);
/*      */         
/* 1198 */         localObject1 = this.resultSet.getObject(paramInt + 1, paramMap);
/*      */       }
/*      */       
/* 1201 */       return localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Ref getRef(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1209 */     synchronized (this.connection)
/*      */     {
/* 1211 */       ensureOpen();
/* 1212 */       return getREF(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Blob getBlob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1220 */     synchronized (this.connection)
/*      */     {
/* 1222 */       ensureOpen();
/* 1223 */       return getBLOB(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Clob getClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1231 */     synchronized (this.connection)
/*      */     {
/* 1233 */       ensureOpen();
/* 1234 */       return getCLOB(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Array getArray(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1243 */     synchronized (this.connection)
/*      */     {
/* 1245 */       ensureOpen();
/* 1246 */       return getARRAY(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getDate(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1255 */     synchronized (this.connection)
/*      */     {
/* 1257 */       ensureOpen();
/* 1258 */       Date localDate = null;
/*      */       
/* 1260 */       setIsNull(3);
/*      */       
/* 1262 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1265 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1267 */         setIsNull(localDatum == null);
/*      */         
/* 1269 */         if (localDatum != null)
/*      */         {
/* 1271 */           if ((localDatum instanceof DATE)) {
/* 1272 */             localDate = ((DATE)localDatum).dateValue(paramCalendar); } else { Object localObject1;
/* 1273 */             if ((localDatum instanceof TIMESTAMP))
/*      */             {
/* 1275 */               localObject1 = ((TIMESTAMP)localDatum).timestampValue(paramCalendar);
/* 1276 */               long l = ((Timestamp)localObject1).getTime();
/* 1277 */               localDate = new Date(l);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/* 1283 */               localObject1 = new DATE(localDatum.stringValue(this.connection));
/*      */               
/* 1285 */               if (localObject1 != null) {
/* 1286 */                 localDate = ((DATE)localObject1).dateValue(paramCalendar);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1292 */         setIsNull(4);
/*      */         
/* 1294 */         localDate = this.resultSet.getDate(paramInt + 1, paramCalendar);
/*      */       }
/*      */       
/* 1297 */       return localDate;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getTime(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1306 */     synchronized (this.connection)
/*      */     {
/* 1308 */       ensureOpen();
/* 1309 */       Time localTime = null;
/*      */       
/* 1311 */       setIsNull(3);
/*      */       
/* 1313 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1316 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1318 */         setIsNull(localDatum == null);
/*      */         
/* 1320 */         if (localDatum != null)
/*      */         {
/* 1322 */           if ((localDatum instanceof DATE)) {
/* 1323 */             localTime = ((DATE)localDatum).timeValue(paramCalendar); } else { Object localObject1;
/* 1324 */             if ((localDatum instanceof TIMESTAMP))
/*      */             {
/* 1326 */               localObject1 = ((TIMESTAMP)localDatum).timestampValue(paramCalendar);
/* 1327 */               long l = ((Timestamp)localObject1).getTime();
/* 1328 */               localTime = new Time(l);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1333 */               localObject1 = new DATE(localDatum.stringValue(this.connection));
/*      */               
/* 1335 */               if (localObject1 != null) {
/* 1336 */                 localTime = ((DATE)localObject1).timeValue(paramCalendar);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1342 */         setIsNull(4);
/*      */         
/* 1344 */         localTime = this.resultSet.getTime(paramInt + 1, paramCalendar);
/*      */       }
/*      */       
/* 1347 */       return localTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar)
/*      */     throws SQLException
/*      */   {
/* 1356 */     synchronized (this.connection)
/*      */     {
/* 1358 */       ensureOpen();
/* 1359 */       Timestamp localTimestamp = null;
/*      */       
/* 1361 */       setIsNull(3);
/*      */       
/* 1363 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1366 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1368 */         setIsNull(localDatum == null);
/*      */         
/* 1370 */         if (localDatum != null)
/*      */         {
/* 1372 */           if ((localDatum instanceof DATE)) {
/* 1373 */             localTimestamp = ((DATE)localDatum).timestampValue(paramCalendar);
/* 1374 */           } else if ((localDatum instanceof TIMESTAMP)) {
/* 1375 */             localTimestamp = ((TIMESTAMP)localDatum).timestampValue(paramCalendar);
/*      */           }
/*      */           else {
/* 1378 */             DATE localDATE = new DATE(localDatum.stringValue(this.connection));
/*      */             
/* 1380 */             if (localDATE != null) {
/* 1381 */               localTimestamp = localDATE.timestampValue(paramCalendar);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1387 */         setIsNull(4);
/*      */         
/* 1389 */         localTimestamp = this.resultSet.getTimestamp(paramInt + 1, paramCalendar);
/*      */       }
/*      */       
/* 1392 */       return localTimestamp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1400 */     synchronized (this.connection)
/*      */     {
/* 1402 */       ensureOpen();
/*      */       
/* 1404 */       URL localURL = null;
/*      */       
/* 1406 */       int i = getInternalMetadata().getColumnType(paramInt + 1);
/* 1407 */       int j = SQLUtil.getInternalType(i);
/*      */       
/*      */ 
/* 1410 */       if ((j == 96) || (j == 1) || (j == 8))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/* 1415 */           String str = getString(paramInt);
/* 1416 */           if (str == null) localURL = null; else {
/* 1417 */             localURL = new URL(str);
/*      */           }
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException)
/*      */         {
/* 1422 */           SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 1423 */           localSQLException2.fillInStackTrace();
/* 1424 */           throw localSQLException2;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1431 */         SQLException localSQLException1 = DatabaseError.createUnsupportedFeatureSqlException();
/* 1432 */         localSQLException1.fillInStackTrace();
/* 1433 */         throw localSQLException1;
/*      */       }
/*      */       
/*      */ 
/* 1437 */       return localURL;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getCursor(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1445 */     synchronized (this.connection)
/*      */     {
/* 1447 */       ensureOpen();
/* 1448 */       ResultSet localResultSet = null;
/*      */       
/* 1450 */       setIsNull(3);
/*      */       
/* 1452 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1455 */         Datum localDatum = getOracleObject(paramInt);
/*      */         
/* 1457 */         setIsNull(localDatum == null);
/*      */         
/* 1459 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/* 1460 */         localSQLException.fillInStackTrace();
/* 1461 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1466 */       setIsNull(4);
/*      */       
/* 1468 */       localResultSet = this.resultSet.getCursor(paramInt + 1);
/*      */       
/*      */ 
/* 1471 */       return localResultSet;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ROWID getROWID(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1479 */     synchronized (this.connection)
/*      */     {
/* 1481 */       ensureOpen();
/* 1482 */       ROWID localROWID = null;
/*      */       
/* 1484 */       setIsNull(3);
/*      */       
/* 1486 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1489 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1491 */         setIsNull(localDatum == null);
/*      */         
/* 1493 */         if ((localDatum != null) && (!(localDatum instanceof ROWID)))
/*      */         {
/* 1495 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/* 1496 */           localSQLException.fillInStackTrace();
/* 1497 */           throw localSQLException;
/*      */         }
/*      */         
/* 1500 */         localROWID = (ROWID)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1504 */         setIsNull(4);
/*      */         
/* 1506 */         localROWID = this.resultSet.getROWID(paramInt + 1);
/*      */       }
/*      */       
/* 1509 */       return localROWID;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public NUMBER getNUMBER(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1517 */     synchronized (this.connection)
/*      */     {
/* 1519 */       ensureOpen();
/* 1520 */       NUMBER localNUMBER = null;
/*      */       
/* 1522 */       setIsNull(3);
/*      */       
/* 1524 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1527 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1529 */         setIsNull(localDatum == null);
/*      */         
/* 1531 */         if ((localDatum != null) && (!(localDatum instanceof NUMBER)))
/*      */         {
/* 1533 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/* 1534 */           localSQLException.fillInStackTrace();
/* 1535 */           throw localSQLException;
/*      */         }
/*      */         
/* 1538 */         localNUMBER = (NUMBER)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1542 */         setIsNull(4);
/*      */         
/* 1544 */         localNUMBER = this.resultSet.getNUMBER(paramInt + 1);
/*      */       }
/*      */       
/* 1547 */       return localNUMBER;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public DATE getDATE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1555 */     synchronized (this.connection)
/*      */     {
/* 1557 */       ensureOpen();
/* 1558 */       DATE localDATE = null;
/*      */       
/* 1560 */       setIsNull(3);
/*      */       
/* 1562 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1565 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1567 */         if (localDatum != null)
/*      */         {
/* 1569 */           if ((localDatum instanceof DATE)) { localDATE = (DATE)localDatum; } else { Object localObject1;
/* 1570 */             if ((localDatum instanceof TIMESTAMP))
/*      */             {
/* 1572 */               localObject1 = ((TIMESTAMP)localDatum).timestampValue();
/* 1573 */               localDATE = new DATE((Timestamp)localObject1);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1578 */               localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/* 1579 */               ((SQLException)localObject1).fillInStackTrace();
/* 1580 */               throw ((Throwable)localObject1);
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */         else {
/* 1586 */           setIsNull(localDatum == null);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1592 */         setIsNull(4);
/*      */         
/* 1594 */         localDATE = this.resultSet.getDATE(paramInt + 1);
/*      */       }
/*      */       
/* 1597 */       return localDATE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1605 */     synchronized (this.connection)
/*      */     {
/* 1607 */       ensureOpen();
/* 1608 */       TIMESTAMP localTIMESTAMP = null;
/*      */       
/* 1610 */       setIsNull(3);
/*      */       
/* 1612 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1615 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1617 */         setIsNull(localDatum == null);
/*      */         
/* 1619 */         if ((localDatum != null) && (!(localDatum instanceof TIMESTAMP)))
/*      */         {
/* 1621 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/* 1622 */           localSQLException.fillInStackTrace();
/* 1623 */           throw localSQLException;
/*      */         }
/*      */         
/* 1626 */         localTIMESTAMP = (TIMESTAMP)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1630 */         setIsNull(4);
/*      */         
/* 1632 */         localTIMESTAMP = this.resultSet.getTIMESTAMP(paramInt + 1);
/*      */       }
/*      */       
/* 1635 */       return localTIMESTAMP;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1643 */     synchronized (this.connection)
/*      */     {
/* 1645 */       ensureOpen();
/* 1646 */       TIMESTAMPTZ localTIMESTAMPTZ = null;
/*      */       
/* 1648 */       setIsNull(3);
/*      */       
/* 1650 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1653 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1655 */         setIsNull(localDatum == null);
/*      */         
/* 1657 */         if ((localDatum != null) && (!(localDatum instanceof TIMESTAMPTZ)))
/*      */         {
/* 1659 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/* 1660 */           localSQLException.fillInStackTrace();
/* 1661 */           throw localSQLException;
/*      */         }
/*      */         
/* 1664 */         localTIMESTAMPTZ = (TIMESTAMPTZ)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1668 */         setIsNull(4);
/*      */         
/* 1670 */         localTIMESTAMPTZ = this.resultSet.getTIMESTAMPTZ(paramInt + 1);
/*      */       }
/*      */       
/* 1673 */       return localTIMESTAMPTZ;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1681 */     synchronized (this.connection)
/*      */     {
/* 1683 */       ensureOpen();
/* 1684 */       TIMESTAMPLTZ localTIMESTAMPLTZ = null;
/*      */       
/* 1686 */       setIsNull(3);
/*      */       
/* 1688 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1691 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1693 */         setIsNull(localDatum == null);
/*      */         
/* 1695 */         if ((localDatum != null) && (!(localDatum instanceof TIMESTAMPLTZ)))
/*      */         {
/* 1697 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/* 1698 */           localSQLException.fillInStackTrace();
/* 1699 */           throw localSQLException;
/*      */         }
/*      */         
/* 1702 */         localTIMESTAMPLTZ = (TIMESTAMPLTZ)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1706 */         setIsNull(4);
/*      */         
/* 1708 */         localTIMESTAMPLTZ = this.resultSet.getTIMESTAMPLTZ(paramInt + 1);
/*      */       }
/*      */       
/* 1711 */       return localTIMESTAMPLTZ;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALDS getINTERVALDS(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1719 */     synchronized (this.connection)
/*      */     {
/* 1721 */       ensureOpen();
/* 1722 */       INTERVALDS localINTERVALDS = null;
/*      */       
/* 1724 */       setIsNull(3);
/*      */       
/* 1726 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1729 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1731 */         setIsNull(localDatum == null);
/*      */         
/* 1733 */         if ((localDatum != null) && (!(localDatum instanceof INTERVALDS)))
/*      */         {
/* 1735 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
/* 1736 */           localSQLException.fillInStackTrace();
/* 1737 */           throw localSQLException;
/*      */         }
/*      */         
/* 1740 */         localINTERVALDS = (INTERVALDS)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1744 */         setIsNull(4);
/*      */         
/* 1746 */         localINTERVALDS = this.resultSet.getINTERVALDS(paramInt + 1);
/*      */       }
/*      */       
/* 1749 */       return localINTERVALDS;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public INTERVALYM getINTERVALYM(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1757 */     synchronized (this.connection)
/*      */     {
/* 1759 */       ensureOpen();
/* 1760 */       INTERVALYM localINTERVALYM = null;
/*      */       
/* 1762 */       setIsNull(3);
/*      */       
/* 1764 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1767 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1769 */         setIsNull(localDatum == null);
/*      */         
/* 1771 */         if ((localDatum != null) && (!(localDatum instanceof INTERVALYM)))
/*      */         {
/* 1773 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
/* 1774 */           localSQLException.fillInStackTrace();
/* 1775 */           throw localSQLException;
/*      */         }
/*      */         
/* 1778 */         localINTERVALYM = (INTERVALYM)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1782 */         setIsNull(4);
/*      */         
/* 1784 */         localINTERVALYM = this.resultSet.getINTERVALYM(paramInt + 1);
/*      */       }
/*      */       
/* 1787 */       return localINTERVALYM;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ARRAY getARRAY(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1795 */     synchronized (this.connection)
/*      */     {
/* 1797 */       ensureOpen();
/* 1798 */       ARRAY localARRAY = null;
/*      */       
/* 1800 */       setIsNull(3);
/*      */       
/* 1802 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1805 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1807 */         setIsNull(localDatum == null);
/*      */         
/* 1809 */         if ((localDatum != null) && (!(localDatum instanceof ARRAY)))
/*      */         {
/* 1811 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/* 1812 */           localSQLException.fillInStackTrace();
/* 1813 */           throw localSQLException;
/*      */         }
/*      */         
/* 1816 */         localARRAY = (ARRAY)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1820 */         setIsNull(4);
/*      */         
/* 1822 */         localARRAY = this.resultSet.getARRAY(paramInt + 1);
/*      */       }
/*      */       
/* 1825 */       return localARRAY;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public STRUCT getSTRUCT(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1833 */     synchronized (this.connection)
/*      */     {
/* 1835 */       ensureOpen();
/* 1836 */       STRUCT localSTRUCT = null;
/*      */       
/* 1838 */       setIsNull(3);
/*      */       
/* 1840 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1843 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1845 */         setIsNull(localDatum == null);
/*      */         
/* 1847 */         if ((localDatum != null) && (!(localDatum instanceof STRUCT)))
/*      */         {
/* 1849 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/* 1850 */           localSQLException.fillInStackTrace();
/* 1851 */           throw localSQLException;
/*      */         }
/*      */         
/* 1854 */         localSTRUCT = (STRUCT)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1858 */         setIsNull(4);
/*      */         
/* 1860 */         localSTRUCT = this.resultSet.getSTRUCT(paramInt + 1);
/*      */       }
/*      */       
/* 1863 */       return localSTRUCT;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public OPAQUE getOPAQUE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1871 */     synchronized (this.connection)
/*      */     {
/* 1873 */       ensureOpen();
/* 1874 */       OPAQUE localOPAQUE = null;
/*      */       
/* 1876 */       setIsNull(3);
/*      */       
/* 1878 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1881 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1883 */         setIsNull(localDatum == null);
/*      */         
/* 1885 */         if ((localDatum != null) && (!(localDatum instanceof OPAQUE)))
/*      */         {
/* 1887 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/* 1888 */           localSQLException.fillInStackTrace();
/* 1889 */           throw localSQLException;
/*      */         }
/*      */         
/* 1892 */         localOPAQUE = (OPAQUE)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1896 */         setIsNull(4);
/*      */         
/* 1898 */         localOPAQUE = this.resultSet.getOPAQUE(paramInt + 1);
/*      */       }
/*      */       
/* 1901 */       return localOPAQUE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public REF getREF(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1909 */     synchronized (this.connection)
/*      */     {
/* 1911 */       ensureOpen();
/* 1912 */       REF localREF = null;
/*      */       
/* 1914 */       setIsNull(3);
/*      */       
/* 1916 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1919 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1921 */         setIsNull(localDatum == null);
/*      */         
/* 1923 */         if ((localDatum != null) && (!(localDatum instanceof REF)))
/*      */         {
/* 1925 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/* 1926 */           localSQLException.fillInStackTrace();
/* 1927 */           throw localSQLException;
/*      */         }
/*      */         
/* 1930 */         localREF = (REF)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1934 */         setIsNull(4);
/*      */         
/* 1936 */         localREF = this.resultSet.getREF(paramInt + 1);
/*      */       }
/*      */       
/* 1939 */       return localREF;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CHAR getCHAR(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1947 */     synchronized (this.connection)
/*      */     {
/* 1949 */       ensureOpen();
/* 1950 */       CHAR localCHAR = null;
/*      */       
/* 1952 */       setIsNull(3);
/*      */       
/* 1954 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1957 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1959 */         setIsNull(localDatum == null);
/*      */         
/* 1961 */         if ((localDatum != null) && (!(localDatum instanceof CHAR)))
/*      */         {
/* 1963 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/* 1964 */           localSQLException.fillInStackTrace();
/* 1965 */           throw localSQLException;
/*      */         }
/*      */         
/* 1968 */         localCHAR = (CHAR)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 1972 */         setIsNull(4);
/*      */         
/* 1974 */         localCHAR = this.resultSet.getCHAR(paramInt + 1);
/*      */       }
/*      */       
/* 1977 */       return localCHAR;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public RAW getRAW(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1985 */     synchronized (this.connection)
/*      */     {
/* 1987 */       ensureOpen();
/* 1988 */       RAW localRAW = null;
/*      */       
/* 1990 */       setIsNull(3);
/*      */       
/* 1992 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 1995 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 1997 */         setIsNull(localDatum == null);
/*      */         
/* 1999 */         if ((localDatum != null) && (!(localDatum instanceof RAW)))
/*      */         {
/* 2001 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/* 2002 */           localSQLException.fillInStackTrace();
/* 2003 */           throw localSQLException;
/*      */         }
/*      */         
/* 2006 */         localRAW = (RAW)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2010 */         setIsNull(4);
/*      */         
/* 2012 */         localRAW = this.resultSet.getRAW(paramInt + 1);
/*      */       }
/*      */       
/* 2015 */       return localRAW;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BLOB getBLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2023 */     synchronized (this.connection)
/*      */     {
/* 2025 */       ensureOpen();
/* 2026 */       BLOB localBLOB = null;
/*      */       
/* 2028 */       setIsNull(3);
/*      */       
/* 2030 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2033 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2035 */         setIsNull(localDatum == null);
/*      */         
/* 2037 */         if ((localDatum != null) && (!(localDatum instanceof BLOB)))
/*      */         {
/* 2039 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/* 2040 */           localSQLException.fillInStackTrace();
/* 2041 */           throw localSQLException;
/*      */         }
/*      */         
/* 2044 */         localBLOB = (BLOB)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2048 */         setIsNull(4);
/*      */         
/* 2050 */         localBLOB = this.resultSet.getBLOB(paramInt + 1);
/*      */       }
/*      */       
/* 2053 */       return localBLOB;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NCLOB getNCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2064 */     synchronized (this.connection)
/*      */     {
/* 2066 */       ensureOpen();
/* 2067 */       NCLOB localNCLOB = null;
/*      */       
/* 2069 */       setIsNull(3);
/*      */       
/* 2071 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2074 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2076 */         setIsNull(localDatum == null);
/*      */         
/* 2078 */         if ((localDatum != null) && (!(localDatum instanceof NCLOB)))
/*      */         {
/* 2080 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 2081 */           localSQLException.fillInStackTrace();
/* 2082 */           throw localSQLException;
/*      */         }
/*      */         
/* 2085 */         localNCLOB = (NCLOB)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2089 */         setIsNull(4);
/*      */         
/* 2091 */         localNCLOB = (NCLOB)this.resultSet.getNClob(paramInt + 1);
/*      */       }
/*      */       
/* 2094 */       return localNCLOB;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public CLOB getCLOB(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2102 */     synchronized (this.connection)
/*      */     {
/* 2104 */       ensureOpen();
/* 2105 */       CLOB localCLOB = null;
/*      */       
/* 2107 */       setIsNull(3);
/*      */       
/* 2109 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2112 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2114 */         setIsNull(localDatum == null);
/*      */         
/* 2116 */         if ((localDatum != null) && (!(localDatum instanceof CLOB)))
/*      */         {
/* 2118 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 2119 */           localSQLException.fillInStackTrace();
/* 2120 */           throw localSQLException;
/*      */         }
/*      */         
/* 2123 */         localCLOB = (CLOB)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2127 */         setIsNull(4);
/*      */         
/* 2129 */         localCLOB = this.resultSet.getCLOB(paramInt + 1);
/*      */       }
/*      */       
/* 2132 */       return localCLOB;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BFILE getBFILE(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2140 */     synchronized (this.connection)
/*      */     {
/* 2142 */       ensureOpen();
/* 2143 */       BFILE localBFILE = null;
/*      */       
/* 2145 */       setIsNull(3);
/*      */       
/* 2147 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2150 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2152 */         setIsNull(localDatum == null);
/*      */         
/* 2154 */         if ((localDatum != null) && (!(localDatum instanceof BFILE)))
/*      */         {
/* 2156 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/* 2157 */           localSQLException.fillInStackTrace();
/* 2158 */           throw localSQLException;
/*      */         }
/*      */         
/* 2161 */         localBFILE = (BFILE)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2165 */         setIsNull(4);
/*      */         
/* 2167 */         localBFILE = this.resultSet.getBFILE(paramInt + 1);
/*      */       }
/*      */       
/* 2170 */       return localBFILE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public BFILE getBfile(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2178 */     synchronized (this.connection)
/*      */     {
/* 2180 */       ensureOpen();
/* 2181 */       return getBFILE(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory)
/*      */     throws SQLException
/*      */   {
/* 2190 */     synchronized (this.connection)
/*      */     {
/* 2192 */       ensureOpen();
/* 2193 */       if (paramCustomDatumFactory == null)
/*      */       {
/* 2195 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2196 */         ((SQLException)localObject1).fillInStackTrace();
/* 2197 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 2200 */       Object localObject1 = null;
/*      */       
/* 2202 */       setIsNull(3);
/*      */       
/* 2204 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2207 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2209 */         setIsNull(localDatum == null);
/*      */         
/* 2211 */         localObject1 = paramCustomDatumFactory.create(localDatum, 0);
/*      */       }
/*      */       else
/*      */       {
/* 2215 */         setIsNull(4);
/*      */         
/* 2217 */         localObject1 = this.resultSet.getCustomDatum(paramInt + 1, paramCustomDatumFactory);
/*      */       }
/*      */       
/* 2220 */       return (CustomDatum)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory)
/*      */     throws SQLException
/*      */   {
/* 2229 */     synchronized (this.connection)
/*      */     {
/* 2231 */       ensureOpen();
/* 2232 */       if (paramORADataFactory == null)
/*      */       {
/* 2234 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2235 */         ((SQLException)localObject1).fillInStackTrace();
/* 2236 */         throw ((Throwable)localObject1);
/*      */       }
/*      */       
/* 2239 */       Object localObject1 = null;
/*      */       
/* 2241 */       setIsNull(3);
/*      */       
/* 2243 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2246 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2248 */         setIsNull(localDatum == null);
/*      */         
/* 2250 */         localObject1 = paramORADataFactory.create(localDatum, 0);
/*      */       }
/*      */       else
/*      */       {
/* 2254 */         setIsNull(4);
/*      */         
/* 2256 */         localObject1 = this.resultSet.getORAData(paramInt + 1, paramORADataFactory);
/*      */       }
/*      */       
/* 2259 */       return (ORAData)localObject1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NClob getNClob(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2271 */     ensureOpen();
/* 2272 */     NCLOB localNCLOB = getNCLOB(paramInt);
/*      */     
/* 2274 */     if (localNCLOB == null) { return null;
/*      */     }
/* 2276 */     if (!(localNCLOB instanceof NClob))
/*      */     {
/* 2278 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 2279 */       localSQLException.fillInStackTrace();
/* 2280 */       throw localSQLException;
/*      */     }
/*      */     
/* 2283 */     return localNCLOB;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getNString(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2290 */     ensureOpen();
/* 2291 */     return getString(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */   public Reader getNCharacterStream(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2298 */     ensureOpen();
/* 2299 */     return getCharacterStream(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */   public RowId getRowId(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2306 */     ensureOpen();
/* 2307 */     return getROWID(paramInt);
/*      */   }
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2313 */     synchronized (this.connection)
/*      */     {
/* 2315 */       ensureOpen();
/* 2316 */       SQLXML localSQLXML = null;
/*      */       
/* 2318 */       setIsNull(3);
/*      */       
/* 2320 */       if ((isOnInsertRow()) || ((isUpdatingRow()) && (isRowBufferUpdatedAt(paramInt))))
/*      */       {
/*      */ 
/* 2323 */         Datum localDatum = getRowBufferDatumAt(paramInt);
/*      */         
/* 2325 */         setIsNull(localDatum == null);
/*      */         
/* 2327 */         if ((localDatum != null) && (!(localDatum instanceof SQLXML)))
/*      */         {
/* 2329 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSQLXML");
/* 2330 */           localSQLException.fillInStackTrace();
/* 2331 */           throw localSQLException;
/*      */         }
/*      */         
/* 2334 */         localSQLXML = (SQLXML)localDatum;
/*      */       }
/*      */       else
/*      */       {
/* 2338 */         setIsNull(4);
/*      */         
/* 2340 */         localSQLXML = this.resultSet.getSQLXML(paramInt + 1);
/*      */       }
/*      */       
/* 2343 */       return localSQLXML;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRowId(int paramInt, RowId paramRowId)
/*      */     throws SQLException
/*      */   {
/* 2353 */     updateROWID(paramInt, (ROWID)paramRowId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2362 */     updateCharacterStream(paramInt, paramReader, paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 2370 */     updateCharacterStream(paramInt, paramReader);
/*      */   }
/*      */   
/*      */   public void updateSQLXML(int paramInt, SQLXML paramSQLXML)
/*      */     throws SQLException
/*      */   {
/* 2376 */     updateOracleObject(paramInt, (Datum)paramSQLXML);
/*      */   }
/*      */   
/*      */   public void updateNString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 2382 */     updateString(paramInt, paramString);
/*      */   }
/*      */   
/*      */   public void updateNClob(int paramInt, NClob paramNClob)
/*      */     throws SQLException
/*      */   {
/* 2388 */     updateClob(paramInt, paramNClob);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2395 */     updateAsciiStream(paramInt, paramInputStream, (int)paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 2402 */     updateAsciiStream(paramInt, paramInputStream, Integer.MAX_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2409 */     updateBinaryStream(paramInt, paramInputStream, (int)paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 2416 */     updateBinaryStream(paramInt, paramInputStream, Integer.MAX_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2423 */     updateCharacterStream(paramInt, paramReader, (int)paramLong);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 2430 */     updateCharacterStream(paramInt, paramReader, Integer.MAX_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream)
/*      */     throws SQLException
/*      */   {
/* 2437 */     Blob localBlob = this.connection.createBlob();
/* 2438 */     addToTempLobsToFree(localBlob);
/* 2439 */     int i = ((BLOB)localBlob).getBufferSize();
/* 2440 */     OutputStream localOutputStream = localBlob.setBinaryStream(1L);
/* 2441 */     byte[] arrayOfByte = new byte[i];
/*      */     try
/*      */     {
/*      */       for (;;)
/*      */       {
/* 2446 */         int j = paramInputStream.read(arrayOfByte);
/* 2447 */         if (j == -1) break;
/* 2448 */         localOutputStream.write(arrayOfByte, 0, j);
/*      */       }
/* 2450 */       localOutputStream.close();
/* 2451 */       updateBlob(paramInt, localBlob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2455 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2456 */       localSQLException.fillInStackTrace();
/* 2457 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2472 */     Blob localBlob = this.connection.createBlob();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2477 */     addToTempLobsToFree(localBlob);
/* 2478 */     int i = ((BLOB)localBlob).getBufferSize();
/* 2479 */     OutputStream localOutputStream = localBlob.setBinaryStream(1L);
/* 2480 */     byte[] arrayOfByte = new byte[i];
/* 2481 */     long l = paramLong;
/*      */     try
/*      */     {
/* 2484 */       while (l > 0L)
/*      */       {
/* 2486 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2487 */         if (j == -1) break;
/* 2488 */         localOutputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2490 */         l -= j;
/*      */       }
/* 2492 */       localOutputStream.close();
/* 2493 */       updateBlob(paramInt, localBlob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2497 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2498 */       localSQLException.fillInStackTrace();
/* 2499 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateClob(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2511 */     updateClob(paramInt, paramReader, paramLong, (short)1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt, Reader paramReader, long paramLong, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2519 */     NClob localNClob = paramShort == 1 ? this.connection.createClob() : this.connection.createNClob();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2527 */     addToTempLobsToFree(localNClob);
/* 2528 */     int i = ((CLOB)localNClob).getBufferSize();
/* 2529 */     Writer localWriter = localNClob.setCharacterStream(1L);
/* 2530 */     char[] arrayOfChar = new char[i];
/* 2531 */     long l = paramLong;
/*      */     try
/*      */     {
/* 2534 */       while (l > 0L)
/*      */       {
/* 2536 */         int j = paramReader.read(arrayOfChar, 0, Math.min(i, (int)l));
/* 2537 */         if (j == -1) break;
/* 2538 */         localWriter.write(arrayOfChar, 0, j);
/*      */         
/* 2540 */         l -= j;
/*      */       }
/* 2542 */       localWriter.close();
/* 2543 */       updateClob(paramInt, localNClob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2547 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2548 */       localSQLException.fillInStackTrace();
/* 2549 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateClob(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 2562 */     Clob localClob = this.connection.createClob();
/* 2563 */     addToTempLobsToFree(localClob);
/* 2564 */     int i = ((CLOB)localClob).getBufferSize();
/* 2565 */     Writer localWriter = localClob.setCharacterStream(1L);
/* 2566 */     char[] arrayOfChar = new char[i];
/*      */     try
/*      */     {
/*      */       for (;;)
/*      */       {
/* 2571 */         int j = paramReader.read(arrayOfChar);
/* 2572 */         if (j == -1) break;
/* 2573 */         localWriter.write(arrayOfChar, 0, j);
/*      */       }
/* 2575 */       localWriter.close();
/* 2576 */       updateClob(paramInt, localClob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2580 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2581 */       localSQLException.fillInStackTrace();
/* 2582 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2593 */     updateClob(paramInt1, paramInputStream, paramInt2, (short)1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 2603 */     NClob localNClob = paramShort == 1 ? this.connection.createClob() : this.connection.createNClob();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2611 */     addToTempLobsToFree(localNClob);
/* 2612 */     int i = ((CLOB)localNClob).getBufferSize();
/* 2613 */     OutputStream localOutputStream = localNClob.setAsciiStream(1L);
/* 2614 */     byte[] arrayOfByte = new byte[i];
/* 2615 */     long l = paramInt2;
/*      */     try
/*      */     {
/* 2618 */       while (l > 0L)
/*      */       {
/* 2620 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2621 */         if (j == -1) break;
/* 2622 */         localOutputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2624 */         l -= j;
/*      */       }
/* 2626 */       localOutputStream.close();
/* 2627 */       updateClob(paramInt1, localNClob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2631 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2632 */       localSQLException.fillInStackTrace();
/* 2633 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateNClob(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2647 */     NClob localNClob = this.connection.createNClob();
/* 2648 */     addToTempLobsToFree(localNClob);
/* 2649 */     int i = ((NCLOB)localNClob).getBufferSize();
/* 2650 */     OutputStream localOutputStream = localNClob.setAsciiStream(1L);
/* 2651 */     byte[] arrayOfByte = new byte[i];
/* 2652 */     long l = paramInt2;
/*      */     try
/*      */     {
/* 2655 */       while (l > 0L)
/*      */       {
/* 2657 */         int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l));
/* 2658 */         if (j == -1) break;
/* 2659 */         localOutputStream.write(arrayOfByte, 0, j);
/*      */         
/* 2661 */         l -= j;
/*      */       }
/* 2663 */       localOutputStream.close();
/* 2664 */       updateNClob(paramInt1, localNClob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2668 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2669 */       localSQLException.fillInStackTrace();
/* 2670 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNClob(int paramInt, Reader paramReader, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2680 */     NClob localNClob = this.connection.createNClob();
/* 2681 */     addToTempLobsToFree(localNClob);
/* 2682 */     int i = ((CLOB)localNClob).getBufferSize();
/* 2683 */     Writer localWriter = localNClob.setCharacterStream(1L);
/* 2684 */     char[] arrayOfChar = new char[i];
/* 2685 */     long l = paramLong;
/*      */     try
/*      */     {
/* 2688 */       while (l > 0L)
/*      */       {
/* 2690 */         int j = paramReader.read(arrayOfChar, 0, Math.min(i, (int)l));
/* 2691 */         if (j == -1) break;
/* 2692 */         localWriter.write(arrayOfChar, 0, j);
/*      */         
/* 2694 */         l -= j;
/*      */       }
/* 2696 */       localWriter.close();
/* 2697 */       updateNClob(paramInt, localNClob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2701 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2702 */       localSQLException.fillInStackTrace();
/* 2703 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNClob(int paramInt, Reader paramReader)
/*      */     throws SQLException
/*      */   {
/* 2713 */     NClob localNClob = this.connection.createNClob();
/* 2714 */     addToTempLobsToFree(localNClob);
/* 2715 */     int i = ((CLOB)localNClob).getBufferSize();
/* 2716 */     Writer localWriter = localNClob.setCharacterStream(1L);
/* 2717 */     char[] arrayOfChar = new char[i];
/*      */     try
/*      */     {
/*      */       for (;;)
/*      */       {
/* 2722 */         int j = paramReader.read(arrayOfChar);
/* 2723 */         if (j == -1) break;
/* 2724 */         localWriter.write(arrayOfChar, 0, j);
/*      */       }
/* 2726 */       localWriter.close();
/* 2727 */       updateNClob(paramInt, localNClob);
/*      */     }
/*      */     catch (IOException localIOException)
/*      */     {
/* 2731 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 2732 */       localSQLException.fillInStackTrace();
/* 2733 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2739 */   ArrayList tempClobsToFree = null;
/* 2740 */   ArrayList tempBlobsToFree = null;
/*      */   
/*      */ 
/*      */   void addToTempLobsToFree(Clob paramClob)
/*      */   {
/* 2745 */     if (this.tempClobsToFree == null)
/* 2746 */       this.tempClobsToFree = new ArrayList();
/* 2747 */     this.tempClobsToFree.add(paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void addToTempLobsToFree(Blob paramBlob)
/*      */   {
/* 2754 */     if (this.tempBlobsToFree == null)
/* 2755 */       this.tempBlobsToFree = new ArrayList();
/* 2756 */     this.tempBlobsToFree.add(paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanTempLobs()
/*      */   {
/* 2763 */     cleanTempClobs(this.tempClobsToFree);
/* 2764 */     cleanTempBlobs(this.tempBlobsToFree);
/* 2765 */     this.tempClobsToFree = null;
/* 2766 */     this.tempBlobsToFree = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void cleanTempBlobs(ArrayList paramArrayList)
/*      */   {
/* 2773 */     if (paramArrayList != null)
/*      */     {
/* 2775 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 2777 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 2781 */           ((BLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void cleanTempClobs(ArrayList paramArrayList)
/*      */   {
/* 2795 */     if (paramArrayList != null)
/*      */     {
/* 2797 */       Iterator localIterator = paramArrayList.iterator();
/*      */       
/* 2799 */       while (localIterator.hasNext())
/*      */       {
/*      */         try
/*      */         {
/* 2803 */           ((CLOB)localIterator.next()).freeTemporary();
/*      */         }
/*      */         catch (SQLException localSQLException) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 15	oracle/jdbc/driver/UpdatableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   4: checkcast 11	oracle/jdbc/driver/OracleStatement
/*      */     //   7: getfield 31	oracle/jdbc/driver/OracleStatement:closed	Z
/*      */     //   10: ifeq +23 -> 33
/*      */     //   13: aload_0
/*      */     //   14: invokevirtual 8	oracle/jdbc/driver/UpdatableResultSet:getConnectionDuringExceptionHandling	()Loracle/jdbc/internal/OracleConnection;
/*      */     //   17: bipush 9
/*      */     //   19: ldc_w 264
/*      */     //   22: invokestatic 80	oracle/jdbc/driver/DatabaseError:createSqlException	(Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*      */     //   25: astore_1
/*      */     //   26: aload_1
/*      */     //   27: invokevirtual 10	java/sql/SQLException:fillInStackTrace	()Ljava/lang/Throwable;
/*      */     //   30: pop
/*      */     //   31: aload_1
/*      */     //   32: athrow
/*      */     //   33: aload_0
/*      */     //   34: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   37: dup
/*      */     //   38: astore_1
/*      */     //   39: monitorenter
/*      */     //   40: new 265	oracle/jdbc/driver/OracleResultSetMetaData
/*      */     //   43: dup
/*      */     //   44: aload_0
/*      */     //   45: getfield 13	oracle/jdbc/driver/UpdatableResultSet:connection	Loracle/jdbc/driver/PhysicalConnection;
/*      */     //   48: aload_0
/*      */     //   49: getfield 15	oracle/jdbc/driver/UpdatableResultSet:scrollStmt	Loracle/jdbc/driver/ScrollRsetStatement;
/*      */     //   52: checkcast 11	oracle/jdbc/driver/OracleStatement
/*      */     //   55: iconst_1
/*      */     //   56: invokespecial 266	oracle/jdbc/driver/OracleResultSetMetaData:<init>	(Loracle/jdbc/driver/PhysicalConnection;Loracle/jdbc/driver/OracleStatement;I)V
/*      */     //   59: aload_1
/*      */     //   60: monitorexit
/*      */     //   61: areturn
/*      */     //   62: astore_2
/*      */     //   63: aload_1
/*      */     //   64: monitorexit
/*      */     //   65: aload_2
/*      */     //   66: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2821	-> byte code offset #0
/*      */     //   Java source line #2823	-> byte code offset #13
/*      */     //   Java source line #2824	-> byte code offset #26
/*      */     //   Java source line #2825	-> byte code offset #31
/*      */     //   Java source line #2828	-> byte code offset #33
/*      */     //   Java source line #2829	-> byte code offset #40
/*      */     //   Java source line #2832	-> byte code offset #62
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	67	0	this	UpdatableResultSet
/*      */     //   25	7	1	localSQLException	SQLException
/*      */     //   38	26	1	Ljava/lang/Object;	Object
/*      */     //   62	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   40	61	62	finally
/*      */     //   62	65	62	finally
/*      */   }
/*      */   
/*      */   public int findColumn(String paramString)
/*      */     throws SQLException
/*      */   {
/* 2838 */     synchronized (this.connection)
/*      */     {
/* 2840 */       ensureOpen();
/* 2841 */       return this.resultSet.findColumn(paramString) - 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2852 */     synchronized (this.connection)
/*      */     {
/* 2854 */       ensureOpen();
/* 2855 */       this.resultSet.setFetchDirection(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 2862 */     synchronized (this.connection)
/*      */     {
/* 2864 */       ensureOpen();
/* 2865 */       return this.resultSet.getFetchDirection();
/*      */     }
/*      */   }
/*      */   
/*      */   public void setFetchSize(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2872 */     synchronized (this.connection)
/*      */     {
/* 2874 */       ensureOpen();
/* 2875 */       this.resultSet.setFetchSize(paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 2882 */     synchronized (this.connection)
/*      */     {
/* 2884 */       ensureOpen();
/* 2885 */       return this.resultSet.getFetchSize();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/* 2893 */     return this.rsetType;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/* 2900 */     return 1008;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 2911 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 2918 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 2925 */     return false;
/*      */   }
/*      */   
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/* 2931 */     synchronized (this.connection)
/*      */     {
/* 2933 */       ensureOpen();
/* 2934 */       if (!isOnInsertRow())
/*      */       {
/* 2936 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 83);
/* 2937 */         localSQLException.fillInStackTrace();
/* 2938 */         throw localSQLException;
/*      */       }
/*      */       
/* 2941 */       prepareInsertRowStatement();
/* 2942 */       prepareInsertRowBinds();
/* 2943 */       executeInsertRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/* 2950 */     synchronized (this.connection)
/*      */     {
/* 2952 */       ensureOpen();
/*      */       
/*      */ 
/* 2955 */       if (isOnInsertRow())
/*      */       {
/* 2957 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2958 */         localSQLException.fillInStackTrace();
/* 2959 */         throw localSQLException;
/*      */       }
/*      */       
/* 2962 */       int i = getNumColumnsChanged();
/*      */       
/* 2964 */       if (i > 0)
/*      */       {
/* 2966 */         prepareUpdateRowStatement(i);
/* 2967 */         prepareUpdateRowBinds(i);
/* 2968 */         executeUpdateRow();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/* 2976 */     synchronized (this.connection)
/*      */     {
/* 2978 */       ensureOpen();
/*      */       
/*      */ 
/* 2981 */       if (isOnInsertRow())
/*      */       {
/* 2983 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2984 */         localSQLException.fillInStackTrace();
/* 2985 */         throw localSQLException;
/*      */       }
/*      */       
/* 2988 */       prepareDeleteRowStatement();
/* 2989 */       prepareDeleteRowBinds();
/* 2990 */       executeDeleteRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 2997 */     synchronized (this.connection)
/*      */     {
/* 2999 */       ensureOpen();
/*      */       
/* 3001 */       if (isOnInsertRow())
/*      */       {
/* 3003 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 3004 */         localSQLException.fillInStackTrace();
/* 3005 */         throw localSQLException;
/*      */       }
/*      */       
/* 3008 */       this.resultSet.refreshRow();
/*      */     }
/*      */   }
/*      */   
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/* 3015 */     synchronized (this.connection)
/*      */     {
/* 3017 */       ensureOpen();
/* 3018 */       if (this.isUpdating)
/*      */       {
/* 3020 */         this.isUpdating = false;
/*      */         
/* 3022 */         clearRowBuffer();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 3030 */     synchronized (this.connection)
/*      */     {
/* 3032 */       ensureOpen();
/* 3033 */       if (isOnInsertRow()) {
/* 3034 */         return;
/*      */       }
/* 3036 */       this.isInserting = true;
/*      */       
/*      */ 
/* 3039 */       if (this.rowBuffer == null) {
/* 3040 */         this.rowBuffer = new Object[getColumnCount()];
/*      */       }
/* 3042 */       if (this.m_nullIndicator == null) {
/* 3043 */         this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       }
/* 3045 */       clearRowBuffer();
/*      */     }
/*      */   }
/*      */   
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 3052 */     synchronized (this.connection)
/*      */     {
/* 3054 */       ensureOpen();
/* 3055 */       cancelRowInserts();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateString(int paramInt, String paramString)
/*      */     throws SQLException
/*      */   {
/* 3063 */     synchronized (this.connection)
/*      */     {
/* 3065 */       if ((paramString == null) || (paramString.length() == 0)) {
/* 3066 */         updateNull(paramInt);
/*      */       } else {
/* 3068 */         updateObject(paramInt, paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException
/*      */   {
/* 3075 */     synchronized (this.connection)
/*      */     {
/* 3077 */       setRowBufferAt(paramInt, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 3085 */     updateObject(paramInt, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateByte(int paramInt, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 3092 */     updateObject(paramInt, Integer.valueOf(paramByte));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateShort(int paramInt, short paramShort)
/*      */     throws SQLException
/*      */   {
/* 3099 */     updateObject(paramInt, Integer.valueOf(paramShort));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateInt(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3106 */     updateObject(paramInt1, Integer.valueOf(paramInt2));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateLong(int paramInt, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 3113 */     updateObject(paramInt, Long.valueOf(paramLong));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateFloat(int paramInt, float paramFloat)
/*      */     throws SQLException
/*      */   {
/* 3120 */     updateObject(paramInt, Float.valueOf(paramFloat));
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateDouble(int paramInt, double paramDouble)
/*      */     throws SQLException
/*      */   {
/* 3127 */     updateObject(paramInt, Double.valueOf(paramDouble));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal)
/*      */     throws SQLException
/*      */   {
/* 3135 */     updateObject(paramInt, paramBigDecimal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 3142 */     updateObject(paramInt, paramArrayOfByte);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateDate(int paramInt, Date paramDate)
/*      */     throws SQLException
/*      */   {
/* 3149 */     updateObject(paramInt, paramDate);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateTime(int paramInt, Time paramTime)
/*      */     throws SQLException
/*      */   {
/* 3156 */     updateObject(paramInt, paramTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp)
/*      */     throws SQLException
/*      */   {
/* 3164 */     updateObject(paramInt, paramTimestamp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3173 */     ensureOpen();
/* 3174 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3175 */     int i = localOracleResultSetMetaData.getColumnType(1 + paramInt1);
/*      */     
/* 3177 */     if ((paramInputStream != null) && (paramInt2 > 0))
/*      */     {
/* 3179 */       switch (i)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2005: 
/* 3185 */         updateClob(paramInt1, paramInputStream, paramInt2);
/* 3186 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2011: 
/* 3192 */         updateNClob(paramInt1, paramInputStream, paramInt2);
/* 3193 */         break;
/*      */       
/*      */ 
/*      */       case 2004: 
/* 3197 */         updateBlob(paramInt1, paramInputStream, paramInt2);
/* 3198 */         break;
/*      */       
/*      */       case -1: 
/* 3201 */         int[] arrayOfInt = { paramInt2, 1 };
/*      */         
/*      */ 
/*      */ 
/* 3205 */         setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/* 3206 */         break;
/*      */       
/*      */       default: 
/*      */         try
/*      */         {
/* 3211 */           int j = 0;
/* 3212 */           int k = paramInt2;
/* 3213 */           byte[] arrayOfByte = new byte['Ѐ'];
/* 3214 */           char[] arrayOfChar = new char['Ѐ'];
/* 3215 */           StringBuilder localStringBuilder = new StringBuilder(1024);
/*      */           
/* 3217 */           while (k > 0)
/*      */           {
/* 3219 */             if (k >= 1024) {
/* 3220 */               j = paramInputStream.read(arrayOfByte);
/*      */             } else {
/* 3222 */               j = paramInputStream.read(arrayOfByte, 0, k);
/*      */             }
/*      */             
/*      */ 
/* 3226 */             if (j == -1) {
/*      */               break;
/*      */             }
/* 3229 */             DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*      */             
/* 3231 */             localStringBuilder.append(arrayOfChar, 0, j);
/* 3232 */             k -= j;
/*      */           }
/*      */           
/* 3235 */           paramInputStream.close();
/* 3236 */           if (k == paramInt2)
/*      */           {
/* 3238 */             updateNull(paramInt1);
/* 3239 */             return;
/*      */           }
/*      */           
/* 3242 */           updateString(paramInt1, localStringBuilder.toString());
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3247 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3248 */           localSQLException.fillInStackTrace();
/* 3249 */           throw localSQLException;
/*      */         }
/*      */       
/*      */ 
/*      */       }
/*      */       
/*      */     } else {
/* 3256 */       setRowBufferAt(paramInt1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3265 */     ensureOpen();
/* 3266 */     int i = getInternalMetadata().getColumnType(1 + paramInt1);
/*      */     
/* 3268 */     if ((paramInputStream != null) && (paramInt2 > 0))
/*      */     {
/* 3270 */       switch (i)
/*      */       {
/*      */       case 2004: 
/* 3273 */         updateBlob(paramInt1, paramInputStream, paramInt2);
/* 3274 */         break;
/*      */       
/*      */       case -4: 
/* 3277 */         int[] arrayOfInt = { paramInt2, 2 };
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3282 */         setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/* 3283 */         break;
/*      */       
/*      */       default: 
/*      */         try
/*      */         {
/* 3288 */           int j = 0;
/* 3289 */           int k = paramInt2;
/* 3290 */           byte[] arrayOfByte = new byte['Ѐ'];
/* 3291 */           ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(1024);
/*      */           
/*      */ 
/* 3294 */           while (k > 0)
/*      */           {
/* 3296 */             if (k >= 1024) {
/* 3297 */               j = paramInputStream.read(arrayOfByte);
/*      */             } else {
/* 3299 */               j = paramInputStream.read(arrayOfByte, 0, k);
/*      */             }
/*      */             
/*      */ 
/* 3303 */             if (j == -1) {
/*      */               break;
/*      */             }
/* 3306 */             localByteArrayOutputStream.write(arrayOfByte, 0, j);
/* 3307 */             k -= j;
/*      */           }
/*      */           
/* 3310 */           paramInputStream.close();
/* 3311 */           if (k == paramInt2)
/*      */           {
/* 3313 */             updateNull(paramInt1);
/* 3314 */             return;
/*      */           }
/*      */           
/* 3317 */           updateBytes(paramInt1, localByteArrayOutputStream.toByteArray());
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3322 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3323 */           localSQLException.fillInStackTrace();
/* 3324 */           throw localSQLException;
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */     } else {
/* 3334 */       setRowBufferAt(paramInt1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3342 */     int i = 0;int j = paramInt2;
/*      */     
/*      */ 
/* 3345 */     ensureOpen();
/* 3346 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3347 */     int k = localOracleResultSetMetaData.getColumnType(1 + paramInt1);
/*      */     
/* 3349 */     if ((paramReader != null) && (paramInt2 > 0))
/*      */     {
/* 3351 */       switch (k)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2005: 
/* 3357 */         updateClob(paramInt1, paramReader, paramInt2);
/* 3358 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 2011: 
/* 3364 */         updateNClob(paramInt1, paramReader, paramInt2);
/* 3365 */         break;
/*      */       
/*      */ 
/*      */       case -1: 
/* 3369 */         int[] arrayOfInt = { paramInt2 };
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3374 */         setRowBufferAt(paramInt1, paramReader, arrayOfInt);
/* 3375 */         break;
/*      */       
/*      */       default: 
/*      */         try
/*      */         {
/* 3380 */           char[] arrayOfChar = new char['Ѐ'];
/* 3381 */           localObject = new StringBuilder(1024);
/*      */           
/* 3383 */           while (j > 0)
/*      */           {
/* 3385 */             if (j >= 1024) {
/* 3386 */               i = paramReader.read(arrayOfChar);
/*      */             } else {
/* 3388 */               i = paramReader.read(arrayOfChar, 0, j);
/*      */             }
/*      */             
/*      */ 
/* 3392 */             if (i == -1) {
/*      */               break;
/*      */             }
/* 3395 */             ((StringBuilder)localObject).append(arrayOfChar, 0, i);
/* 3396 */             j -= i;
/*      */           }
/*      */           
/* 3399 */           paramReader.close();
/* 3400 */           if (j == paramInt2)
/*      */           {
/* 3402 */             updateNull(paramInt1);
/* 3403 */             return;
/*      */           }
/*      */           
/* 3406 */           updateString(paramInt1, ((StringBuilder)localObject).toString());
/*      */ 
/*      */         }
/*      */         catch (IOException localIOException)
/*      */         {
/* 3411 */           Object localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/* 3412 */           ((SQLException)localObject).fillInStackTrace();
/* 3413 */           throw ((Throwable)localObject);
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */     } else {
/* 3421 */       setRowBufferAt(paramInt1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 3430 */     updateObject(paramInt1, paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateObject(int paramInt, Object paramObject)
/*      */     throws SQLException
/*      */   {
/* 3437 */     synchronized (this.connection)
/*      */     {
/* 3439 */       ensureOpen();
/* 3440 */       Datum localDatum = null;
/*      */       
/* 3442 */       if (paramObject != null)
/*      */       {
/* 3444 */         if ((paramObject instanceof Datum)) {
/* 3445 */           localDatum = (Datum)paramObject;
/*      */         }
/*      */         else {
/* 3448 */           OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3449 */           int i = paramInt + 1;
/* 3450 */           if (localOracleResultSetMetaData.getColumnType(i) == 96) {
/* 3451 */             int j = localOracleResultSetMetaData.getColumnDisplaySize(i);
/* 3452 */             String str = (String)paramObject;
/* 3453 */             for (int k = str.length(); k < j; k++) str = str + " ";
/*      */           }
/* 3455 */           localDatum = SQLUtil.makeOracleDatum(this.connection, paramObject, localOracleResultSetMetaData.getColumnType(i), null, localOracleResultSetMetaData.isNCHAR(i));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 3460 */       setRowBufferAt(paramInt, localDatum);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateOracleObject(int paramInt, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 3468 */     synchronized (this.connection)
/*      */     {
/* 3470 */       setRowBufferAt(paramInt, paramDatum);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateROWID(int paramInt, ROWID paramROWID)
/*      */     throws SQLException
/*      */   {
/* 3478 */     updateOracleObject(paramInt, paramROWID);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateNUMBER(int paramInt, NUMBER paramNUMBER)
/*      */     throws SQLException
/*      */   {
/* 3485 */     updateOracleObject(paramInt, paramNUMBER);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateDATE(int paramInt, DATE paramDATE)
/*      */     throws SQLException
/*      */   {
/* 3492 */     updateOracleObject(paramInt, paramDATE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM)
/*      */     throws SQLException
/*      */   {
/* 3500 */     updateOracleObject(paramInt, paramINTERVALYM);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS)
/*      */     throws SQLException
/*      */   {
/* 3508 */     updateOracleObject(paramInt, paramINTERVALDS);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP)
/*      */     throws SQLException
/*      */   {
/* 3515 */     updateOracleObject(paramInt, paramTIMESTAMP);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ)
/*      */     throws SQLException
/*      */   {
/* 3523 */     updateOracleObject(paramInt, paramTIMESTAMPTZ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ)
/*      */     throws SQLException
/*      */   {
/* 3531 */     updateOracleObject(paramInt, paramTIMESTAMPLTZ);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateARRAY(int paramInt, ARRAY paramARRAY)
/*      */     throws SQLException
/*      */   {
/* 3538 */     updateOracleObject(paramInt, paramARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT)
/*      */     throws SQLException
/*      */   {
/* 3545 */     updateOracleObject(paramInt, paramSTRUCT);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE)
/*      */     throws SQLException
/*      */   {
/* 3552 */     updateOracleObject(paramInt, paramOPAQUE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateREF(int paramInt, REF paramREF)
/*      */     throws SQLException
/*      */   {
/* 3559 */     updateOracleObject(paramInt, paramREF);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCHAR(int paramInt, CHAR paramCHAR)
/*      */     throws SQLException
/*      */   {
/* 3566 */     updateOracleObject(paramInt, paramCHAR);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRAW(int paramInt, RAW paramRAW)
/*      */     throws SQLException
/*      */   {
/* 3573 */     updateOracleObject(paramInt, paramRAW);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBLOB(int paramInt, BLOB paramBLOB)
/*      */     throws SQLException
/*      */   {
/* 3580 */     updateOracleObject(paramInt, paramBLOB);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateCLOB(int paramInt, CLOB paramCLOB)
/*      */     throws SQLException
/*      */   {
/* 3587 */     updateOracleObject(paramInt, paramCLOB);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBFILE(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 3594 */     updateOracleObject(paramInt, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBfile(int paramInt, BFILE paramBFILE)
/*      */     throws SQLException
/*      */   {
/* 3601 */     updateOracleObject(paramInt, paramBFILE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum)
/*      */     throws SQLException
/*      */   {
/* 3609 */     throw new Error("wanna do datum = ((CustomDatum) x).toDatum(m_comm)");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateORAData(int paramInt, ORAData paramORAData)
/*      */     throws SQLException
/*      */   {
/* 3619 */     Datum localDatum = paramORAData.toDatum(this.connection);
/*      */     
/* 3621 */     updateOracleObject(paramInt, localDatum);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRef(int paramInt, Ref paramRef)
/*      */     throws SQLException
/*      */   {
/* 3628 */     updateREF(paramInt, (REF)paramRef);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(int paramInt, Blob paramBlob)
/*      */     throws SQLException
/*      */   {
/* 3635 */     updateBLOB(paramInt, (BLOB)paramBlob);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateClob(int paramInt, Clob paramClob)
/*      */     throws SQLException
/*      */   {
/* 3642 */     updateCLOB(paramInt, (CLOB)paramClob);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateArray(int paramInt, Array paramArray)
/*      */     throws SQLException
/*      */   {
/* 3649 */     updateARRAY(paramInt, (ARRAY)paramArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getColumnCount()
/*      */     throws SQLException
/*      */   {
/* 3663 */     if (this.columnCount == 0)
/*      */     {
/* 3665 */       if ((this.resultSet instanceof OracleResultSetImpl))
/*      */       {
/* 3667 */         if (((OracleResultSetImpl)this.resultSet).statement.accessors != null) {
/* 3668 */           this.columnCount = ((OracleResultSetImpl)this.resultSet).statement.numberOfDefinePositions;
/*      */         }
/*      */         else {
/* 3671 */           this.columnCount = getInternalMetadata().getColumnCount();
/*      */         }
/*      */       } else {
/* 3674 */         this.columnCount = ((ScrollableResultSet)this.resultSet).getColumnCount();
/*      */       }
/*      */     }
/* 3677 */     return this.columnCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ResultSetMetaData getInternalMetadata()
/*      */     throws SQLException
/*      */   {
/* 3687 */     if (this.rsetMetaData == null) {
/* 3688 */       this.rsetMetaData = this.resultSet.getMetaData();
/*      */     }
/* 3690 */     return this.rsetMetaData;
/*      */   }
/*      */   
/*      */   private void cancelRowChanges()
/*      */     throws SQLException
/*      */   {
/* 3696 */     synchronized (this.connection)
/*      */     {
/* 3698 */       if (this.isInserting) {
/* 3699 */         cancelRowInserts();
/*      */       }
/* 3701 */       if (this.isUpdating) {
/* 3702 */         cancelRowUpdates();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isOnInsertRow()
/*      */   {
/* 3713 */     return this.isInserting;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cancelRowInserts()
/*      */   {
/* 3723 */     if (this.isInserting)
/*      */     {
/* 3725 */       this.isInserting = false;
/*      */       
/* 3727 */       clearRowBuffer();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isUpdatingRow()
/*      */   {
/* 3738 */     return this.isUpdating;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void clearRowBuffer()
/*      */   {
/*      */     int i;
/*      */     
/*      */ 
/* 3748 */     if (this.rowBuffer != null)
/*      */     {
/* 3750 */       for (i = 0; i < this.rowBuffer.length; i++) {
/* 3751 */         this.rowBuffer[i] = null;
/*      */       }
/*      */     }
/* 3754 */     if (this.m_nullIndicator != null)
/*      */     {
/* 3756 */       for (i = 0; i < this.m_nullIndicator.length; i++) {
/* 3757 */         this.m_nullIndicator[i] = false;
/*      */       }
/*      */     }
/* 3760 */     if (this.typeInfo != null)
/*      */     {
/* 3762 */       for (i = 0; i < this.typeInfo.length; i++) {
/* 3763 */         if (this.typeInfo[i] != null) {
/* 3764 */           for (int j = 0; j < this.typeInfo[i].length; j++) {
/* 3765 */             this.typeInfo[i][j] = 0;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3771 */     cleanTempLobs();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setRowBufferAt(int paramInt, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 3782 */     setRowBufferAt(paramInt, paramDatum, (int[])null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setRowBufferAt(int paramInt, Object paramObject, int[] paramArrayOfInt)
/*      */     throws SQLException
/*      */   {
/*      */     SQLException localSQLException;
/*      */     
/*      */ 
/* 3793 */     if (!this.isInserting)
/*      */     {
/* 3795 */       if ((isBeforeFirst()) || (isAfterLast()) || (getRow() == 0))
/*      */       {
/* 3797 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3798 */         localSQLException.fillInStackTrace();
/* 3799 */         throw localSQLException;
/*      */       }
/*      */       
/* 3802 */       this.isUpdating = true;
/*      */     }
/*      */     
/* 3805 */     if ((paramInt < 1) || (paramInt > getColumnCount() - 1))
/*      */     {
/* 3807 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setRowBufferAt");
/* 3808 */       localSQLException.fillInStackTrace();
/* 3809 */       throw localSQLException;
/*      */     }
/*      */     
/* 3812 */     if (this.rowBuffer == null) {
/* 3813 */       this.rowBuffer = new Object[getColumnCount()];
/*      */     }
/* 3815 */     if (this.m_nullIndicator == null)
/*      */     {
/* 3817 */       this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       
/* 3819 */       for (int i = 0; i < getColumnCount(); i++) {
/* 3820 */         this.m_nullIndicator[i] = false;
/*      */       }
/*      */     }
/* 3823 */     if (paramArrayOfInt != null)
/*      */     {
/* 3825 */       if (this.typeInfo == null)
/*      */       {
/* 3827 */         this.typeInfo = new int[getColumnCount()][];
/*      */       }
/*      */       
/* 3830 */       this.typeInfo[paramInt] = paramArrayOfInt;
/*      */     }
/*      */     
/* 3833 */     this.rowBuffer[paramInt] = paramObject;
/* 3834 */     this.m_nullIndicator[paramInt] = (paramObject == null ? 1 : false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Datum getRowBufferDatumAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3844 */     if ((paramInt < 1) || (paramInt > getColumnCount() - 1))
/*      */     {
/* 3846 */       localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 3847 */       ((SQLException)localObject1).fillInStackTrace();
/* 3848 */       throw ((Throwable)localObject1);
/*      */     }
/*      */     
/* 3851 */     Object localObject1 = null;
/*      */     
/* 3853 */     if (this.rowBuffer != null)
/*      */     {
/* 3855 */       Object localObject2 = this.rowBuffer[paramInt];
/*      */       
/* 3857 */       if (localObject2 != null)
/*      */       {
/* 3859 */         if ((localObject2 instanceof Datum))
/*      */         {
/* 3861 */           localObject1 = (Datum)localObject2;
/*      */         }
/*      */         else
/*      */         {
/* 3865 */           OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3866 */           int i = paramInt + 1;
/* 3867 */           localObject1 = SQLUtil.makeOracleDatum(this.connection, localObject2, localOracleResultSetMetaData.getColumnType(i), null, localOracleResultSetMetaData.isNCHAR(i));
/*      */           
/*      */ 
/*      */ 
/* 3871 */           this.rowBuffer[paramInt] = localObject1;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3876 */     return (Datum)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object getRowBufferAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 3886 */     if ((paramInt < 1) || (paramInt > getColumnCount() - 1))
/*      */     {
/* 3888 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 3889 */       localSQLException.fillInStackTrace();
/* 3890 */       throw localSQLException;
/*      */     }
/*      */     
/* 3893 */     if (this.rowBuffer != null)
/*      */     {
/* 3895 */       return this.rowBuffer[paramInt];
/*      */     }
/*      */     
/* 3898 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isRowBufferUpdatedAt(int paramInt)
/*      */   {
/* 3905 */     if (this.rowBuffer == null) {
/* 3906 */       return false;
/*      */     }
/* 3908 */     return (this.rowBuffer[paramInt] != null) || (this.m_nullIndicator[paramInt] != 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareInsertRowStatement()
/*      */     throws SQLException
/*      */   {
/* 3918 */     if (this.insertStmt == null)
/*      */     {
/*      */ 
/* 3921 */       PreparedStatement localPreparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getInsertSqlForUpdatableResultSet(this));
/*      */       
/*      */ 
/*      */ 
/* 3925 */       this.insertStmt = ((OraclePreparedStatement)((OraclePreparedStatementWrapper)localPreparedStatement).preparedStatement);
/* 3926 */       this.insertStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3927 */       if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3928 */         this.insertStmt.setEscapeProcessing(true);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareInsertRowBinds()
/*      */     throws SQLException
/*      */   {
/* 3940 */     int i = 1;
/*      */     
/*      */ 
/* 3943 */     i = prepareSubqueryBinds(this.insertStmt, i);
/*      */     
/* 3945 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 3947 */     for (int j = 1; j < getColumnCount(); j++)
/*      */     {
/* 3949 */       Object localObject = getRowBufferAt(j);
/*      */       
/* 3951 */       if (localObject != null)
/*      */       {
/* 3953 */         if ((localObject instanceof Reader))
/*      */         {
/* 3955 */           if (localOracleResultSetMetaData.isNCHAR(j + 1))
/* 3956 */             this.insertStmt.setFormOfUse(i, (short)2);
/* 3957 */           this.insertStmt.setCharacterStream(i + j - 1, (Reader)localObject, this.typeInfo[j][0]);
/*      */ 
/*      */         }
/* 3960 */         else if ((localObject instanceof InputStream))
/*      */         {
/* 3962 */           if (this.typeInfo[j][1] == 2) {
/* 3963 */             this.insertStmt.setBinaryStream(i + j - 1, (InputStream)localObject, this.typeInfo[j][0]);
/*      */ 
/*      */           }
/* 3966 */           else if (this.typeInfo[j][1] == 1) {
/* 3967 */             this.insertStmt.setAsciiStream(i + j - 1, (InputStream)localObject, this.typeInfo[j][0]);
/*      */           }
/*      */           
/*      */         }
/*      */         else
/*      */         {
/* 3973 */           Datum localDatum = getRowBufferDatumAt(j);
/*      */           
/* 3975 */           if (localOracleResultSetMetaData.isNCHAR(j + 1))
/* 3976 */             this.insertStmt.setFormOfUse(i + j - 1, (short)2);
/* 3977 */           this.insertStmt.setOracleObject(i + j - 1, localDatum);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 3983 */         int k = getInternalMetadata().getColumnType(j + 1);
/*      */         
/* 3985 */         if ((k == 2006) || (k == 2002) || (k == 2008) || (k == 2007) || (k == 2003) || (k == 2009))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3995 */           this.insertStmt.setNull(i + j - 1, k, getInternalMetadata().getColumnTypeName(j + 1));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 4000 */           this.insertStmt.setNull(i + j - 1, k);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void executeInsertRow()
/*      */     throws SQLException
/*      */   {
/* 4013 */     if (this.insertStmt.executeUpdate() != 1)
/*      */     {
/* 4015 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 4016 */       localSQLException.fillInStackTrace();
/* 4017 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getNumColumnsChanged()
/*      */     throws SQLException
/*      */   {
/* 4030 */     int i = 0;
/*      */     
/* 4032 */     if (this.indexColsChanged == null) {
/* 4033 */       this.indexColsChanged = new int[getColumnCount()];
/*      */     }
/* 4035 */     if (this.rowBuffer != null)
/*      */     {
/* 4037 */       for (int j = 1; j < getColumnCount(); j++)
/*      */       {
/* 4039 */         if ((this.rowBuffer[j] != null) || ((this.rowBuffer[j] == null) && (this.m_nullIndicator[j] != 0)))
/*      */         {
/*      */ 
/* 4042 */           this.indexColsChanged[(i++)] = j;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4047 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareUpdateRowStatement(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4061 */     if (this.updateStmt != null) {
/* 4062 */       this.updateStmt.close();
/*      */     }
/* 4064 */     PreparedStatement localPreparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getUpdateSqlForUpdatableResultSet(this, paramInt, this.rowBuffer, this.indexColsChanged));
/*      */     
/*      */ 
/*      */ 
/* 4068 */     this.updateStmt = ((OraclePreparedStatement)((OraclePreparedStatementWrapper)localPreparedStatement).preparedStatement);
/* 4069 */     this.updateStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 4070 */     if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 4071 */       this.updateStmt.setEscapeProcessing(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareUpdateRowBinds(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4081 */     int i = 1;
/*      */     
/*      */ 
/* 4084 */     i = prepareSubqueryBinds(this.updateStmt, i);
/*      */     
/* 4086 */     OracleResultSetMetaData localOracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 4088 */     for (int j = 0; j < paramInt; j++)
/*      */     {
/* 4090 */       int k = this.indexColsChanged[j];
/* 4091 */       Object localObject = getRowBufferAt(k);
/*      */       
/* 4093 */       if (localObject != null)
/*      */       {
/* 4095 */         if ((localObject instanceof Reader))
/*      */         {
/* 4097 */           if (localOracleResultSetMetaData.isNCHAR(k + 1))
/* 4098 */             this.updateStmt.setFormOfUse(i, (short)2);
/* 4099 */           this.updateStmt.setCharacterStream(i++, (Reader)localObject, this.typeInfo[k][0]);
/*      */ 
/*      */         }
/* 4102 */         else if ((localObject instanceof InputStream))
/*      */         {
/* 4104 */           if (this.typeInfo[k][1] == 2)
/*      */           {
/*      */ 
/* 4107 */             this.updateStmt.setBinaryStream(i++, (InputStream)localObject, this.typeInfo[k][0]);
/*      */           }
/* 4109 */           else if (this.typeInfo[k][1] == 1)
/*      */           {
/* 4111 */             this.updateStmt.setAsciiStream(i++, (InputStream)localObject, this.typeInfo[k][0]);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 4116 */           Datum localDatum = getRowBufferDatumAt(k);
/*      */           
/* 4118 */           if (localOracleResultSetMetaData.isNCHAR(k + 1))
/* 4119 */             this.updateStmt.setFormOfUse(i, (short)2);
/* 4120 */           this.updateStmt.setOracleObject(i++, localDatum);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 4126 */         int m = getInternalMetadata().getColumnType(k + 1);
/*      */         
/* 4128 */         if ((m == 2006) || (m == 2002) || (m == 2008) || (m == 2007) || (m == 2003) || (m == 2009))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4137 */           this.updateStmt.setNull(i++, m, getInternalMetadata().getColumnTypeName(k + 1));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 4142 */           if (localOracleResultSetMetaData.isNCHAR(k + 1))
/* 4143 */             this.updateStmt.setFormOfUse(i, (short)2);
/* 4144 */           this.updateStmt.setNull(i++, m);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4150 */     prepareCompareSelfBinds(this.updateStmt, i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void executeUpdateRow()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 4162 */       if (this.updateStmt.executeUpdate() == 0)
/*      */       {
/* 4164 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 4165 */         localSQLException.fillInStackTrace();
/* 4166 */         throw localSQLException;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4171 */       if (this.isCachedRset)
/*      */       {
/*      */ 
/* 4174 */         ((ScrollableResultSet)this.resultSet).refreshRowsInCache(getRow(), 1, 1000);
/*      */         
/* 4176 */         cancelRowUpdates();
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 4186 */       if (this.updateStmt != null)
/*      */       {
/* 4188 */         this.updateStmt.close();
/*      */         
/* 4190 */         this.updateStmt = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareDeleteRowStatement()
/*      */     throws SQLException
/*      */   {
/* 4202 */     if (this.deleteStmt == null)
/*      */     {
/* 4204 */       PreparedStatement localPreparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getDeleteSqlForUpdatableResultSet(this));
/*      */       
/*      */ 
/* 4207 */       this.deleteStmt = ((OraclePreparedStatement)((OraclePreparedStatementWrapper)localPreparedStatement).preparedStatement);
/* 4208 */       this.deleteStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 4209 */       if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 4210 */         this.deleteStmt.setEscapeProcessing(true);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void prepareDeleteRowBinds()
/*      */     throws SQLException
/*      */   {
/* 4221 */     int i = 1;
/*      */     
/*      */ 
/* 4224 */     i = prepareSubqueryBinds(this.deleteStmt, i);
/*      */     
/*      */ 
/* 4227 */     prepareCompareSelfBinds(this.deleteStmt, i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void executeDeleteRow()
/*      */     throws SQLException
/*      */   {
/* 4239 */     if (this.deleteStmt.executeUpdate() == 0)
/*      */     {
/* 4241 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 4242 */       localSQLException.fillInStackTrace();
/* 4243 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4248 */     if (this.isCachedRset) {
/* 4249 */       ((ScrollableResultSet)this.resultSet).removeRowInCache(getRow());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int prepareCompareSelfBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4258 */     paramOraclePreparedStatement.setOracleObject(paramInt, this.resultSet.getOracleObject(1));
/*      */     
/* 4260 */     return paramInt + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int prepareSubqueryBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 4268 */     int i = this.scrollStmt.copyBinds(paramOraclePreparedStatement, paramInt - 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4283 */     return i + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setIsNull(int paramInt)
/*      */   {
/* 4290 */     this.wasNull = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void setIsNull(boolean paramBoolean)
/*      */   {
/* 4297 */     if (paramBoolean) {
/* 4298 */       this.wasNull = 1;
/*      */     } else {
/* 4300 */       this.wasNull = 2;
/*      */     }
/*      */   }
/*      */   
/*      */   public String getCursorName() throws SQLException
/*      */   {
/* 4306 */     synchronized (this.connection)
/*      */     {
/*      */ 
/* 4309 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 4310 */       localSQLException.fillInStackTrace();
/* 4311 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 4328 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleStatement getOracleStatement()
/*      */     throws SQLException
/*      */   {
/* 4339 */     return this.resultSet == null ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 4344 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\UpdatableResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */