/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.internal.OracleStatement.SqlKind;
/*    */ import oracle.sql.ROWID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VarcharAccessor
/*    */   extends CharCommonAccessor
/*    */ {
/*    */   VarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean)
/*    */     throws SQLException
/*    */   {
/* 24 */     int i = 4000;
/*    */     
/* 26 */     if (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
/* 27 */       i = 32766;
/*    */     }
/* 29 */     init(paramOracleStatement, 1, 9, paramInt1, paramShort, paramInt2, paramBoolean, i, 2000);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   VarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort)
/*    */     throws SQLException
/*    */   {
/* 43 */     int i = 4000;
/*    */     
/* 45 */     if (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
/* 46 */       i = 32766;
/*    */     }
/* 48 */     init(paramOracleStatement, 1, 9, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, i, 2000);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ROWID getROWID(int paramInt)
/*    */     throws SQLException
/*    */   {
/* 62 */     if (this.rowSpaceIndicator == null)
/*    */     {
/*    */ 
/*    */ 
/* 66 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 67 */       ((SQLException)localObject).fillInStackTrace();
/* 68 */       throw ((Throwable)localObject);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 73 */     Object localObject = null;
/*    */     
/* 75 */     if (this.rowSpaceIndicator[(this.indicatorIndex + paramInt)] != -1)
/*    */     {
/* 77 */       byte[] arrayOfByte = getBytesInternal(paramInt);
/* 78 */       if (arrayOfByte != null)
/* 79 */         localObject = new ROWID(arrayOfByte);
/*    */     }
/* 81 */     return (ROWID)localObject;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 86 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\driver\VarcharAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */