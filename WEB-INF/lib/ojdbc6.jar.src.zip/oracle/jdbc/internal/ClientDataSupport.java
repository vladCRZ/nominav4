package oracle.jdbc.internal;

public abstract interface ClientDataSupport
{
  public abstract Object getClientData(Object paramObject);
  
  public abstract Object setClientData(Object paramObject1, Object paramObject2);
  
  public abstract Object removeClientData(Object paramObject);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\internal\ClientDataSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */