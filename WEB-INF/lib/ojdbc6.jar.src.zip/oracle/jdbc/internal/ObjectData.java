package oracle.jdbc.internal;

public abstract interface ObjectData {}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\internal\ObjectData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */