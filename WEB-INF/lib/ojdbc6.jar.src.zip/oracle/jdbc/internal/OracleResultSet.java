package oracle.jdbc.internal;

import java.sql.SQLException;

public abstract interface OracleResultSet
  extends oracle.jdbc.OracleResultSet
{
  public abstract void closeStatementOnClose()
    throws SQLException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\internal\OracleResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */