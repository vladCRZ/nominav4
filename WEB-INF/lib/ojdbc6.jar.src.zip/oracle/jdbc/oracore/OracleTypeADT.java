/*      */ package oracle.jdbc.oracore;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringWriter;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.ObjectData;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.AttributeDescriptor;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.JAVA_STRUCT;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleTypeADT
/*      */   extends OracleNamedType
/*      */   implements Serializable
/*      */ {
/*      */   static final long serialVersionUID = 3031304012507165702L;
/*      */   static final int S_TOP = 1;
/*      */   static final int S_EMBEDDED = 2;
/*      */   static final int S_UPT_ADT = 4;
/*      */   static final int S_JAVA_OBJECT = 16;
/*      */   static final int S_FINAL_TYPE = 32;
/*      */   static final int S_SUB_TYPE = 64;
/*      */   static final int S_ATTR_TDS = 128;
/*      */   static final int S_HAS_METADATA = 256;
/*      */   static final int S_TDS_PARSED = 512;
/*   61 */   private int statusBits = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   68 */   int tdsVersion = 55537;
/*      */   
/*      */   static final int KOPT_V80 = 1;
/*      */   
/*      */   static final int KOPT_V81 = 2;
/*      */   
/*      */   static final int KOPT_VNFT = 3;
/*      */   
/*      */   static final int KOPT_VERSION = 3;
/*      */   
/*   78 */   boolean endOfAdt = false;
/*      */   
/*   80 */   int typeVersion = 1;
/*      */   
/*      */ 
/*   83 */   long fixedDataSize = -1L;
/*   84 */   int alignmentRequirement = -1;
/*      */   
/*      */ 
/*   87 */   OracleType[] attrTypes = null;
/*      */   
/*      */   String[] attrNames;
/*      */   String[] attrTypeNames;
/*   91 */   public long tdoCState = 0L;
/*      */   
/*   93 */   byte[] toid = null;
/*      */   
/*      */   int charSetId;
/*      */   
/*      */   int charSetForm;
/*      */   
/*      */   int flattenedAttrNum;
/*      */   
/*      */   transient int opcode;
/*  102 */   transient int idx = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  109 */   boolean isTransient = false;
/*      */   
/*      */   static final int CURRENT_USER_OBJECT = 0;
/*      */   static final int CURRENT_USER_SYNONYM = 1;
/*      */   static final int CURRENT_USER_SYNONYM_10g = 2;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT = 5;
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
/*      */   static final int OTHER_USER_OBJECT = 7;
/*      */   static final int OTHER_USER_SYNONYM = 8;
/*      */   static final int PUBLIC_SYNONYM = 9;
/*      */   static final int PUBLIC_SYNONYM_10g = 10;
/*      */   static final int BREAK = 11;
/*      */   
/*      */   protected OracleTypeADT() {}
/*      */   
/*      */   public OracleTypeADT(byte[] paramArrayOfByte, int paramInt1, int paramInt2, short paramShort, String paramString)
/*      */     throws SQLException
/*      */   {
/*  129 */     this(paramString, (OracleConnection)null);
/*      */     
/*  131 */     this.toid = paramArrayOfByte;
/*  132 */     this.typeVersion = paramInt1;
/*  133 */     this.charSetId = paramInt2;
/*  134 */     this.charSetForm = paramShort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleTypeADT(String paramString, Connection paramConnection)
/*      */     throws SQLException
/*      */   {
/*  143 */     super(paramString, (OracleConnection)paramConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleTypeADT(OracleTypeADT paramOracleTypeADT, int paramInt, Connection paramConnection)
/*      */     throws SQLException
/*      */   {
/*  154 */     super(paramOracleTypeADT, paramInt, (OracleConnection)paramConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleTypeADT(SQLName paramSQLName, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  168 */     this.sqlName = paramSQLName;
/*  169 */     init(paramArrayOfByte2, paramOracleConnection);
/*  170 */     this.toid = paramArrayOfByte1;
/*  171 */     this.typeVersion = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleTypeADT(AttributeDescriptor[] paramArrayOfAttributeDescriptor, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  191 */     setConnectionInternal(paramOracleConnection);
/*  192 */     this.isTransient = true;
/*  193 */     this.flattenedAttrNum = paramArrayOfAttributeDescriptor.length;
/*  194 */     this.attrTypes = new OracleType[this.flattenedAttrNum];
/*  195 */     this.attrNames = new String[this.flattenedAttrNum];
/*  196 */     for (int i = 0; i < this.flattenedAttrNum; i++)
/*  197 */       this.attrNames[i] = paramArrayOfAttributeDescriptor[i].getAttributeName();
/*  198 */     this.statusBits |= 0x100;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  204 */     for (i = 0; i < this.flattenedAttrNum; i++)
/*      */     {
/*  206 */       TypeDescriptor localTypeDescriptor = paramArrayOfAttributeDescriptor[i].getTypeDescriptor();
/*  207 */       switch (localTypeDescriptor.getInternalTypeCode())
/*      */       {
/*      */       case 12: 
/*  210 */         this.attrTypes[i] = new OracleTypeDATE();
/*  211 */         break;
/*      */       case 9: 
/*  213 */         this.attrTypes[i] = new OracleTypeCHAR(this.connection, 12);
/*  214 */         ((OracleTypeCHAR)this.attrTypes[i]).length = ((int)localTypeDescriptor.getPrecision());
/*  215 */         ((OracleTypeCHAR)this.attrTypes[i]).form = 1;
/*  216 */         break;
/*      */       case 96: 
/*  218 */         this.attrTypes[i] = new OracleTypeCHAR(this.connection, 1);
/*  219 */         ((OracleTypeCHAR)this.attrTypes[i]).length = ((int)localTypeDescriptor.getPrecision());
/*  220 */         ((OracleTypeCHAR)this.attrTypes[i]).form = 1;
/*  221 */         break;
/*      */       case 108: 
/*  223 */         this.attrTypes[i] = ((OracleTypeADT)localTypeDescriptor.getPickler());
/*  224 */         ((OracleTypeADT)this.attrTypes[i]).setEmbeddedADT();
/*  225 */         break;
/*      */       case 2: 
/*  227 */         this.attrTypes[i] = new OracleTypeNUMBER(2);
/*  228 */         ((OracleTypeNUMBER)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  229 */         ((OracleTypeNUMBER)this.attrTypes[i]).scale = localTypeDescriptor.getScale();
/*  230 */         break;
/*      */       case 7: 
/*  232 */         this.attrTypes[i] = new OracleTypeNUMBER(3);
/*  233 */         ((OracleTypeNUMBER)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  234 */         ((OracleTypeNUMBER)this.attrTypes[i]).scale = localTypeDescriptor.getScale();
/*  235 */         break;
/*      */       case 22: 
/*  237 */         this.attrTypes[i] = new OracleTypeNUMBER(8);
/*  238 */         ((OracleTypeNUMBER)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  239 */         ((OracleTypeNUMBER)this.attrTypes[i]).scale = localTypeDescriptor.getScale();
/*  240 */         break;
/*      */       case 4: 
/*  242 */         this.attrTypes[i] = new OracleTypeFLOAT();
/*  243 */         ((OracleTypeFLOAT)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  244 */         break;
/*      */       case 100: 
/*  246 */         this.attrTypes[i] = new OracleTypeBINARY_FLOAT();
/*  247 */         break;
/*      */       case 101: 
/*  249 */         this.attrTypes[i] = new OracleTypeBINARY_DOUBLE();
/*  250 */         break;
/*      */       
/*      */       case 29: 
/*  253 */         this.attrTypes[i] = new OracleTypeSINT32();
/*  254 */         break;
/*      */       
/*      */       case 110: 
/*  257 */         this.attrTypes[i] = new OracleTypeREF(this, i, this.connection);
/*  258 */         break;
/*      */       case 114: 
/*  260 */         this.attrTypes[i] = new OracleTypeBFILE(this.connection);
/*  261 */         break;
/*      */       case 95: 
/*  263 */         this.attrTypes[i] = new OracleTypeRAW();
/*  264 */         break;
/*      */       case 112: 
/*  266 */         this.attrTypes[i] = new OracleTypeCLOB(this.connection);
/*  267 */         break;
/*      */       case 113: 
/*  269 */         this.attrTypes[i] = new OracleTypeBLOB(this.connection);
/*  270 */         break;
/*      */       case 187: 
/*  272 */         this.attrTypes[i] = new OracleTypeTIMESTAMP(this.connection);
/*  273 */         ((OracleTypeTIMESTAMP)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  274 */         break;
/*      */       case 188: 
/*  276 */         this.attrTypes[i] = new OracleTypeTIMESTAMPTZ(this.connection);
/*  277 */         ((OracleTypeTIMESTAMPTZ)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  278 */         break;
/*      */       case 232: 
/*  280 */         this.attrTypes[i] = new OracleTypeTIMESTAMPLTZ(this.connection);
/*  281 */         ((OracleTypeTIMESTAMPLTZ)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  282 */         break;
/*      */       case 189: 
/*  284 */         this.attrTypes[i] = new OracleTypeINTERVAL(this.connection);
/*  285 */         ((OracleTypeINTERVAL)this.attrTypes[i]).typeId = 7;
/*  286 */         ((OracleTypeINTERVAL)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  287 */         ((OracleTypeINTERVAL)this.attrTypes[i]).scale = localTypeDescriptor.getScale();
/*  288 */         break;
/*      */       case 190: 
/*  290 */         this.attrTypes[i] = new OracleTypeINTERVAL(this.connection);
/*  291 */         ((OracleTypeINTERVAL)this.attrTypes[i]).typeId = 10;
/*  292 */         ((OracleTypeINTERVAL)this.attrTypes[i]).precision = ((int)localTypeDescriptor.getPrecision());
/*  293 */         ((OracleTypeINTERVAL)this.attrTypes[i]).scale = localTypeDescriptor.getScale();
/*  294 */         break;
/*      */       case 122: 
/*  296 */         this.attrTypes[i] = new OracleTypeCOLLECTION(this, i, this.connection);
/*  297 */         break;
/*      */       
/*      */       default: 
/*  300 */         SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, "type: " + localTypeDescriptor.getInternalTypeCode());
/*  301 */         localSQLException.fillInStackTrace();
/*  302 */         throw localSQLException;
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  320 */     if (paramObject != null)
/*      */     {
/*  322 */       if ((paramObject instanceof STRUCT))
/*      */       {
/*  324 */         return (STRUCT)paramObject;
/*      */       }
/*  326 */       if (((paramObject instanceof SQLData)) || ((paramObject instanceof ObjectData)))
/*      */       {
/*      */ 
/*  329 */         return STRUCT.toSTRUCT(paramObject, paramOracleConnection);
/*      */       }
/*  331 */       if ((paramObject instanceof Object[]))
/*      */       {
/*  333 */         localObject = createStructDescriptor();
/*  334 */         STRUCT localSTRUCT = createObjSTRUCT((StructDescriptor)localObject, (Object[])paramObject);
/*  335 */         return localSTRUCT;
/*      */       }
/*      */       
/*      */ 
/*  339 */       Object localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  340 */       ((SQLException)localObject).fillInStackTrace();
/*  341 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*  345 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt)
/*      */     throws SQLException
/*      */   {
/*  359 */     Datum[] arrayOfDatum = null;
/*      */     
/*  361 */     if (paramObject != null) {
/*      */       Object localObject;
/*  363 */       if ((paramObject instanceof Object[]))
/*      */       {
/*  365 */         localObject = (Object[])paramObject;
/*      */         
/*  367 */         int i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*      */         
/*      */ 
/*  370 */         arrayOfDatum = new Datum[i];
/*      */         
/*  372 */         for (int j = 0; j < i; j++) {
/*  373 */           arrayOfDatum[j] = toDatum(localObject[((int)paramLong + j - 1)], paramOracleConnection);
/*      */         }
/*      */       }
/*      */       else {
/*  377 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  378 */         ((SQLException)localObject).fillInStackTrace();
/*  379 */         throw ((Throwable)localObject);
/*      */       }
/*      */     }
/*      */     
/*  383 */     return arrayOfDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTypeCode()
/*      */     throws SQLException
/*      */   {
/*  393 */     if ((getStatus() & 0x10) != 0) {
/*  394 */       return 2008;
/*      */     }
/*  396 */     return 2002;
/*      */   }
/*      */   
/*      */ 
/*      */   public OracleType[] getAttrTypes()
/*      */     throws SQLException
/*      */   {
/*  403 */     if (this.attrTypes == null) {
/*  404 */       init(this.connection);
/*      */     }
/*  406 */     return this.attrTypes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isInHierarchyOf(OracleType paramOracleType)
/*      */     throws SQLException
/*      */   {
/*  417 */     if (paramOracleType == null) {
/*  418 */       return false;
/*      */     }
/*  420 */     if (!paramOracleType.isObjectType()) {
/*  421 */       return false;
/*      */     }
/*  423 */     StructDescriptor localStructDescriptor = (StructDescriptor)paramOracleType.getTypeDescriptor();
/*      */     
/*      */ 
/*  426 */     return this.descriptor.isInHierarchyOf(localStructDescriptor.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor)
/*      */     throws SQLException
/*      */   {
/*  435 */     if (paramStructDescriptor == null) {
/*  436 */       return false;
/*      */     }
/*  438 */     return this.descriptor.isInHierarchyOf(paramStructDescriptor.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isObjectType()
/*      */   {
/*  445 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TypeDescriptor getTypeDescriptor()
/*      */   {
/*  452 */     return this.descriptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  468 */     synchronized (paramOracleConnection)
/*      */     {
/*  470 */       byte[] arrayOfByte = initMetadata(paramOracleConnection);
/*  471 */       init(arrayOfByte, paramOracleConnection);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(byte[] paramArrayOfByte, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  485 */     synchronized (paramOracleConnection)
/*      */     {
/*  487 */       this.statusBits = 1;
/*  488 */       this.connection = paramOracleConnection;
/*      */       
/*  490 */       if (paramArrayOfByte != null) parseTDS(paramArrayOfByte, 0L);
/*  491 */       setStatusBits(256);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] initMetadata(OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  509 */     synchronized (this.connection)
/*      */     {
/*  511 */       byte[] arrayOfByte = null;
/*  512 */       if ((this.statusBits & 0x100) != 0) { return null;
/*      */       }
/*      */       
/*  515 */       if (this.sqlName == null) { getFullName();
/*      */       }
/*      */       
/*  518 */       if ((this.statusBits & 0x100) == 0)
/*      */       {
/*  520 */         CallableStatement localCallableStatement = null;
/*      */         try
/*      */         {
/*  523 */           if (this.tdoCState == 0L) { this.tdoCState = this.connection.getTdoCState(this.sqlName.getSchema(), this.sqlName.getSimpleName());
/*      */           }
/*      */           
/*      */ 
/*  527 */           String str = "begin :1 := dbms_pickler.get_type_shape(:2,:3,:4,:5,:6,:7); end;";
/*      */           
/*      */ 
/*      */ 
/*  531 */           int i = 0;
/*  532 */           localCallableStatement = this.connection.prepareCall(str);
/*      */           
/*  534 */           localCallableStatement.registerOutParameter(1, 2);
/*  535 */           localCallableStatement.registerOutParameter(4, -4);
/*  536 */           localCallableStatement.registerOutParameter(5, 4);
/*  537 */           localCallableStatement.registerOutParameter(6, -4);
/*  538 */           localCallableStatement.registerOutParameter(7, -4);
/*  539 */           localCallableStatement.setString(2, this.sqlName.getSchema());
/*  540 */           localCallableStatement.setString(3, this.sqlName.getSimpleName());
/*      */           
/*      */ 
/*      */ 
/*  544 */           localCallableStatement.execute();
/*      */           
/*      */ 
/*  547 */           int j = localCallableStatement.getInt(1);
/*  548 */           Object localObject1; if (j != 0)
/*      */           {
/*      */ 
/*  551 */             if (j != 24331)
/*      */             {
/*  553 */               localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, this.sqlName.toString());
/*  554 */               ((SQLException)localObject1).fillInStackTrace();
/*  555 */               throw ((Throwable)localObject1);
/*      */             }
/*  557 */             if (j == 24331)
/*      */             {
/*  559 */               i = 1;
/*  560 */               localCallableStatement.registerOutParameter(6, 2004);
/*      */               
/*      */ 
/*  563 */               localCallableStatement.execute();
/*      */               
/*      */ 
/*  566 */               j = localCallableStatement.getInt(1);
/*  567 */               if (j != 0)
/*      */               {
/*      */ 
/*  570 */                 localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, this.sqlName.toString());
/*  571 */                 ((SQLException)localObject1).fillInStackTrace();
/*  572 */                 throw ((Throwable)localObject1);
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  579 */           this.toid = localCallableStatement.getBytes(4);
/*  580 */           this.typeVersion = NUMBER.toInt(localCallableStatement.getBytes(5));
/*  581 */           if (i == 0)
/*      */           {
/*  583 */             arrayOfByte = localCallableStatement.getBytes(6);
/*      */           }
/*      */           else
/*      */           {
/*      */             try
/*      */             {
/*      */ 
/*  590 */               Blob localBlob = ((OracleCallableStatement)localCallableStatement).getBlob(6);
/*  591 */               localObject1 = localBlob.getBinaryStream();
/*  592 */               arrayOfByte = new byte[(int)localBlob.length()];
/*  593 */               ((InputStream)localObject1).read(arrayOfByte);
/*  594 */               ((InputStream)localObject1).close();
/*  595 */               ((BLOB)localBlob).freeTemporary();
/*      */             }
/*      */             catch (IOException localIOException)
/*      */             {
/*  599 */               SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), localIOException);
/*  600 */               localSQLException.fillInStackTrace();
/*  601 */               throw localSQLException;
/*      */             }
/*      */           }
/*      */           
/*  605 */           this.metaDataInitialized = true;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  611 */           this.flattenedAttrNum = (Util.getUnsignedByte(arrayOfByte[8]) * 256 + Util.getUnsignedByte(arrayOfByte[9]));
/*      */           
/*  613 */           localCallableStatement.getBytes(7);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/*      */ 
/*  622 */           if (localCallableStatement != null) localCallableStatement.close();
/*      */         }
/*      */       }
/*  625 */       setStatusBits(256);
/*  626 */       return arrayOfByte;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   TDSReader parseTDS(byte[] paramArrayOfByte, long paramLong)
/*      */     throws SQLException
/*      */   {
/*  635 */     if (this.attrTypes != null) {
/*  636 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  641 */     TDSReader localTDSReader = new TDSReader(paramArrayOfByte, paramLong);
/*      */     
/*      */ 
/*  644 */     long l1 = localTDSReader.readLong() + localTDSReader.offset();
/*      */     
/*      */ 
/*      */ 
/*  648 */     localTDSReader.checkNextByte((byte)38);
/*      */     
/*      */ 
/*  651 */     this.tdsVersion = localTDSReader.readByte();
/*      */     
/*      */ 
/*  654 */     localTDSReader.skipBytes(2);
/*      */     
/*      */ 
/*  657 */     this.flattenedAttrNum = localTDSReader.readUB2();
/*      */     
/*      */ 
/*  660 */     if ((localTDSReader.readByte() & 0xFF) == 255) {
/*  661 */       setStatusBits(128);
/*      */     }
/*      */     
/*      */ 
/*  665 */     long l2 = localTDSReader.offset();
/*      */     
/*      */ 
/*  668 */     localTDSReader.checkNextByte((byte)41);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  673 */     if (localTDSReader.readUB2() != 0)
/*      */     {
/*  675 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/*  676 */       localSQLException.fillInStackTrace();
/*  677 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  682 */     long l3 = localTDSReader.readLong();
/*      */     
/*      */ 
/*  685 */     parseTDSrec(localTDSReader);
/*      */     
/*      */ 
/*  688 */     if (this.tdsVersion >= 3)
/*      */     {
/*      */ 
/*      */ 
/*  692 */       localTDSReader.skip_to(l2 + l3 + 2L);
/*      */       
/*      */ 
/*  695 */       localTDSReader.skipBytes(2 * this.flattenedAttrNum);
/*      */       
/*      */ 
/*  698 */       byte b = localTDSReader.readByte();
/*      */       
/*      */ 
/*  701 */       if (localTDSReader.isJavaObject(this.tdsVersion, b)) {
/*  702 */         setStatusBits(16);
/*      */       }
/*      */       
/*      */ 
/*  706 */       if (localTDSReader.isFinalType(this.tdsVersion, b)) {
/*  707 */         setStatusBits(32);
/*      */       }
/*      */       
/*      */ 
/*  711 */       if (localTDSReader.readByte() != 1) {
/*  712 */         setStatusBits(64);
/*      */       }
/*      */     }
/*      */     else {
/*  716 */       setStatusBits(32);
/*      */     }
/*      */     
/*  719 */     localTDSReader.skip_to(l1);
/*  720 */     return localTDSReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void parseTDSrec(TDSReader paramTDSReader)
/*      */     throws SQLException
/*      */   {
/*  728 */     Vector localVector = new Vector(5);
/*  729 */     OracleType localOracleType = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  739 */     this.idx = 1;
/*      */     
/*  741 */     while ((localOracleType = getNextTypeObject(paramTDSReader)) != null)
/*      */     {
/*  743 */       localVector.addElement(localOracleType);
/*      */     }
/*      */     
/*      */ 
/*  747 */     if (this.opcode == 42)
/*      */     {
/*  749 */       this.endOfAdt = true;
/*      */       
/*  751 */       applyTDSpatches(paramTDSReader);
/*      */     }
/*      */     
/*  754 */     this.attrTypes = new OracleType[localVector.size()];
/*      */     
/*  756 */     localVector.copyInto(this.attrTypes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void applyTDSpatches(TDSReader paramTDSReader)
/*      */     throws SQLException
/*      */   {
/*  766 */     TDSPatch localTDSPatch = paramTDSReader.getNextPatch();
/*      */     
/*  768 */     while (localTDSPatch != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  773 */       paramTDSReader.moveToPatchPos(localTDSPatch);
/*      */       
/*  775 */       int i = localTDSPatch.getType();
/*      */       
/*  777 */       if (i == 0)
/*      */       {
/*      */ 
/*      */ 
/*  781 */         paramTDSReader.readByte();
/*      */         
/*  783 */         int j = localTDSPatch.getUptTypeCode();
/*      */         Object localObject2;
/*  785 */         Object localObject3; switch (j)
/*      */         {
/*      */ 
/*      */ 
/*      */         case -6: 
/*  790 */           paramTDSReader.readLong();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case -5: 
/*  797 */           localObject2 = localTDSPatch.getOwner();
/*  798 */           localObject3 = null;
/*      */           
/*  800 */           if (((OracleNamedType)localObject2).hasName())
/*      */           {
/*  802 */             localObject3 = new OracleTypeADT(((OracleNamedType)localObject2).getFullName(), this.connection);
/*      */           }
/*      */           else
/*      */           {
/*  806 */             localObject3 = new OracleTypeADT(((OracleNamedType)localObject2).getParent(), ((OracleNamedType)localObject2).getOrder(), this.connection);
/*      */           }
/*      */           
/*      */ 
/*  810 */           ((OracleTypeADT)localObject3).setUptADT();
/*  811 */           TDSReader localTDSReader = ((OracleTypeADT)localObject3).parseTDS(paramTDSReader.tds(), paramTDSReader.absoluteOffset());
/*      */           
/*  813 */           paramTDSReader.skipBytes((int)localTDSReader.offset());
/*  814 */           localTDSPatch.apply(((OracleTypeADT)localObject3).cleanup());
/*      */           
/*      */ 
/*  817 */           break;
/*      */         
/*      */ 
/*      */         case 58: 
/*  821 */           localObject2 = localTDSPatch.getOwner();
/*  822 */           localObject3 = null;
/*      */           
/*  824 */           if (((OracleNamedType)localObject2).hasName())
/*      */           {
/*  826 */             localObject3 = new OracleTypeOPAQUE(((OracleNamedType)localObject2).getFullName(), this.connection);
/*      */           }
/*      */           else
/*      */           {
/*  830 */             localObject3 = new OracleTypeOPAQUE(((OracleNamedType)localObject2).getParent(), ((OracleNamedType)localObject2).getOrder(), this.connection);
/*      */           }
/*      */           
/*      */ 
/*  834 */           ((OracleTypeOPAQUE)localObject3).parseTDSrec(paramTDSReader);
/*  835 */           localTDSPatch.apply((OracleType)localObject3);
/*      */           
/*      */ 
/*  838 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         default: 
/*  843 */           localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  844 */           ((SQLException)localObject2).fillInStackTrace();
/*  845 */           throw ((Throwable)localObject2);
/*      */         }
/*      */         
/*      */       } else {
/*      */         Object localObject1;
/*  850 */         if (i == 1)
/*      */         {
/*      */ 
/*      */ 
/*  854 */           localObject1 = getNextTypeObject(paramTDSReader);
/*      */           
/*      */ 
/*      */ 
/*  858 */           localTDSPatch.apply((OracleType)localObject1, this.opcode);
/*      */         }
/*      */         else
/*      */         {
/*  862 */           localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/*  863 */           ((SQLException)localObject1).fillInStackTrace();
/*  864 */           throw ((Throwable)localObject1);
/*      */         }
/*      */       }
/*  867 */       localTDSPatch = paramTDSReader.getNextPatch();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleNamedType cleanup()
/*      */   {
/*  878 */     synchronized (this.connection) {
/*      */       Object localObject1;
/*  880 */       if ((this.attrTypes.length == 1) && ((this.attrTypes[0] instanceof OracleTypeCOLLECTION)))
/*      */       {
/*      */ 
/*      */ 
/*  884 */         localObject1 = (OracleTypeCOLLECTION)this.attrTypes[0];
/*      */         
/*  886 */         ((OracleTypeCOLLECTION)localObject1).copy_properties(this);
/*      */         
/*  888 */         return (OracleNamedType)localObject1;
/*      */       }
/*  890 */       if ((this.attrTypes.length == 1) && ((this.statusBits & 0x80) != 0) && ((this.attrTypes[0] instanceof OracleTypeUPT)) && ((((OracleTypeUPT)this.attrTypes[0]).realType instanceof OracleTypeOPAQUE)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  895 */         localObject1 = (OracleTypeOPAQUE)((OracleTypeUPT)this.attrTypes[0]).realType;
/*      */         
/*      */ 
/*  898 */         ((OracleTypeOPAQUE)localObject1).copy_properties(this);
/*      */         
/*  900 */         return (OracleNamedType)localObject1;
/*      */       }
/*      */       
/*  903 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void copy_properties(OracleTypeADT paramOracleTypeADT)
/*      */   {
/*  911 */     this.sqlName = paramOracleTypeADT.sqlName;
/*  912 */     this.parent = paramOracleTypeADT.parent;
/*  913 */     this.idx = paramOracleTypeADT.idx;
/*  914 */     this.connection = paramOracleTypeADT.connection;
/*  915 */     this.toid = paramOracleTypeADT.toid;
/*  916 */     this.tdsVersion = paramOracleTypeADT.tdsVersion;
/*  917 */     this.typeVersion = paramOracleTypeADT.typeVersion;
/*  918 */     this.tdoCState = paramOracleTypeADT.tdoCState;
/*  919 */     this.endOfAdt = paramOracleTypeADT.endOfAdt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleType getNextTypeObject(TDSReader paramTDSReader)
/*      */     throws SQLException
/*      */   {
/*      */     for (;;)
/*      */     {
/*  934 */       this.opcode = paramTDSReader.readByte();
/*      */       
/*  936 */       if (this.opcode != 43)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  942 */         if (this.opcode != 44) {
/*      */           break;
/*      */         }
/*      */         
/*  946 */         byte b = paramTDSReader.readByte();
/*      */         
/*  948 */         if (paramTDSReader.isJavaObject(3, b)) {
/*  949 */           setStatusBits(16);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  961 */     switch (this.opcode)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 40: 
/*      */     case 42: 
/*  968 */       return null;
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/*  973 */       localObject = new OracleTypeDATE();
/*      */       
/*  975 */       ((OracleTypeDATE)localObject).parseTDSrec(paramTDSReader);
/*      */       
/*  977 */       this.idx += 1;
/*      */       
/*  979 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 7: 
/*  984 */       localObject = new OracleTypeCHAR(this.connection, 12);
/*      */       
/*      */ 
/*  987 */       ((OracleTypeCHAR)localObject).parseTDSrec(paramTDSReader);
/*      */       
/*  989 */       this.idx += 1;
/*      */       
/*  991 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/*  996 */       localObject = new OracleTypeCHAR(this.connection, 1);
/*      */       
/*  998 */       ((OracleTypeCHAR)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1000 */       this.idx += 1;
/*      */       
/* 1002 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 39: 
/* 1007 */       localObject = new OracleTypeADT(this, this.idx, this.connection);
/*      */       
/* 1009 */       ((OracleTypeADT)localObject).setEmbeddedADT();
/* 1010 */       ((OracleTypeADT)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1012 */       this.idx += 1;
/*      */       
/* 1014 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 6: 
/* 1019 */       localObject = new OracleTypeNUMBER(2);
/*      */       
/* 1021 */       ((OracleTypeNUMBER)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1023 */       this.idx += 1;
/*      */       
/* 1025 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 3: 
/* 1030 */       localObject = new OracleTypeNUMBER(3);
/*      */       
/* 1032 */       ((OracleTypeNUMBER)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1034 */       this.idx += 1;
/*      */       
/* 1036 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 4: 
/* 1041 */       localObject = new OracleTypeNUMBER(8);
/*      */       
/* 1043 */       ((OracleTypeNUMBER)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1045 */       this.idx += 1;
/*      */       
/* 1047 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 5: 
/* 1052 */       localObject = new OracleTypeFLOAT();
/*      */       
/* 1054 */       ((OracleTypeFLOAT)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1056 */       this.idx += 1;
/*      */       
/* 1058 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 37: 
/* 1063 */       localObject = new OracleTypeBINARY_FLOAT();
/*      */       
/* 1065 */       ((OracleTypeBINARY_FLOAT)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1067 */       this.idx += 1;
/*      */       
/* 1069 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 45: 
/* 1074 */       localObject = new OracleTypeBINARY_DOUBLE();
/*      */       
/* 1076 */       ((OracleTypeBINARY_DOUBLE)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1078 */       this.idx += 1;
/*      */       
/* 1080 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 1086 */       localObject = new OracleTypeSINT32();
/*      */       
/* 1088 */       ((OracleTypeSINT32)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1090 */       this.idx += 1;
/*      */       
/* 1092 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1098 */       localObject = new OracleTypeREF(this, this.idx, this.connection);
/*      */       
/* 1100 */       ((OracleTypeREF)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1102 */       this.idx += 1;
/*      */       
/* 1104 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 31: 
/* 1109 */       localObject = new OracleTypeBFILE(this.connection);
/*      */       
/* 1111 */       ((OracleTypeBFILE)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1113 */       this.idx += 1;
/*      */       
/* 1115 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 19: 
/* 1120 */       localObject = new OracleTypeRAW();
/*      */       
/* 1122 */       ((OracleTypeRAW)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1124 */       this.idx += 1;
/*      */       
/* 1126 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 29: 
/* 1131 */       localObject = new OracleTypeCLOB(this.connection);
/*      */       
/* 1133 */       ((OracleTypeCLOB)localObject).parseTDSrec(paramTDSReader);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1148 */       if ((this.sqlName != null) && (!this.endOfAdt)) {
/* 1149 */         this.connection.getForm(this, (OracleTypeCLOB)localObject, this.idx);
/*      */       }
/* 1151 */       this.idx += 1;
/*      */       
/* 1153 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 30: 
/* 1158 */       localObject = new OracleTypeBLOB(this.connection);
/*      */       
/* 1160 */       ((OracleTypeBLOB)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1162 */       this.idx += 1;
/*      */       
/* 1164 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 21: 
/* 1169 */       localObject = new OracleTypeTIMESTAMP(this.connection);
/*      */       
/* 1171 */       ((OracleTypeTIMESTAMP)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1173 */       this.idx += 1;
/*      */       
/* 1175 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 23: 
/* 1180 */       localObject = new OracleTypeTIMESTAMPTZ(this.connection);
/*      */       
/* 1182 */       ((OracleTypeTIMESTAMPTZ)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1184 */       this.idx += 1;
/*      */       
/* 1186 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 33: 
/* 1191 */       localObject = new OracleTypeTIMESTAMPLTZ(this.connection);
/*      */       
/* 1193 */       ((OracleTypeTIMESTAMPLTZ)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1195 */       this.idx += 1;
/*      */       
/* 1197 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 24: 
/* 1202 */       localObject = new OracleTypeINTERVAL(this.connection);
/*      */       
/* 1204 */       ((OracleTypeINTERVAL)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1206 */       this.idx += 1;
/*      */       
/* 1208 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 28: 
/* 1213 */       localObject = new OracleTypeCOLLECTION(this, this.idx, this.connection);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1218 */       ((OracleTypeCOLLECTION)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1220 */       this.idx += 1;
/*      */       
/* 1222 */       return (OracleType)localObject;
/*      */     
/*      */ 
/*      */ 
/*      */     case 27: 
/* 1227 */       localObject = new OracleTypeUPT(this, this.idx, this.connection);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1232 */       ((OracleTypeUPT)localObject).parseTDSrec(paramTDSReader);
/*      */       
/* 1234 */       this.idx += 1;
/*      */       
/* 1236 */       return (OracleType)localObject;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1254 */     Object localObject = null;
/*      */     
/*      */ 
/* 1257 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, "get_next_type: " + this.opcode);
/* 1258 */     localSQLException.fillInStackTrace();
/* 1259 */     throw localSQLException;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public byte[] linearize(Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 34	oracle/jdbc/oracore/OracleTypeADT:connection	Loracle/jdbc/internal/OracleConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: aload_1
/*      */     //   9: invokevirtual 208	oracle/jdbc/oracore/OracleTypeADT:pickle81	(Loracle/sql/Datum;)[B
/*      */     //   12: aload_2
/*      */     //   13: monitorexit
/*      */     //   14: areturn
/*      */     //   15: astore_3
/*      */     //   16: aload_2
/*      */     //   17: monitorexit
/*      */     //   18: aload_3
/*      */     //   19: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1278	-> byte code offset #0
/*      */     //   Java source line #1280	-> byte code offset #7
/*      */     //   Java source line #1282	-> byte code offset #15
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	20	0	this	OracleTypeADT
/*      */     //   0	20	1	paramDatum	Datum
/*      */     //   5	12	2	Ljava/lang/Object;	Object
/*      */     //   15	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	14	15	finally
/*      */     //   15	18	15	finally
/*      */   }
/*      */   
/*      */   public Datum unlinearize(byte[] paramArrayOfByte, long paramLong, Datum paramDatum, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1298 */     OracleConnection localOracleConnection = getConnection();
/* 1299 */     Datum localDatum = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1304 */     if (localOracleConnection == null)
/*      */     {
/* 1306 */       localDatum = _unlinearize(paramArrayOfByte, paramLong, paramDatum, paramInt, paramMap);
/*      */     }
/*      */     else
/*      */     {
/* 1310 */       synchronized (localOracleConnection) {
/* 1311 */         localDatum = _unlinearize(paramArrayOfByte, paramLong, paramDatum, paramInt, paramMap);
/*      */       }
/*      */     }
/*      */     
/* 1315 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum _unlinearize(byte[] paramArrayOfByte, long paramLong, Datum paramDatum, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1326 */     synchronized (this.connection)
/*      */     {
/* 1328 */       if (paramArrayOfByte == null) {
/* 1329 */         return null;
/*      */       }
/*      */       
/* 1332 */       PickleContext localPickleContext = new PickleContext(paramArrayOfByte, paramLong);
/*      */       
/* 1334 */       return unpickle81(localPickleContext, (STRUCT)paramDatum, 1, paramInt, paramMap);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected STRUCT unpickle81(PickleContext paramPickleContext, STRUCT paramSTRUCT, int paramInt1, int paramInt2, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1356 */     STRUCT localSTRUCT = paramSTRUCT;
/* 1357 */     long l1 = paramPickleContext.offset();
/*      */     
/*      */ 
/* 1360 */     byte b = paramPickleContext.readByte();
/*      */     SQLException localSQLException;
/* 1362 */     if (!PickleContext.is81format(b))
/*      */     {
/* 1364 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
/* 1365 */       localSQLException.fillInStackTrace();
/* 1366 */       throw localSQLException;
/*      */     }
/*      */     
/* 1369 */     if (PickleContext.isCollectionImage_pctx(b))
/*      */     {
/* 1371 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is a collection image,expecting ADT");
/* 1372 */       localSQLException.fillInStackTrace();
/* 1373 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1378 */     if (!paramPickleContext.readAndCheckVersion())
/*      */     {
/* 1380 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image version is not recognized");
/* 1381 */       localSQLException.fillInStackTrace();
/* 1382 */       throw localSQLException;
/*      */     }
/*      */     
/* 1385 */     switch (paramInt1)
/*      */     {
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1390 */       paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2);
/*      */       
/*      */ 
/* 1393 */       break;
/*      */     
/*      */ 
/*      */     case 3: 
/* 1397 */       long l2 = paramPickleContext.readLength();
/*      */       
/* 1399 */       localSTRUCT = unpickle81Prefix(paramPickleContext, localSTRUCT, b);
/*      */       
/* 1401 */       if (localSTRUCT == null)
/*      */       {
/* 1403 */         StructDescriptor localStructDescriptor = createStructDescriptor();
/*      */         
/* 1405 */         localSTRUCT = createByteSTRUCT(localStructDescriptor, (byte[])null);
/*      */       }
/*      */       
/* 1408 */       localSTRUCT.setImage(paramPickleContext.image(), l1, 0L);
/* 1409 */       localSTRUCT.setImageLength(l2);
/* 1410 */       paramPickleContext.skipTo(l1 + l2);
/*      */       
/*      */ 
/* 1413 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 1417 */       paramPickleContext.skipLength();
/*      */       
/*      */ 
/* 1420 */       localSTRUCT = unpickle81Prefix(paramPickleContext, localSTRUCT, b);
/*      */       
/* 1422 */       if (localSTRUCT == null)
/*      */       {
/* 1424 */         localObject1 = createStructDescriptor();
/*      */         
/* 1426 */         localSTRUCT = createByteSTRUCT((StructDescriptor)localObject1, (byte[])null);
/*      */       }
/*      */       
/*      */ 
/* 1430 */       Object localObject1 = localSTRUCT.getDescriptor().getOracleTypeADT().getAttrTypes();
/*      */       Object localObject2;
/*      */       int i;
/* 1433 */       switch (paramInt2)
/*      */       {
/*      */ 
/*      */ 
/*      */       case 1: 
/* 1438 */         localObject2 = new Datum[localObject1.length];
/*      */         
/* 1440 */         for (i = 0; i < localObject1.length; i++)
/*      */         {
/* 1442 */           localObject2[i] = ((Datum)localObject1[i].unpickle81rec(paramPickleContext, paramInt2, paramMap));
/*      */         }
/*      */         
/*      */ 
/* 1446 */         localSTRUCT.setDatumArray((Datum[])localObject2);
/*      */         
/*      */ 
/* 1449 */         break;
/*      */       
/*      */ 
/*      */       case 2: 
/* 1453 */         localObject2 = new Object[localObject1.length];
/*      */         
/* 1455 */         for (i = 0; i < localObject1.length; i++)
/*      */         {
/* 1457 */           localObject2[i] = localObject1[i].unpickle81rec(paramPickleContext, paramInt2, paramMap);
/*      */         }
/*      */         
/* 1460 */         localSTRUCT.setObjArray((Object[])localObject2);
/*      */         
/*      */ 
/* 1463 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       default: 
/* 1468 */         localObject2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/* 1469 */         ((SQLException)localObject2).fillInStackTrace();
/* 1470 */         throw ((Throwable)localObject2);
/*      */       }
/*      */       
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1477 */     return localSTRUCT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected STRUCT unpickle81Prefix(PickleContext paramPickleContext, STRUCT paramSTRUCT, byte paramByte)
/*      */     throws SQLException
/*      */   {
/* 1485 */     STRUCT localSTRUCT = paramSTRUCT;
/*      */     
/* 1487 */     if (PickleContext.hasPrefix(paramByte))
/*      */     {
/* 1489 */       long l = paramPickleContext.readLength() + paramPickleContext.absoluteOffset();
/*      */       
/* 1491 */       int i = paramPickleContext.readByte();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1498 */       int j = (byte)(i & 0xC);
/* 1499 */       int k = j == 0 ? 1 : 0;
/*      */       
/* 1501 */       int m = j == 4 ? 1 : 0;
/*      */       
/* 1503 */       int n = j == 8 ? 1 : 0;
/*      */       
/* 1505 */       int i1 = j == 12 ? 1 : 0;
/*      */       
/*      */ 
/* 1508 */       int i2 = (i & 0x10) != 0 ? 1 : 0;
/*      */       
/*      */       Object localObject;
/* 1511 */       if (m != 0)
/*      */       {
/* 1513 */         localObject = paramPickleContext.readBytes(16);
/* 1514 */         String str = toid2typename(this.connection, (byte[])localObject);
/*      */         
/* 1516 */         StructDescriptor localStructDescriptor = (StructDescriptor)TypeDescriptor.getTypeDescriptor(str, this.connection);
/*      */         
/*      */ 
/*      */ 
/* 1520 */         if (localSTRUCT == null) {
/* 1521 */           localSTRUCT = createByteSTRUCT(localStructDescriptor, (byte[])null);
/*      */         } else {
/* 1523 */           localSTRUCT.setDescriptor(localStructDescriptor);
/*      */         }
/*      */       }
/* 1526 */       if (i2 != 0)
/*      */       {
/* 1528 */         paramPickleContext.readLength();
/*      */       }
/*      */       
/* 1531 */       if ((n | i1) != 0)
/*      */       {
/* 1533 */         localObject = DatabaseError.createUnsupportedFeatureSqlException();
/* 1534 */         ((SQLException)localObject).fillInStackTrace();
/* 1535 */         throw ((Throwable)localObject);
/*      */       }
/*      */       
/* 1538 */       paramPickleContext.skipTo(l);
/*      */     }
/*      */     
/* 1541 */     return localSTRUCT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object unpickle81rec(PickleContext paramPickleContext, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1554 */     byte b1 = paramPickleContext.readByte();
/* 1555 */     byte b2 = 0;
/*      */     
/* 1557 */     if (PickleContext.isAtomicNull(b1))
/* 1558 */       return null;
/* 1559 */     if (PickleContext.isImmediatelyEmbeddedNull(b1)) {
/* 1560 */       b2 = paramPickleContext.readByte();
/*      */     }
/* 1562 */     STRUCT localSTRUCT = unpickle81datum(paramPickleContext, b1, b2);
/*      */     
/* 1564 */     return toObject(localSTRUCT, paramInt, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object unpickle81rec(PickleContext paramPickleContext, byte paramByte, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1573 */     STRUCT localSTRUCT = unpickle81datum(paramPickleContext, paramByte, (byte)0);
/*      */     
/* 1575 */     return toObject(localSTRUCT, paramInt, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private STRUCT unpickle81datum(PickleContext paramPickleContext, byte paramByte1, byte paramByte2)
/*      */     throws SQLException
/*      */   {
/* 1583 */     int i = getNumAttrs();
/*      */     
/*      */ 
/* 1586 */     StructDescriptor localStructDescriptor = createStructDescriptor();
/* 1587 */     STRUCT localSTRUCT = createByteSTRUCT(localStructDescriptor, (byte[])null);
/* 1588 */     OracleType localOracleType = getAttrTypeAt(0);
/* 1589 */     Object localObject = null;
/*      */     
/*      */ 
/*      */ 
/* 1593 */     if ((PickleContext.isImmediatelyEmbeddedNull(paramByte1)) && (paramByte2 == 1)) {
/* 1594 */       localObject = null;
/* 1595 */     } else if (PickleContext.isImmediatelyEmbeddedNull(paramByte1)) {
/* 1596 */       localObject = ((OracleTypeADT)localOracleType).unpickle81datum(paramPickleContext, paramByte1, (byte)(paramByte2 - 1));
/*      */     }
/* 1598 */     else if (PickleContext.isElementNull(paramByte1))
/*      */     {
/* 1600 */       if ((localOracleType.getTypeCode() == 2002) || (localOracleType.getTypeCode() == 2008))
/*      */       {
/* 1602 */         localObject = localOracleType.unpickle81datumAsNull(paramPickleContext, paramByte1, paramByte2);
/*      */       } else {
/* 1604 */         localObject = null;
/*      */       }
/*      */     } else {
/* 1607 */       localObject = localOracleType.unpickle81rec(paramPickleContext, paramByte1, 1, null);
/*      */     }
/*      */     
/* 1610 */     Datum[] arrayOfDatum = new Datum[i];
/*      */     
/* 1612 */     arrayOfDatum[0] = ((Datum)localObject);
/*      */     
/* 1614 */     for (int j = 1; j < i; j++)
/*      */     {
/* 1616 */       localOracleType = getAttrTypeAt(j);
/* 1617 */       arrayOfDatum[j] = ((Datum)localOracleType.unpickle81rec(paramPickleContext, 1, null));
/*      */     }
/*      */     
/* 1620 */     localSTRUCT.setDatumArray(arrayOfDatum);
/*      */     
/* 1622 */     return localSTRUCT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Datum unpickle81datumAsNull(PickleContext paramPickleContext, byte paramByte1, byte paramByte2)
/*      */     throws SQLException
/*      */   {
/* 1630 */     int i = getNumAttrs();
/*      */     
/*      */ 
/* 1633 */     StructDescriptor localStructDescriptor = createStructDescriptor();
/* 1634 */     STRUCT localSTRUCT = createByteSTRUCT(localStructDescriptor, (byte[])null);
/* 1635 */     Datum[] arrayOfDatum = new Datum[i];
/* 1636 */     int j = 0;
/* 1637 */     OracleType localOracleType = getAttrTypeAt(j);
/*      */     
/*      */ 
/* 1640 */     if ((localOracleType.getTypeCode() == 2002) || (localOracleType.getTypeCode() == 2008))
/*      */     {
/* 1642 */       arrayOfDatum[(j++)] = localOracleType.unpickle81datumAsNull(paramPickleContext, paramByte1, paramByte2);
/*      */     } else {
/* 1644 */       arrayOfDatum[(j++)] = ((Datum)null);
/*      */     }
/* 1646 */     for (; j < i; j++)
/*      */     {
/* 1648 */       localOracleType = getAttrTypeAt(j);
/* 1649 */       if ((localOracleType.getTypeCode() == 2002) || (localOracleType.getTypeCode() == 2008))
/*      */       {
/* 1651 */         arrayOfDatum[j] = ((Datum)localOracleType.unpickle81rec(paramPickleContext, 1, null));
/*      */       }
/*      */       else
/* 1654 */         arrayOfDatum[j] = ((Datum)localOracleType.unpickle81rec(paramPickleContext, 1, null));
/*      */     }
/* 1656 */     localSTRUCT.setDatumArray(arrayOfDatum);
/* 1657 */     return localSTRUCT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] pickle81(Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 1674 */     PickleContext localPickleContext = new PickleContext();
/*      */     
/* 1676 */     localPickleContext.initStream();
/* 1677 */     pickle81(localPickleContext, paramDatum);
/*      */     
/* 1679 */     byte[] arrayOfByte = localPickleContext.stream2Bytes();
/*      */     
/*      */ 
/* 1682 */     paramDatum.setShareBytes(arrayOfByte);
/*      */     
/* 1684 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */ 
/*      */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/* 1691 */     int i = paramPickleContext.offset() + 2;
/* 1692 */     int j = 0;
/*      */     
/*      */ 
/* 1695 */     j += paramPickleContext.writeImageHeader(shouldHavePrefix());
/*      */     
/* 1697 */     j += pickle81Prefix(paramPickleContext);
/* 1698 */     j += pickle81rec(paramPickleContext, paramDatum, 0);
/*      */     
/* 1700 */     paramPickleContext.patchImageLen(i, j);
/*      */     
/* 1702 */     return j;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean hasVersion()
/*      */   {
/* 1709 */     return this.typeVersion > 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean needsToid()
/*      */   {
/* 1716 */     if (this.isTransient)
/* 1717 */       return false;
/* 1718 */     return ((this.statusBits & 0x40) != 0) || ((this.statusBits & 0x20) == 0) || (hasVersion());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean shouldHavePrefix()
/*      */   {
/* 1726 */     if (this.isTransient)
/* 1727 */       return false;
/* 1728 */     return (hasVersion()) || (needsToid());
/*      */   }
/*      */   
/*      */ 
/*      */   protected int pickle81Prefix(PickleContext paramPickleContext)
/*      */     throws SQLException
/*      */   {
/* 1735 */     if (shouldHavePrefix())
/*      */     {
/* 1737 */       int i = 0;
/* 1738 */       int j = 1;
/* 1739 */       int k = 1;
/*      */       
/* 1741 */       if (needsToid())
/*      */       {
/* 1743 */         k += getTOID().length;
/* 1744 */         j |= 0x4;
/*      */       }
/*      */       
/* 1747 */       if (hasVersion())
/*      */       {
/* 1749 */         j |= 0x10;
/*      */         
/* 1751 */         if (this.typeVersion > PickleContext.KOPI20_LN_MAXV) {
/* 1752 */           k += 5;
/*      */         } else {
/* 1754 */           k += 2;
/*      */         }
/*      */       }
/* 1757 */       i = paramPickleContext.writeLength(k);
/*      */       
/* 1759 */       i += paramPickleContext.writeData((byte)j);
/*      */       
/* 1761 */       if (needsToid()) {
/* 1762 */         i += paramPickleContext.writeData(this.toid);
/*      */       }
/* 1764 */       if (hasVersion())
/*      */       {
/* 1766 */         if (this.typeVersion > PickleContext.KOPI20_LN_MAXV) {
/* 1767 */           i += paramPickleContext.writeLength(this.typeVersion);
/*      */         } else {
/* 1769 */           i += paramPickleContext.writeSB2(this.typeVersion);
/*      */         }
/*      */       }
/* 1772 */       return i;
/*      */     }
/*      */     
/* 1775 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int pickle81rec(PickleContext paramPickleContext, Datum paramDatum, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1785 */     int i = 0;
/*      */     
/* 1787 */     if (!this.metaDataInitialized) {
/* 1788 */       copy_properties((OracleTypeADT)((STRUCT)paramDatum).getDescriptor().getPickler());
/*      */     }
/* 1790 */     Datum[] arrayOfDatum = ((STRUCT)paramDatum).getOracleAttributes();
/* 1791 */     int j = arrayOfDatum.length;
/* 1792 */     int k = 0;
/* 1793 */     OracleType localOracleType = getAttrTypeAt(0);
/*      */     
/* 1795 */     if (((localOracleType instanceof OracleTypeADT)) && (!(localOracleType instanceof OracleTypeCOLLECTION)) && (!(localOracleType instanceof OracleTypeUPT)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1802 */       k = 1;
/*      */       
/* 1804 */       if (arrayOfDatum[0] == null)
/*      */       {
/* 1806 */         if (paramInt > 0) {
/* 1807 */           i += paramPickleContext.writeImmediatelyEmbeddedElementNull((byte)paramInt);
/*      */         } else {
/* 1809 */           i += paramPickleContext.writeAtomicNull();
/*      */         }
/*      */       }
/*      */       else {
/* 1813 */         i += ((OracleTypeADT)localOracleType).pickle81rec(paramPickleContext, arrayOfDatum[0], paramInt + 1);
/*      */       }
/*      */     }
/* 1818 */     for (; 
/*      */         
/* 1818 */         k < j; k++)
/*      */     {
/* 1820 */       localOracleType = getAttrTypeAt(k);
/*      */       
/*      */ 
/* 1823 */       if (arrayOfDatum[k] == null)
/*      */       {
/* 1825 */         if (((localOracleType instanceof OracleTypeADT)) && (!(localOracleType instanceof OracleTypeCOLLECTION)) && (!(localOracleType instanceof OracleTypeUPT)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1831 */           i += paramPickleContext.writeAtomicNull();
/*      */         }
/*      */         else
/*      */         {
/* 1835 */           i += paramPickleContext.writeElementNull();
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1840 */       else if (((localOracleType instanceof OracleTypeADT)) && (!(localOracleType instanceof OracleTypeCOLLECTION)) && (!(localOracleType instanceof OracleTypeUPT)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1846 */         i += ((OracleTypeADT)localOracleType).pickle81rec(paramPickleContext, arrayOfDatum[k], 1);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1853 */         i += localOracleType.pickle81(paramPickleContext, arrayOfDatum[k]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1858 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object toObject(STRUCT paramSTRUCT, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1870 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */     case 1: 
/* 1874 */       return paramSTRUCT;
/*      */     
/*      */     case 2: 
/* 1877 */       if (paramSTRUCT != null) {
/* 1878 */         return paramSTRUCT.toJdbc(paramMap);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     default: 
/* 1885 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/* 1886 */       localSQLException.fillInStackTrace();
/* 1887 */       throw localSQLException;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 1892 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAttributeType(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1909 */     return getAttributeType(paramInt, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAttributeType(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1921 */     if (paramBoolean)
/*      */     {
/* 1923 */       if (this.sqlName == null) {
/* 1924 */         getFullName();
/*      */       }
/* 1926 */       if (this.attrNames == null)
/* 1927 */         initADTAttrNames();
/*      */     }
/* 1929 */     if ((paramInt < 1) || ((this.attrTypeNames != null) && (paramInt > this.attrTypeNames.length)))
/*      */     {
/* 1931 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
/* 1932 */       localSQLException.fillInStackTrace();
/* 1933 */       throw localSQLException;
/*      */     }
/*      */     
/* 1936 */     if (this.attrTypeNames != null) {
/* 1937 */       return this.attrTypeNames[(paramInt - 1)];
/*      */     }
/* 1939 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAttributeName(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1952 */     if (this.attrNames == null) {
/* 1953 */       initADTAttrNames();
/*      */     }
/* 1955 */     String str = null;
/* 1956 */     if (this.attrNames != null)
/*      */     {
/* 1958 */       synchronized (this.connection) {
/* 1959 */         if ((paramInt < 1) || (paramInt > this.attrNames.length))
/*      */         {
/* 1961 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
/* 1962 */           localSQLException.fillInStackTrace();
/* 1963 */           throw localSQLException;
/*      */         }
/*      */       }
/* 1966 */       str = this.attrNames[(paramInt - 1)];
/*      */     }
/* 1968 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAttributeName(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1980 */     if ((paramBoolean) && (this.connection != null)) {
/* 1981 */       return getAttributeName(paramInt);
/*      */     }
/*      */     
/* 1984 */     if ((paramInt < 1) || ((this.attrNames != null) && (paramInt > this.attrNames.length)))
/*      */     {
/* 1986 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
/* 1987 */       localSQLException.fillInStackTrace();
/* 1988 */       throw localSQLException;
/*      */     }
/*      */     
/* 1991 */     if (this.attrNames != null) {
/* 1992 */       return this.attrNames[(paramInt - 1)];
/*      */     }
/* 1994 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2014 */   static final String[] sqlString = { "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME = :1 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT /*+RULE*/ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "SELECT /*+RULE*/ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = :1 AND TYPE_NAME = :2 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ORDER BY ATTR_NO", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" };
/*      */   
/*      */ 
/*      */   static final int TDS_SIZE = 4;
/*      */   
/*      */ 
/*      */   static final int TDS_NUMBER = 1;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_SQL_CHAR = 1;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_DATE = 2;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_DECIMAL = 3;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_DOUBLE = 4;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_FLOAT = 5;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_NUMBER = 6;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_SQL_VARCHAR2 = 7;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_SINT32 = 8;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_REF = 9;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_VARRAY = 10;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_UINT8 = 11;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_SINT8 = 12;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_UINT16 = 13;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_UINT32 = 14;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_LOB = 15;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_CANONICAL = 17;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_OCTET = 18;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_RAW = 19;
/*      */   
/*      */ 
/*      */   static final int KOPM_OTS_ROWID = 20;
/*      */   
/*      */   static final int KOPM_OTS_STAMP = 21;
/*      */   
/*      */   static final int KOPM_OTS_TZSTAMP = 23;
/*      */   
/*      */   static final int KOPM_OTS_INTERVAL = 24;
/*      */   
/*      */   static final int KOPM_OTS_PTR = 25;
/*      */   
/*      */   static final int KOPM_OTS_SINT16 = 26;
/*      */   
/*      */   static final int KOPM_OTS_UPT = 27;
/*      */   
/*      */   static final int KOPM_OTS_COLLECTION = 28;
/*      */   
/*      */   static final int KOPM_OTS_CLOB = 29;
/*      */   
/*      */   static final int KOPM_OTS_BLOB = 30;
/*      */   
/*      */   static final int KOPM_OTS_BFILE = 31;
/*      */   
/*      */   static final int KOPM_OTS_BINARY_INTEGE = 32;
/*      */   
/*      */   static final int KOPM_OTS_IMPTZSTAMP = 33;
/*      */   
/*      */   static final int KOPM_OTS_BFLOAT = 37;
/*      */   
/*      */   static final int KOPM_OTS_BDOUBLE = 45;
/*      */   
/*      */   static final int KOTTCOPQ = 58;
/*      */   
/*      */   static final int KOPT_OP_STARTEMBADT = 39;
/*      */   
/*      */   static final int KOPT_OP_ENDEMBADT = 40;
/*      */   
/*      */   static final int KOPT_OP_STARTADT = 41;
/*      */   
/*      */   static final int KOPT_OP_ENDADT = 42;
/*      */   
/*      */   static final int KOPT_OP_SUBTYPE_MARKER = 43;
/*      */   
/*      */   static final int KOPT_OP_EMBADT_INFO = 44;
/*      */   
/*      */   static final int KOPT_OPCODE_START = 38;
/*      */   
/*      */   static final int KOPT_OP_VERSION = 38;
/*      */   
/*      */   static final int REGULAR_PATCH = 0;
/*      */   
/*      */   static final int SIMPLE_PATCH = 1;
/*      */   
/*      */ 
/*      */   private void initADTAttrNames()
/*      */     throws SQLException
/*      */   {
/* 2133 */     if (this.connection == null)
/* 2134 */       return;
/* 2135 */     if (this.sqlName == null)
/* 2136 */       getFullName();
/* 2137 */     synchronized (this.connection)
/*      */     {
/* 2139 */       CallableStatement localCallableStatement = null;
/* 2140 */       PreparedStatement localPreparedStatement = null;
/* 2141 */       ResultSet localResultSet = null;
/* 2142 */       String[] arrayOfString1 = new String[this.attrTypes.length];
/* 2143 */       String[] arrayOfString2 = new String[this.attrTypes.length];
/* 2144 */       int i = 0;
/* 2145 */       int j = 0;
/* 2146 */       if (this.attrNames == null)
/*      */       {
/* 2148 */         i = this.sqlName.getSchema().equalsIgnoreCase(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7;
/*      */         
/*      */ 
/* 2151 */         while (i != 11)
/*      */         {
/* 2153 */           switch (i)
/*      */           {
/*      */ 
/*      */           case 0: 
/* 2157 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/* 2158 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2159 */             localPreparedStatement.setFetchSize(this.idx);
/* 2160 */             localResultSet = localPreparedStatement.executeQuery();
/* 2161 */             i = 1;
/* 2162 */             break;
/*      */           
/*      */           case 1: 
/* 2165 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/* 2167 */               i = 2;
/*      */             }
/*      */           
/*      */ 
/*      */           case 2: 
/* 2172 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/* 2173 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2174 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2175 */             localPreparedStatement.setFetchSize(this.idx);
/* 2176 */             localResultSet = localPreparedStatement.executeQuery();
/* 2177 */             i = 3;
/* 2178 */             break;
/*      */           
/*      */           case 3: 
/* 2181 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/* 2183 */               i = 4;
/*      */             }
/*      */           
/*      */ 
/*      */           case 4: 
/* 2188 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/* 2189 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2190 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2191 */             localPreparedStatement.setFetchSize(this.idx);
/* 2192 */             localResultSet = localPreparedStatement.executeQuery();
/* 2193 */             i = 5;
/* 2194 */             break;
/*      */           
/*      */           case 5: 
/* 2197 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/* 2199 */               i = 6;
/*      */             }
/*      */           
/*      */ 
/*      */           case 6: 
/* 2204 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/* 2205 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2206 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2207 */             localPreparedStatement.setFetchSize(this.idx);
/* 2208 */             localResultSet = localPreparedStatement.executeQuery();
/* 2209 */             i = 8;
/* 2210 */             break;
/*      */           
/*      */ 
/*      */           case 7: 
/* 2214 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/* 2215 */             localPreparedStatement.setString(1, this.sqlName.getSchema());
/* 2216 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2217 */             localPreparedStatement.setFetchSize(this.idx);
/* 2218 */             localResultSet = localPreparedStatement.executeQuery();
/* 2219 */             i = 8;
/* 2220 */             break;
/*      */           
/*      */ 
/*      */           case 8: 
/* 2224 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/* 2225 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2226 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2227 */             localPreparedStatement.setFetchSize(this.idx);
/* 2228 */             localResultSet = localPreparedStatement.executeQuery();
/* 2229 */             i = 9;
/* 2230 */             break;
/*      */           
/*      */           case 9: 
/* 2233 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/* 2235 */               i = 10;
/*      */             }
/*      */           
/*      */ 
/*      */           case 10: 
/* 2240 */             localCallableStatement = this.connection.prepareCall(getSqlHint() + sqlString[i]);
/* 2241 */             localCallableStatement.setString(1, this.sqlName.getSimpleName());
/* 2242 */             localCallableStatement.registerOutParameter(2, -10);
/* 2243 */             localCallableStatement.execute();
/* 2244 */             localResultSet = ((OracleCallableStatement)localCallableStatement).getCursor(2);
/* 2245 */             i = 11;
/*      */           }
/*      */           
/*      */           
/*      */ 
/*      */           try
/*      */           {
/* 2252 */             for (j = 0; 
/* 2253 */                 (j < this.attrTypes.length) && (localResultSet.next()); 
/* 2254 */                 j++)
/*      */             {
/* 2256 */               if (localResultSet.getInt(1) != j + 1)
/*      */               {
/* 2258 */                 localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "inconsistent ADT attribute");
/* 2259 */                 ((SQLException)localObject1).fillInStackTrace();
/* 2260 */                 throw ((Throwable)localObject1);
/*      */               }
/*      */               
/*      */ 
/* 2264 */               arrayOfString1[j] = localResultSet.getString(2);
/*      */               
/*      */ 
/* 2267 */               Object localObject1 = localResultSet.getString(4);
/* 2268 */               arrayOfString2[j] = "";
/* 2269 */               if (localObject1 != null)
/* 2270 */                 arrayOfString2[j] = ((String)localObject1 + ".");
/* 2271 */               int tmp970_968 = j; String[] tmp970_966 = arrayOfString2;tmp970_966[tmp970_968] = (tmp970_966[tmp970_968] + localResultSet.getString(3));
/*      */             }
/*      */             
/* 2274 */             if (j != 0)
/*      */             {
/* 2276 */               this.attrTypeNames = arrayOfString2;
/*      */               
/* 2278 */               this.attrNames = arrayOfString1;
/* 2279 */               i = 11;
/*      */             }
/*      */             else {
/* 2282 */               if (localResultSet != null)
/* 2283 */                 localResultSet.close();
/* 2284 */               if (localPreparedStatement != null)
/* 2285 */                 localPreparedStatement.close();
/*      */             }
/*      */           } finally {
/* 2288 */             if (localResultSet != null)
/* 2289 */               localResultSet.close();
/* 2290 */             if (localPreparedStatement != null)
/* 2291 */               localPreparedStatement.close();
/* 2292 */             if (localCallableStatement != null) {
/* 2293 */               localCallableStatement.close();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   StructDescriptor createStructDescriptor()
/*      */     throws SQLException
/*      */   {
/* 2314 */     StructDescriptor localStructDescriptor = (StructDescriptor)this.descriptor;
/*      */     
/* 2316 */     if (localStructDescriptor == null) {
/* 2317 */       localStructDescriptor = new StructDescriptor(this, this.connection);
/*      */     }
/* 2319 */     return localStructDescriptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   STRUCT createObjSTRUCT(StructDescriptor paramStructDescriptor, Object[] paramArrayOfObject)
/*      */     throws SQLException
/*      */   {
/* 2327 */     if ((this.statusBits & 0x10) != 0) {
/* 2328 */       return new JAVA_STRUCT(paramStructDescriptor, this.connection, paramArrayOfObject);
/*      */     }
/* 2330 */     return new STRUCT(paramStructDescriptor, this.connection, paramArrayOfObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   STRUCT createByteSTRUCT(StructDescriptor paramStructDescriptor, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2338 */     if ((this.statusBits & 0x10) != 0) {
/* 2339 */       return new JAVA_STRUCT(paramStructDescriptor, paramArrayOfByte, this.connection);
/*      */     }
/* 2341 */     return new STRUCT(paramStructDescriptor, paramArrayOfByte, this.connection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getSubtypeName(Connection paramConnection, byte[] paramArrayOfByte, long paramLong)
/*      */     throws SQLException
/*      */   {
/* 2353 */     PickleContext localPickleContext = new PickleContext(paramArrayOfByte, paramLong);
/* 2354 */     byte b = localPickleContext.readByte();
/*      */     
/* 2356 */     if ((!PickleContext.is81format(b)) || (PickleContext.isCollectionImage_pctx(b)) || (!PickleContext.hasPrefix(b)))
/*      */     {
/* 2358 */       return null;
/*      */     }
/*      */     
/*      */     Object localObject;
/* 2362 */     if (!localPickleContext.readAndCheckVersion())
/*      */     {
/* 2364 */       localObject = DatabaseError.createSqlException(null, 1, "Image version is not recognized");
/* 2365 */       ((SQLException)localObject).fillInStackTrace();
/* 2366 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2371 */     localPickleContext.skipLength();
/*      */     
/*      */ 
/* 2374 */     localPickleContext.skipLength();
/*      */     
/* 2376 */     b = localPickleContext.readByte();
/*      */     
/*      */ 
/* 2379 */     if ((b & 0x4) != 0)
/*      */     {
/* 2381 */       localObject = localPickleContext.readBytes(16);
/*      */       
/* 2383 */       return toid2typename(paramConnection, (byte[])localObject);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2392 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String toid2typename(Connection paramConnection, byte[] paramArrayOfByte)
/*      */     throws SQLException
/*      */   {
/* 2402 */     String str = (String)((OracleConnection)paramConnection).getDescriptor(paramArrayOfByte);
/*      */     
/* 2404 */     if (str == null)
/*      */     {
/* 2406 */       PreparedStatement localPreparedStatement = null;
/* 2407 */       ResultSet localResultSet = null;
/*      */       
/*      */       try
/*      */       {
/* 2411 */         localPreparedStatement = paramConnection.prepareStatement("select owner, type_name from all_types where type_oid = :1");
/*      */         
/*      */ 
/* 2414 */         localPreparedStatement.setBytes(1, paramArrayOfByte);
/*      */         
/* 2416 */         localResultSet = localPreparedStatement.executeQuery();
/*      */         
/* 2418 */         if (localResultSet.next())
/*      */         {
/* 2420 */           str = localResultSet.getString(1) + "." + localResultSet.getString(2);
/*      */           
/* 2422 */           ((OracleConnection)paramConnection).putDescriptor(paramArrayOfByte, str);
/*      */         }
/*      */         else
/*      */         {
/* 2426 */           SQLException localSQLException = DatabaseError.createSqlException(null, 1, "Invalid type oid");
/* 2427 */           localSQLException.fillInStackTrace();
/* 2428 */           throw localSQLException;
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 2433 */         if (localResultSet != null) {
/* 2434 */           localResultSet.close();
/*      */         }
/* 2436 */         if (localPreparedStatement != null) {
/* 2437 */           localPreparedStatement.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2442 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getTdsVersion()
/*      */   {
/* 2449 */     return this.tdsVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void printDebug() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String debugText()
/*      */   {
/* 2468 */     StringWriter localStringWriter = new StringWriter();
/* 2469 */     PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
/*      */     
/* 2471 */     localPrintWriter.println("OracleTypeADT = " + this);
/* 2472 */     localPrintWriter.println("sqlName = " + this.sqlName);
/*      */     
/* 2474 */     localPrintWriter.println("OracleType[] : ");
/*      */     
/* 2476 */     if (this.attrTypes != null)
/*      */     {
/* 2478 */       for (int i = 0; i < this.attrTypes.length; i++) {
/* 2479 */         localPrintWriter.println("[" + i + "] = " + this.attrTypes[i]);
/*      */       }
/*      */     } else {
/* 2482 */       localPrintWriter.println("null");
/*      */     }
/* 2484 */     localPrintWriter.println("toid : ");
/*      */     
/* 2486 */     if (this.toid != null) {
/* 2487 */       printUnsignedByteArray(this.toid, localPrintWriter);
/*      */     } else {
/* 2489 */       localPrintWriter.println("null");
/*      */     }
/*      */     
/* 2492 */     localPrintWriter.println("tds version : " + this.tdsVersion);
/* 2493 */     localPrintWriter.println("type version : " + this.typeVersion);
/* 2494 */     localPrintWriter.println("type version : " + this.typeVersion);
/* 2495 */     localPrintWriter.println("opcode : " + this.opcode);
/*      */     
/* 2497 */     localPrintWriter.println("tdoCState : " + this.tdoCState);
/*      */     
/* 2499 */     return localStringWriter.getBuffer().substring(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getTOID()
/*      */   {
/*      */     try
/*      */     {
/* 2515 */       if (this.toid == null)
/*      */       {
/*      */ 
/* 2518 */         initMetadata(this.connection);
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/*      */     
/* 2523 */     return this.toid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getImageFormatVersion()
/*      */   {
/* 2530 */     return PickleContext.KOPI20_VERSION;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getTypeVersion()
/*      */   {
/*      */     try
/*      */     {
/* 2539 */       if (this.typeVersion == -1)
/*      */       {
/* 2541 */         initMetadata(this.connection);
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/* 2545 */     return this.typeVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getCharSet()
/*      */   {
/* 2552 */     return this.charSetId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getCharSetForm()
/*      */   {
/* 2559 */     return this.charSetForm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getTdoCState()
/*      */   {
/* 2569 */     synchronized (this.connection)
/*      */     {
/*      */       try
/*      */       {
/* 2573 */         if (this.tdoCState == 0L)
/*      */         {
/* 2575 */           getFullName();
/* 2576 */           this.tdoCState = this.connection.getTdoCState(this.sqlName.getSchema(), this.sqlName.getSimpleName());
/*      */         }
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */       
/* 2581 */       return this.tdoCState;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public long getFIXED_DATA_SIZE()
/*      */   {
/*      */     try
/*      */     {
/* 2591 */       return getFixedDataSize();
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/*      */     
/* 2595 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getFixedDataSize()
/*      */     throws SQLException
/*      */   {
/* 2602 */     return this.fixedDataSize;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getAlignmentReq()
/*      */     throws SQLException
/*      */   {
/* 2609 */     return this.alignmentRequirement;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getNumAttrs()
/*      */     throws SQLException
/*      */   {
/* 2616 */     if ((this.attrTypes == null) && (this.connection != null)) {
/* 2617 */       init(this.connection);
/*      */     }
/* 2619 */     return this.attrTypes.length;
/*      */   }
/*      */   
/*      */ 
/*      */   public OracleType getAttrTypeAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2626 */     if ((this.attrTypes == null) && (this.connection != null)) {
/* 2627 */       init(this.connection);
/*      */     }
/* 2629 */     return this.attrTypes[paramInt];
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isEmbeddedADT()
/*      */     throws SQLException
/*      */   {
/* 2636 */     return (this.statusBits & 0x2) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isUptADT()
/*      */     throws SQLException
/*      */   {
/* 2643 */     return (this.statusBits & 0x4) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isTopADT()
/*      */     throws SQLException
/*      */   {
/* 2650 */     return (this.statusBits & 0x1) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setStatus(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2657 */     this.statusBits = paramInt;
/*      */   }
/*      */   
/*      */ 
/*      */   void setEmbeddedADT()
/*      */     throws SQLException
/*      */   {
/* 2664 */     maskAndSetStatusBits(-16, 2);
/*      */   }
/*      */   
/*      */ 
/*      */   void setUptADT()
/*      */     throws SQLException
/*      */   {
/* 2671 */     maskAndSetStatusBits(-16, 4);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isSubType()
/*      */     throws SQLException
/*      */   {
/* 2678 */     return (this.statusBits & 0x40) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFinalType()
/*      */     throws SQLException
/*      */   {
/* 2687 */     return ((this.statusBits & 0x20) != 0 ? 1 : 0) | ((this.statusBits & 0x2) != 0 ? 1 : 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isJavaObject()
/*      */     throws SQLException
/*      */   {
/* 2695 */     return (this.statusBits & 0x10) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStatus()
/*      */     throws SQLException
/*      */   {
/* 2704 */     if (((this.statusBits & 0x1) != 0) && ((this.statusBits & 0x100) == 0))
/* 2705 */       init(this.connection);
/* 2706 */     return this.statusBits;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static OracleTypeADT shallowClone(OracleTypeADT paramOracleTypeADT)
/*      */     throws SQLException
/*      */   {
/* 2714 */     OracleTypeADT localOracleTypeADT = new OracleTypeADT();
/* 2715 */     shallowCopy(paramOracleTypeADT, localOracleTypeADT);
/* 2716 */     return localOracleTypeADT;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void shallowCopy(OracleTypeADT paramOracleTypeADT1, OracleTypeADT paramOracleTypeADT2)
/*      */     throws SQLException
/*      */   {
/* 2724 */     paramOracleTypeADT2.connection = paramOracleTypeADT1.connection;
/* 2725 */     paramOracleTypeADT2.sqlName = paramOracleTypeADT1.sqlName;
/* 2726 */     paramOracleTypeADT2.parent = paramOracleTypeADT1.parent;
/* 2727 */     paramOracleTypeADT2.idx = paramOracleTypeADT1.idx;
/* 2728 */     paramOracleTypeADT2.descriptor = paramOracleTypeADT1.descriptor;
/* 2729 */     paramOracleTypeADT2.statusBits = paramOracleTypeADT1.statusBits;
/*      */     
/* 2731 */     paramOracleTypeADT2.typeCode = paramOracleTypeADT1.typeCode;
/* 2732 */     paramOracleTypeADT2.dbTypeCode = paramOracleTypeADT1.dbTypeCode;
/* 2733 */     paramOracleTypeADT2.tdsVersion = paramOracleTypeADT1.tdsVersion;
/* 2734 */     paramOracleTypeADT2.typeVersion = paramOracleTypeADT1.typeVersion;
/* 2735 */     paramOracleTypeADT2.fixedDataSize = paramOracleTypeADT1.fixedDataSize;
/* 2736 */     paramOracleTypeADT2.alignmentRequirement = paramOracleTypeADT1.alignmentRequirement;
/* 2737 */     paramOracleTypeADT2.attrTypes = paramOracleTypeADT1.attrTypes;
/* 2738 */     paramOracleTypeADT2.sqlName = paramOracleTypeADT1.sqlName;
/* 2739 */     paramOracleTypeADT2.tdoCState = paramOracleTypeADT1.tdoCState;
/* 2740 */     paramOracleTypeADT2.toid = paramOracleTypeADT1.toid;
/* 2741 */     paramOracleTypeADT2.charSetId = paramOracleTypeADT1.charSetId;
/* 2742 */     paramOracleTypeADT2.charSetForm = paramOracleTypeADT1.charSetForm;
/* 2743 */     paramOracleTypeADT2.flattenedAttrNum = paramOracleTypeADT1.flattenedAttrNum;
/* 2744 */     paramOracleTypeADT2.statusBits = paramOracleTypeADT1.statusBits;
/* 2745 */     paramOracleTypeADT2.attrNames = paramOracleTypeADT1.attrNames;
/* 2746 */     paramOracleTypeADT2.attrTypeNames = paramOracleTypeADT1.attrTypeNames;
/* 2747 */     paramOracleTypeADT2.opcode = paramOracleTypeADT1.opcode;
/* 2748 */     paramOracleTypeADT2.idx = paramOracleTypeADT1.idx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream)
/*      */     throws IOException
/*      */   {
/* 2759 */     paramObjectOutputStream.writeInt(this.statusBits);
/* 2760 */     paramObjectOutputStream.writeInt(this.tdsVersion);
/* 2761 */     paramObjectOutputStream.writeInt(this.typeVersion);
/* 2762 */     paramObjectOutputStream.writeObject(null);
/* 2763 */     paramObjectOutputStream.writeObject(null);
/* 2764 */     paramObjectOutputStream.writeLong(this.fixedDataSize);
/* 2765 */     paramObjectOutputStream.writeInt(this.alignmentRequirement);
/* 2766 */     paramObjectOutputStream.writeObject(this.attrTypes);
/* 2767 */     paramObjectOutputStream.writeObject(this.attrNames);
/* 2768 */     paramObjectOutputStream.writeObject(this.attrTypeNames);
/* 2769 */     paramObjectOutputStream.writeLong(this.tdoCState);
/* 2770 */     paramObjectOutputStream.writeObject(this.toid);
/* 2771 */     paramObjectOutputStream.writeObject(null);
/* 2772 */     paramObjectOutputStream.writeInt(this.charSetId);
/* 2773 */     paramObjectOutputStream.writeInt(this.charSetForm);
/* 2774 */     paramObjectOutputStream.writeBoolean(true);
/* 2775 */     paramObjectOutputStream.writeInt(this.flattenedAttrNum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream paramObjectInputStream)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 2783 */     this.statusBits = paramObjectInputStream.readInt();
/* 2784 */     this.tdsVersion = paramObjectInputStream.readInt();
/* 2785 */     this.typeVersion = paramObjectInputStream.readInt();
/* 2786 */     paramObjectInputStream.readObject();
/* 2787 */     paramObjectInputStream.readObject();
/* 2788 */     paramObjectInputStream.readLong();
/* 2789 */     paramObjectInputStream.readInt();
/* 2790 */     this.attrTypes = ((OracleType[])paramObjectInputStream.readObject());
/* 2791 */     this.attrNames = ((String[])paramObjectInputStream.readObject());
/* 2792 */     this.attrTypeNames = ((String[])paramObjectInputStream.readObject());
/* 2793 */     paramObjectInputStream.readLong();
/* 2794 */     this.toid = ((byte[])paramObjectInputStream.readObject());
/* 2795 */     paramObjectInputStream.readObject();
/* 2796 */     this.charSetId = paramObjectInputStream.readInt();
/* 2797 */     this.charSetForm = paramObjectInputStream.readInt();
/* 2798 */     paramObjectInputStream.readBoolean();
/* 2799 */     this.flattenedAttrNum = paramObjectInputStream.readInt();
/*      */   }
/*      */   
/*      */   public void setConnection(OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/* 2805 */     synchronized (paramOracleConnection)
/*      */     {
/* 2807 */       this.connection = paramOracleConnection;
/* 2808 */       for (int i = 0; i < this.attrTypes.length; i++) {
/* 2809 */         this.attrTypes[i].setConnection(this.connection);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void setStatusBits(int paramInt)
/*      */   {
/* 2816 */     synchronized (this.connection)
/*      */     {
/* 2818 */       this.statusBits |= paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void maskAndSetStatusBits(int paramInt1, int paramInt2)
/*      */   {
/* 2825 */     synchronized (this.connection)
/*      */     {
/* 2827 */       this.statusBits &= paramInt1;
/* 2828 */       this.statusBits |= paramInt2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void printUnsignedByteArray(byte[] paramArrayOfByte, PrintWriter paramPrintWriter)
/*      */   {
/* 2837 */     int i = paramArrayOfByte.length;
/*      */     
/*      */ 
/* 2840 */     int[] arrayOfInt = Util.toJavaUnsignedBytes(paramArrayOfByte);
/*      */     
/* 2842 */     for (int j = 0; j < i; j++)
/*      */     {
/* 2844 */       paramPrintWriter.print("0x" + Integer.toHexString(arrayOfInt[j]) + " ");
/*      */     }
/*      */     
/* 2847 */     paramPrintWriter.println();
/*      */     
/* 2849 */     for (j = 0; j < i; j++)
/*      */     {
/* 2851 */       paramPrintWriter.print(arrayOfInt[j] + " ");
/*      */     }
/*      */     
/* 2854 */     paramPrintWriter.println();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void initChildNamesRecursively(Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 2862 */     TypeTreeElement localTypeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName);
/*      */     
/* 2864 */     if ((this.attrTypes != null) && (this.attrTypes.length > 0))
/*      */     {
/* 2866 */       for (int i = 0; i < this.attrTypes.length; i++)
/*      */       {
/* 2868 */         OracleType localOracleType = this.attrTypes[i];
/* 2869 */         localOracleType.setNames(localTypeTreeElement.getChildSchemaName(i + 1), localTypeTreeElement.getChildTypeName(i + 1));
/* 2870 */         localOracleType.initChildNamesRecursively(paramMap);
/* 2871 */         localOracleType.cacheDescriptor();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void cacheDescriptor()
/*      */     throws SQLException
/*      */   {
/* 2880 */     this.descriptor = StructDescriptor.createDescriptor(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2889 */     printXML(paramPrintWriter, paramInt, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2899 */     for (int i = 0; i < paramInt; i++) paramPrintWriter.print("  ");
/* 2900 */     paramPrintWriter.print("<OracleTypeADT sqlName=\"" + this.sqlName + "\" ");
/*      */     
/* 2902 */     paramPrintWriter.print(" typecode=\"" + this.typeCode + "\"");
/* 2903 */     if (this.tdsVersion != 55537)
/* 2904 */       paramPrintWriter.print(" tds_version=\"" + this.tdsVersion + "\"");
/* 2905 */     paramPrintWriter.println();
/* 2906 */     for (i = 0; i < paramInt + 4; i++) paramPrintWriter.print("  ");
/* 2907 */     paramPrintWriter.println(" is_embedded=\"" + isEmbeddedADT() + "\"" + " is_top_level=\"" + isTopADT() + "\"" + " is_upt=\"" + isUptADT() + "\"" + " finalType=\"" + isFinalType() + "\"" + " subtype=\"" + isSubType() + "\">");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2913 */     if ((this.attrTypes != null) && (this.attrTypes.length > 0))
/*      */     {
/* 2915 */       for (i = 0; i < paramInt + 1; i++) paramPrintWriter.print("  ");
/* 2916 */       paramPrintWriter.println("<attributes>");
/* 2917 */       for (i = 0; i < this.attrTypes.length; i++)
/*      */       {
/* 2919 */         for (int j = 0; j < paramInt + 2; j++) { paramPrintWriter.print("  ");
/*      */         }
/*      */         
/* 2922 */         paramPrintWriter.println("<attribute name=\"" + getAttributeName(i + 1, paramBoolean) + "\" " + " type=\"" + getAttributeType(i + 1, false) + "\" >");
/*      */         
/*      */ 
/* 2925 */         this.attrTypes[i].printXML(paramPrintWriter, paramInt + 3, paramBoolean);
/* 2926 */         for (j = 0; j < paramInt + 2; j++) paramPrintWriter.print("  ");
/* 2927 */         paramPrintWriter.println("</attribute> ");
/*      */       }
/* 2929 */       for (i = 0; i < paramInt + 1; i++) paramPrintWriter.print("  ");
/* 2930 */       paramPrintWriter.println("</attributes>");
/*      */     }
/* 2932 */     for (i = 0; i < paramInt; i++) paramPrintWriter.print("  ");
/* 2933 */     paramPrintWriter.println("</OracleTypeADT>");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2992 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\oracore\OracleTypeADT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */