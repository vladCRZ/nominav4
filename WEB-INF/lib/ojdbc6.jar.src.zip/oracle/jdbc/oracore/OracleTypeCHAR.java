/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeCHAR
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -6899444518695804629L;
/*     */   int form;
/*     */   int charset;
/*     */   int length;
/*     */   int characterSemantic;
/*     */   private transient OracleConnection connection;
/*     */   private short pickleCharaterSetId;
/*     */   private transient CharacterSet pickleCharacterSet;
/*     */   private short pickleNcharCharacterSet;
/*     */   static final int SQLCS_IMPLICIT = 1;
/*     */   static final int SQLCS_NCHAR = 2;
/*     */   static final int SQLCS_EXPLICIT = 3;
/*     */   static final int SQLCS_FLEXIBLE = 4;
/*     */   static final int SQLCS_LIT_NULL = 5;
/*     */   
/*     */   protected OracleTypeCHAR() {}
/*     */   
/*     */   public OracleTypeCHAR(OracleConnection paramOracleConnection)
/*     */   {
/*  68 */     this.form = 0;
/*  69 */     this.charset = 0;
/*  70 */     this.length = 0;
/*  71 */     this.connection = paramOracleConnection;
/*  72 */     this.pickleCharaterSetId = 0;
/*  73 */     this.pickleNcharCharacterSet = 0;
/*  74 */     this.pickleCharacterSet = null;
/*     */     
/*     */     try
/*     */     {
/*  78 */       this.pickleCharaterSetId = this.connection.getStructAttrCsId();
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/*  83 */       this.pickleCharaterSetId = -1;
/*     */     }
/*     */     
/*  86 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */   
/*     */ 
/*     */   protected OracleTypeCHAR(OracleConnection paramOracleConnection, int paramInt)
/*     */   {
/*  92 */     super(paramInt);
/*     */     
/*  94 */     this.form = 0;
/*  95 */     this.charset = 0;
/*  96 */     this.length = 0;
/*  97 */     this.connection = paramOracleConnection;
/*  98 */     this.pickleCharaterSetId = 0;
/*  99 */     this.pickleNcharCharacterSet = 0;
/* 100 */     this.pickleCharacterSet = null;
/*     */     
/*     */     try
/*     */     {
/* 104 */       this.pickleCharaterSetId = this.connection.getStructAttrCsId();
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException)
/*     */     {
/*     */ 
/* 110 */       this.pickleCharaterSetId = -1;
/*     */     }
/*     */     
/* 113 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection)
/*     */     throws SQLException
/*     */   {
/* 139 */     if (paramObject == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     CHAR localCHAR = (paramObject instanceof CHAR) ? (CHAR)paramObject : new CHAR(paramObject, this.pickleCharacterSet);
/*     */     
/* 144 */     return localCHAR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt)
/*     */     throws SQLException
/*     */   {
/* 166 */     Datum[] arrayOfDatum = null;
/*     */     
/* 168 */     if (paramObject != null)
/*     */     {
/* 170 */       if (((paramObject instanceof Object[])) && (!(paramObject instanceof char[][]))) {
/* 171 */         return super.toDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */       }
/* 173 */       arrayOfDatum = cArrayToDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */     }
/*     */     
/* 176 */     return arrayOfDatum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseTDSrec(TDSReader paramTDSReader)
/*     */     throws SQLException
/*     */   {
/* 191 */     super.parseTDSrec(paramTDSReader);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 196 */       this.length = paramTDSReader.readUB2();
/* 197 */       this.form = paramTDSReader.readByte();
/* 198 */       this.characterSemantic = (this.form & 0x80);
/* 199 */       this.form &= 0x7F;
/* 200 */       this.charset = paramTDSReader.readUB2();
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException1)
/*     */     {
/* 205 */       SQLException localSQLException3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/* 206 */       localSQLException3.fillInStackTrace();
/* 207 */       throw localSQLException3;
/*     */     }
/*     */     
/*     */ 
/* 211 */     if ((this.form != 2) || (this.pickleNcharCharacterSet != 0)) {
/* 212 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 220 */       this.pickleNcharCharacterSet = this.connection.getStructAttrNCsId();
/*     */ 
/*     */     }
/*     */     catch (SQLException localSQLException2)
/*     */     {
/*     */ 
/* 226 */       this.pickleNcharCharacterSet = 2000;
/*     */     }
/*     */     
/* 229 */     this.pickleCharaterSetId = this.pickleNcharCharacterSet;
/* 230 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum)
/*     */     throws SQLException
/*     */   {
/* 256 */     CHAR localCHAR = getDbCHAR(paramDatum);
/*     */     SQLException localSQLException;
/* 258 */     if ((this.characterSemantic != 0) && (this.form != 2))
/*     */     {
/*     */ 
/*     */ 
/* 262 */       if (localCHAR.getStringWithReplacement().length() > this.length)
/*     */       {
/* 264 */         localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + localCHAR.getStringWithReplacement() + "\"");
/* 265 */         localSQLException.fillInStackTrace();
/* 266 */         throw localSQLException;
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */     }
/* 273 */     else if (localCHAR.getLength() > this.length)
/*     */     {
/* 275 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + localCHAR.getStringWithReplacement() + "\"");
/* 276 */       localSQLException.fillInStackTrace();
/* 277 */       throw localSQLException;
/*     */     }
/*     */     
/*     */ 
/* 281 */     return super.pickle81(paramPickleContext, localCHAR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object toObject(byte[] paramArrayOfByte, int paramInt, Map paramMap)
/*     */     throws SQLException
/*     */   {
/* 293 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
/* 294 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 298 */     CHAR localCHAR = null;
/*     */     
/* 300 */     switch (this.form)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/*     */     case 2: 
/* 308 */       localCHAR = new CHAR(paramArrayOfByte, this.pickleCharacterSet);
/*     */       
/* 310 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 5: 
/* 317 */       localCHAR = new CHAR(paramArrayOfByte, null);
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 322 */     if (paramInt == 1)
/* 323 */       return localCHAR;
/* 324 */     if (paramInt == 2)
/* 325 */       return localCHAR.stringValue();
/* 326 */     if (paramInt == 3) {
/* 327 */       return paramArrayOfByte;
/*     */     }
/*     */     
/* 330 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfByte);
/* 331 */     localSQLException.fillInStackTrace();
/* 332 */     throw localSQLException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CHAR getDbCHAR(Datum paramDatum)
/*     */   {
/* 346 */     CHAR localCHAR1 = (CHAR)paramDatum;
/* 347 */     CHAR localCHAR2 = null;
/*     */     
/* 349 */     if (localCHAR1.getCharacterSet().getOracleId() == this.pickleCharaterSetId)
/*     */     {
/* 351 */       localCHAR2 = localCHAR1;
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 357 */         localCHAR2 = new CHAR(localCHAR1.toString(), this.pickleCharacterSet);
/*     */ 
/*     */       }
/*     */       catch (SQLException localSQLException)
/*     */       {
/*     */ 
/* 363 */         localCHAR2 = localCHAR1;
/*     */       }
/*     */     }
/* 366 */     return localCHAR2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Datum[] cArrayToDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt)
/*     */     throws SQLException
/*     */   {
/* 395 */     Datum[] arrayOfDatum = null;
/*     */     
/* 397 */     if (paramObject != null) { Object localObject;
/*     */       int i;
/* 399 */       int j; if ((paramObject instanceof char[][]))
/*     */       {
/* 401 */         localObject = (char[][])paramObject;
/* 402 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 405 */         arrayOfDatum = new Datum[i];
/*     */         
/* 407 */         for (j = 0; j < i; j++) {
/* 408 */           arrayOfDatum[j] = new CHAR(new String(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 411 */       else if ((paramObject instanceof boolean[]))
/*     */       {
/* 413 */         localObject = (boolean[])paramObject;
/* 414 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 417 */         arrayOfDatum = new Datum[i];
/*     */         
/* 419 */         for (j = 0; j < i; j++) {
/* 420 */           arrayOfDatum[j] = new CHAR(Boolean.valueOf(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 423 */       else if ((paramObject instanceof short[]))
/*     */       {
/* 425 */         localObject = (short[])paramObject;
/* 426 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 429 */         arrayOfDatum = new Datum[i];
/*     */         
/*     */ 
/*     */ 
/* 433 */         for (j = 0; j < i; j++) {
/* 434 */           arrayOfDatum[j] = new CHAR(Integer.valueOf(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */         
/*     */       }
/* 438 */       else if ((paramObject instanceof int[]))
/*     */       {
/* 440 */         localObject = (int[])paramObject;
/* 441 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 444 */         arrayOfDatum = new Datum[i];
/*     */         
/* 446 */         for (j = 0; j < i; j++) {
/* 447 */           arrayOfDatum[j] = new CHAR(Integer.valueOf(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 450 */       else if ((paramObject instanceof long[]))
/*     */       {
/* 452 */         localObject = (long[])paramObject;
/* 453 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 456 */         arrayOfDatum = new Datum[i];
/*     */         
/* 458 */         for (j = 0; j < i; j++) {
/* 459 */           arrayOfDatum[j] = new CHAR(new Long(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 462 */       else if ((paramObject instanceof float[]))
/*     */       {
/* 464 */         localObject = (float[])paramObject;
/* 465 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 468 */         arrayOfDatum = new Datum[i];
/*     */         
/* 470 */         for (j = 0; j < i; j++) {
/* 471 */           arrayOfDatum[j] = new CHAR(new Float(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 474 */       else if ((paramObject instanceof double[]))
/*     */       {
/* 476 */         localObject = (double[])paramObject;
/* 477 */         i = (int)(paramInt == -1 ? localObject.length : Math.min(localObject.length - paramLong + 1L, paramInt));
/*     */         
/*     */ 
/* 480 */         arrayOfDatum = new Datum[i];
/*     */         
/* 482 */         for (j = 0; j < i; j++) {
/* 483 */           arrayOfDatum[j] = new CHAR(new Double(localObject[((int)paramLong + j - 1)]), this.pickleCharacterSet);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 489 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 490 */         ((SQLException)localObject).fillInStackTrace();
/* 491 */         throw ((Throwable)localObject);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 496 */     return arrayOfDatum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 503 */     return this.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream)
/*     */     throws IOException
/*     */   {
/* 514 */     paramObjectOutputStream.writeInt(this.form);
/* 515 */     paramObjectOutputStream.writeInt(this.charset);
/* 516 */     paramObjectOutputStream.writeInt(this.length);
/* 517 */     paramObjectOutputStream.writeInt(this.characterSemantic);
/* 518 */     paramObjectOutputStream.writeShort(this.pickleCharaterSetId);
/* 519 */     paramObjectOutputStream.writeShort(this.pickleNcharCharacterSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream paramObjectInputStream)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 527 */     this.form = paramObjectInputStream.readInt();
/* 528 */     this.charset = paramObjectInputStream.readInt();
/* 529 */     this.length = paramObjectInputStream.readInt();
/* 530 */     this.characterSemantic = paramObjectInputStream.readInt();
/* 531 */     this.pickleCharaterSetId = paramObjectInputStream.readShort();
/* 532 */     this.pickleNcharCharacterSet = paramObjectInputStream.readShort();
/*     */     
/* 534 */     if (this.pickleNcharCharacterSet != 0) {
/* 535 */       this.pickleCharacterSet = CharacterSet.make(this.pickleNcharCharacterSet);
/*     */     } else {
/* 537 */       this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setConnection(OracleConnection paramOracleConnection)
/*     */     throws SQLException
/*     */   {
/* 544 */     this.connection = paramOracleConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNCHAR()
/*     */     throws SQLException
/*     */   {
/* 558 */     return this.form == 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 573 */     return this.connection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 618 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\oracore\OracleTypeCHAR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */