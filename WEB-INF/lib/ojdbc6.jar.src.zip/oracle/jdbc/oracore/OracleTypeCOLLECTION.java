/*      */ package oracle.jdbc.oracore;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleTypeCOLLECTION
/*      */   extends OracleTypeADT
/*      */   implements Serializable
/*      */ {
/*      */   static final long serialVersionUID = -7279638692691669378L;
/*      */   public static final int TYPE_PLSQL_INDEX_TABLE = 1;
/*      */   public static final int TYPE_NESTED_TABLE = 2;
/*      */   public static final int TYPE_VARRAY = 3;
/*   59 */   int userCode = 0;
/*   60 */   long maxSize = 0L;
/*   61 */   OracleType elementType = null;
/*      */   static final int CURRENT_USER_OBJECT = 0;
/*      */   static final int CURRENT_USER_SYNONYM = 1;
/*      */   static final int CURRENT_USER_SYNONYM_10g = 2;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT = 5;
/*      */   
/*      */   public OracleTypeCOLLECTION(String paramString, OracleConnection paramOracleConnection) throws SQLException {
/*   70 */     super(paramString, paramOracleConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public OracleTypeCOLLECTION(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*   78 */     super(paramOracleTypeADT, paramInt, paramOracleConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OracleTypeCOLLECTION(SQLName paramSQLName, byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*   89 */     super(paramSQLName, paramArrayOfByte1, paramInt, paramArrayOfByte2, paramOracleConnection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/*  105 */     if (paramObject != null)
/*      */     {
/*  107 */       if ((paramObject instanceof ARRAY)) {
/*  108 */         return (ARRAY)paramObject;
/*      */       }
/*      */       
/*  111 */       ArrayDescriptor localArrayDescriptor = createArrayDescriptor();
/*      */       
/*  113 */       return new ARRAY(localArrayDescriptor, this.connection, paramObject);
/*      */     }
/*      */     
/*      */ 
/*  117 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTypeCode()
/*      */   {
/*  129 */     return 2003;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isInHierarchyOf(OracleType paramOracleType)
/*      */     throws SQLException
/*      */   {
/*  140 */     if (paramOracleType == null) {
/*  141 */       return false;
/*      */     }
/*  143 */     if (paramOracleType == this) {
/*  144 */       return true;
/*      */     }
/*  146 */     if (paramOracleType.getClass() != getClass()) {
/*  147 */       return false;
/*      */     }
/*  149 */     return paramOracleType.getTypeDescriptor().getName().equals(this.descriptor.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor)
/*      */     throws SQLException
/*      */   {
/*  158 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isObjectType()
/*      */   {
/*  165 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void parseTDSrec(TDSReader paramTDSReader)
/*      */     throws SQLException
/*      */   {
/*  179 */     long l = paramTDSReader.readLong();
/*      */     
/*      */ 
/*      */ 
/*  183 */     this.maxSize = paramTDSReader.readLong();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */     this.userCode = paramTDSReader.readByte();
/*      */     
/*      */ 
/*  192 */     paramTDSReader.addSimplePatch(l, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum unlinearize(byte[] paramArrayOfByte, long paramLong, Datum paramDatum, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  204 */     return unlinearize(paramArrayOfByte, paramLong, paramDatum, 1L, -1, paramInt, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Datum unlinearize(byte[] paramArrayOfByte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  213 */     OracleConnection localOracleConnection = getConnection();
/*  214 */     Datum localDatum = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  219 */     if (localOracleConnection == null)
/*      */     {
/*  221 */       localDatum = unlinearizeInternal(paramArrayOfByte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  226 */       synchronized (localOracleConnection)
/*      */       {
/*  228 */         localDatum = unlinearizeInternal(paramArrayOfByte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  233 */     return localDatum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Datum unlinearizeInternal(byte[] paramArrayOfByte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  245 */     if (paramArrayOfByte == null) {
/*  246 */       return null;
/*      */     }
/*      */     
/*  249 */     PickleContext localPickleContext = new PickleContext(paramArrayOfByte, paramLong1);
/*      */     
/*  251 */     return unpickle81(localPickleContext, (ARRAY)paramDatum, paramLong2, paramInt1, 1, paramInt2, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isInlineImage(byte[] paramArrayOfByte, int paramInt)
/*      */     throws SQLException
/*      */   {
/*  262 */     if (paramArrayOfByte == null) {
/*  263 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  267 */     if (PickleContext.isCollectionImage_pctx(paramArrayOfByte[paramInt]))
/*  268 */       return true;
/*  269 */     if (PickleContext.isDegenerateImage_pctx(paramArrayOfByte[paramInt])) {
/*  270 */       return false;
/*      */     }
/*      */     
/*  273 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
/*  274 */     localSQLException.fillInStackTrace();
/*  275 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum)
/*      */     throws SQLException
/*      */   {
/*  289 */     ARRAY localARRAY = (ARRAY)paramDatum;
/*      */     
/*  291 */     boolean bool = localARRAY.hasDataSeg();
/*  292 */     int i = 0;
/*  293 */     int j = paramPickleContext.offset() + 2;
/*      */     
/*  295 */     if (bool)
/*      */     {
/*  297 */       if (!this.metaDataInitialized) {
/*  298 */         copy_properties((OracleTypeCOLLECTION)localARRAY.getDescriptor().getPickler());
/*      */       }
/*  300 */       Datum[] arrayOfDatum = localARRAY.getOracleArray();
/*      */       
/*      */ 
/*  303 */       if (this.userCode == 3)
/*      */       {
/*  305 */         if (arrayOfDatum.length > this.maxSize)
/*      */         {
/*  307 */           SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 71, null);
/*  308 */           localSQLException.fillInStackTrace();
/*  309 */           throw localSQLException;
/*      */         }
/*      */       }
/*      */       
/*  313 */       i += paramPickleContext.writeCollImageHeader(arrayOfDatum.length, this.typeVersion);
/*      */       
/*  315 */       for (int k = 0; k < arrayOfDatum.length; k++)
/*      */       {
/*  317 */         if (arrayOfDatum[k] == null) {
/*  318 */           i += paramPickleContext.writeElementNull();
/*      */         } else {
/*  320 */           i += this.elementType.pickle81(paramPickleContext, arrayOfDatum[k]);
/*      */         }
/*  322 */         String str = "idx=" + k + " is " + arrayOfDatum[k];
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  328 */       i += paramPickleContext.writeCollImageHeader(localARRAY.getLocator());
/*      */     }
/*      */     
/*  331 */     paramPickleContext.patchImageLen(j, i);
/*      */     
/*  333 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  344 */     return unpickle81(paramPickleContext, paramARRAY, 1L, -1, paramInt1, paramInt2, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, int paramInt3, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  358 */     ARRAY localARRAY = paramARRAY;
/*      */     
/*  360 */     if (localARRAY == null)
/*      */     {
/*  362 */       ArrayDescriptor localArrayDescriptor = createArrayDescriptor();
/*      */       
/*  364 */       localARRAY = new ARRAY(localArrayDescriptor, (byte[])null, this.connection);
/*      */     }
/*      */     
/*  367 */     if (unpickle81ImgHeader(paramPickleContext, localARRAY, paramInt2, paramInt3))
/*      */     {
/*  369 */       if ((paramLong == 1L) && (paramInt1 == -1)) {
/*  370 */         unpickle81ImgBody(paramPickleContext, localARRAY, paramInt3, paramMap);
/*      */       } else {
/*  372 */         unpickle81ImgBody(paramPickleContext, localARRAY, paramLong, paramInt1, paramInt3, paramMap);
/*      */       }
/*      */     }
/*      */     
/*  376 */     return localARRAY;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   boolean unpickle81ImgHeader(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/*  384 */     int i = 1;
/*      */     
/*  386 */     if (paramInt1 == 3)
/*      */     {
/*  388 */       paramARRAY.setImage(paramPickleContext.image(), paramPickleContext.absoluteOffset(), 0L);
/*      */     }
/*      */     
/*  391 */     byte b = paramPickleContext.readByte();
/*      */     SQLException localSQLException;
/*  393 */     if (!PickleContext.is81format(b))
/*      */     {
/*  395 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
/*  396 */       localSQLException.fillInStackTrace();
/*  397 */       throw localSQLException;
/*      */     }
/*      */     
/*  400 */     if (!PickleContext.hasPrefix(b))
/*      */     {
/*  402 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image has no prefix segment");
/*  403 */       localSQLException.fillInStackTrace();
/*  404 */       throw localSQLException;
/*      */     }
/*      */     
/*  407 */     if (PickleContext.isCollectionImage_pctx(b)) {
/*  408 */       i = 1;
/*  409 */     } else if (PickleContext.isDegenerateImage_pctx(b)) {
/*  410 */       i = 0;
/*      */     }
/*      */     else {
/*  413 */       localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
/*  414 */       localSQLException.fillInStackTrace();
/*  415 */       throw localSQLException;
/*      */     }
/*      */     
/*      */ 
/*  419 */     paramPickleContext.readByte();
/*      */     
/*      */ 
/*  422 */     if (paramInt1 == 9)
/*      */     {
/*  424 */       paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2);
/*      */       
/*  426 */       return false;
/*      */     }
/*  428 */     if (paramInt1 == 3)
/*      */     {
/*  430 */       long l = paramPickleContext.readLength();
/*      */       
/*  432 */       paramARRAY.setImageLength(l);
/*  433 */       paramPickleContext.skipTo(paramARRAY.getImageOffset() + l);
/*      */       
/*  435 */       return false;
/*      */     }
/*      */     
/*  438 */     paramPickleContext.skipLength();
/*      */     
/*      */ 
/*  441 */     int j = paramPickleContext.readLength();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  446 */     paramARRAY.setPrefixFlag(paramPickleContext.readByte());
/*      */     
/*  448 */     if (paramARRAY.isInline())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  455 */       paramPickleContext.readDataValue(j - 1);
/*      */     }
/*      */     else
/*      */     {
/*  459 */       paramARRAY.setLocator(paramPickleContext.readDataValue(j - 1));
/*      */     }
/*      */     
/*  462 */     return paramARRAY.isInline();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  474 */     paramPickleContext.readByte();
/*      */     
/*      */ 
/*  477 */     int i = paramPickleContext.readLength();
/*      */     
/*  479 */     paramARRAY.setLength(i);
/*      */     
/*  481 */     if (paramInt2 == 0) {
/*  482 */       return;
/*      */     }
/*      */     
/*      */ 
/*  486 */     int j = (int)getAccessLength(i, paramLong, paramInt1);
/*  487 */     int k = ArrayDescriptor.getCacheStyle(paramARRAY) == 1 ? 1 : 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  492 */     if ((paramLong > 1L) && (j > 0))
/*      */     {
/*  494 */       long l1 = paramARRAY.getLastIndex();
/*      */       long l2;
/*  496 */       if (l1 < paramLong)
/*      */       {
/*  498 */         if (l1 > 0L) {
/*  499 */           paramPickleContext.skipTo(paramARRAY.getLastOffset());
/*      */         } else {
/*  501 */           l1 = 1L;
/*      */         }
/*  503 */         if (k != 0)
/*      */         {
/*  505 */           for (l2 = l1; l2 < paramLong; l2 += 1L)
/*      */           {
/*  507 */             paramARRAY.setIndexOffset(l2, paramPickleContext.offset());
/*  508 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/*  513 */           for (l2 = l1; l2 < paramLong; l2 += 1L) {
/*  514 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         }
/*  517 */       } else if (l1 > paramLong)
/*      */       {
/*  519 */         l2 = paramARRAY.getOffset(paramLong);
/*      */         
/*  521 */         if (l2 != -1L)
/*      */         {
/*  523 */           paramPickleContext.skipTo(l2);
/*      */         }
/*      */         else {
/*      */           int m;
/*  527 */           if (k != 0)
/*      */           {
/*  529 */             for (m = 1; m < paramLong; m++)
/*      */             {
/*  531 */               paramARRAY.setIndexOffset(m, paramPickleContext.offset());
/*  532 */               this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */             }
/*      */             
/*      */           }
/*      */           else {
/*  537 */             for (m = 1; m < paramLong; m++) {
/*  538 */               this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/*  543 */         paramPickleContext.skipTo(paramARRAY.getLastOffset());
/*      */       }
/*  545 */       paramARRAY.setLastIndexOffset(paramLong, paramPickleContext.offset());
/*      */     }
/*      */     
/*      */ 
/*  549 */     unpickle81ImgBodyElements(paramPickleContext, paramARRAY, (int)paramLong, j, paramInt2, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  561 */     paramPickleContext.readByte();
/*      */     
/*      */ 
/*  564 */     int i = paramPickleContext.readLength();
/*      */     
/*  566 */     paramARRAY.setLength(i);
/*      */     
/*  568 */     if (paramInt == 0) {
/*  569 */       return;
/*      */     }
/*      */     
/*      */ 
/*  573 */     unpickle81ImgBodyElements(paramPickleContext, paramARRAY, 1, i, paramInt, paramMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void unpickle81ImgBodyElements(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, int paramInt3, Map paramMap)
/*      */     throws SQLException
/*      */   {
/*  584 */     int i = ArrayDescriptor.getCacheStyle(paramARRAY) == 1 ? 1 : 0;
/*      */     
/*      */     Object localObject;
/*      */     int j;
/*  588 */     switch (paramInt3)
/*      */     {
/*      */ 
/*      */ 
/*      */     case 1: 
/*  593 */       localObject = new Datum[paramInt2];
/*      */       
/*  595 */       if (i != 0)
/*      */       {
/*  597 */         for (j = 0; j < paramInt2; j++)
/*      */         {
/*  599 */           paramARRAY.setIndexOffset(paramInt1 + j, paramPickleContext.offset());
/*      */           
/*  601 */           localObject[j] = ((Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap));
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  607 */         for (j = 0; j < paramInt2; j++) {
/*  608 */           localObject[j] = ((Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap));
/*      */         }
/*      */       }
/*      */       
/*  612 */       paramARRAY.setDatumArray((Datum[])localObject);
/*      */       
/*      */ 
/*  615 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*  619 */       localObject = ArrayDescriptor.makeJavaArray(paramInt2, this.elementType.getTypeCode());
/*      */       
/*      */ 
/*  622 */       if (i != 0)
/*      */       {
/*  624 */         for (j = 0; j < paramInt2; j++)
/*      */         {
/*  626 */           paramARRAY.setIndexOffset(paramInt1 + j, paramPickleContext.offset());
/*      */           
/*  628 */           localObject[j] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/*  633 */         for (j = 0; j < paramInt2; j++) {
/*  634 */           localObject[j] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */         }
/*      */       }
/*  637 */       paramARRAY.setObjArray(localObject);
/*      */       
/*      */ 
/*  640 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*  652 */       if (((this.elementType instanceof OracleTypeNUMBER)) || ((this.elementType instanceof OracleTypeFLOAT)))
/*      */       {
/*      */ 
/*  655 */         paramARRAY.setObjArray(OracleTypeNUMBER.unpickle81NativeArray(paramPickleContext, 1L, paramInt2, paramInt3));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  660 */         localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "This feature is limited to numeric collection");
/*  661 */         ((SQLException)localObject).fillInStackTrace();
/*  662 */         throw ((Throwable)localObject);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 3: 
/*      */     default: 
/*  670 */       localObject = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "Invalid conversion type " + this.elementType);
/*  671 */       ((SQLException)localObject).fillInStackTrace();
/*  672 */       throw ((Throwable)localObject);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  677 */     paramARRAY.setLastIndexOffset(paramInt1 + paramInt2, paramPickleContext.offset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
/*      */   
/*      */ 
/*      */   static final int OTHER_USER_OBJECT = 7;
/*      */   
/*      */ 
/*      */   static final int OTHER_USER_SYNONYM = 8;
/*      */   
/*      */ 
/*      */   static final int PUBLIC_SYNONYM = 9;
/*      */   
/*      */ 
/*      */   static final int PUBLIC_SYNONYM_10g = 10;
/*      */   
/*      */ 
/*      */   static final int BREAK = 11;
/*      */   
/*      */ 
/*  700 */   static final String[] sqlString = { "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME = :1", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = :1 AND TYPE_NAME = :2", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initCollElemTypeName()
/*      */     throws SQLException
/*      */   {
/*  806 */     if (this.connection == null)
/*  807 */       return;
/*  808 */     synchronized (this.connection) {
/*  809 */       if (this.sqlName == null) {
/*  810 */         getFullName();
/*      */       }
/*  812 */       CallableStatement localCallableStatement = null;
/*  813 */       PreparedStatement localPreparedStatement = null;
/*  814 */       ResultSet localResultSet = null;
/*      */       try {
/*  816 */         int i = this.sqlName.getSchema().equalsIgnoreCase(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7;
/*      */         
/*      */ 
/*  819 */         while (i != 11)
/*      */         {
/*  821 */           switch (i)
/*      */           {
/*      */ 
/*      */           case 0: 
/*  825 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/*  826 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/*  827 */             localPreparedStatement.setFetchSize(1);
/*  828 */             localResultSet = localPreparedStatement.executeQuery();
/*  829 */             i = 1;
/*  830 */             break;
/*      */           
/*      */           case 1: 
/*  833 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/*  835 */               i = 2;
/*      */             }
/*      */           
/*      */ 
/*      */           case 2: 
/*  840 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/*  841 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/*  842 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/*  843 */             localPreparedStatement.setFetchSize(1);
/*  844 */             localResultSet = localPreparedStatement.executeQuery();
/*  845 */             i = 3;
/*  846 */             break;
/*      */           
/*      */           case 3: 
/*  849 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/*  851 */               i = 4;
/*      */             }
/*      */           
/*      */ 
/*      */           case 4: 
/*  856 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/*  857 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/*  858 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/*  859 */             localPreparedStatement.setFetchSize(1);
/*  860 */             localResultSet = localPreparedStatement.executeQuery();
/*  861 */             i = 5;
/*  862 */             break;
/*      */           
/*      */           case 5: 
/*  865 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/*  867 */               i = 6;
/*      */             }
/*      */           
/*      */ 
/*      */           case 6: 
/*  872 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/*  873 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/*  874 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/*  875 */             localPreparedStatement.setFetchSize(1);
/*  876 */             localResultSet = localPreparedStatement.executeQuery();
/*  877 */             i = 8;
/*  878 */             break;
/*      */           
/*      */ 
/*      */           case 7: 
/*  882 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/*  883 */             localPreparedStatement.setString(1, this.sqlName.getSchema());
/*  884 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/*  885 */             localPreparedStatement.setFetchSize(1);
/*  886 */             localResultSet = localPreparedStatement.executeQuery();
/*  887 */             i = 8;
/*  888 */             break;
/*      */           
/*      */ 
/*      */           case 8: 
/*  892 */             localPreparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[i]);
/*  893 */             localPreparedStatement.setString(1, this.sqlName.getSimpleName());
/*  894 */             localPreparedStatement.setString(2, this.sqlName.getSimpleName());
/*  895 */             localPreparedStatement.setFetchSize(1);
/*  896 */             localResultSet = localPreparedStatement.executeQuery();
/*  897 */             i = 9;
/*  898 */             break;
/*      */           
/*      */           case 9: 
/*  901 */             if (this.connection.getVersionNumber() >= 10000)
/*      */             {
/*  903 */               i = 10;
/*      */             }
/*      */           
/*      */ 
/*      */           case 10: 
/*  908 */             localCallableStatement = this.connection.prepareCall(getSqlHint() + sqlString[i]);
/*  909 */             localCallableStatement.setString(1, this.sqlName.getSimpleName());
/*  910 */             localCallableStatement.registerOutParameter(2, -10);
/*  911 */             localCallableStatement.execute();
/*  912 */             localResultSet = ((OracleCallableStatement)localCallableStatement).getCursor(2);
/*  913 */             i = 11;
/*      */           }
/*      */           
/*      */           
/*  917 */           if (localResultSet.next())
/*      */           {
/*  919 */             if (this.attrTypeNames == null) {
/*  920 */               this.attrTypeNames = new String[1];
/*      */             }
/*  922 */             this.attrTypeNames[0] = (localResultSet.getString(2) + "." + localResultSet.getString(1));
/*  923 */             i = 11;
/*  924 */           } else if (i == 11)
/*      */           {
/*  926 */             SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  927 */             localSQLException.fillInStackTrace();
/*  928 */             throw localSQLException;
/*      */           }
/*      */         }
/*  931 */         while (i != 11) {}
/*      */       }
/*      */       finally {
/*  934 */         if (localResultSet != null)
/*  935 */           localResultSet.close();
/*  936 */         if (localPreparedStatement != null)
/*  937 */           localPreparedStatement.close();
/*  938 */         if (localCallableStatement != null) {
/*  939 */           localCallableStatement.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String getAttributeName(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  949 */     SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  950 */     localSQLException.fillInStackTrace();
/*  951 */     throw localSQLException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getAttributeName(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  959 */     return getAttributeName(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAttributeType(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  972 */     if (paramInt != 1)
/*      */     {
/*  974 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  975 */       localSQLException.fillInStackTrace();
/*  976 */       throw localSQLException;
/*      */     }
/*      */     
/*  979 */     if (this.sqlName == null) {
/*  980 */       getFullName();
/*      */     }
/*  982 */     if (this.attrTypeNames == null) {
/*  983 */       initCollElemTypeName();
/*      */     }
/*  985 */     return this.attrTypeNames[0];
/*      */   }
/*      */   
/*      */ 
/*      */   public String getAttributeType(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/*  992 */     if (paramBoolean) {
/*  993 */       return getAttributeType(paramInt);
/*      */     }
/*      */     
/*  996 */     if (paramInt != 1)
/*      */     {
/*  998 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  999 */       localSQLException.fillInStackTrace();
/* 1000 */       throw localSQLException;
/*      */     }
/*      */     
/* 1003 */     if ((this.sqlName != null) && (this.attrTypeNames != null)) {
/* 1004 */       return this.attrTypeNames[0];
/*      */     }
/* 1006 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getNumAttrs()
/*      */     throws SQLException
/*      */   {
/* 1014 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public OracleType getAttrTypeAt(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1021 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   ArrayDescriptor createArrayDescriptor()
/*      */     throws SQLException
/*      */   {
/* 1028 */     return new ArrayDescriptor(this, this.connection);
/*      */   }
/*      */   
/*      */ 
/*      */   ArrayDescriptor createArrayDescriptorWithItsOwnTree()
/*      */     throws SQLException
/*      */   {
/* 1035 */     if (this.descriptor == null)
/*      */     {
/* 1037 */       if ((this.sqlName == null) && (getFullName(false) == null))
/*      */       {
/* 1039 */         this.descriptor = new ArrayDescriptor(this, this.connection);
/*      */       }
/*      */       else
/*      */       {
/* 1043 */         this.descriptor = ArrayDescriptor.createDescriptor(this.sqlName, this.connection);
/*      */       }
/*      */     }
/*      */     
/* 1047 */     return (ArrayDescriptor)this.descriptor;
/*      */   }
/*      */   
/*      */ 
/*      */   public OracleType getElementType()
/*      */     throws SQLException
/*      */   {
/* 1054 */     return this.elementType;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getUserCode()
/*      */     throws SQLException
/*      */   {
/* 1061 */     return this.userCode;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getMaxLength()
/*      */     throws SQLException
/*      */   {
/* 1068 */     return this.maxSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private long getAccessLength(long paramLong1, long paramLong2, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1076 */     if (paramLong2 > paramLong1) {
/* 1077 */       return 0L;
/*      */     }
/* 1079 */     if (paramInt < 0)
/*      */     {
/* 1081 */       return paramLong1 - paramLong2 + 1L;
/*      */     }
/*      */     
/*      */ 
/* 1085 */     return Math.min(paramLong1 - paramLong2 + 1L, paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream)
/*      */     throws IOException
/*      */   {
/* 1097 */     paramObjectOutputStream.writeInt(this.userCode);
/* 1098 */     paramObjectOutputStream.writeLong(this.maxSize);
/* 1099 */     paramObjectOutputStream.writeObject(this.elementType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream paramObjectInputStream)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1107 */     this.userCode = paramObjectInputStream.readInt();
/* 1108 */     this.maxSize = paramObjectInputStream.readLong();
/* 1109 */     this.elementType = ((OracleType)paramObjectInputStream.readObject());
/*      */   }
/*      */   
/*      */ 
/*      */   public void setConnection(OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/* 1116 */     this.connection = paramOracleConnection;
/*      */     
/* 1118 */     this.elementType.setConnection(paramOracleConnection);
/*      */   }
/*      */   
/*      */ 
/*      */   public void initMetadataRecursively()
/*      */     throws SQLException
/*      */   {
/* 1125 */     initMetadata(this.connection);
/* 1126 */     if (this.elementType != null) { this.elementType.initMetadataRecursively();
/*      */     }
/*      */   }
/*      */   
/*      */   public void initChildNamesRecursively(Map paramMap)
/*      */     throws SQLException
/*      */   {
/* 1133 */     TypeTreeElement localTypeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName);
/*      */     
/* 1135 */     if (this.elementType != null)
/*      */     {
/* 1137 */       this.elementType.setNames(localTypeTreeElement.getChildSchemaName(0), localTypeTreeElement.getChildTypeName(0));
/* 1138 */       this.elementType.initChildNamesRecursively(paramMap);
/* 1139 */       this.elementType.cacheDescriptor();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void cacheDescriptor()
/*      */     throws SQLException
/*      */   {
/* 1147 */     this.descriptor = ArrayDescriptor.createDescriptor(this);
/*      */   }
/*      */   
/*      */ 
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1154 */     printXML(paramPrintWriter, paramInt, false);
/*      */   }
/*      */   
/*      */ 
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1161 */     for (int i = 0; i < paramInt; i++) paramPrintWriter.print("  ");
/* 1162 */     paramPrintWriter.println("<OracleTypeCOLLECTION sqlName=\"" + this.sqlName + "\" " + ">");
/*      */     
/*      */ 
/* 1165 */     if (this.elementType != null)
/* 1166 */       this.elementType.printXML(paramPrintWriter, paramInt + 1, paramBoolean);
/* 1167 */     for (i = 0; i < paramInt; i++) paramPrintWriter.print("  ");
/* 1168 */     paramPrintWriter.println("</OracleTypeCOLLECTION>");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1173 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\oracore\OracleTypeCOLLECTION.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */