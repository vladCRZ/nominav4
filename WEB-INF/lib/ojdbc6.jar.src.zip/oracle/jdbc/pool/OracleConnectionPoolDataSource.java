/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.PooledConnection;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleConnectionPoolDataSource
/*     */   extends OracleDataSource
/*     */   implements ConnectionPoolDataSource
/*     */ {
/*     */   public OracleConnectionPoolDataSource()
/*     */     throws SQLException
/*     */   {
/*  41 */     this.dataSourceName = "OracleConnectionPoolDataSource";
/*  42 */     this.isOracleDataSource = false;
/*     */     
/*     */ 
/*  45 */     this.connCachingEnabled = false;
/*     */     
/*     */ 
/*  48 */     this.fastConnFailover = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PooledConnection getPooledConnection()
/*     */     throws SQLException
/*     */   {
/*  63 */     String str1 = null;
/*  64 */     String str2 = null;
/*  65 */     synchronized (this)
/*     */     {
/*  67 */       str1 = this.user;
/*  68 */       str2 = this.password;
/*     */     }
/*  70 */     return getPooledConnection(str1, str2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PooledConnection getPooledConnection(String paramString1, String paramString2)
/*     */     throws SQLException
/*     */   {
/*  88 */     Connection localConnection = getPhysicalConnection(this.url, paramString1, paramString2);
/*  89 */     OraclePooledConnection localOraclePooledConnection = new OraclePooledConnection(localConnection);
/*     */     
/*     */ 
/*  92 */     if (paramString2 == null)
/*  93 */       paramString2 = this.password;
/*  94 */     localOraclePooledConnection.setUserName(!paramString1.startsWith("\"") ? paramString1.toLowerCase() : paramString1, paramString2);
/*     */     
/*     */ 
/*  97 */     return localOraclePooledConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   PooledConnection getPooledConnection(Properties paramProperties)
/*     */     throws SQLException
/*     */   {
/* 105 */     Connection localConnection = getPhysicalConnection(paramProperties);
/* 106 */     OraclePooledConnection localOraclePooledConnection = new OraclePooledConnection(localConnection);
/*     */     
/* 108 */     String str1 = paramProperties.getProperty("user");
/* 109 */     if (str1 == null)
/* 110 */       str1 = ((OracleConnection)localConnection).getUserName();
/* 111 */     String str2 = paramProperties.getProperty("password");
/* 112 */     if (str2 == null)
/* 113 */       str2 = this.password;
/* 114 */     localOraclePooledConnection.setUserName(!str1.startsWith("\"") ? str1.toLowerCase() : str1, str2);
/*     */     
/*     */ 
/* 117 */     return localOraclePooledConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection getPhysicalConnection()
/*     */     throws SQLException
/*     */   {
/* 127 */     return super.getConnection(this.user, this.password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection getPhysicalConnection(String paramString1, String paramString2, String paramString3)
/*     */     throws SQLException
/*     */   {
/* 138 */     this.url = paramString1;
/* 139 */     return super.getConnection(paramString2, paramString3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection getPhysicalConnection(String paramString1, String paramString2)
/*     */     throws SQLException
/*     */   {
/* 150 */     return super.getConnection(paramString1, paramString2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 155 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\pool\OracleConnectionPoolDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */