/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.xa.client.OracleXADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDataSourceFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable)
/*     */     throws Exception
/*     */   {
/*  42 */     Reference localReference = (Reference)paramObject;
/*  43 */     Object localObject1 = null;
/*  44 */     String str1 = localReference.getClassName();
/*  45 */     Properties localProperties = new Properties();
/*     */     Object localObject2;
/*  47 */     String str2; Object localObject3; if ((str1.equals("oracle.jdbc.pool.OracleDataSource")) || (str1.equals("oracle.jdbc.xa.client.OracleXADataSource")))
/*     */     {
/*     */ 
/*  50 */       if (str1.equals("oracle.jdbc.pool.OracleDataSource")) {
/*  51 */         localObject1 = new OracleDataSource();
/*     */       } else {
/*  53 */         localObject1 = new OracleXADataSource();
/*     */       }
/*  55 */       localObject2 = null;
/*     */       
/*     */ 
/*  58 */       if ((localObject2 = (StringRefAddr)localReference.get("connectionCachingEnabled")) != null)
/*     */       {
/*  60 */         str2 = (String)((StringRefAddr)localObject2).getContent();
/*     */         
/*  62 */         if (str2.equals(String.valueOf("true"))) {
/*  63 */           ((OracleDataSource)localObject1).setConnectionCachingEnabled(true);
/*     */         }
/*     */       }
/*  66 */       if ((localObject2 = (StringRefAddr)localReference.get("connectionCacheName")) != null)
/*     */       {
/*  68 */         ((OracleDataSource)localObject1).setConnectionCacheName((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/*  71 */       if ((localObject2 = (StringRefAddr)localReference.get("connectionCacheProperties")) != null)
/*     */       {
/*  73 */         str2 = (String)((StringRefAddr)localObject2).getContent();
/*  74 */         localObject3 = extractConnectionCacheProperties(str2);
/*     */         
/*  76 */         ((OracleDataSource)localObject1).setConnectionCacheProperties((Properties)localObject3);
/*     */       }
/*     */       
/*  79 */       if ((localObject2 = (StringRefAddr)localReference.get("fastConnectionFailoverEnabled")) != null)
/*     */       {
/*     */ 
/*  82 */         str2 = (String)((StringRefAddr)localObject2).getContent();
/*     */         
/*  84 */         if (str2.equals(String.valueOf("true"))) {
/*  85 */           ((OracleDataSource)localObject1).setFastConnectionFailoverEnabled(true);
/*     */         }
/*     */       }
/*  88 */       if ((localObject2 = (StringRefAddr)localReference.get("onsConfigStr")) != null)
/*     */       {
/*  90 */         ((OracleDataSource)localObject1).setONSConfiguration((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */     }
/*  93 */     else if (str1.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource")) {
/*  94 */       localObject1 = new OracleConnectionPoolDataSource();
/*  95 */     } else if (str1.equals("oracle.jdbc.pool.OracleOCIConnectionPool"))
/*     */     {
/*     */ 
/*  98 */       localObject1 = new OracleOCIConnectionPool();
/*     */       
/* 100 */       localObject2 = null;
/* 101 */       str2 = null;
/* 102 */       localObject3 = null;
/* 103 */       String str3 = null;
/* 104 */       String str4 = null;
/* 105 */       String str5 = null;
/* 106 */       String str6 = null;
/* 107 */       StringRefAddr localStringRefAddr = null;
/*     */       
/* 109 */       Object localObject4 = null;
/* 110 */       String str7 = null;
/*     */       
/*     */ 
/*     */ 
/* 114 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_min_limit")) != null)
/*     */       {
/* 116 */         localObject2 = (String)localStringRefAddr.getContent();
/*     */       }
/* 118 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_max_limit")) != null)
/*     */       {
/* 120 */         str2 = (String)localStringRefAddr.getContent();
/*     */       }
/* 122 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_increment")) != null)
/*     */       {
/* 124 */         localObject3 = (String)localStringRefAddr.getContent();
/*     */       }
/* 126 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_active_size")) != null)
/*     */       {
/* 128 */         str3 = (String)localStringRefAddr.getContent();
/*     */       }
/* 130 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_pool_size")) != null)
/*     */       {
/* 132 */         str4 = (String)localStringRefAddr.getContent();
/*     */       }
/* 134 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_timeout")) != null)
/*     */       {
/* 136 */         str5 = (String)localStringRefAddr.getContent();
/*     */       }
/* 138 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("connpool_nowait")) != null)
/*     */       {
/* 140 */         str6 = (String)localStringRefAddr.getContent();
/*     */       }
/* 142 */       if ((localStringRefAddr = (StringRefAddr)localReference.get("transactions_distributed")) != null)
/*     */       {
/* 144 */         str7 = (String)localStringRefAddr.getContent();
/*     */       }
/*     */       
/*     */ 
/* 148 */       localProperties.put("connpool_min_limit", localObject2);
/* 149 */       localProperties.put("connpool_max_limit", str2);
/* 150 */       localProperties.put("connpool_increment", localObject3);
/* 151 */       localProperties.put("connpool_active_size", str3);
/*     */       
/* 153 */       localProperties.put("connpool_pool_size", str4);
/* 154 */       localProperties.put("connpool_timeout", str5);
/*     */       
/* 156 */       if (str6 == "true") {
/* 157 */         localProperties.put("connpool_nowait", str6);
/*     */       }
/* 159 */       if (str7 == "true") {
/* 160 */         localProperties.put("transactions_distributed", str7);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 168 */       return null;
/*     */     }
/* 170 */     if (localObject1 != null)
/*     */     {
/*     */ 
/*     */ 
/* 174 */       localObject2 = null;
/*     */       
/* 176 */       if ((localObject2 = (StringRefAddr)localReference.get("url")) != null)
/*     */       {
/* 178 */         ((OracleDataSource)localObject1).setURL((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 181 */       if (((localObject2 = (StringRefAddr)localReference.get("userName")) != null) || ((localObject2 = (StringRefAddr)localReference.get("u")) != null) || ((localObject2 = (StringRefAddr)localReference.get("user")) != null))
/*     */       {
/*     */ 
/*     */ 
/* 185 */         ((OracleDataSource)localObject1).setUser((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 188 */       if (((localObject2 = (StringRefAddr)localReference.get("passWord")) != null) || ((localObject2 = (StringRefAddr)localReference.get("password")) != null))
/*     */       {
/*     */ 
/* 191 */         ((OracleDataSource)localObject1).setPassword((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 194 */       if (((localObject2 = (StringRefAddr)localReference.get("description")) != null) || ((localObject2 = (StringRefAddr)localReference.get("describe")) != null))
/*     */       {
/* 196 */         ((OracleDataSource)localObject1).setDescription((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/* 198 */       if (((localObject2 = (StringRefAddr)localReference.get("driverType")) != null) || ((localObject2 = (StringRefAddr)localReference.get("driver")) != null))
/*     */       {
/*     */ 
/* 201 */         ((OracleDataSource)localObject1).setDriverType((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 204 */       if (((localObject2 = (StringRefAddr)localReference.get("serverName")) != null) || ((localObject2 = (StringRefAddr)localReference.get("host")) != null))
/*     */       {
/*     */ 
/* 207 */         ((OracleDataSource)localObject1).setServerName((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 210 */       if (((localObject2 = (StringRefAddr)localReference.get("databaseName")) != null) || ((localObject2 = (StringRefAddr)localReference.get("sid")) != null))
/*     */       {
/*     */ 
/* 213 */         ((OracleDataSource)localObject1).setDatabaseName((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 216 */       if ((localObject2 = (StringRefAddr)localReference.get("serviceName")) != null)
/*     */       {
/* 218 */         ((OracleDataSource)localObject1).setServiceName((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 221 */       if (((localObject2 = (StringRefAddr)localReference.get("networkProtocol")) != null) || ((localObject2 = (StringRefAddr)localReference.get("protocol")) != null))
/*     */       {
/*     */ 
/* 224 */         ((OracleDataSource)localObject1).setNetworkProtocol((String)((StringRefAddr)localObject2).getContent());
/*     */       }
/*     */       
/* 227 */       if (((localObject2 = (StringRefAddr)localReference.get("portNumber")) != null) || ((localObject2 = (StringRefAddr)localReference.get("port")) != null))
/*     */       {
/*     */ 
/* 230 */         str2 = (String)((StringRefAddr)localObject2).getContent();
/*     */         
/* 232 */         ((OracleDataSource)localObject1).setPortNumber(Integer.parseInt(str2));
/*     */       }
/*     */       
/* 235 */       if (((localObject2 = (StringRefAddr)localReference.get("tnsentryname")) != null) || ((localObject2 = (StringRefAddr)localReference.get("tns")) != null))
/*     */       {
/*     */ 
/* 238 */         ((OracleDataSource)localObject1).setTNSEntryName((String)((StringRefAddr)localObject2).getContent());
/*     */ 
/*     */       }
/* 241 */       else if (str1.equals("oracle.jdbc.pool.OracleOCIConnectionPool"))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 258 */         str2 = null;
/*     */         
/* 260 */         if ((localObject2 = (StringRefAddr)localReference.get("connpool_is_poolcreated")) != null)
/*     */         {
/* 262 */           str2 = (String)((StringRefAddr)localObject2).getContent();
/*     */         }
/* 264 */         if (str2.equals(String.valueOf("true"))) {
/* 265 */           ((OracleOCIConnectionPool)localObject1).setPoolConfig(localProperties);
/*     */         }
/*     */       }
/*     */     }
/* 269 */     return localObject1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Properties extractConnectionCacheProperties(String paramString)
/*     */     throws SQLException
/*     */   {
/* 291 */     Properties localProperties = new Properties();
/*     */     
/*     */ 
/* 294 */     paramString = paramString.substring(1, paramString.length() - 1);
/*     */     
/*     */ 
/* 297 */     int i = paramString.indexOf("AttributeWeights", 0);
/*     */     String str1;
/* 299 */     String str3; if (i >= 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 308 */       if ((paramString.charAt(i + 16) != '=') || ((i > 0) && (paramString.charAt(i - 1) != ' ')))
/*     */       {
/*     */ 
/*     */ 
/* 312 */         localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139);
/*     */         
/* 314 */         ((SQLException)localObject1).fillInStackTrace();
/* 315 */         throw ((Throwable)localObject1);
/*     */       }
/*     */       
/*     */ 
/* 319 */       localObject1 = new Properties();
/* 320 */       int j = paramString.indexOf("}", i);
/* 321 */       str1 = paramString.substring(i, j);
/*     */       
/*     */ 
/* 324 */       String str2 = str1.substring(18);
/*     */       
/* 326 */       StringTokenizer localStringTokenizer = new StringTokenizer(str2, ", ");
/*     */       
/*     */ 
/* 329 */       synchronized (localStringTokenizer)
/*     */       {
/* 331 */         while (localStringTokenizer.hasMoreTokens())
/*     */         {
/* 333 */           str3 = localStringTokenizer.nextToken();
/* 334 */           int n = str3.length();
/* 335 */           int i1 = str3.indexOf("=");
/*     */           
/* 337 */           String str4 = str3.substring(0, i1);
/* 338 */           String str5 = str3.substring(i1 + 1, n);
/*     */           
/* 340 */           ((Properties)localObject1).setProperty(str4, str5);
/*     */         }
/*     */       }
/*     */       
/* 344 */       localProperties.put("AttributeWeights", localObject1);
/*     */       
/*     */ 
/* 347 */       if ((i > 0) && (j + 1 == paramString.length()))
/*     */       {
/* 349 */         paramString = paramString.substring(0, i - 2);
/*     */       }
/* 351 */       else if ((i > 0) && (j + 1 < paramString.length()))
/*     */       {
/* 353 */         ??? = paramString.substring(0, i - 2);
/* 354 */         str3 = paramString.substring(j + 1, paramString.length());
/*     */         
/* 356 */         paramString = ((String)???).concat(str3);
/*     */       }
/*     */       else
/*     */       {
/* 360 */         paramString = paramString.substring(j + 2, paramString.length());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 365 */     Object localObject1 = new StringTokenizer(paramString, ", ");
/*     */     
/* 367 */     synchronized (localObject1)
/*     */     {
/* 369 */       while (((StringTokenizer)localObject1).hasMoreTokens())
/*     */       {
/* 371 */         str1 = ((StringTokenizer)localObject1).nextToken();
/* 372 */         int k = str1.length();
/* 373 */         int m = str1.indexOf("=");
/*     */         
/* 375 */         ??? = str1.substring(0, m);
/* 376 */         str3 = str1.substring(m + 1, k);
/*     */         
/* 378 */         localProperties.setProperty((String)???, str3);
/*     */       }
/*     */     }
/* 381 */     return localProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OracleConnection getConnectionDuringExceptionHandling()
/*     */   {
/* 396 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 401 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\pool\OracleDataSourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */