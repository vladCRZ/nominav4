/*      */ package oracle.jdbc.pool;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import javax.sql.PooledConnection;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.xa.client.OracleXADataSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ /**
/*      */  * @deprecated
/*      */  */
/*      */ class OracleImplicitConnectionCache
/*      */ {
/*   51 */   protected OracleDataSource cacheEnabledDS = null;
/*   52 */   protected String cacheName = null;
/*   53 */   protected OracleConnectionPoolDataSource connectionPoolDS = null;
/*   54 */   protected boolean fastConnectionFailoverEnabled = false;
/*      */   
/*      */ 
/*   57 */   protected String defaultUser = null;
/*   58 */   protected String defaultPassword = null;
/*      */   
/*      */   protected static final int DEFAULT_MIN_LIMIT = 0;
/*      */   
/*      */   protected static final int DEFAULT_MAX_LIMIT = Integer.MAX_VALUE;
/*      */   
/*      */   protected static final int DEFAULT_INITIAL_LIMIT = 0;
/*      */   
/*      */   protected static final int DEFAULT_MAX_STATEMENTS_LIMIT = 0;
/*      */   
/*      */   protected static final int DEFAULT_INACTIVITY_TIMEOUT = 0;
/*      */   
/*      */   protected static final int DEFAULT_TIMETOLIVE_TIMEOUT = 0;
/*      */   
/*      */   protected static final int DEFAULT_ABANDONED_CONN_TIMEOUT = 0;
/*      */   
/*      */   protected static final int DEFAULT_CONNECTION_WAIT_TIMEOUT = 0;
/*      */   protected static final String DEFAULT_ATTRIBUTE_WEIGHT = "0";
/*      */   protected static final int DEFAULT_LOWER_THRESHOLD_LIMIT = 20;
/*      */   protected static final int DEFAULT_PROPERTY_CHECK_INTERVAL = 900;
/*      */   protected static final int CLOSE_AND_REMOVE_ALL_CONNECTIONS = 1;
/*      */   protected static final int CLOSE_AND_REMOVE_FAILOVER_CONNECTIONS = 2;
/*      */   protected static final int PROCESS_INACTIVITY_TIMEOUT = 4;
/*      */   protected static final int CLOSE_AND_REMOVE_N_CONNECTIONS = 8;
/*      */   protected static final int DISABLE_STATEMENT_CACHING = 16;
/*      */   protected static final int RESET_STATEMENT_CACHE_SIZE = 18;
/*      */   protected static final int CLOSE_AND_REMOVE_RLB_CONNECTIONS = 24;
/*      */   protected static final int ABORT_AND_CLOSE_ALL_CONNECTIONS = 32;
/*      */   public static final int REFRESH_INVALID_CONNECTIONS = 4096;
/*      */   public static final int REFRESH_ALL_CONNECTIONS = 8192;
/*      */   private static final String ATTRKEY_DELIM = "0xffff";
/*   89 */   protected int cacheMinLimit = 0;
/*   90 */   protected int cacheMaxLimit = Integer.MAX_VALUE;
/*   91 */   protected int cacheInitialLimit = 0;
/*   92 */   protected int cacheMaxStatementsLimit = 0;
/*   93 */   protected Properties cacheAttributeWeights = null;
/*   94 */   protected int cacheInactivityTimeout = 0;
/*   95 */   protected int cacheTimeToLiveTimeout = 0;
/*   96 */   protected int cacheAbandonedConnectionTimeout = 0;
/*   97 */   protected int cacheLowerThresholdLimit = 20;
/*   98 */   protected int cachePropertyCheckInterval = 900;
/*   99 */   protected boolean cacheClosestConnectionMatch = false;
/*  100 */   protected boolean cacheValidateConnection = false;
/*  101 */   protected int cacheConnectionWaitTimeout = 0;
/*      */   
/*      */   static final String MIN_LIMIT_KEY = "MinLimit";
/*      */   
/*      */   static final String MAX_LIMIT_KEY = "MaxLimit";
/*      */   
/*      */   static final String INITIAL_LIMIT_KEY = "InitialLimit";
/*      */   
/*      */   static final String MAX_STATEMENTS_LIMIT_KEY = "MaxStatementsLimit";
/*      */   
/*      */   static final String ATTRIBUTE_WEIGHTS_KEY = "AttributeWeights";
/*      */   
/*      */   static final String INACTIVITY_TIMEOUT_KEY = "InactivityTimeout";
/*      */   
/*      */   static final String TIME_TO_LIVE_TIMEOUT_KEY = "TimeToLiveTimeout";
/*      */   
/*      */   static final String ABANDONED_CONNECTION_TIMEOUT_KEY = "AbandonedConnectionTimeout";
/*      */   static final String LOWER_THRESHOLD_LIMIT_KEY = "LowerThresholdLimit";
/*      */   static final String PROPERTY_CHECK_INTERVAL_KEY = "PropertyCheckInterval";
/*      */   static final String VALIDATE_CONNECTION_KEY = "ValidateConnection";
/*      */   static final String CLOSEST_CONNECTION_MATCH_KEY = "ClosestConnectionMatch";
/*      */   static final String CONNECTION_WAIT_TIMEOUT_KEY = "ConnectionWaitTimeout";
/*      */   static final String LOCAL_TXN_COMMIT_ON_CLOSE = "LocalTransactionCommitOnClose";
/*      */   static final int INSTANCE_GOOD = 1;
/*      */   static final int INSTANCE_UNKNOWN = 2;
/*      */   static final int INSTANCE_VIOLATING = 3;
/*      */   static final int INSTANCE_NO_DATA = 4;
/*      */   static final int INSTANCE_BLOCKED = 5;
/*      */   static final int RLB_NUMBER_OF_HITS_PER_INSTANCE = 1000;
/*  130 */   int dbInstancePercentTotal = 0;
/*  131 */   boolean useGoodGroup = false;
/*  132 */   Vector instancesToRetireQueue = null;
/*  133 */   OracleDatabaseInstance instanceToRetire = null;
/*  134 */   int retireConnectionsCount = 0;
/*  135 */   int countTotal = 0;
/*      */   
/*  137 */   protected OracleConnectionCacheManager cacheManager = null;
/*  138 */   protected boolean disableConnectionRequest = false;
/*  139 */   protected OracleImplicitConnectionCacheThread timeoutThread = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  146 */   protected OracleRuntimeLoadBalancingEventHandlerThread runtimeLoadBalancingThread = null;
/*      */   
/*      */ 
/*      */ 
/*  150 */   protected OracleGravitateConnectionCacheThread gravitateCacheThread = null;
/*  151 */   protected int connectionsToRemove = 0;
/*      */   
/*      */ 
/*      */ 
/*  155 */   private HashMap userMap = null;
/*  156 */   Vector checkedOutConnectionList = null;
/*      */   
/*      */ 
/*  159 */   LinkedList databaseInstancesList = null;
/*      */   
/*  161 */   int cacheSize = 0;
/*      */   
/*      */   protected static final String EVENT_DELIMITER = " ";
/*      */   
/*  165 */   protected boolean isEntireServiceDownProcessed = false;
/*  166 */   protected int defaultUserPreFailureSize = 0;
/*  167 */   protected String dataSourceServiceName = null;
/*  168 */   protected OracleFailoverWorkerThread failoverWorkerThread = null;
/*  169 */   protected Random rand = null;
/*  170 */   protected int downEventCount = 0;
/*  171 */   protected int upEventCount = 0;
/*  172 */   protected int pendingCreationRequests = 0;
/*      */   
/*  174 */   protected int connectionClosedCount = 0;
/*  175 */   protected int connectionCreatedCount = 0;
/*  176 */   boolean cacheLocalTxnCommitOnClose = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OracleImplicitConnectionCache(OracleDataSource paramOracleDataSource, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*  188 */     this.cacheEnabledDS = paramOracleDataSource;
/*      */     
/*  190 */     initializeConnectionCache();
/*  191 */     setConnectionCacheProperties(paramProperties);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  198 */     defaultUserPrePopulateCache(this.cacheInitialLimit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void defaultUserPrePopulateCache(int paramInt)
/*      */     throws SQLException
/*      */   {
/*  211 */     if (paramInt > 0)
/*      */     {
/*  213 */       String str1 = this.defaultUser;
/*  214 */       String str2 = this.defaultPassword;
/*      */       
/*  216 */       validateUser(str1, str2);
/*      */       
/*  218 */       OraclePooledConnection localOraclePooledConnection = null;
/*      */       
/*  220 */       for (int i = 0; i < paramInt; i++)
/*      */       {
/*  222 */         localOraclePooledConnection = makeOneConnection(str1, str2);
/*  223 */         synchronized (this)
/*      */         {
/*  225 */           if (localOraclePooledConnection != null)
/*      */           {
/*      */ 
/*      */ 
/*  229 */             this.cacheSize -= 1;
/*  230 */             storeCacheConnection(null, localOraclePooledConnection);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initializeConnectionCache()
/*      */     throws SQLException
/*      */   {
/*  245 */     this.userMap = new HashMap();
/*  246 */     this.checkedOutConnectionList = new Vector();
/*      */     
/*  248 */     if (this.cacheManager == null) {
/*  249 */       this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
/*      */     }
/*      */     
/*  252 */     if ((this.cacheEnabledDS.user != null) && (!this.cacheEnabledDS.user.startsWith("\"")))
/*      */     {
/*  254 */       this.defaultUser = this.cacheEnabledDS.user.toLowerCase();
/*      */     } else {
/*  256 */       this.defaultUser = this.cacheEnabledDS.user;
/*      */     }
/*  258 */     this.defaultPassword = this.cacheEnabledDS.password;
/*  259 */     if (this.connectionPoolDS == null)
/*      */     {
/*  261 */       if ((this.cacheEnabledDS instanceof OracleXADataSource))
/*      */       {
/*  263 */         this.connectionPoolDS = new OracleXADataSource();
/*      */       }
/*      */       else
/*      */       {
/*  267 */         this.connectionPoolDS = new OracleConnectionPoolDataSource();
/*      */       }
/*      */       
/*      */ 
/*  271 */       this.cacheEnabledDS.copy(this.connectionPoolDS);
/*      */     }
/*      */     
/*  274 */     if ((this.fastConnectionFailoverEnabled = this.cacheEnabledDS.getFastConnectionFailoverEnabled()))
/*      */     {
/*      */ 
/*  277 */       this.rand = new Random(0L);
/*  278 */       this.instancesToRetireQueue = new Vector();
/*  279 */       this.cacheManager.failoverEnabledCacheCount += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateUser(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/*  293 */     if ((paramString1 == null) || (paramString2 == null))
/*      */     {
/*  295 */       SQLException localSQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 79);
/*  296 */       localSQLException.fillInStackTrace();
/*  297 */       throw localSQLException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Connection getConnection(String paramString1, String paramString2, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*  317 */     OraclePooledConnection localOraclePooledConnection = null;
/*  318 */     Connection localConnection = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  327 */       if (this.disableConnectionRequest)
/*      */       {
/*      */ 
/*  330 */         SQLException localSQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 142);
/*  331 */         localSQLException1.fillInStackTrace();
/*  332 */         throw localSQLException1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  337 */       validateUser(paramString1, paramString2);
/*      */       
/*      */ 
/*  340 */       if (!paramString1.startsWith("\"")) {
/*  341 */         paramString1 = paramString1.toLowerCase();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  356 */       if (getNumberOfCheckedOutConnections() < this.cacheMaxLimit) {
/*  357 */         localOraclePooledConnection = getCacheConnection(paramString1, paramString2, paramProperties);
/*      */       }
/*      */       
/*  360 */       if (localOraclePooledConnection == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  367 */         processConnectionCacheCallback();
/*      */         
/*  369 */         if (this.cacheSize > 0) {
/*  370 */           localOraclePooledConnection = getCacheConnection(paramString1, paramString2, paramProperties);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  379 */         if ((localOraclePooledConnection == null) && (this.cacheConnectionWaitTimeout > 0))
/*      */         {
/*  381 */           long l1 = this.cacheConnectionWaitTimeout * 1000L;
/*  382 */           long l2 = System.currentTimeMillis();
/*  383 */           long l3 = 0L;
/*      */           do
/*      */           {
/*  386 */             processConnectionWaitTimeout(l1);
/*      */             
/*  388 */             if (this.cacheSize > 0) {
/*  389 */               localOraclePooledConnection = getCacheConnection(paramString1, paramString2, paramProperties);
/*      */             }
/*  391 */             l3 = System.currentTimeMillis();
/*  392 */             l1 -= System.currentTimeMillis() - l2;
/*  393 */             l2 = l3;
/*      */ 
/*      */           }
/*  396 */           while ((localOraclePooledConnection == null) && (l1 > 0L));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  401 */       if ((localOraclePooledConnection != null) && (localOraclePooledConnection.physicalConn != null))
/*      */       {
/*      */ 
/*      */ 
/*  405 */         localConnection = localOraclePooledConnection.getConnection();
/*      */         
/*  407 */         if (localConnection != null)
/*      */         {
/*  409 */           if ((this.cacheValidateConnection) && (testDatabaseConnection((OracleConnection)localConnection) != 0))
/*      */           {
/*      */ 
/*      */ 
/*  413 */             ((OracleConnection)localConnection).close(4096);
/*      */             
/*      */ 
/*  416 */             SQLException localSQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143);
/*  417 */             localSQLException2.fillInStackTrace();
/*  418 */             throw localSQLException2;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  423 */           if (this.cacheAbandonedConnectionTimeout > 0) {
/*  424 */             ((OracleConnection)localConnection).setAbandonedTimeoutEnabled(true);
/*      */           }
/*      */           
/*  427 */           if (this.cacheTimeToLiveTimeout > 0) {
/*  428 */             ((OracleConnection)localConnection).setStartTime(System.currentTimeMillis());
/*      */           }
/*  430 */           synchronized (this)
/*      */           {
/*      */ 
/*      */ 
/*  434 */             this.cacheSize -= 1;
/*  435 */             this.checkedOutConnectionList.addElement(localOraclePooledConnection);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SQLException localSQLException3) {
/*  441 */       synchronized (this)
/*      */       {
/*  443 */         if (localOraclePooledConnection != null)
/*      */         {
/*  445 */           this.cacheSize -= 1;
/*  446 */           abortConnection(localOraclePooledConnection);
/*      */         }
/*      */       }
/*  449 */       throw localSQLException3;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  455 */     return localConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private OraclePooledConnection getCacheConnection(String paramString1, String paramString2, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*  471 */     OraclePooledConnection localOraclePooledConnection = retrieveCacheConnection(paramString1, paramString2, paramProperties);
/*      */     
/*  473 */     if (localOraclePooledConnection == null)
/*      */     {
/*  475 */       localOraclePooledConnection = makeOneConnection(paramString1, paramString2);
/*      */       
/*  477 */       if ((localOraclePooledConnection != null) && (paramProperties != null) && (!paramProperties.isEmpty())) {
/*  478 */         setUnMatchedAttributes(paramProperties, localOraclePooledConnection);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  486 */     return localOraclePooledConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   OraclePooledConnection makeOneConnection(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/*  498 */     OraclePooledConnection localOraclePooledConnection = null;
/*  499 */     int i = 0;
/*  500 */     synchronized (this)
/*      */     {
/*      */ 
/*  503 */       if (getTotalCachedConnections() + this.pendingCreationRequests < this.cacheMaxLimit)
/*      */       {
/*      */ 
/*  506 */         this.pendingCreationRequests += 1;
/*  507 */         i = 1;
/*      */       }
/*      */     }
/*      */     
/*  511 */     if (i != 0)
/*      */     {
/*      */       try
/*      */       {
/*  515 */         localOraclePooledConnection = makeCacheConnection(paramString1, paramString2);
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*  523 */         synchronized (this)
/*      */         {
/*  525 */           if (localOraclePooledConnection != null)
/*  526 */             this.connectionCreatedCount += 1;
/*  527 */           this.pendingCreationRequests -= 1;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  532 */     return localOraclePooledConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getTotalCachedConnections()
/*      */   {
/*  543 */     return this.cacheSize + getNumberOfCheckedOutConnections();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getNumberOfCheckedOutConnections()
/*      */   {
/*  554 */     return this.checkedOutConnectionList.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized OraclePooledConnection retrieveCacheConnection(String paramString1, String paramString2, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*  566 */     OraclePooledConnection localOraclePooledConnection = null;
/*      */     
/*  568 */     OracleConnectionCacheEntry localOracleConnectionCacheEntry = (OracleConnectionCacheEntry)this.userMap.get(OraclePooledConnection.generateKey(paramString1, paramString2));
/*      */     
/*      */ 
/*  571 */     if (localOracleConnectionCacheEntry != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  576 */       if ((paramProperties == null) || ((paramProperties != null) && (paramProperties.isEmpty())))
/*      */       {
/*  578 */         if (localOracleConnectionCacheEntry.userConnList != null) {
/*  579 */           localOraclePooledConnection = retrieveFromConnectionList(localOracleConnectionCacheEntry.userConnList);
/*      */         }
/*  581 */       } else if (localOracleConnectionCacheEntry.attrConnMap != null)
/*      */       {
/*  583 */         String str = buildAttrKey(paramProperties);
/*  584 */         Vector localVector = (Vector)localOracleConnectionCacheEntry.attrConnMap.get(str);
/*      */         
/*      */ 
/*  587 */         if (localVector != null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  594 */           localOraclePooledConnection = retrieveFromConnectionList(localVector);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  602 */         if ((localOraclePooledConnection == null) && (this.cacheClosestConnectionMatch)) {
/*  603 */           localOraclePooledConnection = retrieveClosestConnectionMatch(localOracleConnectionCacheEntry.attrConnMap, paramProperties);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  608 */         if ((localOraclePooledConnection == null) && (localOracleConnectionCacheEntry.userConnList != null)) {
/*  609 */           localOraclePooledConnection = retrieveFromConnectionList(localOracleConnectionCacheEntry.userConnList);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  614 */     if (localOraclePooledConnection != null)
/*      */     {
/*  616 */       if ((paramProperties != null) && (!paramProperties.isEmpty())) {
/*  617 */         setUnMatchedAttributes(paramProperties, localOraclePooledConnection);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  623 */     return localOraclePooledConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private OraclePooledConnection retrieveClosestConnectionMatch(HashMap paramHashMap, Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*  635 */     OraclePooledConnection localOraclePooledConnection1 = null;
/*  636 */     OraclePooledConnection localOraclePooledConnection2 = null;
/*  637 */     Object localObject = null;
/*      */     
/*  639 */     int i = paramProperties.size();
/*  640 */     int j = 0;
/*  641 */     int k = 0;
/*  642 */     int m = 0;
/*  643 */     int n = 0;
/*  644 */     int i1 = 0;
/*      */     
/*  646 */     if (this.cacheAttributeWeights != null) {
/*  647 */       j = getAttributesWeightCount(paramProperties, null);
/*      */     }
/*  649 */     if ((paramHashMap != null) && (!paramHashMap.isEmpty()))
/*      */     {
/*      */ 
/*      */ 
/*  653 */       Iterator localIterator = paramHashMap.entrySet().iterator();
/*      */       
/*  655 */       while (localIterator.hasNext())
/*      */       {
/*  657 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/*      */         
/*  659 */         Vector localVector = (Vector)localEntry.getValue();
/*  660 */         Object[] arrayOfObject = localVector.toArray();
/*  661 */         int i2 = localVector.size();
/*      */         
/*  663 */         for (int i3 = 0; i3 < i2; i3++)
/*      */         {
/*  665 */           localOraclePooledConnection1 = (OraclePooledConnection)arrayOfObject[i3];
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  672 */           if ((localOraclePooledConnection1.cachedConnectionAttributes != null) && (!localOraclePooledConnection1.cachedConnectionAttributes.isEmpty()) && (localOraclePooledConnection1.cachedConnectionAttributes.size() <= i))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  686 */             if (j > 0)
/*      */             {
/*  688 */               m = getAttributesWeightCount(paramProperties, localOraclePooledConnection1.cachedConnectionAttributes);
/*      */               
/*      */ 
/*      */ 
/*  692 */               if (m > k)
/*      */               {
/*  694 */                 localOraclePooledConnection2 = localOraclePooledConnection1;
/*  695 */                 k = m;
/*  696 */                 localObject = localVector;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/*  701 */               i1 = getAttributesMatchCount(paramProperties, localOraclePooledConnection1.cachedConnectionAttributes);
/*      */               
/*      */ 
/*  704 */               if (i1 > n)
/*      */               {
/*  706 */                 localOraclePooledConnection2 = localOraclePooledConnection1;
/*  707 */                 n = i1;
/*  708 */                 localObject = localVector;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  716 */     if (localObject != null) {
/*  717 */       ((Vector)localObject).remove(localOraclePooledConnection2);
/*      */     }
/*  719 */     return localOraclePooledConnection2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAttributesMatchCount(Properties paramProperties1, Properties paramProperties2)
/*      */     throws SQLException
/*      */   {
/*  734 */     int i = 0;
/*  735 */     Map.Entry localEntry = null;
/*  736 */     Object localObject1 = null;
/*  737 */     Object localObject2 = null;
/*      */     
/*  739 */     Iterator localIterator = paramProperties1.entrySet().iterator();
/*      */     
/*  741 */     while (localIterator.hasNext())
/*      */     {
/*  743 */       localEntry = (Map.Entry)localIterator.next();
/*  744 */       localObject1 = localEntry.getKey();
/*  745 */       localObject2 = localEntry.getValue();
/*      */       
/*  747 */       if ((paramProperties2.containsKey(localObject1)) && (localObject2.equals(paramProperties2.get(localObject1))))
/*      */       {
/*  749 */         i++; }
/*      */     }
/*  751 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAttributesWeightCount(Properties paramProperties1, Properties paramProperties2)
/*      */     throws SQLException
/*      */   {
/*  780 */     Map.Entry localEntry = null;
/*  781 */     Object localObject1 = null;
/*  782 */     Object localObject2 = null;
/*  783 */     int i = 0;
/*      */     
/*  785 */     Iterator localIterator = paramProperties1.entrySet().iterator();
/*      */     
/*  787 */     while (localIterator.hasNext())
/*      */     {
/*  789 */       localEntry = (Map.Entry)localIterator.next();
/*  790 */       localObject1 = localEntry.getKey();
/*  791 */       localObject2 = localEntry.getValue();
/*      */       
/*      */ 
/*  794 */       if (paramProperties2 == null)
/*      */       {
/*  796 */         if (this.cacheAttributeWeights.containsKey(localObject1))
/*      */         {
/*  798 */           i += Integer.parseInt((String)this.cacheAttributeWeights.get(localObject1));
/*      */         }
/*      */         
/*      */       }
/*  802 */       else if ((paramProperties2.containsKey(localObject1)) && (localObject2.equals(paramProperties2.get(localObject1))))
/*      */       {
/*      */ 
/*  805 */         if (this.cacheAttributeWeights.containsKey(localObject1))
/*      */         {
/*  807 */           i += Integer.parseInt((String)this.cacheAttributeWeights.get(localObject1));
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*  813 */           i++;
/*      */         }
/*      */       }
/*      */     }
/*  817 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setUnMatchedAttributes(Properties paramProperties, OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/*  831 */     if (paramOraclePooledConnection.unMatchedCachedConnAttr == null) {
/*  832 */       paramOraclePooledConnection.unMatchedCachedConnAttr = new Properties();
/*      */     } else {
/*  834 */       paramOraclePooledConnection.unMatchedCachedConnAttr.clear();
/*      */     }
/*  836 */     if (!this.cacheClosestConnectionMatch)
/*      */     {
/*  838 */       paramOraclePooledConnection.unMatchedCachedConnAttr.putAll(paramProperties);
/*      */     }
/*      */     else
/*      */     {
/*  842 */       Properties localProperties = paramOraclePooledConnection.cachedConnectionAttributes;
/*  843 */       Map.Entry localEntry = null;
/*  844 */       Object localObject1 = null;
/*  845 */       Object localObject2 = null;
/*      */       
/*  847 */       Iterator localIterator = paramProperties.entrySet().iterator();
/*      */       
/*  849 */       while (localIterator.hasNext())
/*      */       {
/*  851 */         localEntry = (Map.Entry)localIterator.next();
/*  852 */         localObject1 = localEntry.getKey();
/*  853 */         localObject2 = localEntry.getValue();
/*      */         
/*  855 */         if ((!localProperties.containsKey(localObject1)) && (!localObject2.equals(localProperties.get(localObject1))))
/*      */         {
/*  857 */           paramOraclePooledConnection.unMatchedCachedConnAttr.put(localObject1, localObject2);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private OraclePooledConnection retrieveFromConnectionList(Vector paramVector)
/*      */     throws SQLException
/*      */   {
/*  874 */     if (paramVector.isEmpty()) {
/*  875 */       return null;
/*      */     }
/*  877 */     Object localObject1 = null;
/*  878 */     if (this.fastConnectionFailoverEnabled) { int i;
/*      */       Object localObject2;
/*      */       Object localObject3;
/*  881 */       if ((this.useGoodGroup) && (this.databaseInstancesList != null) && (this.databaseInstancesList.size() > 0)) {
/*      */         label234:
/*  883 */         synchronized (this.databaseInstancesList) {
/*  884 */           i = this.databaseInstancesList.size();
/*  885 */           localObject2 = null;
/*  886 */           localObject3 = 0;
/*      */           
/*  888 */           boolean[] arrayOfBoolean = new boolean[i];
/*  889 */           int j = this.dbInstancePercentTotal;
/*      */           
/*  891 */           for (int k = 0; k < i; k++) {
/*  892 */             Object localObject4 = 0;
/*      */             
/*      */ 
/*  895 */             if (j <= 1) {
/*  896 */               localObject3 = 0;
/*      */             } else {
/*  898 */               localObject3 = this.rand.nextInt(j - 1);
/*      */             }
/*  900 */             for (int m = 0; m < i; m++)
/*      */             {
/*  902 */               localObject2 = (OracleDatabaseInstance)this.databaseInstancesList.get(m);
/*      */               
/*  904 */               if ((arrayOfBoolean[m] == 0) && (((OracleDatabaseInstance)localObject2).flag <= 3))
/*      */               {
/*  906 */                 localObject4 += ((OracleDatabaseInstance)localObject2).percent;
/*      */                 
/*      */ 
/*  909 */                 if (localObject3 <= localObject4)
/*      */                 {
/*      */ 
/*  912 */                   if (k == 0) { localObject2.attemptedConnRequestCount += 1;
/*      */                   }
/*  914 */                   if ((localObject1 = selectConnectionFromList(paramVector, (OracleDatabaseInstance)localObject2)) != null) {
/*      */                     break label234;
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*  920 */                   j -= ((OracleDatabaseInstance)localObject2).percent;
/*  921 */                   arrayOfBoolean[m] = true;
/*  922 */                   break;
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  938 */         ??? = paramVector.size();
/*  939 */         i = this.rand.nextInt(???);
/*  940 */         localObject2 = null;
/*      */         
/*  942 */         for (localObject3 = 0; localObject3 < ???; localObject3++)
/*      */         {
/*  944 */           localObject2 = (OraclePooledConnection)paramVector.get((i++ + ???) % ???);
/*      */           
/*      */ 
/*  947 */           if (!((OraclePooledConnection)localObject2).connectionMarkedDown)
/*      */           {
/*  949 */             localObject1 = localObject2;
/*  950 */             paramVector.remove(localObject1);
/*  951 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  957 */       localObject1 = (OraclePooledConnection)paramVector.remove(0);
/*      */     }
/*  959 */     return (OraclePooledConnection)localObject1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private OraclePooledConnection selectConnectionFromList(Vector paramVector, OracleDatabaseInstance paramOracleDatabaseInstance)
/*      */   {
/*  971 */     Object localObject = null;
/*  972 */     OraclePooledConnection localOraclePooledConnection = null;
/*      */     
/*      */ 
/*  975 */     int i = paramVector.size();
/*  976 */     for (int j = 0; j < i; j++)
/*      */     {
/*  978 */       localOraclePooledConnection = (OraclePooledConnection)paramVector.get(j);
/*      */       
/*  980 */       if ((!localOraclePooledConnection.connectionMarkedDown) && (localOraclePooledConnection.dataSourceDbUniqNameKey == paramOracleDatabaseInstance.databaseUniqName) && (localOraclePooledConnection.dataSourceInstanceNameKey == paramOracleDatabaseInstance.instanceName))
/*      */       {
/*      */ 
/*      */ 
/*  984 */         localObject = localOraclePooledConnection;
/*  985 */         paramVector.remove(localObject);
/*  986 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  993 */     return (OraclePooledConnection)localObject;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void removeCacheConnection(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 1005 */     boolean bool = false;
/*      */     
/* 1007 */     OracleConnectionCacheEntry localOracleConnectionCacheEntry = paramOraclePooledConnection.removeFromImplictCache(this.userMap);
/*      */     
/*      */ 
/* 1010 */     if (localOracleConnectionCacheEntry != null)
/*      */     {
/* 1012 */       Properties localProperties = paramOraclePooledConnection.cachedConnectionAttributes;
/*      */       
/* 1014 */       if ((localProperties == null) || ((localProperties != null) && (localProperties.isEmpty())))
/*      */       {
/* 1016 */         if (localOracleConnectionCacheEntry.userConnList != null) {
/* 1017 */           bool = localOracleConnectionCacheEntry.userConnList.removeElement(paramOraclePooledConnection);
/*      */         }
/* 1019 */       } else if (localOracleConnectionCacheEntry.attrConnMap != null)
/*      */       {
/* 1021 */         String str = buildAttrKey(localProperties);
/*      */         
/* 1023 */         Vector localVector = (Vector)localOracleConnectionCacheEntry.attrConnMap.get(str);
/*      */         
/*      */ 
/* 1026 */         if (localVector != null)
/*      */         {
/*      */ 
/*      */ 
/* 1030 */           if (paramOraclePooledConnection.unMatchedCachedConnAttr != null)
/*      */           {
/* 1032 */             paramOraclePooledConnection.unMatchedCachedConnAttr.clear();
/* 1033 */             paramOraclePooledConnection.unMatchedCachedConnAttr = null;
/*      */           }
/*      */           
/* 1036 */           if (paramOraclePooledConnection.cachedConnectionAttributes != null)
/*      */           {
/* 1038 */             paramOraclePooledConnection.cachedConnectionAttributes.clear();
/* 1039 */             paramOraclePooledConnection.cachedConnectionAttributes = null;
/*      */           }
/*      */           
/* 1042 */           localProperties = null;
/* 1043 */           bool = localVector.removeElement(paramOraclePooledConnection);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1049 */     if (bool)
/*      */     {
/* 1051 */       this.cacheSize -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doForEveryCachedConnection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1076 */     int i = 0;
/*      */     
/* 1078 */     synchronized (this)
/*      */     {
/* 1080 */       if ((this.userMap != null) && (!this.userMap.isEmpty()))
/*      */       {
/* 1082 */         Iterator localIterator = this.userMap.entrySet().iterator();
/*      */         
/* 1084 */         while (localIterator.hasNext())
/*      */         {
/* 1086 */           Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 1087 */           OracleConnectionCacheEntry localOracleConnectionCacheEntry = (OracleConnectionCacheEntry)localEntry.getValue();
/*      */           Object localObject1;
/*      */           Object localObject2;
/*      */           OraclePooledConnection localOraclePooledConnection;
/* 1091 */           if ((localOracleConnectionCacheEntry.userConnList != null) && (!localOracleConnectionCacheEntry.userConnList.isEmpty()))
/*      */           {
/* 1093 */             localObject1 = localOracleConnectionCacheEntry.userConnList;
/* 1094 */             localObject2 = ((Vector)localObject1).toArray();
/*      */             
/* 1096 */             for (int j = 0; j < localObject2.length; j++)
/*      */             {
/* 1098 */               localOraclePooledConnection = (OraclePooledConnection)localObject2[j];
/*      */               
/* 1100 */               if ((localOraclePooledConnection != null) && (performPooledConnectionTask(localOraclePooledConnection, paramInt))) {
/* 1101 */                 i++;
/*      */               }
/*      */             }
/*      */           }
/* 1105 */           if ((localOracleConnectionCacheEntry.attrConnMap != null) && (!localOracleConnectionCacheEntry.attrConnMap.isEmpty()))
/*      */           {
/* 1107 */             localObject1 = localOracleConnectionCacheEntry.attrConnMap.entrySet().iterator();
/*      */             
/* 1109 */             while (((Iterator)localObject1).hasNext())
/*      */             {
/* 1111 */               localObject2 = (Map.Entry)((Iterator)localObject1).next();
/*      */               
/* 1113 */               Vector localVector = (Vector)((Map.Entry)localObject2).getValue();
/* 1114 */               Object[] arrayOfObject = localVector.toArray();
/*      */               
/* 1116 */               for (int k = 0; k < arrayOfObject.length; k++)
/*      */               {
/* 1118 */                 localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[k];
/*      */                 
/* 1120 */                 if ((localOraclePooledConnection != null) && (performPooledConnectionTask(localOraclePooledConnection, paramInt))) {
/* 1121 */                   i++;
/*      */                 }
/*      */               }
/*      */             }
/* 1125 */             if ((paramInt == 1) || (paramInt == 32))
/*      */             {
/* 1127 */               localOracleConnectionCacheEntry.attrConnMap.clear();
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1132 */         if ((paramInt == 1) || (paramInt == 32))
/*      */         {
/*      */ 
/* 1135 */           this.userMap.clear();
/*      */           
/* 1137 */           this.cacheSize = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1147 */     if (i > 0)
/*      */     {
/*      */ 
/* 1150 */       defaultUserPrePopulateCache(i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean performPooledConnectionTask(OraclePooledConnection paramOraclePooledConnection, int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1171 */     boolean bool = false;
/*      */     
/* 1173 */     switch (paramInt)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 1179 */       if (paramOraclePooledConnection.connectionMarkedDown)
/*      */       {
/*      */ 
/*      */ 
/* 1183 */         paramOraclePooledConnection.needToAbort = true;
/* 1184 */         closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 8: 
/* 1193 */       if (this.connectionsToRemove > 0)
/*      */       {
/* 1195 */         closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */         
/* 1197 */         this.connectionsToRemove -= 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 24: 
/* 1206 */       if (this.retireConnectionsCount > 0)
/*      */       {
/* 1208 */         if ((this.instanceToRetire.databaseUniqName == paramOraclePooledConnection.dataSourceDbUniqNameKey) && (this.instanceToRetire.instanceName == paramOraclePooledConnection.dataSourceInstanceNameKey))
/*      */         {
/*      */ 
/* 1211 */           closeAndRemovePooledConnection(paramOraclePooledConnection);
/* 1212 */           this.retireConnectionsCount -= 1;
/*      */           
/* 1214 */           if (getTotalCachedConnections() < this.cacheMinLimit) {
/* 1215 */             bool = true;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 4096: 
/* 1224 */       Connection localConnection = paramOraclePooledConnection.getLogicalHandle();
/*      */       
/* 1226 */       if ((localConnection != null) || ((localConnection = paramOraclePooledConnection.getPhysicalHandle()) != null))
/*      */       {
/*      */ 
/* 1229 */         if (testDatabaseConnection((OracleConnection)localConnection) != 0)
/*      */         {
/*      */ 
/* 1232 */           closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */           
/* 1234 */           bool = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 8192: 
/* 1243 */       closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */       
/* 1245 */       bool = true;
/*      */       
/* 1247 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 1: 
/* 1252 */       closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */       
/* 1254 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 4: 
/* 1259 */       processInactivityTimeout(paramOraclePooledConnection);
/*      */       
/* 1261 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 16: 
/* 1266 */       setStatementCaching(paramOraclePooledConnection, this.cacheMaxStatementsLimit, false);
/*      */       
/* 1268 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 18: 
/* 1273 */       setStatementCaching(paramOraclePooledConnection, this.cacheMaxStatementsLimit, true);
/*      */       
/* 1275 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 32: 
/* 1280 */       abortConnection(paramOraclePooledConnection);
/* 1281 */       closeAndRemovePooledConnection(paramOraclePooledConnection);
/* 1282 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1289 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void doForEveryCheckedOutConnection(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1306 */     int i = this.checkedOutConnectionList.size();
/*      */     int j;
/*      */     OraclePooledConnection localOraclePooledConnection;
/* 1309 */     switch (paramInt)
/*      */     {
/*      */     case 1: 
/* 1312 */       for (j = 0; j < i; j++)
/*      */       {
/* 1314 */         closeCheckedOutConnection((OraclePooledConnection)this.checkedOutConnectionList.get(j), false);
/*      */       }
/*      */       
/*      */ 
/* 1318 */       this.checkedOutConnectionList.removeAllElements();
/* 1319 */       break;
/*      */     
/*      */     case 24: 
/* 1322 */       for (j = 0; (j < i) && (this.retireConnectionsCount > 0); j++)
/*      */       {
/* 1324 */         localOraclePooledConnection = (OraclePooledConnection)this.checkedOutConnectionList.get(j);
/* 1325 */         if ((this.instanceToRetire.databaseUniqName == localOraclePooledConnection.dataSourceDbUniqNameKey) && (this.instanceToRetire.instanceName == localOraclePooledConnection.dataSourceInstanceNameKey))
/*      */         {
/*      */ 
/* 1328 */           localOraclePooledConnection.closeOption = 4096;
/*      */           
/*      */ 
/* 1331 */           this.retireConnectionsCount -= 2;
/*      */         }
/*      */       }
/* 1334 */       break;
/*      */     
/*      */     case 32: 
/* 1337 */       for (j = 0; j < i; j++)
/*      */       {
/* 1339 */         localOraclePooledConnection = null;
/* 1340 */         abortConnection(localOraclePooledConnection = (OraclePooledConnection)this.checkedOutConnectionList.get(j));
/* 1341 */         closeCheckedOutConnection(localOraclePooledConnection, false);
/*      */       }
/*      */       
/*      */ 
/* 1345 */       this.checkedOutConnectionList.removeAllElements();
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void closeCheckedOutConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1366 */     if (paramOraclePooledConnection != null)
/*      */     {
/* 1368 */       OracleConnection localOracleConnection1 = (OracleConnection)paramOraclePooledConnection.getLogicalHandle();
/* 1369 */       OracleConnection localOracleConnection2 = (OracleConnection)paramOraclePooledConnection.getPhysicalHandle();
/* 1370 */       boolean bool1 = localOracleConnection1.getAutoCommit();
/*      */       
/* 1372 */       if (paramBoolean)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1378 */         boolean bool2 = paramOraclePooledConnection.localTxnCommitOnClose;
/*      */         
/*      */         try
/*      */         {
/* 1382 */           paramOraclePooledConnection.localTxnCommitOnClose = false;
/* 1383 */           localOracleConnection1.cleanupAndClose(true);
/*      */           
/*      */           try
/*      */           {
/* 1387 */             if ((!bool1) && (!paramOraclePooledConnection.needToAbort)) {
/* 1388 */               localOracleConnection2.rollback();
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*      */           catch (SQLException localSQLException2) {}
/*      */ 
/*      */         }
/*      */         catch (SQLException localSQLException3) {}finally
/*      */         {
/*      */ 
/* 1400 */           if (paramOraclePooledConnection.localTxnCommitOnClose != bool2) {
/* 1401 */             paramOraclePooledConnection.localTxnCommitOnClose = bool2;
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*      */         try
/*      */         {
/* 1409 */           if ((!bool1) && (!paramOraclePooledConnection.needToAbort))
/*      */           {
/* 1411 */             localOracleConnection2.cancel();
/* 1412 */             localOracleConnection2.rollback();
/*      */           }
/*      */         }
/*      */         catch (SQLException localSQLException1) {}
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1420 */         actualPooledConnectionClose(paramOraclePooledConnection);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void storeCacheConnection(Properties paramProperties, OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 1438 */     boolean bool = false;
/*      */     
/* 1440 */     if ((paramOraclePooledConnection == null) || (paramOraclePooledConnection.physicalConn == null))
/*      */     {
/* 1442 */       return;
/*      */     }
/*      */     
/* 1445 */     if (this.cacheInactivityTimeout > 0)
/*      */     {
/* 1447 */       paramOraclePooledConnection.setLastAccessedTime(System.currentTimeMillis());
/*      */     }
/*      */     
/* 1450 */     if (paramOraclePooledConnection.unMatchedCachedConnAttr != null)
/*      */     {
/* 1452 */       paramOraclePooledConnection.unMatchedCachedConnAttr.clear();
/* 1453 */       paramOraclePooledConnection.unMatchedCachedConnAttr = null;
/*      */     }
/*      */     
/* 1456 */     OracleConnectionCacheEntry localOracleConnectionCacheEntry = paramOraclePooledConnection.removeFromImplictCache(this.userMap);
/*      */     Object localObject1;
/*      */     Object localObject2;
/* 1459 */     if (localOracleConnectionCacheEntry != null)
/*      */     {
/* 1461 */       if ((paramProperties == null) || ((paramProperties != null) && (paramProperties.isEmpty())))
/*      */       {
/* 1463 */         if (localOracleConnectionCacheEntry.userConnList == null) {
/* 1464 */           localOracleConnectionCacheEntry.userConnList = new Vector();
/*      */         }
/* 1466 */         bool = localOracleConnectionCacheEntry.userConnList.add(paramOraclePooledConnection);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1472 */         paramOraclePooledConnection.cachedConnectionAttributes = paramProperties;
/*      */         
/* 1474 */         if (localOracleConnectionCacheEntry.attrConnMap == null) {
/* 1475 */           localOracleConnectionCacheEntry.attrConnMap = new HashMap();
/*      */         }
/* 1477 */         localObject1 = buildAttrKey(paramProperties);
/* 1478 */         localObject2 = (Vector)localOracleConnectionCacheEntry.attrConnMap.get(localObject1);
/*      */         
/*      */ 
/* 1481 */         if (localObject2 != null)
/*      */         {
/* 1483 */           bool = ((Vector)localObject2).add(paramOraclePooledConnection);
/*      */         }
/*      */         else
/*      */         {
/* 1487 */           localObject2 = new Vector();
/*      */           
/* 1489 */           bool = ((Vector)localObject2).add(paramOraclePooledConnection);
/* 1490 */           localOracleConnectionCacheEntry.attrConnMap.put(localObject1, localObject2);
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1496 */       localOracleConnectionCacheEntry = new OracleConnectionCacheEntry();
/*      */       
/* 1498 */       paramOraclePooledConnection.addToImplicitCache(this.userMap, localOracleConnectionCacheEntry);
/*      */       
/* 1500 */       if ((paramProperties == null) || ((paramProperties != null) && (paramProperties.isEmpty())))
/*      */       {
/* 1502 */         localObject1 = new Vector();
/*      */         
/* 1504 */         bool = ((Vector)localObject1).add(paramOraclePooledConnection);
/*      */         
/* 1506 */         localOracleConnectionCacheEntry.userConnList = ((Vector)localObject1);
/*      */       }
/*      */       else
/*      */       {
/* 1510 */         localObject1 = buildAttrKey(paramProperties);
/*      */         
/*      */ 
/* 1513 */         paramOraclePooledConnection.cachedConnectionAttributes = paramProperties;
/*      */         
/* 1515 */         localObject2 = new HashMap();
/* 1516 */         Vector localVector = new Vector();
/*      */         
/* 1518 */         bool = localVector.add(paramOraclePooledConnection);
/* 1519 */         ((HashMap)localObject2).put(localObject1, localVector);
/*      */         
/* 1521 */         localOracleConnectionCacheEntry.attrConnMap = ((HashMap)localObject2);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1526 */     if (bool) {
/* 1527 */       this.cacheSize += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1538 */     if (this.cacheConnectionWaitTimeout > 0)
/*      */     {
/* 1540 */       notifyAll();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String buildAttrKey(Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/* 1557 */     int i = paramProperties.keySet().size();
/* 1558 */     Object[] arrayOfObject = paramProperties.keySet().toArray();
/* 1559 */     int j = 1;
/* 1560 */     StringBuffer localStringBuffer = new StringBuffer();
/*      */     
/*      */ 
/* 1563 */     while (j != 0)
/*      */     {
/* 1565 */       j = 0;
/*      */       
/* 1567 */       for (k = 0; k < i - 1; k++)
/*      */       {
/* 1569 */         if (((String)arrayOfObject[k]).compareTo((String)arrayOfObject[(k + 1)]) > 0)
/*      */         {
/* 1571 */           j = 1;
/*      */           
/* 1573 */           Object localObject = arrayOfObject[k];
/*      */           
/* 1575 */           arrayOfObject[k] = arrayOfObject[(k + 1)];
/* 1576 */           arrayOfObject[(k + 1)] = localObject;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1582 */     for (int k = 0; k < i; k++) {
/* 1583 */       localStringBuffer.append(arrayOfObject[k] + "0xffff" + paramProperties.get(arrayOfObject[k]));
/*      */     }
/* 1585 */     return localStringBuffer.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OraclePooledConnection makeCacheConnection(String paramString1, String paramString2)
/*      */     throws SQLException
/*      */   {
/* 1598 */     OraclePooledConnection localOraclePooledConnection = (OraclePooledConnection)this.connectionPoolDS.getPooledConnection(paramString1, paramString2);
/*      */     
/*      */ 
/*      */ 
/* 1602 */     if (localOraclePooledConnection != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1610 */       if (this.cacheMaxStatementsLimit > 0) {
/* 1611 */         setStatementCaching(localOraclePooledConnection, this.cacheMaxStatementsLimit, true);
/*      */       }
/*      */       
/* 1614 */       localOraclePooledConnection.registerImplicitCacheConnectionEventListener(new OracleConnectionCacheEventListener(this));
/*      */       
/*      */ 
/* 1617 */       localOraclePooledConnection.cachedConnectionAttributes = new Properties();
/*      */       
/*      */ 
/* 1620 */       if (this.fastConnectionFailoverEnabled)
/*      */       {
/* 1622 */         initFailoverParameters(localOraclePooledConnection);
/*      */       }
/*      */       
/*      */ 
/* 1626 */       synchronized (this)
/*      */       {
/* 1628 */         this.cacheSize += 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1633 */         if ((this.fastConnectionFailoverEnabled) && (this.runtimeLoadBalancingThread == null))
/*      */         {
/*      */ 
/* 1636 */           this.runtimeLoadBalancingThread = new OracleRuntimeLoadBalancingEventHandlerThread(this.dataSourceServiceName);
/*      */           
/* 1638 */           this.cacheManager.checkAndStartThread(this.runtimeLoadBalancingThread);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1644 */       localOraclePooledConnection.localTxnCommitOnClose = this.cacheLocalTxnCommitOnClose;
/*      */     }
/* 1646 */     return localOraclePooledConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setStatementCaching(OraclePooledConnection paramOraclePooledConnection, int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 1657 */     if (paramInt > 0) {
/* 1658 */       paramOraclePooledConnection.setStatementCacheSize(paramInt);
/*      */     }
/* 1660 */     paramOraclePooledConnection.setImplicitCachingEnabled(paramBoolean);
/* 1661 */     paramOraclePooledConnection.setExplicitCachingEnabled(paramBoolean);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void reusePooledConnection(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/* 1683 */     OraclePooledConnection localOraclePooledConnection = (OraclePooledConnection)paramPooledConnection;
/* 1684 */     if ((localOraclePooledConnection != null) && (localOraclePooledConnection.physicalConn != null))
/*      */     {
/* 1686 */       if (localOraclePooledConnection.localTxnCommitOnClose)
/* 1687 */         localOraclePooledConnection.physicalConn.commit();
/* 1688 */       storeCacheConnection(localOraclePooledConnection.cachedConnectionAttributes, localOraclePooledConnection);
/*      */       
/*      */ 
/* 1691 */       this.checkedOutConnectionList.removeElement(localOraclePooledConnection);
/*      */       
/*      */ 
/*      */ 
/* 1695 */       localOraclePooledConnection.logicalHandle = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void closePooledConnection(PooledConnection paramPooledConnection)
/*      */     throws SQLException
/*      */   {
/* 1718 */     if (paramPooledConnection != null)
/*      */     {
/* 1720 */       actualPooledConnectionClose((OraclePooledConnection)paramPooledConnection);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1726 */       if (((OraclePooledConnection)paramPooledConnection).closeOption == 4096) {
/* 1727 */         this.checkedOutConnectionList.removeElement(paramPooledConnection);
/*      */       }
/* 1729 */       paramPooledConnection = null;
/*      */       
/* 1731 */       if (getTotalCachedConnections() < this.cacheMinLimit) {
/* 1732 */         defaultUserPrePopulateCache(1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void refreshCacheConnections(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 1748 */     doForEveryCachedConnection(paramInt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reinitializeCacheConnections(Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/* 1764 */     int m = 0;
/*      */     
/*      */ 
/* 1767 */     synchronized (this)
/*      */     {
/* 1769 */       this.defaultUser = this.cacheEnabledDS.user;
/* 1770 */       this.defaultPassword = this.cacheEnabledDS.password;
/* 1771 */       this.fastConnectionFailoverEnabled = this.cacheEnabledDS.getFastConnectionFailoverEnabled();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1779 */       cleanupTimeoutThread();
/*      */       
/*      */ 
/*      */ 
/* 1783 */       doForEveryCheckedOutConnection(1);
/*      */       
/*      */ 
/* 1786 */       int i = this.cacheInitialLimit;
/* 1787 */       int j = this.cacheMaxLimit;
/* 1788 */       int k = this.cacheMaxStatementsLimit;
/*      */       
/*      */ 
/* 1791 */       setConnectionCacheProperties(paramProperties);
/*      */       
/* 1793 */       if (this.cacheInitialLimit > i) {
/* 1794 */         m = this.cacheInitialLimit - i;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1800 */       if (j != Integer.MAX_VALUE)
/*      */       {
/* 1802 */         if ((this.cacheMaxLimit < j) && (this.cacheSize > this.cacheMaxLimit))
/*      */         {
/* 1804 */           this.connectionsToRemove = (this.cacheSize - this.cacheMaxLimit);
/*      */           
/* 1806 */           doForEveryCachedConnection(8);
/*      */           
/* 1808 */           this.connectionsToRemove = 0;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1814 */       if (this.cacheMaxStatementsLimit != k)
/*      */       {
/* 1816 */         if (this.cacheMaxStatementsLimit == 0) {
/* 1817 */           doForEveryCachedConnection(16);
/*      */         } else {
/* 1819 */           doForEveryCachedConnection(18);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1826 */     if (m > 0)
/*      */     {
/* 1828 */       defaultUserPrePopulateCache(m);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setConnectionCacheProperties(Properties paramProperties)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1855 */       if (paramProperties != null)
/*      */       {
/* 1857 */         String str = null;
/*      */         
/*      */ 
/* 1860 */         if ((str = paramProperties.getProperty("MinLimit")) != null)
/*      */         {
/* 1862 */           if ((this.cacheMinLimit = Integer.parseInt(str)) < 0) {
/* 1863 */             this.cacheMinLimit = 0;
/*      */           }
/*      */         }
/*      */         
/* 1867 */         if ((str = paramProperties.getProperty("MaxLimit")) != null)
/*      */         {
/* 1869 */           if ((this.cacheMaxLimit = Integer.parseInt(str)) < 0) {
/* 1870 */             this.cacheMaxLimit = Integer.MAX_VALUE;
/*      */           }
/*      */         }
/*      */         
/* 1874 */         if (this.cacheMaxLimit < this.cacheMinLimit) {
/* 1875 */           this.cacheMinLimit = this.cacheMaxLimit;
/*      */         }
/*      */         
/* 1878 */         if ((str = paramProperties.getProperty("InitialLimit")) != null)
/*      */         {
/* 1880 */           if ((this.cacheInitialLimit = Integer.parseInt(str)) < 0) {
/* 1881 */             this.cacheInitialLimit = 0;
/*      */           }
/*      */         }
/* 1884 */         if (this.cacheInitialLimit > this.cacheMaxLimit) {
/* 1885 */           this.cacheInitialLimit = this.cacheMaxLimit;
/*      */         }
/*      */         
/* 1888 */         if ((str = paramProperties.getProperty("MaxStatementsLimit")) != null)
/*      */         {
/* 1890 */           if ((this.cacheMaxStatementsLimit = Integer.parseInt(str)) < 0) {
/* 1891 */             this.cacheMaxStatementsLimit = 0;
/*      */           }
/*      */         }
/*      */         
/* 1895 */         localObject1 = (Properties)paramProperties.get("AttributeWeights");
/*      */         
/*      */ 
/* 1898 */         if (localObject1 != null)
/*      */         {
/* 1900 */           Map.Entry localEntry = null;
/* 1901 */           int i = 0;
/* 1902 */           Object localObject2 = null;
/*      */           
/* 1904 */           Iterator localIterator = ((Properties)localObject1).entrySet().iterator();
/*      */           
/* 1906 */           while (localIterator.hasNext())
/*      */           {
/* 1908 */             localEntry = (Map.Entry)localIterator.next();
/* 1909 */             localObject2 = localEntry.getKey();
/*      */             
/* 1911 */             if (((str = (String)((Properties)localObject1).get(localObject2)) != null) && 
/*      */             
/* 1913 */               ((i = Integer.parseInt(str)) < 0)) {
/* 1914 */               ((Properties)localObject1).put(localObject2, "0");
/*      */             }
/*      */           }
/*      */           
/* 1918 */           if (this.cacheAttributeWeights == null) {
/* 1919 */             this.cacheAttributeWeights = new Properties();
/*      */           }
/* 1921 */           this.cacheAttributeWeights.putAll((Map)localObject1);
/*      */         }
/*      */         
/*      */ 
/* 1925 */         if ((str = paramProperties.getProperty("InactivityTimeout")) != null)
/*      */         {
/* 1927 */           if ((this.cacheInactivityTimeout = Integer.parseInt(str)) < 0) {
/* 1928 */             this.cacheInactivityTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1932 */         if ((str = paramProperties.getProperty("TimeToLiveTimeout")) != null)
/*      */         {
/* 1934 */           if ((this.cacheTimeToLiveTimeout = Integer.parseInt(str)) < 0) {
/* 1935 */             this.cacheTimeToLiveTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1939 */         if ((str = paramProperties.getProperty("AbandonedConnectionTimeout")) != null)
/*      */         {
/* 1941 */           if ((this.cacheAbandonedConnectionTimeout = Integer.parseInt(str)) < 0) {
/* 1942 */             this.cacheAbandonedConnectionTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1946 */         if ((str = paramProperties.getProperty("LowerThresholdLimit")) != null)
/*      */         {
/* 1948 */           this.cacheLowerThresholdLimit = Integer.parseInt(str);
/*      */           
/* 1950 */           if ((this.cacheLowerThresholdLimit < 0) || (this.cacheLowerThresholdLimit > 100))
/*      */           {
/* 1952 */             this.cacheLowerThresholdLimit = 20;
/*      */           }
/*      */         }
/*      */         
/* 1956 */         if ((str = paramProperties.getProperty("PropertyCheckInterval")) != null)
/*      */         {
/* 1958 */           if ((this.cachePropertyCheckInterval = Integer.parseInt(str)) < 0)
/*      */           {
/* 1960 */             this.cachePropertyCheckInterval = 900;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1965 */         if ((str = paramProperties.getProperty("ValidateConnection")) != null) {
/* 1966 */           this.cacheValidateConnection = Boolean.valueOf(str).booleanValue();
/*      */         }
/*      */         
/*      */ 
/* 1970 */         if ((str = paramProperties.getProperty("ClosestConnectionMatch")) != null)
/*      */         {
/* 1972 */           this.cacheClosestConnectionMatch = Boolean.valueOf(str).booleanValue();
/*      */         }
/*      */         
/*      */ 
/* 1976 */         if ((str = paramProperties.getProperty("ConnectionWaitTimeout")) != null)
/*      */         {
/* 1978 */           if ((this.cacheConnectionWaitTimeout = Integer.parseInt(str)) < 0) {
/* 1979 */             this.cacheConnectionWaitTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1983 */         if ((str = paramProperties.getProperty("LocalTransactionCommitOnClose")) != null)
/*      */         {
/* 1985 */           this.cacheLocalTxnCommitOnClose = str.equalsIgnoreCase("true");
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1991 */         this.cacheMinLimit = 0;
/* 1992 */         this.cacheMaxLimit = Integer.MAX_VALUE;
/* 1993 */         this.cacheInitialLimit = 0;
/* 1994 */         this.cacheMaxStatementsLimit = 0;
/* 1995 */         this.cacheAttributeWeights = null;
/* 1996 */         this.cacheInactivityTimeout = 0;
/* 1997 */         this.cacheTimeToLiveTimeout = 0;
/* 1998 */         this.cacheAbandonedConnectionTimeout = 0;
/* 1999 */         this.cacheLowerThresholdLimit = 20;
/* 2000 */         this.cachePropertyCheckInterval = 900;
/* 2001 */         this.cacheClosestConnectionMatch = false;
/* 2002 */         this.cacheValidateConnection = false;
/* 2003 */         this.cacheConnectionWaitTimeout = 0;
/* 2004 */         this.cacheLocalTxnCommitOnClose = false;
/*      */       }
/*      */       
/*      */ 
/* 2008 */       if (((this.cacheInactivityTimeout > 0) || (this.cacheTimeToLiveTimeout > 0) || (this.cacheAbandonedConnectionTimeout > 0)) && (this.cachePropertyCheckInterval > 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2013 */         if (this.timeoutThread == null) {
/* 2014 */           this.timeoutThread = new OracleImplicitConnectionCacheThread(this);
/*      */         }
/* 2016 */         this.cacheManager.checkAndStartThread(this.timeoutThread);
/*      */       }
/*      */       
/* 2019 */       if (this.cachePropertyCheckInterval == 0)
/*      */       {
/*      */ 
/*      */ 
/* 2023 */         cleanupTimeoutThread();
/*      */       }
/*      */       
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException)
/*      */     {
/* 2029 */       Object localObject1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139, "OracleImplicitConnectionCache:setConnectionCacheProperties() - NumberFormatException Occurred :" + localNumberFormatException.getMessage());
/*      */       
/*      */ 
/*      */ 
/* 2033 */       ((SQLException)localObject1).fillInStackTrace();
/* 2034 */       throw ((Throwable)localObject1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Properties getConnectionCacheProperties()
/*      */     throws SQLException
/*      */   {
/* 2048 */     Properties localProperties = new Properties();
/*      */     
/* 2050 */     localProperties.setProperty("MinLimit", String.valueOf(this.cacheMinLimit));
/* 2051 */     localProperties.setProperty("MaxLimit", String.valueOf(this.cacheMaxLimit));
/* 2052 */     localProperties.setProperty("InitialLimit", String.valueOf(this.cacheInitialLimit));
/*      */     
/* 2054 */     localProperties.setProperty("MaxStatementsLimit", String.valueOf(this.cacheMaxStatementsLimit));
/*      */     
/*      */ 
/* 2057 */     if (this.cacheAttributeWeights != null) {
/* 2058 */       localProperties.put("AttributeWeights", this.cacheAttributeWeights);
/*      */     } else {
/* 2060 */       localProperties.setProperty("AttributeWeights", "NULL");
/*      */     }
/* 2062 */     localProperties.setProperty("InactivityTimeout", String.valueOf(this.cacheInactivityTimeout));
/*      */     
/* 2064 */     localProperties.setProperty("TimeToLiveTimeout", String.valueOf(this.cacheTimeToLiveTimeout));
/*      */     
/* 2066 */     localProperties.setProperty("AbandonedConnectionTimeout", String.valueOf(this.cacheAbandonedConnectionTimeout));
/*      */     
/* 2068 */     localProperties.setProperty("LowerThresholdLimit", String.valueOf(this.cacheLowerThresholdLimit));
/*      */     
/* 2070 */     localProperties.setProperty("PropertyCheckInterval", String.valueOf(this.cachePropertyCheckInterval));
/*      */     
/* 2072 */     localProperties.setProperty("ConnectionWaitTimeout", String.valueOf(this.cacheConnectionWaitTimeout));
/*      */     
/* 2074 */     localProperties.setProperty("ValidateConnection", String.valueOf(this.cacheValidateConnection));
/*      */     
/* 2076 */     localProperties.setProperty("ClosestConnectionMatch", String.valueOf(this.cacheClosestConnectionMatch));
/*      */     
/* 2078 */     localProperties.setProperty("LocalTransactionCommitOnClose", String.valueOf(this.cacheLocalTxnCommitOnClose));
/*      */     
/*      */ 
/* 2081 */     return localProperties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int testDatabaseConnection(OracleConnection paramOracleConnection)
/*      */     throws SQLException
/*      */   {
/* 2093 */     return paramOracleConnection.pingDatabase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void closeConnectionCache(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2110 */     cleanupTimeoutThread();
/*      */     
/*      */ 
/*      */ 
/* 2114 */     purgeCacheConnections(true, paramInt);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2121 */     this.connectionPoolDS = null;
/* 2122 */     this.cacheEnabledDS = null;
/* 2123 */     this.checkedOutConnectionList = null;
/* 2124 */     this.userMap = null;
/* 2125 */     this.cacheManager = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void disableConnectionCache()
/*      */     throws SQLException
/*      */   {
/* 2137 */     this.disableConnectionRequest = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void enableConnectionCache()
/*      */     throws SQLException
/*      */   {
/* 2149 */     this.disableConnectionRequest = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initFailoverParameters(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 2163 */     String str1 = null;
/* 2164 */     String str2 = null;
/* 2165 */     String str3 = null;
/*      */     
/* 2167 */     Properties localProperties = ((OracleConnection)paramOraclePooledConnection.getPhysicalHandle()).getServerSessionInfo();
/*      */     
/* 2169 */     str3 = localProperties.getProperty("INSTANCE_NAME");
/* 2170 */     if (str3 != null) {
/* 2171 */       str1 = paramOraclePooledConnection.dataSourceInstanceNameKey = str3.trim().toLowerCase().intern();
/*      */     }
/*      */     
/*      */ 
/* 2175 */     str3 = localProperties.getProperty("SERVER_HOST");
/* 2176 */     if (str3 != null) {
/* 2177 */       paramOraclePooledConnection.dataSourceHostNameKey = str3.trim().toLowerCase().intern();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2182 */     str3 = localProperties.getProperty("SERVICE_NAME");
/* 2183 */     if (str3 != null) {
/* 2184 */       this.dataSourceServiceName = str3.trim();
/*      */     }
/*      */     
/*      */ 
/* 2188 */     str3 = localProperties.getProperty("DATABASE_NAME");
/* 2189 */     if (str3 != null) {
/* 2190 */       str2 = paramOraclePooledConnection.dataSourceDbUniqNameKey = str3.trim().toLowerCase().intern();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2197 */     if (this.databaseInstancesList == null) {
/* 2198 */       this.databaseInstancesList = new LinkedList();
/*      */     }
/* 2200 */     int i = this.databaseInstancesList.size();
/* 2201 */     synchronized (this.databaseInstancesList)
/*      */     {
/* 2203 */       OracleDatabaseInstance localOracleDatabaseInstance1 = null;
/* 2204 */       int j = 0;
/*      */       
/* 2206 */       for (int k = 0; k < i; k++)
/*      */       {
/* 2208 */         localOracleDatabaseInstance1 = (OracleDatabaseInstance)this.databaseInstancesList.get(k);
/* 2209 */         if ((localOracleDatabaseInstance1.databaseUniqName == str2) && (localOracleDatabaseInstance1.instanceName == str1))
/*      */         {
/*      */ 
/* 2212 */           localOracleDatabaseInstance1.numberOfConnectionsCount += 1;
/* 2213 */           j = 1;
/* 2214 */           break;
/*      */         }
/*      */       }
/*      */       
/* 2218 */       if (j == 0)
/*      */       {
/* 2220 */         OracleDatabaseInstance localOracleDatabaseInstance2 = new OracleDatabaseInstance(str2, str1);
/*      */         
/*      */ 
/* 2223 */         localOracleDatabaseInstance2.numberOfConnectionsCount += 1;
/* 2224 */         this.databaseInstancesList.add(localOracleDatabaseInstance2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processFailoverEvent(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2)
/*      */   {
/* 2251 */     if (paramInt1 == 256)
/*      */     {
/* 2253 */       if ((paramString4.equalsIgnoreCase("down")) || (paramString4.equalsIgnoreCase("not_restarting")) || (paramString4.equalsIgnoreCase("restart_failed")))
/*      */       {
/*      */ 
/*      */ 
/* 2257 */         this.downEventCount += 1;
/*      */         
/* 2259 */         markDownLostConnections(true, false, paramString1, paramString2, paramString3, paramString4);
/*      */         
/* 2261 */         cleanupFailoverConnections(true, false, paramString1, paramString2, paramString3, paramString4);
/*      */ 
/*      */       }
/* 2264 */       else if (paramString4.equalsIgnoreCase("up"))
/*      */       {
/*      */ 
/*      */ 
/* 2268 */         if (this.downEventCount > 0) {
/* 2269 */           this.upEventCount += 1;
/*      */         }
/*      */         try
/*      */         {
/* 2273 */           processUpEvent(paramInt2);
/*      */         }
/*      */         catch (Exception localException) {}
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2281 */         this.isEntireServiceDownProcessed = false;
/*      */       }
/*      */     }
/* 2284 */     else if ((paramInt1 == 512) && (paramString4.equalsIgnoreCase("nodedown")))
/*      */     {
/*      */ 
/*      */ 
/* 2288 */       markDownLostConnections(false, true, paramString1, paramString2, paramString3, paramString4);
/*      */       
/* 2290 */       cleanupFailoverConnections(false, true, paramString1, paramString2, paramString3, paramString4);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void processUpEvent(int paramInt)
/*      */     throws SQLException
/*      */   {
/* 2367 */     int i = 0;
/* 2368 */     int j = 0;
/* 2369 */     int k = getTotalCachedConnections();
/* 2370 */     boolean bool = false;
/*      */     
/* 2372 */     synchronized (this)
/*      */     {
/*      */ 
/*      */ 
/* 2376 */       if (paramInt <= 1) {
/* 2377 */         paramInt = 2;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2384 */       if ((this.downEventCount == 0) && (this.upEventCount == 0) && (getNumberOfDefaultUserConnections() > 0))
/*      */       {
/*      */ 
/*      */ 
/* 2388 */         i = (int)(this.cacheSize * 0.25D);
/*      */       }
/*      */       else
/*      */       {
/* 2392 */         i = this.defaultUserPreFailureSize;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2404 */       if (i <= 0)
/*      */       {
/* 2406 */         if (getNumberOfDefaultUserConnections() > 0)
/*      */         {
/* 2408 */           j = (int)(this.cacheSize * 0.25D);
/* 2409 */           bool = true;
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 2418 */         j = i / paramInt;
/*      */         
/*      */ 
/*      */ 
/* 2422 */         if (j + k > this.cacheMaxLimit) {
/* 2423 */           bool = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2438 */       if (this.downEventCount == this.upEventCount)
/*      */       {
/* 2440 */         this.defaultUserPreFailureSize = 0;
/* 2441 */         this.downEventCount = 0;
/* 2442 */         this.upEventCount = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2447 */     if (j > 0) {
/* 2448 */       loadBalanceConnections(j, bool);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadBalanceConnections(int paramInt, boolean paramBoolean)
/*      */     throws SQLException
/*      */   {
/* 2460 */     if (paramBoolean)
/*      */     {
/* 2462 */       this.connectionsToRemove = paramInt;
/*      */       
/* 2464 */       doForEveryCachedConnection(8);
/*      */       
/* 2466 */       this.connectionsToRemove = 0;
/*      */     }
/*      */     
/*      */ 
/* 2470 */     if (paramInt <= 10)
/*      */     {
/*      */       try
/*      */       {
/* 2474 */         defaultUserPrePopulateCache(paramInt);
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (Exception localException1) {}
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 2486 */       int i = (int)(paramInt * 0.25D);
/*      */       
/* 2488 */       for (int j = 0; j < 4; j++)
/*      */       {
/*      */         try
/*      */         {
/* 2492 */           defaultUserPrePopulateCache(i);
/*      */         }
/*      */         catch (Exception localException2) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getNumberOfDefaultUserConnections()
/*      */   {
/* 2511 */     int i = 0;
/*      */     
/* 2513 */     if ((this.userMap != null) && (!this.userMap.isEmpty()))
/*      */     {
/*      */ 
/* 2516 */       OracleConnectionCacheEntry localOracleConnectionCacheEntry = (OracleConnectionCacheEntry)this.userMap.get(OraclePooledConnection.generateKey(this.defaultUser, this.defaultPassword));
/*      */       
/*      */ 
/*      */ 
/* 2520 */       if ((localOracleConnectionCacheEntry != null) && (localOracleConnectionCacheEntry.userConnList != null) && (!localOracleConnectionCacheEntry.userConnList.isEmpty()))
/*      */       {
/*      */ 
/* 2523 */         i = localOracleConnectionCacheEntry.userConnList.size();
/*      */       }
/*      */     }
/* 2526 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void markDownLostConnections(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, String paramString3, String paramString4)
/*      */   {
/* 2547 */     if (!this.isEntireServiceDownProcessed)
/*      */     {
/* 2549 */       if ((this.userMap != null) && (!this.userMap.isEmpty()))
/*      */       {
/*      */ 
/*      */ 
/* 2553 */         Iterator localIterator1 = this.userMap.entrySet().iterator();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2561 */         while (localIterator1.hasNext())
/*      */         {
/* 2563 */           int i = 0;
/*      */           
/* 2565 */           Map.Entry localEntry = (Map.Entry)localIterator1.next();
/* 2566 */           String str = null;
/* 2567 */           if ((this.defaultUser != null) && (this.defaultPassword != null)) {
/* 2568 */             str = this.defaultUser + this.defaultPassword;
/*      */           }
/*      */           
/* 2571 */           if ((str != null) && (str.equalsIgnoreCase((String)localEntry.getKey())))
/*      */           {
/* 2573 */             i = 1;
/*      */           }
/* 2575 */           OracleConnectionCacheEntry localOracleConnectionCacheEntry = (OracleConnectionCacheEntry)localEntry.getValue();
/*      */           
/*      */           Object localObject1;
/*      */           Object localObject2;
/* 2579 */           if ((localOracleConnectionCacheEntry != null) && (localOracleConnectionCacheEntry.userConnList != null) && (!localOracleConnectionCacheEntry.userConnList.isEmpty()))
/*      */           {
/*      */ 
/* 2582 */             boolean bool = false;
/* 2583 */             localObject1 = localOracleConnectionCacheEntry.userConnList.iterator();
/*      */             
/* 2585 */             while (((Iterator)localObject1).hasNext())
/*      */             {
/* 2587 */               localObject2 = (OraclePooledConnection)((Iterator)localObject1).next();
/*      */               
/* 2589 */               if (paramBoolean1) {
/* 2590 */                 bool = markDownConnectionsForServiceEvent(paramString1, paramString2, (OraclePooledConnection)localObject2);
/*      */               }
/* 2592 */               else if (paramBoolean2) {
/* 2593 */                 bool = markDownConnectionsForHostEvent(paramString3, (OraclePooledConnection)localObject2);
/*      */               }
/*      */               
/*      */ 
/* 2597 */               if ((bool) && (i != 0)) {
/* 2598 */                 this.defaultUserPreFailureSize += 1;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 2603 */           if ((localOracleConnectionCacheEntry != null) && (localOracleConnectionCacheEntry.attrConnMap != null) && (!localOracleConnectionCacheEntry.attrConnMap.isEmpty()))
/*      */           {
/*      */ 
/* 2606 */             Iterator localIterator2 = localOracleConnectionCacheEntry.attrConnMap.entrySet().iterator();
/*      */             
/* 2608 */             while (localIterator2.hasNext())
/*      */             {
/* 2610 */               localObject1 = (Map.Entry)localIterator2.next();
/* 2611 */               localObject2 = ((Vector)((Map.Entry)localObject1).getValue()).iterator();
/*      */               
/* 2613 */               while (((Iterator)localObject2).hasNext())
/*      */               {
/* 2615 */                 OraclePooledConnection localOraclePooledConnection = (OraclePooledConnection)((Iterator)localObject2).next();
/*      */                 
/* 2617 */                 if (paramBoolean1) {
/* 2618 */                   markDownConnectionsForServiceEvent(paramString1, paramString2, localOraclePooledConnection);
/*      */                 }
/* 2620 */                 else if (paramBoolean2) {
/* 2621 */                   markDownConnectionsForHostEvent(paramString3, localOraclePooledConnection);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 2628 */       if (paramString1 == null) {
/* 2629 */         this.isEntireServiceDownProcessed = true;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean markDownConnectionsForServiceEvent(String paramString1, String paramString2, OraclePooledConnection paramOraclePooledConnection)
/*      */   {
/* 2643 */     boolean bool = false;
/*      */     
/* 2645 */     if ((paramString1 == null) || ((paramString2 == paramOraclePooledConnection.dataSourceDbUniqNameKey) && (paramString1 == paramOraclePooledConnection.dataSourceInstanceNameKey)))
/*      */     {
/*      */ 
/*      */ 
/* 2649 */       paramOraclePooledConnection.connectionMarkedDown = true;
/* 2650 */       bool = true;
/*      */     }
/*      */     
/* 2653 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean markDownConnectionsForHostEvent(String paramString, OraclePooledConnection paramOraclePooledConnection)
/*      */   {
/* 2664 */     boolean bool = false;
/*      */     
/* 2666 */     if (paramString == paramOraclePooledConnection.dataSourceHostNameKey)
/*      */     {
/* 2668 */       paramOraclePooledConnection.connectionMarkedDown = true;
/* 2669 */       paramOraclePooledConnection.needToAbort = true;
/* 2670 */       bool = true;
/*      */     }
/* 2672 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void cleanupFailoverConnections(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, String paramString3, String paramString4)
/*      */   {
/* 2694 */     OraclePooledConnection localOraclePooledConnection = null;
/* 2695 */     Object[] arrayOfObject = this.checkedOutConnectionList.toArray();
/* 2696 */     int i = this.checkedOutConnectionList.size();
/*      */     
/* 2698 */     OraclePooledConnection[] arrayOfOraclePooledConnection = new OraclePooledConnection[i];
/* 2699 */     int j = 0;
/*      */     
/* 2701 */     for (int k = 0; k < i; k++)
/*      */     {
/*      */       try
/*      */       {
/* 2705 */         localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[k];
/*      */         
/* 2707 */         if (((paramBoolean1) && ((paramString1 == null) || (paramString1 == localOraclePooledConnection.dataSourceInstanceNameKey)) && (paramString2 == localOraclePooledConnection.dataSourceDbUniqNameKey)) || ((paramBoolean2) && (paramString3 == localOraclePooledConnection.dataSourceHostNameKey)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2714 */           if ((localOraclePooledConnection.isSameUser(this.defaultUser, this.defaultPassword)) && (localOraclePooledConnection.cachedConnectionAttributes != null) && (localOraclePooledConnection.cachedConnectionAttributes.isEmpty()))
/*      */           {
/*      */ 
/* 2717 */             this.defaultUserPreFailureSize += 1;
/*      */           }
/*      */           
/* 2720 */           this.checkedOutConnectionList.removeElement(localOraclePooledConnection);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2727 */           abortConnection(localOraclePooledConnection);
/* 2728 */           localOraclePooledConnection.needToAbort = true;
/*      */           
/*      */ 
/* 2731 */           arrayOfOraclePooledConnection[(j++)] = localOraclePooledConnection;
/*      */         }
/*      */       }
/*      */       catch (Exception localException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2741 */     for (k = 0; k < j; k++)
/*      */     {
/*      */       try
/*      */       {
/* 2745 */         closeCheckedOutConnection(arrayOfOraclePooledConnection[k], false);
/*      */       }
/*      */       catch (SQLException localSQLException2) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2754 */     if ((this.checkedOutConnectionList.size() < i) && (this.cacheConnectionWaitTimeout > 0))
/*      */     {
/*      */ 
/* 2757 */       notifyAll();
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2763 */       doForEveryCachedConnection(2);
/*      */     }
/*      */     catch (SQLException localSQLException1) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2772 */     if ((this.databaseInstancesList != null) && ((i = this.databaseInstancesList.size()) > 0))
/*      */     {
/*      */ 
/* 2775 */       synchronized (this.databaseInstancesList)
/*      */       {
/* 2777 */         OracleDatabaseInstance localOracleDatabaseInstance = null;
/* 2778 */         arrayOfObject = this.databaseInstancesList.toArray();
/*      */         
/* 2780 */         for (int m = 0; m < i; m++)
/*      */         {
/* 2782 */           localOracleDatabaseInstance = (OracleDatabaseInstance)arrayOfObject[m];
/*      */           
/* 2784 */           if ((localOracleDatabaseInstance.databaseUniqName == paramString2) && (localOracleDatabaseInstance.instanceName == paramString1))
/*      */           {
/*      */ 
/*      */ 
/* 2788 */             if (localOracleDatabaseInstance.flag <= 3)
/* 2789 */               this.dbInstancePercentTotal -= localOracleDatabaseInstance.percent;
/* 2790 */             this.databaseInstancesList.remove(localOracleDatabaseInstance);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void zapRLBInfo()
/*      */   {
/* 2804 */     this.databaseInstancesList.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void closeAndRemovePooledConnection(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 2816 */     if (paramOraclePooledConnection != null)
/*      */     {
/* 2818 */       if (paramOraclePooledConnection.needToAbort) {
/* 2819 */         abortConnection(paramOraclePooledConnection);
/*      */       }
/* 2821 */       actualPooledConnectionClose(paramOraclePooledConnection);
/* 2822 */       removeCacheConnection(paramOraclePooledConnection);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void abortConnection(OraclePooledConnection paramOraclePooledConnection)
/*      */   {
/*      */     try
/*      */     {
/* 2841 */       ((OracleConnection)paramOraclePooledConnection.getPhysicalHandle()).abort();
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void actualPooledConnectionClose(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 2861 */     int i = 0;
/* 2862 */     if ((this.databaseInstancesList != null) && ((i = this.databaseInstancesList.size()) > 0))
/*      */     {
/*      */ 
/* 2865 */       synchronized (this.databaseInstancesList)
/*      */       {
/* 2867 */         OracleDatabaseInstance localOracleDatabaseInstance = null;
/*      */         
/* 2869 */         for (int j = 0; j < i; j++)
/*      */         {
/* 2871 */           localOracleDatabaseInstance = (OracleDatabaseInstance)this.databaseInstancesList.get(j);
/* 2872 */           if ((localOracleDatabaseInstance.databaseUniqName == paramOraclePooledConnection.dataSourceDbUniqNameKey) && (localOracleDatabaseInstance.instanceName == paramOraclePooledConnection.dataSourceInstanceNameKey))
/*      */           {
/*      */ 
/* 2875 */             if (localOracleDatabaseInstance.numberOfConnectionsCount <= 0) break;
/* 2876 */             localOracleDatabaseInstance.numberOfConnectionsCount -= 1; break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 2890 */       this.connectionClosedCount += 1;
/* 2891 */       paramOraclePooledConnection.close();
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getCacheTimeToLiveTimeout()
/*      */   {
/* 2903 */     return this.cacheTimeToLiveTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected int getCacheInactivityTimeout()
/*      */   {
/* 2910 */     return this.cacheInactivityTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected int getCachePropertyCheckInterval()
/*      */   {
/* 2917 */     return this.cachePropertyCheckInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected int getCacheAbandonedTimeout()
/*      */   {
/* 2924 */     return this.cacheAbandonedConnectionTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void processConnectionCacheCallback()
/*      */     throws SQLException
/*      */   {
/* 2939 */     float f = this.cacheMaxLimit / 100.0F;
/* 2940 */     int i = (int)(this.cacheLowerThresholdLimit * f);
/*      */     
/*      */ 
/* 2943 */     releaseBasedOnPriority(1024, i);
/*      */     
/*      */ 
/* 2946 */     if (this.cacheSize < i) {
/* 2947 */       releaseBasedOnPriority(512, i);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void releaseBasedOnPriority(int paramInt1, int paramInt2)
/*      */     throws SQLException
/*      */   {
/* 2960 */     Object[] arrayOfObject = this.checkedOutConnectionList.toArray();
/*      */     
/* 2962 */     for (int i = 0; (i < arrayOfObject.length) && (this.cacheSize < paramInt2); i++)
/*      */     {
/* 2964 */       OraclePooledConnection localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[i];
/* 2965 */       OracleConnection localOracleConnection = null;
/*      */       
/* 2967 */       if (localOraclePooledConnection != null) {
/* 2968 */         localOracleConnection = (OracleConnection)localOraclePooledConnection.getLogicalHandle();
/*      */       }
/* 2970 */       if (localOracleConnection != null)
/*      */       {
/* 2972 */         OracleConnectionCacheCallback localOracleConnectionCacheCallback = localOracleConnection.getConnectionCacheCallbackObj();
/*      */         
/*      */ 
/* 2975 */         if ((localOracleConnectionCacheCallback != null) && ((localOracleConnection.getConnectionCacheCallbackFlag() == 2) || (localOracleConnection.getConnectionCacheCallbackFlag() == 4)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2981 */           if (paramInt1 == localOracleConnection.getConnectionReleasePriority())
/*      */           {
/* 2983 */             Object localObject = localOracleConnection.getConnectionCacheCallbackPrivObj();
/* 2984 */             localOracleConnectionCacheCallback.releaseConnection(localOracleConnection, localObject);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void processConnectionWaitTimeout(long paramLong)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3005 */       wait(paramLong);
/*      */     }
/*      */     catch (InterruptedException localInterruptedException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processInactivityTimeout(OraclePooledConnection paramOraclePooledConnection)
/*      */     throws SQLException
/*      */   {
/* 3027 */     long l1 = paramOraclePooledConnection.getLastAccessedTime();
/* 3028 */     long l2 = System.currentTimeMillis();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3036 */     if ((getTotalCachedConnections() > this.cacheMinLimit) && (l2 - l1 > this.cacheInactivityTimeout * 1000))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3042 */       closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanupTimeoutThread()
/*      */     throws SQLException
/*      */   {
/* 3056 */     if (this.timeoutThread != null)
/*      */     {
/* 3058 */       this.timeoutThread.timeToLive = false;
/*      */       
/*      */ 
/*      */ 
/* 3062 */       if (this.timeoutThread.isSleeping) {
/* 3063 */         this.timeoutThread.interrupt();
/*      */       }
/* 3065 */       this.timeoutThread = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void purgeCacheConnections(boolean paramBoolean, int paramInt)
/*      */   {
/*      */     try
/*      */     {
/* 3082 */       if (paramBoolean) {
/* 3083 */         doForEveryCheckedOutConnection(paramInt);
/*      */       }
/*      */       
/* 3086 */       doForEveryCachedConnection(paramInt);
/*      */     }
/*      */     catch (SQLException localSQLException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void updateDatabaseInstance(String paramString1, String paramString2, int paramInt1, int paramInt2)
/*      */   {
/* 3103 */     if (this.databaseInstancesList == null) {
/* 3104 */       this.databaseInstancesList = new LinkedList();
/*      */     }
/* 3106 */     synchronized (this.databaseInstancesList)
/*      */     {
/* 3108 */       int i = this.databaseInstancesList.size();
/* 3109 */       int j = 0;
/*      */       
/* 3111 */       for (int k = 0; k < i; k++)
/*      */       {
/* 3113 */         OracleDatabaseInstance localOracleDatabaseInstance2 = (OracleDatabaseInstance)this.databaseInstancesList.get(k);
/*      */         
/* 3115 */         if ((localOracleDatabaseInstance2.databaseUniqName == paramString1) && (localOracleDatabaseInstance2.instanceName == paramString2))
/*      */         {
/*      */ 
/* 3118 */           localOracleDatabaseInstance2.percent = paramInt1;
/* 3119 */           localOracleDatabaseInstance2.flag = paramInt2;
/* 3120 */           j = 1;
/* 3121 */           break;
/*      */         }
/*      */       }
/*      */       
/* 3125 */       if (j == 0)
/*      */       {
/* 3127 */         OracleDatabaseInstance localOracleDatabaseInstance1 = new OracleDatabaseInstance(paramString1, paramString2);
/*      */         
/*      */ 
/* 3130 */         localOracleDatabaseInstance1.percent = paramInt1;
/* 3131 */         localOracleDatabaseInstance1.flag = paramInt2;
/*      */         
/* 3133 */         this.databaseInstancesList.add(localOracleDatabaseInstance1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processDatabaseInstances()
/*      */     throws SQLException
/*      */   {
/* 3148 */     OracleDatabaseInstance localOracleDatabaseInstance = null;
/*      */     
/* 3150 */     if (this.databaseInstancesList != null)
/*      */     {
/* 3152 */       synchronized (this.databaseInstancesList)
/*      */       {
/* 3154 */         int i = 0;
/* 3155 */         int j = 0;
/*      */         
/*      */ 
/* 3158 */         this.useGoodGroup = false;
/*      */         
/*      */ 
/* 3161 */         int k = this.databaseInstancesList.size();
/*      */         
/* 3163 */         for (int m = 0; m < k; m++)
/*      */         {
/* 3165 */           localOracleDatabaseInstance = (OracleDatabaseInstance)this.databaseInstancesList.get(m);
/*      */           
/*      */ 
/*      */ 
/* 3169 */           if (localOracleDatabaseInstance.flag <= 3) {
/* 3170 */             i += localOracleDatabaseInstance.percent;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3176 */         if (i > 0)
/*      */         {
/* 3178 */           this.dbInstancePercentTotal = i;
/* 3179 */           this.useGoodGroup = true;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3186 */         if (k > 1)
/*      */         {
/*      */ 
/* 3189 */           for (m = 0; m < k; m++)
/*      */           {
/* 3191 */             localOracleDatabaseInstance = (OracleDatabaseInstance)this.databaseInstancesList.get(m);
/* 3192 */             this.countTotal += localOracleDatabaseInstance.attemptedConnRequestCount;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3200 */           if (this.countTotal > k * 1000)
/*      */           {
/* 3202 */             for (m = 0; m < k; m++)
/*      */             {
/* 3204 */               localOracleDatabaseInstance = (OracleDatabaseInstance)this.databaseInstancesList.get(m);
/*      */               
/*      */ 
/* 3207 */               float f1 = localOracleDatabaseInstance.attemptedConnRequestCount / this.countTotal;
/*      */               
/* 3209 */               float f2 = localOracleDatabaseInstance.numberOfConnectionsCount / getTotalCachedConnections();
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3222 */               if (f2 > f1 * 2.0F)
/*      */               {
/*      */ 
/*      */ 
/* 3226 */                 if ((int)(localOracleDatabaseInstance.numberOfConnectionsCount * 0.25D) >= 1) {
/* 3227 */                   this.instancesToRetireQueue.addElement(localOracleDatabaseInstance);
/*      */                 }
/* 3229 */                 j = 1;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/* 3234 */             if (j != 0)
/*      */             {
/* 3236 */               for (m = 0; m < k; m++)
/*      */               {
/* 3238 */                 localOracleDatabaseInstance = (OracleDatabaseInstance)this.databaseInstancesList.get(m);
/*      */                 
/* 3240 */                 localOracleDatabaseInstance.attemptedConnRequestCount = 0;
/*      */               }
/* 3242 */               j = 0;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3259 */       if (this.instancesToRetireQueue.size() > 0)
/*      */       {
/* 3261 */         if (this.gravitateCacheThread != null)
/*      */         {
/*      */           try
/*      */           {
/* 3265 */             this.gravitateCacheThread.interrupt();
/* 3266 */             this.gravitateCacheThread.join();
/*      */           }
/*      */           catch (InterruptedException localInterruptedException) {}
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3273 */           this.gravitateCacheThread = null;
/*      */         }
/*      */         
/*      */ 
/* 3277 */         this.gravitateCacheThread = new OracleGravitateConnectionCacheThread(this);
/*      */         
/*      */ 
/* 3280 */         this.cacheManager.checkAndStartThread(this.gravitateCacheThread);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void gravitateCache()
/*      */   {
/* 3295 */     while (this.instancesToRetireQueue.size() > 0)
/*      */     {
/*      */ 
/* 3298 */       this.instanceToRetire = ((OracleDatabaseInstance)this.instancesToRetireQueue.remove(0));
/* 3299 */       this.retireConnectionsCount = ((int)(this.instanceToRetire.numberOfConnectionsCount * 0.25D));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 3307 */         doForEveryCachedConnection(24);
/*      */       }
/*      */       catch (SQLException localSQLException1) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3321 */       if (this.retireConnectionsCount > 0)
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/*      */ 
/* 3327 */           doForEveryCheckedOutConnection(24);
/*      */         }
/*      */         catch (SQLException localSQLException2) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3338 */     this.retireConnectionsCount = 0;
/* 3339 */     this.instanceToRetire = null;
/* 3340 */     this.countTotal = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void cleanupRLBThreads()
/*      */   {
/* 3359 */     if (this.gravitateCacheThread != null)
/*      */     {
/*      */       try
/*      */       {
/* 3363 */         this.gravitateCacheThread.interrupt();
/* 3364 */         this.gravitateCacheThread.join();
/*      */       }
/*      */       catch (InterruptedException localInterruptedException) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3371 */       this.gravitateCacheThread = null;
/*      */     }
/*      */     
/* 3374 */     if (this.runtimeLoadBalancingThread != null)
/*      */     {
/*      */       try
/*      */       {
/* 3378 */         this.runtimeLoadBalancingThread.interrupt();
/*      */       }
/*      */       catch (Exception localException) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3385 */       this.runtimeLoadBalancingThread = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Map getStatistics()
/*      */     throws SQLException
/*      */   {
/* 3397 */     HashMap localHashMap = new HashMap(2);
/* 3398 */     localHashMap.put("PhysicalConnectionClosedCount", new Integer(this.connectionClosedCount));
/* 3399 */     localHashMap.put("PhysicalConnectionCreatedCount", new Integer(this.connectionCreatedCount));
/*      */     
/* 3401 */     return localHashMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OracleConnection getConnectionDuringExceptionHandling()
/*      */   {
/* 3416 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 3421 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\pool\OracleImplicitConnectionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */