/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Vector;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ class OracleImplicitConnectionCacheThread
/*     */   extends Thread
/*     */ {
/*  35 */   private OracleImplicitConnectionCache implicitCache = null;
/*  36 */   protected boolean timeToLive = true;
/*  37 */   protected boolean isSleeping = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   OracleImplicitConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache)
/*     */     throws SQLException
/*     */   {
/*  45 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*  53 */     long l1 = 0L;
/*  54 */     long l2 = 0L;
/*  55 */     long l3 = 0L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  60 */     while (this.timeToLive)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*  66 */         if ((this.timeToLive) && ((l1 = this.implicitCache.getCacheTimeToLiveTimeout()) > 0L))
/*     */         {
/*     */ 
/*  69 */           runTimeToLiveTimeout(l1);
/*     */         }
/*     */         
/*     */ 
/*  73 */         if ((this.timeToLive) && ((l2 = this.implicitCache.getCacheInactivityTimeout()) > 0L))
/*     */         {
/*  75 */           runInactivityTimeout();
/*     */         }
/*     */         
/*     */ 
/*  79 */         if ((this.timeToLive) && ((l3 = this.implicitCache.getCacheAbandonedTimeout()) > 0L))
/*     */         {
/*  81 */           runAbandonedTimeout(l3);
/*     */         }
/*     */         
/*     */ 
/*  85 */         if (this.timeToLive)
/*     */         {
/*  87 */           this.isSleeping = true;
/*     */           
/*     */           try
/*     */           {
/*  91 */             sleep(this.implicitCache.getCachePropertyCheckInterval() * 1000);
/*     */           }
/*     */           catch (InterruptedException localInterruptedException) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*  98 */           this.isSleeping = false;
/*     */         }
/*     */         
/*     */ 
/* 102 */         if ((this.implicitCache == null) || ((l1 <= 0L) && (l2 <= 0L) && (l3 <= 0L)))
/*     */         {
/*     */ 
/* 105 */           this.timeToLive = false;
/*     */         }
/*     */       }
/*     */       catch (SQLException localSQLException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runTimeToLiveTimeout(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 121 */     long l1 = 0L;
/* 122 */     long l2 = 0L;
/*     */     
/*     */ 
/* 125 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0)
/*     */     {
/* 127 */       OraclePooledConnection localOraclePooledConnection = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 132 */       synchronized (this.implicitCache)
/*     */       {
/*     */ 
/*     */ 
/* 136 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/* 137 */         int i = this.implicitCache.checkedOutConnectionList.size();
/*     */         
/* 139 */         for (int j = 0; j < i; j++)
/*     */         {
/* 141 */           localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[j];
/*     */           
/* 143 */           Connection localConnection = localOraclePooledConnection.getLogicalHandle();
/*     */           
/* 145 */           if (localConnection != null)
/*     */           {
/* 147 */             l2 = ((OracleConnection)localConnection).getStartTime();
/*     */             
/* 149 */             l1 = System.currentTimeMillis();
/*     */             
/*     */ 
/* 152 */             if (l1 - l2 > paramLong * 1000L)
/*     */             {
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/* 158 */                 this.implicitCache.closeCheckedOutConnection(localOraclePooledConnection, true);
/*     */               }
/*     */               catch (SQLException localSQLException) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runInactivityTimeout()
/*     */   {
/*     */     try
/*     */     {
/* 180 */       this.implicitCache.doForEveryCachedConnection(4);
/*     */     }
/*     */     catch (SQLException localSQLException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runAbandonedTimeout(long paramLong)
/*     */     throws SQLException
/*     */   {
/* 198 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0)
/*     */     {
/* 200 */       OraclePooledConnection localOraclePooledConnection = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 205 */       synchronized (this.implicitCache)
/*     */       {
/* 207 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/*     */         
/*     */ 
/* 210 */         for (int i = 0; i < arrayOfObject.length; i++)
/*     */         {
/* 212 */           localOraclePooledConnection = (OraclePooledConnection)arrayOfObject[i];
/*     */           
/* 214 */           OracleConnection localOracleConnection = (OracleConnection)localOraclePooledConnection.getLogicalHandle();
/*     */           
/* 216 */           if (localOracleConnection != null)
/*     */           {
/*     */ 
/*     */ 
/* 220 */             OracleConnectionCacheCallback localOracleConnectionCacheCallback = localOracleConnection.getConnectionCacheCallbackObj();
/*     */             
/*     */ 
/*     */ 
/* 224 */             if (localOracleConnection.getHeartbeatNoChangeCount() * this.implicitCache.getCachePropertyCheckInterval() > paramLong)
/*     */             {
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/* 232 */                 boolean bool = true;
/* 233 */                 if ((localOracleConnectionCacheCallback != null) && ((localOracleConnection.getConnectionCacheCallbackFlag() == 4) || (localOracleConnection.getConnectionCacheCallbackFlag() == 1)))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */                   bool = localOracleConnectionCacheCallback.handleAbandonedConnection(localOracleConnection, localOracleConnection.getConnectionCacheCallbackPrivObj());
/*     */                 }
/*     */                 
/*     */ 
/*     */ 
/* 249 */                 if (bool) {
/* 250 */                   this.implicitCache.closeCheckedOutConnection(localOraclePooledConnection, true);
/*     */                 }
/*     */               }
/*     */               catch (SQLException localSQLException) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 268 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Tue_Aug_23_13:33:58_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\pool\OracleImplicitConnectionCacheThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */