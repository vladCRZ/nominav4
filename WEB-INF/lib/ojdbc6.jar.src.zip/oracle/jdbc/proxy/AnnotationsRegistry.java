/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.jdbc.proxy.annotation.GetCreator;
/*     */ import oracle.jdbc.proxy.annotation.GetDelegate;
/*     */ import oracle.jdbc.proxy.annotation.GetProxy;
/*     */ import oracle.jdbc.proxy.annotation.Methods;
/*     */ import oracle.jdbc.proxy.annotation.OnError;
/*     */ import oracle.jdbc.proxy.annotation.Post;
/*     */ import oracle.jdbc.proxy.annotation.Pre;
/*     */ import oracle.jdbc.proxy.annotation.ProxyFor;
/*     */ import oracle.jdbc.proxy.annotation.ProxyLocale;
/*     */ import oracle.jdbc.proxy.annotation.SetDelegate;
/*     */ import oracle.jdbc.proxy.annotation.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationsRegistry
/*     */ {
/*     */   private static class SyntaxError
/*     */     extends RuntimeException
/*     */   {
/*     */     SyntaxError(String paramString)
/*     */     {
/*  48 */       super();
/*     */     }
/*     */     
/*  51 */     private static final SyntaxError onlyOneAllowed = new SyntaxError("only one @Pre/@Post/@OnError/@GetDelegate/@SetDelegate/@GetCreator/@GetProxy allowed");
/*     */     
/*     */ 
/*  54 */     private static final SyntaxError onlyOneMethodslessAllowed = new SyntaxError("only one @Methods-less @Pre/@Post/@OnError allowed");
/*     */     
/*     */ 
/*  57 */     private static final SyntaxError wrongMethodsContext = new SyntaxError("wrong context for @Methods");
/*     */     
/*     */ 
/*  60 */     private static final SyntaxError wrongPre = new SyntaxError("wrong @Pre");
/*     */     
/*     */ 
/*  63 */     private static final SyntaxError wrongPost = new SyntaxError("wrong @Post");
/*     */     
/*     */ 
/*  66 */     private static final SyntaxError wrongOnError = new SyntaxError("wrong @OnError");
/*     */     
/*     */ 
/*  69 */     private static final SyntaxError onlyOneOnErrorExceptionTypeAllowed = new SyntaxError("only one @OnError Exception type allowed for a given method");
/*     */     
/*     */ 
/*  72 */     private static final SyntaxError wrongGetCreator = new SyntaxError("wrong @GetCreator");
/*     */     
/*     */ 
/*  75 */     private static final SyntaxError wrongGetCreatorMustBeProtected = new SyntaxError("wrong @GetCreator: must be protected");
/*     */     
/*     */ 
/*  78 */     private static final SyntaxError wrongGetCreatorMustBeAbstract = new SyntaxError("wrong @GetCreator: must be abstract");
/*     */     
/*     */ 
/*  81 */     private static final SyntaxError wrongGetDelegate = new SyntaxError("wrong @GetDelegate");
/*     */     
/*     */ 
/*  84 */     private static final SyntaxError wrongGetDelegateMustBeProtected = new SyntaxError("wrong @GetDelegate: must be protected");
/*     */     
/*     */ 
/*  87 */     private static final SyntaxError wrongGetDelegateMustBeAbstract = new SyntaxError("wrong @GetDelegate: must be abstract");
/*     */     
/*     */ 
/*  90 */     private static final SyntaxError wrongGetProxy = new SyntaxError("wrong @GetProxy");
/*     */     
/*     */ 
/*  93 */     private static final SyntaxError wrongGetProxyMustBeProtected = new SyntaxError("wrong @GetProxy: must be protected");
/*     */     
/*     */ 
/*  96 */     private static final SyntaxError wrongGetProxyMustBeAbstract = new SyntaxError("wrong @GetProxy: must be abstract");
/*     */     
/*     */ 
/*  99 */     private static final SyntaxError wrongSetDelegate = new SyntaxError("wrong @SetDelegate");
/*     */     
/*     */ 
/* 102 */     private static final SyntaxError wrongSetDelegateMustBeProtected = new SyntaxError("wrong @SetDelegate: must be protected");
/*     */     
/*     */ 
/* 105 */     private static final SyntaxError wrongSetDelegateMustBeAbstract = new SyntaxError("wrong @SetDelegate: must be abstract");
/*     */     
/*     */ 
/* 108 */     private static final SyntaxError emptyProxyForList = new SyntaxError("empty @ProxyFor list");
/*     */     
/*     */ 
/*     */     private static SyntaxError mustBeClass(Class paramClass)
/*     */     {
/* 113 */       return new SyntaxError(paramClass.getName() + " must be an abstract or concrete class");
/*     */     }
/*     */     
/*     */ 
/*     */     private static SyntaxError mustBeIface(Class paramClass)
/*     */     {
/* 119 */       return new SyntaxError(paramClass.getName() + " must be an interface");
/*     */     }
/*     */     
/*     */ 
/*     */     private static SyntaxError annotationDefinedMoreThanOnce(String paramString)
/*     */     {
/* 125 */       return new SyntaxError(paramString + " is defined more than once for the same method");
/*     */     }
/*     */     
/*     */ 
/*     */     private static SyntaxError noProxyForClass(Class paramClass)
/*     */     {
/* 131 */       return new SyntaxError("no @ProxyFor for class " + paramClass.getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static SyntaxError returnTypeMismatch(Method paramMethod1, Method paramMethod2)
/*     */     {
/* 138 */       return new SyntaxError("interceptor " + paramMethod1.getName() + " and interceptee " + paramMethod2.getName() + ": have different return types (" + paramMethod1.getReturnType().getName() + " and " + paramMethod2.getReturnType().getName() + ")");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */   private Map<Class, Value> ifacesToAnnotatedSuperclasses = new HashMap();
/*     */   
/*     */ 
/*     */   void register(Class... paramVarArgs)
/*     */   {
/*     */     Value localValue;
/*     */     
/* 155 */     for (Class localClass1 : paramVarArgs)
/*     */     {
/* 157 */       if (localClass1.isInterface()) {
/* 158 */         throw SyntaxError.mustBeClass(localClass1);
/*     */       }
/* 160 */       localValue = new Value(localClass1);
/*     */       
/* 162 */       for (Class localClass2 : localValue.getIfacesToProxy()) {
/* 163 */         this.ifacesToAnnotatedSuperclasses.put(localClass2, localValue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   Value get(Class paramClass) {
/* 169 */     return (Value)this.ifacesToAnnotatedSuperclasses.get(paramClass);
/*     */   }
/*     */   
/*     */   Set<Class> keySet()
/*     */   {
/* 174 */     return this.ifacesToAnnotatedSuperclasses.keySet();
/*     */   }
/*     */   
/*     */   Collection<Value> values()
/*     */   {
/* 179 */     return this.ifacesToAnnotatedSuperclasses.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 184 */   boolean containsKey(Object paramObject) { return this.ifacesToAnnotatedSuperclasses.containsKey(paramObject); }
/*     */   
/*     */   static class Value {
/*     */     private final Class superclass;
/*     */     
/*     */     private static class MethodSpecific<T> {
/*     */       static final class Pres extends AnnotationsRegistry.Value.MethodSpecific<Method> {
/* 191 */         Pres() { super(null); } }
/* 192 */       static final class VoidPosts extends AnnotationsRegistry.Value.MethodSpecific<Method> { VoidPosts() { super(null); } }
/* 193 */       static final class ReturningPosts extends AnnotationsRegistry.Value.MethodSpecific<Method> { ReturningPosts() { super(null); } }
/* 194 */       static final class VoidOnErrors extends AnnotationsRegistry.Value.MethodSpecific<Map<Class, Method>> { VoidOnErrors() { super(null); } }
/* 195 */       static final class ReturningOnErrors extends AnnotationsRegistry.Value.MethodSpecific<Map<Class, Method>> { ReturningOnErrors() { super(null); } }
/*     */       
/* 197 */       private final Map<MethodSignature, T> ref = new HashMap();
/*     */       
/*     */       private final String annotationType;
/*     */       
/*     */ 
/*     */       private MethodSpecific(String paramString)
/*     */       {
/* 204 */         this.annotationType = paramString;
/*     */       }
/*     */       
/*     */       void put(MethodSignature paramMethodSignature, T paramT)
/*     */       {
/* 209 */         if (null != this.ref.put(paramMethodSignature, paramT)) {
/* 210 */           throw AnnotationsRegistry.SyntaxError.access$200(this.annotationType);
/*     */         }
/*     */       }
/*     */       
/*     */       T get(MethodSignature paramMethodSignature) {
/* 215 */         return (T)this.ref.get(paramMethodSignature);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static class Rest
/*     */     {
/*     */       private final Method pre;
/*     */       
/*     */ 
/*     */       private final Method voidPost;
/*     */       
/*     */       private final Method returningPost;
/*     */       
/*     */       private final Map<Class, Method> voidOnErrorsMap;
/*     */       
/*     */       private final Map<Class, Method> returningOnErrorsMap;
/*     */       
/*     */ 
/*     */       Rest(Method paramMethod1, Method paramMethod2, Method paramMethod3, Map<Class, Method> paramMap1, Map<Class, Method> paramMap2)
/*     */       {
/* 237 */         this.pre = paramMethod1;
/* 238 */         this.voidPost = paramMethod2;
/* 239 */         this.returningPost = paramMethod3;
/* 240 */         this.voidOnErrorsMap = paramMap1;
/* 241 */         this.returningOnErrorsMap = paramMap2;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       Method getPre()
/*     */       {
/* 249 */         return this.pre;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       Map<Class, Method> getReturningOnError()
/*     */       {
/* 257 */         return this.returningOnErrorsMap;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       Method getReturningPost()
/*     */       {
/* 265 */         return this.returningPost;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       Map<Class, Method> getVoidOnError()
/*     */       {
/* 273 */         return this.voidOnErrorsMap;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       Method getVoidPost()
/*     */       {
/* 281 */         return this.voidPost;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 286 */     private final List<Class> ifacesToProxy = new ArrayList();
/*     */     
/* 288 */     private final AnnotationsRegistry.Value.MethodSpecific.Pres pres = new AnnotationsRegistry.Value.MethodSpecific.Pres();
/* 289 */     private final AnnotationsRegistry.Value.MethodSpecific.VoidPosts voidPosts = new AnnotationsRegistry.Value.MethodSpecific.VoidPosts();
/* 290 */     private final AnnotationsRegistry.Value.MethodSpecific.ReturningPosts returningPosts = new AnnotationsRegistry.Value.MethodSpecific.ReturningPosts();
/* 291 */     private final AnnotationsRegistry.Value.MethodSpecific.VoidOnErrors voidOnErrors = new AnnotationsRegistry.Value.MethodSpecific.VoidOnErrors();
/* 292 */     private final AnnotationsRegistry.Value.MethodSpecific.ReturningOnErrors returningOnErrors = new AnnotationsRegistry.Value.MethodSpecific.ReturningOnErrors();
/*     */     
/*     */     private final Rest rest;
/*     */     
/* 296 */     private Method methodGetCreator = null;
/* 297 */     private Method methodGetDelegate = null;
/* 298 */     private Method methodGetProxy = null;
/* 299 */     private Method methodSetDelegate = null;
/* 300 */     private boolean isProxyLocale = false;
/*     */     
/*     */     Value(Class paramClass)
/*     */     {
/* 304 */       this.superclass = paramClass;
/* 305 */       this.rest = parseAnnotations();
/*     */     }
/*     */     
/* 308 */     private Method pre = null; private Method voidPost = null; private Method returningPost = null;
/* 309 */     private Map<Class, Method> voidOnErrorsMap = new HashMap(); private Map<Class, Method> returningOnErrorsMap = new HashMap();
/*     */     
/*     */ 
/*     */ 
/*     */     private void parseAnnotationProxyLocale()
/*     */     {
/* 315 */       if (this.superclass.isAnnotationPresent(ProxyLocale.class)) {
/* 316 */         this.isProxyLocale = true;
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationProxyFor() {
/* 321 */       if (this.superclass.isAnnotationPresent(ProxyFor.class))
/*     */       {
/* 323 */         ProxyFor localProxyFor = (ProxyFor)this.superclass.getAnnotation(ProxyFor.class);
/* 324 */         int i = 1;
/*     */         
/* 326 */         for (Class localClass : localProxyFor.value())
/*     */         {
/* 328 */           if (!localClass.isInterface()) {
/* 329 */             throw AnnotationsRegistry.SyntaxError.access$300(localClass);
/*     */           }
/* 331 */           this.ifacesToProxy.add(localClass);
/* 332 */           i = 0;
/*     */         }
/*     */         
/* 335 */         if (i != 0) throw AnnotationsRegistry.SyntaxError.access$400();
/*     */       }
/*     */       else {
/* 338 */         throw AnnotationsRegistry.SyntaxError.access$500(this.superclass);
/*     */       } }
/*     */     
/* 341 */     private static final Class[] listOfMethodOperators = { Pre.class, Post.class, OnError.class, GetCreator.class, GetDelegate.class, GetProxy.class, SetDelegate.class };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void checkIsSingle(Method paramMethod, Class paramClass)
/*     */     {
/* 349 */       for (Class localClass : listOfMethodOperators) {
/* 350 */         if ((!localClass.equals(paramClass)) && 
/* 351 */           (paramMethod.isAnnotationPresent(localClass)))
/* 352 */           throw AnnotationsRegistry.SyntaxError.access$600();
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationPre(Method paramMethod) {
/* 357 */       if (paramMethod.isAnnotationPresent(Pre.class))
/*     */       {
/* 359 */         checkIsSingle(paramMethod, Pre.class);
/*     */         
/* 361 */         if (!Arrays.deepEquals(new Class[0], paramMethod.getExceptionTypes()))
/*     */         {
/*     */ 
/* 364 */           throw AnnotationsRegistry.SyntaxError.access$700();
/*     */         }
/* 366 */         if (!Arrays.deepEquals(new Class[] { Method.class, Object.class, Object[].class }, paramMethod.getParameterTypes()))
/*     */         {
/*     */ 
/* 369 */           throw AnnotationsRegistry.SyntaxError.access$700();
/*     */         }
/* 371 */         if (!Void.TYPE.equals(paramMethod.getReturnType())) {
/* 372 */           throw AnnotationsRegistry.SyntaxError.access$700();
/*     */         }
/* 374 */         if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 375 */           for (Signature localSignature : ((Methods)paramMethod.getAnnotation(Methods.class)).signatures()) {
/* 376 */             this.pres.put(new MethodSignature(localSignature.name(), localSignature.args(), null), paramMethod);
/*     */           }
/*     */         } else {
/* 379 */           if (null != this.pre) throw AnnotationsRegistry.SyntaxError.access$800();
/* 380 */           this.pre = paramMethod;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private Class doAutoBoxing(Class paramClass)
/*     */     {
/* 387 */       if (Boolean.TYPE.equals(paramClass)) {
/* 388 */         return Boolean.class;
/*     */       }
/* 390 */       if (Character.TYPE.equals(paramClass)) {
/* 391 */         return Character.class;
/*     */       }
/* 393 */       if (Byte.TYPE.equals(paramClass)) {
/* 394 */         return Byte.class;
/*     */       }
/* 396 */       if (Short.TYPE.equals(paramClass)) {
/* 397 */         return Short.class;
/*     */       }
/* 399 */       if (Integer.TYPE.equals(paramClass)) {
/* 400 */         return Integer.class;
/*     */       }
/* 402 */       if (Long.TYPE.equals(paramClass)) {
/* 403 */         return Long.class;
/*     */       }
/* 405 */       if (Float.TYPE.equals(paramClass)) {
/* 406 */         return Float.class;
/*     */       }
/* 408 */       if (Double.TYPE.equals(paramClass)) {
/* 409 */         return Double.class;
/*     */       }
/* 411 */       return paramClass;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void checkReturnTypesMismatch(MethodSignature paramMethodSignature, Method paramMethod)
/*     */     {
/* 424 */       Method localMethod = null;
/*     */       
/* 426 */       Class localClass1 = doAutoBoxing(paramMethod.getReturnType());
/*     */       
/*     */ 
/* 429 */       for (Class localClass2 : getIfacesToProxy()) {
/*     */         try
/*     */         {
/* 432 */           localMethod = localClass2.getDeclaredMethod(paramMethodSignature.getName(), paramMethodSignature.getParameterTypes());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 437 */           Class localClass3 = doAutoBoxing(localMethod.getReturnType());
/*     */           
/*     */ 
/* 440 */           if (!Void.TYPE.equals(localClass3))
/*     */           {
/*     */ 
/* 443 */             localClass1.asSubclass(localClass3);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (NoSuchMethodException localNoSuchMethodException) {}catch (ClassCastException localClassCastException)
/*     */         {
/*     */ 
/* 451 */           throw AnnotationsRegistry.SyntaxError.access$900(paramMethod, localMethod);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void checkReturnTypesMismatch(Method paramMethod)
/*     */     {
/* 466 */       Class localClass1 = doAutoBoxing(paramMethod.getReturnType());
/*     */       
/*     */ 
/* 469 */       for (Class localClass2 : getIfacesToProxy()) {
/* 470 */         for (Method localMethod : localClass2.getDeclaredMethods())
/*     */         {
/* 472 */           Class localClass3 = doAutoBoxing(localMethod.getReturnType());
/*     */           
/*     */ 
/* 475 */           if (!Void.TYPE.equals(localClass3))
/*     */           {
/*     */             try
/*     */             {
/*     */ 
/* 480 */               localClass3.asSubclass(localClass1);
/*     */             }
/*     */             catch (ClassCastException localClassCastException)
/*     */             {
/* 484 */               throw AnnotationsRegistry.SyntaxError.access$900(paramMethod, localMethod);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationPost(Method paramMethod)
/*     */     {
/* 493 */       if (paramMethod.isAnnotationPresent(Post.class))
/*     */       {
/* 495 */         checkIsSingle(paramMethod, Post.class);
/*     */         
/* 497 */         Class localClass = paramMethod.getReturnType();
/* 498 */         Class[] arrayOfClass1 = paramMethod.getParameterTypes();
/* 499 */         Class[] arrayOfClass2 = paramMethod.getExceptionTypes();
/*     */         
/* 501 */         if (!Arrays.deepEquals(new Class[0], arrayOfClass2))
/* 502 */           throw AnnotationsRegistry.SyntaxError.access$1000();
/*     */         Signature localSignature;
/* 504 */         if (Void.TYPE.equals(localClass)) { if (Arrays.deepEquals(new Class[] { Method.class }, arrayOfClass1))
/*     */           {
/*     */ 
/* 507 */             if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 508 */               for (localSignature : ((Methods)paramMethod.getAnnotation(Methods.class)).signatures())
/* 509 */                 this.voidPosts.put(new MethodSignature(localSignature.name(), localSignature.args(), null), paramMethod);
/*     */               return;
/*     */             }
/* 512 */             if (null != this.voidPost) throw AnnotationsRegistry.SyntaxError.access$800();
/* 513 */             this.voidPost = paramMethod; return;
/*     */           }
/*     */         }
/* 516 */         if (!Void.TYPE.equals(localClass)) { if (Arrays.deepEquals(new Class[] { Method.class, localClass }, arrayOfClass1))
/*     */           {
/*     */ 
/* 519 */             if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 520 */               for (localSignature : ((Methods)paramMethod.getAnnotation(Methods.class)).signatures())
/*     */               {
/* 522 */                 MethodSignature localMethodSignature = new MethodSignature(localSignature.name(), localSignature.args(), null);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 528 */                 checkReturnTypesMismatch(localMethodSignature, paramMethod);
/* 529 */                 this.returningPosts.put(localMethodSignature, paramMethod);
/*     */               }
/*     */               return;
/*     */             }
/* 533 */             checkReturnTypesMismatch(paramMethod);
/*     */             
/* 535 */             if (null != this.returningPost) throw AnnotationsRegistry.SyntaxError.access$800();
/* 536 */             this.returningPost = paramMethod; return;
/*     */           }
/*     */         }
/*     */         
/* 540 */         throw AnnotationsRegistry.SyntaxError.access$1000();
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationOnError(Method paramMethod)
/*     */     {
/* 546 */       if (paramMethod.isAnnotationPresent(OnError.class))
/*     */       {
/* 548 */         checkIsSingle(paramMethod, OnError.class);
/*     */         
/* 550 */         Class localClass1 = paramMethod.getReturnType();
/* 551 */         Class[] arrayOfClass1 = paramMethod.getParameterTypes();
/* 552 */         Class[] arrayOfClass2 = paramMethod.getExceptionTypes();
/*     */         
/* 554 */         OnError localOnError = (OnError)paramMethod.getAnnotation(OnError.class);
/* 555 */         Class localClass2 = localOnError.value();
/*     */         Signature localSignature;
/* 557 */         MethodSignature localMethodSignature; Object localObject; if (Arrays.deepEquals(new Class[] { Method.class, localClass2 }, arrayOfClass1)) if ((Arrays.deepEquals(new Class[] { localClass2 }, arrayOfClass2)) && (Void.TYPE.equals(localClass1)))
/*     */           {
/*     */ 
/*     */ 
/* 561 */             if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 562 */               for (localSignature : ((Methods)paramMethod.getAnnotation(Methods.class)).signatures())
/*     */               {
/* 564 */                 localMethodSignature = new MethodSignature(localSignature.name(), localSignature.args(), null);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 570 */                 localObject = (Map)this.voidOnErrors.get(localMethodSignature);
/* 571 */                 if (null == localObject) {
/* 572 */                   this.voidOnErrors.put(localMethodSignature, localObject = new HashMap());
/*     */                 }
/* 574 */                 if (null != ((Map)localObject).put(localClass2, paramMethod))
/* 575 */                   throw AnnotationsRegistry.SyntaxError.access$1100();
/*     */               }
/*     */               return; }
/* 578 */             if (null == this.voidOnErrorsMap.put(localClass2, paramMethod)) return;
/* 579 */             throw AnnotationsRegistry.SyntaxError.access$800();
/*     */           }
/* 581 */         if (Arrays.deepEquals(new Class[] { Method.class, localClass2 }, arrayOfClass1)) { if ((Arrays.deepEquals(new Class[] { localClass2 }, arrayOfClass2)) && (!Void.TYPE.equals(localClass1)))
/*     */           {
/*     */ 
/*     */ 
/* 585 */             if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 586 */               for (localSignature : ((Methods)paramMethod.getAnnotation(Methods.class)).signatures())
/*     */               {
/* 588 */                 localMethodSignature = new MethodSignature(localSignature.name(), localSignature.args(), null);
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 594 */                 checkReturnTypesMismatch(localMethodSignature, paramMethod);
/*     */                 
/* 596 */                 localObject = (Map)this.returningOnErrors.get(localMethodSignature);
/* 597 */                 if (null == localObject) {
/* 598 */                   this.returningOnErrors.put(localMethodSignature, localObject = new HashMap());
/*     */                 }
/* 600 */                 if (null != ((Map)localObject).put(localClass2, paramMethod))
/* 601 */                   throw AnnotationsRegistry.SyntaxError.access$1100();
/*     */               }
/*     */               return;
/*     */             }
/* 605 */             checkReturnTypesMismatch(paramMethod);
/*     */             
/* 607 */             if (null == this.returningOnErrorsMap.put(localClass2, paramMethod)) return;
/* 608 */             throw AnnotationsRegistry.SyntaxError.access$800();
/*     */           }
/*     */         }
/*     */         
/* 612 */         throw AnnotationsRegistry.SyntaxError.access$1200();
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationGetCreator(Method paramMethod)
/*     */     {
/* 618 */       if (paramMethod.isAnnotationPresent(GetCreator.class))
/*     */       {
/* 620 */         checkIsSingle(paramMethod, GetCreator.class);
/*     */         
/* 622 */         if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 623 */           throw AnnotationsRegistry.SyntaxError.access$1300();
/*     */         }
/* 625 */         int i = paramMethod.getModifiers();
/*     */         
/* 627 */         if (!Modifier.isProtected(i)) {
/* 628 */           throw AnnotationsRegistry.SyntaxError.access$1400();
/*     */         }
/* 630 */         if (!Modifier.isAbstract(i)) {
/* 631 */           throw AnnotationsRegistry.SyntaxError.access$1500();
/*     */         }
/* 633 */         if (!Arrays.deepEquals(new Class[0], paramMethod.getParameterTypes())) {
/* 634 */           throw AnnotationsRegistry.SyntaxError.access$1600();
/*     */         }
/* 636 */         if (!Object.class.equals(paramMethod.getReturnType())) {
/* 637 */           throw AnnotationsRegistry.SyntaxError.access$1600();
/*     */         }
/* 639 */         this.methodGetCreator = paramMethod;
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationGetProxy(Method paramMethod)
/*     */     {
/* 645 */       if (paramMethod.isAnnotationPresent(GetProxy.class))
/*     */       {
/* 647 */         checkIsSingle(paramMethod, GetProxy.class);
/*     */         
/* 649 */         if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 650 */           throw AnnotationsRegistry.SyntaxError.access$1300();
/*     */         }
/* 652 */         int i = paramMethod.getModifiers();
/*     */         
/* 654 */         if (!Modifier.isProtected(i)) {
/* 655 */           throw AnnotationsRegistry.SyntaxError.access$1700();
/*     */         }
/* 657 */         if (!Modifier.isAbstract(i)) {
/* 658 */           throw AnnotationsRegistry.SyntaxError.access$1800();
/*     */         }
/* 660 */         if (!Arrays.deepEquals(new Class[] { Object.class, Object.class }, paramMethod.getParameterTypes()))
/*     */         {
/*     */ 
/* 663 */           throw AnnotationsRegistry.SyntaxError.access$1900();
/*     */         }
/* 665 */         if (!Object.class.equals(paramMethod.getReturnType())) {
/* 666 */           throw AnnotationsRegistry.SyntaxError.access$1900();
/*     */         }
/* 668 */         this.methodGetProxy = paramMethod;
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationGetDelegate(Method paramMethod)
/*     */     {
/* 674 */       if (paramMethod.isAnnotationPresent(GetDelegate.class))
/*     */       {
/* 676 */         checkIsSingle(paramMethod, GetDelegate.class);
/*     */         
/* 678 */         if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 679 */           throw AnnotationsRegistry.SyntaxError.access$1300();
/*     */         }
/* 681 */         int i = paramMethod.getModifiers();
/*     */         
/* 683 */         if (!Modifier.isProtected(i)) {
/* 684 */           throw AnnotationsRegistry.SyntaxError.access$2000();
/*     */         }
/* 686 */         if (!Modifier.isAbstract(i)) {
/* 687 */           throw AnnotationsRegistry.SyntaxError.access$2100();
/*     */         }
/* 689 */         if (!Arrays.deepEquals(new Class[0], paramMethod.getParameterTypes())) {
/* 690 */           throw AnnotationsRegistry.SyntaxError.access$2200();
/*     */         }
/* 692 */         if (Void.TYPE.equals(paramMethod.getReturnType())) {
/* 693 */           throw AnnotationsRegistry.SyntaxError.access$2200();
/*     */         }
/* 695 */         this.methodGetDelegate = paramMethod;
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationSetDelegate(Method paramMethod)
/*     */     {
/* 701 */       if (paramMethod.isAnnotationPresent(SetDelegate.class))
/*     */       {
/* 703 */         checkIsSingle(paramMethod, SetDelegate.class);
/*     */         
/* 705 */         if (paramMethod.isAnnotationPresent(Methods.class)) {
/* 706 */           throw AnnotationsRegistry.SyntaxError.access$1300();
/*     */         }
/* 708 */         int i = paramMethod.getModifiers();
/*     */         
/* 710 */         if (!Modifier.isProtected(i)) {
/* 711 */           throw AnnotationsRegistry.SyntaxError.access$2300();
/*     */         }
/* 713 */         if (!Modifier.isAbstract(i)) {
/* 714 */           throw AnnotationsRegistry.SyntaxError.access$2400();
/*     */         }
/* 716 */         if (1 != paramMethod.getParameterTypes().length) {
/* 717 */           throw AnnotationsRegistry.SyntaxError.access$2500();
/*     */         }
/* 719 */         if (!Void.TYPE.equals(paramMethod.getReturnType())) {
/* 720 */           throw AnnotationsRegistry.SyntaxError.access$2500();
/*     */         }
/* 722 */         this.methodSetDelegate = paramMethod;
/*     */       }
/*     */     }
/*     */     
/*     */     private Rest parseAnnotations()
/*     */     {
/* 728 */       parseAnnotationProxyFor();
/* 729 */       parseAnnotationProxyLocale();
/*     */       
/* 731 */       for (Method localMethod : this.superclass.getDeclaredMethods())
/*     */       {
/* 733 */         parseAnnotationPre(localMethod);
/* 734 */         parseAnnotationPost(localMethod);
/* 735 */         parseAnnotationOnError(localMethod);
/* 736 */         parseAnnotationGetCreator(localMethod);
/* 737 */         parseAnnotationGetProxy(localMethod);
/* 738 */         parseAnnotationGetDelegate(localMethod);
/* 739 */         parseAnnotationSetDelegate(localMethod);
/*     */       }
/*     */       
/* 742 */       return new Rest(this.pre, this.voidPost, this.returningPost, this.voidOnErrorsMap, this.returningOnErrorsMap);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     boolean belongsToIfaceToProxy(Class paramClass, MethodSignature paramMethodSignature)
/*     */     {
/* 757 */       for (Class localClass : this.ifacesToProxy) {
/*     */         try
/*     */         {
/* 760 */           paramClass.asSubclass(localClass);
/*     */           
/* 762 */           if (null != localClass.getDeclaredMethod(paramMethodSignature.getName(), paramMethodSignature.getParameterTypes()))
/*     */           {
/*     */ 
/* 765 */             return true;
/*     */           }
/*     */         }
/*     */         catch (NoSuchMethodException localNoSuchMethodException) {}catch (ClassCastException localClassCastException) {}
/*     */       }
/* 770 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodPre(Class paramClass, MethodSignature paramMethodSignature)
/*     */     {
/* 786 */       Method localMethod = (Method)this.pres.get(paramMethodSignature);
/*     */       
/*     */ 
/* 789 */       if (null != localMethod) {
/* 790 */         return localMethod;
/*     */       }
/* 792 */       return belongsToIfaceToProxy(paramClass, paramMethodSignature) ? this.rest.getPre() : null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodVoidPost(Class paramClass, MethodSignature paramMethodSignature)
/*     */     {
/* 810 */       Method localMethod = (Method)this.voidPosts.get(paramMethodSignature);
/*     */       
/*     */ 
/* 813 */       if (null != localMethod) {
/* 814 */         return localMethod;
/*     */       }
/* 816 */       return belongsToIfaceToProxy(paramClass, paramMethodSignature) ? this.rest.getVoidPost() : null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodReturningPost(Class paramClass, MethodSignature paramMethodSignature)
/*     */     {
/* 834 */       Method localMethod = (Method)this.returningPosts.get(paramMethodSignature);
/*     */       
/*     */ 
/* 837 */       if (null != localMethod) {
/* 838 */         return localMethod;
/*     */       }
/* 840 */       return belongsToIfaceToProxy(paramClass, paramMethodSignature) ? this.rest.getReturningPost() : null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Map<Class, Method> getMapVoidOnError(Class paramClass, MethodSignature paramMethodSignature)
/*     */     {
/* 858 */       Map localMap = (Map)this.voidOnErrors.get(paramMethodSignature);
/*     */       
/*     */ 
/* 861 */       if (null != localMap) {
/* 862 */         return localMap;
/*     */       }
/* 864 */       return belongsToIfaceToProxy(paramClass, paramMethodSignature) ? this.rest.getVoidOnError() : null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Map<Class, Method> getMapReturningOnError(Class paramClass, MethodSignature paramMethodSignature)
/*     */     {
/* 882 */       Map localMap = (Map)this.returningOnErrors.get(paramMethodSignature);
/*     */       
/*     */ 
/* 885 */       if (null != localMap) {
/* 886 */         return localMap;
/*     */       }
/* 888 */       return belongsToIfaceToProxy(paramClass, paramMethodSignature) ? this.rest.getReturningOnError() : null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodGetCreator()
/*     */     {
/* 898 */       return this.methodGetCreator;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodGetDelegate()
/*     */     {
/* 906 */       return this.methodGetDelegate;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodGetProxy()
/*     */     {
/* 914 */       return this.methodGetProxy;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Method getMethodSetDelegate()
/*     */     {
/* 922 */       return this.methodSetDelegate;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     List<Class> getIfacesToProxy()
/*     */     {
/* 930 */       return this.ifacesToProxy;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Class getSuperclass()
/*     */     {
/* 938 */       return this.superclass;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     boolean isProxyLocale()
/*     */     {
/* 946 */       return this.isProxyLocale;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\AnnotationsRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */