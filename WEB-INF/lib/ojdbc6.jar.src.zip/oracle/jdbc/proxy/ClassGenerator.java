/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.FieldVisitor;
/*     */ import org.objectweb.asm.Label;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassGenerator
/*     */ {
/*     */   private final AnnotationsForIface annotationsForIface;
/*     */   private final String proxyName;
/*     */   private final String superclassName;
/*     */   private final String ifaceName;
/*     */   private final String proxyType;
/*     */   private final String ifaceType;
/*     */   final Map<MethodSignature, MethodGenerator> members;
/*     */   
/*     */   static class AnnotationsForIface
/*     */   {
/*     */     private final AnnotationsRegistry registry;
/*     */     private final Class iface;
/*     */     private final AnnotationsRegistry.Value value;
/*     */     
/*     */     AnnotationsForIface(AnnotationsRegistry paramAnnotationsRegistry, Class paramClass, AnnotationsRegistry.Value paramValue)
/*     */     {
/*  74 */       this.registry = paramAnnotationsRegistry;
/*  75 */       this.iface = paramClass;
/*  76 */       this.value = paramValue;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     AnnotationsRegistry getRegistry()
/*     */     {
/*  84 */       return this.registry;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Class getIface()
/*     */     {
/*  92 */       return this.iface;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     AnnotationsRegistry.Value getValue()
/*     */     {
/* 100 */       return this.value;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ClassGenerator(AnnotationsForIface paramAnnotationsForIface, String paramString1, String paramString2, String paramString3, Map<MethodSignature, MethodGenerator> paramMap)
/*     */   {
/* 116 */     this.annotationsForIface = paramAnnotationsForIface;
/* 117 */     this.proxyName = Utils.makeSlashed(paramString1);
/* 118 */     this.proxyType = Utils.makeType(paramString1);
/* 119 */     this.superclassName = Utils.makeSlashed(paramString2);
/* 120 */     this.ifaceName = Utils.makeSlashed(paramString3);
/* 121 */     this.ifaceType = Utils.makeType(paramString3);
/* 122 */     this.members = paramMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getProxyName()
/*     */   {
/* 130 */     return this.proxyName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getSuperclassName()
/*     */   {
/* 138 */     return this.superclassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getIfaceName()
/*     */   {
/* 146 */     return this.ifaceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getProxyType()
/*     */   {
/* 154 */     return this.proxyType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getIfaceType()
/*     */   {
/* 162 */     return this.ifaceType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static <T> byte[] generateBytecode(GeneratedProxiesRegistry.Key paramKey, AnnotationsRegistry paramAnnotationsRegistry)
/*     */   {
/* 169 */     Class localClass1 = paramKey.getIface();
/* 170 */     Class localClass2 = paramKey.getSuperclass();
/*     */     
/* 172 */     if (!localClass1.isInterface()) {
/* 173 */       new RuntimeException("iface must be interface");
/*     */     }
/* 175 */     if (localClass2.isInterface()) {
/* 176 */       new RuntimeException("sclass must not be interface");
/*     */     }
/* 178 */     HashMap localHashMap1 = new HashMap();
/*     */     
/*     */ 
/* 181 */     final HashMap localHashMap2 = new HashMap();
/*     */     
/*     */ 
/* 184 */     AnnotationsForIface localAnnotationsForIface = new AnnotationsForIface(paramAnnotationsRegistry, localClass1, paramAnnotationsRegistry.get(localClass1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */     ClassGenerator localClassGenerator = new ClassGenerator(localAnnotationsForIface, paramKey.toString(), localClass2.getName(), localClass1.getName(), localHashMap1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */     new Runnable()
/*     */     {
/* 200 */       public void run() { traverse(this.val$superclass); }
/*     */       
/*     */       void traverse(Class paramAnonymousClass) {
/* 203 */         if (null == paramAnonymousClass) {
/* 204 */           return;
/*     */         }
/* 206 */         for (Method localMethod : paramAnonymousClass.getDeclaredMethods()) {
/* 207 */           localHashMap2.put(new MethodSignature(localMethod), localMethod);
/*     */         }
/* 209 */         traverse(paramAnonymousClass.getSuperclass());
/*     */       }
/*     */     }.run();
/*     */     
/*     */ 
/* 214 */     for (Method localMethod1 : localClass1.getMethods())
/*     */     {
/* 216 */       MethodSignature localMethodSignature = new MethodSignature(localMethod1);
/*     */       
/*     */ 
/* 219 */       Method localMethod2 = (Method)localHashMap2.get(localMethodSignature);
/*     */       
/*     */ 
/* 222 */       localHashMap1.put(localMethodSignature, new MethodGenerator(localClassGenerator, localMethod1, (null == localMethod2) || (Modifier.isAbstract(localMethod2.getModifiers()))));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     ??? = new ClassWriter(3);
/*     */     
/*     */ 
/* 233 */     localClassGenerator.generate((ClassWriter)???);
/* 234 */     return ((ClassWriter)???).toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static <T> Class generate(Class<T> paramClass, Class paramClass1, AnnotationsRegistry paramAnnotationsRegistry)
/*     */   {
/* 242 */     GeneratedProxiesRegistry.Key localKey = new GeneratedProxiesRegistry.Key(paramClass, paramClass1);
/*     */     
/*     */ 
/* 245 */     byte[] arrayOfByte = generateBytecode(localKey, paramAnnotationsRegistry);
/*     */     
/*     */ 
/*     */ 
/* 249 */     String str = System.getProperty("oracle.jdbc.proxy.asm.verify");
/* 250 */     if ((null != str) && (0 == "true".compareToIgnoreCase(str))) {
/*     */       try
/*     */       {
/* 253 */         Class localClass = Class.forName("org.objectweb.asm.util.CheckClassAdapter");
/*     */         
/*     */ 
/* 256 */         Method localMethod = localClass.getMethod("verify", new Class[] { ClassReader.class, Boolean.TYPE, PrintWriter.class });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */         localMethod.invoke(null, new Object[] { new ClassReader(arrayOfByte), Boolean.valueOf(true), new PrintWriter(new OutputStreamWriter(System.out)) });
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException1) {}catch (NoSuchMethodException localNoSuchMethodException) {}catch (IllegalAccessException localIllegalAccessException) {}catch (InvocationTargetException localInvocationTargetException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 279 */       Class.forName(localKey.toString(), false, new ClassLoader()
/*     */       {
/*     */ 
/*     */ 
/*     */         protected Class findClass(String paramAnonymousString)
/*     */         {
/*     */ 
/* 286 */           return defineClass(paramAnonymousString, this.val$bytecode, 0, this.val$bytecode.length);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException2)
/*     */     {
/* 292 */       throw new RuntimeException(localClassNotFoundException2);
/*     */     }
/*     */   }
/*     */   
/*     */   private void generate(ClassWriter paramClassWriter)
/*     */   {
/* 298 */     paramClassWriter.visit(50, 33, this.proxyName, null, this.superclassName, new String[] { this.ifaceName, Utils.makeSlashed(_Proxy_.class.getName()) });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */     for (Object localObject1 = this.members.values().iterator(); ((Iterator)localObject1).hasNext();) { localObject2 = (MethodGenerator)((Iterator)localObject1).next();
/* 308 */       if (null != localObject2) {
/* 309 */         ((MethodGenerator)localObject2).generate(paramClassWriter);
/*     */       }
/*     */     }
/*     */     
/* 313 */     localObject1 = paramClassWriter.visitMethod(1, "_getDelegate_", "()" + this.ifaceType, null, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 321 */     ((MethodVisitor)localObject1).visitCode();
/* 322 */     ((MethodVisitor)localObject1).visitVarInsn(25, 0);
/* 323 */     ((MethodVisitor)localObject1).visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 329 */     ((MethodVisitor)localObject1).visitInsn(176);
/* 330 */     ((MethodVisitor)localObject1).visitMaxs(0, 0);
/* 331 */     ((MethodVisitor)localObject1).visitEnd();
/*     */     
/*     */ 
/* 334 */     localObject1 = paramClassWriter.visitMethod(4161, "_getDelegate_", "()Ljava/lang/Object;", null, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */     ((MethodVisitor)localObject1).visitCode();
/* 343 */     ((MethodVisitor)localObject1).visitVarInsn(25, 0);
/* 344 */     ((MethodVisitor)localObject1).visitMethodInsn(182, this.proxyName, "_getDelegate_", "()" + this.ifaceType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 350 */     ((MethodVisitor)localObject1).visitInsn(176);
/* 351 */     ((MethodVisitor)localObject1).visitMaxs(0, 0);
/* 352 */     ((MethodVisitor)localObject1).visitEnd();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 357 */     localObject1 = this.annotationsForIface.getValue();
/*     */     Object localObject4;
/*     */     Object localObject5;
/* 360 */     Object localObject6; Object localObject7; Object localObject8; if (null != localObject1)
/*     */     {
/*     */ 
/* 363 */       localObject2 = ((AnnotationsRegistry.Value)localObject1).getMethodGetDelegate();
/*     */       
/*     */ 
/* 366 */       if (null != localObject2)
/*     */       {
/* 368 */         localObject3 = paramClassWriter.visitMethod(1, ((Method)localObject2).getName(), "()" + Utils.makeType(((Method)localObject2).getReturnType()), null, null);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 375 */         ((MethodVisitor)localObject3).visitCode();
/* 376 */         localObject4 = new Label();
/* 377 */         ((MethodVisitor)localObject3).visitLabel((Label)localObject4);
/* 378 */         ((MethodVisitor)localObject3).visitVarInsn(25, 0);
/* 379 */         ((MethodVisitor)localObject3).visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/* 380 */         ((MethodVisitor)localObject3).visitInsn(176);
/* 381 */         localObject5 = new Label();
/* 382 */         ((MethodVisitor)localObject3).visitLabel((Label)localObject5);
/* 383 */         ((MethodVisitor)localObject3).visitLocalVariable("this", this.proxyType, null, (Label)localObject4, (Label)localObject5, 0);
/* 384 */         ((MethodVisitor)localObject3).visitMaxs(0, 0);
/* 385 */         ((MethodVisitor)localObject3).visitEnd();
/*     */       }
/*     */       
/*     */ 
/* 389 */       localObject3 = ((AnnotationsRegistry.Value)localObject1).getMethodSetDelegate();
/*     */       
/*     */ 
/* 392 */       if (null != localObject3)
/*     */       {
/* 394 */         localObject4 = ((Method)localObject3).getParameterTypes();
/*     */         
/* 396 */         if (1 != localObject4.length) {
/* 397 */           throw new RuntimeException("wrong delegate setter signature");
/*     */         }
/* 399 */         localObject5 = paramClassWriter.visitMethod(1, ((Method)localObject3).getName(), "(" + Utils.makeType(localObject4[0]) + ")V", null, null);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 407 */         ((MethodVisitor)localObject5).visitCode();
/*     */         
/* 409 */         ((MethodVisitor)localObject5).visitLabel(localObject6 = new Label());
/*     */         
/* 411 */         ((MethodVisitor)localObject5).visitVarInsn(25, 0);
/*     */         
/* 413 */         ((MethodVisitor)localObject5).visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 419 */         ((MethodVisitor)localObject5).visitVarInsn(25, 0);
/* 420 */         ((MethodVisitor)localObject5).visitVarInsn(25, 0);
/*     */         
/* 422 */         ((MethodVisitor)localObject5).visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 428 */         ((MethodVisitor)localObject5).visitVarInsn(25, 1);
/*     */         
/* 430 */         ((MethodVisitor)localObject5).visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class), "updateDelegate", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 436 */         ((MethodVisitor)localObject5).visitVarInsn(25, 0);
/* 437 */         ((MethodVisitor)localObject5).visitVarInsn(25, 1);
/*     */         
/* 439 */         ((MethodVisitor)localObject5).visitFieldInsn(181, this.proxyName, "delegate", this.ifaceType);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 445 */         ((MethodVisitor)localObject5).visitInsn(177);
/*     */         
/* 447 */         ((MethodVisitor)localObject5).visitLabel(localObject7 = new Label());
/*     */         
/* 449 */         ((MethodVisitor)localObject5).visitLocalVariable("this", this.proxyType, null, (Label)localObject6, (Label)localObject7, 0);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 457 */         ((MethodVisitor)localObject5).visitLocalVariable("delegate", this.ifaceType, null, (Label)localObject6, (Label)localObject7, 1);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 465 */         ((MethodVisitor)localObject5).visitMaxs(0, 0);
/* 466 */         ((MethodVisitor)localObject5).visitEnd();
/*     */       }
/*     */       
/*     */ 
/* 470 */       localObject4 = ((AnnotationsRegistry.Value)localObject1).getMethodGetCreator();
/*     */       
/*     */ 
/* 473 */       if (null != localObject4)
/*     */       {
/* 475 */         localObject5 = paramClassWriter.visitMethod(1, ((Method)localObject4).getName(), "()" + Utils.makeType(((Method)localObject4).getReturnType()), null, null);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 483 */         ((MethodVisitor)localObject5).visitCode();
/* 484 */         localObject6 = new Label();
/* 485 */         ((MethodVisitor)localObject5).visitLabel((Label)localObject6);
/* 486 */         ((MethodVisitor)localObject5).visitVarInsn(25, 0);
/* 487 */         ((MethodVisitor)localObject5).visitFieldInsn(180, this.proxyName, "creator", "Ljava/lang/Object;");
/* 488 */         ((MethodVisitor)localObject5).visitInsn(176);
/* 489 */         localObject7 = new Label();
/* 490 */         ((MethodVisitor)localObject5).visitLabel((Label)localObject7);
/* 491 */         ((MethodVisitor)localObject5).visitLocalVariable("this", this.proxyType, null, (Label)localObject6, (Label)localObject7, 0);
/* 492 */         ((MethodVisitor)localObject5).visitMaxs(1, 1);
/* 493 */         ((MethodVisitor)localObject5).visitEnd();
/*     */       }
/*     */       
/*     */ 
/* 497 */       localObject5 = ((AnnotationsRegistry.Value)localObject1).getMethodGetProxy();
/*     */       
/*     */ 
/* 500 */       if (null != localObject5)
/*     */       {
/* 502 */         localObject6 = ((Method)localObject5).getParameterTypes();
/*     */         
/*     */ 
/* 505 */         localObject7 = ((Method)localObject5).getReturnType();
/*     */         
/*     */ 
/* 508 */         if ((!Arrays.deepEquals(new Class[] { Object.class, Object.class }, (Object[])localObject6)) || (!Object.class.equals(localObject7)))
/*     */         {
/* 510 */           throw new RuntimeException("internal error: wrong @GetProxy method");
/*     */         }
/* 512 */         localObject8 = paramClassWriter.visitMethod(1, ((Method)localObject5).getName(), "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<T:Ljava/lang/Object;>(TT;Ljava/lang/Object;)TT;", null);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 520 */         ((MethodVisitor)localObject8).visitCode();
/* 521 */         ((MethodVisitor)localObject8).visitVarInsn(25, 0);
/*     */         
/* 523 */         ((MethodVisitor)localObject8).visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 529 */         ((MethodVisitor)localObject8).visitVarInsn(25, 1);
/* 530 */         ((MethodVisitor)localObject8).visitVarInsn(25, 2);
/*     */         
/* 532 */         ((MethodVisitor)localObject8).visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class), "proxyFor", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 538 */         ((MethodVisitor)localObject8).visitInsn(176);
/* 539 */         ((MethodVisitor)localObject8).visitMaxs(3, 3);
/* 540 */         ((MethodVisitor)localObject8).visitEnd();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 546 */     paramClassWriter.visitField(2, "delegate", this.ifaceType, null, null).visitEnd();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 554 */     paramClassWriter.visitField(18, "creator", "Ljava/lang/Object;", null, null).visitEnd();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 562 */     paramClassWriter.visitField(18, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()), null, null).visitEnd();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 570 */     paramClassWriter.visitField(18, "proxyCache", "Ljava/util/Map;", "Ljava/util/Map<Ljava/lang/Object;Ljava/lang/Object;>;", null).visitEnd();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 578 */     int i = 0;
/* 579 */     for (Object localObject2 = this.members.values().iterator(); ((Iterator)localObject2).hasNext();) { localObject3 = (MethodGenerator)((Iterator)localObject2).next();
/*     */       
/* 581 */       paramClassWriter.visitField(10, ((MethodGenerator)localObject3).getMethodObject(), "Ljava/lang/reflect/Method;", null, null).visitEnd();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 588 */       i = 1;
/*     */     }
/*     */     
/*     */ 
/* 592 */     if (i != 0)
/*     */     {
/* 594 */       localObject2 = paramClassWriter.visitMethod(8, "<clinit>", "()V", null, null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 602 */       ((MethodVisitor)localObject2).visitCode();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 609 */       ((MethodVisitor)localObject2).visitTryCatchBlock(localObject3 = new Label(), localObject4 = new Label(), localObject5 = new Label(), "java/lang/Throwable");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 615 */       ((MethodVisitor)localObject2).visitLabel((Label)localObject3);
/*     */       
/* 617 */       for (localObject7 = this.members.values().iterator(); ((Iterator)localObject7).hasNext();) { localObject8 = (MethodGenerator)((Iterator)localObject7).next();
/* 618 */         ((MethodGenerator)localObject8).initializeMethodObject((MethodVisitor)localObject2);
/*     */       }
/* 620 */       ((MethodVisitor)localObject2).visitLabel((Label)localObject4);
/* 621 */       ((MethodVisitor)localObject2).visitJumpInsn(167, localObject6 = new Label());
/* 622 */       ((MethodVisitor)localObject2).visitLabel((Label)localObject5);
/*     */       
/* 624 */       ((MethodVisitor)localObject2).visitFrame(4, 0, null, 1, new Object[] { "java/lang/Throwable" });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 631 */       ((MethodVisitor)localObject2).visitVarInsn(58, 0);
/*     */       
/* 633 */       ((MethodVisitor)localObject2).visitTypeInsn(187, "java/lang/RuntimeException");
/* 634 */       ((MethodVisitor)localObject2).visitInsn(89);
/* 635 */       ((MethodVisitor)localObject2).visitVarInsn(25, 0);
/*     */       
/* 637 */       ((MethodVisitor)localObject2).visitMethodInsn(183, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 643 */       ((MethodVisitor)localObject2).visitInsn(191);
/*     */       
/* 645 */       ((MethodVisitor)localObject2).visitLabel((Label)localObject6);
/* 646 */       ((MethodVisitor)localObject2).visitFrame(3, 0, null, 0, null);
/* 647 */       ((MethodVisitor)localObject2).visitInsn(177);
/* 648 */       ((MethodVisitor)localObject2).visitMaxs(0, 0);
/* 649 */       ((MethodVisitor)localObject2).visitEnd();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 654 */     localObject2 = "(" + this.ifaceType + "Ljava/lang/Object;" + Utils.makeType(ProxyFactory.class.getName()) + "Ljava/util/Map;" + ")V";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 662 */     Object localObject3 = paramClassWriter.visitMethod(1, "<init>", (String)localObject2, null, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 670 */     ((MethodVisitor)localObject3).visitCode();
/* 671 */     ((MethodVisitor)localObject3).visitVarInsn(25, 0);
/*     */     
/* 673 */     ((MethodVisitor)localObject3).visitMethodInsn(183, this.superclassName, "<init>", "()V");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 679 */     ((MethodVisitor)localObject3).visitVarInsn(25, 0);
/* 680 */     ((MethodVisitor)localObject3).visitVarInsn(25, 1);
/*     */     
/* 682 */     ((MethodVisitor)localObject3).visitFieldInsn(181, this.proxyName, "delegate", this.ifaceType);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 688 */     ((MethodVisitor)localObject3).visitVarInsn(25, 0);
/* 689 */     ((MethodVisitor)localObject3).visitVarInsn(25, 2);
/*     */     
/* 691 */     ((MethodVisitor)localObject3).visitFieldInsn(181, this.proxyName, "creator", "Ljava/lang/Object;");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 697 */     ((MethodVisitor)localObject3).visitVarInsn(25, 0);
/* 698 */     ((MethodVisitor)localObject3).visitVarInsn(25, 3);
/*     */     
/* 700 */     ((MethodVisitor)localObject3).visitFieldInsn(181, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 706 */     ((MethodVisitor)localObject3).visitVarInsn(25, 0);
/* 707 */     ((MethodVisitor)localObject3).visitVarInsn(25, 4);
/*     */     
/* 709 */     ((MethodVisitor)localObject3).visitFieldInsn(181, this.proxyName, "proxyCache", "Ljava/util/Map;");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 715 */     ((MethodVisitor)localObject3).visitInsn(177);
/* 716 */     ((MethodVisitor)localObject3).visitMaxs(0, 0);
/* 717 */     ((MethodVisitor)localObject3).visitEnd();
/*     */     
/*     */ 
/* 720 */     paramClassWriter.visitEnd();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   AnnotationsForIface getAnnotationsForIface()
/*     */   {
/* 728 */     return this.annotationsForIface;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\ClassGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */