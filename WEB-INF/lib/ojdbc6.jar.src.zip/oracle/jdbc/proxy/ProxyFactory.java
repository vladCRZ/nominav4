/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyFactory
/*     */ {
/*  32 */   final AnnotationsRegistry annotationsRegistry = new AnnotationsRegistry();
/*  33 */   private final GeneratedProxiesRegistry generatedRegistry = new GeneratedProxiesRegistry();
/*  34 */   private Map<Class, Class> delegateClassToProxyClass = Collections.synchronizedMap(new HashMap());
/*  35 */   private final Map<Object, WeakReference<Object>> delegateToProxy = Collections.synchronizedMap(new WeakIdentityHashMap());
/*  36 */   private Map<Class, Class> delegateToMostSuitableIface = new HashMap();
/*     */   
/*  38 */   private static Object STALE_DELEGATE = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ProxyFactory createProxyFactory(Class... paramVarArgs)
/*     */   {
/*  49 */     ProxyFactory localProxyFactory = new ProxyFactory();
/*  50 */     localProxyFactory.annotationsRegistry.register(paramVarArgs);
/*  51 */     return localProxyFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ProxyFactory createJDBCProxyFactory(Class... paramVarArgs)
/*     */   {
/*  65 */     ProxyFactory localProxyFactory = new ProxyFactory();
/*  66 */     localProxyFactory.annotationsRegistry.register(new Class[] { NullProxy.class });
/*  67 */     localProxyFactory.annotationsRegistry.register(paramVarArgs);
/*  68 */     return localProxyFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isProxied(Class paramClass)
/*     */   {
/*  78 */     return this.annotationsRegistry.containsKey(paramClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final <T> T proxyFor(T paramT)
/*     */   {
/*  90 */     return (T)proxyFor(paramT, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final <T> T proxyFor(T paramT, Object paramObject)
/*     */   {
/* 104 */     return (T)proxyFor(paramT, paramObject, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final <T> T proxyFor(T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap, Method paramMethod)
/*     */   {
/* 137 */     if (null == paramT) {
/* 138 */       return null;
/*     */     }
/* 140 */     Class localClass1 = paramT.getClass();
/* 141 */     Class localClass2 = findMostSuitableIface(localClass1);
/*     */     
/*     */ 
/* 144 */     if ((null != paramMethod) && (null != localClass2) && 
/* 145 */       (!paramMethod.getReturnType().isAssignableFrom(localClass2))) {
/* 146 */       return paramT;
/*     */     }
/* 148 */     AnnotationsRegistry.Value localValue = this.annotationsRegistry.get(localClass2);
/* 149 */     if (null == localValue) {
/* 150 */       return paramT;
/*     */     }
/* 152 */     if (null == paramMap) {
/* 153 */       paramMap = localValue.isProxyLocale() ? new WeakIdentityHashMap() : this.delegateToProxy;
/*     */     }
/*     */     
/*     */ 
/* 157 */     WeakReference localWeakReference = (WeakReference)paramMap.get(paramT);
/* 158 */     if (null != localWeakReference)
/*     */     {
/* 160 */       localObject1 = localWeakReference.get();
/* 161 */       if (null != localObject1)
/*     */       {
/* 163 */         if (STALE_DELEGATE == localObject1) {
/* 164 */           throw new RuntimeException("stale delegate");
/*     */         }
/* 166 */         return (T)localObject1;
/*     */       }
/*     */     }
/*     */     
/* 170 */     Object localObject1 = getProxyClass(localClass2, localClass1);
/* 171 */     Object localObject2; if (null == localObject1)
/*     */     {
/* 173 */       localObject2 = createProxy(localClass2, paramT, paramObject, paramMap);
/* 174 */       paramMap.put(paramT, new WeakReference(localObject2));
/* 175 */       return (T)localObject2;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 180 */       localObject2 = ((Class)localObject1).getConstructor(new Class[] { localClass2, Object.class, ProxyFactory.class, Map.class }).newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */       paramMap.put(paramT, new WeakReference(localObject2));
/* 188 */       return (T)localObject2;
/*     */     }
/*     */     catch (NoSuchMethodException localNoSuchMethodException)
/*     */     {
/* 192 */       throw new RuntimeException(localNoSuchMethodException);
/*     */     }
/*     */     catch (IllegalAccessException localIllegalAccessException)
/*     */     {
/* 196 */       throw new RuntimeException(localIllegalAccessException);
/*     */     }
/*     */     catch (InvocationTargetException localInvocationTargetException)
/*     */     {
/* 200 */       throw new RuntimeException(localInvocationTargetException);
/*     */     }
/*     */     catch (InstantiationException localInstantiationException)
/*     */     {
/* 204 */       throw new RuntimeException(localInstantiationException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void updateDelegate(Object paramObject, T paramT1, T paramT2)
/*     */   {
/* 227 */     this.delegateToProxy.put(paramT1, new WeakReference(STALE_DELEGATE));
/* 228 */     this.delegateToProxy.put(paramT2, new WeakReference(paramObject));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> T createProxy(Class paramClass, T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap)
/*     */   {
/* 244 */     if (null == paramClass) {
/* 245 */       return paramT;
/*     */     }
/* 247 */     AnnotationsRegistry.Value localValue = this.annotationsRegistry.get(paramClass);
/*     */     
/* 249 */     Class localClass = localValue.getSuperclass();
/*     */     
/* 251 */     GeneratedProxiesRegistry.Value localValue1 = this.generatedRegistry.get(paramClass, localClass);
/*     */     
/*     */ 
/* 254 */     Constructor localConstructor = null == localValue1 ? prepareProxy(paramClass, localClass) : localValue1.getConstructor();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 261 */       return (T)localConstructor.newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */     }
/*     */     catch (InvocationTargetException localInvocationTargetException)
/*     */     {
/* 265 */       throw new RuntimeException(localInvocationTargetException.getTargetException());
/*     */     }
/*     */     catch (IllegalAccessException localIllegalAccessException)
/*     */     {
/* 269 */       throw new RuntimeException(localIllegalAccessException);
/*     */     }
/*     */     catch (InstantiationException localInstantiationException)
/*     */     {
/* 273 */       throw new RuntimeException(localInstantiationException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Constructor prepareProxy(Class paramClass1, Class paramClass2)
/*     */   {
/* 281 */     Class localClass = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 286 */       localClass = Class.forName(new GeneratedProxiesRegistry.Key(paramClass1, paramClass2).toString());
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException)
/*     */     {
/*     */ 
/* 292 */       localClass = ClassGenerator.generate(paramClass1, paramClass2, this.annotationsRegistry);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Constructor localConstructor;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 302 */       localConstructor = localClass.getConstructor(new Class[] { paramClass1, Object.class, ProxyFactory.class, Map.class });
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException localNoSuchMethodException)
/*     */     {
/*     */ 
/*     */ 
/* 310 */       throw new RuntimeException(localNoSuchMethodException);
/*     */     }
/*     */     
/* 313 */     this.generatedRegistry.put(paramClass1, paramClass2, new GeneratedProxiesRegistry.Value(null, null, localClass, localConstructor));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 320 */     return localConstructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Class getProxyClass(Class paramClass1, Class paramClass2)
/*     */   {
/* 327 */     if (null == paramClass2) {
/* 328 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 332 */     if (this.delegateClassToProxyClass.containsKey(paramClass2)) {
/* 333 */       return (Class)this.delegateClassToProxyClass.get(paramClass2);
/*     */     }
/*     */     
/* 336 */     if (null == paramClass1) {
/* 337 */       return null;
/*     */     }
/* 339 */     GeneratedProxiesRegistry.Value localValue = this.generatedRegistry.get(paramClass1, this.annotationsRegistry.get(paramClass1).getSuperclass());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 344 */     if (null == localValue) {
/* 345 */       return null;
/*     */     }
/* 347 */     Class localClass = localValue.getClazz();
/*     */     
/*     */ 
/* 350 */     synchronized (this)
/*     */     {
/*     */ 
/*     */ 
/* 354 */       HashMap localHashMap = new HashMap(this.delegateClassToProxyClass);
/* 355 */       localHashMap.put(paramClass2, localClass);
/* 356 */       this.delegateClassToProxyClass = localHashMap;
/*     */     }
/*     */     
/* 359 */     return localClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class findMostSuitableIface(Class paramClass)
/*     */   {
/* 371 */     if (null == paramClass) {
/* 372 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 377 */     if (this.delegateToMostSuitableIface.containsKey(paramClass)) {
/* 378 */       return (Class)this.delegateToMostSuitableIface.get(paramClass);
/*     */     }
/*     */     
/* 381 */     int i = -1;
/* 382 */     Object localObject1 = null;
/* 383 */     for (Iterator localIterator = this.annotationsRegistry.keySet().iterator(); localIterator.hasNext();) { localObject2 = (Class)localIterator.next();
/*     */       
/* 385 */       int j = intersectionCardinality(paramClass, (Class)localObject2);
/* 386 */       if ((j >= 1) && 
/*     */       
/* 388 */         (j > i))
/*     */       {
/*     */ 
/*     */ 
/* 392 */         i = j;
/* 393 */         localObject1 = localObject2;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 398 */     synchronized (this)
/*     */     {
/*     */ 
/*     */ 
/* 402 */       Object localObject2 = new HashMap(this.delegateToMostSuitableIface);
/* 403 */       ((Map)localObject2).put(paramClass, localObject1);
/* 404 */       this.delegateToMostSuitableIface = ((Map)localObject2);
/*     */     }
/*     */     
/* 407 */     return (Class)localObject1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int intersectionCardinality(Class paramClass1, Class paramClass2)
/*     */   {
/* 414 */     HashSet localHashSet1 = new HashSet();
/*     */     
/*     */ 
/* 417 */     collectIfaces(paramClass2, localHashSet1);
/*     */     
/* 419 */     HashSet localHashSet2 = new HashSet();
/*     */     
/*     */ 
/* 422 */     collectIfaces(paramClass1, localHashSet2);
/*     */     
/* 424 */     int i = localHashSet1.size();
/* 425 */     localHashSet1.removeAll(localHashSet2);
/*     */     
/* 427 */     if (localHashSet1.size() > 0) {
/* 428 */       return -1;
/*     */     }
/* 430 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void collectIfaces(Class paramClass, Set<Class> paramSet)
/*     */   {
/* 437 */     if (paramClass.isInterface()) {
/* 438 */       paramSet.add(paramClass);
/*     */     }
/* 440 */     for (Class localClass : paramClass.getInterfaces()) {
/* 441 */       collectIfaces(localClass, paramSet);
/*     */     }
/* 443 */     ??? = paramClass.getSuperclass();
/* 444 */     if (null != ???) {
/* 445 */       collectIfaces((Class)???, paramSet);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\ProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */