package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy
  extends NonTxnReplayableArray
  implements Array, _Proxy_
{
  private Array delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject22257;
  private static Method methodObject22254;
  private static Method methodObject22255;
  private static Method methodObject22261;
  private static Method methodObject22252;
  private static Method methodObject22259;
  private static Method methodObject22260;
  private static Method methodObject22251;
  private static Method methodObject22253;
  private static Method methodObject22256;
  private static Method methodObject22258;
  
  public String getBaseTypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22257, this, new Object[0]);
      return (String)postForAll(methodObject22257, this.proxyFactory.proxyFor((Object)this.delegate.getBaseTypeName(), this, this.proxyCache, methodObject22257));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject22257, onErrorForAll(methodObject22257, e));
    }
  }
  
  public Object getArray(long arg0, int arg1, Map arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22254, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject22254, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1, arg2), this, this.proxyCache, methodObject22254));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22254, onErrorForAll(methodObject22254, e));
    }
  }
  
  public void free()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22255, this, new Object[0]);
      this.delegate.free();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22255, e);
    }
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22261, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject22261, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0, arg1, arg2), this, this.proxyCache, methodObject22261));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22261, onErrorForAll(methodObject22261, e));
    }
  }
  
  public Object getArray(Map arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22252, this, new Object[] { arg0 });
      return postForAll(methodObject22252, this.proxyFactory.proxyFor(this.delegate.getArray(arg0), this, this.proxyCache, methodObject22252));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22252, onErrorForAll(methodObject22252, e));
    }
  }
  
  public ResultSet getResultSet(Map arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22259, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject22259, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0), this, this.proxyCache, methodObject22259));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22259, onErrorForAll(methodObject22259, e));
    }
  }
  
  public ResultSet getResultSet(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22260, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject22260, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0, arg1), this, this.proxyCache, methodObject22260));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22260, onErrorForAll(methodObject22260, e));
    }
  }
  
  public Object getArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22251, this, new Object[0]);
      return postForAll(methodObject22251, this.proxyFactory.proxyFor(this.delegate.getArray(), this, this.proxyCache, methodObject22251));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22251, onErrorForAll(methodObject22251, e));
    }
  }
  
  public Object getArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22253, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject22253, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1), this, this.proxyCache, methodObject22253));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22253, onErrorForAll(methodObject22253, e));
    }
  }
  
  public int getBaseType()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22256, this, new Object[0]);
      return ((Integer)postForAll(methodObject22256, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, this.proxyCache, methodObject22256))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject22256, onErrorForAll(methodObject22256, e))).intValue();
    }
  }
  
  public ResultSet getResultSet()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22258, this, new Object[0]);
      return (ResultSet)postForAll(methodObject22258, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(), this, this.proxyCache, methodObject22258));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22258, onErrorForAll(methodObject22258, e));
    }
  }
  
  public Array _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject22257 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject22254 = Array.class.getDeclaredMethod("getArray", new Class[] { Long.TYPE, Integer.TYPE, Map.class });
      methodObject22255 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject22261 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Long.TYPE, Integer.TYPE, Map.class });
      methodObject22252 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject22259 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject22260 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22251 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject22253 = Array.class.getDeclaredMethod("getArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22256 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject22258 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy(Array paramArray, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */