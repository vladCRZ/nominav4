package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy
  extends NonTxnReplayableArray
  implements OracleArray, _Proxy_
{
  private OracleArray delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject22279;
  private static Method methodObject22262;
  private static Method methodObject22286;
  private static Method methodObject22276;
  private static Method methodObject22274;
  private static Method methodObject22267;
  private static Method methodObject22277;
  private static Method methodObject22263;
  private static Method methodObject22275;
  private static Method methodObject22266;
  private static Method methodObject22281;
  private static Method methodObject22268;
  private static Method methodObject22264;
  private static Method methodObject22282;
  private static Method methodObject22269;
  private static Method methodObject22280;
  private static Method methodObject22272;
  private static Method methodObject22285;
  private static Method methodObject22270;
  private static Method methodObject22265;
  private static Method methodObject22271;
  private static Method methodObject22284;
  private static Method methodObject22273;
  private static Method methodObject22278;
  private static Method methodObject22283;
  
  public Object getArray(long arg0, int arg1, Map arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22279, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject22279, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1, arg2), this, this.proxyCache, methodObject22279));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22279, onErrorForAll(methodObject22279, e));
    }
  }
  
  public int length()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22262, this, new Object[0]);
      return ((Integer)postForAll(methodObject22262, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.length()), this, this.proxyCache, methodObject22262))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject22262, onErrorForAll(methodObject22262, e))).intValue();
    }
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22286, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject22286, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0, arg1, arg2), this, this.proxyCache, methodObject22286));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22286, onErrorForAll(methodObject22286, e));
    }
  }
  
  public Object getArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22276, this, new Object[0]);
      return postForAll(methodObject22276, this.proxyFactory.proxyFor(this.delegate.getArray(), this, this.proxyCache, methodObject22276));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22276, onErrorForAll(methodObject22276, e));
    }
  }
  
  public float[] getFloatArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22274, this, new Object[0]);
      return (float[])postForAll(methodObject22274, this.proxyFactory.proxyFor((Object)this.delegate.getFloatArray(), this, this.proxyCache, methodObject22274));
    }
    catch (SQLException e)
    {
      return (float[])postForAll(methodObject22274, onErrorForAll(methodObject22274, e));
    }
  }
  
  public int[] getIntArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22267, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (int[])postForAll(methodObject22267, this.proxyFactory.proxyFor((Object)this.delegate.getIntArray(arg0, arg1), this, this.proxyCache, methodObject22267));
    }
    catch (SQLException e)
    {
      return (int[])postForAll(methodObject22267, onErrorForAll(methodObject22267, e));
    }
  }
  
  public Object getArray(Map arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22277, this, new Object[] { arg0 });
      return postForAll(methodObject22277, this.proxyFactory.proxyFor(this.delegate.getArray(arg0), this, this.proxyCache, methodObject22277));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22277, onErrorForAll(methodObject22277, e));
    }
  }
  
  public String getSQLTypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22263, this, new Object[0]);
      return (String)postForAll(methodObject22263, this.proxyFactory.proxyFor((Object)this.delegate.getSQLTypeName(), this, this.proxyCache, methodObject22263));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject22263, onErrorForAll(methodObject22263, e));
    }
  }
  
  public float[] getFloatArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22275, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (float[])postForAll(methodObject22275, this.proxyFactory.proxyFor((Object)this.delegate.getFloatArray(arg0, arg1), this, this.proxyCache, methodObject22275));
    }
    catch (SQLException e)
    {
      return (float[])postForAll(methodObject22275, onErrorForAll(methodObject22275, e));
    }
  }
  
  public int[] getIntArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22266, this, new Object[0]);
      return (int[])postForAll(methodObject22266, this.proxyFactory.proxyFor((Object)this.delegate.getIntArray(), this, this.proxyCache, methodObject22266));
    }
    catch (SQLException e)
    {
      return (int[])postForAll(methodObject22266, onErrorForAll(methodObject22266, e));
    }
  }
  
  public int getBaseType()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22281, this, new Object[0]);
      return ((Integer)postForAll(methodObject22281, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, this.proxyCache, methodObject22281))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject22281, onErrorForAll(methodObject22281, e))).intValue();
    }
  }
  
  public double[] getDoubleArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22268, this, new Object[0]);
      return (double[])postForAll(methodObject22268, this.proxyFactory.proxyFor((Object)this.delegate.getDoubleArray(), this, this.proxyCache, methodObject22268));
    }
    catch (SQLException e)
    {
      return (double[])postForAll(methodObject22268, onErrorForAll(methodObject22268, e));
    }
  }
  
  public Object toJdbc()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22264, this, new Object[0]);
      return postForAll(methodObject22264, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, this.proxyCache, methodObject22264));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22264, onErrorForAll(methodObject22264, e));
    }
  }
  
  public String getBaseTypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22282, this, new Object[0]);
      return (String)postForAll(methodObject22282, this.proxyFactory.proxyFor((Object)this.delegate.getBaseTypeName(), this, this.proxyCache, methodObject22282));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject22282, onErrorForAll(methodObject22282, e));
    }
  }
  
  public double[] getDoubleArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22269, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (double[])postForAll(methodObject22269, this.proxyFactory.proxyFor((Object)this.delegate.getDoubleArray(arg0, arg1), this, this.proxyCache, methodObject22269));
    }
    catch (SQLException e)
    {
      return (double[])postForAll(methodObject22269, onErrorForAll(methodObject22269, e));
    }
  }
  
  public void free()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22280, this, new Object[0]);
      this.delegate.free();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22280, e);
    }
  }
  
  public long[] getLongArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22272, this, new Object[0]);
      return (long[])postForAll(methodObject22272, this.proxyFactory.proxyFor((Object)this.delegate.getLongArray(), this, this.proxyCache, methodObject22272));
    }
    catch (SQLException e)
    {
      return (long[])postForAll(methodObject22272, onErrorForAll(methodObject22272, e));
    }
  }
  
  public ResultSet getResultSet(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22285, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject22285, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0, arg1), this, this.proxyCache, methodObject22285));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22285, onErrorForAll(methodObject22285, e));
    }
  }
  
  public short[] getShortArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22270, this, new Object[0]);
      return (short[])postForAll(methodObject22270, this.proxyFactory.proxyFor((Object)this.delegate.getShortArray(), this, this.proxyCache, methodObject22270));
    }
    catch (SQLException e)
    {
      return (short[])postForAll(methodObject22270, onErrorForAll(methodObject22270, e));
    }
  }
  
  public OracleTypeMetaData getOracleMetaData()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22265, this, new Object[0]);
      return (OracleTypeMetaData)postForAll(methodObject22265, this.proxyFactory.proxyFor((Object)this.delegate.getOracleMetaData(), this, this.proxyCache, methodObject22265));
    }
    catch (SQLException e)
    {
      return (OracleTypeMetaData)postForAll(methodObject22265, onErrorForAll(methodObject22265, e));
    }
  }
  
  public short[] getShortArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22271, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (short[])postForAll(methodObject22271, this.proxyFactory.proxyFor((Object)this.delegate.getShortArray(arg0, arg1), this, this.proxyCache, methodObject22271));
    }
    catch (SQLException e)
    {
      return (short[])postForAll(methodObject22271, onErrorForAll(methodObject22271, e));
    }
  }
  
  public ResultSet getResultSet(Map arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22284, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject22284, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0), this, this.proxyCache, methodObject22284));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22284, onErrorForAll(methodObject22284, e));
    }
  }
  
  public long[] getLongArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22273, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (long[])postForAll(methodObject22273, this.proxyFactory.proxyFor((Object)this.delegate.getLongArray(arg0, arg1), this, this.proxyCache, methodObject22273));
    }
    catch (SQLException e)
    {
      return (long[])postForAll(methodObject22273, onErrorForAll(methodObject22273, e));
    }
  }
  
  public Object getArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22278, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject22278, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1), this, this.proxyCache, methodObject22278));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22278, onErrorForAll(methodObject22278, e));
    }
  }
  
  public ResultSet getResultSet()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22283, this, new Object[0]);
      return (ResultSet)postForAll(methodObject22283, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(), this, this.proxyCache, methodObject22283));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22283, onErrorForAll(methodObject22283, e));
    }
  }
  
  public OracleArray _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject22279 = Array.class.getDeclaredMethod("getArray", new Class[] { Long.TYPE, Integer.TYPE, Map.class });
      methodObject22262 = OracleArray.class.getDeclaredMethod("length", new Class[0]);
      methodObject22286 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Long.TYPE, Integer.TYPE, Map.class });
      methodObject22276 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject22274 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[0]);
      methodObject22267 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22277 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject22263 = OracleArray.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject22275 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22266 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[0]);
      methodObject22281 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject22268 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[0]);
      methodObject22264 = OracleArray.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject22282 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject22269 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22280 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject22272 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[0]);
      methodObject22285 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22270 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[0]);
      methodObject22265 = OracleArray.class.getDeclaredMethod("getOracleMetaData", new Class[0]);
      methodObject22271 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22284 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject22273 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22278 = Array.class.getDeclaredMethod("getArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22283 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy(OracleArray paramOracleArray, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */