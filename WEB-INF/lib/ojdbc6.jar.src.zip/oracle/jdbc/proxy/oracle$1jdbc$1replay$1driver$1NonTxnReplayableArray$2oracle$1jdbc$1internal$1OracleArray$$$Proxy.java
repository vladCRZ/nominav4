package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy
  extends NonTxnReplayableArray
  implements oracle.jdbc.internal.OracleArray, _Proxy_
{
  private oracle.jdbc.internal.OracleArray delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject22364;
  private static Method methodObject22303;
  private static Method methodObject22315;
  private static Method methodObject22304;
  private static Method methodObject22289;
  private static Method methodObject22317;
  private static Method methodObject22343;
  private static Method methodObject22359;
  private static Method methodObject22298;
  private static Method methodObject22316;
  private static Method methodObject22320;
  private static Method methodObject22329;
  private static Method methodObject22311;
  private static Method methodObject22348;
  private static Method methodObject22351;
  private static Method methodObject22290;
  private static Method methodObject22337;
  private static Method methodObject22366;
  private static Method methodObject22324;
  private static Method methodObject22353;
  private static Method methodObject22331;
  private static Method methodObject22309;
  private static Method methodObject22354;
  private static Method methodObject22365;
  private static Method methodObject22340;
  private static Method methodObject22296;
  private static Method methodObject22314;
  private static Method methodObject22357;
  private static Method methodObject22328;
  private static Method methodObject22322;
  private static Method methodObject22301;
  private static Method methodObject22288;
  private static Method methodObject22297;
  private static Method methodObject22313;
  private static Method methodObject22355;
  private static Method methodObject22356;
  private static Method methodObject22325;
  private static Method methodObject22369;
  private static Method methodObject22306;
  private static Method methodObject22299;
  private static Method methodObject22363;
  private static Method methodObject22332;
  private static Method methodObject22347;
  private static Method methodObject22345;
  private static Method methodObject22287;
  private static Method methodObject22371;
  private static Method methodObject22293;
  private static Method methodObject22361;
  private static Method methodObject22319;
  private static Method methodObject22300;
  private static Method methodObject22338;
  private static Method methodObject22352;
  private static Method methodObject22312;
  private static Method methodObject22362;
  private static Method methodObject22341;
  private static Method methodObject22305;
  private static Method methodObject22360;
  private static Method methodObject22346;
  private static Method methodObject22336;
  private static Method methodObject22310;
  private static Method methodObject22294;
  private static Method methodObject22344;
  private static Method methodObject22349;
  private static Method methodObject22367;
  private static Method methodObject22302;
  private static Method methodObject22292;
  private static Method methodObject22370;
  private static Method methodObject22334;
  private static Method methodObject22333;
  private static Method methodObject22327;
  private static Method methodObject22350;
  private static Method methodObject22291;
  private static Method methodObject22321;
  private static Method methodObject22307;
  private static Method methodObject22358;
  private static Method methodObject22339;
  private static Method methodObject22308;
  private static Method methodObject22323;
  private static Method methodObject22295;
  private static Method methodObject22330;
  private static Method methodObject22318;
  private static Method methodObject22335;
  private static Method methodObject22368;
  private static Method methodObject22326;
  
  public Object getArray(long arg0, int arg1, Map arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22364, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject22364, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1, arg2), this, this.proxyCache, methodObject22364));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22364, onErrorForAll(methodObject22364, e));
    }
  }
  
  public boolean isInline()
  {
    super.preForAll(methodObject22303, this, new Object[0]);
    return ((Boolean)postForAll(methodObject22303, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isInline()), this, this.proxyCache, methodObject22303))).booleanValue();
  }
  
  public void setImageLength(long arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22315, this, new Object[] { Long.valueOf(arg0) });
      this.delegate.setImageLength(arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22315, e);
    }
  }
  
  public void setAutoBuffering(boolean arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22304, this, new Object[] { Boolean.valueOf(arg0) });
      this.delegate.setAutoBuffering(arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22304, e);
    }
  }
  
  public long getOffset(long arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22289, this, new Object[] { Long.valueOf(arg0) });
      return ((Long)postForAll(methodObject22289, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getOffset(arg0)), this, this.proxyCache, methodObject22289))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject22289, onErrorForAll(methodObject22289, e))).longValue();
    }
  }
  
  public long getImageLength()
  {
    super.preForAll(methodObject22317, this, new Object[0]);
    return ((Long)postForAll(methodObject22317, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getImageLength()), this, this.proxyCache, methodObject22317))).longValue();
  }
  
  public Connection getJavaSqlConnection()
    throws SQLException
  {
    return this.delegate.getJavaSqlConnection();
  }
  
  public float[] getFloatArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22359, this, new Object[0]);
      return (float[])postForAll(methodObject22359, this.proxyFactory.proxyFor((Object)this.delegate.getFloatArray(), this, this.proxyCache, methodObject22359));
    }
    catch (SQLException e)
    {
      return (float[])postForAll(methodObject22359, onErrorForAll(methodObject22359, e));
    }
  }
  
  public void setLocator(byte[] arg0)
  {
    super.preForAll(methodObject22298, this, new Object[] { arg0 });
    this.delegate.setLocator(arg0);
  }
  
  public long getImageOffset()
  {
    super.preForAll(methodObject22316, this, new Object[0]);
    return ((Long)postForAll(methodObject22316, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getImageOffset()), this, this.proxyCache, methodObject22316))).longValue();
  }
  
  public boolean booleanValue()
    throws SQLException
  {
    return this.delegate.booleanValue();
  }
  
  public void setShareBytes(byte[] arg0)
  {
    this.delegate.setShareBytes(arg0);
  }
  
  public void setIndexOffset(long arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22311, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      this.delegate.setIndexOffset(arg0, arg1);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22311, e);
    }
  }
  
  public String getSQLTypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22348, this, new Object[0]);
      return (String)postForAll(methodObject22348, this.proxyFactory.proxyFor((Object)this.delegate.getSQLTypeName(), this, this.proxyCache, methodObject22348));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject22348, onErrorForAll(methodObject22348, e));
    }
  }
  
  public int[] getIntArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22351, this, new Object[0]);
      return (int[])postForAll(methodObject22351, this.proxyFactory.proxyFor((Object)this.delegate.getIntArray(), this, this.proxyCache, methodObject22351));
    }
    catch (SQLException e)
    {
      return (int[])postForAll(methodObject22351, onErrorForAll(methodObject22351, e));
    }
  }
  
  public Map getMap()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22290, this, new Object[0]);
      return (Map)postForAll(methodObject22290, this.proxyFactory.proxyFor((Object)this.delegate.getMap(), this, this.proxyCache, methodObject22290));
    }
    catch (SQLException e)
    {
      return (Map)postForAll(methodObject22290, onErrorForAll(methodObject22290, e));
    }
  }
  
  public Timestamp timestampValue()
    throws SQLException
  {
    return this.delegate.timestampValue();
  }
  
  public int getBaseType()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22366, this, new Object[0]);
      return ((Integer)postForAll(methodObject22366, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, this.proxyCache, methodObject22366))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject22366, onErrorForAll(methodObject22366, e))).intValue();
    }
  }
  
  public int intValue()
    throws SQLException
  {
    return this.delegate.intValue();
  }
  
  public double[] getDoubleArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22353, this, new Object[0]);
      return (double[])postForAll(methodObject22353, this.proxyFactory.proxyFor((Object)this.delegate.getDoubleArray(), this, this.proxyCache, methodObject22353));
    }
    catch (SQLException e)
    {
      return (double[])postForAll(methodObject22353, onErrorForAll(methodObject22353, e));
    }
  }
  
  public String stringValue()
    throws SQLException
  {
    return this.delegate.stringValue();
  }
  
  public int getAccessDirection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22309, this, new Object[0]);
      return ((Integer)postForAll(methodObject22309, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getAccessDirection()), this, this.proxyCache, methodObject22309))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject22309, onErrorForAll(methodObject22309, e))).intValue();
    }
  }
  
  public double[] getDoubleArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22354, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (double[])postForAll(methodObject22354, this.proxyFactory.proxyFor((Object)this.delegate.getDoubleArray(arg0, arg1), this, this.proxyCache, methodObject22354));
    }
    catch (SQLException e)
    {
      return (double[])postForAll(methodObject22354, onErrorForAll(methodObject22354, e));
    }
  }
  
  public void free()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22365, this, new Object[0]);
      this.delegate.free();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22365, e);
    }
  }
  
  public InputStream asciiStreamValue()
    throws SQLException
  {
    return this.delegate.asciiStreamValue();
  }
  
  public void setDatumArray(Datum[] arg0)
  {
    super.preForAll(methodObject22296, this, new Object[] { arg0 });
    this.delegate.setDatumArray(arg0);
  }
  
  public void setImage(byte[] arg0, long arg1, long arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22314, this, new Object[] { arg0, Long.valueOf(arg1), Long.valueOf(arg2) });
      this.delegate.setImage(arg0, arg1, arg2);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22314, e);
    }
  }
  
  public long[] getLongArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22357, this, new Object[0]);
      return (long[])postForAll(methodObject22357, this.proxyFactory.proxyFor((Object)this.delegate.getLongArray(), this, this.proxyCache, methodObject22357));
    }
    catch (SQLException e)
    {
      return (long[])postForAll(methodObject22357, onErrorForAll(methodObject22357, e));
    }
  }
  
  public byte[] shareBytes()
  {
    return this.delegate.shareBytes();
  }
  
  public double doubleValue()
    throws SQLException
  {
    return this.delegate.doubleValue();
  }
  
  public byte[] getLocator()
  {
    super.preForAll(methodObject22301, this, new Object[0]);
    return (byte[])postForAll(methodObject22301, this.proxyFactory.proxyFor((Object)this.delegate.getLocator(), this, this.proxyCache, methodObject22301));
  }
  
  public void setLength(int arg0)
  {
    super.preForAll(methodObject22288, this, new Object[] { Integer.valueOf(arg0) });
    this.delegate.setLength(arg0);
  }
  
  public void setObjArray(Object arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22297, this, new Object[] { arg0 });
      this.delegate.setObjArray((arg0 instanceof _Proxy_) ? (Object)((_Proxy_)arg0)._getDelegate_() : arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22297, e);
    }
  }
  
  public long getLastOffset()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22313, this, new Object[0]);
      return ((Long)postForAll(methodObject22313, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getLastOffset()), this, this.proxyCache, methodObject22313))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject22313, onErrorForAll(methodObject22313, e))).longValue();
    }
  }
  
  public short[] getShortArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22355, this, new Object[0]);
      return (short[])postForAll(methodObject22355, this.proxyFactory.proxyFor((Object)this.delegate.getShortArray(), this, this.proxyCache, methodObject22355));
    }
    catch (SQLException e)
    {
      return (short[])postForAll(methodObject22355, onErrorForAll(methodObject22355, e));
    }
  }
  
  public short[] getShortArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22356, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (short[])postForAll(methodObject22356, this.proxyFactory.proxyFor((Object)this.delegate.getShortArray(arg0, arg1), this, this.proxyCache, methodObject22356));
    }
    catch (SQLException e)
    {
      return (short[])postForAll(methodObject22356, onErrorForAll(methodObject22356, e));
    }
  }
  
  public long longValue()
    throws SQLException
  {
    return this.delegate.longValue();
  }
  
  public ResultSet getResultSet(Map arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22369, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject22369, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0), this, this.proxyCache, methodObject22369));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22369, onErrorForAll(methodObject22369, e));
    }
  }
  
  public void setAutoIndexing(boolean arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22306, this, new Object[] { Boolean.valueOf(arg0), Integer.valueOf(arg1) });
      this.delegate.setAutoIndexing(arg0, arg1);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22306, e);
    }
  }
  
  public void setPrefixSegment(byte[] arg0)
  {
    super.preForAll(methodObject22299, this, new Object[] { arg0 });
    this.delegate.setPrefixSegment(arg0);
  }
  
  public Object getArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22363, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject22363, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1), this, this.proxyCache, methodObject22363));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22363, onErrorForAll(methodObject22363, e));
    }
  }
  
  public String stringValue(Connection arg0)
    throws SQLException
  {
    return this.delegate.stringValue((arg0 instanceof _Proxy_) ? (Connection)((_Proxy_)arg0)._getDelegate_() : arg0);
  }
  
  public int length()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22347, this, new Object[0]);
      return ((Integer)postForAll(methodObject22347, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.length()), this, this.proxyCache, methodObject22347))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject22347, onErrorForAll(methodObject22347, e))).intValue();
    }
  }
  
  public oracle.jdbc.internal.OracleConnection getInternalConnection()
    throws SQLException
  {
    return this.delegate.getInternalConnection();
  }
  
  public ArrayDescriptor getDescriptor()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22287, this, new Object[0]);
      return (ArrayDescriptor)postForAll(methodObject22287, this.proxyFactory.proxyFor((Object)this.delegate.getDescriptor(), this, this.proxyCache, methodObject22287));
    }
    catch (SQLException e)
    {
      return (ArrayDescriptor)postForAll(methodObject22287, onErrorForAll(methodObject22287, e));
    }
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22371, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject22371, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0, arg1, arg2), this, this.proxyCache, methodObject22371));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22371, onErrorForAll(methodObject22371, e));
    }
  }
  
  public Datum[] getOracleArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22293, this, new Object[0]);
      return (Datum[])postForAll(methodObject22293, this.proxyFactory.proxyFor((Object)this.delegate.getOracleArray(), this, this.proxyCache, methodObject22293));
    }
    catch (SQLException e)
    {
      return (Datum[])postForAll(methodObject22293, onErrorForAll(methodObject22293, e));
    }
  }
  
  public Object getArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22361, this, new Object[0]);
      return postForAll(methodObject22361, this.proxyFactory.proxyFor(this.delegate.getArray(), this, this.proxyCache, methodObject22361));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22361, onErrorForAll(methodObject22361, e));
    }
  }
  
  public byte[] getBytes()
  {
    return this.delegate.getBytes();
  }
  
  public void setPrefixFlag(byte arg0)
  {
    super.preForAll(methodObject22300, this, new Object[] { Byte.valueOf(arg0) });
    this.delegate.setPrefixFlag(arg0);
  }
  
  public Timestamp timestampValue(Calendar arg0)
    throws SQLException
  {
    return this.delegate.timestampValue(arg0);
  }
  
  public int[] getIntArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22352, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (int[])postForAll(methodObject22352, this.proxyFactory.proxyFor((Object)this.delegate.getIntArray(arg0, arg1), this, this.proxyCache, methodObject22352));
    }
    catch (SQLException e)
    {
      return (int[])postForAll(methodObject22352, onErrorForAll(methodObject22352, e));
    }
  }
  
  public long getLastIndex()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22312, this, new Object[0]);
      return ((Long)postForAll(methodObject22312, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getLastIndex()), this, this.proxyCache, methodObject22312))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject22312, onErrorForAll(methodObject22312, e))).longValue();
    }
  }
  
  public Object getArray(Map arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22362, this, new Object[] { arg0 });
      return postForAll(methodObject22362, this.proxyFactory.proxyFor(this.delegate.getArray(arg0), this, this.proxyCache, methodObject22362));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22362, onErrorForAll(methodObject22362, e));
    }
  }
  
  public InputStream binaryStreamValue()
    throws SQLException
  {
    return this.delegate.binaryStreamValue();
  }
  
  public boolean getAutoBuffering()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22305, this, new Object[0]);
      return ((Boolean)postForAll(methodObject22305, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.getAutoBuffering()), this, this.proxyCache, methodObject22305))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject22305, onErrorForAll(methodObject22305, e))).booleanValue();
    }
  }
  
  public float[] getFloatArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22360, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (float[])postForAll(methodObject22360, this.proxyFactory.proxyFor((Object)this.delegate.getFloatArray(arg0, arg1), this, this.proxyCache, methodObject22360));
    }
    catch (SQLException e)
    {
      return (float[])postForAll(methodObject22360, onErrorForAll(methodObject22360, e));
    }
  }
  
  public void setPhysicalConnectionOf(Connection arg0)
  {
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? (Connection)((_Proxy_)arg0)._getDelegate_() : arg0);
  }
  
  public Time timeValue(Calendar arg0)
    throws SQLException
  {
    return this.delegate.timeValue(arg0);
  }
  
  public void setLastIndexOffset(long arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22310, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      this.delegate.setLastIndexOffset(arg0, arg1);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22310, e);
    }
  }
  
  public Datum[] getOracleArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22294, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (Datum[])postForAll(methodObject22294, this.proxyFactory.proxyFor((Object)this.delegate.getOracleArray(arg0, arg1), this, this.proxyCache, methodObject22294));
    }
    catch (SQLException e)
    {
      return (Datum[])postForAll(methodObject22294, onErrorForAll(methodObject22294, e));
    }
  }
  
  public oracle.jdbc.OracleConnection getOracleConnection()
    throws SQLException
  {
    return this.delegate.getOracleConnection();
  }
  
  public Object toJdbc()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22349, this, new Object[0]);
      return postForAll(methodObject22349, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, this.proxyCache, methodObject22349));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject22349, onErrorForAll(methodObject22349, e));
    }
  }
  
  public String getBaseTypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22367, this, new Object[0]);
      return (String)postForAll(methodObject22367, this.proxyFactory.proxyFor((Object)this.delegate.getBaseTypeName(), this, this.proxyCache, methodObject22367));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject22367, onErrorForAll(methodObject22367, e));
    }
  }
  
  public boolean hasDataSeg()
  {
    super.preForAll(methodObject22302, this, new Object[0]);
    return ((Boolean)postForAll(methodObject22302, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.hasDataSeg()), this, this.proxyCache, methodObject22302))).booleanValue();
  }
  
  public Object makeJdbcArray(int arg0)
  {
    super.preForAll(methodObject22292, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject22292, this.proxyFactory.proxyFor(this.delegate.makeJdbcArray(arg0), this, this.proxyCache, methodObject22292));
  }
  
  public ResultSet getResultSet(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22370, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject22370, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(arg0, arg1), this, this.proxyCache, methodObject22370));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22370, onErrorForAll(methodObject22370, e));
    }
  }
  
  public Date dateValue()
    throws SQLException
  {
    return this.delegate.dateValue();
  }
  
  public BigDecimal bigDecimalValue()
    throws SQLException
  {
    return this.delegate.bigDecimalValue();
  }
  
  public void setBytes(byte[] arg0)
  {
    this.delegate.setBytes(arg0);
  }
  
  public OracleTypeMetaData getOracleMetaData()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22350, this, new Object[0]);
      return (OracleTypeMetaData)postForAll(methodObject22350, this.proxyFactory.proxyFor((Object)this.delegate.getOracleMetaData(), this, this.proxyCache, methodObject22350));
    }
    catch (SQLException e)
    {
      return (OracleTypeMetaData)postForAll(methodObject22350, onErrorForAll(methodObject22350, e));
    }
  }
  
  public boolean isConvertibleTo(Class arg0)
  {
    super.preForAll(methodObject22291, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject22291, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isConvertibleTo(arg0)), this, this.proxyCache, methodObject22291))).booleanValue();
  }
  
  public byte byteValue()
    throws SQLException
  {
    return this.delegate.byteValue();
  }
  
  public void setAutoIndexing(boolean arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22307, this, new Object[] { Boolean.valueOf(arg0) });
      this.delegate.setAutoIndexing(arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject22307, e);
    }
  }
  
  public long[] getLongArray(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22358, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (long[])postForAll(methodObject22358, this.proxyFactory.proxyFor((Object)this.delegate.getLongArray(arg0, arg1), this, this.proxyCache, methodObject22358));
    }
    catch (SQLException e)
    {
      return (long[])postForAll(methodObject22358, onErrorForAll(methodObject22358, e));
    }
  }
  
  public Reader characterStreamValue()
    throws SQLException
  {
    return this.delegate.characterStreamValue();
  }
  
  public boolean getAutoIndexing()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22308, this, new Object[0]);
      return ((Boolean)postForAll(methodObject22308, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.getAutoIndexing()), this, this.proxyCache, methodObject22308))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject22308, onErrorForAll(methodObject22308, e))).booleanValue();
    }
  }
  
  public float floatValue()
    throws SQLException
  {
    return this.delegate.floatValue();
  }
  
  public byte[] toBytes()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22295, this, new Object[0]);
      return (byte[])postForAll(methodObject22295, this.proxyFactory.proxyFor((Object)this.delegate.toBytes(), this, this.proxyCache, methodObject22295));
    }
    catch (SQLException e)
    {
      return (byte[])postForAll(methodObject22295, onErrorForAll(methodObject22295, e));
    }
  }
  
  public InputStream getStream()
    throws SQLException
  {
    return this.delegate.getStream();
  }
  
  public long getLength()
  {
    return this.delegate.getLength();
  }
  
  public Time timeValue()
    throws SQLException
  {
    return this.delegate.timeValue();
  }
  
  public ResultSet getResultSet()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject22368, this, new Object[0]);
      return (ResultSet)postForAll(methodObject22368, this.proxyFactory.proxyFor((Object)this.delegate.getResultSet(), this, this.proxyCache, methodObject22368));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject22368, onErrorForAll(methodObject22368, e));
    }
  }
  
  public oracle.jdbc.driver.OracleConnection getConnection()
    throws SQLException
  {
    return this.delegate.getConnection();
  }
  
  public oracle.jdbc.internal.OracleArray _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject22364 = Array.class.getDeclaredMethod("getArray", new Class[] { Long.TYPE, Integer.TYPE, Map.class });
      methodObject22303 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("isInline", new Class[0]);
      methodObject22315 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setImageLength", new Class[] { Long.TYPE });
      methodObject22304 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setAutoBuffering", new Class[] { Boolean.TYPE });
      methodObject22289 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getOffset", new Class[] { Long.TYPE });
      methodObject22317 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getImageLength", new Class[0]);
      methodObject22343 = OracleDatumWithConnection.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject22359 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getFloatArray", new Class[0]);
      methodObject22298 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setLocator", new Class[] { byte[].class });
      methodObject22316 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getImageOffset", new Class[0]);
      methodObject22320 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject22329 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject22311 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setIndexOffset", new Class[] { Long.TYPE, Long.TYPE });
      methodObject22348 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject22351 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getIntArray", new Class[0]);
      methodObject22290 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getMap", new Class[0]);
      methodObject22337 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject22366 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject22324 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject22353 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[0]);
      methodObject22331 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject22309 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getAccessDirection", new Class[0]);
      methodObject22354 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22365 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject22340 = OracleDatumWithConnection.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject22296 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setDatumArray", new Class[] { Datum[].class });
      methodObject22314 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setImage", new Class[] { byte[].class, Long.TYPE, Long.TYPE });
      methodObject22357 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getLongArray", new Class[0]);
      methodObject22328 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject22322 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject22301 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getLocator", new Class[0]);
      methodObject22288 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setLength", new Class[] { Integer.TYPE });
      methodObject22297 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setObjArray", new Class[] { Object.class });
      methodObject22313 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getLastOffset", new Class[0]);
      methodObject22355 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getShortArray", new Class[0]);
      methodObject22356 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getShortArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22325 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject22369 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject22306 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setAutoIndexing", new Class[] { Boolean.TYPE, Integer.TYPE });
      methodObject22299 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setPrefixSegment", new Class[] { byte[].class });
      methodObject22363 = Array.class.getDeclaredMethod("getArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22332 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject22347 = oracle.jdbc.OracleArray.class.getDeclaredMethod("length", new Class[0]);
      methodObject22345 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject22287 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getDescriptor", new Class[0]);
      methodObject22371 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Long.TYPE, Integer.TYPE, Map.class });
      methodObject22293 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getOracleArray", new Class[0]);
      methodObject22361 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject22319 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject22300 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setPrefixFlag", new Class[] { Byte.TYPE });
      methodObject22338 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject22352 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getIntArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22312 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getLastIndex", new Class[0]);
      methodObject22362 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject22341 = OracleDatumWithConnection.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject22305 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getAutoBuffering", new Class[0]);
      methodObject22360 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getFloatArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22346 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject22336 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject22310 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setLastIndexOffset", new Class[] { Long.TYPE, Long.TYPE });
      methodObject22294 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getOracleArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22344 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject22349 = oracle.jdbc.OracleArray.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject22367 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject22302 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("hasDataSeg", new Class[0]);
      methodObject22292 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("makeJdbcArray", new Class[] { Integer.TYPE });
      methodObject22370 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22334 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject22333 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject22327 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject22350 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getOracleMetaData", new Class[0]);
      methodObject22291 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject22321 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject22307 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("setAutoIndexing", new Class[] { Boolean.TYPE });
      methodObject22358 = oracle.jdbc.OracleArray.class.getDeclaredMethod("getLongArray", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject22339 = OracleDatumWithConnection.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject22308 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("getAutoIndexing", new Class[0]);
      methodObject22323 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject22295 = oracle.jdbc.internal.OracleArray.class.getDeclaredMethod("toBytes", new Class[0]);
      methodObject22330 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject22318 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject22335 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject22368 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
      methodObject22326 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy(oracle.jdbc.internal.OracleArray paramOracleArray, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */