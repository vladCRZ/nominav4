package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.RowIdLifetime;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1DatabaseMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements DatabaseMetaData, _Proxy_
{
  private DatabaseMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28712;
  private static Method methodObject28816;
  private static Method methodObject28786;
  private static Method methodObject28702;
  private static Method methodObject28690;
  private static Method methodObject28807;
  private static Method methodObject28744;
  private static Method methodObject28709;
  private static Method methodObject28824;
  private static Method methodObject28796;
  private static Method methodObject28746;
  private static Method methodObject28830;
  private static Method methodObject28728;
  private static Method methodObject28842;
  private static Method methodObject28800;
  private static Method methodObject28761;
  private static Method methodObject28750;
  private static Method methodObject28847;
  private static Method methodObject28741;
  private static Method methodObject28757;
  private static Method methodObject28733;
  private static Method methodObject28704;
  private static Method methodObject28719;
  private static Method methodObject28743;
  private static Method methodObject28839;
  private static Method methodObject28826;
  private static Method methodObject28831;
  private static Method methodObject28819;
  private static Method methodObject28703;
  private static Method methodObject28736;
  private static Method methodObject28738;
  private static Method methodObject28683;
  private static Method methodObject28692;
  private static Method methodObject28698;
  private static Method methodObject28841;
  private static Method methodObject28696;
  private static Method methodObject28721;
  private static Method methodObject28836;
  private static Method methodObject28693;
  private static Method methodObject28829;
  private static Method methodObject28700;
  private static Method methodObject28747;
  private static Method methodObject28687;
  private static Method methodObject28846;
  private static Method methodObject28832;
  private static Method methodObject28805;
  private static Method methodObject28684;
  private static Method methodObject28756;
  private static Method methodObject28763;
  private static Method methodObject28691;
  private static Method methodObject28701;
  private static Method methodObject28787;
  private static Method methodObject28760;
  private static Method methodObject28714;
  private static Method methodObject28739;
  private static Method methodObject28777;
  private static Method methodObject28678;
  private static Method methodObject28797;
  private static Method methodObject28753;
  private static Method methodObject28801;
  private static Method methodObject28731;
  private static Method methodObject28755;
  private static Method methodObject28732;
  private static Method methodObject28844;
  private static Method methodObject28838;
  private static Method methodObject28820;
  private static Method methodObject28688;
  private static Method methodObject28848;
  private static Method methodObject28781;
  private static Method methodObject28734;
  private static Method methodObject28742;
  private static Method methodObject28745;
  private static Method methodObject28729;
  private static Method methodObject28754;
  private static Method methodObject28695;
  private static Method methodObject28828;
  private static Method methodObject28823;
  private static Method methodObject28776;
  private static Method methodObject28809;
  private static Method methodObject28778;
  private static Method methodObject28748;
  private static Method methodObject28793;
  private static Method methodObject28697;
  private static Method methodObject28727;
  private static Method methodObject28766;
  private static Method methodObject28814;
  private static Method methodObject28677;
  private static Method methodObject28770;
  private static Method methodObject28705;
  private static Method methodObject28772;
  private static Method methodObject28843;
  private static Method methodObject28825;
  private static Method methodObject28680;
  private static Method methodObject28706;
  private static Method methodObject28810;
  private static Method methodObject28774;
  private static Method methodObject28799;
  private static Method methodObject28791;
  private static Method methodObject28850;
  private static Method methodObject28780;
  private static Method methodObject28835;
  private static Method methodObject28724;
  private static Method methodObject28713;
  private static Method methodObject28815;
  private static Method methodObject28758;
  private static Method methodObject28806;
  private static Method methodObject28794;
  private static Method methodObject28737;
  private static Method methodObject28765;
  private static Method methodObject28827;
  private static Method methodObject28715;
  private static Method methodObject28694;
  private static Method methodObject28784;
  private static Method methodObject28792;
  private static Method methodObject28711;
  private static Method methodObject28798;
  private static Method methodObject28759;
  private static Method methodObject28685;
  private static Method methodObject28821;
  private static Method methodObject28751;
  private static Method methodObject28764;
  private static Method methodObject28769;
  private static Method methodObject28679;
  private static Method methodObject28845;
  private static Method methodObject28681;
  private static Method methodObject28708;
  private static Method methodObject28785;
  private static Method methodObject28849;
  private static Method methodObject28740;
  private static Method methodObject28699;
  private static Method methodObject28726;
  private static Method methodObject28775;
  private static Method methodObject28790;
  private static Method methodObject28783;
  private static Method methodObject28813;
  private static Method methodObject28710;
  private static Method methodObject28707;
  private static Method methodObject28802;
  private static Method methodObject28722;
  private static Method methodObject28720;
  private static Method methodObject28723;
  private static Method methodObject28767;
  private static Method methodObject28682;
  private static Method methodObject28752;
  private static Method methodObject28762;
  private static Method methodObject28837;
  private static Method methodObject28725;
  private static Method methodObject28749;
  private static Method methodObject28840;
  private static Method methodObject28818;
  private static Method methodObject28789;
  private static Method methodObject28803;
  private static Method methodObject28834;
  private static Method methodObject28795;
  private static Method methodObject28811;
  private static Method methodObject28718;
  private static Method methodObject28717;
  private static Method methodObject28730;
  private static Method methodObject28782;
  private static Method methodObject28804;
  private static Method methodObject28779;
  private static Method methodObject28735;
  private static Method methodObject28686;
  private static Method methodObject28808;
  private static Method methodObject28716;
  private static Method methodObject28771;
  private static Method methodObject28773;
  private static Method methodObject28812;
  private static Method methodObject28817;
  private static Method methodObject28768;
  private static Method methodObject28833;
  private static Method methodObject28822;
  private static Method methodObject28788;
  private static Method methodObject28689;
  
  public int getJDBCMajorVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28712, this, new Object[0]);
      return ((Integer)postForAll(methodObject28712, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getJDBCMajorVersion()), this, this.proxyCache, methodObject28712))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28712, onErrorForAll(methodObject28712, e))).intValue();
    }
  }
  
  public boolean supportsOpenCursorsAcrossCommit()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28816, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28816, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenCursorsAcrossCommit()), this, this.proxyCache, methodObject28816))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28816, onErrorForAll(methodObject28816, e))).booleanValue();
    }
  }
  
  public boolean supportsCatalogsInIndexDefinitions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28786, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28786, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInIndexDefinitions()), this, this.proxyCache, methodObject28786))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28786, onErrorForAll(methodObject28786, e))).booleanValue();
    }
  }
  
  public int getDriverMinorVersion()
  {
    super.preForAll(methodObject28702, this, new Object[0]);
    return ((Integer)postForAll(methodObject28702, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDriverMinorVersion()), this, this.proxyCache, methodObject28702))).intValue();
  }
  
  public String getCatalogTerm()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28690, this, new Object[0]);
      return (String)postForAll(methodObject28690, this.proxyFactory.proxyFor((Object)this.delegate.getCatalogTerm(), this, this.proxyCache, methodObject28690));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28690, onErrorForAll(methodObject28690, e));
    }
  }
  
  public boolean supportsLimitedOuterJoins()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28807, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28807, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsLimitedOuterJoins()), this, this.proxyCache, methodObject28807))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28807, onErrorForAll(methodObject28807, e))).booleanValue();
    }
  }
  
  public ResultSet getSchemas()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28744, this, new Object[0]);
      return (ResultSet)postForAll(methodObject28744, this.proxyFactory.proxyFor((Object)this.delegate.getSchemas(), this, this.proxyCache, methodObject28744));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28744, onErrorForAll(methodObject28744, e));
    }
  }
  
  public String getIdentifierQuoteString()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28709, this, new Object[0]);
      return (String)postForAll(methodObject28709, this.proxyFactory.proxyFor((Object)this.delegate.getIdentifierQuoteString(), this, this.proxyCache, methodObject28709));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28709, onErrorForAll(methodObject28709, e));
    }
  }
  
  public boolean supportsResultSetConcurrency(int arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28824, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
      return ((Boolean)postForAll(methodObject28824, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsResultSetConcurrency(arg0, arg1)), this, this.proxyCache, methodObject28824))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28824, onErrorForAll(methodObject28824, e))).booleanValue();
    }
  }
  
  public boolean supportsDataManipulationTransactionsOnly()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28796, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28796, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsDataManipulationTransactionsOnly()), this, this.proxyCache, methodObject28796))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28796, onErrorForAll(methodObject28796, e))).booleanValue();
    }
  }
  
  public String getSearchStringEscape()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28746, this, new Object[0]);
      return (String)postForAll(methodObject28746, this.proxyFactory.proxyFor((Object)this.delegate.getSearchStringEscape(), this, this.proxyCache, methodObject28746));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28746, onErrorForAll(methodObject28746, e));
    }
  }
  
  public boolean supportsSchemasInPrivilegeDefinitions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28830, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28830, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInPrivilegeDefinitions()), this, this.proxyCache, methodObject28830))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28830, onErrorForAll(methodObject28830, e))).booleanValue();
    }
  }
  
  public int getMaxSchemaNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28728, this, new Object[0]);
      return ((Integer)postForAll(methodObject28728, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxSchemaNameLength()), this, this.proxyCache, methodObject28728))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28728, onErrorForAll(methodObject28728, e))).intValue();
    }
  }
  
  public boolean supportsTransactionIsolationLevel(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28842, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28842, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsTransactionIsolationLevel(arg0)), this, this.proxyCache, methodObject28842))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28842, onErrorForAll(methodObject28842, e))).booleanValue();
    }
  }
  
  public boolean supportsFullOuterJoins()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28800, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28800, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsFullOuterJoins()), this, this.proxyCache, methodObject28800))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28800, onErrorForAll(methodObject28800, e))).booleanValue();
    }
  }
  
  public boolean locatorsUpdateCopy()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28761, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28761, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.locatorsUpdateCopy()), this, this.proxyCache, methodObject28761))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28761, onErrorForAll(methodObject28761, e))).booleanValue();
    }
  }
  
  public String getSystemFunctions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28750, this, new Object[0]);
      return (String)postForAll(methodObject28750, this.proxyFactory.proxyFor((Object)this.delegate.getSystemFunctions(), this, this.proxyCache, methodObject28750));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28750, onErrorForAll(methodObject28750, e));
    }
  }
  
  public boolean usesLocalFilePerTable()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28847, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28847, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.usesLocalFilePerTable()), this, this.proxyCache, methodObject28847))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28847, onErrorForAll(methodObject28847, e))).booleanValue();
    }
  }
  
  public String getSQLKeywords()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28741, this, new Object[0]);
      return (String)postForAll(methodObject28741, this.proxyFactory.proxyFor((Object)this.delegate.getSQLKeywords(), this, this.proxyCache, methodObject28741));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28741, onErrorForAll(methodObject28741, e));
    }
  }
  
  public String getUserName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28757, this, new Object[0]);
      return (String)postForAll(methodObject28757, this.proxyFactory.proxyFor((Object)this.delegate.getUserName(), this, this.proxyCache, methodObject28757));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28757, onErrorForAll(methodObject28757, e));
    }
  }
  
  public int getMaxUserNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28733, this, new Object[0]);
      return ((Integer)postForAll(methodObject28733, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxUserNameLength()), this, this.proxyCache, methodObject28733))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28733, onErrorForAll(methodObject28733, e))).intValue();
    }
  }
  
  public String getDriverVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28704, this, new Object[0]);
      return (String)postForAll(methodObject28704, this.proxyFactory.proxyFor((Object)this.delegate.getDriverVersion(), this, this.proxyCache, methodObject28704));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28704, onErrorForAll(methodObject28704, e));
    }
  }
  
  public int getMaxColumnsInIndex()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28719, this, new Object[0]);
      return ((Integer)postForAll(methodObject28719, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInIndex()), this, this.proxyCache, methodObject28719))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28719, onErrorForAll(methodObject28719, e))).intValue();
    }
  }
  
  public String getSchemaTerm()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28743, this, new Object[0]);
      return (String)postForAll(methodObject28743, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaTerm(), this, this.proxyCache, methodObject28743));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28743, onErrorForAll(methodObject28743, e));
    }
  }
  
  public boolean supportsSubqueriesInIns()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28839, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28839, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInIns()), this, this.proxyCache, methodObject28839))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28839, onErrorForAll(methodObject28839, e))).booleanValue();
    }
  }
  
  public boolean supportsResultSetType(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28826, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28826, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsResultSetType(arg0)), this, this.proxyCache, methodObject28826))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28826, onErrorForAll(methodObject28826, e))).booleanValue();
    }
  }
  
  public boolean supportsSchemasInProcedureCalls()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28831, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28831, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInProcedureCalls()), this, this.proxyCache, methodObject28831))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28831, onErrorForAll(methodObject28831, e))).booleanValue();
    }
  }
  
  public boolean supportsOpenStatementsAcrossRollback()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28819, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28819, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenStatementsAcrossRollback()), this, this.proxyCache, methodObject28819))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28819, onErrorForAll(methodObject28819, e))).booleanValue();
    }
  }
  
  public String getDriverName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28703, this, new Object[0]);
      return (String)postForAll(methodObject28703, this.proxyFactory.proxyFor((Object)this.delegate.getDriverName(), this, this.proxyCache, methodObject28703));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28703, onErrorForAll(methodObject28703, e));
    }
  }
  
  public ResultSet getProcedureColumns(String arg0, String arg1, String arg2, String arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28736, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28736, this.proxyFactory.proxyFor((Object)this.delegate.getProcedureColumns(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28736));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28736, onErrorForAll(methodObject28736, e));
    }
  }
  
  public ResultSet getProcedures(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28738, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28738, this.proxyFactory.proxyFor((Object)this.delegate.getProcedures(arg0, arg1, arg2), this, this.proxyCache, methodObject28738));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28738, onErrorForAll(methodObject28738, e));
    }
  }
  
  public boolean autoCommitFailureClosesAllResultSets()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28683, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28683, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.autoCommitFailureClosesAllResultSets()), this, this.proxyCache, methodObject28683))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28683, onErrorForAll(methodObject28683, e))).booleanValue();
    }
  }
  
  public ResultSet getClientInfoProperties()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28692, this, new Object[0]);
      return (ResultSet)postForAll(methodObject28692, this.proxyFactory.proxyFor((Object)this.delegate.getClientInfoProperties(), this, this.proxyCache, methodObject28692));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28692, onErrorForAll(methodObject28692, e));
    }
  }
  
  public String getDatabaseProductName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28698, this, new Object[0]);
      return (String)postForAll(methodObject28698, this.proxyFactory.proxyFor((Object)this.delegate.getDatabaseProductName(), this, this.proxyCache, methodObject28698));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28698, onErrorForAll(methodObject28698, e));
    }
  }
  
  public boolean supportsTableCorrelationNames()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28841, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28841, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsTableCorrelationNames()), this, this.proxyCache, methodObject28841))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28841, onErrorForAll(methodObject28841, e))).booleanValue();
    }
  }
  
  public int getDatabaseMajorVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28696, this, new Object[0]);
      return ((Integer)postForAll(methodObject28696, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDatabaseMajorVersion()), this, this.proxyCache, methodObject28696))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28696, onErrorForAll(methodObject28696, e))).intValue();
    }
  }
  
  public int getMaxColumnsInSelect()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28721, this, new Object[0]);
      return ((Integer)postForAll(methodObject28721, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInSelect()), this, this.proxyCache, methodObject28721))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28721, onErrorForAll(methodObject28721, e))).intValue();
    }
  }
  
  public boolean supportsStoredProcedures()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28836, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28836, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsStoredProcedures()), this, this.proxyCache, methodObject28836))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28836, onErrorForAll(methodObject28836, e))).booleanValue();
    }
  }
  
  public ResultSet getColumnPrivileges(String arg0, String arg1, String arg2, String arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28693, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28693, this.proxyFactory.proxyFor((Object)this.delegate.getColumnPrivileges(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28693));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28693, onErrorForAll(methodObject28693, e));
    }
  }
  
  public boolean supportsSchemasInIndexDefinitions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28829, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28829, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInIndexDefinitions()), this, this.proxyCache, methodObject28829))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28829, onErrorForAll(methodObject28829, e))).booleanValue();
    }
  }
  
  public int getDefaultTransactionIsolation()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28700, this, new Object[0]);
      return ((Integer)postForAll(methodObject28700, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDefaultTransactionIsolation()), this, this.proxyCache, methodObject28700))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28700, onErrorForAll(methodObject28700, e))).intValue();
    }
  }
  
  public String getStringFunctions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28747, this, new Object[0]);
      return (String)postForAll(methodObject28747, this.proxyFactory.proxyFor((Object)this.delegate.getStringFunctions(), this, this.proxyCache, methodObject28747));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28747, onErrorForAll(methodObject28747, e));
    }
  }
  
  public boolean doesMaxRowSizeIncludeBlobs()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28687, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28687, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.doesMaxRowSizeIncludeBlobs()), this, this.proxyCache, methodObject28687))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28687, onErrorForAll(methodObject28687, e))).booleanValue();
    }
  }
  
  public boolean updatesAreDetected(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28846, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28846, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.updatesAreDetected(arg0)), this, this.proxyCache, methodObject28846))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28846, onErrorForAll(methodObject28846, e))).booleanValue();
    }
  }
  
  public boolean supportsSchemasInTableDefinitions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28832, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28832, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInTableDefinitions()), this, this.proxyCache, methodObject28832))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28832, onErrorForAll(methodObject28832, e))).booleanValue();
    }
  }
  
  public boolean supportsIntegrityEnhancementFacility()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28805, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28805, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsIntegrityEnhancementFacility()), this, this.proxyCache, methodObject28805))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28805, onErrorForAll(methodObject28805, e))).booleanValue();
    }
  }
  
  public boolean dataDefinitionCausesTransactionCommit()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28684, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28684, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.dataDefinitionCausesTransactionCommit()), this, this.proxyCache, methodObject28684))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28684, onErrorForAll(methodObject28684, e))).booleanValue();
    }
  }
  
  public ResultSet getUDTs(String arg0, String arg1, String arg2, int[] arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28756, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28756, this.proxyFactory.proxyFor((Object)this.delegate.getUDTs(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28756));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28756, onErrorForAll(methodObject28756, e));
    }
  }
  
  public boolean nullsAreSortedAtEnd()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28763, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28763, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedAtEnd()), this, this.proxyCache, methodObject28763))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28763, onErrorForAll(methodObject28763, e))).booleanValue();
    }
  }
  
  public ResultSet getCatalogs()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28691, this, new Object[0]);
      return (ResultSet)postForAll(methodObject28691, this.proxyFactory.proxyFor((Object)this.delegate.getCatalogs(), this, this.proxyCache, methodObject28691));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28691, onErrorForAll(methodObject28691, e));
    }
  }
  
  public int getDriverMajorVersion()
  {
    super.preForAll(methodObject28701, this, new Object[0]);
    return ((Integer)postForAll(methodObject28701, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDriverMajorVersion()), this, this.proxyCache, methodObject28701))).intValue();
  }
  
  public boolean supportsCatalogsInPrivilegeDefinitions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28787, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28787, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInPrivilegeDefinitions()), this, this.proxyCache, methodObject28787))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28787, onErrorForAll(methodObject28787, e))).booleanValue();
    }
  }
  
  public boolean isCatalogAtStart()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28760, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28760, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCatalogAtStart()), this, this.proxyCache, methodObject28760))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28760, onErrorForAll(methodObject28760, e))).booleanValue();
    }
  }
  
  public int getMaxBinaryLiteralLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28714, this, new Object[0]);
      return ((Integer)postForAll(methodObject28714, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxBinaryLiteralLength()), this, this.proxyCache, methodObject28714))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28714, onErrorForAll(methodObject28714, e))).intValue();
    }
  }
  
  public int getResultSetHoldability()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28739, this, new Object[0]);
      return ((Integer)postForAll(methodObject28739, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getResultSetHoldability()), this, this.proxyCache, methodObject28739))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28739, onErrorForAll(methodObject28739, e))).intValue();
    }
  }
  
  public boolean storesUpperCaseIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28777, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28777, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesUpperCaseIdentifiers()), this, this.proxyCache, methodObject28777))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28777, onErrorForAll(methodObject28777, e))).booleanValue();
    }
  }
  
  public boolean isReadOnly()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28678, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28678, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly()), this, this.proxyCache, methodObject28678))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28678, onErrorForAll(methodObject28678, e))).booleanValue();
    }
  }
  
  public boolean supportsDifferentTableCorrelationNames()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28797, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28797, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsDifferentTableCorrelationNames()), this, this.proxyCache, methodObject28797))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28797, onErrorForAll(methodObject28797, e))).booleanValue();
    }
  }
  
  public ResultSet getTables(String arg0, String arg1, String arg2, String[] arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28753, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28753, this.proxyFactory.proxyFor((Object)this.delegate.getTables(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28753));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28753, onErrorForAll(methodObject28753, e));
    }
  }
  
  public boolean supportsGetGeneratedKeys()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28801, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28801, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGetGeneratedKeys()), this, this.proxyCache, methodObject28801))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28801, onErrorForAll(methodObject28801, e))).booleanValue();
    }
  }
  
  public int getMaxTableNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28731, this, new Object[0]);
      return ((Integer)postForAll(methodObject28731, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxTableNameLength()), this, this.proxyCache, methodObject28731))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28731, onErrorForAll(methodObject28731, e))).intValue();
    }
  }
  
  public ResultSet getTypeInfo()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28755, this, new Object[0]);
      return (ResultSet)postForAll(methodObject28755, this.proxyFactory.proxyFor((Object)this.delegate.getTypeInfo(), this, this.proxyCache, methodObject28755));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28755, onErrorForAll(methodObject28755, e));
    }
  }
  
  public int getMaxTablesInSelect()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28732, this, new Object[0]);
      return ((Integer)postForAll(methodObject28732, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxTablesInSelect()), this, this.proxyCache, methodObject28732))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28732, onErrorForAll(methodObject28732, e))).intValue();
    }
  }
  
  public boolean supportsUnion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28844, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28844, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsUnion()), this, this.proxyCache, methodObject28844))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28844, onErrorForAll(methodObject28844, e))).booleanValue();
    }
  }
  
  public boolean supportsSubqueriesInExists()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28838, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28838, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInExists()), this, this.proxyCache, methodObject28838))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28838, onErrorForAll(methodObject28838, e))).booleanValue();
    }
  }
  
  public boolean supportsOrderByUnrelated()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28820, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28820, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOrderByUnrelated()), this, this.proxyCache, methodObject28820))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28820, onErrorForAll(methodObject28820, e))).booleanValue();
    }
  }
  
  public ResultSet getBestRowIdentifier(String arg0, String arg1, String arg2, int arg3, boolean arg4)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28688, this, new Object[] { arg0, arg1, arg2, Integer.valueOf(arg3), Boolean.valueOf(arg4) });
      return (ResultSet)postForAll(methodObject28688, this.proxyFactory.proxyFor((Object)this.delegate.getBestRowIdentifier(arg0, arg1, arg2, arg3, arg4), this, this.proxyCache, methodObject28688));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28688, onErrorForAll(methodObject28688, e));
    }
  }
  
  public boolean usesLocalFiles()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28848, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28848, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.usesLocalFiles()), this, this.proxyCache, methodObject28848))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28848, onErrorForAll(methodObject28848, e))).booleanValue();
    }
  }
  
  public boolean supportsANSI92IntermediateSQL()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28781, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28781, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsANSI92IntermediateSQL()), this, this.proxyCache, methodObject28781))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28781, onErrorForAll(methodObject28781, e))).booleanValue();
    }
  }
  
  public String getNumericFunctions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28734, this, new Object[0]);
      return (String)postForAll(methodObject28734, this.proxyFactory.proxyFor((Object)this.delegate.getNumericFunctions(), this, this.proxyCache, methodObject28734));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28734, onErrorForAll(methodObject28734, e));
    }
  }
  
  public int getSQLStateType()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28742, this, new Object[0]);
      return ((Integer)postForAll(methodObject28742, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getSQLStateType()), this, this.proxyCache, methodObject28742))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28742, onErrorForAll(methodObject28742, e))).intValue();
    }
  }
  
  public ResultSet getSchemas(String arg0, String arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28745, this, new Object[] { arg0, arg1 });
      return (ResultSet)postForAll(methodObject28745, this.proxyFactory.proxyFor((Object)this.delegate.getSchemas(arg0, arg1), this, this.proxyCache, methodObject28745));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28745, onErrorForAll(methodObject28745, e));
    }
  }
  
  public int getMaxStatementLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28729, this, new Object[0]);
      return ((Integer)postForAll(methodObject28729, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxStatementLength()), this, this.proxyCache, methodObject28729))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28729, onErrorForAll(methodObject28729, e))).intValue();
    }
  }
  
  public String getTimeDateFunctions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28754, this, new Object[0]);
      return (String)postForAll(methodObject28754, this.proxyFactory.proxyFor((Object)this.delegate.getTimeDateFunctions(), this, this.proxyCache, methodObject28754));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28754, onErrorForAll(methodObject28754, e));
    }
  }
  
  public ResultSet getCrossReference(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28695, this, new Object[] { arg0, arg1, arg2, arg3, arg4, arg5 });
      return (ResultSet)postForAll(methodObject28695, this.proxyFactory.proxyFor((Object)this.delegate.getCrossReference(arg0, arg1, arg2, arg3, arg4, arg5), this, this.proxyCache, methodObject28695));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28695, onErrorForAll(methodObject28695, e));
    }
  }
  
  public boolean supportsSchemasInDataManipulation()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28828, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28828, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInDataManipulation()), this, this.proxyCache, methodObject28828))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28828, onErrorForAll(methodObject28828, e))).booleanValue();
    }
  }
  
  public boolean supportsPositionedUpdate()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28823, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28823, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsPositionedUpdate()), this, this.proxyCache, methodObject28823))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28823, onErrorForAll(methodObject28823, e))).booleanValue();
    }
  }
  
  public boolean storesMixedCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28776, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28776, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesMixedCaseQuotedIdentifiers()), this, this.proxyCache, methodObject28776))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28776, onErrorForAll(methodObject28776, e))).booleanValue();
    }
  }
  
  public boolean supportsMixedCaseIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28809, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28809, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMixedCaseIdentifiers()), this, this.proxyCache, methodObject28809))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28809, onErrorForAll(methodObject28809, e))).booleanValue();
    }
  }
  
  public boolean storesUpperCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28778, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28778, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesUpperCaseQuotedIdentifiers()), this, this.proxyCache, methodObject28778))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28778, onErrorForAll(methodObject28778, e))).booleanValue();
    }
  }
  
  public ResultSet getSuperTables(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28748, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28748, this.proxyFactory.proxyFor((Object)this.delegate.getSuperTables(arg0, arg1, arg2), this, this.proxyCache, methodObject28748));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28748, onErrorForAll(methodObject28748, e));
    }
  }
  
  public boolean supportsCoreSQLGrammar()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28793, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28793, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCoreSQLGrammar()), this, this.proxyCache, methodObject28793))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28793, onErrorForAll(methodObject28793, e))).booleanValue();
    }
  }
  
  public int getDatabaseMinorVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28697, this, new Object[0]);
      return ((Integer)postForAll(methodObject28697, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDatabaseMinorVersion()), this, this.proxyCache, methodObject28697))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28697, onErrorForAll(methodObject28697, e))).intValue();
    }
  }
  
  public int getMaxRowSize()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28727, this, new Object[0]);
      return ((Integer)postForAll(methodObject28727, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxRowSize()), this, this.proxyCache, methodObject28727))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28727, onErrorForAll(methodObject28727, e))).intValue();
    }
  }
  
  public boolean nullsAreSortedLow()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28766, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28766, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedLow()), this, this.proxyCache, methodObject28766))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28766, onErrorForAll(methodObject28766, e))).booleanValue();
    }
  }
  
  public boolean supportsNamedParameters()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28814, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28814, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsNamedParameters()), this, this.proxyCache, methodObject28814))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28814, onErrorForAll(methodObject28814, e))).booleanValue();
    }
  }
  
  public String getURL()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28677, this, new Object[0]);
      return (String)postForAll(methodObject28677, this.proxyFactory.proxyFor((Object)this.delegate.getURL(), this, this.proxyCache, methodObject28677));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28677, onErrorForAll(methodObject28677, e));
    }
  }
  
  public boolean ownDeletesAreVisible(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28770, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28770, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.ownDeletesAreVisible(arg0)), this, this.proxyCache, methodObject28770))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28770, onErrorForAll(methodObject28770, e))).booleanValue();
    }
  }
  
  public ResultSet getExportedKeys(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28705, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28705, this.proxyFactory.proxyFor((Object)this.delegate.getExportedKeys(arg0, arg1, arg2), this, this.proxyCache, methodObject28705));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28705, onErrorForAll(methodObject28705, e));
    }
  }
  
  public boolean ownUpdatesAreVisible(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28772, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28772, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.ownUpdatesAreVisible(arg0)), this, this.proxyCache, methodObject28772))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28772, onErrorForAll(methodObject28772, e))).booleanValue();
    }
  }
  
  public boolean supportsTransactions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28843, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28843, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsTransactions()), this, this.proxyCache, methodObject28843))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28843, onErrorForAll(methodObject28843, e))).booleanValue();
    }
  }
  
  public boolean supportsResultSetHoldability(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28825, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28825, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsResultSetHoldability(arg0)), this, this.proxyCache, methodObject28825))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28825, onErrorForAll(methodObject28825, e))).booleanValue();
    }
  }
  
  public Connection getConnection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28680, this, new Object[0]);
      return (Connection)postForAll(methodObject28680, this.proxyFactory.proxyFor((Object)this.delegate.getConnection(), this, this.proxyCache, methodObject28680));
    }
    catch (SQLException e)
    {
      return (Connection)postForAll(methodObject28680, onErrorForAll(methodObject28680, e));
    }
  }
  
  public String getExtraNameCharacters()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28706, this, new Object[0]);
      return (String)postForAll(methodObject28706, this.proxyFactory.proxyFor((Object)this.delegate.getExtraNameCharacters(), this, this.proxyCache, methodObject28706));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28706, onErrorForAll(methodObject28706, e));
    }
  }
  
  public boolean supportsMixedCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28810, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28810, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMixedCaseQuotedIdentifiers()), this, this.proxyCache, methodObject28810))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28810, onErrorForAll(methodObject28810, e))).booleanValue();
    }
  }
  
  public boolean storesLowerCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28774, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28774, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesLowerCaseQuotedIdentifiers()), this, this.proxyCache, methodObject28774))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28774, onErrorForAll(methodObject28774, e))).booleanValue();
    }
  }
  
  public boolean supportsExtendedSQLGrammar()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28799, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28799, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsExtendedSQLGrammar()), this, this.proxyCache, methodObject28799))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28799, onErrorForAll(methodObject28799, e))).booleanValue();
    }
  }
  
  public boolean supportsConvert()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28791, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28791, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsConvert()), this, this.proxyCache, methodObject28791))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28791, onErrorForAll(methodObject28791, e))).booleanValue();
    }
  }
  
  public Object unwrap(Class arg0)
    throws SQLException
  {
    return this.delegate.unwrap(arg0);
  }
  
  public boolean supportsANSI92FullSQL()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28780, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28780, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsANSI92FullSQL()), this, this.proxyCache, methodObject28780))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28780, onErrorForAll(methodObject28780, e))).booleanValue();
    }
  }
  
  public boolean supportsStoredFunctionsUsingCallSyntax()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28835, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28835, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsStoredFunctionsUsingCallSyntax()), this, this.proxyCache, methodObject28835))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28835, onErrorForAll(methodObject28835, e))).booleanValue();
    }
  }
  
  public int getMaxCursorNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28724, this, new Object[0]);
      return ((Integer)postForAll(methodObject28724, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxCursorNameLength()), this, this.proxyCache, methodObject28724))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28724, onErrorForAll(methodObject28724, e))).intValue();
    }
  }
  
  public int getJDBCMinorVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28713, this, new Object[0]);
      return ((Integer)postForAll(methodObject28713, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getJDBCMinorVersion()), this, this.proxyCache, methodObject28713))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28713, onErrorForAll(methodObject28713, e))).intValue();
    }
  }
  
  public boolean supportsNonNullableColumns()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28815, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28815, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsNonNullableColumns()), this, this.proxyCache, methodObject28815))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28815, onErrorForAll(methodObject28815, e))).booleanValue();
    }
  }
  
  public ResultSet getVersionColumns(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28758, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28758, this.proxyFactory.proxyFor((Object)this.delegate.getVersionColumns(arg0, arg1, arg2), this, this.proxyCache, methodObject28758));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28758, onErrorForAll(methodObject28758, e));
    }
  }
  
  public boolean supportsLikeEscapeClause()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28806, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28806, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsLikeEscapeClause()), this, this.proxyCache, methodObject28806))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28806, onErrorForAll(methodObject28806, e))).booleanValue();
    }
  }
  
  public boolean supportsCorrelatedSubqueries()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28794, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28794, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCorrelatedSubqueries()), this, this.proxyCache, methodObject28794))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28794, onErrorForAll(methodObject28794, e))).booleanValue();
    }
  }
  
  public String getProcedureTerm()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28737, this, new Object[0]);
      return (String)postForAll(methodObject28737, this.proxyFactory.proxyFor((Object)this.delegate.getProcedureTerm(), this, this.proxyCache, methodObject28737));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28737, onErrorForAll(methodObject28737, e));
    }
  }
  
  public boolean nullsAreSortedHigh()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28765, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28765, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedHigh()), this, this.proxyCache, methodObject28765))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28765, onErrorForAll(methodObject28765, e))).booleanValue();
    }
  }
  
  public boolean supportsSavepoints()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28827, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28827, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSavepoints()), this, this.proxyCache, methodObject28827))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28827, onErrorForAll(methodObject28827, e))).booleanValue();
    }
  }
  
  public int getMaxCatalogNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28715, this, new Object[0]);
      return ((Integer)postForAll(methodObject28715, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxCatalogNameLength()), this, this.proxyCache, methodObject28715))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28715, onErrorForAll(methodObject28715, e))).intValue();
    }
  }
  
  public ResultSet getColumns(String arg0, String arg1, String arg2, String arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28694, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28694, this.proxyFactory.proxyFor((Object)this.delegate.getColumns(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28694));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28694, onErrorForAll(methodObject28694, e));
    }
  }
  
  public boolean supportsBatchUpdates()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28784, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28784, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsBatchUpdates()), this, this.proxyCache, methodObject28784))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28784, onErrorForAll(methodObject28784, e))).booleanValue();
    }
  }
  
  public boolean supportsConvert(int arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28792, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
      return ((Boolean)postForAll(methodObject28792, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsConvert(arg0, arg1)), this, this.proxyCache, methodObject28792))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28792, onErrorForAll(methodObject28792, e))).booleanValue();
    }
  }
  
  public ResultSet getIndexInfo(String arg0, String arg1, String arg2, boolean arg3, boolean arg4)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28711, this, new Object[] { arg0, arg1, arg2, Boolean.valueOf(arg3), Boolean.valueOf(arg4) });
      return (ResultSet)postForAll(methodObject28711, this.proxyFactory.proxyFor((Object)this.delegate.getIndexInfo(arg0, arg1, arg2, arg3, arg4), this, this.proxyCache, methodObject28711));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28711, onErrorForAll(methodObject28711, e));
    }
  }
  
  public boolean supportsExpressionsInOrderBy()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28798, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28798, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsExpressionsInOrderBy()), this, this.proxyCache, methodObject28798))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28798, onErrorForAll(methodObject28798, e))).booleanValue();
    }
  }
  
  public boolean insertsAreDetected(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28759, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28759, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.insertsAreDetected(arg0)), this, this.proxyCache, methodObject28759))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28759, onErrorForAll(methodObject28759, e))).booleanValue();
    }
  }
  
  public boolean dataDefinitionIgnoredInTransactions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28685, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28685, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.dataDefinitionIgnoredInTransactions()), this, this.proxyCache, methodObject28685))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28685, onErrorForAll(methodObject28685, e))).booleanValue();
    }
  }
  
  public boolean supportsOuterJoins()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28821, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28821, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOuterJoins()), this, this.proxyCache, methodObject28821))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28821, onErrorForAll(methodObject28821, e))).booleanValue();
    }
  }
  
  public ResultSet getTablePrivileges(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28751, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28751, this.proxyFactory.proxyFor((Object)this.delegate.getTablePrivileges(arg0, arg1, arg2), this, this.proxyCache, methodObject28751));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28751, onErrorForAll(methodObject28751, e));
    }
  }
  
  public boolean nullsAreSortedAtStart()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28764, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28764, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedAtStart()), this, this.proxyCache, methodObject28764))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28764, onErrorForAll(methodObject28764, e))).booleanValue();
    }
  }
  
  public boolean othersUpdatesAreVisible(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28769, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28769, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.othersUpdatesAreVisible(arg0)), this, this.proxyCache, methodObject28769))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28769, onErrorForAll(methodObject28769, e))).booleanValue();
    }
  }
  
  public ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28679, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28679, this.proxyFactory.proxyFor((Object)this.delegate.getAttributes(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28679));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28679, onErrorForAll(methodObject28679, e));
    }
  }
  
  public boolean supportsUnionAll()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28845, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28845, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsUnionAll()), this, this.proxyCache, methodObject28845))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28845, onErrorForAll(methodObject28845, e))).booleanValue();
    }
  }
  
  public boolean allProceduresAreCallable()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28681, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28681, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.allProceduresAreCallable()), this, this.proxyCache, methodObject28681))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28681, onErrorForAll(methodObject28681, e))).booleanValue();
    }
  }
  
  public ResultSet getFunctions(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28708, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28708, this.proxyFactory.proxyFor((Object)this.delegate.getFunctions(arg0, arg1, arg2), this, this.proxyCache, methodObject28708));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28708, onErrorForAll(methodObject28708, e));
    }
  }
  
  public boolean supportsCatalogsInDataManipulation()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28785, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28785, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInDataManipulation()), this, this.proxyCache, methodObject28785))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28785, onErrorForAll(methodObject28785, e))).booleanValue();
    }
  }
  
  public boolean isWrapperFor(Class arg0)
    throws SQLException
  {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public RowIdLifetime getRowIdLifetime()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28740, this, new Object[0]);
      return (RowIdLifetime)postForAll(methodObject28740, this.proxyFactory.proxyFor((Object)this.delegate.getRowIdLifetime(), this, this.proxyCache, methodObject28740));
    }
    catch (SQLException e)
    {
      return (RowIdLifetime)postForAll(methodObject28740, onErrorForAll(methodObject28740, e));
    }
  }
  
  public String getDatabaseProductVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28699, this, new Object[0]);
      return (String)postForAll(methodObject28699, this.proxyFactory.proxyFor((Object)this.delegate.getDatabaseProductVersion(), this, this.proxyCache, methodObject28699));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28699, onErrorForAll(methodObject28699, e));
    }
  }
  
  public int getMaxProcedureNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28726, this, new Object[0]);
      return ((Integer)postForAll(methodObject28726, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxProcedureNameLength()), this, this.proxyCache, methodObject28726))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28726, onErrorForAll(methodObject28726, e))).intValue();
    }
  }
  
  public boolean storesMixedCaseIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28775, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28775, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesMixedCaseIdentifiers()), this, this.proxyCache, methodObject28775))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28775, onErrorForAll(methodObject28775, e))).booleanValue();
    }
  }
  
  public boolean supportsColumnAliasing()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28790, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28790, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsColumnAliasing()), this, this.proxyCache, methodObject28790))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28790, onErrorForAll(methodObject28790, e))).booleanValue();
    }
  }
  
  public boolean supportsAlterTableWithDropColumn()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28783, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28783, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsAlterTableWithDropColumn()), this, this.proxyCache, methodObject28783))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28783, onErrorForAll(methodObject28783, e))).booleanValue();
    }
  }
  
  public boolean supportsMultipleTransactions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28813, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28813, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMultipleTransactions()), this, this.proxyCache, methodObject28813))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28813, onErrorForAll(methodObject28813, e))).booleanValue();
    }
  }
  
  public ResultSet getImportedKeys(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28710, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28710, this.proxyFactory.proxyFor((Object)this.delegate.getImportedKeys(arg0, arg1, arg2), this, this.proxyCache, methodObject28710));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28710, onErrorForAll(methodObject28710, e));
    }
  }
  
  public ResultSet getFunctionColumns(String arg0, String arg1, String arg2, String arg3)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28707, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject28707, this.proxyFactory.proxyFor((Object)this.delegate.getFunctionColumns(arg0, arg1, arg2, arg3), this, this.proxyCache, methodObject28707));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28707, onErrorForAll(methodObject28707, e));
    }
  }
  
  public boolean supportsGroupBy()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28802, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28802, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGroupBy()), this, this.proxyCache, methodObject28802))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28802, onErrorForAll(methodObject28802, e))).booleanValue();
    }
  }
  
  public int getMaxColumnsInTable()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28722, this, new Object[0]);
      return ((Integer)postForAll(methodObject28722, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInTable()), this, this.proxyCache, methodObject28722))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28722, onErrorForAll(methodObject28722, e))).intValue();
    }
  }
  
  public int getMaxColumnsInOrderBy()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28720, this, new Object[0]);
      return ((Integer)postForAll(methodObject28720, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInOrderBy()), this, this.proxyCache, methodObject28720))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28720, onErrorForAll(methodObject28720, e))).intValue();
    }
  }
  
  public int getMaxConnections()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28723, this, new Object[0]);
      return ((Integer)postForAll(methodObject28723, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxConnections()), this, this.proxyCache, methodObject28723))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28723, onErrorForAll(methodObject28723, e))).intValue();
    }
  }
  
  public boolean othersDeletesAreVisible(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28767, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28767, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.othersDeletesAreVisible(arg0)), this, this.proxyCache, methodObject28767))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28767, onErrorForAll(methodObject28767, e))).booleanValue();
    }
  }
  
  public boolean allTablesAreSelectable()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28682, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28682, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.allTablesAreSelectable()), this, this.proxyCache, methodObject28682))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28682, onErrorForAll(methodObject28682, e))).booleanValue();
    }
  }
  
  public ResultSet getTableTypes()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28752, this, new Object[0]);
      return (ResultSet)postForAll(methodObject28752, this.proxyFactory.proxyFor((Object)this.delegate.getTableTypes(), this, this.proxyCache, methodObject28752));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28752, onErrorForAll(methodObject28752, e));
    }
  }
  
  public boolean nullPlusNonNullIsNull()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28762, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28762, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullPlusNonNullIsNull()), this, this.proxyCache, methodObject28762))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28762, onErrorForAll(methodObject28762, e))).booleanValue();
    }
  }
  
  public boolean supportsSubqueriesInComparisons()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28837, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28837, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInComparisons()), this, this.proxyCache, methodObject28837))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28837, onErrorForAll(methodObject28837, e))).booleanValue();
    }
  }
  
  public int getMaxIndexLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28725, this, new Object[0]);
      return ((Integer)postForAll(methodObject28725, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxIndexLength()), this, this.proxyCache, methodObject28725))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28725, onErrorForAll(methodObject28725, e))).intValue();
    }
  }
  
  public ResultSet getSuperTypes(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28749, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28749, this.proxyFactory.proxyFor((Object)this.delegate.getSuperTypes(arg0, arg1, arg2), this, this.proxyCache, methodObject28749));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28749, onErrorForAll(methodObject28749, e));
    }
  }
  
  public boolean supportsSubqueriesInQuantifieds()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28840, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28840, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInQuantifieds()), this, this.proxyCache, methodObject28840))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28840, onErrorForAll(methodObject28840, e))).booleanValue();
    }
  }
  
  public boolean supportsOpenStatementsAcrossCommit()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28818, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28818, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenStatementsAcrossCommit()), this, this.proxyCache, methodObject28818))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28818, onErrorForAll(methodObject28818, e))).booleanValue();
    }
  }
  
  public boolean supportsCatalogsInTableDefinitions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28789, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28789, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInTableDefinitions()), this, this.proxyCache, methodObject28789))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28789, onErrorForAll(methodObject28789, e))).booleanValue();
    }
  }
  
  public boolean supportsGroupByBeyondSelect()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28803, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28803, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGroupByBeyondSelect()), this, this.proxyCache, methodObject28803))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28803, onErrorForAll(methodObject28803, e))).booleanValue();
    }
  }
  
  public boolean supportsStatementPooling()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28834, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28834, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsStatementPooling()), this, this.proxyCache, methodObject28834))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28834, onErrorForAll(methodObject28834, e))).booleanValue();
    }
  }
  
  public boolean supportsDataDefinitionAndDataManipulationTransactions()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28795, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28795, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsDataDefinitionAndDataManipulationTransactions()), this, this.proxyCache, methodObject28795))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28795, onErrorForAll(methodObject28795, e))).booleanValue();
    }
  }
  
  public boolean supportsMultipleOpenResults()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28811, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28811, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMultipleOpenResults()), this, this.proxyCache, methodObject28811))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28811, onErrorForAll(methodObject28811, e))).booleanValue();
    }
  }
  
  public int getMaxColumnsInGroupBy()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28718, this, new Object[0]);
      return ((Integer)postForAll(methodObject28718, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInGroupBy()), this, this.proxyCache, methodObject28718))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28718, onErrorForAll(methodObject28718, e))).intValue();
    }
  }
  
  public int getMaxColumnNameLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28717, this, new Object[0]);
      return ((Integer)postForAll(methodObject28717, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnNameLength()), this, this.proxyCache, methodObject28717))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28717, onErrorForAll(methodObject28717, e))).intValue();
    }
  }
  
  public int getMaxStatements()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28730, this, new Object[0]);
      return ((Integer)postForAll(methodObject28730, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxStatements()), this, this.proxyCache, methodObject28730))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28730, onErrorForAll(methodObject28730, e))).intValue();
    }
  }
  
  public boolean supportsAlterTableWithAddColumn()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28782, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28782, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsAlterTableWithAddColumn()), this, this.proxyCache, methodObject28782))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28782, onErrorForAll(methodObject28782, e))).booleanValue();
    }
  }
  
  public boolean supportsGroupByUnrelated()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28804, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28804, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGroupByUnrelated()), this, this.proxyCache, methodObject28804))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28804, onErrorForAll(methodObject28804, e))).booleanValue();
    }
  }
  
  public boolean supportsANSI92EntryLevelSQL()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28779, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28779, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsANSI92EntryLevelSQL()), this, this.proxyCache, methodObject28779))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28779, onErrorForAll(methodObject28779, e))).booleanValue();
    }
  }
  
  public ResultSet getPrimaryKeys(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28735, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject28735, this.proxyFactory.proxyFor((Object)this.delegate.getPrimaryKeys(arg0, arg1, arg2), this, this.proxyCache, methodObject28735));
    }
    catch (SQLException e)
    {
      return (ResultSet)postForAll(methodObject28735, onErrorForAll(methodObject28735, e));
    }
  }
  
  public boolean deletesAreDetected(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28686, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28686, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.deletesAreDetected(arg0)), this, this.proxyCache, methodObject28686))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28686, onErrorForAll(methodObject28686, e))).booleanValue();
    }
  }
  
  public boolean supportsMinimumSQLGrammar()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28808, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28808, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMinimumSQLGrammar()), this, this.proxyCache, methodObject28808))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28808, onErrorForAll(methodObject28808, e))).booleanValue();
    }
  }
  
  public int getMaxCharLiteralLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28716, this, new Object[0]);
      return ((Integer)postForAll(methodObject28716, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxCharLiteralLength()), this, this.proxyCache, methodObject28716))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28716, onErrorForAll(methodObject28716, e))).intValue();
    }
  }
  
  public boolean ownInsertsAreVisible(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28771, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28771, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.ownInsertsAreVisible(arg0)), this, this.proxyCache, methodObject28771))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28771, onErrorForAll(methodObject28771, e))).booleanValue();
    }
  }
  
  public boolean storesLowerCaseIdentifiers()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28773, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28773, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesLowerCaseIdentifiers()), this, this.proxyCache, methodObject28773))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28773, onErrorForAll(methodObject28773, e))).booleanValue();
    }
  }
  
  public boolean supportsMultipleResultSets()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28812, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28812, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMultipleResultSets()), this, this.proxyCache, methodObject28812))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28812, onErrorForAll(methodObject28812, e))).booleanValue();
    }
  }
  
  public boolean supportsOpenCursorsAcrossRollback()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28817, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28817, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenCursorsAcrossRollback()), this, this.proxyCache, methodObject28817))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28817, onErrorForAll(methodObject28817, e))).booleanValue();
    }
  }
  
  public boolean othersInsertsAreVisible(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28768, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28768, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.othersInsertsAreVisible(arg0)), this, this.proxyCache, methodObject28768))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28768, onErrorForAll(methodObject28768, e))).booleanValue();
    }
  }
  
  public boolean supportsSelectForUpdate()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28833, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28833, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSelectForUpdate()), this, this.proxyCache, methodObject28833))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28833, onErrorForAll(methodObject28833, e))).booleanValue();
    }
  }
  
  public boolean supportsPositionedDelete()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28822, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28822, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsPositionedDelete()), this, this.proxyCache, methodObject28822))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28822, onErrorForAll(methodObject28822, e))).booleanValue();
    }
  }
  
  public boolean supportsCatalogsInProcedureCalls()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28788, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28788, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInProcedureCalls()), this, this.proxyCache, methodObject28788))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28788, onErrorForAll(methodObject28788, e))).booleanValue();
    }
  }
  
  public String getCatalogSeparator()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28689, this, new Object[0]);
      return (String)postForAll(methodObject28689, this.proxyFactory.proxyFor((Object)this.delegate.getCatalogSeparator(), this, this.proxyCache, methodObject28689));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28689, onErrorForAll(methodObject28689, e));
    }
  }
  
  public DatabaseMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28712 = DatabaseMetaData.class.getDeclaredMethod("getJDBCMajorVersion", new Class[0]);
      methodObject28816 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenCursorsAcrossCommit", new Class[0]);
      methodObject28786 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInIndexDefinitions", new Class[0]);
      methodObject28702 = DatabaseMetaData.class.getDeclaredMethod("getDriverMinorVersion", new Class[0]);
      methodObject28690 = DatabaseMetaData.class.getDeclaredMethod("getCatalogTerm", new Class[0]);
      methodObject28807 = DatabaseMetaData.class.getDeclaredMethod("supportsLimitedOuterJoins", new Class[0]);
      methodObject28744 = DatabaseMetaData.class.getDeclaredMethod("getSchemas", new Class[0]);
      methodObject28709 = DatabaseMetaData.class.getDeclaredMethod("getIdentifierQuoteString", new Class[0]);
      methodObject28824 = DatabaseMetaData.class.getDeclaredMethod("supportsResultSetConcurrency", new Class[] { Integer.TYPE, Integer.TYPE });
      methodObject28796 = DatabaseMetaData.class.getDeclaredMethod("supportsDataManipulationTransactionsOnly", new Class[0]);
      methodObject28746 = DatabaseMetaData.class.getDeclaredMethod("getSearchStringEscape", new Class[0]);
      methodObject28830 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInPrivilegeDefinitions", new Class[0]);
      methodObject28728 = DatabaseMetaData.class.getDeclaredMethod("getMaxSchemaNameLength", new Class[0]);
      methodObject28842 = DatabaseMetaData.class.getDeclaredMethod("supportsTransactionIsolationLevel", new Class[] { Integer.TYPE });
      methodObject28800 = DatabaseMetaData.class.getDeclaredMethod("supportsFullOuterJoins", new Class[0]);
      methodObject28761 = DatabaseMetaData.class.getDeclaredMethod("locatorsUpdateCopy", new Class[0]);
      methodObject28750 = DatabaseMetaData.class.getDeclaredMethod("getSystemFunctions", new Class[0]);
      methodObject28847 = DatabaseMetaData.class.getDeclaredMethod("usesLocalFilePerTable", new Class[0]);
      methodObject28741 = DatabaseMetaData.class.getDeclaredMethod("getSQLKeywords", new Class[0]);
      methodObject28757 = DatabaseMetaData.class.getDeclaredMethod("getUserName", new Class[0]);
      methodObject28733 = DatabaseMetaData.class.getDeclaredMethod("getMaxUserNameLength", new Class[0]);
      methodObject28704 = DatabaseMetaData.class.getDeclaredMethod("getDriverVersion", new Class[0]);
      methodObject28719 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInIndex", new Class[0]);
      methodObject28743 = DatabaseMetaData.class.getDeclaredMethod("getSchemaTerm", new Class[0]);
      methodObject28839 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInIns", new Class[0]);
      methodObject28826 = DatabaseMetaData.class.getDeclaredMethod("supportsResultSetType", new Class[] { Integer.TYPE });
      methodObject28831 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInProcedureCalls", new Class[0]);
      methodObject28819 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenStatementsAcrossRollback", new Class[0]);
      methodObject28703 = DatabaseMetaData.class.getDeclaredMethod("getDriverName", new Class[0]);
      methodObject28736 = DatabaseMetaData.class.getDeclaredMethod("getProcedureColumns", new Class[] { String.class, String.class, String.class, String.class });
      methodObject28738 = DatabaseMetaData.class.getDeclaredMethod("getProcedures", new Class[] { String.class, String.class, String.class });
      methodObject28683 = DatabaseMetaData.class.getDeclaredMethod("autoCommitFailureClosesAllResultSets", new Class[0]);
      methodObject28692 = DatabaseMetaData.class.getDeclaredMethod("getClientInfoProperties", new Class[0]);
      methodObject28698 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseProductName", new Class[0]);
      methodObject28841 = DatabaseMetaData.class.getDeclaredMethod("supportsTableCorrelationNames", new Class[0]);
      methodObject28696 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseMajorVersion", new Class[0]);
      methodObject28721 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInSelect", new Class[0]);
      methodObject28836 = DatabaseMetaData.class.getDeclaredMethod("supportsStoredProcedures", new Class[0]);
      methodObject28693 = DatabaseMetaData.class.getDeclaredMethod("getColumnPrivileges", new Class[] { String.class, String.class, String.class, String.class });
      methodObject28829 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInIndexDefinitions", new Class[0]);
      methodObject28700 = DatabaseMetaData.class.getDeclaredMethod("getDefaultTransactionIsolation", new Class[0]);
      methodObject28747 = DatabaseMetaData.class.getDeclaredMethod("getStringFunctions", new Class[0]);
      methodObject28687 = DatabaseMetaData.class.getDeclaredMethod("doesMaxRowSizeIncludeBlobs", new Class[0]);
      methodObject28846 = DatabaseMetaData.class.getDeclaredMethod("updatesAreDetected", new Class[] { Integer.TYPE });
      methodObject28832 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInTableDefinitions", new Class[0]);
      methodObject28805 = DatabaseMetaData.class.getDeclaredMethod("supportsIntegrityEnhancementFacility", new Class[0]);
      methodObject28684 = DatabaseMetaData.class.getDeclaredMethod("dataDefinitionCausesTransactionCommit", new Class[0]);
      methodObject28756 = DatabaseMetaData.class.getDeclaredMethod("getUDTs", new Class[] { String.class, String.class, String.class, int[].class });
      methodObject28763 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedAtEnd", new Class[0]);
      methodObject28691 = DatabaseMetaData.class.getDeclaredMethod("getCatalogs", new Class[0]);
      methodObject28701 = DatabaseMetaData.class.getDeclaredMethod("getDriverMajorVersion", new Class[0]);
      methodObject28787 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInPrivilegeDefinitions", new Class[0]);
      methodObject28760 = DatabaseMetaData.class.getDeclaredMethod("isCatalogAtStart", new Class[0]);
      methodObject28714 = DatabaseMetaData.class.getDeclaredMethod("getMaxBinaryLiteralLength", new Class[0]);
      methodObject28739 = DatabaseMetaData.class.getDeclaredMethod("getResultSetHoldability", new Class[0]);
      methodObject28777 = DatabaseMetaData.class.getDeclaredMethod("storesUpperCaseIdentifiers", new Class[0]);
      methodObject28678 = DatabaseMetaData.class.getDeclaredMethod("isReadOnly", new Class[0]);
      methodObject28797 = DatabaseMetaData.class.getDeclaredMethod("supportsDifferentTableCorrelationNames", new Class[0]);
      methodObject28753 = DatabaseMetaData.class.getDeclaredMethod("getTables", new Class[] { String.class, String.class, String.class, String[].class });
      methodObject28801 = DatabaseMetaData.class.getDeclaredMethod("supportsGetGeneratedKeys", new Class[0]);
      methodObject28731 = DatabaseMetaData.class.getDeclaredMethod("getMaxTableNameLength", new Class[0]);
      methodObject28755 = DatabaseMetaData.class.getDeclaredMethod("getTypeInfo", new Class[0]);
      methodObject28732 = DatabaseMetaData.class.getDeclaredMethod("getMaxTablesInSelect", new Class[0]);
      methodObject28844 = DatabaseMetaData.class.getDeclaredMethod("supportsUnion", new Class[0]);
      methodObject28838 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInExists", new Class[0]);
      methodObject28820 = DatabaseMetaData.class.getDeclaredMethod("supportsOrderByUnrelated", new Class[0]);
      methodObject28688 = DatabaseMetaData.class.getDeclaredMethod("getBestRowIdentifier", new Class[] { String.class, String.class, String.class, Integer.TYPE, Boolean.TYPE });
      methodObject28848 = DatabaseMetaData.class.getDeclaredMethod("usesLocalFiles", new Class[0]);
      methodObject28781 = DatabaseMetaData.class.getDeclaredMethod("supportsANSI92IntermediateSQL", new Class[0]);
      methodObject28734 = DatabaseMetaData.class.getDeclaredMethod("getNumericFunctions", new Class[0]);
      methodObject28742 = DatabaseMetaData.class.getDeclaredMethod("getSQLStateType", new Class[0]);
      methodObject28745 = DatabaseMetaData.class.getDeclaredMethod("getSchemas", new Class[] { String.class, String.class });
      methodObject28729 = DatabaseMetaData.class.getDeclaredMethod("getMaxStatementLength", new Class[0]);
      methodObject28754 = DatabaseMetaData.class.getDeclaredMethod("getTimeDateFunctions", new Class[0]);
      methodObject28695 = DatabaseMetaData.class.getDeclaredMethod("getCrossReference", new Class[] { String.class, String.class, String.class, String.class, String.class, String.class });
      methodObject28828 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInDataManipulation", new Class[0]);
      methodObject28823 = DatabaseMetaData.class.getDeclaredMethod("supportsPositionedUpdate", new Class[0]);
      methodObject28776 = DatabaseMetaData.class.getDeclaredMethod("storesMixedCaseQuotedIdentifiers", new Class[0]);
      methodObject28809 = DatabaseMetaData.class.getDeclaredMethod("supportsMixedCaseIdentifiers", new Class[0]);
      methodObject28778 = DatabaseMetaData.class.getDeclaredMethod("storesUpperCaseQuotedIdentifiers", new Class[0]);
      methodObject28748 = DatabaseMetaData.class.getDeclaredMethod("getSuperTables", new Class[] { String.class, String.class, String.class });
      methodObject28793 = DatabaseMetaData.class.getDeclaredMethod("supportsCoreSQLGrammar", new Class[0]);
      methodObject28697 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseMinorVersion", new Class[0]);
      methodObject28727 = DatabaseMetaData.class.getDeclaredMethod("getMaxRowSize", new Class[0]);
      methodObject28766 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedLow", new Class[0]);
      methodObject28814 = DatabaseMetaData.class.getDeclaredMethod("supportsNamedParameters", new Class[0]);
      methodObject28677 = DatabaseMetaData.class.getDeclaredMethod("getURL", new Class[0]);
      methodObject28770 = DatabaseMetaData.class.getDeclaredMethod("ownDeletesAreVisible", new Class[] { Integer.TYPE });
      methodObject28705 = DatabaseMetaData.class.getDeclaredMethod("getExportedKeys", new Class[] { String.class, String.class, String.class });
      methodObject28772 = DatabaseMetaData.class.getDeclaredMethod("ownUpdatesAreVisible", new Class[] { Integer.TYPE });
      methodObject28843 = DatabaseMetaData.class.getDeclaredMethod("supportsTransactions", new Class[0]);
      methodObject28825 = DatabaseMetaData.class.getDeclaredMethod("supportsResultSetHoldability", new Class[] { Integer.TYPE });
      methodObject28680 = DatabaseMetaData.class.getDeclaredMethod("getConnection", new Class[0]);
      methodObject28706 = DatabaseMetaData.class.getDeclaredMethod("getExtraNameCharacters", new Class[0]);
      methodObject28810 = DatabaseMetaData.class.getDeclaredMethod("supportsMixedCaseQuotedIdentifiers", new Class[0]);
      methodObject28774 = DatabaseMetaData.class.getDeclaredMethod("storesLowerCaseQuotedIdentifiers", new Class[0]);
      methodObject28799 = DatabaseMetaData.class.getDeclaredMethod("supportsExtendedSQLGrammar", new Class[0]);
      methodObject28791 = DatabaseMetaData.class.getDeclaredMethod("supportsConvert", new Class[0]);
      methodObject28850 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject28780 = DatabaseMetaData.class.getDeclaredMethod("supportsANSI92FullSQL", new Class[0]);
      methodObject28835 = DatabaseMetaData.class.getDeclaredMethod("supportsStoredFunctionsUsingCallSyntax", new Class[0]);
      methodObject28724 = DatabaseMetaData.class.getDeclaredMethod("getMaxCursorNameLength", new Class[0]);
      methodObject28713 = DatabaseMetaData.class.getDeclaredMethod("getJDBCMinorVersion", new Class[0]);
      methodObject28815 = DatabaseMetaData.class.getDeclaredMethod("supportsNonNullableColumns", new Class[0]);
      methodObject28758 = DatabaseMetaData.class.getDeclaredMethod("getVersionColumns", new Class[] { String.class, String.class, String.class });
      methodObject28806 = DatabaseMetaData.class.getDeclaredMethod("supportsLikeEscapeClause", new Class[0]);
      methodObject28794 = DatabaseMetaData.class.getDeclaredMethod("supportsCorrelatedSubqueries", new Class[0]);
      methodObject28737 = DatabaseMetaData.class.getDeclaredMethod("getProcedureTerm", new Class[0]);
      methodObject28765 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedHigh", new Class[0]);
      methodObject28827 = DatabaseMetaData.class.getDeclaredMethod("supportsSavepoints", new Class[0]);
      methodObject28715 = DatabaseMetaData.class.getDeclaredMethod("getMaxCatalogNameLength", new Class[0]);
      methodObject28694 = DatabaseMetaData.class.getDeclaredMethod("getColumns", new Class[] { String.class, String.class, String.class, String.class });
      methodObject28784 = DatabaseMetaData.class.getDeclaredMethod("supportsBatchUpdates", new Class[0]);
      methodObject28792 = DatabaseMetaData.class.getDeclaredMethod("supportsConvert", new Class[] { Integer.TYPE, Integer.TYPE });
      methodObject28711 = DatabaseMetaData.class.getDeclaredMethod("getIndexInfo", new Class[] { String.class, String.class, String.class, Boolean.TYPE, Boolean.TYPE });
      methodObject28798 = DatabaseMetaData.class.getDeclaredMethod("supportsExpressionsInOrderBy", new Class[0]);
      methodObject28759 = DatabaseMetaData.class.getDeclaredMethod("insertsAreDetected", new Class[] { Integer.TYPE });
      methodObject28685 = DatabaseMetaData.class.getDeclaredMethod("dataDefinitionIgnoredInTransactions", new Class[0]);
      methodObject28821 = DatabaseMetaData.class.getDeclaredMethod("supportsOuterJoins", new Class[0]);
      methodObject28751 = DatabaseMetaData.class.getDeclaredMethod("getTablePrivileges", new Class[] { String.class, String.class, String.class });
      methodObject28764 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedAtStart", new Class[0]);
      methodObject28769 = DatabaseMetaData.class.getDeclaredMethod("othersUpdatesAreVisible", new Class[] { Integer.TYPE });
      methodObject28679 = DatabaseMetaData.class.getDeclaredMethod("getAttributes", new Class[] { String.class, String.class, String.class, String.class });
      methodObject28845 = DatabaseMetaData.class.getDeclaredMethod("supportsUnionAll", new Class[0]);
      methodObject28681 = DatabaseMetaData.class.getDeclaredMethod("allProceduresAreCallable", new Class[0]);
      methodObject28708 = DatabaseMetaData.class.getDeclaredMethod("getFunctions", new Class[] { String.class, String.class, String.class });
      methodObject28785 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInDataManipulation", new Class[0]);
      methodObject28849 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject28740 = DatabaseMetaData.class.getDeclaredMethod("getRowIdLifetime", new Class[0]);
      methodObject28699 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseProductVersion", new Class[0]);
      methodObject28726 = DatabaseMetaData.class.getDeclaredMethod("getMaxProcedureNameLength", new Class[0]);
      methodObject28775 = DatabaseMetaData.class.getDeclaredMethod("storesMixedCaseIdentifiers", new Class[0]);
      methodObject28790 = DatabaseMetaData.class.getDeclaredMethod("supportsColumnAliasing", new Class[0]);
      methodObject28783 = DatabaseMetaData.class.getDeclaredMethod("supportsAlterTableWithDropColumn", new Class[0]);
      methodObject28813 = DatabaseMetaData.class.getDeclaredMethod("supportsMultipleTransactions", new Class[0]);
      methodObject28710 = DatabaseMetaData.class.getDeclaredMethod("getImportedKeys", new Class[] { String.class, String.class, String.class });
      methodObject28707 = DatabaseMetaData.class.getDeclaredMethod("getFunctionColumns", new Class[] { String.class, String.class, String.class, String.class });
      methodObject28802 = DatabaseMetaData.class.getDeclaredMethod("supportsGroupBy", new Class[0]);
      methodObject28722 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInTable", new Class[0]);
      methodObject28720 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInOrderBy", new Class[0]);
      methodObject28723 = DatabaseMetaData.class.getDeclaredMethod("getMaxConnections", new Class[0]);
      methodObject28767 = DatabaseMetaData.class.getDeclaredMethod("othersDeletesAreVisible", new Class[] { Integer.TYPE });
      methodObject28682 = DatabaseMetaData.class.getDeclaredMethod("allTablesAreSelectable", new Class[0]);
      methodObject28752 = DatabaseMetaData.class.getDeclaredMethod("getTableTypes", new Class[0]);
      methodObject28762 = DatabaseMetaData.class.getDeclaredMethod("nullPlusNonNullIsNull", new Class[0]);
      methodObject28837 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInComparisons", new Class[0]);
      methodObject28725 = DatabaseMetaData.class.getDeclaredMethod("getMaxIndexLength", new Class[0]);
      methodObject28749 = DatabaseMetaData.class.getDeclaredMethod("getSuperTypes", new Class[] { String.class, String.class, String.class });
      methodObject28840 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInQuantifieds", new Class[0]);
      methodObject28818 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenStatementsAcrossCommit", new Class[0]);
      methodObject28789 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInTableDefinitions", new Class[0]);
      methodObject28803 = DatabaseMetaData.class.getDeclaredMethod("supportsGroupByBeyondSelect", new Class[0]);
      methodObject28834 = DatabaseMetaData.class.getDeclaredMethod("supportsStatementPooling", new Class[0]);
      methodObject28795 = DatabaseMetaData.class.getDeclaredMethod("supportsDataDefinitionAndDataManipulationTransactions", new Class[0]);
      methodObject28811 = DatabaseMetaData.class.getDeclaredMethod("supportsMultipleOpenResults", new Class[0]);
      methodObject28718 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInGroupBy", new Class[0]);
      methodObject28717 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnNameLength", new Class[0]);
      methodObject28730 = DatabaseMetaData.class.getDeclaredMethod("getMaxStatements", new Class[0]);
      methodObject28782 = DatabaseMetaData.class.getDeclaredMethod("supportsAlterTableWithAddColumn", new Class[0]);
      methodObject28804 = DatabaseMetaData.class.getDeclaredMethod("supportsGroupByUnrelated", new Class[0]);
      methodObject28779 = DatabaseMetaData.class.getDeclaredMethod("supportsANSI92EntryLevelSQL", new Class[0]);
      methodObject28735 = DatabaseMetaData.class.getDeclaredMethod("getPrimaryKeys", new Class[] { String.class, String.class, String.class });
      methodObject28686 = DatabaseMetaData.class.getDeclaredMethod("deletesAreDetected", new Class[] { Integer.TYPE });
      methodObject28808 = DatabaseMetaData.class.getDeclaredMethod("supportsMinimumSQLGrammar", new Class[0]);
      methodObject28716 = DatabaseMetaData.class.getDeclaredMethod("getMaxCharLiteralLength", new Class[0]);
      methodObject28771 = DatabaseMetaData.class.getDeclaredMethod("ownInsertsAreVisible", new Class[] { Integer.TYPE });
      methodObject28773 = DatabaseMetaData.class.getDeclaredMethod("storesLowerCaseIdentifiers", new Class[0]);
      methodObject28812 = DatabaseMetaData.class.getDeclaredMethod("supportsMultipleResultSets", new Class[0]);
      methodObject28817 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenCursorsAcrossRollback", new Class[0]);
      methodObject28768 = DatabaseMetaData.class.getDeclaredMethod("othersInsertsAreVisible", new Class[] { Integer.TYPE });
      methodObject28833 = DatabaseMetaData.class.getDeclaredMethod("supportsSelectForUpdate", new Class[0]);
      methodObject28822 = DatabaseMetaData.class.getDeclaredMethod("supportsPositionedDelete", new Class[0]);
      methodObject28788 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInProcedureCalls", new Class[0]);
      methodObject28689 = DatabaseMetaData.class.getDeclaredMethod("getCatalogSeparator", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1DatabaseMetaData$$$Proxy(DatabaseMetaData paramDatabaseMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramDatabaseMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1DatabaseMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */