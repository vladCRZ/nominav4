package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ParameterMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ParameterMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements ParameterMetaData, _Proxy_
{
  private ParameterMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28853;
  private static Method methodObject28852;
  private static Method methodObject28857;
  private static Method methodObject28860;
  private static Method methodObject28855;
  private static Method methodObject28861;
  private static Method methodObject28859;
  private static Method methodObject28858;
  private static Method methodObject28856;
  private static Method methodObject28854;
  private static Method methodObject28851;
  
  public int getParameterMode(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28853, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28853, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterMode(arg0)), this, this.proxyCache, methodObject28853))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28853, onErrorForAll(methodObject28853, e))).intValue();
    }
  }
  
  public int getParameterCount()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28852, this, new Object[0]);
      return ((Integer)postForAll(methodObject28852, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterCount()), this, this.proxyCache, methodObject28852))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28852, onErrorForAll(methodObject28852, e))).intValue();
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28857, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28857, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, this.proxyCache, methodObject28857))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28857, onErrorForAll(methodObject28857, e))).intValue();
    }
  }
  
  public boolean isWrapperFor(Class arg0)
    throws SQLException
  {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getParameterTypeName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28855, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28855, this.proxyFactory.proxyFor((Object)this.delegate.getParameterTypeName(arg0), this, this.proxyCache, methodObject28855));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28855, onErrorForAll(methodObject28855, e));
    }
  }
  
  public Object unwrap(Class arg0)
    throws SQLException
  {
    return this.delegate.unwrap(arg0);
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28859, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28859, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, this.proxyCache, methodObject28859))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28859, onErrorForAll(methodObject28859, e))).booleanValue();
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28858, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28858, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, this.proxyCache, methodObject28858))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28858, onErrorForAll(methodObject28858, e))).intValue();
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28856, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28856, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, this.proxyCache, methodObject28856))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28856, onErrorForAll(methodObject28856, e))).intValue();
    }
  }
  
  public int getParameterType(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28854, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28854, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterType(arg0)), this, this.proxyCache, methodObject28854))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28854, onErrorForAll(methodObject28854, e))).intValue();
    }
  }
  
  public String getParameterClassName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28851, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28851, this.proxyFactory.proxyFor((Object)this.delegate.getParameterClassName(arg0), this, this.proxyCache, methodObject28851));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28851, onErrorForAll(methodObject28851, e));
    }
  }
  
  public ParameterMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28853 = ParameterMetaData.class.getDeclaredMethod("getParameterMode", new Class[] { Integer.TYPE });
      methodObject28852 = ParameterMetaData.class.getDeclaredMethod("getParameterCount", new Class[0]);
      methodObject28857 = ParameterMetaData.class.getDeclaredMethod("getScale", new Class[] { Integer.TYPE });
      methodObject28860 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject28855 = ParameterMetaData.class.getDeclaredMethod("getParameterTypeName", new Class[] { Integer.TYPE });
      methodObject28861 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject28859 = ParameterMetaData.class.getDeclaredMethod("isSigned", new Class[] { Integer.TYPE });
      methodObject28858 = ParameterMetaData.class.getDeclaredMethod("isNullable", new Class[] { Integer.TYPE });
      methodObject28856 = ParameterMetaData.class.getDeclaredMethod("getPrecision", new Class[] { Integer.TYPE });
      methodObject28854 = ParameterMetaData.class.getDeclaredMethod("getParameterType", new Class[] { Integer.TYPE });
      methodObject28851 = ParameterMetaData.class.getDeclaredMethod("getParameterClassName", new Class[] { Integer.TYPE });
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ParameterMetaData$$$Proxy(ParameterMetaData paramParameterMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramParameterMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ParameterMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */