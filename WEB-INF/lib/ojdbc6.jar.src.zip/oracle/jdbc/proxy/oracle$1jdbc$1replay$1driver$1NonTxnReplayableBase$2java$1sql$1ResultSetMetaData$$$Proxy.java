package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ResultSetMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements ResultSetMetaData, _Proxy_
{
  private ResultSetMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28881;
  private static Method methodObject28879;
  private static Method methodObject28864;
  private static Method methodObject28884;
  private static Method methodObject28875;
  private static Method methodObject28866;
  private static Method methodObject28863;
  private static Method methodObject28868;
  private static Method methodObject28862;
  private static Method methodObject28882;
  private static Method methodObject28883;
  private static Method methodObject28871;
  private static Method methodObject28872;
  private static Method methodObject28877;
  private static Method methodObject28870;
  private static Method methodObject28874;
  private static Method methodObject28865;
  private static Method methodObject28873;
  private static Method methodObject28880;
  private static Method methodObject28878;
  private static Method methodObject28876;
  private static Method methodObject28867;
  private static Method methodObject28869;
  
  public boolean isSearchable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28881, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28881, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSearchable(arg0)), this, this.proxyCache, methodObject28881))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28881, onErrorForAll(methodObject28881, e))).booleanValue();
    }
  }
  
  public boolean isCurrency(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28879, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28879, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCurrency(arg0)), this, this.proxyCache, methodObject28879))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28879, onErrorForAll(methodObject28879, e))).booleanValue();
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28864, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28864, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, this.proxyCache, methodObject28864))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28864, onErrorForAll(methodObject28864, e))).intValue();
    }
  }
  
  public Object unwrap(Class arg0)
    throws SQLException
  {
    return this.delegate.unwrap(arg0);
  }
  
  public String getSchemaName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28875, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28875, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(arg0), this, this.proxyCache, methodObject28875));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28875, onErrorForAll(methodObject28875, e));
    }
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28866, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28866, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, this.proxyCache, methodObject28866))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28866, onErrorForAll(methodObject28866, e))).booleanValue();
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28863, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28863, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, this.proxyCache, methodObject28863))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28863, onErrorForAll(methodObject28863, e))).intValue();
    }
  }
  
  public String getColumnClassName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28868, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28868, this.proxyFactory.proxyFor((Object)this.delegate.getColumnClassName(arg0), this, this.proxyCache, methodObject28868));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28868, onErrorForAll(methodObject28868, e));
    }
  }
  
  public boolean isReadOnly(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28862, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28862, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly(arg0)), this, this.proxyCache, methodObject28862))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28862, onErrorForAll(methodObject28862, e))).booleanValue();
    }
  }
  
  public boolean isWritable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28882, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28882, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isWritable(arg0)), this, this.proxyCache, methodObject28882))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28882, onErrorForAll(methodObject28882, e))).booleanValue();
    }
  }
  
  public boolean isWrapperFor(Class arg0)
    throws SQLException
  {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getColumnLabel(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28871, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28871, this.proxyFactory.proxyFor((Object)this.delegate.getColumnLabel(arg0), this, this.proxyCache, methodObject28871));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28871, onErrorForAll(methodObject28871, e));
    }
  }
  
  public String getColumnName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28872, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28872, this.proxyFactory.proxyFor((Object)this.delegate.getColumnName(arg0), this, this.proxyCache, methodObject28872));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28872, onErrorForAll(methodObject28872, e));
    }
  }
  
  public boolean isAutoIncrement(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28877, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28877, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isAutoIncrement(arg0)), this, this.proxyCache, methodObject28877))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28877, onErrorForAll(methodObject28877, e))).booleanValue();
    }
  }
  
  public int getColumnDisplaySize(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28870, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28870, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnDisplaySize(arg0)), this, this.proxyCache, methodObject28870))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28870, onErrorForAll(methodObject28870, e))).intValue();
    }
  }
  
  public String getColumnTypeName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28874, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28874, this.proxyFactory.proxyFor((Object)this.delegate.getColumnTypeName(arg0), this, this.proxyCache, methodObject28874));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28874, onErrorForAll(methodObject28874, e));
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28865, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28865, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, this.proxyCache, methodObject28865))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28865, onErrorForAll(methodObject28865, e))).intValue();
    }
  }
  
  public int getColumnType(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28873, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28873, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnType(arg0)), this, this.proxyCache, methodObject28873))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28873, onErrorForAll(methodObject28873, e))).intValue();
    }
  }
  
  public boolean isDefinitelyWritable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28880, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28880, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isDefinitelyWritable(arg0)), this, this.proxyCache, methodObject28880))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28880, onErrorForAll(methodObject28880, e))).booleanValue();
    }
  }
  
  public boolean isCaseSensitive(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28878, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28878, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCaseSensitive(arg0)), this, this.proxyCache, methodObject28878))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28878, onErrorForAll(methodObject28878, e))).booleanValue();
    }
  }
  
  public String getTableName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28876, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28876, this.proxyFactory.proxyFor((Object)this.delegate.getTableName(arg0), this, this.proxyCache, methodObject28876));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28876, onErrorForAll(methodObject28876, e));
    }
  }
  
  public String getCatalogName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28867, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28867, this.proxyFactory.proxyFor((Object)this.delegate.getCatalogName(arg0), this, this.proxyCache, methodObject28867));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28867, onErrorForAll(methodObject28867, e));
    }
  }
  
  public int getColumnCount()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28869, this, new Object[0]);
      return ((Integer)postForAll(methodObject28869, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnCount()), this, this.proxyCache, methodObject28869))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28869, onErrorForAll(methodObject28869, e))).intValue();
    }
  }
  
  public ResultSetMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28881 = ResultSetMetaData.class.getDeclaredMethod("isSearchable", new Class[] { Integer.TYPE });
      methodObject28879 = ResultSetMetaData.class.getDeclaredMethod("isCurrency", new Class[] { Integer.TYPE });
      methodObject28864 = ResultSetMetaData.class.getDeclaredMethod("getScale", new Class[] { Integer.TYPE });
      methodObject28884 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject28875 = ResultSetMetaData.class.getDeclaredMethod("getSchemaName", new Class[] { Integer.TYPE });
      methodObject28866 = ResultSetMetaData.class.getDeclaredMethod("isSigned", new Class[] { Integer.TYPE });
      methodObject28863 = ResultSetMetaData.class.getDeclaredMethod("getPrecision", new Class[] { Integer.TYPE });
      methodObject28868 = ResultSetMetaData.class.getDeclaredMethod("getColumnClassName", new Class[] { Integer.TYPE });
      methodObject28862 = ResultSetMetaData.class.getDeclaredMethod("isReadOnly", new Class[] { Integer.TYPE });
      methodObject28882 = ResultSetMetaData.class.getDeclaredMethod("isWritable", new Class[] { Integer.TYPE });
      methodObject28883 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject28871 = ResultSetMetaData.class.getDeclaredMethod("getColumnLabel", new Class[] { Integer.TYPE });
      methodObject28872 = ResultSetMetaData.class.getDeclaredMethod("getColumnName", new Class[] { Integer.TYPE });
      methodObject28877 = ResultSetMetaData.class.getDeclaredMethod("isAutoIncrement", new Class[] { Integer.TYPE });
      methodObject28870 = ResultSetMetaData.class.getDeclaredMethod("getColumnDisplaySize", new Class[] { Integer.TYPE });
      methodObject28874 = ResultSetMetaData.class.getDeclaredMethod("getColumnTypeName", new Class[] { Integer.TYPE });
      methodObject28865 = ResultSetMetaData.class.getDeclaredMethod("isNullable", new Class[] { Integer.TYPE });
      methodObject28873 = ResultSetMetaData.class.getDeclaredMethod("getColumnType", new Class[] { Integer.TYPE });
      methodObject28880 = ResultSetMetaData.class.getDeclaredMethod("isDefinitelyWritable", new Class[] { Integer.TYPE });
      methodObject28878 = ResultSetMetaData.class.getDeclaredMethod("isCaseSensitive", new Class[] { Integer.TYPE });
      methodObject28876 = ResultSetMetaData.class.getDeclaredMethod("getTableName", new Class[] { Integer.TYPE });
      methodObject28867 = ResultSetMetaData.class.getDeclaredMethod("getCatalogName", new Class[] { Integer.TYPE });
      methodObject28869 = ResultSetMetaData.class.getDeclaredMethod("getColumnCount", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ResultSetMetaData$$$Proxy(ResultSetMetaData paramResultSetMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramResultSetMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ResultSetMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */