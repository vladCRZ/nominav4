package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.RowId;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1RowId$$$Proxy
  extends NonTxnReplayableBase
  implements RowId, _Proxy_
{
  private RowId delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28885;
  private static Method methodObject28886;
  private static Method methodObject28887;
  private static Method methodObject28888;
  
  public boolean equals(Object arg0)
  {
    super.preForAll(methodObject28885, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject28885, this.proxyFactory.proxyFor(Boolean.valueOf(super.equals((arg0 instanceof _Proxy_) ? (Object)((_Proxy_)arg0)._getDelegate_() : arg0)), this, this.proxyCache, methodObject28885))).booleanValue();
  }
  
  public String toString()
  {
    super.preForAll(methodObject28886, this, new Object[0]);
    return (String)postForAll(methodObject28886, this.proxyFactory.proxyFor((Object)super.toString(), this, this.proxyCache, methodObject28886));
  }
  
  public int hashCode()
  {
    super.preForAll(methodObject28887, this, new Object[0]);
    return ((Integer)postForAll(methodObject28887, this.proxyFactory.proxyFor(Integer.valueOf(super.hashCode()), this, this.proxyCache, methodObject28887))).intValue();
  }
  
  public byte[] getBytes()
  {
    super.preForAll(methodObject28888, this, new Object[0]);
    return (byte[])postForAll(methodObject28888, this.proxyFactory.proxyFor((Object)this.delegate.getBytes(), this, this.proxyCache, methodObject28888));
  }
  
  public RowId _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28885 = RowId.class.getDeclaredMethod("equals", new Class[] { Object.class });
      methodObject28886 = RowId.class.getDeclaredMethod("toString", new Class[0]);
      methodObject28887 = RowId.class.getDeclaredMethod("hashCode", new Class[0]);
      methodObject28888 = RowId.class.getDeclaredMethod("getBytes", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1RowId$$$Proxy(RowId paramRowId, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramRowId;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1RowId$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */