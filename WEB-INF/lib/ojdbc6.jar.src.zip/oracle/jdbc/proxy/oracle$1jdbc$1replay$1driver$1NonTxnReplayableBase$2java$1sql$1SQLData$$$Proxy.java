package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLData$$$Proxy
  extends NonTxnReplayableBase
  implements SQLData, _Proxy_
{
  private SQLData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28891;
  private static Method methodObject28890;
  private static Method methodObject28889;
  
  public void writeSQL(SQLOutput arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28891, this, new Object[] { arg0 });
      this.delegate.writeSQL((arg0 instanceof _Proxy_) ? (SQLOutput)((_Proxy_)arg0)._getDelegate_() : arg0);
      postForAll(methodObject28891);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject28891, e);
    }
  }
  
  public void readSQL(SQLInput arg0, String arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28890, this, new Object[] { arg0, arg1 });
      this.delegate.readSQL((arg0 instanceof _Proxy_) ? (SQLInput)((_Proxy_)arg0)._getDelegate_() : arg0, arg1);
      postForAll(methodObject28890);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject28890, e);
    }
  }
  
  public String getSQLTypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28889, this, new Object[0]);
      return (String)postForAll(methodObject28889, this.proxyFactory.proxyFor((Object)this.delegate.getSQLTypeName(), this, this.proxyCache, methodObject28889));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28889, onErrorForAll(methodObject28889, e));
    }
  }
  
  public SQLData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28891 = SQLData.class.getDeclaredMethod("writeSQL", new Class[] { SQLOutput.class });
      methodObject28890 = SQLData.class.getDeclaredMethod("readSQL", new Class[] { SQLInput.class, String.class });
      methodObject28889 = SQLData.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLData$$$Proxy(SQLData paramSQLData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramSQLData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */