package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLInput$$$Proxy
  extends NonTxnReplayableBase
  implements SQLInput, _Proxy_
{
  private SQLInput delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28917;
  private static Method methodObject28898;
  private static Method methodObject28897;
  private static Method methodObject28896;
  private static Method methodObject28903;
  private static Method methodObject28918;
  private static Method methodObject28905;
  private static Method methodObject28907;
  private static Method methodObject28892;
  private static Method methodObject28911;
  private static Method methodObject28900;
  private static Method methodObject28894;
  private static Method methodObject28902;
  private static Method methodObject28914;
  private static Method methodObject28906;
  private static Method methodObject28899;
  private static Method methodObject28912;
  private static Method methodObject28893;
  private static Method methodObject28904;
  private static Method methodObject28901;
  private static Method methodObject28895;
  private static Method methodObject28909;
  private static Method methodObject28908;
  private static Method methodObject28913;
  private static Method methodObject28910;
  private static Method methodObject28915;
  private static Method methodObject28916;
  
  public URL readURL()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28917, this, new Object[0]);
      return (URL)postForAll(methodObject28917, this.proxyFactory.proxyFor((Object)this.delegate.readURL(), this, this.proxyCache, methodObject28917));
    }
    catch (SQLException e)
    {
      return (URL)postForAll(methodObject28917, onErrorForAll(methodObject28917, e));
    }
  }
  
  public float readFloat()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28898, this, new Object[0]);
      return ((Float)postForAll(methodObject28898, this.proxyFactory.proxyFor(Float.valueOf(this.delegate.readFloat()), this, this.proxyCache, methodObject28898))).floatValue();
    }
    catch (SQLException e)
    {
      return ((Float)postForAll(methodObject28898, onErrorForAll(methodObject28898, e))).floatValue();
    }
  }
  
  public short readShort()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28897, this, new Object[0]);
      return ((Short)postForAll(methodObject28897, this.proxyFactory.proxyFor(Short.valueOf(this.delegate.readShort()), this, this.proxyCache, methodObject28897))).shortValue();
    }
    catch (SQLException e)
    {
      return ((Short)postForAll(methodObject28897, onErrorForAll(methodObject28897, e))).shortValue();
    }
  }
  
  public long readLong()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28896, this, new Object[0]);
      return ((Long)postForAll(methodObject28896, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.readLong()), this, this.proxyCache, methodObject28896))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject28896, onErrorForAll(methodObject28896, e))).longValue();
    }
  }
  
  public Blob readBlob()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28903, this, new Object[0]);
      return (Blob)postForAll(methodObject28903, this.proxyFactory.proxyFor((Object)this.delegate.readBlob(), this, this.proxyCache, methodObject28903));
    }
    catch (SQLException e)
    {
      return (Blob)postForAll(methodObject28903, onErrorForAll(methodObject28903, e));
    }
  }
  
  public boolean wasNull()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28918, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28918, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.wasNull()), this, this.proxyCache, methodObject28918))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28918, onErrorForAll(methodObject28918, e))).booleanValue();
    }
  }
  
  public Reader readCharacterStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28905, this, new Object[0]);
      return (Reader)postForAll(methodObject28905, this.proxyFactory.proxyFor((Object)this.delegate.readCharacterStream(), this, this.proxyCache, methodObject28905));
    }
    catch (SQLException e)
    {
      return (Reader)postForAll(methodObject28905, onErrorForAll(methodObject28905, e));
    }
  }
  
  public Date readDate()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28907, this, new Object[0]);
      return (Date)postForAll(methodObject28907, this.proxyFactory.proxyFor((Object)this.delegate.readDate(), this, this.proxyCache, methodObject28907));
    }
    catch (SQLException e)
    {
      return (Date)postForAll(methodObject28907, onErrorForAll(methodObject28907, e));
    }
  }
  
  public int readInt()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28892, this, new Object[0]);
      return ((Integer)postForAll(methodObject28892, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.readInt()), this, this.proxyCache, methodObject28892))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28892, onErrorForAll(methodObject28892, e))).intValue();
    }
  }
  
  public Ref readRef()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28911, this, new Object[0]);
      return (Ref)postForAll(methodObject28911, this.proxyFactory.proxyFor((Object)this.delegate.readRef(), this, this.proxyCache, methodObject28911));
    }
    catch (SQLException e)
    {
      return (Ref)postForAll(methodObject28911, onErrorForAll(methodObject28911, e));
    }
  }
  
  public InputStream readAsciiStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28900, this, new Object[0]);
      return (InputStream)postForAll(methodObject28900, this.proxyFactory.proxyFor((Object)this.delegate.readAsciiStream(), this, this.proxyCache, methodObject28900));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject28900, onErrorForAll(methodObject28900, e));
    }
  }
  
  public byte[] readBytes()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28894, this, new Object[0]);
      return (byte[])postForAll(methodObject28894, this.proxyFactory.proxyFor((Object)this.delegate.readBytes(), this, this.proxyCache, methodObject28894));
    }
    catch (SQLException e)
    {
      return (byte[])postForAll(methodObject28894, onErrorForAll(methodObject28894, e));
    }
  }
  
  public InputStream readBinaryStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28902, this, new Object[0]);
      return (InputStream)postForAll(methodObject28902, this.proxyFactory.proxyFor((Object)this.delegate.readBinaryStream(), this, this.proxyCache, methodObject28902));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject28902, onErrorForAll(methodObject28902, e));
    }
  }
  
  public String readString()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28914, this, new Object[0]);
      return (String)postForAll(methodObject28914, this.proxyFactory.proxyFor((Object)this.delegate.readString(), this, this.proxyCache, methodObject28914));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28914, onErrorForAll(methodObject28914, e));
    }
  }
  
  public Clob readClob()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28906, this, new Object[0]);
      return (Clob)postForAll(methodObject28906, this.proxyFactory.proxyFor((Object)this.delegate.readClob(), this, this.proxyCache, methodObject28906));
    }
    catch (SQLException e)
    {
      return (Clob)postForAll(methodObject28906, onErrorForAll(methodObject28906, e));
    }
  }
  
  public Array readArray()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28899, this, new Object[0]);
      return (Array)postForAll(methodObject28899, this.proxyFactory.proxyFor((Object)this.delegate.readArray(), this, this.proxyCache, methodObject28899));
    }
    catch (SQLException e)
    {
      return (Array)postForAll(methodObject28899, onErrorForAll(methodObject28899, e));
    }
  }
  
  public RowId readRowId()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28912, this, new Object[0]);
      return (RowId)postForAll(methodObject28912, this.proxyFactory.proxyFor((Object)this.delegate.readRowId(), this, this.proxyCache, methodObject28912));
    }
    catch (SQLException e)
    {
      return (RowId)postForAll(methodObject28912, onErrorForAll(methodObject28912, e));
    }
  }
  
  public Object readObject()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28893, this, new Object[0]);
      return postForAll(methodObject28893, this.proxyFactory.proxyFor(this.delegate.readObject(), this, this.proxyCache, methodObject28893));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject28893, onErrorForAll(methodObject28893, e));
    }
  }
  
  public boolean readBoolean()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28904, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28904, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.readBoolean()), this, this.proxyCache, methodObject28904))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28904, onErrorForAll(methodObject28904, e))).booleanValue();
    }
  }
  
  public BigDecimal readBigDecimal()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28901, this, new Object[0]);
      return (BigDecimal)postForAll(methodObject28901, this.proxyFactory.proxyFor((Object)this.delegate.readBigDecimal(), this, this.proxyCache, methodObject28901));
    }
    catch (SQLException e)
    {
      return (BigDecimal)postForAll(methodObject28901, onErrorForAll(methodObject28901, e));
    }
  }
  
  public byte readByte()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28895, this, new Object[0]);
      return ((Byte)postForAll(methodObject28895, this.proxyFactory.proxyFor(Byte.valueOf(this.delegate.readByte()), this, this.proxyCache, methodObject28895))).byteValue();
    }
    catch (SQLException e)
    {
      return ((Byte)postForAll(methodObject28895, onErrorForAll(methodObject28895, e))).byteValue();
    }
  }
  
  public NClob readNClob()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28909, this, new Object[0]);
      return (NClob)postForAll(methodObject28909, this.proxyFactory.proxyFor((Object)this.delegate.readNClob(), this, this.proxyCache, methodObject28909));
    }
    catch (SQLException e)
    {
      return (NClob)postForAll(methodObject28909, onErrorForAll(methodObject28909, e));
    }
  }
  
  public double readDouble()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28908, this, new Object[0]);
      return ((Double)postForAll(methodObject28908, this.proxyFactory.proxyFor(Double.valueOf(this.delegate.readDouble()), this, this.proxyCache, methodObject28908))).doubleValue();
    }
    catch (SQLException e)
    {
      return ((Double)postForAll(methodObject28908, onErrorForAll(methodObject28908, e))).doubleValue();
    }
  }
  
  public SQLXML readSQLXML()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28913, this, new Object[0]);
      return (SQLXML)postForAll(methodObject28913, this.proxyFactory.proxyFor((Object)this.delegate.readSQLXML(), this, this.proxyCache, methodObject28913));
    }
    catch (SQLException e)
    {
      return (SQLXML)postForAll(methodObject28913, onErrorForAll(methodObject28913, e));
    }
  }
  
  public String readNString()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28910, this, new Object[0]);
      return (String)postForAll(methodObject28910, this.proxyFactory.proxyFor((Object)this.delegate.readNString(), this, this.proxyCache, methodObject28910));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28910, onErrorForAll(methodObject28910, e));
    }
  }
  
  public Time readTime()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28915, this, new Object[0]);
      return (Time)postForAll(methodObject28915, this.proxyFactory.proxyFor((Object)this.delegate.readTime(), this, this.proxyCache, methodObject28915));
    }
    catch (SQLException e)
    {
      return (Time)postForAll(methodObject28915, onErrorForAll(methodObject28915, e));
    }
  }
  
  public Timestamp readTimestamp()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28916, this, new Object[0]);
      return (Timestamp)postForAll(methodObject28916, this.proxyFactory.proxyFor((Object)this.delegate.readTimestamp(), this, this.proxyCache, methodObject28916));
    }
    catch (SQLException e)
    {
      return (Timestamp)postForAll(methodObject28916, onErrorForAll(methodObject28916, e));
    }
  }
  
  public SQLInput _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28917 = SQLInput.class.getDeclaredMethod("readURL", new Class[0]);
      methodObject28898 = SQLInput.class.getDeclaredMethod("readFloat", new Class[0]);
      methodObject28897 = SQLInput.class.getDeclaredMethod("readShort", new Class[0]);
      methodObject28896 = SQLInput.class.getDeclaredMethod("readLong", new Class[0]);
      methodObject28903 = SQLInput.class.getDeclaredMethod("readBlob", new Class[0]);
      methodObject28918 = SQLInput.class.getDeclaredMethod("wasNull", new Class[0]);
      methodObject28905 = SQLInput.class.getDeclaredMethod("readCharacterStream", new Class[0]);
      methodObject28907 = SQLInput.class.getDeclaredMethod("readDate", new Class[0]);
      methodObject28892 = SQLInput.class.getDeclaredMethod("readInt", new Class[0]);
      methodObject28911 = SQLInput.class.getDeclaredMethod("readRef", new Class[0]);
      methodObject28900 = SQLInput.class.getDeclaredMethod("readAsciiStream", new Class[0]);
      methodObject28894 = SQLInput.class.getDeclaredMethod("readBytes", new Class[0]);
      methodObject28902 = SQLInput.class.getDeclaredMethod("readBinaryStream", new Class[0]);
      methodObject28914 = SQLInput.class.getDeclaredMethod("readString", new Class[0]);
      methodObject28906 = SQLInput.class.getDeclaredMethod("readClob", new Class[0]);
      methodObject28899 = SQLInput.class.getDeclaredMethod("readArray", new Class[0]);
      methodObject28912 = SQLInput.class.getDeclaredMethod("readRowId", new Class[0]);
      methodObject28893 = SQLInput.class.getDeclaredMethod("readObject", new Class[0]);
      methodObject28904 = SQLInput.class.getDeclaredMethod("readBoolean", new Class[0]);
      methodObject28901 = SQLInput.class.getDeclaredMethod("readBigDecimal", new Class[0]);
      methodObject28895 = SQLInput.class.getDeclaredMethod("readByte", new Class[0]);
      methodObject28909 = SQLInput.class.getDeclaredMethod("readNClob", new Class[0]);
      methodObject28908 = SQLInput.class.getDeclaredMethod("readDouble", new Class[0]);
      methodObject28913 = SQLInput.class.getDeclaredMethod("readSQLXML", new Class[0]);
      methodObject28910 = SQLInput.class.getDeclaredMethod("readNString", new Class[0]);
      methodObject28915 = SQLInput.class.getDeclaredMethod("readTime", new Class[0]);
      methodObject28916 = SQLInput.class.getDeclaredMethod("readTimestamp", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLInput$$$Proxy(SQLInput paramSQLInput, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramSQLInput;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLInput$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */