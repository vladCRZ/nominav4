package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.util.Map;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLXML$$$Proxy
  extends NonTxnReplayableBase
  implements SQLXML, _Proxy_
{
  private SQLXML delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28921;
  private static Method methodObject28924;
  private static Method methodObject28927;
  private static Method methodObject28925;
  private static Method methodObject28923;
  private static Method methodObject28926;
  private static Method methodObject28920;
  private static Method methodObject28922;
  private static Method methodObject28919;
  
  public OutputStream setBinaryStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28921, this, new Object[0]);
      return (OutputStream)postForAll(methodObject28921, this.proxyFactory.proxyFor((Object)this.delegate.setBinaryStream(), this, this.proxyCache, methodObject28921));
    }
    catch (SQLException e)
    {
      return (OutputStream)postForAll(methodObject28921, onErrorForAll(methodObject28921, e));
    }
  }
  
  public void free()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28924, this, new Object[0]);
      this.delegate.free();
      postForAll(methodObject28924);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject28924, e);
    }
  }
  
  public Result setResult(Class arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28927, this, new Object[] { arg0 });
      return (Result)postForAll(methodObject28927, this.proxyFactory.proxyFor((Object)this.delegate.setResult(arg0), this, this.proxyCache, methodObject28927));
    }
    catch (SQLException e)
    {
      return (Result)postForAll(methodObject28927, onErrorForAll(methodObject28927, e));
    }
  }
  
  public InputStream getBinaryStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28925, this, new Object[0]);
      return (InputStream)postForAll(methodObject28925, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(), this, this.proxyCache, methodObject28925));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject28925, onErrorForAll(methodObject28925, e));
    }
  }
  
  public void setString(String arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28923, this, new Object[] { arg0 });
      this.delegate.setString(arg0);
      postForAll(methodObject28923);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject28923, e);
    }
  }
  
  public Reader getCharacterStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28926, this, new Object[0]);
      return (Reader)postForAll(methodObject28926, this.proxyFactory.proxyFor((Object)this.delegate.getCharacterStream(), this, this.proxyCache, methodObject28926));
    }
    catch (SQLException e)
    {
      return (Reader)postForAll(methodObject28926, onErrorForAll(methodObject28926, e));
    }
  }
  
  public Source getSource(Class arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28920, this, new Object[] { arg0 });
      return (Source)postForAll(methodObject28920, this.proxyFactory.proxyFor((Object)this.delegate.getSource(arg0), this, this.proxyCache, methodObject28920));
    }
    catch (SQLException e)
    {
      return (Source)postForAll(methodObject28920, onErrorForAll(methodObject28920, e));
    }
  }
  
  public Writer setCharacterStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28922, this, new Object[0]);
      return (Writer)postForAll(methodObject28922, this.proxyFactory.proxyFor((Object)this.delegate.setCharacterStream(), this, this.proxyCache, methodObject28922));
    }
    catch (SQLException e)
    {
      return (Writer)postForAll(methodObject28922, onErrorForAll(methodObject28922, e));
    }
  }
  
  public String getString()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28919, this, new Object[0]);
      return (String)postForAll(methodObject28919, this.proxyFactory.proxyFor((Object)this.delegate.getString(), this, this.proxyCache, methodObject28919));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28919, onErrorForAll(methodObject28919, e));
    }
  }
  
  public SQLXML _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28921 = SQLXML.class.getDeclaredMethod("setBinaryStream", new Class[0]);
      methodObject28924 = SQLXML.class.getDeclaredMethod("free", new Class[0]);
      methodObject28927 = SQLXML.class.getDeclaredMethod("setResult", new Class[] { Class.class });
      methodObject28925 = SQLXML.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject28923 = SQLXML.class.getDeclaredMethod("setString", new Class[] { String.class });
      methodObject28926 = SQLXML.class.getDeclaredMethod("getCharacterStream", new Class[0]);
      methodObject28920 = SQLXML.class.getDeclaredMethod("getSource", new Class[] { Class.class });
      methodObject28922 = SQLXML.class.getDeclaredMethod("setCharacterStream", new Class[0]);
      methodObject28919 = SQLXML.class.getDeclaredMethod("getString", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLXML$$$Proxy(SQLXML paramSQLXML, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramSQLXML;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLXML$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */