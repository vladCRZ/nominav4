package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ParameterMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.OracleParameterMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleParameterMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements OracleParameterMetaData, _Proxy_
{
  private OracleParameterMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28930;
  private static Method methodObject28929;
  private static Method methodObject28934;
  private static Method methodObject28937;
  private static Method methodObject28932;
  private static Method methodObject28938;
  private static Method methodObject28936;
  private static Method methodObject28935;
  private static Method methodObject28933;
  private static Method methodObject28931;
  private static Method methodObject28928;
  
  public int getParameterMode(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28930, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28930, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterMode(arg0)), this, this.proxyCache, methodObject28930))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28930, onErrorForAll(methodObject28930, e))).intValue();
    }
  }
  
  public int getParameterCount()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28929, this, new Object[0]);
      return ((Integer)postForAll(methodObject28929, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterCount()), this, this.proxyCache, methodObject28929))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28929, onErrorForAll(methodObject28929, e))).intValue();
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28934, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28934, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, this.proxyCache, methodObject28934))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28934, onErrorForAll(methodObject28934, e))).intValue();
    }
  }
  
  public boolean isWrapperFor(Class arg0)
    throws SQLException
  {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getParameterTypeName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28932, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28932, this.proxyFactory.proxyFor((Object)this.delegate.getParameterTypeName(arg0), this, this.proxyCache, methodObject28932));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28932, onErrorForAll(methodObject28932, e));
    }
  }
  
  public Object unwrap(Class arg0)
    throws SQLException
  {
    return this.delegate.unwrap(arg0);
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28936, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28936, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, this.proxyCache, methodObject28936))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28936, onErrorForAll(methodObject28936, e))).booleanValue();
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28935, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28935, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, this.proxyCache, methodObject28935))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28935, onErrorForAll(methodObject28935, e))).intValue();
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28933, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28933, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, this.proxyCache, methodObject28933))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28933, onErrorForAll(methodObject28933, e))).intValue();
    }
  }
  
  public int getParameterType(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28931, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28931, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterType(arg0)), this, this.proxyCache, methodObject28931))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28931, onErrorForAll(methodObject28931, e))).intValue();
    }
  }
  
  public String getParameterClassName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28928, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28928, this.proxyFactory.proxyFor((Object)this.delegate.getParameterClassName(arg0), this, this.proxyCache, methodObject28928));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28928, onErrorForAll(methodObject28928, e));
    }
  }
  
  public OracleParameterMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28930 = ParameterMetaData.class.getDeclaredMethod("getParameterMode", new Class[] { Integer.TYPE });
      methodObject28929 = ParameterMetaData.class.getDeclaredMethod("getParameterCount", new Class[0]);
      methodObject28934 = ParameterMetaData.class.getDeclaredMethod("getScale", new Class[] { Integer.TYPE });
      methodObject28937 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject28932 = ParameterMetaData.class.getDeclaredMethod("getParameterTypeName", new Class[] { Integer.TYPE });
      methodObject28938 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject28936 = ParameterMetaData.class.getDeclaredMethod("isSigned", new Class[] { Integer.TYPE });
      methodObject28935 = ParameterMetaData.class.getDeclaredMethod("isNullable", new Class[] { Integer.TYPE });
      methodObject28933 = ParameterMetaData.class.getDeclaredMethod("getPrecision", new Class[] { Integer.TYPE });
      methodObject28931 = ParameterMetaData.class.getDeclaredMethod("getParameterType", new Class[] { Integer.TYPE });
      methodObject28928 = ParameterMetaData.class.getDeclaredMethod("getParameterClassName", new Class[] { Integer.TYPE });
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleParameterMetaData$$$Proxy(OracleParameterMetaData paramOracleParameterMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleParameterMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleParameterMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */