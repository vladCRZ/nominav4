package oracle.jdbc.proxy;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import oracle.jdbc.OracleResultSetCache;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetCache$$$Proxy
  extends NonTxnReplayableBase
  implements OracleResultSetCache, _Proxy_
{
  private OracleResultSetCache delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28942;
  private static Method methodObject28939;
  private static Method methodObject28940;
  private static Method methodObject28943;
  private static Method methodObject28941;
  private static Method methodObject28944;
  
  public void remove(int arg0)
    throws IOException
  {
    super.preForAll(methodObject28942, this, new Object[] { Integer.valueOf(arg0) });
    this.delegate.remove(arg0);
    postForAll(methodObject28942);
  }
  
  public Object get(int arg0, int arg1)
    throws IOException
  {
    super.preForAll(methodObject28939, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
    return postForAll(methodObject28939, this.proxyFactory.proxyFor(this.delegate.get(arg0, arg1), this, this.proxyCache, methodObject28939));
  }
  
  public void put(int arg0, int arg1, Object arg2)
    throws IOException
  {
    super.preForAll(methodObject28940, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1), arg2 });
    this.delegate.put(arg0, arg1, (arg2 instanceof _Proxy_) ? (Object)((_Proxy_)arg2)._getDelegate_() : arg2);
    postForAll(methodObject28940);
  }
  
  public void remove(int arg0, int arg1)
    throws IOException
  {
    super.preForAll(methodObject28943, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
    this.delegate.remove(arg0, arg1);
    postForAll(methodObject28943);
  }
  
  public void clear()
    throws IOException
  {
    super.preForAll(methodObject28941, this, new Object[0]);
    this.delegate.clear();
    postForAll(methodObject28941);
  }
  
  public void close()
    throws IOException
  {
    super.preForAll(methodObject28944, this, new Object[0]);
    this.delegate.close();
    postForAll(methodObject28944);
  }
  
  public OracleResultSetCache _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28942 = OracleResultSetCache.class.getDeclaredMethod("remove", new Class[] { Integer.TYPE });
      methodObject28939 = OracleResultSetCache.class.getDeclaredMethod("get", new Class[] { Integer.TYPE, Integer.TYPE });
      methodObject28940 = OracleResultSetCache.class.getDeclaredMethod("put", new Class[] { Integer.TYPE, Integer.TYPE, Object.class });
      methodObject28943 = OracleResultSetCache.class.getDeclaredMethod("remove", new Class[] { Integer.TYPE, Integer.TYPE });
      methodObject28941 = OracleResultSetCache.class.getDeclaredMethod("clear", new Class[0]);
      methodObject28944 = OracleResultSetCache.class.getDeclaredMethod("close", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetCache$$$Proxy(OracleResultSetCache paramOracleResultSetCache, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleResultSetCache;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetCache$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */