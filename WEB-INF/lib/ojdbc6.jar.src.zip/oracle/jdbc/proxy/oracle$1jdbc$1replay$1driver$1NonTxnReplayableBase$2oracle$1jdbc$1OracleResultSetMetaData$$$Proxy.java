package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.OracleResultSetMetaData.SecurityAttribute;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements OracleResultSetMetaData, _Proxy_
{
  private OracleResultSetMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28966;
  private static Method methodObject28969;
  private static Method methodObject28960;
  private static Method methodObject28951;
  private static Method methodObject28953;
  private static Method methodObject28948;
  private static Method methodObject28947;
  private static Method methodObject28959;
  private static Method methodObject28962;
  private static Method methodObject28965;
  private static Method methodObject28963;
  private static Method methodObject28954;
  private static Method methodObject28952;
  private static Method methodObject28949;
  private static Method methodObject28964;
  private static Method methodObject28945;
  private static Method methodObject28946;
  private static Method methodObject28967;
  private static Method methodObject28956;
  private static Method methodObject28968;
  private static Method methodObject28957;
  private static Method methodObject28955;
  private static Method methodObject28950;
  private static Method methodObject28958;
  private static Method methodObject28961;
  
  public boolean isSearchable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28966, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28966, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSearchable(arg0)), this, this.proxyCache, methodObject28966))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28966, onErrorForAll(methodObject28966, e))).booleanValue();
    }
  }
  
  public Object unwrap(Class arg0)
    throws SQLException
  {
    return this.delegate.unwrap(arg0);
  }
  
  public String getSchemaName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28960, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28960, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(arg0), this, this.proxyCache, methodObject28960));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28960, onErrorForAll(methodObject28960, e));
    }
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28951, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28951, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, this.proxyCache, methodObject28951))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28951, onErrorForAll(methodObject28951, e))).booleanValue();
    }
  }
  
  public String getColumnClassName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28953, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28953, this.proxyFactory.proxyFor((Object)this.delegate.getColumnClassName(arg0), this, this.proxyCache, methodObject28953));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28953, onErrorForAll(methodObject28953, e));
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28948, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28948, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, this.proxyCache, methodObject28948))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28948, onErrorForAll(methodObject28948, e))).intValue();
    }
  }
  
  public boolean isReadOnly(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28947, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28947, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly(arg0)), this, this.proxyCache, methodObject28947))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28947, onErrorForAll(methodObject28947, e))).booleanValue();
    }
  }
  
  public String getColumnTypeName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28959, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28959, this.proxyFactory.proxyFor((Object)this.delegate.getColumnTypeName(arg0), this, this.proxyCache, methodObject28959));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28959, onErrorForAll(methodObject28959, e));
    }
  }
  
  public boolean isAutoIncrement(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28962, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28962, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isAutoIncrement(arg0)), this, this.proxyCache, methodObject28962))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28962, onErrorForAll(methodObject28962, e))).booleanValue();
    }
  }
  
  public boolean isDefinitelyWritable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28965, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28965, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isDefinitelyWritable(arg0)), this, this.proxyCache, methodObject28965))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28965, onErrorForAll(methodObject28965, e))).booleanValue();
    }
  }
  
  public boolean isCaseSensitive(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28963, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28963, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCaseSensitive(arg0)), this, this.proxyCache, methodObject28963))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28963, onErrorForAll(methodObject28963, e))).booleanValue();
    }
  }
  
  public int getColumnCount()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28954, this, new Object[0]);
      return ((Integer)postForAll(methodObject28954, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnCount()), this, this.proxyCache, methodObject28954))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28954, onErrorForAll(methodObject28954, e))).intValue();
    }
  }
  
  public String getCatalogName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28952, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28952, this.proxyFactory.proxyFor((Object)this.delegate.getCatalogName(arg0), this, this.proxyCache, methodObject28952));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28952, onErrorForAll(methodObject28952, e));
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28949, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28949, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, this.proxyCache, methodObject28949))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28949, onErrorForAll(methodObject28949, e))).intValue();
    }
  }
  
  public boolean isCurrency(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28964, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28964, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCurrency(arg0)), this, this.proxyCache, methodObject28964))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28964, onErrorForAll(methodObject28964, e))).booleanValue();
    }
  }
  
  public boolean isNCHAR(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28945, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28945, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isNCHAR(arg0)), this, this.proxyCache, methodObject28945))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28945, onErrorForAll(methodObject28945, e))).booleanValue();
    }
  }
  
  public OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28946, this, new Object[] { Integer.valueOf(arg0) });
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject28946, this.proxyFactory.proxyFor((Object)this.delegate.getSecurityAttribute(arg0), this, this.proxyCache, methodObject28946));
    }
    catch (SQLException e)
    {
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject28946, onErrorForAll(methodObject28946, e));
    }
  }
  
  public boolean isWritable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28967, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject28967, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isWritable(arg0)), this, this.proxyCache, methodObject28967))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28967, onErrorForAll(methodObject28967, e))).booleanValue();
    }
  }
  
  public String getColumnLabel(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28956, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28956, this.proxyFactory.proxyFor((Object)this.delegate.getColumnLabel(arg0), this, this.proxyCache, methodObject28956));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28956, onErrorForAll(methodObject28956, e));
    }
  }
  
  public boolean isWrapperFor(Class arg0)
    throws SQLException
  {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getColumnName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28957, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28957, this.proxyFactory.proxyFor((Object)this.delegate.getColumnName(arg0), this, this.proxyCache, methodObject28957));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28957, onErrorForAll(methodObject28957, e));
    }
  }
  
  public int getColumnDisplaySize(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28955, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28955, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnDisplaySize(arg0)), this, this.proxyCache, methodObject28955))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28955, onErrorForAll(methodObject28955, e))).intValue();
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28950, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28950, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, this.proxyCache, methodObject28950))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28950, onErrorForAll(methodObject28950, e))).intValue();
    }
  }
  
  public int getColumnType(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28958, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject28958, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnType(arg0)), this, this.proxyCache, methodObject28958))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28958, onErrorForAll(methodObject28958, e))).intValue();
    }
  }
  
  public String getTableName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28961, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject28961, this.proxyFactory.proxyFor((Object)this.delegate.getTableName(arg0), this, this.proxyCache, methodObject28961));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28961, onErrorForAll(methodObject28961, e));
    }
  }
  
  public OracleResultSetMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28966 = ResultSetMetaData.class.getDeclaredMethod("isSearchable", new Class[] { Integer.TYPE });
      methodObject28969 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject28960 = ResultSetMetaData.class.getDeclaredMethod("getSchemaName", new Class[] { Integer.TYPE });
      methodObject28951 = ResultSetMetaData.class.getDeclaredMethod("isSigned", new Class[] { Integer.TYPE });
      methodObject28953 = ResultSetMetaData.class.getDeclaredMethod("getColumnClassName", new Class[] { Integer.TYPE });
      methodObject28948 = ResultSetMetaData.class.getDeclaredMethod("getPrecision", new Class[] { Integer.TYPE });
      methodObject28947 = ResultSetMetaData.class.getDeclaredMethod("isReadOnly", new Class[] { Integer.TYPE });
      methodObject28959 = ResultSetMetaData.class.getDeclaredMethod("getColumnTypeName", new Class[] { Integer.TYPE });
      methodObject28962 = ResultSetMetaData.class.getDeclaredMethod("isAutoIncrement", new Class[] { Integer.TYPE });
      methodObject28965 = ResultSetMetaData.class.getDeclaredMethod("isDefinitelyWritable", new Class[] { Integer.TYPE });
      methodObject28963 = ResultSetMetaData.class.getDeclaredMethod("isCaseSensitive", new Class[] { Integer.TYPE });
      methodObject28954 = ResultSetMetaData.class.getDeclaredMethod("getColumnCount", new Class[0]);
      methodObject28952 = ResultSetMetaData.class.getDeclaredMethod("getCatalogName", new Class[] { Integer.TYPE });
      methodObject28949 = ResultSetMetaData.class.getDeclaredMethod("getScale", new Class[] { Integer.TYPE });
      methodObject28964 = ResultSetMetaData.class.getDeclaredMethod("isCurrency", new Class[] { Integer.TYPE });
      methodObject28945 = OracleResultSetMetaData.class.getDeclaredMethod("isNCHAR", new Class[] { Integer.TYPE });
      methodObject28946 = OracleResultSetMetaData.class.getDeclaredMethod("getSecurityAttribute", new Class[] { Integer.TYPE });
      methodObject28967 = ResultSetMetaData.class.getDeclaredMethod("isWritable", new Class[] { Integer.TYPE });
      methodObject28956 = ResultSetMetaData.class.getDeclaredMethod("getColumnLabel", new Class[] { Integer.TYPE });
      methodObject28968 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject28957 = ResultSetMetaData.class.getDeclaredMethod("getColumnName", new Class[] { Integer.TYPE });
      methodObject28955 = ResultSetMetaData.class.getDeclaredMethod("getColumnDisplaySize", new Class[] { Integer.TYPE });
      methodObject28950 = ResultSetMetaData.class.getDeclaredMethod("isNullable", new Class[] { Integer.TYPE });
      methodObject28958 = ResultSetMetaData.class.getDeclaredMethod("getColumnType", new Class[] { Integer.TYPE });
      methodObject28961 = ResultSetMetaData.class.getDeclaredMethod("getTableName", new Class[] { Integer.TYPE });
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetMetaData$$$Proxy(OracleResultSetMetaData paramOracleResultSetMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleResultSetMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */