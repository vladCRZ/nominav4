package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.OracleTypeMetaData.Kind;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements OracleTypeMetaData, _Proxy_
{
  private OracleTypeMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28973;
  private static Method methodObject28971;
  private static Method methodObject28974;
  private static Method methodObject28972;
  private static Method methodObject28975;
  private static Method methodObject28970;
  
  public OracleTypeMetaData.Kind getKind()
  {
    super.preForAll(methodObject28973, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject28973, this.proxyFactory.proxyFor((Object)this.delegate.getKind(), this, this.proxyCache, methodObject28973));
  }
  
  public int getTypeCode()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28971, this, new Object[0]);
      return ((Integer)postForAll(methodObject28971, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, this.proxyCache, methodObject28971))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28971, onErrorForAll(methodObject28971, e))).intValue();
    }
  }
  
  public SQLName getSQLName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28974, this, new Object[0]);
      return (SQLName)postForAll(methodObject28974, this.proxyFactory.proxyFor((Object)this.delegate.getSQLName(), this, this.proxyCache, methodObject28974));
    }
    catch (SQLException e)
    {
      return (SQLName)postForAll(methodObject28974, onErrorForAll(methodObject28974, e));
    }
  }
  
  public String getSchemaName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28972, this, new Object[0]);
      return (String)postForAll(methodObject28972, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(), this, this.proxyCache, methodObject28972));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28972, onErrorForAll(methodObject28972, e));
    }
  }
  
  public String getTypeCodeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28975, this, new Object[0]);
      return (String)postForAll(methodObject28975, this.proxyFactory.proxyFor((Object)this.delegate.getTypeCodeName(), this, this.proxyCache, methodObject28975));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28975, onErrorForAll(methodObject28975, e));
    }
  }
  
  public String getName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28970, this, new Object[0]);
      return (String)postForAll(methodObject28970, this.proxyFactory.proxyFor((Object)this.delegate.getName(), this, this.proxyCache, methodObject28970));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28970, onErrorForAll(methodObject28970, e));
    }
  }
  
  public OracleTypeMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28973 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject28971 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject28974 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject28972 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject28975 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject28970 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$$$Proxy(OracleTypeMetaData paramOracleTypeMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleTypeMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */