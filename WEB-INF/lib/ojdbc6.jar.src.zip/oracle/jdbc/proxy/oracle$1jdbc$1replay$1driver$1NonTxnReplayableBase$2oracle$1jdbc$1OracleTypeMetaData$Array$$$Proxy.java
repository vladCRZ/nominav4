package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.OracleTypeMetaData.Array;
import oracle.jdbc.OracleTypeMetaData.ArrayStorage;
import oracle.jdbc.OracleTypeMetaData.Kind;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Array$$$Proxy
  extends NonTxnReplayableBase
  implements OracleTypeMetaData.Array, _Proxy_
{
  private OracleTypeMetaData.Array delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28983;
  private static Method methodObject28981;
  private static Method methodObject28978;
  private static Method methodObject28979;
  private static Method methodObject28984;
  private static Method methodObject28982;
  private static Method methodObject28985;
  private static Method methodObject28977;
  private static Method methodObject28980;
  private static Method methodObject28976;
  
  public OracleTypeMetaData.Kind getKind()
  {
    super.preForAll(methodObject28983, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject28983, this.proxyFactory.proxyFor((Object)this.delegate.getKind(), this, this.proxyCache, methodObject28983));
  }
  
  public int getTypeCode()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28981, this, new Object[0]);
      return ((Integer)postForAll(methodObject28981, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, this.proxyCache, methodObject28981))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28981, onErrorForAll(methodObject28981, e))).intValue();
    }
  }
  
  public OracleTypeMetaData.ArrayStorage getArrayStorage()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28978, this, new Object[0]);
      return (OracleTypeMetaData.ArrayStorage)postForAll(methodObject28978, this.proxyFactory.proxyFor((Object)this.delegate.getArrayStorage(), this, this.proxyCache, methodObject28978));
    }
    catch (SQLException e)
    {
      return (OracleTypeMetaData.ArrayStorage)postForAll(methodObject28978, onErrorForAll(methodObject28978, e));
    }
  }
  
  public long getMaxLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28979, this, new Object[0]);
      return ((Long)postForAll(methodObject28979, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getMaxLength()), this, this.proxyCache, methodObject28979))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject28979, onErrorForAll(methodObject28979, e))).longValue();
    }
  }
  
  public SQLName getSQLName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28984, this, new Object[0]);
      return (SQLName)postForAll(methodObject28984, this.proxyFactory.proxyFor((Object)this.delegate.getSQLName(), this, this.proxyCache, methodObject28984));
    }
    catch (SQLException e)
    {
      return (SQLName)postForAll(methodObject28984, onErrorForAll(methodObject28984, e));
    }
  }
  
  public String getSchemaName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28982, this, new Object[0]);
      return (String)postForAll(methodObject28982, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(), this, this.proxyCache, methodObject28982));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28982, onErrorForAll(methodObject28982, e));
    }
  }
  
  public String getTypeCodeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28985, this, new Object[0]);
      return (String)postForAll(methodObject28985, this.proxyFactory.proxyFor((Object)this.delegate.getTypeCodeName(), this, this.proxyCache, methodObject28985));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28985, onErrorForAll(methodObject28985, e));
    }
  }
  
  public String getBaseName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28977, this, new Object[0]);
      return (String)postForAll(methodObject28977, this.proxyFactory.proxyFor((Object)this.delegate.getBaseName(), this, this.proxyCache, methodObject28977));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28977, onErrorForAll(methodObject28977, e));
    }
  }
  
  public String getName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28980, this, new Object[0]);
      return (String)postForAll(methodObject28980, this.proxyFactory.proxyFor((Object)this.delegate.getName(), this, this.proxyCache, methodObject28980));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28980, onErrorForAll(methodObject28980, e));
    }
  }
  
  public int getBaseType()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28976, this, new Object[0]);
      return ((Integer)postForAll(methodObject28976, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, this.proxyCache, methodObject28976))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28976, onErrorForAll(methodObject28976, e))).intValue();
    }
  }
  
  public OracleTypeMetaData.Array _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28983 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject28981 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject28978 = OracleTypeMetaData.Array.class.getDeclaredMethod("getArrayStorage", new Class[0]);
      methodObject28979 = OracleTypeMetaData.Array.class.getDeclaredMethod("getMaxLength", new Class[0]);
      methodObject28984 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject28982 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject28985 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject28977 = OracleTypeMetaData.Array.class.getDeclaredMethod("getBaseName", new Class[0]);
      methodObject28980 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
      methodObject28976 = OracleTypeMetaData.Array.class.getDeclaredMethod("getBaseType", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Array$$$Proxy(OracleTypeMetaData.Array paramArray, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Array$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */