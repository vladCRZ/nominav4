package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.OracleTypeMetaData.Kind;
import oracle.jdbc.OracleTypeMetaData.Opaque;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Opaque$$$Proxy
  extends NonTxnReplayableBase
  implements OracleTypeMetaData.Opaque, _Proxy_
{
  private OracleTypeMetaData.Opaque delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject28988;
  private static Method methodObject28994;
  private static Method methodObject28987;
  private static Method methodObject28992;
  private static Method methodObject28990;
  private static Method methodObject28989;
  private static Method methodObject28986;
  private static Method methodObject28995;
  private static Method methodObject28993;
  private static Method methodObject28996;
  private static Method methodObject28991;
  
  public boolean isModeledInC()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28988, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28988, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isModeledInC()), this, this.proxyCache, methodObject28988))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28988, onErrorForAll(methodObject28988, e))).booleanValue();
    }
  }
  
  public OracleTypeMetaData.Kind getKind()
  {
    super.preForAll(methodObject28994, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject28994, this.proxyFactory.proxyFor((Object)this.delegate.getKind(), this, this.proxyCache, methodObject28994));
  }
  
  public boolean isTrustedLibrary()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28987, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28987, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isTrustedLibrary()), this, this.proxyCache, methodObject28987))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28987, onErrorForAll(methodObject28987, e))).booleanValue();
    }
  }
  
  public int getTypeCode()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28992, this, new Object[0]);
      return ((Integer)postForAll(methodObject28992, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, this.proxyCache, methodObject28992))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28992, onErrorForAll(methodObject28992, e))).intValue();
    }
  }
  
  public boolean hasFixedSize()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28990, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28990, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.hasFixedSize()), this, this.proxyCache, methodObject28990))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28990, onErrorForAll(methodObject28990, e))).booleanValue();
    }
  }
  
  public boolean hasUnboundedSize()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28989, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28989, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.hasUnboundedSize()), this, this.proxyCache, methodObject28989))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28989, onErrorForAll(methodObject28989, e))).booleanValue();
    }
  }
  
  public long getMaxLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28986, this, new Object[0]);
      return ((Long)postForAll(methodObject28986, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getMaxLength()), this, this.proxyCache, methodObject28986))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject28986, onErrorForAll(methodObject28986, e))).longValue();
    }
  }
  
  public SQLName getSQLName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28995, this, new Object[0]);
      return (SQLName)postForAll(methodObject28995, this.proxyFactory.proxyFor((Object)this.delegate.getSQLName(), this, this.proxyCache, methodObject28995));
    }
    catch (SQLException e)
    {
      return (SQLName)postForAll(methodObject28995, onErrorForAll(methodObject28995, e));
    }
  }
  
  public String getSchemaName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28993, this, new Object[0]);
      return (String)postForAll(methodObject28993, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(), this, this.proxyCache, methodObject28993));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28993, onErrorForAll(methodObject28993, e));
    }
  }
  
  public String getTypeCodeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28996, this, new Object[0]);
      return (String)postForAll(methodObject28996, this.proxyFactory.proxyFor((Object)this.delegate.getTypeCodeName(), this, this.proxyCache, methodObject28996));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28996, onErrorForAll(methodObject28996, e));
    }
  }
  
  public String getName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28991, this, new Object[0]);
      return (String)postForAll(methodObject28991, this.proxyFactory.proxyFor((Object)this.delegate.getName(), this, this.proxyCache, methodObject28991));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject28991, onErrorForAll(methodObject28991, e));
    }
  }
  
  public OracleTypeMetaData.Opaque _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject28988 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("isModeledInC", new Class[0]);
      methodObject28994 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject28987 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("isTrustedLibrary", new Class[0]);
      methodObject28992 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject28990 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("hasFixedSize", new Class[0]);
      methodObject28989 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("hasUnboundedSize", new Class[0]);
      methodObject28986 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("getMaxLength", new Class[0]);
      methodObject28995 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject28993 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject28996 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject28991 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Opaque$$$Proxy(OracleTypeMetaData.Opaque paramOpaque, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOpaque;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Opaque$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */