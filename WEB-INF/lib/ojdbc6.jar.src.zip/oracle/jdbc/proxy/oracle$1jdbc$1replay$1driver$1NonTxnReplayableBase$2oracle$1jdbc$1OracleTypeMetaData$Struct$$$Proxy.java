package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.OracleTypeMetaData.Kind;
import oracle.jdbc.OracleTypeMetaData.Struct;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Struct$$$Proxy
  extends NonTxnReplayableBase
  implements OracleTypeMetaData.Struct, _Proxy_
{
  private OracleTypeMetaData.Struct delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject29005;
  private static Method methodObject29010;
  private static Method methodObject29011;
  private static Method methodObject29000;
  private static Method methodObject29009;
  private static Method methodObject29001;
  private static Method methodObject29007;
  private static Method methodObject29002;
  private static Method methodObject29003;
  private static Method methodObject29008;
  private static Method methodObject28998;
  private static Method methodObject28999;
  private static Method methodObject28997;
  private static Method methodObject29006;
  private static Method methodObject29004;
  
  public String[] getSubtypeNames()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29005, this, new Object[0]);
      return (String[])postForAll(methodObject29005, this.proxyFactory.proxyFor((Object)this.delegate.getSubtypeNames(), this, this.proxyCache, methodObject29005));
    }
    catch (SQLException e)
    {
      return (String[])postForAll(methodObject29005, onErrorForAll(methodObject29005, e));
    }
  }
  
  public SQLName getSQLName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29010, this, new Object[0]);
      return (SQLName)postForAll(methodObject29010, this.proxyFactory.proxyFor((Object)this.delegate.getSQLName(), this, this.proxyCache, methodObject29010));
    }
    catch (SQLException e)
    {
      return (SQLName)postForAll(methodObject29010, onErrorForAll(methodObject29010, e));
    }
  }
  
  public String getTypeCodeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29011, this, new Object[0]);
      return (String)postForAll(methodObject29011, this.proxyFactory.proxyFor((Object)this.delegate.getTypeCodeName(), this, this.proxyCache, methodObject29011));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29011, onErrorForAll(methodObject29011, e));
    }
  }
  
  public ResultSetMetaData getMetaData()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29000, this, new Object[0]);
      return (ResultSetMetaData)postForAll(methodObject29000, this.proxyFactory.proxyFor((Object)this.delegate.getMetaData(), this, this.proxyCache, methodObject29000));
    }
    catch (SQLException e)
    {
      return (ResultSetMetaData)postForAll(methodObject29000, onErrorForAll(methodObject29000, e));
    }
  }
  
  public OracleTypeMetaData.Kind getKind()
  {
    super.preForAll(methodObject29009, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject29009, this.proxyFactory.proxyFor((Object)this.delegate.getKind(), this, this.proxyCache, methodObject29009));
  }
  
  public boolean isFinalType()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29001, this, new Object[0]);
      return ((Boolean)postForAll(methodObject29001, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isFinalType()), this, this.proxyCache, methodObject29001))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29001, onErrorForAll(methodObject29001, e))).booleanValue();
    }
  }
  
  public int getTypeCode()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29007, this, new Object[0]);
      return ((Integer)postForAll(methodObject29007, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, this.proxyCache, methodObject29007))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29007, onErrorForAll(methodObject29007, e))).intValue();
    }
  }
  
  public boolean isSubtype()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29002, this, new Object[0]);
      return ((Boolean)postForAll(methodObject29002, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSubtype()), this, this.proxyCache, methodObject29002))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29002, onErrorForAll(methodObject29002, e))).booleanValue();
    }
  }
  
  public String getSupertypeName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29003, this, new Object[0]);
      return (String)postForAll(methodObject29003, this.proxyFactory.proxyFor((Object)this.delegate.getSupertypeName(), this, this.proxyCache, methodObject29003));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29003, onErrorForAll(methodObject29003, e));
    }
  }
  
  public String getSchemaName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29008, this, new Object[0]);
      return (String)postForAll(methodObject29008, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(), this, this.proxyCache, methodObject29008));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29008, onErrorForAll(methodObject29008, e));
    }
  }
  
  public boolean isInstantiable()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28998, this, new Object[0]);
      return ((Boolean)postForAll(methodObject28998, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isInstantiable()), this, this.proxyCache, methodObject28998))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject28998, onErrorForAll(methodObject28998, e))).booleanValue();
    }
  }
  
  public int getTypeVersion()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28999, this, new Object[0]);
      return ((Integer)postForAll(methodObject28999, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeVersion()), this, this.proxyCache, methodObject28999))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28999, onErrorForAll(methodObject28999, e))).intValue();
    }
  }
  
  public int getLength()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject28997, this, new Object[0]);
      return ((Integer)postForAll(methodObject28997, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getLength()), this, this.proxyCache, methodObject28997))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject28997, onErrorForAll(methodObject28997, e))).intValue();
    }
  }
  
  public String getName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29006, this, new Object[0]);
      return (String)postForAll(methodObject29006, this.proxyFactory.proxyFor((Object)this.delegate.getName(), this, this.proxyCache, methodObject29006));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29006, onErrorForAll(methodObject29006, e));
    }
  }
  
  public int getLocalAttributeCount()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29004, this, new Object[0]);
      return ((Integer)postForAll(methodObject29004, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getLocalAttributeCount()), this, this.proxyCache, methodObject29004))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29004, onErrorForAll(methodObject29004, e))).intValue();
    }
  }
  
  public OracleTypeMetaData.Struct _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject29005 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getSubtypeNames", new Class[0]);
      methodObject29010 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject29011 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject29000 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getMetaData", new Class[0]);
      methodObject29009 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject29001 = OracleTypeMetaData.Struct.class.getDeclaredMethod("isFinalType", new Class[0]);
      methodObject29007 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject29002 = OracleTypeMetaData.Struct.class.getDeclaredMethod("isSubtype", new Class[0]);
      methodObject29003 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getSupertypeName", new Class[0]);
      methodObject29008 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject28998 = OracleTypeMetaData.Struct.class.getDeclaredMethod("isInstantiable", new Class[0]);
      methodObject28999 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getTypeVersion", new Class[0]);
      methodObject28997 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject29006 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
      methodObject29004 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getLocalAttributeCount", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Struct$$$Proxy(OracleTypeMetaData.Struct paramStruct, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramStruct;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Struct$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */