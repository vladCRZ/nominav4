package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleDatumWithConnection$$$Proxy
  extends NonTxnReplayableBase
  implements OracleDatumWithConnection, _Proxy_
{
  private OracleDatumWithConnection delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject29026;
  private static Method methodObject29041;
  private static Method methodObject29039;
  private static Method methodObject29013;
  private static Method methodObject29014;
  private static Method methodObject29032;
  private static Method methodObject29023;
  private static Method methodObject29035;
  private static Method methodObject29042;
  private static Method methodObject29030;
  private static Method methodObject29031;
  private static Method methodObject29018;
  private static Method methodObject29040;
  private static Method methodObject29025;
  private static Method methodObject29037;
  private static Method methodObject29038;
  private static Method methodObject29034;
  private static Method methodObject29022;
  private static Method methodObject29028;
  private static Method methodObject29016;
  private static Method methodObject29027;
  private static Method methodObject29021;
  private static Method methodObject29036;
  private static Method methodObject29019;
  private static Method methodObject29015;
  private static Method methodObject29017;
  private static Method methodObject29033;
  private static Method methodObject29024;
  private static Method methodObject29012;
  private static Method methodObject29029;
  private static Method methodObject29020;
  
  public String stringValue(Connection arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29026, this, new Object[] { arg0 });
      return (String)postForAll(methodObject29026, this.proxyFactory.proxyFor((Object)this.delegate.stringValue((arg0 instanceof _Proxy_) ? (Connection)((_Proxy_)arg0)._getDelegate_() : arg0), this, this.proxyCache, methodObject29026));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29026, onErrorForAll(methodObject29026, e));
    }
  }
  
  public oracle.jdbc.internal.OracleConnection getInternalConnection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29041, this, new Object[0]);
      return (oracle.jdbc.internal.OracleConnection)postForAll(methodObject29041, this.proxyFactory.proxyFor((Object)this.delegate.getInternalConnection(), this, this.proxyCache, methodObject29041));
    }
    catch (SQLException e)
    {
      return (oracle.jdbc.internal.OracleConnection)postForAll(methodObject29041, onErrorForAll(methodObject29041, e));
    }
  }
  
  public Connection getJavaSqlConnection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29039, this, new Object[0]);
      return (Connection)postForAll(methodObject29039, this.proxyFactory.proxyFor((Object)this.delegate.getJavaSqlConnection(), this, this.proxyCache, methodObject29039));
    }
    catch (SQLException e)
    {
      return (Connection)postForAll(methodObject29039, onErrorForAll(methodObject29039, e));
    }
  }
  
  public byte[] getBytes()
  {
    super.preForAll(methodObject29013, this, new Object[0]);
    return (byte[])postForAll(methodObject29013, this.proxyFactory.proxyFor((Object)this.delegate.getBytes(), this, this.proxyCache, methodObject29013));
  }
  
  public boolean booleanValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29014, this, new Object[0]);
      return ((Boolean)postForAll(methodObject29014, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.booleanValue()), this, this.proxyCache, methodObject29014))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29014, onErrorForAll(methodObject29014, e))).booleanValue();
    }
  }
  
  public Timestamp timestampValue(Calendar arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29032, this, new Object[] { arg0 });
      return (Timestamp)postForAll(methodObject29032, this.proxyFactory.proxyFor((Object)this.delegate.timestampValue(arg0), this, this.proxyCache, methodObject29032));
    }
    catch (SQLException e)
    {
      return (Timestamp)postForAll(methodObject29032, onErrorForAll(methodObject29032, e));
    }
  }
  
  public void setShareBytes(byte[] arg0)
  {
    super.preForAll(methodObject29023, this, new Object[] { arg0 });
    this.delegate.setShareBytes(arg0);
    postForAll(methodObject29023);
  }
  
  public InputStream binaryStreamValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29035, this, new Object[0]);
      return (InputStream)postForAll(methodObject29035, this.proxyFactory.proxyFor((Object)this.delegate.binaryStreamValue(), this, this.proxyCache, methodObject29035));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject29035, onErrorForAll(methodObject29035, e));
    }
  }
  
  public void setPhysicalConnectionOf(Connection arg0)
  {
    super.preForAll(methodObject29042, this, new Object[] { arg0 });
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? (Connection)((_Proxy_)arg0)._getDelegate_() : arg0);
    postForAll(methodObject29042);
  }
  
  public Time timeValue(Calendar arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29030, this, new Object[] { arg0 });
      return (Time)postForAll(methodObject29030, this.proxyFactory.proxyFor((Object)this.delegate.timeValue(arg0), this, this.proxyCache, methodObject29030));
    }
    catch (SQLException e)
    {
      return (Time)postForAll(methodObject29030, onErrorForAll(methodObject29030, e));
    }
  }
  
  public Timestamp timestampValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29031, this, new Object[0]);
      return (Timestamp)postForAll(methodObject29031, this.proxyFactory.proxyFor((Object)this.delegate.timestampValue(), this, this.proxyCache, methodObject29031));
    }
    catch (SQLException e)
    {
      return (Timestamp)postForAll(methodObject29031, onErrorForAll(methodObject29031, e));
    }
  }
  
  public int intValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29018, this, new Object[0]);
      return ((Integer)postForAll(methodObject29018, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.intValue()), this, this.proxyCache, methodObject29018))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29018, onErrorForAll(methodObject29018, e))).intValue();
    }
  }
  
  public oracle.jdbc.OracleConnection getOracleConnection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29040, this, new Object[0]);
      return (oracle.jdbc.OracleConnection)postForAll(methodObject29040, this.proxyFactory.proxyFor((Object)this.delegate.getOracleConnection(), this, this.proxyCache, methodObject29040));
    }
    catch (SQLException e)
    {
      return (oracle.jdbc.OracleConnection)postForAll(methodObject29040, onErrorForAll(methodObject29040, e));
    }
  }
  
  public String stringValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29025, this, new Object[0]);
      return (String)postForAll(methodObject29025, this.proxyFactory.proxyFor((Object)this.delegate.stringValue(), this, this.proxyCache, methodObject29025));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29025, onErrorForAll(methodObject29025, e));
    }
  }
  
  public Object toJdbc()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29037, this, new Object[0]);
      return postForAll(methodObject29037, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, this.proxyCache, methodObject29037));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject29037, onErrorForAll(methodObject29037, e));
    }
  }
  
  public Object makeJdbcArray(int arg0)
  {
    super.preForAll(methodObject29038, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject29038, this.proxyFactory.proxyFor(this.delegate.makeJdbcArray(arg0), this, this.proxyCache, methodObject29038));
  }
  
  public InputStream asciiStreamValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29034, this, new Object[0]);
      return (InputStream)postForAll(methodObject29034, this.proxyFactory.proxyFor((Object)this.delegate.asciiStreamValue(), this, this.proxyCache, methodObject29034));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject29034, onErrorForAll(methodObject29034, e));
    }
  }
  
  public byte[] shareBytes()
  {
    super.preForAll(methodObject29022, this, new Object[0]);
    return (byte[])postForAll(methodObject29022, this.proxyFactory.proxyFor((Object)this.delegate.shareBytes(), this, this.proxyCache, methodObject29022));
  }
  
  public Date dateValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29028, this, new Object[0]);
      return (Date)postForAll(methodObject29028, this.proxyFactory.proxyFor((Object)this.delegate.dateValue(), this, this.proxyCache, methodObject29028));
    }
    catch (SQLException e)
    {
      return (Date)postForAll(methodObject29028, onErrorForAll(methodObject29028, e));
    }
  }
  
  public double doubleValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29016, this, new Object[0]);
      return ((Double)postForAll(methodObject29016, this.proxyFactory.proxyFor(Double.valueOf(this.delegate.doubleValue()), this, this.proxyCache, methodObject29016))).doubleValue();
    }
    catch (SQLException e)
    {
      return ((Double)postForAll(methodObject29016, onErrorForAll(methodObject29016, e))).doubleValue();
    }
  }
  
  public BigDecimal bigDecimalValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29027, this, new Object[0]);
      return (BigDecimal)postForAll(methodObject29027, this.proxyFactory.proxyFor((Object)this.delegate.bigDecimalValue(), this, this.proxyCache, methodObject29027));
    }
    catch (SQLException e)
    {
      return (BigDecimal)postForAll(methodObject29027, onErrorForAll(methodObject29027, e));
    }
  }
  
  public void setBytes(byte[] arg0)
  {
    super.preForAll(methodObject29021, this, new Object[] { arg0 });
    this.delegate.setBytes(arg0);
    postForAll(methodObject29021);
  }
  
  public boolean isConvertibleTo(Class arg0)
  {
    super.preForAll(methodObject29036, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject29036, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isConvertibleTo(arg0)), this, this.proxyCache, methodObject29036))).booleanValue();
  }
  
  public long longValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29019, this, new Object[0]);
      return ((Long)postForAll(methodObject29019, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.longValue()), this, this.proxyCache, methodObject29019))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject29019, onErrorForAll(methodObject29019, e))).longValue();
    }
  }
  
  public byte byteValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29015, this, new Object[0]);
      return ((Byte)postForAll(methodObject29015, this.proxyFactory.proxyFor(Byte.valueOf(this.delegate.byteValue()), this, this.proxyCache, methodObject29015))).byteValue();
    }
    catch (SQLException e)
    {
      return ((Byte)postForAll(methodObject29015, onErrorForAll(methodObject29015, e))).byteValue();
    }
  }
  
  public float floatValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29017, this, new Object[0]);
      return ((Float)postForAll(methodObject29017, this.proxyFactory.proxyFor(Float.valueOf(this.delegate.floatValue()), this, this.proxyCache, methodObject29017))).floatValue();
    }
    catch (SQLException e)
    {
      return ((Float)postForAll(methodObject29017, onErrorForAll(methodObject29017, e))).floatValue();
    }
  }
  
  public Reader characterStreamValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29033, this, new Object[0]);
      return (Reader)postForAll(methodObject29033, this.proxyFactory.proxyFor((Object)this.delegate.characterStreamValue(), this, this.proxyCache, methodObject29033));
    }
    catch (SQLException e)
    {
      return (Reader)postForAll(methodObject29033, onErrorForAll(methodObject29033, e));
    }
  }
  
  public InputStream getStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29024, this, new Object[0]);
      return (InputStream)postForAll(methodObject29024, this.proxyFactory.proxyFor((Object)this.delegate.getStream(), this, this.proxyCache, methodObject29024));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject29024, onErrorForAll(methodObject29024, e));
    }
  }
  
  public long getLength()
  {
    super.preForAll(methodObject29012, this, new Object[0]);
    return ((Long)postForAll(methodObject29012, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getLength()), this, this.proxyCache, methodObject29012))).longValue();
  }
  
  public Time timeValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29029, this, new Object[0]);
      return (Time)postForAll(methodObject29029, this.proxyFactory.proxyFor((Object)this.delegate.timeValue(), this, this.proxyCache, methodObject29029));
    }
    catch (SQLException e)
    {
      return (Time)postForAll(methodObject29029, onErrorForAll(methodObject29029, e));
    }
  }
  
  public oracle.jdbc.driver.OracleConnection getConnection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29020, this, new Object[0]);
      return (oracle.jdbc.driver.OracleConnection)postForAll(methodObject29020, this.proxyFactory.proxyFor((Object)this.delegate.getConnection(), this, this.proxyCache, methodObject29020));
    }
    catch (SQLException e)
    {
      return (oracle.jdbc.driver.OracleConnection)postForAll(methodObject29020, onErrorForAll(methodObject29020, e));
    }
  }
  
  public OracleDatumWithConnection _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject29026 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject29041 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject29039 = OracleDatumWithConnection.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject29013 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject29014 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject29032 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject29023 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject29035 = OracleDatumWithConnection.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject29042 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject29030 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject29031 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject29018 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject29040 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject29025 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject29037 = OracleDatumWithConnection.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject29038 = OracleDatumWithConnection.class.getDeclaredMethod("makeJdbcArray", new Class[] { Integer.TYPE });
      methodObject29034 = OracleDatumWithConnection.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject29022 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject29028 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject29016 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject29027 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject29021 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject29036 = OracleDatumWithConnection.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject29019 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject29015 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject29017 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject29033 = OracleDatumWithConnection.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject29024 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject29012 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject29029 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject29020 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleDatumWithConnection$$$Proxy(OracleDatumWithConnection paramOracleDatumWithConnection, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleDatumWithConnection;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleDatumWithConnection$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */