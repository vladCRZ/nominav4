package oracle.jdbc.proxy;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetCache$$$Proxy
  extends NonTxnReplayableBase
  implements oracle.jdbc.internal.OracleResultSetCache, _Proxy_
{
  private oracle.jdbc.internal.OracleResultSetCache delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject29046;
  private static Method methodObject29043;
  private static Method methodObject29044;
  private static Method methodObject29047;
  private static Method methodObject29045;
  private static Method methodObject29048;
  
  public void remove(int arg0)
    throws IOException
  {
    super.preForAll(methodObject29046, this, new Object[] { Integer.valueOf(arg0) });
    this.delegate.remove(arg0);
    postForAll(methodObject29046);
  }
  
  public Object get(int arg0, int arg1)
    throws IOException
  {
    super.preForAll(methodObject29043, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
    return postForAll(methodObject29043, this.proxyFactory.proxyFor(this.delegate.get(arg0, arg1), this, this.proxyCache, methodObject29043));
  }
  
  public void put(int arg0, int arg1, Object arg2)
    throws IOException
  {
    super.preForAll(methodObject29044, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1), arg2 });
    this.delegate.put(arg0, arg1, (arg2 instanceof _Proxy_) ? (Object)((_Proxy_)arg2)._getDelegate_() : arg2);
    postForAll(methodObject29044);
  }
  
  public void remove(int arg0, int arg1)
    throws IOException
  {
    super.preForAll(methodObject29047, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
    this.delegate.remove(arg0, arg1);
    postForAll(methodObject29047);
  }
  
  public void clear()
    throws IOException
  {
    super.preForAll(methodObject29045, this, new Object[0]);
    this.delegate.clear();
    postForAll(methodObject29045);
  }
  
  public void close()
    throws IOException
  {
    super.preForAll(methodObject29048, this, new Object[0]);
    this.delegate.close();
    postForAll(methodObject29048);
  }
  
  public oracle.jdbc.internal.OracleResultSetCache _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject29046 = oracle.jdbc.OracleResultSetCache.class.getDeclaredMethod("remove", new Class[] { Integer.TYPE });
      methodObject29043 = oracle.jdbc.OracleResultSetCache.class.getDeclaredMethod("get", new Class[] { Integer.TYPE, Integer.TYPE });
      methodObject29044 = oracle.jdbc.OracleResultSetCache.class.getDeclaredMethod("put", new Class[] { Integer.TYPE, Integer.TYPE, Object.class });
      methodObject29047 = oracle.jdbc.OracleResultSetCache.class.getDeclaredMethod("remove", new Class[] { Integer.TYPE, Integer.TYPE });
      methodObject29045 = oracle.jdbc.OracleResultSetCache.class.getDeclaredMethod("clear", new Class[0]);
      methodObject29048 = oracle.jdbc.OracleResultSetCache.class.getDeclaredMethod("close", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetCache$$$Proxy(oracle.jdbc.internal.OracleResultSetCache paramOracleResultSetCache, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleResultSetCache;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetCache$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */