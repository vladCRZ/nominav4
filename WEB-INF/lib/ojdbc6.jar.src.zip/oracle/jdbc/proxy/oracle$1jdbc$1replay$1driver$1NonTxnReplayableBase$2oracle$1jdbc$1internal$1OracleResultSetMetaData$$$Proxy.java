package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.OracleResultSetMetaData.SecurityAttribute;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetMetaData$$$Proxy
  extends NonTxnReplayableBase
  implements oracle.jdbc.internal.OracleResultSetMetaData, _Proxy_
{
  private oracle.jdbc.internal.OracleResultSetMetaData delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject29070;
  private static Method methodObject29073;
  private static Method methodObject29064;
  private static Method methodObject29055;
  private static Method methodObject29057;
  private static Method methodObject29052;
  private static Method methodObject29051;
  private static Method methodObject29063;
  private static Method methodObject29066;
  private static Method methodObject29069;
  private static Method methodObject29067;
  private static Method methodObject29058;
  private static Method methodObject29056;
  private static Method methodObject29053;
  private static Method methodObject29068;
  private static Method methodObject29049;
  private static Method methodObject29050;
  private static Method methodObject29071;
  private static Method methodObject29060;
  private static Method methodObject29072;
  private static Method methodObject29061;
  private static Method methodObject29059;
  private static Method methodObject29054;
  private static Method methodObject29062;
  private static Method methodObject29065;
  
  public boolean isSearchable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29070, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29070, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSearchable(arg0)), this, this.proxyCache, methodObject29070))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29070, onErrorForAll(methodObject29070, e))).booleanValue();
    }
  }
  
  public Object unwrap(Class arg0)
    throws SQLException
  {
    return this.delegate.unwrap(arg0);
  }
  
  public String getSchemaName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29064, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29064, this.proxyFactory.proxyFor((Object)this.delegate.getSchemaName(arg0), this, this.proxyCache, methodObject29064));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29064, onErrorForAll(methodObject29064, e));
    }
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29055, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29055, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, this.proxyCache, methodObject29055))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29055, onErrorForAll(methodObject29055, e))).booleanValue();
    }
  }
  
  public String getColumnClassName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29057, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29057, this.proxyFactory.proxyFor((Object)this.delegate.getColumnClassName(arg0), this, this.proxyCache, methodObject29057));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29057, onErrorForAll(methodObject29057, e));
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29052, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject29052, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, this.proxyCache, methodObject29052))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29052, onErrorForAll(methodObject29052, e))).intValue();
    }
  }
  
  public boolean isReadOnly(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29051, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29051, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly(arg0)), this, this.proxyCache, methodObject29051))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29051, onErrorForAll(methodObject29051, e))).booleanValue();
    }
  }
  
  public String getColumnTypeName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29063, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29063, this.proxyFactory.proxyFor((Object)this.delegate.getColumnTypeName(arg0), this, this.proxyCache, methodObject29063));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29063, onErrorForAll(methodObject29063, e));
    }
  }
  
  public boolean isAutoIncrement(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29066, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29066, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isAutoIncrement(arg0)), this, this.proxyCache, methodObject29066))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29066, onErrorForAll(methodObject29066, e))).booleanValue();
    }
  }
  
  public boolean isDefinitelyWritable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29069, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29069, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isDefinitelyWritable(arg0)), this, this.proxyCache, methodObject29069))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29069, onErrorForAll(methodObject29069, e))).booleanValue();
    }
  }
  
  public boolean isCaseSensitive(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29067, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29067, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCaseSensitive(arg0)), this, this.proxyCache, methodObject29067))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29067, onErrorForAll(methodObject29067, e))).booleanValue();
    }
  }
  
  public int getColumnCount()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29058, this, new Object[0]);
      return ((Integer)postForAll(methodObject29058, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnCount()), this, this.proxyCache, methodObject29058))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29058, onErrorForAll(methodObject29058, e))).intValue();
    }
  }
  
  public String getCatalogName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29056, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29056, this.proxyFactory.proxyFor((Object)this.delegate.getCatalogName(arg0), this, this.proxyCache, methodObject29056));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29056, onErrorForAll(methodObject29056, e));
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29053, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject29053, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, this.proxyCache, methodObject29053))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29053, onErrorForAll(methodObject29053, e))).intValue();
    }
  }
  
  public boolean isCurrency(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29068, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29068, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCurrency(arg0)), this, this.proxyCache, methodObject29068))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29068, onErrorForAll(methodObject29068, e))).booleanValue();
    }
  }
  
  public boolean isNCHAR(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29049, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29049, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isNCHAR(arg0)), this, this.proxyCache, methodObject29049))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29049, onErrorForAll(methodObject29049, e))).booleanValue();
    }
  }
  
  public OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29050, this, new Object[] { Integer.valueOf(arg0) });
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject29050, this.proxyFactory.proxyFor((Object)this.delegate.getSecurityAttribute(arg0), this, this.proxyCache, methodObject29050));
    }
    catch (SQLException e)
    {
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject29050, onErrorForAll(methodObject29050, e));
    }
  }
  
  public boolean isWritable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29071, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject29071, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isWritable(arg0)), this, this.proxyCache, methodObject29071))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject29071, onErrorForAll(methodObject29071, e))).booleanValue();
    }
  }
  
  public String getColumnLabel(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29060, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29060, this.proxyFactory.proxyFor((Object)this.delegate.getColumnLabel(arg0), this, this.proxyCache, methodObject29060));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29060, onErrorForAll(methodObject29060, e));
    }
  }
  
  public boolean isWrapperFor(Class arg0)
    throws SQLException
  {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getColumnName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29061, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29061, this.proxyFactory.proxyFor((Object)this.delegate.getColumnName(arg0), this, this.proxyCache, methodObject29061));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29061, onErrorForAll(methodObject29061, e));
    }
  }
  
  public int getColumnDisplaySize(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29059, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject29059, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnDisplaySize(arg0)), this, this.proxyCache, methodObject29059))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29059, onErrorForAll(methodObject29059, e))).intValue();
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29054, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject29054, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, this.proxyCache, methodObject29054))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29054, onErrorForAll(methodObject29054, e))).intValue();
    }
  }
  
  public int getColumnType(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29062, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject29062, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnType(arg0)), this, this.proxyCache, methodObject29062))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject29062, onErrorForAll(methodObject29062, e))).intValue();
    }
  }
  
  public String getTableName(int arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject29065, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject29065, this.proxyFactory.proxyFor((Object)this.delegate.getTableName(arg0), this, this.proxyCache, methodObject29065));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject29065, onErrorForAll(methodObject29065, e));
    }
  }
  
  public oracle.jdbc.internal.OracleResultSetMetaData _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject29070 = ResultSetMetaData.class.getDeclaredMethod("isSearchable", new Class[] { Integer.TYPE });
      methodObject29073 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject29064 = ResultSetMetaData.class.getDeclaredMethod("getSchemaName", new Class[] { Integer.TYPE });
      methodObject29055 = ResultSetMetaData.class.getDeclaredMethod("isSigned", new Class[] { Integer.TYPE });
      methodObject29057 = ResultSetMetaData.class.getDeclaredMethod("getColumnClassName", new Class[] { Integer.TYPE });
      methodObject29052 = ResultSetMetaData.class.getDeclaredMethod("getPrecision", new Class[] { Integer.TYPE });
      methodObject29051 = ResultSetMetaData.class.getDeclaredMethod("isReadOnly", new Class[] { Integer.TYPE });
      methodObject29063 = ResultSetMetaData.class.getDeclaredMethod("getColumnTypeName", new Class[] { Integer.TYPE });
      methodObject29066 = ResultSetMetaData.class.getDeclaredMethod("isAutoIncrement", new Class[] { Integer.TYPE });
      methodObject29069 = ResultSetMetaData.class.getDeclaredMethod("isDefinitelyWritable", new Class[] { Integer.TYPE });
      methodObject29067 = ResultSetMetaData.class.getDeclaredMethod("isCaseSensitive", new Class[] { Integer.TYPE });
      methodObject29058 = ResultSetMetaData.class.getDeclaredMethod("getColumnCount", new Class[0]);
      methodObject29056 = ResultSetMetaData.class.getDeclaredMethod("getCatalogName", new Class[] { Integer.TYPE });
      methodObject29053 = ResultSetMetaData.class.getDeclaredMethod("getScale", new Class[] { Integer.TYPE });
      methodObject29068 = ResultSetMetaData.class.getDeclaredMethod("isCurrency", new Class[] { Integer.TYPE });
      methodObject29049 = oracle.jdbc.OracleResultSetMetaData.class.getDeclaredMethod("isNCHAR", new Class[] { Integer.TYPE });
      methodObject29050 = oracle.jdbc.OracleResultSetMetaData.class.getDeclaredMethod("getSecurityAttribute", new Class[] { Integer.TYPE });
      methodObject29071 = ResultSetMetaData.class.getDeclaredMethod("isWritable", new Class[] { Integer.TYPE });
      methodObject29060 = ResultSetMetaData.class.getDeclaredMethod("getColumnLabel", new Class[] { Integer.TYPE });
      methodObject29072 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject29061 = ResultSetMetaData.class.getDeclaredMethod("getColumnName", new Class[] { Integer.TYPE });
      methodObject29059 = ResultSetMetaData.class.getDeclaredMethod("getColumnDisplaySize", new Class[] { Integer.TYPE });
      methodObject29054 = ResultSetMetaData.class.getDeclaredMethod("isNullable", new Class[] { Integer.TYPE });
      methodObject29062 = ResultSetMetaData.class.getDeclaredMethod("getColumnType", new Class[] { Integer.TYPE });
      methodObject29065 = ResultSetMetaData.class.getDeclaredMethod("getTableName", new Class[] { Integer.TYPE });
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetMetaData$$$Proxy(oracle.jdbc.internal.OracleResultSetMetaData paramOracleResultSetMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleResultSetMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */