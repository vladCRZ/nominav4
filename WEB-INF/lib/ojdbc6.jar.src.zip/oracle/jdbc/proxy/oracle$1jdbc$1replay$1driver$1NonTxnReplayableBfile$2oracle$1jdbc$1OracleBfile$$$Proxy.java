package oracle.jdbc.proxy;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.LargeObjectAccessMode;
import oracle.jdbc.OracleBfile;
import oracle.jdbc.replay.driver.NonTxnReplayableBfile;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1OracleBfile$$$Proxy
  extends NonTxnReplayableBfile
  implements OracleBfile, _Proxy_
{
  private OracleBfile delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject2535;
  private static Method methodObject2540;
  private static Method methodObject2537;
  private static Method methodObject2541;
  private static Method methodObject2533;
  private static Method methodObject2544;
  private static Method methodObject2534;
  private static Method methodObject2545;
  private static Method methodObject2546;
  private static Method methodObject2536;
  private static Method methodObject2538;
  private static Method methodObject2547;
  private static Method methodObject2539;
  private static Method methodObject2542;
  private static Method methodObject2532;
  private static Method methodObject2543;
  
  public long length()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2535, this, new Object[0]);
      return ((Long)postForAll(methodObject2535, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.length()), this, this.proxyCache, methodObject2535))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2535, onErrorForAll(methodObject2535, e))).longValue();
    }
  }
  
  public boolean isOpen()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2540, this, new Object[0]);
      return ((Boolean)postForAll(methodObject2540, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isOpen()), this, this.proxyCache, methodObject2540))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject2540, onErrorForAll(methodObject2540, e))).booleanValue();
    }
  }
  
  public long position(OracleBfile arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2537, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject2537, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position((arg0 instanceof _Proxy_) ? (OracleBfile)((_Proxy_)arg0)._getDelegate_() : arg0, arg1)), this, this.proxyCache, methodObject2537))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2537, onErrorForAll(methodObject2537, e))).longValue();
    }
  }
  
  public InputStream getBinaryStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2541, this, new Object[0]);
      return (InputStream)postForAll(methodObject2541, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(), this, this.proxyCache, methodObject2541));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject2541, onErrorForAll(methodObject2541, e));
    }
  }
  
  public byte[] getBytes(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2533, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (byte[])postForAll(methodObject2533, this.proxyFactory.proxyFor((Object)this.delegate.getBytes(arg0, arg1), this, this.proxyCache, methodObject2533));
    }
    catch (SQLException e)
    {
      return (byte[])postForAll(methodObject2533, onErrorForAll(methodObject2533, e));
    }
  }
  
  public void openFile()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2544, this, new Object[0]);
      this.delegate.openFile();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2544, e);
    }
  }
  
  public int getBytes(long arg0, int arg1, byte[] arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2534, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return ((Integer)postForAll(methodObject2534, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBytes(arg0, arg1, arg2)), this, this.proxyCache, methodObject2534))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject2534, onErrorForAll(methodObject2534, e))).intValue();
    }
  }
  
  public boolean isFileOpen()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2545, this, new Object[0]);
      return ((Boolean)postForAll(methodObject2545, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isFileOpen()), this, this.proxyCache, methodObject2545))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject2545, onErrorForAll(methodObject2545, e))).booleanValue();
    }
  }
  
  public boolean fileExists()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2546, this, new Object[0]);
      return ((Boolean)postForAll(methodObject2546, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.fileExists()), this, this.proxyCache, methodObject2546))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject2546, onErrorForAll(methodObject2546, e))).booleanValue();
    }
  }
  
  public long position(byte[] arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2536, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject2536, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, this.proxyCache, methodObject2536))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2536, onErrorForAll(methodObject2536, e))).longValue();
    }
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2538, this, new Object[0]);
      this.delegate.close();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2538, e);
    }
  }
  
  public void closeFile()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2547, this, new Object[0]);
      this.delegate.closeFile();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2547, e);
    }
  }
  
  public void open(LargeObjectAccessMode arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2539, this, new Object[] { arg0 });
      this.delegate.open(arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2539, e);
    }
  }
  
  public InputStream getBinaryStream(long arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2542, this, new Object[] { Long.valueOf(arg0) });
      return (InputStream)postForAll(methodObject2542, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(arg0), this, this.proxyCache, methodObject2542));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject2542, onErrorForAll(methodObject2542, e));
    }
  }
  
  public String getName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2532, this, new Object[0]);
      return (String)postForAll(methodObject2532, this.proxyFactory.proxyFor((Object)this.delegate.getName(), this, this.proxyCache, methodObject2532));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject2532, onErrorForAll(methodObject2532, e));
    }
  }
  
  public String getDirAlias()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2543, this, new Object[0]);
      return (String)postForAll(methodObject2543, this.proxyFactory.proxyFor((Object)this.delegate.getDirAlias(), this, this.proxyCache, methodObject2543));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject2543, onErrorForAll(methodObject2543, e));
    }
  }
  
  public OracleBfile _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject2535 = OracleBfile.class.getDeclaredMethod("length", new Class[0]);
      methodObject2540 = OracleBfile.class.getDeclaredMethod("isOpen", new Class[0]);
      methodObject2537 = OracleBfile.class.getDeclaredMethod("position", new Class[] { OracleBfile.class, Long.TYPE });
      methodObject2541 = OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject2533 = OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject2544 = OracleBfile.class.getDeclaredMethod("openFile", new Class[0]);
      methodObject2534 = OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { Long.TYPE, Integer.TYPE, byte[].class });
      methodObject2545 = OracleBfile.class.getDeclaredMethod("isFileOpen", new Class[0]);
      methodObject2546 = OracleBfile.class.getDeclaredMethod("fileExists", new Class[0]);
      methodObject2536 = OracleBfile.class.getDeclaredMethod("position", new Class[] { byte[].class, Long.TYPE });
      methodObject2538 = OracleBfile.class.getDeclaredMethod("close", new Class[0]);
      methodObject2547 = OracleBfile.class.getDeclaredMethod("closeFile", new Class[0]);
      methodObject2539 = OracleBfile.class.getDeclaredMethod("open", new Class[] { LargeObjectAccessMode.class });
      methodObject2542 = OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[] { Long.TYPE });
      methodObject2532 = OracleBfile.class.getDeclaredMethod("getName", new Class[0]);
      methodObject2543 = OracleBfile.class.getDeclaredMethod("getDirAlias", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1OracleBfile$$$Proxy(OracleBfile paramOracleBfile, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleBfile;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1OracleBfile$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */