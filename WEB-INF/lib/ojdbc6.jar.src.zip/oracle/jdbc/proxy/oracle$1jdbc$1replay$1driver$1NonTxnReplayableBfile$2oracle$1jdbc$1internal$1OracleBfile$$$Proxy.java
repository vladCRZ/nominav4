package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.LargeObjectAccessMode;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableBfile;
import oracle.sql.BFILE;
import oracle.sql.BfileDBAccess;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1internal$1OracleBfile$$$Proxy
  extends NonTxnReplayableBfile
  implements oracle.jdbc.internal.OracleBfile, _Proxy_
{
  private oracle.jdbc.internal.OracleBfile delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject2596;
  private static Method methodObject2586;
  private static Method methodObject2598;
  private static Method methodObject2588;
  private static Method methodObject2590;
  private static Method methodObject2556;
  private static Method methodObject2562;
  private static Method methodObject2557;
  private static Method methodObject2571;
  private static Method methodObject2591;
  private static Method methodObject2579;
  private static Method methodObject2594;
  private static Method methodObject2566;
  private static Method methodObject2573;
  private static Method methodObject2595;
  private static Method methodObject2549;
  private static Method methodObject2551;
  private static Method methodObject2570;
  private static Method methodObject2564;
  private static Method methodObject2597;
  private static Method methodObject2559;
  private static Method methodObject2558;
  private static Method methodObject2567;
  private static Method methodObject2574;
  private static Method methodObject2587;
  private static Method methodObject2582;
  private static Method methodObject2593;
  private static Method methodObject2561;
  private static Method methodObject2580;
  private static Method methodObject2552;
  private static Method methodObject2578;
  private static Method methodObject2583;
  private static Method methodObject2581;
  private static Method methodObject2554;
  private static Method methodObject2548;
  private static Method methodObject2555;
  private static Method methodObject2592;
  private static Method methodObject2589;
  private static Method methodObject2576;
  private static Method methodObject2585;
  private static Method methodObject2575;
  private static Method methodObject2569;
  private static Method methodObject2599;
  private static Method methodObject2553;
  private static Method methodObject2563;
  private static Method methodObject2565;
  private static Method methodObject2550;
  private static Method methodObject2572;
  private static Method methodObject2560;
  private static Method methodObject2577;
  private static Method methodObject2584;
  private static Method methodObject2568;
  
  public void openFile()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2596, this, new Object[0]);
      this.delegate.openFile();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2596, e);
    }
  }
  
  public int getBytes(long arg0, int arg1, byte[] arg2)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2586, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return ((Integer)postForAll(methodObject2586, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBytes(arg0, arg1, arg2)), this, this.proxyCache, methodObject2586))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject2586, onErrorForAll(methodObject2586, e))).intValue();
    }
  }
  
  public boolean fileExists()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2598, this, new Object[0]);
      return ((Boolean)postForAll(methodObject2598, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.fileExists()), this, this.proxyCache, methodObject2598))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject2598, onErrorForAll(methodObject2598, e))).booleanValue();
    }
  }
  
  public long position(byte[] arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2588, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject2588, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, this.proxyCache, methodObject2588))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2588, onErrorForAll(methodObject2588, e))).longValue();
    }
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2590, this, new Object[0]);
      this.delegate.close();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2590, e);
    }
  }
  
  public Connection getJavaSqlConnection()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2556, this, new Object[0]);
      return (Connection)postForAll(methodObject2556, this.proxyFactory.proxyFor((Object)this.delegate.getJavaSqlConnection(), this, this.proxyCache, methodObject2556));
    }
    catch (SQLException e)
    {
      return (Connection)postForAll(methodObject2556, onErrorForAll(methodObject2556, e));
    }
  }
  
  public boolean booleanValue()
    throws SQLException
  {
    return this.delegate.booleanValue();
  }
  
  public void setLocator(byte[] arg0)
  {
    super.preForAll(methodObject2557, this, new Object[] { arg0 });
    this.delegate.setLocator(arg0);
  }
  
  public void setShareBytes(byte[] arg0)
  {
    this.delegate.setShareBytes(arg0);
  }
  
  public void open(LargeObjectAccessMode arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2591, this, new Object[] { arg0 });
      this.delegate.open(arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2591, e);
    }
  }
  
  public Timestamp timestampValue()
    throws SQLException
  {
    return this.delegate.timestampValue();
  }
  
  public InputStream getBinaryStream(long arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2594, this, new Object[] { Long.valueOf(arg0) });
      return (InputStream)postForAll(methodObject2594, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(arg0), this, this.proxyCache, methodObject2594));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject2594, onErrorForAll(methodObject2594, e));
    }
  }
  
  public int intValue()
    throws SQLException
  {
    return this.delegate.intValue();
  }
  
  public String stringValue()
    throws SQLException
  {
    return this.delegate.stringValue();
  }
  
  public String getDirAlias()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2595, this, new Object[0]);
      return (String)postForAll(methodObject2595, this.proxyFactory.proxyFor((Object)this.delegate.getDirAlias(), this, this.proxyCache, methodObject2595));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject2595, onErrorForAll(methodObject2595, e));
    }
  }
  
  public void setLength(long arg0)
  {
    super.preForAll(methodObject2549, this, new Object[] { Long.valueOf(arg0) });
    this.delegate.setLength(arg0);
  }
  
  public InputStream asciiStreamValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2551, this, new Object[0]);
      return (InputStream)postForAll(methodObject2551, this.proxyFactory.proxyFor((Object)this.delegate.asciiStreamValue(), this, this.proxyCache, methodObject2551));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject2551, onErrorForAll(methodObject2551, e));
    }
  }
  
  public byte[] shareBytes()
  {
    return this.delegate.shareBytes();
  }
  
  public double doubleValue()
    throws SQLException
  {
    return this.delegate.doubleValue();
  }
  
  public boolean isFileOpen()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2597, this, new Object[0]);
      return ((Boolean)postForAll(methodObject2597, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isFileOpen()), this, this.proxyCache, methodObject2597))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject2597, onErrorForAll(methodObject2597, e))).booleanValue();
    }
  }
  
  public BfileDBAccess getDBAccess()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2559, this, new Object[0]);
      return (BfileDBAccess)postForAll(methodObject2559, this.proxyFactory.proxyFor((Object)this.delegate.getDBAccess(), this, this.proxyCache, methodObject2559));
    }
    catch (SQLException e)
    {
      return (BfileDBAccess)postForAll(methodObject2559, onErrorForAll(methodObject2559, e));
    }
  }
  
  public byte[] getLocator()
  {
    super.preForAll(methodObject2558, this, new Object[0]);
    return (byte[])postForAll(methodObject2558, this.proxyFactory.proxyFor((Object)this.delegate.getLocator(), this, this.proxyCache, methodObject2558));
  }
  
  public long longValue()
    throws SQLException
  {
    return this.delegate.longValue();
  }
  
  public String stringValue(Connection arg0)
    throws SQLException
  {
    return this.delegate.stringValue((arg0 instanceof _Proxy_) ? (Connection)((_Proxy_)arg0)._getDelegate_() : arg0);
  }
  
  public long length()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2587, this, new Object[0]);
      return ((Long)postForAll(methodObject2587, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.length()), this, this.proxyCache, methodObject2587))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2587, onErrorForAll(methodObject2587, e))).longValue();
    }
  }
  
  public oracle.jdbc.internal.OracleConnection getInternalConnection()
    throws SQLException
  {
    return this.delegate.getInternalConnection();
  }
  
  public InputStream getBinaryStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2593, this, new Object[0]);
      return (InputStream)postForAll(methodObject2593, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(), this, this.proxyCache, methodObject2593));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject2593, onErrorForAll(methodObject2593, e));
    }
  }
  
  public byte[] getBytes()
  {
    return this.delegate.getBytes();
  }
  
  public Timestamp timestampValue(Calendar arg0)
    throws SQLException
  {
    return this.delegate.timestampValue(arg0);
  }
  
  public InputStream binaryStreamValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2552, this, new Object[0]);
      return (InputStream)postForAll(methodObject2552, this.proxyFactory.proxyFor((Object)this.delegate.binaryStreamValue(), this, this.proxyCache, methodObject2552));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject2552, onErrorForAll(methodObject2552, e));
    }
  }
  
  public Time timeValue(Calendar arg0)
    throws SQLException
  {
    return this.delegate.timeValue(arg0);
  }
  
  public void setPhysicalConnectionOf(Connection arg0)
  {
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? (Connection)((_Proxy_)arg0)._getDelegate_() : arg0);
  }
  
  public oracle.jdbc.OracleConnection getOracleConnection()
    throws SQLException
  {
    return this.delegate.getOracleConnection();
  }
  
  public Object toJdbc()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2554, this, new Object[0]);
      return postForAll(methodObject2554, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, this.proxyCache, methodObject2554));
    }
    catch (SQLException e)
    {
      return postForAll(methodObject2554, onErrorForAll(methodObject2554, e));
    }
  }
  
  public long position(BFILE arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2548, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject2548, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, this.proxyCache, methodObject2548))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2548, onErrorForAll(methodObject2548, e))).longValue();
    }
  }
  
  public Object makeJdbcArray(int arg0)
  {
    super.preForAll(methodObject2555, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject2555, this.proxyFactory.proxyFor(this.delegate.makeJdbcArray(arg0), this, this.proxyCache, methodObject2555));
  }
  
  public boolean isOpen()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2592, this, new Object[0]);
      return ((Boolean)postForAll(methodObject2592, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isOpen()), this, this.proxyCache, methodObject2592))).booleanValue();
    }
    catch (SQLException e)
    {
      return ((Boolean)postForAll(methodObject2592, onErrorForAll(methodObject2592, e))).booleanValue();
    }
  }
  
  public long position(oracle.jdbc.OracleBfile arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2589, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject2589, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position((arg0 instanceof _Proxy_) ? (oracle.jdbc.OracleBfile)((_Proxy_)arg0)._getDelegate_() : arg0, arg1)), this, this.proxyCache, methodObject2589))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject2589, onErrorForAll(methodObject2589, e))).longValue();
    }
  }
  
  public Date dateValue()
    throws SQLException
  {
    return this.delegate.dateValue();
  }
  
  public byte[] getBytes(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2585, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (byte[])postForAll(methodObject2585, this.proxyFactory.proxyFor((Object)this.delegate.getBytes(arg0, arg1), this, this.proxyCache, methodObject2585));
    }
    catch (SQLException e)
    {
      return (byte[])postForAll(methodObject2585, onErrorForAll(methodObject2585, e));
    }
  }
  
  public BigDecimal bigDecimalValue()
    throws SQLException
  {
    return this.delegate.bigDecimalValue();
  }
  
  public void setBytes(byte[] arg0)
  {
    this.delegate.setBytes(arg0);
  }
  
  public void closeFile()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2599, this, new Object[0]);
      this.delegate.closeFile();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject2599, e);
    }
  }
  
  public boolean isConvertibleTo(Class arg0)
  {
    super.preForAll(methodObject2553, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject2553, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isConvertibleTo(arg0)), this, this.proxyCache, methodObject2553))).booleanValue();
  }
  
  public byte byteValue()
    throws SQLException
  {
    return this.delegate.byteValue();
  }
  
  public float floatValue()
    throws SQLException
  {
    return this.delegate.floatValue();
  }
  
  public Reader characterStreamValue()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2550, this, new Object[0]);
      return (Reader)postForAll(methodObject2550, this.proxyFactory.proxyFor((Object)this.delegate.characterStreamValue(), this, this.proxyCache, methodObject2550));
    }
    catch (SQLException e)
    {
      return (Reader)postForAll(methodObject2550, onErrorForAll(methodObject2550, e));
    }
  }
  
  public InputStream getStream()
    throws SQLException
  {
    return this.delegate.getStream();
  }
  
  public long getLength()
  {
    return this.delegate.getLength();
  }
  
  public Time timeValue()
    throws SQLException
  {
    return this.delegate.timeValue();
  }
  
  public String getName()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject2584, this, new Object[0]);
      return (String)postForAll(methodObject2584, this.proxyFactory.proxyFor((Object)this.delegate.getName(), this, this.proxyCache, methodObject2584));
    }
    catch (SQLException e)
    {
      return (String)postForAll(methodObject2584, onErrorForAll(methodObject2584, e));
    }
  }
  
  public oracle.jdbc.driver.OracleConnection getConnection()
    throws SQLException
  {
    return this.delegate.getConnection();
  }
  
  public oracle.jdbc.internal.OracleBfile _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject2596 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("openFile", new Class[0]);
      methodObject2586 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { Long.TYPE, Integer.TYPE, byte[].class });
      methodObject2598 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("fileExists", new Class[0]);
      methodObject2588 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("position", new Class[] { byte[].class, Long.TYPE });
      methodObject2590 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("close", new Class[0]);
      methodObject2556 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject2562 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject2557 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("setLocator", new Class[] { byte[].class });
      methodObject2571 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject2591 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("open", new Class[] { LargeObjectAccessMode.class });
      methodObject2579 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject2594 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[] { Long.TYPE });
      methodObject2566 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject2573 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject2595 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("getDirAlias", new Class[0]);
      methodObject2549 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("setLength", new Class[] { Long.TYPE });
      methodObject2551 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject2570 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject2564 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject2597 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("isFileOpen", new Class[0]);
      methodObject2559 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("getDBAccess", new Class[0]);
      methodObject2558 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("getLocator", new Class[0]);
      methodObject2567 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject2574 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject2587 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("length", new Class[0]);
      methodObject2582 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject2593 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject2561 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject2580 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject2552 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject2578 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject2583 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject2581 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject2554 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject2548 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("position", new Class[] { BFILE.class, Long.TYPE });
      methodObject2555 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("makeJdbcArray", new Class[] { Integer.TYPE });
      methodObject2592 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("isOpen", new Class[0]);
      methodObject2589 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("position", new Class[] { oracle.jdbc.OracleBfile.class, Long.TYPE });
      methodObject2576 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject2585 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject2575 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject2569 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject2599 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("closeFile", new Class[0]);
      methodObject2553 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject2563 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject2565 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject2550 = oracle.jdbc.internal.OracleBfile.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject2572 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject2560 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject2577 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject2584 = oracle.jdbc.OracleBfile.class.getDeclaredMethod("getName", new Class[0]);
      methodObject2568 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1internal$1OracleBfile$$$Proxy(oracle.jdbc.internal.OracleBfile paramOracleBfile, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramOracleBfile;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1internal$1OracleBfile$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */