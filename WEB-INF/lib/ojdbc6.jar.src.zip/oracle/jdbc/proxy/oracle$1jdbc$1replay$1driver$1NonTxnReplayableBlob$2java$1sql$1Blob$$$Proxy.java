package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBlob;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBlob$2java$1sql$1Blob$$$Proxy
  extends NonTxnReplayableBlob
  implements Blob, _Proxy_
{
  private Blob delegate;
  private final Object creator;
  private final ProxyFactory proxyFactory;
  private final Map<Object, Object> proxyCache;
  private static Method methodObject27192;
  private static Method methodObject27196;
  private static Method methodObject27195;
  private static Method methodObject27189;
  private static Method methodObject27198;
  private static Method methodObject27197;
  private static Method methodObject27193;
  private static Method methodObject27194;
  private static Method methodObject27188;
  private static Method methodObject27191;
  private static Method methodObject27190;
  
  public OutputStream setBinaryStream(long arg0)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27192, this, new Object[] { Long.valueOf(arg0) });
      return (OutputStream)postForAll(methodObject27192, this.proxyFactory.proxyFor((Object)this.delegate.setBinaryStream(arg0), this, this.proxyCache, methodObject27192));
    }
    catch (SQLException e)
    {
      return (OutputStream)postForAll(methodObject27192, onErrorForAll(methodObject27192, e));
    }
  }
  
  public void free()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27196, this, new Object[0]);
      this.delegate.free();
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject27196, e);
    }
  }
  
  public void truncate(long arg0)
    throws SQLException
  {
    try
    {
      super.preForBlobWrites(methodObject27195, this, new Object[] { Long.valueOf(arg0) });
      this.delegate.truncate(arg0);
      return;
    }
    catch (SQLException e)
    {
      onErrorVoidForAll(methodObject27195, e);
    }
  }
  
  public long length()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27189, this, new Object[0]);
      return ((Long)postForAll(methodObject27189, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.length()), this, this.proxyCache, methodObject27189))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject27189, onErrorForAll(methodObject27189, e))).longValue();
    }
  }
  
  public InputStream getBinaryStream(long arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27198, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      return (InputStream)postForAll(methodObject27198, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(arg0, arg1), this, this.proxyCache, methodObject27198));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject27198, onErrorForAll(methodObject27198, e));
    }
  }
  
  public InputStream getBinaryStream()
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27197, this, new Object[0]);
      return (InputStream)postForAll(methodObject27197, this.proxyFactory.proxyFor((Object)this.delegate.getBinaryStream(), this, this.proxyCache, methodObject27197));
    }
    catch (SQLException e)
    {
      return (InputStream)postForAll(methodObject27197, onErrorForAll(methodObject27197, e));
    }
  }
  
  public int setBytes(long arg0, byte[] arg1)
    throws SQLException
  {
    try
    {
      super.preForBlobWrites(methodObject27193, this, new Object[] { Long.valueOf(arg0), arg1 });
      return ((Integer)postForAll(methodObject27193, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.setBytes(arg0, arg1)), this, this.proxyCache, methodObject27193))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject27193, onErrorForAll(methodObject27193, e))).intValue();
    }
  }
  
  public int setBytes(long arg0, byte[] arg1, int arg2, int arg3)
    throws SQLException
  {
    try
    {
      super.preForBlobWrites(methodObject27194, this, new Object[] { Long.valueOf(arg0), arg1, Integer.valueOf(arg2), Integer.valueOf(arg3) });
      return ((Integer)postForAll(methodObject27194, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.setBytes(arg0, arg1, arg2, arg3)), this, this.proxyCache, methodObject27194))).intValue();
    }
    catch (SQLException e)
    {
      return ((Integer)postForAll(methodObject27194, onErrorForAll(methodObject27194, e))).intValue();
    }
  }
  
  public byte[] getBytes(long arg0, int arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27188, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (byte[])postForAll(methodObject27188, this.proxyFactory.proxyFor((Object)this.delegate.getBytes(arg0, arg1), this, this.proxyCache, methodObject27188));
    }
    catch (SQLException e)
    {
      return (byte[])postForAll(methodObject27188, onErrorForAll(methodObject27188, e));
    }
  }
  
  public long position(Blob arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27191, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject27191, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position((arg0 instanceof _Proxy_) ? (Blob)((_Proxy_)arg0)._getDelegate_() : arg0, arg1)), this, this.proxyCache, methodObject27191))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject27191, onErrorForAll(methodObject27191, e))).longValue();
    }
  }
  
  public long position(byte[] arg0, long arg1)
    throws SQLException
  {
    try
    {
      super.preForAll(methodObject27190, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject27190, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, this.proxyCache, methodObject27190))).longValue();
    }
    catch (SQLException e)
    {
      return ((Long)postForAll(methodObject27190, onErrorForAll(methodObject27190, e))).longValue();
    }
  }
  
  public Blob _getDelegate_()
  {
    return this.delegate;
  }
  
  public Object getDelegate()
  {
    return this.delegate;
  }
  
  public void setDelegate(Object delegate)
  {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator()
  {
    return this.creator;
  }
  
  static
  {
    try
    {
      methodObject27192 = Blob.class.getDeclaredMethod("setBinaryStream", new Class[] { Long.TYPE });
      methodObject27196 = Blob.class.getDeclaredMethod("free", new Class[0]);
      methodObject27195 = Blob.class.getDeclaredMethod("truncate", new Class[] { Long.TYPE });
      methodObject27189 = Blob.class.getDeclaredMethod("length", new Class[0]);
      methodObject27198 = Blob.class.getDeclaredMethod("getBinaryStream", new Class[] { Long.TYPE, Long.TYPE });
      methodObject27197 = Blob.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject27193 = Blob.class.getDeclaredMethod("setBytes", new Class[] { Long.TYPE, byte[].class });
      methodObject27194 = Blob.class.getDeclaredMethod("setBytes", new Class[] { Long.TYPE, byte[].class, Integer.TYPE, Integer.TYPE });
      methodObject27188 = Blob.class.getDeclaredMethod("getBytes", new Class[] { Long.TYPE, Integer.TYPE });
      methodObject27191 = Blob.class.getDeclaredMethod("position", new Class[] { Blob.class, Long.TYPE });
      methodObject27190 = Blob.class.getDeclaredMethod("position", new Class[] { byte[].class, Long.TYPE });
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException(localThrowable);
    }
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBlob$2java$1sql$1Blob$$$Proxy(Blob paramBlob, Object paramObject, ProxyFactory paramProxyFactory, Map paramMap)
  {
    this.delegate = paramBlob;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\ojdbc6.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBlob$2java$1sql$1Blob$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */