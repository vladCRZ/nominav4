package org.apache.poi.common.usermodel;

import java.awt.Color;

public abstract interface Fill
{
  public abstract Color getColor();
  
  public abstract void setColor(Color paramColor);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\commo\\usermodel\Fill.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */