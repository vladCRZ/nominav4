package org.apache.poi.common.usermodel;

public abstract interface Hyperlink
{
  public static final int LINK_URL = 1;
  public static final int LINK_DOCUMENT = 2;
  public static final int LINK_EMAIL = 3;
  public static final int LINK_FILE = 4;
  
  public abstract String getAddress();
  
  public abstract void setAddress(String paramString);
  
  public abstract String getLabel();
  
  public abstract void setLabel(String paramString);
  
  public abstract int getType();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\commo\\usermodel\Hyperlink.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */