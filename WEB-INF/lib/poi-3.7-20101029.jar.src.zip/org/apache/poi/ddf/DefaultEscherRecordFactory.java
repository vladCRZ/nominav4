/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultEscherRecordFactory
/*     */   implements EscherRecordFactory
/*     */ {
/*  33 */   private static Class<?>[] escherRecordClasses = { EscherBSERecord.class, EscherOptRecord.class, EscherClientAnchorRecord.class, EscherDgRecord.class, EscherSpgrRecord.class, EscherSpRecord.class, EscherClientDataRecord.class, EscherDggRecord.class, EscherSplitMenuColorsRecord.class, EscherChildAnchorRecord.class, EscherTextboxRecord.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   private static Map<Short, Constructor<? extends EscherRecord>> recordsMap = recordsToMap(escherRecordClasses);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherRecord createRecord(byte[] data, int offset)
/*     */   {
/*  56 */     EscherRecord.EscherRecordHeader header = EscherRecord.EscherRecordHeader.readHeader(data, offset);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */     if (((header.getOptions() & 0xF) == 15) && (header.getRecordId() != 61453))
/*     */     {
/*  64 */       EscherContainerRecord r = new EscherContainerRecord();
/*  65 */       r.setRecordId(header.getRecordId());
/*  66 */       r.setOptions(header.getOptions());
/*  67 */       return r;
/*     */     }
/*     */     
/*  70 */     if ((header.getRecordId() >= 61464) && (header.getRecordId() <= 61719)) {
/*     */       EscherBlipRecord r;
/*     */       EscherBlipRecord r;
/*  73 */       if ((header.getRecordId() == 61471) || (header.getRecordId() == 61469) || (header.getRecordId() == 61470))
/*     */       {
/*     */ 
/*     */ 
/*  77 */         r = new EscherBitmapBlip();
/*     */       } else { EscherBlipRecord r;
/*  79 */         if ((header.getRecordId() == 61466) || (header.getRecordId() == 61467) || (header.getRecordId() == 61468))
/*     */         {
/*     */ 
/*     */ 
/*  83 */           r = new EscherMetafileBlip();
/*     */         } else
/*  85 */           r = new EscherBlipRecord();
/*     */       }
/*  87 */       r.setRecordId(header.getRecordId());
/*  88 */       r.setOptions(header.getOptions());
/*  89 */       return r;
/*     */     }
/*     */     
/*  92 */     Constructor<? extends EscherRecord> recordConstructor = (Constructor)recordsMap.get(Short.valueOf(header.getRecordId()));
/*  93 */     EscherRecord escherRecord = null;
/*  94 */     if (recordConstructor == null) {
/*  95 */       return new UnknownEscherRecord();
/*     */     }
/*     */     try {
/*  98 */       escherRecord = (EscherRecord)recordConstructor.newInstance(new Object[0]);
/*     */     } catch (Exception e) {
/* 100 */       return new UnknownEscherRecord();
/*     */     }
/* 102 */     escherRecord.setRecordId(header.getRecordId());
/* 103 */     escherRecord.setOptions(header.getOptions());
/* 104 */     return escherRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<Short, Constructor<? extends EscherRecord>> recordsToMap(Class<?>[] recClasses)
/*     */   {
/* 116 */     Map<Short, Constructor<? extends EscherRecord>> result = new HashMap();
/* 117 */     Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */     
/* 119 */     for (int i = 0; i < recClasses.length; i++)
/*     */     {
/* 121 */       Class<? extends EscherRecord> recCls = recClasses[i];
/*     */       short sid;
/*     */       try {
/* 124 */         sid = recCls.getField("RECORD_ID").getShort(null);
/*     */       } catch (IllegalArgumentException e) {
/* 126 */         throw new RuntimeException(e);
/*     */       } catch (IllegalAccessException e) {
/* 128 */         throw new RuntimeException(e);
/*     */       } catch (NoSuchFieldException e) {
/* 130 */         throw new RuntimeException(e);
/*     */       }
/*     */       Constructor<? extends EscherRecord> constructor;
/*     */       try {
/* 134 */         constructor = recCls.getConstructor(EMPTY_CLASS_ARRAY);
/*     */       } catch (NoSuchMethodException e) {
/* 136 */         throw new RuntimeException(e);
/*     */       }
/* 138 */       result.put(Short.valueOf(sid), constructor);
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\DefaultEscherRecordFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */