/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherArrayProperty
/*     */   extends EscherComplexProperty
/*     */ {
/*     */   private static final int FIXED_SIZE = 6;
/*  40 */   private boolean sizeIncludesHeaderSize = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private boolean emptyComplexPart = false;
/*     */   
/*     */   public EscherArrayProperty(short id, byte[] complexData) {
/*  48 */     super(id, checkComplexData(complexData));
/*  49 */     this.emptyComplexPart = (complexData.length == 0);
/*     */   }
/*     */   
/*     */   public EscherArrayProperty(short propertyNumber, boolean isBlipId, byte[] complexData) {
/*  53 */     super(propertyNumber, isBlipId, checkComplexData(complexData));
/*     */   }
/*     */   
/*     */   private static byte[] checkComplexData(byte[] complexData) {
/*  57 */     if ((complexData == null) || (complexData.length == 0)) {
/*  58 */       return new byte[6];
/*     */     }
/*     */     
/*  61 */     return complexData;
/*     */   }
/*     */   
/*     */   public int getNumberOfElementsInArray() {
/*  65 */     return LittleEndian.getUShort(this._complexData, 0);
/*     */   }
/*     */   
/*     */   public void setNumberOfElementsInArray(int numberOfElements) {
/*  69 */     int expectedArraySize = numberOfElements * getActualSizeOfElements(getSizeOfElements()) + 6;
/*  70 */     if (expectedArraySize != this._complexData.length) {
/*  71 */       byte[] newArray = new byte[expectedArraySize];
/*  72 */       System.arraycopy(this._complexData, 0, newArray, 0, this._complexData.length);
/*  73 */       this._complexData = newArray;
/*     */     }
/*  75 */     LittleEndian.putShort(this._complexData, 0, (short)numberOfElements);
/*     */   }
/*     */   
/*     */   public int getNumberOfElementsInMemory() {
/*  79 */     return LittleEndian.getUShort(this._complexData, 2);
/*     */   }
/*     */   
/*     */   public void setNumberOfElementsInMemory(int numberOfElements) {
/*  83 */     int expectedArraySize = numberOfElements * getActualSizeOfElements(getSizeOfElements()) + 6;
/*  84 */     if (expectedArraySize != this._complexData.length) {
/*  85 */       byte[] newArray = new byte[expectedArraySize];
/*  86 */       System.arraycopy(this._complexData, 0, newArray, 0, expectedArraySize);
/*  87 */       this._complexData = newArray;
/*     */     }
/*  89 */     LittleEndian.putShort(this._complexData, 2, (short)numberOfElements);
/*     */   }
/*     */   
/*     */   public short getSizeOfElements() {
/*  93 */     return LittleEndian.getShort(this._complexData, 4);
/*     */   }
/*     */   
/*     */   public void setSizeOfElements(int sizeOfElements) {
/*  97 */     LittleEndian.putShort(this._complexData, 4, (short)sizeOfElements);
/*     */     
/*  99 */     int expectedArraySize = getNumberOfElementsInArray() * getActualSizeOfElements(getSizeOfElements()) + 6;
/* 100 */     if (expectedArraySize != this._complexData.length)
/*     */     {
/* 102 */       byte[] newArray = new byte[expectedArraySize];
/* 103 */       System.arraycopy(this._complexData, 0, newArray, 0, 6);
/* 104 */       this._complexData = newArray;
/*     */     }
/*     */   }
/*     */   
/*     */   public byte[] getElement(int index) {
/* 109 */     int actualSize = getActualSizeOfElements(getSizeOfElements());
/* 110 */     byte[] result = new byte[actualSize];
/* 111 */     System.arraycopy(this._complexData, 6 + index * actualSize, result, 0, result.length);
/* 112 */     return result;
/*     */   }
/*     */   
/*     */   public void setElement(int index, byte[] element) {
/* 116 */     int actualSize = getActualSizeOfElements(getSizeOfElements());
/* 117 */     System.arraycopy(element, 0, this._complexData, 6 + index * actualSize, actualSize);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 121 */     StringBuffer results = new StringBuffer();
/* 122 */     results.append("    {EscherArrayProperty:\n");
/* 123 */     results.append("     Num Elements: " + getNumberOfElementsInArray() + '\n');
/* 124 */     results.append("     Num Elements In Memory: " + getNumberOfElementsInMemory() + '\n');
/* 125 */     results.append("     Size of elements: " + getSizeOfElements() + '\n');
/* 126 */     for (int i = 0; i < getNumberOfElementsInArray(); i++) {
/* 127 */       results.append("     Element " + i + ": " + HexDump.toHex(getElement(i)) + '\n');
/*     */     }
/* 129 */     results.append("}\n");
/*     */     
/* 131 */     return "propNum: " + getPropertyNumber() + ", propName: " + EscherProperties.getPropertyName(getPropertyNumber()) + ", complex: " + isComplex() + ", blipId: " + isBlipId() + ", data: " + '\n' + results.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int setArrayData(byte[] data, int offset)
/*     */   {
/* 149 */     if (this.emptyComplexPart) {
/* 150 */       this._complexData = new byte[0];
/*     */     } else {
/* 152 */       short numElements = LittleEndian.getShort(data, offset);
/* 153 */       LittleEndian.getShort(data, offset + 2);
/* 154 */       short sizeOfElements = LittleEndian.getShort(data, offset + 4);
/*     */       
/* 156 */       int arraySize = getActualSizeOfElements(sizeOfElements) * numElements;
/* 157 */       if (arraySize == this._complexData.length)
/*     */       {
/* 159 */         this._complexData = new byte[arraySize + 6];
/* 160 */         this.sizeIncludesHeaderSize = false;
/*     */       }
/* 162 */       System.arraycopy(data, offset, this._complexData, 0, this._complexData.length);
/*     */     }
/* 164 */     return this._complexData.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serializeSimplePart(byte[] data, int pos)
/*     */   {
/* 174 */     LittleEndian.putShort(data, pos, getId());
/* 175 */     int recordSize = this._complexData.length;
/* 176 */     if (!this.sizeIncludesHeaderSize) {
/* 177 */       recordSize -= 6;
/*     */     }
/* 179 */     LittleEndian.putInt(data, pos + 2, recordSize);
/* 180 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getActualSizeOfElements(short sizeOfElements)
/*     */   {
/* 188 */     if (sizeOfElements < 0) {
/* 189 */       return (short)(-sizeOfElements >> 2);
/*     */     }
/* 191 */     return sizeOfElements;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherArrayProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */