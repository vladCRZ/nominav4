/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherBSERecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4089;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtBSE";
/*     */   public static final byte BT_ERROR = 0;
/*     */   public static final byte BT_UNKNOWN = 1;
/*     */   public static final byte BT_EMF = 2;
/*     */   public static final byte BT_WMF = 3;
/*     */   public static final byte BT_PICT = 4;
/*     */   public static final byte BT_JPEG = 5;
/*     */   public static final byte BT_PNG = 6;
/*     */   public static final byte BT_DIB = 7;
/*     */   private byte field_1_blipTypeWin32;
/*     */   private byte field_2_blipTypeMacOS;
/*     */   private byte[] field_3_uid;
/*     */   private short field_4_tag;
/*     */   private int field_5_size;
/*     */   private int field_6_ref;
/*     */   private int field_7_offset;
/*     */   private byte field_8_usage;
/*     */   private byte field_9_name;
/*     */   private byte field_10_unused2;
/*     */   private byte field_11_unused3;
/*     */   private EscherBlipRecord field_12_blipRecord;
/*     */   private byte[] _remainingData;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  60 */     int bytesRemaining = readHeader(data, offset);
/*  61 */     int pos = offset + 8;
/*  62 */     this.field_1_blipTypeWin32 = data[pos];
/*  63 */     this.field_2_blipTypeMacOS = data[(pos + 1)];
/*  64 */     System.arraycopy(data, pos + 2, this.field_3_uid = new byte[16], 0, 16);
/*  65 */     this.field_4_tag = LittleEndian.getShort(data, pos + 18);
/*  66 */     this.field_5_size = LittleEndian.getInt(data, pos + 20);
/*  67 */     this.field_6_ref = LittleEndian.getInt(data, pos + 24);
/*  68 */     this.field_7_offset = LittleEndian.getInt(data, pos + 28);
/*  69 */     this.field_8_usage = data[(pos + 32)];
/*  70 */     this.field_9_name = data[(pos + 33)];
/*  71 */     this.field_10_unused2 = data[(pos + 34)];
/*  72 */     this.field_11_unused3 = data[(pos + 35)];
/*  73 */     bytesRemaining -= 36;
/*     */     
/*  75 */     int bytesRead = 0;
/*  76 */     if (bytesRemaining > 0)
/*     */     {
/*  78 */       this.field_12_blipRecord = ((EscherBlipRecord)recordFactory.createRecord(data, pos + 36));
/*  79 */       bytesRead = this.field_12_blipRecord.fillFields(data, pos + 36, recordFactory);
/*     */     }
/*  81 */     pos += 36 + bytesRead;
/*  82 */     bytesRemaining -= bytesRead;
/*     */     
/*  84 */     this._remainingData = new byte[bytesRemaining];
/*  85 */     System.arraycopy(data, pos, this._remainingData, 0, bytesRemaining);
/*  86 */     return bytesRemaining + 8 + 36 + (this.field_12_blipRecord == null ? 0 : this.field_12_blipRecord.getRecordSize());
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  91 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  93 */     if (this._remainingData == null) {
/*  94 */       this._remainingData = new byte[0];
/*     */     }
/*  96 */     LittleEndian.putShort(data, offset, getOptions());
/*  97 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  98 */     if (this._remainingData == null) this._remainingData = new byte[0];
/*  99 */     int blipSize = this.field_12_blipRecord == null ? 0 : this.field_12_blipRecord.getRecordSize();
/* 100 */     int remainingBytes = this._remainingData.length + 36 + blipSize;
/* 101 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*     */     
/* 103 */     data[(offset + 8)] = this.field_1_blipTypeWin32;
/* 104 */     data[(offset + 9)] = this.field_2_blipTypeMacOS;
/* 105 */     for (int i = 0; i < 16; i++)
/* 106 */       data[(offset + 10 + i)] = this.field_3_uid[i];
/* 107 */     LittleEndian.putShort(data, offset + 26, this.field_4_tag);
/* 108 */     LittleEndian.putInt(data, offset + 28, this.field_5_size);
/* 109 */     LittleEndian.putInt(data, offset + 32, this.field_6_ref);
/* 110 */     LittleEndian.putInt(data, offset + 36, this.field_7_offset);
/* 111 */     data[(offset + 40)] = this.field_8_usage;
/* 112 */     data[(offset + 41)] = this.field_9_name;
/* 113 */     data[(offset + 42)] = this.field_10_unused2;
/* 114 */     data[(offset + 43)] = this.field_11_unused3;
/* 115 */     int bytesWritten = 0;
/* 116 */     if (this.field_12_blipRecord != null)
/*     */     {
/* 118 */       bytesWritten = this.field_12_blipRecord.serialize(offset + 44, data, new NullEscherSerializationListener());
/*     */     }
/* 120 */     if (this._remainingData == null)
/* 121 */       this._remainingData = new byte[0];
/* 122 */     System.arraycopy(this._remainingData, 0, data, offset + 44 + bytesWritten, this._remainingData.length);
/* 123 */     int pos = offset + 8 + 36 + this._remainingData.length + bytesWritten;
/*     */     
/* 125 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/* 126 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/* 130 */     int field_12_size = 0;
/* 131 */     if (this.field_12_blipRecord != null) {
/* 132 */       field_12_size = this.field_12_blipRecord.getRecordSize();
/*     */     }
/* 134 */     int remaining_size = 0;
/* 135 */     if (this._remainingData != null) {
/* 136 */       remaining_size = this._remainingData.length;
/*     */     }
/* 138 */     return 44 + field_12_size + remaining_size;
/*     */   }
/*     */   
/*     */   public String getRecordName()
/*     */   {
/* 143 */     return "BSE";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getBlipTypeWin32()
/*     */   {
/* 151 */     return this.field_1_blipTypeWin32;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBlipTypeWin32(byte blipTypeWin32)
/*     */   {
/* 158 */     this.field_1_blipTypeWin32 = blipTypeWin32;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getBlipTypeMacOS()
/*     */   {
/* 166 */     return this.field_2_blipTypeMacOS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBlipTypeMacOS(byte blipTypeMacOS)
/*     */   {
/* 173 */     this.field_2_blipTypeMacOS = blipTypeMacOS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getUid()
/*     */   {
/* 180 */     return this.field_3_uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUid(byte[] uid)
/*     */   {
/* 187 */     this.field_3_uid = uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getTag()
/*     */   {
/* 194 */     return this.field_4_tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTag(short tag)
/*     */   {
/* 201 */     this.field_4_tag = tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 208 */     return this.field_5_size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSize(int size)
/*     */   {
/* 215 */     this.field_5_size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRef()
/*     */   {
/* 222 */     return this.field_6_ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRef(int ref)
/*     */   {
/* 229 */     this.field_6_ref = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getOffset()
/*     */   {
/* 236 */     return this.field_7_offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOffset(int offset)
/*     */   {
/* 243 */     this.field_7_offset = offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte getUsage()
/*     */   {
/* 250 */     return this.field_8_usage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUsage(byte usage)
/*     */   {
/* 257 */     this.field_8_usage = usage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte getName()
/*     */   {
/* 264 */     return this.field_9_name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setName(byte name)
/*     */   {
/* 271 */     this.field_9_name = name;
/*     */   }
/*     */   
/*     */   public byte getUnused2() {
/* 275 */     return this.field_10_unused2;
/*     */   }
/*     */   
/*     */   public void setUnused2(byte unused2) {
/* 279 */     this.field_10_unused2 = unused2;
/*     */   }
/*     */   
/*     */   public byte getUnused3() {
/* 283 */     return this.field_11_unused3;
/*     */   }
/*     */   
/*     */   public void setUnused3(byte unused3) {
/* 287 */     this.field_11_unused3 = unused3;
/*     */   }
/*     */   
/*     */   public EscherBlipRecord getBlipRecord() {
/* 291 */     return this.field_12_blipRecord;
/*     */   }
/*     */   
/*     */   public void setBlipRecord(EscherBlipRecord blipRecord) {
/* 295 */     this.field_12_blipRecord = blipRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getRemainingData()
/*     */   {
/* 302 */     return this._remainingData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRemainingData(byte[] remainingData)
/*     */   {
/* 309 */     this._remainingData = remainingData;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 313 */     String extraData = this._remainingData == null ? null : HexDump.toHex(this._remainingData, 32);
/* 314 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex((short)61447) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  BlipTypeWin32: " + this.field_1_blipTypeWin32 + '\n' + "  BlipTypeMacOS: " + this.field_2_blipTypeMacOS + '\n' + "  SUID: " + (this.field_3_uid == null ? "" : HexDump.toHex(this.field_3_uid)) + '\n' + "  Tag: " + this.field_4_tag + '\n' + "  Size: " + this.field_5_size + '\n' + "  Ref: " + this.field_6_ref + '\n' + "  Offset: " + this.field_7_offset + '\n' + "  Usage: " + this.field_8_usage + '\n' + "  Name: " + this.field_9_name + '\n' + "  Unused2: " + this.field_10_unused2 + '\n' + "  Unused3: " + this.field_11_unused3 + '\n' + "  blipRecord: " + this.field_12_blipRecord + '\n' + "  Extra Data:" + '\n' + extraData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getBlipType(byte b)
/*     */   {
/* 336 */     switch (b) {
/* 337 */     case 0:  return " ERROR";
/* 338 */     case 1:  return " UNKNOWN";
/* 339 */     case 2:  return " EMF";
/* 340 */     case 3:  return " WMF";
/* 341 */     case 4:  return " PICT";
/* 342 */     case 5:  return " JPEG";
/* 343 */     case 6:  return " PNG";
/* 344 */     case 7:  return " DIB";
/*     */     }
/* 346 */     if (b < 32) {
/* 347 */       return " NotKnown";
/*     */     }
/* 349 */     return " Client";
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherBSERecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */