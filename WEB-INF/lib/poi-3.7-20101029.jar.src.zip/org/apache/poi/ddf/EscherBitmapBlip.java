/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherBitmapBlip
/*     */   extends EscherBlipRecord
/*     */ {
/*     */   public static final short RECORD_ID_JPEG = -4067;
/*     */   public static final short RECORD_ID_PNG = -4066;
/*     */   public static final short RECORD_ID_DIB = -4065;
/*     */   private static final int HEADER_SIZE = 8;
/*     */   private byte[] field_1_UID;
/*  36 */   private byte field_2_marker = -1;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory) {
/*  39 */     int bytesAfterHeader = readHeader(data, offset);
/*  40 */     int pos = offset + 8;
/*     */     
/*  42 */     this.field_1_UID = new byte[16];
/*  43 */     System.arraycopy(data, pos, this.field_1_UID, 0, 16);pos += 16;
/*  44 */     this.field_2_marker = data[pos];pos++;
/*     */     
/*  46 */     this.field_pictureData = new byte[bytesAfterHeader - 17];
/*  47 */     System.arraycopy(data, pos, this.field_pictureData, 0, this.field_pictureData.length);
/*     */     
/*  49 */     return bytesAfterHeader + 8;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  54 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  56 */     LittleEndian.putShort(data, offset, getOptions());
/*  57 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  58 */     LittleEndian.putInt(data, offset + 4, getRecordSize() - 8);
/*  59 */     int pos = offset + 8;
/*     */     
/*  61 */     System.arraycopy(this.field_1_UID, 0, data, pos, 16);
/*  62 */     data[(pos + 16)] = this.field_2_marker;
/*  63 */     System.arraycopy(this.field_pictureData, 0, data, pos + 17, this.field_pictureData.length);
/*     */     
/*  65 */     listener.afterRecordSerialize(offset + getRecordSize(), getRecordId(), getRecordSize(), this);
/*  66 */     return 25 + this.field_pictureData.length;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  71 */     return 25 + this.field_pictureData.length;
/*     */   }
/*     */   
/*     */   public byte[] getUID()
/*     */   {
/*  76 */     return this.field_1_UID;
/*     */   }
/*     */   
/*     */   public void setUID(byte[] field_1_UID)
/*     */   {
/*  81 */     this.field_1_UID = field_1_UID;
/*     */   }
/*     */   
/*     */   public byte getMarker()
/*     */   {
/*  86 */     return this.field_2_marker;
/*     */   }
/*     */   
/*     */   public void setMarker(byte field_2_marker)
/*     */   {
/*  91 */     this.field_2_marker = field_2_marker;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  96 */     String nl = System.getProperty("line.separator");
/*     */     
/*     */ 
/*  99 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/*     */     String extraData;
/*     */     try {
/* 102 */       HexDump.dump(this.field_pictureData, 0L, b, 0);
/* 103 */       extraData = b.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 107 */       extraData = e.toString();
/*     */     }
/* 109 */     return getClass().getName() + ":" + nl + "  RecordId: 0x" + HexDump.toHex(getRecordId()) + nl + "  Options: 0x" + HexDump.toHex(getOptions()) + nl + "  UID: 0x" + HexDump.toHex(this.field_1_UID) + nl + "  Marker: 0x" + HexDump.toHex(this.field_2_marker) + nl + "  Extra Data:" + nl + extraData;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherBitmapBlip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */