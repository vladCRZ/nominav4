/*    */ package org.apache.poi.ddf;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndian;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EscherBlipRecord
/*    */   extends EscherRecord
/*    */ {
/*    */   public static final short RECORD_ID_START = -4072;
/*    */   public static final short RECORD_ID_END = -3817;
/*    */   public static final String RECORD_DESCRIPTION = "msofbtBlip";
/*    */   private static final int HEADER_SIZE = 8;
/*    */   protected byte[] field_pictureData;
/*    */   
/*    */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*    */   {
/* 39 */     int bytesAfterHeader = readHeader(data, offset);
/* 40 */     int pos = offset + 8;
/*    */     
/* 42 */     this.field_pictureData = new byte[bytesAfterHeader];
/* 43 */     System.arraycopy(data, pos, this.field_pictureData, 0, bytesAfterHeader);
/*    */     
/* 45 */     return bytesAfterHeader + 8;
/*    */   }
/*    */   
/*    */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/* 49 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*    */     
/* 51 */     LittleEndian.putShort(data, offset, getOptions());
/* 52 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*    */     
/* 54 */     System.arraycopy(this.field_pictureData, 0, data, offset + 4, this.field_pictureData.length);
/*    */     
/* 56 */     listener.afterRecordSerialize(offset + 4 + this.field_pictureData.length, getRecordId(), this.field_pictureData.length + 4, this);
/* 57 */     return this.field_pictureData.length + 4;
/*    */   }
/*    */   
/*    */   public int getRecordSize() {
/* 61 */     return this.field_pictureData.length + 8;
/*    */   }
/*    */   
/*    */   public String getRecordName() {
/* 65 */     return "Blip";
/*    */   }
/*    */   
/*    */   public byte[] getPicturedata() {
/* 69 */     return this.field_pictureData;
/*    */   }
/*    */   
/*    */   public void setPictureData(byte[] pictureData) {
/* 73 */     this.field_pictureData = pictureData;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 77 */     String extraData = HexDump.toHex(this.field_pictureData, 32);
/* 78 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex(getRecordId()) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  Extra Data:" + '\n' + extraData;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherBlipRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */