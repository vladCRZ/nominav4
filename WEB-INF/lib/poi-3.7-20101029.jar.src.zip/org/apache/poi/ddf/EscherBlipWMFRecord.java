/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.RecordFormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherBlipWMFRecord
/*     */   extends EscherBlipRecord
/*     */ {
/*     */   public static final String RECORD_DESCRIPTION = "msofbtBlip";
/*     */   private static final int HEADER_SIZE = 8;
/*     */   private byte[] field_1_secondaryUID;
/*     */   private int field_2_cacheOfSize;
/*     */   private int field_3_boundaryTop;
/*     */   private int field_4_boundaryLeft;
/*     */   private int field_5_boundaryWidth;
/*     */   private int field_6_boundaryHeight;
/*     */   private int field_7_width;
/*     */   private int field_8_height;
/*     */   private int field_9_cacheOfSavedSize;
/*     */   private byte field_10_compressionFlag;
/*     */   private byte field_11_filter;
/*     */   private byte[] field_12_data;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  62 */     int bytesAfterHeader = readHeader(data, offset);
/*  63 */     int pos = offset + 8;
/*     */     
/*  65 */     int size = 0;
/*  66 */     this.field_1_secondaryUID = new byte[16];
/*  67 */     System.arraycopy(data, pos + size, this.field_1_secondaryUID, 0, 16);size += 16;
/*  68 */     this.field_2_cacheOfSize = LittleEndian.getInt(data, pos + size);size += 4;
/*  69 */     this.field_3_boundaryTop = LittleEndian.getInt(data, pos + size);size += 4;
/*  70 */     this.field_4_boundaryLeft = LittleEndian.getInt(data, pos + size);size += 4;
/*  71 */     this.field_5_boundaryWidth = LittleEndian.getInt(data, pos + size);size += 4;
/*  72 */     this.field_6_boundaryHeight = LittleEndian.getInt(data, pos + size);size += 4;
/*  73 */     this.field_7_width = LittleEndian.getInt(data, pos + size);size += 4;
/*  74 */     this.field_8_height = LittleEndian.getInt(data, pos + size);size += 4;
/*  75 */     this.field_9_cacheOfSavedSize = LittleEndian.getInt(data, pos + size);size += 4;
/*  76 */     this.field_10_compressionFlag = data[(pos + size)];size++;
/*  77 */     this.field_11_filter = data[(pos + size)];size++;
/*     */     
/*  79 */     int bytesRemaining = bytesAfterHeader - size;
/*  80 */     this.field_12_data = new byte[bytesRemaining];
/*  81 */     System.arraycopy(data, pos + size, this.field_12_data, 0, bytesRemaining);
/*  82 */     size += bytesRemaining;
/*     */     
/*  84 */     return 8 + size;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  89 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  91 */     LittleEndian.putShort(data, offset, getOptions());
/*  92 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  93 */     int remainingBytes = this.field_12_data.length + 36;
/*  94 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*     */     
/*  96 */     int pos = offset + 8;
/*  97 */     System.arraycopy(this.field_1_secondaryUID, 0, data, pos, 16);pos += 16;
/*  98 */     LittleEndian.putInt(data, pos, this.field_2_cacheOfSize);pos += 4;
/*  99 */     LittleEndian.putInt(data, pos, this.field_3_boundaryTop);pos += 4;
/* 100 */     LittleEndian.putInt(data, pos, this.field_4_boundaryLeft);pos += 4;
/* 101 */     LittleEndian.putInt(data, pos, this.field_5_boundaryWidth);pos += 4;
/* 102 */     LittleEndian.putInt(data, pos, this.field_6_boundaryHeight);pos += 4;
/* 103 */     LittleEndian.putInt(data, pos, this.field_7_width);pos += 4;
/* 104 */     LittleEndian.putInt(data, pos, this.field_8_height);pos += 4;
/* 105 */     LittleEndian.putInt(data, pos, this.field_9_cacheOfSavedSize);pos += 4;
/* 106 */     data[(pos++)] = this.field_10_compressionFlag;
/* 107 */     data[(pos++)] = this.field_11_filter;
/* 108 */     System.arraycopy(this.field_12_data, 0, data, pos, this.field_12_data.length);pos += this.field_12_data.length;
/*     */     
/* 110 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/* 111 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/* 116 */     return 58 + this.field_12_data.length;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/* 120 */     return "Blip";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getSecondaryUID()
/*     */   {
/* 128 */     return this.field_1_secondaryUID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSecondaryUID(byte[] field_1_secondaryUID)
/*     */   {
/* 136 */     this.field_1_secondaryUID = field_1_secondaryUID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCacheOfSize()
/*     */   {
/* 144 */     return this.field_2_cacheOfSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheOfSize(int field_2_cacheOfSize)
/*     */   {
/* 152 */     this.field_2_cacheOfSize = field_2_cacheOfSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBoundaryTop()
/*     */   {
/* 160 */     return this.field_3_boundaryTop;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBoundaryTop(int field_3_boundaryTop)
/*     */   {
/* 168 */     this.field_3_boundaryTop = field_3_boundaryTop;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBoundaryLeft()
/*     */   {
/* 176 */     return this.field_4_boundaryLeft;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBoundaryLeft(int field_4_boundaryLeft)
/*     */   {
/* 184 */     this.field_4_boundaryLeft = field_4_boundaryLeft;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBoundaryWidth()
/*     */   {
/* 192 */     return this.field_5_boundaryWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBoundaryWidth(int field_5_boundaryWidth)
/*     */   {
/* 200 */     this.field_5_boundaryWidth = field_5_boundaryWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBoundaryHeight()
/*     */   {
/* 208 */     return this.field_6_boundaryHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBoundaryHeight(int field_6_boundaryHeight)
/*     */   {
/* 216 */     this.field_6_boundaryHeight = field_6_boundaryHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 224 */     return this.field_7_width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 232 */     this.field_7_width = width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 240 */     return this.field_8_height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 248 */     this.field_8_height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCacheOfSavedSize()
/*     */   {
/* 256 */     return this.field_9_cacheOfSavedSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheOfSavedSize(int field_9_cacheOfSavedSize)
/*     */   {
/* 264 */     this.field_9_cacheOfSavedSize = field_9_cacheOfSavedSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getCompressionFlag()
/*     */   {
/* 272 */     return this.field_10_compressionFlag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompressionFlag(byte field_10_compressionFlag)
/*     */   {
/* 280 */     this.field_10_compressionFlag = field_10_compressionFlag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getFilter()
/*     */   {
/* 288 */     return this.field_11_filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilter(byte field_11_filter)
/*     */   {
/* 296 */     this.field_11_filter = field_11_filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 304 */     return this.field_12_data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(byte[] field_12_data)
/*     */   {
/* 312 */     this.field_12_data = field_12_data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 322 */     String nl = System.getProperty("line.separator");
/*     */     
/*     */ 
/* 325 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/*     */     String extraData;
/*     */     try {
/* 328 */       HexDump.dump(this.field_12_data, 0L, b, 0);
/* 329 */       extraData = b.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 333 */       extraData = e.toString();
/*     */     }
/* 335 */     return getClass().getName() + ":" + nl + "  RecordId: 0x" + HexDump.toHex(getRecordId()) + nl + "  Options: 0x" + HexDump.toHex(getOptions()) + nl + "  Secondary UID: " + HexDump.toHex(this.field_1_secondaryUID) + nl + "  CacheOfSize: " + this.field_2_cacheOfSize + nl + "  BoundaryTop: " + this.field_3_boundaryTop + nl + "  BoundaryLeft: " + this.field_4_boundaryLeft + nl + "  BoundaryWidth: " + this.field_5_boundaryWidth + nl + "  BoundaryHeight: " + this.field_6_boundaryHeight + nl + "  X: " + this.field_7_width + nl + "  Y: " + this.field_8_height + nl + "  CacheOfSavedSize: " + this.field_9_cacheOfSavedSize + nl + "  CompressionFlag: " + this.field_10_compressionFlag + nl + "  Filter: " + this.field_11_filter + nl + "  Data:" + nl + extraData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] compress(byte[] data)
/*     */   {
/* 360 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 361 */     DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(out);
/*     */     try
/*     */     {
/* 364 */       for (int i = 0; i < data.length; i++) {
/* 365 */         deflaterOutputStream.write(data[i]);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 369 */       throw new RecordFormatException(e.toString());
/*     */     }
/*     */     
/* 372 */     return out.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] decompress(byte[] data, int pos, int length)
/*     */   {
/* 386 */     byte[] compressedData = new byte[length];
/* 387 */     System.arraycopy(data, pos + 50, compressedData, 0, length);
/* 388 */     InputStream compressedInputStream = new ByteArrayInputStream(compressedData);
/* 389 */     InflaterInputStream inflaterInputStream = new InflaterInputStream(compressedInputStream);
/* 390 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */     try
/*     */     {
/*     */       int c;
/* 394 */       while ((c = inflaterInputStream.read()) != -1) {
/* 395 */         out.write(c);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 399 */       throw new RecordFormatException(e.toString());
/*     */     }
/* 401 */     return out.toByteArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherBlipWMFRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */