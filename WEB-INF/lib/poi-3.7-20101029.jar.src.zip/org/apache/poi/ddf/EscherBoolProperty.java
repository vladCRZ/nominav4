/*    */ package org.apache.poi.ddf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EscherBoolProperty
/*    */   extends EscherSimpleProperty
/*    */ {
/*    */   public EscherBoolProperty(short propertyNumber, int value)
/*    */   {
/* 41 */     super(propertyNumber, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isTrue()
/*    */   {
/* 49 */     return this.propertyValue != 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isFalse()
/*    */   {
/* 57 */     return this.propertyValue == 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherBoolProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */