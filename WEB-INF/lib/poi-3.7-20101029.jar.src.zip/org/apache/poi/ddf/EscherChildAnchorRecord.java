/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherChildAnchorRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4081;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtChildAnchor";
/*     */   private int field_1_dx1;
/*     */   private int field_2_dy1;
/*     */   private int field_3_dx2;
/*     */   private int field_4_dy2;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  43 */     int bytesRemaining = readHeader(data, offset);
/*  44 */     int pos = offset + 8;
/*  45 */     int size = 0;
/*  46 */     this.field_1_dx1 = LittleEndian.getInt(data, pos + size);size += 4;
/*  47 */     this.field_2_dy1 = LittleEndian.getInt(data, pos + size);size += 4;
/*  48 */     this.field_3_dx2 = LittleEndian.getInt(data, pos + size);size += 4;
/*  49 */     this.field_4_dy2 = LittleEndian.getInt(data, pos + size);size += 4;
/*  50 */     return 8 + size;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/*  54 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*  55 */     int pos = offset;
/*  56 */     LittleEndian.putShort(data, pos, getOptions());pos += 2;
/*  57 */     LittleEndian.putShort(data, pos, getRecordId());pos += 2;
/*  58 */     LittleEndian.putInt(data, pos, getRecordSize() - 8);pos += 4;
/*  59 */     LittleEndian.putInt(data, pos, this.field_1_dx1);pos += 4;
/*  60 */     LittleEndian.putInt(data, pos, this.field_2_dy1);pos += 4;
/*  61 */     LittleEndian.putInt(data, pos, this.field_3_dx2);pos += 4;
/*  62 */     LittleEndian.putInt(data, pos, this.field_4_dy2);pos += 4;
/*     */     
/*  64 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  65 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  70 */     return 24;
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/*  74 */     return 61455;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  78 */     return "ChildAnchor";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  87 */     String nl = System.getProperty("line.separator");
/*     */     
/*  89 */     return getClass().getName() + ":" + nl + "  RecordId: 0x" + HexDump.toHex((short)61455) + nl + "  Options: 0x" + HexDump.toHex(getOptions()) + nl + "  X1: " + this.field_1_dx1 + nl + "  Y1: " + this.field_2_dy1 + nl + "  X2: " + this.field_3_dx2 + nl + "  Y2: " + this.field_4_dy2 + nl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDx1()
/*     */   {
/* 104 */     return this.field_1_dx1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDx1(int field_1_dx1)
/*     */   {
/* 112 */     this.field_1_dx1 = field_1_dx1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDy1()
/*     */   {
/* 120 */     return this.field_2_dy1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDy1(int field_2_dy1)
/*     */   {
/* 128 */     this.field_2_dy1 = field_2_dy1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDx2()
/*     */   {
/* 136 */     return this.field_3_dx2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDx2(int field_3_dx2)
/*     */   {
/* 144 */     this.field_3_dx2 = field_3_dx2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDy2()
/*     */   {
/* 152 */     return this.field_4_dy2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDy2(int field_4_dy2)
/*     */   {
/* 160 */     this.field_4_dy2 = field_4_dy2;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherChildAnchorRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */