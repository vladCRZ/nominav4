/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherClientAnchorRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4080;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtClientAnchor";
/*     */   private short field_1_flag;
/*     */   private short field_2_col1;
/*     */   private short field_3_dx1;
/*     */   private short field_4_row1;
/*     */   private short field_5_dy1;
/*     */   private short field_6_col2;
/*     */   private short field_7_dx2;
/*     */   private short field_8_row2;
/*     */   private short field_9_dy2;
/*     */   private byte[] remainingData;
/*  51 */   private boolean shortRecord = false;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory) {
/*  54 */     int bytesRemaining = readHeader(data, offset);
/*  55 */     int pos = offset + 8;
/*  56 */     int size = 0;
/*     */     
/*     */ 
/*  59 */     if (bytesRemaining != 4)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */       this.field_1_flag = LittleEndian.getShort(data, pos + size);size += 2;
/*  66 */       this.field_2_col1 = LittleEndian.getShort(data, pos + size);size += 2;
/*  67 */       this.field_3_dx1 = LittleEndian.getShort(data, pos + size);size += 2;
/*  68 */       this.field_4_row1 = LittleEndian.getShort(data, pos + size);size += 2;
/*  69 */       if (bytesRemaining >= 18) {
/*  70 */         this.field_5_dy1 = LittleEndian.getShort(data, pos + size);size += 2;
/*  71 */         this.field_6_col2 = LittleEndian.getShort(data, pos + size);size += 2;
/*  72 */         this.field_7_dx2 = LittleEndian.getShort(data, pos + size);size += 2;
/*  73 */         this.field_8_row2 = LittleEndian.getShort(data, pos + size);size += 2;
/*  74 */         this.field_9_dy2 = LittleEndian.getShort(data, pos + size);size += 2;
/*  75 */         this.shortRecord = false;
/*     */       } else {
/*  77 */         this.shortRecord = true;
/*     */       }
/*     */     }
/*  80 */     bytesRemaining -= size;
/*  81 */     this.remainingData = new byte[bytesRemaining];
/*  82 */     System.arraycopy(data, pos + size, this.remainingData, 0, bytesRemaining);
/*  83 */     return 8 + size + bytesRemaining;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  88 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  90 */     if (this.remainingData == null) this.remainingData = new byte[0];
/*  91 */     LittleEndian.putShort(data, offset, getOptions());
/*  92 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  93 */     int remainingBytes = this.remainingData.length + (this.shortRecord ? 8 : 18);
/*  94 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*  95 */     LittleEndian.putShort(data, offset + 8, this.field_1_flag);
/*  96 */     LittleEndian.putShort(data, offset + 10, this.field_2_col1);
/*  97 */     LittleEndian.putShort(data, offset + 12, this.field_3_dx1);
/*  98 */     LittleEndian.putShort(data, offset + 14, this.field_4_row1);
/*  99 */     if (!this.shortRecord) {
/* 100 */       LittleEndian.putShort(data, offset + 16, this.field_5_dy1);
/* 101 */       LittleEndian.putShort(data, offset + 18, this.field_6_col2);
/* 102 */       LittleEndian.putShort(data, offset + 20, this.field_7_dx2);
/* 103 */       LittleEndian.putShort(data, offset + 22, this.field_8_row2);
/* 104 */       LittleEndian.putShort(data, offset + 24, this.field_9_dy2);
/*     */     }
/* 106 */     System.arraycopy(this.remainingData, 0, data, offset + (this.shortRecord ? 16 : 26), this.remainingData.length);
/* 107 */     int pos = offset + 8 + (this.shortRecord ? 8 : 18) + this.remainingData.length;
/*     */     
/* 109 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/* 110 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/* 115 */     return 8 + (this.shortRecord ? 8 : 18) + (this.remainingData == null ? 0 : this.remainingData.length);
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/* 119 */     return 61456;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/* 123 */     return "ClientAnchor";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 133 */     String nl = System.getProperty("line.separator");
/*     */     
/*     */ 
/* 136 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/*     */     String extraData;
/*     */     try {
/* 139 */       HexDump.dump(this.remainingData, 0L, b, 0);
/* 140 */       extraData = b.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 144 */       extraData = "error\n";
/*     */     }
/* 146 */     return getClass().getName() + ":" + nl + "  RecordId: 0x" + HexDump.toHex((short)61456) + nl + "  Options: 0x" + HexDump.toHex(getOptions()) + nl + "  Flag: " + this.field_1_flag + nl + "  Col1: " + this.field_2_col1 + nl + "  DX1: " + this.field_3_dx1 + nl + "  Row1: " + this.field_4_row1 + nl + "  DY1: " + this.field_5_dy1 + nl + "  Col2: " + this.field_6_col2 + nl + "  DX2: " + this.field_7_dx2 + nl + "  Row2: " + this.field_8_row2 + nl + "  DY2: " + this.field_9_dy2 + nl + "  Extra Data:" + nl + extraData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFlag()
/*     */   {
/* 167 */     return this.field_1_flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlag(short field_1_flag)
/*     */   {
/* 175 */     this.field_1_flag = field_1_flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCol1()
/*     */   {
/* 183 */     return this.field_2_col1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCol1(short field_2_col1)
/*     */   {
/* 191 */     this.field_2_col1 = field_2_col1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDx1()
/*     */   {
/* 199 */     return this.field_3_dx1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDx1(short field_3_dx1)
/*     */   {
/* 207 */     this.field_3_dx1 = field_3_dx1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getRow1()
/*     */   {
/* 215 */     return this.field_4_row1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRow1(short field_4_row1)
/*     */   {
/* 223 */     this.field_4_row1 = field_4_row1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDy1()
/*     */   {
/* 231 */     return this.field_5_dy1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDy1(short field_5_dy1)
/*     */   {
/* 239 */     this.shortRecord = false;
/* 240 */     this.field_5_dy1 = field_5_dy1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCol2()
/*     */   {
/* 248 */     return this.field_6_col2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCol2(short field_6_col2)
/*     */   {
/* 256 */     this.shortRecord = false;
/* 257 */     this.field_6_col2 = field_6_col2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDx2()
/*     */   {
/* 265 */     return this.field_7_dx2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDx2(short field_7_dx2)
/*     */   {
/* 273 */     this.shortRecord = false;
/* 274 */     this.field_7_dx2 = field_7_dx2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getRow2()
/*     */   {
/* 282 */     return this.field_8_row2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRow2(short field_8_row2)
/*     */   {
/* 290 */     this.shortRecord = false;
/* 291 */     this.field_8_row2 = field_8_row2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDy2()
/*     */   {
/* 299 */     return this.field_9_dy2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDy2(short field_9_dy2)
/*     */   {
/* 307 */     this.shortRecord = false;
/* 308 */     this.field_9_dy2 = field_9_dy2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getRemainingData()
/*     */   {
/* 316 */     return this.remainingData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemainingData(byte[] remainingData)
/*     */   {
/* 324 */     this.remainingData = remainingData;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherClientAnchorRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */