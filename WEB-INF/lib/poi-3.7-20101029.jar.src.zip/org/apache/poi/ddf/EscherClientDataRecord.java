/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherClientDataRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4079;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtClientData";
/*     */   private byte[] remainingData;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  41 */     int bytesRemaining = readHeader(data, offset);
/*  42 */     int pos = offset + 8;
/*  43 */     this.remainingData = new byte[bytesRemaining];
/*  44 */     System.arraycopy(data, pos, this.remainingData, 0, bytesRemaining);
/*  45 */     return 8 + bytesRemaining;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/*  49 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  51 */     if (this.remainingData == null) this.remainingData = new byte[0];
/*  52 */     LittleEndian.putShort(data, offset, getOptions());
/*  53 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  54 */     LittleEndian.putInt(data, offset + 4, this.remainingData.length);
/*  55 */     System.arraycopy(this.remainingData, 0, data, offset + 8, this.remainingData.length);
/*  56 */     int pos = offset + 8 + this.remainingData.length;
/*     */     
/*  58 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  59 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  64 */     return 8 + (this.remainingData == null ? 0 : this.remainingData.length);
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/*  68 */     return 61457;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  72 */     return "ClientData";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  80 */     String nl = System.getProperty("line.separator");
/*     */     
/*     */ 
/*  83 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/*     */     String extraData;
/*     */     try {
/*  86 */       HexDump.dump(this.remainingData, 0L, b, 0);
/*  87 */       extraData = b.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  91 */       extraData = "error\n";
/*     */     }
/*  93 */     return getClass().getName() + ":" + nl + "  RecordId: 0x" + HexDump.toHex((short)61457) + nl + "  Options: 0x" + HexDump.toHex(getOptions()) + nl + "  Extra Data:" + nl + extraData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getRemainingData()
/*     */   {
/* 106 */     return this.remainingData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemainingData(byte[] remainingData)
/*     */   {
/* 114 */     this.remainingData = remainingData;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherClientDataRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */