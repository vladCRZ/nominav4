/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherComplexProperty
/*     */   extends EscherProperty
/*     */ {
/*     */   protected byte[] _complexData;
/*     */   
/*     */   public EscherComplexProperty(short id, byte[] complexData)
/*     */   {
/*  45 */     super(id);
/*  46 */     this._complexData = complexData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherComplexProperty(short propertyNumber, boolean isBlipId, byte[] complexData)
/*     */   {
/*  58 */     super(propertyNumber, true, isBlipId);
/*  59 */     this._complexData = complexData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int serializeSimplePart(byte[] data, int pos)
/*     */   {
/*  66 */     LittleEndian.putShort(data, pos, getId());
/*  67 */     LittleEndian.putInt(data, pos + 2, this._complexData.length);
/*  68 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serializeComplexPart(byte[] data, int pos)
/*     */   {
/*  79 */     System.arraycopy(this._complexData, 0, data, pos, this._complexData.length);
/*  80 */     return this._complexData.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getComplexData()
/*     */   {
/*  87 */     return this._complexData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  97 */     if (this == o) {
/*  98 */       return true;
/*     */     }
/* 100 */     if (!(o instanceof EscherComplexProperty)) {
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     EscherComplexProperty escherComplexProperty = (EscherComplexProperty)o;
/*     */     
/* 106 */     if (!Arrays.equals(this._complexData, escherComplexProperty._complexData)) { return false;
/*     */     }
/* 108 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPropertySize()
/*     */   {
/* 117 */     return 6 + this._complexData.length;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 121 */     return getId() * 11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 128 */     String dataStr = HexDump.toHex(this._complexData, 32);
/*     */     
/* 130 */     return "propNum: " + getPropertyNumber() + ", propName: " + EscherProperties.getPropertyName(getPropertyNumber()) + ", complex: " + isComplex() + ", blipId: " + isBlipId() + ", data: " + System.getProperty("line.separator") + dataStr;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherComplexProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */