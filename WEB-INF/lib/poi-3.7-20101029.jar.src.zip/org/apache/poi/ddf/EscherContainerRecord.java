/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherContainerRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short DGG_CONTAINER = -4096;
/*     */   public static final short BSTORE_CONTAINER = -4095;
/*     */   public static final short DG_CONTAINER = -4094;
/*     */   public static final short SPGR_CONTAINER = -4093;
/*     */   public static final short SP_CONTAINER = -4092;
/*     */   public static final short SOLVER_CONTAINER = -4091;
/*     */   private final List<EscherRecord> _childRecords;
/*     */   
/*  45 */   public EscherContainerRecord() { this._childRecords = new ArrayList(); }
/*     */   
/*     */   public int fillFields(byte[] data, int pOffset, EscherRecordFactory recordFactory) {
/*  48 */     int bytesRemaining = readHeader(data, pOffset);
/*  49 */     int bytesWritten = 8;
/*  50 */     int offset = pOffset + 8;
/*  51 */     while ((bytesRemaining > 0) && (offset < data.length)) {
/*  52 */       EscherRecord child = recordFactory.createRecord(data, offset);
/*  53 */       int childBytesWritten = child.fillFields(data, offset, recordFactory);
/*  54 */       bytesWritten += childBytesWritten;
/*  55 */       offset += childBytesWritten;
/*  56 */       bytesRemaining -= childBytesWritten;
/*  57 */       addChildRecord(child);
/*  58 */       if ((offset >= data.length) && (bytesRemaining > 0)) {
/*  59 */         System.out.println("WARNING: " + bytesRemaining + " bytes remaining but no space left");
/*     */       }
/*     */     }
/*  62 */     return bytesWritten;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  67 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  69 */     LittleEndian.putShort(data, offset, getOptions());
/*  70 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  71 */     int remainingBytes = 0;
/*  72 */     Iterator<EscherRecord> iterator = this._childRecords.iterator();
/*  73 */     while (iterator.hasNext()) {
/*  74 */       EscherRecord r = (EscherRecord)iterator.next();
/*  75 */       remainingBytes += r.getRecordSize();
/*     */     }
/*  77 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*  78 */     int pos = offset + 8;
/*  79 */     iterator = this._childRecords.iterator();
/*  80 */     while (iterator.hasNext()) {
/*  81 */       EscherRecord r = (EscherRecord)iterator.next();
/*  82 */       pos += r.serialize(pos, data, listener);
/*     */     }
/*     */     
/*  85 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  86 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/*  90 */     int childRecordsSize = 0;
/*  91 */     Iterator<EscherRecord> iterator = this._childRecords.iterator();
/*  92 */     while (iterator.hasNext()) {
/*  93 */       EscherRecord r = (EscherRecord)iterator.next();
/*  94 */       childRecordsSize += r.getRecordSize();
/*     */     }
/*  96 */     return 8 + childRecordsSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasChildOfType(short recordId)
/*     */   {
/* 104 */     Iterator<EscherRecord> iterator = this._childRecords.iterator();
/* 105 */     while (iterator.hasNext()) {
/* 106 */       EscherRecord r = (EscherRecord)iterator.next();
/* 107 */       if (r.getRecordId() == recordId) {
/* 108 */         return true;
/*     */       }
/*     */     }
/* 111 */     return false;
/*     */   }
/*     */   
/* 114 */   public EscherRecord getChild(int index) { return (EscherRecord)this._childRecords.get(index); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<EscherRecord> getChildRecords()
/*     */   {
/* 121 */     return new ArrayList(this._childRecords);
/*     */   }
/*     */   
/*     */ 
/* 125 */   public Iterator<EscherRecord> getChildIterator() { return new ReadOnlyIterator(this._childRecords); }
/*     */   
/*     */   private static final class ReadOnlyIterator implements Iterator<EscherRecord> {
/*     */     private final List<EscherRecord> _list;
/*     */     private int _index;
/*     */     
/*     */     public ReadOnlyIterator(List<EscherRecord> list) {
/* 132 */       this._list = list;
/* 133 */       this._index = 0;
/*     */     }
/*     */     
/*     */ 
/* 137 */     public boolean hasNext() { return this._index < this._list.size(); }
/*     */     
/*     */     public EscherRecord next() {
/* 140 */       if (!hasNext()) {
/* 141 */         throw new NoSuchElementException();
/*     */       }
/* 143 */       return (EscherRecord)this._list.get(this._index++);
/*     */     }
/*     */     
/* 146 */     public void remove() { throw new UnsupportedOperationException(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setChildRecords(List<EscherRecord> childRecords)
/*     */   {
/* 153 */     if (childRecords == this._childRecords) {
/* 154 */       throw new IllegalStateException("Child records private data member has escaped");
/*     */     }
/* 156 */     this._childRecords.clear();
/* 157 */     this._childRecords.addAll(childRecords);
/*     */   }
/*     */   
/*     */   public boolean removeChildRecord(EscherRecord toBeRemoved) {
/* 161 */     return this._childRecords.remove(toBeRemoved);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<EscherContainerRecord> getChildContainers()
/*     */   {
/* 172 */     List<EscherContainerRecord> containers = new ArrayList();
/* 173 */     Iterator<EscherRecord> iterator = this._childRecords.iterator();
/* 174 */     while (iterator.hasNext()) {
/* 175 */       EscherRecord r = (EscherRecord)iterator.next();
/* 176 */       if ((r instanceof EscherContainerRecord)) {
/* 177 */         containers.add((EscherContainerRecord)r);
/*     */       }
/*     */     }
/* 180 */     return containers;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/* 184 */     switch (getRecordId()) {
/*     */     case -4096: 
/* 186 */       return "DggContainer";
/*     */     case -4095: 
/* 188 */       return "BStoreContainer";
/*     */     case -4094: 
/* 190 */       return "DgContainer";
/*     */     case -4093: 
/* 192 */       return "SpgrContainer";
/*     */     case -4092: 
/* 194 */       return "SpContainer";
/*     */     case -4091: 
/* 196 */       return "SolverContainer";
/*     */     }
/* 198 */     return "Container 0x" + HexDump.toHex(getRecordId());
/*     */   }
/*     */   
/*     */   public void display(PrintWriter w, int indent)
/*     */   {
/* 203 */     super.display(w, indent);
/* 204 */     for (Iterator<EscherRecord> iterator = this._childRecords.iterator(); iterator.hasNext();)
/*     */     {
/* 206 */       EscherRecord escherRecord = (EscherRecord)iterator.next();
/* 207 */       escherRecord.display(w, indent + 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addChildRecord(EscherRecord record) {
/* 212 */     this._childRecords.add(record);
/*     */   }
/*     */   
/*     */   public void addChildBefore(EscherRecord record, int insertBeforeRecordId) {
/* 216 */     for (int i = 0; i < this._childRecords.size(); i++) {
/* 217 */       EscherRecord rec = (EscherRecord)this._childRecords.get(i);
/* 218 */       if (rec.getRecordId() == insertBeforeRecordId) {
/* 219 */         this._childRecords.add(i++, record);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 227 */     return toString("");
/*     */   }
/*     */   
/*     */   public String toString(String indent) {
/* 231 */     String nl = System.getProperty("line.separator");
/*     */     
/* 233 */     StringBuffer children = new StringBuffer();
/* 234 */     int count; Iterator<EscherRecord> iterator; if (this._childRecords.size() > 0) {
/* 235 */       children.append("  children: " + nl);
/*     */       
/* 237 */       count = 0;
/* 238 */       for (iterator = this._childRecords.iterator(); iterator.hasNext();)
/*     */       {
/* 240 */         String newIndent = indent + "   ";
/*     */         
/* 242 */         EscherRecord record = (EscherRecord)iterator.next();
/* 243 */         children.append(newIndent + "Child " + count + ":" + nl);
/*     */         
/* 245 */         if ((record instanceof EscherContainerRecord)) {
/* 246 */           EscherContainerRecord ecr = (EscherContainerRecord)record;
/* 247 */           children.append(ecr.toString(newIndent));
/*     */         } else {
/* 249 */           children.append(record.toString());
/*     */         }
/* 251 */         count++;
/*     */       }
/*     */     }
/*     */     
/* 255 */     return indent + getClass().getName() + " (" + getRecordName() + "):" + nl + indent + "  isContainer: " + isContainerRecord() + nl + indent + "  options: 0x" + HexDump.toHex(getOptions()) + nl + indent + "  recordId: 0x" + HexDump.toHex(getRecordId()) + nl + indent + "  numchildren: " + this._childRecords.size() + nl + indent + children.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherSpRecord getChildById(short recordId)
/*     */   {
/* 266 */     Iterator<EscherRecord> iterator = this._childRecords.iterator();
/* 267 */     while (iterator.hasNext()) {
/* 268 */       EscherRecord r = (EscherRecord)iterator.next();
/* 269 */       if (r.getRecordId() == recordId)
/* 270 */         return (EscherSpRecord)r;
/*     */     }
/* 272 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getRecordsById(short recordId, List<EscherRecord> out)
/*     */   {
/* 281 */     Iterator<EscherRecord> iterator = this._childRecords.iterator();
/* 282 */     while (iterator.hasNext()) {
/* 283 */       EscherRecord r = (EscherRecord)iterator.next();
/* 284 */       if ((r instanceof EscherContainerRecord)) {
/* 285 */         EscherContainerRecord c = (EscherContainerRecord)r;
/* 286 */         c.getRecordsById(recordId, out);
/* 287 */       } else if (r.getRecordId() == recordId) {
/* 288 */         out.add(r);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherContainerRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */