/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherDgRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4088;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtDg";
/*     */   private int field_1_numShapes;
/*     */   private int field_2_lastMSOSPID;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  40 */     int bytesRemaining = readHeader(data, offset);
/*  41 */     int pos = offset + 8;
/*  42 */     int size = 0;
/*  43 */     this.field_1_numShapes = LittleEndian.getInt(data, pos + size);size += 4;
/*  44 */     this.field_2_lastMSOSPID = LittleEndian.getInt(data, pos + size);size += 4;
/*     */     
/*     */ 
/*     */ 
/*  48 */     return getRecordSize();
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  53 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  55 */     LittleEndian.putShort(data, offset, getOptions());
/*  56 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  57 */     LittleEndian.putInt(data, offset + 4, 8);
/*  58 */     LittleEndian.putInt(data, offset + 8, this.field_1_numShapes);
/*  59 */     LittleEndian.putInt(data, offset + 12, this.field_2_lastMSOSPID);
/*     */     
/*     */ 
/*     */ 
/*  63 */     listener.afterRecordSerialize(offset + 16, getRecordId(), getRecordSize(), this);
/*  64 */     return getRecordSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordSize()
/*     */   {
/*  74 */     return 16;
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/*  78 */     return 61448;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  82 */     return "Dg";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  89 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex((short)61448) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  NumShapes: " + this.field_1_numShapes + '\n' + "  LastMSOSPID: " + this.field_2_lastMSOSPID + '\n';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumShapes()
/*     */   {
/* 102 */     return this.field_1_numShapes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumShapes(int field_1_numShapes)
/*     */   {
/* 110 */     this.field_1_numShapes = field_1_numShapes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastMSOSPID()
/*     */   {
/* 118 */     return this.field_2_lastMSOSPID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastMSOSPID(int field_2_lastMSOSPID)
/*     */   {
/* 126 */     this.field_2_lastMSOSPID = field_2_lastMSOSPID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDrawingGroupId()
/*     */   {
/* 137 */     return (short)(getOptions() >> 4);
/*     */   }
/*     */   
/*     */   public void incrementShapeCount()
/*     */   {
/* 142 */     this.field_1_numShapes += 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherDgRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */