/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.RecordFormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherDggRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4090;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtDgg";
/*     */   private int field_1_shapeIdMax;
/*     */   private int field_3_numShapesSaved;
/*     */   private int field_4_drawingsSaved;
/*     */   private FileIdCluster[] field_5_fileIdClusters;
/*     */   private int maxDgId;
/*     */   
/*     */   public static class FileIdCluster
/*     */   {
/*     */     private int field_1_drawingGroupId;
/*     */     private int field_2_numShapeIdsUsed;
/*     */     
/*     */     public FileIdCluster(int drawingGroupId, int numShapeIdsUsed)
/*     */     {
/*  44 */       this.field_1_drawingGroupId = drawingGroupId;
/*  45 */       this.field_2_numShapeIdsUsed = numShapeIdsUsed;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getDrawingGroupId()
/*     */     {
/*  53 */       return this.field_1_drawingGroupId;
/*     */     }
/*     */     
/*     */     public int getNumShapeIdsUsed()
/*     */     {
/*  58 */       return this.field_2_numShapeIdsUsed;
/*     */     }
/*     */     
/*     */     public void incrementShapeId()
/*     */     {
/*  63 */       this.field_2_numShapeIdsUsed += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory) {
/*  68 */     int bytesRemaining = readHeader(data, offset);
/*  69 */     int pos = offset + 8;
/*  70 */     int size = 0;
/*  71 */     this.field_1_shapeIdMax = LittleEndian.getInt(data, pos + size);size += 4;
/*  72 */     LittleEndian.getInt(data, pos + size);size += 4;
/*  73 */     this.field_3_numShapesSaved = LittleEndian.getInt(data, pos + size);size += 4;
/*  74 */     this.field_4_drawingsSaved = LittleEndian.getInt(data, pos + size);size += 4;
/*  75 */     this.field_5_fileIdClusters = new FileIdCluster[(bytesRemaining - size) / 8];
/*  76 */     for (int i = 0; i < this.field_5_fileIdClusters.length; i++)
/*     */     {
/*  78 */       this.field_5_fileIdClusters[i] = new FileIdCluster(LittleEndian.getInt(data, pos + size), LittleEndian.getInt(data, pos + size + 4));
/*  79 */       this.maxDgId = Math.max(this.maxDgId, this.field_5_fileIdClusters[i].getDrawingGroupId());
/*  80 */       size += 8;
/*     */     }
/*  82 */     bytesRemaining -= size;
/*  83 */     if (bytesRemaining != 0)
/*  84 */       throw new RecordFormatException("Expecting no remaining data but got " + bytesRemaining + " byte(s).");
/*  85 */     return 8 + size + bytesRemaining;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/*  89 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  91 */     int pos = offset;
/*  92 */     LittleEndian.putShort(data, pos, getOptions());pos += 2;
/*  93 */     LittleEndian.putShort(data, pos, getRecordId());pos += 2;
/*  94 */     int remainingBytes = getRecordSize() - 8;
/*  95 */     LittleEndian.putInt(data, pos, remainingBytes);pos += 4;
/*     */     
/*  97 */     LittleEndian.putInt(data, pos, this.field_1_shapeIdMax);pos += 4;
/*  98 */     LittleEndian.putInt(data, pos, getNumIdClusters());pos += 4;
/*  99 */     LittleEndian.putInt(data, pos, this.field_3_numShapesSaved);pos += 4;
/* 100 */     LittleEndian.putInt(data, pos, this.field_4_drawingsSaved);pos += 4;
/* 101 */     for (int i = 0; i < this.field_5_fileIdClusters.length; i++) {
/* 102 */       LittleEndian.putInt(data, pos, this.field_5_fileIdClusters[i].field_1_drawingGroupId);pos += 4;
/* 103 */       LittleEndian.putInt(data, pos, this.field_5_fileIdClusters[i].field_2_numShapeIdsUsed);pos += 4;
/*     */     }
/*     */     
/* 106 */     listener.afterRecordSerialize(pos, getRecordId(), getRecordSize(), this);
/* 107 */     return getRecordSize();
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/* 111 */     return 24 + 8 * this.field_5_fileIdClusters.length;
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/* 115 */     return 61446;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/* 119 */     return "Dgg";
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 124 */     StringBuffer field_5_string = new StringBuffer();
/* 125 */     if (this.field_5_fileIdClusters != null) for (int i = 0; i < this.field_5_fileIdClusters.length; i++) {
/* 126 */         field_5_string.append("  DrawingGroupId").append(i + 1).append(": ");
/* 127 */         field_5_string.append(this.field_5_fileIdClusters[i].field_1_drawingGroupId);
/* 128 */         field_5_string.append('\n');
/* 129 */         field_5_string.append("  NumShapeIdsUsed").append(i + 1).append(": ");
/* 130 */         field_5_string.append(this.field_5_fileIdClusters[i].field_2_numShapeIdsUsed);
/* 131 */         field_5_string.append('\n');
/*     */       }
/* 133 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex((short)61446) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  ShapeIdMax: " + this.field_1_shapeIdMax + '\n' + "  NumIdClusters: " + getNumIdClusters() + '\n' + "  NumShapesSaved: " + this.field_3_numShapesSaved + '\n' + "  DrawingsSaved: " + this.field_4_drawingsSaved + '\n' + "" + field_5_string.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getShapeIdMax()
/*     */   {
/* 145 */     return this.field_1_shapeIdMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setShapeIdMax(int shapeIdMax)
/*     */   {
/* 152 */     this.field_1_shapeIdMax = shapeIdMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNumIdClusters()
/*     */   {
/* 159 */     return this.field_5_fileIdClusters == null ? 0 : this.field_5_fileIdClusters.length + 1;
/*     */   }
/*     */   
/*     */   public int getNumShapesSaved() {
/* 163 */     return this.field_3_numShapesSaved;
/*     */   }
/*     */   
/*     */   public void setNumShapesSaved(int numShapesSaved) {
/* 167 */     this.field_3_numShapesSaved = numShapesSaved;
/*     */   }
/*     */   
/*     */   public int getDrawingsSaved() {
/* 171 */     return this.field_4_drawingsSaved;
/*     */   }
/*     */   
/*     */   public void setDrawingsSaved(int drawingsSaved) {
/* 175 */     this.field_4_drawingsSaved = drawingsSaved;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxDrawingGroupId()
/*     */   {
/* 182 */     return this.maxDgId;
/*     */   }
/*     */   
/*     */   public void setMaxDrawingGroupId(int id) {
/* 186 */     this.maxDgId = id;
/*     */   }
/*     */   
/*     */   public FileIdCluster[] getFileIdClusters() {
/* 190 */     return this.field_5_fileIdClusters;
/*     */   }
/*     */   
/*     */   public void setFileIdClusters(FileIdCluster[] fileIdClusters) {
/* 194 */     this.field_5_fileIdClusters = fileIdClusters;
/*     */   }
/*     */   
/*     */   public void addCluster(int dgId, int numShapedUsed) {
/* 198 */     addCluster(dgId, numShapedUsed, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCluster(int dgId, int numShapedUsed, boolean sort)
/*     */   {
/* 210 */     List<FileIdCluster> clusters = new ArrayList(Arrays.asList(this.field_5_fileIdClusters));
/* 211 */     clusters.add(new FileIdCluster(dgId, numShapedUsed));
/* 212 */     if (sort) Collections.sort(clusters, MY_COMP);
/* 213 */     this.maxDgId = Math.min(this.maxDgId, dgId);
/* 214 */     this.field_5_fileIdClusters = ((FileIdCluster[])clusters.toArray(new FileIdCluster[clusters.size()]));
/*     */   }
/*     */   
/* 217 */   private static final Comparator<FileIdCluster> MY_COMP = new Comparator() {
/*     */     public int compare(EscherDggRecord.FileIdCluster f1, EscherDggRecord.FileIdCluster f2) {
/* 219 */       if (f1.getDrawingGroupId() == f2.getDrawingGroupId()) {
/* 220 */         return 0;
/*     */       }
/* 222 */       if (f1.getDrawingGroupId() < f2.getDrawingGroupId()) {
/* 223 */         return -1;
/*     */       }
/* 225 */       return 1;
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherDggRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */