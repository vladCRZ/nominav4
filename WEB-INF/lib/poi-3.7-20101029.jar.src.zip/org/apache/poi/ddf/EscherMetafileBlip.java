/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.POILogFactory;
/*     */ import org.apache.poi.util.POILogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherMetafileBlip
/*     */   extends EscherBlipRecord
/*     */ {
/*  36 */   private static final POILogger log = POILogFactory.getLogger(EscherMetafileBlip.class);
/*     */   
/*     */   public static final short RECORD_ID_EMF = -4070;
/*     */   
/*     */   public static final short RECORD_ID_WMF = -4069;
/*     */   
/*     */   public static final short RECORD_ID_PICT = -4068;
/*     */   
/*     */   public static final short SIGNATURE_EMF = 15680;
/*     */   
/*     */   public static final short SIGNATURE_WMF = 8544;
/*     */   
/*     */   public static final short SIGNATURE_PICT = 21536;
/*     */   
/*     */   private static final int HEADER_SIZE = 8;
/*     */   
/*     */   private byte[] field_1_UID;
/*     */   
/*     */   private byte[] field_2_UID;
/*     */   
/*     */   private int field_2_cb;
/*     */   private int field_3_rcBounds_x1;
/*     */   private int field_3_rcBounds_y1;
/*     */   private int field_3_rcBounds_x2;
/*     */   private int field_3_rcBounds_y2;
/*     */   private int field_4_ptSize_w;
/*     */   private int field_4_ptSize_h;
/*     */   private int field_5_cbSave;
/*     */   private byte field_6_fCompression;
/*     */   private byte field_7_fFilter;
/*     */   private byte[] raw_pictureData;
/*     */   private byte[] remainingData;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  71 */     int bytesAfterHeader = readHeader(data, offset);
/*  72 */     int pos = offset + 8;
/*  73 */     this.field_1_UID = new byte[16];
/*  74 */     System.arraycopy(data, pos, this.field_1_UID, 0, 16);pos += 16;
/*     */     
/*  76 */     if ((getOptions() ^ getSignature()) == 16) {
/*  77 */       this.field_2_UID = new byte[16];
/*  78 */       System.arraycopy(data, pos, this.field_2_UID, 0, 16);pos += 16;
/*     */     }
/*     */     
/*  81 */     this.field_2_cb = LittleEndian.getInt(data, pos);pos += 4;
/*  82 */     this.field_3_rcBounds_x1 = LittleEndian.getInt(data, pos);pos += 4;
/*  83 */     this.field_3_rcBounds_y1 = LittleEndian.getInt(data, pos);pos += 4;
/*  84 */     this.field_3_rcBounds_x2 = LittleEndian.getInt(data, pos);pos += 4;
/*  85 */     this.field_3_rcBounds_y2 = LittleEndian.getInt(data, pos);pos += 4;
/*  86 */     this.field_4_ptSize_w = LittleEndian.getInt(data, pos);pos += 4;
/*  87 */     this.field_4_ptSize_h = LittleEndian.getInt(data, pos);pos += 4;
/*  88 */     this.field_5_cbSave = LittleEndian.getInt(data, pos);pos += 4;
/*  89 */     this.field_6_fCompression = data[pos];pos++;
/*  90 */     this.field_7_fFilter = data[pos];pos++;
/*     */     
/*  92 */     this.raw_pictureData = new byte[this.field_5_cbSave];
/*  93 */     System.arraycopy(data, pos, this.raw_pictureData, 0, this.field_5_cbSave);
/*  94 */     pos += this.field_5_cbSave;
/*     */     
/*     */ 
/*     */ 
/*  98 */     if (this.field_6_fCompression == 0) {
/*  99 */       this.field_pictureData = inflatePictureData(this.raw_pictureData);
/*     */     } else {
/* 101 */       this.field_pictureData = this.raw_pictureData;
/*     */     }
/*     */     
/* 104 */     int remaining = bytesAfterHeader - pos + offset + 8;
/* 105 */     if (remaining > 0) {
/* 106 */       this.remainingData = new byte[remaining];
/* 107 */       System.arraycopy(data, pos, this.remainingData, 0, remaining);
/*     */     }
/* 109 */     return bytesAfterHeader + 8;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/* 113 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/* 115 */     int pos = offset;
/* 116 */     LittleEndian.putShort(data, pos, getOptions());pos += 2;
/* 117 */     LittleEndian.putShort(data, pos, getRecordId());pos += 2;
/* 118 */     LittleEndian.putInt(data, pos, getRecordSize() - 8);pos += 4;
/*     */     
/* 120 */     System.arraycopy(this.field_1_UID, 0, data, pos, this.field_1_UID.length);pos += this.field_1_UID.length;
/* 121 */     if ((getOptions() ^ getSignature()) == 16) {
/* 122 */       System.arraycopy(this.field_2_UID, 0, data, pos, this.field_2_UID.length);pos += this.field_2_UID.length;
/*     */     }
/* 124 */     LittleEndian.putInt(data, pos, this.field_2_cb);pos += 4;
/* 125 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_x1);pos += 4;
/* 126 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_y1);pos += 4;
/* 127 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_x2);pos += 4;
/* 128 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_y2);pos += 4;
/* 129 */     LittleEndian.putInt(data, pos, this.field_4_ptSize_w);pos += 4;
/* 130 */     LittleEndian.putInt(data, pos, this.field_4_ptSize_h);pos += 4;
/* 131 */     LittleEndian.putInt(data, pos, this.field_5_cbSave);pos += 4;
/* 132 */     data[pos] = this.field_6_fCompression;pos++;
/* 133 */     data[pos] = this.field_7_fFilter;pos++;
/*     */     
/* 135 */     System.arraycopy(this.raw_pictureData, 0, data, pos, this.raw_pictureData.length);pos += this.raw_pictureData.length;
/* 136 */     if (this.remainingData != null) {
/* 137 */       System.arraycopy(this.remainingData, 0, data, pos, this.remainingData.length);pos += this.remainingData.length;
/*     */     }
/*     */     
/* 140 */     listener.afterRecordSerialize(offset + getRecordSize(), getRecordId(), getRecordSize(), this);
/* 141 */     return getRecordSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] inflatePictureData(byte[] data)
/*     */   {
/*     */     try
/*     */     {
/* 152 */       InflaterInputStream in = new InflaterInputStream(new ByteArrayInputStream(data));
/*     */       
/* 154 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 155 */       byte[] buf = new byte['က'];
/*     */       int readBytes;
/* 157 */       while ((readBytes = in.read(buf)) > 0) {
/* 158 */         out.write(buf, 0, readBytes);
/*     */       }
/* 160 */       return out.toByteArray();
/*     */     } catch (IOException e) {
/* 162 */       log.log(POILogger.WARN, "Possibly corrupt compression or non-compressed data", e); }
/* 163 */     return data;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/* 168 */     int size = 58 + this.raw_pictureData.length;
/* 169 */     if (this.remainingData != null) size += this.remainingData.length;
/* 170 */     if ((getOptions() ^ getSignature()) == 16) {
/* 171 */       size += this.field_2_UID.length;
/*     */     }
/* 173 */     return size;
/*     */   }
/*     */   
/*     */   public byte[] getUID() {
/* 177 */     return this.field_1_UID;
/*     */   }
/*     */   
/*     */   public void setUID(byte[] uid) {
/* 181 */     this.field_1_UID = uid;
/*     */   }
/*     */   
/*     */   public byte[] getPrimaryUID()
/*     */   {
/* 186 */     return this.field_2_UID;
/*     */   }
/*     */   
/*     */   public void setPrimaryUID(byte[] primaryUID) {
/* 190 */     this.field_2_UID = primaryUID;
/*     */   }
/*     */   
/*     */   public int getUncompressedSize() {
/* 194 */     return this.field_2_cb;
/*     */   }
/*     */   
/*     */   public void setUncompressedSize(int uncompressedSize) {
/* 198 */     this.field_2_cb = uncompressedSize;
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/* 202 */     return new Rectangle(this.field_3_rcBounds_x1, this.field_3_rcBounds_y1, this.field_3_rcBounds_x2 - this.field_3_rcBounds_x1, this.field_3_rcBounds_y2 - this.field_3_rcBounds_y1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBounds(Rectangle bounds)
/*     */   {
/* 209 */     this.field_3_rcBounds_x1 = bounds.x;
/* 210 */     this.field_3_rcBounds_y1 = bounds.y;
/* 211 */     this.field_3_rcBounds_x2 = (bounds.x + bounds.width);
/* 212 */     this.field_3_rcBounds_y2 = (bounds.y + bounds.height);
/*     */   }
/*     */   
/*     */   public Dimension getSizeEMU() {
/* 216 */     return new Dimension(this.field_4_ptSize_w, this.field_4_ptSize_h);
/*     */   }
/*     */   
/*     */   public void setSizeEMU(Dimension sizeEMU) {
/* 220 */     this.field_4_ptSize_w = sizeEMU.width;
/* 221 */     this.field_4_ptSize_h = sizeEMU.height;
/*     */   }
/*     */   
/*     */   public int getCompressedSize() {
/* 225 */     return this.field_5_cbSave;
/*     */   }
/*     */   
/*     */   public void setCompressedSize(int compressedSize) {
/* 229 */     this.field_5_cbSave = compressedSize;
/*     */   }
/*     */   
/*     */   public boolean isCompressed() {
/* 233 */     return this.field_6_fCompression == 0;
/*     */   }
/*     */   
/*     */   public void setCompressed(boolean compressed) {
/* 237 */     this.field_6_fCompression = (compressed ? 0 : -2);
/*     */   }
/*     */   
/*     */   public byte[] getRemainingData() {
/* 241 */     return this.remainingData;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 247 */     String extraData = "";
/* 248 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex(getRecordId()) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  UID: 0x" + HexDump.toHex(this.field_1_UID) + '\n' + (this.field_2_UID == null ? "" : new StringBuilder().append("  UID2: 0x").append(HexDump.toHex(this.field_2_UID)).append('\n').toString()) + "  Uncompressed Size: " + HexDump.toHex(this.field_2_cb) + '\n' + "  Bounds: " + getBounds() + '\n' + "  Size in EMU: " + getSizeEMU() + '\n' + "  Compressed Size: " + HexDump.toHex(this.field_5_cbSave) + '\n' + "  Compression: " + HexDump.toHex(this.field_6_fCompression) + '\n' + "  Filter: " + HexDump.toHex(this.field_7_fFilter) + '\n' + "  Extra Data:" + '\n' + extraData + (this.remainingData == null ? null : new StringBuilder().append("\n Remaining Data: ").append(HexDump.toHex(this.remainingData, 32)).toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSignature()
/*     */   {
/* 270 */     switch (getRecordId()) {
/* 271 */     case -4070:  return 15680;
/* 272 */     case -4069:  return 8544;
/* 273 */     case -4068:  return 21536;
/*     */     }
/* 275 */     log.log(POILogger.WARN, "Unknown metafile: " + getRecordId());
/* 276 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherMetafileBlip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */