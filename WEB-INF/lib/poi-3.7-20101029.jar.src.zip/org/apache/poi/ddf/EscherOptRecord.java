/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherOptRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4085;
/*     */   public static final String RECORD_DESCRIPTION = "msofbtOPT";
/*  43 */   private List properties = new ArrayList();
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory) {
/*  46 */     int bytesRemaining = readHeader(data, offset);
/*  47 */     int pos = offset + 8;
/*     */     
/*  49 */     EscherPropertyFactory f = new EscherPropertyFactory();
/*  50 */     this.properties = f.createProperties(data, pos, getInstance());
/*  51 */     return bytesRemaining + 8;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  56 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  58 */     LittleEndian.putShort(data, offset, getOptions());
/*  59 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  60 */     LittleEndian.putInt(data, offset + 4, getPropertiesSize());
/*  61 */     int pos = offset + 8;
/*  62 */     for (Iterator iterator = this.properties.iterator(); iterator.hasNext();)
/*     */     {
/*  64 */       EscherProperty escherProperty = (EscherProperty)iterator.next();
/*  65 */       pos += escherProperty.serializeSimplePart(data, pos);
/*     */     }
/*  67 */     for (Iterator iterator = this.properties.iterator(); iterator.hasNext();)
/*     */     {
/*  69 */       EscherProperty escherProperty = (EscherProperty)iterator.next();
/*  70 */       pos += escherProperty.serializeComplexPart(data, pos);
/*     */     }
/*  72 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  73 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  78 */     return 8 + getPropertiesSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/*  86 */     setOptions((short)(this.properties.size() << 4 | 0x3));
/*  87 */     return super.getOptions();
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  91 */     return "Opt";
/*     */   }
/*     */   
/*     */   private int getPropertiesSize()
/*     */   {
/*  96 */     int totalSize = 0;
/*  97 */     for (Iterator iterator = this.properties.iterator(); iterator.hasNext();)
/*     */     {
/*  99 */       EscherProperty escherProperty = (EscherProperty)iterator.next();
/* 100 */       totalSize += escherProperty.getPropertySize();
/*     */     }
/* 102 */     return totalSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 110 */     String nl = System.getProperty("line.separator");
/* 111 */     StringBuffer propertiesBuf = new StringBuffer();
/* 112 */     for (Iterator iterator = this.properties.iterator(); iterator.hasNext();) {
/* 113 */       propertiesBuf.append("    " + iterator.next().toString() + nl);
/*     */     }
/*     */     
/*     */ 
/* 117 */     return "org.apache.poi.ddf.EscherOptRecord:" + nl + "  isContainer: " + isContainerRecord() + nl + "  options: 0x" + HexDump.toHex(getOptions()) + nl + "  recordId: 0x" + HexDump.toHex(getRecordId()) + nl + "  numchildren: " + getChildRecords().size() + nl + "  properties:" + nl + propertiesBuf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getEscherProperties()
/*     */   {
/* 131 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherProperty getEscherProperty(int index)
/*     */   {
/* 139 */     return (EscherProperty)this.properties.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEscherProperty(EscherProperty prop)
/*     */   {
/* 147 */     this.properties.add(prop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sortProperties()
/*     */   {
/* 155 */     Collections.sort(this.properties, new Comparator()
/*     */     {
/*     */       public int compare(Object o1, Object o2)
/*     */       {
/* 159 */         EscherProperty p1 = (EscherProperty)o1;
/* 160 */         EscherProperty p2 = (EscherProperty)o2;
/* 161 */         return Short.valueOf(p1.getPropertyNumber()).compareTo(Short.valueOf(p2.getPropertyNumber()));
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherOptRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */