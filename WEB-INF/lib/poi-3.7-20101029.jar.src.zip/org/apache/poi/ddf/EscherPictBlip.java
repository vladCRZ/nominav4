/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.POILogFactory;
/*     */ import org.apache.poi.util.POILogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherPictBlip
/*     */   extends EscherBlipRecord
/*     */ {
/*  36 */   private static final POILogger log = POILogFactory.getLogger(EscherPictBlip.class);
/*     */   
/*     */   public static final short RECORD_ID_EMF = -4070;
/*     */   
/*     */   public static final short RECORD_ID_WMF = -4069;
/*     */   
/*     */   public static final short RECORD_ID_PICT = -4068;
/*     */   private static final int HEADER_SIZE = 8;
/*     */   private byte[] field_1_UID;
/*     */   private int field_2_cb;
/*     */   private int field_3_rcBounds_x1;
/*     */   private int field_3_rcBounds_y1;
/*     */   private int field_3_rcBounds_x2;
/*     */   private int field_3_rcBounds_y2;
/*     */   private int field_4_ptSize_w;
/*     */   private int field_4_ptSize_h;
/*     */   private int field_5_cbSave;
/*     */   private byte field_6_fCompression;
/*     */   private byte field_7_fFilter;
/*     */   private byte[] raw_pictureData;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  59 */     int bytesAfterHeader = readHeader(data, offset);
/*  60 */     int pos = offset + 8;
/*     */     
/*  62 */     this.field_1_UID = new byte[16];
/*  63 */     System.arraycopy(data, pos, this.field_1_UID, 0, 16);pos += 16;
/*  64 */     this.field_2_cb = LittleEndian.getInt(data, pos);pos += 4;
/*  65 */     this.field_3_rcBounds_x1 = LittleEndian.getInt(data, pos);pos += 4;
/*  66 */     this.field_3_rcBounds_y1 = LittleEndian.getInt(data, pos);pos += 4;
/*  67 */     this.field_3_rcBounds_x2 = LittleEndian.getInt(data, pos);pos += 4;
/*  68 */     this.field_3_rcBounds_y2 = LittleEndian.getInt(data, pos);pos += 4;
/*  69 */     this.field_4_ptSize_w = LittleEndian.getInt(data, pos);pos += 4;
/*  70 */     this.field_4_ptSize_h = LittleEndian.getInt(data, pos);pos += 4;
/*  71 */     this.field_5_cbSave = LittleEndian.getInt(data, pos);pos += 4;
/*  72 */     this.field_6_fCompression = data[pos];pos++;
/*  73 */     this.field_7_fFilter = data[pos];pos++;
/*     */     
/*  75 */     this.raw_pictureData = new byte[this.field_5_cbSave];
/*  76 */     System.arraycopy(data, pos, this.raw_pictureData, 0, this.field_5_cbSave);
/*     */     
/*     */ 
/*     */ 
/*  80 */     if (this.field_6_fCompression == 0)
/*     */     {
/*  82 */       this.field_pictureData = inflatePictureData(this.raw_pictureData);
/*     */     }
/*     */     else
/*     */     {
/*  86 */       this.field_pictureData = this.raw_pictureData;
/*     */     }
/*     */     
/*  89 */     return bytesAfterHeader + 8;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/*  93 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  95 */     int pos = offset;
/*  96 */     LittleEndian.putShort(data, pos, getOptions());pos += 2;
/*  97 */     LittleEndian.putShort(data, pos, getRecordId());pos += 2;
/*  98 */     LittleEndian.putInt(data, getRecordSize() - 8);pos += 4;
/*     */     
/* 100 */     System.arraycopy(this.field_1_UID, 0, data, pos, 16);pos += 16;
/* 101 */     LittleEndian.putInt(data, pos, this.field_2_cb);pos += 4;
/* 102 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_x1);pos += 4;
/* 103 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_y1);pos += 4;
/* 104 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_x2);pos += 4;
/* 105 */     LittleEndian.putInt(data, pos, this.field_3_rcBounds_y2);pos += 4;
/* 106 */     LittleEndian.putInt(data, pos, this.field_4_ptSize_w);pos += 4;
/* 107 */     LittleEndian.putInt(data, pos, this.field_4_ptSize_h);pos += 4;
/* 108 */     LittleEndian.putInt(data, pos, this.field_5_cbSave);pos += 4;
/* 109 */     data[pos] = this.field_6_fCompression;pos++;
/* 110 */     data[pos] = this.field_7_fFilter;pos++;
/*     */     
/* 112 */     System.arraycopy(this.raw_pictureData, 0, data, pos, this.raw_pictureData.length);
/*     */     
/* 114 */     listener.afterRecordSerialize(offset + getRecordSize(), getRecordId(), getRecordSize(), this);
/* 115 */     return 25 + this.raw_pictureData.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] inflatePictureData(byte[] data)
/*     */   {
/*     */     try
/*     */     {
/* 126 */       InflaterInputStream in = new InflaterInputStream(new ByteArrayInputStream(data));
/* 127 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 128 */       byte[] buf = new byte['က'];
/*     */       int readBytes;
/* 130 */       while ((readBytes = in.read(buf)) > 0) {
/* 131 */         out.write(buf, 0, readBytes);
/*     */       }
/* 133 */       return out.toByteArray();
/*     */     } catch (IOException e) {
/* 135 */       log.log(POILogger.INFO, "Possibly corrupt compression or non-compressed data", e); }
/* 136 */     return data;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/* 141 */     return 58 + this.raw_pictureData.length;
/*     */   }
/*     */   
/*     */   public byte[] getUID() {
/* 145 */     return this.field_1_UID;
/*     */   }
/*     */   
/*     */   public void setUID(byte[] uid) {
/* 149 */     this.field_1_UID = uid;
/*     */   }
/*     */   
/*     */   public int getUncompressedSize() {
/* 153 */     return this.field_2_cb;
/*     */   }
/*     */   
/*     */   public void setUncompressedSize(int uncompressedSize) {
/* 157 */     this.field_2_cb = uncompressedSize;
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/* 161 */     return new Rectangle(this.field_3_rcBounds_x1, this.field_3_rcBounds_y1, this.field_3_rcBounds_x2 - this.field_3_rcBounds_x1, this.field_3_rcBounds_y2 - this.field_3_rcBounds_y1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBounds(Rectangle bounds)
/*     */   {
/* 168 */     this.field_3_rcBounds_x1 = bounds.x;
/* 169 */     this.field_3_rcBounds_y1 = bounds.y;
/* 170 */     this.field_3_rcBounds_x2 = (bounds.x + bounds.width);
/* 171 */     this.field_3_rcBounds_y2 = (bounds.y + bounds.height);
/*     */   }
/*     */   
/*     */   public Dimension getSizeEMU() {
/* 175 */     return new Dimension(this.field_4_ptSize_w, this.field_4_ptSize_h);
/*     */   }
/*     */   
/*     */   public void setSizeEMU(Dimension sizeEMU) {
/* 179 */     this.field_4_ptSize_w = sizeEMU.width;
/* 180 */     this.field_4_ptSize_h = sizeEMU.height;
/*     */   }
/*     */   
/*     */   public int getCompressedSize() {
/* 184 */     return this.field_5_cbSave;
/*     */   }
/*     */   
/*     */   public void setCompressedSize(int compressedSize) {
/* 188 */     this.field_5_cbSave = compressedSize;
/*     */   }
/*     */   
/*     */   public boolean isCompressed() {
/* 192 */     return this.field_6_fCompression == 0;
/*     */   }
/*     */   
/*     */   public void setCompressed(boolean compressed) {
/* 196 */     this.field_6_fCompression = (compressed ? 0 : -2);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 202 */     String extraData = HexDump.toHex(this.field_pictureData, 32);
/* 203 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex(getRecordId()) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  UID: 0x" + HexDump.toHex(this.field_1_UID) + '\n' + "  Uncompressed Size: " + HexDump.toHex(this.field_2_cb) + '\n' + "  Bounds: " + getBounds() + '\n' + "  Size in EMU: " + getSizeEMU() + '\n' + "  Compressed Size: " + HexDump.toHex(this.field_5_cbSave) + '\n' + "  Compression: " + HexDump.toHex(this.field_6_fCompression) + '\n' + "  Filter: " + HexDump.toHex(this.field_7_fFilter) + '\n' + "  Extra Data:" + '\n' + extraData;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherPictBlip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */