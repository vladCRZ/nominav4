/*    */ package org.apache.poi.ddf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EscherProperty
/*    */ {
/*    */   private short _id;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EscherProperty(short id)
/*    */   {
/* 35 */     this._id = id;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EscherProperty(short propertyNumber, boolean isComplex, boolean isBlipId)
/*    */   {
/* 43 */     this._id = ((short)(propertyNumber + (isComplex ? 32768 : 0) + (isBlipId ? 16384 : 0)));
/*    */   }
/*    */   
/*    */ 
/*    */   public short getId()
/*    */   {
/* 49 */     return this._id;
/*    */   }
/*    */   
/*    */   public short getPropertyNumber() {
/* 53 */     return (short)(this._id & 0x3FFF);
/*    */   }
/*    */   
/*    */   public boolean isComplex() {
/* 57 */     return (this._id & 0x8000) != 0;
/*    */   }
/*    */   
/*    */   public boolean isBlipId() {
/* 61 */     return (this._id & 0x4000) != 0;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 65 */     return EscherProperties.getPropertyName(this._id);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getPropertySize()
/*    */   {
/* 73 */     return 6;
/*    */   }
/*    */   
/*    */   public abstract int serializeSimplePart(byte[] paramArrayOfByte, int paramInt);
/*    */   
/*    */   public abstract int serializeComplexPart(byte[] paramArrayOfByte, int paramInt);
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */