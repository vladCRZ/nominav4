/*    */ package org.apache.poi.ddf;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.poi.util.LittleEndian;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EscherPropertyFactory
/*    */ {
/*    */   public List<EscherProperty> createProperties(byte[] data, int offset, short numProperties)
/*    */   {
/* 40 */     List<EscherProperty> results = new ArrayList();
/*    */     
/* 42 */     int pos = offset;
/*    */     
/*    */ 
/* 45 */     for (int i = 0; i < numProperties; i++)
/*    */     {
/*    */ 
/* 48 */       short propId = LittleEndian.getShort(data, pos);
/* 49 */       int propData = LittleEndian.getInt(data, pos + 2);
/* 50 */       short propNumber = (short)(propId & 0x3FFF);
/* 51 */       boolean isComplex = (propId & 0x8000) != 0;
/* 52 */       boolean isBlipId = (propId & 0x4000) != 0;
/*    */       
/* 54 */       byte propertyType = EscherProperties.getPropertyType(propNumber);
/* 55 */       if (propertyType == 1) {
/* 56 */         results.add(new EscherBoolProperty(propId, propData));
/* 57 */       } else if (propertyType == 2) {
/* 58 */         results.add(new EscherRGBProperty(propId, propData));
/* 59 */       } else if (propertyType == 3) {
/* 60 */         results.add(new EscherShapePathProperty(propId, propData));
/*    */ 
/*    */       }
/* 63 */       else if (!isComplex) {
/* 64 */         results.add(new EscherSimpleProperty(propId, propData));
/*    */ 
/*    */       }
/* 67 */       else if (propertyType == 5) {
/* 68 */         results.add(new EscherArrayProperty(propId, new byte[propData]));
/*    */       } else {
/* 70 */         results.add(new EscherComplexProperty(propId, new byte[propData]));
/*    */       }
/*    */       
/* 73 */       pos += 6;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 78 */     for (Iterator<EscherProperty> iterator = results.iterator(); iterator.hasNext();) {
/* 79 */       EscherProperty p = (EscherProperty)iterator.next();
/* 80 */       if ((p instanceof EscherComplexProperty)) {
/* 81 */         if ((p instanceof EscherArrayProperty)) {
/* 82 */           pos += ((EscherArrayProperty)p).setArrayData(data, pos);
/*    */         } else {
/* 84 */           byte[] complexData = ((EscherComplexProperty)p).getComplexData();
/* 85 */           System.arraycopy(data, pos, complexData, 0, complexData.length);
/* 86 */           pos += complexData.length;
/*    */         }
/*    */       }
/*    */     }
/* 90 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherPropertyFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */