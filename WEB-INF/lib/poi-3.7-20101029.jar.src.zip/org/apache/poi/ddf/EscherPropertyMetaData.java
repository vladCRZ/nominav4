/*    */ package org.apache.poi.ddf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EscherPropertyMetaData
/*    */ {
/*    */   public static final byte TYPE_UNKNOWN = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final byte TYPE_BOOLEAN = 1;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final byte TYPE_RGB = 2;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final byte TYPE_SHAPEPATH = 3;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final byte TYPE_SIMPLE = 4;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final byte TYPE_ARRAY = 5;
/*    */   
/*    */ 
/*    */ 
/*    */   private String description;
/*    */   
/*    */ 
/*    */ 
/*    */   private byte type;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EscherPropertyMetaData(String description)
/*    */   {
/* 45 */     this.description = description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EscherPropertyMetaData(String description, byte type)
/*    */   {
/* 55 */     this.description = description;
/* 56 */     this.type = type;
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 61 */     return this.description;
/*    */   }
/*    */   
/*    */   public byte getType()
/*    */   {
/* 66 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherPropertyMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */