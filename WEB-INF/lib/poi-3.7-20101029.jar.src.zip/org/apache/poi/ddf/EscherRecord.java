/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EscherRecord
/*     */ {
/*     */   private short _options;
/*     */   private short _recordId;
/*     */   
/*     */   protected int fillFields(byte[] data, EscherRecordFactory f)
/*     */   {
/*  51 */     return fillFields(data, 0, f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int fillFields(byte[] paramArrayOfByte, int paramInt, EscherRecordFactory paramEscherRecordFactory);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int readHeader(byte[] data, int offset)
/*     */   {
/*  76 */     EscherRecordHeader header = EscherRecordHeader.readHeader(data, offset);
/*  77 */     this._options = header.getOptions();
/*  78 */     this._recordId = header.getRecordId();
/*  79 */     return header.getRemainingBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isContainerRecord()
/*     */   {
/*  88 */     return (this._options & 0xF) == 15;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/*  95 */     return this._options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short options)
/*     */   {
/* 103 */     this._options = options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] serialize()
/*     */   {
/* 115 */     byte[] retval = new byte[getRecordSize()];
/*     */     
/* 117 */     serialize(0, retval);
/* 118 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serialize(int offset, byte[] data)
/*     */   {
/* 133 */     return serialize(offset, data, new NullEscherSerializationListener());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int serialize(int paramInt, byte[] paramArrayOfByte, EscherSerializationListener paramEscherSerializationListener);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getRecordSize();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getRecordId()
/*     */   {
/* 163 */     return this._recordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRecordId(short recordId)
/*     */   {
/* 170 */     this._recordId = recordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<EscherRecord> getChildRecords()
/*     */   {
/* 180 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChildRecords(List<EscherRecord> childRecords)
/*     */   {
/* 189 */     throw new UnsupportedOperationException("This record does not support child records.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 197 */     throw new RuntimeException("The class " + getClass().getName() + " needs to define a clone method");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public EscherRecord getChild(int index)
/*     */   {
/* 204 */     return (EscherRecord)getChildRecords().get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void display(PrintWriter w, int indent)
/*     */   {
/* 216 */     for (int i = 0; i < indent * 4; i++) w.print(' ');
/* 217 */     w.println(getRecordName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getRecordName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getInstance()
/*     */   {
/* 231 */     return (short)(this._options >> 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class EscherRecordHeader
/*     */   {
/*     */     private short options;
/*     */     
/*     */ 
/*     */     private short recordId;
/*     */     
/*     */ 
/*     */     private int remainingBytes;
/*     */     
/*     */ 
/*     */     public static EscherRecordHeader readHeader(byte[] data, int offset)
/*     */     {
/* 249 */       EscherRecordHeader header = new EscherRecordHeader();
/* 250 */       header.options = LittleEndian.getShort(data, offset);
/* 251 */       header.recordId = LittleEndian.getShort(data, offset + 2);
/* 252 */       header.remainingBytes = LittleEndian.getInt(data, offset + 4);
/* 253 */       return header;
/*     */     }
/*     */     
/*     */ 
/*     */     public short getOptions()
/*     */     {
/* 259 */       return this.options;
/*     */     }
/*     */     
/*     */     public short getRecordId()
/*     */     {
/* 264 */       return this.recordId;
/*     */     }
/*     */     
/*     */     public int getRemainingBytes()
/*     */     {
/* 269 */       return this.remainingBytes;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 274 */       return "EscherRecordHeader{options=" + this.options + ", recordId=" + this.recordId + ", remainingBytes=" + this.remainingBytes + "}";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */