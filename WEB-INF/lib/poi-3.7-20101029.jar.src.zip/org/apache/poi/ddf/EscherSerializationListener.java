package org.apache.poi.ddf;

public abstract interface EscherSerializationListener
{
  public abstract void beforeRecordSerialize(int paramInt, short paramShort, EscherRecord paramEscherRecord);
  
  public abstract void afterRecordSerialize(int paramInt1, short paramShort, int paramInt2, EscherRecord paramEscherRecord);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherSerializationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */