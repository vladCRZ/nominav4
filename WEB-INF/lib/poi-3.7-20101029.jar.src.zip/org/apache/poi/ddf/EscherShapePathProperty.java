/*    */ package org.apache.poi.ddf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EscherShapePathProperty
/*    */   extends EscherSimpleProperty
/*    */ {
/*    */   public static final int LINE_OF_STRAIGHT_SEGMENTS = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int CLOSED_POLYGON = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int CURVES = 2;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final int CLOSED_CURVES = 3;
/*    */   
/*    */ 
/*    */ 
/*    */   public static final int COMPLEX = 4;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EscherShapePathProperty(short propertyNumber, int shapePath)
/*    */   {
/* 35 */     super(propertyNumber, false, false, shapePath);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherShapePathProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */