/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherSimpleProperty
/*     */   extends EscherProperty
/*     */ {
/*     */   protected int propertyValue;
/*     */   
/*     */   public EscherSimpleProperty(short id, int propertyValue)
/*     */   {
/*  40 */     super(id);
/*  41 */     this.propertyValue = propertyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherSimpleProperty(short propertyNumber, boolean isComplex, boolean isBlipId, int propertyValue)
/*     */   {
/*  50 */     super(propertyNumber, isComplex, isBlipId);
/*  51 */     this.propertyValue = propertyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serializeSimplePart(byte[] data, int offset)
/*     */   {
/*  61 */     LittleEndian.putShort(data, offset, getId());
/*  62 */     LittleEndian.putInt(data, offset + 2, this.propertyValue);
/*  63 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serializeComplexPart(byte[] data, int pos)
/*     */   {
/*  72 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPropertyValue()
/*     */   {
/*  80 */     return this.propertyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  88 */     if (this == o) return true;
/*  89 */     if (!(o instanceof EscherSimpleProperty)) { return false;
/*     */     }
/*  91 */     EscherSimpleProperty escherSimpleProperty = (EscherSimpleProperty)o;
/*     */     
/*  93 */     if (this.propertyValue != escherSimpleProperty.propertyValue) return false;
/*  94 */     if (getId() != escherSimpleProperty.getId()) { return false;
/*     */     }
/*  96 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 105 */     return this.propertyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 113 */     return "propNum: " + getPropertyNumber() + ", RAW: 0x" + HexDump.toHex(getId()) + ", propName: " + EscherProperties.getPropertyName(getPropertyNumber()) + ", complex: " + isComplex() + ", blipId: " + isBlipId() + ", value: " + this.propertyValue + " (0x" + HexDump.toHex(this.propertyValue) + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherSimpleProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */