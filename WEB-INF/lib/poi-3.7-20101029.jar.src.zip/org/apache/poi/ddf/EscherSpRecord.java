/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherSpRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4086;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtSp";
/*     */   public static final int FLAG_GROUP = 1;
/*     */   public static final int FLAG_CHILD = 2;
/*     */   public static final int FLAG_PATRIARCH = 4;
/*     */   public static final int FLAG_DELETED = 8;
/*     */   public static final int FLAG_OLESHAPE = 16;
/*     */   public static final int FLAG_HAVEMASTER = 32;
/*     */   public static final int FLAG_FLIPHORIZ = 64;
/*     */   public static final int FLAG_FLIPVERT = 128;
/*     */   public static final int FLAG_CONNECTOR = 256;
/*     */   public static final int FLAG_HAVEANCHOR = 512;
/*     */   public static final int FLAG_BACKGROUND = 1024;
/*     */   public static final int FLAG_HASSHAPETYPE = 2048;
/*     */   private int field_1_shapeId;
/*     */   private int field_2_flags;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  52 */     int bytesRemaining = readHeader(data, offset);
/*  53 */     int pos = offset + 8;
/*  54 */     int size = 0;
/*  55 */     this.field_1_shapeId = LittleEndian.getInt(data, pos + size);size += 4;
/*  56 */     this.field_2_flags = LittleEndian.getInt(data, pos + size);size += 4;
/*     */     
/*     */ 
/*     */ 
/*  60 */     return getRecordSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  75 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*  76 */     LittleEndian.putShort(data, offset, getOptions());
/*  77 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  78 */     int remainingBytes = 8;
/*  79 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*  80 */     LittleEndian.putInt(data, offset + 8, this.field_1_shapeId);
/*  81 */     LittleEndian.putInt(data, offset + 12, this.field_2_flags);
/*     */     
/*     */ 
/*  84 */     listener.afterRecordSerialize(offset + getRecordSize(), getRecordId(), getRecordSize(), this);
/*  85 */     return 16;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  90 */     return 16;
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/*  94 */     return 61450;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  98 */     return "Sp";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 107 */     String nl = System.getProperty("line.separator");
/*     */     
/* 109 */     return getClass().getName() + ":" + nl + "  RecordId: 0x" + HexDump.toHex((short)61450) + nl + "  Options: 0x" + HexDump.toHex(getOptions()) + nl + "  ShapeId: " + this.field_1_shapeId + nl + "  Flags: " + decodeFlags(this.field_2_flags) + " (0x" + HexDump.toHex(this.field_2_flags) + ")" + nl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String decodeFlags(int flags)
/*     */   {
/* 122 */     StringBuffer result = new StringBuffer();
/* 123 */     result.append((flags & 0x1) != 0 ? "|GROUP" : "");
/* 124 */     result.append((flags & 0x2) != 0 ? "|CHILD" : "");
/* 125 */     result.append((flags & 0x4) != 0 ? "|PATRIARCH" : "");
/* 126 */     result.append((flags & 0x8) != 0 ? "|DELETED" : "");
/* 127 */     result.append((flags & 0x10) != 0 ? "|OLESHAPE" : "");
/* 128 */     result.append((flags & 0x20) != 0 ? "|HAVEMASTER" : "");
/* 129 */     result.append((flags & 0x40) != 0 ? "|FLIPHORIZ" : "");
/* 130 */     result.append((flags & 0x80) != 0 ? "|FLIPVERT" : "");
/* 131 */     result.append((flags & 0x100) != 0 ? "|CONNECTOR" : "");
/* 132 */     result.append((flags & 0x200) != 0 ? "|HAVEANCHOR" : "");
/* 133 */     result.append((flags & 0x400) != 0 ? "|BACKGROUND" : "");
/* 134 */     result.append((flags & 0x800) != 0 ? "|HASSHAPETYPE" : "");
/*     */     
/*     */ 
/* 137 */     if (result.length() > 0) {
/* 138 */       result.deleteCharAt(0);
/*     */     }
/* 140 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getShapeId()
/*     */   {
/* 148 */     return this.field_1_shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShapeId(int field_1_shapeId)
/*     */   {
/* 156 */     this.field_1_shapeId = field_1_shapeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFlags()
/*     */   {
/* 177 */     return this.field_2_flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlags(int field_2_flags)
/*     */   {
/* 198 */     this.field_2_flags = field_2_flags;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherSpRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */