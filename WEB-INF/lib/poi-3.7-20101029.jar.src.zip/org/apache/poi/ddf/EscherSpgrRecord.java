/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.RecordFormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherSpgrRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4087;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtSpgr";
/*     */   private int field_1_rectX1;
/*     */   private int field_2_rectY1;
/*     */   private int field_3_rectX2;
/*     */   private int field_4_rectY2;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  42 */     int bytesRemaining = readHeader(data, offset);
/*  43 */     int pos = offset + 8;
/*  44 */     int size = 0;
/*  45 */     this.field_1_rectX1 = LittleEndian.getInt(data, pos + size);size += 4;
/*  46 */     this.field_2_rectY1 = LittleEndian.getInt(data, pos + size);size += 4;
/*  47 */     this.field_3_rectX2 = LittleEndian.getInt(data, pos + size);size += 4;
/*  48 */     this.field_4_rectY2 = LittleEndian.getInt(data, pos + size);size += 4;
/*  49 */     bytesRemaining -= size;
/*  50 */     if (bytesRemaining != 0) { throw new RecordFormatException("Expected no remaining bytes but got " + bytesRemaining);
/*     */     }
/*     */     
/*  53 */     return 8 + size + bytesRemaining;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  58 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*  59 */     LittleEndian.putShort(data, offset, getOptions());
/*  60 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  61 */     int remainingBytes = 16;
/*  62 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*  63 */     LittleEndian.putInt(data, offset + 8, this.field_1_rectX1);
/*  64 */     LittleEndian.putInt(data, offset + 12, this.field_2_rectY1);
/*  65 */     LittleEndian.putInt(data, offset + 16, this.field_3_rectX2);
/*  66 */     LittleEndian.putInt(data, offset + 20, this.field_4_rectY2);
/*     */     
/*     */ 
/*  69 */     listener.afterRecordSerialize(offset + getRecordSize(), getRecordId(), offset + getRecordSize(), this);
/*  70 */     return 24;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  75 */     return 24;
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/*  79 */     return 61449;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  83 */     return "Spgr";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  90 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex((short)61449) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  RectX: " + this.field_1_rectX1 + '\n' + "  RectY: " + this.field_2_rectY1 + '\n' + "  RectWidth: " + this.field_3_rectX2 + '\n' + "  RectHeight: " + this.field_4_rectY2 + '\n';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRectX1()
/*     */   {
/* 104 */     return this.field_1_rectX1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRectX1(int x1)
/*     */   {
/* 112 */     this.field_1_rectX1 = x1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRectY1()
/*     */   {
/* 120 */     return this.field_2_rectY1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRectY1(int y1)
/*     */   {
/* 128 */     this.field_2_rectY1 = y1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRectX2()
/*     */   {
/* 136 */     return this.field_3_rectX2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRectX2(int x2)
/*     */   {
/* 144 */     this.field_3_rectX2 = x2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRectY2()
/*     */   {
/* 152 */     return this.field_4_rectY2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRectY2(int rectY2)
/*     */   {
/* 159 */     this.field_4_rectY2 = rectY2;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherSpgrRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */