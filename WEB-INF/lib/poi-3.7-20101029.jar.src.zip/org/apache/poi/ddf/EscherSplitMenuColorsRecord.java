/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.RecordFormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherSplitMenuColorsRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -3810;
/*     */   public static final String RECORD_DESCRIPTION = "MsofbtSplitMenuColors";
/*     */   private int field_1_color1;
/*     */   private int field_2_color2;
/*     */   private int field_3_color3;
/*     */   private int field_4_color4;
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  42 */     int bytesRemaining = readHeader(data, offset);
/*  43 */     int pos = offset + 8;
/*  44 */     int size = 0;
/*  45 */     this.field_1_color1 = LittleEndian.getInt(data, pos + size);size += 4;
/*  46 */     this.field_2_color2 = LittleEndian.getInt(data, pos + size);size += 4;
/*  47 */     this.field_3_color3 = LittleEndian.getInt(data, pos + size);size += 4;
/*  48 */     this.field_4_color4 = LittleEndian.getInt(data, pos + size);size += 4;
/*  49 */     bytesRemaining -= size;
/*  50 */     if (bytesRemaining != 0)
/*  51 */       throw new RecordFormatException("Expecting no remaining data but got " + bytesRemaining + " byte(s).");
/*  52 */     return 8 + size + bytesRemaining;
/*     */   }
/*     */   
/*     */ 
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  58 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  60 */     int pos = offset;
/*  61 */     LittleEndian.putShort(data, pos, getOptions());pos += 2;
/*  62 */     LittleEndian.putShort(data, pos, getRecordId());pos += 2;
/*  63 */     int remainingBytes = getRecordSize() - 8;
/*     */     
/*  65 */     LittleEndian.putInt(data, pos, remainingBytes);pos += 4;
/*  66 */     LittleEndian.putInt(data, pos, this.field_1_color1);pos += 4;
/*  67 */     LittleEndian.putInt(data, pos, this.field_2_color2);pos += 4;
/*  68 */     LittleEndian.putInt(data, pos, this.field_3_color3);pos += 4;
/*  69 */     LittleEndian.putInt(data, pos, this.field_4_color4);pos += 4;
/*  70 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  71 */     return getRecordSize();
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  76 */     return 24;
/*     */   }
/*     */   
/*     */   public short getRecordId() {
/*  80 */     return 61726;
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/*  84 */     return "SplitMenuColors";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  91 */     return getClass().getName() + ":" + '\n' + "  RecordId: 0x" + HexDump.toHex((short)61726) + '\n' + "  Options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  Color1: 0x" + HexDump.toHex(this.field_1_color1) + '\n' + "  Color2: 0x" + HexDump.toHex(this.field_2_color2) + '\n' + "  Color3: 0x" + HexDump.toHex(this.field_3_color3) + '\n' + "  Color4: 0x" + HexDump.toHex(this.field_4_color4) + '\n' + "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColor1()
/*     */   {
/* 103 */     return this.field_1_color1;
/*     */   }
/*     */   
/*     */   public void setColor1(int field_1_color1)
/*     */   {
/* 108 */     this.field_1_color1 = field_1_color1;
/*     */   }
/*     */   
/*     */   public int getColor2()
/*     */   {
/* 113 */     return this.field_2_color2;
/*     */   }
/*     */   
/*     */   public void setColor2(int field_2_color2)
/*     */   {
/* 118 */     this.field_2_color2 = field_2_color2;
/*     */   }
/*     */   
/*     */   public int getColor3()
/*     */   {
/* 123 */     return this.field_3_color3;
/*     */   }
/*     */   
/*     */   public void setColor3(int field_3_color3)
/*     */   {
/* 128 */     this.field_3_color3 = field_3_color3;
/*     */   }
/*     */   
/*     */   public int getColor4()
/*     */   {
/* 133 */     return this.field_4_color4;
/*     */   }
/*     */   
/*     */   public void setColor4(int field_4_color4)
/*     */   {
/* 138 */     this.field_4_color4 = field_4_color4;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherSplitMenuColorsRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */