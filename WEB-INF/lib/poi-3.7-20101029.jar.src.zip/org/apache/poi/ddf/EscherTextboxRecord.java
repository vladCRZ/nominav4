/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.RecordFormatException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscherTextboxRecord
/*     */   extends EscherRecord
/*     */ {
/*     */   public static final short RECORD_ID = -4083;
/*     */   public static final String RECORD_DESCRIPTION = "msofbtClientTextbox";
/*  38 */   private static final byte[] NO_BYTES = new byte[0];
/*     */   
/*     */ 
/*  41 */   private byte[] thedata = NO_BYTES;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory)
/*     */   {
/*  48 */     int bytesRemaining = readHeader(data, offset);
/*     */     
/*     */ 
/*     */ 
/*  52 */     this.thedata = new byte[bytesRemaining];
/*  53 */     System.arraycopy(data, offset + 8, this.thedata, 0, bytesRemaining);
/*  54 */     return bytesRemaining + 8;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener)
/*     */   {
/*  59 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  61 */     LittleEndian.putShort(data, offset, getOptions());
/*  62 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  63 */     int remainingBytes = this.thedata.length;
/*  64 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*  65 */     System.arraycopy(this.thedata, 0, data, offset + 8, this.thedata.length);
/*  66 */     int pos = offset + 8 + this.thedata.length;
/*     */     
/*  68 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  69 */     int size = pos - offset;
/*  70 */     if (size != getRecordSize())
/*  71 */       throw new RecordFormatException(size + " bytes written but getRecordSize() reports " + getRecordSize());
/*  72 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/*  83 */     return this.thedata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(byte[] b, int start, int length)
/*     */   {
/*  93 */     this.thedata = new byte[length];
/*  94 */     System.arraycopy(b, start, this.thedata, 0, length);
/*     */   }
/*     */   
/*  97 */   public void setData(byte[] b) { setData(b, 0, b.length); }
/*     */   
/*     */ 
/*     */   public int getRecordSize()
/*     */   {
/* 102 */     return 8 + this.thedata.length;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 108 */     return super.clone();
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/* 112 */     return "ClientTextbox";
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 117 */     String nl = System.getProperty("line.separator");
/*     */     
/* 119 */     String theDumpHex = "";
/*     */     try
/*     */     {
/* 122 */       if (this.thedata.length != 0)
/*     */       {
/* 124 */         theDumpHex = "  Extra Data:" + nl;
/* 125 */         theDumpHex = theDumpHex + HexDump.dump(this.thedata, 0L, 0);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 130 */       theDumpHex = "Error!!";
/*     */     }
/*     */     
/* 133 */     return getClass().getName() + ":" + nl + "  isContainer: " + isContainerRecord() + nl + "  options: 0x" + HexDump.toHex(getOptions()) + nl + "  recordId: 0x" + HexDump.toHex(getRecordId()) + nl + "  numchildren: " + getChildRecords().size() + nl + theDumpHex;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\EscherTextboxRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */