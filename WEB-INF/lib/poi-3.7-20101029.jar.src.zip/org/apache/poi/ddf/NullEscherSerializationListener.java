package org.apache.poi.ddf;

public class NullEscherSerializationListener
  implements EscherSerializationListener
{
  public void beforeRecordSerialize(int offset, short recordId, EscherRecord record) {}
  
  public void afterRecordSerialize(int offset, short recordId, int size, EscherRecord record) {}
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\NullEscherSerializationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */