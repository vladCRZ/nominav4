/*     */ package org.apache.poi.ddf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnknownEscherRecord
/*     */   extends EscherRecord
/*     */ {
/*  34 */   private static final byte[] NO_BYTES = new byte[0];
/*     */   
/*     */ 
/*  37 */   private byte[] thedata = NO_BYTES;
/*     */   private List<EscherRecord> _childRecords;
/*     */   
/*     */   public UnknownEscherRecord() {
/*  41 */     this._childRecords = new ArrayList();
/*     */   }
/*     */   
/*     */   public int fillFields(byte[] data, int offset, EscherRecordFactory recordFactory) {
/*  45 */     int bytesRemaining = readHeader(data, offset);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */     int avaliable = data.length - (offset + 8);
/*  53 */     if (bytesRemaining > avaliable) {
/*  54 */       bytesRemaining = avaliable;
/*     */     }
/*     */     
/*  57 */     if (isContainerRecord()) {
/*  58 */       int bytesWritten = 0;
/*  59 */       this.thedata = new byte[0];
/*  60 */       offset += 8;
/*  61 */       bytesWritten += 8;
/*  62 */       while (bytesRemaining > 0)
/*     */       {
/*  64 */         EscherRecord child = recordFactory.createRecord(data, offset);
/*  65 */         int childBytesWritten = child.fillFields(data, offset, recordFactory);
/*  66 */         bytesWritten += childBytesWritten;
/*  67 */         offset += childBytesWritten;
/*  68 */         bytesRemaining -= childBytesWritten;
/*  69 */         getChildRecords().add(child);
/*     */       }
/*  71 */       return bytesWritten;
/*     */     }
/*     */     
/*  74 */     this.thedata = new byte[bytesRemaining];
/*  75 */     System.arraycopy(data, offset + 8, this.thedata, 0, bytesRemaining);
/*  76 */     return bytesRemaining + 8;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data, EscherSerializationListener listener) {
/*  80 */     listener.beforeRecordSerialize(offset, getRecordId(), this);
/*     */     
/*  82 */     LittleEndian.putShort(data, offset, getOptions());
/*  83 */     LittleEndian.putShort(data, offset + 2, getRecordId());
/*  84 */     int remainingBytes = this.thedata.length;
/*  85 */     for (EscherRecord r : this._childRecords) {
/*  86 */       remainingBytes += r.getRecordSize();
/*     */     }
/*  88 */     LittleEndian.putInt(data, offset + 4, remainingBytes);
/*  89 */     System.arraycopy(this.thedata, 0, data, offset + 8, this.thedata.length);
/*  90 */     int pos = offset + 8 + this.thedata.length;
/*  91 */     for (EscherRecord r : this._childRecords) {
/*  92 */       pos += r.serialize(pos, data, listener);
/*     */     }
/*     */     
/*  95 */     listener.afterRecordSerialize(pos, getRecordId(), pos - offset, this);
/*  96 */     return pos - offset;
/*     */   }
/*     */   
/*     */   public byte[] getData() {
/* 100 */     return this.thedata;
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/* 104 */     return 8 + this.thedata.length;
/*     */   }
/*     */   
/*     */   public List<EscherRecord> getChildRecords() {
/* 108 */     return this._childRecords;
/*     */   }
/*     */   
/*     */   public void setChildRecords(List<EscherRecord> childRecords) {
/* 112 */     this._childRecords = childRecords;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 117 */     return super.clone();
/*     */   }
/*     */   
/*     */   public String getRecordName() {
/* 121 */     return "Unknown 0x" + HexDump.toHex(getRecordId());
/*     */   }
/*     */   
/*     */   public String toString() {
/* 125 */     StringBuffer children = new StringBuffer();
/* 126 */     if (getChildRecords().size() > 0) {
/* 127 */       children.append("  children: \n");
/* 128 */       for (EscherRecord record : this._childRecords) {
/* 129 */         children.append(record.toString());
/* 130 */         children.append('\n');
/*     */       }
/*     */     }
/*     */     
/* 134 */     String theDumpHex = HexDump.toHex(this.thedata, 32);
/*     */     
/* 136 */     return getClass().getName() + ":" + '\n' + "  isContainer: " + isContainerRecord() + '\n' + "  options: 0x" + HexDump.toHex(getOptions()) + '\n' + "  recordId: 0x" + HexDump.toHex(getRecordId()) + '\n' + "  numchildren: " + getChildRecords().size() + '\n' + theDumpHex + children.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChildRecord(EscherRecord childRecord)
/*     */   {
/* 146 */     getChildRecords().add(childRecord);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\ddf\UnknownEscherRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */