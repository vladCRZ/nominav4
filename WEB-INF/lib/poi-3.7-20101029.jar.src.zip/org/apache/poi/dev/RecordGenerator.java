/*     */ package org.apache.poi.dev;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordGenerator
/*     */ {
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  56 */     Class.forName("org.apache.poi.generator.FieldIterator");
/*     */     
/*  58 */     if (args.length != 4) {
/*  59 */       System.out.println("Usage:");
/*  60 */       System.out.println("  java org.apache.poi.hssf.util.RecordGenerator RECORD_DEFINTIONS RECORD_STYLES DEST_SRC_PATH TEST_SRC_PATH");
/*     */     } else {
/*  62 */       generateRecords(args[0], args[1], args[2], args[3]);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void generateRecords(String defintionsDir, String recordStyleDir, String destSrcPathDir, String testSrcPathDir)
/*     */     throws Exception
/*     */   {
/*  69 */     File definitionsFile = new File(defintionsDir);
/*     */     
/*  71 */     for (int i = 0; i < definitionsFile.listFiles().length; i++) {
/*  72 */       File file = definitionsFile.listFiles()[i];
/*  73 */       if ((file.isFile()) && ((file.getName().endsWith("_record.xml")) || (file.getName().endsWith("_type.xml"))))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */         
/*  81 */         DocumentBuilder builder = factory.newDocumentBuilder();
/*  82 */         Document document = builder.parse(file);
/*  83 */         Element record = document.getDocumentElement();
/*  84 */         String extendstg = record.getElementsByTagName("extends").item(0).getFirstChild().getNodeValue();
/*  85 */         String suffix = record.getElementsByTagName("suffix").item(0).getFirstChild().getNodeValue();
/*  86 */         String recordName = record.getAttributes().getNamedItem("name").getNodeValue();
/*  87 */         String packageName = record.getAttributes().getNamedItem("package").getNodeValue();
/*  88 */         packageName = packageName.replace('.', '/');
/*     */         
/*     */ 
/*  91 */         String destinationPath = destSrcPathDir + "/" + packageName;
/*  92 */         File destinationPathFile = new File(destinationPath);
/*  93 */         destinationPathFile.mkdirs();
/*  94 */         String destinationFilepath = destinationPath + "/" + recordName + suffix + ".java";
/*  95 */         transform(file, new File(destinationFilepath), new File(recordStyleDir + "/" + extendstg.toLowerCase() + ".xsl"));
/*  96 */         System.out.println("Generated " + suffix + ": " + destinationFilepath);
/*     */         
/*     */ 
/*  99 */         destinationPath = testSrcPathDir + "/" + packageName;
/* 100 */         destinationPathFile = new File(destinationPath);
/* 101 */         destinationPathFile.mkdirs();
/* 102 */         destinationFilepath = destinationPath + "/Test" + recordName + suffix + ".java";
/* 103 */         if (!new File(destinationFilepath).exists()) {
/* 104 */           String temp = recordStyleDir + "/" + extendstg.toLowerCase() + "_test.xsl";
/* 105 */           transform(file, new File(destinationFilepath), new File(temp));
/* 106 */           System.out.println("Generated test: " + destinationFilepath);
/*     */         } else {
/* 108 */           System.out.println("Skipped test generation: " + destinationFilepath);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void transform(File in, File out, File xslt)
/*     */     throws FileNotFoundException, TransformerException
/*     */   {
/* 129 */     Reader r = new FileReader(xslt);
/* 130 */     StreamSource ss = new StreamSource(r);
/* 131 */     TransformerFactory tf = TransformerFactory.newInstance();
/*     */     Transformer t;
/*     */     try
/*     */     {
/* 135 */       t = tf.newTransformer(ss);
/*     */     }
/*     */     catch (TransformerException ex)
/*     */     {
/* 139 */       System.err.println("Error compiling XSL style sheet " + xslt);
/* 140 */       throw ex;
/*     */     }
/* 142 */     Properties p = new Properties();
/* 143 */     p.setProperty("method", "text");
/* 144 */     t.setOutputProperties(p);
/* 145 */     Result result = new StreamResult(out);
/* 146 */     t.transform(new StreamSource(in), result);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\dev\RecordGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */