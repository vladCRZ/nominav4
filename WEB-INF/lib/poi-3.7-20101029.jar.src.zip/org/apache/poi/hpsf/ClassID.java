/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassID
/*     */ {
/*     */   protected byte[] bytes;
/*     */   public static final int LENGTH = 16;
/*     */   
/*     */   public ClassID(byte[] src, int offset)
/*     */   {
/*  51 */     read(src, offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassID()
/*     */   {
/*  61 */     this.bytes = new byte[16];
/*  62 */     for (int i = 0; i < 16; i++) {
/*  63 */       this.bytes[i] = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/*  78 */     return 16;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  91 */     return this.bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBytes(byte[] bytes)
/*     */   {
/* 104 */     for (int i = 0; i < this.bytes.length; i++) {
/* 105 */       this.bytes[i] = bytes[i];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] read(byte[] src, int offset)
/*     */   {
/* 122 */     this.bytes = new byte[16];
/*     */     
/*     */ 
/* 125 */     this.bytes[0] = src[(3 + offset)];
/* 126 */     this.bytes[1] = src[(2 + offset)];
/* 127 */     this.bytes[2] = src[(1 + offset)];
/* 128 */     this.bytes[3] = src[(0 + offset)];
/*     */     
/*     */ 
/* 131 */     this.bytes[4] = src[(5 + offset)];
/* 132 */     this.bytes[5] = src[(4 + offset)];
/*     */     
/*     */ 
/* 135 */     this.bytes[6] = src[(7 + offset)];
/* 136 */     this.bytes[7] = src[(6 + offset)];
/*     */     
/*     */ 
/* 139 */     for (int i = 8; i < 16; i++) {
/* 140 */       this.bytes[i] = src[(i + offset)];
/*     */     }
/* 142 */     return this.bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] dst, int offset)
/*     */     throws ArrayStoreException
/*     */   {
/* 162 */     if (dst.length < 16) {
/* 163 */       throw new ArrayStoreException("Destination byte[] must have room for at least 16 bytes, but has a length of only " + dst.length + ".");
/*     */     }
/*     */     
/*     */ 
/* 167 */     dst[(0 + offset)] = this.bytes[3];
/* 168 */     dst[(1 + offset)] = this.bytes[2];
/* 169 */     dst[(2 + offset)] = this.bytes[1];
/* 170 */     dst[(3 + offset)] = this.bytes[0];
/*     */     
/*     */ 
/* 173 */     dst[(4 + offset)] = this.bytes[5];
/* 174 */     dst[(5 + offset)] = this.bytes[4];
/*     */     
/*     */ 
/* 177 */     dst[(6 + offset)] = this.bytes[7];
/* 178 */     dst[(7 + offset)] = this.bytes[6];
/*     */     
/*     */ 
/* 181 */     for (int i = 8; i < 16; i++) {
/* 182 */       dst[(i + offset)] = this.bytes[i];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 197 */     if ((o == null) || (!(o instanceof ClassID)))
/* 198 */       return false;
/* 199 */     ClassID cid = (ClassID)o;
/* 200 */     if (this.bytes.length != cid.bytes.length)
/* 201 */       return false;
/* 202 */     for (int i = 0; i < this.bytes.length; i++)
/* 203 */       if (this.bytes[i] != cid.bytes[i])
/* 204 */         return false;
/* 205 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 215 */     return new String(this.bytes).hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 228 */     StringBuffer sbClassId = new StringBuffer(38);
/* 229 */     sbClassId.append('{');
/* 230 */     for (int i = 0; i < 16; i++)
/*     */     {
/* 232 */       sbClassId.append(HexDump.toHex(this.bytes[i]));
/* 233 */       if ((i == 3) || (i == 5) || (i == 7) || (i == 9))
/* 234 */         sbClassId.append('-');
/*     */     }
/* 236 */     sbClassId.append('}');
/* 237 */     return sbClassId.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\ClassID.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */