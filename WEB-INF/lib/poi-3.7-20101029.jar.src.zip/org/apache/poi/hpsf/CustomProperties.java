/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomProperties
/*     */   extends HashMap<Object, CustomProperty>
/*     */ {
/*  66 */   private Map<Long, String> dictionaryIDToName = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private Map<String, Long> dictionaryNameToID = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private boolean isPure = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CustomProperty put(String name, CustomProperty cp)
/*     */   {
/*  86 */     if (name == null)
/*     */     {
/*     */ 
/*  89 */       this.isPure = false;
/*  90 */       return null;
/*     */     }
/*  92 */     if (!name.equals(cp.getName())) {
/*  93 */       throw new IllegalArgumentException("Parameter \"name\" (" + name + ") and custom property's name (" + cp.getName() + ") do not match.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  98 */     Long idKey = Long.valueOf(cp.getID());
/*  99 */     Long oldID = (Long)this.dictionaryNameToID.get(name);
/* 100 */     this.dictionaryIDToName.remove(oldID);
/* 101 */     this.dictionaryNameToID.put(name, idKey);
/* 102 */     this.dictionaryIDToName.put(idKey, name);
/*     */     
/*     */ 
/* 105 */     CustomProperty oldCp = (CustomProperty)super.remove(oldID);
/* 106 */     super.put(idKey, cp);
/* 107 */     return oldCp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object put(CustomProperty customProperty)
/*     */     throws ClassCastException
/*     */   {
/* 131 */     String name = customProperty.getName();
/*     */     
/*     */ 
/* 134 */     Long oldId = (Long)this.dictionaryNameToID.get(name);
/* 135 */     if (oldId != null) {
/* 136 */       customProperty.setID(oldId.longValue());
/*     */     }
/*     */     else {
/* 139 */       long max = 1L;
/* 140 */       for (Iterator<Long> i = this.dictionaryIDToName.keySet().iterator(); i.hasNext();)
/*     */       {
/* 142 */         long id = ((Long)i.next()).longValue();
/* 143 */         if (id > max)
/* 144 */           max = id;
/*     */       }
/* 146 */       customProperty.setID(max + 1L);
/*     */     }
/* 148 */     return put(name, customProperty);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object remove(String name)
/*     */   {
/* 162 */     Long id = (Long)this.dictionaryNameToID.get(name);
/* 163 */     if (id == null)
/* 164 */       return null;
/* 165 */     this.dictionaryIDToName.remove(id);
/* 166 */     this.dictionaryNameToID.remove(name);
/* 167 */     return super.remove(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String name, String value)
/*     */   {
/* 180 */     MutableProperty p = new MutableProperty();
/* 181 */     p.setID(-1L);
/* 182 */     p.setType(31L);
/* 183 */     p.setValue(value);
/* 184 */     CustomProperty cp = new CustomProperty(p, name);
/* 185 */     return put(cp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String name, Long value)
/*     */   {
/* 198 */     MutableProperty p = new MutableProperty();
/* 199 */     p.setID(-1L);
/* 200 */     p.setType(20L);
/* 201 */     p.setValue(value);
/* 202 */     CustomProperty cp = new CustomProperty(p, name);
/* 203 */     return put(cp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String name, Double value)
/*     */   {
/* 216 */     MutableProperty p = new MutableProperty();
/* 217 */     p.setID(-1L);
/* 218 */     p.setType(5L);
/* 219 */     p.setValue(value);
/* 220 */     CustomProperty cp = new CustomProperty(p, name);
/* 221 */     return put(cp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String name, Integer value)
/*     */   {
/* 234 */     MutableProperty p = new MutableProperty();
/* 235 */     p.setID(-1L);
/* 236 */     p.setType(3L);
/* 237 */     p.setValue(value);
/* 238 */     CustomProperty cp = new CustomProperty(p, name);
/* 239 */     return put(cp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String name, Boolean value)
/*     */   {
/* 252 */     MutableProperty p = new MutableProperty();
/* 253 */     p.setID(-1L);
/* 254 */     p.setType(11L);
/* 255 */     p.setValue(value);
/* 256 */     CustomProperty cp = new CustomProperty(p, name);
/* 257 */     return put(cp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 270 */     Long id = (Long)this.dictionaryNameToID.get(name);
/* 271 */     CustomProperty cp = (CustomProperty)super.get(id);
/* 272 */     return cp != null ? cp.getValue() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(String name, Date value)
/*     */   {
/* 287 */     MutableProperty p = new MutableProperty();
/* 288 */     p.setID(-1L);
/* 289 */     p.setType(64L);
/* 290 */     p.setValue(value);
/* 291 */     CustomProperty cp = new CustomProperty(p, name);
/* 292 */     return put(cp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 301 */     return this.dictionaryNameToID.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> nameSet()
/*     */   {
/* 309 */     return this.dictionaryNameToID.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> idSet()
/*     */   {
/* 317 */     return this.dictionaryNameToID.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCodepage(int codepage)
/*     */   {
/* 328 */     MutableProperty p = new MutableProperty();
/* 329 */     p.setID(1L);
/* 330 */     p.setType(2L);
/* 331 */     p.setValue(Integer.valueOf(codepage));
/* 332 */     put(new CustomProperty(p));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Map<Long, String> getDictionary()
/*     */   {
/* 345 */     return this.dictionaryIDToName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 353 */     if ((key instanceof Long)) {
/* 354 */       return super.containsKey((Long)key);
/*     */     }
/* 356 */     if ((key instanceof String)) {
/* 357 */       return super.containsKey((Long)this.dictionaryNameToID.get(key));
/*     */     }
/* 359 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 366 */     if ((value instanceof CustomProperty)) {
/* 367 */       return super.containsValue((CustomProperty)value);
/*     */     }
/* 369 */     for (CustomProperty cp : super.values()) {
/* 370 */       if (cp.getValue() == value) {
/* 371 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 375 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCodepage()
/*     */   {
/* 387 */     int codepage = -1;
/* 388 */     for (Iterator<CustomProperty> i = values().iterator(); (codepage == -1) && (i.hasNext());)
/*     */     {
/* 390 */       CustomProperty cp = (CustomProperty)i.next();
/* 391 */       if (cp.getID() == 1L)
/* 392 */         codepage = ((Integer)cp.getValue()).intValue();
/*     */     }
/* 394 */     return codepage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPure()
/*     */   {
/* 409 */     return this.isPure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPure(boolean isPure)
/*     */   {
/* 419 */     this.isPure = isPure;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\CustomProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */