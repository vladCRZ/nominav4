/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomProperty
/*     */   extends MutableProperty
/*     */ {
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CustomProperty()
/*     */   {
/*  40 */     this.name = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CustomProperty(Property property)
/*     */   {
/*  51 */     this(property, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CustomProperty(Property property, String name)
/*     */   {
/*  63 */     super(property);
/*  64 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  74 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  84 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equalsContents(Object o)
/*     */   {
/* 101 */     CustomProperty c = (CustomProperty)o;
/* 102 */     String name1 = c.getName();
/* 103 */     String name2 = getName();
/* 104 */     boolean equalNames = true;
/* 105 */     if (name1 == null) {
/* 106 */       equalNames = name2 == null;
/*     */     } else
/* 108 */       equalNames = name1.equals(name2);
/* 109 */     return (equalNames) && (c.getID() == getID()) && (c.getType() == getType()) && (c.getValue().equals(getValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 119 */     return (int)getID();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\CustomProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */