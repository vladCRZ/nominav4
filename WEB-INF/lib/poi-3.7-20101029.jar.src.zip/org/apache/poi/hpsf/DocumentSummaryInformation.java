/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hpsf.wellknown.PropertyIDMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentSummaryInformation
/*     */   extends SpecialPropertySet
/*     */ {
/*     */   public static final String DEFAULT_STREAM_NAME = "\005DocumentSummaryInformation";
/*     */   
/*     */   public PropertyIDMap getPropertySetIDMap()
/*     */   {
/*  47 */     return PropertyIDMap.getDocumentSummaryInformationProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentSummaryInformation(PropertySet ps)
/*     */     throws UnexpectedPropertySetTypeException
/*     */   {
/*  63 */     super(ps);
/*  64 */     if (!isDocumentSummaryInformation()) {
/*  65 */       throw new UnexpectedPropertySetTypeException("Not a " + getClass().getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCategory()
/*     */   {
/*  78 */     return (String)getProperty(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCategory(String category)
/*     */   {
/*  88 */     MutableSection s = (MutableSection)getFirstSection();
/*  89 */     s.setProperty(2, category);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCategory()
/*     */   {
/*  97 */     MutableSection s = (MutableSection)getFirstSection();
/*  98 */     s.removeProperty(2L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPresentationFormat()
/*     */   {
/* 111 */     return (String)getProperty(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPresentationFormat(String presentationFormat)
/*     */   {
/* 121 */     MutableSection s = (MutableSection)getFirstSection();
/* 122 */     s.setProperty(3, presentationFormat);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePresentationFormat()
/*     */   {
/* 130 */     MutableSection s = (MutableSection)getFirstSection();
/* 131 */     s.removeProperty(3L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/* 144 */     return getPropertyIntValue(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setByteCount(int byteCount)
/*     */   {
/* 154 */     MutableSection s = (MutableSection)getFirstSection();
/* 155 */     s.setProperty(4, byteCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeByteCount()
/*     */   {
/* 163 */     MutableSection s = (MutableSection)getFirstSection();
/* 164 */     s.removeProperty(4L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineCount()
/*     */   {
/* 177 */     return getPropertyIntValue(5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineCount(int lineCount)
/*     */   {
/* 187 */     MutableSection s = (MutableSection)getFirstSection();
/* 188 */     s.setProperty(5, lineCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLineCount()
/*     */   {
/* 196 */     MutableSection s = (MutableSection)getFirstSection();
/* 197 */     s.removeProperty(5L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getParCount()
/*     */   {
/* 210 */     return getPropertyIntValue(6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParCount(int parCount)
/*     */   {
/* 220 */     MutableSection s = (MutableSection)getFirstSection();
/* 221 */     s.setProperty(6, parCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeParCount()
/*     */   {
/* 229 */     MutableSection s = (MutableSection)getFirstSection();
/* 230 */     s.removeProperty(6L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSlideCount()
/*     */   {
/* 243 */     return getPropertyIntValue(7);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSlideCount(int slideCount)
/*     */   {
/* 253 */     MutableSection s = (MutableSection)getFirstSection();
/* 254 */     s.setProperty(7, slideCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSlideCount()
/*     */   {
/* 262 */     MutableSection s = (MutableSection)getFirstSection();
/* 263 */     s.removeProperty(7L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNoteCount()
/*     */   {
/* 276 */     return getPropertyIntValue(8);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNoteCount(int noteCount)
/*     */   {
/* 286 */     MutableSection s = (MutableSection)getFirstSection();
/* 287 */     s.setProperty(8, noteCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeNoteCount()
/*     */   {
/* 295 */     MutableSection s = (MutableSection)getFirstSection();
/* 296 */     s.removeProperty(8L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHiddenCount()
/*     */   {
/* 310 */     return getPropertyIntValue(9);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHiddenCount(int hiddenCount)
/*     */   {
/* 320 */     MutableSection s = (MutableSection)getSections().get(0);
/* 321 */     s.setProperty(9, hiddenCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeHiddenCount()
/*     */   {
/* 329 */     MutableSection s = (MutableSection)getFirstSection();
/* 330 */     s.removeProperty(9L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMMClipCount()
/*     */   {
/* 344 */     return getPropertyIntValue(10);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMMClipCount(int mmClipCount)
/*     */   {
/* 354 */     MutableSection s = (MutableSection)getFirstSection();
/* 355 */     s.setProperty(10, mmClipCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMMClipCount()
/*     */   {
/* 363 */     MutableSection s = (MutableSection)getFirstSection();
/* 364 */     s.removeProperty(10L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getScale()
/*     */   {
/* 377 */     return getPropertyBooleanValue(11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScale(boolean scale)
/*     */   {
/* 387 */     MutableSection s = (MutableSection)getFirstSection();
/* 388 */     s.setProperty(11, scale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeScale()
/*     */   {
/* 396 */     MutableSection s = (MutableSection)getFirstSection();
/* 397 */     s.removeProperty(11L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getHeadingPair()
/*     */   {
/* 411 */     notYetImplemented("Reading byte arrays ");
/* 412 */     return (byte[])getProperty(12);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeadingPair(byte[] headingPair)
/*     */   {
/* 422 */     notYetImplemented("Writing byte arrays ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeHeadingPair()
/*     */   {
/* 430 */     MutableSection s = (MutableSection)getFirstSection();
/* 431 */     s.removeProperty(12L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getDocparts()
/*     */   {
/* 445 */     notYetImplemented("Reading byte arrays");
/* 446 */     return (byte[])getProperty(13);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDocparts(byte[] docparts)
/*     */   {
/* 458 */     notYetImplemented("Writing byte arrays");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeDocparts()
/*     */   {
/* 466 */     MutableSection s = (MutableSection)getFirstSection();
/* 467 */     s.removeProperty(13L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getManager()
/*     */   {
/* 479 */     return (String)getProperty(14);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setManager(String manager)
/*     */   {
/* 489 */     MutableSection s = (MutableSection)getFirstSection();
/* 490 */     s.setProperty(14, manager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeManager()
/*     */   {
/* 498 */     MutableSection s = (MutableSection)getFirstSection();
/* 499 */     s.removeProperty(14L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCompany()
/*     */   {
/* 511 */     return (String)getProperty(15);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompany(String company)
/*     */   {
/* 521 */     MutableSection s = (MutableSection)getFirstSection();
/* 522 */     s.setProperty(15, company);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCompany()
/*     */   {
/* 530 */     MutableSection s = (MutableSection)getFirstSection();
/* 531 */     s.removeProperty(15L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getLinksDirty()
/*     */   {
/* 543 */     return getPropertyBooleanValue(16);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLinksDirty(boolean linksDirty)
/*     */   {
/* 553 */     MutableSection s = (MutableSection)getFirstSection();
/* 554 */     s.setProperty(16, linksDirty);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLinksDirty()
/*     */   {
/* 562 */     MutableSection s = (MutableSection)getFirstSection();
/* 563 */     s.removeProperty(16L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CustomProperties getCustomProperties()
/*     */   {
/* 575 */     CustomProperties cps = null;
/* 576 */     if (getSectionCount() >= 2)
/*     */     {
/* 578 */       cps = new CustomProperties();
/* 579 */       Section section = (Section)getSections().get(1);
/* 580 */       Map<Long, String> dictionary = section.getDictionary();
/* 581 */       Property[] properties = section.getProperties();
/* 582 */       int propertyCount = 0;
/* 583 */       for (int i = 0; i < properties.length; i++)
/*     */       {
/* 585 */         Property p = properties[i];
/* 586 */         long id = p.getID();
/* 587 */         if ((id != 0L) && (id != 1L))
/*     */         {
/* 589 */           propertyCount++;
/* 590 */           CustomProperty cp = new CustomProperty(p, (String)dictionary.get(Long.valueOf(id)));
/*     */           
/* 592 */           cps.put(cp.getName(), cp);
/*     */         }
/*     */       }
/* 595 */       if (cps.size() != propertyCount)
/* 596 */         cps.setPure(false);
/*     */     }
/* 598 */     return cps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomProperties(CustomProperties customProperties)
/*     */   {
/* 608 */     ensureSection2();
/* 609 */     MutableSection section = (MutableSection)getSections().get(1);
/* 610 */     Map<Long, String> dictionary = customProperties.getDictionary();
/* 611 */     section.clear();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 616 */     int cpCodepage = customProperties.getCodepage();
/* 617 */     if (cpCodepage < 0)
/* 618 */       cpCodepage = section.getCodepage();
/* 619 */     if (cpCodepage < 0)
/* 620 */       cpCodepage = 1200;
/* 621 */     customProperties.setCodepage(cpCodepage);
/* 622 */     section.setCodepage(cpCodepage);
/* 623 */     section.setDictionary(dictionary);
/* 624 */     for (Iterator<CustomProperty> i = customProperties.values().iterator(); i.hasNext();)
/*     */     {
/* 626 */       Property p = (Property)i.next();
/* 627 */       section.setProperty(p);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureSection2()
/*     */   {
/* 639 */     if (getSectionCount() < 2)
/*     */     {
/* 641 */       MutableSection s2 = new MutableSection();
/* 642 */       s2.setFormatID(org.apache.poi.hpsf.wellknown.SectionIDMap.DOCUMENT_SUMMARY_INFORMATION_ID[1]);
/* 643 */       addSection(s2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCustomProperties()
/*     */   {
/* 654 */     if (getSectionCount() >= 2) {
/* 655 */       getSections().remove(1);
/*     */     } else {
/* 657 */       throw new HPSFRuntimeException("Illegal internal format of Document SummaryInformation stream: second section is missing.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void notYetImplemented(String msg)
/*     */   {
/* 671 */     throw new UnsupportedOperationException(msg + " is not yet implemented.");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\DocumentSummaryInformation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */