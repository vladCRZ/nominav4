/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HPSFRuntimeException
/*     */   extends RuntimeException
/*     */ {
/*     */   private Throwable reason;
/*     */   
/*     */   public HPSFRuntimeException() {}
/*     */   
/*     */   public HPSFRuntimeException(String msg)
/*     */   {
/*  58 */     super(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HPSFRuntimeException(Throwable reason)
/*     */   {
/*  73 */     this.reason = reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HPSFRuntimeException(String msg, Throwable reason)
/*     */   {
/*  88 */     super(msg);
/*  89 */     this.reason = reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getReason()
/*     */   {
/* 103 */     return this.reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 113 */     printStackTrace(System.err);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream p)
/*     */   {
/* 123 */     Throwable reason = getReason();
/* 124 */     super.printStackTrace(p);
/* 125 */     if (reason != null)
/*     */     {
/* 127 */       p.println("Caused by:");
/* 128 */       reason.printStackTrace(p);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter p)
/*     */   {
/* 139 */     Throwable reason = getReason();
/* 140 */     super.printStackTrace(p);
/* 141 */     if (reason != null)
/*     */     {
/* 143 */       p.println("Caused by:");
/* 144 */       reason.printStackTrace(p);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\HPSFRuntimeException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */