/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutableProperty
/*     */   extends Property
/*     */ {
/*     */   public MutableProperty() {}
/*     */   
/*     */   public MutableProperty(Property p)
/*     */   {
/*  52 */     setID(p.getID());
/*  53 */     setType(p.getType());
/*  54 */     setValue(p.getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setID(long id)
/*     */   {
/*  65 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(long type)
/*     */   {
/*  77 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/*  89 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int write(OutputStream out, int codepage)
/*     */     throws IOException, WritingNotSupportedException
/*     */   {
/* 108 */     int length = 0;
/* 109 */     long variantType = getType();
/*     */     
/*     */ 
/* 112 */     if ((codepage == 1200) && (variantType == 30L)) {
/* 113 */       variantType = 31L;
/*     */     }
/* 115 */     length += TypeWriter.writeUIntToStream(out, variantType);
/* 116 */     length += VariantSupport.write(out, variantType, getValue(), codepage);
/* 117 */     return length;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\MutableProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */