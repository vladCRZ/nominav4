/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.apache.poi.poifs.filesystem.DirectoryEntry;
/*     */ import org.apache.poi.poifs.filesystem.Entry;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutablePropertySet
/*     */   extends PropertySet
/*     */ {
/*     */   public MutablePropertySet()
/*     */   {
/*  56 */     this.byteOrder = LittleEndian.getUShort(BYTE_ORDER_ASSERTION);
/*     */     
/*     */ 
/*  59 */     this.format = LittleEndian.getUShort(FORMAT_ASSERTION);
/*     */     
/*     */ 
/*     */ 
/*  63 */     this.osVersion = 133636;
/*     */     
/*     */ 
/*  66 */     this.classID = new ClassID();
/*     */     
/*     */ 
/*     */ 
/*  70 */     this.sections = new LinkedList();
/*  71 */     this.sections.add(new MutableSection());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutablePropertySet(PropertySet ps)
/*     */   {
/*  86 */     this.byteOrder = ps.getByteOrder();
/*  87 */     this.format = ps.getFormat();
/*  88 */     this.osVersion = ps.getOSVersion();
/*  89 */     setClassID(ps.getClassID());
/*  90 */     clearSections();
/*  91 */     if (this.sections == null)
/*  92 */       this.sections = new LinkedList();
/*  93 */     for (Iterator i = ps.getSections().iterator(); i.hasNext();)
/*     */     {
/*  95 */       MutableSection s = new MutableSection((Section)i.next());
/*  96 */       addSection(s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private final int OFFSET_HEADER = BYTE_ORDER_ASSERTION.length + FORMAT_ASSERTION.length + 4 + 16 + 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setByteOrder(int byteOrder)
/*     */   {
/* 121 */     this.byteOrder = byteOrder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(int format)
/*     */   {
/* 133 */     this.format = format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOSVersion(int osVersion)
/*     */   {
/* 145 */     this.osVersion = osVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClassID(ClassID classID)
/*     */   {
/* 160 */     this.classID = classID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearSections()
/*     */   {
/* 170 */     this.sections = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSection(Section section)
/*     */   {
/* 184 */     if (this.sections == null)
/* 185 */       this.sections = new LinkedList();
/* 186 */     this.sections.add(section);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(OutputStream out)
/*     */     throws WritingNotSupportedException, IOException
/*     */   {
/* 204 */     int nrSections = this.sections.size();
/* 205 */     int length = 0;
/*     */     
/*     */ 
/* 208 */     length += TypeWriter.writeToStream(out, (short)getByteOrder());
/* 209 */     length += TypeWriter.writeToStream(out, (short)getFormat());
/* 210 */     length += TypeWriter.writeToStream(out, getOSVersion());
/* 211 */     length += TypeWriter.writeToStream(out, getClassID());
/* 212 */     length += TypeWriter.writeToStream(out, nrSections);
/* 213 */     int offset = this.OFFSET_HEADER;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 218 */     offset += nrSections * 20;
/* 219 */     int sectionsBegin = offset;
/* 220 */     for (ListIterator i = this.sections.listIterator(); i.hasNext();)
/*     */     {
/* 222 */       MutableSection s = (MutableSection)i.next();
/* 223 */       ClassID formatID = s.getFormatID();
/* 224 */       if (formatID == null)
/* 225 */         throw new NoFormatIDException();
/* 226 */       length += TypeWriter.writeToStream(out, s.getFormatID());
/* 227 */       length += TypeWriter.writeUIntToStream(out, offset);
/*     */       try
/*     */       {
/* 230 */         offset += s.getSize();
/*     */       }
/*     */       catch (HPSFRuntimeException ex)
/*     */       {
/* 234 */         Throwable cause = ex.getReason();
/* 235 */         if ((cause instanceof UnsupportedEncodingException)) {
/* 236 */           throw new IllegalPropertySetDataException(cause);
/*     */         }
/* 238 */         throw ex;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 243 */     offset = sectionsBegin;
/* 244 */     for (ListIterator i = this.sections.listIterator(); i.hasNext();)
/*     */     {
/* 246 */       MutableSection s = (MutableSection)i.next();
/* 247 */       offset += s.write(out);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream toInputStream()
/*     */     throws IOException, WritingNotSupportedException
/*     */   {
/* 270 */     ByteArrayOutputStream psStream = new ByteArrayOutputStream();
/* 271 */     write(psStream);
/* 272 */     psStream.close();
/* 273 */     byte[] streamData = psStream.toByteArray();
/* 274 */     return new ByteArrayInputStream(streamData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(DirectoryEntry dir, String name)
/*     */     throws WritingNotSupportedException, IOException
/*     */   {
/*     */     try
/*     */     {
/* 293 */       Entry e = dir.getEntry(name);
/* 294 */       e.delete();
/*     */     }
/*     */     catch (FileNotFoundException ex) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 301 */     dir.createDocument(name, toInputStream());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\MutablePropertySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */