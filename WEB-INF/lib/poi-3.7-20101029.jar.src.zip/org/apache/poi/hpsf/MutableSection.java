/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutableSection
/*     */   extends Section
/*     */ {
/*  47 */   private boolean dirty = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Property> preprops;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] sectionBytes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutableSection()
/*     */   {
/*  74 */     this.dirty = true;
/*  75 */     this.formatID = null;
/*  76 */     this.offset = -1L;
/*  77 */     this.preprops = new LinkedList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutableSection(Section s)
/*     */   {
/*  92 */     setFormatID(s.getFormatID());
/*  93 */     Property[] pa = s.getProperties();
/*  94 */     MutableProperty[] mpa = new MutableProperty[pa.length];
/*  95 */     for (int i = 0; i < pa.length; i++)
/*  96 */       mpa[i] = new MutableProperty(pa[i]);
/*  97 */     setProperties(mpa);
/*  98 */     setDictionary(s.getDictionary());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatID(ClassID formatID)
/*     */   {
/* 113 */     this.formatID = formatID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatID(byte[] formatID)
/*     */   {
/* 129 */     ClassID fid = getFormatID();
/* 130 */     if (fid == null)
/*     */     {
/* 132 */       fid = new ClassID();
/* 133 */       setFormatID(fid);
/*     */     }
/* 135 */     fid.setBytes(formatID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperties(Property[] properties)
/*     */   {
/* 147 */     this.properties = properties;
/* 148 */     this.preprops = new LinkedList();
/* 149 */     for (int i = 0; i < properties.length; i++)
/* 150 */       this.preprops.add(properties[i]);
/* 151 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(int id, String value)
/*     */   {
/* 168 */     setProperty(id, 31L, value);
/* 169 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(int id, int value)
/*     */   {
/* 185 */     setProperty(id, 3L, Integer.valueOf(value));
/* 186 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(int id, long value)
/*     */   {
/* 202 */     setProperty(id, 20L, Long.valueOf(value));
/* 203 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(int id, boolean value)
/*     */   {
/* 219 */     setProperty(id, 11L, Boolean.valueOf(value));
/* 220 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(int id, long variantType, Object value)
/*     */   {
/* 243 */     MutableProperty p = new MutableProperty();
/* 244 */     p.setID(id);
/* 245 */     p.setType(variantType);
/* 246 */     p.setValue(value);
/* 247 */     setProperty(p);
/* 248 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(Property p)
/*     */   {
/* 264 */     long id = p.getID();
/* 265 */     removeProperty(id);
/* 266 */     this.preprops.add(p);
/* 267 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeProperty(long id)
/*     */   {
/* 279 */     for (Iterator<Property> i = this.preprops.iterator(); i.hasNext();) {
/* 280 */       if (((Property)i.next()).getID() == id)
/*     */       {
/* 282 */         i.remove();
/*     */       }
/*     */     }
/* 285 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setPropertyBooleanValue(int id, boolean value)
/*     */   {
/* 303 */     setProperty(id, 11L, Boolean.valueOf(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 315 */     if (this.dirty)
/*     */     {
/*     */       try
/*     */       {
/* 319 */         this.size = calcSize();
/* 320 */         this.dirty = false;
/*     */       }
/*     */       catch (HPSFRuntimeException ex)
/*     */       {
/* 324 */         throw ex;
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 328 */         throw new HPSFRuntimeException(ex);
/*     */       }
/*     */     }
/* 331 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int calcSize()
/*     */     throws WritingNotSupportedException, IOException
/*     */   {
/* 347 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 348 */     write(out);
/* 349 */     out.close();
/*     */     
/*     */ 
/* 352 */     this.sectionBytes = Util.pad4(out.toByteArray());
/* 353 */     return this.sectionBytes.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int write(OutputStream out)
/*     */     throws WritingNotSupportedException, IOException
/*     */   {
/* 378 */     if ((!this.dirty) && (this.sectionBytes != null))
/*     */     {
/* 380 */       out.write(this.sectionBytes);
/* 381 */       return this.sectionBytes.length;
/*     */     }
/*     */     
/*     */ 
/* 385 */     ByteArrayOutputStream propertyStream = new ByteArrayOutputStream();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 391 */     ByteArrayOutputStream propertyListStream = new ByteArrayOutputStream();
/*     */     
/*     */ 
/*     */ 
/* 395 */     int position = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 400 */     position += 8 + getPropertyCount() * 2 * 4;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 405 */     int codepage = -1;
/* 406 */     if (getProperty(0L) != null)
/*     */     {
/* 408 */       Object p1 = getProperty(1L);
/* 409 */       if (p1 != null)
/*     */       {
/* 411 */         if (!(p1 instanceof Integer)) {
/* 412 */           throw new IllegalPropertySetDataException("The codepage property (ID = 1) must be an Integer object.");
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 420 */         setProperty(1, 2L, Integer.valueOf(1200));
/*     */       }
/* 422 */       codepage = getCodepage();
/*     */     }
/*     */     
/*     */ 
/* 426 */     Collections.sort(this.preprops, new Comparator()
/*     */     {
/*     */       public int compare(Property p1, Property p2)
/*     */       {
/* 430 */         if (p1.getID() < p2.getID())
/* 431 */           return -1;
/* 432 */         if (p1.getID() == p2.getID()) {
/* 433 */           return 0;
/*     */         }
/* 435 */         return 1;
/*     */       }
/*     */     });
/*     */     
/*     */ 
/*     */ 
/* 441 */     for (ListIterator<Property> i = this.preprops.listIterator(); i.hasNext();)
/*     */     {
/* 443 */       MutableProperty p = (MutableProperty)i.next();
/* 444 */       long id = p.getID();
/*     */       
/*     */ 
/* 447 */       TypeWriter.writeUIntToStream(propertyListStream, p.getID());
/* 448 */       TypeWriter.writeUIntToStream(propertyListStream, position);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 454 */       if (id != 0L)
/*     */       {
/*     */ 
/* 457 */         position += p.write(propertyStream, getCodepage());
/*     */       }
/*     */       else {
/* 460 */         if (codepage == -1) {
/* 461 */           throw new IllegalPropertySetDataException("Codepage (property 1) is undefined.");
/*     */         }
/* 463 */         position += writeDictionary(propertyStream, this.dictionary, codepage);
/*     */       }
/*     */     }
/*     */     
/* 467 */     propertyStream.close();
/* 468 */     propertyListStream.close();
/*     */     
/*     */ 
/* 471 */     byte[] pb1 = propertyListStream.toByteArray();
/* 472 */     byte[] pb2 = propertyStream.toByteArray();
/*     */     
/*     */ 
/* 475 */     TypeWriter.writeToStream(out, 8 + pb1.length + pb2.length);
/*     */     
/*     */ 
/*     */ 
/* 479 */     TypeWriter.writeToStream(out, getPropertyCount());
/*     */     
/*     */ 
/* 482 */     out.write(pb1);
/*     */     
/*     */ 
/* 485 */     out.write(pb2);
/*     */     
/* 487 */     int streamLength = 8 + pb1.length + pb2.length;
/* 488 */     return streamLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int writeDictionary(OutputStream out, Map<Long, String> dictionary, int codepage)
/*     */     throws IOException
/*     */   {
/* 506 */     int length = TypeWriter.writeUIntToStream(out, dictionary.size());
/* 507 */     for (Iterator<Long> i = dictionary.keySet().iterator(); i.hasNext();)
/*     */     {
/* 509 */       Long key = (Long)i.next();
/* 510 */       String value = (String)dictionary.get(key);
/*     */       
/* 512 */       if (codepage == 1200)
/*     */       {
/*     */ 
/* 515 */         int sLength = value.length() + 1;
/* 516 */         if (sLength % 2 == 1)
/* 517 */           sLength++;
/* 518 */         length += TypeWriter.writeUIntToStream(out, key.longValue());
/* 519 */         length += TypeWriter.writeUIntToStream(out, sLength);
/* 520 */         byte[] ca = value.getBytes(VariantSupport.codepageToEncoding(codepage));
/*     */         
/* 522 */         for (int j = 2; j < ca.length; j += 2)
/*     */         {
/* 524 */           out.write(ca[(j + 1)]);
/* 525 */           out.write(ca[j]);
/* 526 */           length += 2;
/*     */         }
/* 528 */         sLength -= value.length();
/* 529 */         while (sLength > 0)
/*     */         {
/* 531 */           out.write(0);
/* 532 */           out.write(0);
/* 533 */           length += 2;
/* 534 */           sLength--;
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 541 */         length += TypeWriter.writeUIntToStream(out, key.longValue());
/* 542 */         length += TypeWriter.writeUIntToStream(out, value.length() + 1);
/* 543 */         byte[] ba = value.getBytes(VariantSupport.codepageToEncoding(codepage));
/*     */         
/* 545 */         for (int j = 0; j < ba.length; j++)
/*     */         {
/* 547 */           out.write(ba[j]);
/* 548 */           length++;
/*     */         }
/* 550 */         out.write(0);
/* 551 */         length++;
/*     */       }
/*     */     }
/* 554 */     return length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 568 */     return this.preprops.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Property[] getProperties()
/*     */   {
/* 580 */     this.properties = ((Property[])this.preprops.toArray(new Property[0]));
/* 581 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(long id)
/*     */   {
/* 596 */     getProperties();
/* 597 */     return super.getProperty(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDictionary(Map<Long, String> dictionary)
/*     */     throws IllegalPropertySetDataException
/*     */   {
/* 621 */     if (dictionary != null)
/*     */     {
/* 623 */       this.dictionary = dictionary;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 628 */       setProperty(0, -1L, dictionary);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 633 */       Integer codepage = (Integer)getProperty(1L);
/*     */       
/* 635 */       if (codepage == null) {
/* 636 */         setProperty(1, 2L, Integer.valueOf(1200));
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 642 */       removeProperty(0L);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(int id, Object value)
/*     */   {
/* 656 */     if ((value instanceof String)) {
/* 657 */       setProperty(id, (String)value);
/* 658 */     } else if ((value instanceof Long)) {
/* 659 */       setProperty(id, ((Long)value).longValue());
/* 660 */     } else if ((value instanceof Integer)) {
/* 661 */       setProperty(id, ((Integer)value).intValue());
/* 662 */     } else if ((value instanceof Short)) {
/* 663 */       setProperty(id, ((Short)value).intValue());
/* 664 */     } else if ((value instanceof Boolean)) {
/* 665 */       setProperty(id, ((Boolean)value).booleanValue());
/* 666 */     } else if ((value instanceof Date)) {
/* 667 */       setProperty(id, 64L, value);
/*     */     } else {
/* 669 */       throw new HPSFRuntimeException("HPSF does not support properties of type " + value.getClass().getName() + ".");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 682 */     Property[] properties = getProperties();
/* 683 */     for (int i = 0; i < properties.length; i++)
/*     */     {
/* 685 */       Property p = properties[i];
/* 686 */       removeProperty(p.getID());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCodepage(int codepage)
/*     */   {
/* 697 */     setProperty(1, 2L, Integer.valueOf(codepage));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\MutableSection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */