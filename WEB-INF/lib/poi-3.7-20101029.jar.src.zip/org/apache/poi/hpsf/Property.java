/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.POILogFactory;
/*     */ import org.apache.poi.util.POILogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Property
/*     */ {
/*     */   protected long id;
/*     */   protected long type;
/*     */   protected Object value;
/*     */   
/*     */   public long getID()
/*     */   {
/*  74 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getType()
/*     */   {
/*  90 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 106 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Property(long id, long type, Object value)
/*     */   {
/* 121 */     this.id = id;
/* 122 */     this.type = type;
/* 123 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Property(long id, byte[] src, long offset, int length, int codepage)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 146 */     this.id = id;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */     if (id == 0L)
/*     */     {
/* 154 */       this.value = readDictionary(src, offset, length, codepage);
/* 155 */       return;
/*     */     }
/*     */     
/* 158 */     int o = (int)offset;
/* 159 */     this.type = LittleEndian.getUInt(src, o);
/* 160 */     o += 4;
/*     */     
/*     */     try
/*     */     {
/* 164 */       this.value = VariantSupport.read(src, o, length, (int)this.type, codepage);
/*     */     }
/*     */     catch (UnsupportedVariantTypeException ex)
/*     */     {
/* 168 */       VariantSupport.writeUnsupportedTypeMessage(ex);
/* 169 */       this.value = ex.getValue();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Property() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map readDictionary(byte[] src, long offset, int length, int codepage)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 201 */     if ((offset < 0L) || (offset > src.length)) {
/* 202 */       throw new HPSFRuntimeException("Illegal offset " + offset + " while HPSF stream contains " + length + " bytes.");
/*     */     }
/*     */     
/* 205 */     int o = (int)offset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 210 */     long nrEntries = LittleEndian.getUInt(src, o);
/* 211 */     o += 4;
/*     */     
/* 213 */     Map m = new HashMap((int)nrEntries, 1.0F);
/*     */     
/*     */     try
/*     */     {
/* 217 */       for (int i = 0; i < nrEntries; i++)
/*     */       {
/*     */ 
/* 220 */         Long id = Long.valueOf(LittleEndian.getUInt(src, o));
/* 221 */         o += 4;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */         long sLength = LittleEndian.getUInt(src, o);
/* 229 */         o += 4;
/*     */         
/*     */ 
/* 232 */         StringBuffer b = new StringBuffer();
/* 233 */         switch (codepage)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */         case -1: 
/* 239 */           b.append(new String(src, o, (int)sLength));
/* 240 */           break;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         case 1200: 
/* 246 */           int nrBytes = (int)(sLength * 2L);
/* 247 */           byte[] h = new byte[nrBytes];
/* 248 */           for (int i2 = 0; i2 < nrBytes; i2 += 2)
/*     */           {
/* 250 */             h[i2] = src[(o + i2 + 1)];
/* 251 */             h[(i2 + 1)] = src[(o + i2)];
/*     */           }
/* 253 */           b.append(new String(h, 0, nrBytes, VariantSupport.codepageToEncoding(codepage)));
/*     */           
/* 255 */           break;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         default: 
/* 261 */           b.append(new String(src, o, (int)sLength, VariantSupport.codepageToEncoding(codepage)));
/*     */         }
/*     */         
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 268 */         while ((b.length() > 0) && (b.charAt(b.length() - 1) == 0))
/* 269 */           b.setLength(b.length() - 1);
/* 270 */         if (codepage == 1200)
/*     */         {
/* 272 */           if (sLength % 2L == 1L)
/* 273 */             sLength += 1L;
/* 274 */           o = (int)(o + (sLength + sLength));
/*     */         }
/*     */         else {
/* 277 */           o = (int)(o + sLength); }
/* 278 */         m.put(id, b.toString());
/*     */       }
/*     */     }
/*     */     catch (RuntimeException ex)
/*     */     {
/* 283 */       POILogger l = POILogFactory.getLogger(getClass());
/* 284 */       l.log(POILogger.WARN, "The property set's dictionary contains bogus data. All dictionary entries starting with the one with ID " + this.id + " will be ignored.", ex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 289 */     return m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getSize()
/*     */     throws WritingNotSupportedException
/*     */   {
/* 305 */     int length = VariantSupport.getVariantLength(this.type);
/* 306 */     if (length >= 0)
/* 307 */       return length;
/* 308 */     if (length == -2)
/*     */     {
/* 310 */       throw new WritingNotSupportedException(this.type, null);
/*     */     }
/*     */     
/* 313 */     int PADDING = 4;
/* 314 */     switch ((int)this.type)
/*     */     {
/*     */ 
/*     */     case 30: 
/* 318 */       int l = ((String)this.value).length() + 1;
/* 319 */       int r = l % 4;
/* 320 */       if (r > 0)
/* 321 */         l += 4 - r;
/* 322 */       length += l;
/* 323 */       break;
/*     */     case 0: 
/*     */       break;
/*     */     
/*     */     default: 
/* 328 */       throw new WritingNotSupportedException(this.type, this.value); }
/*     */     
/* 330 */     return length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 345 */     if (!(o instanceof Property)) {
/* 346 */       return false;
/*     */     }
/* 348 */     Property p = (Property)o;
/* 349 */     Object pValue = p.getValue();
/* 350 */     long pId = p.getID();
/* 351 */     if ((this.id != pId) || ((this.id != 0L) && (!typesAreEqual(this.type, p.getType()))))
/* 352 */       return false;
/* 353 */     if ((this.value == null) && (pValue == null))
/* 354 */       return true;
/* 355 */     if ((this.value == null) || (pValue == null)) {
/* 356 */       return false;
/*     */     }
/*     */     
/* 359 */     Class<?> valueClass = this.value.getClass();
/* 360 */     Class<?> pValueClass = pValue.getClass();
/* 361 */     if ((!valueClass.isAssignableFrom(pValueClass)) && (!pValueClass.isAssignableFrom(valueClass)))
/*     */     {
/* 363 */       return false;
/*     */     }
/* 365 */     if ((this.value instanceof byte[])) {
/* 366 */       return Util.equal((byte[])this.value, (byte[])pValue);
/*     */     }
/* 368 */     return this.value.equals(pValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean typesAreEqual(long t1, long t2)
/*     */   {
/* 375 */     if ((t1 == t2) || ((t1 == 30L) && (t2 == 31L)) || ((t2 == 30L) && (t1 == 31L)))
/*     */     {
/*     */ 
/* 378 */       return true;
/*     */     }
/* 380 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 390 */     long hashCode = 0L;
/* 391 */     hashCode += this.id;
/* 392 */     hashCode += this.type;
/* 393 */     if (this.value != null)
/* 394 */       hashCode += this.value.hashCode();
/* 395 */     int returnHashCode = (int)(hashCode & 0xFFFFFFFF);
/* 396 */     return returnHashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 407 */     StringBuffer b = new StringBuffer();
/* 408 */     b.append(getClass().getName());
/* 409 */     b.append('[');
/* 410 */     b.append("id: ");
/* 411 */     b.append(getID());
/* 412 */     b.append(", type: ");
/* 413 */     b.append(getType());
/* 414 */     Object value = getValue();
/* 415 */     b.append(", value: ");
/* 416 */     b.append(value.toString());
/* 417 */     if ((value instanceof String))
/*     */     {
/* 419 */       String s = (String)value;
/* 420 */       int l = s.length();
/* 421 */       byte[] bytes = new byte[l * 2];
/* 422 */       for (int i = 0; i < l; i++)
/*     */       {
/* 424 */         char c = s.charAt(i);
/* 425 */         byte high = (byte)((c & 0xFF00) >> '\b');
/* 426 */         byte low = (byte)((c & 0xFF) >> '\000');
/* 427 */         bytes[(i * 2)] = high;
/* 428 */         bytes[(i * 2 + 1)] = low;
/*     */       }
/* 430 */       String hex = HexDump.dump(bytes, 0L, 0);
/* 431 */       b.append(" [");
/* 432 */       b.append(hex);
/* 433 */       b.append("]");
/*     */     }
/* 435 */     b.append(']');
/* 436 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\Property.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */