/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hpsf.wellknown.SectionIDMap;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySet
/*     */ {
/*  67 */   static final byte[] BYTE_ORDER_ASSERTION = { -2, -1 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int byteOrder;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteOrder()
/*     */   {
/*  84 */     return this.byteOrder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   static final byte[] FORMAT_ASSERTION = { 0, 0 };
/*     */   
/*     */   protected int format;
/*     */   
/*     */   protected int osVersion;
/*     */   
/*     */   public static final int OS_WIN16 = 0;
/*     */   
/*     */   public static final int OS_MACINTOSH = 1;
/*     */   
/*     */   public static final int OS_WIN32 = 2;
/*     */   
/*     */   protected ClassID classID;
/*     */   protected List sections;
/*     */   
/*     */   public int getFormat()
/*     */   {
/* 109 */     return this.format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOSVersion()
/*     */   {
/* 148 */     return this.osVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassID getClassID()
/*     */   {
/* 167 */     return this.classID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSectionCount()
/*     */   {
/* 180 */     return this.sections.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getSections()
/*     */   {
/* 198 */     return this.sections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertySet() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySet(InputStream stream)
/*     */     throws NoPropertySetStreamException, MarkUnsupportedException, IOException, UnsupportedEncodingException
/*     */   {
/* 242 */     if (isPropertySetStream(stream))
/*     */     {
/* 244 */       int avail = stream.available();
/* 245 */       byte[] buffer = new byte[avail];
/* 246 */       stream.read(buffer, 0, buffer.length);
/* 247 */       init(buffer, 0, buffer.length);
/*     */     }
/*     */     else {
/* 250 */       throw new NoPropertySetStreamException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySet(byte[] stream, int offset, int length)
/*     */     throws NoPropertySetStreamException, UnsupportedEncodingException
/*     */   {
/* 273 */     if (isPropertySetStream(stream, offset, length)) {
/* 274 */       init(stream, offset, length);
/*     */     } else {
/* 276 */       throw new NoPropertySetStreamException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySet(byte[] stream)
/*     */     throws NoPropertySetStreamException, UnsupportedEncodingException
/*     */   {
/* 296 */     this(stream, 0, stream.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPropertySetStream(InputStream stream)
/*     */     throws MarkUnsupportedException, IOException
/*     */   {
/* 322 */     int BUFFER_SIZE = 50;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 329 */     if (!stream.markSupported())
/* 330 */       throw new MarkUnsupportedException(stream.getClass().getName());
/* 331 */     stream.mark(50);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 336 */     byte[] buffer = new byte[50];
/* 337 */     int bytes = stream.read(buffer, 0, Math.min(buffer.length, stream.available()));
/*     */     
/*     */ 
/* 340 */     boolean isPropertySetStream = isPropertySetStream(buffer, 0, bytes);
/*     */     
/* 342 */     stream.reset();
/* 343 */     return isPropertySetStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isPropertySetStream(byte[] src, int offset, int length)
/*     */   {
/* 369 */     int o = offset;
/* 370 */     int byteOrder = LittleEndian.getUShort(src, o);
/* 371 */     o += 2;
/* 372 */     byte[] temp = new byte[2];
/* 373 */     LittleEndian.putShort(temp, (short)byteOrder);
/* 374 */     if (!Util.equal(temp, BYTE_ORDER_ASSERTION))
/* 375 */       return false;
/* 376 */     int format = LittleEndian.getUShort(src, o);
/* 377 */     o += 2;
/* 378 */     temp = new byte[2];
/* 379 */     LittleEndian.putShort(temp, (short)format);
/* 380 */     if (!Util.equal(temp, FORMAT_ASSERTION)) {
/* 381 */       return false;
/*     */     }
/* 383 */     o += 4;
/*     */     
/* 385 */     o += 16;
/* 386 */     long sectionCount = LittleEndian.getUInt(src, o);
/* 387 */     o += 4;
/* 388 */     if (sectionCount < 0L)
/* 389 */       return false;
/* 390 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init(byte[] src, int offset, int length)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 416 */     int o = offset;
/* 417 */     this.byteOrder = LittleEndian.getUShort(src, o);
/* 418 */     o += 2;
/* 419 */     this.format = LittleEndian.getUShort(src, o);
/* 420 */     o += 2;
/* 421 */     this.osVersion = ((int)LittleEndian.getUInt(src, o));
/* 422 */     o += 4;
/* 423 */     this.classID = new ClassID(src, o);
/* 424 */     o += 16;
/* 425 */     int sectionCount = LittleEndian.getInt(src, o);
/* 426 */     o += 4;
/* 427 */     if (sectionCount < 0) {
/* 428 */       throw new HPSFRuntimeException("Section count " + sectionCount + " is negative.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 443 */     this.sections = new ArrayList(sectionCount);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 450 */     for (int i = 0; i < sectionCount; i++)
/*     */     {
/* 452 */       Section s = new Section(src, o);
/* 453 */       o += 20;
/* 454 */       this.sections.add(s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSummaryInformation()
/*     */   {
/* 469 */     if (this.sections.size() <= 0)
/* 470 */       return false;
/* 471 */     return Util.equal(((Section)this.sections.get(0)).getFormatID().getBytes(), SectionIDMap.SUMMARY_INFORMATION_ID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDocumentSummaryInformation()
/*     */   {
/* 486 */     if (this.sections.size() <= 0)
/* 487 */       return false;
/* 488 */     return Util.equal(((Section)this.sections.get(0)).getFormatID().getBytes(), SectionIDMap.DOCUMENT_SUMMARY_INFORMATION_ID[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Property[] getProperties()
/*     */     throws NoSingleSectionException
/*     */   {
/* 509 */     return getFirstSection().getProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getProperty(int id)
/*     */     throws NoSingleSectionException
/*     */   {
/* 527 */     return getFirstSection().getProperty(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean getPropertyBooleanValue(int id)
/*     */     throws NoSingleSectionException
/*     */   {
/* 548 */     return getFirstSection().getPropertyBooleanValue(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPropertyIntValue(int id)
/*     */     throws NoSingleSectionException
/*     */   {
/* 568 */     return getFirstSection().getPropertyIntValue(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean wasNull()
/*     */     throws NoSingleSectionException
/*     */   {
/* 590 */     return getFirstSection().wasNull();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Section getFirstSection()
/*     */   {
/* 602 */     if (getSectionCount() < 1)
/* 603 */       throw new MissingSectionException("Property set does not contain any sections.");
/* 604 */     return (Section)this.sections.get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Section getSingleSection()
/*     */   {
/* 617 */     int sectionCount = getSectionCount();
/* 618 */     if (sectionCount != 1) {
/* 619 */       throw new NoSingleSectionException("Property set contains " + sectionCount + " sections.");
/*     */     }
/* 621 */     return (Section)this.sections.get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 637 */     if ((o == null) || (!(o instanceof PropertySet)))
/* 638 */       return false;
/* 639 */     PropertySet ps = (PropertySet)o;
/* 640 */     int byteOrder1 = ps.getByteOrder();
/* 641 */     int byteOrder2 = getByteOrder();
/* 642 */     ClassID classID1 = ps.getClassID();
/* 643 */     ClassID classID2 = getClassID();
/* 644 */     int format1 = ps.getFormat();
/* 645 */     int format2 = getFormat();
/* 646 */     int osVersion1 = ps.getOSVersion();
/* 647 */     int osVersion2 = getOSVersion();
/* 648 */     int sectionCount1 = ps.getSectionCount();
/* 649 */     int sectionCount2 = getSectionCount();
/* 650 */     if ((byteOrder1 != byteOrder2) || (!classID1.equals(classID2)) || (format1 != format2) || (osVersion1 != osVersion2) || (sectionCount1 != sectionCount2))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 655 */       return false;
/*     */     }
/*     */     
/* 658 */     return Util.equals(getSections(), ps.getSections());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 668 */     throw new UnsupportedOperationException("FIXME: Not yet implemented.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 678 */     StringBuffer b = new StringBuffer();
/* 679 */     int sectionCount = getSectionCount();
/* 680 */     b.append(getClass().getName());
/* 681 */     b.append('[');
/* 682 */     b.append("byteOrder: ");
/* 683 */     b.append(getByteOrder());
/* 684 */     b.append(", classID: ");
/* 685 */     b.append(getClassID());
/* 686 */     b.append(", format: ");
/* 687 */     b.append(getFormat());
/* 688 */     b.append(", OSVersion: ");
/* 689 */     b.append(getOSVersion());
/* 690 */     b.append(", sectionCount: ");
/* 691 */     b.append(sectionCount);
/* 692 */     b.append(", sections: [\n");
/* 693 */     List sections = getSections();
/* 694 */     for (int i = 0; i < sectionCount; i++)
/* 695 */       b.append(((Section)sections.get(i)).toString());
/* 696 */     b.append(']');
/* 697 */     b.append(']');
/* 698 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\PropertySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */