/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.rmi.UnexpectedException;
/*     */ import org.apache.poi.hpsf.wellknown.SectionIDMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertySetFactory
/*     */ {
/*     */   public static PropertySet create(InputStream stream)
/*     */     throws NoPropertySetStreamException, MarkUnsupportedException, UnsupportedEncodingException, IOException
/*     */   {
/*  59 */     PropertySet ps = new PropertySet(stream);
/*     */     try
/*     */     {
/*  62 */       if (ps.isSummaryInformation())
/*  63 */         return new SummaryInformation(ps);
/*  64 */       if (ps.isDocumentSummaryInformation()) {
/*  65 */         return new DocumentSummaryInformation(ps);
/*     */       }
/*  67 */       return ps;
/*     */ 
/*     */     }
/*     */     catch (UnexpectedPropertySetTypeException ex)
/*     */     {
/*     */ 
/*  73 */       throw new UnexpectedException(ex.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SummaryInformation newSummaryInformation()
/*     */   {
/*  86 */     MutablePropertySet ps = new MutablePropertySet();
/*  87 */     MutableSection s = (MutableSection)ps.getFirstSection();
/*  88 */     s.setFormatID(SectionIDMap.SUMMARY_INFORMATION_ID);
/*     */     try
/*     */     {
/*  91 */       return new SummaryInformation(ps);
/*     */ 
/*     */     }
/*     */     catch (UnexpectedPropertySetTypeException ex)
/*     */     {
/*  96 */       throw new HPSFRuntimeException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DocumentSummaryInformation newDocumentSummaryInformation()
/*     */   {
/* 109 */     MutablePropertySet ps = new MutablePropertySet();
/* 110 */     MutableSection s = (MutableSection)ps.getFirstSection();
/* 111 */     s.setFormatID(SectionIDMap.DOCUMENT_SUMMARY_INFORMATION_ID[0]);
/*     */     try
/*     */     {
/* 114 */       return new DocumentSummaryInformation(ps);
/*     */ 
/*     */     }
/*     */     catch (UnexpectedPropertySetTypeException ex)
/*     */     {
/* 119 */       throw new HPSFRuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\PropertySetFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */