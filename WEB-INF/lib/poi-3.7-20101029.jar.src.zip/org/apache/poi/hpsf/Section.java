/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hpsf.wellknown.SectionIDMap;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Section
/*     */ {
/*     */   protected Map<Long, String> dictionary;
/*     */   protected ClassID formatID;
/*     */   protected long offset;
/*     */   protected int size;
/*     */   protected Property[] properties;
/*     */   private boolean wasNull;
/*     */   
/*     */   public ClassID getFormatID()
/*     */   {
/*  64 */     return this.formatID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getOffset()
/*     */   {
/*  82 */     return this.offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 100 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 112 */     return this.properties.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Property[] getProperties()
/*     */   {
/* 130 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Section() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Section(byte[] src, int offset)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 156 */     int o1 = offset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 161 */     this.formatID = new ClassID(src, o1);
/* 162 */     o1 += 16;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     this.offset = LittleEndian.getUInt(src, o1);
/* 169 */     o1 = (int)this.offset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 174 */     this.size = ((int)LittleEndian.getUInt(src, o1));
/* 175 */     o1 += 4;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 180 */     int propertyCount = (int)LittleEndian.getUInt(src, o1);
/* 181 */     o1 += 4;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */     this.properties = new Property[propertyCount];
/*     */     
/*     */ 
/* 210 */     int pass1Offset = o1;
/* 211 */     List<PropertyListEntry> propertyList = new ArrayList(propertyCount);
/*     */     
/* 213 */     for (int i = 0; i < this.properties.length; i++)
/*     */     {
/* 215 */       PropertyListEntry ple = new PropertyListEntry();
/*     */       
/*     */ 
/* 218 */       ple.id = ((int)LittleEndian.getUInt(src, pass1Offset));
/* 219 */       pass1Offset += 4;
/*     */       
/*     */ 
/* 222 */       ple.offset = ((int)LittleEndian.getUInt(src, pass1Offset));
/* 223 */       pass1Offset += 4;
/*     */       
/*     */ 
/* 226 */       propertyList.add(ple);
/*     */     }
/*     */     
/*     */ 
/* 230 */     Collections.sort(propertyList);
/*     */     
/*     */ 
/* 233 */     for (int i = 0; i < propertyCount - 1; i++)
/*     */     {
/* 235 */       PropertyListEntry ple1 = (PropertyListEntry)propertyList.get(i);
/* 236 */       PropertyListEntry ple2 = (PropertyListEntry)propertyList.get(i + 1);
/* 237 */       ple1.length = (ple2.offset - ple1.offset);
/*     */     }
/* 239 */     if (propertyCount > 0)
/*     */     {
/* 241 */       PropertyListEntry ple = (PropertyListEntry)propertyList.get(propertyCount - 1);
/* 242 */       ple.length = (this.size - ple.offset);
/*     */     }
/*     */     
/*     */ 
/* 246 */     int codepage = -1;
/* 247 */     Iterator<PropertyListEntry> i = propertyList.iterator();
/* 248 */     while ((codepage == -1) && (i.hasNext()))
/*     */     {
/* 250 */       PropertyListEntry ple = (PropertyListEntry)i.next();
/*     */       
/*     */ 
/* 253 */       if (ple.id == 1)
/*     */       {
/*     */ 
/*     */ 
/* 257 */         int o = (int)(this.offset + ple.offset);
/* 258 */         long type = LittleEndian.getUInt(src, o);
/* 259 */         o += 4;
/*     */         
/* 261 */         if (type != 2L) {
/* 262 */           throw new HPSFRuntimeException("Value type of property ID 1 is not VT_I2 but " + type + ".");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 267 */         codepage = LittleEndian.getUShort(src, o);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 273 */     int i1 = 0;
/* 274 */     for (Iterator<PropertyListEntry> i = propertyList.iterator(); i.hasNext();)
/*     */     {
/* 276 */       PropertyListEntry ple = (PropertyListEntry)i.next();
/* 277 */       Property p = new Property(ple.id, src, this.offset + ple.offset, ple.length, codepage);
/*     */       
/*     */ 
/* 280 */       if (p.getID() == 1L)
/* 281 */         p = new Property(p.getID(), p.getType(), Integer.valueOf(codepage));
/* 282 */       this.properties[(i1++)] = p;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 288 */     this.dictionary = ((Map)getProperty(0L));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   class PropertyListEntry
/*     */     implements Comparable<PropertyListEntry>
/*     */   {
/*     */     int id;
/*     */     
/*     */ 
/*     */     int offset;
/*     */     
/*     */ 
/*     */     int length;
/*     */     
/*     */ 
/*     */ 
/*     */     PropertyListEntry() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public int compareTo(PropertyListEntry o)
/*     */     {
/* 312 */       int otherOffset = o.offset;
/* 313 */       if (this.offset < otherOffset)
/* 314 */         return -1;
/* 315 */       if (this.offset == otherOffset) {
/* 316 */         return 0;
/*     */       }
/* 318 */       return 1;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 323 */       StringBuffer b = new StringBuffer();
/* 324 */       b.append(getClass().getName());
/* 325 */       b.append("[id=");
/* 326 */       b.append(this.id);
/* 327 */       b.append(", offset=");
/* 328 */       b.append(this.offset);
/* 329 */       b.append(", length=");
/* 330 */       b.append(this.length);
/* 331 */       b.append(']');
/* 332 */       return b.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getProperty(long id)
/*     */   {
/* 350 */     this.wasNull = false;
/* 351 */     for (int i = 0; i < this.properties.length; i++)
/* 352 */       if (id == this.properties[i].getID())
/* 353 */         return this.properties[i].getValue();
/* 354 */     this.wasNull = true;
/* 355 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPropertyIntValue(long id)
/*     */   {
/* 374 */     Object o = getProperty(id);
/* 375 */     if (o == null)
/* 376 */       return 0;
/* 377 */     if ((!(o instanceof Long)) && (!(o instanceof Integer))) {
/* 378 */       throw new HPSFRuntimeException("This property is not an integer type, but " + o.getClass().getName() + ".");
/*     */     }
/*     */     
/* 381 */     Number i = (Number)o;
/* 382 */     return i.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean getPropertyBooleanValue(int id)
/*     */   {
/* 400 */     Boolean b = (Boolean)getProperty(id);
/* 401 */     if (b == null) {
/* 402 */       return false;
/*     */     }
/* 404 */     return b.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean wasNull()
/*     */   {
/* 432 */     return this.wasNull;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPIDString(long pid)
/*     */   {
/* 449 */     String s = null;
/* 450 */     if (this.dictionary != null)
/* 451 */       s = (String)this.dictionary.get(Long.valueOf(pid));
/* 452 */     if (s == null)
/* 453 */       s = SectionIDMap.getPIDString(getFormatID().getBytes(), pid);
/* 454 */     if (s == null)
/* 455 */       s = "[undefined]";
/* 456 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 487 */     if ((o == null) || (!(o instanceof Section)))
/* 488 */       return false;
/* 489 */     Section s = (Section)o;
/* 490 */     if (!s.getFormatID().equals(getFormatID())) {
/* 491 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 495 */     Property[] pa1 = new Property[getProperties().length];
/* 496 */     Property[] pa2 = new Property[s.getProperties().length];
/* 497 */     System.arraycopy(getProperties(), 0, pa1, 0, pa1.length);
/* 498 */     System.arraycopy(s.getProperties(), 0, pa2, 0, pa2.length);
/*     */     
/*     */ 
/*     */ 
/* 502 */     Property p10 = null;
/* 503 */     Property p20 = null;
/* 504 */     for (int i = 0; i < pa1.length; i++)
/*     */     {
/* 506 */       long id = pa1[i].getID();
/* 507 */       if (id == 0L)
/*     */       {
/* 509 */         p10 = pa1[i];
/* 510 */         pa1 = remove(pa1, i);
/* 511 */         i--;
/*     */       }
/* 513 */       if (id == 1L)
/*     */       {
/*     */ 
/* 516 */         pa1 = remove(pa1, i);
/* 517 */         i--;
/*     */       }
/*     */     }
/* 520 */     for (int i = 0; i < pa2.length; i++)
/*     */     {
/* 522 */       long id = pa2[i].getID();
/* 523 */       if (id == 0L)
/*     */       {
/* 525 */         p20 = pa2[i];
/* 526 */         pa2 = remove(pa2, i);
/* 527 */         i--;
/*     */       }
/* 529 */       if (id == 1L)
/*     */       {
/*     */ 
/* 532 */         pa2 = remove(pa2, i);
/* 533 */         i--;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 539 */     if (pa1.length != pa2.length) {
/* 540 */       return false;
/*     */     }
/*     */     
/* 543 */     boolean dictionaryEqual = true;
/* 544 */     if ((p10 != null) && (p20 != null)) {
/* 545 */       dictionaryEqual = p10.getValue().equals(p20.getValue());
/* 546 */     } else if ((p10 != null) || (p20 != null))
/* 547 */       dictionaryEqual = false;
/* 548 */     if (dictionaryEqual) {
/* 549 */       return Util.equals(pa1, pa2);
/*     */     }
/* 551 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Property[] remove(Property[] pa, int i)
/*     */   {
/* 566 */     Property[] h = new Property[pa.length - 1];
/* 567 */     if (i > 0)
/* 568 */       System.arraycopy(pa, 0, h, 0, i);
/* 569 */     System.arraycopy(pa, i + 1, h, i, h.length - i);
/* 570 */     return h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 580 */     long hashCode = 0L;
/* 581 */     hashCode += getFormatID().hashCode();
/* 582 */     Property[] pa = getProperties();
/* 583 */     for (int i = 0; i < pa.length; i++)
/* 584 */       hashCode += pa[i].hashCode();
/* 585 */     int returnHashCode = (int)(hashCode & 0xFFFFFFFF);
/* 586 */     return returnHashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 596 */     StringBuffer b = new StringBuffer();
/* 597 */     Property[] pa = getProperties();
/* 598 */     b.append(getClass().getName());
/* 599 */     b.append('[');
/* 600 */     b.append("formatID: ");
/* 601 */     b.append(getFormatID());
/* 602 */     b.append(", offset: ");
/* 603 */     b.append(getOffset());
/* 604 */     b.append(", propertyCount: ");
/* 605 */     b.append(getPropertyCount());
/* 606 */     b.append(", size: ");
/* 607 */     b.append(getSize());
/* 608 */     b.append(", properties: [\n");
/* 609 */     for (int i = 0; i < pa.length; i++)
/*     */     {
/* 611 */       b.append(pa[i].toString());
/* 612 */       b.append(",\n");
/*     */     }
/* 614 */     b.append(']');
/* 615 */     b.append(']');
/* 616 */     return b.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Long, String> getDictionary()
/*     */   {
/* 633 */     return this.dictionary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCodepage()
/*     */   {
/* 645 */     Integer codepage = (Integer)getProperty(1L);
/*     */     
/* 647 */     if (codepage == null)
/* 648 */       return -1;
/* 649 */     int cp = codepage.intValue();
/* 650 */     return cp;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\Section.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */