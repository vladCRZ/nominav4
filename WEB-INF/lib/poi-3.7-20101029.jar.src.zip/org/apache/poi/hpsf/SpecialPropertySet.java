/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hpsf.wellknown.PropertyIDMap;
/*     */ import org.apache.poi.poifs.filesystem.DirectoryEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpecialPropertySet
/*     */   extends MutablePropertySet
/*     */ {
/*     */   private MutablePropertySet delegate;
/*     */   
/*     */   public abstract PropertyIDMap getPropertySetIDMap();
/*     */   
/*     */   public SpecialPropertySet(PropertySet ps)
/*     */   {
/*  81 */     this.delegate = new MutablePropertySet(ps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpecialPropertySet(MutablePropertySet ps)
/*     */   {
/*  94 */     this.delegate = ps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteOrder()
/*     */   {
/* 104 */     return this.delegate.getByteOrder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFormat()
/*     */   {
/* 114 */     return this.delegate.getFormat();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOSVersion()
/*     */   {
/* 124 */     return this.delegate.getOSVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassID getClassID()
/*     */   {
/* 134 */     return this.delegate.getClassID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSectionCount()
/*     */   {
/* 144 */     return this.delegate.getSectionCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getSections()
/*     */   {
/* 154 */     return this.delegate.getSections();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSummaryInformation()
/*     */   {
/* 164 */     return this.delegate.isSummaryInformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDocumentSummaryInformation()
/*     */   {
/* 174 */     return this.delegate.isDocumentSummaryInformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Section getFirstSection()
/*     */   {
/* 184 */     return this.delegate.getFirstSection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSection(Section section)
/*     */   {
/* 193 */     this.delegate.addSection(section);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearSections()
/*     */   {
/* 203 */     this.delegate.clearSections();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setByteOrder(int byteOrder)
/*     */   {
/* 213 */     this.delegate.setByteOrder(byteOrder);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClassID(ClassID classID)
/*     */   {
/* 223 */     this.delegate.setClassID(classID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(int format)
/*     */   {
/* 233 */     this.delegate.setFormat(format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOSVersion(int osVersion)
/*     */   {
/* 243 */     this.delegate.setOSVersion(osVersion);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream toInputStream()
/*     */     throws IOException, WritingNotSupportedException
/*     */   {
/* 253 */     return this.delegate.toInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(DirectoryEntry dir, String name)
/*     */     throws WritingNotSupportedException, IOException
/*     */   {
/* 263 */     this.delegate.write(dir, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(OutputStream out)
/*     */     throws WritingNotSupportedException, IOException
/*     */   {
/* 273 */     this.delegate.write(out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 283 */     return this.delegate.equals(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Property[] getProperties()
/*     */     throws NoSingleSectionException
/*     */   {
/* 293 */     return this.delegate.getProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getProperty(int id)
/*     */     throws NoSingleSectionException
/*     */   {
/* 303 */     return this.delegate.getProperty(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean getPropertyBooleanValue(int id)
/*     */     throws NoSingleSectionException
/*     */   {
/* 313 */     return this.delegate.getPropertyBooleanValue(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPropertyIntValue(int id)
/*     */     throws NoSingleSectionException
/*     */   {
/* 323 */     return this.delegate.getPropertyIntValue(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 333 */     return this.delegate.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 343 */     return this.delegate.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean wasNull()
/*     */     throws NoSingleSectionException
/*     */   {
/* 353 */     return this.delegate.wasNull();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\SpecialPropertySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */