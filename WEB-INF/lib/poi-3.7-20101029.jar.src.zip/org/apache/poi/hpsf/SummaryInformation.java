/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.util.Date;
/*     */ import org.apache.poi.hpsf.wellknown.PropertyIDMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SummaryInformation
/*     */   extends SpecialPropertySet
/*     */ {
/*     */   public static final String DEFAULT_STREAM_NAME = "\005SummaryInformation";
/*     */   
/*     */   public PropertyIDMap getPropertySetIDMap()
/*     */   {
/*  41 */     return PropertyIDMap.getSummaryInformationProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SummaryInformation(PropertySet ps)
/*     */     throws UnexpectedPropertySetTypeException
/*     */   {
/*  57 */     super(ps);
/*  58 */     if (!isSummaryInformation()) {
/*  59 */       throw new UnexpectedPropertySetTypeException("Not a " + getClass().getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTitle()
/*     */   {
/*  72 */     return (String)getProperty(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/*  84 */     MutableSection s = (MutableSection)getFirstSection();
/*  85 */     s.setProperty(2, title);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeTitle()
/*     */   {
/*  95 */     MutableSection s = (MutableSection)getFirstSection();
/*  96 */     s.removeProperty(2L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 108 */     return (String)getProperty(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubject(String subject)
/*     */   {
/* 120 */     MutableSection s = (MutableSection)getFirstSection();
/* 121 */     s.setProperty(3, subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSubject()
/*     */   {
/* 131 */     MutableSection s = (MutableSection)getFirstSection();
/* 132 */     s.removeProperty(3L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAuthor()
/*     */   {
/* 144 */     return (String)getProperty(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthor(String author)
/*     */   {
/* 156 */     MutableSection s = (MutableSection)getFirstSection();
/* 157 */     s.setProperty(4, author);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAuthor()
/*     */   {
/* 167 */     MutableSection s = (MutableSection)getFirstSection();
/* 168 */     s.removeProperty(4L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getKeywords()
/*     */   {
/* 180 */     return (String)getProperty(5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeywords(String keywords)
/*     */   {
/* 192 */     MutableSection s = (MutableSection)getFirstSection();
/* 193 */     s.setProperty(5, keywords);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeKeywords()
/*     */   {
/* 203 */     MutableSection s = (MutableSection)getFirstSection();
/* 204 */     s.removeProperty(5L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getComments()
/*     */   {
/* 216 */     return (String)getProperty(6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComments(String comments)
/*     */   {
/* 228 */     MutableSection s = (MutableSection)getFirstSection();
/* 229 */     s.setProperty(6, comments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeComments()
/*     */   {
/* 239 */     MutableSection s = (MutableSection)getFirstSection();
/* 240 */     s.removeProperty(6L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTemplate()
/*     */   {
/* 252 */     return (String)getProperty(7);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplate(String template)
/*     */   {
/* 264 */     MutableSection s = (MutableSection)getFirstSection();
/* 265 */     s.setProperty(7, template);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeTemplate()
/*     */   {
/* 275 */     MutableSection s = (MutableSection)getFirstSection();
/* 276 */     s.removeProperty(7L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLastAuthor()
/*     */   {
/* 288 */     return (String)getProperty(8);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastAuthor(String lastAuthor)
/*     */   {
/* 300 */     MutableSection s = (MutableSection)getFirstSection();
/* 301 */     s.setProperty(8, lastAuthor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLastAuthor()
/*     */   {
/* 311 */     MutableSection s = (MutableSection)getFirstSection();
/* 312 */     s.removeProperty(8L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRevNumber()
/*     */   {
/* 324 */     return (String)getProperty(9);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRevNumber(String revNumber)
/*     */   {
/* 336 */     MutableSection s = (MutableSection)getFirstSection();
/* 337 */     s.setProperty(9, revNumber);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRevNumber()
/*     */   {
/* 347 */     MutableSection s = (MutableSection)getFirstSection();
/* 348 */     s.removeProperty(9L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getEditTime()
/*     */   {
/* 362 */     Date d = (Date)getProperty(10);
/* 363 */     if (d == null) {
/* 364 */       return 0L;
/*     */     }
/* 366 */     return Util.dateToFileTime(d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEditTime(long time)
/*     */   {
/* 378 */     Date d = Util.filetimeToDate(time);
/* 379 */     MutableSection s = (MutableSection)getFirstSection();
/* 380 */     s.setProperty(10, 64L, d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeEditTime()
/*     */   {
/* 390 */     MutableSection s = (MutableSection)getFirstSection();
/* 391 */     s.removeProperty(10L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLastPrinted()
/*     */   {
/* 403 */     return (Date)getProperty(11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastPrinted(Date lastPrinted)
/*     */   {
/* 415 */     MutableSection s = (MutableSection)getFirstSection();
/* 416 */     s.setProperty(11, 64L, lastPrinted);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLastPrinted()
/*     */   {
/* 427 */     MutableSection s = (MutableSection)getFirstSection();
/* 428 */     s.removeProperty(11L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getCreateDateTime()
/*     */   {
/* 440 */     return (Date)getProperty(12);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreateDateTime(Date createDateTime)
/*     */   {
/* 452 */     MutableSection s = (MutableSection)getFirstSection();
/* 453 */     s.setProperty(12, 64L, createDateTime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCreateDateTime()
/*     */   {
/* 464 */     MutableSection s = (MutableSection)getFirstSection();
/* 465 */     s.removeProperty(12L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLastSaveDateTime()
/*     */   {
/* 477 */     return (Date)getProperty(13);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastSaveDateTime(Date time)
/*     */   {
/* 489 */     MutableSection s = (MutableSection)getFirstSection();
/* 490 */     s.setProperty(13, 64L, time);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLastSaveDateTime()
/*     */   {
/* 502 */     MutableSection s = (MutableSection)getFirstSection();
/* 503 */     s.removeProperty(13L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPageCount()
/*     */   {
/* 517 */     return getPropertyIntValue(14);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPageCount(int pageCount)
/*     */   {
/* 529 */     MutableSection s = (MutableSection)getFirstSection();
/* 530 */     s.setProperty(14, pageCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePageCount()
/*     */   {
/* 540 */     MutableSection s = (MutableSection)getFirstSection();
/* 541 */     s.removeProperty(14L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 554 */     return getPropertyIntValue(15);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWordCount(int wordCount)
/*     */   {
/* 566 */     MutableSection s = (MutableSection)getFirstSection();
/* 567 */     s.setProperty(15, wordCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeWordCount()
/*     */   {
/* 577 */     MutableSection s = (MutableSection)getFirstSection();
/* 578 */     s.removeProperty(15L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCharCount()
/*     */   {
/* 591 */     return getPropertyIntValue(16);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharCount(int charCount)
/*     */   {
/* 603 */     MutableSection s = (MutableSection)getFirstSection();
/* 604 */     s.setProperty(16, charCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCharCount()
/*     */   {
/* 614 */     MutableSection s = (MutableSection)getFirstSection();
/* 615 */     s.removeProperty(16L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getThumbnail()
/*     */   {
/* 634 */     return (byte[])getProperty(17);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThumbnail(byte[] thumbnail)
/*     */   {
/* 646 */     MutableSection s = (MutableSection)getFirstSection();
/* 647 */     s.setProperty(17, 30L, thumbnail);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeThumbnail()
/*     */   {
/* 658 */     MutableSection s = (MutableSection)getFirstSection();
/* 659 */     s.removeProperty(17L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getApplicationName()
/*     */   {
/* 671 */     return (String)getProperty(18);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplicationName(String applicationName)
/*     */   {
/* 683 */     MutableSection s = (MutableSection)getFirstSection();
/* 684 */     s.setProperty(18, applicationName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeApplicationName()
/*     */   {
/* 694 */     MutableSection s = (MutableSection)getFirstSection();
/* 695 */     s.removeProperty(18L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSecurity()
/*     */   {
/* 724 */     return getPropertyIntValue(19);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSecurity(int security)
/*     */   {
/* 736 */     MutableSection s = (MutableSection)getFirstSection();
/* 737 */     s.setProperty(19, security);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSecurity()
/*     */   {
/* 747 */     MutableSection s = (MutableSection)getFirstSection();
/* 748 */     s.removeProperty(19L);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\SummaryInformation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */