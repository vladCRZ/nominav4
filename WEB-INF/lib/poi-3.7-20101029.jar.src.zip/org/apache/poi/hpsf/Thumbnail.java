/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Thumbnail
/*     */ {
/*  35 */   public static int OFFSET_CFTAG = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */   public static int OFFSET_CF = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   public static int OFFSET_WMFDATA = 20;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   public static int CFTAG_WINDOWS = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   public static int CFTAG_MACINTOSH = -2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   public static int CFTAG_FMTID = -3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   public static int CFTAG_NODATA = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   public static int CF_METAFILEPICT = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 110 */   public static int CF_DIB = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 115 */   public static int CF_ENHMETAFILE = 14;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */   public static int CF_BITMAP = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */   private byte[] _thumbnailData = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Thumbnail() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Thumbnail(byte[] thumbnailData)
/*     */   {
/* 156 */     this._thumbnailData = thumbnailData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getThumbnail()
/*     */   {
/* 170 */     return this._thumbnailData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThumbnail(byte[] thumbnail)
/*     */   {
/* 184 */     this._thumbnailData = thumbnail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getClipboardFormatTag()
/*     */   {
/* 205 */     long clipboardFormatTag = LittleEndian.getUInt(getThumbnail(), OFFSET_CFTAG);
/*     */     
/* 207 */     return clipboardFormatTag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getClipboardFormat()
/*     */     throws HPSFException
/*     */   {
/* 233 */     if (getClipboardFormatTag() != CFTAG_WINDOWS) {
/* 234 */       throw new HPSFException("Clipboard Format Tag of Thumbnail must be CFTAG_WINDOWS.");
/*     */     }
/*     */     
/* 237 */     return LittleEndian.getUInt(getThumbnail(), OFFSET_CF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getThumbnailAsWMF()
/*     */     throws HPSFException
/*     */   {
/* 260 */     if (getClipboardFormatTag() != CFTAG_WINDOWS) {
/* 261 */       throw new HPSFException("Clipboard Format Tag of Thumbnail must be CFTAG_WINDOWS.");
/*     */     }
/* 263 */     if (getClipboardFormat() != CF_METAFILEPICT) {
/* 264 */       throw new HPSFException("Clipboard Format of Thumbnail must be CF_METAFILEPICT.");
/*     */     }
/*     */     
/* 267 */     byte[] thumbnail = getThumbnail();
/* 268 */     int wmfImageLength = thumbnail.length - OFFSET_WMFDATA;
/* 269 */     byte[] wmfImage = new byte[wmfImageLength];
/* 270 */     System.arraycopy(thumbnail, OFFSET_WMFDATA, wmfImage, 0, wmfImageLength);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 275 */     return wmfImage;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\Thumbnail.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */