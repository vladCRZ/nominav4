/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeWriter
/*     */ {
/*     */   public static int writeToStream(OutputStream out, short n)
/*     */     throws IOException
/*     */   {
/*  45 */     int length = 2;
/*  46 */     byte[] buffer = new byte[2];
/*  47 */     LittleEndian.putShort(buffer, 0, n);
/*  48 */     out.write(buffer, 0, 2);
/*  49 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int writeToStream(OutputStream out, int n)
/*     */     throws IOException
/*     */   {
/*  65 */     int l = 4;
/*  66 */     byte[] buffer = new byte[4];
/*  67 */     LittleEndian.putInt(buffer, 0, n);
/*  68 */     out.write(buffer, 0, 4);
/*  69 */     return 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int writeToStream(OutputStream out, long n)
/*     */     throws IOException
/*     */   {
/*  86 */     int l = 8;
/*  87 */     byte[] buffer = new byte[8];
/*  88 */     LittleEndian.putLong(buffer, 0, n);
/*  89 */     out.write(buffer, 0, 8);
/*  90 */     return 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeUShortToStream(OutputStream out, int n)
/*     */     throws IOException
/*     */   {
/* 106 */     int high = n & 0xFFFF0000;
/* 107 */     if (high != 0) {
/* 108 */       throw new IllegalPropertySetDataException("Value " + n + " cannot be represented by 2 bytes.");
/*     */     }
/* 110 */     writeToStream(out, (short)n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int writeUIntToStream(OutputStream out, long n)
/*     */     throws IOException
/*     */   {
/* 126 */     long high = n & 0xFFFFFFFF00000000;
/* 127 */     if ((high != 0L) && (high != -4294967296L)) {
/* 128 */       throw new IllegalPropertySetDataException("Value " + n + " cannot be represented by 4 bytes.");
/*     */     }
/* 130 */     return writeToStream(out, (int)n);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int writeToStream(OutputStream out, ClassID n)
/*     */     throws IOException
/*     */   {
/* 146 */     byte[] b = new byte[16];
/* 147 */     n.write(b, 0);
/* 148 */     out.write(b, 0, b.length);
/* 149 */     return b.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeToStream(OutputStream out, Property[] properties, int codepage)
/*     */     throws IOException, UnsupportedVariantTypeException
/*     */   {
/* 171 */     if (properties == null) {
/* 172 */       return;
/*     */     }
/*     */     
/*     */ 
/* 176 */     for (int i = 0; i < properties.length; i++)
/*     */     {
/* 178 */       Property p = properties[i];
/* 179 */       writeUIntToStream(out, p.getID());
/* 180 */       writeUIntToStream(out, p.getSize());
/*     */     }
/*     */     
/*     */ 
/* 184 */     for (int i = 0; i < properties.length; i++)
/*     */     {
/* 186 */       Property p = properties[i];
/* 187 */       long type = p.getType();
/* 188 */       writeUIntToStream(out, type);
/* 189 */       VariantSupport.write(out, (int)type, p.getValue(), codepage);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int writeToStream(OutputStream out, double n)
/*     */     throws IOException
/*     */   {
/* 206 */     int l = 8;
/* 207 */     byte[] buffer = new byte[8];
/* 208 */     LittleEndian.putDouble(buffer, 0, n);
/* 209 */     out.write(buffer, 0, 8);
/* 210 */     return 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\TypeWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */