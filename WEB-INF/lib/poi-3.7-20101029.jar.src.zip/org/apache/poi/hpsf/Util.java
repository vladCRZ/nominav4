/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   public static final long EPOCH_DIFF = 11644473600000L;
/*     */   
/*     */   public static boolean equal(byte[] a, byte[] b)
/*     */   {
/*  56 */     if (a.length != b.length)
/*  57 */       return false;
/*  58 */     for (int i = 0; i < a.length; i++)
/*  59 */       if (a[i] != b[i])
/*  60 */         return false;
/*  61 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void copy(byte[] src, int srcOffset, int length, byte[] dst, int dstOffset)
/*     */   {
/*  79 */     for (int i = 0; i < length; i++) {
/*  80 */       dst[(dstOffset + i)] = src[(srcOffset + i)];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] cat(byte[][] byteArrays)
/*     */   {
/*  95 */     int capacity = 0;
/*  96 */     for (int i = 0; i < byteArrays.length; i++)
/*  97 */       capacity += byteArrays[i].length;
/*  98 */     byte[] result = new byte[capacity];
/*  99 */     int r = 0;
/* 100 */     for (int i = 0; i < byteArrays.length; i++)
/* 101 */       for (int j = 0; j < byteArrays[i].length; j++)
/* 102 */         result[(r++)] = byteArrays[i][j];
/* 103 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] copy(byte[] src, int offset, int length)
/*     */   {
/* 120 */     byte[] result = new byte[length];
/* 121 */     copy(src, offset, length, result, 0);
/* 122 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date filetimeToDate(int high, int low)
/*     */   {
/* 152 */     long filetime = high << 32 | low & 0xFFFFFFFF;
/* 153 */     return filetimeToDate(filetime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date filetimeToDate(long filetime)
/*     */   {
/* 168 */     long ms_since_16010101 = filetime / 10000L;
/* 169 */     long ms_since_19700101 = ms_since_16010101 - 11644473600000L;
/* 170 */     return new Date(ms_since_19700101);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long dateToFileTime(Date date)
/*     */   {
/* 186 */     long ms_since_19700101 = date.getTime();
/* 187 */     long ms_since_16010101 = ms_since_19700101 + 11644473600000L;
/* 188 */     return ms_since_16010101 * 10000L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean equals(Collection<?> c1, Collection<?> c2)
/*     */   {
/* 216 */     Object[] o1 = c1.toArray();
/* 217 */     Object[] o2 = c2.toArray();
/* 218 */     return internalEquals(o1, o2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean equals(Object[] c1, Object[] c2)
/*     */   {
/* 234 */     Object[] o1 = (Object[])c1.clone();
/* 235 */     Object[] o2 = (Object[])c2.clone();
/* 236 */     return internalEquals(o1, o2);
/*     */   }
/*     */   
/*     */   private static boolean internalEquals(Object[] o1, Object[] o2)
/*     */   {
/* 241 */     for (int i1 = 0; i1 < o1.length; i1++)
/*     */     {
/* 243 */       Object obj1 = o1[i1];
/* 244 */       boolean matchFound = false;
/* 245 */       for (int i2 = 0; (!matchFound) && (i2 < o1.length); i2++)
/*     */       {
/* 247 */         Object obj2 = o2[i2];
/* 248 */         if (obj1.equals(obj2))
/*     */         {
/* 250 */           matchFound = true;
/* 251 */           o2[i2] = null;
/*     */         }
/*     */       }
/* 254 */       if (!matchFound)
/* 255 */         return false;
/*     */     }
/* 257 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] pad4(byte[] ba)
/*     */   {
/* 271 */     int PAD = 4;
/*     */     
/* 273 */     int l = ba.length % 4;
/* 274 */     byte[] result; byte[] result; if (l == 0) {
/* 275 */       result = ba;
/*     */     }
/*     */     else {
/* 278 */       l = 4 - l;
/* 279 */       result = new byte[ba.length + l];
/* 280 */       System.arraycopy(ba, 0, result, 0, ba.length);
/*     */     }
/* 282 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] pad4(char[] ca)
/*     */   {
/* 296 */     int PAD = 4;
/*     */     
/* 298 */     int l = ca.length % 4;
/* 299 */     char[] result; char[] result; if (l == 0) {
/* 300 */       result = ca;
/*     */     }
/*     */     else {
/* 303 */       l = 4 - l;
/* 304 */       result = new char[ca.length + l];
/* 305 */       System.arraycopy(ca, 0, result, 0, ca.length);
/*     */     }
/* 307 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] pad4(String s)
/*     */   {
/* 321 */     return pad4(s.toCharArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Throwable t)
/*     */   {
/* 337 */     StringWriter sw = new StringWriter();
/* 338 */     PrintWriter pw = new PrintWriter(sw);
/* 339 */     t.printStackTrace(pw);
/* 340 */     pw.close();
/*     */     try
/*     */     {
/* 343 */       sw.close();
/* 344 */       return sw.toString();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 348 */       StringBuffer b = new StringBuffer(t.getMessage());
/* 349 */       b.append("\n");
/* 350 */       b.append("Could not create a stacktrace. Reason: ");
/* 351 */       b.append(e.getMessage());
/* 352 */       return b.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */