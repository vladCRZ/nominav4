/*     */ package org.apache.poi.hpsf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariantSupport
/*     */   extends Variant
/*     */ {
/*  52 */   private static boolean logUnsupportedTypes = false;
/*     */   
/*     */ 
/*     */ 
/*     */   protected static List unsupportedMessage;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setLogUnsupportedTypes(boolean logUnsupportedTypes)
/*     */   {
/*  63 */     logUnsupportedTypes = logUnsupportedTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isLogUnsupportedTypes()
/*     */   {
/*  75 */     return logUnsupportedTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void writeUnsupportedTypeMessage(UnsupportedVariantTypeException ex)
/*     */   {
/*  96 */     if (isLogUnsupportedTypes())
/*     */     {
/*  98 */       if (unsupportedMessage == null)
/*  99 */         unsupportedMessage = new LinkedList();
/* 100 */       Long vt = Long.valueOf(ex.getVariantType());
/* 101 */       if (!unsupportedMessage.contains(vt))
/*     */       {
/* 103 */         System.err.println(ex.getMessage());
/* 104 */         unsupportedMessage.add(vt);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   public static final int[] SUPPORTED_TYPES = { 0, 2, 3, 20, 5, 64, 30, 31, 71, 11 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSupportedType(int variantType)
/*     */   {
/* 132 */     for (int i = 0; i < SUPPORTED_TYPES.length; i++)
/* 133 */       if (variantType == SUPPORTED_TYPES[i])
/* 134 */         return true;
/* 135 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object read(byte[] src, int offset, int length, long type, int codepage)
/*     */     throws ReadingNotSupportedException, UnsupportedEncodingException
/*     */   {
/* 163 */     int o1 = offset;
/* 164 */     int l1 = length - 4;
/* 165 */     long lType = type;
/*     */     
/*     */ 
/*     */ 
/* 169 */     if ((codepage == 1200) && (type == 30L))
/* 170 */       lType = 31L;
/*     */     Object value;
/* 172 */     Object value; switch ((int)lType)
/*     */     {
/*     */ 
/*     */     case 0: 
/* 176 */       value = null;
/* 177 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 2: 
/* 185 */       value = Integer.valueOf(LittleEndian.getShort(src, o1));
/* 186 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 194 */       value = Integer.valueOf(LittleEndian.getInt(src, o1));
/* 195 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 20: 
/* 203 */       value = Long.valueOf(LittleEndian.getLong(src, o1));
/* 204 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 5: 
/* 212 */       value = new Double(LittleEndian.getDouble(src, o1));
/* 213 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 64: 
/* 221 */       long low = LittleEndian.getUInt(src, o1);
/* 222 */       o1 += 4;
/* 223 */       long high = LittleEndian.getUInt(src, o1);
/* 224 */       value = Util.filetimeToDate((int)high, (int)low);
/* 225 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 30: 
/* 234 */       int first = o1 + 4;
/* 235 */       long last = first + LittleEndian.getUInt(src, o1) - 1L;
/* 236 */       o1 += 4;
/* 237 */       while ((src[((int)last)] == 0) && (first <= last))
/* 238 */         last -= 1L;
/* 239 */       int l = (int)(last - first + 1L);
/* 240 */       value = codepage != -1 ? new String(src, first, l, codepageToEncoding(codepage)) : new String(src, first, l);
/*     */       
/*     */ 
/*     */ 
/* 244 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 31: 
/* 253 */       int first = o1 + 4;
/* 254 */       long last = first + LittleEndian.getUInt(src, o1) - 1L;
/* 255 */       long l = last - first;
/* 256 */       o1 += 4;
/* 257 */       StringBuffer b = new StringBuffer((int)(last - first));
/* 258 */       for (int i = 0; i <= l; i++)
/*     */       {
/* 260 */         int i1 = o1 + i * 2;
/* 261 */         int i2 = i1 + 1;
/* 262 */         int high = src[i2] << 8;
/* 263 */         int low = src[i1] & 0xFF;
/* 264 */         char c = (char)(high | low);
/* 265 */         b.append(c);
/*     */       }
/*     */       
/* 268 */       while ((b.length() > 0) && (b.charAt(b.length() - 1) == 0))
/* 269 */         b.setLength(b.length() - 1);
/* 270 */       value = b.toString();
/* 271 */       break;
/*     */     
/*     */ 
/*     */     case 71: 
/* 275 */       if (l1 < 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 285 */         l1 = LittleEndian.getInt(src, o1);o1 += 4;
/*     */       }
/* 287 */       byte[] v = new byte[l1];
/* 288 */       System.arraycopy(src, o1, v, 0, v.length);
/* 289 */       value = v;
/* 290 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 11: 
/* 300 */       long bool = LittleEndian.getUInt(src, o1);
/* 301 */       if (bool != 0L) {
/* 302 */         value = Boolean.TRUE;
/*     */       } else
/* 304 */         value = Boolean.FALSE;
/* 305 */       break;
/*     */     
/*     */ 
/*     */     default: 
/* 309 */       byte[] v = new byte[l1];
/* 310 */       for (int i = 0; i < l1; i++)
/* 311 */         v[i] = src[(o1 + i)];
/* 312 */       throw new ReadingNotSupportedException(type, v);
/*     */     }
/*     */     
/* 315 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String codepageToEncoding(int codepage)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 337 */     if (codepage <= 0) {
/* 338 */       throw new UnsupportedEncodingException("Codepage number may not be " + codepage);
/*     */     }
/* 340 */     switch (codepage)
/*     */     {
/*     */     case 1200: 
/* 343 */       return "UTF-16";
/*     */     case 1201: 
/* 345 */       return "UTF-16BE";
/*     */     case 65001: 
/* 347 */       return "UTF-8";
/*     */     case 37: 
/* 349 */       return "cp037";
/*     */     case 936: 
/* 351 */       return "GBK";
/*     */     case 949: 
/* 353 */       return "ms949";
/*     */     case 1250: 
/* 355 */       return "windows-1250";
/*     */     case 1251: 
/* 357 */       return "windows-1251";
/*     */     case 1252: 
/* 359 */       return "windows-1252";
/*     */     case 1253: 
/* 361 */       return "windows-1253";
/*     */     case 1254: 
/* 363 */       return "windows-1254";
/*     */     case 1255: 
/* 365 */       return "windows-1255";
/*     */     case 1256: 
/* 367 */       return "windows-1256";
/*     */     case 1257: 
/* 369 */       return "windows-1257";
/*     */     case 1258: 
/* 371 */       return "windows-1258";
/*     */     case 1361: 
/* 373 */       return "johab";
/*     */     case 10000: 
/* 375 */       return "MacRoman";
/*     */     case 10001: 
/* 377 */       return "SJIS";
/*     */     case 10002: 
/* 379 */       return "Big5";
/*     */     case 10003: 
/* 381 */       return "EUC-KR";
/*     */     case 10004: 
/* 383 */       return "MacArabic";
/*     */     case 10005: 
/* 385 */       return "MacHebrew";
/*     */     case 10006: 
/* 387 */       return "MacGreek";
/*     */     case 10007: 
/* 389 */       return "MacCyrillic";
/*     */     case 10008: 
/* 391 */       return "EUC_CN";
/*     */     case 10010: 
/* 393 */       return "MacRomania";
/*     */     case 10017: 
/* 395 */       return "MacUkraine";
/*     */     case 10021: 
/* 397 */       return "MacThai";
/*     */     case 10029: 
/* 399 */       return "MacCentralEurope";
/*     */     case 10079: 
/* 401 */       return "MacIceland";
/*     */     case 10081: 
/* 403 */       return "MacTurkish";
/*     */     case 10082: 
/* 405 */       return "MacCroatian";
/*     */     case 20127: 
/*     */     case 65000: 
/* 408 */       return "US-ASCII";
/*     */     case 20866: 
/* 410 */       return "KOI8-R";
/*     */     case 28591: 
/* 412 */       return "ISO-8859-1";
/*     */     case 28592: 
/* 414 */       return "ISO-8859-2";
/*     */     case 28593: 
/* 416 */       return "ISO-8859-3";
/*     */     case 28594: 
/* 418 */       return "ISO-8859-4";
/*     */     case 28595: 
/* 420 */       return "ISO-8859-5";
/*     */     case 28596: 
/* 422 */       return "ISO-8859-6";
/*     */     case 28597: 
/* 424 */       return "ISO-8859-7";
/*     */     case 28598: 
/* 426 */       return "ISO-8859-8";
/*     */     case 28599: 
/* 428 */       return "ISO-8859-9";
/*     */     case 50220: 
/*     */     case 50221: 
/*     */     case 50222: 
/* 432 */       return "ISO-2022-JP";
/*     */     case 50225: 
/* 434 */       return "ISO-2022-KR";
/*     */     case 51932: 
/* 436 */       return "EUC-JP";
/*     */     case 51949: 
/* 438 */       return "EUC-KR";
/*     */     case 52936: 
/* 440 */       return "GB2312";
/*     */     case 54936: 
/* 442 */       return "GB18030";
/*     */     case 932: 
/* 444 */       return "SJIS";
/*     */     }
/* 446 */     return "cp" + codepage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int write(OutputStream out, long type, Object value, int codepage)
/*     */     throws IOException, WritingNotSupportedException
/*     */   {
/* 474 */     int length = 0;
/* 475 */     switch ((int)type)
/*     */     {
/*     */     case 11: 
/*     */       int trueOrFalse;
/*     */       int trueOrFalse;
/* 480 */       if (((Boolean)value).booleanValue()) {
/* 481 */         trueOrFalse = 1;
/*     */       } else
/* 483 */         trueOrFalse = 0;
/* 484 */       length = TypeWriter.writeUIntToStream(out, trueOrFalse);
/* 485 */       break;
/*     */     
/*     */ 
/*     */     case 30: 
/* 489 */       byte[] bytes = codepage == -1 ? ((String)value).getBytes() : ((String)value).getBytes(codepageToEncoding(codepage));
/*     */       
/*     */ 
/*     */ 
/* 493 */       length = TypeWriter.writeUIntToStream(out, bytes.length + 1);
/* 494 */       byte[] b = new byte[bytes.length + 1];
/* 495 */       System.arraycopy(bytes, 0, b, 0, bytes.length);
/* 496 */       b[(b.length - 1)] = 0;
/* 497 */       out.write(b);
/* 498 */       length += b.length;
/* 499 */       break;
/*     */     
/*     */ 
/*     */     case 31: 
/* 503 */       int nrOfChars = ((String)value).length() + 1;
/* 504 */       length += TypeWriter.writeUIntToStream(out, nrOfChars);
/* 505 */       char[] s = Util.pad4((String)value);
/* 506 */       for (int i = 0; i < s.length; i++)
/*     */       {
/* 508 */         int high = (s[i] & 0xFF00) >> '\b';
/* 509 */         int low = s[i] & 0xFF;
/* 510 */         byte highb = (byte)high;
/* 511 */         byte lowb = (byte)low;
/* 512 */         out.write(lowb);
/* 513 */         out.write(highb);
/* 514 */         length += 2;
/*     */       }
/* 516 */       out.write(0);
/* 517 */       out.write(0);
/* 518 */       length += 2;
/* 519 */       break;
/*     */     
/*     */ 
/*     */     case 71: 
/* 523 */       byte[] b = (byte[])value;
/* 524 */       out.write(b);
/* 525 */       length = b.length;
/* 526 */       break;
/*     */     
/*     */ 
/*     */     case 0: 
/* 530 */       TypeWriter.writeUIntToStream(out, 0L);
/* 531 */       length = 4;
/* 532 */       break;
/*     */     
/*     */ 
/*     */     case 2: 
/* 536 */       TypeWriter.writeToStream(out, ((Integer)value).shortValue());
/* 537 */       length = 2;
/* 538 */       break;
/*     */     
/*     */ 
/*     */     case 3: 
/* 542 */       if (!(value instanceof Integer))
/*     */       {
/* 544 */         throw new ClassCastException("Could not cast an object to " + Integer.class.toString() + ": " + value.getClass().toString() + ", " + value.toString());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 549 */       length += TypeWriter.writeToStream(out, ((Integer)value).intValue());
/*     */       
/* 551 */       break;
/*     */     
/*     */ 
/*     */     case 20: 
/* 555 */       TypeWriter.writeToStream(out, ((Long)value).longValue());
/* 556 */       length = 8;
/* 557 */       break;
/*     */     
/*     */ 
/*     */     case 5: 
/* 561 */       length += TypeWriter.writeToStream(out, ((Double)value).doubleValue());
/*     */       
/* 563 */       break;
/*     */     
/*     */ 
/*     */     case 64: 
/* 567 */       long filetime = Util.dateToFileTime((Date)value);
/* 568 */       int high = (int)(filetime >> 32 & 0xFFFFFFFF);
/* 569 */       int low = (int)(filetime & 0xFFFFFFFF);
/* 570 */       length += TypeWriter.writeUIntToStream(out, 0xFFFFFFFF & low);
/*     */       
/* 572 */       length += TypeWriter.writeUIntToStream(out, 0xFFFFFFFF & high);
/*     */       
/* 574 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     default: 
/* 580 */       if ((value instanceof byte[]))
/*     */       {
/* 582 */         byte[] b = (byte[])value;
/* 583 */         out.write(b);
/* 584 */         length = b.length;
/* 585 */         writeUnsupportedTypeMessage(new WritingNotSupportedException(type, value));
/*     */       }
/*     */       else
/*     */       {
/* 589 */         throw new WritingNotSupportedException(type, value);
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/* 594 */     return length;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\VariantSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */