/*     */ package org.apache.poi.hpsf.extractor;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.poi.POIDocument;
/*     */ import org.apache.poi.POITextExtractor;
/*     */ import org.apache.poi.hpsf.CustomProperties;
/*     */ import org.apache.poi.hpsf.DocumentSummaryInformation;
/*     */ import org.apache.poi.hpsf.Property;
/*     */ import org.apache.poi.hpsf.SpecialPropertySet;
/*     */ import org.apache.poi.hpsf.SummaryInformation;
/*     */ import org.apache.poi.hpsf.wellknown.PropertyIDMap;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HPSFPropertiesExtractor
/*     */   extends POITextExtractor
/*     */ {
/*     */   public HPSFPropertiesExtractor(POITextExtractor mainExtractor)
/*     */   {
/*  43 */     super(mainExtractor);
/*     */   }
/*     */   
/*  46 */   public HPSFPropertiesExtractor(POIDocument doc) { super(doc); }
/*     */   
/*     */   public HPSFPropertiesExtractor(POIFSFileSystem fs) {
/*  49 */     super(new PropertiesOnlyDocument(fs));
/*     */   }
/*     */   
/*     */   public String getDocumentSummaryInformationText() {
/*  53 */     DocumentSummaryInformation dsi = this.document.getDocumentSummaryInformation();
/*  54 */     StringBuffer text = new StringBuffer();
/*     */     
/*     */ 
/*  57 */     text.append(getPropertiesText(dsi));
/*     */     
/*     */ 
/*  60 */     CustomProperties cps = dsi == null ? null : dsi.getCustomProperties();
/*  61 */     if (cps != null) {
/*  62 */       Iterator<String> keys = cps.nameSet().iterator();
/*  63 */       while (keys.hasNext()) {
/*  64 */         String key = (String)keys.next();
/*  65 */         String val = getPropertyValueText(cps.get(key));
/*  66 */         text.append(key + " = " + val + "\n");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  71 */     return text.toString();
/*     */   }
/*     */   
/*  74 */   public String getSummaryInformationText() { SummaryInformation si = this.document.getSummaryInformation();
/*     */     
/*     */ 
/*  77 */     return getPropertiesText(si);
/*     */   }
/*     */   
/*     */   private static String getPropertiesText(SpecialPropertySet ps) {
/*  81 */     if (ps == null)
/*     */     {
/*  83 */       return "";
/*     */     }
/*     */     
/*  86 */     StringBuffer text = new StringBuffer();
/*     */     
/*  88 */     PropertyIDMap idMap = ps.getPropertySetIDMap();
/*  89 */     Property[] props = ps.getProperties();
/*  90 */     for (int i = 0; i < props.length; i++) {
/*  91 */       String type = Long.toString(props[i].getID());
/*  92 */       Object typeObj = idMap.get(props[i].getID());
/*  93 */       if (typeObj != null) {
/*  94 */         type = typeObj.toString();
/*     */       }
/*     */       
/*  97 */       String val = getPropertyValueText(props[i].getValue());
/*  98 */       text.append(type + " = " + val + "\n");
/*     */     }
/*     */     
/* 101 */     return text.toString();
/*     */   }
/*     */   
/* 104 */   private static String getPropertyValueText(Object val) { if (val == null) {
/* 105 */       return "(not set)";
/*     */     }
/* 107 */     if ((val instanceof byte[])) {
/* 108 */       byte[] b = (byte[])val;
/* 109 */       if (b.length == 0) {
/* 110 */         return "";
/*     */       }
/* 112 */       if (b.length == 1) {
/* 113 */         return Byte.toString(b[0]);
/*     */       }
/* 115 */       if (b.length == 2) {
/* 116 */         return Integer.toString(LittleEndian.getUShort(b));
/*     */       }
/* 118 */       if (b.length == 4) {
/* 119 */         return Long.toString(LittleEndian.getUInt(b));
/*     */       }
/*     */       
/* 122 */       return new String(b);
/*     */     }
/* 124 */     return val.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 132 */     return getSummaryInformationText() + getDocumentSummaryInformationText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public POITextExtractor getMetadataTextExtractor()
/*     */   {
/* 139 */     throw new IllegalStateException("You already have the Metadata Text Extractor, not recursing!");
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class PropertiesOnlyDocument
/*     */     extends POIDocument
/*     */   {
/*     */     public PropertiesOnlyDocument(POIFSFileSystem fs)
/*     */     {
/* 148 */       super();
/*     */     }
/*     */     
/*     */     public void write(OutputStream out) {
/* 152 */       throw new IllegalStateException("Unable to write, only for properties!");
/*     */     }
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/* 157 */     for (String file : args) {
/* 158 */       HPSFPropertiesExtractor ext = new HPSFPropertiesExtractor(new POIFSFileSystem(new FileInputStream(file)));
/*     */       
/*     */ 
/* 161 */       System.out.println(ext.getText());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\extractor\HPSFPropertiesExtractor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */