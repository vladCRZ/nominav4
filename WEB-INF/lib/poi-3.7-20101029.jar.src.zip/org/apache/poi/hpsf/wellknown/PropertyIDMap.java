/*     */ package org.apache.poi.hpsf.wellknown;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyIDMap
/*     */   extends HashMap
/*     */ {
/*     */   public static final int PID_TITLE = 2;
/*     */   public static final int PID_SUBJECT = 3;
/*     */   public static final int PID_AUTHOR = 4;
/*     */   public static final int PID_KEYWORDS = 5;
/*     */   public static final int PID_COMMENTS = 6;
/*     */   public static final int PID_TEMPLATE = 7;
/*     */   public static final int PID_LASTAUTHOR = 8;
/*     */   public static final int PID_REVNUMBER = 9;
/*     */   public static final int PID_EDITTIME = 10;
/*     */   public static final int PID_LASTPRINTED = 11;
/*     */   public static final int PID_CREATE_DTM = 12;
/*     */   public static final int PID_LASTSAVE_DTM = 13;
/*     */   public static final int PID_PAGECOUNT = 14;
/*     */   public static final int PID_WORDCOUNT = 15;
/*     */   public static final int PID_CHARCOUNT = 16;
/*     */   public static final int PID_THUMBNAIL = 17;
/*     */   public static final int PID_APPNAME = 18;
/*     */   public static final int PID_SECURITY = 19;
/*     */   public static final int PID_DICTIONARY = 0;
/*     */   public static final int PID_CODEPAGE = 1;
/*     */   public static final int PID_CATEGORY = 2;
/*     */   public static final int PID_PRESFORMAT = 3;
/*     */   public static final int PID_BYTECOUNT = 4;
/*     */   public static final int PID_LINECOUNT = 5;
/*     */   public static final int PID_PARCOUNT = 6;
/*     */   public static final int PID_SLIDECOUNT = 7;
/*     */   public static final int PID_NOTECOUNT = 8;
/*     */   public static final int PID_HIDDENCOUNT = 9;
/*     */   public static final int PID_MMCLIPCOUNT = 10;
/*     */   public static final int PID_SCALE = 11;
/*     */   public static final int PID_HEADINGPAIR = 12;
/*     */   public static final int PID_DOCPARTS = 13;
/*     */   public static final int PID_MANAGER = 14;
/*     */   public static final int PID_COMPANY = 15;
/*     */   public static final int PID_LINKSDIRTY = 16;
/*     */   public static final int PID_MAX = 16;
/*     */   private static PropertyIDMap summaryInformationProperties;
/*     */   private static PropertyIDMap documentSummaryInformationProperties;
/*     */   
/*     */   public PropertyIDMap(int initialCapacity, float loadFactor)
/*     */   {
/* 264 */     super(initialCapacity, loadFactor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyIDMap(Map map)
/*     */   {
/* 276 */     super(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(long id, String idString)
/*     */   {
/* 294 */     return put(Long.valueOf(id), idString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(long id)
/*     */   {
/* 308 */     return get(Long.valueOf(id));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PropertyIDMap getSummaryInformationProperties()
/*     */   {
/* 318 */     if (summaryInformationProperties == null)
/*     */     {
/* 320 */       PropertyIDMap m = new PropertyIDMap(18, 1.0F);
/* 321 */       m.put(2L, "PID_TITLE");
/* 322 */       m.put(3L, "PID_SUBJECT");
/* 323 */       m.put(4L, "PID_AUTHOR");
/* 324 */       m.put(5L, "PID_KEYWORDS");
/* 325 */       m.put(6L, "PID_COMMENTS");
/* 326 */       m.put(7L, "PID_TEMPLATE");
/* 327 */       m.put(8L, "PID_LASTAUTHOR");
/* 328 */       m.put(9L, "PID_REVNUMBER");
/* 329 */       m.put(10L, "PID_EDITTIME");
/* 330 */       m.put(11L, "PID_LASTPRINTED");
/* 331 */       m.put(12L, "PID_CREATE_DTM");
/* 332 */       m.put(13L, "PID_LASTSAVE_DTM");
/* 333 */       m.put(14L, "PID_PAGECOUNT");
/* 334 */       m.put(15L, "PID_WORDCOUNT");
/* 335 */       m.put(16L, "PID_CHARCOUNT");
/* 336 */       m.put(17L, "PID_THUMBNAIL");
/* 337 */       m.put(18L, "PID_APPNAME");
/* 338 */       m.put(19L, "PID_SECURITY");
/* 339 */       summaryInformationProperties = new PropertyIDMap(Collections.unmodifiableMap(m));
/*     */     }
/*     */     
/* 342 */     return summaryInformationProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PropertyIDMap getDocumentSummaryInformationProperties()
/*     */   {
/* 355 */     if (documentSummaryInformationProperties == null)
/*     */     {
/* 357 */       PropertyIDMap m = new PropertyIDMap(17, 1.0F);
/* 358 */       m.put(0L, "PID_DICTIONARY");
/* 359 */       m.put(1L, "PID_CODEPAGE");
/* 360 */       m.put(2L, "PID_CATEGORY");
/* 361 */       m.put(3L, "PID_PRESFORMAT");
/* 362 */       m.put(4L, "PID_BYTECOUNT");
/* 363 */       m.put(5L, "PID_LINECOUNT");
/* 364 */       m.put(6L, "PID_PARCOUNT");
/* 365 */       m.put(7L, "PID_SLIDECOUNT");
/* 366 */       m.put(8L, "PID_NOTECOUNT");
/* 367 */       m.put(9L, "PID_HIDDENCOUNT");
/* 368 */       m.put(10L, "PID_MMCLIPCOUNT");
/* 369 */       m.put(11L, "PID_SCALE");
/* 370 */       m.put(12L, "PID_HEADINGPAIR");
/* 371 */       m.put(13L, "PID_DOCPARTS");
/* 372 */       m.put(14L, "PID_MANAGER");
/* 373 */       m.put(15L, "PID_COMPANY");
/* 374 */       m.put(16L, "PID_LINKSDIRTY");
/* 375 */       documentSummaryInformationProperties = new PropertyIDMap(Collections.unmodifiableMap(m));
/*     */     }
/*     */     
/* 378 */     return documentSummaryInformationProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 390 */     PropertyIDMap s1 = getSummaryInformationProperties();
/* 391 */     PropertyIDMap s2 = getDocumentSummaryInformationProperties();
/* 392 */     System.out.println("s1: " + s1);
/* 393 */     System.out.println("s2: " + s2);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\wellknown\PropertyIDMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */