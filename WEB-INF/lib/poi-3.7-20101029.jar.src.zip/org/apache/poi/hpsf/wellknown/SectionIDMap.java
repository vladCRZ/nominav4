/*     */ package org.apache.poi.hpsf.wellknown;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SectionIDMap
/*     */   extends HashMap
/*     */ {
/*  44 */   public static final byte[] SUMMARY_INFORMATION_ID = { -14, -97, -123, -32, 79, -7, 16, 104, -85, -111, 8, 0, 43, 39, -77, -39 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   public static final byte[][] DOCUMENT_SUMMARY_INFORMATION_ID = { { -43, -51, -43, 2, 46, -100, 16, 27, -109, -105, 8, 0, 43, 44, -7, -82 }, { -43, -51, -43, 5, 46, -100, 16, 27, -109, -105, 8, 0, 43, 44, -7, -82 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String UNDEFINED = "[undefined]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static SectionIDMap defaultMap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SectionIDMap getInstance()
/*     */   {
/*  93 */     if (defaultMap == null)
/*     */     {
/*  95 */       SectionIDMap m = new SectionIDMap();
/*  96 */       m.put(SUMMARY_INFORMATION_ID, PropertyIDMap.getSummaryInformationProperties());
/*     */       
/*  98 */       m.put(DOCUMENT_SUMMARY_INFORMATION_ID[0], PropertyIDMap.getDocumentSummaryInformationProperties());
/*     */       
/* 100 */       defaultMap = m;
/*     */     }
/* 102 */     return defaultMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getPIDString(byte[] sectionFormatID, long pid)
/*     */   {
/* 123 */     PropertyIDMap m = getInstance().get(sectionFormatID);
/* 124 */     if (m == null) {
/* 125 */       return "[undefined]";
/*     */     }
/* 127 */     String s = (String)m.get(pid);
/* 128 */     if (s == null)
/* 129 */       return "[undefined]";
/* 130 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyIDMap get(byte[] sectionFormatID)
/*     */   {
/* 144 */     return (PropertyIDMap)super.get(new String(sectionFormatID));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Object get(Object sectionFormatID)
/*     */   {
/* 159 */     return get((byte[])sectionFormatID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(byte[] sectionFormatID, PropertyIDMap propertyIDMap)
/*     */   {
/* 175 */     return super.put(new String(sectionFormatID), propertyIDMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 194 */     return put((byte[])key, (PropertyIDMap)value);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hpsf\wellknown\SectionIDMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */