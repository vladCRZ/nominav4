/*     */ package org.apache.poi.hssf.dev;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.record.BOFRecord;
/*     */ import org.apache.poi.hssf.record.BoundSheetRecord;
/*     */ import org.apache.poi.hssf.record.CFHeaderRecord;
/*     */ import org.apache.poi.hssf.record.DateWindow1904Record;
/*     */ import org.apache.poi.hssf.record.DrawingGroupRecord;
/*     */ import org.apache.poi.hssf.record.EOFRecord;
/*     */ import org.apache.poi.hssf.record.ExtendedFormatRecord;
/*     */ import org.apache.poi.hssf.record.GutsRecord;
/*     */ import org.apache.poi.hssf.record.HorizontalPageBreakRecord;
/*     */ import org.apache.poi.hssf.record.HyperlinkRecord;
/*     */ import org.apache.poi.hssf.record.InterfaceEndRecord;
/*     */ import org.apache.poi.hssf.record.InterfaceHdrRecord;
/*     */ import org.apache.poi.hssf.record.LabelRecord;
/*     */ import org.apache.poi.hssf.record.NameCommentRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.RecordInputStream.LeftoverDataException;
/*     */ import org.apache.poi.hssf.record.RowRecord;
/*     */ import org.apache.poi.hssf.record.SelectionRecord;
/*     */ import org.apache.poi.hssf.record.TabIdRecord;
/*     */ import org.apache.poi.hssf.record.TopMarginRecord;
/*     */ import org.apache.poi.hssf.record.UseSelFSRecord;
/*     */ import org.apache.poi.hssf.record.chart.AxisRecord;
/*     */ import org.apache.poi.hssf.record.chart.AxisUsedRecord;
/*     */ import org.apache.poi.hssf.record.chart.FontIndexRecord;
/*     */ import org.apache.poi.hssf.record.chart.FrameRecord;
/*     */ import org.apache.poi.hssf.record.chart.LinkedDataRecord;
/*     */ import org.apache.poi.hssf.record.chart.ObjectLinkRecord;
/*     */ import org.apache.poi.hssf.record.chart.TextRecord;
/*     */ import org.apache.poi.hssf.record.chart.TickRecord;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ public final class BiffViewer
/*     */ {
/*  49 */   static final char[] NEW_LINE_CHARS = System.getProperty("line.separator").toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int DUMP_LINE_LEN = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Record[] createRecords(InputStream is, PrintStream ps, BiffRecordListener recListener, boolean dumpInterpretedRecords)
/*     */     throws org.apache.poi.hssf.record.RecordFormatException
/*     */   {
/*  64 */     List<Record> temp = new ArrayList();
/*     */     
/*  66 */     RecordInputStream recStream = new RecordInputStream(is);
/*     */     for (;;) {
/*     */       boolean hasNext;
/*     */       try {
/*  70 */         hasNext = recStream.hasNextRecord();
/*     */       } catch (RecordInputStream.LeftoverDataException e) {
/*  72 */         e.printStackTrace();
/*  73 */         System.err.println("Discarding " + recStream.remaining() + " bytes and continuing");
/*  74 */         recStream.readRemainder();
/*  75 */         hasNext = recStream.hasNextRecord();
/*     */       }
/*  77 */       if (!hasNext) {
/*     */         break;
/*     */       }
/*  80 */       recStream.nextRecord();
/*  81 */       if (recStream.getSid() != 0)
/*     */       {
/*     */ 
/*     */ 
/*  85 */         if (dumpInterpretedRecords) {
/*  86 */           Record record = createRecord(recStream);
/*  87 */           if (record.getSid() == 60) {
/*     */             continue;
/*     */           }
/*  90 */           temp.add(record);
/*     */           
/*  92 */           if (dumpInterpretedRecords) {
/*  93 */             String[] headers = recListener.getRecentHeaders();
/*  94 */             for (int i = 0; i < headers.length; i++) {
/*  95 */               ps.println(headers[i]);
/*     */             }
/*  97 */             ps.print(record.toString());
/*     */           }
/*     */         } else {
/* 100 */           recStream.readRemainder();
/*     */         }
/* 102 */         ps.println();
/*     */       } }
/* 104 */     Record[] result = new Record[temp.size()];
/* 105 */     temp.toArray(result);
/* 106 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Record createRecord(RecordInputStream in)
/*     */   {
/* 116 */     switch (in.getSid()) {
/* 117 */     case 4106:  return new org.apache.poi.hssf.record.chart.AreaFormatRecord(in);
/* 118 */     case 4122:  return new org.apache.poi.hssf.record.chart.AreaRecord(in);
/* 119 */     case 545:  return new org.apache.poi.hssf.record.ArrayRecord(in);
/* 120 */     case 4129:  return new org.apache.poi.hssf.record.chart.AxisLineFormatRecord(in);
/* 121 */     case 4194:  return new org.apache.poi.hssf.record.chart.AxisOptionsRecord(in);
/* 122 */     case 4161:  return new org.apache.poi.hssf.record.chart.AxisParentRecord(in);
/* 123 */     case 4125:  return new AxisRecord(in);
/* 124 */     case 4166:  return new AxisUsedRecord(in);
/* 125 */     case 157:  return new org.apache.poi.hssf.record.AutoFilterInfoRecord(in);
/* 126 */     case 2057:  return new BOFRecord(in);
/* 127 */     case 64:  return new org.apache.poi.hssf.record.BackupRecord(in);
/* 128 */     case 4119:  return new org.apache.poi.hssf.record.chart.BarRecord(in);
/* 129 */     case 4147:  return new org.apache.poi.hssf.record.chart.BeginRecord(in);
/* 130 */     case 513:  return new org.apache.poi.hssf.record.BlankRecord(in);
/* 131 */     case 218:  return new org.apache.poi.hssf.record.BookBoolRecord(in);
/* 132 */     case 517:  return new org.apache.poi.hssf.record.BoolErrRecord(in);
/* 133 */     case 41:  return new org.apache.poi.hssf.record.BottomMarginRecord(in);
/* 134 */     case 133:  return new BoundSheetRecord(in);
/* 135 */     case 432:  return new CFHeaderRecord(in);
/* 136 */     case 433:  return new org.apache.poi.hssf.record.CFRuleRecord(in);
/* 137 */     case 12:  return new org.apache.poi.hssf.record.CalcCountRecord(in);
/* 138 */     case 13:  return new org.apache.poi.hssf.record.CalcModeRecord(in);
/* 139 */     case 4128:  return new org.apache.poi.hssf.record.chart.CategorySeriesAxisRecord(in);
/* 140 */     case 4116:  return new org.apache.poi.hssf.record.chart.ChartFormatRecord(in);
/* 141 */     case 4098:  return new org.apache.poi.hssf.record.chart.ChartRecord(in);
/* 142 */     case 66:  return new org.apache.poi.hssf.record.CodepageRecord(in);
/* 143 */     case 125:  return new org.apache.poi.hssf.record.ColumnInfoRecord(in);
/* 144 */     case 60:  return new org.apache.poi.hssf.record.ContinueRecord(in);
/* 145 */     case 140:  return new org.apache.poi.hssf.record.CountryRecord(in);
/* 146 */     case 215:  return new org.apache.poi.hssf.record.DBCellRecord(in);
/* 147 */     case 353:  return new org.apache.poi.hssf.record.DSFRecord(in);
/* 148 */     case 4195:  return new org.apache.poi.hssf.record.chart.DatRecord(in);
/* 149 */     case 4102:  return new org.apache.poi.hssf.record.chart.DataFormatRecord(in);
/* 150 */     case 34:  return new DateWindow1904Record(in);
/* 151 */     case 85:  return new org.apache.poi.hssf.record.DefaultColWidthRecord(in);
/* 152 */     case 4132:  return new org.apache.poi.hssf.record.chart.DefaultDataLabelTextPropertiesRecord(in);
/* 153 */     case 549:  return new org.apache.poi.hssf.record.DefaultRowHeightRecord(in);
/* 154 */     case 16:  return new org.apache.poi.hssf.record.DeltaRecord(in);
/* 155 */     case 512:  return new org.apache.poi.hssf.record.DimensionsRecord(in);
/* 156 */     case 235:  return new DrawingGroupRecord(in);
/* 157 */     case 236:  return new org.apache.poi.hssf.record.DrawingRecordForBiffViewer(in);
/* 158 */     case 237:  return new org.apache.poi.hssf.record.DrawingSelectionRecord(in);
/* 159 */     case 446:  return new org.apache.poi.hssf.record.DVRecord(in);
/* 160 */     case 434:  return new org.apache.poi.hssf.record.DVALRecord(in);
/* 161 */     case 10:  return new EOFRecord(in);
/* 162 */     case 4148:  return new org.apache.poi.hssf.record.chart.EndRecord(in);
/* 163 */     case 255:  return new org.apache.poi.hssf.record.ExtSSTRecord(in);
/* 164 */     case 224:  return new ExtendedFormatRecord(in);
/* 165 */     case 23:  return new org.apache.poi.hssf.record.ExternSheetRecord(in);
/* 166 */     case 35:  return new org.apache.poi.hssf.record.ExternalNameRecord(in);
/* 167 */     case 2152:  return new org.apache.poi.hssf.record.FeatRecord(in);
/* 168 */     case 2151:  return new org.apache.poi.hssf.record.FeatHdrRecord(in);
/* 169 */     case 47:  return new org.apache.poi.hssf.record.FilePassRecord(in);
/* 170 */     case 91:  return new org.apache.poi.hssf.record.FileSharingRecord(in);
/* 171 */     case 156:  return new org.apache.poi.hssf.record.FnGroupCountRecord(in);
/* 172 */     case 4192:  return new org.apache.poi.hssf.record.chart.FontBasisRecord(in);
/* 173 */     case 4134:  return new FontIndexRecord(in);
/* 174 */     case 49:  return new org.apache.poi.hssf.record.FontRecord(in);
/* 175 */     case 21:  return new org.apache.poi.hssf.record.FooterRecord(in);
/* 176 */     case 1054:  return new org.apache.poi.hssf.record.FormatRecord(in);
/* 177 */     case 6:  return new org.apache.poi.hssf.record.FormulaRecord(in);
/* 178 */     case 4146:  return new FrameRecord(in);
/* 179 */     case 130:  return new org.apache.poi.hssf.record.GridsetRecord(in);
/* 180 */     case 128:  return new GutsRecord(in);
/* 181 */     case 131:  return new org.apache.poi.hssf.record.HCenterRecord(in);
/* 182 */     case 20:  return new org.apache.poi.hssf.record.HeaderRecord(in);
/* 183 */     case 141:  return new org.apache.poi.hssf.record.HideObjRecord(in);
/* 184 */     case 27:  return new HorizontalPageBreakRecord(in);
/* 185 */     case 440:  return new HyperlinkRecord(in);
/* 186 */     case 523:  return new org.apache.poi.hssf.record.IndexRecord(in);
/* 187 */     case 226:  return InterfaceEndRecord.create(in);
/* 188 */     case 225:  return new InterfaceHdrRecord(in);
/* 189 */     case 17:  return new org.apache.poi.hssf.record.IterationRecord(in);
/* 190 */     case 516:  return new LabelRecord(in);
/* 191 */     case 253:  return new org.apache.poi.hssf.record.LabelSSTRecord(in);
/* 192 */     case 38:  return new org.apache.poi.hssf.record.LeftMarginRecord(in);
/* 193 */     case 4117:  return new org.apache.poi.hssf.record.chart.LegendRecord(in);
/* 194 */     case 4103:  return new org.apache.poi.hssf.record.chart.LineFormatRecord(in);
/* 195 */     case 4177:  return new LinkedDataRecord(in);
/* 196 */     case 193:  return new org.apache.poi.hssf.record.MMSRecord(in);
/* 197 */     case 229:  return new org.apache.poi.hssf.record.MergeCellsRecord(in);
/* 198 */     case 190:  return new org.apache.poi.hssf.record.MulBlankRecord(in);
/* 199 */     case 189:  return new org.apache.poi.hssf.record.MulRKRecord(in);
/* 200 */     case 24:  return new org.apache.poi.hssf.record.NameRecord(in);
/* 201 */     case 2196:  return new NameCommentRecord(in);
/* 202 */     case 28:  return new org.apache.poi.hssf.record.NoteRecord(in);
/* 203 */     case 515:  return new org.apache.poi.hssf.record.NumberRecord(in);
/* 204 */     case 93:  return new ObjRecord(in);
/* 205 */     case 4135:  return new ObjectLinkRecord(in);
/* 206 */     case 146:  return new org.apache.poi.hssf.record.PaletteRecord(in);
/* 207 */     case 65:  return new org.apache.poi.hssf.record.PaneRecord(in);
/* 208 */     case 19:  return new org.apache.poi.hssf.record.PasswordRecord(in);
/* 209 */     case 444:  return new org.apache.poi.hssf.record.PasswordRev4Record(in);
/* 210 */     case 4149:  return new org.apache.poi.hssf.record.chart.PlotAreaRecord(in);
/* 211 */     case 4196:  return new org.apache.poi.hssf.record.chart.PlotGrowthRecord(in);
/* 212 */     case 14:  return new org.apache.poi.hssf.record.PrecisionRecord(in);
/* 213 */     case 43:  return new org.apache.poi.hssf.record.PrintGridlinesRecord(in);
/* 214 */     case 42:  return new org.apache.poi.hssf.record.PrintHeadersRecord(in);
/* 215 */     case 161:  return new org.apache.poi.hssf.record.PrintSetupRecord(in);
/* 216 */     case 18:  return new org.apache.poi.hssf.record.ProtectRecord(in);
/* 217 */     case 431:  return new org.apache.poi.hssf.record.ProtectionRev4Record(in);
/* 218 */     case 638:  return new org.apache.poi.hssf.record.RKRecord(in);
/* 219 */     case 449:  return new org.apache.poi.hssf.record.RecalcIdRecord(in);
/* 220 */     case 15:  return new org.apache.poi.hssf.record.RefModeRecord(in);
/* 221 */     case 439:  return new org.apache.poi.hssf.record.RefreshAllRecord(in);
/* 222 */     case 39:  return new org.apache.poi.hssf.record.RightMarginRecord(in);
/* 223 */     case 520:  return new RowRecord(in);
/* 224 */     case 160:  return new org.apache.poi.hssf.record.SCLRecord(in);
/* 225 */     case 252:  return new org.apache.poi.hssf.record.SSTRecord(in);
/* 226 */     case 95:  return new org.apache.poi.hssf.record.SaveRecalcRecord(in);
/* 227 */     case 29:  return new SelectionRecord(in);
/* 228 */     case 4197:  return new org.apache.poi.hssf.record.chart.SeriesIndexRecord(in);
/* 229 */     case 4118:  return new org.apache.poi.hssf.record.chart.SeriesListRecord(in);
/* 230 */     case 4099:  return new org.apache.poi.hssf.record.chart.SeriesRecord(in);
/* 231 */     case 4109:  return new org.apache.poi.hssf.record.chart.SeriesTextRecord(in);
/* 232 */     case 4165:  return new org.apache.poi.hssf.record.chart.SeriesToChartGroupRecord(in);
/* 233 */     case 1212:  return new org.apache.poi.hssf.record.SharedFormulaRecord(in);
/* 234 */     case 4164:  return new org.apache.poi.hssf.record.chart.SheetPropertiesRecord(in);
/* 235 */     case 519:  return new org.apache.poi.hssf.record.StringRecord(in);
/* 236 */     case 659:  return new org.apache.poi.hssf.record.StyleRecord(in);
/* 237 */     case 430:  return new org.apache.poi.hssf.record.SupBookRecord(in);
/* 238 */     case 317:  return new TabIdRecord(in);
/* 239 */     case 2190:  return new org.apache.poi.hssf.record.TableStylesRecord(in);
/* 240 */     case 566:  return new org.apache.poi.hssf.record.TableRecord(in);
/* 241 */     case 438:  return new org.apache.poi.hssf.record.TextObjectRecord(in);
/* 242 */     case 4133:  return new TextRecord(in);
/* 243 */     case 4126:  return new TickRecord(in);
/* 244 */     case 40:  return new TopMarginRecord(in);
/* 245 */     case 4097:  return new org.apache.poi.hssf.record.chart.UnitsRecord(in);
/* 246 */     case 352:  return new UseSelFSRecord(in);
/* 247 */     case 132:  return new org.apache.poi.hssf.record.VCenterRecord(in);
/* 248 */     case 4127:  return new org.apache.poi.hssf.record.chart.ValueRangeRecord(in);
/* 249 */     case 26:  return new org.apache.poi.hssf.record.VerticalPageBreakRecord(in);
/* 250 */     case 129:  return new org.apache.poi.hssf.record.WSBoolRecord(in);
/* 251 */     case 61:  return new org.apache.poi.hssf.record.WindowOneRecord(in);
/* 252 */     case 25:  return new org.apache.poi.hssf.record.WindowProtectRecord(in);
/* 253 */     case 574:  return new org.apache.poi.hssf.record.WindowTwoRecord(in);
/* 254 */     case 92:  return new org.apache.poi.hssf.record.WriteAccessRecord(in);
/* 255 */     case 134:  return new org.apache.poi.hssf.record.WriteProtectRecord(in);
/*     */     
/*     */     case 2134: 
/* 258 */       return new org.apache.poi.hssf.record.chart.CatLabRecord(in);
/* 259 */     case 2131:  return new org.apache.poi.hssf.record.chart.ChartEndBlockRecord(in);
/* 260 */     case 2133:  return new org.apache.poi.hssf.record.chart.ChartEndObjectRecord(in);
/* 261 */     case 2128:  return new org.apache.poi.hssf.record.chart.ChartFRTInfoRecord(in);
/* 262 */     case 2130:  return new org.apache.poi.hssf.record.chart.ChartStartBlockRecord(in);
/* 263 */     case 2132:  return new org.apache.poi.hssf.record.chart.ChartStartObjectRecord(in);
/*     */     
/*     */     case 213: 
/* 266 */       return new org.apache.poi.hssf.record.pivottable.StreamIDRecord(in);
/* 267 */     case 227:  return new org.apache.poi.hssf.record.pivottable.ViewSourceRecord(in);
/* 268 */     case 182:  return new org.apache.poi.hssf.record.pivottable.PageItemRecord(in);
/* 269 */     case 176:  return new org.apache.poi.hssf.record.pivottable.ViewDefinitionRecord(in);
/* 270 */     case 177:  return new org.apache.poi.hssf.record.pivottable.ViewFieldsRecord(in);
/* 271 */     case 197:  return new org.apache.poi.hssf.record.pivottable.DataItemRecord(in);
/* 272 */     case 256:  return new org.apache.poi.hssf.record.pivottable.ExtendedPivotTableViewFieldsRecord(in);
/*     */     }
/* 274 */     return new org.apache.poi.hssf.record.UnknownRecord(in);
/*     */   }
/*     */   
/*     */   private static final class CommandArgs
/*     */   {
/*     */     private final boolean _biffhex;
/*     */     private final boolean _noint;
/*     */     private final boolean _out;
/*     */     private final boolean _rawhex;
/*     */     private final boolean _noHeader;
/*     */     private final File _file;
/*     */     
/*     */     private CommandArgs(boolean biffhex, boolean noint, boolean out, boolean rawhex, boolean noHeader, File file) {
/* 287 */       this._biffhex = biffhex;
/* 288 */       this._noint = noint;
/* 289 */       this._out = out;
/* 290 */       this._rawhex = rawhex;
/* 291 */       this._file = file;
/* 292 */       this._noHeader = noHeader;
/*     */     }
/*     */     
/*     */     public static CommandArgs parse(String[] args) throws BiffViewer.CommandParseException {
/* 296 */       int nArgs = args.length;
/* 297 */       boolean biffhex = false;
/* 298 */       boolean noint = false;
/* 299 */       boolean out = false;
/* 300 */       boolean rawhex = false;
/* 301 */       boolean noheader = false;
/* 302 */       File file = null;
/* 303 */       for (int i = 0; i < nArgs; i++) {
/* 304 */         String arg = args[i];
/* 305 */         if (arg.startsWith("--")) {
/* 306 */           if ("--biffhex".equals(arg)) {
/* 307 */             biffhex = true;
/* 308 */           } else if ("--noint".equals(arg)) {
/* 309 */             noint = true;
/* 310 */           } else if ("--out".equals(arg)) {
/* 311 */             out = true;
/* 312 */           } else if ("--escher".equals(arg)) {
/* 313 */             System.setProperty("poi.deserialize.escher", "true");
/* 314 */           } else if ("--rawhex".equals(arg)) {
/* 315 */             rawhex = true;
/* 316 */           } else if ("--noheader".equals(arg)) {
/* 317 */             noheader = true;
/*     */           } else {
/* 319 */             throw new BiffViewer.CommandParseException("Unexpected option '" + arg + "'");
/*     */           }
/*     */         }
/*     */         else {
/* 323 */           file = new File(arg);
/* 324 */           if (!file.exists()) {
/* 325 */             throw new BiffViewer.CommandParseException("Specified file '" + arg + "' does not exist");
/*     */           }
/* 327 */           if (i + 1 < nArgs)
/* 328 */             throw new BiffViewer.CommandParseException("File name must be the last arg");
/*     */         }
/*     */       }
/* 331 */       if (file == null) {
/* 332 */         throw new BiffViewer.CommandParseException("Biff viewer needs a filename");
/*     */       }
/* 334 */       return new CommandArgs(biffhex, noint, out, rawhex, noheader, file);
/*     */     }
/*     */     
/* 337 */     public boolean shouldDumpBiffHex() { return this._biffhex; }
/*     */     
/*     */     public boolean shouldDumpRecordInterpretations() {
/* 340 */       return !this._noint;
/*     */     }
/*     */     
/* 343 */     public boolean shouldOutputToFile() { return this._out; }
/*     */     
/*     */     public boolean shouldOutputRawHexOnly() {
/* 346 */       return this._rawhex;
/*     */     }
/*     */     
/* 349 */     public boolean suppressHeader() { return this._noHeader; }
/*     */     
/*     */     public File getFile() {
/* 352 */       return this._file;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CommandParseException extends Exception {
/* 357 */     public CommandParseException(String msg) { super(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     CommandArgs cmdArgs;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 385 */       cmdArgs = CommandArgs.parse(args);
/*     */     } catch (CommandParseException e) {
/* 387 */       e.printStackTrace();
/* 388 */       return;
/*     */     }
/*     */     try
/*     */     {
/*     */       PrintStream ps;
/*     */       PrintStream ps;
/* 394 */       if (cmdArgs.shouldOutputToFile()) {
/* 395 */         java.io.OutputStream os = new java.io.FileOutputStream(cmdArgs.getFile().getAbsolutePath() + ".out");
/* 396 */         ps = new PrintStream(os);
/*     */       } else {
/* 398 */         ps = System.out;
/*     */       }
/*     */       
/* 401 */       POIFSFileSystem fs = new POIFSFileSystem(new java.io.FileInputStream(cmdArgs.getFile()));
/* 402 */       InputStream is = fs.createDocumentInputStream("Workbook");
/*     */       
/* 404 */       if (cmdArgs.shouldOutputRawHexOnly()) {
/* 405 */         int size = is.available();
/* 406 */         byte[] data = new byte[size];
/*     */         
/* 408 */         is.read(data);
/* 409 */         HexDump.dump(data, 0L, System.out, 0);
/*     */       } else {
/* 411 */         boolean dumpInterpretedRecords = cmdArgs.shouldDumpRecordInterpretations();
/* 412 */         boolean dumpHex = cmdArgs.shouldDumpBiffHex();
/* 413 */         boolean zeroAlignHexDump = dumpInterpretedRecords;
/* 414 */         BiffRecordListener recListener = new BiffRecordListener(dumpHex ? new OutputStreamWriter(ps) : null, zeroAlignHexDump, cmdArgs.suppressHeader());
/* 415 */         is = new BiffDumpingStream(is, recListener);
/* 416 */         createRecords(is, ps, recListener, dumpInterpretedRecords);
/*     */       }
/* 418 */       ps.close();
/*     */     } catch (Exception e) {
/* 420 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class BiffRecordListener implements BiffViewer.IBiffRecordListener {
/*     */     private final Writer _hexDumpWriter;
/*     */     private final List<String> _headers;
/*     */     private final boolean _zeroAlignEachRecord;
/*     */     private final boolean _noHeader;
/*     */     
/* 430 */     public BiffRecordListener(Writer hexDumpWriter, boolean zeroAlignEachRecord, boolean noHeader) { this._hexDumpWriter = hexDumpWriter;
/* 431 */       this._zeroAlignEachRecord = zeroAlignEachRecord;
/* 432 */       this._noHeader = noHeader;
/* 433 */       this._headers = new ArrayList();
/*     */     }
/*     */     
/*     */     public void processRecord(int globalOffset, int recordCounter, int sid, int dataSize, byte[] data)
/*     */     {
/* 438 */       String header = formatRecordDetails(globalOffset, sid, dataSize, recordCounter);
/* 439 */       if (!this._noHeader) this._headers.add(header);
/* 440 */       Writer w = this._hexDumpWriter;
/* 441 */       if (w != null)
/*     */         try {
/* 443 */           w.write(header);
/* 444 */           w.write(BiffViewer.NEW_LINE_CHARS);
/* 445 */           BiffViewer.hexDumpAligned(w, data, dataSize + 4, globalOffset, this._zeroAlignEachRecord);
/* 446 */           w.flush();
/*     */         } catch (IOException e) {
/* 448 */           throw new RuntimeException(e);
/*     */         }
/*     */     }
/*     */     
/*     */     public String[] getRecentHeaders() {
/* 453 */       String[] result = new String[this._headers.size()];
/* 454 */       this._headers.toArray(result);
/* 455 */       this._headers.clear();
/* 456 */       return result;
/*     */     }
/*     */     
/* 459 */     private static String formatRecordDetails(int globalOffset, int sid, int size, int recordCounter) { StringBuffer sb = new StringBuffer(64);
/* 460 */       sb.append("Offset=").append(HexDump.intToHex(globalOffset)).append("(").append(globalOffset).append(")");
/* 461 */       sb.append(" recno=").append(recordCounter);
/* 462 */       sb.append(" sid=").append(HexDump.shortToHex(sid));
/* 463 */       sb.append(" size=").append(HexDump.shortToHex(size)).append("(").append(size).append(")");
/* 464 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static abstract interface IBiffRecordListener
/*     */   {
/*     */     public abstract void processRecord(int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfByte);
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class BiffDumpingStream
/*     */     extends InputStream
/*     */   {
/*     */     private final DataInputStream _is;
/*     */     private final BiffViewer.IBiffRecordListener _listener;
/*     */     private final byte[] _data;
/*     */     private int _recordCounter;
/*     */     private int _overallStreamPos;
/*     */     private int _currentPos;
/*     */     private int _currentSize;
/*     */     private boolean _innerHasReachedEOF;
/*     */     
/*     */     public BiffDumpingStream(InputStream is, BiffViewer.IBiffRecordListener listener)
/*     */     {
/* 489 */       this._is = new DataInputStream(is);
/* 490 */       this._listener = listener;
/* 491 */       this._data = new byte['․'];
/* 492 */       this._recordCounter = 0;
/* 493 */       this._overallStreamPos = 0;
/* 494 */       this._currentSize = 0;
/* 495 */       this._currentPos = 0;
/*     */     }
/*     */     
/*     */     public int read() throws IOException {
/* 499 */       if (this._currentPos >= this._currentSize) {
/* 500 */         fillNextBuffer();
/*     */       }
/* 502 */       if (this._currentPos >= this._currentSize) {
/* 503 */         return -1;
/*     */       }
/* 505 */       int result = this._data[this._currentPos] & 0xFF;
/* 506 */       this._currentPos += 1;
/* 507 */       this._overallStreamPos += 1;
/* 508 */       formatBufferIfAtEndOfRec();
/* 509 */       return result;
/*     */     }
/*     */     
/* 512 */     public int read(byte[] b, int off, int len) throws IOException { if (this._currentPos >= this._currentSize) {
/* 513 */         fillNextBuffer();
/*     */       }
/* 515 */       if (this._currentPos >= this._currentSize) {
/* 516 */         return -1;
/*     */       }
/* 518 */       int availSize = this._currentSize - this._currentPos;
/*     */       int result;
/* 520 */       int result; if (len > availSize) {
/* 521 */         System.err.println("Unexpected request to read past end of current biff record");
/* 522 */         result = availSize;
/*     */       } else {
/* 524 */         result = len;
/*     */       }
/* 526 */       System.arraycopy(this._data, this._currentPos, b, off, result);
/* 527 */       this._currentPos += result;
/* 528 */       this._overallStreamPos += result;
/* 529 */       formatBufferIfAtEndOfRec();
/* 530 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 534 */     public int available() throws IOException { return this._currentSize - this._currentPos + this._is.available(); }
/*     */     
/*     */     private void fillNextBuffer() throws IOException {
/* 537 */       if (this._innerHasReachedEOF) {
/* 538 */         return;
/*     */       }
/* 540 */       int b0 = this._is.read();
/* 541 */       if (b0 == -1) {
/* 542 */         this._innerHasReachedEOF = true;
/* 543 */         return;
/*     */       }
/* 545 */       this._data[0] = ((byte)b0);
/* 546 */       this._is.readFully(this._data, 1, 3);
/* 547 */       int len = LittleEndian.getShort(this._data, 2);
/* 548 */       this._is.readFully(this._data, 4, len);
/* 549 */       this._currentPos = 0;
/* 550 */       this._currentSize = (len + 4);
/* 551 */       this._recordCounter += 1;
/*     */     }
/*     */     
/* 554 */     private void formatBufferIfAtEndOfRec() { if (this._currentPos != this._currentSize) {
/* 555 */         return;
/*     */       }
/* 557 */       int dataSize = this._currentSize - 4;
/* 558 */       int sid = LittleEndian.getShort(this._data, 0);
/* 559 */       int globalOffset = this._overallStreamPos - this._currentSize;
/* 560 */       this._listener.processRecord(globalOffset, this._recordCounter, sid, dataSize, this._data);
/*     */     }
/*     */     
/* 563 */     public void close() throws IOException { this._is.close(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 568 */   private static final char[] COLUMN_SEPARATOR = " | ".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void hexDumpAligned(Writer w, byte[] data, int dumpLen, int globalOffset, boolean zeroAlignEachRecord)
/*     */   {
/* 576 */     int baseDataOffset = 0;
/*     */     
/*     */ 
/* 579 */     int globalStart = globalOffset + baseDataOffset;
/* 580 */     int globalEnd = globalOffset + baseDataOffset + dumpLen;
/* 581 */     int startDelta = globalStart % 16;
/* 582 */     int endDelta = globalEnd % 16;
/* 583 */     if (zeroAlignEachRecord) {
/* 584 */       endDelta -= startDelta;
/* 585 */       if (endDelta < 0) {
/* 586 */         endDelta += 16;
/*     */       }
/* 588 */       startDelta = 0; }
/*     */     int startLineAddr;
/*     */     int startLineAddr;
/*     */     int endLineAddr;
/* 592 */     if (zeroAlignEachRecord) {
/* 593 */       int endLineAddr = globalEnd - endDelta - (globalStart - startDelta);
/* 594 */       startLineAddr = 0;
/*     */     } else {
/* 596 */       startLineAddr = globalStart - startDelta;
/* 597 */       endLineAddr = globalEnd - endDelta;
/*     */     }
/*     */     
/* 600 */     int lineDataOffset = baseDataOffset - startDelta;
/* 601 */     int lineAddr = startLineAddr;
/*     */     
/*     */ 
/* 604 */     if (startLineAddr == endLineAddr) {
/* 605 */       hexDumpLine(w, data, lineAddr, lineDataOffset, startDelta, endDelta);
/* 606 */       return;
/*     */     }
/* 608 */     hexDumpLine(w, data, lineAddr, lineDataOffset, startDelta, 16);
/*     */     
/*     */     for (;;)
/*     */     {
/* 612 */       lineAddr += 16;
/* 613 */       lineDataOffset += 16;
/* 614 */       if (lineAddr >= endLineAddr) {
/*     */         break;
/*     */       }
/* 617 */       hexDumpLine(w, data, lineAddr, lineDataOffset, 0, 16);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 622 */     if (endDelta != 0) {
/* 623 */       hexDumpLine(w, data, lineAddr, lineDataOffset, 0, endDelta);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void hexDumpLine(Writer w, byte[] data, int lineStartAddress, int lineDataOffset, int startDelta, int endDelta) {
/* 628 */     if (startDelta >= endDelta) {
/* 629 */       throw new IllegalArgumentException("Bad start/end delta");
/*     */     }
/*     */     try {
/* 632 */       writeHex(w, lineStartAddress, 8);
/* 633 */       w.write(COLUMN_SEPARATOR);
/*     */       
/* 635 */       for (int i = 0; i < 16; i++) {
/* 636 */         if (i > 0) {
/* 637 */           w.write(" ");
/*     */         }
/* 639 */         if ((i >= startDelta) && (i < endDelta)) {
/* 640 */           writeHex(w, data[(lineDataOffset + i)], 2);
/*     */         } else {
/* 642 */           w.write("  ");
/*     */         }
/*     */       }
/* 645 */       w.write(COLUMN_SEPARATOR);
/*     */       
/*     */ 
/* 648 */       for (int i = 0; i < 16; i++) {
/* 649 */         if ((i >= startDelta) && (i < endDelta)) {
/* 650 */           w.write(getPrintableChar(data[(lineDataOffset + i)]));
/*     */         } else {
/* 652 */           w.write(" ");
/*     */         }
/*     */       }
/* 655 */       w.write(NEW_LINE_CHARS);
/*     */     } catch (IOException e) {
/* 657 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static char getPrintableChar(byte b) {
/* 662 */     char ib = (char)(b & 0xFF);
/* 663 */     if ((ib < ' ') || (ib > '~')) {
/* 664 */       return '.';
/*     */     }
/* 666 */     return ib;
/*     */   }
/*     */   
/*     */   private static void writeHex(Writer w, int value, int nDigits) throws IOException {
/* 670 */     char[] buf = new char[nDigits];
/* 671 */     int acc = value;
/* 672 */     for (int i = nDigits - 1; i >= 0; i--) {
/* 673 */       int digit = acc & 0xF;
/* 674 */       buf[i] = ((char)(digit < 10 ? 48 + digit : 65 + digit - 10));
/* 675 */       acc >>= 4;
/*     */     }
/* 677 */     w.write(buf);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\dev\BiffViewer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */