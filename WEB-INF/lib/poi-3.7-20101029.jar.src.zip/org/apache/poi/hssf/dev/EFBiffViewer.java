/*    */ package org.apache.poi.hssf.dev;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.poi.hssf.eventusermodel.HSSFEventFactory;
/*    */ import org.apache.poi.hssf.eventusermodel.HSSFListener;
/*    */ import org.apache.poi.hssf.eventusermodel.HSSFRequest;
/*    */ import org.apache.poi.hssf.record.Record;
/*    */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EFBiffViewer
/*    */ {
/*    */   String file;
/*    */   
/*    */   public void run()
/*    */     throws IOException
/*    */   {
/* 49 */     FileInputStream fin = new FileInputStream(this.file);
/* 50 */     POIFSFileSystem poifs = new POIFSFileSystem(fin);
/* 51 */     InputStream din = poifs.createDocumentInputStream("Workbook");
/* 52 */     HSSFRequest req = new HSSFRequest();
/*    */     
/* 54 */     req.addListenerForAllRecords(new HSSFListener()
/*    */     {
/*    */       public void processRecord(Record rec)
/*    */       {
/* 58 */         System.out.println(rec.toString());
/*    */       }
/* 60 */     });
/* 61 */     HSSFEventFactory factory = new HSSFEventFactory();
/*    */     
/* 63 */     factory.processEvents(req, din);
/*    */   }
/*    */   
/*    */   public void setFile(String file)
/*    */   {
/* 68 */     this.file = file;
/*    */   }
/*    */   
/*    */   public static void main(String[] args)
/*    */   {
/* 73 */     if ((args.length == 1) && (!args[0].equals("--help")))
/*    */     {
/*    */       try
/*    */       {
/* 77 */         EFBiffViewer viewer = new EFBiffViewer();
/*    */         
/* 79 */         viewer.setFile(args[0]);
/* 80 */         viewer.run();
/*    */       }
/*    */       catch (IOException e)
/*    */       {
/* 84 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 89 */       System.out.println("EFBiffViewer");
/* 90 */       System.out.println("Outputs biffview of records based on HSSFEventFactory");
/*    */       
/* 92 */       System.out.println("usage: java org.apache.poi.hssf.dev.EBBiffViewer filename");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\dev\EFBiffViewer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */