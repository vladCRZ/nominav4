/*     */ package org.apache.poi.hssf.dev;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.HSSFFormulaParser;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFactory;
/*     */ import org.apache.poi.hssf.record.formula.ExpPtg;
/*     */ import org.apache.poi.hssf.record.formula.FuncPtg;
/*     */ import org.apache.poi.hssf.record.formula.OperationPtg;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormulaViewer
/*     */ {
/*     */   private String file;
/*  44 */   private boolean list = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */     throws Exception
/*     */   {
/*  63 */     POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(this.file));
/*     */     
/*  65 */     List<Record> records = RecordFactory.createRecords(fs.createDocumentInputStream("Workbook"));
/*     */     
/*     */ 
/*     */ 
/*  69 */     for (int k = 0; k < records.size(); k++)
/*     */     {
/*  71 */       Record record = (Record)records.get(k);
/*     */       
/*  73 */       if (record.getSid() == 6)
/*     */       {
/*  75 */         if (this.list) {
/*  76 */           listFormula((FormulaRecord)record);
/*     */         } else {
/*  78 */           parseFormulaRecord((FormulaRecord)record);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void listFormula(FormulaRecord record) {
/*  85 */     String sep = "~";
/*  86 */     Ptg[] tokens = record.getParsedExpression();
/*     */     
/*  88 */     int numptgs = tokens.length;
/*     */     
/*  90 */     Ptg token = tokens[(numptgs - 1)];
/*  91 */     String numArg; String numArg; if ((token instanceof FuncPtg)) {
/*  92 */       numArg = String.valueOf(numptgs - 1);
/*     */     } else {
/*  94 */       numArg = String.valueOf(-1);
/*     */     }
/*     */     
/*  97 */     StringBuffer buf = new StringBuffer();
/*     */     
/*  99 */     if ((token instanceof ExpPtg)) return;
/* 100 */     buf.append(((OperationPtg)token).toFormulaString());
/* 101 */     buf.append(sep);
/* 102 */     switch (token.getPtgClass()) {
/*     */     case 0: 
/* 104 */       buf.append("REF");
/* 105 */       break;
/*     */     case 32: 
/* 107 */       buf.append("VALUE");
/* 108 */       break;
/*     */     case 64: 
/* 110 */       buf.append("ARRAY");
/*     */     }
/*     */     
/*     */     
/* 114 */     buf.append(sep);
/* 115 */     if (numptgs > 1) {
/* 116 */       token = tokens[(numptgs - 2)];
/* 117 */       switch (token.getPtgClass()) {
/*     */       case 0: 
/* 119 */         buf.append("REF");
/* 120 */         break;
/*     */       case 32: 
/* 122 */         buf.append("VALUE");
/* 123 */         break;
/*     */       case 64: 
/* 125 */         buf.append("ARRAY");
/*     */       }
/*     */     }
/*     */     else {
/* 129 */       buf.append("VALUE");
/*     */     }
/* 131 */     buf.append(sep);
/* 132 */     buf.append(numArg);
/* 133 */     System.out.println(buf.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFormulaRecord(FormulaRecord record)
/*     */   {
/* 146 */     System.out.println("==============================");
/* 147 */     System.out.print("row = " + record.getRow());
/* 148 */     System.out.println(", col = " + record.getColumn());
/* 149 */     System.out.println("value = " + record.getValue());
/* 150 */     System.out.print("xf = " + record.getXFIndex());
/* 151 */     System.out.print(", number of ptgs = " + record.getParsedExpression().length);
/*     */     
/* 153 */     System.out.println(", options = " + record.getOptions());
/* 154 */     System.out.println("RPN List = " + formulaString(record));
/* 155 */     System.out.println("Formula text = " + composeFormula(record));
/*     */   }
/*     */   
/*     */   private String formulaString(FormulaRecord record)
/*     */   {
/* 160 */     StringBuffer buf = new StringBuffer();
/* 161 */     Ptg[] tokens = record.getParsedExpression();
/* 162 */     for (int i = 0; i < tokens.length; i++) {
/* 163 */       Ptg token = tokens[i];
/* 164 */       buf.append(token.toFormulaString());
/* 165 */       switch (token.getPtgClass()) {
/*     */       case 0: 
/* 167 */         buf.append("(R)");
/* 168 */         break;
/*     */       case 32: 
/* 170 */         buf.append("(V)");
/* 171 */         break;
/*     */       case 64: 
/* 173 */         buf.append("(A)");
/*     */       }
/*     */       
/* 176 */       buf.append(' ');
/*     */     }
/* 178 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   private static String composeFormula(FormulaRecord record)
/*     */   {
/* 184 */     return HSSFFormulaParser.toFormulaString((HSSFWorkbook)null, record.getParsedExpression());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFile(String file)
/*     */   {
/* 197 */     this.file = file;
/*     */   }
/*     */   
/*     */   public void setList(boolean list) {
/* 201 */     this.list = list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 215 */     if ((args == null) || (args.length > 2) || (args[0].equals("--help")))
/*     */     {
/*     */ 
/* 218 */       System.out.println("FormulaViewer .8 proof that the devil lies in the details (or just in BIFF8 files in general)");
/*     */       
/* 220 */       System.out.println("usage: Give me a big fat file name");
/* 221 */     } else if (args[0].equals("--listFunctions")) {
/*     */       try {
/* 223 */         FormulaViewer viewer = new FormulaViewer();
/* 224 */         viewer.setFile(args[1]);
/* 225 */         viewer.setList(true);
/* 226 */         viewer.run();
/*     */       }
/*     */       catch (Exception e) {
/* 229 */         System.out.println("Whoops!");
/* 230 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 237 */         FormulaViewer viewer = new FormulaViewer();
/*     */         
/* 239 */         viewer.setFile(args[0]);
/* 240 */         viewer.run();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 244 */         System.out.println("Whoops!");
/* 245 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\dev\FormulaViewer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */