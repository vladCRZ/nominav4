/*     */ package org.apache.poi.hssf.dev;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFactory;
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordLister
/*     */ {
/*     */   String file;
/*     */   
/*     */   public void run()
/*     */     throws IOException
/*     */   {
/*  53 */     FileInputStream fin = new FileInputStream(this.file);
/*  54 */     POIFSFileSystem poifs = new POIFSFileSystem(fin);
/*  55 */     InputStream din = poifs.createDocumentInputStream("Workbook");
/*  56 */     RecordInputStream rinp = new RecordInputStream(din);
/*     */     
/*  58 */     while (rinp.hasNextRecord()) {
/*  59 */       int sid = rinp.getNextSid();
/*  60 */       rinp.nextRecord();
/*     */       
/*  62 */       int size = rinp.available();
/*  63 */       Class<? extends Record> clz = RecordFactory.getRecordClass(sid);
/*     */       
/*  65 */       System.out.print(formatSID(sid) + " - " + formatSize(size) + " bytes");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */       if (clz != null) {
/*  72 */         System.out.print("  \t");
/*  73 */         System.out.print(clz.getName().replace("org.apache.poi.hssf.record.", ""));
/*     */       }
/*  75 */       System.out.println();
/*     */       
/*  77 */       byte[] data = rinp.readRemainder();
/*  78 */       if (data.length > 0) {
/*  79 */         System.out.print("   ");
/*  80 */         System.out.println(formatData(data));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String formatSID(int sid) {
/*  86 */     String hex = Integer.toHexString(sid);
/*  87 */     String dec = Integer.toString(sid);
/*     */     
/*  89 */     StringBuffer s = new StringBuffer();
/*  90 */     s.append("0x");
/*  91 */     for (int i = hex.length(); i < 4; i++) {
/*  92 */       s.append('0');
/*     */     }
/*  94 */     s.append(hex);
/*     */     
/*  96 */     s.append(" (");
/*  97 */     for (int i = dec.length(); i < 4; i++) {
/*  98 */       s.append('0');
/*     */     }
/* 100 */     s.append(dec);
/* 101 */     s.append(")");
/*     */     
/* 103 */     return s.toString();
/*     */   }
/*     */   
/* 106 */   private static String formatSize(int size) { String hex = Integer.toHexString(size);
/* 107 */     String dec = Integer.toString(size);
/*     */     
/* 109 */     StringBuffer s = new StringBuffer();
/* 110 */     for (int i = hex.length(); i < 3; i++) {
/* 111 */       s.append('0');
/*     */     }
/* 113 */     s.append(hex);
/*     */     
/* 115 */     s.append(" (");
/* 116 */     for (int i = dec.length(); i < 3; i++) {
/* 117 */       s.append('0');
/*     */     }
/* 119 */     s.append(dec);
/* 120 */     s.append(")");
/*     */     
/* 122 */     return s.toString();
/*     */   }
/*     */   
/* 125 */   private static String formatData(byte[] data) { if ((data == null) || (data.length == 0)) {
/* 126 */       return "";
/*     */     }
/*     */     
/* 129 */     StringBuffer s = new StringBuffer();
/* 130 */     if (data.length > 9) {
/* 131 */       s.append(byteToHex(data[0]));
/* 132 */       s.append(' ');
/* 133 */       s.append(byteToHex(data[1]));
/* 134 */       s.append(' ');
/* 135 */       s.append(byteToHex(data[2]));
/* 136 */       s.append(' ');
/* 137 */       s.append(byteToHex(data[3]));
/* 138 */       s.append(' ');
/*     */       
/* 140 */       s.append(" .... ");
/*     */       
/* 142 */       s.append(' ');
/* 143 */       s.append(byteToHex(data[(data.length - 4)]));
/* 144 */       s.append(' ');
/* 145 */       s.append(byteToHex(data[(data.length - 3)]));
/* 146 */       s.append(' ');
/* 147 */       s.append(byteToHex(data[(data.length - 2)]));
/* 148 */       s.append(' ');
/* 149 */       s.append(byteToHex(data[(data.length - 1)]));
/*     */     } else {
/* 151 */       for (int i = 0; i < data.length; i++) {
/* 152 */         s.append(byteToHex(data[i]));
/* 153 */         s.append(' ');
/*     */       }
/*     */     }
/*     */     
/* 157 */     return s.toString();
/*     */   }
/*     */   
/* 160 */   private static String byteToHex(byte b) { int i = b;
/* 161 */     if (i < 0) {
/* 162 */       i += 256;
/*     */     }
/* 164 */     String s = Integer.toHexString(i);
/* 165 */     if (i < 16) {
/* 166 */       return "0" + s;
/*     */     }
/* 168 */     return s;
/*     */   }
/*     */   
/*     */   public void setFile(String file)
/*     */   {
/* 173 */     this.file = file;
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 178 */     if ((args.length == 1) && (!args[0].equals("--help")))
/*     */     {
/*     */       try
/*     */       {
/* 182 */         RecordLister viewer = new RecordLister();
/*     */         
/* 184 */         viewer.setFile(args[0]);
/* 185 */         viewer.run();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 189 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 194 */       System.out.println("RecordLister");
/* 195 */       System.out.println("Outputs the summary of the records in file order");
/*     */       
/* 197 */       System.out.println("usage: java org.apache.poi.hssf.dev.RecordLister filename");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\dev\RecordLister.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */