/*     */ package org.apache.poi.hssf.eventmodel;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFactory;
/*     */ import org.apache.poi.hssf.record.RecordFormatException;
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EventRecordFactory
/*     */ {
/*     */   private final ERFListener _listener;
/*     */   private final short[] _sids;
/*     */   
/*     */   public EventRecordFactory(ERFListener listener, short[] sids)
/*     */   {
/*  48 */     this._listener = listener;
/*  49 */     if (sids == null) {
/*  50 */       this._sids = null;
/*     */     } else {
/*  52 */       this._sids = ((short[])sids.clone());
/*  53 */       Arrays.sort(this._sids);
/*     */     }
/*     */   }
/*     */   
/*  57 */   private boolean isSidIncluded(short sid) { if (this._sids == null) {
/*  58 */       return true;
/*     */     }
/*  60 */     return Arrays.binarySearch(this._sids, sid) >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean processRecord(Record record)
/*     */   {
/*  71 */     if (!isSidIncluded(record.getSid())) {
/*  72 */       return true;
/*     */     }
/*  74 */     return this._listener.processRecord(record);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processRecords(InputStream in)
/*     */     throws RecordFormatException
/*     */   {
/*  87 */     Record last_record = null;
/*     */     
/*  89 */     RecordInputStream recStream = new RecordInputStream(in);
/*     */     
/*  91 */     while (recStream.hasNextRecord()) {
/*  92 */       recStream.nextRecord();
/*  93 */       Record[] recs = RecordFactory.createRecord(recStream);
/*  94 */       if (recs.length > 1) {
/*  95 */         for (int k = 0; k < recs.length; k++) {
/*  96 */           if ((last_record != null) && 
/*  97 */             (!processRecord(last_record))) {
/*  98 */             return;
/*     */           }
/*     */           
/* 101 */           last_record = recs[k];
/*     */         }
/*     */       } else {
/* 104 */         Record record = recs[0];
/*     */         
/* 106 */         if (record != null) {
/* 107 */           if ((last_record != null) && 
/* 108 */             (!processRecord(last_record))) {
/* 109 */             return;
/*     */           }
/*     */           
/* 112 */           last_record = record;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 117 */     if (last_record != null) {
/* 118 */       processRecord(last_record);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventmodel\EventRecordFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */