package org.apache.poi.hssf.eventusermodel;

import org.apache.poi.hssf.record.Record;

public abstract class AbortableHSSFListener
  implements HSSFListener
{
  public void processRecord(Record record) {}
  
  public abstract short abortableProcessRecord(Record paramRecord)
    throws HSSFUserException;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\AbortableHSSFListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */