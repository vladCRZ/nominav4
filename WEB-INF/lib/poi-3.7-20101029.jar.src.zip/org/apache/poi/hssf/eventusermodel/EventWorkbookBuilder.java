/*     */ package org.apache.poi.hssf.eventusermodel;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.InternalWorkbook;
/*     */ import org.apache.poi.hssf.record.BoundSheetRecord;
/*     */ import org.apache.poi.hssf.record.EOFRecord;
/*     */ import org.apache.poi.hssf.record.ExternSheetRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.SSTRecord;
/*     */ import org.apache.poi.hssf.record.SupBookRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventWorkbookBuilder
/*     */ {
/*     */   public static InternalWorkbook createStubWorkbook(ExternSheetRecord[] externs, BoundSheetRecord[] bounds, SSTRecord sst)
/*     */   {
/*  68 */     List wbRecords = new ArrayList();
/*     */     
/*     */ 
/*  71 */     if (bounds != null) {
/*  72 */       for (int i = 0; i < bounds.length; i++) {
/*  73 */         wbRecords.add(bounds[i]);
/*     */       }
/*     */     }
/*  76 */     if (sst != null) {
/*  77 */       wbRecords.add(sst);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  82 */     if (externs != null) {
/*  83 */       wbRecords.add(SupBookRecord.createInternalReferences((short)externs.length));
/*     */       
/*  85 */       for (int i = 0; i < externs.length; i++) {
/*  86 */         wbRecords.add(externs[i]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  91 */     wbRecords.add(EOFRecord.instance);
/*     */     
/*  93 */     return InternalWorkbook.createWorkbook(wbRecords);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InternalWorkbook createStubWorkbook(ExternSheetRecord[] externs, BoundSheetRecord[] bounds)
/*     */   {
/* 105 */     return createStubWorkbook(externs, bounds, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SheetRecordCollectingListener
/*     */     implements HSSFListener
/*     */   {
/*     */     private HSSFListener childListener;
/*     */     
/*     */ 
/* 117 */     private List boundSheetRecords = new ArrayList();
/* 118 */     private List externSheetRecords = new ArrayList();
/* 119 */     private SSTRecord sstRecord = null;
/*     */     
/*     */     public SheetRecordCollectingListener(HSSFListener childListener) {
/* 122 */       this.childListener = childListener;
/*     */     }
/*     */     
/*     */     public BoundSheetRecord[] getBoundSheetRecords()
/*     */     {
/* 127 */       return (BoundSheetRecord[])this.boundSheetRecords.toArray(new BoundSheetRecord[this.boundSheetRecords.size()]);
/*     */     }
/*     */     
/*     */     public ExternSheetRecord[] getExternSheetRecords()
/*     */     {
/* 132 */       return (ExternSheetRecord[])this.externSheetRecords.toArray(new ExternSheetRecord[this.externSheetRecords.size()]);
/*     */     }
/*     */     
/*     */     public SSTRecord getSSTRecord()
/*     */     {
/* 137 */       return this.sstRecord;
/*     */     }
/*     */     
/*     */     public HSSFWorkbook getStubHSSFWorkbook() {
/* 141 */       return HSSFWorkbook.create(getStubWorkbook());
/*     */     }
/*     */     
/* 144 */     public InternalWorkbook getStubWorkbook() { return EventWorkbookBuilder.createStubWorkbook(getExternSheetRecords(), getBoundSheetRecords(), getSSTRecord()); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void processRecord(Record record)
/*     */     {
/* 157 */       processRecordInternally(record);
/*     */       
/*     */ 
/* 160 */       this.childListener.processRecord(record);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void processRecordInternally(Record record)
/*     */     {
/* 168 */       if ((record instanceof BoundSheetRecord)) {
/* 169 */         this.boundSheetRecords.add(record);
/*     */       }
/* 171 */       else if ((record instanceof ExternSheetRecord)) {
/* 172 */         this.externSheetRecords.add(record);
/*     */       }
/* 174 */       else if ((record instanceof SSTRecord)) {
/* 175 */         this.sstRecord = ((SSTRecord)record);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\EventWorkbookBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */