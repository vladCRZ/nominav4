/*     */ package org.apache.poi.hssf.eventusermodel;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hssf.record.CellValueRecordInterface;
/*     */ import org.apache.poi.hssf.record.ExtendedFormatRecord;
/*     */ import org.apache.poi.hssf.record.FormatRecord;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.NumberRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.usermodel.HSSFDataFormat;
/*     */ import org.apache.poi.hssf.usermodel.HSSFDataFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatTrackingHSSFListener
/*     */   implements HSSFListener
/*     */ {
/*     */   private final HSSFListener _childListener;
/*     */   private final HSSFDataFormatter _formatter;
/*     */   private final NumberFormat _defaultFormat;
/*  44 */   private final Map<Integer, FormatRecord> _customFormatRecords = new Hashtable();
/*  45 */   private final List<ExtendedFormatRecord> _xfRecords = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormatTrackingHSSFListener(HSSFListener childListener)
/*     */   {
/*  52 */     this(childListener, Locale.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormatTrackingHSSFListener(HSSFListener childListener, Locale locale)
/*     */   {
/*  61 */     this._childListener = childListener;
/*  62 */     this._formatter = new HSSFDataFormatter(locale);
/*  63 */     this._defaultFormat = NumberFormat.getInstance(locale);
/*     */   }
/*     */   
/*     */   protected int getNumberOfCustomFormats() {
/*  67 */     return this._customFormatRecords.size();
/*     */   }
/*     */   
/*     */   protected int getNumberOfExtendedFormats() {
/*  71 */     return this._xfRecords.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processRecord(Record record)
/*     */   {
/*  79 */     processRecordInternally(record);
/*     */     
/*     */ 
/*  82 */     this._childListener.processRecord(record);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processRecordInternally(Record record)
/*     */   {
/*  92 */     if ((record instanceof FormatRecord)) {
/*  93 */       FormatRecord fr = (FormatRecord)record;
/*  94 */       this._customFormatRecords.put(Integer.valueOf(fr.getIndexCode()), fr);
/*     */     }
/*  96 */     if ((record instanceof ExtendedFormatRecord)) {
/*  97 */       ExtendedFormatRecord xr = (ExtendedFormatRecord)record;
/*  98 */       this._xfRecords.add(xr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatNumberDateCell(CellValueRecordInterface cell)
/*     */   {
/*     */     double value;
/*     */     
/*     */ 
/*     */ 
/* 112 */     if ((cell instanceof NumberRecord)) {
/* 113 */       value = ((NumberRecord)cell).getValue(); } else { double value;
/* 114 */       if ((cell instanceof FormulaRecord)) {
/* 115 */         value = ((FormulaRecord)cell).getValue();
/*     */       } else {
/* 117 */         throw new IllegalArgumentException("Unsupported CellValue Record passed in " + cell);
/*     */       }
/*     */     }
/*     */     double value;
/* 121 */     int formatIndex = getFormatIndex(cell);
/* 122 */     String formatString = getFormatString(cell);
/*     */     
/* 124 */     if (formatString == null) {
/* 125 */       return this._defaultFormat.format(value);
/*     */     }
/*     */     
/*     */ 
/* 129 */     return this._formatter.formatRawCellContents(value, formatIndex, formatString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFormatString(int formatIndex)
/*     */   {
/* 136 */     String format = null;
/* 137 */     if (formatIndex >= HSSFDataFormat.getNumberOfBuiltinBuiltinFormats()) {
/* 138 */       FormatRecord tfr = (FormatRecord)this._customFormatRecords.get(Integer.valueOf(formatIndex));
/* 139 */       if (tfr == null) {
/* 140 */         System.err.println("Requested format at index " + formatIndex + ", but it wasn't found");
/*     */       }
/*     */       else {
/* 143 */         format = tfr.getFormatString();
/*     */       }
/*     */     } else {
/* 146 */       format = HSSFDataFormat.getBuiltinFormat((short)formatIndex);
/*     */     }
/* 148 */     return format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFormatString(CellValueRecordInterface cell)
/*     */   {
/* 155 */     int formatIndex = getFormatIndex(cell);
/* 156 */     if (formatIndex == -1)
/*     */     {
/* 158 */       return null;
/*     */     }
/* 160 */     return getFormatString(formatIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFormatIndex(CellValueRecordInterface cell)
/*     */   {
/* 168 */     ExtendedFormatRecord xfr = (ExtendedFormatRecord)this._xfRecords.get(cell.getXFIndex());
/* 169 */     if (xfr == null) {
/* 170 */       System.err.println("Cell " + cell.getRow() + "," + cell.getColumn() + " uses XF with index " + cell.getXFIndex() + ", but we don't have that");
/*     */       
/* 172 */       return -1;
/*     */     }
/* 174 */     return xfr.getFormatIndex();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\FormatTrackingHSSFListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */