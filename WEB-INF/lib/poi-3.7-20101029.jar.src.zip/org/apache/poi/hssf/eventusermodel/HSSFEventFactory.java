/*     */ package org.apache.poi.hssf.eventusermodel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFactoryInputStream;
/*     */ import org.apache.poi.poifs.filesystem.DirectoryNode;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HSSFEventFactory
/*     */ {
/*     */   public void processWorkbookEvents(HSSFRequest req, POIFSFileSystem fs)
/*     */     throws IOException
/*     */   {
/*  53 */     processWorkbookEvents(req, fs.getRoot());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processWorkbookEvents(HSSFRequest req, DirectoryNode dir)
/*     */     throws IOException
/*     */   {
/*  63 */     InputStream in = dir.createDocumentInputStream("Workbook");
/*     */     
/*  65 */     processEvents(req, in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short abortableProcessWorkbookEvents(HSSFRequest req, POIFSFileSystem fs)
/*     */     throws IOException, HSSFUserException
/*     */   {
/*  77 */     return abortableProcessWorkbookEvents(req, fs.getRoot());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short abortableProcessWorkbookEvents(HSSFRequest req, DirectoryNode dir)
/*     */     throws IOException, HSSFUserException
/*     */   {
/*  89 */     InputStream in = dir.createDocumentInputStream("Workbook");
/*  90 */     return abortableProcessEvents(req, in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processEvents(HSSFRequest req, InputStream in)
/*     */   {
/*     */     try
/*     */     {
/* 106 */       genericProcessEvents(req, in);
/*     */     }
/*     */     catch (HSSFUserException hue) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short abortableProcessEvents(HSSFRequest req, InputStream in)
/*     */     throws HSSFUserException
/*     */   {
/* 123 */     return genericProcessEvents(req, in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private short genericProcessEvents(HSSFRequest req, InputStream in)
/*     */     throws HSSFUserException
/*     */   {
/* 136 */     short userCode = 0;
/*     */     
/*     */ 
/* 139 */     RecordFactoryInputStream recordStream = new RecordFactoryInputStream(in, false);
/*     */     
/*     */     for (;;)
/*     */     {
/* 143 */       Record r = recordStream.nextRecord();
/* 144 */       if (r == null) {
/*     */         break;
/*     */       }
/* 147 */       userCode = req.processRecord(r);
/* 148 */       if (userCode != 0) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 154 */     return userCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\HSSFEventFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */