/*     */ package org.apache.poi.hssf.eventusermodel;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HSSFRequest
/*     */ {
/*     */   private final Map<Short, List<HSSFListener>> _records;
/*     */   
/*     */   public HSSFRequest()
/*     */   {
/*  43 */     this._records = new HashMap(50);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addListener(HSSFListener lsnr, short sid)
/*     */   {
/*  60 */     List<HSSFListener> list = (List)this._records.get(Short.valueOf(sid));
/*     */     
/*  62 */     if (list == null) {
/*  63 */       list = new ArrayList(1);
/*  64 */       this._records.put(Short.valueOf(sid), list);
/*     */     }
/*  66 */     list.add(lsnr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addListenerForAllRecords(HSSFListener lsnr)
/*     */   {
/*  80 */     short[] rectypes = RecordFactory.getAllKnownRecordSIDs();
/*     */     
/*  82 */     for (int k = 0; k < rectypes.length; k++) {
/*  83 */       addListener(lsnr, rectypes[k]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected short processRecord(Record rec)
/*     */     throws HSSFUserException
/*     */   {
/*  97 */     Object obj = this._records.get(Short.valueOf(rec.getSid()));
/*  98 */     short userCode = 0;
/*     */     
/* 100 */     if (obj != null) {
/* 101 */       List listeners = (List)obj;
/*     */       
/* 103 */       for (int k = 0; k < listeners.size(); k++) {
/* 104 */         Object listenObj = listeners.get(k);
/* 105 */         if ((listenObj instanceof AbortableHSSFListener)) {
/* 106 */           AbortableHSSFListener listener = (AbortableHSSFListener)listenObj;
/* 107 */           userCode = listener.abortableProcessRecord(rec);
/* 108 */           if (userCode != 0)
/*     */             break;
/*     */         } else {
/* 111 */           HSSFListener listener = (HSSFListener)listenObj;
/* 112 */           listener.processRecord(rec);
/*     */         }
/*     */       }
/*     */     }
/* 116 */     return userCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\HSSFRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */