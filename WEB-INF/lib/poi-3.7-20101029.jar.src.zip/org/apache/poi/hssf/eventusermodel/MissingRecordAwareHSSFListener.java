/*     */ package org.apache.poi.hssf.eventusermodel;
/*     */ 
/*     */ import org.apache.poi.hssf.eventusermodel.dummyrecord.LastCellOfRowDummyRecord;
/*     */ import org.apache.poi.hssf.eventusermodel.dummyrecord.MissingCellDummyRecord;
/*     */ import org.apache.poi.hssf.eventusermodel.dummyrecord.MissingRowDummyRecord;
/*     */ import org.apache.poi.hssf.record.BOFRecord;
/*     */ import org.apache.poi.hssf.record.CellValueRecordInterface;
/*     */ import org.apache.poi.hssf.record.MulBlankRecord;
/*     */ import org.apache.poi.hssf.record.MulRKRecord;
/*     */ import org.apache.poi.hssf.record.NoteRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFactory;
/*     */ import org.apache.poi.hssf.record.RowRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MissingRecordAwareHSSFListener
/*     */   implements HSSFListener
/*     */ {
/*     */   private HSSFListener childListener;
/*     */   private int lastRowRow;
/*     */   private int lastCellRow;
/*     */   private int lastCellColumn;
/*     */   
/*     */   public MissingRecordAwareHSSFListener(HSSFListener listener)
/*     */   {
/*  61 */     resetCounts();
/*  62 */     this.childListener = listener;
/*     */   }
/*     */   
/*     */ 
/*     */   public void processRecord(Record record)
/*     */   {
/*  68 */     CellValueRecordInterface[] expandedRecords = null;
/*     */     int thisColumn;
/*  70 */     int thisRow; int thisColumn; if ((record instanceof CellValueRecordInterface)) {
/*  71 */       CellValueRecordInterface valueRec = (CellValueRecordInterface)record;
/*  72 */       int thisRow = valueRec.getRow();
/*  73 */       thisColumn = valueRec.getColumn();
/*     */     } else {
/*  75 */       thisRow = -1;
/*  76 */       thisColumn = -1;
/*     */       
/*  78 */       switch (record.getSid())
/*     */       {
/*     */ 
/*     */       case 2057: 
/*  82 */         BOFRecord bof = (BOFRecord)record;
/*  83 */         if ((bof.getType() == 5) || (bof.getType() == 16))
/*     */         {
/*  85 */           resetCounts();
/*     */         }
/*     */         break;
/*     */       case 520: 
/*  89 */         RowRecord rowrec = (RowRecord)record;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  94 */         if (this.lastRowRow + 1 < rowrec.getRowNumber()) {
/*  95 */           for (int i = this.lastRowRow + 1; i < rowrec.getRowNumber(); i++) {
/*  96 */             MissingRowDummyRecord dr = new MissingRowDummyRecord(i);
/*  97 */             this.childListener.processRecord(dr);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 102 */         this.lastRowRow = rowrec.getRowNumber();
/* 103 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 1212: 
/* 109 */         this.childListener.processRecord(record);
/* 110 */         return;
/*     */       
/*     */ 
/*     */ 
/*     */       case 190: 
/* 115 */         MulBlankRecord mbr = (MulBlankRecord)record;
/* 116 */         expandedRecords = RecordFactory.convertBlankRecords(mbr);
/* 117 */         break;
/*     */       
/*     */ 
/*     */       case 189: 
/* 121 */         MulRKRecord mrk = (MulRKRecord)record;
/* 122 */         expandedRecords = RecordFactory.convertRKRecords(mrk);
/* 123 */         break;
/*     */       case 28: 
/* 125 */         NoteRecord nrec = (NoteRecord)record;
/* 126 */         thisRow = nrec.getRow();
/* 127 */         thisColumn = nrec.getColumn();
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/* 133 */     if ((expandedRecords != null) && (expandedRecords.length > 0)) {
/* 134 */       thisRow = expandedRecords[0].getRow();
/* 135 */       thisColumn = expandedRecords[0].getColumn();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     if ((thisRow != this.lastCellRow) && (this.lastCellRow > -1)) {
/* 142 */       for (int i = this.lastCellRow; i < thisRow; i++) {
/* 143 */         int cols = -1;
/* 144 */         if (i == this.lastCellRow) {
/* 145 */           cols = this.lastCellColumn;
/*     */         }
/* 147 */         this.childListener.processRecord(new LastCellOfRowDummyRecord(i, cols));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 153 */     if ((this.lastCellRow != -1) && (this.lastCellColumn != -1) && (thisRow == -1)) {
/* 154 */       this.childListener.processRecord(new LastCellOfRowDummyRecord(this.lastCellRow, this.lastCellColumn));
/*     */       
/* 156 */       this.lastCellRow = -1;
/* 157 */       this.lastCellColumn = -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 162 */     if (thisRow != this.lastCellRow) {
/* 163 */       this.lastCellColumn = -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 168 */     if (this.lastCellColumn != thisColumn - 1) {
/* 169 */       for (int i = this.lastCellColumn + 1; i < thisColumn; i++) {
/* 170 */         this.childListener.processRecord(new MissingCellDummyRecord(thisRow, i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 175 */     if ((expandedRecords != null) && (expandedRecords.length > 0)) {
/* 176 */       thisColumn = expandedRecords[(expandedRecords.length - 1)].getColumn();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 181 */     if (thisColumn != -1) {
/* 182 */       this.lastCellColumn = thisColumn;
/* 183 */       this.lastCellRow = thisRow;
/*     */     }
/*     */     
/*     */ 
/* 187 */     if ((expandedRecords != null) && (expandedRecords.length > 0)) {
/* 188 */       for (CellValueRecordInterface r : expandedRecords) {
/* 189 */         this.childListener.processRecord((Record)r);
/*     */       }
/*     */     } else {
/* 192 */       this.childListener.processRecord(record);
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetCounts() {
/* 197 */     this.lastRowRow = -1;
/* 198 */     this.lastCellRow = -1;
/* 199 */     this.lastCellColumn = -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\MissingRecordAwareHSSFListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */