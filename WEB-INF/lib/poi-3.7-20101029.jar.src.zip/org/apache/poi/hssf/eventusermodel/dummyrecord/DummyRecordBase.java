/*    */ package org.apache.poi.hssf.eventusermodel.dummyrecord;
/*    */ 
/*    */ import org.apache.poi.hssf.record.Record;
/*    */ import org.apache.poi.hssf.record.RecordFormatException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class DummyRecordBase
/*    */   extends Record
/*    */ {
/*    */   public final short getSid()
/*    */   {
/* 32 */     return -1;
/*    */   }
/*    */   
/* 35 */   public int serialize(int offset, byte[] data) { throw new RecordFormatException("Cannot serialize a dummy record"); }
/*    */   
/*    */   public final int getRecordSize() {
/* 38 */     throw new RecordFormatException("Cannot serialize a dummy record");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\dummyrecord\DummyRecordBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */