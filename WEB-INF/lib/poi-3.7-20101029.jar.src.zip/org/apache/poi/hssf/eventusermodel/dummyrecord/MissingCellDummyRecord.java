/*    */ package org.apache.poi.hssf.eventusermodel.dummyrecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MissingCellDummyRecord
/*    */   extends DummyRecordBase
/*    */ {
/*    */   private int row;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int column;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MissingCellDummyRecord(int row, int column)
/*    */   {
/* 30 */     this.row = row;
/* 31 */     this.column = column; }
/*    */   
/* 33 */   public int getRow() { return this.row; }
/* 34 */   public int getColumn() { return this.column; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\eventusermodel\dummyrecord\MissingCellDummyRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */