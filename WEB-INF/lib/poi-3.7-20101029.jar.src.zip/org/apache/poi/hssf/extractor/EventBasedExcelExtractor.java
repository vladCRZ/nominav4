/*     */ package org.apache.poi.hssf.extractor;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.POIOLE2TextExtractor;
/*     */ import org.apache.poi.hpsf.DocumentSummaryInformation;
/*     */ import org.apache.poi.hpsf.SummaryInformation;
/*     */ import org.apache.poi.hssf.eventusermodel.FormatTrackingHSSFListener;
/*     */ import org.apache.poi.hssf.eventusermodel.HSSFEventFactory;
/*     */ import org.apache.poi.hssf.eventusermodel.HSSFListener;
/*     */ import org.apache.poi.hssf.eventusermodel.HSSFRequest;
/*     */ import org.apache.poi.hssf.model.HSSFFormulaParser;
/*     */ import org.apache.poi.hssf.record.BOFRecord;
/*     */ import org.apache.poi.hssf.record.BoundSheetRecord;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.LabelRecord;
/*     */ import org.apache.poi.hssf.record.LabelSSTRecord;
/*     */ import org.apache.poi.hssf.record.NoteRecord;
/*     */ import org.apache.poi.hssf.record.NumberRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.SSTRecord;
/*     */ import org.apache.poi.hssf.record.StringRecord;
/*     */ import org.apache.poi.hssf.record.common.UnicodeString;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.poifs.filesystem.DirectoryNode;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventBasedExcelExtractor
/*     */   extends POIOLE2TextExtractor
/*     */ {
/*     */   private DirectoryNode _dir;
/*     */   private POIFSFileSystem _fs;
/*  65 */   boolean _includeSheetNames = true;
/*  66 */   boolean _formulasNotResults = false;
/*     */   
/*     */   public EventBasedExcelExtractor(DirectoryNode dir, POIFSFileSystem fs) {
/*  69 */     super(null);
/*  70 */     this._dir = dir;
/*  71 */     this._fs = fs;
/*     */   }
/*     */   
/*  74 */   public EventBasedExcelExtractor(POIFSFileSystem fs) { this(fs.getRoot(), fs); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public POIFSFileSystem getFileSystem()
/*     */   {
/*  82 */     return this._fs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentSummaryInformation getDocSummaryInformation()
/*     */   {
/*  90 */     throw new IllegalStateException("Metadata extraction not supported in streaming mode, please use ExcelExtractor");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SummaryInformation getSummaryInformation()
/*     */   {
/*  97 */     throw new IllegalStateException("Metadata extraction not supported in streaming mode, please use ExcelExtractor");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIncludeSheetNames(boolean includeSheetNames)
/*     */   {
/* 105 */     this._includeSheetNames = includeSheetNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFormulasNotResults(boolean formulasNotResults)
/*     */   {
/* 112 */     this._formulasNotResults = formulasNotResults;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 120 */     String text = null;
/*     */     try {
/* 122 */       TextListener tl = triggerExtraction();
/*     */       
/* 124 */       text = tl._text.toString();
/* 125 */       if (!text.endsWith("\n")) {
/* 126 */         text = text + "\n";
/*     */       }
/*     */     } catch (IOException e) {
/* 129 */       throw new RuntimeException(e);
/*     */     }
/*     */     
/* 132 */     return text;
/*     */   }
/*     */   
/*     */   private TextListener triggerExtraction() throws IOException {
/* 136 */     TextListener tl = new TextListener();
/* 137 */     FormatTrackingHSSFListener ft = new FormatTrackingHSSFListener(tl);
/* 138 */     tl._ft = ft;
/*     */     
/*     */ 
/* 141 */     HSSFEventFactory factory = new HSSFEventFactory();
/* 142 */     HSSFRequest request = new HSSFRequest();
/* 143 */     request.addListenerForAllRecords(ft);
/*     */     
/* 145 */     factory.processWorkbookEvents(request, this._dir);
/*     */     
/* 147 */     return tl;
/*     */   }
/*     */   
/*     */   private class TextListener implements HSSFListener
/*     */   {
/*     */     FormatTrackingHSSFListener _ft;
/*     */     private SSTRecord sstRecord;
/*     */     private final List<String> sheetNames;
/* 155 */     final StringBuffer _text = new StringBuffer();
/* 156 */     private int sheetNum = -1;
/*     */     
/*     */     private int rowNum;
/* 159 */     private boolean outputNextStringValue = false;
/* 160 */     private int nextRow = -1;
/*     */     
/*     */ 
/* 163 */     public TextListener() { this.sheetNames = new ArrayList(); }
/*     */     
/*     */     public void processRecord(Record record) {
/* 166 */       String thisText = null;
/* 167 */       int thisRow = -1;
/*     */       
/* 169 */       switch (record.getSid()) {
/*     */       case 133: 
/* 171 */         BoundSheetRecord sr = (BoundSheetRecord)record;
/* 172 */         this.sheetNames.add(sr.getSheetname());
/* 173 */         break;
/*     */       case 2057: 
/* 175 */         BOFRecord bof = (BOFRecord)record;
/* 176 */         if (bof.getType() == 16) {
/* 177 */           this.sheetNum += 1;
/* 178 */           this.rowNum = -1;
/*     */           
/* 180 */           if (EventBasedExcelExtractor.this._includeSheetNames) {
/* 181 */             if (this._text.length() > 0) this._text.append("\n");
/* 182 */             this._text.append((String)this.sheetNames.get(this.sheetNum));
/*     */           }
/*     */         }
/*     */         break;
/*     */       case 252: 
/* 187 */         this.sstRecord = ((SSTRecord)record);
/* 188 */         break;
/*     */       
/*     */       case 6: 
/* 191 */         FormulaRecord frec = (FormulaRecord)record;
/* 192 */         thisRow = frec.getRow();
/*     */         
/* 194 */         if (EventBasedExcelExtractor.this._formulasNotResults) {
/* 195 */           thisText = HSSFFormulaParser.toFormulaString((HSSFWorkbook)null, frec.getParsedExpression());
/*     */         }
/* 197 */         else if (frec.hasCachedResultString())
/*     */         {
/*     */ 
/* 200 */           this.outputNextStringValue = true;
/* 201 */           this.nextRow = frec.getRow();
/*     */         } else {
/* 203 */           thisText = this._ft.formatNumberDateCell(frec);
/*     */         }
/*     */         
/* 206 */         break;
/*     */       case 519: 
/* 208 */         if (this.outputNextStringValue)
/*     */         {
/* 210 */           StringRecord srec = (StringRecord)record;
/* 211 */           thisText = srec.getString();
/* 212 */           thisRow = this.nextRow;
/* 213 */           this.outputNextStringValue = false; }
/* 214 */         break;
/*     */       
/*     */       case 516: 
/* 217 */         LabelRecord lrec = (LabelRecord)record;
/* 218 */         thisRow = lrec.getRow();
/* 219 */         thisText = lrec.getValue();
/* 220 */         break;
/*     */       case 253: 
/* 222 */         LabelSSTRecord lsrec = (LabelSSTRecord)record;
/* 223 */         thisRow = lsrec.getRow();
/* 224 */         if (this.sstRecord == null) {
/* 225 */           throw new IllegalStateException("No SST record found");
/*     */         }
/* 227 */         thisText = this.sstRecord.getString(lsrec.getSSTIndex()).toString();
/* 228 */         break;
/*     */       case 28: 
/* 230 */         NoteRecord nrec = (NoteRecord)record;
/* 231 */         thisRow = nrec.getRow();
/*     */         
/* 233 */         break;
/*     */       case 515: 
/* 235 */         NumberRecord numrec = (NumberRecord)record;
/* 236 */         thisRow = numrec.getRow();
/* 237 */         thisText = this._ft.formatNumberDateCell(numrec);
/* 238 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/* 243 */       if (thisText != null) {
/* 244 */         if (thisRow != this.rowNum) {
/* 245 */           this.rowNum = thisRow;
/* 246 */           if (this._text.length() > 0)
/* 247 */             this._text.append("\n");
/*     */         } else {
/* 249 */           this._text.append("\t");
/*     */         }
/* 251 */         this._text.append(thisText);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\extractor\EventBasedExcelExtractor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */