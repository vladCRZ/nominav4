/*     */ package org.apache.poi.hssf.extractor;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.poi.POIOLE2TextExtractor;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*     */ import org.apache.poi.hssf.usermodel.HSSFComment;
/*     */ import org.apache.poi.hssf.usermodel.HSSFDataFormatter;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRichTextString;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.poifs.filesystem.DirectoryNode;
/*     */ import org.apache.poi.poifs.filesystem.POIFSFileSystem;
/*     */ import org.apache.poi.ss.usermodel.HeaderFooter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExcelExtractor
/*     */   extends POIOLE2TextExtractor
/*     */   implements org.apache.poi.ss.extractor.ExcelExtractor
/*     */ {
/*     */   private HSSFWorkbook _wb;
/*     */   private HSSFDataFormatter _formatter;
/*  57 */   private boolean _includeSheetNames = true;
/*  58 */   private boolean _shouldEvaluateFormulas = true;
/*  59 */   private boolean _includeCellComments = false;
/*  60 */   private boolean _includeBlankCells = false;
/*  61 */   private boolean _includeHeadersFooters = true;
/*     */   
/*     */   public ExcelExtractor(HSSFWorkbook wb) {
/*  64 */     super(wb);
/*  65 */     this._wb = wb;
/*  66 */     this._formatter = new HSSFDataFormatter();
/*     */   }
/*     */   
/*  69 */   public ExcelExtractor(POIFSFileSystem fs) throws IOException { this(fs.getRoot(), fs); }
/*     */   
/*     */   public ExcelExtractor(DirectoryNode dir, POIFSFileSystem fs) throws IOException {
/*  72 */     this(new HSSFWorkbook(dir, fs, true));
/*     */   }
/*     */   
/*     */   private static final class CommandParseException
/*     */     extends Exception {
/*  77 */     public CommandParseException(String msg) { super(); }
/*     */   }
/*     */   
/*     */   private static final class CommandArgs {
/*     */     private final boolean _requestHelp;
/*     */     private final File _inputFile;
/*     */     private final boolean _showSheetNames;
/*     */     private final boolean _evaluateFormulas;
/*     */     private final boolean _showCellComments;
/*     */     private final boolean _showBlankCells;
/*     */     private final boolean _headersFooters;
/*     */     
/*  89 */     public CommandArgs(String[] args) throws ExcelExtractor.CommandParseException { int nArgs = args.length;
/*  90 */       File inputFile = null;
/*  91 */       boolean requestHelp = false;
/*  92 */       boolean showSheetNames = true;
/*  93 */       boolean evaluateFormulas = true;
/*  94 */       boolean showCellComments = false;
/*  95 */       boolean showBlankCells = false;
/*  96 */       boolean headersFooters = true;
/*  97 */       for (int i = 0; i < nArgs; i++) {
/*  98 */         String arg = args[i];
/*  99 */         if ("-help".equalsIgnoreCase(arg)) {
/* 100 */           requestHelp = true;
/* 101 */           break;
/*     */         }
/* 103 */         if ("-i".equals(arg))
/*     */         {
/* 105 */           i++; if (i >= nArgs) {
/* 106 */             throw new ExcelExtractor.CommandParseException("Expected filename after '-i'");
/*     */           }
/* 108 */           arg = args[i];
/* 109 */           if (inputFile != null) {
/* 110 */             throw new ExcelExtractor.CommandParseException("Only one input file can be supplied");
/*     */           }
/* 112 */           inputFile = new File(arg);
/* 113 */           if (!inputFile.exists()) {
/* 114 */             throw new ExcelExtractor.CommandParseException("Specified input file '" + arg + "' does not exist");
/*     */           }
/* 116 */           if (inputFile.isDirectory()) {
/* 117 */             throw new ExcelExtractor.CommandParseException("Specified input file '" + arg + "' is a directory");
/*     */           }
/*     */           
/*     */         }
/* 121 */         else if ("--show-sheet-names".equals(arg)) {
/* 122 */           showSheetNames = parseBoolArg(args, ++i);
/*     */ 
/*     */         }
/* 125 */         else if ("--evaluate-formulas".equals(arg)) {
/* 126 */           evaluateFormulas = parseBoolArg(args, ++i);
/*     */ 
/*     */         }
/* 129 */         else if ("--show-comments".equals(arg)) {
/* 130 */           showCellComments = parseBoolArg(args, ++i);
/*     */ 
/*     */         }
/* 133 */         else if ("--show-blanks".equals(arg)) {
/* 134 */           showBlankCells = parseBoolArg(args, ++i);
/*     */ 
/*     */         }
/* 137 */         else if ("--headers-footers".equals(arg)) {
/* 138 */           headersFooters = parseBoolArg(args, ++i);
/*     */         }
/*     */         else {
/* 141 */           throw new ExcelExtractor.CommandParseException("Invalid argument '" + arg + "'");
/*     */         } }
/* 143 */       this._requestHelp = requestHelp;
/* 144 */       this._inputFile = inputFile;
/* 145 */       this._showSheetNames = showSheetNames;
/* 146 */       this._evaluateFormulas = evaluateFormulas;
/* 147 */       this._showCellComments = showCellComments;
/* 148 */       this._showBlankCells = showBlankCells;
/* 149 */       this._headersFooters = headersFooters;
/*     */     }
/*     */     
/* 152 */     private static boolean parseBoolArg(String[] args, int i) throws ExcelExtractor.CommandParseException { if (i >= args.length) {
/* 153 */         throw new ExcelExtractor.CommandParseException("Expected value after '" + args[(i - 1)] + "'");
/*     */       }
/* 155 */       String value = args[i].toUpperCase();
/* 156 */       if (("Y".equals(value)) || ("YES".equals(value)) || ("ON".equals(value)) || ("TRUE".equals(value))) {
/* 157 */         return true;
/*     */       }
/* 159 */       if (("N".equals(value)) || ("NO".equals(value)) || ("OFF".equals(value)) || ("FALSE".equals(value))) {
/* 160 */         return false;
/*     */       }
/* 162 */       throw new ExcelExtractor.CommandParseException("Invalid value '" + args[i] + "' for '" + args[(i - 1)] + "'. Expected 'Y' or 'N'");
/*     */     }
/*     */     
/* 165 */     public boolean isRequestHelp() { return this._requestHelp; }
/*     */     
/*     */     public File getInputFile() {
/* 168 */       return this._inputFile;
/*     */     }
/*     */     
/* 171 */     public boolean shouldShowSheetNames() { return this._showSheetNames; }
/*     */     
/*     */     public boolean shouldEvaluateFormulas() {
/* 174 */       return this._evaluateFormulas;
/*     */     }
/*     */     
/* 177 */     public boolean shouldShowCellComments() { return this._showCellComments; }
/*     */     
/*     */     public boolean shouldShowBlankCells() {
/* 180 */       return this._showBlankCells;
/*     */     }
/*     */     
/* 183 */     public boolean shouldIncludeHeadersFooters() { return this._headersFooters; }
/*     */   }
/*     */   
/*     */   private static void printUsageMessage(PrintStream ps)
/*     */   {
/* 188 */     ps.println("Use:");
/* 189 */     ps.println("    " + ExcelExtractor.class.getName() + " [<flag> <value> [<flag> <value> [...]]] [-i <filename.xls>]");
/* 190 */     ps.println("       -i <filename.xls> specifies input file (default is to use stdin)");
/* 191 */     ps.println("       Flags can be set on or off by using the values 'Y' or 'N'.");
/* 192 */     ps.println("       Following are available flags and their default values:");
/* 193 */     ps.println("       --show-sheet-names  Y");
/* 194 */     ps.println("       --evaluate-formulas Y");
/* 195 */     ps.println("       --show-comments     N");
/* 196 */     ps.println("       --show-blanks       Y");
/* 197 */     ps.println("       --headers-footers   Y");
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     CommandArgs cmdArgs;
/*     */     
/*     */     try
/*     */     {
/* 207 */       cmdArgs = new CommandArgs(args);
/*     */     } catch (CommandParseException e) {
/* 209 */       System.err.println(e.getMessage());
/* 210 */       printUsageMessage(System.err);
/* 211 */       System.exit(1);
/* 212 */       return;
/*     */     }
/*     */     
/* 215 */     if (cmdArgs.isRequestHelp()) {
/* 216 */       printUsageMessage(System.out);
/* 217 */       return;
/*     */     }
/*     */     try {
/*     */       InputStream is;
/*     */       InputStream is;
/* 222 */       if (cmdArgs.getInputFile() == null) {
/* 223 */         is = System.in;
/*     */       } else {
/* 225 */         is = new FileInputStream(cmdArgs.getInputFile());
/*     */       }
/* 227 */       HSSFWorkbook wb = new HSSFWorkbook(is);
/*     */       
/* 229 */       ExcelExtractor extractor = new ExcelExtractor(wb);
/* 230 */       extractor.setIncludeSheetNames(cmdArgs.shouldShowSheetNames());
/* 231 */       extractor.setFormulasNotResults(!cmdArgs.shouldEvaluateFormulas());
/* 232 */       extractor.setIncludeCellComments(cmdArgs.shouldShowCellComments());
/* 233 */       extractor.setIncludeBlankCells(cmdArgs.shouldShowBlankCells());
/* 234 */       extractor.setIncludeHeadersFooters(cmdArgs.shouldIncludeHeadersFooters());
/* 235 */       System.out.println(extractor.getText());
/*     */     } catch (Exception e) {
/* 237 */       e.printStackTrace();
/* 238 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIncludeSheetNames(boolean includeSheetNames)
/*     */   {
/* 245 */     this._includeSheetNames = includeSheetNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFormulasNotResults(boolean formulasNotResults)
/*     */   {
/* 252 */     this._shouldEvaluateFormulas = (!formulasNotResults);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIncludeCellComments(boolean includeCellComments)
/*     */   {
/* 258 */     this._includeCellComments = includeCellComments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIncludeBlankCells(boolean includeBlankCells)
/*     */   {
/* 266 */     this._includeBlankCells = includeBlankCells;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setIncludeHeadersFooters(boolean includeHeadersFooters)
/*     */   {
/* 273 */     this._includeHeadersFooters = includeHeadersFooters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 280 */     StringBuffer text = new StringBuffer();
/*     */     
/*     */ 
/*     */ 
/* 284 */     this._wb.setMissingCellPolicy(HSSFRow.RETURN_BLANK_AS_NULL);
/*     */     
/*     */ 
/* 287 */     for (int i = 0; i < this._wb.getNumberOfSheets(); i++) {
/* 288 */       HSSFSheet sheet = this._wb.getSheetAt(i);
/* 289 */       if (sheet != null)
/*     */       {
/* 291 */         if (this._includeSheetNames) {
/* 292 */           String name = this._wb.getSheetName(i);
/* 293 */           if (name != null) {
/* 294 */             text.append(name);
/* 295 */             text.append("\n");
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 300 */         if (this._includeHeadersFooters) {
/* 301 */           text.append(_extractHeaderFooter(sheet.getHeader()));
/*     */         }
/*     */         
/* 304 */         int firstRow = sheet.getFirstRowNum();
/* 305 */         int lastRow = sheet.getLastRowNum();
/* 306 */         for (int j = firstRow; j <= lastRow; j++) {
/* 307 */           HSSFRow row = sheet.getRow(j);
/* 308 */           if (row != null)
/*     */           {
/*     */ 
/* 311 */             int firstCell = row.getFirstCellNum();
/* 312 */             int lastCell = row.getLastCellNum();
/* 313 */             if (this._includeBlankCells) {
/* 314 */               firstCell = 0;
/*     */             }
/*     */             
/* 317 */             for (int k = firstCell; k < lastCell; k++) {
/* 318 */               HSSFCell cell = row.getCell(k);
/* 319 */               boolean outputContents = true;
/*     */               
/* 321 */               if (cell == null)
/*     */               {
/* 323 */                 outputContents = this._includeBlankCells;
/*     */               } else {
/* 325 */                 switch (cell.getCellType()) {
/*     */                 case 1: 
/* 327 */                   text.append(cell.getRichStringCellValue().getString());
/* 328 */                   break;
/*     */                 case 0: 
/* 330 */                   text.append(this._formatter.formatCellValue(cell));
/*     */                   
/*     */ 
/* 333 */                   break;
/*     */                 case 4: 
/* 335 */                   text.append(cell.getBooleanCellValue());
/* 336 */                   break;
/*     */                 case 5: 
/* 338 */                   text.append(ErrorEval.getText(cell.getErrorCellValue()));
/* 339 */                   break;
/*     */                 case 2: 
/* 341 */                   if (!this._shouldEvaluateFormulas) {
/* 342 */                     text.append(cell.getCellFormula());
/*     */                   } else {
/* 344 */                     switch (cell.getCachedFormulaResultType()) {
/*     */                     case 1: 
/* 346 */                       HSSFRichTextString str = cell.getRichStringCellValue();
/* 347 */                       if ((str != null) && (str.length() > 0)) {
/* 348 */                         text.append(str.toString());
/*     */                       }
/*     */                       break;
/*     */                     case 0: 
/* 352 */                       HSSFCellStyle style = cell.getCellStyle();
/* 353 */                       if (style == null) {
/* 354 */                         text.append(cell.getNumericCellValue());
/*     */                       } else {
/* 356 */                         text.append(this._formatter.formatRawCellContents(cell.getNumericCellValue(), style.getDataFormat(), style.getDataFormatString()));
/*     */                       }
/*     */                       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */                       break;
/*     */                     case 4: 
/* 366 */                       text.append(cell.getBooleanCellValue());
/* 367 */                       break;
/*     */                     case 5: 
/* 369 */                       text.append(ErrorEval.getText(cell.getErrorCellValue()));
/*     */                     }
/*     */                     
/*     */                   }
/*     */                   
/* 374 */                   break;
/*     */                 case 3: default: 
/* 376 */                   throw new RuntimeException("Unexpected cell type (" + cell.getCellType() + ")");
/*     */                 }
/*     */                 
/*     */                 
/* 380 */                 HSSFComment comment = cell.getCellComment();
/* 381 */                 if ((this._includeCellComments) && (comment != null))
/*     */                 {
/*     */ 
/* 384 */                   String commentText = comment.getString().getString().replace('\n', ' ');
/* 385 */                   text.append(" Comment by " + comment.getAuthor() + ": " + commentText);
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/* 390 */               if ((outputContents) && (k < lastCell - 1)) {
/* 391 */                 text.append("\t");
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 396 */             text.append("\n");
/*     */           }
/*     */         }
/*     */         
/* 400 */         if (this._includeHeadersFooters) {
/* 401 */           text.append(_extractHeaderFooter(sheet.getFooter()));
/*     */         }
/*     */       }
/*     */     }
/* 405 */     return text.toString();
/*     */   }
/*     */   
/*     */   public static String _extractHeaderFooter(HeaderFooter hf) {
/* 409 */     StringBuffer text = new StringBuffer();
/*     */     
/* 411 */     if (hf.getLeft() != null) {
/* 412 */       text.append(hf.getLeft());
/*     */     }
/* 414 */     if (hf.getCenter() != null) {
/* 415 */       if (text.length() > 0)
/* 416 */         text.append("\t");
/* 417 */       text.append(hf.getCenter());
/*     */     }
/* 419 */     if (hf.getRight() != null) {
/* 420 */       if (text.length() > 0)
/* 421 */         text.append("\t");
/* 422 */       text.append(hf.getRight());
/*     */     }
/* 424 */     if (text.length() > 0) {
/* 425 */       text.append("\n");
/*     */     }
/* 427 */     return text.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\extractor\ExcelExtractor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */