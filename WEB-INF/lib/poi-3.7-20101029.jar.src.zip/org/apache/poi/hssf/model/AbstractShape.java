/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherBoolProperty;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRGBProperty;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFComment;
/*     */ import org.apache.poi.hssf.usermodel.HSSFPolygon;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFTextbox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractShape
/*     */ {
/*     */   public static AbstractShape createShape(HSSFShape hssfShape, int shapeId)
/*     */   {
/*     */     AbstractShape shape;
/*  39 */     if ((hssfShape instanceof HSSFComment))
/*     */     {
/*  41 */       shape = new CommentShape((HSSFComment)hssfShape, shapeId);
/*     */     } else { AbstractShape shape;
/*  43 */       if ((hssfShape instanceof HSSFTextbox))
/*     */       {
/*  45 */         shape = new TextboxShape((HSSFTextbox)hssfShape, shapeId);
/*     */       } else { AbstractShape shape;
/*  47 */         if ((hssfShape instanceof HSSFPolygon))
/*     */         {
/*  49 */           shape = new PolygonShape((HSSFPolygon)hssfShape, shapeId);
/*     */         }
/*  51 */         else if ((hssfShape instanceof HSSFSimpleShape))
/*     */         {
/*  53 */           HSSFSimpleShape simpleShape = (HSSFSimpleShape)hssfShape;
/*  54 */           AbstractShape shape; switch (simpleShape.getShapeType())
/*     */           {
/*     */           case 8: 
/*  57 */             shape = new PictureShape(simpleShape, shapeId);
/*  58 */             break;
/*     */           case 1: 
/*  60 */             shape = new LineShape(simpleShape, shapeId);
/*  61 */             break;
/*     */           case 2: 
/*     */           case 3: 
/*  64 */             shape = new SimpleFilledShape(simpleShape, shapeId);
/*  65 */             break;
/*     */           case 20: 
/*  67 */             shape = new ComboboxShape(simpleShape, shapeId);
/*  68 */             break;
/*     */           default: 
/*  70 */             throw new IllegalArgumentException("Do not know how to handle this type of shape");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  75 */           throw new IllegalArgumentException("Unknown shape type"); } } }
/*     */     AbstractShape shape;
/*  77 */     EscherSpRecord sp = shape.getSpContainer().getChildById((short)61450);
/*  78 */     if (hssfShape.getParent() != null)
/*  79 */       sp.setFlags(sp.getFlags() | 0x2);
/*  80 */     return shape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract EscherContainerRecord getSpContainer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ObjRecord getObjRecord();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EscherRecord createAnchor(HSSFAnchor userAnchor)
/*     */   {
/* 106 */     return ConvertAnchor.createAnchor(userAnchor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int addStandardOptions(HSSFShape shape, EscherOptRecord opt)
/*     */   {
/* 119 */     opt.addEscherProperty(new EscherBoolProperty((short)191, 524288));
/*     */     
/* 121 */     if (shape.isNoFill())
/*     */     {
/*     */ 
/* 124 */       opt.addEscherProperty(new EscherBoolProperty((short)447, 1114112));
/*     */     }
/*     */     else
/*     */     {
/* 128 */       opt.addEscherProperty(new EscherBoolProperty((short)447, 65536));
/*     */     }
/* 130 */     opt.addEscherProperty(new EscherRGBProperty((short)385, shape.getFillColor()));
/* 131 */     opt.addEscherProperty(new EscherBoolProperty((short)959, 524288));
/* 132 */     opt.addEscherProperty(new EscherRGBProperty((short)448, shape.getLineStyleColor()));
/* 133 */     int options = 5;
/* 134 */     if (shape.getLineWidth() != 9525)
/*     */     {
/* 136 */       opt.addEscherProperty(new EscherSimpleProperty((short)459, shape.getLineWidth()));
/* 137 */       options++;
/*     */     }
/* 139 */     if (shape.getLineStyle() != 0)
/*     */     {
/* 141 */       opt.addEscherProperty(new EscherSimpleProperty((short)462, shape.getLineStyle()));
/* 142 */       opt.addEscherProperty(new EscherSimpleProperty((short)471, 0));
/* 143 */       if (shape.getLineStyle() == -1) {
/* 144 */         opt.addEscherProperty(new EscherBoolProperty((short)511, 524288));
/*     */       } else
/* 146 */         opt.addEscherProperty(new EscherBoolProperty((short)511, 524296));
/* 147 */       options += 3;
/*     */     }
/* 149 */     opt.sortProperties();
/* 150 */     return options;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\AbstractShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */