/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherBoolProperty;
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.EndSubRecord;
/*     */ import org.apache.poi.hssf.record.LbsDataSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboboxShape
/*     */   extends AbstractShape
/*     */ {
/*     */   private EscherContainerRecord spContainer;
/*     */   private ObjRecord objRecord;
/*     */   
/*     */   ComboboxShape(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  42 */     this.spContainer = createSpContainer(hssfShape, shapeId);
/*  43 */     this.objRecord = createObjRecord(hssfShape, shapeId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ObjRecord createObjRecord(HSSFSimpleShape shape, int shapeId)
/*     */   {
/*  50 */     ObjRecord obj = new ObjRecord();
/*  51 */     CommonObjectDataSubRecord c = new CommonObjectDataSubRecord();
/*  52 */     c.setObjectType((short)20);
/*  53 */     c.setObjectId(shapeId);
/*  54 */     c.setLocked(true);
/*  55 */     c.setPrintable(false);
/*  56 */     c.setAutofill(true);
/*  57 */     c.setAutoline(false);
/*     */     
/*  59 */     LbsDataSubRecord l = LbsDataSubRecord.newAutoFilterInstance();
/*     */     
/*  61 */     EndSubRecord e = new EndSubRecord();
/*     */     
/*  63 */     obj.addSubRecord(c);
/*  64 */     obj.addSubRecord(l);
/*  65 */     obj.addSubRecord(e);
/*     */     
/*  67 */     return obj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private EscherContainerRecord createSpContainer(HSSFSimpleShape shape, int shapeId)
/*     */   {
/*  74 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/*  75 */     EscherSpRecord sp = new EscherSpRecord();
/*  76 */     EscherOptRecord opt = new EscherOptRecord();
/*  77 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*     */     
/*  79 */     spContainer.setRecordId((short)61444);
/*  80 */     spContainer.setOptions((short)15);
/*  81 */     sp.setRecordId((short)61450);
/*  82 */     sp.setOptions((short)3218);
/*     */     
/*  84 */     sp.setShapeId(shapeId);
/*  85 */     sp.setFlags(2560);
/*  86 */     opt.setRecordId((short)61451);
/*  87 */     opt.addEscherProperty(new EscherBoolProperty((short)127, 17039620));
/*  88 */     opt.addEscherProperty(new EscherBoolProperty((short)191, 524296));
/*  89 */     opt.addEscherProperty(new EscherBoolProperty((short)511, 524288));
/*  90 */     opt.addEscherProperty(new EscherSimpleProperty((short)959, 131072));
/*     */     
/*  92 */     HSSFClientAnchor userAnchor = (HSSFClientAnchor)shape.getAnchor();
/*  93 */     userAnchor.setAnchorType(1);
/*  94 */     EscherRecord anchor = createAnchor(userAnchor);
/*  95 */     clientData.setRecordId((short)61457);
/*  96 */     clientData.setOptions((short)0);
/*     */     
/*  98 */     spContainer.addChildRecord(sp);
/*  99 */     spContainer.addChildRecord(opt);
/* 100 */     spContainer.addChildRecord(anchor);
/* 101 */     spContainer.addChildRecord(clientData);
/*     */     
/* 103 */     return spContainer;
/*     */   }
/*     */   
/*     */   public EscherContainerRecord getSpContainer() {
/* 107 */     return this.spContainer;
/*     */   }
/*     */   
/*     */   public ObjRecord getObjRecord() {
/* 111 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\ComboboxShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */