/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherProperty;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.NoteRecord;
/*     */ import org.apache.poi.hssf.record.NoteStructureSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.record.SubRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFComment;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CommentShape
/*     */   extends TextboxShape
/*     */ {
/*     */   private NoteRecord _note;
/*     */   
/*     */   public CommentShape(HSSFComment hssfShape, int shapeId)
/*     */   {
/*  54 */     super(hssfShape, shapeId);
/*     */     
/*  56 */     this._note = createNoteRecord(hssfShape, shapeId);
/*     */     
/*  58 */     ObjRecord obj = getObjRecord();
/*  59 */     List<SubRecord> records = obj.getSubRecords();
/*  60 */     int cmoIdx = 0;
/*  61 */     for (int i = 0; i < records.size(); i++) {
/*  62 */       Object r = records.get(i);
/*     */       
/*  64 */       if ((r instanceof CommonObjectDataSubRecord))
/*     */       {
/*  66 */         CommonObjectDataSubRecord cmo = (CommonObjectDataSubRecord)r;
/*  67 */         cmo.setAutofill(false);
/*  68 */         cmoIdx = i;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  73 */     NoteStructureSubRecord u = new NoteStructureSubRecord();
/*  74 */     obj.addSubRecord(cmoIdx + 1, u);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NoteRecord createNoteRecord(HSSFComment shape, int shapeId)
/*     */   {
/*  83 */     NoteRecord note = new NoteRecord();
/*  84 */     note.setColumn(shape.getColumn());
/*  85 */     note.setRow(shape.getRow());
/*  86 */     note.setFlags((short)(shape.isVisible() ? 2 : 0));
/*  87 */     note.setShapeId(shapeId);
/*  88 */     note.setAuthor(shape.getAuthor() == null ? "" : shape.getAuthor());
/*  89 */     return note;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int addStandardOptions(HSSFShape shape, EscherOptRecord opt)
/*     */   {
/* 103 */     super.addStandardOptions(shape, opt);
/*     */     
/*     */ 
/* 106 */     List<EscherProperty> props = opt.getEscherProperties();
/* 107 */     for (Iterator<EscherProperty> iterator = props.iterator(); iterator.hasNext();) {
/* 108 */       EscherProperty prop = (EscherProperty)iterator.next();
/* 109 */       switch (prop.getId()) {
/*     */       case 129: 
/*     */       case 130: 
/*     */       case 131: 
/*     */       case 132: 
/*     */       case 387: 
/*     */       case 448: 
/*     */       case 959: 
/* 117 */         iterator.remove();
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 122 */     HSSFComment comment = (HSSFComment)shape;
/* 123 */     opt.addEscherProperty(new EscherSimpleProperty((short)959, comment.isVisible() ? 655360 : 655362));
/* 124 */     opt.addEscherProperty(new EscherSimpleProperty((short)575, 196611));
/* 125 */     opt.addEscherProperty(new EscherSimpleProperty((short)513, 0));
/* 126 */     opt.sortProperties();
/* 127 */     return opt.getEscherProperties().size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NoteRecord getNoteRecord()
/*     */   {
/* 137 */     return this._note;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\CommentShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */