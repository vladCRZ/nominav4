/*    */ package org.apache.poi.hssf.model;
/*    */ 
/*    */ import org.apache.poi.ddf.EscherChildAnchorRecord;
/*    */ import org.apache.poi.ddf.EscherClientAnchorRecord;
/*    */ import org.apache.poi.ddf.EscherRecord;
/*    */ import org.apache.poi.hssf.usermodel.HSSFAnchor;
/*    */ import org.apache.poi.hssf.usermodel.HSSFChildAnchor;
/*    */ import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConvertAnchor
/*    */ {
/*    */   public static EscherRecord createAnchor(HSSFAnchor userAnchor)
/*    */   {
/* 34 */     if ((userAnchor instanceof HSSFClientAnchor))
/*    */     {
/* 36 */       HSSFClientAnchor a = (HSSFClientAnchor)userAnchor;
/*    */       
/* 38 */       EscherClientAnchorRecord anchor = new EscherClientAnchorRecord();
/* 39 */       anchor.setRecordId((short)61456);
/* 40 */       anchor.setOptions((short)0);
/* 41 */       anchor.setFlag((short)a.getAnchorType());
/* 42 */       anchor.setCol1((short)Math.min(a.getCol1(), a.getCol2()));
/* 43 */       anchor.setDx1((short)a.getDx1());
/* 44 */       anchor.setRow1((short)Math.min(a.getRow1(), a.getRow2()));
/* 45 */       anchor.setDy1((short)a.getDy1());
/*    */       
/* 47 */       anchor.setCol2((short)Math.max(a.getCol1(), a.getCol2()));
/* 48 */       anchor.setDx2((short)a.getDx2());
/* 49 */       anchor.setRow2((short)Math.max(a.getRow1(), a.getRow2()));
/* 50 */       anchor.setDy2((short)a.getDy2());
/* 51 */       return anchor;
/*    */     }
/* 53 */     HSSFChildAnchor a = (HSSFChildAnchor)userAnchor;
/* 54 */     EscherChildAnchorRecord anchor = new EscherChildAnchorRecord();
/* 55 */     anchor.setRecordId((short)61455);
/* 56 */     anchor.setOptions((short)0);
/* 57 */     anchor.setDx1((short)Math.min(a.getDx1(), a.getDx2()));
/* 58 */     anchor.setDy1((short)Math.min(a.getDy1(), a.getDy2()));
/* 59 */     anchor.setDx2((short)Math.max(a.getDx2(), a.getDx1()));
/* 60 */     anchor.setDy2((short)Math.max(a.getDy2(), a.getDy1()));
/* 61 */     return anchor;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\ConvertAnchor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */