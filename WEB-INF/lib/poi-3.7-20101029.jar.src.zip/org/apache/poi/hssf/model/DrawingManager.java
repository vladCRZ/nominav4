/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.ddf.EscherDgRecord;
/*     */ import org.apache.poi.ddf.EscherDggRecord;
/*     */ import org.apache.poi.ddf.EscherDggRecord.FileIdCluster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawingManager
/*     */ {
/*     */   EscherDggRecord dgg;
/*  34 */   Map dgMap = new HashMap();
/*     */   
/*     */   public DrawingManager(EscherDggRecord dgg)
/*     */   {
/*  38 */     this.dgg = dgg;
/*     */   }
/*     */   
/*     */   public EscherDgRecord createDgRecord()
/*     */   {
/*  43 */     EscherDgRecord dg = new EscherDgRecord();
/*  44 */     dg.setRecordId((short)61448);
/*  45 */     short dgId = findNewDrawingGroupId();
/*  46 */     dg.setOptions((short)(dgId << 4));
/*  47 */     dg.setNumShapes(0);
/*  48 */     dg.setLastMSOSPID(-1);
/*  49 */     this.dgg.addCluster(dgId, 0);
/*  50 */     this.dgg.setDrawingsSaved(this.dgg.getDrawingsSaved() + 1);
/*  51 */     this.dgMap.put(Short.valueOf(dgId), dg);
/*  52 */     return dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int allocateShapeId(short drawingGroupId)
/*     */   {
/*  63 */     EscherDgRecord dg = (EscherDgRecord)this.dgMap.get(Short.valueOf(drawingGroupId));
/*  64 */     int lastShapeId = dg.getLastMSOSPID();
/*     */     
/*     */ 
/*     */ 
/*  68 */     int newShapeId = 0;
/*  69 */     if (lastShapeId % 1024 == 1023)
/*     */     {
/*     */ 
/*     */ 
/*  73 */       newShapeId = findFreeSPIDBlock();
/*     */       
/*  75 */       this.dgg.addCluster(drawingGroupId, 1);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  81 */       for (int i = 0; i < this.dgg.getFileIdClusters().length; i++)
/*     */       {
/*  83 */         EscherDggRecord.FileIdCluster c = this.dgg.getFileIdClusters()[i];
/*  84 */         if (c.getDrawingGroupId() == drawingGroupId)
/*     */         {
/*  86 */           if (c.getNumShapeIdsUsed() != 1024)
/*     */           {
/*     */ 
/*  89 */             c.incrementShapeId();
/*     */           }
/*     */         }
/*     */         
/*  93 */         if (dg.getLastMSOSPID() == -1)
/*     */         {
/*  95 */           newShapeId = findFreeSPIDBlock();
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 100 */           newShapeId = dg.getLastMSOSPID() + 1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 105 */     this.dgg.setNumShapesSaved(this.dgg.getNumShapesSaved() + 1);
/*     */     
/* 107 */     if (newShapeId >= this.dgg.getShapeIdMax())
/*     */     {
/*     */ 
/*     */ 
/* 111 */       this.dgg.setShapeIdMax(newShapeId + 1);
/*     */     }
/*     */     
/* 114 */     dg.setLastMSOSPID(newShapeId);
/*     */     
/* 116 */     dg.incrementShapeCount();
/*     */     
/*     */ 
/* 119 */     return newShapeId;
/*     */   }
/*     */   
/*     */ 
/*     */   short findNewDrawingGroupId()
/*     */   {
/* 125 */     short dgId = 1;
/* 126 */     while (drawingGroupExists(dgId))
/* 127 */       dgId = (short)(dgId + 1);
/* 128 */     return dgId;
/*     */   }
/*     */   
/*     */   boolean drawingGroupExists(short dgId)
/*     */   {
/* 133 */     for (int i = 0; i < this.dgg.getFileIdClusters().length; i++)
/*     */     {
/* 135 */       if (this.dgg.getFileIdClusters()[i].getDrawingGroupId() == dgId)
/* 136 */         return true;
/*     */     }
/* 138 */     return false;
/*     */   }
/*     */   
/*     */   int findFreeSPIDBlock()
/*     */   {
/* 143 */     int max = this.dgg.getShapeIdMax();
/* 144 */     int next = (max / 1024 + 1) * 1024;
/* 145 */     return next;
/*     */   }
/*     */   
/*     */   public EscherDggRecord getDgg()
/*     */   {
/* 150 */     return this.dgg;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\DrawingManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */