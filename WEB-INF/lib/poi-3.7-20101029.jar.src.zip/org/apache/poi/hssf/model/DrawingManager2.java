/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.ddf.EscherDgRecord;
/*     */ import org.apache.poi.ddf.EscherDggRecord;
/*     */ import org.apache.poi.ddf.EscherDggRecord.FileIdCluster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawingManager2
/*     */ {
/*     */   EscherDggRecord dgg;
/*  35 */   List drawingGroups = new ArrayList();
/*     */   
/*     */ 
/*     */   public DrawingManager2(EscherDggRecord dgg)
/*     */   {
/*  40 */     this.dgg = dgg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearDrawingGroups()
/*     */   {
/*  47 */     this.drawingGroups.clear();
/*     */   }
/*     */   
/*     */   public EscherDgRecord createDgRecord()
/*     */   {
/*  52 */     EscherDgRecord dg = new EscherDgRecord();
/*  53 */     dg.setRecordId((short)61448);
/*  54 */     short dgId = findNewDrawingGroupId();
/*  55 */     dg.setOptions((short)(dgId << 4));
/*  56 */     dg.setNumShapes(0);
/*  57 */     dg.setLastMSOSPID(-1);
/*  58 */     this.drawingGroups.add(dg);
/*  59 */     this.dgg.addCluster(dgId, 0);
/*  60 */     this.dgg.setDrawingsSaved(this.dgg.getDrawingsSaved() + 1);
/*  61 */     return dg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int allocateShapeId(short drawingGroupId)
/*     */   {
/*  71 */     EscherDgRecord dg = getDrawingGroup(drawingGroupId);
/*  72 */     return allocateShapeId(drawingGroupId, dg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int allocateShapeId(short drawingGroupId, EscherDgRecord dg)
/*     */   {
/*  82 */     this.dgg.setNumShapesSaved(this.dgg.getNumShapesSaved() + 1);
/*     */     
/*     */ 
/*  85 */     for (int i = 0; i < this.dgg.getFileIdClusters().length; i++)
/*     */     {
/*  87 */       EscherDggRecord.FileIdCluster c = this.dgg.getFileIdClusters()[i];
/*  88 */       if ((c.getDrawingGroupId() == drawingGroupId) && (c.getNumShapeIdsUsed() != 1024))
/*     */       {
/*  90 */         int result = c.getNumShapeIdsUsed() + 1024 * (i + 1);
/*  91 */         c.incrementShapeId();
/*  92 */         dg.setNumShapes(dg.getNumShapes() + 1);
/*  93 */         dg.setLastMSOSPID(result);
/*  94 */         if (result >= this.dgg.getShapeIdMax())
/*  95 */           this.dgg.setShapeIdMax(result + 1);
/*  96 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 101 */     this.dgg.addCluster(drawingGroupId, 0);
/* 102 */     this.dgg.getFileIdClusters()[(this.dgg.getFileIdClusters().length - 1)].incrementShapeId();
/* 103 */     dg.setNumShapes(dg.getNumShapes() + 1);
/* 104 */     int result = 1024 * this.dgg.getFileIdClusters().length;
/* 105 */     dg.setLastMSOSPID(result);
/* 106 */     if (result >= this.dgg.getShapeIdMax())
/* 107 */       this.dgg.setShapeIdMax(result + 1);
/* 108 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   short findNewDrawingGroupId()
/*     */   {
/* 117 */     short dgId = 1;
/* 118 */     while (drawingGroupExists(dgId))
/* 119 */       dgId = (short)(dgId + 1);
/* 120 */     return dgId;
/*     */   }
/*     */   
/*     */   EscherDgRecord getDrawingGroup(int drawingGroupId)
/*     */   {
/* 125 */     return (EscherDgRecord)this.drawingGroups.get(drawingGroupId - 1);
/*     */   }
/*     */   
/*     */   boolean drawingGroupExists(short dgId)
/*     */   {
/* 130 */     for (int i = 0; i < this.dgg.getFileIdClusters().length; i++)
/*     */     {
/* 132 */       if (this.dgg.getFileIdClusters()[i].getDrawingGroupId() == dgId)
/* 133 */         return true;
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   int findFreeSPIDBlock()
/*     */   {
/* 140 */     int max = this.dgg.getShapeIdMax();
/* 141 */     int next = (max / 1024 + 1) * 1024;
/* 142 */     return next;
/*     */   }
/*     */   
/*     */   public EscherDggRecord getDgg()
/*     */   {
/* 147 */     return this.dgg;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\DrawingManager2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */