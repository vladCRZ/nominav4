/*    */ package org.apache.poi.hssf.model;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.Ptg;
/*    */ import org.apache.poi.hssf.usermodel.HSSFEvaluationWorkbook;
/*    */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*    */ import org.apache.poi.ss.formula.FormulaParseException;
/*    */ import org.apache.poi.ss.formula.FormulaParser;
/*    */ import org.apache.poi.ss.formula.FormulaParsingWorkbook;
/*    */ import org.apache.poi.ss.formula.FormulaRenderer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HSSFFormulaParser
/*    */ {
/*    */   private static FormulaParsingWorkbook createParsingWorkbook(HSSFWorkbook book)
/*    */   {
/* 37 */     return HSSFEvaluationWorkbook.create(book);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Ptg[] parse(String formula, HSSFWorkbook workbook)
/*    */     throws FormulaParseException
/*    */   {
/* 48 */     return parse(formula, workbook, 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Ptg[] parse(String formula, HSSFWorkbook workbook, int formulaType)
/*    */     throws FormulaParseException
/*    */   {
/* 57 */     return parse(formula, workbook, formulaType, -1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Ptg[] parse(String formula, HSSFWorkbook workbook, int formulaType, int sheetIndex)
/*    */     throws FormulaParseException
/*    */   {
/* 72 */     return FormulaParser.parse(formula, createParsingWorkbook(workbook), formulaType, sheetIndex);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String toFormulaString(HSSFWorkbook book, Ptg[] ptgs)
/*    */   {
/* 83 */     return FormulaRenderer.toFormulaString(HSSFEvaluationWorkbook.create(book), ptgs);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\HSSFFormulaParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */