/*      */ package org.apache.poi.hssf.model;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.apache.poi.hssf.record.BOFRecord;
/*      */ import org.apache.poi.hssf.record.CalcCountRecord;
/*      */ import org.apache.poi.hssf.record.CalcModeRecord;
/*      */ import org.apache.poi.hssf.record.CellValueRecordInterface;
/*      */ import org.apache.poi.hssf.record.ColumnInfoRecord;
/*      */ import org.apache.poi.hssf.record.DefaultColWidthRecord;
/*      */ import org.apache.poi.hssf.record.DefaultRowHeightRecord;
/*      */ import org.apache.poi.hssf.record.DeltaRecord;
/*      */ import org.apache.poi.hssf.record.DimensionsRecord;
/*      */ import org.apache.poi.hssf.record.DrawingRecord;
/*      */ import org.apache.poi.hssf.record.EOFRecord;
/*      */ import org.apache.poi.hssf.record.EscherAggregate;
/*      */ import org.apache.poi.hssf.record.GridsetRecord;
/*      */ import org.apache.poi.hssf.record.GutsRecord;
/*      */ import org.apache.poi.hssf.record.IterationRecord;
/*      */ import org.apache.poi.hssf.record.NoteRecord;
/*      */ import org.apache.poi.hssf.record.ObjRecord;
/*      */ import org.apache.poi.hssf.record.PaneRecord;
/*      */ import org.apache.poi.hssf.record.PrintGridlinesRecord;
/*      */ import org.apache.poi.hssf.record.PrintHeadersRecord;
/*      */ import org.apache.poi.hssf.record.Record;
/*      */ import org.apache.poi.hssf.record.RecordBase;
/*      */ import org.apache.poi.hssf.record.RefModeRecord;
/*      */ import org.apache.poi.hssf.record.RowRecord;
/*      */ import org.apache.poi.hssf.record.SCLRecord;
/*      */ import org.apache.poi.hssf.record.SaveRecalcRecord;
/*      */ import org.apache.poi.hssf.record.SelectionRecord;
/*      */ import org.apache.poi.hssf.record.UncalcedRecord;
/*      */ import org.apache.poi.hssf.record.WSBoolRecord;
/*      */ import org.apache.poi.hssf.record.WindowTwoRecord;
/*      */ import org.apache.poi.hssf.record.aggregates.ChartSubstreamRecordAggregate;
/*      */ import org.apache.poi.hssf.record.aggregates.ColumnInfoRecordsAggregate;
/*      */ import org.apache.poi.hssf.record.aggregates.ConditionalFormattingTable;
/*      */ import org.apache.poi.hssf.record.aggregates.CustomViewSettingsRecordAggregate;
/*      */ import org.apache.poi.hssf.record.aggregates.DataValidityTable;
/*      */ import org.apache.poi.hssf.record.aggregates.MergedCellsTable;
/*      */ import org.apache.poi.hssf.record.aggregates.PageSettingsBlock;
/*      */ import org.apache.poi.hssf.record.aggregates.RecordAggregate;
/*      */ import org.apache.poi.hssf.record.aggregates.RecordAggregate.PositionTrackingVisitor;
/*      */ import org.apache.poi.hssf.record.aggregates.RecordAggregate.RecordVisitor;
/*      */ import org.apache.poi.hssf.record.aggregates.RowRecordsAggregate;
/*      */ import org.apache.poi.hssf.record.aggregates.WorksheetProtectionBlock;
/*      */ import org.apache.poi.hssf.record.formula.FormulaShifter;
/*      */ import org.apache.poi.hssf.util.PaneInformation;
/*      */ import org.apache.poi.ss.util.CellRangeAddress;
/*      */ import org.apache.poi.util.Internal;
/*      */ import org.apache.poi.util.POILogFactory;
/*      */ import org.apache.poi.util.POILogger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Internal
/*      */ public final class InternalSheet
/*      */ {
/*      */   public static final short LeftMargin = 0;
/*      */   public static final short RightMargin = 1;
/*      */   public static final short TopMargin = 2;
/*      */   public static final short BottomMargin = 3;
/*  107 */   private static POILogger log = POILogFactory.getLogger(InternalSheet.class);
/*      */   
/*      */   private List<RecordBase> _records;
/*  110 */   protected PrintGridlinesRecord printGridlines = null;
/*  111 */   protected GridsetRecord gridset = null;
/*      */   private GutsRecord _gutsRecord;
/*  113 */   protected DefaultColWidthRecord defaultcolwidth = null;
/*  114 */   protected DefaultRowHeightRecord defaultrowheight = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private PageSettingsBlock _psBlock;
/*      */   
/*      */ 
/*  121 */   private final WorksheetProtectionBlock _protectionBlock = new WorksheetProtectionBlock();
/*      */   
/*  123 */   protected WindowTwoRecord windowTwo = null;
/*  124 */   protected SelectionRecord _selection = null;
/*      */   
/*      */   private final MergedCellsTable _mergedCellsTable;
/*      */   
/*      */   ColumnInfoRecordsAggregate _columnInfos;
/*      */   
/*      */   private DimensionsRecord _dimensions;
/*      */   
/*      */   protected final RowRecordsAggregate _rowsAggregate;
/*  133 */   private DataValidityTable _dataValidityTable = null;
/*      */   
/*      */   private ConditionalFormattingTable condFormatting;
/*  136 */   private Iterator<RowRecord> rowRecIterator = null;
/*      */   
/*      */ 
/*  139 */   protected boolean _isUncalced = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte PANE_LOWER_RIGHT = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte PANE_UPPER_RIGHT = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte PANE_LOWER_LEFT = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte PANE_UPPER_LEFT = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  162 */   public static InternalSheet createSheet(RecordStream rs) { return new InternalSheet(rs); }
/*      */   
/*      */   private InternalSheet(RecordStream rs) {
/*  165 */     this._mergedCellsTable = new MergedCellsTable();
/*  166 */     RowRecordsAggregate rra = null;
/*      */     
/*  168 */     List<RecordBase> records = new ArrayList(128);
/*  169 */     this._records = records;
/*  170 */     int dimsloc = -1;
/*      */     
/*  172 */     if (rs.peekNextSid() != 2057) {
/*  173 */       throw new RuntimeException("BOF record expected");
/*      */     }
/*  175 */     BOFRecord bof = (BOFRecord)rs.getNext();
/*  176 */     if (bof.getType() != 16) {}
/*      */     
/*      */ 
/*  179 */     records.add(bof);
/*  180 */     while (rs.hasNext()) {
/*  181 */       int recSid = rs.peekNextSid();
/*      */       
/*  183 */       if (recSid == 432) {
/*  184 */         this.condFormatting = new ConditionalFormattingTable(rs);
/*  185 */         records.add(this.condFormatting);
/*      */ 
/*      */ 
/*      */       }
/*  189 */       else if (recSid == 125) {
/*  190 */         this._columnInfos = new ColumnInfoRecordsAggregate(rs);
/*  191 */         records.add(this._columnInfos);
/*      */ 
/*      */       }
/*  194 */       else if (recSid == 434) {
/*  195 */         this._dataValidityTable = new DataValidityTable(rs);
/*  196 */         records.add(this._dataValidityTable);
/*      */ 
/*      */ 
/*      */       }
/*  200 */       else if (RecordOrderer.isRowBlockRecord(recSid))
/*      */       {
/*  202 */         if (rra != null) {
/*  203 */           throw new RuntimeException("row/cell records found in the wrong place");
/*      */         }
/*  205 */         RowBlocksReader rbr = new RowBlocksReader(rs);
/*  206 */         this._mergedCellsTable.addRecords(rbr.getLooseMergedCells());
/*  207 */         rra = new RowRecordsAggregate(rbr.getPlainRecordStream(), rbr.getSharedFormulaManager());
/*  208 */         records.add(rra);
/*      */ 
/*      */ 
/*      */       }
/*  212 */       else if (CustomViewSettingsRecordAggregate.isBeginRecord(recSid))
/*      */       {
/*      */ 
/*  215 */         records.add(new CustomViewSettingsRecordAggregate(rs));
/*      */ 
/*      */ 
/*      */       }
/*  219 */       else if (PageSettingsBlock.isComponentRecord(recSid)) {
/*  220 */         if (this._psBlock == null)
/*      */         {
/*  222 */           this._psBlock = new PageSettingsBlock(rs);
/*  223 */           records.add(this._psBlock);
/*      */         }
/*      */         else {
/*  226 */           this._psBlock.addLateRecords(rs);
/*      */         }
/*      */         
/*      */ 
/*  230 */         this._psBlock.positionRecords(records);
/*      */ 
/*      */ 
/*      */       }
/*  234 */       else if (WorksheetProtectionBlock.isComponentRecord(recSid)) {
/*  235 */         this._protectionBlock.addRecords(rs);
/*      */ 
/*      */ 
/*      */       }
/*  239 */       else if (recSid == 229)
/*      */       {
/*  241 */         this._mergedCellsTable.read(rs);
/*      */ 
/*      */ 
/*      */       }
/*  245 */       else if (recSid == 2057) {
/*  246 */         ChartSubstreamRecordAggregate chartAgg = new ChartSubstreamRecordAggregate(rs);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  251 */         spillAggregate(chartAgg, records);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  256 */         Record rec = rs.getNext();
/*  257 */         if (recSid != 523)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  264 */           if (recSid == 94)
/*      */           {
/*  266 */             this._isUncalced = true;
/*      */ 
/*      */ 
/*      */           }
/*  270 */           else if ((recSid == 2152) || (recSid == 2151))
/*      */           {
/*  272 */             records.add(rec);
/*      */           }
/*      */           else
/*      */           {
/*  276 */             if (recSid == 10) {
/*  277 */               records.add(rec);
/*  278 */               break;
/*      */             }
/*      */             
/*  281 */             if (recSid == 512)
/*      */             {
/*      */ 
/*  284 */               if (this._columnInfos == null)
/*      */               {
/*  286 */                 this._columnInfos = new ColumnInfoRecordsAggregate();
/*  287 */                 records.add(this._columnInfos);
/*      */               }
/*      */               
/*  290 */               this._dimensions = ((DimensionsRecord)rec);
/*  291 */               dimsloc = records.size();
/*      */             }
/*  293 */             else if (recSid == 85)
/*      */             {
/*  295 */               this.defaultcolwidth = ((DefaultColWidthRecord)rec);
/*      */             }
/*  297 */             else if (recSid == 549)
/*      */             {
/*  299 */               this.defaultrowheight = ((DefaultRowHeightRecord)rec);
/*      */             }
/*  301 */             else if (recSid == 43)
/*      */             {
/*  303 */               this.printGridlines = ((PrintGridlinesRecord)rec);
/*      */             }
/*  305 */             else if (recSid == 130)
/*      */             {
/*  307 */               this.gridset = ((GridsetRecord)rec);
/*      */             }
/*  309 */             else if (recSid == 29)
/*      */             {
/*  311 */               this._selection = ((SelectionRecord)rec);
/*      */             }
/*  313 */             else if (recSid == 574)
/*      */             {
/*  315 */               this.windowTwo = ((WindowTwoRecord)rec);
/*      */             }
/*  317 */             else if (recSid == 128)
/*      */             {
/*  319 */               this._gutsRecord = ((GutsRecord)rec);
/*      */             }
/*      */             
/*  322 */             records.add(rec);
/*      */           } } } }
/*  324 */     if (this.windowTwo == null) {
/*  325 */       throw new RuntimeException("WINDOW2 was not found");
/*      */     }
/*  327 */     if (this._dimensions == null)
/*      */     {
/*      */ 
/*  330 */       if (rra == null)
/*      */       {
/*      */ 
/*      */ 
/*  334 */         rra = new RowRecordsAggregate();
/*      */       } else {
/*  336 */         log.log(POILogger.WARN, "DIMENSION record not found even though row/cells present");
/*      */       }
/*      */       
/*  339 */       dimsloc = findFirstRecordLocBySid((short)574);
/*  340 */       this._dimensions = rra.createDimensions();
/*  341 */       records.add(dimsloc, this._dimensions);
/*      */     }
/*  343 */     if (rra == null) {
/*  344 */       rra = new RowRecordsAggregate();
/*  345 */       records.add(dimsloc + 1, rra);
/*      */     }
/*  347 */     this._rowsAggregate = rra;
/*      */     
/*  349 */     RecordOrderer.addNewSheetRecord(records, this._mergedCellsTable);
/*  350 */     RecordOrderer.addNewSheetRecord(records, this._protectionBlock);
/*  351 */     if (log.check(POILogger.DEBUG))
/*  352 */       log.log(POILogger.DEBUG, "sheet createSheet (existing file) exited");
/*      */   }
/*      */   
/*  355 */   private static void spillAggregate(RecordAggregate ra, List<RecordBase> recs) { ra.visitContainedRecords(new RecordAggregate.RecordVisitor() {
/*      */       public void visitRecord(Record r) {
/*  357 */         this.val$recs.add(r);
/*      */       }
/*      */     }); }
/*      */   
/*      */   private static final class RecordCloner implements RecordAggregate.RecordVisitor
/*      */   {
/*      */     private final List<RecordBase> _destList;
/*      */     
/*      */     public RecordCloner(List<RecordBase> destList) {
/*  366 */       this._destList = destList;
/*      */     }
/*      */     
/*  369 */     public void visitRecord(Record r) { this._destList.add((RecordBase)r.clone()); }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InternalSheet cloneSheet()
/*      */   {
/*  381 */     List<RecordBase> clonedRecords = new ArrayList(this._records.size());
/*  382 */     for (int i = 0; i < this._records.size(); i++) {
/*  383 */       RecordBase rb = (RecordBase)this._records.get(i);
/*  384 */       if ((rb instanceof RecordAggregate)) {
/*  385 */         ((RecordAggregate)rb).visitContainedRecords(new RecordCloner(clonedRecords));
/*      */       }
/*      */       else {
/*  388 */         Record rec = (Record)((Record)rb).clone();
/*  389 */         clonedRecords.add(rec);
/*      */       } }
/*  391 */     return createSheet(new RecordStream(clonedRecords, 0));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  402 */   public static InternalSheet createSheet() { return new InternalSheet(); }
/*      */   
/*      */   private InternalSheet() {
/*  405 */     this._mergedCellsTable = new MergedCellsTable();
/*  406 */     List<RecordBase> records = new ArrayList(32);
/*      */     
/*  408 */     if (log.check(POILogger.DEBUG)) {
/*  409 */       log.log(POILogger.DEBUG, "Sheet createsheet from scratch called");
/*      */     }
/*  411 */     records.add(createBOF());
/*      */     
/*  413 */     records.add(createCalcMode());
/*  414 */     records.add(createCalcCount());
/*  415 */     records.add(createRefMode());
/*  416 */     records.add(createIteration());
/*  417 */     records.add(createDelta());
/*  418 */     records.add(createSaveRecalc());
/*  419 */     records.add(createPrintHeaders());
/*  420 */     this.printGridlines = createPrintGridlines();
/*  421 */     records.add(this.printGridlines);
/*  422 */     this.gridset = createGridset();
/*  423 */     records.add(this.gridset);
/*  424 */     this._gutsRecord = createGuts();
/*  425 */     records.add(this._gutsRecord);
/*  426 */     this.defaultrowheight = createDefaultRowHeight();
/*  427 */     records.add(this.defaultrowheight);
/*  428 */     records.add(createWSBool());
/*      */     
/*      */ 
/*  431 */     this._psBlock = new PageSettingsBlock();
/*  432 */     records.add(this._psBlock);
/*      */     
/*      */ 
/*  435 */     records.add(this._protectionBlock);
/*      */     
/*  437 */     this.defaultcolwidth = createDefaultColWidth();
/*  438 */     records.add(this.defaultcolwidth);
/*  439 */     ColumnInfoRecordsAggregate columns = new ColumnInfoRecordsAggregate();
/*  440 */     records.add(columns);
/*  441 */     this._columnInfos = columns;
/*  442 */     this._dimensions = createDimensions();
/*  443 */     records.add(this._dimensions);
/*  444 */     this._rowsAggregate = new RowRecordsAggregate();
/*  445 */     records.add(this._rowsAggregate);
/*      */     
/*  447 */     records.add(this.windowTwo = createWindowTwo());
/*  448 */     this._selection = createSelection();
/*  449 */     records.add(this._selection);
/*      */     
/*  451 */     records.add(this._mergedCellsTable);
/*  452 */     records.add(EOFRecord.instance);
/*      */     
/*  454 */     this._records = records;
/*  455 */     if (log.check(POILogger.DEBUG))
/*  456 */       log.log(POILogger.DEBUG, "Sheet createsheet from scratch exit");
/*      */   }
/*      */   
/*      */   public RowRecordsAggregate getRowsAggregate() {
/*  460 */     return this._rowsAggregate;
/*      */   }
/*      */   
/*      */   private MergedCellsTable getMergedRecords()
/*      */   {
/*  465 */     return this._mergedCellsTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFormulasAfterCellShift(FormulaShifter shifter, int externSheetIndex)
/*      */   {
/*  473 */     getRowsAggregate().updateFormulasAfterRowShift(shifter, externSheetIndex);
/*  474 */     if (this.condFormatting != null) {
/*  475 */       getConditionalFormattingTable().updateFormulasAfterCellShift(shifter, externSheetIndex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int addMergedRegion(int rowFrom, int colFrom, int rowTo, int colTo)
/*      */   {
/*  482 */     if (rowTo < rowFrom) {
/*  483 */       throw new IllegalArgumentException("The 'to' row (" + rowTo + ") must not be less than the 'from' row (" + rowFrom + ")");
/*      */     }
/*      */     
/*  486 */     if (colTo < colFrom) {
/*  487 */       throw new IllegalArgumentException("The 'to' col (" + colTo + ") must not be less than the 'from' col (" + colFrom + ")");
/*      */     }
/*      */     
/*      */ 
/*  491 */     MergedCellsTable mrt = getMergedRecords();
/*  492 */     mrt.addArea(rowFrom, colFrom, rowTo, colTo);
/*  493 */     return mrt.getNumberOfMergedRegions() - 1;
/*      */   }
/*      */   
/*      */   public void removeMergedRegion(int index)
/*      */   {
/*  498 */     MergedCellsTable mrt = getMergedRecords();
/*  499 */     if (index >= mrt.getNumberOfMergedRegions()) {
/*  500 */       return;
/*      */     }
/*  502 */     mrt.remove(index);
/*      */   }
/*      */   
/*      */   public CellRangeAddress getMergedRegionAt(int index)
/*      */   {
/*  507 */     MergedCellsTable mrt = getMergedRecords();
/*  508 */     if (index >= mrt.getNumberOfMergedRegions()) {
/*  509 */       return null;
/*      */     }
/*  511 */     return mrt.get(index);
/*      */   }
/*      */   
/*      */ 
/*  515 */   public int getNumMergedRegions() { return getMergedRecords().getNumberOfMergedRegions(); }
/*      */   
/*      */   public ConditionalFormattingTable getConditionalFormattingTable() {
/*  518 */     if (this.condFormatting == null) {
/*  519 */       this.condFormatting = new ConditionalFormattingTable();
/*  520 */       RecordOrderer.addNewSheetRecord(this._records, this.condFormatting);
/*      */     }
/*  522 */     return this.condFormatting;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDimensions(int firstrow, short firstcol, int lastrow, short lastcol)
/*      */   {
/*  535 */     if (log.check(POILogger.DEBUG))
/*      */     {
/*  537 */       log.log(POILogger.DEBUG, "Sheet.setDimensions");
/*  538 */       log.log(POILogger.DEBUG, "firstrow" + firstrow + "firstcol" + firstcol + "lastrow" + lastrow + "lastcol" + lastcol);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  544 */     this._dimensions.setFirstCol(firstcol);
/*  545 */     this._dimensions.setFirstRow(firstrow);
/*  546 */     this._dimensions.setLastCol(lastcol);
/*  547 */     this._dimensions.setLastRow(lastrow);
/*  548 */     if (log.check(POILogger.DEBUG)) {
/*  549 */       log.log(POILogger.DEBUG, "Sheet.setDimensions exiting");
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv, int offset) {
/*  554 */     RecordAggregate.PositionTrackingVisitor ptv = new RecordAggregate.PositionTrackingVisitor(rv, offset);
/*      */     
/*  556 */     boolean haveSerializedIndex = false;
/*      */     
/*  558 */     for (int k = 0; k < this._records.size(); k++) {
/*  559 */       RecordBase record = (RecordBase)this._records.get(k);
/*      */       
/*  561 */       if ((record instanceof RecordAggregate)) {
/*  562 */         RecordAggregate agg = (RecordAggregate)record;
/*  563 */         agg.visitContainedRecords(ptv);
/*      */       } else {
/*  565 */         ptv.visitRecord((Record)record);
/*      */       }
/*      */       
/*      */ 
/*  569 */       if (((record instanceof BOFRecord)) && 
/*  570 */         (!haveSerializedIndex)) {
/*  571 */         haveSerializedIndex = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  576 */         if (this._isUncalced) {
/*  577 */           ptv.visitRecord(new UncalcedRecord());
/*      */         }
/*      */         
/*      */ 
/*  581 */         if (this._rowsAggregate != null)
/*      */         {
/*  583 */           int initRecsSize = getSizeOfInitialSheetRecords(k);
/*  584 */           int currentPos = ptv.getPosition();
/*  585 */           ptv.visitRecord(this._rowsAggregate.createIndexRecord(currentPos, initRecsSize));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getSizeOfInitialSheetRecords(int bofRecordIndex)
/*      */   {
/*  598 */     int result = 0;
/*      */     
/*  600 */     for (int j = bofRecordIndex + 1; j < this._records.size(); j++) {
/*  601 */       RecordBase tmpRec = (RecordBase)this._records.get(j);
/*  602 */       if ((tmpRec instanceof RowRecordsAggregate)) {
/*      */         break;
/*      */       }
/*  605 */       result += tmpRec.getRecordSize();
/*      */     }
/*  607 */     if (this._isUncalced) {
/*  608 */       result += UncalcedRecord.getStaticRecordSize();
/*      */     }
/*  610 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addValueRecord(int row, CellValueRecordInterface col)
/*      */   {
/*  627 */     if (log.check(POILogger.DEBUG)) {
/*  628 */       log.log(POILogger.DEBUG, "add value record  row" + row);
/*      */     }
/*  630 */     DimensionsRecord d = this._dimensions;
/*      */     
/*  632 */     if (col.getColumn() > d.getLastCol()) {
/*  633 */       d.setLastCol((short)(col.getColumn() + 1));
/*      */     }
/*  635 */     if (col.getColumn() < d.getFirstCol()) {
/*  636 */       d.setFirstCol(col.getColumn());
/*      */     }
/*  638 */     this._rowsAggregate.insertCell(col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeValueRecord(int row, CellValueRecordInterface col)
/*      */   {
/*  652 */     log.logFormatted(POILogger.DEBUG, "remove value record row %", new int[] { row });
/*      */     
/*  654 */     this._rowsAggregate.removeCell(col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void replaceValueRecord(CellValueRecordInterface newval)
/*      */   {
/*  669 */     if (log.check(POILogger.DEBUG)) {
/*  670 */       log.log(POILogger.DEBUG, "replaceValueRecord ");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  676 */     this._rowsAggregate.removeCell(newval);
/*  677 */     this._rowsAggregate.insertCell(newval);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRow(RowRecord row)
/*      */   {
/*  693 */     if (log.check(POILogger.DEBUG))
/*  694 */       log.log(POILogger.DEBUG, "addRow ");
/*  695 */     DimensionsRecord d = this._dimensions;
/*      */     
/*  697 */     if (row.getRowNumber() >= d.getLastRow()) {
/*  698 */       d.setLastRow(row.getRowNumber() + 1);
/*      */     }
/*  700 */     if (row.getRowNumber() < d.getFirstRow()) {
/*  701 */       d.setFirstRow(row.getRowNumber());
/*      */     }
/*      */     
/*      */ 
/*  705 */     RowRecord existingRow = this._rowsAggregate.getRow(row.getRowNumber());
/*  706 */     if (existingRow != null) {
/*  707 */       this._rowsAggregate.removeRow(existingRow);
/*      */     }
/*      */     
/*  710 */     this._rowsAggregate.insertRow(row);
/*      */     
/*  712 */     if (log.check(POILogger.DEBUG)) {
/*  713 */       log.log(POILogger.DEBUG, "exit addRow");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRow(RowRecord row)
/*      */   {
/*  724 */     this._rowsAggregate.removeRow(row);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CellValueRecordInterface[] getValueRecords()
/*      */   {
/*  741 */     return this._rowsAggregate.getValueRecords();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowRecord getNextRow()
/*      */   {
/*  757 */     if (this.rowRecIterator == null)
/*      */     {
/*  759 */       this.rowRecIterator = this._rowsAggregate.getIterator();
/*      */     }
/*  761 */     if (!this.rowRecIterator.hasNext())
/*      */     {
/*  763 */       return null;
/*      */     }
/*  765 */     return (RowRecord)this.rowRecIterator.next();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RowRecord getRow(int rownum)
/*      */   {
/*  784 */     return this._rowsAggregate.getRow(rownum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static BOFRecord createBOF()
/*      */   {
/*  791 */     BOFRecord retval = new BOFRecord();
/*      */     
/*  793 */     retval.setVersion(1536);
/*  794 */     retval.setType(16);
/*      */     
/*  796 */     retval.setBuild(3515);
/*  797 */     retval.setBuildYear(1996);
/*  798 */     retval.setHistoryBitMask(193);
/*  799 */     retval.setRequiredVersion(6);
/*  800 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static CalcModeRecord createCalcMode()
/*      */   {
/*  807 */     CalcModeRecord retval = new CalcModeRecord();
/*      */     
/*  809 */     retval.setCalcMode((short)1);
/*  810 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static CalcCountRecord createCalcCount()
/*      */   {
/*  817 */     CalcCountRecord retval = new CalcCountRecord();
/*      */     
/*  819 */     retval.setIterations((short)100);
/*  820 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static RefModeRecord createRefMode()
/*      */   {
/*  827 */     RefModeRecord retval = new RefModeRecord();
/*      */     
/*  829 */     retval.setMode((short)1);
/*  830 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static IterationRecord createIteration()
/*      */   {
/*  837 */     return new IterationRecord(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static DeltaRecord createDelta()
/*      */   {
/*  844 */     return new DeltaRecord(0.001D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static SaveRecalcRecord createSaveRecalc()
/*      */   {
/*  851 */     SaveRecalcRecord retval = new SaveRecalcRecord();
/*      */     
/*  853 */     retval.setRecalc(true);
/*  854 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static PrintHeadersRecord createPrintHeaders()
/*      */   {
/*  861 */     PrintHeadersRecord retval = new PrintHeadersRecord();
/*      */     
/*  863 */     retval.setPrintHeaders(false);
/*  864 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static PrintGridlinesRecord createPrintGridlines()
/*      */   {
/*  872 */     PrintGridlinesRecord retval = new PrintGridlinesRecord();
/*      */     
/*  874 */     retval.setPrintGridlines(false);
/*  875 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static GridsetRecord createGridset()
/*      */   {
/*  882 */     GridsetRecord retval = new GridsetRecord();
/*      */     
/*  884 */     retval.setGridset(true);
/*  885 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static GutsRecord createGuts()
/*      */   {
/*  892 */     GutsRecord retval = new GutsRecord();
/*      */     
/*  894 */     retval.setLeftRowGutter((short)0);
/*  895 */     retval.setTopColGutter((short)0);
/*  896 */     retval.setRowLevelMax((short)0);
/*  897 */     retval.setColLevelMax((short)0);
/*  898 */     return retval;
/*      */   }
/*      */   
/*      */   private GutsRecord getGutsRecord() {
/*  902 */     if (this._gutsRecord == null) {
/*  903 */       GutsRecord result = createGuts();
/*  904 */       RecordOrderer.addNewSheetRecord(this._records, result);
/*  905 */       this._gutsRecord = result;
/*      */     }
/*      */     
/*  908 */     return this._gutsRecord;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static DefaultRowHeightRecord createDefaultRowHeight()
/*      */   {
/*  915 */     DefaultRowHeightRecord retval = new DefaultRowHeightRecord();
/*      */     
/*  917 */     retval.setOptionFlags((short)0);
/*  918 */     retval.setRowHeight((short)255);
/*  919 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static WSBoolRecord createWSBool()
/*      */   {
/*  926 */     WSBoolRecord retval = new WSBoolRecord();
/*      */     
/*  928 */     retval.setWSBool1((byte)4);
/*  929 */     retval.setWSBool2((byte)-63);
/*  930 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static DefaultColWidthRecord createDefaultColWidth()
/*      */   {
/*  938 */     DefaultColWidthRecord retval = new DefaultColWidthRecord();
/*  939 */     retval.setColWidth(8);
/*  940 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDefaultColumnWidth()
/*      */   {
/*  948 */     return this.defaultcolwidth.getColWidth();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isGridsPrinted()
/*      */   {
/*  955 */     if (this.gridset == null) {
/*  956 */       this.gridset = createGridset();
/*      */       
/*  958 */       int loc = findFirstRecordLocBySid((short)10);
/*  959 */       this._records.add(loc, this.gridset);
/*      */     }
/*  961 */     return !this.gridset.getGridset();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGridsPrinted(boolean value)
/*      */   {
/*  969 */     this.gridset.setGridset(!value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultColumnWidth(int dcw)
/*      */   {
/*  977 */     this.defaultcolwidth.setColWidth(dcw);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDefaultRowHeight(short dch)
/*      */   {
/*  984 */     this.defaultrowheight.setRowHeight(dch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getDefaultRowHeight()
/*      */   {
/*  992 */     return this.defaultrowheight.getRowHeight();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumnWidth(int columnIndex)
/*      */   {
/* 1005 */     ColumnInfoRecord ci = this._columnInfos.findColumnInfo(columnIndex);
/* 1006 */     if (ci != null) {
/* 1007 */       return ci.getColumnWidth();
/*      */     }
/*      */     
/*      */ 
/* 1011 */     return 256 * this.defaultcolwidth.getColWidth();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getXFIndexForColAt(short columnIndex)
/*      */   {
/* 1029 */     ColumnInfoRecord ci = this._columnInfos.findColumnInfo(columnIndex);
/* 1030 */     if (ci != null) {
/* 1031 */       return (short)ci.getXFIndex();
/*      */     }
/* 1033 */     return 15;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnWidth(int column, int width)
/*      */   {
/* 1045 */     if (width > 65280) { throw new IllegalArgumentException("The maximum column width for an individual cell is 255 characters.");
/*      */     }
/* 1047 */     setColumn(column, null, Integer.valueOf(width), null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isColumnHidden(int columnIndex)
/*      */   {
/* 1059 */     ColumnInfoRecord cir = this._columnInfos.findColumnInfo(columnIndex);
/* 1060 */     if (cir == null) {
/* 1061 */       return false;
/*      */     }
/* 1063 */     return cir.getHidden();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnHidden(int column, boolean hidden)
/*      */   {
/* 1072 */     setColumn(column, null, null, null, Boolean.valueOf(hidden), null);
/*      */   }
/*      */   
/* 1075 */   public void setDefaultColumnStyle(int column, int styleIndex) { setColumn(column, Short.valueOf((short)styleIndex), null, null, null, null); }
/*      */   
/*      */   private void setColumn(int column, Short xfStyle, Integer width, Integer level, Boolean hidden, Boolean collapsed)
/*      */   {
/* 1079 */     this._columnInfos.setColumn(column, xfStyle, width, level, hidden, collapsed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void groupColumnRange(int fromColumn, int toColumn, boolean indent)
/*      */   {
/* 1093 */     this._columnInfos.groupColumnRange(fromColumn, toColumn, indent);
/*      */     
/*      */ 
/* 1096 */     int maxLevel = this._columnInfos.getMaxOutlineLevel();
/*      */     
/* 1098 */     GutsRecord guts = getGutsRecord();
/* 1099 */     guts.setColLevelMax((short)(maxLevel + 1));
/* 1100 */     if (maxLevel == 0) {
/* 1101 */       guts.setTopColGutter((short)0);
/*      */     } else {
/* 1103 */       guts.setTopColGutter((short)(29 + 12 * (maxLevel - 1)));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static DimensionsRecord createDimensions()
/*      */   {
/* 1112 */     DimensionsRecord retval = new DimensionsRecord();
/*      */     
/* 1114 */     retval.setFirstCol((short)0);
/* 1115 */     retval.setLastRow(1);
/* 1116 */     retval.setFirstRow(0);
/* 1117 */     retval.setLastCol((short)1);
/* 1118 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static WindowTwoRecord createWindowTwo()
/*      */   {
/* 1131 */     WindowTwoRecord retval = new WindowTwoRecord();
/*      */     
/* 1133 */     retval.setOptions((short)1718);
/* 1134 */     retval.setTopRow((short)0);
/* 1135 */     retval.setLeftCol((short)0);
/* 1136 */     retval.setHeaderColor(64);
/* 1137 */     retval.setPageBreakZoom((short)0);
/* 1138 */     retval.setNormalZoom((short)0);
/* 1139 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static SelectionRecord createSelection()
/*      */   {
/* 1146 */     return new SelectionRecord(0, 0);
/*      */   }
/*      */   
/*      */   public short getTopRow() {
/* 1150 */     return this.windowTwo == null ? 0 : this.windowTwo.getTopRow();
/*      */   }
/*      */   
/*      */   public void setTopRow(short topRow) {
/* 1154 */     if (this.windowTwo != null) {
/* 1155 */       this.windowTwo.setTopRow(topRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeftCol(short leftCol)
/*      */   {
/* 1164 */     if (this.windowTwo != null) {
/* 1165 */       this.windowTwo.setLeftCol(leftCol);
/*      */     }
/*      */   }
/*      */   
/*      */   public short getLeftCol() {
/* 1170 */     return this.windowTwo == null ? 0 : this.windowTwo.getLeftCol();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getActiveCellRow()
/*      */   {
/* 1180 */     if (this._selection == null) {
/* 1181 */       return 0;
/*      */     }
/* 1183 */     return this._selection.getActiveCellRow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setActiveCellRow(int row)
/*      */   {
/* 1194 */     if (this._selection != null) {
/* 1195 */       this._selection.setActiveCellRow(row);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getActiveCellCol()
/*      */   {
/* 1204 */     if (this._selection == null) {
/* 1205 */       return 0;
/*      */     }
/* 1207 */     return (short)this._selection.getActiveCellCol();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setActiveCellCol(short col)
/*      */   {
/* 1218 */     if (this._selection != null)
/*      */     {
/* 1220 */       this._selection.setActiveCellCol(col);
/*      */     }
/*      */   }
/*      */   
/*      */   public List<RecordBase> getRecords() {
/* 1225 */     return this._records;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public GridsetRecord getGridsetRecord()
/*      */   {
/* 1233 */     return this.gridset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Record findFirstRecordBySid(short sid)
/*      */   {
/* 1240 */     int ix = findFirstRecordLocBySid(sid);
/* 1241 */     if (ix < 0) {
/* 1242 */       return null;
/*      */     }
/* 1244 */     return (Record)this._records.get(ix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSCLRecord(SCLRecord sclRecord)
/*      */   {
/* 1254 */     int oldRecordLoc = findFirstRecordLocBySid((short)160);
/* 1255 */     if (oldRecordLoc == -1)
/*      */     {
/* 1257 */       int windowRecordLoc = findFirstRecordLocBySid((short)574);
/* 1258 */       this._records.add(windowRecordLoc + 1, sclRecord);
/*      */     } else {
/* 1260 */       this._records.set(oldRecordLoc, sclRecord);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int findFirstRecordLocBySid(short sid)
/*      */   {
/* 1272 */     int max = this._records.size();
/* 1273 */     for (int i = 0; i < max; i++) {
/* 1274 */       Object rb = this._records.get(i);
/* 1275 */       if ((rb instanceof Record))
/*      */       {
/*      */ 
/* 1278 */         Record record = (Record)rb;
/* 1279 */         if (record.getSid() == sid)
/* 1280 */           return i;
/*      */       }
/*      */     }
/* 1283 */     return -1;
/*      */   }
/*      */   
/*      */   public WindowTwoRecord getWindowTwo() {
/* 1287 */     return this.windowTwo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrintGridlinesRecord getPrintGridlines()
/*      */   {
/* 1296 */     return this.printGridlines;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrintGridlines(PrintGridlinesRecord newPrintGridlines)
/*      */   {
/* 1305 */     this.printGridlines = newPrintGridlines;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelected(boolean sel)
/*      */   {
/* 1313 */     this.windowTwo.setSelected(sel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createFreezePane(int colSplit, int rowSplit, int topRow, int leftmostColumn)
/*      */   {
/* 1324 */     int paneLoc = findFirstRecordLocBySid((short)65);
/* 1325 */     if (paneLoc != -1) {
/* 1326 */       this._records.remove(paneLoc);
/*      */     }
/* 1328 */     int loc = findFirstRecordLocBySid((short)574);
/* 1329 */     PaneRecord pane = new PaneRecord();
/* 1330 */     pane.setX((short)colSplit);
/* 1331 */     pane.setY((short)rowSplit);
/* 1332 */     pane.setTopRow((short)topRow);
/* 1333 */     pane.setLeftColumn((short)leftmostColumn);
/* 1334 */     if (rowSplit == 0) {
/* 1335 */       pane.setTopRow((short)0);
/* 1336 */       pane.setActivePane((short)1);
/* 1337 */     } else if (colSplit == 0) {
/* 1338 */       pane.setLeftColumn((short)64);
/* 1339 */       pane.setActivePane((short)2);
/*      */     } else {
/* 1341 */       pane.setActivePane((short)0);
/*      */     }
/* 1343 */     this._records.add(loc + 1, pane);
/*      */     
/* 1345 */     this.windowTwo.setFreezePanes(true);
/* 1346 */     this.windowTwo.setFreezePanesNoSplit(true);
/*      */     
/* 1348 */     SelectionRecord sel = (SelectionRecord)findFirstRecordBySid((short)29);
/* 1349 */     sel.setPane((byte)pane.getActivePane());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createSplitPane(int xSplitPos, int ySplitPos, int topRow, int leftmostColumn, int activePane)
/*      */   {
/* 1367 */     int paneLoc = findFirstRecordLocBySid((short)65);
/* 1368 */     if (paneLoc != -1) {
/* 1369 */       this._records.remove(paneLoc);
/*      */     }
/* 1371 */     int loc = findFirstRecordLocBySid((short)574);
/* 1372 */     PaneRecord r = new PaneRecord();
/* 1373 */     r.setX((short)xSplitPos);
/* 1374 */     r.setY((short)ySplitPos);
/* 1375 */     r.setTopRow((short)topRow);
/* 1376 */     r.setLeftColumn((short)leftmostColumn);
/* 1377 */     r.setActivePane((short)activePane);
/* 1378 */     this._records.add(loc + 1, r);
/*      */     
/* 1380 */     this.windowTwo.setFreezePanes(false);
/* 1381 */     this.windowTwo.setFreezePanesNoSplit(false);
/*      */     
/* 1383 */     SelectionRecord sel = (SelectionRecord)findFirstRecordBySid((short)29);
/* 1384 */     sel.setPane((byte)0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PaneInformation getPaneInformation()
/*      */   {
/* 1393 */     PaneRecord rec = (PaneRecord)findFirstRecordBySid((short)65);
/* 1394 */     if (rec == null) {
/* 1395 */       return null;
/*      */     }
/* 1397 */     return new PaneInformation(rec.getX(), rec.getY(), rec.getTopRow(), rec.getLeftColumn(), (byte)rec.getActivePane(), this.windowTwo.getFreezePanes());
/*      */   }
/*      */   
/*      */   public SelectionRecord getSelection()
/*      */   {
/* 1402 */     return this._selection;
/*      */   }
/*      */   
/*      */   public void setSelection(SelectionRecord selection) {
/* 1406 */     this._selection = selection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public WorksheetProtectionBlock getProtectionBlock()
/*      */   {
/* 1413 */     return this._protectionBlock;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDisplayGridlines(boolean show)
/*      */   {
/* 1420 */     this.windowTwo.setDisplayGridlines(show);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isDisplayGridlines()
/*      */   {
/* 1427 */     return this.windowTwo.getDisplayGridlines();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisplayFormulas(boolean show)
/*      */   {
/* 1435 */     this.windowTwo.setDisplayFormulas(show);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDisplayFormulas()
/*      */   {
/* 1443 */     return this.windowTwo.getDisplayFormulas();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisplayRowColHeadings(boolean show)
/*      */   {
/* 1451 */     this.windowTwo.setDisplayRowColHeadings(show);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDisplayRowColHeadings()
/*      */   {
/* 1459 */     return this.windowTwo.getDisplayRowColHeadings();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUncalced()
/*      */   {
/* 1467 */     return this._isUncalced;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUncalced(boolean uncalced)
/*      */   {
/* 1473 */     this._isUncalced = uncalced;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int aggregateDrawingRecords(DrawingManager2 drawingManager, boolean createIfMissing)
/*      */   {
/* 1486 */     int loc = findFirstRecordLocBySid((short)236);
/* 1487 */     boolean noDrawingRecordsFound = loc == -1;
/* 1488 */     if (noDrawingRecordsFound) {
/* 1489 */       if (!createIfMissing)
/*      */       {
/* 1491 */         return -1;
/*      */       }
/*      */       
/* 1494 */       EscherAggregate aggregate = new EscherAggregate(drawingManager);
/* 1495 */       loc = findFirstRecordLocBySid((short)9876);
/* 1496 */       if (loc == -1) {
/* 1497 */         loc = findFirstRecordLocBySid((short)574);
/*      */       } else {
/* 1499 */         getRecords().remove(loc);
/*      */       }
/* 1501 */       getRecords().add(loc, aggregate);
/* 1502 */       return loc;
/*      */     }
/* 1504 */     List<RecordBase> records = getRecords();
/* 1505 */     EscherAggregate r = EscherAggregate.createAggregate(records, loc, drawingManager);
/* 1506 */     int startloc = loc;
/*      */     
/*      */ 
/* 1509 */     while ((loc + 1 < records.size()) && ((records.get(loc) instanceof DrawingRecord)) && ((records.get(loc + 1) instanceof ObjRecord)))
/*      */     {
/* 1511 */       loc += 2;
/*      */     }
/* 1513 */     int endloc = loc - 1;
/* 1514 */     for (int i = 0; i < endloc - startloc + 1; i++)
/* 1515 */       records.remove(startloc);
/* 1516 */     records.add(startloc, r);
/*      */     
/* 1518 */     return startloc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void preSerialize()
/*      */   {
/* 1527 */     for (RecordBase r : getRecords()) {
/* 1528 */       if ((r instanceof EscherAggregate))
/*      */       {
/* 1530 */         r.getRecordSize();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public PageSettingsBlock getPageSettings()
/*      */   {
/* 1537 */     if (this._psBlock == null) {
/* 1538 */       this._psBlock = new PageSettingsBlock();
/* 1539 */       RecordOrderer.addNewSheetRecord(this._records, this._psBlock);
/*      */     }
/* 1541 */     return this._psBlock;
/*      */   }
/*      */   
/*      */   public void setColumnGroupCollapsed(int columnNumber, boolean collapsed)
/*      */   {
/* 1546 */     if (collapsed) {
/* 1547 */       this._columnInfos.collapseColumn(columnNumber);
/*      */     } else {
/* 1549 */       this._columnInfos.expandColumn(columnNumber);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void groupRowRange(int fromRow, int toRow, boolean indent)
/*      */   {
/* 1556 */     for (int rowNum = fromRow; rowNum <= toRow; rowNum++)
/*      */     {
/* 1558 */       RowRecord row = getRow(rowNum);
/* 1559 */       if (row == null)
/*      */       {
/* 1561 */         row = RowRecordsAggregate.createRow(rowNum);
/* 1562 */         addRow(row);
/*      */       }
/* 1564 */       int level = row.getOutlineLevel();
/* 1565 */       if (indent) level++; else level--;
/* 1566 */       level = Math.max(0, level);
/* 1567 */       level = Math.min(7, level);
/* 1568 */       row.setOutlineLevel((short)level);
/*      */     }
/*      */     
/* 1571 */     recalcRowGutter();
/*      */   }
/*      */   
/*      */   private void recalcRowGutter() {
/* 1575 */     int maxLevel = 0;
/* 1576 */     Iterator iterator = this._rowsAggregate.getIterator();
/* 1577 */     while (iterator.hasNext()) {
/* 1578 */       RowRecord rowRecord = (RowRecord)iterator.next();
/* 1579 */       maxLevel = Math.max(rowRecord.getOutlineLevel(), maxLevel);
/*      */     }
/*      */     
/*      */ 
/* 1583 */     GutsRecord guts = getGutsRecord();
/*      */     
/* 1585 */     guts.setRowLevelMax((short)(maxLevel + 1));
/* 1586 */     guts.setLeftRowGutter((short)(29 + 12 * maxLevel));
/*      */   }
/*      */   
/*      */   public DataValidityTable getOrCreateDataValidityTable() {
/* 1590 */     if (this._dataValidityTable == null) {
/* 1591 */       DataValidityTable result = new DataValidityTable();
/* 1592 */       RecordOrderer.addNewSheetRecord(this._records, result);
/* 1593 */       this._dataValidityTable = result;
/*      */     }
/* 1595 */     return this._dataValidityTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public NoteRecord[] getNoteRecords()
/*      */   {
/* 1602 */     List<NoteRecord> temp = new ArrayList();
/* 1603 */     for (int i = this._records.size() - 1; i >= 0; i--) {
/* 1604 */       RecordBase rec = (RecordBase)this._records.get(i);
/* 1605 */       if ((rec instanceof NoteRecord)) {
/* 1606 */         temp.add((NoteRecord)rec);
/*      */       }
/*      */     }
/* 1609 */     if (temp.size() < 1) {
/* 1610 */       return NoteRecord.EMPTY_ARRAY;
/*      */     }
/* 1612 */     NoteRecord[] result = new NoteRecord[temp.size()];
/* 1613 */     temp.toArray(result);
/* 1614 */     return result;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\InternalSheet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */