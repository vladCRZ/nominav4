/*      */ package org.apache.poi.hssf.model;
/*      */ 
/*      */ import java.security.AccessControlException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import org.apache.poi.ddf.EscherBSERecord;
/*      */ import org.apache.poi.ddf.EscherBoolProperty;
/*      */ import org.apache.poi.ddf.EscherContainerRecord;
/*      */ import org.apache.poi.ddf.EscherDgRecord;
/*      */ import org.apache.poi.ddf.EscherDggRecord;
/*      */ import org.apache.poi.ddf.EscherDggRecord.FileIdCluster;
/*      */ import org.apache.poi.ddf.EscherOptRecord;
/*      */ import org.apache.poi.ddf.EscherRGBProperty;
/*      */ import org.apache.poi.ddf.EscherRecord;
/*      */ import org.apache.poi.ddf.EscherSpRecord;
/*      */ import org.apache.poi.ddf.EscherSplitMenuColorsRecord;
/*      */ import org.apache.poi.hssf.record.BOFRecord;
/*      */ import org.apache.poi.hssf.record.BackupRecord;
/*      */ import org.apache.poi.hssf.record.BookBoolRecord;
/*      */ import org.apache.poi.hssf.record.BoundSheetRecord;
/*      */ import org.apache.poi.hssf.record.CodepageRecord;
/*      */ import org.apache.poi.hssf.record.CountryRecord;
/*      */ import org.apache.poi.hssf.record.DSFRecord;
/*      */ import org.apache.poi.hssf.record.DateWindow1904Record;
/*      */ import org.apache.poi.hssf.record.DrawingGroupRecord;
/*      */ import org.apache.poi.hssf.record.EOFRecord;
/*      */ import org.apache.poi.hssf.record.EscherAggregate;
/*      */ import org.apache.poi.hssf.record.ExtSSTRecord;
/*      */ import org.apache.poi.hssf.record.ExtendedFormatRecord;
/*      */ import org.apache.poi.hssf.record.FileSharingRecord;
/*      */ import org.apache.poi.hssf.record.FnGroupCountRecord;
/*      */ import org.apache.poi.hssf.record.FontRecord;
/*      */ import org.apache.poi.hssf.record.FormatRecord;
/*      */ import org.apache.poi.hssf.record.HideObjRecord;
/*      */ import org.apache.poi.hssf.record.HyperlinkRecord;
/*      */ import org.apache.poi.hssf.record.InterfaceEndRecord;
/*      */ import org.apache.poi.hssf.record.InterfaceHdrRecord;
/*      */ import org.apache.poi.hssf.record.MMSRecord;
/*      */ import org.apache.poi.hssf.record.NameCommentRecord;
/*      */ import org.apache.poi.hssf.record.NameRecord;
/*      */ import org.apache.poi.hssf.record.PaletteRecord;
/*      */ import org.apache.poi.hssf.record.PasswordRecord;
/*      */ import org.apache.poi.hssf.record.PasswordRev4Record;
/*      */ import org.apache.poi.hssf.record.PrecisionRecord;
/*      */ import org.apache.poi.hssf.record.ProtectRecord;
/*      */ import org.apache.poi.hssf.record.ProtectionRev4Record;
/*      */ import org.apache.poi.hssf.record.RecalcIdRecord;
/*      */ import org.apache.poi.hssf.record.Record;
/*      */ import org.apache.poi.hssf.record.RefreshAllRecord;
/*      */ import org.apache.poi.hssf.record.SSTRecord;
/*      */ import org.apache.poi.hssf.record.StyleRecord;
/*      */ import org.apache.poi.hssf.record.TabIdRecord;
/*      */ import org.apache.poi.hssf.record.UseSelFSRecord;
/*      */ import org.apache.poi.hssf.record.WindowOneRecord;
/*      */ import org.apache.poi.hssf.record.WindowProtectRecord;
/*      */ import org.apache.poi.hssf.record.WriteAccessRecord;
/*      */ import org.apache.poi.hssf.record.WriteProtectRecord;
/*      */ import org.apache.poi.hssf.record.common.UnicodeString;
/*      */ import org.apache.poi.hssf.record.formula.FormulaShifter;
/*      */ import org.apache.poi.hssf.record.formula.NameXPtg;
/*      */ import org.apache.poi.hssf.record.formula.Ptg;
/*      */ import org.apache.poi.ss.formula.EvaluationWorkbook.ExternalName;
/*      */ import org.apache.poi.ss.formula.EvaluationWorkbook.ExternalSheet;
/*      */ import org.apache.poi.util.Internal;
/*      */ import org.apache.poi.util.POILogFactory;
/*      */ import org.apache.poi.util.POILogger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Internal
/*      */ public final class InternalWorkbook
/*      */ {
/*      */   private static final int MAX_SENSITIVE_SHEET_NAME_LEN = 31;
/*  126 */   private static final POILogger log = POILogFactory.getLogger(InternalWorkbook.class);
/*  127 */   private static final int DEBUG = POILogger.DEBUG;
/*      */   
/*      */ 
/*      */   private static final short CODEPAGE = 1200;
/*      */   
/*      */ 
/*      */   private final WorkbookRecordList records;
/*      */   
/*      */ 
/*      */   protected SSTRecord sst;
/*      */   
/*      */ 
/*      */   private LinkTable linkTable;
/*      */   
/*      */ 
/*      */   private final List<BoundSheetRecord> boundsheets;
/*      */   
/*      */ 
/*      */   private final List<FormatRecord> formats;
/*      */   
/*      */ 
/*      */   private final List<HyperlinkRecord> hyperlinks;
/*      */   
/*      */ 
/*      */   private int numxfs;
/*      */   
/*      */ 
/*      */   private int numfonts;
/*      */   
/*      */ 
/*      */   private int maxformatid;
/*      */   
/*      */   private boolean uses1904datewindowing;
/*      */   
/*      */   private DrawingManager2 drawingManager;
/*      */   
/*      */   private List<EscherBSERecord> escherBSERecords;
/*      */   
/*      */   private WindowOneRecord windowOne;
/*      */   
/*      */   private FileSharingRecord fileShare;
/*      */   
/*      */   private WriteAccessRecord writeAccess;
/*      */   
/*      */   private WriteProtectRecord writeProtect;
/*      */   
/*      */   private final Map<String, NameCommentRecord> commentRecords;
/*      */   
/*      */ 
/*      */   private InternalWorkbook()
/*      */   {
/*  178 */     this.records = new WorkbookRecordList();
/*      */     
/*  180 */     this.boundsheets = new ArrayList();
/*  181 */     this.formats = new ArrayList();
/*  182 */     this.hyperlinks = new ArrayList();
/*  183 */     this.numxfs = 0;
/*  184 */     this.numfonts = 0;
/*  185 */     this.maxformatid = -1;
/*  186 */     this.uses1904datewindowing = false;
/*  187 */     this.escherBSERecords = new ArrayList();
/*  188 */     this.commentRecords = new LinkedHashMap();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static InternalWorkbook createWorkbook(List<Record> recs)
/*      */   {
/*  204 */     if (log.check(POILogger.DEBUG)) {
/*  205 */       log.log(DEBUG, "Workbook (readfile) created with reclen=", Integer.valueOf(recs.size()));
/*      */     }
/*  207 */     InternalWorkbook retval = new InternalWorkbook();
/*  208 */     List<Record> records = new ArrayList(recs.size() / 3);
/*  209 */     retval.records.setRecords(records);
/*      */     
/*      */ 
/*  212 */     for (int k = 0; k < recs.size(); k++) {
/*  213 */       Record rec = (Record)recs.get(k);
/*      */       
/*  215 */       if (rec.getSid() == 10) {
/*  216 */         records.add(rec);
/*  217 */         if (!log.check(POILogger.DEBUG)) break;
/*  218 */         log.log(DEBUG, "found workbook eof record at " + k); break;
/*      */       }
/*      */       
/*  221 */       switch (rec.getSid())
/*      */       {
/*      */       case 133: 
/*  224 */         if (log.check(POILogger.DEBUG))
/*  225 */           log.log(DEBUG, "found boundsheet record at " + k);
/*  226 */         retval.boundsheets.add((BoundSheetRecord)rec);
/*  227 */         retval.records.setBspos(k);
/*  228 */         break;
/*      */       
/*      */       case 252: 
/*  231 */         if (log.check(POILogger.DEBUG))
/*  232 */           log.log(DEBUG, "found sst record at " + k);
/*  233 */         retval.sst = ((SSTRecord)rec);
/*  234 */         break;
/*      */       
/*      */       case 49: 
/*  237 */         if (log.check(POILogger.DEBUG))
/*  238 */           log.log(DEBUG, "found font record at " + k);
/*  239 */         retval.records.setFontpos(k);
/*  240 */         retval.numfonts += 1;
/*  241 */         break;
/*      */       
/*      */       case 224: 
/*  244 */         if (log.check(POILogger.DEBUG))
/*  245 */           log.log(DEBUG, "found XF record at " + k);
/*  246 */         retval.records.setXfpos(k);
/*  247 */         retval.numxfs += 1;
/*  248 */         break;
/*      */       
/*      */       case 317: 
/*  251 */         if (log.check(POILogger.DEBUG))
/*  252 */           log.log(DEBUG, "found tabid record at " + k);
/*  253 */         retval.records.setTabpos(k);
/*  254 */         break;
/*      */       
/*      */       case 18: 
/*  257 */         if (log.check(POILogger.DEBUG))
/*  258 */           log.log(DEBUG, "found protect record at " + k);
/*  259 */         retval.records.setProtpos(k);
/*  260 */         break;
/*      */       
/*      */       case 64: 
/*  263 */         if (log.check(POILogger.DEBUG))
/*  264 */           log.log(DEBUG, "found backup record at " + k);
/*  265 */         retval.records.setBackuppos(k);
/*  266 */         break;
/*      */       case 23: 
/*  268 */         throw new RuntimeException("Extern sheet is part of LinkTable");
/*      */       
/*      */       case 24: 
/*      */       case 430: 
/*  272 */         if (log.check(POILogger.DEBUG))
/*  273 */           log.log(DEBUG, "found SupBook record at " + k);
/*  274 */         retval.linkTable = new LinkTable(recs, k, retval.records, retval.commentRecords);
/*  275 */         k += retval.linkTable.getRecordCount() - 1;
/*  276 */         break;
/*      */       case 1054: 
/*  278 */         if (log.check(POILogger.DEBUG))
/*  279 */           log.log(DEBUG, "found format record at " + k);
/*  280 */         retval.formats.add((FormatRecord)rec);
/*  281 */         retval.maxformatid = (retval.maxformatid >= ((FormatRecord)rec).getIndexCode() ? retval.maxformatid : ((FormatRecord)rec).getIndexCode());
/*  282 */         break;
/*      */       case 34: 
/*  284 */         if (log.check(POILogger.DEBUG))
/*  285 */           log.log(DEBUG, "found datewindow1904 record at " + k);
/*  286 */         retval.uses1904datewindowing = (((DateWindow1904Record)rec).getWindowing() == 1);
/*  287 */         break;
/*      */       case 146: 
/*  289 */         if (log.check(POILogger.DEBUG))
/*  290 */           log.log(DEBUG, "found palette record at " + k);
/*  291 */         retval.records.setPalettepos(k);
/*  292 */         break;
/*      */       case 61: 
/*  294 */         if (log.check(POILogger.DEBUG))
/*  295 */           log.log(DEBUG, "found WindowOneRecord at " + k);
/*  296 */         retval.windowOne = ((WindowOneRecord)rec);
/*  297 */         break;
/*      */       case 92: 
/*  299 */         if (log.check(POILogger.DEBUG))
/*  300 */           log.log(DEBUG, "found WriteAccess at " + k);
/*  301 */         retval.writeAccess = ((WriteAccessRecord)rec);
/*  302 */         break;
/*      */       case 134: 
/*  304 */         if (log.check(POILogger.DEBUG))
/*  305 */           log.log(DEBUG, "found WriteProtect at " + k);
/*  306 */         retval.writeProtect = ((WriteProtectRecord)rec);
/*  307 */         break;
/*      */       case 91: 
/*  309 */         if (log.check(POILogger.DEBUG))
/*  310 */           log.log(DEBUG, "found FileSharing at " + k);
/*  311 */         retval.fileShare = ((FileSharingRecord)rec);
/*  312 */         break;
/*      */       
/*      */       case 2196: 
/*  315 */         NameCommentRecord ncr = (NameCommentRecord)rec;
/*  316 */         if (log.check(POILogger.DEBUG))
/*  317 */           log.log(DEBUG, "found NameComment at " + k);
/*  318 */         retval.commentRecords.put(ncr.getNameText(), ncr);
/*      */       }
/*      */       
/*  321 */       records.add(rec);
/*      */     }
/*  331 */     for (; 
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  331 */         k < recs.size(); k++) {
/*  332 */       Record rec = (Record)recs.get(k);
/*  333 */       switch (rec.getSid()) {
/*      */       case 440: 
/*  335 */         retval.hyperlinks.add((HyperlinkRecord)rec);
/*      */       }
/*      */       
/*      */     }
/*      */     
/*  340 */     if (retval.windowOne == null) {
/*  341 */       retval.windowOne = createWindowOne();
/*      */     }
/*  343 */     if (log.check(POILogger.DEBUG))
/*  344 */       log.log(DEBUG, "exit create workbook from existing file function");
/*  345 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static InternalWorkbook createWorkbook()
/*      */   {
/*  354 */     if (log.check(POILogger.DEBUG))
/*  355 */       log.log(DEBUG, "creating new workbook from scratch");
/*  356 */     InternalWorkbook retval = new InternalWorkbook();
/*  357 */     List<Record> records = new ArrayList(30);
/*  358 */     retval.records.setRecords(records);
/*  359 */     List<FormatRecord> formats = retval.formats;
/*      */     
/*  361 */     records.add(createBOF());
/*  362 */     records.add(new InterfaceHdrRecord(1200));
/*  363 */     records.add(createMMS());
/*  364 */     records.add(InterfaceEndRecord.instance);
/*  365 */     records.add(createWriteAccess());
/*  366 */     records.add(createCodepage());
/*  367 */     records.add(createDSF());
/*  368 */     records.add(createTabId());
/*  369 */     retval.records.setTabpos(records.size() - 1);
/*  370 */     records.add(createFnGroupCount());
/*  371 */     records.add(createWindowProtect());
/*  372 */     records.add(createProtect());
/*  373 */     retval.records.setProtpos(records.size() - 1);
/*  374 */     records.add(createPassword());
/*  375 */     records.add(createProtectionRev4());
/*  376 */     records.add(createPasswordRev4());
/*  377 */     retval.windowOne = createWindowOne();
/*  378 */     records.add(retval.windowOne);
/*  379 */     records.add(createBackup());
/*  380 */     retval.records.setBackuppos(records.size() - 1);
/*  381 */     records.add(createHideObj());
/*  382 */     records.add(createDateWindow1904());
/*  383 */     records.add(createPrecision());
/*  384 */     records.add(createRefreshAll());
/*  385 */     records.add(createBookBool());
/*  386 */     records.add(createFont());
/*  387 */     records.add(createFont());
/*  388 */     records.add(createFont());
/*  389 */     records.add(createFont());
/*  390 */     retval.records.setFontpos(records.size() - 1);
/*  391 */     retval.numfonts = 4;
/*      */     
/*      */ 
/*  394 */     for (int i = 0; i <= 7; i++) {
/*  395 */       FormatRecord rec = createFormat(i);
/*  396 */       retval.maxformatid = (retval.maxformatid >= rec.getIndexCode() ? retval.maxformatid : rec.getIndexCode());
/*  397 */       formats.add(rec);
/*  398 */       records.add(rec);
/*      */     }
/*      */     
/*  401 */     for (int k = 0; k < 21; k++) {
/*  402 */       records.add(createExtendedFormat(k));
/*  403 */       retval.numxfs += 1;
/*      */     }
/*  405 */     retval.records.setXfpos(records.size() - 1);
/*  406 */     for (int k = 0; k < 6; k++) {
/*  407 */       records.add(createStyle(k));
/*      */     }
/*  409 */     records.add(createUseSelFS());
/*      */     
/*  411 */     int nBoundSheets = 1;
/*  412 */     for (int k = 0; k < nBoundSheets; k++) {
/*  413 */       BoundSheetRecord bsr = createBoundSheet(k);
/*      */       
/*  415 */       records.add(bsr);
/*  416 */       retval.boundsheets.add(bsr);
/*  417 */       retval.records.setBspos(records.size() - 1);
/*      */     }
/*  419 */     records.add(createCountry());
/*  420 */     for (int k = 0; k < nBoundSheets; k++) {
/*  421 */       retval.getOrCreateLinkTable().checkExternSheet(k);
/*      */     }
/*  423 */     retval.sst = new SSTRecord();
/*  424 */     records.add(retval.sst);
/*  425 */     records.add(createExtendedSST());
/*      */     
/*  427 */     records.add(EOFRecord.instance);
/*  428 */     if (log.check(POILogger.DEBUG))
/*  429 */       log.log(DEBUG, "exit create new workbook from scratch");
/*  430 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NameRecord getSpecificBuiltinRecord(byte name, int sheetNumber)
/*      */   {
/*  442 */     return getOrCreateLinkTable().getSpecificBuiltinRecord(name, sheetNumber);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeBuiltinRecord(byte name, int sheetIndex)
/*      */   {
/*  451 */     this.linkTable.removeBuiltinRecord(name, sheetIndex);
/*      */   }
/*      */   
/*      */   public int getNumRecords()
/*      */   {
/*  456 */     return this.records.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FontRecord getFontRecordAt(int idx)
/*      */   {
/*  469 */     int index = idx;
/*      */     
/*  471 */     if (index > 4) {
/*  472 */       index--;
/*      */     }
/*  474 */     if (index > this.numfonts - 1) {
/*  475 */       throw new ArrayIndexOutOfBoundsException("There are only " + this.numfonts + " font records, you asked for " + idx);
/*      */     }
/*      */     
/*      */ 
/*  479 */     FontRecord retval = (FontRecord)this.records.get(this.records.getFontpos() - (this.numfonts - 1) + index);
/*      */     
/*      */ 
/*  482 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getFontIndex(FontRecord font)
/*      */   {
/*  489 */     for (int i = 0; i <= this.numfonts; i++) {
/*  490 */       FontRecord thisFont = (FontRecord)this.records.get(this.records.getFontpos() - (this.numfonts - 1) + i);
/*      */       
/*  492 */       if (thisFont == font)
/*      */       {
/*  494 */         if (i > 3) {
/*  495 */           return i + 1;
/*      */         }
/*  497 */         return i;
/*      */       }
/*      */     }
/*  500 */     throw new IllegalArgumentException("Could not find that font!");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FontRecord createNewFont()
/*      */   {
/*  512 */     FontRecord rec = createFont();
/*      */     
/*  514 */     this.records.add(this.records.getFontpos() + 1, rec);
/*  515 */     this.records.setFontpos(this.records.getFontpos() + 1);
/*  516 */     this.numfonts += 1;
/*  517 */     return rec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeFontRecord(FontRecord rec)
/*      */   {
/*  527 */     this.records.remove(rec);
/*  528 */     this.numfonts -= 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumberOfFontRecords()
/*      */   {
/*  538 */     return this.numfonts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSheetBof(int sheetIndex, int pos)
/*      */   {
/*  549 */     if (log.check(POILogger.DEBUG)) {
/*  550 */       log.log(DEBUG, "setting bof for sheetnum =", Integer.valueOf(sheetIndex), " at pos=", Integer.valueOf(pos));
/*      */     }
/*  552 */     checkSheets(sheetIndex);
/*  553 */     getBoundSheetRec(sheetIndex).setPositionOfBof(pos);
/*      */   }
/*      */   
/*      */   private BoundSheetRecord getBoundSheetRec(int sheetIndex)
/*      */   {
/*  558 */     return (BoundSheetRecord)this.boundsheets.get(sheetIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BackupRecord getBackupRecord()
/*      */   {
/*  566 */     return (BackupRecord)this.records.get(this.records.getBackuppos());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSheetName(int sheetnum, String sheetname)
/*      */   {
/*  579 */     checkSheets(sheetnum);
/*  580 */     BoundSheetRecord sheet = (BoundSheetRecord)this.boundsheets.get(sheetnum);
/*  581 */     sheet.setSheetname(sheetname);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean doesContainsSheetName(String name, int excludeSheetIdx)
/*      */   {
/*  593 */     String aName = name;
/*  594 */     if (aName.length() > 31) {
/*  595 */       aName = aName.substring(0, 31);
/*      */     }
/*  597 */     for (int i = 0; i < this.boundsheets.size(); i++) {
/*  598 */       BoundSheetRecord boundSheetRecord = getBoundSheetRec(i);
/*  599 */       if (excludeSheetIdx != i)
/*      */       {
/*      */ 
/*  602 */         String bName = boundSheetRecord.getSheetname();
/*  603 */         if (bName.length() > 31) {
/*  604 */           bName = bName.substring(0, 31);
/*      */         }
/*  606 */         if (aName.equalsIgnoreCase(bName))
/*  607 */           return true;
/*      */       }
/*      */     }
/*  610 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSheetOrder(String sheetname, int pos)
/*      */   {
/*  621 */     int sheetNumber = getSheetIndex(sheetname);
/*      */     
/*  623 */     this.boundsheets.add(pos, this.boundsheets.remove(sheetNumber));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSheetName(int sheetIndex)
/*      */   {
/*  633 */     return getBoundSheetRec(sheetIndex).getSheetname();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSheetHidden(int sheetnum)
/*      */   {
/*  646 */     return getBoundSheetRec(sheetnum).isHidden();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSheetVeryHidden(int sheetnum)
/*      */   {
/*  659 */     return getBoundSheetRec(sheetnum).isVeryHidden();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSheetHidden(int sheetnum, boolean hidden)
/*      */   {
/*  669 */     getBoundSheetRec(sheetnum).setHidden(hidden);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSheetHidden(int sheetnum, int hidden)
/*      */   {
/*  682 */     BoundSheetRecord bsr = getBoundSheetRec(sheetnum);
/*  683 */     boolean h = false;
/*  684 */     boolean vh = false;
/*  685 */     if (hidden != 0) {
/*  686 */       if (hidden == 1) {
/*  687 */         h = true;
/*  688 */       } else if (hidden == 2) {
/*  689 */         vh = true;
/*      */       } else
/*  691 */         throw new IllegalArgumentException("Invalid hidden flag " + hidden + " given, must be 0, 1 or 2");
/*      */     }
/*  693 */     bsr.setHidden(h);
/*  694 */     bsr.setVeryHidden(vh);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSheetIndex(String name)
/*      */   {
/*  704 */     int retval = -1;
/*      */     
/*  706 */     for (int k = 0; k < this.boundsheets.size(); k++) {
/*  707 */       String sheet = getSheetName(k);
/*      */       
/*  709 */       if (sheet.equalsIgnoreCase(name)) {
/*  710 */         retval = k;
/*  711 */         break;
/*      */       }
/*      */     }
/*  714 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkSheets(int sheetnum)
/*      */   {
/*  722 */     if (this.boundsheets.size() <= sheetnum) {
/*  723 */       if (this.boundsheets.size() + 1 <= sheetnum) {
/*  724 */         throw new RuntimeException("Sheet number out of bounds!");
/*      */       }
/*  726 */       BoundSheetRecord bsr = createBoundSheet(sheetnum);
/*      */       
/*  728 */       this.records.add(this.records.getBspos() + 1, bsr);
/*  729 */       this.records.setBspos(this.records.getBspos() + 1);
/*  730 */       this.boundsheets.add(bsr);
/*  731 */       getOrCreateLinkTable().checkExternSheet(sheetnum);
/*  732 */       fixTabIdRecord();
/*      */ 
/*      */ 
/*      */     }
/*  736 */     else if (this.records.getTabpos() > 0) {
/*  737 */       TabIdRecord tir = (TabIdRecord)this.records.get(this.records.getTabpos());
/*  738 */       if (tir._tabids.length < this.boundsheets.size()) {
/*  739 */         fixTabIdRecord();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSheet(int sheetIndex)
/*      */   {
/*  749 */     if (this.boundsheets.size() > sheetIndex) {
/*  750 */       this.records.remove(this.records.getBspos() - (this.boundsheets.size() - 1) + sheetIndex);
/*  751 */       this.boundsheets.remove(sheetIndex);
/*  752 */       fixTabIdRecord();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  762 */     int sheetNum1Based = sheetIndex + 1;
/*  763 */     for (int i = 0; i < getNumNames(); i++) {
/*  764 */       NameRecord nr = getNameRecord(i);
/*      */       
/*  766 */       if (nr.getSheetNumber() == sheetNum1Based)
/*      */       {
/*  768 */         nr.setSheetNumber(0);
/*  769 */       } else if (nr.getSheetNumber() > sheetNum1Based)
/*      */       {
/*      */ 
/*  772 */         nr.setSheetNumber(nr.getSheetNumber() - 1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fixTabIdRecord()
/*      */   {
/*  782 */     TabIdRecord tir = (TabIdRecord)this.records.get(this.records.getTabpos());
/*  783 */     short[] tia = new short[this.boundsheets.size()];
/*      */     
/*  785 */     for (short k = 0; k < tia.length; k = (short)(k + 1)) {
/*  786 */       tia[k] = k;
/*      */     }
/*  788 */     tir.setTabIdArray(tia);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumSheets()
/*      */   {
/*  798 */     if (log.check(POILogger.DEBUG))
/*  799 */       log.log(DEBUG, "getNumSheets=", Integer.valueOf(this.boundsheets.size()));
/*  800 */     return this.boundsheets.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumExFormats()
/*      */   {
/*  810 */     if (log.check(POILogger.DEBUG))
/*  811 */       log.log(DEBUG, "getXF=", Integer.valueOf(this.numxfs));
/*  812 */     return this.numxfs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ExtendedFormatRecord getExFormatAt(int index)
/*      */   {
/*  823 */     int xfptr = this.records.getXfpos() - (this.numxfs - 1);
/*      */     
/*  825 */     xfptr += index;
/*  826 */     ExtendedFormatRecord retval = (ExtendedFormatRecord)this.records.get(xfptr);
/*      */     
/*      */ 
/*  829 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeExFormatRecord(ExtendedFormatRecord rec)
/*      */   {
/*  839 */     this.records.remove(rec);
/*  840 */     this.numxfs -= 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ExtendedFormatRecord createCellXF()
/*      */   {
/*  852 */     ExtendedFormatRecord xf = createExtendedFormat();
/*      */     
/*  854 */     this.records.add(this.records.getXfpos() + 1, xf);
/*  855 */     this.records.setXfpos(this.records.getXfpos() + 1);
/*  856 */     this.numxfs += 1;
/*  857 */     return xf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StyleRecord getStyleRecord(int xfIndex)
/*      */   {
/*  868 */     for (int i = this.records.getXfpos(); i < this.records.size(); i++) {
/*  869 */       Record r = this.records.get(i);
/*  870 */       if (!(r instanceof ExtendedFormatRecord))
/*      */       {
/*      */ 
/*  873 */         if ((r instanceof StyleRecord))
/*      */         {
/*      */ 
/*  876 */           StyleRecord sr = (StyleRecord)r;
/*  877 */           if (sr.getXFIndex() == xfIndex)
/*  878 */             return sr;
/*      */         } }
/*      */     }
/*  881 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StyleRecord createStyleRecord(int xfIndex)
/*      */   {
/*  891 */     StyleRecord newSR = new StyleRecord();
/*  892 */     newSR.setXFIndex(xfIndex);
/*      */     
/*      */ 
/*  895 */     int addAt = -1;
/*  896 */     for (int i = this.records.getXfpos(); 
/*  897 */         (i < this.records.size()) && (addAt == -1); i++) {
/*  898 */       Record r = this.records.get(i);
/*  899 */       if ((!(r instanceof ExtendedFormatRecord)) && (!(r instanceof StyleRecord)))
/*      */       {
/*      */ 
/*      */ 
/*  903 */         addAt = i;
/*      */       }
/*      */     }
/*  906 */     if (addAt == -1) {
/*  907 */       throw new IllegalStateException("No XF Records found!");
/*      */     }
/*  909 */     this.records.add(addAt, newSR);
/*      */     
/*  911 */     return newSR;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int addSSTString(UnicodeString string)
/*      */   {
/*  925 */     if (log.check(POILogger.DEBUG))
/*  926 */       log.log(DEBUG, "insert to sst string='", string);
/*  927 */     if (this.sst == null) {
/*  928 */       insertSST();
/*      */     }
/*  930 */     return this.sst.addString(string);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UnicodeString getSSTString(int str)
/*      */   {
/*  939 */     if (this.sst == null) {
/*  940 */       insertSST();
/*      */     }
/*  942 */     UnicodeString retval = this.sst.getString(str);
/*      */     
/*  944 */     if (log.check(POILogger.DEBUG)) {
/*  945 */       log.log(DEBUG, "Returning SST for index=", Integer.valueOf(str), " String= ", retval);
/*      */     }
/*  947 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertSST()
/*      */   {
/*  958 */     if (log.check(POILogger.DEBUG))
/*  959 */       log.log(DEBUG, "creating new SST via insertSST!");
/*  960 */     this.sst = new SSTRecord();
/*  961 */     this.records.add(this.records.size() - 1, createExtendedSST());
/*  962 */     this.records.add(this.records.size() - 2, this.sst);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int serialize(int offset, byte[] data)
/*      */   {
/* 1002 */     if (log.check(POILogger.DEBUG)) {
/* 1003 */       log.log(DEBUG, "Serializing Workbook with offsets");
/*      */     }
/* 1005 */     int pos = 0;
/*      */     
/* 1007 */     SSTRecord sst = null;
/* 1008 */     int sstPos = 0;
/* 1009 */     boolean wroteBoundSheets = false;
/* 1010 */     for (int k = 0; k < this.records.size(); k++)
/*      */     {
/*      */ 
/* 1013 */       Record record = this.records.get(k);
/*      */       
/* 1015 */       if ((record.getSid() != 449) || (((RecalcIdRecord)record).isNeeded()))
/*      */       {
/* 1017 */         int len = 0;
/* 1018 */         if ((record instanceof SSTRecord))
/*      */         {
/* 1020 */           sst = (SSTRecord)record;
/* 1021 */           sstPos = pos;
/*      */         }
/* 1023 */         if ((record.getSid() == 255) && (sst != null))
/*      */         {
/* 1025 */           record = sst.createExtSSTRecord(sstPos + offset);
/*      */         }
/* 1027 */         if ((record instanceof BoundSheetRecord)) {
/* 1028 */           if (!wroteBoundSheets) {
/* 1029 */             for (int i = 0; i < this.boundsheets.size(); i++) {
/* 1030 */               len += getBoundSheetRec(i).serialize(pos + offset + len, data);
/*      */             }
/*      */             
/* 1033 */             wroteBoundSheets = true;
/*      */           }
/*      */         } else {
/* 1036 */           len = record.serialize(pos + offset, data);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1042 */         pos += len;
/*      */       }
/*      */     }
/* 1045 */     if (log.check(POILogger.DEBUG))
/* 1046 */       log.log(DEBUG, "Exiting serialize workbook");
/* 1047 */     return pos;
/*      */   }
/*      */   
/*      */   public int getSize()
/*      */   {
/* 1052 */     int retval = 0;
/*      */     
/* 1054 */     SSTRecord sst = null;
/* 1055 */     for (int k = 0; k < this.records.size(); k++)
/*      */     {
/* 1057 */       Record record = this.records.get(k);
/*      */       
/* 1059 */       if ((record.getSid() != 449) || (((RecalcIdRecord)record).isNeeded()))
/*      */       {
/* 1061 */         if ((record instanceof SSTRecord))
/* 1062 */           sst = (SSTRecord)record;
/* 1063 */         if ((record.getSid() == 255) && (sst != null)) {
/* 1064 */           retval += sst.calcExtSSTRecordSize();
/*      */         } else
/* 1066 */           retval += record.getRecordSize();
/*      */       }
/*      */     }
/* 1069 */     return retval;
/*      */   }
/*      */   
/*      */   private static BOFRecord createBOF() {
/* 1073 */     BOFRecord retval = new BOFRecord();
/*      */     
/* 1075 */     retval.setVersion(1536);
/* 1076 */     retval.setType(5);
/* 1077 */     retval.setBuild(4307);
/* 1078 */     retval.setBuildYear(1996);
/* 1079 */     retval.setHistoryBitMask(65);
/* 1080 */     retval.setRequiredVersion(6);
/* 1081 */     return retval;
/*      */   }
/*      */   
/*      */   private static MMSRecord createMMS()
/*      */   {
/* 1086 */     MMSRecord retval = new MMSRecord();
/*      */     
/* 1088 */     retval.setAddMenuCount((byte)0);
/* 1089 */     retval.setDelMenuCount((byte)0);
/* 1090 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static WriteAccessRecord createWriteAccess()
/*      */   {
/* 1097 */     WriteAccessRecord retval = new WriteAccessRecord();
/*      */     try
/*      */     {
/* 1100 */       retval.setUsername(System.getProperty("user.name"));
/*      */     }
/*      */     catch (AccessControlException e)
/*      */     {
/* 1104 */       retval.setUsername("POI");
/*      */     }
/* 1106 */     return retval;
/*      */   }
/*      */   
/*      */   private static CodepageRecord createCodepage() {
/* 1110 */     CodepageRecord retval = new CodepageRecord();
/*      */     
/* 1112 */     retval.setCodepage((short)1200);
/* 1113 */     return retval;
/*      */   }
/*      */   
/*      */   private static DSFRecord createDSF() {
/* 1117 */     return new DSFRecord(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static TabIdRecord createTabId()
/*      */   {
/* 1124 */     return new TabIdRecord();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static FnGroupCountRecord createFnGroupCount()
/*      */   {
/* 1131 */     FnGroupCountRecord retval = new FnGroupCountRecord();
/*      */     
/* 1133 */     retval.setCount((short)14);
/* 1134 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static WindowProtectRecord createWindowProtect()
/*      */   {
/* 1143 */     return new WindowProtectRecord(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ProtectRecord createProtect()
/*      */   {
/* 1152 */     return new ProtectRecord(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static PasswordRecord createPassword()
/*      */   {
/* 1159 */     return new PasswordRecord(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static ProtectionRev4Record createProtectionRev4()
/*      */   {
/* 1166 */     return new ProtectionRev4Record(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static PasswordRev4Record createPasswordRev4()
/*      */   {
/* 1173 */     return new PasswordRev4Record(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static WindowOneRecord createWindowOne()
/*      */   {
/* 1189 */     WindowOneRecord retval = new WindowOneRecord();
/*      */     
/* 1191 */     retval.setHorizontalHold((short)360);
/* 1192 */     retval.setVerticalHold((short)270);
/* 1193 */     retval.setWidth((short)14940);
/* 1194 */     retval.setHeight((short)9150);
/* 1195 */     retval.setOptions((short)56);
/* 1196 */     retval.setActiveSheetIndex(0);
/* 1197 */     retval.setFirstVisibleTab(0);
/* 1198 */     retval.setNumSelectedTabs((short)1);
/* 1199 */     retval.setTabWidthRatio((short)600);
/* 1200 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static BackupRecord createBackup()
/*      */   {
/* 1207 */     BackupRecord retval = new BackupRecord();
/*      */     
/* 1209 */     retval.setBackup((short)0);
/* 1210 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static HideObjRecord createHideObj()
/*      */   {
/* 1217 */     HideObjRecord retval = new HideObjRecord();
/* 1218 */     retval.setHideObj((short)0);
/* 1219 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static DateWindow1904Record createDateWindow1904()
/*      */   {
/* 1226 */     DateWindow1904Record retval = new DateWindow1904Record();
/*      */     
/* 1228 */     retval.setWindowing((short)0);
/* 1229 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static PrecisionRecord createPrecision()
/*      */   {
/* 1236 */     PrecisionRecord retval = new PrecisionRecord();
/* 1237 */     retval.setFullPrecision(true);
/* 1238 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static RefreshAllRecord createRefreshAll()
/*      */   {
/* 1245 */     return new RefreshAllRecord(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static BookBoolRecord createBookBool()
/*      */   {
/* 1252 */     BookBoolRecord retval = new BookBoolRecord();
/* 1253 */     retval.setSaveLinkValues((short)0);
/* 1254 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static FontRecord createFont()
/*      */   {
/* 1267 */     FontRecord retval = new FontRecord();
/*      */     
/* 1269 */     retval.setFontHeight((short)200);
/* 1270 */     retval.setAttributes((short)0);
/* 1271 */     retval.setColorPaletteIndex((short)Short.MAX_VALUE);
/* 1272 */     retval.setBoldWeight((short)400);
/* 1273 */     retval.setFontName("Arial");
/* 1274 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static FormatRecord createFormat(int id)
/*      */   {
/* 1286 */     switch (id) {
/* 1287 */     case 0:  return new FormatRecord(5, "\"$\"#,##0_);\\(\"$\"#,##0\\)");
/* 1288 */     case 1:  return new FormatRecord(6, "\"$\"#,##0_);[Red]\\(\"$\"#,##0\\)");
/* 1289 */     case 2:  return new FormatRecord(7, "\"$\"#,##0.00_);\\(\"$\"#,##0.00\\)");
/* 1290 */     case 3:  return new FormatRecord(8, "\"$\"#,##0.00_);[Red]\\(\"$\"#,##0.00\\)");
/* 1291 */     case 4:  return new FormatRecord(42, "_(\"$\"* #,##0_);_(\"$\"* \\(#,##0\\);_(\"$\"* \"-\"_);_(@_)");
/* 1292 */     case 5:  return new FormatRecord(41, "_(* #,##0_);_(* \\(#,##0\\);_(* \"-\"_);_(@_)");
/* 1293 */     case 6:  return new FormatRecord(44, "_(\"$\"* #,##0.00_);_(\"$\"* \\(#,##0.00\\);_(\"$\"* \"-\"??_);_(@_)");
/* 1294 */     case 7:  return new FormatRecord(43, "_(* #,##0.00_);_(* \\(#,##0.00\\);_(* \"-\"??_);_(@_)");
/*      */     }
/* 1296 */     throw new IllegalArgumentException("Unexpected id " + id);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ExtendedFormatRecord createExtendedFormat(int id)
/*      */   {
/* 1305 */     ExtendedFormatRecord retval = new ExtendedFormatRecord();
/*      */     
/* 1307 */     switch (id)
/*      */     {
/*      */     case 0: 
/* 1310 */       retval.setFontIndex((short)0);
/* 1311 */       retval.setFormatIndex((short)0);
/* 1312 */       retval.setCellOptions((short)-11);
/* 1313 */       retval.setAlignmentOptions((short)32);
/* 1314 */       retval.setIndentionOptions((short)0);
/* 1315 */       retval.setBorderOptions((short)0);
/* 1316 */       retval.setPaletteOptions((short)0);
/* 1317 */       retval.setAdtlPaletteOptions((short)0);
/* 1318 */       retval.setFillPaletteOptions((short)8384);
/* 1319 */       break;
/*      */     
/*      */     case 1: 
/* 1322 */       retval.setFontIndex((short)1);
/* 1323 */       retval.setFormatIndex((short)0);
/* 1324 */       retval.setCellOptions((short)-11);
/* 1325 */       retval.setAlignmentOptions((short)32);
/* 1326 */       retval.setIndentionOptions((short)62464);
/* 1327 */       retval.setBorderOptions((short)0);
/* 1328 */       retval.setPaletteOptions((short)0);
/* 1329 */       retval.setAdtlPaletteOptions((short)0);
/* 1330 */       retval.setFillPaletteOptions((short)8384);
/* 1331 */       break;
/*      */     
/*      */     case 2: 
/* 1334 */       retval.setFontIndex((short)1);
/* 1335 */       retval.setFormatIndex((short)0);
/* 1336 */       retval.setCellOptions((short)-11);
/* 1337 */       retval.setAlignmentOptions((short)32);
/* 1338 */       retval.setIndentionOptions((short)62464);
/* 1339 */       retval.setBorderOptions((short)0);
/* 1340 */       retval.setPaletteOptions((short)0);
/* 1341 */       retval.setAdtlPaletteOptions((short)0);
/* 1342 */       retval.setFillPaletteOptions((short)8384);
/* 1343 */       break;
/*      */     
/*      */     case 3: 
/* 1346 */       retval.setFontIndex((short)2);
/* 1347 */       retval.setFormatIndex((short)0);
/* 1348 */       retval.setCellOptions((short)-11);
/* 1349 */       retval.setAlignmentOptions((short)32);
/* 1350 */       retval.setIndentionOptions((short)62464);
/* 1351 */       retval.setBorderOptions((short)0);
/* 1352 */       retval.setPaletteOptions((short)0);
/* 1353 */       retval.setAdtlPaletteOptions((short)0);
/* 1354 */       retval.setFillPaletteOptions((short)8384);
/* 1355 */       break;
/*      */     
/*      */     case 4: 
/* 1358 */       retval.setFontIndex((short)2);
/* 1359 */       retval.setFormatIndex((short)0);
/* 1360 */       retval.setCellOptions((short)-11);
/* 1361 */       retval.setAlignmentOptions((short)32);
/* 1362 */       retval.setIndentionOptions((short)62464);
/* 1363 */       retval.setBorderOptions((short)0);
/* 1364 */       retval.setPaletteOptions((short)0);
/* 1365 */       retval.setAdtlPaletteOptions((short)0);
/* 1366 */       retval.setFillPaletteOptions((short)8384);
/* 1367 */       break;
/*      */     
/*      */     case 5: 
/* 1370 */       retval.setFontIndex((short)0);
/* 1371 */       retval.setFormatIndex((short)0);
/* 1372 */       retval.setCellOptions((short)-11);
/* 1373 */       retval.setAlignmentOptions((short)32);
/* 1374 */       retval.setIndentionOptions((short)62464);
/* 1375 */       retval.setBorderOptions((short)0);
/* 1376 */       retval.setPaletteOptions((short)0);
/* 1377 */       retval.setAdtlPaletteOptions((short)0);
/* 1378 */       retval.setFillPaletteOptions((short)8384);
/* 1379 */       break;
/*      */     
/*      */     case 6: 
/* 1382 */       retval.setFontIndex((short)0);
/* 1383 */       retval.setFormatIndex((short)0);
/* 1384 */       retval.setCellOptions((short)-11);
/* 1385 */       retval.setAlignmentOptions((short)32);
/* 1386 */       retval.setIndentionOptions((short)62464);
/* 1387 */       retval.setBorderOptions((short)0);
/* 1388 */       retval.setPaletteOptions((short)0);
/* 1389 */       retval.setAdtlPaletteOptions((short)0);
/* 1390 */       retval.setFillPaletteOptions((short)8384);
/* 1391 */       break;
/*      */     
/*      */     case 7: 
/* 1394 */       retval.setFontIndex((short)0);
/* 1395 */       retval.setFormatIndex((short)0);
/* 1396 */       retval.setCellOptions((short)-11);
/* 1397 */       retval.setAlignmentOptions((short)32);
/* 1398 */       retval.setIndentionOptions((short)62464);
/* 1399 */       retval.setBorderOptions((short)0);
/* 1400 */       retval.setPaletteOptions((short)0);
/* 1401 */       retval.setAdtlPaletteOptions((short)0);
/* 1402 */       retval.setFillPaletteOptions((short)8384);
/* 1403 */       break;
/*      */     
/*      */     case 8: 
/* 1406 */       retval.setFontIndex((short)0);
/* 1407 */       retval.setFormatIndex((short)0);
/* 1408 */       retval.setCellOptions((short)-11);
/* 1409 */       retval.setAlignmentOptions((short)32);
/* 1410 */       retval.setIndentionOptions((short)62464);
/* 1411 */       retval.setBorderOptions((short)0);
/* 1412 */       retval.setPaletteOptions((short)0);
/* 1413 */       retval.setAdtlPaletteOptions((short)0);
/* 1414 */       retval.setFillPaletteOptions((short)8384);
/* 1415 */       break;
/*      */     
/*      */     case 9: 
/* 1418 */       retval.setFontIndex((short)0);
/* 1419 */       retval.setFormatIndex((short)0);
/* 1420 */       retval.setCellOptions((short)-11);
/* 1421 */       retval.setAlignmentOptions((short)32);
/* 1422 */       retval.setIndentionOptions((short)62464);
/* 1423 */       retval.setBorderOptions((short)0);
/* 1424 */       retval.setPaletteOptions((short)0);
/* 1425 */       retval.setAdtlPaletteOptions((short)0);
/* 1426 */       retval.setFillPaletteOptions((short)8384);
/* 1427 */       break;
/*      */     
/*      */     case 10: 
/* 1430 */       retval.setFontIndex((short)0);
/* 1431 */       retval.setFormatIndex((short)0);
/* 1432 */       retval.setCellOptions((short)-11);
/* 1433 */       retval.setAlignmentOptions((short)32);
/* 1434 */       retval.setIndentionOptions((short)62464);
/* 1435 */       retval.setBorderOptions((short)0);
/* 1436 */       retval.setPaletteOptions((short)0);
/* 1437 */       retval.setAdtlPaletteOptions((short)0);
/* 1438 */       retval.setFillPaletteOptions((short)8384);
/* 1439 */       break;
/*      */     
/*      */     case 11: 
/* 1442 */       retval.setFontIndex((short)0);
/* 1443 */       retval.setFormatIndex((short)0);
/* 1444 */       retval.setCellOptions((short)-11);
/* 1445 */       retval.setAlignmentOptions((short)32);
/* 1446 */       retval.setIndentionOptions((short)62464);
/* 1447 */       retval.setBorderOptions((short)0);
/* 1448 */       retval.setPaletteOptions((short)0);
/* 1449 */       retval.setAdtlPaletteOptions((short)0);
/* 1450 */       retval.setFillPaletteOptions((short)8384);
/* 1451 */       break;
/*      */     
/*      */     case 12: 
/* 1454 */       retval.setFontIndex((short)0);
/* 1455 */       retval.setFormatIndex((short)0);
/* 1456 */       retval.setCellOptions((short)-11);
/* 1457 */       retval.setAlignmentOptions((short)32);
/* 1458 */       retval.setIndentionOptions((short)62464);
/* 1459 */       retval.setBorderOptions((short)0);
/* 1460 */       retval.setPaletteOptions((short)0);
/* 1461 */       retval.setAdtlPaletteOptions((short)0);
/* 1462 */       retval.setFillPaletteOptions((short)8384);
/* 1463 */       break;
/*      */     
/*      */     case 13: 
/* 1466 */       retval.setFontIndex((short)0);
/* 1467 */       retval.setFormatIndex((short)0);
/* 1468 */       retval.setCellOptions((short)-11);
/* 1469 */       retval.setAlignmentOptions((short)32);
/* 1470 */       retval.setIndentionOptions((short)62464);
/* 1471 */       retval.setBorderOptions((short)0);
/* 1472 */       retval.setPaletteOptions((short)0);
/* 1473 */       retval.setAdtlPaletteOptions((short)0);
/* 1474 */       retval.setFillPaletteOptions((short)8384);
/* 1475 */       break;
/*      */     
/*      */     case 14: 
/* 1478 */       retval.setFontIndex((short)0);
/* 1479 */       retval.setFormatIndex((short)0);
/* 1480 */       retval.setCellOptions((short)-11);
/* 1481 */       retval.setAlignmentOptions((short)32);
/* 1482 */       retval.setIndentionOptions((short)62464);
/* 1483 */       retval.setBorderOptions((short)0);
/* 1484 */       retval.setPaletteOptions((short)0);
/* 1485 */       retval.setAdtlPaletteOptions((short)0);
/* 1486 */       retval.setFillPaletteOptions((short)8384);
/* 1487 */       break;
/*      */     
/*      */ 
/*      */     case 15: 
/* 1491 */       retval.setFontIndex((short)0);
/* 1492 */       retval.setFormatIndex((short)0);
/* 1493 */       retval.setCellOptions((short)1);
/* 1494 */       retval.setAlignmentOptions((short)32);
/* 1495 */       retval.setIndentionOptions((short)0);
/* 1496 */       retval.setBorderOptions((short)0);
/* 1497 */       retval.setPaletteOptions((short)0);
/* 1498 */       retval.setAdtlPaletteOptions((short)0);
/* 1499 */       retval.setFillPaletteOptions((short)8384);
/* 1500 */       break;
/*      */     
/*      */ 
/*      */     case 16: 
/* 1504 */       retval.setFontIndex((short)1);
/* 1505 */       retval.setFormatIndex((short)43);
/* 1506 */       retval.setCellOptions((short)-11);
/* 1507 */       retval.setAlignmentOptions((short)32);
/* 1508 */       retval.setIndentionOptions((short)63488);
/* 1509 */       retval.setBorderOptions((short)0);
/* 1510 */       retval.setPaletteOptions((short)0);
/* 1511 */       retval.setAdtlPaletteOptions((short)0);
/* 1512 */       retval.setFillPaletteOptions((short)8384);
/* 1513 */       break;
/*      */     
/*      */     case 17: 
/* 1516 */       retval.setFontIndex((short)1);
/* 1517 */       retval.setFormatIndex((short)41);
/* 1518 */       retval.setCellOptions((short)-11);
/* 1519 */       retval.setAlignmentOptions((short)32);
/* 1520 */       retval.setIndentionOptions((short)63488);
/* 1521 */       retval.setBorderOptions((short)0);
/* 1522 */       retval.setPaletteOptions((short)0);
/* 1523 */       retval.setAdtlPaletteOptions((short)0);
/* 1524 */       retval.setFillPaletteOptions((short)8384);
/* 1525 */       break;
/*      */     
/*      */     case 18: 
/* 1528 */       retval.setFontIndex((short)1);
/* 1529 */       retval.setFormatIndex((short)44);
/* 1530 */       retval.setCellOptions((short)-11);
/* 1531 */       retval.setAlignmentOptions((short)32);
/* 1532 */       retval.setIndentionOptions((short)63488);
/* 1533 */       retval.setBorderOptions((short)0);
/* 1534 */       retval.setPaletteOptions((short)0);
/* 1535 */       retval.setAdtlPaletteOptions((short)0);
/* 1536 */       retval.setFillPaletteOptions((short)8384);
/* 1537 */       break;
/*      */     
/*      */     case 19: 
/* 1540 */       retval.setFontIndex((short)1);
/* 1541 */       retval.setFormatIndex((short)42);
/* 1542 */       retval.setCellOptions((short)-11);
/* 1543 */       retval.setAlignmentOptions((short)32);
/* 1544 */       retval.setIndentionOptions((short)63488);
/* 1545 */       retval.setBorderOptions((short)0);
/* 1546 */       retval.setPaletteOptions((short)0);
/* 1547 */       retval.setAdtlPaletteOptions((short)0);
/* 1548 */       retval.setFillPaletteOptions((short)8384);
/* 1549 */       break;
/*      */     
/*      */     case 20: 
/* 1552 */       retval.setFontIndex((short)1);
/* 1553 */       retval.setFormatIndex((short)9);
/* 1554 */       retval.setCellOptions((short)-11);
/* 1555 */       retval.setAlignmentOptions((short)32);
/* 1556 */       retval.setIndentionOptions((short)63488);
/* 1557 */       retval.setBorderOptions((short)0);
/* 1558 */       retval.setPaletteOptions((short)0);
/* 1559 */       retval.setAdtlPaletteOptions((short)0);
/* 1560 */       retval.setFillPaletteOptions((short)8384);
/* 1561 */       break;
/*      */     
/*      */ 
/*      */     case 21: 
/* 1565 */       retval.setFontIndex((short)5);
/* 1566 */       retval.setFormatIndex((short)0);
/* 1567 */       retval.setCellOptions((short)1);
/* 1568 */       retval.setAlignmentOptions((short)32);
/* 1569 */       retval.setIndentionOptions((short)2048);
/* 1570 */       retval.setBorderOptions((short)0);
/* 1571 */       retval.setPaletteOptions((short)0);
/* 1572 */       retval.setAdtlPaletteOptions((short)0);
/* 1573 */       retval.setFillPaletteOptions((short)8384);
/* 1574 */       break;
/*      */     
/*      */     case 22: 
/* 1577 */       retval.setFontIndex((short)6);
/* 1578 */       retval.setFormatIndex((short)0);
/* 1579 */       retval.setCellOptions((short)1);
/* 1580 */       retval.setAlignmentOptions((short)32);
/* 1581 */       retval.setIndentionOptions((short)23552);
/* 1582 */       retval.setBorderOptions((short)0);
/* 1583 */       retval.setPaletteOptions((short)0);
/* 1584 */       retval.setAdtlPaletteOptions((short)0);
/* 1585 */       retval.setFillPaletteOptions((short)8384);
/* 1586 */       break;
/*      */     
/*      */     case 23: 
/* 1589 */       retval.setFontIndex((short)0);
/* 1590 */       retval.setFormatIndex((short)49);
/* 1591 */       retval.setCellOptions((short)1);
/* 1592 */       retval.setAlignmentOptions((short)32);
/* 1593 */       retval.setIndentionOptions((short)23552);
/* 1594 */       retval.setBorderOptions((short)0);
/* 1595 */       retval.setPaletteOptions((short)0);
/* 1596 */       retval.setAdtlPaletteOptions((short)0);
/* 1597 */       retval.setFillPaletteOptions((short)8384);
/* 1598 */       break;
/*      */     
/*      */     case 24: 
/* 1601 */       retval.setFontIndex((short)0);
/* 1602 */       retval.setFormatIndex((short)8);
/* 1603 */       retval.setCellOptions((short)1);
/* 1604 */       retval.setAlignmentOptions((short)32);
/* 1605 */       retval.setIndentionOptions((short)23552);
/* 1606 */       retval.setBorderOptions((short)0);
/* 1607 */       retval.setPaletteOptions((short)0);
/* 1608 */       retval.setAdtlPaletteOptions((short)0);
/* 1609 */       retval.setFillPaletteOptions((short)8384);
/* 1610 */       break;
/*      */     
/*      */     case 25: 
/* 1613 */       retval.setFontIndex((short)6);
/* 1614 */       retval.setFormatIndex((short)8);
/* 1615 */       retval.setCellOptions((short)1);
/* 1616 */       retval.setAlignmentOptions((short)32);
/* 1617 */       retval.setIndentionOptions((short)23552);
/* 1618 */       retval.setBorderOptions((short)0);
/* 1619 */       retval.setPaletteOptions((short)0);
/* 1620 */       retval.setAdtlPaletteOptions((short)0);
/* 1621 */       retval.setFillPaletteOptions((short)8384);
/*      */     }
/*      */     
/* 1624 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ExtendedFormatRecord createExtendedFormat()
/*      */   {
/* 1632 */     ExtendedFormatRecord retval = new ExtendedFormatRecord();
/*      */     
/* 1634 */     retval.setFontIndex((short)0);
/* 1635 */     retval.setFormatIndex((short)0);
/* 1636 */     retval.setCellOptions((short)1);
/* 1637 */     retval.setAlignmentOptions((short)32);
/* 1638 */     retval.setIndentionOptions((short)0);
/* 1639 */     retval.setBorderOptions((short)0);
/* 1640 */     retval.setPaletteOptions((short)0);
/* 1641 */     retval.setAdtlPaletteOptions((short)0);
/* 1642 */     retval.setFillPaletteOptions((short)8384);
/* 1643 */     retval.setTopBorderPaletteIdx((short)8);
/* 1644 */     retval.setBottomBorderPaletteIdx((short)8);
/* 1645 */     retval.setLeftBorderPaletteIdx((short)8);
/* 1646 */     retval.setRightBorderPaletteIdx((short)8);
/* 1647 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static StyleRecord createStyle(int id)
/*      */   {
/* 1656 */     StyleRecord retval = new StyleRecord();
/*      */     
/* 1658 */     switch (id)
/*      */     {
/*      */     case 0: 
/* 1661 */       retval.setXFIndex(16);
/* 1662 */       retval.setBuiltinStyle(3);
/* 1663 */       retval.setOutlineStyleLevel(-1);
/* 1664 */       break;
/*      */     
/*      */     case 1: 
/* 1667 */       retval.setXFIndex(17);
/* 1668 */       retval.setBuiltinStyle(6);
/* 1669 */       retval.setOutlineStyleLevel(-1);
/* 1670 */       break;
/*      */     
/*      */     case 2: 
/* 1673 */       retval.setXFIndex(18);
/* 1674 */       retval.setBuiltinStyle(4);
/* 1675 */       retval.setOutlineStyleLevel(-1);
/* 1676 */       break;
/*      */     
/*      */     case 3: 
/* 1679 */       retval.setXFIndex(19);
/* 1680 */       retval.setBuiltinStyle(7);
/* 1681 */       retval.setOutlineStyleLevel(-1);
/* 1682 */       break;
/*      */     
/*      */     case 4: 
/* 1685 */       retval.setXFIndex(0);
/* 1686 */       retval.setBuiltinStyle(0);
/* 1687 */       retval.setOutlineStyleLevel(-1);
/* 1688 */       break;
/*      */     
/*      */     case 5: 
/* 1691 */       retval.setXFIndex(20);
/* 1692 */       retval.setBuiltinStyle(5);
/* 1693 */       retval.setOutlineStyleLevel(-1);
/*      */     }
/*      */     
/* 1696 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static PaletteRecord createPalette()
/*      */   {
/* 1703 */     return new PaletteRecord();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static UseSelFSRecord createUseSelFS()
/*      */   {
/* 1710 */     return new UseSelFSRecord(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static BoundSheetRecord createBoundSheet(int id)
/*      */   {
/* 1722 */     return new BoundSheetRecord("Sheet" + (id + 1));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static CountryRecord createCountry()
/*      */   {
/* 1730 */     CountryRecord retval = new CountryRecord();
/*      */     
/* 1732 */     retval.setDefaultCountry((short)1);
/*      */     
/*      */ 
/* 1735 */     if (Locale.getDefault().toString().equals("ru_RU")) {
/* 1736 */       retval.setCurrentCountry((short)7);
/*      */     }
/*      */     else {
/* 1739 */       retval.setCurrentCountry((short)1);
/*      */     }
/*      */     
/* 1742 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ExtSSTRecord createExtendedSST()
/*      */   {
/* 1751 */     ExtSSTRecord retval = new ExtSSTRecord();
/* 1752 */     retval.setNumStringsPerBucket((short)8);
/* 1753 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private LinkTable getOrCreateLinkTable()
/*      */   {
/* 1761 */     if (this.linkTable == null) {
/* 1762 */       this.linkTable = new LinkTable((short)getNumSheets(), this.records);
/*      */     }
/* 1764 */     return this.linkTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findSheetNameFromExternSheet(int externSheetIndex)
/*      */   {
/* 1773 */     int indexToSheet = this.linkTable.getIndexToInternalSheet(externSheetIndex);
/* 1774 */     if (indexToSheet < 0)
/*      */     {
/*      */ 
/* 1777 */       return "";
/*      */     }
/* 1779 */     if (indexToSheet >= this.boundsheets.size())
/*      */     {
/* 1781 */       return "";
/*      */     }
/* 1783 */     return getSheetName(indexToSheet);
/*      */   }
/*      */   
/* 1786 */   public EvaluationWorkbook.ExternalSheet getExternalSheet(int externSheetIndex) { String[] extNames = this.linkTable.getExternalBookAndSheetName(externSheetIndex);
/* 1787 */     if (extNames == null) {
/* 1788 */       return null;
/*      */     }
/* 1790 */     return new EvaluationWorkbook.ExternalSheet(extNames[0], extNames[1]);
/*      */   }
/*      */   
/* 1793 */   public EvaluationWorkbook.ExternalName getExternalName(int externSheetIndex, int externNameIndex) { String nameName = this.linkTable.resolveNameXText(externSheetIndex, externNameIndex);
/* 1794 */     if (nameName == null) {
/* 1795 */       return null;
/*      */     }
/* 1797 */     int ix = this.linkTable.resolveNameXIx(externSheetIndex, externNameIndex);
/* 1798 */     return new EvaluationWorkbook.ExternalName(nameName, externNameIndex, ix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSheetIndexFromExternSheetIndex(int externSheetNumber)
/*      */   {
/* 1808 */     return this.linkTable.getSheetIndexFromExternSheetIndex(externSheetNumber);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short checkExternSheet(int sheetNumber)
/*      */   {
/* 1817 */     return (short)getOrCreateLinkTable().checkExternSheet(sheetNumber);
/*      */   }
/*      */   
/*      */   public int getExternalSheetIndex(String workbookName, String sheetName) {
/* 1821 */     return getOrCreateLinkTable().getExternalSheetIndex(workbookName, sheetName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNumNames()
/*      */   {
/* 1829 */     if (this.linkTable == null) {
/* 1830 */       return 0;
/*      */     }
/* 1832 */     return this.linkTable.getNumNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public NameRecord getNameRecord(int index)
/*      */   {
/* 1840 */     return this.linkTable.getNameRecord(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public NameCommentRecord getNameCommentRecord(NameRecord nameRecord)
/*      */   {
/* 1848 */     return (NameCommentRecord)this.commentRecords.get(nameRecord.getNameText());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public NameRecord createName()
/*      */   {
/* 1855 */     return addName(new NameRecord());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NameRecord addName(NameRecord name)
/*      */   {
/* 1865 */     LinkTable linkTable = getOrCreateLinkTable();
/* 1866 */     linkTable.addName(name);
/*      */     
/* 1868 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public NameRecord createBuiltInName(byte builtInName, int sheetNumber)
/*      */   {
/* 1876 */     if ((sheetNumber < 0) || (sheetNumber + 1 > 32767)) {
/* 1877 */       throw new IllegalArgumentException("Sheet number [" + sheetNumber + "]is not valid ");
/*      */     }
/*      */     
/* 1880 */     NameRecord name = new NameRecord(builtInName, sheetNumber);
/*      */     
/* 1882 */     if (this.linkTable.nameAlreadyExists(name)) {
/* 1883 */       throw new RuntimeException("Builtin (" + builtInName + ") already exists for sheet (" + sheetNumber + ")");
/*      */     }
/*      */     
/* 1886 */     addName(name);
/* 1887 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeName(int nameIndex)
/*      */   {
/* 1896 */     if (this.linkTable.getNumNames() > nameIndex) {
/* 1897 */       int idx = findFirstRecordLocBySid((short)24);
/* 1898 */       this.records.remove(idx + nameIndex);
/* 1899 */       this.linkTable.removeName(nameIndex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNameCommentRecordCache(NameCommentRecord commentRecord)
/*      */   {
/* 1908 */     if (this.commentRecords.containsValue(commentRecord)) {
/* 1909 */       for (Map.Entry<String, NameCommentRecord> entry : this.commentRecords.entrySet()) {
/* 1910 */         if (((NameCommentRecord)entry.getValue()).equals(commentRecord)) {
/* 1911 */           this.commentRecords.remove(entry.getKey());
/* 1912 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1916 */     this.commentRecords.put(commentRecord.getNameText(), commentRecord);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getFormat(String format, boolean createIfNotFound)
/*      */   {
/* 1926 */     for (FormatRecord r : this.formats) {
/* 1927 */       if (r.getFormatString().equals(format)) {
/* 1928 */         return (short)r.getIndexCode();
/*      */       }
/*      */     }
/*      */     
/* 1932 */     if (createIfNotFound) {
/* 1933 */       return (short)createFormat(format);
/*      */     }
/*      */     
/* 1936 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<FormatRecord> getFormats()
/*      */   {
/* 1944 */     return this.formats;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int createFormat(String formatString)
/*      */   {
/* 1956 */     this.maxformatid = (this.maxformatid >= 164 ? this.maxformatid + 1 : 164);
/* 1957 */     FormatRecord rec = new FormatRecord(this.maxformatid, formatString);
/*      */     
/* 1959 */     int pos = 0;
/* 1960 */     while ((pos < this.records.size()) && (this.records.get(pos).getSid() != 1054))
/* 1961 */       pos++;
/* 1962 */     pos += this.formats.size();
/* 1963 */     this.formats.add(rec);
/* 1964 */     this.records.add(pos, rec);
/* 1965 */     return this.maxformatid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Record findFirstRecordBySid(short sid)
/*      */   {
/* 1974 */     for (Record record : this.records) {
/* 1975 */       if (record.getSid() == sid) {
/* 1976 */         return record;
/*      */       }
/*      */     }
/* 1979 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int findFirstRecordLocBySid(short sid)
/*      */   {
/* 1988 */     int index = 0;
/* 1989 */     for (Record record : this.records) {
/* 1990 */       if (record.getSid() == sid) {
/* 1991 */         return index;
/*      */       }
/* 1993 */       index++;
/*      */     }
/* 1995 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Record findNextRecordBySid(short sid, int pos)
/*      */   {
/* 2002 */     int matches = 0;
/* 2003 */     for (Record record : this.records) {
/* 2004 */       if ((record.getSid() == sid) && 
/* 2005 */         (matches++ == pos)) {
/* 2006 */         return record;
/*      */       }
/*      */     }
/* 2009 */     return null;
/*      */   }
/*      */   
/*      */   public List<HyperlinkRecord> getHyperlinks()
/*      */   {
/* 2014 */     return this.hyperlinks;
/*      */   }
/*      */   
/*      */   public List<Record> getRecords() {
/* 2018 */     return this.records.getRecords();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUsing1904DateWindowing()
/*      */   {
/* 2028 */     return this.uses1904datewindowing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PaletteRecord getCustomPalette()
/*      */   {
/* 2038 */     int palettePos = this.records.getPalettepos();
/* 2039 */     PaletteRecord palette; PaletteRecord palette; if (palettePos != -1) {
/* 2040 */       Record rec = this.records.get(palettePos);
/* 2041 */       PaletteRecord palette; if ((rec instanceof PaletteRecord))
/* 2042 */         palette = (PaletteRecord)rec; else {
/* 2043 */         throw new RuntimeException("InternalError: Expected PaletteRecord but got a '" + rec + "'");
/*      */       }
/*      */     }
/*      */     else {
/* 2047 */       palette = createPalette();
/*      */       
/* 2049 */       this.records.add(1, palette);
/* 2050 */       this.records.setPalettepos(1);
/*      */     }
/* 2052 */     return palette;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void findDrawingGroup()
/*      */   {
/* 2059 */     if (this.drawingManager != null)
/*      */     {
/* 2061 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2066 */     for (Record r : this.records) {
/* 2067 */       if ((r instanceof DrawingGroupRecord)) {
/* 2068 */         DrawingGroupRecord dg = (DrawingGroupRecord)r;
/* 2069 */         dg.processChildRecords();
/*      */         
/* 2071 */         EscherContainerRecord cr = dg.getEscherContainer();
/*      */         
/* 2073 */         if (cr != null)
/*      */         {
/*      */ 
/*      */ 
/* 2077 */           EscherDggRecord dgg = null;
/* 2078 */           for (Iterator<EscherRecord> it = cr.getChildIterator(); it.hasNext();) {
/* 2079 */             Object er = it.next();
/* 2080 */             if ((er instanceof EscherDggRecord)) {
/* 2081 */               dgg = (EscherDggRecord)er;
/*      */             }
/*      */           }
/*      */           
/* 2085 */           if (dgg != null) {
/* 2086 */             this.drawingManager = new DrawingManager2(dgg);
/* 2087 */             return;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2093 */     int dgLoc = findFirstRecordLocBySid((short)235);
/*      */     
/*      */ 
/* 2096 */     if (dgLoc != -1) {
/* 2097 */       DrawingGroupRecord dg = (DrawingGroupRecord)this.records.get(dgLoc);
/* 2098 */       EscherDggRecord dgg = null;
/* 2099 */       for (EscherRecord er : dg.getEscherRecords()) {
/* 2100 */         if ((er instanceof EscherDggRecord)) {
/* 2101 */           dgg = (EscherDggRecord)er;
/*      */         }
/*      */       }
/*      */       
/* 2105 */       if (dgg != null) {
/* 2106 */         this.drawingManager = new DrawingManager2(dgg);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createDrawingGroup()
/*      */   {
/* 2116 */     if (this.drawingManager == null) {
/* 2117 */       EscherContainerRecord dggContainer = new EscherContainerRecord();
/* 2118 */       EscherDggRecord dgg = new EscherDggRecord();
/* 2119 */       EscherOptRecord opt = new EscherOptRecord();
/* 2120 */       EscherSplitMenuColorsRecord splitMenuColors = new EscherSplitMenuColorsRecord();
/*      */       
/* 2122 */       dggContainer.setRecordId((short)61440);
/* 2123 */       dggContainer.setOptions((short)15);
/* 2124 */       dgg.setRecordId((short)61446);
/* 2125 */       dgg.setOptions((short)0);
/* 2126 */       dgg.setShapeIdMax(1024);
/* 2127 */       dgg.setNumShapesSaved(0);
/* 2128 */       dgg.setDrawingsSaved(0);
/* 2129 */       dgg.setFileIdClusters(new EscherDggRecord.FileIdCluster[0]);
/* 2130 */       this.drawingManager = new DrawingManager2(dgg);
/* 2131 */       EscherContainerRecord bstoreContainer = null;
/* 2132 */       if (this.escherBSERecords.size() > 0)
/*      */       {
/* 2134 */         bstoreContainer = new EscherContainerRecord();
/* 2135 */         bstoreContainer.setRecordId((short)61441);
/* 2136 */         bstoreContainer.setOptions((short)(this.escherBSERecords.size() << 4 | 0xF));
/* 2137 */         for (EscherRecord escherRecord : this.escherBSERecords) {
/* 2138 */           bstoreContainer.addChildRecord(escherRecord);
/*      */         }
/*      */       }
/* 2141 */       opt.setRecordId((short)61451);
/* 2142 */       opt.setOptions((short)51);
/* 2143 */       opt.addEscherProperty(new EscherBoolProperty((short)191, 524296));
/* 2144 */       opt.addEscherProperty(new EscherRGBProperty((short)385, 134217793));
/* 2145 */       opt.addEscherProperty(new EscherRGBProperty((short)448, 134217792));
/* 2146 */       splitMenuColors.setRecordId((short)61726);
/* 2147 */       splitMenuColors.setOptions((short)64);
/* 2148 */       splitMenuColors.setColor1(134217741);
/* 2149 */       splitMenuColors.setColor2(134217740);
/* 2150 */       splitMenuColors.setColor3(134217751);
/* 2151 */       splitMenuColors.setColor4(268435703);
/*      */       
/* 2153 */       dggContainer.addChildRecord(dgg);
/* 2154 */       if (bstoreContainer != null)
/* 2155 */         dggContainer.addChildRecord(bstoreContainer);
/* 2156 */       dggContainer.addChildRecord(opt);
/* 2157 */       dggContainer.addChildRecord(splitMenuColors);
/*      */       
/* 2159 */       int dgLoc = findFirstRecordLocBySid((short)235);
/* 2160 */       if (dgLoc == -1) {
/* 2161 */         DrawingGroupRecord drawingGroup = new DrawingGroupRecord();
/* 2162 */         drawingGroup.addEscherRecord(dggContainer);
/* 2163 */         int loc = findFirstRecordLocBySid((short)140);
/*      */         
/* 2165 */         getRecords().add(loc + 1, drawingGroup);
/*      */       } else {
/* 2167 */         DrawingGroupRecord drawingGroup = new DrawingGroupRecord();
/* 2168 */         drawingGroup.addEscherRecord(dggContainer);
/* 2169 */         getRecords().set(dgLoc, drawingGroup);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public WindowOneRecord getWindowOne()
/*      */   {
/* 2176 */     return this.windowOne;
/*      */   }
/*      */   
/*      */   public EscherBSERecord getBSERecord(int pictureIndex) {
/* 2180 */     return (EscherBSERecord)this.escherBSERecords.get(pictureIndex - 1);
/*      */   }
/*      */   
/*      */   public int addBSERecord(EscherBSERecord e) {
/* 2184 */     createDrawingGroup();
/*      */     
/*      */ 
/* 2187 */     this.escherBSERecords.add(e);
/*      */     
/* 2189 */     int dgLoc = findFirstRecordLocBySid((short)235);
/* 2190 */     DrawingGroupRecord drawingGroup = (DrawingGroupRecord)getRecords().get(dgLoc);
/*      */     
/* 2192 */     EscherContainerRecord dggContainer = (EscherContainerRecord)drawingGroup.getEscherRecord(0);
/*      */     EscherContainerRecord bstoreContainer;
/* 2194 */     EscherContainerRecord bstoreContainer; if (dggContainer.getChild(1).getRecordId() == 61441)
/*      */     {
/* 2196 */       bstoreContainer = (EscherContainerRecord)dggContainer.getChild(1);
/*      */     }
/*      */     else
/*      */     {
/* 2200 */       bstoreContainer = new EscherContainerRecord();
/* 2201 */       bstoreContainer.setRecordId((short)61441);
/* 2202 */       List<EscherRecord> childRecords = dggContainer.getChildRecords();
/* 2203 */       childRecords.add(1, bstoreContainer);
/* 2204 */       dggContainer.setChildRecords(childRecords);
/*      */     }
/* 2206 */     bstoreContainer.setOptions((short)(this.escherBSERecords.size() << 4 | 0xF));
/*      */     
/* 2208 */     bstoreContainer.addChildRecord(e);
/*      */     
/* 2210 */     return this.escherBSERecords.size();
/*      */   }
/*      */   
/*      */   public DrawingManager2 getDrawingManager()
/*      */   {
/* 2215 */     return this.drawingManager;
/*      */   }
/*      */   
/*      */   public WriteProtectRecord getWriteProtect() {
/* 2219 */     if (this.writeProtect == null) {
/* 2220 */       this.writeProtect = new WriteProtectRecord();
/* 2221 */       int i = 0;
/* 2222 */       i = 0;
/* 2223 */       while ((i < this.records.size()) && (!(this.records.get(i) instanceof BOFRecord))) {
/* 2224 */         i++;
/*      */       }
/* 2226 */       this.records.add(i + 1, this.writeProtect);
/*      */     }
/* 2228 */     return this.writeProtect;
/*      */   }
/*      */   
/*      */   public WriteAccessRecord getWriteAccess() {
/* 2232 */     if (this.writeAccess == null) {
/* 2233 */       this.writeAccess = createWriteAccess();
/* 2234 */       int i = 0;
/* 2235 */       i = 0;
/* 2236 */       while ((i < this.records.size()) && (!(this.records.get(i) instanceof InterfaceEndRecord))) {
/* 2237 */         i++;
/*      */       }
/* 2239 */       this.records.add(i + 1, this.writeAccess);
/*      */     }
/* 2241 */     return this.writeAccess;
/*      */   }
/*      */   
/*      */   public FileSharingRecord getFileSharing() {
/* 2245 */     if (this.fileShare == null) {
/* 2246 */       this.fileShare = new FileSharingRecord();
/* 2247 */       int i = 0;
/* 2248 */       i = 0;
/* 2249 */       while ((i < this.records.size()) && (!(this.records.get(i) instanceof WriteAccessRecord))) {
/* 2250 */         i++;
/*      */       }
/* 2252 */       this.records.add(i + 1, this.fileShare);
/*      */     }
/* 2254 */     return this.fileShare;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isWriteProtected()
/*      */   {
/* 2261 */     if (this.fileShare == null) {
/* 2262 */       return false;
/*      */     }
/* 2264 */     FileSharingRecord frec = getFileSharing();
/* 2265 */     return frec.getReadOnly() == 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeProtectWorkbook(String password, String username)
/*      */   {
/* 2274 */     int protIdx = -1;
/* 2275 */     FileSharingRecord frec = getFileSharing();
/* 2276 */     WriteAccessRecord waccess = getWriteAccess();
/* 2277 */     WriteProtectRecord wprotect = getWriteProtect();
/* 2278 */     frec.setReadOnly((short)1);
/* 2279 */     frec.setPassword(FileSharingRecord.hashPassword(password));
/* 2280 */     frec.setUsername(username);
/* 2281 */     waccess.setUsername(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void unwriteProtectWorkbook()
/*      */   {
/* 2288 */     this.records.remove(this.fileShare);
/* 2289 */     this.records.remove(this.writeProtect);
/* 2290 */     this.fileShare = null;
/* 2291 */     this.writeProtect = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String resolveNameXText(int refIndex, int definedNameIndex)
/*      */   {
/* 2300 */     return this.linkTable.resolveNameXText(refIndex, definedNameIndex);
/*      */   }
/*      */   
/*      */   public NameXPtg getNameXPtg(String name) {
/* 2304 */     return getOrCreateLinkTable().getNameXPtg(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cloneDrawings(InternalSheet sheet)
/*      */   {
/* 2315 */     findDrawingGroup();
/*      */     
/* 2317 */     if (this.drawingManager == null)
/*      */     {
/* 2319 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2323 */     int aggLoc = sheet.aggregateDrawingRecords(this.drawingManager, false);
/* 2324 */     int dgId; EscherDgRecord dg; Iterator<EscherRecord> it; if (aggLoc != -1) {
/* 2325 */       EscherAggregate agg = (EscherAggregate)sheet.findFirstRecordBySid((short)9876);
/* 2326 */       EscherContainerRecord escherContainer = agg.getEscherContainer();
/* 2327 */       if (escherContainer == null) {
/* 2328 */         return;
/*      */       }
/*      */       
/* 2331 */       EscherDggRecord dgg = this.drawingManager.getDgg();
/*      */       
/*      */ 
/* 2334 */       dgId = this.drawingManager.findNewDrawingGroupId();
/* 2335 */       dgg.addCluster(dgId, 0);
/* 2336 */       dgg.setDrawingsSaved(dgg.getDrawingsSaved() + 1);
/*      */       
/* 2338 */       dg = null;
/* 2339 */       for (it = escherContainer.getChildIterator(); it.hasNext();) {
/* 2340 */         EscherRecord er = (EscherRecord)it.next();
/* 2341 */         if ((er instanceof EscherDgRecord)) {
/* 2342 */           dg = (EscherDgRecord)er;
/*      */           
/* 2344 */           dg.setOptions((short)(dgId << 4));
/* 2345 */         } else if ((er instanceof EscherContainerRecord))
/*      */         {
/* 2347 */           List<EscherRecord> spRecords = new ArrayList();
/* 2348 */           EscherContainerRecord cp = (EscherContainerRecord)er;
/* 2349 */           cp.getRecordsById((short)61450, spRecords);
/* 2350 */           for (spIt = spRecords.iterator(); spIt.hasNext();) {
/* 2351 */             EscherSpRecord sp = (EscherSpRecord)spIt.next();
/* 2352 */             int shapeId = this.drawingManager.allocateShapeId((short)dgId, dg);
/*      */             
/* 2354 */             dg.setNumShapes(dg.getNumShapes() - 1);
/* 2355 */             sp.setShapeId(shapeId);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     Iterator<EscherRecord> spIt;
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateNamesAfterCellShift(FormulaShifter shifter)
/*      */   {
/* 2367 */     for (int i = 0; i < getNumNames(); i++) {
/* 2368 */       NameRecord nr = getNameRecord(i);
/* 2369 */       Ptg[] ptgs = nr.getNameDefinition();
/* 2370 */       if (shifter.adjustFormula(ptgs, nr.getSheetNumber())) {
/* 2371 */         nr.setNameDefinition(ptgs);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\InternalWorkbook.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */