/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherBoolProperty;
/*     */ import org.apache.poi.ddf.EscherClientAnchorRecord;
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherShapePathProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.EndSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineShape
/*     */   extends AbstractShape
/*     */ {
/*     */   private EscherContainerRecord spContainer;
/*     */   private ObjRecord objRecord;
/*     */   
/*     */   LineShape(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  45 */     this.spContainer = createSpContainer(hssfShape, shapeId);
/*  46 */     this.objRecord = createObjRecord(hssfShape, shapeId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainerRecord createSpContainer(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  54 */     HSSFShape shape = hssfShape;
/*     */     
/*  56 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/*  57 */     EscherSpRecord sp = new EscherSpRecord();
/*  58 */     EscherOptRecord opt = new EscherOptRecord();
/*  59 */     EscherRecord anchor = new EscherClientAnchorRecord();
/*  60 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*     */     
/*  62 */     spContainer.setRecordId((short)61444);
/*  63 */     spContainer.setOptions((short)15);
/*  64 */     sp.setRecordId((short)61450);
/*  65 */     sp.setOptions((short)322);
/*     */     
/*  67 */     sp.setShapeId(shapeId);
/*  68 */     sp.setFlags(2560);
/*  69 */     opt.setRecordId((short)61451);
/*  70 */     opt.addEscherProperty(new EscherShapePathProperty((short)324, 4));
/*  71 */     opt.addEscherProperty(new EscherBoolProperty((short)511, 1048592));
/*  72 */     addStandardOptions(shape, opt);
/*  73 */     HSSFAnchor userAnchor = shape.getAnchor();
/*  74 */     if (userAnchor.isHorizontallyFlipped())
/*  75 */       sp.setFlags(sp.getFlags() | 0x40);
/*  76 */     if (userAnchor.isVerticallyFlipped())
/*  77 */       sp.setFlags(sp.getFlags() | 0x80);
/*  78 */     anchor = createAnchor(userAnchor);
/*  79 */     clientData.setRecordId((short)61457);
/*  80 */     clientData.setOptions((short)0);
/*     */     
/*  82 */     spContainer.addChildRecord(sp);
/*  83 */     spContainer.addChildRecord(opt);
/*  84 */     spContainer.addChildRecord(anchor);
/*  85 */     spContainer.addChildRecord(clientData);
/*     */     
/*  87 */     return spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord createObjRecord(HSSFShape hssfShape, int shapeId)
/*     */   {
/*  95 */     HSSFShape shape = hssfShape;
/*     */     
/*  97 */     ObjRecord obj = new ObjRecord();
/*  98 */     CommonObjectDataSubRecord c = new CommonObjectDataSubRecord();
/*  99 */     c.setObjectType((short)((HSSFSimpleShape)shape).getShapeType());
/* 100 */     c.setObjectId(shapeId);
/* 101 */     c.setLocked(true);
/* 102 */     c.setPrintable(true);
/* 103 */     c.setAutofill(true);
/* 104 */     c.setAutoline(true);
/* 105 */     EndSubRecord e = new EndSubRecord();
/*     */     
/* 107 */     obj.addSubRecord(c);
/* 108 */     obj.addSubRecord(e);
/*     */     
/* 110 */     return obj;
/*     */   }
/*     */   
/*     */   public EscherContainerRecord getSpContainer()
/*     */   {
/* 115 */     return this.spContainer;
/*     */   }
/*     */   
/*     */   public ObjRecord getObjRecord()
/*     */   {
/* 120 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\LineShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */