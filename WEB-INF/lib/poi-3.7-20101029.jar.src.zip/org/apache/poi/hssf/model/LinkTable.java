/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hssf.record.CRNCountRecord;
/*     */ import org.apache.poi.hssf.record.CRNRecord;
/*     */ import org.apache.poi.hssf.record.ExternSheetRecord;
/*     */ import org.apache.poi.hssf.record.ExternalNameRecord;
/*     */ import org.apache.poi.hssf.record.NameCommentRecord;
/*     */ import org.apache.poi.hssf.record.NameRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.SupBookRecord;
/*     */ import org.apache.poi.hssf.record.formula.NameXPtg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LinkTable
/*     */ {
/*     */   private final ExternalBookBlock[] _externalBookBlocks;
/*     */   private final ExternSheetRecord _externSheetRecord;
/*     */   private final List<NameRecord> _definedNames;
/*     */   private final int _recordCount;
/*     */   private final WorkbookRecordList _workbookRecordList;
/*     */   
/*     */   private static final class CRNBlock
/*     */   {
/*     */     private final CRNCountRecord _countRecord;
/*     */     private final CRNRecord[] _crns;
/*     */     
/*     */     public CRNBlock(RecordStream rs)
/*     */     {
/*  80 */       this._countRecord = ((CRNCountRecord)rs.getNext());
/*  81 */       int nCRNs = this._countRecord.getNumberOfCRNs();
/*  82 */       CRNRecord[] crns = new CRNRecord[nCRNs];
/*  83 */       for (int i = 0; i < crns.length; i++) {
/*  84 */         crns[i] = ((CRNRecord)rs.getNext());
/*     */       }
/*  86 */       this._crns = crns;
/*     */     }
/*     */     
/*  89 */     public CRNRecord[] getCrns() { return (CRNRecord[])this._crns.clone(); }
/*     */   }
/*     */   
/*     */   private static final class ExternalBookBlock
/*     */   {
/*     */     private final SupBookRecord _externalBookRecord;
/*     */     private final ExternalNameRecord[] _externalNameRecords;
/*     */     private final LinkTable.CRNBlock[] _crnBlocks;
/*     */     
/*     */     public ExternalBookBlock(RecordStream rs) {
/*  99 */       this._externalBookRecord = ((SupBookRecord)rs.getNext());
/* 100 */       List<Object> temp = new ArrayList();
/* 101 */       while (rs.peekNextClass() == ExternalNameRecord.class) {
/* 102 */         temp.add(rs.getNext());
/*     */       }
/* 104 */       this._externalNameRecords = new ExternalNameRecord[temp.size()];
/* 105 */       temp.toArray(this._externalNameRecords);
/*     */       
/* 107 */       temp.clear();
/*     */       
/* 109 */       while (rs.peekNextClass() == CRNCountRecord.class) {
/* 110 */         temp.add(new LinkTable.CRNBlock(rs));
/*     */       }
/* 112 */       this._crnBlocks = new LinkTable.CRNBlock[temp.size()];
/* 113 */       temp.toArray(this._crnBlocks);
/*     */     }
/*     */     
/*     */     public ExternalBookBlock(int numberOfSheets) {
/* 117 */       this._externalBookRecord = SupBookRecord.createInternalReferences((short)numberOfSheets);
/* 118 */       this._externalNameRecords = new ExternalNameRecord[0];
/* 119 */       this._crnBlocks = new LinkTable.CRNBlock[0];
/*     */     }
/*     */     
/*     */     public SupBookRecord getExternalBookRecord() {
/* 123 */       return this._externalBookRecord;
/*     */     }
/*     */     
/*     */     public String getNameText(int definedNameIndex) {
/* 127 */       return this._externalNameRecords[definedNameIndex].getText();
/*     */     }
/*     */     
/*     */     public int getNameIx(int definedNameIndex) {
/* 131 */       return this._externalNameRecords[definedNameIndex].getIx();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getIndexOfName(String name)
/*     */     {
/* 139 */       for (int i = 0; i < this._externalNameRecords.length; i++) {
/* 140 */         if (this._externalNameRecords[i].getText().equalsIgnoreCase(name)) {
/* 141 */           return i;
/*     */         }
/*     */       }
/* 144 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LinkTable(List inputList, int startIndex, WorkbookRecordList workbookRecordList, Map<String, NameCommentRecord> commentRecords)
/*     */   {
/* 156 */     this._workbookRecordList = workbookRecordList;
/* 157 */     RecordStream rs = new RecordStream(inputList, startIndex);
/*     */     
/* 159 */     List<ExternalBookBlock> temp = new ArrayList();
/* 160 */     while (rs.peekNextClass() == SupBookRecord.class) {
/* 161 */       temp.add(new ExternalBookBlock(rs));
/*     */     }
/*     */     
/* 164 */     this._externalBookBlocks = new ExternalBookBlock[temp.size()];
/* 165 */     temp.toArray(this._externalBookBlocks);
/* 166 */     temp.clear();
/*     */     
/* 168 */     if (this._externalBookBlocks.length > 0)
/*     */     {
/* 170 */       if (rs.peekNextClass() != ExternSheetRecord.class)
/*     */       {
/* 172 */         this._externSheetRecord = null;
/*     */       } else {
/* 174 */         this._externSheetRecord = readExtSheetRecord(rs);
/*     */       }
/*     */     } else {
/* 177 */       this._externSheetRecord = null;
/*     */     }
/*     */     
/* 180 */     this._definedNames = new ArrayList();
/*     */     
/*     */     for (;;)
/*     */     {
/* 184 */       Class nextClass = rs.peekNextClass();
/* 185 */       if (nextClass == NameRecord.class) {
/* 186 */         NameRecord nr = (NameRecord)rs.getNext();
/* 187 */         this._definedNames.add(nr);
/*     */       } else {
/* 189 */         if (nextClass != NameCommentRecord.class) break;
/* 190 */         NameCommentRecord ncr = (NameCommentRecord)rs.getNext();
/* 191 */         commentRecords.put(ncr.getNameText(), ncr);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 198 */     this._recordCount = rs.getCountRead();
/* 199 */     this._workbookRecordList.getRecords().addAll(inputList.subList(startIndex, startIndex + this._recordCount));
/*     */   }
/*     */   
/*     */   private static ExternSheetRecord readExtSheetRecord(RecordStream rs) {
/* 203 */     List<ExternSheetRecord> temp = new ArrayList(2);
/* 204 */     while (rs.peekNextClass() == ExternSheetRecord.class) {
/* 205 */       temp.add((ExternSheetRecord)rs.getNext());
/*     */     }
/*     */     
/* 208 */     int nItems = temp.size();
/* 209 */     if (nItems < 1) {
/* 210 */       throw new RuntimeException("Expected an EXTERNSHEET record but got (" + rs.peekNextClass().getName() + ")");
/*     */     }
/*     */     
/* 213 */     if (nItems == 1)
/*     */     {
/* 215 */       return (ExternSheetRecord)temp.get(0);
/*     */     }
/*     */     
/*     */ 
/* 219 */     ExternSheetRecord[] esrs = new ExternSheetRecord[nItems];
/* 220 */     temp.toArray(esrs);
/* 221 */     return ExternSheetRecord.combine(esrs);
/*     */   }
/*     */   
/*     */   public LinkTable(int numberOfSheets, WorkbookRecordList workbookRecordList) {
/* 225 */     this._workbookRecordList = workbookRecordList;
/* 226 */     this._definedNames = new ArrayList();
/* 227 */     this._externalBookBlocks = new ExternalBookBlock[] { new ExternalBookBlock(numberOfSheets) };
/*     */     
/*     */ 
/* 230 */     this._externSheetRecord = new ExternSheetRecord();
/* 231 */     this._recordCount = 2;
/*     */     
/*     */ 
/*     */ 
/* 235 */     SupBookRecord supbook = this._externalBookBlocks[0].getExternalBookRecord();
/*     */     
/* 237 */     int idx = findFirstRecordLocBySid((short)140);
/* 238 */     if (idx < 0) {
/* 239 */       throw new RuntimeException("CountryRecord not found");
/*     */     }
/* 241 */     this._workbookRecordList.add(idx + 1, this._externSheetRecord);
/* 242 */     this._workbookRecordList.add(idx + 1, supbook);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRecordCount()
/*     */   {
/* 249 */     return this._recordCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRecord getSpecificBuiltinRecord(byte builtInCode, int sheetNumber)
/*     */   {
/* 259 */     Iterator iterator = this._definedNames.iterator();
/* 260 */     while (iterator.hasNext()) {
/* 261 */       NameRecord record = (NameRecord)iterator.next();
/*     */       
/*     */ 
/* 264 */       if ((record.getBuiltInName() == builtInCode) && (record.getSheetNumber() == sheetNumber)) {
/* 265 */         return record;
/*     */       }
/*     */     }
/*     */     
/* 269 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeBuiltinRecord(byte name, int sheetIndex)
/*     */   {
/* 275 */     NameRecord record = getSpecificBuiltinRecord(name, sheetIndex);
/* 276 */     if (record != null) {
/* 277 */       this._definedNames.remove(record);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getNumNames()
/*     */   {
/* 283 */     return this._definedNames.size();
/*     */   }
/*     */   
/*     */   public NameRecord getNameRecord(int index) {
/* 287 */     return (NameRecord)this._definedNames.get(index);
/*     */   }
/*     */   
/*     */   public void addName(NameRecord name) {
/* 291 */     this._definedNames.add(name);
/*     */     
/*     */ 
/*     */ 
/* 295 */     int idx = findFirstRecordLocBySid((short)23);
/* 296 */     if (idx == -1) idx = findFirstRecordLocBySid((short)430);
/* 297 */     if (idx == -1) idx = findFirstRecordLocBySid((short)140);
/* 298 */     int countNames = this._definedNames.size();
/* 299 */     this._workbookRecordList.add(idx + countNames, name);
/*     */   }
/*     */   
/*     */   public void removeName(int namenum) {
/* 303 */     this._definedNames.remove(namenum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean nameAlreadyExists(NameRecord name)
/*     */   {
/* 312 */     for (int i = getNumNames() - 1; i >= 0; i--) {
/* 313 */       NameRecord rec = getNameRecord(i);
/* 314 */       if ((rec != name) && 
/* 315 */         (isDuplicatedNames(name, rec))) {
/* 316 */         return true;
/*     */       }
/*     */     }
/* 319 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean isDuplicatedNames(NameRecord firstName, NameRecord lastName) {
/* 323 */     return (lastName.getNameText().equalsIgnoreCase(firstName.getNameText())) && (isSameSheetNames(firstName, lastName));
/*     */   }
/*     */   
/*     */   private static boolean isSameSheetNames(NameRecord firstName, NameRecord lastName) {
/* 327 */     return lastName.getSheetNumber() == firstName.getSheetNumber();
/*     */   }
/*     */   
/*     */   public String[] getExternalBookAndSheetName(int extRefIndex) {
/* 331 */     int ebIx = this._externSheetRecord.getExtbookIndexFromRefIndex(extRefIndex);
/* 332 */     SupBookRecord ebr = this._externalBookBlocks[ebIx].getExternalBookRecord();
/* 333 */     if (!ebr.isExternalReferences()) {
/* 334 */       return null;
/*     */     }
/*     */     
/* 337 */     int shIx = this._externSheetRecord.getFirstSheetIndexFromRefIndex(extRefIndex);
/* 338 */     String usSheetName = null;
/* 339 */     if (shIx >= 0) {
/* 340 */       usSheetName = ebr.getSheetNames()[shIx];
/*     */     }
/* 342 */     return new String[] { ebr.getURL(), usSheetName };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getExternalSheetIndex(String workbookName, String sheetName)
/*     */   {
/* 349 */     SupBookRecord ebrTarget = null;
/* 350 */     int externalBookIndex = -1;
/* 351 */     for (int i = 0; i < this._externalBookBlocks.length; i++) {
/* 352 */       SupBookRecord ebr = this._externalBookBlocks[i].getExternalBookRecord();
/* 353 */       if (ebr.isExternalReferences())
/*     */       {
/*     */ 
/* 356 */         if (workbookName.equals(ebr.getURL())) {
/* 357 */           ebrTarget = ebr;
/* 358 */           externalBookIndex = i;
/* 359 */           break;
/*     */         } }
/*     */     }
/* 362 */     if (ebrTarget == null) {
/* 363 */       throw new RuntimeException("No external workbook with name '" + workbookName + "'");
/*     */     }
/* 365 */     int sheetIndex = getSheetIndex(ebrTarget.getSheetNames(), sheetName);
/*     */     
/* 367 */     int result = this._externSheetRecord.getRefIxForSheet(externalBookIndex, sheetIndex);
/* 368 */     if (result < 0) {
/* 369 */       throw new RuntimeException("ExternSheetRecord does not contain combination (" + externalBookIndex + ", " + sheetIndex + ")");
/*     */     }
/*     */     
/* 372 */     return result;
/*     */   }
/*     */   
/*     */   private static int getSheetIndex(String[] sheetNames, String sheetName) {
/* 376 */     for (int i = 0; i < sheetNames.length; i++) {
/* 377 */       if (sheetNames[i].equals(sheetName)) {
/* 378 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 382 */     throw new RuntimeException("External workbook does not contain sheet '" + sheetName + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndexToInternalSheet(int extRefIndex)
/*     */   {
/* 390 */     return this._externSheetRecord.getFirstSheetIndexFromRefIndex(extRefIndex);
/*     */   }
/*     */   
/*     */   public int getSheetIndexFromExternSheetIndex(int extRefIndex) {
/* 394 */     if (extRefIndex >= this._externSheetRecord.getNumOfRefs()) {
/* 395 */       return -1;
/*     */     }
/* 397 */     return this._externSheetRecord.getFirstSheetIndexFromRefIndex(extRefIndex);
/*     */   }
/*     */   
/*     */   public int checkExternSheet(int sheetIndex) {
/* 401 */     int thisWbIndex = -1;
/* 402 */     for (int i = 0; i < this._externalBookBlocks.length; i++) {
/* 403 */       SupBookRecord ebr = this._externalBookBlocks[i].getExternalBookRecord();
/* 404 */       if (ebr.isInternalReferences()) {
/* 405 */         thisWbIndex = i;
/* 406 */         break;
/*     */       }
/*     */     }
/* 409 */     if (thisWbIndex < 0) {
/* 410 */       throw new RuntimeException("Could not find 'internal references' EXTERNALBOOK");
/*     */     }
/*     */     
/*     */ 
/* 414 */     int i = this._externSheetRecord.getRefIxForSheet(thisWbIndex, sheetIndex);
/* 415 */     if (i >= 0) {
/* 416 */       return i;
/*     */     }
/*     */     
/* 419 */     return this._externSheetRecord.addRef(thisWbIndex, sheetIndex, sheetIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int findFirstRecordLocBySid(short sid)
/*     */   {
/* 427 */     int index = 0;
/* 428 */     for (Iterator iterator = this._workbookRecordList.iterator(); iterator.hasNext();) {
/* 429 */       Record record = (Record)iterator.next();
/*     */       
/* 431 */       if (record.getSid() == sid) {
/* 432 */         return index;
/*     */       }
/* 434 */       index++;
/*     */     }
/* 436 */     return -1;
/*     */   }
/*     */   
/*     */   public String resolveNameXText(int refIndex, int definedNameIndex) {
/* 440 */     int extBookIndex = this._externSheetRecord.getExtbookIndexFromRefIndex(refIndex);
/* 441 */     return this._externalBookBlocks[extBookIndex].getNameText(definedNameIndex);
/*     */   }
/*     */   
/* 444 */   public int resolveNameXIx(int refIndex, int definedNameIndex) { int extBookIndex = this._externSheetRecord.getExtbookIndexFromRefIndex(refIndex);
/* 445 */     return this._externalBookBlocks[extBookIndex].getNameIx(definedNameIndex);
/*     */   }
/*     */   
/*     */   public NameXPtg getNameXPtg(String name)
/*     */   {
/* 450 */     for (int i = 0; i < this._externalBookBlocks.length; i++) {
/* 451 */       int definedNameIndex = this._externalBookBlocks[i].getIndexOfName(name);
/* 452 */       if (definedNameIndex >= 0)
/*     */       {
/*     */ 
/*     */ 
/* 456 */         int sheetRefIndex = findRefIndexFromExtBookIndex(i);
/* 457 */         if (sheetRefIndex >= 0)
/* 458 */           return new NameXPtg(sheetRefIndex, definedNameIndex);
/*     */       }
/*     */     }
/* 461 */     return null;
/*     */   }
/*     */   
/*     */   private int findRefIndexFromExtBookIndex(int extBookIndex) {
/* 465 */     return this._externSheetRecord.findRefIndexFromExtBookIndex(extBookIndex);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\LinkTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */