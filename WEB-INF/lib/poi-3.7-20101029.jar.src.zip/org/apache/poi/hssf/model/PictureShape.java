/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.EndSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFPicture;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PictureShape
/*     */   extends AbstractShape
/*     */ {
/*     */   private EscherContainerRecord spContainer;
/*     */   private ObjRecord objRecord;
/*     */   
/*     */   PictureShape(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  45 */     this.spContainer = createSpContainer(hssfShape, shapeId);
/*  46 */     this.objRecord = createObjRecord(hssfShape, shapeId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainerRecord createSpContainer(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  54 */     HSSFPicture shape = (HSSFPicture)hssfShape;
/*     */     
/*  56 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/*  57 */     EscherSpRecord sp = new EscherSpRecord();
/*  58 */     EscherOptRecord opt = new EscherOptRecord();
/*     */     
/*  60 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*     */     
/*  62 */     spContainer.setRecordId((short)61444);
/*  63 */     spContainer.setOptions((short)15);
/*  64 */     sp.setRecordId((short)61450);
/*  65 */     sp.setOptions((short)1202);
/*     */     
/*  67 */     sp.setShapeId(shapeId);
/*  68 */     sp.setFlags(2560);
/*  69 */     opt.setRecordId((short)61451);
/*     */     
/*  71 */     opt.addEscherProperty(new EscherSimpleProperty((short)260, false, true, shape.getPictureIndex()));
/*     */     
/*     */ 
/*  74 */     addStandardOptions(shape, opt);
/*  75 */     HSSFAnchor userAnchor = shape.getAnchor();
/*  76 */     if (userAnchor.isHorizontallyFlipped())
/*  77 */       sp.setFlags(sp.getFlags() | 0x40);
/*  78 */     if (userAnchor.isVerticallyFlipped())
/*  79 */       sp.setFlags(sp.getFlags() | 0x80);
/*  80 */     EscherRecord anchor = createAnchor(userAnchor);
/*  81 */     clientData.setRecordId((short)61457);
/*  82 */     clientData.setOptions((short)0);
/*     */     
/*  84 */     spContainer.addChildRecord(sp);
/*  85 */     spContainer.addChildRecord(opt);
/*  86 */     spContainer.addChildRecord(anchor);
/*  87 */     spContainer.addChildRecord(clientData);
/*     */     
/*  89 */     return spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord createObjRecord(HSSFShape hssfShape, int shapeId)
/*     */   {
/*  97 */     HSSFShape shape = hssfShape;
/*     */     
/*  99 */     ObjRecord obj = new ObjRecord();
/* 100 */     CommonObjectDataSubRecord c = new CommonObjectDataSubRecord();
/* 101 */     c.setObjectType((short)((HSSFSimpleShape)shape).getShapeType());
/*     */     
/* 103 */     c.setObjectId(shapeId);
/* 104 */     c.setLocked(true);
/* 105 */     c.setPrintable(true);
/* 106 */     c.setAutofill(true);
/* 107 */     c.setAutoline(true);
/*     */     
/* 109 */     c.setReserved2(0);
/*     */     
/*     */ 
/* 112 */     EndSubRecord e = new EndSubRecord();
/*     */     
/* 114 */     obj.addSubRecord(c);
/*     */     
/*     */ 
/* 117 */     obj.addSubRecord(e);
/*     */     
/* 119 */     return obj;
/*     */   }
/*     */   
/*     */   public EscherContainerRecord getSpContainer()
/*     */   {
/* 124 */     return this.spContainer;
/*     */   }
/*     */   
/*     */   public ObjRecord getObjRecord()
/*     */   {
/* 129 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\PictureShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */