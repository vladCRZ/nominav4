/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherArrayProperty;
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherShapePathProperty;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.EndSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFPolygon;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PolygonShape
/*     */   extends AbstractShape
/*     */ {
/*     */   public static final short OBJECT_TYPE_MICROSOFT_OFFICE_DRAWING = 30;
/*     */   private EscherContainerRecord spContainer;
/*     */   private ObjRecord objRecord;
/*     */   
/*     */   PolygonShape(HSSFPolygon hssfShape, int shapeId)
/*     */   {
/*  46 */     this.spContainer = createSpContainer(hssfShape, shapeId);
/*  47 */     this.objRecord = createObjRecord(hssfShape, shapeId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainerRecord createSpContainer(HSSFPolygon hssfShape, int shapeId)
/*     */   {
/*  56 */     HSSFShape shape = hssfShape;
/*     */     
/*  58 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/*  59 */     EscherSpRecord sp = new EscherSpRecord();
/*  60 */     EscherOptRecord opt = new EscherOptRecord();
/*  61 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*     */     
/*  63 */     spContainer.setRecordId((short)61444);
/*  64 */     spContainer.setOptions((short)15);
/*  65 */     sp.setRecordId((short)61450);
/*  66 */     sp.setOptions((short)370);
/*  67 */     sp.setShapeId(shapeId);
/*  68 */     if (hssfShape.getParent() == null) {
/*  69 */       sp.setFlags(2560);
/*     */     } else
/*  71 */       sp.setFlags(2562);
/*  72 */     opt.setRecordId((short)61451);
/*  73 */     opt.addEscherProperty(new EscherSimpleProperty((short)4, false, false, 0));
/*  74 */     opt.addEscherProperty(new EscherSimpleProperty((short)322, false, false, hssfShape.getDrawAreaWidth()));
/*  75 */     opt.addEscherProperty(new EscherSimpleProperty((short)323, false, false, hssfShape.getDrawAreaHeight()));
/*  76 */     opt.addEscherProperty(new EscherShapePathProperty((short)324, 4));
/*  77 */     EscherArrayProperty verticesProp = new EscherArrayProperty((short)325, false, new byte[0]);
/*  78 */     verticesProp.setNumberOfElementsInArray(hssfShape.getXPoints().length + 1);
/*  79 */     verticesProp.setNumberOfElementsInMemory(hssfShape.getXPoints().length + 1);
/*  80 */     verticesProp.setSizeOfElements(65520);
/*  81 */     for (int i = 0; i < hssfShape.getXPoints().length; i++)
/*     */     {
/*  83 */       byte[] data = new byte[4];
/*  84 */       LittleEndian.putShort(data, 0, (short)hssfShape.getXPoints()[i]);
/*  85 */       LittleEndian.putShort(data, 2, (short)hssfShape.getYPoints()[i]);
/*  86 */       verticesProp.setElement(i, data);
/*     */     }
/*  88 */     int point = hssfShape.getXPoints().length;
/*  89 */     byte[] data = new byte[4];
/*  90 */     LittleEndian.putShort(data, 0, (short)hssfShape.getXPoints()[0]);
/*  91 */     LittleEndian.putShort(data, 2, (short)hssfShape.getYPoints()[0]);
/*  92 */     verticesProp.setElement(point, data);
/*  93 */     opt.addEscherProperty(verticesProp);
/*  94 */     EscherArrayProperty segmentsProp = new EscherArrayProperty((short)326, false, null);
/*  95 */     segmentsProp.setSizeOfElements(2);
/*  96 */     segmentsProp.setNumberOfElementsInArray(hssfShape.getXPoints().length * 2 + 4);
/*  97 */     segmentsProp.setNumberOfElementsInMemory(hssfShape.getXPoints().length * 2 + 4);
/*  98 */     segmentsProp.setElement(0, new byte[] { 0, 64 });
/*  99 */     segmentsProp.setElement(1, new byte[] { 0, -84 });
/* 100 */     for (int i = 0; i < hssfShape.getXPoints().length; i++)
/*     */     {
/* 102 */       segmentsProp.setElement(2 + i * 2, new byte[] { 1, 0 });
/* 103 */       segmentsProp.setElement(3 + i * 2, new byte[] { 0, -84 });
/*     */     }
/* 105 */     segmentsProp.setElement(segmentsProp.getNumberOfElementsInArray() - 2, new byte[] { 1, 96 });
/* 106 */     segmentsProp.setElement(segmentsProp.getNumberOfElementsInArray() - 1, new byte[] { 0, Byte.MIN_VALUE });
/* 107 */     opt.addEscherProperty(segmentsProp);
/* 108 */     opt.addEscherProperty(new EscherSimpleProperty((short)383, false, false, 65537));
/* 109 */     opt.addEscherProperty(new EscherSimpleProperty((short)464, false, false, 0));
/* 110 */     opt.addEscherProperty(new EscherSimpleProperty((short)465, false, false, 0));
/* 111 */     opt.addEscherProperty(new EscherSimpleProperty((short)471, false, false, 0));
/*     */     
/* 113 */     addStandardOptions(shape, opt);
/*     */     
/* 115 */     EscherRecord anchor = createAnchor(shape.getAnchor());
/* 116 */     clientData.setRecordId((short)61457);
/* 117 */     clientData.setOptions((short)0);
/*     */     
/* 119 */     spContainer.addChildRecord(sp);
/* 120 */     spContainer.addChildRecord(opt);
/* 121 */     spContainer.addChildRecord(anchor);
/* 122 */     spContainer.addChildRecord(clientData);
/*     */     
/* 124 */     return spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord createObjRecord(HSSFShape hssfShape, int shapeId)
/*     */   {
/* 132 */     HSSFShape shape = hssfShape;
/*     */     
/* 134 */     ObjRecord obj = new ObjRecord();
/* 135 */     CommonObjectDataSubRecord c = new CommonObjectDataSubRecord();
/* 136 */     c.setObjectType((short)30);
/* 137 */     c.setObjectId(shapeId);
/* 138 */     c.setLocked(true);
/* 139 */     c.setPrintable(true);
/* 140 */     c.setAutofill(true);
/* 141 */     c.setAutoline(true);
/* 142 */     EndSubRecord e = new EndSubRecord();
/*     */     
/* 144 */     obj.addSubRecord(c);
/* 145 */     obj.addSubRecord(e);
/*     */     
/* 147 */     return obj;
/*     */   }
/*     */   
/*     */   public EscherContainerRecord getSpContainer()
/*     */   {
/* 152 */     return this.spContainer;
/*     */   }
/*     */   
/*     */   public ObjRecord getObjRecord()
/*     */   {
/* 157 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\PolygonShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */