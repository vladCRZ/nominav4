/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.record.DimensionsRecord;
/*     */ import org.apache.poi.hssf.record.EOFRecord;
/*     */ import org.apache.poi.hssf.record.GutsRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordBase;
/*     */ import org.apache.poi.hssf.record.aggregates.ColumnInfoRecordsAggregate;
/*     */ import org.apache.poi.hssf.record.aggregates.ConditionalFormattingTable;
/*     */ import org.apache.poi.hssf.record.aggregates.DataValidityTable;
/*     */ import org.apache.poi.hssf.record.aggregates.MergedCellsTable;
/*     */ import org.apache.poi.hssf.record.aggregates.PageSettingsBlock;
/*     */ import org.apache.poi.hssf.record.aggregates.WorksheetProtectionBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RecordOrderer
/*     */ {
/*     */   public static void addNewSheetRecord(List<RecordBase> sheetRecords, RecordBase newRecord)
/*     */   {
/*  93 */     int index = findSheetInsertPos(sheetRecords, newRecord.getClass());
/*  94 */     sheetRecords.add(index, newRecord);
/*     */   }
/*     */   
/*     */   private static int findSheetInsertPos(List<RecordBase> records, Class<? extends RecordBase> recClass) {
/*  98 */     if (recClass == DataValidityTable.class) {
/*  99 */       return findDataValidationTableInsertPos(records);
/*     */     }
/* 101 */     if (recClass == MergedCellsTable.class) {
/* 102 */       return findInsertPosForNewMergedRecordTable(records);
/*     */     }
/* 104 */     if (recClass == ConditionalFormattingTable.class) {
/* 105 */       return findInsertPosForNewCondFormatTable(records);
/*     */     }
/* 107 */     if (recClass == GutsRecord.class) {
/* 108 */       return getGutsRecordInsertPos(records);
/*     */     }
/* 110 */     if (recClass == PageSettingsBlock.class) {
/* 111 */       return getPageBreakRecordInsertPos(records);
/*     */     }
/* 113 */     if (recClass == WorksheetProtectionBlock.class) {
/* 114 */       return getWorksheetProtectionBlockInsertPos(records);
/*     */     }
/* 116 */     throw new RuntimeException("Unexpected record class (" + recClass.getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getWorksheetProtectionBlockInsertPos(List<RecordBase> records)
/*     */   {
/* 141 */     int i = getDimensionsIndex(records);
/* 142 */     while (i > 0) {
/* 143 */       i--;
/* 144 */       Object rb = records.get(i);
/* 145 */       if (!isProtectionSubsequentRecord(rb)) {
/* 146 */         return i + 1;
/*     */       }
/*     */     }
/* 149 */     throw new IllegalStateException("did not find insert pos for protection block");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isProtectionSubsequentRecord(Object rb)
/*     */   {
/* 162 */     if ((rb instanceof ColumnInfoRecordsAggregate)) {
/* 163 */       return true;
/*     */     }
/* 165 */     if ((rb instanceof Record)) {
/* 166 */       Record record = (Record)rb;
/* 167 */       switch (record.getSid()) {
/*     */       case 85: 
/*     */       case 144: 
/* 170 */         return true;
/*     */       }
/*     */     }
/* 173 */     return false;
/*     */   }
/*     */   
/*     */   private static int getPageBreakRecordInsertPos(List<RecordBase> records) {
/* 177 */     int dimensionsIndex = getDimensionsIndex(records);
/* 178 */     int i = dimensionsIndex - 1;
/* 179 */     while (i > 0) {
/* 180 */       i--;
/* 181 */       Object rb = records.get(i);
/* 182 */       if (isPageBreakPriorRecord(rb)) {
/* 183 */         return i + 1;
/*     */       }
/*     */     }
/* 186 */     throw new RuntimeException("Did not find insert point for GUTS");
/*     */   }
/*     */   
/* 189 */   private static boolean isPageBreakPriorRecord(Object rb) { if ((rb instanceof Record)) {
/* 190 */       Record record = (Record)rb;
/* 191 */       switch (record.getSid())
/*     */       {
/*     */ 
/*     */       case 12: 
/*     */       case 13: 
/*     */       case 14: 
/*     */       case 15: 
/*     */       case 16: 
/*     */       case 17: 
/*     */       case 34: 
/*     */       case 42: 
/*     */       case 43: 
/*     */       case 94: 
/*     */       case 95: 
/*     */       case 129: 
/*     */       case 130: 
/*     */       case 523: 
/*     */       case 549: 
/*     */       case 2057: 
/* 210 */         return true;
/*     */       }
/*     */       
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int findInsertPosForNewCondFormatTable(List<RecordBase> records)
/*     */   {
/* 221 */     for (int i = records.size() - 2; i >= 0; i--) {
/* 222 */       Object rb = records.get(i);
/* 223 */       if ((rb instanceof MergedCellsTable)) {
/* 224 */         return i + 1;
/*     */       }
/* 226 */       if (!(rb instanceof DataValidityTable))
/*     */       {
/*     */ 
/*     */ 
/* 230 */         Record rec = (Record)rb;
/* 231 */         switch (rec.getSid())
/*     */         {
/*     */ 
/*     */         case 29: 
/*     */         case 65: 
/*     */         case 153: 
/*     */         case 160: 
/*     */         case 239: 
/*     */         case 351: 
/*     */         case 574: 
/* 241 */           return i + 1;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 246 */     throw new RuntimeException("Did not find Window2 record");
/*     */   }
/*     */   
/*     */   private static int findInsertPosForNewMergedRecordTable(List<RecordBase> records) {
/* 250 */     for (int i = records.size() - 2; i >= 0; i--) {
/* 251 */       Object rb = records.get(i);
/* 252 */       if ((rb instanceof Record))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 257 */         Record rec = (Record)rb;
/* 258 */         switch (rec.getSid())
/*     */         {
/*     */ 
/*     */         case 29: 
/*     */         case 65: 
/*     */         case 153: 
/*     */         case 160: 
/*     */         case 574: 
/* 266 */           return i + 1; }
/*     */         
/*     */       } }
/* 269 */     throw new RuntimeException("Did not find Window2 record");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findDataValidationTableInsertPos(List<RecordBase> records)
/*     */   {
/* 294 */     int i = records.size() - 1;
/* 295 */     if (!(records.get(i) instanceof EOFRecord)) {
/* 296 */       throw new IllegalStateException("Last sheet record should be EOFRecord");
/*     */     }
/* 298 */     while (i > 0) {
/* 299 */       i--;
/* 300 */       RecordBase rb = (RecordBase)records.get(i);
/* 301 */       if (isDVTPriorRecord(rb)) {
/* 302 */         Record nextRec = (Record)records.get(i + 1);
/* 303 */         if (!isDVTSubsequentRecord(nextRec.getSid())) {
/* 304 */           throw new IllegalStateException("Unexpected (" + nextRec.getClass().getName() + ") found after (" + rb.getClass().getName() + ")");
/*     */         }
/*     */         
/* 307 */         return i + 1;
/*     */       }
/* 309 */       Record rec = (Record)rb;
/* 310 */       if (!isDVTSubsequentRecord(rec.getSid())) {
/* 311 */         throw new IllegalStateException("Unexpected (" + rec.getClass().getName() + ") while looking for DV Table insert pos");
/*     */       }
/*     */     }
/*     */     
/* 315 */     return 0;
/*     */   }
/*     */   
/*     */   private static boolean isDVTPriorRecord(RecordBase rb)
/*     */   {
/* 320 */     if (((rb instanceof MergedCellsTable)) || ((rb instanceof ConditionalFormattingTable))) {
/* 321 */       return true;
/*     */     }
/* 323 */     short sid = ((Record)rb).getSid();
/* 324 */     switch (sid)
/*     */     {
/*     */ 
/*     */ 
/*     */     case 29: 
/*     */     case 65: 
/*     */     case 153: 
/*     */     case 160: 
/*     */     case 239: 
/*     */     case 351: 
/*     */     case 440: 
/*     */     case 442: 
/*     */     case 574: 
/*     */     case 2048: 
/* 338 */       return true; }
/*     */     
/* 340 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean isDVTSubsequentRecord(short sid) {
/* 344 */     switch (sid) {
/*     */     case 10: 
/*     */     case 2146: 
/*     */     case 2151: 
/*     */     case 2152: 
/* 349 */       return true;
/*     */     }
/* 351 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private static int getDimensionsIndex(List<RecordBase> records)
/*     */   {
/* 357 */     int nRecs = records.size();
/* 358 */     for (int i = 0; i < nRecs; i++) {
/* 359 */       if ((records.get(i) instanceof DimensionsRecord)) {
/* 360 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 364 */     throw new RuntimeException("DimensionsRecord not found");
/*     */   }
/*     */   
/*     */   private static int getGutsRecordInsertPos(List<RecordBase> records) {
/* 368 */     int dimensionsIndex = getDimensionsIndex(records);
/* 369 */     int i = dimensionsIndex - 1;
/* 370 */     while (i > 0) {
/* 371 */       i--;
/* 372 */       RecordBase rb = (RecordBase)records.get(i);
/* 373 */       if (isGutsPriorRecord(rb)) {
/* 374 */         return i + 1;
/*     */       }
/*     */     }
/* 377 */     throw new RuntimeException("Did not find insert point for GUTS");
/*     */   }
/*     */   
/*     */   private static boolean isGutsPriorRecord(RecordBase rb) {
/* 381 */     if ((rb instanceof Record)) {
/* 382 */       Record record = (Record)rb;
/* 383 */       switch (record.getSid())
/*     */       {
/*     */ 
/*     */       case 12: 
/*     */       case 13: 
/*     */       case 14: 
/*     */       case 15: 
/*     */       case 16: 
/*     */       case 17: 
/*     */       case 34: 
/*     */       case 42: 
/*     */       case 43: 
/*     */       case 94: 
/*     */       case 95: 
/*     */       case 130: 
/*     */       case 523: 
/*     */       case 2057: 
/* 400 */         return true;
/*     */       }
/*     */       
/*     */     }
/* 404 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEndOfRowBlock(int sid)
/*     */   {
/* 412 */     switch (sid)
/*     */     {
/*     */ 
/*     */ 
/*     */     case 61: 
/*     */     case 93: 
/*     */     case 176: 
/*     */     case 236: 
/*     */     case 237: 
/*     */     case 438: 
/*     */     case 574: 
/* 423 */       return true;
/*     */     
/*     */     case 434: 
/* 426 */       return true;
/*     */     
/*     */     case 10: 
/* 429 */       throw new RuntimeException("Found EOFRecord before WindowTwoRecord was encountered"); }
/*     */     
/* 431 */     return PageSettingsBlock.isComponentRecord(sid);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isRowBlockRecord(int sid)
/*     */   {
/* 439 */     switch (sid)
/*     */     {
/*     */ 
/*     */     case 6: 
/*     */     case 253: 
/*     */     case 513: 
/*     */     case 515: 
/*     */     case 516: 
/*     */     case 517: 
/*     */     case 520: 
/*     */     case 545: 
/*     */     case 566: 
/*     */     case 638: 
/*     */     case 1212: 
/* 453 */       return true; }
/*     */     
/* 455 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\RecordOrderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */