/*    */ package org.apache.poi.hssf.model;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.poi.hssf.record.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RecordStream
/*    */ {
/*    */   private final List _list;
/*    */   private int _nextIndex;
/*    */   private int _countRead;
/*    */   private final int _endIx;
/*    */   
/*    */   public RecordStream(List inputList, int startIndex, int endIx)
/*    */   {
/* 39 */     this._list = inputList;
/* 40 */     this._nextIndex = startIndex;
/* 41 */     this._endIx = endIx;
/* 42 */     this._countRead = 0;
/*    */   }
/*    */   
/*    */   public RecordStream(List records, int startIx) {
/* 46 */     this(records, startIx, records.size());
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 50 */     return this._nextIndex < this._endIx;
/*    */   }
/*    */   
/*    */   public Record getNext() {
/* 54 */     if (!hasNext()) {
/* 55 */       throw new RuntimeException("Attempt to read past end of record stream");
/*    */     }
/* 57 */     this._countRead += 1;
/* 58 */     return (Record)this._list.get(this._nextIndex++);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Class peekNextClass()
/*    */   {
/* 65 */     if (!hasNext()) {
/* 66 */       return null;
/*    */     }
/* 68 */     return this._list.get(this._nextIndex).getClass();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int peekNextSid()
/*    */   {
/* 75 */     if (!hasNext()) {
/* 76 */       return -1;
/*    */     }
/* 78 */     return ((Record)this._list.get(this._nextIndex)).getSid();
/*    */   }
/*    */   
/*    */   public int getCountRead() {
/* 82 */     return this._countRead;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\RecordStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */