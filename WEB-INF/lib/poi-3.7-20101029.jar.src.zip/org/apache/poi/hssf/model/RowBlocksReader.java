/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.record.ArrayRecord;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.MergeCellsRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.SharedFormulaRecord;
/*     */ import org.apache.poi.hssf.record.TableRecord;
/*     */ import org.apache.poi.hssf.record.aggregates.SharedValueManager;
/*     */ import org.apache.poi.ss.util.CellReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RowBlocksReader
/*     */ {
/*     */   private final List _plainRecords;
/*     */   private final SharedValueManager _sfm;
/*     */   private final MergeCellsRecord[] _mergedCellsRecords;
/*     */   
/*     */   public RowBlocksReader(RecordStream rs)
/*     */   {
/*  50 */     List<Record> plainRecords = new ArrayList();
/*  51 */     List<Record> shFrmRecords = new ArrayList();
/*  52 */     List<CellReference> firstCellRefs = new ArrayList();
/*  53 */     List<Record> arrayRecords = new ArrayList();
/*  54 */     List<Record> tableRecords = new ArrayList();
/*  55 */     List<Record> mergeCellRecords = new ArrayList();
/*     */     
/*  57 */     Record prevRec = null;
/*  58 */     while (!RecordOrderer.isEndOfRowBlock(rs.peekNextSid()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  63 */       if (!rs.hasNext()) {
/*  64 */         throw new RuntimeException("Failed to find end of row/cell records");
/*     */       }
/*     */       
/*  67 */       Record rec = rs.getNext();
/*     */       List<Record> dest;
/*  69 */       switch (rec.getSid()) {
/*  70 */       case 229:  dest = mergeCellRecords; break;
/*  71 */       case 1212:  dest = shFrmRecords;
/*  72 */         if (!(prevRec instanceof FormulaRecord)) {
/*  73 */           throw new RuntimeException("Shared formula record should follow a FormulaRecord");
/*     */         }
/*  75 */         FormulaRecord fr = (FormulaRecord)prevRec;
/*  76 */         firstCellRefs.add(new CellReference(fr.getRow(), fr.getColumn()));
/*  77 */         break;
/*  78 */       case 545:  dest = arrayRecords; break;
/*  79 */       case 566:  dest = tableRecords; break;
/*  80 */       default:  dest = plainRecords;
/*     */       }
/*  82 */       dest.add(rec);
/*  83 */       prevRec = rec;
/*     */     }
/*  85 */     SharedFormulaRecord[] sharedFormulaRecs = new SharedFormulaRecord[shFrmRecords.size()];
/*  86 */     CellReference[] firstCells = new CellReference[firstCellRefs.size()];
/*  87 */     ArrayRecord[] arrayRecs = new ArrayRecord[arrayRecords.size()];
/*  88 */     TableRecord[] tableRecs = new TableRecord[tableRecords.size()];
/*  89 */     shFrmRecords.toArray(sharedFormulaRecs);
/*  90 */     firstCellRefs.toArray(firstCells);
/*  91 */     arrayRecords.toArray(arrayRecs);
/*  92 */     tableRecords.toArray(tableRecs);
/*     */     
/*  94 */     this._plainRecords = plainRecords;
/*  95 */     this._sfm = SharedValueManager.create(sharedFormulaRecs, firstCells, arrayRecs, tableRecs);
/*  96 */     this._mergedCellsRecords = new MergeCellsRecord[mergeCellRecords.size()];
/*  97 */     mergeCellRecords.toArray(this._mergedCellsRecords);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MergeCellsRecord[] getLooseMergedCells()
/*     */   {
/* 106 */     return this._mergedCellsRecords;
/*     */   }
/*     */   
/*     */   public SharedValueManager getSharedFormulaManager() {
/* 110 */     return this._sfm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RecordStream getPlainRecordStream()
/*     */   {
/* 117 */     return new RecordStream(this._plainRecords, 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\RowBlocksReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */