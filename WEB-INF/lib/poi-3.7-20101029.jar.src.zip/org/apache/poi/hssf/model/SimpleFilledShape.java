/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.EndSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleFilledShape
/*     */   extends AbstractShape
/*     */ {
/*     */   private EscherContainerRecord spContainer;
/*     */   private ObjRecord objRecord;
/*     */   
/*     */   SimpleFilledShape(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  42 */     this.spContainer = createSpContainer(hssfShape, shapeId);
/*  43 */     this.objRecord = createObjRecord(hssfShape, shapeId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainerRecord createSpContainer(HSSFSimpleShape hssfShape, int shapeId)
/*     */   {
/*  54 */     HSSFShape shape = hssfShape;
/*     */     
/*  56 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/*  57 */     EscherSpRecord sp = new EscherSpRecord();
/*  58 */     EscherOptRecord opt = new EscherOptRecord();
/*  59 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*     */     
/*  61 */     spContainer.setRecordId((short)61444);
/*  62 */     spContainer.setOptions((short)15);
/*  63 */     sp.setRecordId((short)61450);
/*  64 */     short shapeType = objTypeToShapeType(hssfShape.getShapeType());
/*  65 */     sp.setOptions((short)(shapeType << 4 | 0x2));
/*  66 */     sp.setShapeId(shapeId);
/*  67 */     sp.setFlags(2560);
/*  68 */     opt.setRecordId((short)61451);
/*  69 */     addStandardOptions(shape, opt);
/*  70 */     EscherRecord anchor = createAnchor(shape.getAnchor());
/*  71 */     clientData.setRecordId((short)61457);
/*  72 */     clientData.setOptions((short)0);
/*     */     
/*  74 */     spContainer.addChildRecord(sp);
/*  75 */     spContainer.addChildRecord(opt);
/*  76 */     spContainer.addChildRecord(anchor);
/*  77 */     spContainer.addChildRecord(clientData);
/*     */     
/*  79 */     return spContainer;
/*     */   }
/*     */   
/*     */   private short objTypeToShapeType(int objType)
/*     */   {
/*     */     short shapeType;
/*  85 */     if (objType == 3) {
/*  86 */       shapeType = 3; } else { short shapeType;
/*  87 */       if (objType == 2) {
/*  88 */         shapeType = 1;
/*     */       } else
/*  90 */         throw new IllegalArgumentException("Unable to handle an object of this type"); }
/*  91 */     short shapeType; return shapeType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord createObjRecord(HSSFShape hssfShape, int shapeId)
/*     */   {
/*  99 */     HSSFShape shape = hssfShape;
/*     */     
/* 101 */     ObjRecord obj = new ObjRecord();
/* 102 */     CommonObjectDataSubRecord c = new CommonObjectDataSubRecord();
/* 103 */     c.setObjectType((short)((HSSFSimpleShape)shape).getShapeType());
/* 104 */     c.setObjectId(shapeId);
/* 105 */     c.setLocked(true);
/* 106 */     c.setPrintable(true);
/* 107 */     c.setAutofill(true);
/* 108 */     c.setAutoline(true);
/* 109 */     EndSubRecord e = new EndSubRecord();
/*     */     
/* 111 */     obj.addSubRecord(c);
/* 112 */     obj.addSubRecord(e);
/*     */     
/* 114 */     return obj;
/*     */   }
/*     */   
/*     */   public EscherContainerRecord getSpContainer()
/*     */   {
/* 119 */     return this.spContainer;
/*     */   }
/*     */   
/*     */   public ObjRecord getObjRecord()
/*     */   {
/* 124 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\SimpleFilledShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */