/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import org.apache.poi.ddf.EscherClientAnchorRecord;
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.ddf.EscherTextboxRecord;
/*     */ import org.apache.poi.hssf.record.CommonObjectDataSubRecord;
/*     */ import org.apache.poi.hssf.record.EndSubRecord;
/*     */ import org.apache.poi.hssf.record.ObjRecord;
/*     */ import org.apache.poi.hssf.record.TextObjectRecord;
/*     */ import org.apache.poi.hssf.usermodel.HSSFAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFTextbox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextboxShape
/*     */   extends AbstractShape
/*     */ {
/*     */   private EscherContainerRecord spContainer;
/*     */   private TextObjectRecord textObjectRecord;
/*     */   private ObjRecord objRecord;
/*     */   private EscherTextboxRecord escherTextbox;
/*     */   
/*     */   TextboxShape(HSSFTextbox hssfShape, int shapeId)
/*     */   {
/*  47 */     this.spContainer = createSpContainer(hssfShape, shapeId);
/*  48 */     this.objRecord = createObjRecord(hssfShape, shapeId);
/*  49 */     this.textObjectRecord = createTextObjectRecord(hssfShape, shapeId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjRecord createObjRecord(HSSFTextbox hssfShape, int shapeId)
/*     */   {
/*  57 */     HSSFShape shape = hssfShape;
/*     */     
/*  59 */     ObjRecord obj = new ObjRecord();
/*  60 */     CommonObjectDataSubRecord c = new CommonObjectDataSubRecord();
/*  61 */     c.setObjectType((short)((HSSFSimpleShape)shape).getShapeType());
/*  62 */     c.setObjectId(shapeId);
/*  63 */     c.setLocked(true);
/*  64 */     c.setPrintable(true);
/*  65 */     c.setAutofill(true);
/*  66 */     c.setAutoline(true);
/*  67 */     EndSubRecord e = new EndSubRecord();
/*     */     
/*  69 */     obj.addSubRecord(c);
/*  70 */     obj.addSubRecord(e);
/*     */     
/*  72 */     return obj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EscherContainerRecord createSpContainer(HSSFTextbox hssfShape, int shapeId)
/*     */   {
/*  83 */     HSSFTextbox shape = hssfShape;
/*     */     
/*  85 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/*  86 */     EscherSpRecord sp = new EscherSpRecord();
/*  87 */     EscherOptRecord opt = new EscherOptRecord();
/*  88 */     EscherRecord anchor = new EscherClientAnchorRecord();
/*  89 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*  90 */     this.escherTextbox = new EscherTextboxRecord();
/*     */     
/*  92 */     spContainer.setRecordId((short)61444);
/*  93 */     spContainer.setOptions((short)15);
/*  94 */     sp.setRecordId((short)61450);
/*  95 */     sp.setOptions((short)3234);
/*     */     
/*  97 */     sp.setShapeId(shapeId);
/*  98 */     sp.setFlags(2560);
/*  99 */     opt.setRecordId((short)61451);
/*     */     
/* 101 */     opt.addEscherProperty(new EscherSimpleProperty((short)128, 0));
/* 102 */     opt.addEscherProperty(new EscherSimpleProperty((short)129, shape.getMarginLeft()));
/* 103 */     opt.addEscherProperty(new EscherSimpleProperty((short)131, shape.getMarginRight()));
/* 104 */     opt.addEscherProperty(new EscherSimpleProperty((short)132, shape.getMarginBottom()));
/* 105 */     opt.addEscherProperty(new EscherSimpleProperty((short)130, shape.getMarginTop()));
/*     */     
/* 107 */     opt.addEscherProperty(new EscherSimpleProperty((short)133, 0));
/* 108 */     opt.addEscherProperty(new EscherSimpleProperty((short)135, 0));
/* 109 */     opt.addEscherProperty(new EscherSimpleProperty((short)959, 524288));
/*     */     
/* 111 */     addStandardOptions(shape, opt);
/* 112 */     HSSFAnchor userAnchor = shape.getAnchor();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 117 */     anchor = createAnchor(userAnchor);
/* 118 */     clientData.setRecordId((short)61457);
/* 119 */     clientData.setOptions((short)0);
/* 120 */     this.escherTextbox.setRecordId((short)61453);
/* 121 */     this.escherTextbox.setOptions((short)0);
/*     */     
/* 123 */     spContainer.addChildRecord(sp);
/* 124 */     spContainer.addChildRecord(opt);
/* 125 */     spContainer.addChildRecord(anchor);
/* 126 */     spContainer.addChildRecord(clientData);
/* 127 */     spContainer.addChildRecord(this.escherTextbox);
/*     */     
/* 129 */     return spContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TextObjectRecord createTextObjectRecord(HSSFTextbox hssfShape, int shapeId)
/*     */   {
/* 138 */     HSSFTextbox shape = hssfShape;
/*     */     
/* 140 */     TextObjectRecord obj = new TextObjectRecord();
/* 141 */     obj.setHorizontalTextAlignment(hssfShape.getHorizontalAlignment());
/* 142 */     obj.setVerticalTextAlignment(hssfShape.getVerticalAlignment());
/* 143 */     obj.setTextLocked(true);
/* 144 */     obj.setTextOrientation(0);
/* 145 */     obj.setStr(shape.getString());
/*     */     
/* 147 */     return obj;
/*     */   }
/*     */   
/*     */   public EscherContainerRecord getSpContainer()
/*     */   {
/* 152 */     return this.spContainer;
/*     */   }
/*     */   
/*     */   public ObjRecord getObjRecord()
/*     */   {
/* 157 */     return this.objRecord;
/*     */   }
/*     */   
/*     */   public TextObjectRecord getTextObjectRecord()
/*     */   {
/* 162 */     return this.textObjectRecord;
/*     */   }
/*     */   
/*     */   public EscherRecord getEscherTextbox()
/*     */   {
/* 167 */     return this.escherTextbox;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\TextboxShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */