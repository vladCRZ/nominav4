/*     */ package org.apache.poi.hssf.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WorkbookRecordList
/*     */   implements Iterable<Record>
/*     */ {
/*  27 */   private List<Record> records = new ArrayList();
/*     */   
/*  29 */   private int protpos = 0;
/*  30 */   private int bspos = 0;
/*  31 */   private int tabpos = 0;
/*  32 */   private int fontpos = 0;
/*  33 */   private int xfpos = 0;
/*  34 */   private int backuppos = 0;
/*  35 */   private int namepos = 0;
/*  36 */   private int supbookpos = 0;
/*  37 */   private int externsheetPos = 0;
/*  38 */   private int palettepos = -1;
/*     */   
/*     */   public void setRecords(List<Record> records)
/*     */   {
/*  42 */     this.records = records;
/*     */   }
/*     */   
/*     */   public int size() {
/*  46 */     return this.records.size();
/*     */   }
/*     */   
/*     */   public Record get(int i) {
/*  50 */     return (Record)this.records.get(i);
/*     */   }
/*     */   
/*     */   public void add(int pos, Record r) {
/*  54 */     this.records.add(pos, r);
/*  55 */     if (getProtpos() >= pos) setProtpos(this.protpos + 1);
/*  56 */     if (getBspos() >= pos) setBspos(this.bspos + 1);
/*  57 */     if (getTabpos() >= pos) setTabpos(this.tabpos + 1);
/*  58 */     if (getFontpos() >= pos) setFontpos(this.fontpos + 1);
/*  59 */     if (getXfpos() >= pos) setXfpos(this.xfpos + 1);
/*  60 */     if (getBackuppos() >= pos) setBackuppos(this.backuppos + 1);
/*  61 */     if (getNamepos() >= pos) setNamepos(this.namepos + 1);
/*  62 */     if (getSupbookpos() >= pos) setSupbookpos(this.supbookpos + 1);
/*  63 */     if ((getPalettepos() != -1) && (getPalettepos() >= pos)) setPalettepos(this.palettepos + 1);
/*  64 */     if (getExternsheetPos() >= pos) setExternsheetPos(getExternsheetPos() + 1);
/*     */   }
/*     */   
/*     */   public List<Record> getRecords() {
/*  68 */     return this.records;
/*     */   }
/*     */   
/*     */   public Iterator<Record> iterator() {
/*  72 */     return this.records.iterator();
/*     */   }
/*     */   
/*     */   public void remove(Object record) {
/*  76 */     int i = this.records.indexOf(record);
/*  77 */     remove(i);
/*     */   }
/*     */   
/*     */   public void remove(int pos)
/*     */   {
/*  82 */     this.records.remove(pos);
/*  83 */     if (getProtpos() >= pos) setProtpos(this.protpos - 1);
/*  84 */     if (getBspos() >= pos) setBspos(this.bspos - 1);
/*  85 */     if (getTabpos() >= pos) setTabpos(this.tabpos - 1);
/*  86 */     if (getFontpos() >= pos) setFontpos(this.fontpos - 1);
/*  87 */     if (getXfpos() >= pos) setXfpos(this.xfpos - 1);
/*  88 */     if (getBackuppos() >= pos) setBackuppos(this.backuppos - 1);
/*  89 */     if (getNamepos() >= pos) setNamepos(getNamepos() - 1);
/*  90 */     if (getSupbookpos() >= pos) setSupbookpos(getSupbookpos() - 1);
/*  91 */     if ((getPalettepos() != -1) && (getPalettepos() >= pos)) setPalettepos(this.palettepos - 1);
/*  92 */     if (getExternsheetPos() >= pos) setExternsheetPos(getExternsheetPos() - 1);
/*     */   }
/*     */   
/*     */   public int getProtpos() {
/*  96 */     return this.protpos;
/*     */   }
/*     */   
/*     */   public void setProtpos(int protpos) {
/* 100 */     this.protpos = protpos;
/*     */   }
/*     */   
/*     */   public int getBspos() {
/* 104 */     return this.bspos;
/*     */   }
/*     */   
/*     */   public void setBspos(int bspos) {
/* 108 */     this.bspos = bspos;
/*     */   }
/*     */   
/*     */   public int getTabpos() {
/* 112 */     return this.tabpos;
/*     */   }
/*     */   
/*     */   public void setTabpos(int tabpos) {
/* 116 */     this.tabpos = tabpos;
/*     */   }
/*     */   
/*     */   public int getFontpos() {
/* 120 */     return this.fontpos;
/*     */   }
/*     */   
/*     */   public void setFontpos(int fontpos) {
/* 124 */     this.fontpos = fontpos;
/*     */   }
/*     */   
/*     */   public int getXfpos() {
/* 128 */     return this.xfpos;
/*     */   }
/*     */   
/*     */   public void setXfpos(int xfpos) {
/* 132 */     this.xfpos = xfpos;
/*     */   }
/*     */   
/*     */   public int getBackuppos() {
/* 136 */     return this.backuppos;
/*     */   }
/*     */   
/*     */   public void setBackuppos(int backuppos) {
/* 140 */     this.backuppos = backuppos;
/*     */   }
/*     */   
/*     */   public int getPalettepos() {
/* 144 */     return this.palettepos;
/*     */   }
/*     */   
/*     */   public void setPalettepos(int palettepos) {
/* 148 */     this.palettepos = palettepos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNamepos()
/*     */   {
/* 157 */     return this.namepos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSupbookpos()
/*     */   {
/* 165 */     return this.supbookpos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamepos(int namepos)
/*     */   {
/* 173 */     this.namepos = namepos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSupbookpos(int supbookpos)
/*     */   {
/* 181 */     this.supbookpos = supbookpos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getExternsheetPos()
/*     */   {
/* 189 */     return this.externsheetPos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExternsheetPos(int externsheetPos)
/*     */   {
/* 197 */     this.externsheetPos = externsheetPos;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\model\WorkbookRecordList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */