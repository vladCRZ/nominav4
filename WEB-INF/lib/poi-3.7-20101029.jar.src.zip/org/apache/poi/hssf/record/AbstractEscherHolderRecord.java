/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.ddf.DefaultEscherRecordFactory;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherRecordFactory;
/*     */ import org.apache.poi.ddf.NullEscherSerializationListener;
/*     */ import org.apache.poi.hssf.util.LazilyConcatenatedByteArray;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEscherHolderRecord
/*     */   extends Record
/*     */ {
/*     */   private static boolean DESERIALISE;
/*     */   private List<EscherRecord> escherRecords;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  43 */       DESERIALISE = System.getProperty("poi.deserialize.escher") != null;
/*     */     } catch (SecurityException e) {
/*  45 */       DESERIALISE = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  50 */   private LazilyConcatenatedByteArray rawDataContainer = new LazilyConcatenatedByteArray();
/*     */   
/*     */   public AbstractEscherHolderRecord()
/*     */   {
/*  54 */     this.escherRecords = new ArrayList();
/*     */   }
/*     */   
/*     */   public AbstractEscherHolderRecord(RecordInputStream in)
/*     */   {
/*  59 */     this.escherRecords = new ArrayList();
/*  60 */     if (!DESERIALISE)
/*     */     {
/*  62 */       this.rawDataContainer.concatenate(in.readRemainder());
/*     */     }
/*     */     else
/*     */     {
/*  66 */       byte[] data = in.readAllContinuedRemainder();
/*  67 */       convertToEscherRecords(0, data.length, data);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void convertRawBytesToEscherRecords() {
/*  72 */     byte[] rawData = getRawData();
/*  73 */     convertToEscherRecords(0, rawData.length, rawData);
/*     */   }
/*     */   
/*     */   private void convertToEscherRecords(int offset, int size, byte[] data) {
/*  77 */     EscherRecordFactory recordFactory = new DefaultEscherRecordFactory();
/*  78 */     int pos = offset;
/*  79 */     while (pos < offset + size)
/*     */     {
/*  81 */       EscherRecord r = recordFactory.createRecord(data, pos);
/*  82 */       int bytesRead = r.fillFields(data, pos, recordFactory);
/*  83 */       this.escherRecords.add(r);
/*  84 */       pos += bytesRead;
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  90 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  92 */     String nl = System.getProperty("line.separator");
/*  93 */     buffer.append('[' + getRecordName() + ']' + nl);
/*  94 */     if (this.escherRecords.size() == 0)
/*  95 */       buffer.append("No Escher Records Decoded" + nl);
/*  96 */     for (Iterator<EscherRecord> iterator = this.escherRecords.iterator(); iterator.hasNext();)
/*     */     {
/*  98 */       EscherRecord r = (EscherRecord)iterator.next();
/*  99 */       buffer.append(r.toString());
/*     */     }
/* 101 */     buffer.append("[/" + getRecordName() + ']' + nl);
/*     */     
/* 103 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int serialize(int offset, byte[] data)
/*     */   {
/* 110 */     LittleEndian.putShort(data, 0 + offset, getSid());
/* 111 */     LittleEndian.putShort(data, 2 + offset, (short)(getRecordSize() - 4));
/* 112 */     byte[] rawData = getRawData();
/* 113 */     if ((this.escherRecords.size() == 0) && (rawData != null))
/*     */     {
/* 115 */       LittleEndian.putShort(data, 0 + offset, getSid());
/* 116 */       LittleEndian.putShort(data, 2 + offset, (short)(getRecordSize() - 4));
/* 117 */       System.arraycopy(rawData, 0, data, 4 + offset, rawData.length);
/* 118 */       return rawData.length + 4;
/*     */     }
/* 120 */     LittleEndian.putShort(data, 0 + offset, getSid());
/* 121 */     LittleEndian.putShort(data, 2 + offset, (short)(getRecordSize() - 4));
/*     */     
/* 123 */     int pos = offset + 4;
/* 124 */     for (Iterator<EscherRecord> iterator = this.escherRecords.iterator(); iterator.hasNext();)
/*     */     {
/* 126 */       EscherRecord r = (EscherRecord)iterator.next();
/* 127 */       pos += r.serialize(pos, data, new NullEscherSerializationListener());
/*     */     }
/* 129 */     return getRecordSize();
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/* 133 */     byte[] rawData = getRawData();
/* 134 */     if ((this.escherRecords.size() == 0) && (rawData != null))
/*     */     {
/* 136 */       return rawData.length;
/*     */     }
/* 138 */     int size = 0;
/* 139 */     for (Iterator<EscherRecord> iterator = this.escherRecords.iterator(); iterator.hasNext();)
/*     */     {
/* 141 */       EscherRecord r = (EscherRecord)iterator.next();
/* 142 */       size += r.getRecordSize();
/*     */     }
/* 144 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 153 */     return cloneViaReserialise();
/*     */   }
/*     */   
/*     */   public void addEscherRecord(int index, EscherRecord element)
/*     */   {
/* 158 */     this.escherRecords.add(index, element);
/*     */   }
/*     */   
/*     */   public boolean addEscherRecord(EscherRecord element)
/*     */   {
/* 163 */     return this.escherRecords.add(element);
/*     */   }
/*     */   
/*     */   public List<EscherRecord> getEscherRecords()
/*     */   {
/* 168 */     return this.escherRecords;
/*     */   }
/*     */   
/*     */   public void clearEscherRecords()
/*     */   {
/* 173 */     this.escherRecords.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherContainerRecord getEscherContainer()
/*     */   {
/* 182 */     for (Iterator<EscherRecord> it = this.escherRecords.iterator(); it.hasNext();) {
/* 183 */       EscherRecord er = (EscherRecord)it.next();
/* 184 */       if ((er instanceof EscherContainerRecord)) {
/* 185 */         return (EscherContainerRecord)er;
/*     */       }
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EscherRecord findFirstWithId(short id)
/*     */   {
/* 197 */     return findFirstWithId(id, getEscherRecords());
/*     */   }
/*     */   
/*     */   private EscherRecord findFirstWithId(short id, List<EscherRecord> records) {
/* 201 */     for (Iterator<EscherRecord> it = records.iterator(); it.hasNext();) {
/* 202 */       EscherRecord r = (EscherRecord)it.next();
/* 203 */       if (r.getRecordId() == id) {
/* 204 */         return r;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 209 */     for (Iterator<EscherRecord> it = records.iterator(); it.hasNext();) {
/* 210 */       EscherRecord r = (EscherRecord)it.next();
/* 211 */       if (r.isContainerRecord()) {
/* 212 */         EscherRecord found = findFirstWithId(id, r.getChildRecords());
/* 213 */         if (found != null) {
/* 214 */           return found;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 220 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public EscherRecord getEscherRecord(int index)
/*     */   {
/* 226 */     return (EscherRecord)this.escherRecords.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void join(AbstractEscherHolderRecord record)
/*     */   {
/* 235 */     this.rawDataContainer.concatenate(record.getRawData());
/*     */   }
/*     */   
/*     */   public void processContinueRecord(byte[] record)
/*     */   {
/* 240 */     this.rawDataContainer.concatenate(record);
/*     */   }
/*     */   
/*     */   public byte[] getRawData()
/*     */   {
/* 245 */     return this.rawDataContainer.toArray();
/*     */   }
/*     */   
/*     */   public void setRawData(byte[] rawData)
/*     */   {
/* 250 */     this.rawDataContainer.clear();
/* 251 */     this.rawDataContainer.concatenate(rawData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decode()
/*     */   {
/* 259 */     byte[] rawData = getRawData();
/* 260 */     convertToEscherRecords(0, rawData.length, rawData);
/*     */   }
/*     */   
/*     */   protected abstract String getRecordName();
/*     */   
/*     */   public abstract short getSid();
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\AbstractEscherHolderRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */