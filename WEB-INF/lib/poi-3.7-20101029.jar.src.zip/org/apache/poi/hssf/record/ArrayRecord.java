/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.Ptg;
/*    */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*    */ import org.apache.poi.ss.formula.Formula;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ArrayRecord
/*    */   extends SharedValueRecordBase
/*    */ {
/*    */   public static final short sid = 545;
/*    */   private static final int OPT_ALWAYS_RECALCULATE = 1;
/*    */   private static final int OPT_CALCULATE_ON_OPEN = 2;
/*    */   private int _options;
/*    */   private int _field3notUsed;
/*    */   private Formula _formula;
/*    */   
/*    */   public ArrayRecord(RecordInputStream in)
/*    */   {
/* 44 */     super(in);
/* 45 */     this._options = in.readUShort();
/* 46 */     this._field3notUsed = in.readInt();
/* 47 */     int formulaTokenLen = in.readUShort();
/* 48 */     int totalFormulaLen = in.available();
/* 49 */     this._formula = Formula.read(formulaTokenLen, in, totalFormulaLen);
/*    */   }
/*    */   
/*    */   public ArrayRecord(Formula formula, CellRangeAddress8Bit range) {
/* 53 */     super(range);
/* 54 */     this._options = 0;
/* 55 */     this._field3notUsed = 0;
/* 56 */     this._formula = formula;
/*    */   }
/*    */   
/*    */   public boolean isAlwaysRecalculate() {
/* 60 */     return (this._options & 0x1) != 0;
/*    */   }
/*    */   
/* 63 */   public boolean isCalculateOnOpen() { return (this._options & 0x2) != 0; }
/*    */   
/*    */   public Ptg[] getFormulaTokens()
/*    */   {
/* 67 */     return this._formula.getTokens();
/*    */   }
/*    */   
/*    */ 
/* 71 */   protected int getExtraDataSize() { return 6 + this._formula.getEncodedSize(); }
/*    */   
/*    */   protected void serializeExtraData(LittleEndianOutput out) {
/* 74 */     out.writeShort(this._options);
/* 75 */     out.writeInt(this._field3notUsed);
/* 76 */     this._formula.serialize(out);
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 80 */     return 545;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 84 */     StringBuffer sb = new StringBuffer();
/* 85 */     sb.append(getClass().getName()).append(" [ARRAY]\n");
/* 86 */     sb.append(" range=").append(getRange().toString()).append("\n");
/* 87 */     sb.append(" options=").append(HexDump.shortToHex(this._options)).append("\n");
/* 88 */     sb.append(" notUsed=").append(HexDump.intToHex(this._field3notUsed)).append("\n");
/* 89 */     sb.append(" formula:").append("\n");
/* 90 */     Ptg[] ptgs = this._formula.getTokens();
/* 91 */     for (int i = 0; i < ptgs.length; i++) {
/* 92 */       Ptg ptg = ptgs[i];
/* 93 */       sb.append(ptg.toString()).append(ptg.getRVAType()).append("\n");
/*    */     }
/* 95 */     sb.append("]");
/* 96 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ArrayRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */