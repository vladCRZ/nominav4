/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BOFRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 2057;
/*     */   public static final int VERSION = 1536;
/*     */   public static final int BUILD = 4307;
/*     */   public static final int BUILD_YEAR = 1996;
/*     */   public static final int HISTORY_MASK = 65;
/*     */   public static final int TYPE_WORKBOOK = 5;
/*     */   public static final int TYPE_VB_MODULE = 6;
/*     */   public static final int TYPE_WORKSHEET = 16;
/*     */   public static final int TYPE_CHART = 32;
/*     */   public static final int TYPE_EXCEL_4_MACRO = 64;
/*     */   public static final int TYPE_WORKSPACE_FILE = 256;
/*     */   private int field_1_version;
/*     */   private int field_2_type;
/*     */   private int field_3_build;
/*     */   private int field_4_year;
/*     */   private int field_5_history;
/*     */   private int field_6_rversion;
/*     */   
/*     */   public BOFRecord() {}
/*     */   
/*     */   private BOFRecord(int type)
/*     */   {
/*  68 */     this.field_1_version = 1536;
/*  69 */     this.field_2_type = type;
/*  70 */     this.field_3_build = 4307;
/*  71 */     this.field_4_year = 1996;
/*  72 */     this.field_5_history = 1;
/*  73 */     this.field_6_rversion = 1536;
/*     */   }
/*     */   
/*     */   public static BOFRecord createSheetBOF() {
/*  77 */     return new BOFRecord(16);
/*     */   }
/*     */   
/*     */   public BOFRecord(RecordInputStream in) {
/*  81 */     this.field_1_version = in.readShort();
/*  82 */     this.field_2_type = in.readShort();
/*     */     
/*     */ 
/*     */ 
/*  86 */     if (in.remaining() >= 2) {
/*  87 */       this.field_3_build = in.readShort();
/*     */     }
/*  89 */     if (in.remaining() >= 2) {
/*  90 */       this.field_4_year = in.readShort();
/*     */     }
/*  92 */     if (in.remaining() >= 4) {
/*  93 */       this.field_5_history = in.readInt();
/*     */     }
/*  95 */     if (in.remaining() >= 4) {
/*  96 */       this.field_6_rversion = in.readInt();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVersion(int version)
/*     */   {
/* 106 */     this.field_1_version = version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(int type)
/*     */   {
/* 120 */     this.field_2_type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBuild(int build)
/*     */   {
/* 129 */     this.field_3_build = build;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBuildYear(int year)
/*     */   {
/* 138 */     this.field_4_year = year;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHistoryBitMask(int bitmask)
/*     */   {
/* 147 */     this.field_5_history = bitmask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequiredVersion(int version)
/*     */   {
/* 157 */     this.field_6_rversion = version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVersion()
/*     */   {
/* 166 */     return this.field_1_version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getType()
/*     */   {
/* 180 */     return this.field_2_type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBuild()
/*     */   {
/* 189 */     return this.field_3_build;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBuildYear()
/*     */   {
/* 198 */     return this.field_4_year;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHistoryBitMask()
/*     */   {
/* 207 */     return this.field_5_history;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRequiredVersion()
/*     */   {
/* 217 */     return this.field_6_rversion;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 221 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 223 */     buffer.append("[BOF RECORD]\n");
/* 224 */     buffer.append("    .version  = ").append(HexDump.shortToHex(getVersion())).append("\n");
/* 225 */     buffer.append("    .type     = ").append(HexDump.shortToHex(getType()));
/* 226 */     buffer.append(" (").append(getTypeName()).append(")").append("\n");
/* 227 */     buffer.append("    .build    = ").append(HexDump.shortToHex(getBuild())).append("\n");
/* 228 */     buffer.append("    .buildyear= ").append(getBuildYear()).append("\n");
/* 229 */     buffer.append("    .history  = ").append(HexDump.intToHex(getHistoryBitMask())).append("\n");
/* 230 */     buffer.append("    .reqver   = ").append(HexDump.intToHex(getRequiredVersion())).append("\n");
/* 231 */     buffer.append("[/BOF RECORD]\n");
/* 232 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String getTypeName() {
/* 236 */     switch (this.field_2_type) {
/* 237 */     case 32:  return "chart";
/* 238 */     case 64:  return "excel 4 macro";
/* 239 */     case 6:  return "vb module";
/* 240 */     case 5:  return "workbook";
/* 241 */     case 16:  return "worksheet";
/* 242 */     case 256:  return "workspace file";
/*     */     }
/* 244 */     return "#error unknown type#";
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 248 */     out.writeShort(getVersion());
/* 249 */     out.writeShort(getType());
/* 250 */     out.writeShort(getBuild());
/* 251 */     out.writeShort(getBuildYear());
/* 252 */     out.writeInt(getHistoryBitMask());
/* 253 */     out.writeInt(getRequiredVersion());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 257 */     return 16;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 261 */     return 2057;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 265 */     BOFRecord rec = new BOFRecord();
/* 266 */     rec.field_1_version = this.field_1_version;
/* 267 */     rec.field_2_type = this.field_2_type;
/* 268 */     rec.field_3_build = this.field_3_build;
/* 269 */     rec.field_4_year = this.field_4_year;
/* 270 */     rec.field_5_history = this.field_5_history;
/* 271 */     rec.field_6_rversion = this.field_6_rversion;
/* 272 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\BOFRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */