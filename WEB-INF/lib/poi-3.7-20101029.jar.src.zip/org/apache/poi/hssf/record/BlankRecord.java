/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BlankRecord
/*     */   extends StandardRecord
/*     */   implements CellValueRecordInterface
/*     */ {
/*     */   public static final short sid = 513;
/*     */   private int field_1_row;
/*     */   private short field_2_col;
/*     */   private short field_3_xf;
/*     */   
/*     */   public BlankRecord() {}
/*     */   
/*     */   public BlankRecord(RecordInputStream in)
/*     */   {
/*  44 */     this.field_1_row = in.readUShort();
/*  45 */     this.field_2_col = in.readShort();
/*  46 */     this.field_3_xf = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRow(int row)
/*     */   {
/*  55 */     this.field_1_row = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/*  65 */     return this.field_1_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getColumn()
/*     */   {
/*  75 */     return this.field_2_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXFIndex(short xf)
/*     */   {
/*  86 */     this.field_3_xf = xf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getXFIndex()
/*     */   {
/*  96 */     return this.field_3_xf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumn(short col)
/*     */   {
/* 107 */     this.field_2_col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 115 */     return 513;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 120 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 122 */     sb.append("[BLANK]\n");
/* 123 */     sb.append("    row= ").append(HexDump.shortToHex(getRow())).append("\n");
/* 124 */     sb.append("    col= ").append(HexDump.shortToHex(getColumn())).append("\n");
/* 125 */     sb.append("    xf = ").append(HexDump.shortToHex(getXFIndex())).append("\n");
/* 126 */     sb.append("[/BLANK]\n");
/* 127 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 131 */     out.writeShort(getRow());
/* 132 */     out.writeShort(getColumn());
/* 133 */     out.writeShort(getXFIndex());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 137 */     return 6;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 141 */     BlankRecord rec = new BlankRecord();
/* 142 */     rec.field_1_row = this.field_1_row;
/* 143 */     rec.field_2_col = this.field_2_col;
/* 144 */     rec.field_3_xf = this.field_3_xf;
/* 145 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\BlankRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */