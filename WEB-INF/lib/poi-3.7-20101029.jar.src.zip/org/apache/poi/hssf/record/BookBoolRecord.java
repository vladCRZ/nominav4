/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BookBoolRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 218;
/*    */   private short field_1_save_link_values;
/*    */   
/*    */   public BookBoolRecord() {}
/*    */   
/*    */   public BookBoolRecord(RecordInputStream in)
/*    */   {
/* 45 */     this.field_1_save_link_values = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSaveLinkValues(short flag)
/*    */   {
/* 56 */     this.field_1_save_link_values = flag;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getSaveLinkValues()
/*    */   {
/* 67 */     return this.field_1_save_link_values;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 72 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 74 */     buffer.append("[BOOKBOOL]\n");
/* 75 */     buffer.append("    .savelinkvalues  = ").append(Integer.toHexString(getSaveLinkValues())).append("\n");
/*    */     
/* 77 */     buffer.append("[/BOOKBOOL]\n");
/* 78 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 82 */     out.writeShort(this.field_1_save_link_values);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 86 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 91 */     return 218;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\BookBoolRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */