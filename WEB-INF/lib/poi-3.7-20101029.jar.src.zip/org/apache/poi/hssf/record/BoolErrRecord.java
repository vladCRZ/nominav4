/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.ss.usermodel.ErrorConstants;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BoolErrRecord
/*     */   extends CellRecord
/*     */ {
/*     */   public static final short sid = 517;
/*     */   private int _value;
/*     */   private boolean _isError;
/*     */   
/*     */   public BoolErrRecord() {}
/*     */   
/*     */   public BoolErrRecord(RecordInputStream in)
/*     */   {
/*  47 */     super(in);
/*  48 */     switch (in.remaining()) {
/*     */     case 2: 
/*  50 */       this._value = in.readByte();
/*  51 */       break;
/*     */     case 3: 
/*  53 */       this._value = in.readUShort();
/*  54 */       break;
/*     */     default: 
/*  56 */       throw new RecordFormatException("Unexpected size (" + in.remaining() + ") for BOOLERR record.");
/*     */     }
/*     */     
/*  59 */     int flag = in.readUByte();
/*  60 */     switch (flag) {
/*     */     case 0: 
/*  62 */       this._isError = false;
/*  63 */       break;
/*     */     case 1: 
/*  65 */       this._isError = true;
/*  66 */       break;
/*     */     default: 
/*  68 */       throw new RecordFormatException("Unexpected isError flag (" + flag + ") for BOOLERR record.");
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(boolean value)
/*     */   {
/*  79 */     this._value = (value ? 1 : 0);
/*  80 */     this._isError = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(byte value)
/*     */   {
/*  91 */     switch (value) {
/*     */     case 0: 
/*     */     case 7: 
/*     */     case 15: 
/*     */     case 23: 
/*     */     case 29: 
/*     */     case 36: 
/*     */     case 42: 
/*  99 */       this._value = value;
/* 100 */       this._isError = true;
/* 101 */       return;
/*     */     }
/* 103 */     throw new IllegalArgumentException("Error Value can only be 0,7,15,23,29,36 or 42. It cannot be " + value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getBooleanValue()
/*     */   {
/* 112 */     return this._value != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getErrorValue()
/*     */   {
/* 121 */     return (byte)this._value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBoolean()
/*     */   {
/* 130 */     return !this._isError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isError()
/*     */   {
/* 139 */     return this._isError;
/*     */   }
/*     */   
/*     */   protected String getRecordName()
/*     */   {
/* 144 */     return "BOOLERR";
/*     */   }
/*     */   
/*     */   protected void appendValueText(StringBuilder sb) {
/* 148 */     if (isBoolean()) {
/* 149 */       sb.append("  .boolVal = ");
/* 150 */       sb.append(getBooleanValue());
/*     */     } else {
/* 152 */       sb.append("  .errCode = ");
/* 153 */       sb.append(ErrorConstants.getText(getErrorValue()));
/* 154 */       sb.append(" (").append(HexDump.byteToHex(getErrorValue())).append(")");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void serializeValue(LittleEndianOutput out) {
/* 159 */     out.writeByte(this._value);
/* 160 */     out.writeByte(this._isError ? 1 : 0);
/*     */   }
/*     */   
/*     */   protected int getValueDataSize()
/*     */   {
/* 165 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 169 */     return 517;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 173 */     BoolErrRecord rec = new BoolErrRecord();
/* 174 */     copyBaseFields(rec);
/* 175 */     rec._value = this._value;
/* 176 */     rec._isError = this._isError;
/* 177 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\BoolErrRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */