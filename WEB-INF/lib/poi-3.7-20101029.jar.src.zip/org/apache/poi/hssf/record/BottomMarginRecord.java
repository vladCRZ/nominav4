/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BottomMarginRecord
/*    */   extends StandardRecord
/*    */   implements Margin
/*    */ {
/*    */   public static final short sid = 41;
/*    */   private double field_1_margin;
/*    */   
/*    */   public BottomMarginRecord() {}
/*    */   
/*    */   public BottomMarginRecord(RecordInputStream in)
/*    */   {
/* 41 */     this.field_1_margin = in.readDouble();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 46 */     StringBuffer buffer = new StringBuffer();
/* 47 */     buffer.append("[BottomMargin]\n");
/* 48 */     buffer.append("    .margin               = ").append(" (").append(getMargin()).append(" )\n");
/*    */     
/* 50 */     buffer.append("[/BottomMargin]\n");
/* 51 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 55 */     out.writeDouble(this.field_1_margin);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 59 */     return 8;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 64 */     return 41;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getMargin()
/*    */   {
/* 72 */     return this.field_1_margin;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMargin(double field_1_margin)
/*    */   {
/* 80 */     this.field_1_margin = field_1_margin;
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/* 85 */     BottomMarginRecord rec = new BottomMarginRecord();
/* 86 */     rec.field_1_margin = this.field_1_margin;
/* 87 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\BottomMarginRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */