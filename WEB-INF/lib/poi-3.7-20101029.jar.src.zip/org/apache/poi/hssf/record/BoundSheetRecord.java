/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.ss.util.WorkbookUtil;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BoundSheetRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 133;
/*  43 */   private static final BitField hiddenFlag = BitFieldFactory.getInstance(1);
/*  44 */   private static final BitField veryHiddenFlag = BitFieldFactory.getInstance(2);
/*     */   private int field_1_position_of_BOF;
/*     */   private int field_2_option_flags;
/*     */   private int field_4_isMultibyteUnicode;
/*     */   private String field_5_sheetname;
/*     */   
/*     */   public BoundSheetRecord(String sheetname) {
/*  51 */     this.field_2_option_flags = 0;
/*  52 */     setSheetname(sheetname);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BoundSheetRecord(RecordInputStream in)
/*     */   {
/*  63 */     this.field_1_position_of_BOF = in.readInt();
/*  64 */     this.field_2_option_flags = in.readUShort();
/*  65 */     int field_3_sheetname_length = in.readUByte();
/*  66 */     this.field_4_isMultibyteUnicode = in.readByte();
/*     */     
/*  68 */     if (isMultibyte()) {
/*  69 */       this.field_5_sheetname = in.readUnicodeLEString(field_3_sheetname_length);
/*     */     } else {
/*  71 */       this.field_5_sheetname = in.readCompressedUnicode(field_3_sheetname_length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPositionOfBof(int pos)
/*     */   {
/*  82 */     this.field_1_position_of_BOF = pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSheetname(String sheetName)
/*     */   {
/*  94 */     WorkbookUtil.validateSheetName(sheetName);
/*  95 */     this.field_5_sheetname = sheetName;
/*  96 */     this.field_4_isMultibyteUnicode = (StringUtil.hasMultibyte(sheetName) ? 1 : 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPositionOfBof()
/*     */   {
/* 105 */     return this.field_1_position_of_BOF;
/*     */   }
/*     */   
/*     */   private boolean isMultibyte() {
/* 109 */     return (this.field_4_isMultibyteUnicode & 0x1) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSheetname()
/*     */   {
/* 117 */     return this.field_5_sheetname;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 121 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 123 */     buffer.append("[BOUNDSHEET]\n");
/* 124 */     buffer.append("    .bof        = ").append(HexDump.intToHex(getPositionOfBof())).append("\n");
/* 125 */     buffer.append("    .options    = ").append(HexDump.shortToHex(this.field_2_option_flags)).append("\n");
/* 126 */     buffer.append("    .unicodeflag= ").append(HexDump.byteToHex(this.field_4_isMultibyteUnicode)).append("\n");
/* 127 */     buffer.append("    .sheetname  = ").append(this.field_5_sheetname).append("\n");
/* 128 */     buffer.append("[/BOUNDSHEET]\n");
/* 129 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 133 */     return 8 + this.field_5_sheetname.length() * (isMultibyte() ? 2 : 1);
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 137 */     out.writeInt(getPositionOfBof());
/* 138 */     out.writeShort(this.field_2_option_flags);
/*     */     
/* 140 */     String name = this.field_5_sheetname;
/* 141 */     out.writeByte(name.length());
/* 142 */     out.writeByte(this.field_4_isMultibyteUnicode);
/*     */     
/* 144 */     if (isMultibyte()) {
/* 145 */       StringUtil.putUnicodeLE(name, out);
/*     */     } else {
/* 147 */       StringUtil.putCompressedUnicode(name, out);
/*     */     }
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 152 */     return 133;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isHidden()
/*     */   {
/* 159 */     return hiddenFlag.isSet(this.field_2_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHidden(boolean hidden)
/*     */   {
/* 166 */     this.field_2_option_flags = hiddenFlag.setBoolean(this.field_2_option_flags, hidden);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isVeryHidden()
/*     */   {
/* 173 */     return veryHiddenFlag.isSet(this.field_2_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setVeryHidden(boolean veryHidden)
/*     */   {
/* 180 */     this.field_2_option_flags = veryHiddenFlag.setBoolean(this.field_2_option_flags, veryHidden);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BoundSheetRecord[] orderByBofPosition(List<BoundSheetRecord> boundSheetRecords)
/*     */   {
/* 188 */     BoundSheetRecord[] bsrs = new BoundSheetRecord[boundSheetRecords.size()];
/* 189 */     boundSheetRecords.toArray(bsrs);
/* 190 */     Arrays.sort(bsrs, BOFComparator);
/* 191 */     return bsrs; }
/*     */   
/* 193 */   private static final Comparator<BoundSheetRecord> BOFComparator = new Comparator()
/*     */   {
/*     */     public int compare(BoundSheetRecord bsr1, BoundSheetRecord bsr2) {
/* 196 */       return bsr1.getPositionOfBof() - bsr2.getPositionOfBof();
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\BoundSheetRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */