/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.cf.CellRangeUtil;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.ss.util.CellRangeAddressList;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CFHeaderRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 432;
/*     */   private int field_1_numcf;
/*     */   private int field_2_need_recalculation;
/*     */   private CellRangeAddress field_3_enclosing_cell_range;
/*     */   private CellRangeAddressList field_4_cell_ranges;
/*     */   
/*  41 */   public CFHeaderRecord() { this.field_4_cell_ranges = new CellRangeAddressList(); }
/*     */   
/*     */   public CFHeaderRecord(CellRangeAddress[] regions, int nRules) {
/*  44 */     CellRangeAddress[] unmergedRanges = regions;
/*  45 */     CellRangeAddress[] mergeCellRanges = CellRangeUtil.mergeCellRanges(unmergedRanges);
/*  46 */     setCellRanges(mergeCellRanges);
/*  47 */     this.field_1_numcf = nRules;
/*     */   }
/*     */   
/*     */   public CFHeaderRecord(RecordInputStream in)
/*     */   {
/*  52 */     this.field_1_numcf = in.readShort();
/*  53 */     this.field_2_need_recalculation = in.readShort();
/*  54 */     this.field_3_enclosing_cell_range = new CellRangeAddress(in);
/*  55 */     this.field_4_cell_ranges = new CellRangeAddressList(in);
/*     */   }
/*     */   
/*     */   public int getNumberOfConditionalFormats()
/*     */   {
/*  60 */     return this.field_1_numcf;
/*     */   }
/*     */   
/*     */   public void setNumberOfConditionalFormats(int n) {
/*  64 */     this.field_1_numcf = n;
/*     */   }
/*     */   
/*     */   public boolean getNeedRecalculation()
/*     */   {
/*  69 */     return this.field_2_need_recalculation == 1;
/*     */   }
/*     */   
/*     */   public void setNeedRecalculation(boolean b)
/*     */   {
/*  74 */     this.field_2_need_recalculation = (b ? 1 : 0);
/*     */   }
/*     */   
/*     */   public CellRangeAddress getEnclosingCellRange()
/*     */   {
/*  79 */     return this.field_3_enclosing_cell_range;
/*     */   }
/*     */   
/*     */   public void setEnclosingCellRange(CellRangeAddress cr)
/*     */   {
/*  84 */     this.field_3_enclosing_cell_range = cr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCellRanges(CellRangeAddress[] cellRanges)
/*     */   {
/*  94 */     if (cellRanges == null)
/*     */     {
/*  96 */       throw new IllegalArgumentException("cellRanges must not be null");
/*     */     }
/*  98 */     CellRangeAddressList cral = new CellRangeAddressList();
/*  99 */     CellRangeAddress enclosingRange = null;
/* 100 */     for (int i = 0; i < cellRanges.length; i++)
/*     */     {
/* 102 */       CellRangeAddress cr = cellRanges[i];
/* 103 */       enclosingRange = CellRangeUtil.createEnclosingCellRange(cr, enclosingRange);
/* 104 */       cral.addCellRangeAddress(cr);
/*     */     }
/* 106 */     this.field_3_enclosing_cell_range = enclosingRange;
/* 107 */     this.field_4_cell_ranges = cral;
/*     */   }
/*     */   
/*     */   public CellRangeAddress[] getCellRanges() {
/* 111 */     return this.field_4_cell_ranges.getCellRangeAddresses();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 116 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 118 */     buffer.append("[CFHEADER]\n");
/* 119 */     buffer.append("\t.id\t\t= ").append(Integer.toHexString(432)).append("\n");
/* 120 */     buffer.append("\t.numCF\t\t\t= ").append(getNumberOfConditionalFormats()).append("\n");
/* 121 */     buffer.append("\t.needRecalc\t   = ").append(getNeedRecalculation()).append("\n");
/* 122 */     buffer.append("\t.enclosingCellRange= ").append(getEnclosingCellRange()).append("\n");
/* 123 */     buffer.append("\t.cfranges=[");
/* 124 */     for (int i = 0; i < this.field_4_cell_ranges.countRanges(); i++)
/*     */     {
/* 126 */       buffer.append(i == 0 ? "" : ",").append(this.field_4_cell_ranges.getCellRangeAddress(i).toString());
/*     */     }
/* 128 */     buffer.append("]\n");
/* 129 */     buffer.append("[/CFHEADER]\n");
/* 130 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 134 */     return 12 + this.field_4_cell_ranges.getSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 141 */     out.writeShort(this.field_1_numcf);
/* 142 */     out.writeShort(this.field_2_need_recalculation);
/* 143 */     this.field_3_enclosing_cell_range.serialize(out);
/* 144 */     this.field_4_cell_ranges.serialize(out);
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 148 */     return 432;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 153 */     CFHeaderRecord result = new CFHeaderRecord();
/* 154 */     result.field_1_numcf = this.field_1_numcf;
/* 155 */     result.field_2_need_recalculation = this.field_2_need_recalculation;
/* 156 */     result.field_3_enclosing_cell_range = this.field_3_enclosing_cell_range;
/* 157 */     result.field_4_cell_ranges = this.field_4_cell_ranges.copy();
/* 158 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CFHeaderRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */