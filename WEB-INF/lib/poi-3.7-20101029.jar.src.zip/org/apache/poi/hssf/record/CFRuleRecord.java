/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.model.HSSFFormulaParser;
/*     */ import org.apache.poi.hssf.record.cf.BorderFormatting;
/*     */ import org.apache.poi.hssf.record.cf.FontFormatting;
/*     */ import org.apache.poi.hssf.record.cf.PatternFormatting;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CFRuleRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 433;
/*     */   private byte field_1_condition_type;
/*     */   public static final byte CONDITION_TYPE_CELL_VALUE_IS = 1;
/*     */   public static final byte CONDITION_TYPE_FORMULA = 2;
/*     */   private byte field_2_comparison_operator;
/*     */   private int field_5_options;
/*  61 */   private static final BitField modificationBits = bf(4194303);
/*  62 */   private static final BitField alignHor = bf(1);
/*  63 */   private static final BitField alignVer = bf(2);
/*  64 */   private static final BitField alignWrap = bf(4);
/*  65 */   private static final BitField alignRot = bf(8);
/*  66 */   private static final BitField alignJustLast = bf(16);
/*  67 */   private static final BitField alignIndent = bf(32);
/*  68 */   private static final BitField alignShrin = bf(64);
/*  69 */   private static final BitField notUsed1 = bf(128);
/*  70 */   private static final BitField protLocked = bf(256);
/*  71 */   private static final BitField protHidden = bf(512);
/*  72 */   private static final BitField bordLeft = bf(1024);
/*  73 */   private static final BitField bordRight = bf(2048);
/*  74 */   private static final BitField bordTop = bf(4096);
/*  75 */   private static final BitField bordBot = bf(8192);
/*  76 */   private static final BitField bordTlBr = bf(16384);
/*  77 */   private static final BitField bordBlTr = bf(32768);
/*  78 */   private static final BitField pattStyle = bf(65536);
/*  79 */   private static final BitField pattCol = bf(131072);
/*  80 */   private static final BitField pattBgCol = bf(262144);
/*  81 */   private static final BitField notUsed2 = bf(3670016);
/*  82 */   private static final BitField undocumented = bf(62914560);
/*  83 */   private static final BitField fmtBlockBits = bf(2080374784);
/*  84 */   private static final BitField font = bf(67108864);
/*  85 */   private static final BitField align = bf(134217728);
/*  86 */   private static final BitField bord = bf(268435456);
/*  87 */   private static final BitField patt = bf(536870912);
/*  88 */   private static final BitField prot = bf(1073741824);
/*  89 */   private static final BitField alignTextDir = bf(Integer.MIN_VALUE);
/*     */   private short field_6_not_used;
/*     */   
/*     */   private static BitField bf(int i) {
/*  93 */     return BitFieldFactory.getInstance(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private FontFormatting _fontFormatting;
/*     */   
/*     */   private BorderFormatting _borderFormatting;
/*     */   
/*     */   private PatternFormatting _patternFormatting;
/*     */   
/*     */   private Formula field_17_formula1;
/*     */   
/*     */   private Formula field_18_formula2;
/*     */   
/*     */   private CFRuleRecord(byte conditionType, byte comparisonOperation)
/*     */   {
/* 110 */     this.field_1_condition_type = conditionType;
/* 111 */     this.field_2_comparison_operator = comparisonOperation;
/*     */     
/*     */ 
/* 114 */     this.field_5_options = modificationBits.setValue(this.field_5_options, -1);
/*     */     
/* 116 */     this.field_5_options = fmtBlockBits.setValue(this.field_5_options, 0);
/* 117 */     this.field_5_options = undocumented.clear(this.field_5_options);
/*     */     
/* 119 */     this.field_6_not_used = 32770;
/* 120 */     this._fontFormatting = null;
/* 121 */     this._borderFormatting = null;
/* 122 */     this._patternFormatting = null;
/* 123 */     this.field_17_formula1 = Formula.create(Ptg.EMPTY_PTG_ARRAY);
/* 124 */     this.field_18_formula2 = Formula.create(Ptg.EMPTY_PTG_ARRAY);
/*     */   }
/*     */   
/*     */   private CFRuleRecord(byte conditionType, byte comparisonOperation, Ptg[] formula1, Ptg[] formula2) {
/* 128 */     this(conditionType, comparisonOperation);
/* 129 */     this.field_17_formula1 = Formula.create(formula1);
/* 130 */     this.field_18_formula2 = Formula.create(formula2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static CFRuleRecord create(HSSFSheet sheet, String formulaText)
/*     */   {
/* 137 */     Ptg[] formula1 = parseFormula(formulaText, sheet);
/* 138 */     return new CFRuleRecord((byte)2, (byte)0, formula1, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CFRuleRecord create(HSSFSheet sheet, byte comparisonOperation, String formulaText1, String formulaText2)
/*     */   {
/* 146 */     Ptg[] formula1 = parseFormula(formulaText1, sheet);
/* 147 */     Ptg[] formula2 = parseFormula(formulaText2, sheet);
/* 148 */     return new CFRuleRecord((byte)1, comparisonOperation, formula1, formula2);
/*     */   }
/*     */   
/*     */   public CFRuleRecord(RecordInputStream in) {
/* 152 */     this.field_1_condition_type = in.readByte();
/* 153 */     this.field_2_comparison_operator = in.readByte();
/* 154 */     int field_3_formula1_len = in.readUShort();
/* 155 */     int field_4_formula2_len = in.readUShort();
/* 156 */     this.field_5_options = in.readInt();
/* 157 */     this.field_6_not_used = in.readShort();
/*     */     
/* 159 */     if (containsFontFormattingBlock()) {
/* 160 */       this._fontFormatting = new FontFormatting(in);
/*     */     }
/*     */     
/* 163 */     if (containsBorderFormattingBlock()) {
/* 164 */       this._borderFormatting = new BorderFormatting(in);
/*     */     }
/*     */     
/* 167 */     if (containsPatternFormattingBlock()) {
/* 168 */       this._patternFormatting = new PatternFormatting(in);
/*     */     }
/*     */     
/*     */ 
/* 172 */     this.field_17_formula1 = Formula.read(field_3_formula1_len, in);
/* 173 */     this.field_18_formula2 = Formula.read(field_4_formula2_len, in);
/*     */   }
/*     */   
/*     */   public byte getConditionType()
/*     */   {
/* 178 */     return this.field_1_condition_type;
/*     */   }
/*     */   
/*     */   public boolean containsFontFormattingBlock()
/*     */   {
/* 183 */     return getOptionFlag(font);
/*     */   }
/*     */   
/*     */   public void setFontFormatting(FontFormatting fontFormatting) {
/* 187 */     this._fontFormatting = fontFormatting;
/* 188 */     setOptionFlag(fontFormatting != null, font);
/*     */   }
/*     */   
/*     */   public FontFormatting getFontFormatting() {
/* 192 */     if (containsFontFormattingBlock())
/*     */     {
/* 194 */       return this._fontFormatting;
/*     */     }
/* 196 */     return null;
/*     */   }
/*     */   
/*     */   public boolean containsAlignFormattingBlock()
/*     */   {
/* 201 */     return getOptionFlag(align);
/*     */   }
/*     */   
/*     */   public void setAlignFormattingUnchanged() {
/* 205 */     setOptionFlag(false, align);
/*     */   }
/*     */   
/*     */   public boolean containsBorderFormattingBlock()
/*     */   {
/* 210 */     return getOptionFlag(bord);
/*     */   }
/*     */   
/*     */   public void setBorderFormatting(BorderFormatting borderFormatting) {
/* 214 */     this._borderFormatting = borderFormatting;
/* 215 */     setOptionFlag(borderFormatting != null, bord);
/*     */   }
/*     */   
/*     */   public BorderFormatting getBorderFormatting() {
/* 219 */     if (containsBorderFormattingBlock())
/*     */     {
/* 221 */       return this._borderFormatting;
/*     */     }
/* 223 */     return null;
/*     */   }
/*     */   
/*     */   public boolean containsPatternFormattingBlock()
/*     */   {
/* 228 */     return getOptionFlag(patt);
/*     */   }
/*     */   
/*     */   public void setPatternFormatting(PatternFormatting patternFormatting) {
/* 232 */     this._patternFormatting = patternFormatting;
/* 233 */     setOptionFlag(patternFormatting != null, patt);
/*     */   }
/*     */   
/*     */   public PatternFormatting getPatternFormatting() {
/* 237 */     if (containsPatternFormattingBlock())
/*     */     {
/* 239 */       return this._patternFormatting;
/*     */     }
/* 241 */     return null;
/*     */   }
/*     */   
/*     */   public boolean containsProtectionFormattingBlock()
/*     */   {
/* 246 */     return getOptionFlag(prot);
/*     */   }
/*     */   
/*     */   public void setProtectionFormattingUnchanged() {
/* 250 */     setOptionFlag(false, prot);
/*     */   }
/*     */   
/*     */   public void setComparisonOperation(byte operation)
/*     */   {
/* 255 */     this.field_2_comparison_operator = operation;
/*     */   }
/*     */   
/*     */   public byte getComparisonOperation()
/*     */   {
/* 260 */     return this.field_2_comparison_operator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOptions()
/*     */   {
/* 271 */     return this.field_5_options;
/*     */   }
/*     */   
/*     */   private boolean isModified(BitField field)
/*     */   {
/* 276 */     return !field.isSet(this.field_5_options);
/*     */   }
/*     */   
/*     */   private void setModified(boolean modified, BitField field)
/*     */   {
/* 281 */     this.field_5_options = field.setBoolean(this.field_5_options, !modified);
/*     */   }
/*     */   
/*     */   public boolean isLeftBorderModified()
/*     */   {
/* 286 */     return isModified(bordLeft);
/*     */   }
/*     */   
/*     */   public void setLeftBorderModified(boolean modified)
/*     */   {
/* 291 */     setModified(modified, bordLeft);
/*     */   }
/*     */   
/*     */   public boolean isRightBorderModified()
/*     */   {
/* 296 */     return isModified(bordRight);
/*     */   }
/*     */   
/*     */   public void setRightBorderModified(boolean modified)
/*     */   {
/* 301 */     setModified(modified, bordRight);
/*     */   }
/*     */   
/*     */   public boolean isTopBorderModified()
/*     */   {
/* 306 */     return isModified(bordTop);
/*     */   }
/*     */   
/*     */   public void setTopBorderModified(boolean modified)
/*     */   {
/* 311 */     setModified(modified, bordTop);
/*     */   }
/*     */   
/*     */   public boolean isBottomBorderModified()
/*     */   {
/* 316 */     return isModified(bordBot);
/*     */   }
/*     */   
/*     */   public void setBottomBorderModified(boolean modified)
/*     */   {
/* 321 */     setModified(modified, bordBot);
/*     */   }
/*     */   
/*     */   public boolean isTopLeftBottomRightBorderModified()
/*     */   {
/* 326 */     return isModified(bordTlBr);
/*     */   }
/*     */   
/*     */   public void setTopLeftBottomRightBorderModified(boolean modified)
/*     */   {
/* 331 */     setModified(modified, bordTlBr);
/*     */   }
/*     */   
/*     */   public boolean isBottomLeftTopRightBorderModified()
/*     */   {
/* 336 */     return isModified(bordBlTr);
/*     */   }
/*     */   
/*     */   public void setBottomLeftTopRightBorderModified(boolean modified)
/*     */   {
/* 341 */     setModified(modified, bordBlTr);
/*     */   }
/*     */   
/*     */   public boolean isPatternStyleModified()
/*     */   {
/* 346 */     return isModified(pattStyle);
/*     */   }
/*     */   
/*     */   public void setPatternStyleModified(boolean modified)
/*     */   {
/* 351 */     setModified(modified, pattStyle);
/*     */   }
/*     */   
/*     */   public boolean isPatternColorModified()
/*     */   {
/* 356 */     return isModified(pattCol);
/*     */   }
/*     */   
/*     */   public void setPatternColorModified(boolean modified)
/*     */   {
/* 361 */     setModified(modified, pattCol);
/*     */   }
/*     */   
/*     */   public boolean isPatternBackgroundColorModified()
/*     */   {
/* 366 */     return isModified(pattBgCol);
/*     */   }
/*     */   
/*     */   public void setPatternBackgroundColorModified(boolean modified)
/*     */   {
/* 371 */     setModified(modified, pattBgCol);
/*     */   }
/*     */   
/*     */   private boolean getOptionFlag(BitField field)
/*     */   {
/* 376 */     return field.isSet(this.field_5_options);
/*     */   }
/*     */   
/*     */   private void setOptionFlag(boolean flag, BitField field)
/*     */   {
/* 381 */     this.field_5_options = field.setBoolean(this.field_5_options, flag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ptg[] getParsedExpression1()
/*     */   {
/* 395 */     return this.field_17_formula1.getTokens();
/*     */   }
/*     */   
/* 398 */   public void setParsedExpression1(Ptg[] ptgs) { this.field_17_formula1 = Formula.create(ptgs); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ptg[] getParsedExpression2()
/*     */   {
/* 407 */     return Formula.getTokens(this.field_18_formula2);
/*     */   }
/*     */   
/* 410 */   public void setParsedExpression2(Ptg[] ptgs) { this.field_18_formula2 = Formula.create(ptgs); }
/*     */   
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 415 */     return 433;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int getFormulaSize(Formula formula)
/*     */   {
/* 423 */     return formula.getEncodedTokenSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 435 */     int formula1Len = getFormulaSize(this.field_17_formula1);
/* 436 */     int formula2Len = getFormulaSize(this.field_18_formula2);
/*     */     
/* 438 */     out.writeByte(this.field_1_condition_type);
/* 439 */     out.writeByte(this.field_2_comparison_operator);
/* 440 */     out.writeShort(formula1Len);
/* 441 */     out.writeShort(formula2Len);
/* 442 */     out.writeInt(this.field_5_options);
/* 443 */     out.writeShort(this.field_6_not_used);
/*     */     
/* 445 */     if (containsFontFormattingBlock()) {
/* 446 */       byte[] fontFormattingRawRecord = this._fontFormatting.getRawRecord();
/* 447 */       out.write(fontFormattingRawRecord);
/*     */     }
/*     */     
/* 450 */     if (containsBorderFormattingBlock()) {
/* 451 */       this._borderFormatting.serialize(out);
/*     */     }
/*     */     
/* 454 */     if (containsPatternFormattingBlock()) {
/* 455 */       this._patternFormatting.serialize(out);
/*     */     }
/*     */     
/* 458 */     this.field_17_formula1.serializeTokens(out);
/* 459 */     this.field_18_formula2.serializeTokens(out);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 463 */     return 12 + (containsFontFormattingBlock() ? this._fontFormatting.getRawRecord().length : 0) + (containsBorderFormattingBlock() ? 8 : 0) + (containsPatternFormattingBlock() ? 4 : 0) + getFormulaSize(this.field_17_formula1) + getFormulaSize(this.field_18_formula2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 474 */     StringBuffer buffer = new StringBuffer();
/* 475 */     buffer.append("[CFRULE]\n");
/* 476 */     buffer.append("    .condition_type   =" + this.field_1_condition_type);
/* 477 */     buffer.append("    OPTION FLAGS=0x" + Integer.toHexString(getOptions()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 490 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 494 */     CFRuleRecord rec = new CFRuleRecord(this.field_1_condition_type, this.field_2_comparison_operator);
/* 495 */     rec.field_5_options = this.field_5_options;
/* 496 */     rec.field_6_not_used = this.field_6_not_used;
/* 497 */     if (containsFontFormattingBlock()) {
/* 498 */       rec._fontFormatting = ((FontFormatting)this._fontFormatting.clone());
/*     */     }
/* 500 */     if (containsBorderFormattingBlock()) {
/* 501 */       rec._borderFormatting = ((BorderFormatting)this._borderFormatting.clone());
/*     */     }
/* 503 */     if (containsPatternFormattingBlock()) {
/* 504 */       rec._patternFormatting = ((PatternFormatting)this._patternFormatting.clone());
/*     */     }
/* 506 */     rec.field_17_formula1 = this.field_17_formula1.copy();
/* 507 */     rec.field_18_formula2 = this.field_17_formula1.copy();
/*     */     
/* 509 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Ptg[] parseFormula(String formula, HSSFSheet sheet)
/*     */   {
/* 521 */     if (formula == null) {
/* 522 */       return null;
/*     */     }
/* 524 */     int sheetIndex = sheet.getWorkbook().getSheetIndex(sheet);
/* 525 */     return HSSFFormulaParser.parse(formula, sheet.getWorkbook(), 0, sheetIndex);
/*     */   }
/*     */   
/*     */   public static final class ComparisonOperator
/*     */   {
/*     */     public static final byte NO_COMPARISON = 0;
/*     */     public static final byte BETWEEN = 1;
/*     */     public static final byte NOT_BETWEEN = 2;
/*     */     public static final byte EQUAL = 3;
/*     */     public static final byte NOT_EQUAL = 4;
/*     */     public static final byte GT = 5;
/*     */     public static final byte LT = 6;
/*     */     public static final byte GE = 7;
/*     */     public static final byte LE = 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CFRuleRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */