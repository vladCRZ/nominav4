/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CalcCountRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 12;
/*     */   private short field_1_iterations;
/*     */   
/*     */   public CalcCountRecord() {}
/*     */   
/*     */   public CalcCountRecord(RecordInputStream in)
/*     */   {
/*  50 */     this.field_1_iterations = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIterations(short iterations)
/*     */   {
/*  60 */     this.field_1_iterations = iterations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getIterations()
/*     */   {
/*  70 */     return this.field_1_iterations;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  75 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  77 */     buffer.append("[CALCCOUNT]\n");
/*  78 */     buffer.append("    .iterations     = ").append(Integer.toHexString(getIterations())).append("\n");
/*     */     
/*  80 */     buffer.append("[/CALCCOUNT]\n");
/*  81 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  85 */     out.writeShort(getIterations());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  89 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  94 */     return 12;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  98 */     CalcCountRecord rec = new CalcCountRecord();
/*  99 */     rec.field_1_iterations = this.field_1_iterations;
/* 100 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CalcCountRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */