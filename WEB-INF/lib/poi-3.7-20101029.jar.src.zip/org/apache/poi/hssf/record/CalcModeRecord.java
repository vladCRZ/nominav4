/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CalcModeRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 13;
/*     */   public static final short MANUAL = 0;
/*     */   public static final short AUTOMATIC = 1;
/*     */   public static final short AUTOMATIC_EXCEPT_TABLES = -1;
/*     */   private short field_1_calcmode;
/*     */   
/*     */   public CalcModeRecord() {}
/*     */   
/*     */   public CalcModeRecord(RecordInputStream in)
/*     */   {
/*  66 */     this.field_1_calcmode = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCalcMode(short calcmode)
/*     */   {
/*  81 */     this.field_1_calcmode = calcmode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCalcMode()
/*     */   {
/*  96 */     return this.field_1_calcmode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 101 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 103 */     buffer.append("[CALCMODE]\n");
/* 104 */     buffer.append("    .calcmode       = ").append(Integer.toHexString(getCalcMode())).append("\n");
/*     */     
/* 106 */     buffer.append("[/CALCMODE]\n");
/* 107 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 111 */     out.writeShort(getCalcMode());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 115 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 120 */     return 13;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 124 */     CalcModeRecord rec = new CalcModeRecord();
/* 125 */     rec.field_1_calcmode = this.field_1_calcmode;
/* 126 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CalcModeRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */