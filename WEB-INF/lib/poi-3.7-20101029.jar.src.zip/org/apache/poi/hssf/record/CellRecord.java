/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CellRecord
/*     */   extends StandardRecord
/*     */   implements CellValueRecordInterface
/*     */ {
/*     */   private int _rowIndex;
/*     */   private int _columnIndex;
/*     */   private int _formatIndex;
/*     */   
/*     */   protected CellRecord() {}
/*     */   
/*     */   protected CellRecord(RecordInputStream in)
/*     */   {
/*  39 */     this._rowIndex = in.readUShort();
/*  40 */     this._columnIndex = in.readUShort();
/*  41 */     this._formatIndex = in.readUShort();
/*     */   }
/*     */   
/*     */   public final void setRow(int row) {
/*  45 */     this._rowIndex = row;
/*     */   }
/*     */   
/*     */   public final void setColumn(short col) {
/*  49 */     this._columnIndex = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setXFIndex(short xf)
/*     */   {
/*  59 */     this._formatIndex = xf;
/*     */   }
/*     */   
/*     */   public final int getRow() {
/*  63 */     return this._rowIndex;
/*     */   }
/*     */   
/*     */   public final short getColumn() {
/*  67 */     return (short)this._columnIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final short getXFIndex()
/*     */   {
/*  77 */     return (short)this._formatIndex;
/*     */   }
/*     */   
/*     */   public final String toString() {
/*  81 */     StringBuilder sb = new StringBuilder();
/*  82 */     String recordName = getRecordName();
/*     */     
/*  84 */     sb.append("[").append(recordName).append("]\n");
/*  85 */     sb.append("    .row    = ").append(HexDump.shortToHex(getRow())).append("\n");
/*  86 */     sb.append("    .col    = ").append(HexDump.shortToHex(getColumn())).append("\n");
/*  87 */     sb.append("    .xfindex= ").append(HexDump.shortToHex(getXFIndex())).append("\n");
/*  88 */     appendValueText(sb);
/*  89 */     sb.append("\n");
/*  90 */     sb.append("[/").append(recordName).append("]\n");
/*  91 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void appendValueText(StringBuilder paramStringBuilder);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String getRecordName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void serializeValue(LittleEndianOutput paramLittleEndianOutput);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract int getValueDataSize();
/*     */   
/*     */ 
/*     */ 
/*     */   public final void serialize(LittleEndianOutput out)
/*     */   {
/* 117 */     out.writeShort(getRow());
/* 118 */     out.writeShort(getColumn());
/* 119 */     out.writeShort(getXFIndex());
/* 120 */     serializeValue(out);
/*     */   }
/*     */   
/*     */   protected final int getDataSize() {
/* 124 */     return 6 + getValueDataSize();
/*     */   }
/*     */   
/*     */   protected final void copyBaseFields(CellRecord rec) {
/* 128 */     rec._rowIndex = this._rowIndex;
/* 129 */     rec._columnIndex = this._columnIndex;
/* 130 */     rec._formatIndex = this._formatIndex;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CellRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */