/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ColumnInfoRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 125;
/*     */   private int _firstCol;
/*     */   private int _lastCol;
/*     */   private int _colWidth;
/*     */   private int _xfIndex;
/*     */   private int _options;
/*  39 */   private static final BitField hidden = BitFieldFactory.getInstance(1);
/*  40 */   private static final BitField outlevel = BitFieldFactory.getInstance(1792);
/*  41 */   private static final BitField collapsed = BitFieldFactory.getInstance(4096);
/*     */   
/*     */ 
/*     */   private int field_6_reserved;
/*     */   
/*     */ 
/*     */   public ColumnInfoRecord()
/*     */   {
/*  49 */     setColumnWidth(2275);
/*  50 */     this._options = 2;
/*  51 */     this._xfIndex = 15;
/*  52 */     this.field_6_reserved = 2;
/*     */   }
/*     */   
/*     */   public ColumnInfoRecord(RecordInputStream in) {
/*  56 */     this._firstCol = in.readUShort();
/*  57 */     this._lastCol = in.readUShort();
/*  58 */     this._colWidth = in.readUShort();
/*  59 */     this._xfIndex = in.readUShort();
/*  60 */     this._options = in.readUShort();
/*  61 */     switch (in.remaining()) {
/*     */     case 2: 
/*  63 */       this.field_6_reserved = in.readUShort();
/*  64 */       break;
/*     */     
/*     */ 
/*     */     case 1: 
/*  68 */       this.field_6_reserved = in.readByte();
/*  69 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 0: 
/*  74 */       this.field_6_reserved = 0;
/*  75 */       break;
/*     */     default: 
/*  77 */       throw new RuntimeException("Unusual record size remaining=(" + in.remaining() + ")");
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFirstColumn(int fc)
/*     */   {
/*  86 */     this._firstCol = fc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastColumn(int lc)
/*     */   {
/*  94 */     this._lastCol = lc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnWidth(int cw)
/*     */   {
/* 102 */     this._colWidth = cw;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXFIndex(int xfi)
/*     */   {
/* 111 */     this._xfIndex = xfi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHidden(boolean ishidden)
/*     */   {
/* 119 */     this._options = hidden.setBoolean(this._options, ishidden);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutlineLevel(int olevel)
/*     */   {
/* 127 */     this._options = outlevel.setValue(this._options, olevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCollapsed(boolean isCollapsed)
/*     */   {
/* 135 */     this._options = collapsed.setBoolean(this._options, isCollapsed);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstColumn()
/*     */   {
/* 143 */     return this._firstCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastColumn()
/*     */   {
/* 151 */     return this._lastCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColumnWidth()
/*     */   {
/* 158 */     return this._colWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXFIndex()
/*     */   {
/* 167 */     return this._xfIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getHidden()
/*     */   {
/* 174 */     return hidden.isSet(this._options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getOutlineLevel()
/*     */   {
/* 181 */     return outlevel.getValue(this._options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getCollapsed()
/*     */   {
/* 188 */     return collapsed.isSet(this._options);
/*     */   }
/*     */   
/*     */   public boolean containsColumn(int columnIndex) {
/* 192 */     return (this._firstCol <= columnIndex) && (columnIndex <= this._lastCol);
/*     */   }
/*     */   
/* 195 */   public boolean isAdjacentBefore(ColumnInfoRecord other) { return this._lastCol == other._firstCol - 1; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean formatMatches(ColumnInfoRecord other)
/*     */   {
/* 202 */     if (this._xfIndex != other._xfIndex) {
/* 203 */       return false;
/*     */     }
/* 205 */     if (this._options != other._options) {
/* 206 */       return false;
/*     */     }
/* 208 */     if (this._colWidth != other._colWidth) {
/* 209 */       return false;
/*     */     }
/* 211 */     return true;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 215 */     return 125;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 219 */     out.writeShort(getFirstColumn());
/* 220 */     out.writeShort(getLastColumn());
/* 221 */     out.writeShort(getColumnWidth());
/* 222 */     out.writeShort(getXFIndex());
/* 223 */     out.writeShort(this._options);
/* 224 */     out.writeShort(this.field_6_reserved);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 228 */     return 12;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 232 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 234 */     sb.append("[COLINFO]\n");
/* 235 */     sb.append("  colfirst = ").append(getFirstColumn()).append("\n");
/* 236 */     sb.append("  collast  = ").append(getLastColumn()).append("\n");
/* 237 */     sb.append("  colwidth = ").append(getColumnWidth()).append("\n");
/* 238 */     sb.append("  xfindex  = ").append(getXFIndex()).append("\n");
/* 239 */     sb.append("  options  = ").append(HexDump.shortToHex(this._options)).append("\n");
/* 240 */     sb.append("    hidden   = ").append(getHidden()).append("\n");
/* 241 */     sb.append("    olevel   = ").append(getOutlineLevel()).append("\n");
/* 242 */     sb.append("    collapsed= ").append(getCollapsed()).append("\n");
/* 243 */     sb.append("[/COLINFO]\n");
/* 244 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 248 */     ColumnInfoRecord rec = new ColumnInfoRecord();
/* 249 */     rec._firstCol = this._firstCol;
/* 250 */     rec._lastCol = this._lastCol;
/* 251 */     rec._colWidth = this._colWidth;
/* 252 */     rec._xfIndex = this._xfIndex;
/* 253 */     rec._options = this._options;
/* 254 */     rec.field_6_reserved = this.field_6_reserved;
/* 255 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ColumnInfoRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */