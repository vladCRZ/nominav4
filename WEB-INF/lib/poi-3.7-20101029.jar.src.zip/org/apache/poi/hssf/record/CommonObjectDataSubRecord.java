/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CommonObjectDataSubRecord
/*     */   extends SubRecord
/*     */ {
/*     */   public static final short sid = 21;
/*  34 */   private static final BitField locked = BitFieldFactory.getInstance(1);
/*  35 */   private static final BitField printable = BitFieldFactory.getInstance(16);
/*  36 */   private static final BitField autofill = BitFieldFactory.getInstance(8192);
/*  37 */   private static final BitField autoline = BitFieldFactory.getInstance(16384);
/*     */   
/*     */   public static final short OBJECT_TYPE_GROUP = 0;
/*     */   
/*     */   public static final short OBJECT_TYPE_LINE = 1;
/*     */   
/*     */   public static final short OBJECT_TYPE_RECTANGLE = 2;
/*     */   
/*     */   public static final short OBJECT_TYPE_OVAL = 3;
/*     */   
/*     */   public static final short OBJECT_TYPE_ARC = 4;
/*     */   public static final short OBJECT_TYPE_CHART = 5;
/*     */   public static final short OBJECT_TYPE_TEXT = 6;
/*     */   public static final short OBJECT_TYPE_BUTTON = 7;
/*     */   public static final short OBJECT_TYPE_PICTURE = 8;
/*     */   public static final short OBJECT_TYPE_POLYGON = 9;
/*     */   public static final short OBJECT_TYPE_RESERVED1 = 10;
/*     */   public static final short OBJECT_TYPE_CHECKBOX = 11;
/*     */   public static final short OBJECT_TYPE_OPTION_BUTTON = 12;
/*     */   public static final short OBJECT_TYPE_EDIT_BOX = 13;
/*     */   public static final short OBJECT_TYPE_LABEL = 14;
/*     */   public static final short OBJECT_TYPE_DIALOG_BOX = 15;
/*     */   public static final short OBJECT_TYPE_SPINNER = 16;
/*     */   public static final short OBJECT_TYPE_SCROLL_BAR = 17;
/*     */   public static final short OBJECT_TYPE_LIST_BOX = 18;
/*     */   public static final short OBJECT_TYPE_GROUP_BOX = 19;
/*     */   public static final short OBJECT_TYPE_COMBO_BOX = 20;
/*     */   public static final short OBJECT_TYPE_RESERVED2 = 21;
/*     */   public static final short OBJECT_TYPE_RESERVED3 = 22;
/*     */   public static final short OBJECT_TYPE_RESERVED4 = 23;
/*     */   public static final short OBJECT_TYPE_RESERVED5 = 24;
/*     */   public static final short OBJECT_TYPE_COMMENT = 25;
/*     */   public static final short OBJECT_TYPE_RESERVED6 = 26;
/*     */   public static final short OBJECT_TYPE_RESERVED7 = 27;
/*     */   public static final short OBJECT_TYPE_RESERVED8 = 28;
/*     */   public static final short OBJECT_TYPE_RESERVED9 = 29;
/*     */   public static final short OBJECT_TYPE_MICROSOFT_OFFICE_DRAWING = 30;
/*     */   private short field_1_objectType;
/*     */   private int field_2_objectId;
/*     */   private short field_3_option;
/*     */   private int field_4_reserved1;
/*     */   private int field_5_reserved2;
/*     */   private int field_6_reserved3;
/*     */   
/*     */   public CommonObjectDataSubRecord() {}
/*     */   
/*     */   public CommonObjectDataSubRecord(LittleEndianInput in, int size)
/*     */   {
/*  85 */     if (size != 18) {
/*  86 */       throw new RecordFormatException("Expected size 18 but got (" + size + ")");
/*     */     }
/*  88 */     this.field_1_objectType = in.readShort();
/*  89 */     this.field_2_objectId = in.readUShort();
/*  90 */     this.field_3_option = in.readShort();
/*  91 */     this.field_4_reserved1 = in.readInt();
/*  92 */     this.field_5_reserved2 = in.readInt();
/*  93 */     this.field_6_reserved3 = in.readInt();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  98 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 100 */     buffer.append("[ftCmo]\n");
/* 101 */     buffer.append("    .objectType           = ").append("0x").append(HexDump.toHex(getObjectType())).append(" (").append(getObjectType()).append(" )");
/*     */     
/*     */ 
/* 104 */     buffer.append(System.getProperty("line.separator"));
/* 105 */     buffer.append("    .objectId             = ").append("0x").append(HexDump.toHex(getObjectId())).append(" (").append(getObjectId()).append(" )");
/*     */     
/*     */ 
/* 108 */     buffer.append(System.getProperty("line.separator"));
/* 109 */     buffer.append("    .option               = ").append("0x").append(HexDump.toHex(getOption())).append(" (").append(getOption()).append(" )");
/*     */     
/*     */ 
/* 112 */     buffer.append(System.getProperty("line.separator"));
/* 113 */     buffer.append("         .locked                   = ").append(isLocked()).append('\n');
/* 114 */     buffer.append("         .printable                = ").append(isPrintable()).append('\n');
/* 115 */     buffer.append("         .autofill                 = ").append(isAutofill()).append('\n');
/* 116 */     buffer.append("         .autoline                 = ").append(isAutoline()).append('\n');
/* 117 */     buffer.append("    .reserved1            = ").append("0x").append(HexDump.toHex(getReserved1())).append(" (").append(getReserved1()).append(" )");
/*     */     
/*     */ 
/* 120 */     buffer.append(System.getProperty("line.separator"));
/* 121 */     buffer.append("    .reserved2            = ").append("0x").append(HexDump.toHex(getReserved2())).append(" (").append(getReserved2()).append(" )");
/*     */     
/*     */ 
/* 124 */     buffer.append(System.getProperty("line.separator"));
/* 125 */     buffer.append("    .reserved3            = ").append("0x").append(HexDump.toHex(getReserved3())).append(" (").append(getReserved3()).append(" )");
/*     */     
/*     */ 
/* 128 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/* 130 */     buffer.append("[/ftCmo]\n");
/* 131 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 136 */     out.writeShort(21);
/* 137 */     out.writeShort(getDataSize());
/*     */     
/* 139 */     out.writeShort(this.field_1_objectType);
/* 140 */     out.writeShort(this.field_2_objectId);
/* 141 */     out.writeShort(this.field_3_option);
/* 142 */     out.writeInt(this.field_4_reserved1);
/* 143 */     out.writeInt(this.field_5_reserved2);
/* 144 */     out.writeInt(this.field_6_reserved3);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 148 */     return 18;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 153 */     return 21;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 157 */     CommonObjectDataSubRecord rec = new CommonObjectDataSubRecord();
/*     */     
/* 159 */     rec.field_1_objectType = this.field_1_objectType;
/* 160 */     rec.field_2_objectId = this.field_2_objectId;
/* 161 */     rec.field_3_option = this.field_3_option;
/* 162 */     rec.field_4_reserved1 = this.field_4_reserved1;
/* 163 */     rec.field_5_reserved2 = this.field_5_reserved2;
/* 164 */     rec.field_6_reserved3 = this.field_6_reserved3;
/* 165 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getObjectType()
/*     */   {
/* 207 */     return this.field_1_objectType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectType(short field_1_objectType)
/*     */   {
/* 249 */     this.field_1_objectType = field_1_objectType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getObjectId()
/*     */   {
/* 257 */     return this.field_2_objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectId(int field_2_objectId)
/*     */   {
/* 265 */     this.field_2_objectId = field_2_objectId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOption()
/*     */   {
/* 273 */     return this.field_3_option;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOption(short field_3_option)
/*     */   {
/* 281 */     this.field_3_option = field_3_option;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReserved1()
/*     */   {
/* 289 */     return this.field_4_reserved1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReserved1(int field_4_reserved1)
/*     */   {
/* 297 */     this.field_4_reserved1 = field_4_reserved1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReserved2()
/*     */   {
/* 305 */     return this.field_5_reserved2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReserved2(int field_5_reserved2)
/*     */   {
/* 313 */     this.field_5_reserved2 = field_5_reserved2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReserved3()
/*     */   {
/* 321 */     return this.field_6_reserved3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReserved3(int field_6_reserved3)
/*     */   {
/* 329 */     this.field_6_reserved3 = field_6_reserved3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocked(boolean value)
/*     */   {
/* 338 */     this.field_3_option = locked.setShortBoolean(this.field_3_option, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLocked()
/*     */   {
/* 347 */     return locked.isSet(this.field_3_option);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrintable(boolean value)
/*     */   {
/* 356 */     this.field_3_option = printable.setShortBoolean(this.field_3_option, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrintable()
/*     */   {
/* 365 */     return printable.isSet(this.field_3_option);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutofill(boolean value)
/*     */   {
/* 374 */     this.field_3_option = autofill.setShortBoolean(this.field_3_option, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutofill()
/*     */   {
/* 383 */     return autofill.isSet(this.field_3_option);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoline(boolean value)
/*     */   {
/* 392 */     this.field_3_option = autoline.setShortBoolean(this.field_3_option, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoline()
/*     */   {
/* 401 */     return autoline.isSet(this.field_3_option);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CommonObjectDataSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */