/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CountryRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 140;
/*     */   private short field_1_default_country;
/*     */   private short field_2_current_country;
/*     */   
/*     */   public CountryRecord() {}
/*     */   
/*     */   public CountryRecord(RecordInputStream in)
/*     */   {
/*  49 */     this.field_1_default_country = in.readShort();
/*  50 */     this.field_2_current_country = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultCountry(short country)
/*     */   {
/*  61 */     this.field_1_default_country = country;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentCountry(short country)
/*     */   {
/*  72 */     this.field_2_current_country = country;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDefaultCountry()
/*     */   {
/*  83 */     return this.field_1_default_country;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCurrentCountry()
/*     */   {
/*  94 */     return this.field_2_current_country;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  99 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 101 */     buffer.append("[COUNTRY]\n");
/* 102 */     buffer.append("    .defaultcountry  = ").append(Integer.toHexString(getDefaultCountry())).append("\n");
/*     */     
/* 104 */     buffer.append("    .currentcountry  = ").append(Integer.toHexString(getCurrentCountry())).append("\n");
/*     */     
/* 106 */     buffer.append("[/COUNTRY]\n");
/* 107 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 111 */     out.writeShort(getDefaultCountry());
/* 112 */     out.writeShort(getCurrentCountry());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 116 */     return 4;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 121 */     return 140;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\CountryRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */