/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DBCellRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 215;
/*     */   public static final int BLOCK_SIZE = 32;
/*     */   private final int field_1_row_offset;
/*     */   private final short[] field_2_cell_offsets;
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private short[] _cellOffsets;
/*     */     private int _nCellOffsets;
/*     */     
/*     */     public Builder()
/*     */     {
/*  38 */       this._cellOffsets = new short[4];
/*     */     }
/*     */     
/*     */     public void addCellOffset(int cellRefOffset) {
/*  42 */       if (this._cellOffsets.length <= this._nCellOffsets) {
/*  43 */         short[] temp = new short[this._nCellOffsets * 2];
/*  44 */         System.arraycopy(this._cellOffsets, 0, temp, 0, this._nCellOffsets);
/*  45 */         this._cellOffsets = temp;
/*     */       }
/*  47 */       this._cellOffsets[this._nCellOffsets] = ((short)cellRefOffset);
/*  48 */       this._nCellOffsets += 1;
/*     */     }
/*     */     
/*     */     public DBCellRecord build(int rowOffset) {
/*  52 */       short[] cellOffsets = new short[this._nCellOffsets];
/*  53 */       System.arraycopy(this._cellOffsets, 0, cellOffsets, 0, this._nCellOffsets);
/*  54 */       return new DBCellRecord(rowOffset, cellOffsets);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DBCellRecord(int rowOffset, short[] cellOffsets)
/*     */   {
/*  65 */     this.field_1_row_offset = rowOffset;
/*  66 */     this.field_2_cell_offsets = cellOffsets;
/*     */   }
/*     */   
/*     */   public DBCellRecord(RecordInputStream in) {
/*  70 */     this.field_1_row_offset = in.readUShort();
/*  71 */     int size = in.remaining();
/*  72 */     this.field_2_cell_offsets = new short[size / 2];
/*     */     
/*  74 */     for (int i = 0; i < this.field_2_cell_offsets.length; i++)
/*     */     {
/*  76 */       this.field_2_cell_offsets[i] = in.readShort();
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  82 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  84 */     buffer.append("[DBCELL]\n");
/*  85 */     buffer.append("    .rowoffset = ").append(HexDump.intToHex(this.field_1_row_offset)).append("\n");
/*  86 */     for (int k = 0; k < this.field_2_cell_offsets.length; k++) {
/*  87 */       buffer.append("    .cell_").append(k).append(" = ").append(HexDump.shortToHex(this.field_2_cell_offsets[k])).append("\n");
/*     */     }
/*     */     
/*  90 */     buffer.append("[/DBCELL]\n");
/*  91 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  95 */     out.writeInt(this.field_1_row_offset);
/*  96 */     for (int k = 0; k < this.field_2_cell_offsets.length; k++)
/*  97 */       out.writeShort(this.field_2_cell_offsets[k]);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 101 */     return 4 + this.field_2_cell_offsets.length * 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int calculateSizeOfRecords(int nBlocks, int nRows)
/*     */   {
/* 112 */     return nBlocks * 8 + nRows * 2;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 116 */     return 215;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 121 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DBCellRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */