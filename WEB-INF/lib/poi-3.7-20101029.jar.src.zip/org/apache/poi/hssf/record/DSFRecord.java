/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.BitField;
/*    */ import org.apache.poi.util.BitFieldFactory;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DSFRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 353;
/* 35 */   private static final BitField biff5BookStreamFlag = BitFieldFactory.getInstance(1);
/*    */   
/*    */   private int _options;
/*    */   
/*    */ 
/* 40 */   private DSFRecord(int options) { this._options = options; }
/*    */   
/*    */   public DSFRecord(boolean isBiff5BookStreamPresent) {
/* 43 */     this(0);
/* 44 */     this._options = biff5BookStreamFlag.setBoolean(0, isBiff5BookStreamPresent);
/*    */   }
/*    */   
/*    */   public DSFRecord(RecordInputStream in) {
/* 48 */     this(in.readShort());
/*    */   }
/*    */   
/*    */   public boolean isBiff5BookStreamPresent() {
/* 52 */     return biff5BookStreamFlag.isSet(this._options);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 56 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 58 */     buffer.append("[DSF]\n");
/* 59 */     buffer.append("    .options = ").append(HexDump.shortToHex(this._options)).append("\n");
/* 60 */     buffer.append("[/DSF]\n");
/* 61 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 65 */     out.writeShort(this._options);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 69 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 73 */     return 353;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DSFRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */