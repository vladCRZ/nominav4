/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DVALRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 434;
/*     */   private short field_1_options;
/*     */   private int field_2_horiz_pos;
/*     */   private int field_3_vert_pos;
/*     */   private int field_cbo_id;
/*     */   private int field_5_dv_no;
/*     */   
/*     */   public DVALRecord()
/*     */   {
/*  47 */     this.field_cbo_id = -1;
/*  48 */     this.field_5_dv_no = 0;
/*     */   }
/*     */   
/*     */   public DVALRecord(RecordInputStream in) {
/*  52 */     this.field_1_options = in.readShort();
/*  53 */     this.field_2_horiz_pos = in.readInt();
/*  54 */     this.field_3_vert_pos = in.readInt();
/*  55 */     this.field_cbo_id = in.readInt();
/*  56 */     this.field_5_dv_no = in.readInt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOptions(short options)
/*     */   {
/*  63 */     this.field_1_options = options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHorizontalPos(int horiz_pos)
/*     */   {
/*  70 */     this.field_2_horiz_pos = horiz_pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setVerticalPos(int vert_pos)
/*     */   {
/*  77 */     this.field_3_vert_pos = vert_pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectID(int cboID)
/*     */   {
/*  85 */     this.field_cbo_id = cboID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDVRecNo(int dvNo)
/*     */   {
/*  93 */     this.field_5_dv_no = dvNo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 100 */     return this.field_1_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getHorizontalPos()
/*     */   {
/* 107 */     return this.field_2_horiz_pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getVerticalPos()
/*     */   {
/* 114 */     return this.field_3_vert_pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getObjectID()
/*     */   {
/* 121 */     return this.field_cbo_id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getDVRecNo()
/*     */   {
/* 128 */     return this.field_5_dv_no;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 133 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 135 */     buffer.append("[DVAL]\n");
/* 136 */     buffer.append("    .options      = ").append(getOptions()).append('\n');
/* 137 */     buffer.append("    .horizPos     = ").append(getHorizontalPos()).append('\n');
/* 138 */     buffer.append("    .vertPos      = ").append(getVerticalPos()).append('\n');
/* 139 */     buffer.append("    .comboObjectID   = ").append(Integer.toHexString(getObjectID())).append("\n");
/* 140 */     buffer.append("    .DVRecordsNumber = ").append(Integer.toHexString(getDVRecNo())).append("\n");
/* 141 */     buffer.append("[/DVAL]\n");
/* 142 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 147 */     out.writeShort(getOptions());
/* 148 */     out.writeInt(getHorizontalPos());
/* 149 */     out.writeInt(getVerticalPos());
/* 150 */     out.writeInt(getObjectID());
/* 151 */     out.writeInt(getDVRecNo());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 155 */     return 18;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 159 */     return 434;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 163 */     DVALRecord rec = new DVALRecord();
/* 164 */     rec.field_1_options = this.field_1_options;
/* 165 */     rec.field_2_horiz_pos = this.field_2_horiz_pos;
/* 166 */     rec.field_3_vert_pos = this.field_3_vert_pos;
/* 167 */     rec.field_cbo_id = this.field_cbo_id;
/* 168 */     rec.field_5_dv_no = this.field_5_dv_no;
/* 169 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DVALRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */