/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.common.UnicodeString;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.ss.util.CellRangeAddressList;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DVRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 446;
/*  43 */   private static final UnicodeString NULL_TEXT_STRING = new UnicodeString("\000");
/*     */   
/*     */ 
/*     */   private int _option_flags;
/*     */   
/*     */   private UnicodeString _promptTitle;
/*     */   
/*     */   private UnicodeString _errorTitle;
/*     */   
/*     */   private UnicodeString _promptText;
/*     */   
/*     */   private UnicodeString _errorText;
/*     */   
/*  56 */   private short _not_used_1 = 16352;
/*     */   
/*     */   private Formula _formula1;
/*     */   
/*  60 */   private short _not_used_2 = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   private Formula _formula2;
/*     */   
/*     */ 
/*     */ 
/*     */   private CellRangeAddressList _regions;
/*     */   
/*     */ 
/*  71 */   private static final BitField opt_data_type = new BitField(15);
/*  72 */   private static final BitField opt_error_style = new BitField(112);
/*  73 */   private static final BitField opt_string_list_formula = new BitField(128);
/*  74 */   private static final BitField opt_empty_cell_allowed = new BitField(256);
/*  75 */   private static final BitField opt_suppress_dropdown_arrow = new BitField(512);
/*  76 */   private static final BitField opt_show_prompt_on_cell_selected = new BitField(262144);
/*  77 */   private static final BitField opt_show_error_on_invalid_value = new BitField(524288);
/*  78 */   private static final BitField opt_condition_operator = new BitField(7340032);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DVRecord(int validationType, int operator, int errorStyle, boolean emptyCellAllowed, boolean suppressDropDownArrow, boolean isExplicitList, boolean showPromptBox, String promptTitle, String promptText, boolean showErrorBox, String errorTitle, String errorText, Ptg[] formula1, Ptg[] formula2, CellRangeAddressList regions)
/*     */   {
/*  87 */     int flags = 0;
/*  88 */     flags = opt_data_type.setValue(flags, validationType);
/*  89 */     flags = opt_condition_operator.setValue(flags, operator);
/*  90 */     flags = opt_error_style.setValue(flags, errorStyle);
/*  91 */     flags = opt_empty_cell_allowed.setBoolean(flags, emptyCellAllowed);
/*  92 */     flags = opt_suppress_dropdown_arrow.setBoolean(flags, suppressDropDownArrow);
/*  93 */     flags = opt_string_list_formula.setBoolean(flags, isExplicitList);
/*  94 */     flags = opt_show_prompt_on_cell_selected.setBoolean(flags, showPromptBox);
/*  95 */     flags = opt_show_error_on_invalid_value.setBoolean(flags, showErrorBox);
/*  96 */     this._option_flags = flags;
/*  97 */     this._promptTitle = resolveTitleText(promptTitle);
/*  98 */     this._promptText = resolveTitleText(promptText);
/*  99 */     this._errorTitle = resolveTitleText(errorTitle);
/* 100 */     this._errorText = resolveTitleText(errorText);
/* 101 */     this._formula1 = Formula.create(formula1);
/* 102 */     this._formula2 = Formula.create(formula2);
/* 103 */     this._regions = regions;
/*     */   }
/*     */   
/*     */   public DVRecord(RecordInputStream in)
/*     */   {
/* 108 */     this._option_flags = in.readInt();
/*     */     
/* 110 */     this._promptTitle = readUnicodeString(in);
/* 111 */     this._errorTitle = readUnicodeString(in);
/* 112 */     this._promptText = readUnicodeString(in);
/* 113 */     this._errorText = readUnicodeString(in);
/*     */     
/* 115 */     int field_size_first_formula = in.readUShort();
/* 116 */     this._not_used_1 = in.readShort();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     this._formula1 = Formula.read(field_size_first_formula, in);
/*     */     
/* 123 */     int field_size_sec_formula = in.readUShort();
/* 124 */     this._not_used_2 = in.readShort();
/*     */     
/*     */ 
/* 127 */     this._formula2 = Formula.read(field_size_sec_formula, in);
/*     */     
/*     */ 
/* 130 */     this._regions = new CellRangeAddressList(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDataType()
/*     */   {
/* 139 */     return opt_data_type.getValue(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getErrorStyle()
/*     */   {
/* 147 */     return opt_error_style.getValue(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getListExplicitFormula()
/*     */   {
/* 155 */     return opt_string_list_formula.isSet(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getEmptyCellAllowed()
/*     */   {
/* 162 */     return opt_empty_cell_allowed.isSet(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getSuppressDropdownArrow()
/*     */   {
/* 171 */     return opt_suppress_dropdown_arrow.isSet(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getShowPromptOnCellSelected()
/*     */   {
/* 178 */     return opt_show_prompt_on_cell_selected.isSet(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getShowErrorOnInvalidValue()
/*     */   {
/* 186 */     return opt_show_error_on_invalid_value.isSet(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getConditionOperator()
/*     */   {
/* 195 */     return opt_condition_operator.getValue(this._option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellRangeAddressList getCellRangeAddress()
/*     */   {
/* 203 */     return this._regions;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 208 */     StringBuffer sb = new StringBuffer();
/* 209 */     sb.append("[DV]\n");
/* 210 */     sb.append(" options=").append(Integer.toHexString(this._option_flags));
/* 211 */     sb.append(" title-prompt=").append(formatTextTitle(this._promptTitle));
/* 212 */     sb.append(" title-error=").append(formatTextTitle(this._errorTitle));
/* 213 */     sb.append(" text-prompt=").append(formatTextTitle(this._promptText));
/* 214 */     sb.append(" text-error=").append(formatTextTitle(this._errorText));
/* 215 */     sb.append("\n");
/* 216 */     appendFormula(sb, "Formula 1:", this._formula1);
/* 217 */     appendFormula(sb, "Formula 2:", this._formula2);
/* 218 */     sb.append("Regions: ");
/* 219 */     int nRegions = this._regions.countRanges();
/* 220 */     for (int i = 0; i < nRegions; i++) {
/* 221 */       if (i > 0) {
/* 222 */         sb.append(", ");
/*     */       }
/* 224 */       CellRangeAddress addr = this._regions.getCellRangeAddress(i);
/* 225 */       sb.append('(').append(addr.getFirstRow()).append(',').append(addr.getLastRow());
/* 226 */       sb.append(',').append(addr.getFirstColumn()).append(',').append(addr.getLastColumn()).append(')');
/*     */     }
/* 228 */     sb.append("\n");
/* 229 */     sb.append("[/DV]");
/*     */     
/* 231 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String formatTextTitle(UnicodeString us) {
/* 235 */     String str = us.getString();
/* 236 */     if ((str.length() == 1) && (str.charAt(0) == 0)) {
/* 237 */       return "'\\0'";
/*     */     }
/* 239 */     return str;
/*     */   }
/*     */   
/*     */   private static void appendFormula(StringBuffer sb, String label, Formula f) {
/* 243 */     sb.append(label);
/*     */     
/* 245 */     if (f == null) {
/* 246 */       sb.append("<empty>\n");
/* 247 */       return;
/*     */     }
/* 249 */     Ptg[] ptgs = f.getTokens();
/* 250 */     sb.append('\n');
/* 251 */     for (int i = 0; i < ptgs.length; i++) {
/* 252 */       sb.append('\t').append(ptgs[i].toString()).append('\n');
/*     */     }
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 258 */     out.writeInt(this._option_flags);
/*     */     
/* 260 */     serializeUnicodeString(this._promptTitle, out);
/* 261 */     serializeUnicodeString(this._errorTitle, out);
/* 262 */     serializeUnicodeString(this._promptText, out);
/* 263 */     serializeUnicodeString(this._errorText, out);
/* 264 */     out.writeShort(this._formula1.getEncodedTokenSize());
/* 265 */     out.writeShort(this._not_used_1);
/* 266 */     this._formula1.serializeTokens(out);
/*     */     
/* 268 */     out.writeShort(this._formula2.getEncodedTokenSize());
/* 269 */     out.writeShort(this._not_used_2);
/* 270 */     this._formula2.serializeTokens(out);
/*     */     
/* 272 */     this._regions.serialize(out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static UnicodeString resolveTitleText(String str)
/*     */   {
/* 282 */     if ((str == null) || (str.length() < 1)) {
/* 283 */       return NULL_TEXT_STRING;
/*     */     }
/* 285 */     return new UnicodeString(str);
/*     */   }
/*     */   
/*     */   private static UnicodeString readUnicodeString(RecordInputStream in) {
/* 289 */     return new UnicodeString(in);
/*     */   }
/*     */   
/*     */ 
/* 293 */   private static void serializeUnicodeString(UnicodeString us, LittleEndianOutput out) { StringUtil.writeUnicodeString(out, us.getString()); }
/*     */   
/*     */   private static int getUnicodeStringSize(UnicodeString us) {
/* 296 */     String str = us.getString();
/* 297 */     return 3 + str.length() * (StringUtil.hasMultibyte(str) ? 2 : 1);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 301 */     int size = 12;
/* 302 */     size += getUnicodeStringSize(this._promptTitle);
/* 303 */     size += getUnicodeStringSize(this._errorTitle);
/* 304 */     size += getUnicodeStringSize(this._promptText);
/* 305 */     size += getUnicodeStringSize(this._errorText);
/* 306 */     size += this._formula1.getEncodedTokenSize();
/* 307 */     size += this._formula2.getEncodedTokenSize();
/* 308 */     size += this._regions.getSize();
/* 309 */     return size;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 313 */     return 446;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 321 */     return cloneViaReserialise();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DVRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */