/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultColWidthRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 85;
/*    */   private int field_1_col_width;
/*    */   
/*    */   public DefaultColWidthRecord() {}
/*    */   
/*    */   public DefaultColWidthRecord(RecordInputStream in)
/*    */   {
/* 41 */     this.field_1_col_width = in.readUShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setColWidth(int width)
/*    */   {
/* 51 */     this.field_1_col_width = width;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getColWidth()
/*    */   {
/* 61 */     return this.field_1_col_width;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 66 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 68 */     buffer.append("[DEFAULTCOLWIDTH]\n");
/* 69 */     buffer.append("    .colwidth      = ").append(Integer.toHexString(getColWidth())).append("\n");
/*    */     
/* 71 */     buffer.append("[/DEFAULTCOLWIDTH]\n");
/* 72 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 76 */     out.writeShort(getColWidth());
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 80 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 85 */     return 85;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 89 */     DefaultColWidthRecord rec = new DefaultColWidthRecord();
/* 90 */     rec.field_1_col_width = this.field_1_col_width;
/* 91 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DefaultColWidthRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */