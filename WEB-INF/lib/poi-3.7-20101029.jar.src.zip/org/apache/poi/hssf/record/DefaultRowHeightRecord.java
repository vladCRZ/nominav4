/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultRowHeightRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 549;
/*     */   private short field_1_option_flags;
/*     */   private short field_2_row_height;
/*     */   
/*     */   public DefaultRowHeightRecord() {}
/*     */   
/*     */   public DefaultRowHeightRecord(RecordInputStream in)
/*     */   {
/*  47 */     this.field_1_option_flags = in.readShort();
/*  48 */     this.field_2_row_height = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptionFlags(short flags)
/*     */   {
/*  58 */     this.field_1_option_flags = flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRowHeight(short height)
/*     */   {
/*  68 */     this.field_2_row_height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptionFlags()
/*     */   {
/*  78 */     return this.field_1_option_flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getRowHeight()
/*     */   {
/*  88 */     return this.field_2_row_height;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  93 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  95 */     buffer.append("[DEFAULTROWHEIGHT]\n");
/*  96 */     buffer.append("    .optionflags    = ").append(Integer.toHexString(getOptionFlags())).append("\n");
/*     */     
/*  98 */     buffer.append("    .rowheight      = ").append(Integer.toHexString(getRowHeight())).append("\n");
/*     */     
/* 100 */     buffer.append("[/DEFAULTROWHEIGHT]\n");
/* 101 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 105 */     out.writeShort(getOptionFlags());
/* 106 */     out.writeShort(getRowHeight());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 110 */     return 4;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 115 */     return 549;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 119 */     DefaultRowHeightRecord rec = new DefaultRowHeightRecord();
/* 120 */     rec.field_1_option_flags = this.field_1_option_flags;
/* 121 */     rec.field_2_row_height = this.field_2_row_height;
/* 122 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DefaultRowHeightRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */