/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DeltaRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 16;
/*    */   public static final double DEFAULT_VALUE = 0.001D;
/*    */   private double field_1_max_change;
/*    */   
/*    */   public DeltaRecord(double maxChange)
/*    */   {
/* 38 */     this.field_1_max_change = maxChange;
/*    */   }
/*    */   
/*    */   public DeltaRecord(RecordInputStream in) {
/* 42 */     this.field_1_max_change = in.readDouble();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getMaxChange()
/*    */   {
/* 50 */     return this.field_1_max_change;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 54 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 56 */     buffer.append("[DELTA]\n");
/* 57 */     buffer.append("    .maxchange = ").append(getMaxChange()).append("\n");
/* 58 */     buffer.append("[/DELTA]\n");
/* 59 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 63 */     out.writeDouble(getMaxChange());
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 67 */     return 8;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 71 */     return 16;
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/* 76 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DeltaRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */