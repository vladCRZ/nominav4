/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DimensionsRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 512;
/*     */   private int field_1_first_row;
/*     */   private int field_2_last_row;
/*     */   private short field_3_first_col;
/*     */   private short field_4_last_col;
/*     */   private short field_5_zero;
/*     */   
/*     */   public DimensionsRecord() {}
/*     */   
/*     */   public DimensionsRecord(RecordInputStream in)
/*     */   {
/*  50 */     this.field_1_first_row = in.readInt();
/*  51 */     this.field_2_last_row = in.readInt();
/*  52 */     this.field_3_first_col = in.readShort();
/*  53 */     this.field_4_last_col = in.readShort();
/*  54 */     this.field_5_zero = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFirstRow(int row)
/*     */   {
/*  64 */     this.field_1_first_row = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastRow(int row)
/*     */   {
/*  74 */     this.field_2_last_row = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFirstCol(short col)
/*     */   {
/*  84 */     this.field_3_first_col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastCol(short col)
/*     */   {
/*  94 */     this.field_4_last_col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstRow()
/*     */   {
/* 104 */     return this.field_1_first_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastRow()
/*     */   {
/* 114 */     return this.field_2_last_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFirstCol()
/*     */   {
/* 124 */     return this.field_3_first_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLastCol()
/*     */   {
/* 134 */     return this.field_4_last_col;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 139 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 141 */     buffer.append("[DIMENSIONS]\n");
/* 142 */     buffer.append("    .firstrow       = ").append(Integer.toHexString(getFirstRow())).append("\n");
/*     */     
/* 144 */     buffer.append("    .lastrow        = ").append(Integer.toHexString(getLastRow())).append("\n");
/*     */     
/* 146 */     buffer.append("    .firstcol       = ").append(Integer.toHexString(getFirstCol())).append("\n");
/*     */     
/* 148 */     buffer.append("    .lastcol        = ").append(Integer.toHexString(getLastCol())).append("\n");
/*     */     
/* 150 */     buffer.append("    .zero           = ").append(Integer.toHexString(this.field_5_zero)).append("\n");
/*     */     
/* 152 */     buffer.append("[/DIMENSIONS]\n");
/* 153 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 157 */     out.writeInt(getFirstRow());
/* 158 */     out.writeInt(getLastRow());
/* 159 */     out.writeShort(getFirstCol());
/* 160 */     out.writeShort(getLastCol());
/* 161 */     out.writeShort(0);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 165 */     return 14;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 170 */     return 512;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 174 */     DimensionsRecord rec = new DimensionsRecord();
/* 175 */     rec.field_1_first_row = this.field_1_first_row;
/* 176 */     rec.field_2_last_row = this.field_2_last_row;
/* 177 */     rec.field_3_first_col = this.field_3_first_col;
/* 178 */     rec.field_4_last_col = this.field_4_last_col;
/* 179 */     rec.field_5_zero = this.field_5_zero;
/* 180 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DimensionsRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */