/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.NullEscherSerializationListener;
/*     */ import org.apache.poi.util.ArrayUtil;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DrawingGroupRecord
/*     */   extends AbstractEscherHolderRecord
/*     */ {
/*     */   public static final short sid = 235;
/*     */   static final int MAX_RECORD_SIZE = 8228;
/*     */   private static final int MAX_DATA_SIZE = 8224;
/*     */   
/*     */   public DrawingGroupRecord() {}
/*     */   
/*     */   public DrawingGroupRecord(RecordInputStream in)
/*     */   {
/*  41 */     super(in);
/*     */   }
/*     */   
/*     */   protected String getRecordName()
/*     */   {
/*  46 */     return "MSODRAWINGGROUP";
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  51 */     return 235;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data)
/*     */   {
/*  56 */     byte[] rawData = getRawData();
/*  57 */     if ((getEscherRecords().size() == 0) && (rawData != null))
/*     */     {
/*  59 */       return writeData(offset, data, rawData);
/*     */     }
/*  61 */     byte[] buffer = new byte[getRawDataSize()];
/*  62 */     int pos = 0;
/*  63 */     for (Iterator iterator = getEscherRecords().iterator(); iterator.hasNext();)
/*     */     {
/*  65 */       EscherRecord r = (EscherRecord)iterator.next();
/*  66 */       pos += r.serialize(pos, buffer, new NullEscherSerializationListener());
/*     */     }
/*     */     
/*  69 */     return writeData(offset, data, buffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processChildRecords()
/*     */   {
/*  79 */     convertRawBytesToEscherRecords();
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  84 */     return grossSizeFromDataSize(getRawDataSize());
/*     */   }
/*     */   
/*     */   private int getRawDataSize() {
/*  88 */     List escherRecords = getEscherRecords();
/*  89 */     byte[] rawData = getRawData();
/*  90 */     if ((escherRecords.size() == 0) && (rawData != null))
/*     */     {
/*  92 */       return rawData.length;
/*     */     }
/*  94 */     int size = 0;
/*  95 */     for (Iterator iterator = escherRecords.iterator(); iterator.hasNext();)
/*     */     {
/*  97 */       EscherRecord r = (EscherRecord)iterator.next();
/*  98 */       size += r.getRecordSize();
/*     */     }
/* 100 */     return size;
/*     */   }
/*     */   
/*     */   static int grossSizeFromDataSize(int dataSize)
/*     */   {
/* 105 */     return dataSize + ((dataSize - 1) / 8224 + 1) * 4;
/*     */   }
/*     */   
/*     */   private int writeData(int offset, byte[] data, byte[] rawData)
/*     */   {
/* 110 */     int writtenActualData = 0;
/* 111 */     int writtenRawData = 0;
/* 112 */     while (writtenRawData < rawData.length)
/*     */     {
/* 114 */       int segmentLength = Math.min(rawData.length - writtenRawData, 8224);
/* 115 */       if (writtenRawData / 8224 >= 2) {
/* 116 */         writeContinueHeader(data, offset, segmentLength);
/*     */       } else
/* 118 */         writeHeader(data, offset, segmentLength);
/* 119 */       writtenActualData += 4;
/* 120 */       offset += 4;
/* 121 */       ArrayUtil.arraycopy(rawData, writtenRawData, data, offset, segmentLength);
/* 122 */       offset += segmentLength;
/* 123 */       writtenRawData += segmentLength;
/* 124 */       writtenActualData += segmentLength;
/*     */     }
/* 126 */     return writtenActualData;
/*     */   }
/*     */   
/*     */   private void writeHeader(byte[] data, int offset, int sizeExcludingHeader)
/*     */   {
/* 131 */     LittleEndian.putShort(data, 0 + offset, getSid());
/* 132 */     LittleEndian.putShort(data, 2 + offset, (short)sizeExcludingHeader);
/*     */   }
/*     */   
/*     */   private void writeContinueHeader(byte[] data, int offset, int sizeExcludingHeader)
/*     */   {
/* 137 */     LittleEndian.putShort(data, 0 + offset, (short)60);
/* 138 */     LittleEndian.putShort(data, 2 + offset, (short)sizeExcludingHeader);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DrawingGroupRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */