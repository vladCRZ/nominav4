/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DrawingRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 236;
/* 28 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*    */   private byte[] recordData;
/*    */   private byte[] contd;
/*    */   
/*    */   public DrawingRecord()
/*    */   {
/* 34 */     this.recordData = EMPTY_BYTE_ARRAY;
/*    */   }
/*    */   
/*    */   public DrawingRecord(RecordInputStream in) {
/* 38 */     this.recordData = in.readRemainder();
/*    */   }
/*    */   
/*    */   public void processContinueRecord(byte[] record)
/*    */   {
/* 43 */     this.contd = record;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 47 */     out.write(this.recordData);
/*    */   }
/*    */   
/* 50 */   protected int getDataSize() { return this.recordData.length; }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 54 */     return 236;
/*    */   }
/*    */   
/*    */   public byte[] getData() {
/* 58 */     if (this.contd != null) {
/* 59 */       byte[] newBuffer = new byte[this.recordData.length + this.contd.length];
/* 60 */       System.arraycopy(this.recordData, 0, newBuffer, 0, this.recordData.length);
/* 61 */       System.arraycopy(this.contd, 0, newBuffer, this.recordData.length, this.contd.length);
/* 62 */       return newBuffer;
/*    */     }
/* 64 */     return this.recordData;
/*    */   }
/*    */   
/*    */   public void setData(byte[] thedata) {
/* 68 */     if (thedata == null) {
/* 69 */       throw new IllegalArgumentException("data must not be null");
/*    */     }
/* 71 */     this.recordData = thedata;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 75 */     DrawingRecord rec = new DrawingRecord();
/*    */     
/* 77 */     rec.recordData = ((byte[])this.recordData.clone());
/* 78 */     if (this.contd != null)
/*    */     {
/* 80 */       rec.contd = ((byte[])this.contd.clone());
/*    */     }
/*    */     
/* 83 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DrawingRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */