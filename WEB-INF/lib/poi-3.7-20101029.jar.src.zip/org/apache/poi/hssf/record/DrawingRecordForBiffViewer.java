/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DrawingRecordForBiffViewer
/*    */   extends AbstractEscherHolderRecord
/*    */ {
/*    */   public static final short sid = 236;
/*    */   
/*    */   public DrawingRecordForBiffViewer() {}
/*    */   
/*    */   public DrawingRecordForBiffViewer(RecordInputStream in)
/*    */   {
/* 35 */     super(in);
/*    */   }
/*    */   
/*    */   public DrawingRecordForBiffViewer(DrawingRecord r)
/*    */   {
/* 40 */     super(convertToInputStream(r));
/* 41 */     convertRawBytesToEscherRecords();
/*    */   }
/*    */   
/*    */   private static RecordInputStream convertToInputStream(DrawingRecord r) {
/* 45 */     byte[] data = r.serialize();
/* 46 */     RecordInputStream rinp = new RecordInputStream(new ByteArrayInputStream(data));
/*    */     
/*    */ 
/* 49 */     rinp.nextRecord();
/* 50 */     return rinp;
/*    */   }
/*    */   
/*    */   protected String getRecordName()
/*    */   {
/* 55 */     return "MSODRAWING";
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 60 */     return 236;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DrawingRecordForBiffViewer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */