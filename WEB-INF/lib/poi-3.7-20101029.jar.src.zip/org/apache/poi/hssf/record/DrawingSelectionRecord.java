/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DrawingSelectionRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 237;
/*     */   private OfficeArtRecordHeader _header;
/*     */   private int _cpsp;
/*     */   private int _dgslk;
/*     */   private int _spidFocus;
/*     */   private int[] _shapeIds;
/*     */   
/*     */   private static final class OfficeArtRecordHeader
/*     */   {
/*     */     public static final int ENCODED_SIZE = 8;
/*     */     private final int _verAndInstance;
/*     */     private final int _type;
/*     */     private final int _length;
/*     */     
/*     */     public OfficeArtRecordHeader(LittleEndianInput in)
/*     */     {
/*  50 */       this._verAndInstance = in.readUShort();
/*  51 */       this._type = in.readUShort();
/*  52 */       this._length = in.readInt();
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  56 */       out.writeShort(this._verAndInstance);
/*  57 */       out.writeShort(this._type);
/*  58 */       out.writeInt(this._length);
/*     */     }
/*     */     
/*     */     public String debugFormatAsString() {
/*  62 */       StringBuffer sb = new StringBuffer(32);
/*  63 */       sb.append("ver+inst=").append(HexDump.shortToHex(this._verAndInstance));
/*  64 */       sb.append(" type=").append(HexDump.shortToHex(this._type));
/*  65 */       sb.append(" len=").append(HexDump.intToHex(this._length));
/*  66 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DrawingSelectionRecord(RecordInputStream in)
/*     */   {
/*  81 */     this._header = new OfficeArtRecordHeader(in);
/*  82 */     this._cpsp = in.readInt();
/*  83 */     this._dgslk = in.readInt();
/*  84 */     this._spidFocus = in.readInt();
/*  85 */     int nShapes = in.available() / 4;
/*  86 */     int[] shapeIds = new int[nShapes];
/*  87 */     for (int i = 0; i < nShapes; i++) {
/*  88 */       shapeIds[i] = in.readInt();
/*     */     }
/*  90 */     this._shapeIds = shapeIds;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  94 */     return 237;
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  98 */     return 20 + this._shapeIds.length * 4;
/*     */   }
/*     */   
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 104 */     this._header.serialize(out);
/* 105 */     out.writeInt(this._cpsp);
/* 106 */     out.writeInt(this._dgslk);
/* 107 */     out.writeInt(this._spidFocus);
/* 108 */     for (int i = 0; i < this._shapeIds.length; i++) {
/* 109 */       out.writeInt(this._shapeIds[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 115 */     return this;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 119 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 121 */     sb.append("[MSODRAWINGSELECTION]\n");
/* 122 */     sb.append("    .rh       =(").append(this._header.debugFormatAsString()).append(")\n");
/* 123 */     sb.append("    .cpsp     =").append(HexDump.intToHex(this._cpsp)).append('\n');
/* 124 */     sb.append("    .dgslk    =").append(HexDump.intToHex(this._dgslk)).append('\n');
/* 125 */     sb.append("    .spidFocus=").append(HexDump.intToHex(this._spidFocus)).append('\n');
/* 126 */     sb.append("    .shapeIds =(");
/* 127 */     for (int i = 0; i < this._shapeIds.length; i++) {
/* 128 */       if (i > 0) {
/* 129 */         sb.append(", ");
/*     */       }
/* 131 */       sb.append(HexDump.intToHex(this._shapeIds[i]));
/*     */     }
/* 133 */     sb.append(")\n");
/*     */     
/* 135 */     sb.append("[/MSODRAWINGSELECTION]\n");
/* 136 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\DrawingSelectionRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */