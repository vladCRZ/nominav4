/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EOFRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 10;
/*    */   public static final int ENCODED_SIZE = 4;
/* 36 */   public static final EOFRecord instance = new EOFRecord();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private EOFRecord() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public EOFRecord(RecordInputStream in) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 53 */     buffer.append("[EOF]\n");
/* 54 */     buffer.append("[/EOF]\n");
/* 55 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {}
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 62 */     return 0;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 67 */     return 10;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 71 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\EOFRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */