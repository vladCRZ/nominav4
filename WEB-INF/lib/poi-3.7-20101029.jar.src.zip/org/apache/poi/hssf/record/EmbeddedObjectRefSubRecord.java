/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.poi.hssf.record.formula.Area3DPtg;
/*     */ import org.apache.poi.hssf.record.formula.AreaPtg;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.record.formula.Ref3DPtg;
/*     */ import org.apache.poi.hssf.record.formula.RefPtg;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianInputStream;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EmbeddedObjectRefSubRecord
/*     */   extends SubRecord
/*     */ {
/*     */   public static final short sid = 9;
/*  44 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   
/*     */   private int field_1_unknown_int;
/*     */   
/*     */   private Ptg field_2_refPtg;
/*     */   
/*     */   private byte[] field_2_unknownFormulaData;
/*     */   
/*     */   private boolean field_3_unicode_flag;
/*     */   
/*     */   private String field_4_ole_classname;
/*     */   
/*     */   private Byte field_4_unknownByte;
/*     */   
/*     */   private Integer field_5_stream_id;
/*     */   
/*     */   private byte[] field_6_unknown;
/*     */   
/*     */ 
/*     */   EmbeddedObjectRefSubRecord()
/*     */   {
/*  65 */     this.field_2_unknownFormulaData = new byte[] { 2, 108, 106, 22, 1 };
/*  66 */     this.field_6_unknown = EMPTY_BYTE_ARRAY;
/*  67 */     this.field_4_ole_classname = null;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  71 */     return 9;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EmbeddedObjectRefSubRecord(LittleEndianInput in, int size)
/*     */   {
/*  81 */     int streamIdOffset = in.readShort();
/*  82 */     int remaining = size - 2;
/*     */     
/*  84 */     int dataLenAfterFormula = remaining - streamIdOffset;
/*  85 */     int formulaSize = in.readUShort();
/*  86 */     remaining -= 2;
/*  87 */     this.field_1_unknown_int = in.readInt();
/*  88 */     remaining -= 4;
/*  89 */     byte[] formulaRawBytes = readRawData(in, formulaSize);
/*  90 */     remaining -= formulaSize;
/*  91 */     this.field_2_refPtg = readRefPtg(formulaRawBytes);
/*  92 */     if (this.field_2_refPtg == null)
/*     */     {
/*     */ 
/*     */ 
/*  96 */       this.field_2_unknownFormulaData = formulaRawBytes;
/*     */     } else {
/*  98 */       this.field_2_unknownFormulaData = null;
/*     */     }
/*     */     
/*     */     int stringByteCount;
/* 102 */     if (remaining >= dataLenAfterFormula + 3) {
/* 103 */       int tag = in.readByte();
/* 104 */       int stringByteCount = 1;
/* 105 */       if (tag != 3) {
/* 106 */         throw new RecordFormatException("Expected byte 0x03 here");
/*     */       }
/* 108 */       int nChars = in.readUShort();
/* 109 */       stringByteCount += 2;
/* 110 */       if (nChars > 0)
/*     */       {
/* 112 */         this.field_3_unicode_flag = ((in.readByte() & 0x1) != 0);
/* 113 */         stringByteCount++;
/* 114 */         if (this.field_3_unicode_flag) {
/* 115 */           this.field_4_ole_classname = StringUtil.readUnicodeLE(in, nChars);
/* 116 */           stringByteCount += nChars * 2;
/*     */         } else {
/* 118 */           this.field_4_ole_classname = StringUtil.readCompressedUnicode(in, nChars);
/* 119 */           stringByteCount += nChars;
/*     */         }
/*     */       } else {
/* 122 */         this.field_4_ole_classname = "";
/*     */       }
/*     */     } else {
/* 125 */       this.field_4_ole_classname = null;
/* 126 */       stringByteCount = 0;
/*     */     }
/* 128 */     remaining -= stringByteCount;
/*     */     
/* 130 */     if ((stringByteCount + formulaSize) % 2 != 0) {
/* 131 */       int b = in.readByte();
/* 132 */       remaining--;
/* 133 */       if ((this.field_2_refPtg != null) && (this.field_4_ole_classname == null)) {
/* 134 */         this.field_4_unknownByte = Byte.valueOf((byte)b);
/*     */       }
/*     */     }
/* 137 */     int nUnexpectedPadding = remaining - dataLenAfterFormula;
/*     */     
/* 139 */     if (nUnexpectedPadding > 0) {
/* 140 */       System.err.println("Discarding " + nUnexpectedPadding + " unexpected padding bytes ");
/* 141 */       readRawData(in, nUnexpectedPadding);
/* 142 */       remaining -= nUnexpectedPadding;
/*     */     }
/*     */     
/*     */ 
/* 146 */     if (dataLenAfterFormula >= 4) {
/* 147 */       this.field_5_stream_id = Integer.valueOf(in.readInt());
/* 148 */       remaining -= 4;
/*     */     } else {
/* 150 */       this.field_5_stream_id = null;
/*     */     }
/* 152 */     this.field_6_unknown = readRawData(in, remaining);
/*     */   }
/*     */   
/*     */   private static Ptg readRefPtg(byte[] formulaRawBytes) {
/* 156 */     LittleEndianInput in = new LittleEndianInputStream(new ByteArrayInputStream(formulaRawBytes));
/* 157 */     byte ptgSid = in.readByte();
/* 158 */     switch (ptgSid) {
/* 159 */     case 37:  return new AreaPtg(in);
/* 160 */     case 59:  return new Area3DPtg(in);
/* 161 */     case 36:  return new RefPtg(in);
/* 162 */     case 58:  return new Ref3DPtg(in);
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */   
/*     */   private static byte[] readRawData(LittleEndianInput in, int size) {
/* 168 */     if (size < 0) {
/* 169 */       throw new IllegalArgumentException("Negative size (" + size + ")");
/*     */     }
/* 171 */     if (size == 0) {
/* 172 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 174 */     byte[] result = new byte[size];
/* 175 */     in.readFully(result);
/* 176 */     return result;
/*     */   }
/*     */   
/*     */   private int getStreamIDOffset(int formulaSize) {
/* 180 */     int result = 6;
/* 181 */     result += formulaSize;
/*     */     
/*     */     int stringLen;
/* 184 */     if (this.field_4_ole_classname == null)
/*     */     {
/* 186 */       stringLen = 0;
/*     */     } else {
/* 188 */       result += 3;
/* 189 */       int stringLen = this.field_4_ole_classname.length();
/* 190 */       if (stringLen > 0) {
/* 191 */         result++;
/* 192 */         if (this.field_3_unicode_flag) {
/* 193 */           result += stringLen * 2;
/*     */         } else {
/* 195 */           result += stringLen;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 200 */     if (result % 2 != 0) {
/* 201 */       result++;
/*     */     }
/* 203 */     return result;
/*     */   }
/*     */   
/*     */   private int getDataSize(int idOffset)
/*     */   {
/* 208 */     int result = 2 + idOffset;
/* 209 */     if (this.field_5_stream_id != null) {
/* 210 */       result += 4;
/*     */     }
/* 212 */     return result + this.field_6_unknown.length;
/*     */   }
/*     */   
/* 215 */   protected int getDataSize() { int formulaSize = this.field_2_refPtg == null ? this.field_2_unknownFormulaData.length : this.field_2_refPtg.getSize();
/* 216 */     int idOffset = getStreamIDOffset(formulaSize);
/* 217 */     return getDataSize(idOffset);
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 222 */     int formulaSize = this.field_2_refPtg == null ? this.field_2_unknownFormulaData.length : this.field_2_refPtg.getSize();
/* 223 */     int idOffset = getStreamIDOffset(formulaSize);
/* 224 */     int dataSize = getDataSize(idOffset);
/*     */     
/*     */ 
/* 227 */     out.writeShort(9);
/* 228 */     out.writeShort(dataSize);
/*     */     
/* 230 */     out.writeShort(idOffset);
/* 231 */     out.writeShort(formulaSize);
/* 232 */     out.writeInt(this.field_1_unknown_int);
/*     */     
/* 234 */     int pos = 12;
/*     */     
/* 236 */     if (this.field_2_refPtg == null) {
/* 237 */       out.write(this.field_2_unknownFormulaData);
/*     */     } else {
/* 239 */       this.field_2_refPtg.write(out);
/*     */     }
/* 241 */     pos += formulaSize;
/*     */     
/*     */     int stringLen;
/* 244 */     if (this.field_4_ole_classname == null)
/*     */     {
/* 246 */       stringLen = 0;
/*     */     } else {
/* 248 */       out.writeByte(3);
/* 249 */       pos++;
/* 250 */       int stringLen = this.field_4_ole_classname.length();
/* 251 */       out.writeShort(stringLen);
/* 252 */       pos += 2;
/* 253 */       if (stringLen > 0) {
/* 254 */         out.writeByte(this.field_3_unicode_flag ? 1 : 0);
/* 255 */         pos++;
/*     */         
/* 257 */         if (this.field_3_unicode_flag) {
/* 258 */           StringUtil.putUnicodeLE(this.field_4_ole_classname, out);
/* 259 */           pos += stringLen * 2;
/*     */         } else {
/* 261 */           StringUtil.putCompressedUnicode(this.field_4_ole_classname, out);
/* 262 */           pos += stringLen;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 268 */     switch (idOffset - (pos - 6)) {
/*     */     case 1: 
/* 270 */       out.writeByte(this.field_4_unknownByte == null ? 0 : this.field_4_unknownByte.intValue());
/* 271 */       pos++;
/*     */     case 0: 
/*     */       break;
/*     */     default: 
/* 275 */       throw new IllegalStateException("Bad padding calculation (" + idOffset + ", " + pos + ")");
/*     */     }
/*     */     
/* 278 */     if (this.field_5_stream_id != null) {
/* 279 */       out.writeInt(this.field_5_stream_id.intValue());
/* 280 */       pos += 4;
/*     */     }
/* 282 */     out.write(this.field_6_unknown);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getStreamId()
/*     */   {
/* 294 */     return this.field_5_stream_id;
/*     */   }
/*     */   
/*     */   public String getOLEClassName() {
/* 298 */     return this.field_4_ole_classname;
/*     */   }
/*     */   
/*     */   public byte[] getObjectData() {
/* 302 */     return this.field_6_unknown;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 306 */     return this;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 310 */     StringBuffer sb = new StringBuffer();
/* 311 */     sb.append("[ftPictFmla]\n");
/* 312 */     sb.append("    .f2unknown     = ").append(HexDump.intToHex(this.field_1_unknown_int)).append("\n");
/* 313 */     if (this.field_2_refPtg == null) {
/* 314 */       sb.append("    .f3unknown     = ").append(HexDump.toHex(this.field_2_unknownFormulaData)).append("\n");
/*     */     } else {
/* 316 */       sb.append("    .formula       = ").append(this.field_2_refPtg.toString()).append("\n");
/*     */     }
/* 318 */     if (this.field_4_ole_classname != null) {
/* 319 */       sb.append("    .unicodeFlag   = ").append(this.field_3_unicode_flag).append("\n");
/* 320 */       sb.append("    .oleClassname  = ").append(this.field_4_ole_classname).append("\n");
/*     */     }
/* 322 */     if (this.field_4_unknownByte != null) {
/* 323 */       sb.append("    .f4unknown   = ").append(HexDump.byteToHex(this.field_4_unknownByte.intValue())).append("\n");
/*     */     }
/* 325 */     if (this.field_5_stream_id != null) {
/* 326 */       sb.append("    .streamId      = ").append(HexDump.intToHex(this.field_5_stream_id.intValue())).append("\n");
/*     */     }
/* 328 */     if (this.field_6_unknown.length > 0) {
/* 329 */       sb.append("    .f7unknown     = ").append(HexDump.toHex(this.field_6_unknown)).append("\n");
/*     */     }
/* 331 */     sb.append("[/ftPictFmla]");
/* 332 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\EmbeddedObjectRefSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */