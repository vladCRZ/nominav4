/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EndSubRecord
/*    */   extends SubRecord
/*    */ {
/*    */   public static final short sid = 0;
/*    */   private static final int ENCODED_SIZE = 0;
/*    */   
/*    */   public EndSubRecord() {}
/*    */   
/*    */   public EndSubRecord(LittleEndianInput in, int size)
/*    */   {
/* 44 */     if ((size & 0xFF) != 0) {
/* 45 */       throw new RecordFormatException("Unexpected size (" + size + ")");
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isTerminating()
/*    */   {
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 56 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 58 */     buffer.append("[ftEnd]\n");
/*    */     
/* 60 */     buffer.append("[/ftEnd]\n");
/* 61 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 65 */     out.writeShort(0);
/* 66 */     out.writeShort(0);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 70 */     return 0;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 75 */     return 0;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 79 */     EndSubRecord rec = new EndSubRecord();
/*    */     
/* 81 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\EndSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */