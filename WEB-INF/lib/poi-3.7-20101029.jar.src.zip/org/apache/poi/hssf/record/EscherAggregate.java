/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.ddf.DefaultEscherRecordFactory;
/*     */ import org.apache.poi.ddf.EscherBoolProperty;
/*     */ import org.apache.poi.ddf.EscherClientAnchorRecord;
/*     */ import org.apache.poi.ddf.EscherClientDataRecord;
/*     */ import org.apache.poi.ddf.EscherContainerRecord;
/*     */ import org.apache.poi.ddf.EscherDgRecord;
/*     */ import org.apache.poi.ddf.EscherDggRecord;
/*     */ import org.apache.poi.ddf.EscherDggRecord.FileIdCluster;
/*     */ import org.apache.poi.ddf.EscherOptRecord;
/*     */ import org.apache.poi.ddf.EscherProperty;
/*     */ import org.apache.poi.ddf.EscherRecord;
/*     */ import org.apache.poi.ddf.EscherRecordFactory;
/*     */ import org.apache.poi.ddf.EscherSerializationListener;
/*     */ import org.apache.poi.ddf.EscherSimpleProperty;
/*     */ import org.apache.poi.ddf.EscherSpRecord;
/*     */ import org.apache.poi.ddf.EscherSpgrRecord;
/*     */ import org.apache.poi.ddf.EscherTextboxRecord;
/*     */ import org.apache.poi.hssf.model.AbstractShape;
/*     */ import org.apache.poi.hssf.model.CommentShape;
/*     */ import org.apache.poi.hssf.model.ConvertAnchor;
/*     */ import org.apache.poi.hssf.model.DrawingManager2;
/*     */ import org.apache.poi.hssf.model.TextboxShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
/*     */ import org.apache.poi.hssf.usermodel.HSSFPatriarch;
/*     */ import org.apache.poi.hssf.usermodel.HSSFPicture;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShape;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShapeContainer;
/*     */ import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
/*     */ import org.apache.poi.hssf.usermodel.HSSFTextbox;
/*     */ import org.apache.poi.util.POILogFactory;
/*     */ import org.apache.poi.util.POILogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscherAggregate
/*     */   extends AbstractEscherHolderRecord
/*     */ {
/*     */   public static final short sid = 9876;
/*  78 */   private static POILogger log = POILogFactory.getLogger(EscherAggregate.class);
/*     */   
/*     */   public static final short ST_MIN = 0;
/*     */   
/*     */   public static final short ST_NOT_PRIMATIVE = 0;
/*     */   
/*     */   public static final short ST_RECTANGLE = 1;
/*     */   
/*     */   public static final short ST_ROUNDRECTANGLE = 2;
/*     */   public static final short ST_ELLIPSE = 3;
/*     */   public static final short ST_DIAMOND = 4;
/*     */   public static final short ST_ISOCELESTRIANGLE = 5;
/*     */   public static final short ST_RIGHTTRIANGLE = 6;
/*     */   public static final short ST_PARALLELOGRAM = 7;
/*     */   public static final short ST_TRAPEZOID = 8;
/*     */   public static final short ST_HEXAGON = 9;
/*     */   public static final short ST_OCTAGON = 10;
/*     */   public static final short ST_PLUS = 11;
/*     */   public static final short ST_STAR = 12;
/*     */   public static final short ST_ARROW = 13;
/*     */   public static final short ST_THICKARROW = 14;
/*     */   public static final short ST_HOMEPLATE = 15;
/*     */   public static final short ST_CUBE = 16;
/*     */   public static final short ST_BALLOON = 17;
/*     */   public static final short ST_SEAL = 18;
/*     */   public static final short ST_ARC = 19;
/*     */   public static final short ST_LINE = 20;
/*     */   public static final short ST_PLAQUE = 21;
/*     */   public static final short ST_CAN = 22;
/*     */   public static final short ST_DONUT = 23;
/*     */   public static final short ST_TEXTSIMPLE = 24;
/*     */   public static final short ST_TEXTOCTAGON = 25;
/*     */   public static final short ST_TEXTHEXAGON = 26;
/*     */   public static final short ST_TEXTCURVE = 27;
/*     */   public static final short ST_TEXTWAVE = 28;
/*     */   public static final short ST_TEXTRING = 29;
/*     */   public static final short ST_TEXTONCURVE = 30;
/*     */   public static final short ST_TEXTONRING = 31;
/*     */   public static final short ST_STRAIGHTCONNECTOR1 = 32;
/*     */   public static final short ST_BENTCONNECTOR2 = 33;
/*     */   public static final short ST_BENTCONNECTOR3 = 34;
/*     */   public static final short ST_BENTCONNECTOR4 = 35;
/*     */   public static final short ST_BENTCONNECTOR5 = 36;
/*     */   public static final short ST_CURVEDCONNECTOR2 = 37;
/*     */   public static final short ST_CURVEDCONNECTOR3 = 38;
/*     */   public static final short ST_CURVEDCONNECTOR4 = 39;
/*     */   public static final short ST_CURVEDCONNECTOR5 = 40;
/*     */   public static final short ST_CALLOUT1 = 41;
/*     */   public static final short ST_CALLOUT2 = 42;
/*     */   public static final short ST_CALLOUT3 = 43;
/*     */   public static final short ST_ACCENTCALLOUT1 = 44;
/*     */   public static final short ST_ACCENTCALLOUT2 = 45;
/*     */   public static final short ST_ACCENTCALLOUT3 = 46;
/*     */   public static final short ST_BORDERCALLOUT1 = 47;
/*     */   public static final short ST_BORDERCALLOUT2 = 48;
/*     */   public static final short ST_BORDERCALLOUT3 = 49;
/*     */   public static final short ST_ACCENTBORDERCALLOUT1 = 50;
/*     */   public static final short ST_ACCENTBORDERCALLOUT2 = 51;
/*     */   public static final short ST_ACCENTBORDERCALLOUT3 = 52;
/*     */   public static final short ST_RIBBON = 53;
/*     */   public static final short ST_RIBBON2 = 54;
/*     */   public static final short ST_CHEVRON = 55;
/*     */   public static final short ST_PENTAGON = 56;
/*     */   public static final short ST_NOSMOKING = 57;
/*     */   public static final short ST_SEAL8 = 58;
/*     */   public static final short ST_SEAL16 = 59;
/*     */   public static final short ST_SEAL32 = 60;
/*     */   public static final short ST_WEDGERECTCALLOUT = 61;
/*     */   public static final short ST_WEDGERRECTCALLOUT = 62;
/*     */   public static final short ST_WEDGEELLIPSECALLOUT = 63;
/*     */   public static final short ST_WAVE = 64;
/*     */   public static final short ST_FOLDEDCORNER = 65;
/*     */   public static final short ST_LEFTARROW = 66;
/*     */   public static final short ST_DOWNARROW = 67;
/*     */   public static final short ST_UPARROW = 68;
/*     */   public static final short ST_LEFTRIGHTARROW = 69;
/*     */   public static final short ST_UPDOWNARROW = 70;
/*     */   public static final short ST_IRREGULARSEAL1 = 71;
/*     */   public static final short ST_IRREGULARSEAL2 = 72;
/*     */   public static final short ST_LIGHTNINGBOLT = 73;
/*     */   public static final short ST_HEART = 74;
/*     */   public static final short ST_PICTUREFRAME = 75;
/*     */   public static final short ST_QUADARROW = 76;
/*     */   public static final short ST_LEFTARROWCALLOUT = 77;
/*     */   public static final short ST_RIGHTARROWCALLOUT = 78;
/*     */   public static final short ST_UPARROWCALLOUT = 79;
/*     */   public static final short ST_DOWNARROWCALLOUT = 80;
/*     */   public static final short ST_LEFTRIGHTARROWCALLOUT = 81;
/*     */   public static final short ST_UPDOWNARROWCALLOUT = 82;
/*     */   public static final short ST_QUADARROWCALLOUT = 83;
/*     */   public static final short ST_BEVEL = 84;
/*     */   public static final short ST_LEFTBRACKET = 85;
/*     */   public static final short ST_RIGHTBRACKET = 86;
/*     */   public static final short ST_LEFTBRACE = 87;
/*     */   public static final short ST_RIGHTBRACE = 88;
/*     */   public static final short ST_LEFTUPARROW = 89;
/*     */   public static final short ST_BENTUPARROW = 90;
/*     */   public static final short ST_BENTARROW = 91;
/*     */   public static final short ST_SEAL24 = 92;
/*     */   public static final short ST_STRIPEDRIGHTARROW = 93;
/*     */   public static final short ST_NOTCHEDRIGHTARROW = 94;
/*     */   public static final short ST_BLOCKARC = 95;
/*     */   public static final short ST_SMILEYFACE = 96;
/*     */   public static final short ST_VERTICALSCROLL = 97;
/*     */   public static final short ST_HORIZONTALSCROLL = 98;
/*     */   public static final short ST_CIRCULARARROW = 99;
/*     */   public static final short ST_NOTCHEDCIRCULARARROW = 100;
/*     */   public static final short ST_UTURNARROW = 101;
/*     */   public static final short ST_CURVEDRIGHTARROW = 102;
/*     */   public static final short ST_CURVEDLEFTARROW = 103;
/*     */   public static final short ST_CURVEDUPARROW = 104;
/*     */   public static final short ST_CURVEDDOWNARROW = 105;
/*     */   public static final short ST_CLOUDCALLOUT = 106;
/*     */   public static final short ST_ELLIPSERIBBON = 107;
/*     */   public static final short ST_ELLIPSERIBBON2 = 108;
/*     */   public static final short ST_FLOWCHARTPROCESS = 109;
/*     */   public static final short ST_FLOWCHARTDECISION = 110;
/*     */   public static final short ST_FLOWCHARTINPUTOUTPUT = 111;
/*     */   public static final short ST_FLOWCHARTPREDEFINEDPROCESS = 112;
/*     */   public static final short ST_FLOWCHARTINTERNALSTORAGE = 113;
/*     */   public static final short ST_FLOWCHARTDOCUMENT = 114;
/*     */   public static final short ST_FLOWCHARTMULTIDOCUMENT = 115;
/*     */   public static final short ST_FLOWCHARTTERMINATOR = 116;
/*     */   public static final short ST_FLOWCHARTPREPARATION = 117;
/*     */   public static final short ST_FLOWCHARTMANUALINPUT = 118;
/*     */   public static final short ST_FLOWCHARTMANUALOPERATION = 119;
/*     */   public static final short ST_FLOWCHARTCONNECTOR = 120;
/*     */   public static final short ST_FLOWCHARTPUNCHEDCARD = 121;
/*     */   public static final short ST_FLOWCHARTPUNCHEDTAPE = 122;
/*     */   public static final short ST_FLOWCHARTSUMMINGJUNCTION = 123;
/*     */   public static final short ST_FLOWCHARTOR = 124;
/*     */   public static final short ST_FLOWCHARTCOLLATE = 125;
/*     */   public static final short ST_FLOWCHARTSORT = 126;
/*     */   public static final short ST_FLOWCHARTEXTRACT = 127;
/*     */   public static final short ST_FLOWCHARTMERGE = 128;
/*     */   public static final short ST_FLOWCHARTOFFLINESTORAGE = 129;
/*     */   public static final short ST_FLOWCHARTONLINESTORAGE = 130;
/*     */   public static final short ST_FLOWCHARTMAGNETICTAPE = 131;
/*     */   public static final short ST_FLOWCHARTMAGNETICDISK = 132;
/*     */   public static final short ST_FLOWCHARTMAGNETICDRUM = 133;
/*     */   public static final short ST_FLOWCHARTDISPLAY = 134;
/*     */   public static final short ST_FLOWCHARTDELAY = 135;
/*     */   public static final short ST_TEXTPLAINTEXT = 136;
/*     */   public static final short ST_TEXTSTOP = 137;
/*     */   public static final short ST_TEXTTRIANGLE = 138;
/*     */   public static final short ST_TEXTTRIANGLEINVERTED = 139;
/*     */   public static final short ST_TEXTCHEVRON = 140;
/*     */   public static final short ST_TEXTCHEVRONINVERTED = 141;
/*     */   public static final short ST_TEXTRINGINSIDE = 142;
/*     */   public static final short ST_TEXTRINGOUTSIDE = 143;
/*     */   public static final short ST_TEXTARCHUPCURVE = 144;
/*     */   public static final short ST_TEXTARCHDOWNCURVE = 145;
/*     */   public static final short ST_TEXTCIRCLECURVE = 146;
/*     */   public static final short ST_TEXTBUTTONCURVE = 147;
/*     */   public static final short ST_TEXTARCHUPPOUR = 148;
/*     */   public static final short ST_TEXTARCHDOWNPOUR = 149;
/*     */   public static final short ST_TEXTCIRCLEPOUR = 150;
/*     */   public static final short ST_TEXTBUTTONPOUR = 151;
/*     */   public static final short ST_TEXTCURVEUP = 152;
/*     */   public static final short ST_TEXTCURVEDOWN = 153;
/*     */   public static final short ST_TEXTCASCADEUP = 154;
/*     */   public static final short ST_TEXTCASCADEDOWN = 155;
/*     */   public static final short ST_TEXTWAVE1 = 156;
/*     */   public static final short ST_TEXTWAVE2 = 157;
/*     */   public static final short ST_TEXTWAVE3 = 158;
/*     */   public static final short ST_TEXTWAVE4 = 159;
/*     */   public static final short ST_TEXTINFLATE = 160;
/*     */   public static final short ST_TEXTDEFLATE = 161;
/*     */   public static final short ST_TEXTINFLATEBOTTOM = 162;
/*     */   public static final short ST_TEXTDEFLATEBOTTOM = 163;
/*     */   public static final short ST_TEXTINFLATETOP = 164;
/*     */   public static final short ST_TEXTDEFLATETOP = 165;
/*     */   public static final short ST_TEXTDEFLATEINFLATE = 166;
/*     */   public static final short ST_TEXTDEFLATEINFLATEDEFLATE = 167;
/*     */   public static final short ST_TEXTFADERIGHT = 168;
/*     */   public static final short ST_TEXTFADELEFT = 169;
/*     */   public static final short ST_TEXTFADEUP = 170;
/*     */   public static final short ST_TEXTFADEDOWN = 171;
/*     */   public static final short ST_TEXTSLANTUP = 172;
/*     */   public static final short ST_TEXTSLANTDOWN = 173;
/*     */   public static final short ST_TEXTCANUP = 174;
/*     */   public static final short ST_TEXTCANDOWN = 175;
/*     */   public static final short ST_FLOWCHARTALTERNATEPROCESS = 176;
/*     */   public static final short ST_FLOWCHARTOFFPAGECONNECTOR = 177;
/*     */   public static final short ST_CALLOUT90 = 178;
/*     */   public static final short ST_ACCENTCALLOUT90 = 179;
/*     */   public static final short ST_BORDERCALLOUT90 = 180;
/*     */   public static final short ST_ACCENTBORDERCALLOUT90 = 181;
/*     */   public static final short ST_LEFTRIGHTUPARROW = 182;
/*     */   public static final short ST_SUN = 183;
/*     */   public static final short ST_MOON = 184;
/*     */   public static final short ST_BRACKETPAIR = 185;
/*     */   public static final short ST_BRACEPAIR = 186;
/*     */   public static final short ST_SEAL4 = 187;
/*     */   public static final short ST_DOUBLEWAVE = 188;
/*     */   public static final short ST_ACTIONBUTTONBLANK = 189;
/*     */   public static final short ST_ACTIONBUTTONHOME = 190;
/*     */   public static final short ST_ACTIONBUTTONHELP = 191;
/*     */   public static final short ST_ACTIONBUTTONINFORMATION = 192;
/*     */   public static final short ST_ACTIONBUTTONFORWARDNEXT = 193;
/*     */   public static final short ST_ACTIONBUTTONBACKPREVIOUS = 194;
/*     */   public static final short ST_ACTIONBUTTONEND = 195;
/*     */   public static final short ST_ACTIONBUTTONBEGINNING = 196;
/*     */   public static final short ST_ACTIONBUTTONRETURN = 197;
/*     */   public static final short ST_ACTIONBUTTONDOCUMENT = 198;
/*     */   public static final short ST_ACTIONBUTTONSOUND = 199;
/*     */   public static final short ST_ACTIONBUTTONMOVIE = 200;
/*     */   public static final short ST_HOSTCONTROL = 201;
/*     */   public static final short ST_TEXTBOX = 202;
/*     */   public static final short ST_NIL = 4095;
/*     */   protected HSSFPatriarch patriarch;
/* 289 */   private Map<EscherRecord, Record> shapeToObj = new HashMap();
/*     */   
/*     */ 
/*     */   private DrawingManager2 drawingManager;
/*     */   
/*     */   private short drawingGroupId;
/*     */   
/* 296 */   private List tailRec = new ArrayList();
/*     */   
/*     */   public EscherAggregate(DrawingManager2 drawingManager)
/*     */   {
/* 300 */     this.drawingManager = drawingManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 308 */     return 9876;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 317 */     String nl = System.getProperty("line.separtor");
/*     */     
/* 319 */     StringBuffer result = new StringBuffer();
/* 320 */     result.append('[').append(getRecordName()).append(']' + nl);
/* 321 */     for (Iterator iterator = getEscherRecords().iterator(); iterator.hasNext();)
/*     */     {
/* 323 */       EscherRecord escherRecord = (EscherRecord)iterator.next();
/* 324 */       result.append(escherRecord.toString());
/*     */     }
/* 326 */     result.append("[/").append(getRecordName()).append(']' + nl);
/*     */     
/* 328 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EscherAggregate createAggregate(List records, int locFirstDrawingRecord, DrawingManager2 drawingManager)
/*     */   {
/* 338 */     List<EscherRecord> shapeRecords = new ArrayList();
/* 339 */     EscherRecordFactory recordFactory = new DefaultEscherRecordFactory()
/*     */     {
/*     */       public EscherRecord createRecord(byte[] data, int offset)
/*     */       {
/* 343 */         EscherRecord r = super.createRecord(data, offset);
/* 344 */         if ((r.getRecordId() == 61457) || (r.getRecordId() == 61453))
/*     */         {
/* 346 */           this.val$shapeRecords.add(r);
/*     */         }
/* 348 */         return r;
/*     */       }
/*     */       
/*     */ 
/* 352 */     };
/* 353 */     EscherAggregate agg = new EscherAggregate(drawingManager);
/* 354 */     int loc = locFirstDrawingRecord;
/* 355 */     int dataSize = 0;
/*     */     
/*     */ 
/* 358 */     while ((loc + 1 < records.size()) && (sid(records, loc) == 236) && (isObjectRecord(records, loc + 1)))
/*     */     {
/* 360 */       dataSize += ((DrawingRecord)records.get(loc)).getData().length;
/* 361 */       loc += 2;
/*     */     }
/*     */     
/*     */ 
/* 365 */     byte[] buffer = new byte[dataSize];
/* 366 */     int offset = 0;
/* 367 */     loc = locFirstDrawingRecord;
/*     */     
/*     */ 
/* 370 */     while ((loc + 1 < records.size()) && (sid(records, loc) == 236) && (isObjectRecord(records, loc + 1)))
/*     */     {
/* 372 */       DrawingRecord drawingRecord = (DrawingRecord)records.get(loc);
/* 373 */       System.arraycopy(drawingRecord.getData(), 0, buffer, offset, drawingRecord.getData().length);
/* 374 */       offset += drawingRecord.getData().length;
/* 375 */       loc += 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 380 */     int pos = 0;
/* 381 */     while (pos < dataSize)
/*     */     {
/* 383 */       EscherRecord r = recordFactory.createRecord(buffer, pos);
/* 384 */       int bytesRead = r.fillFields(buffer, pos, recordFactory);
/* 385 */       agg.addEscherRecord(r);
/* 386 */       pos += bytesRead;
/*     */     }
/*     */     
/*     */ 
/* 390 */     loc = locFirstDrawingRecord;
/* 391 */     int shapeIndex = 0;
/* 392 */     agg.shapeToObj = new HashMap();
/*     */     
/*     */ 
/* 395 */     while ((loc + 1 < records.size()) && (sid(records, loc) == 236) && (isObjectRecord(records, loc + 1)))
/*     */     {
/* 397 */       Record objRecord = (Record)records.get(loc + 1);
/* 398 */       agg.shapeToObj.put(shapeRecords.get(shapeIndex++), objRecord);
/* 399 */       loc += 2;
/*     */     }
/*     */     
/* 402 */     return agg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int serialize(int offset, byte[] data)
/*     */   {
/* 416 */     convertUserModelToRecords();
/*     */     
/*     */ 
/* 419 */     List records = getEscherRecords();
/* 420 */     int size = getEscherRecordSize(records);
/* 421 */     byte[] buffer = new byte[size];
/*     */     
/*     */ 
/*     */ 
/* 425 */     final List spEndingOffsets = new ArrayList();
/* 426 */     final List shapes = new ArrayList();
/* 427 */     int pos = 0;
/* 428 */     for (Iterator iterator = records.iterator(); iterator.hasNext();)
/*     */     {
/* 430 */       EscherRecord e = (EscherRecord)iterator.next();
/* 431 */       pos += e.serialize(pos, buffer, new EscherSerializationListener()
/*     */       {
/*     */         public void beforeRecordSerialize(int offset, short recordId, EscherRecord record) {}
/*     */         
/*     */ 
/*     */ 
/*     */         public void afterRecordSerialize(int offset, short recordId, int size, EscherRecord record)
/*     */         {
/* 439 */           if ((recordId == 61457) || (recordId == 61453))
/*     */           {
/* 441 */             spEndingOffsets.add(Integer.valueOf(offset));
/* 442 */             shapes.add(record);
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 448 */     shapes.add(0, null);
/* 449 */     spEndingOffsets.add(0, null);
/*     */     
/*     */ 
/*     */ 
/* 453 */     pos = offset;
/* 454 */     for (int i = 1; i < shapes.size(); i++)
/*     */     {
/* 456 */       int endOffset = ((Integer)spEndingOffsets.get(i)).intValue() - 1;
/*     */       int startOffset;
/* 458 */       int startOffset; if (i == 1) {
/* 459 */         startOffset = 0;
/*     */       } else {
/* 461 */         startOffset = ((Integer)spEndingOffsets.get(i - 1)).intValue();
/*     */       }
/*     */       
/* 464 */       DrawingRecord drawing = new DrawingRecord();
/* 465 */       byte[] drawingData = new byte[endOffset - startOffset + 1];
/* 466 */       System.arraycopy(buffer, startOffset, drawingData, 0, drawingData.length);
/* 467 */       drawing.setData(drawingData);
/* 468 */       int temp = drawing.serialize(pos, data);
/* 469 */       pos += temp;
/*     */       
/*     */ 
/* 472 */       Record obj = (Record)this.shapeToObj.get(shapes.get(i));
/* 473 */       temp = obj.serialize(pos, data);
/* 474 */       pos += temp;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 479 */     for (int i = 0; i < this.tailRec.size(); i++)
/*     */     {
/* 481 */       Record rec = (Record)this.tailRec.get(i);
/* 482 */       pos += rec.serialize(pos, data);
/*     */     }
/*     */     
/* 485 */     int bytesWritten = pos - offset;
/* 486 */     if (bytesWritten != getRecordSize())
/* 487 */       throw new RecordFormatException(bytesWritten + " bytes written but getRecordSize() reports " + getRecordSize());
/* 488 */     return bytesWritten;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getEscherRecordSize(List records)
/*     */   {
/* 498 */     int size = 0;
/* 499 */     for (Iterator iterator = records.iterator(); iterator.hasNext();)
/* 500 */       size += ((EscherRecord)iterator.next()).getRecordSize();
/* 501 */     return size;
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/* 506 */     convertUserModelToRecords();
/* 507 */     List records = getEscherRecords();
/* 508 */     int rawEscherSize = getEscherRecordSize(records);
/* 509 */     int drawingRecordSize = rawEscherSize + this.shapeToObj.size() * 4;
/* 510 */     int objRecordSize = 0;
/* 511 */     for (Iterator iterator = this.shapeToObj.values().iterator(); iterator.hasNext();)
/*     */     {
/* 513 */       Record r = (Record)iterator.next();
/* 514 */       objRecordSize += r.getRecordSize();
/*     */     }
/* 516 */     int tailRecordSize = 0;
/* 517 */     for (Iterator iterator = this.tailRec.iterator(); iterator.hasNext();)
/*     */     {
/* 519 */       Record r = (Record)iterator.next();
/* 520 */       tailRecordSize += r.getRecordSize();
/*     */     }
/* 522 */     return drawingRecordSize + objRecordSize + tailRecordSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Object associateShapeToObjRecord(EscherRecord r, ObjRecord objRecord)
/*     */   {
/* 530 */     return this.shapeToObj.put(r, objRecord);
/*     */   }
/*     */   
/*     */   public HSSFPatriarch getPatriarch()
/*     */   {
/* 535 */     return this.patriarch;
/*     */   }
/*     */   
/*     */   public void setPatriarch(HSSFPatriarch patriarch)
/*     */   {
/* 540 */     this.patriarch = patriarch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void convertRecordsToUserModel()
/*     */   {
/* 548 */     if (this.patriarch == null) {
/* 549 */       throw new IllegalStateException("Must call setPatriarch() first");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 555 */     EscherContainerRecord topContainer = getEscherContainer();
/* 556 */     if (topContainer == null) {
/* 557 */       return;
/*     */     }
/* 559 */     topContainer = (EscherContainerRecord)topContainer.getChildContainers().get(0);
/*     */     
/* 561 */     List tcc = topContainer.getChildContainers();
/* 562 */     if (tcc.size() == 0) {
/* 563 */       throw new IllegalStateException("No child escher containers at the point that should hold the patriach data, and one container per top level shape!");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 569 */     EscherContainerRecord patriachContainer = (EscherContainerRecord)tcc.get(0);
/*     */     
/* 571 */     EscherSpgrRecord spgr = null;
/* 572 */     for (Iterator<EscherRecord> it = patriachContainer.getChildIterator(); it.hasNext();) {
/* 573 */       EscherRecord r = (EscherRecord)it.next();
/* 574 */       if ((r instanceof EscherSpgrRecord)) {
/* 575 */         spgr = (EscherSpgrRecord)r;
/* 576 */         break;
/*     */       }
/*     */     }
/* 579 */     if (spgr != null) {
/* 580 */       this.patriarch.setCoordinates(spgr.getRectX1(), spgr.getRectY1(), spgr.getRectX2(), spgr.getRectY2());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 588 */     for (int i = 1; i < tcc.size(); i++) {
/* 589 */       EscherContainerRecord shapeContainer = (EscherContainerRecord)tcc.get(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 596 */       if (shapeContainer.getRecordId() == 61443)
/*     */       {
/*     */ 
/* 599 */         if (shapeContainer.getChildRecords().size() > 0)
/*     */         {
/* 601 */           HSSFShapeGroup group = new HSSFShapeGroup(null, new HSSFClientAnchor());
/*     */           
/* 603 */           this.patriarch.getChildren().add(group);
/*     */           
/* 605 */           EscherContainerRecord groupContainer = (EscherContainerRecord)shapeContainer.getChild(0);
/*     */           
/* 607 */           convertRecordsToUserModel(groupContainer, group);
/*     */         }
/*     */         else {
/* 610 */           log.log(POILogger.WARN, "Found drawing group without children.");
/*     */         }
/*     */         
/*     */       }
/* 614 */       else if (shapeContainer.getRecordId() == 61444)
/*     */       {
/* 616 */         EscherSpRecord spRecord = shapeContainer.getChildById((short)61450);
/*     */         
/* 618 */         int type = spRecord.getOptions() >> 4;
/*     */         
/* 620 */         switch (type)
/*     */         {
/*     */         case 202: 
/* 623 */           HSSFTextbox box = new HSSFTextbox(null, new HSSFClientAnchor());
/*     */           
/* 625 */           this.patriarch.getChildren().add(box);
/*     */           
/* 627 */           convertRecordsToUserModel(shapeContainer, box);
/* 628 */           break;
/*     */         
/*     */ 
/*     */         case 75: 
/* 632 */           EscherOptRecord opt = (EscherOptRecord)getEscherChild(shapeContainer, 61451);
/*     */           
/* 634 */           EscherSimpleProperty prop = (EscherSimpleProperty)getEscherProperty(opt, 260);
/*     */           
/* 636 */           if (prop == null)
/*     */           {
/* 638 */             log.log(POILogger.WARN, "Picture index for picture shape not found.");
/*     */           }
/*     */           else
/*     */           {
/* 642 */             int pictureIndex = prop.getPropertyValue();
/*     */             
/* 644 */             EscherClientAnchorRecord anchorRecord = (EscherClientAnchorRecord)getEscherChild(shapeContainer, 61456);
/*     */             
/*     */ 
/* 647 */             HSSFClientAnchor anchor = new HSSFClientAnchor();
/* 648 */             anchor.setCol1(anchorRecord.getCol1());
/* 649 */             anchor.setCol2(anchorRecord.getCol2());
/* 650 */             anchor.setDx1(anchorRecord.getDx1());
/* 651 */             anchor.setDx2(anchorRecord.getDx2());
/* 652 */             anchor.setDy1(anchorRecord.getDy1());
/* 653 */             anchor.setDy2(anchorRecord.getDy2());
/* 654 */             anchor.setRow1(anchorRecord.getRow1());
/* 655 */             anchor.setRow2(anchorRecord.getRow2());
/*     */             
/* 657 */             HSSFPicture picture = new HSSFPicture(null, anchor);
/* 658 */             picture.setPictureIndex(pictureIndex);
/* 659 */             this.patriarch.getChildren().add(picture);
/*     */           }
/* 661 */           break;
/*     */         default: 
/* 663 */           log.log(POILogger.WARN, "Unhandled shape type: " + type);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 669 */         log.log(POILogger.WARN, "Unexpected record id of shape group.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 679 */     this.drawingManager.getDgg().setFileIdClusters(new EscherDggRecord.FileIdCluster[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void convertRecordsToUserModel(EscherContainerRecord shapeContainer, Object model)
/*     */   {
/* 687 */     for (Iterator<EscherRecord> it = shapeContainer.getChildIterator(); it.hasNext();) {
/* 688 */       EscherRecord r = (EscherRecord)it.next();
/* 689 */       if ((r instanceof EscherSpgrRecord))
/*     */       {
/* 691 */         EscherSpgrRecord spgr = (EscherSpgrRecord)r;
/*     */         
/* 693 */         if ((model instanceof HSSFShapeGroup)) {
/* 694 */           HSSFShapeGroup g = (HSSFShapeGroup)model;
/* 695 */           g.setCoordinates(spgr.getRectX1(), spgr.getRectY1(), spgr.getRectX2(), spgr.getRectY2());
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 700 */           throw new IllegalStateException("Got top level anchor but not processing a group");
/*     */         }
/*     */       }
/* 703 */       else if ((r instanceof EscherClientAnchorRecord)) {
/* 704 */         EscherClientAnchorRecord car = (EscherClientAnchorRecord)r;
/*     */         
/* 706 */         if ((model instanceof HSSFShape)) {
/* 707 */           HSSFShape g = (HSSFShape)model;
/* 708 */           g.getAnchor().setDx1(car.getDx1());
/* 709 */           g.getAnchor().setDx2(car.getDx2());
/* 710 */           g.getAnchor().setDy1(car.getDy1());
/* 711 */           g.getAnchor().setDy2(car.getDy2());
/*     */         } else {
/* 713 */           throw new IllegalStateException("Got top level anchor but not processing a group or shape");
/*     */         }
/*     */       } else { EscherTextboxRecord tbr;
/* 716 */         if ((r instanceof EscherTextboxRecord)) {
/* 717 */           tbr = (EscherTextboxRecord)r;
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 722 */         else if (!(r instanceof EscherSpRecord))
/*     */         {
/*     */ 
/* 725 */           if (!(r instanceof EscherOptRecord)) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 736 */     clearEscherRecords();
/* 737 */     this.shapeToObj.clear();
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getRecordName()
/*     */   {
/* 743 */     return "ESCHERAGGREGATE";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean isObjectRecord(List records, int loc)
/*     */   {
/* 750 */     return (sid(records, loc) == 93) || (sid(records, loc) == 438);
/*     */   }
/*     */   
/*     */   private void convertUserModelToRecords()
/*     */   {
/* 755 */     if (this.patriarch != null)
/*     */     {
/* 757 */       this.shapeToObj.clear();
/* 758 */       this.tailRec.clear();
/* 759 */       clearEscherRecords();
/* 760 */       if (this.patriarch.getChildren().size() != 0)
/*     */       {
/* 762 */         convertPatriarch(this.patriarch);
/* 763 */         EscherContainerRecord dgContainer = (EscherContainerRecord)getEscherRecord(0);
/* 764 */         EscherContainerRecord spgrContainer = null;
/* 765 */         Iterator<EscherRecord> iter = dgContainer.getChildIterator();
/* 766 */         while (iter.hasNext()) {
/* 767 */           EscherRecord child = (EscherRecord)iter.next();
/* 768 */           if (child.getRecordId() == 61443) {
/* 769 */             spgrContainer = (EscherContainerRecord)child;
/*     */           }
/*     */         }
/* 772 */         convertShapes(this.patriarch, spgrContainer, this.shapeToObj);
/*     */         
/* 774 */         this.patriarch = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void convertShapes(HSSFShapeContainer parent, EscherContainerRecord escherParent, Map shapeToObj)
/*     */   {
/* 781 */     if (escherParent == null) { throw new IllegalArgumentException("Parent record required");
/*     */     }
/* 783 */     List shapes = parent.getChildren();
/* 784 */     for (Iterator iterator = shapes.iterator(); iterator.hasNext();)
/*     */     {
/* 786 */       HSSFShape shape = (HSSFShape)iterator.next();
/* 787 */       if ((shape instanceof HSSFShapeGroup))
/*     */       {
/* 789 */         convertGroup((HSSFShapeGroup)shape, escherParent, shapeToObj);
/*     */       }
/*     */       else
/*     */       {
/* 793 */         AbstractShape shapeModel = AbstractShape.createShape(shape, this.drawingManager.allocateShapeId(this.drawingGroupId));
/*     */         
/*     */ 
/* 796 */         shapeToObj.put(findClientData(shapeModel.getSpContainer()), shapeModel.getObjRecord());
/* 797 */         if ((shapeModel instanceof TextboxShape))
/*     */         {
/* 799 */           EscherRecord escherTextbox = ((TextboxShape)shapeModel).getEscherTextbox();
/* 800 */           shapeToObj.put(escherTextbox, ((TextboxShape)shapeModel).getTextObjectRecord());
/*     */           
/*     */ 
/* 803 */           if ((shapeModel instanceof CommentShape)) {
/* 804 */             CommentShape comment = (CommentShape)shapeModel;
/* 805 */             this.tailRec.add(comment.getNoteRecord());
/*     */           }
/*     */         }
/*     */         
/* 809 */         escherParent.addChildRecord(shapeModel.getSpContainer());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void convertGroup(HSSFShapeGroup shape, EscherContainerRecord escherParent, Map shapeToObj)
/*     */   {
/* 819 */     EscherContainerRecord spgrContainer = new EscherContainerRecord();
/* 820 */     EscherContainerRecord spContainer = new EscherContainerRecord();
/* 821 */     EscherSpgrRecord spgr = new EscherSpgrRecord();
/* 822 */     EscherSpRecord sp = new EscherSpRecord();
/* 823 */     EscherOptRecord opt = new EscherOptRecord();
/*     */     
/* 825 */     EscherClientDataRecord clientData = new EscherClientDataRecord();
/*     */     
/* 827 */     spgrContainer.setRecordId((short)61443);
/* 828 */     spgrContainer.setOptions((short)15);
/* 829 */     spContainer.setRecordId((short)61444);
/* 830 */     spContainer.setOptions((short)15);
/* 831 */     spgr.setRecordId((short)61449);
/* 832 */     spgr.setOptions((short)1);
/* 833 */     spgr.setRectX1(shape.getX1());
/* 834 */     spgr.setRectY1(shape.getY1());
/* 835 */     spgr.setRectX2(shape.getX2());
/* 836 */     spgr.setRectY2(shape.getY2());
/* 837 */     sp.setRecordId((short)61450);
/* 838 */     sp.setOptions((short)2);
/* 839 */     int shapeId = this.drawingManager.allocateShapeId(this.drawingGroupId);
/* 840 */     sp.setShapeId(shapeId);
/* 841 */     if ((shape.getAnchor() instanceof HSSFClientAnchor)) {
/* 842 */       sp.setFlags(513);
/*     */     } else
/* 844 */       sp.setFlags(515);
/* 845 */     opt.setRecordId((short)61451);
/* 846 */     opt.setOptions((short)35);
/* 847 */     opt.addEscherProperty(new EscherBoolProperty((short)127, 262148));
/* 848 */     opt.addEscherProperty(new EscherBoolProperty((short)959, 524288));
/*     */     
/* 850 */     EscherRecord anchor = ConvertAnchor.createAnchor(shape.getAnchor());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 859 */     clientData.setRecordId((short)61457);
/* 860 */     clientData.setOptions((short)0);
/*     */     
/* 862 */     spgrContainer.addChildRecord(spContainer);
/* 863 */     spContainer.addChildRecord(spgr);
/* 864 */     spContainer.addChildRecord(sp);
/* 865 */     spContainer.addChildRecord(opt);
/* 866 */     spContainer.addChildRecord(anchor);
/* 867 */     spContainer.addChildRecord(clientData);
/*     */     
/* 869 */     ObjRecord obj = new ObjRecord();
/* 870 */     CommonObjectDataSubRecord cmo = new CommonObjectDataSubRecord();
/* 871 */     cmo.setObjectType((short)0);
/* 872 */     cmo.setObjectId(shapeId);
/* 873 */     cmo.setLocked(true);
/* 874 */     cmo.setPrintable(true);
/* 875 */     cmo.setAutofill(true);
/* 876 */     cmo.setAutoline(true);
/* 877 */     GroupMarkerSubRecord gmo = new GroupMarkerSubRecord();
/* 878 */     EndSubRecord end = new EndSubRecord();
/* 879 */     obj.addSubRecord(cmo);
/* 880 */     obj.addSubRecord(gmo);
/* 881 */     obj.addSubRecord(end);
/* 882 */     shapeToObj.put(clientData, obj);
/*     */     
/* 884 */     escherParent.addChildRecord(spgrContainer);
/*     */     
/* 886 */     convertShapes(shape, spgrContainer, shapeToObj);
/*     */   }
/*     */   
/*     */ 
/*     */   private EscherRecord findClientData(EscherContainerRecord spContainer)
/*     */   {
/* 892 */     for (Iterator<EscherRecord> iterator = spContainer.getChildIterator(); iterator.hasNext();) {
/* 893 */       EscherRecord r = (EscherRecord)iterator.next();
/* 894 */       if (r.getRecordId() == 61457) {
/* 895 */         return r;
/*     */       }
/*     */     }
/* 898 */     throw new IllegalArgumentException("Can not find client data record");
/*     */   }
/*     */   
/*     */   private void convertPatriarch(HSSFPatriarch patriarch)
/*     */   {
/* 903 */     EscherContainerRecord dgContainer = new EscherContainerRecord();
/*     */     
/* 905 */     EscherContainerRecord spgrContainer = new EscherContainerRecord();
/* 906 */     EscherContainerRecord spContainer1 = new EscherContainerRecord();
/* 907 */     EscherSpgrRecord spgr = new EscherSpgrRecord();
/* 908 */     EscherSpRecord sp1 = new EscherSpRecord();
/*     */     
/* 910 */     dgContainer.setRecordId((short)61442);
/* 911 */     dgContainer.setOptions((short)15);
/* 912 */     EscherDgRecord dg = this.drawingManager.createDgRecord();
/* 913 */     this.drawingGroupId = dg.getDrawingGroupId();
/*     */     
/*     */ 
/*     */ 
/* 917 */     spgrContainer.setRecordId((short)61443);
/* 918 */     spgrContainer.setOptions((short)15);
/* 919 */     spContainer1.setRecordId((short)61444);
/* 920 */     spContainer1.setOptions((short)15);
/* 921 */     spgr.setRecordId((short)61449);
/* 922 */     spgr.setOptions((short)1);
/* 923 */     spgr.setRectX1(patriarch.getX1());
/* 924 */     spgr.setRectY1(patriarch.getY1());
/* 925 */     spgr.setRectX2(patriarch.getX2());
/* 926 */     spgr.setRectY2(patriarch.getY2());
/* 927 */     sp1.setRecordId((short)61450);
/* 928 */     sp1.setOptions((short)2);
/* 929 */     sp1.setShapeId(this.drawingManager.allocateShapeId(dg.getDrawingGroupId()));
/* 930 */     sp1.setFlags(5);
/*     */     
/* 932 */     dgContainer.addChildRecord(dg);
/* 933 */     dgContainer.addChildRecord(spgrContainer);
/* 934 */     spgrContainer.addChildRecord(spContainer1);
/* 935 */     spContainer1.addChildRecord(spgr);
/* 936 */     spContainer1.addChildRecord(sp1);
/*     */     
/* 938 */     addEscherRecord(dgContainer);
/*     */   }
/*     */   
/*     */ 
/*     */   private static short sid(List records, int loc)
/*     */   {
/* 944 */     return ((Record)records.get(loc)).getSid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static EscherRecord getEscherChild(EscherContainerRecord owner, int recordId)
/*     */   {
/* 958 */     Iterator iterator = owner.getChildRecords().iterator();
/* 959 */     while (iterator.hasNext())
/*     */     {
/* 961 */       EscherRecord escherRecord = (EscherRecord)iterator.next();
/* 962 */       if (escherRecord.getRecordId() == recordId)
/* 963 */         return escherRecord;
/*     */     }
/* 965 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static EscherProperty getEscherProperty(EscherOptRecord opt, int propId)
/*     */   {
/* 976 */     if (opt != null) {
/* 977 */       Iterator iterator = opt.getEscherProperties().iterator();
/* 978 */       while (iterator.hasNext())
/*     */       {
/* 980 */         EscherProperty prop = (EscherProperty)iterator.next();
/* 981 */         if (prop.getPropertyNumber() == propId)
/* 982 */           return prop;
/*     */       } }
/* 984 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\EscherAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */