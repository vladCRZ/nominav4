/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtSSTRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 255;
/*     */   public static final int DEFAULT_BUCKET_SIZE = 8;
/*     */   public static final int MAX_BUCKETS = 128;
/*     */   private short _stringsPerBucket;
/*     */   private InfoSubRecord[] _sstInfos;
/*     */   
/*     */   private static final class InfoSubRecord
/*     */   {
/*     */     public static final int ENCODED_SIZE = 8;
/*     */     private int field_1_stream_pos;
/*     */     private int field_2_bucket_sst_offset;
/*     */     private short field_3_zero;
/*     */     
/*     */     public InfoSubRecord(int streamPos, int bucketSstOffset)
/*     */     {
/*  50 */       this.field_1_stream_pos = streamPos;
/*  51 */       this.field_2_bucket_sst_offset = bucketSstOffset;
/*     */     }
/*     */     
/*     */     public InfoSubRecord(RecordInputStream in)
/*     */     {
/*  56 */       this.field_1_stream_pos = in.readInt();
/*  57 */       this.field_2_bucket_sst_offset = in.readShort();
/*  58 */       this.field_3_zero = in.readShort();
/*     */     }
/*     */     
/*     */     public int getStreamPos() {
/*  62 */       return this.field_1_stream_pos;
/*     */     }
/*     */     
/*     */     public int getBucketSSTOffset() {
/*  66 */       return this.field_2_bucket_sst_offset;
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  70 */       out.writeInt(this.field_1_stream_pos);
/*  71 */       out.writeShort(this.field_2_bucket_sst_offset);
/*  72 */       out.writeShort(this.field_3_zero);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtSSTRecord()
/*     */   {
/*  82 */     this._stringsPerBucket = 8;
/*  83 */     this._sstInfos = new InfoSubRecord[0];
/*     */   }
/*     */   
/*     */   public ExtSSTRecord(RecordInputStream in) {
/*  87 */     this._stringsPerBucket = in.readShort();
/*  88 */     int nInfos = in.remaining() / 8;
/*  89 */     this._sstInfos = new InfoSubRecord[nInfos];
/*  90 */     for (int i = 0; i < this._sstInfos.length; i++) {
/*  91 */       this._sstInfos[i] = new InfoSubRecord(in);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setNumStringsPerBucket(short numStrings) {
/*  96 */     this._stringsPerBucket = numStrings;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 100 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 102 */     buffer.append("[EXTSST]\n");
/* 103 */     buffer.append("    .dsst           = ").append(Integer.toHexString(this._stringsPerBucket)).append("\n");
/*     */     
/*     */ 
/* 106 */     buffer.append("    .numInfoRecords = ").append(this._sstInfos.length).append("\n");
/*     */     
/* 108 */     for (int k = 0; k < this._sstInfos.length; k++)
/*     */     {
/* 110 */       buffer.append("    .inforecord     = ").append(k).append("\n");
/* 111 */       buffer.append("    .streampos      = ").append(Integer.toHexString(this._sstInfos[k].getStreamPos())).append("\n");
/*     */       
/*     */ 
/* 114 */       buffer.append("    .sstoffset      = ").append(Integer.toHexString(this._sstInfos[k].getBucketSSTOffset())).append("\n");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 119 */     buffer.append("[/EXTSST]\n");
/* 120 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 124 */     out.writeShort(this._stringsPerBucket);
/* 125 */     for (int k = 0; k < this._sstInfos.length; k++)
/* 126 */       this._sstInfos[k].serialize(out);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 130 */     return 2 + 8 * this._sstInfos.length;
/*     */   }
/*     */   
/*     */   public static final int getNumberOfInfoRecsForStrings(int numStrings) {
/* 134 */     int infoRecs = numStrings / 8;
/* 135 */     if (numStrings % 8 != 0) {
/* 136 */       infoRecs++;
/*     */     }
/*     */     
/* 139 */     if (infoRecs > 128)
/* 140 */       infoRecs = 128;
/* 141 */     return infoRecs;
/*     */   }
/*     */   
/*     */   public static final int getRecordSizeForStrings(int numStrings)
/*     */   {
/* 146 */     return 6 + getNumberOfInfoRecsForStrings(numStrings) * 8;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 150 */     return 255;
/*     */   }
/*     */   
/*     */   public void setBucketOffsets(int[] bucketAbsoluteOffsets, int[] bucketRelativeOffsets)
/*     */   {
/* 155 */     this._sstInfos = new InfoSubRecord[bucketAbsoluteOffsets.length];
/* 156 */     for (int i = 0; i < bucketAbsoluteOffsets.length; i++) {
/* 157 */       this._sstInfos[i] = new InfoSubRecord(bucketAbsoluteOffsets[i], bucketRelativeOffsets[i]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ExtSSTRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */