/*      */ package org.apache.poi.hssf.record;
/*      */ 
/*      */ import org.apache.poi.util.BitField;
/*      */ import org.apache.poi.util.BitFieldFactory;
/*      */ import org.apache.poi.util.LittleEndianOutput;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ExtendedFormatRecord
/*      */   extends StandardRecord
/*      */ {
/*      */   public static final short sid = 224;
/*      */   public static final short NULL = -16;
/*      */   public static final short XF_STYLE = 1;
/*      */   public static final short XF_CELL = 0;
/*      */   public static final short NONE = 0;
/*      */   public static final short THIN = 1;
/*      */   public static final short MEDIUM = 2;
/*      */   public static final short DASHED = 3;
/*      */   public static final short DOTTED = 4;
/*      */   public static final short THICK = 5;
/*      */   public static final short DOUBLE = 6;
/*      */   public static final short HAIR = 7;
/*      */   public static final short MEDIUM_DASHED = 8;
/*      */   public static final short DASH_DOT = 9;
/*      */   public static final short MEDIUM_DASH_DOT = 10;
/*      */   public static final short DASH_DOT_DOT = 11;
/*      */   public static final short MEDIUM_DASH_DOT_DOT = 12;
/*      */   public static final short SLANTED_DASH_DOT = 13;
/*      */   public static final short GENERAL = 0;
/*      */   public static final short LEFT = 1;
/*      */   public static final short CENTER = 2;
/*      */   public static final short RIGHT = 3;
/*      */   public static final short FILL = 4;
/*      */   public static final short JUSTIFY = 5;
/*      */   public static final short CENTER_SELECTION = 6;
/*      */   public static final short VERTICAL_TOP = 0;
/*      */   public static final short VERTICAL_CENTER = 1;
/*      */   public static final short VERTICAL_BOTTOM = 2;
/*      */   public static final short VERTICAL_JUSTIFY = 3;
/*      */   public static final short NO_FILL = 0;
/*      */   public static final short SOLID_FILL = 1;
/*      */   public static final short FINE_DOTS = 2;
/*      */   public static final short ALT_BARS = 3;
/*      */   public static final short SPARSE_DOTS = 4;
/*      */   public static final short THICK_HORZ_BANDS = 5;
/*      */   public static final short THICK_VERT_BANDS = 6;
/*      */   public static final short THICK_BACKWARD_DIAG = 7;
/*      */   public static final short THICK_FORWARD_DIAG = 8;
/*      */   public static final short BIG_SPOTS = 9;
/*      */   public static final short BRICKS = 10;
/*      */   public static final short THIN_HORZ_BANDS = 11;
/*      */   public static final short THIN_VERT_BANDS = 12;
/*      */   public static final short THIN_BACKWARD_DIAG = 13;
/*      */   public static final short THIN_FORWARD_DIAG = 14;
/*      */   public static final short SQUARES = 15;
/*      */   public static final short DIAMONDS = 16;
/*      */   private short field_1_font_index;
/*      */   private short field_2_format_index;
/*  109 */   private static final BitField _locked = BitFieldFactory.getInstance(1);
/*  110 */   private static final BitField _hidden = BitFieldFactory.getInstance(2);
/*  111 */   private static final BitField _xf_type = BitFieldFactory.getInstance(4);
/*  112 */   private static final BitField _123_prefix = BitFieldFactory.getInstance(8);
/*  113 */   private static final BitField _parent_index = BitFieldFactory.getInstance(65520);
/*      */   
/*      */   private short field_3_cell_options;
/*      */   
/*  117 */   private static final BitField _alignment = BitFieldFactory.getInstance(7);
/*  118 */   private static final BitField _wrap_text = BitFieldFactory.getInstance(8);
/*  119 */   private static final BitField _vertical_alignment = BitFieldFactory.getInstance(112);
/*  120 */   private static final BitField _justify_last = BitFieldFactory.getInstance(128);
/*  121 */   private static final BitField _rotation = BitFieldFactory.getInstance(65280);
/*      */   
/*      */   private short field_4_alignment_options;
/*      */   
/*  125 */   private static final BitField _indent = BitFieldFactory.getInstance(15);
/*      */   
/*  127 */   private static final BitField _shrink_to_fit = BitFieldFactory.getInstance(16);
/*      */   
/*  129 */   private static final BitField _merge_cells = BitFieldFactory.getInstance(32);
/*      */   
/*  131 */   private static final BitField _reading_order = BitFieldFactory.getInstance(192);
/*      */   
/*      */ 
/*      */ 
/*  135 */   private static final BitField _indent_not_parent_format = BitFieldFactory.getInstance(1024);
/*      */   
/*  137 */   private static final BitField _indent_not_parent_font = BitFieldFactory.getInstance(2048);
/*      */   
/*  139 */   private static final BitField _indent_not_parent_alignment = BitFieldFactory.getInstance(4096);
/*      */   
/*  141 */   private static final BitField _indent_not_parent_border = BitFieldFactory.getInstance(8192);
/*      */   
/*  143 */   private static final BitField _indent_not_parent_pattern = BitFieldFactory.getInstance(16384);
/*      */   
/*  145 */   private static final BitField _indent_not_parent_cell_options = BitFieldFactory.getInstance(32768);
/*      */   
/*      */ 
/*      */   private short field_5_indention_options;
/*      */   
/*  150 */   private static final BitField _border_left = BitFieldFactory.getInstance(15);
/*  151 */   private static final BitField _border_right = BitFieldFactory.getInstance(240);
/*  152 */   private static final BitField _border_top = BitFieldFactory.getInstance(3840);
/*  153 */   private static final BitField _border_bottom = BitFieldFactory.getInstance(61440);
/*      */   
/*      */ 
/*      */   private short field_6_border_options;
/*      */   
/*  158 */   private static final BitField _left_border_palette_idx = BitFieldFactory.getInstance(127);
/*      */   
/*  160 */   private static final BitField _right_border_palette_idx = BitFieldFactory.getInstance(16256);
/*      */   
/*  162 */   private static final BitField _diag = BitFieldFactory.getInstance(49152);
/*      */   
/*      */ 
/*      */   private short field_7_palette_options;
/*      */   
/*  167 */   private static final BitField _top_border_palette_idx = BitFieldFactory.getInstance(127);
/*      */   
/*  169 */   private static final BitField _bottom_border_palette_idx = BitFieldFactory.getInstance(16256);
/*      */   
/*  171 */   private static final BitField _adtl_diag = BitFieldFactory.getInstance(2080768);
/*      */   
/*  173 */   private static final BitField _adtl_diag_line_style = BitFieldFactory.getInstance(31457280);
/*      */   
/*      */ 
/*      */ 
/*  177 */   private static final BitField _adtl_fill_pattern = BitFieldFactory.getInstance(-67108864);
/*      */   
/*      */ 
/*      */   private int field_8_adtl_palette_options;
/*      */   
/*  182 */   private static final BitField _fill_foreground = BitFieldFactory.getInstance(127);
/*  183 */   private static final BitField _fill_background = BitFieldFactory.getInstance(16256);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private short field_9_fill_palette_options;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ExtendedFormatRecord() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ExtendedFormatRecord(RecordInputStream in)
/*      */   {
/*  200 */     this.field_1_font_index = in.readShort();
/*  201 */     this.field_2_format_index = in.readShort();
/*  202 */     this.field_3_cell_options = in.readShort();
/*  203 */     this.field_4_alignment_options = in.readShort();
/*  204 */     this.field_5_indention_options = in.readShort();
/*  205 */     this.field_6_border_options = in.readShort();
/*  206 */     this.field_7_palette_options = in.readShort();
/*  207 */     this.field_8_adtl_palette_options = in.readInt();
/*  208 */     this.field_9_fill_palette_options = in.readShort();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFontIndex(short index)
/*      */   {
/*  221 */     this.field_1_font_index = index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFormatIndex(short index)
/*      */   {
/*  234 */     this.field_2_format_index = index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCellOptions(short options)
/*      */   {
/*  248 */     this.field_3_cell_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocked(boolean locked)
/*      */   {
/*  263 */     this.field_3_cell_options = _locked.setShortBoolean(this.field_3_cell_options, locked);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHidden(boolean hidden)
/*      */   {
/*  277 */     this.field_3_cell_options = _hidden.setShortBoolean(this.field_3_cell_options, hidden);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXFType(short type)
/*      */   {
/*  293 */     this.field_3_cell_options = _xf_type.setShortValue(this.field_3_cell_options, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void set123Prefix(boolean prefix)
/*      */   {
/*  307 */     this.field_3_cell_options = _123_prefix.setShortBoolean(this.field_3_cell_options, prefix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParentIndex(short parent)
/*      */   {
/*  324 */     this.field_3_cell_options = _parent_index.setShortValue(this.field_3_cell_options, parent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlignmentOptions(short options)
/*      */   {
/*  340 */     this.field_4_alignment_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlignment(short align)
/*      */   {
/*  360 */     this.field_4_alignment_options = _alignment.setShortValue(this.field_4_alignment_options, align);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWrapText(boolean wrapped)
/*      */   {
/*  374 */     this.field_4_alignment_options = _wrap_text.setShortBoolean(this.field_4_alignment_options, wrapped);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVerticalAlignment(short align)
/*      */   {
/*  393 */     this.field_4_alignment_options = _vertical_alignment.setShortValue(this.field_4_alignment_options, align);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJustifyLast(short justify)
/*      */   {
/*  409 */     this.field_4_alignment_options = _justify_last.setShortValue(this.field_4_alignment_options, justify);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRotation(short rotation)
/*      */   {
/*  423 */     this.field_4_alignment_options = _rotation.setShortValue(this.field_4_alignment_options, rotation);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentionOptions(short options)
/*      */   {
/*  438 */     this.field_5_indention_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndent(short indent)
/*      */   {
/*  452 */     this.field_5_indention_options = _indent.setShortValue(this.field_5_indention_options, indent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShrinkToFit(boolean shrink)
/*      */   {
/*  466 */     this.field_5_indention_options = _shrink_to_fit.setShortBoolean(this.field_5_indention_options, shrink);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMergeCells(boolean merge)
/*      */   {
/*  480 */     this.field_5_indention_options = _merge_cells.setShortBoolean(this.field_5_indention_options, merge);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadingOrder(short order)
/*      */   {
/*  494 */     this.field_5_indention_options = _reading_order.setShortValue(this.field_5_indention_options, order);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentNotParentFormat(boolean parent)
/*      */   {
/*  509 */     this.field_5_indention_options = _indent_not_parent_format.setShortBoolean(this.field_5_indention_options, parent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentNotParentFont(boolean font)
/*      */   {
/*  525 */     this.field_5_indention_options = _indent_not_parent_font.setShortBoolean(this.field_5_indention_options, font);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentNotParentAlignment(boolean alignment)
/*      */   {
/*  541 */     this.field_5_indention_options = _indent_not_parent_alignment.setShortBoolean(this.field_5_indention_options, alignment);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentNotParentBorder(boolean border)
/*      */   {
/*  557 */     this.field_5_indention_options = _indent_not_parent_border.setShortBoolean(this.field_5_indention_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentNotParentPattern(boolean pattern)
/*      */   {
/*  573 */     this.field_5_indention_options = _indent_not_parent_pattern.setShortBoolean(this.field_5_indention_options, pattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndentNotParentCellOptions(boolean options)
/*      */   {
/*  589 */     this.field_5_indention_options = _indent_not_parent_cell_options.setShortBoolean(this.field_5_indention_options, options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBorderOptions(short options)
/*      */   {
/*  606 */     this.field_6_border_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBorderLeft(short border)
/*      */   {
/*  635 */     this.field_6_border_options = _border_left.setShortValue(this.field_6_border_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBorderRight(short border)
/*      */   {
/*  663 */     this.field_6_border_options = _border_right.setShortValue(this.field_6_border_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBorderTop(short border)
/*      */   {
/*  691 */     this.field_6_border_options = _border_top.setShortValue(this.field_6_border_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBorderBottom(short border)
/*      */   {
/*  719 */     this.field_6_border_options = _border_bottom.setShortValue(this.field_6_border_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPaletteOptions(short options)
/*      */   {
/*  736 */     this.field_7_palette_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLeftBorderPaletteIdx(short border)
/*      */   {
/*  751 */     this.field_7_palette_options = _left_border_palette_idx.setShortValue(this.field_7_palette_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRightBorderPaletteIdx(short border)
/*      */   {
/*  766 */     this.field_7_palette_options = _right_border_palette_idx.setShortValue(this.field_7_palette_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDiag(short diag)
/*      */   {
/*  784 */     this.field_7_palette_options = _diag.setShortValue(this.field_7_palette_options, diag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdtlPaletteOptions(short options)
/*      */   {
/*  801 */     this.field_8_adtl_palette_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTopBorderPaletteIdx(short border)
/*      */   {
/*  816 */     this.field_8_adtl_palette_options = _top_border_palette_idx.setValue(this.field_8_adtl_palette_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBottomBorderPaletteIdx(short border)
/*      */   {
/*  831 */     this.field_8_adtl_palette_options = _bottom_border_palette_idx.setValue(this.field_8_adtl_palette_options, border);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdtlDiag(short diag)
/*      */   {
/*  847 */     this.field_8_adtl_palette_options = _adtl_diag.setValue(this.field_8_adtl_palette_options, diag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdtlDiagLineStyle(short diag)
/*      */   {
/*  875 */     this.field_8_adtl_palette_options = _adtl_diag_line_style.setValue(this.field_8_adtl_palette_options, diag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdtlFillPattern(short fill)
/*      */   {
/*  907 */     this.field_8_adtl_palette_options = _adtl_fill_pattern.setValue(this.field_8_adtl_palette_options, fill);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFillPaletteOptions(short options)
/*      */   {
/*  923 */     this.field_9_fill_palette_options = options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFillForeground(short color)
/*      */   {
/*  936 */     this.field_9_fill_palette_options = _fill_foreground.setShortValue(this.field_9_fill_palette_options, color);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFillBackground(short color)
/*      */   {
/*  951 */     this.field_9_fill_palette_options = _fill_background.setShortValue(this.field_9_fill_palette_options, color);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getFontIndex()
/*      */   {
/*  966 */     return this.field_1_font_index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getFormatIndex()
/*      */   {
/*  979 */     return this.field_2_format_index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getCellOptions()
/*      */   {
/*  993 */     return this.field_3_cell_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLocked()
/*      */   {
/* 1008 */     return _locked.isSet(this.field_3_cell_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isHidden()
/*      */   {
/* 1021 */     return _hidden.isSet(this.field_3_cell_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getXFType()
/*      */   {
/* 1036 */     return _xf_type.getShortValue(this.field_3_cell_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean get123Prefix()
/*      */   {
/* 1049 */     return _123_prefix.isSet(this.field_3_cell_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getParentIndex()
/*      */   {
/* 1063 */     return _parent_index.getShortValue(this.field_3_cell_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getAlignmentOptions()
/*      */   {
/* 1078 */     return this.field_4_alignment_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getAlignment()
/*      */   {
/* 1100 */     return _alignment.getShortValue(this.field_4_alignment_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getWrapText()
/*      */   {
/* 1113 */     return _wrap_text.isSet(this.field_4_alignment_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getVerticalAlignment()
/*      */   {
/* 1131 */     return _vertical_alignment.getShortValue(this.field_4_alignment_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getJustifyLast()
/*      */   {
/* 1145 */     return _justify_last.getShortValue(this.field_4_alignment_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getRotation()
/*      */   {
/* 1158 */     return _rotation.getShortValue(this.field_4_alignment_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getIndentionOptions()
/*      */   {
/* 1174 */     return this.field_5_indention_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getIndent()
/*      */   {
/* 1188 */     return _indent.getShortValue(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getShrinkToFit()
/*      */   {
/* 1201 */     return _shrink_to_fit.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMergeCells()
/*      */   {
/* 1214 */     return _merge_cells.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getReadingOrder()
/*      */   {
/* 1227 */     return _reading_order.getShortValue(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIndentNotParentFormat()
/*      */   {
/* 1241 */     return _indent_not_parent_format.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIndentNotParentFont()
/*      */   {
/* 1255 */     return _indent_not_parent_font.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIndentNotParentAlignment()
/*      */   {
/* 1269 */     return _indent_not_parent_alignment.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIndentNotParentBorder()
/*      */   {
/* 1283 */     return _indent_not_parent_border.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIndentNotParentPattern()
/*      */   {
/* 1297 */     return _indent_not_parent_pattern.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isIndentNotParentCellOptions()
/*      */   {
/* 1311 */     return _indent_not_parent_cell_options.isSet(this.field_5_indention_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getBorderOptions()
/*      */   {
/* 1328 */     return this.field_6_border_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getBorderLeft()
/*      */   {
/* 1357 */     return _border_left.getShortValue(this.field_6_border_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getBorderRight()
/*      */   {
/* 1384 */     return _border_right.getShortValue(this.field_6_border_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getBorderTop()
/*      */   {
/* 1411 */     return _border_top.getShortValue(this.field_6_border_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getBorderBottom()
/*      */   {
/* 1438 */     return _border_bottom.getShortValue(this.field_6_border_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getPaletteOptions()
/*      */   {
/* 1454 */     return this.field_7_palette_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getLeftBorderPaletteIdx()
/*      */   {
/* 1469 */     return _left_border_palette_idx.getShortValue(this.field_7_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getRightBorderPaletteIdx()
/*      */   {
/* 1483 */     return _right_border_palette_idx.getShortValue(this.field_7_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getDiag()
/*      */   {
/* 1500 */     return _diag.getShortValue(this.field_7_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAdtlPaletteOptions()
/*      */   {
/* 1517 */     return this.field_8_adtl_palette_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getTopBorderPaletteIdx()
/*      */   {
/* 1532 */     return (short)_top_border_palette_idx.getValue(this.field_8_adtl_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getBottomBorderPaletteIdx()
/*      */   {
/* 1546 */     return (short)_bottom_border_palette_idx.getValue(this.field_8_adtl_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getAdtlDiag()
/*      */   {
/* 1561 */     return (short)_adtl_diag.getValue(this.field_8_adtl_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getAdtlDiagLineStyle()
/*      */   {
/* 1588 */     return (short)_adtl_diag_line_style.getValue(this.field_8_adtl_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getAdtlFillPattern()
/*      */   {
/* 1619 */     return (short)_adtl_fill_pattern.getValue(this.field_8_adtl_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getFillPaletteOptions()
/*      */   {
/* 1636 */     return this.field_9_fill_palette_options;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getFillForeground()
/*      */   {
/* 1651 */     return _fill_foreground.getShortValue(this.field_9_fill_palette_options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getFillBackground()
/*      */   {
/* 1663 */     return _fill_background.getShortValue(this.field_9_fill_palette_options);
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/* 1668 */     StringBuffer buffer = new StringBuffer();
/*      */     
/* 1670 */     buffer.append("[EXTENDEDFORMAT]\n");
/* 1671 */     if (getXFType() == 1)
/*      */     {
/* 1673 */       buffer.append(" STYLE_RECORD_TYPE\n");
/*      */     }
/* 1675 */     else if (getXFType() == 0)
/*      */     {
/* 1677 */       buffer.append(" CELL_RECORD_TYPE\n");
/*      */     }
/* 1679 */     buffer.append("    .fontindex       = ").append(Integer.toHexString(getFontIndex())).append("\n");
/*      */     
/* 1681 */     buffer.append("    .formatindex     = ").append(Integer.toHexString(getFormatIndex())).append("\n");
/*      */     
/* 1683 */     buffer.append("    .celloptions     = ").append(Integer.toHexString(getCellOptions())).append("\n");
/*      */     
/* 1685 */     buffer.append("          .islocked  = ").append(isLocked()).append("\n");
/*      */     
/* 1687 */     buffer.append("          .ishidden  = ").append(isHidden()).append("\n");
/*      */     
/* 1689 */     buffer.append("          .recordtype= ").append(Integer.toHexString(getXFType())).append("\n");
/*      */     
/* 1691 */     buffer.append("          .parentidx = ").append(Integer.toHexString(getParentIndex())).append("\n");
/*      */     
/* 1693 */     buffer.append("    .alignmentoptions= ").append(Integer.toHexString(getAlignmentOptions())).append("\n");
/*      */     
/* 1695 */     buffer.append("          .alignment = ").append(getAlignment()).append("\n");
/*      */     
/* 1697 */     buffer.append("          .wraptext  = ").append(getWrapText()).append("\n");
/*      */     
/* 1699 */     buffer.append("          .valignment= ").append(Integer.toHexString(getVerticalAlignment())).append("\n");
/*      */     
/* 1701 */     buffer.append("          .justlast  = ").append(Integer.toHexString(getJustifyLast())).append("\n");
/*      */     
/* 1703 */     buffer.append("          .rotation  = ").append(Integer.toHexString(getRotation())).append("\n");
/*      */     
/* 1705 */     buffer.append("    .indentionoptions= ").append(Integer.toHexString(getIndentionOptions())).append("\n");
/*      */     
/* 1707 */     buffer.append("          .indent    = ").append(Integer.toHexString(getIndent())).append("\n");
/*      */     
/* 1709 */     buffer.append("          .shrinktoft= ").append(getShrinkToFit()).append("\n");
/*      */     
/* 1711 */     buffer.append("          .mergecells= ").append(getMergeCells()).append("\n");
/*      */     
/* 1713 */     buffer.append("          .readngordr= ").append(Integer.toHexString(getReadingOrder())).append("\n");
/*      */     
/* 1715 */     buffer.append("          .formatflag= ").append(isIndentNotParentFormat()).append("\n");
/*      */     
/* 1717 */     buffer.append("          .fontflag  = ").append(isIndentNotParentFont()).append("\n");
/*      */     
/* 1719 */     buffer.append("          .prntalgnmt= ").append(isIndentNotParentAlignment()).append("\n");
/*      */     
/* 1721 */     buffer.append("          .borderflag= ").append(isIndentNotParentBorder()).append("\n");
/*      */     
/* 1723 */     buffer.append("          .paternflag= ").append(isIndentNotParentPattern()).append("\n");
/*      */     
/* 1725 */     buffer.append("          .celloption= ").append(isIndentNotParentCellOptions()).append("\n");
/*      */     
/* 1727 */     buffer.append("    .borderoptns     = ").append(Integer.toHexString(getBorderOptions())).append("\n");
/*      */     
/* 1729 */     buffer.append("          .lftln     = ").append(Integer.toHexString(getBorderLeft())).append("\n");
/*      */     
/* 1731 */     buffer.append("          .rgtln     = ").append(Integer.toHexString(getBorderRight())).append("\n");
/*      */     
/* 1733 */     buffer.append("          .topln     = ").append(Integer.toHexString(getBorderTop())).append("\n");
/*      */     
/* 1735 */     buffer.append("          .btmln     = ").append(Integer.toHexString(getBorderBottom())).append("\n");
/*      */     
/* 1737 */     buffer.append("    .paleteoptns     = ").append(Integer.toHexString(getPaletteOptions())).append("\n");
/*      */     
/* 1739 */     buffer.append("          .leftborder= ").append(Integer.toHexString(getLeftBorderPaletteIdx())).append("\n");
/*      */     
/*      */ 
/* 1742 */     buffer.append("          .rghtborder= ").append(Integer.toHexString(getRightBorderPaletteIdx())).append("\n");
/*      */     
/*      */ 
/* 1745 */     buffer.append("          .diag      = ").append(Integer.toHexString(getDiag())).append("\n");
/*      */     
/* 1747 */     buffer.append("    .paleteoptn2     = ").append(Integer.toHexString(getAdtlPaletteOptions())).append("\n");
/*      */     
/*      */ 
/* 1750 */     buffer.append("          .topborder = ").append(Integer.toHexString(getTopBorderPaletteIdx())).append("\n");
/*      */     
/*      */ 
/* 1753 */     buffer.append("          .botmborder= ").append(Integer.toHexString(getBottomBorderPaletteIdx())).append("\n");
/*      */     
/*      */ 
/* 1756 */     buffer.append("          .adtldiag  = ").append(Integer.toHexString(getAdtlDiag())).append("\n");
/*      */     
/* 1758 */     buffer.append("          .diaglnstyl= ").append(Integer.toHexString(getAdtlDiagLineStyle())).append("\n");
/*      */     
/* 1760 */     buffer.append("          .fillpattrn= ").append(Integer.toHexString(getAdtlFillPattern())).append("\n");
/*      */     
/* 1762 */     buffer.append("    .fillpaloptn     = ").append(Integer.toHexString(getFillPaletteOptions())).append("\n");
/*      */     
/*      */ 
/* 1765 */     buffer.append("          .foreground= ").append(Integer.toHexString(getFillForeground())).append("\n");
/*      */     
/* 1767 */     buffer.append("          .background= ").append(Integer.toHexString(getFillBackground())).append("\n");
/*      */     
/* 1769 */     buffer.append("[/EXTENDEDFORMAT]\n");
/* 1770 */     return buffer.toString();
/*      */   }
/*      */   
/*      */   public void serialize(LittleEndianOutput out) {
/* 1774 */     out.writeShort(getFontIndex());
/* 1775 */     out.writeShort(getFormatIndex());
/* 1776 */     out.writeShort(getCellOptions());
/* 1777 */     out.writeShort(getAlignmentOptions());
/* 1778 */     out.writeShort(getIndentionOptions());
/* 1779 */     out.writeShort(getBorderOptions());
/* 1780 */     out.writeShort(getPaletteOptions());
/* 1781 */     out.writeInt(getAdtlPaletteOptions());
/* 1782 */     out.writeShort(getFillPaletteOptions());
/*      */   }
/*      */   
/*      */   protected int getDataSize() {
/* 1786 */     return 20;
/*      */   }
/*      */   
/*      */   public short getSid()
/*      */   {
/* 1791 */     return 224;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cloneStyleFrom(ExtendedFormatRecord source)
/*      */   {
/* 1804 */     this.field_1_font_index = source.field_1_font_index;
/* 1805 */     this.field_2_format_index = source.field_2_format_index;
/* 1806 */     this.field_3_cell_options = source.field_3_cell_options;
/* 1807 */     this.field_4_alignment_options = source.field_4_alignment_options;
/* 1808 */     this.field_5_indention_options = source.field_5_indention_options;
/* 1809 */     this.field_6_border_options = source.field_6_border_options;
/* 1810 */     this.field_7_palette_options = source.field_7_palette_options;
/* 1811 */     this.field_8_adtl_palette_options = source.field_8_adtl_palette_options;
/* 1812 */     this.field_9_fill_palette_options = source.field_9_fill_palette_options;
/*      */   }
/*      */   
/*      */   public int hashCode() {
/* 1816 */     int prime = 31;
/* 1817 */     int result = 1;
/* 1818 */     result = 31 * result + this.field_1_font_index;
/* 1819 */     result = 31 * result + this.field_2_format_index;
/* 1820 */     result = 31 * result + this.field_3_cell_options;
/* 1821 */     result = 31 * result + this.field_4_alignment_options;
/* 1822 */     result = 31 * result + this.field_5_indention_options;
/* 1823 */     result = 31 * result + this.field_6_border_options;
/* 1824 */     result = 31 * result + this.field_7_palette_options;
/* 1825 */     result = 31 * result + this.field_8_adtl_palette_options;
/* 1826 */     result = 31 * result + this.field_9_fill_palette_options;
/* 1827 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object obj)
/*      */   {
/* 1836 */     if (this == obj)
/* 1837 */       return true;
/* 1838 */     if (obj == null)
/* 1839 */       return false;
/* 1840 */     if ((obj instanceof ExtendedFormatRecord)) {
/* 1841 */       ExtendedFormatRecord other = (ExtendedFormatRecord)obj;
/* 1842 */       if (this.field_1_font_index != other.field_1_font_index)
/* 1843 */         return false;
/* 1844 */       if (this.field_2_format_index != other.field_2_format_index)
/* 1845 */         return false;
/* 1846 */       if (this.field_3_cell_options != other.field_3_cell_options)
/* 1847 */         return false;
/* 1848 */       if (this.field_4_alignment_options != other.field_4_alignment_options)
/* 1849 */         return false;
/* 1850 */       if (this.field_5_indention_options != other.field_5_indention_options)
/* 1851 */         return false;
/* 1852 */       if (this.field_6_border_options != other.field_6_border_options)
/* 1853 */         return false;
/* 1854 */       if (this.field_7_palette_options != other.field_7_palette_options)
/* 1855 */         return false;
/* 1856 */       if (this.field_8_adtl_palette_options != other.field_8_adtl_palette_options)
/* 1857 */         return false;
/* 1858 */       if (this.field_9_fill_palette_options != other.field_9_fill_palette_options)
/* 1859 */         return false;
/* 1860 */       return true;
/*      */     }
/* 1862 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ExtendedFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */