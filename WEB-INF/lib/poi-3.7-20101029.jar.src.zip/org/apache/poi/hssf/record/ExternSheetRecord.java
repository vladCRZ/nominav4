/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternSheetRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 23;
/*     */   private List<RefSubRecord> _list;
/*     */   
/*     */   private static final class RefSubRecord
/*     */   {
/*     */     public static final int ENCODED_SIZE = 6;
/*     */     private int _extBookIndex;
/*     */     private int _firstSheetIndex;
/*     */     private int _lastSheetIndex;
/*     */     
/*     */     public RefSubRecord(int extBookIndex, int firstSheetIndex, int lastSheetIndex)
/*     */     {
/*  47 */       this._extBookIndex = extBookIndex;
/*  48 */       this._firstSheetIndex = firstSheetIndex;
/*  49 */       this._lastSheetIndex = lastSheetIndex;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public RefSubRecord(RecordInputStream in)
/*     */     {
/*  56 */       this(in.readShort(), in.readShort(), in.readShort());
/*     */     }
/*     */     
/*  59 */     public int getExtBookIndex() { return this._extBookIndex; }
/*     */     
/*     */     public int getFirstSheetIndex() {
/*  62 */       return this._firstSheetIndex;
/*     */     }
/*     */     
/*  65 */     public int getLastSheetIndex() { return this._lastSheetIndex; }
/*     */     
/*     */     public String toString()
/*     */     {
/*  69 */       StringBuffer buffer = new StringBuffer();
/*  70 */       buffer.append("extBook=").append(this._extBookIndex);
/*  71 */       buffer.append(" firstSheet=").append(this._firstSheetIndex);
/*  72 */       buffer.append(" lastSheet=").append(this._lastSheetIndex);
/*  73 */       return buffer.toString();
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  77 */       out.writeShort(this._extBookIndex);
/*  78 */       out.writeShort(this._firstSheetIndex);
/*  79 */       out.writeShort(this._lastSheetIndex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ExternSheetRecord()
/*     */   {
/*  86 */     this._list = new ArrayList();
/*     */   }
/*     */   
/*     */   public ExternSheetRecord(RecordInputStream in) {
/*  90 */     this._list = new ArrayList();
/*     */     
/*  92 */     int nItems = in.readShort();
/*     */     
/*  94 */     for (int i = 0; i < nItems; i++) {
/*  95 */       RefSubRecord rec = new RefSubRecord(in);
/*  96 */       this._list.add(rec);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumOfRefs()
/*     */   {
/* 105 */     return this._list.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addREFRecord(RefSubRecord rec)
/*     */   {
/* 113 */     this._list.add(rec);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNumOfREFRecords()
/*     */   {
/* 120 */     return this._list.size();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 125 */     StringBuffer sb = new StringBuffer();
/* 126 */     int nItems = this._list.size();
/* 127 */     sb.append("[EXTERNSHEET]\n");
/* 128 */     sb.append("   numOfRefs     = ").append(nItems).append("\n");
/* 129 */     for (int i = 0; i < nItems; i++) {
/* 130 */       sb.append("refrec         #").append(i).append(": ");
/* 131 */       sb.append(getRef(i).toString());
/* 132 */       sb.append('\n');
/*     */     }
/* 134 */     sb.append("[/EXTERNSHEET]\n");
/*     */     
/*     */ 
/* 137 */     return sb.toString();
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 141 */     return 2 + this._list.size() * 6;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 145 */     int nItems = this._list.size();
/*     */     
/* 147 */     out.writeShort(nItems);
/*     */     
/* 149 */     for (int i = 0; i < nItems; i++) {
/* 150 */       getRef(i).serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   private RefSubRecord getRef(int i) {
/* 155 */     return (RefSubRecord)this._list.get(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 162 */     return 23;
/*     */   }
/*     */   
/*     */   public int getExtbookIndexFromRefIndex(int refIndex) {
/* 166 */     return getRef(refIndex).getExtBookIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int findRefIndexFromExtBookIndex(int extBookIndex)
/*     */   {
/* 173 */     int nItems = this._list.size();
/* 174 */     for (int i = 0; i < nItems; i++) {
/* 175 */       if (getRef(i).getExtBookIndex() == extBookIndex) {
/* 176 */         return i;
/*     */       }
/*     */     }
/* 179 */     return -1;
/*     */   }
/*     */   
/*     */   public int getFirstSheetIndexFromRefIndex(int extRefIndex) {
/* 183 */     return getRef(extRefIndex).getFirstSheetIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int addRef(int extBookIndex, int firstSheetIndex, int lastSheetIndex)
/*     */   {
/* 190 */     this._list.add(new RefSubRecord(extBookIndex, firstSheetIndex, lastSheetIndex));
/* 191 */     return this._list.size() - 1;
/*     */   }
/*     */   
/*     */   public int getRefIxForSheet(int externalBookIndex, int sheetIndex) {
/* 195 */     int nItems = this._list.size();
/* 196 */     for (int i = 0; i < nItems; i++) {
/* 197 */       RefSubRecord ref = getRef(i);
/* 198 */       if (ref.getExtBookIndex() == externalBookIndex)
/*     */       {
/*     */ 
/* 201 */         if ((ref.getFirstSheetIndex() == sheetIndex) && (ref.getLastSheetIndex() == sheetIndex))
/* 202 */           return i;
/*     */       }
/*     */     }
/* 205 */     return -1;
/*     */   }
/*     */   
/*     */   public static ExternSheetRecord combine(ExternSheetRecord[] esrs) {
/* 209 */     ExternSheetRecord result = new ExternSheetRecord();
/* 210 */     for (int i = 0; i < esrs.length; i++) {
/* 211 */       ExternSheetRecord esr = esrs[i];
/* 212 */       int nRefs = esr.getNumOfREFRecords();
/* 213 */       for (int j = 0; j < nRefs; j++) {
/* 214 */         result.addREFRecord(esr.getRef(j));
/*     */       }
/*     */     }
/* 217 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ExternSheetRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */