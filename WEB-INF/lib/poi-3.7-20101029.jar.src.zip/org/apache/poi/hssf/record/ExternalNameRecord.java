/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.constant.ConstantValueParser;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExternalNameRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 35;
/*     */   private static final int OPT_BUILTIN_NAME = 1;
/*     */   private static final int OPT_AUTOMATIC_LINK = 2;
/*     */   private static final int OPT_PICTURE_LINK = 4;
/*     */   private static final int OPT_STD_DOCUMENT_NAME = 8;
/*     */   private static final int OPT_OLE_LINK = 16;
/*     */   private static final int OPT_ICONIFIED_PICTURE_LINK = 32768;
/*     */   private short field_1_option_flag;
/*     */   private short field_2_ixals;
/*     */   private short field_3_not_used;
/*     */   private String field_4_name;
/*     */   private Formula field_5_name_definition;
/*     */   private Object[] _ddeValues;
/*     */   private int _nColumns;
/*     */   private int _nRows;
/*     */   
/*     */   public boolean isBuiltInName()
/*     */   {
/*  68 */     return (this.field_1_option_flag & 0x1) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAutomaticLink()
/*     */   {
/*  74 */     return (this.field_1_option_flag & 0x2) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isPicureLink()
/*     */   {
/*  80 */     return (this.field_1_option_flag & 0x4) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isStdDocumentNameIdentifier()
/*     */   {
/*  86 */     return (this.field_1_option_flag & 0x8) != 0;
/*     */   }
/*     */   
/*  89 */   public boolean isOLELink() { return (this.field_1_option_flag & 0x10) != 0; }
/*     */   
/*     */   public boolean isIconifiedPictureLink() {
/*  92 */     return (this.field_1_option_flag & 0x8000) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getText()
/*     */   {
/*  98 */     return this.field_4_name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getIx()
/*     */   {
/* 108 */     return this.field_2_ixals;
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 112 */     int result = 6;
/* 113 */     result += StringUtil.getEncodedSize(this.field_4_name) - 1;
/*     */     
/* 115 */     if ((!isOLELink()) && (!isStdDocumentNameIdentifier())) {
/* 116 */       if (isAutomaticLink()) {
/* 117 */         result += 3;
/* 118 */         result += ConstantValueParser.getEncodedSize(this._ddeValues);
/*     */       } else {
/* 120 */         result += this.field_5_name_definition.getEncodedSize();
/*     */       }
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 127 */     out.writeShort(this.field_1_option_flag);
/* 128 */     out.writeShort(this.field_2_ixals);
/* 129 */     out.writeShort(this.field_3_not_used);
/*     */     
/* 131 */     out.writeByte(this.field_4_name.length());
/* 132 */     StringUtil.writeUnicodeStringFlagAndData(out, this.field_4_name);
/*     */     
/* 134 */     if ((!isOLELink()) && (!isStdDocumentNameIdentifier())) {
/* 135 */       if (isAutomaticLink()) {
/* 136 */         out.writeByte(this._nColumns - 1);
/* 137 */         out.writeShort(this._nRows - 1);
/* 138 */         ConstantValueParser.encode(out, this._ddeValues);
/*     */       } else {
/* 140 */         this.field_5_name_definition.serialize(out);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ExternalNameRecord(RecordInputStream in)
/*     */   {
/* 147 */     this.field_1_option_flag = in.readShort();
/* 148 */     this.field_2_ixals = in.readShort();
/* 149 */     this.field_3_not_used = in.readShort();
/*     */     
/* 151 */     int numChars = in.readUByte();
/* 152 */     this.field_4_name = StringUtil.readUnicodeString(in, numChars);
/*     */     
/*     */ 
/*     */ 
/* 156 */     if ((!isOLELink()) && (!isStdDocumentNameIdentifier()))
/*     */     {
/*     */ 
/* 159 */       if (isAutomaticLink())
/*     */       {
/* 161 */         int nColumns = in.readUByte() + 1;
/* 162 */         int nRows = in.readShort() + 1;
/*     */         
/* 164 */         int totalCount = nRows * nColumns;
/* 165 */         this._ddeValues = ConstantValueParser.parse(in, totalCount);
/* 166 */         this._nColumns = nColumns;
/* 167 */         this._nRows = nRows;
/*     */       }
/*     */       else {
/* 170 */         int formulaLen = in.readUShort();
/* 171 */         this.field_5_name_definition = Formula.read(formulaLen, in);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 177 */     return 35;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 181 */     StringBuffer sb = new StringBuffer();
/* 182 */     sb.append("[EXTERNALNAME]\n");
/* 183 */     sb.append("    .ix      = ").append(this.field_2_ixals).append("\n");
/* 184 */     sb.append("    .name    = ").append(this.field_4_name).append("\n");
/* 185 */     if (this.field_5_name_definition != null) {
/* 186 */       sb.append("    .formula = ").append(this.field_5_name_definition).append("\n");
/*     */     }
/* 188 */     sb.append("[/EXTERNALNAME]\n");
/* 189 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ExternalNameRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */