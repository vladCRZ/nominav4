/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.common.FtrHeader;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FeatHdrRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final int SHAREDFEATURES_ISFPROTECTION = 2;
/*     */   public static final int SHAREDFEATURES_ISFFEC2 = 3;
/*     */   public static final int SHAREDFEATURES_ISFFACTOID = 4;
/*     */   public static final int SHAREDFEATURES_ISFLIST = 5;
/*     */   public static final short sid = 2151;
/*     */   private FtrHeader futureHeader;
/*     */   private int isf_sharedFeatureType;
/*     */   private byte reserved;
/*     */   private long cbHdrData;
/*     */   private byte[] rgbHdrData;
/*     */   
/*     */   public FeatHdrRecord()
/*     */   {
/*  68 */     this.futureHeader = new FtrHeader();
/*  69 */     this.futureHeader.setRecordType((short)2151);
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  73 */     return 2151;
/*     */   }
/*     */   
/*     */   public FeatHdrRecord(RecordInputStream in) {
/*  77 */     this.futureHeader = new FtrHeader(in);
/*     */     
/*  79 */     this.isf_sharedFeatureType = in.readShort();
/*  80 */     this.reserved = in.readByte();
/*  81 */     this.cbHdrData = in.readInt();
/*     */     
/*  83 */     this.rgbHdrData = in.readRemainder();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  87 */     StringBuffer buffer = new StringBuffer();
/*  88 */     buffer.append("[FEATURE HEADER]\n");
/*     */     
/*     */ 
/*     */ 
/*  92 */     buffer.append("[/FEATURE HEADER]\n");
/*  93 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  97 */     this.futureHeader.serialize(out);
/*     */     
/*  99 */     out.writeShort(this.isf_sharedFeatureType);
/* 100 */     out.writeByte(this.reserved);
/* 101 */     out.writeInt((int)this.cbHdrData);
/* 102 */     out.write(this.rgbHdrData);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 106 */     return 19 + this.rgbHdrData.length;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 111 */     return cloneViaReserialise();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FeatHdrRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */