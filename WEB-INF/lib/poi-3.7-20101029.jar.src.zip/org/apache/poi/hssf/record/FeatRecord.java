/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.apache.poi.hssf.record.common.FeatFormulaErr2;
/*     */ import org.apache.poi.hssf.record.common.FeatProtection;
/*     */ import org.apache.poi.hssf.record.common.FeatSmartTag;
/*     */ import org.apache.poi.hssf.record.common.FtrHeader;
/*     */ import org.apache.poi.hssf.record.common.SharedFeature;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FeatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 2152;
/*     */   private FtrHeader futureHeader;
/*     */   private int isf_sharedFeatureType;
/*     */   private byte reserved1;
/*     */   private long reserved2;
/*     */   private long cbFeatData;
/*     */   private int reserved3;
/*     */   private CellRangeAddress[] cellRefs;
/*     */   private SharedFeature sharedFeature;
/*     */   
/*     */   public FeatRecord()
/*     */   {
/*  59 */     this.futureHeader = new FtrHeader();
/*  60 */     this.futureHeader.setRecordType((short)2152);
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  64 */     return 2152;
/*     */   }
/*     */   
/*     */   public FeatRecord(RecordInputStream in) {
/*  68 */     this.futureHeader = new FtrHeader(in);
/*     */     
/*  70 */     this.isf_sharedFeatureType = in.readShort();
/*  71 */     this.reserved1 = in.readByte();
/*  72 */     this.reserved2 = in.readInt();
/*  73 */     int cref = in.readUShort();
/*  74 */     this.cbFeatData = in.readInt();
/*  75 */     this.reserved3 = in.readShort();
/*     */     
/*  77 */     this.cellRefs = new CellRangeAddress[cref];
/*  78 */     for (int i = 0; i < this.cellRefs.length; i++) {
/*  79 */       this.cellRefs[i] = new CellRangeAddress(in);
/*     */     }
/*     */     
/*  82 */     switch (this.isf_sharedFeatureType) {
/*     */     case 2: 
/*  84 */       this.sharedFeature = new FeatProtection(in);
/*  85 */       break;
/*     */     case 3: 
/*  87 */       this.sharedFeature = new FeatFormulaErr2(in);
/*  88 */       break;
/*     */     case 4: 
/*  90 */       this.sharedFeature = new FeatSmartTag(in);
/*  91 */       break;
/*     */     default: 
/*  93 */       System.err.println("Unknown Shared Feature " + this.isf_sharedFeatureType + " found!");
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuffer buffer = new StringBuffer();
/*  99 */     buffer.append("[SHARED FEATURE]\n");
/*     */     
/*     */ 
/*     */ 
/* 103 */     buffer.append("[/SHARED FEATURE]\n");
/* 104 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 108 */     this.futureHeader.serialize(out);
/*     */     
/* 110 */     out.writeShort(this.isf_sharedFeatureType);
/* 111 */     out.writeByte(this.reserved1);
/* 112 */     out.writeInt((int)this.reserved2);
/* 113 */     out.writeShort(this.cellRefs.length);
/* 114 */     out.writeInt((int)this.cbFeatData);
/* 115 */     out.writeShort(this.reserved3);
/*     */     
/* 117 */     for (int i = 0; i < this.cellRefs.length; i++) {
/* 118 */       this.cellRefs[i].serialize(out);
/*     */     }
/*     */     
/* 121 */     this.sharedFeature.serialize(out);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 125 */     return 27 + this.cellRefs.length * 8 + this.sharedFeature.getDataSize();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getIsf_sharedFeatureType()
/*     */   {
/* 131 */     return this.isf_sharedFeatureType;
/*     */   }
/*     */   
/*     */   public long getCbFeatData() {
/* 135 */     return this.cbFeatData;
/*     */   }
/*     */   
/* 138 */   public void setCbFeatData(long cbFeatData) { this.cbFeatData = cbFeatData; }
/*     */   
/*     */   public CellRangeAddress[] getCellRefs()
/*     */   {
/* 142 */     return this.cellRefs;
/*     */   }
/*     */   
/* 145 */   public void setCellRefs(CellRangeAddress[] cellRefs) { this.cellRefs = cellRefs; }
/*     */   
/*     */ 
/*     */ 
/* 149 */   public SharedFeature getSharedFeature() { return this.sharedFeature; }
/*     */   
/*     */   public void setSharedFeature(SharedFeature feature) {
/* 152 */     this.sharedFeature = feature;
/*     */     
/* 154 */     if ((feature instanceof FeatProtection)) {
/* 155 */       this.isf_sharedFeatureType = 2;
/*     */     }
/* 157 */     if ((feature instanceof FeatFormulaErr2)) {
/* 158 */       this.isf_sharedFeatureType = 3;
/*     */     }
/* 160 */     if ((feature instanceof FeatSmartTag)) {
/* 161 */       this.isf_sharedFeatureType = 4;
/*     */     }
/*     */     
/* 164 */     if (this.isf_sharedFeatureType == 3) {
/* 165 */       this.cbFeatData = this.sharedFeature.getDataSize();
/*     */     } else {
/* 167 */       this.cbFeatData = 0L;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 174 */     return cloneViaReserialise();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FeatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */