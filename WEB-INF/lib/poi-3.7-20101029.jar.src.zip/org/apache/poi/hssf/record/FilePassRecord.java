/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilePassRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 47;
/*     */   private int _encryptionType;
/*     */   private int _encryptionInfo;
/*     */   private int _minorVersionNo;
/*     */   private byte[] _docId;
/*     */   private byte[] _saltData;
/*     */   private byte[] _saltHash;
/*     */   private static final int ENCRYPTION_XOR = 0;
/*     */   private static final int ENCRYPTION_OTHER = 1;
/*     */   private static final int ENCRYPTION_OTHER_RC4 = 1;
/*     */   private static final int ENCRYPTION_OTHER_CAPI_2 = 2;
/*     */   private static final int ENCRYPTION_OTHER_CAPI_3 = 3;
/*     */   
/*     */   public FilePassRecord(RecordInputStream in)
/*     */   {
/*  48 */     this._encryptionType = in.readUShort();
/*     */     
/*  50 */     switch (this._encryptionType) {
/*     */     case 0: 
/*  52 */       throw new RecordFormatException("HSSF does not currently support XOR obfuscation");
/*     */     case 1: 
/*     */       break;
/*     */     
/*     */     default: 
/*  57 */       throw new RecordFormatException("Unknown encryption type " + this._encryptionType);
/*     */     }
/*  59 */     this._encryptionInfo = in.readUShort();
/*  60 */     switch (this._encryptionInfo)
/*     */     {
/*     */     case 1: 
/*     */       break;
/*     */     case 2: 
/*     */     case 3: 
/*  66 */       throw new RecordFormatException("HSSF does not currently support CryptoAPI encryption");
/*     */     
/*     */     default: 
/*  69 */       throw new RecordFormatException("Unknown encryption info " + this._encryptionInfo);
/*     */     }
/*  71 */     this._minorVersionNo = in.readUShort();
/*  72 */     if (this._minorVersionNo != 1) {
/*  73 */       throw new RecordFormatException("Unexpected VersionInfo number for RC4Header " + this._minorVersionNo);
/*     */     }
/*  75 */     this._docId = read(in, 16);
/*  76 */     this._saltData = read(in, 16);
/*  77 */     this._saltHash = read(in, 16);
/*     */   }
/*     */   
/*     */   private static byte[] read(RecordInputStream in, int size) {
/*  81 */     byte[] result = new byte[size];
/*  82 */     in.readFully(result);
/*  83 */     return result;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  87 */     out.writeShort(this._encryptionType);
/*  88 */     out.writeShort(this._encryptionInfo);
/*  89 */     out.writeShort(this._minorVersionNo);
/*  90 */     out.write(this._docId);
/*  91 */     out.write(this._saltData);
/*  92 */     out.write(this._saltHash);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  96 */     return 54;
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getDocId()
/*     */   {
/* 102 */     return (byte[])this._docId.clone();
/*     */   }
/*     */   
/*     */   public void setDocId(byte[] docId) {
/* 106 */     this._docId = ((byte[])docId.clone());
/*     */   }
/*     */   
/*     */   public byte[] getSaltData() {
/* 110 */     return (byte[])this._saltData.clone();
/*     */   }
/*     */   
/*     */   public void setSaltData(byte[] saltData) {
/* 114 */     this._saltData = ((byte[])saltData.clone());
/*     */   }
/*     */   
/*     */   public byte[] getSaltHash() {
/* 118 */     return (byte[])this._saltHash.clone();
/*     */   }
/*     */   
/*     */   public void setSaltHash(byte[] saltHash) {
/* 122 */     this._saltHash = ((byte[])saltHash.clone());
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 126 */     return 47;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 131 */     return this;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 135 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 137 */     buffer.append("[FILEPASS]\n");
/* 138 */     buffer.append("    .type = ").append(HexDump.shortToHex(this._encryptionType)).append("\n");
/* 139 */     buffer.append("    .info = ").append(HexDump.shortToHex(this._encryptionInfo)).append("\n");
/* 140 */     buffer.append("    .ver  = ").append(HexDump.shortToHex(this._minorVersionNo)).append("\n");
/* 141 */     buffer.append("    .docId= ").append(HexDump.toHex(this._docId)).append("\n");
/* 142 */     buffer.append("    .salt = ").append(HexDump.toHex(this._saltData)).append("\n");
/* 143 */     buffer.append("    .hash = ").append(HexDump.toHex(this._saltHash)).append("\n");
/* 144 */     buffer.append("[/FILEPASS]\n");
/* 145 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FilePassRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */