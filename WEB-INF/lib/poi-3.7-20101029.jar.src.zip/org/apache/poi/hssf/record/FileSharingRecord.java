/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FileSharingRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 91;
/*     */   private short field_1_readonly;
/*     */   private short field_2_password;
/*     */   private byte field_3_username_unicode_options;
/*     */   private String field_3_username_value;
/*     */   
/*     */   public FileSharingRecord() {}
/*     */   
/*     */   public FileSharingRecord(RecordInputStream in)
/*     */   {
/*  41 */     this.field_1_readonly = in.readShort();
/*  42 */     this.field_2_password = in.readShort();
/*     */     
/*  44 */     int nameLen = in.readShort();
/*     */     
/*  46 */     if (nameLen > 0)
/*     */     {
/*  48 */       this.field_3_username_unicode_options = in.readByte();
/*  49 */       this.field_3_username_value = in.readCompressedUnicode(nameLen);
/*     */     } else {
/*  51 */       this.field_3_username_value = "";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static short hashPassword(String password)
/*     */   {
/*  58 */     byte[] passwordCharacters = password.getBytes();
/*  59 */     int hash = 0;
/*  60 */     if (passwordCharacters.length > 0) {
/*  61 */       int charIndex = passwordCharacters.length;
/*  62 */       while (charIndex-- > 0) {
/*  63 */         hash = hash >> 14 & 0x1 | hash << 1 & 0x7FFF;
/*  64 */         hash ^= passwordCharacters[charIndex];
/*     */       }
/*     */       
/*  67 */       hash = hash >> 14 & 0x1 | hash << 1 & 0x7FFF;
/*  68 */       hash ^= passwordCharacters.length;
/*  69 */       hash ^= 0xCE4B;
/*     */     }
/*  71 */     return (short)hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadOnly(short readonly)
/*     */   {
/*  80 */     this.field_1_readonly = readonly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getReadOnly()
/*     */   {
/*  89 */     return this.field_1_readonly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPassword(short password)
/*     */   {
/*  96 */     this.field_2_password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getPassword()
/*     */   {
/* 103 */     return this.field_2_password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 111 */     return this.field_3_username_value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 118 */     this.field_3_username_value = username;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 123 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 125 */     buffer.append("[FILESHARING]\n");
/* 126 */     buffer.append("    .readonly       = ").append(getReadOnly() == 1 ? "true" : "false").append("\n");
/*     */     
/* 128 */     buffer.append("    .password       = ").append(Integer.toHexString(getPassword())).append("\n");
/*     */     
/* 130 */     buffer.append("    .username       = ").append(getUsername()).append("\n");
/*     */     
/* 132 */     buffer.append("[/FILESHARING]\n");
/* 133 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 138 */     out.writeShort(getReadOnly());
/* 139 */     out.writeShort(getPassword());
/* 140 */     out.writeShort(this.field_3_username_value.length());
/* 141 */     if (this.field_3_username_value.length() > 0) {
/* 142 */       out.writeByte(this.field_3_username_unicode_options);
/* 143 */       StringUtil.putCompressedUnicode(getUsername(), out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 148 */     int nameLen = this.field_3_username_value.length();
/* 149 */     if (nameLen < 1) {
/* 150 */       return 6;
/*     */     }
/* 152 */     return 7 + nameLen;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 156 */     return 91;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 163 */     FileSharingRecord clone = new FileSharingRecord();
/* 164 */     clone.setReadOnly(this.field_1_readonly);
/* 165 */     clone.setPassword(this.field_2_password);
/* 166 */     clone.setUsername(this.field_3_username_value);
/* 167 */     return clone;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FileSharingRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */