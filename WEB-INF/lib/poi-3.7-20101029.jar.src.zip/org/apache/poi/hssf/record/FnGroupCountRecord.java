/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FnGroupCountRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 156;
/*    */   public static final short COUNT = 14;
/*    */   private short field_1_count;
/*    */   
/*    */   public FnGroupCountRecord() {}
/*    */   
/*    */   public FnGroupCountRecord(RecordInputStream in)
/*    */   {
/* 51 */     this.field_1_count = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCount(short count)
/*    */   {
/* 62 */     this.field_1_count = count;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getCount()
/*    */   {
/* 73 */     return this.field_1_count;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 78 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 80 */     buffer.append("[FNGROUPCOUNT]\n");
/* 81 */     buffer.append("    .count            = ").append(getCount()).append("\n");
/*    */     
/* 83 */     buffer.append("[/FNGROUPCOUNT]\n");
/* 84 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 88 */     out.writeShort(getCount());
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 92 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 97 */     return 156;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FnGroupCountRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */