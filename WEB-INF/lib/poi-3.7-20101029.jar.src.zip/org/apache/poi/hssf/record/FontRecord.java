/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FontRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 49;
/*     */   public static final short SS_NONE = 0;
/*     */   public static final short SS_SUPER = 1;
/*     */   public static final short SS_SUB = 2;
/*     */   public static final byte U_NONE = 0;
/*     */   public static final byte U_SINGLE = 1;
/*     */   public static final byte U_DOUBLE = 2;
/*     */   public static final byte U_SINGLE_ACCOUNTING = 33;
/*     */   public static final byte U_DOUBLE_ACCOUNTING = 34;
/*     */   private short field_1_font_height;
/*     */   private short field_2_attributes;
/*  47 */   private static final BitField italic = BitFieldFactory.getInstance(2);
/*     */   
/*     */ 
/*  50 */   private static final BitField strikeout = BitFieldFactory.getInstance(8);
/*  51 */   private static final BitField macoutline = BitFieldFactory.getInstance(16);
/*  52 */   private static final BitField macshadow = BitFieldFactory.getInstance(32);
/*     */   
/*     */   private short field_3_color_palette_index;
/*     */   
/*     */   private short field_4_bold_weight;
/*     */   
/*     */   private short field_5_super_sub_script;
/*     */   private byte field_6_underline;
/*     */   private byte field_7_family;
/*     */   private byte field_8_charset;
/*  62 */   private byte field_9_zero = 0;
/*     */   
/*     */   private String field_11_font_name;
/*     */   
/*     */   public FontRecord() {}
/*     */   
/*     */   public FontRecord(RecordInputStream in)
/*     */   {
/*  70 */     this.field_1_font_height = in.readShort();
/*  71 */     this.field_2_attributes = in.readShort();
/*  72 */     this.field_3_color_palette_index = in.readShort();
/*  73 */     this.field_4_bold_weight = in.readShort();
/*  74 */     this.field_5_super_sub_script = in.readShort();
/*  75 */     this.field_6_underline = in.readByte();
/*  76 */     this.field_7_family = in.readByte();
/*  77 */     this.field_8_charset = in.readByte();
/*  78 */     this.field_9_zero = in.readByte();
/*  79 */     int field_10_font_name_len = in.readUByte();
/*  80 */     int unicodeFlags = in.readUByte();
/*     */     
/*  82 */     if (field_10_font_name_len > 0) {
/*  83 */       if (unicodeFlags == 0) {
/*  84 */         this.field_11_font_name = in.readCompressedUnicode(field_10_font_name_len);
/*     */       } else {
/*  86 */         this.field_11_font_name = in.readUnicodeLEString(field_10_font_name_len);
/*     */       }
/*     */     } else {
/*  89 */       this.field_11_font_name = "";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontHeight(short height)
/*     */   {
/*  99 */     this.field_1_font_height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributes(short attributes)
/*     */   {
/* 108 */     this.field_2_attributes = attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItalic(boolean italics)
/*     */   {
/* 120 */     this.field_2_attributes = italic.setShortBoolean(this.field_2_attributes, italics);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStrikeout(boolean strike)
/*     */   {
/* 130 */     this.field_2_attributes = strikeout.setShortBoolean(this.field_2_attributes, strike);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMacoutline(boolean mac)
/*     */   {
/* 141 */     this.field_2_attributes = macoutline.setShortBoolean(this.field_2_attributes, mac);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMacshadow(boolean mac)
/*     */   {
/* 152 */     this.field_2_attributes = macshadow.setShortBoolean(this.field_2_attributes, mac);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColorPaletteIndex(short cpi)
/*     */   {
/* 161 */     this.field_3_color_palette_index = cpi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBoldWeight(short bw)
/*     */   {
/* 171 */     this.field_4_bold_weight = bw;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuperSubScript(short sss)
/*     */   {
/* 183 */     this.field_5_super_sub_script = sss;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnderline(byte u)
/*     */   {
/* 198 */     this.field_6_underline = u;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFamily(byte f)
/*     */   {
/* 207 */     this.field_7_family = f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharset(byte charset)
/*     */   {
/* 216 */     this.field_8_charset = charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontName(String fn)
/*     */   {
/* 226 */     this.field_11_font_name = fn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFontHeight()
/*     */   {
/* 235 */     return this.field_1_font_height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getAttributes()
/*     */   {
/* 244 */     return this.field_2_attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isItalic()
/*     */   {
/* 254 */     return italic.isSet(this.field_2_attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStruckout()
/*     */   {
/* 264 */     return strikeout.isSet(this.field_2_attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMacoutlined()
/*     */   {
/* 275 */     return macoutline.isSet(this.field_2_attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMacshadowed()
/*     */   {
/* 286 */     return macshadow.isSet(this.field_2_attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getColorPaletteIndex()
/*     */   {
/* 295 */     return this.field_3_color_palette_index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getBoldWeight()
/*     */   {
/* 305 */     return this.field_4_bold_weight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSuperSubScript()
/*     */   {
/* 317 */     return this.field_5_super_sub_script;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getUnderline()
/*     */   {
/* 332 */     return this.field_6_underline;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getFamily()
/*     */   {
/* 341 */     return this.field_7_family;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getCharset()
/*     */   {
/* 350 */     return this.field_8_charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFontName()
/*     */   {
/* 359 */     return this.field_11_font_name;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 363 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 365 */     sb.append("[FONT]\n");
/* 366 */     sb.append("    .fontheight    = ").append(HexDump.shortToHex(getFontHeight())).append("\n");
/* 367 */     sb.append("    .attributes    = ").append(HexDump.shortToHex(getAttributes())).append("\n");
/* 368 */     sb.append("       .italic     = ").append(isItalic()).append("\n");
/* 369 */     sb.append("       .strikout   = ").append(isStruckout()).append("\n");
/* 370 */     sb.append("       .macoutlined= ").append(isMacoutlined()).append("\n");
/* 371 */     sb.append("       .macshadowed= ").append(isMacshadowed()).append("\n");
/* 372 */     sb.append("    .colorpalette  = ").append(HexDump.shortToHex(getColorPaletteIndex())).append("\n");
/* 373 */     sb.append("    .boldweight    = ").append(HexDump.shortToHex(getBoldWeight())).append("\n");
/* 374 */     sb.append("    .supersubscript= ").append(HexDump.shortToHex(getSuperSubScript())).append("\n");
/* 375 */     sb.append("    .underline     = ").append(HexDump.byteToHex(getUnderline())).append("\n");
/* 376 */     sb.append("    .family        = ").append(HexDump.byteToHex(getFamily())).append("\n");
/* 377 */     sb.append("    .charset       = ").append(HexDump.byteToHex(getCharset())).append("\n");
/* 378 */     sb.append("    .fontname      = ").append(getFontName()).append("\n");
/* 379 */     sb.append("[/FONT]\n");
/* 380 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 385 */     out.writeShort(getFontHeight());
/* 386 */     out.writeShort(getAttributes());
/* 387 */     out.writeShort(getColorPaletteIndex());
/* 388 */     out.writeShort(getBoldWeight());
/* 389 */     out.writeShort(getSuperSubScript());
/* 390 */     out.writeByte(getUnderline());
/* 391 */     out.writeByte(getFamily());
/* 392 */     out.writeByte(getCharset());
/* 393 */     out.writeByte(this.field_9_zero);
/* 394 */     int fontNameLen = this.field_11_font_name.length();
/* 395 */     out.writeByte(fontNameLen);
/* 396 */     boolean hasMultibyte = StringUtil.hasMultibyte(this.field_11_font_name);
/* 397 */     out.writeByte(hasMultibyte ? 1 : 0);
/* 398 */     if (fontNameLen > 0) {
/* 399 */       if (hasMultibyte) {
/* 400 */         StringUtil.putUnicodeLE(this.field_11_font_name, out);
/*     */       } else
/* 402 */         StringUtil.putCompressedUnicode(this.field_11_font_name, out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 407 */     int size = 16;
/* 408 */     int fontNameLen = this.field_11_font_name.length();
/* 409 */     if (fontNameLen < 1) {
/* 410 */       return size;
/*     */     }
/*     */     
/* 413 */     boolean hasMultibyte = StringUtil.hasMultibyte(this.field_11_font_name);
/* 414 */     return size + fontNameLen * (hasMultibyte ? 2 : 1);
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 418 */     return 49;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cloneStyleFrom(FontRecord source)
/*     */   {
/* 427 */     this.field_1_font_height = source.field_1_font_height;
/* 428 */     this.field_2_attributes = source.field_2_attributes;
/* 429 */     this.field_3_color_palette_index = source.field_3_color_palette_index;
/* 430 */     this.field_4_bold_weight = source.field_4_bold_weight;
/* 431 */     this.field_5_super_sub_script = source.field_5_super_sub_script;
/* 432 */     this.field_6_underline = source.field_6_underline;
/* 433 */     this.field_7_family = source.field_7_family;
/* 434 */     this.field_8_charset = source.field_8_charset;
/* 435 */     this.field_9_zero = source.field_9_zero;
/* 436 */     this.field_11_font_name = source.field_11_font_name;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 440 */     int prime = 31;
/* 441 */     int result = 1;
/* 442 */     result = 31 * result + (this.field_11_font_name == null ? 0 : this.field_11_font_name.hashCode());
/*     */     
/*     */ 
/*     */ 
/* 446 */     result = 31 * result + this.field_1_font_height;
/* 447 */     result = 31 * result + this.field_2_attributes;
/* 448 */     result = 31 * result + this.field_3_color_palette_index;
/* 449 */     result = 31 * result + this.field_4_bold_weight;
/* 450 */     result = 31 * result + this.field_5_super_sub_script;
/* 451 */     result = 31 * result + this.field_6_underline;
/* 452 */     result = 31 * result + this.field_7_family;
/* 453 */     result = 31 * result + this.field_8_charset;
/* 454 */     result = 31 * result + this.field_9_zero;
/* 455 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean sameProperties(FontRecord other)
/*     */   {
/* 468 */     return (this.field_1_font_height == other.field_1_font_height) && (this.field_2_attributes == other.field_2_attributes) && (this.field_3_color_palette_index == other.field_3_color_palette_index) && (this.field_4_bold_weight == other.field_4_bold_weight) && (this.field_5_super_sub_script == other.field_5_super_sub_script) && (this.field_6_underline == other.field_6_underline) && (this.field_7_family == other.field_7_family) && (this.field_8_charset == other.field_8_charset) && (this.field_9_zero == other.field_9_zero) && (this.field_11_font_name.equals(other.field_11_font_name));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FontRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */