/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 1054;
/*     */   private final int field_1_index_code;
/*     */   private final boolean field_3_hasMultibyte;
/*     */   private final String field_4_formatstring;
/*     */   
/*     */   public FormatRecord(int indexCode, String fs)
/*     */   {
/*  40 */     this.field_1_index_code = indexCode;
/*  41 */     this.field_4_formatstring = fs;
/*  42 */     this.field_3_hasMultibyte = StringUtil.hasMultibyte(fs);
/*     */   }
/*     */   
/*     */   public FormatRecord(RecordInputStream in) {
/*  46 */     this.field_1_index_code = in.readShort();
/*  47 */     int field_3_unicode_len = in.readUShort();
/*  48 */     this.field_3_hasMultibyte = ((in.readByte() & 0x1) != 0);
/*     */     
/*  50 */     if (this.field_3_hasMultibyte) {
/*  51 */       this.field_4_formatstring = in.readUnicodeLEString(field_3_unicode_len);
/*     */     } else {
/*  53 */       this.field_4_formatstring = in.readCompressedUnicode(field_3_unicode_len);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndexCode()
/*     */   {
/*  64 */     return this.field_1_index_code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFormatString()
/*     */   {
/*  73 */     return this.field_4_formatstring;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  77 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  79 */     buffer.append("[FORMAT]\n");
/*  80 */     buffer.append("    .indexcode       = ").append(HexDump.shortToHex(getIndexCode())).append("\n");
/*  81 */     buffer.append("    .isUnicode       = ").append(this.field_3_hasMultibyte).append("\n");
/*  82 */     buffer.append("    .formatstring    = ").append(getFormatString()).append("\n");
/*  83 */     buffer.append("[/FORMAT]\n");
/*  84 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  88 */     String formatString = getFormatString();
/*  89 */     out.writeShort(getIndexCode());
/*  90 */     out.writeShort(formatString.length());
/*  91 */     out.writeByte(this.field_3_hasMultibyte ? 1 : 0);
/*     */     
/*  93 */     if (this.field_3_hasMultibyte) {
/*  94 */       StringUtil.putUnicodeLE(formatString, out);
/*     */     } else
/*  96 */       StringUtil.putCompressedUnicode(formatString, out);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 100 */     return 5 + getFormatString().length() * (this.field_3_hasMultibyte ? 2 : 1);
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 105 */     return 1054;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 110 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */