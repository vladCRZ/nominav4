/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormulaRecord
/*     */   extends CellRecord
/*     */ {
/*     */   public static final short sid = 6;
/*  39 */   private static int FIXED_SIZE = 14;
/*     */   
/*  41 */   private static final BitField alwaysCalc = BitFieldFactory.getInstance(1);
/*  42 */   private static final BitField calcOnLoad = BitFieldFactory.getInstance(2);
/*  43 */   private static final BitField sharedFormula = BitFieldFactory.getInstance(8);
/*     */   
/*     */   private double field_4_value;
/*     */   private short field_5_options;
/*     */   private int field_6_zero;
/*     */   private Formula field_8_parsed_expr;
/*     */   private SpecialCachedValue specialCachedValue;
/*     */   
/*     */   private static final class SpecialCachedValue
/*     */   {
/*     */     private static final long BIT_MARKER = -281474976710656L;
/*     */     private static final int VARIABLE_DATA_LENGTH = 6;
/*     */     private static final int DATA_INDEX = 2;
/*     */     public static final int STRING = 0;
/*     */     public static final int BOOLEAN = 1;
/*     */     public static final int ERROR_CODE = 2;
/*     */     public static final int EMPTY = 3;
/*     */     private final byte[] _variableData;
/*     */     
/*     */     private SpecialCachedValue(byte[] data)
/*     */     {
/*  64 */       this._variableData = data;
/*     */     }
/*     */     
/*  67 */     public int getTypeCode() { return this._variableData[0]; }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static SpecialCachedValue create(long valueLongBits)
/*     */     {
/*  75 */       if ((0xFFFF000000000000 & valueLongBits) != -281474976710656L) {
/*  76 */         return null;
/*     */       }
/*     */       
/*  79 */       byte[] result = new byte[6];
/*  80 */       long x = valueLongBits;
/*  81 */       for (int i = 0; i < 6; i++) {
/*  82 */         result[i] = ((byte)(int)x);
/*  83 */         x >>= 8;
/*     */       }
/*  85 */       switch (result[0]) {
/*     */       case 0: 
/*     */       case 1: 
/*     */       case 2: 
/*     */       case 3: 
/*     */         break;
/*     */       default: 
/*  92 */         throw new RecordFormatException("Bad special value code (" + result[0] + ")");
/*     */       }
/*  94 */       return new SpecialCachedValue(result);
/*     */     }
/*     */     
/*  97 */     public void serialize(LittleEndianOutput out) { out.write(this._variableData);
/*  98 */       out.writeShort(65535);
/*     */     }
/*     */     
/* 101 */     public String formatDebugString() { return formatValue() + ' ' + HexDump.toHex(this._variableData); }
/*     */     
/*     */     private String formatValue() {
/* 104 */       int typeCode = getTypeCode();
/* 105 */       switch (typeCode) {
/* 106 */       case 0:  return "<string>";
/* 107 */       case 1:  return getDataValue() == 0 ? "FALSE" : "TRUE";
/* 108 */       case 2:  return ErrorEval.getText(getDataValue());
/* 109 */       case 3:  return "<empty>";
/*     */       }
/* 111 */       return "#error(type=" + typeCode + ")#";
/*     */     }
/*     */     
/* 114 */     private int getDataValue() { return this._variableData[2]; }
/*     */     
/*     */     public static SpecialCachedValue createCachedEmptyValue() {
/* 117 */       return create(3, 0);
/*     */     }
/*     */     
/* 120 */     public static SpecialCachedValue createForString() { return create(0, 0); }
/*     */     
/*     */     public static SpecialCachedValue createCachedBoolean(boolean b) {
/* 123 */       return create(1, b ? 1 : 0);
/*     */     }
/*     */     
/* 126 */     public static SpecialCachedValue createCachedErrorCode(int errorCode) { return create(2, errorCode); }
/*     */     
/*     */     private static SpecialCachedValue create(int code, int data) {
/* 129 */       byte[] vd = { (byte)code, 0, (byte)data, 0, 0, 0 };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */       return new SpecialCachedValue(vd);
/*     */     }
/*     */     
/* 140 */     public String toString() { StringBuffer sb = new StringBuffer(64);
/* 141 */       sb.append(getClass().getName());
/* 142 */       sb.append('[').append(formatValue()).append(']');
/* 143 */       return sb.toString();
/*     */     }
/*     */     
/* 146 */     public int getValueType() { int typeCode = getTypeCode();
/* 147 */       switch (typeCode) {
/* 148 */       case 0:  return 1;
/* 149 */       case 1:  return 4;
/* 150 */       case 2:  return 5;
/* 151 */       case 3:  return 1;
/*     */       }
/* 153 */       throw new IllegalStateException("Unexpected type id (" + typeCode + ")");
/*     */     }
/*     */     
/* 156 */     public boolean getBooleanValue() { if (getTypeCode() != 1) {
/* 157 */         throw new IllegalStateException("Not a boolean cached value - " + formatValue());
/*     */       }
/* 159 */       return getDataValue() != 0;
/*     */     }
/*     */     
/* 162 */     public int getErrorValue() { if (getTypeCode() != 2) {
/* 163 */         throw new IllegalStateException("Not an error cached value - " + formatValue());
/*     */       }
/* 165 */       return getDataValue();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormulaRecord()
/*     */   {
/* 187 */     this.field_8_parsed_expr = Formula.create(Ptg.EMPTY_PTG_ARRAY);
/*     */   }
/*     */   
/*     */   public FormulaRecord(RecordInputStream ris) {
/* 191 */     super(ris);
/* 192 */     LittleEndianInput in = ris;
/* 193 */     long valueLongBits = in.readLong();
/* 194 */     this.field_5_options = in.readShort();
/* 195 */     this.specialCachedValue = SpecialCachedValue.create(valueLongBits);
/* 196 */     if (this.specialCachedValue == null) {
/* 197 */       this.field_4_value = Double.longBitsToDouble(valueLongBits);
/*     */     }
/*     */     
/* 200 */     this.field_6_zero = in.readInt();
/*     */     
/* 202 */     int field_7_expression_len = in.readShort();
/* 203 */     int nBytesAvailable = in.available();
/* 204 */     this.field_8_parsed_expr = Formula.read(field_7_expression_len, in, nBytesAvailable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(double value)
/*     */   {
/* 213 */     this.field_4_value = value;
/* 214 */     this.specialCachedValue = null;
/*     */   }
/*     */   
/*     */   public void setCachedResultTypeEmptyString() {
/* 218 */     this.specialCachedValue = SpecialCachedValue.createCachedEmptyValue();
/*     */   }
/*     */   
/* 221 */   public void setCachedResultTypeString() { this.specialCachedValue = SpecialCachedValue.createForString(); }
/*     */   
/*     */   public void setCachedResultErrorCode(int errorCode) {
/* 224 */     this.specialCachedValue = SpecialCachedValue.createCachedErrorCode(errorCode);
/*     */   }
/*     */   
/* 227 */   public void setCachedResultBoolean(boolean value) { this.specialCachedValue = SpecialCachedValue.createCachedBoolean(value); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasCachedResultString()
/*     */   {
/* 235 */     if (this.specialCachedValue == null) {
/* 236 */       return false;
/*     */     }
/* 238 */     return this.specialCachedValue.getTypeCode() == 0;
/*     */   }
/*     */   
/*     */   public int getCachedResultType() {
/* 242 */     if (this.specialCachedValue == null) {
/* 243 */       return 0;
/*     */     }
/* 245 */     return this.specialCachedValue.getValueType();
/*     */   }
/*     */   
/*     */   public boolean getCachedBooleanValue() {
/* 249 */     return this.specialCachedValue.getBooleanValue();
/*     */   }
/*     */   
/* 252 */   public int getCachedErrorValue() { return this.specialCachedValue.getErrorValue(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short options)
/*     */   {
/* 262 */     this.field_5_options = options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 271 */     return this.field_4_value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 280 */     return this.field_5_options;
/*     */   }
/*     */   
/*     */   public boolean isSharedFormula() {
/* 284 */     return sharedFormula.isSet(this.field_5_options);
/*     */   }
/*     */   
/* 287 */   public void setSharedFormula(boolean flag) { this.field_5_options = sharedFormula.setShortBoolean(this.field_5_options, flag); }
/*     */   
/*     */ 
/*     */   public boolean isAlwaysCalc()
/*     */   {
/* 292 */     return alwaysCalc.isSet(this.field_5_options);
/*     */   }
/*     */   
/* 295 */   public void setAlwaysCalc(boolean flag) { this.field_5_options = alwaysCalc.setShortBoolean(this.field_5_options, flag); }
/*     */   
/*     */ 
/*     */   public boolean isCalcOnLoad()
/*     */   {
/* 300 */     return calcOnLoad.isSet(this.field_5_options);
/*     */   }
/*     */   
/* 303 */   public void setCalcOnLoad(boolean flag) { this.field_5_options = calcOnLoad.setShortBoolean(this.field_5_options, flag); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ptg[] getParsedExpression()
/*     */   {
/* 311 */     return this.field_8_parsed_expr.getTokens();
/*     */   }
/*     */   
/*     */   public Formula getFormula() {
/* 315 */     return this.field_8_parsed_expr;
/*     */   }
/*     */   
/*     */   public void setParsedExpression(Ptg[] ptgs) {
/* 319 */     this.field_8_parsed_expr = Formula.create(ptgs);
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 323 */     return 6;
/*     */   }
/*     */   
/*     */   protected int getValueDataSize()
/*     */   {
/* 328 */     return FIXED_SIZE + this.field_8_parsed_expr.getEncodedSize();
/*     */   }
/*     */   
/*     */   protected void serializeValue(LittleEndianOutput out)
/*     */   {
/* 333 */     if (this.specialCachedValue == null) {
/* 334 */       out.writeDouble(this.field_4_value);
/*     */     } else {
/* 336 */       this.specialCachedValue.serialize(out);
/*     */     }
/*     */     
/* 339 */     out.writeShort(getOptions());
/*     */     
/* 341 */     out.writeInt(this.field_6_zero);
/* 342 */     this.field_8_parsed_expr.serialize(out);
/*     */   }
/*     */   
/*     */   protected String getRecordName()
/*     */   {
/* 347 */     return "FORMULA";
/*     */   }
/*     */   
/*     */   protected void appendValueText(StringBuilder sb)
/*     */   {
/* 352 */     sb.append("  .value\t = ");
/* 353 */     if (this.specialCachedValue == null) {
/* 354 */       sb.append(this.field_4_value).append("\n");
/*     */     } else {
/* 356 */       sb.append(this.specialCachedValue.formatDebugString()).append("\n");
/*     */     }
/* 358 */     sb.append("  .options   = ").append(HexDump.shortToHex(getOptions())).append("\n");
/* 359 */     sb.append("    .alwaysCalc= ").append(isAlwaysCalc()).append("\n");
/* 360 */     sb.append("    .calcOnLoad= ").append(isCalcOnLoad()).append("\n");
/* 361 */     sb.append("    .shared    = ").append(isSharedFormula()).append("\n");
/* 362 */     sb.append("  .zero      = ").append(HexDump.intToHex(this.field_6_zero));
/*     */     
/* 364 */     Ptg[] ptgs = this.field_8_parsed_expr.getTokens();
/* 365 */     for (int k = 0; k < ptgs.length; k++) {
/* 366 */       if (k > 0) {
/* 367 */         sb.append("\n");
/*     */       }
/* 369 */       sb.append("    Ptg[").append(k).append("]=");
/* 370 */       Ptg ptg = ptgs[k];
/* 371 */       sb.append(ptg.toString()).append(ptg.getRVAType());
/*     */     }
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 376 */     FormulaRecord rec = new FormulaRecord();
/* 377 */     copyBaseFields(rec);
/* 378 */     rec.field_4_value = this.field_4_value;
/* 379 */     rec.field_5_options = this.field_5_options;
/* 380 */     rec.field_6_zero = this.field_6_zero;
/* 381 */     rec.field_8_parsed_expr = this.field_8_parsed_expr;
/* 382 */     rec.specialCachedValue = this.specialCachedValue;
/* 383 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FormulaRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */