/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FtCblsSubRecord
/*    */   extends SubRecord
/*    */ {
/*    */   public static final short sid = 12;
/*    */   private static final int ENCODED_SIZE = 20;
/*    */   private byte[] reserved;
/*    */   
/*    */   public FtCblsSubRecord()
/*    */   {
/* 42 */     this.reserved = new byte[20];
/*    */   }
/*    */   
/*    */   public FtCblsSubRecord(LittleEndianInput in, int size) {
/* 46 */     if (size != 20) {
/* 47 */       throw new RecordFormatException("Unexpected size (" + size + ")");
/*    */     }
/*    */     
/* 50 */     byte[] buf = new byte[size];
/* 51 */     in.readFully(buf);
/* 52 */     this.reserved = buf;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 61 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 63 */     buffer.append("[FtCbls ]").append("\n");
/* 64 */     buffer.append("  size     = ").append(getDataSize()).append("\n");
/* 65 */     buffer.append("  reserved = ").append(HexDump.toHex(this.reserved)).append("\n");
/* 66 */     buffer.append("[/FtCbls ]").append("\n");
/* 67 */     return buffer.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void serialize(LittleEndianOutput out)
/*    */   {
/* 76 */     out.writeShort(12);
/* 77 */     out.writeShort(this.reserved.length);
/* 78 */     out.write(this.reserved);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 82 */     return this.reserved.length;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getSid()
/*    */   {
/* 90 */     return 12;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 94 */     FtCblsSubRecord rec = new FtCblsSubRecord();
/* 95 */     byte[] recdata = new byte[this.reserved.length];
/* 96 */     System.arraycopy(this.reserved, 0, recdata, 0, recdata.length);
/* 97 */     rec.reserved = recdata;
/* 98 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\FtCblsSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */