/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GroupMarkerSubRecord
/*    */   extends SubRecord
/*    */ {
/*    */   public static final short sid = 6;
/* 33 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*    */   private byte[] reserved;
/*    */   
/*    */   public GroupMarkerSubRecord()
/*    */   {
/* 38 */     this.reserved = EMPTY_BYTE_ARRAY;
/*    */   }
/*    */   
/*    */   public GroupMarkerSubRecord(LittleEndianInput in, int size) {
/* 42 */     byte[] buf = new byte[size];
/* 43 */     in.readFully(buf);
/* 44 */     this.reserved = buf;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 49 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 51 */     String nl = System.getProperty("line.separator");
/* 52 */     buffer.append("[ftGmo]" + nl);
/* 53 */     buffer.append("  reserved = ").append(HexDump.toHex(this.reserved)).append(nl);
/* 54 */     buffer.append("[/ftGmo]" + nl);
/* 55 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 59 */     out.writeShort(6);
/* 60 */     out.writeShort(this.reserved.length);
/* 61 */     out.write(this.reserved);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 65 */     return this.reserved.length;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 70 */     return 6;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 74 */     GroupMarkerSubRecord rec = new GroupMarkerSubRecord();
/* 75 */     rec.reserved = new byte[this.reserved.length];
/* 76 */     for (int i = 0; i < this.reserved.length; i++)
/* 77 */       rec.reserved[i] = this.reserved[i];
/* 78 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\GroupMarkerSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */