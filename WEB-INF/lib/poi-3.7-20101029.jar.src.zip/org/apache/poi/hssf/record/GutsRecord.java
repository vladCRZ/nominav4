/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GutsRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 128;
/*     */   private short field_1_left_row_gutter;
/*     */   private short field_2_top_col_gutter;
/*     */   private short field_3_row_level_max;
/*     */   private short field_4_col_level_max;
/*     */   
/*     */   public GutsRecord() {}
/*     */   
/*     */   public GutsRecord(RecordInputStream in)
/*     */   {
/*  48 */     this.field_1_left_row_gutter = in.readShort();
/*  49 */     this.field_2_top_col_gutter = in.readShort();
/*  50 */     this.field_3_row_level_max = in.readShort();
/*  51 */     this.field_4_col_level_max = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeftRowGutter(short gut)
/*     */   {
/*  62 */     this.field_1_left_row_gutter = gut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTopColGutter(short gut)
/*     */   {
/*  73 */     this.field_2_top_col_gutter = gut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRowLevelMax(short max)
/*     */   {
/*  84 */     this.field_3_row_level_max = max;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColLevelMax(short max)
/*     */   {
/*  95 */     this.field_4_col_level_max = max;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLeftRowGutter()
/*     */   {
/* 106 */     return this.field_1_left_row_gutter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getTopColGutter()
/*     */   {
/* 117 */     return this.field_2_top_col_gutter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getRowLevelMax()
/*     */   {
/* 128 */     return this.field_3_row_level_max;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getColLevelMax()
/*     */   {
/* 139 */     return this.field_4_col_level_max;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 144 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 146 */     buffer.append("[GUTS]\n");
/* 147 */     buffer.append("    .leftgutter     = ").append(Integer.toHexString(getLeftRowGutter())).append("\n");
/*     */     
/* 149 */     buffer.append("    .topgutter      = ").append(Integer.toHexString(getTopColGutter())).append("\n");
/*     */     
/* 151 */     buffer.append("    .rowlevelmax    = ").append(Integer.toHexString(getRowLevelMax())).append("\n");
/*     */     
/* 153 */     buffer.append("    .collevelmax    = ").append(Integer.toHexString(getColLevelMax())).append("\n");
/*     */     
/* 155 */     buffer.append("[/GUTS]\n");
/* 156 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 160 */     out.writeShort(getLeftRowGutter());
/* 161 */     out.writeShort(getTopColGutter());
/* 162 */     out.writeShort(getRowLevelMax());
/* 163 */     out.writeShort(getColLevelMax());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 167 */     return 8;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 172 */     return 128;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 176 */     GutsRecord rec = new GutsRecord();
/* 177 */     rec.field_1_left_row_gutter = this.field_1_left_row_gutter;
/* 178 */     rec.field_2_top_col_gutter = this.field_2_top_col_gutter;
/* 179 */     rec.field_3_row_level_max = this.field_3_row_level_max;
/* 180 */     rec.field_4_col_level_max = this.field_4_col_level_max;
/* 181 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\GutsRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */