/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HCenterRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 131;
/*    */   private short field_1_hcenter;
/*    */   
/*    */   public HCenterRecord() {}
/*    */   
/*    */   public HCenterRecord(RecordInputStream in)
/*    */   {
/* 40 */     this.field_1_hcenter = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setHCenter(boolean hc)
/*    */   {
/* 50 */     if (hc == true)
/*    */     {
/* 52 */       this.field_1_hcenter = 1;
/*    */     }
/*    */     else
/*    */     {
/* 56 */       this.field_1_hcenter = 0;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getHCenter()
/*    */   {
/* 67 */     return this.field_1_hcenter == 1;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 72 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 74 */     buffer.append("[HCENTER]\n");
/* 75 */     buffer.append("    .hcenter        = ").append(getHCenter()).append("\n");
/*    */     
/* 77 */     buffer.append("[/HCENTER]\n");
/* 78 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 82 */     out.writeShort(this.field_1_hcenter);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 86 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 91 */     return 131;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 95 */     HCenterRecord rec = new HCenterRecord();
/* 96 */     rec.field_1_hcenter = this.field_1_hcenter;
/* 97 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\HCenterRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */