/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HeaderRecord
/*    */   extends HeaderFooterBase
/*    */ {
/*    */   public static final short sid = 20;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HeaderRecord(String text)
/*    */   {
/* 32 */     super(text);
/*    */   }
/*    */   
/*    */   public HeaderRecord(RecordInputStream in) {
/* 36 */     super(in);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 40 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 42 */     buffer.append("[HEADER]\n");
/* 43 */     buffer.append("    .header = ").append(getText()).append("\n");
/* 44 */     buffer.append("[/HEADER]\n");
/* 45 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 49 */     return 20;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 53 */     return new HeaderRecord(getText());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\HeaderRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */