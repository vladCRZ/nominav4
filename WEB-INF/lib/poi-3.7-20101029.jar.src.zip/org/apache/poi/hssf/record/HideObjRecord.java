/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HideObjRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 141;
/*    */   public static final short HIDE_ALL = 2;
/*    */   public static final short SHOW_PLACEHOLDERS = 1;
/*    */   public static final short SHOW_ALL = 0;
/*    */   private short field_1_hide_obj;
/*    */   
/*    */   public HideObjRecord() {}
/*    */   
/*    */   public HideObjRecord(RecordInputStream in)
/*    */   {
/* 47 */     this.field_1_hide_obj = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setHideObj(short hide)
/*    */   {
/* 61 */     this.field_1_hide_obj = hide;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getHideObj()
/*    */   {
/* 75 */     return this.field_1_hide_obj;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 80 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 82 */     buffer.append("[HIDEOBJ]\n");
/* 83 */     buffer.append("    .hideobj         = ").append(Integer.toHexString(getHideObj())).append("\n");
/*    */     
/* 85 */     buffer.append("[/HIDEOBJ]\n");
/* 86 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 90 */     out.writeShort(getHideObj());
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 94 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 99 */     return 141;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\HideObjRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */