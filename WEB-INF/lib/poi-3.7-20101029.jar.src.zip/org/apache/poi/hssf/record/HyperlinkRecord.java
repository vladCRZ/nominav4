/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.HexRead;
/*     */ import org.apache.poi.util.LittleEndianByteArrayInputStream;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HyperlinkRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 440;
/*     */   static final int HLINK_URL = 1;
/*     */   static final int HLINK_ABS = 2;
/*     */   static final int HLINK_LABEL = 20;
/*     */   static final int HLINK_PLACE = 8;
/*     */   private static final int HLINK_TARGET_FRAME = 128;
/*     */   private static final int HLINK_UNC_PATH = 256;
/*     */   public HyperlinkRecord() {}
/*     */   
/*     */   static final class GUID
/*     */   {
/*     */     private static final int TEXT_FORMAT_LENGTH = 36;
/*     */     public static final int ENCODED_SIZE = 16;
/*     */     private final int _d1;
/*     */     private final int _d2;
/*     */     private final int _d3;
/*     */     private final long _d4;
/*     */     
/*     */     public GUID(LittleEndianInput in)
/*     */     {
/*  64 */       this(in.readInt(), in.readUShort(), in.readUShort(), in.readLong());
/*     */     }
/*     */     
/*     */     public GUID(int d1, int d2, int d3, long d4) {
/*  68 */       this._d1 = d1;
/*  69 */       this._d2 = d2;
/*  70 */       this._d3 = d3;
/*  71 */       this._d4 = d4;
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  75 */       out.writeInt(this._d1);
/*  76 */       out.writeShort(this._d2);
/*  77 */       out.writeShort(this._d3);
/*  78 */       out.writeLong(this._d4);
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/*  83 */       GUID other = (GUID)obj;
/*  84 */       if ((obj == null) || (!(obj instanceof GUID)))
/*  85 */         return false;
/*  86 */       return (this._d1 == other._d1) && (this._d2 == other._d2) && (this._d3 == other._d3) && (this._d4 == other._d4);
/*     */     }
/*     */     
/*     */     public int getD1()
/*     */     {
/*  91 */       return this._d1;
/*     */     }
/*     */     
/*     */     public int getD2() {
/*  95 */       return this._d2;
/*     */     }
/*     */     
/*     */     public int getD3() {
/*  99 */       return this._d3;
/*     */     }
/*     */     
/*     */     public long getD4()
/*     */     {
/* 104 */       ByteArrayOutputStream baos = new ByteArrayOutputStream(8);
/*     */       try {
/* 106 */         new DataOutputStream(baos).writeLong(this._d4);
/*     */       } catch (IOException e) {
/* 108 */         throw new RuntimeException(e);
/*     */       }
/* 110 */       byte[] buf = baos.toByteArray();
/* 111 */       return new LittleEndianByteArrayInputStream(buf).readLong();
/*     */     }
/*     */     
/*     */     public String formatAsString()
/*     */     {
/* 116 */       StringBuilder sb = new StringBuilder(36);
/*     */       
/* 118 */       int PREFIX_LEN = "0x".length();
/* 119 */       sb.append(HexDump.intToHex(this._d1), PREFIX_LEN, 8);
/* 120 */       sb.append("-");
/* 121 */       sb.append(HexDump.shortToHex(this._d2), PREFIX_LEN, 4);
/* 122 */       sb.append("-");
/* 123 */       sb.append(HexDump.shortToHex(this._d3), PREFIX_LEN, 4);
/* 124 */       sb.append("-");
/* 125 */       char[] d4Chars = HexDump.longToHex(getD4());
/* 126 */       sb.append(d4Chars, PREFIX_LEN, 4);
/* 127 */       sb.append("-");
/* 128 */       sb.append(d4Chars, PREFIX_LEN + 4, 12);
/* 129 */       return sb.toString();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 134 */       StringBuilder sb = new StringBuilder(64);
/* 135 */       sb.append(getClass().getName()).append(" [");
/* 136 */       sb.append(formatAsString());
/* 137 */       sb.append("]");
/* 138 */       return sb.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static GUID parse(String rep)
/*     */     {
/* 148 */       char[] cc = rep.toCharArray();
/* 149 */       if (cc.length != 36) {
/* 150 */         throw new RecordFormatException("supplied text is the wrong length for a GUID");
/*     */       }
/* 152 */       int d0 = (parseShort(cc, 0) << 16) + (parseShort(cc, 4) << 0);
/* 153 */       int d1 = parseShort(cc, 9);
/* 154 */       int d2 = parseShort(cc, 14);
/* 155 */       for (int i = 23; i > 19; i--) {
/* 156 */         cc[i] = cc[(i - 1)];
/*     */       }
/* 158 */       long d3 = parseLELong(cc, 20);
/*     */       
/* 160 */       return new GUID(d0, d1, d2, d3);
/*     */     }
/*     */     
/*     */     private static long parseLELong(char[] cc, int startIndex) {
/* 164 */       long acc = 0L;
/* 165 */       for (int i = startIndex + 14; i >= startIndex; i -= 2) {
/* 166 */         acc <<= 4;
/* 167 */         acc += parseHexChar(cc[(i + 0)]);
/* 168 */         acc <<= 4;
/* 169 */         acc += parseHexChar(cc[(i + 1)]);
/*     */       }
/* 171 */       return acc;
/*     */     }
/*     */     
/*     */     private static int parseShort(char[] cc, int startIndex) {
/* 175 */       int acc = 0;
/* 176 */       for (int i = 0; i < 4; i++) {
/* 177 */         acc <<= 4;
/* 178 */         acc += parseHexChar(cc[(startIndex + i)]);
/*     */       }
/* 180 */       return acc;
/*     */     }
/*     */     
/*     */     private static int parseHexChar(char c) {
/* 184 */       if ((c >= '0') && (c <= '9')) {
/* 185 */         return c - '0';
/*     */       }
/* 187 */       if ((c >= 'A') && (c <= 'F')) {
/* 188 */         return c - 'A' + 10;
/*     */       }
/* 190 */       if ((c >= 'a') && (c <= 'f')) {
/* 191 */         return c - 'a' + 10;
/*     */       }
/* 193 */       throw new RecordFormatException("Bad hex char '" + c + "'");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */   static final GUID STD_MONIKER = GUID.parse("79EAC9D0-BAF9-11CE-8C82-00AA004BA90B");
/* 209 */   static final GUID URL_MONIKER = GUID.parse("79EAC9E0-BAF9-11CE-8C82-00AA004BA90B");
/* 210 */   static final GUID FILE_MONIKER = GUID.parse("00000303-0000-0000-C000-000000000046");
/*     */   
/* 212 */   private static final byte[] URL_TAIL = HexRead.readFromString("79 58 81 F4  3B 1D 7F 48   AF 2C 82 5D  C4 85 27 63   00 00 00 00  A5 AB 00 00");
/*     */   
/* 214 */   private static final byte[] FILE_TAIL = HexRead.readFromString("FF FF AD DE  00 00 00 00   00 00 00 00  00 00 00 00   00 00 00 00  00 00 00 00");
/*     */   
/* 216 */   private static final int TAIL_SIZE = FILE_TAIL.length;
/*     */   
/*     */ 
/*     */ 
/*     */   private CellRangeAddress _range;
/*     */   
/*     */ 
/*     */ 
/*     */   private GUID _guid;
/*     */   
/*     */ 
/*     */ 
/*     */   private int _fileOpts;
/*     */   
/*     */ 
/*     */ 
/*     */   private int _linkOpts;
/*     */   
/*     */ 
/*     */   private String _label;
/*     */   
/*     */ 
/*     */   private String _targetFrame;
/*     */   
/*     */ 
/*     */   private GUID _moniker;
/*     */   
/*     */ 
/*     */   private String _shortFilename;
/*     */   
/*     */ 
/*     */   private String _address;
/*     */   
/*     */ 
/*     */   private String _textMark;
/*     */   
/*     */ 
/*     */   private byte[] _uninterpretedTail;
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFirstColumn()
/*     */   {
/* 259 */     return this._range.getFirstColumn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFirstColumn(int col)
/*     */   {
/* 266 */     this._range.setFirstColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLastColumn()
/*     */   {
/* 273 */     return this._range.getLastColumn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLastColumn(int col)
/*     */   {
/* 280 */     this._range.setLastColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFirstRow()
/*     */   {
/* 287 */     return this._range.getFirstRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFirstRow(int col)
/*     */   {
/* 294 */     this._range.setFirstRow(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLastRow()
/*     */   {
/* 301 */     return this._range.getLastRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLastRow(int col)
/*     */   {
/* 308 */     this._range.setLastRow(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   GUID getGuid()
/*     */   {
/* 315 */     return this._guid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   GUID getMoniker()
/*     */   {
/* 323 */     return this._moniker;
/*     */   }
/*     */   
/*     */   private static String cleanString(String s) {
/* 327 */     if (s == null) {
/* 328 */       return null;
/*     */     }
/* 330 */     int idx = s.indexOf(0);
/* 331 */     if (idx < 0) {
/* 332 */       return s;
/*     */     }
/* 334 */     return s.substring(0, idx);
/*     */   }
/*     */   
/* 337 */   private static String appendNullTerm(String s) { if (s == null) {
/* 338 */       return null;
/*     */     }
/* 340 */     return s + '\000';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 349 */     return cleanString(this._label);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 358 */     this._label = appendNullTerm(label);
/*     */   }
/*     */   
/* 361 */   public String getTargetFrame() { return cleanString(this._targetFrame); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddress()
/*     */   {
/* 370 */     if (((this._linkOpts & 0x1) != 0) && (FILE_MONIKER.equals(this._moniker)))
/* 371 */       return cleanString(this._address != null ? this._address : this._shortFilename);
/* 372 */     if ((this._linkOpts & 0x8) != 0) {
/* 373 */       return cleanString(this._textMark);
/*     */     }
/* 375 */     return cleanString(this._address);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(String address)
/*     */   {
/* 384 */     if (((this._linkOpts & 0x1) != 0) && (FILE_MONIKER.equals(this._moniker))) {
/* 385 */       this._shortFilename = appendNullTerm(address);
/* 386 */     } else if ((this._linkOpts & 0x8) != 0) {
/* 387 */       this._textMark = appendNullTerm(address);
/*     */     } else
/* 389 */       this._address = appendNullTerm(address);
/*     */   }
/*     */   
/*     */   public String getShortFilename() {
/* 393 */     return cleanString(this._shortFilename);
/*     */   }
/*     */   
/*     */   public void setShortFilename(String shortFilename) {
/* 397 */     this._shortFilename = appendNullTerm(shortFilename);
/*     */   }
/*     */   
/*     */   public String getTextMark() {
/* 401 */     return cleanString(this._textMark);
/*     */   }
/*     */   
/* 404 */   public void setTextMark(String textMark) { this._textMark = appendNullTerm(textMark); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLinkOptions()
/*     */   {
/* 413 */     return this._linkOpts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLabelOptions()
/*     */   {
/* 420 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFileOptions()
/*     */   {
/* 427 */     return this._fileOpts;
/*     */   }
/*     */   
/*     */   public HyperlinkRecord(RecordInputStream in)
/*     */   {
/* 432 */     this._range = new CellRangeAddress(in);
/*     */     
/* 434 */     this._guid = new GUID(in);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 440 */     int streamVersion = in.readInt();
/* 441 */     if (streamVersion != 2) {
/* 442 */       throw new RecordFormatException("Stream Version must be 0x2 but found " + streamVersion);
/*     */     }
/* 444 */     this._linkOpts = in.readInt();
/*     */     
/* 446 */     if ((this._linkOpts & 0x14) != 0) {
/* 447 */       int label_len = in.readInt();
/* 448 */       this._label = in.readUnicodeLEString(label_len);
/*     */     }
/*     */     
/* 451 */     if ((this._linkOpts & 0x80) != 0) {
/* 452 */       int len = in.readInt();
/* 453 */       this._targetFrame = in.readUnicodeLEString(len);
/*     */     }
/*     */     
/* 456 */     if (((this._linkOpts & 0x1) != 0) && ((this._linkOpts & 0x100) != 0)) {
/* 457 */       this._moniker = null;
/* 458 */       int nChars = in.readInt();
/* 459 */       this._address = in.readUnicodeLEString(nChars);
/*     */     }
/*     */     
/* 462 */     if (((this._linkOpts & 0x1) != 0) && ((this._linkOpts & 0x100) == 0)) {
/* 463 */       this._moniker = new GUID(in);
/*     */       
/* 465 */       if (URL_MONIKER.equals(this._moniker)) {
/* 466 */         int length = in.readInt();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 473 */         int remaining = in.remaining();
/* 474 */         if (length == remaining) {
/* 475 */           int nChars = length / 2;
/* 476 */           this._address = in.readUnicodeLEString(nChars);
/*     */         } else {
/* 478 */           int nChars = (length - TAIL_SIZE) / 2;
/* 479 */           this._address = in.readUnicodeLEString(nChars);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 488 */           this._uninterpretedTail = readTail(URL_TAIL, in);
/*     */         }
/* 490 */       } else if (FILE_MONIKER.equals(this._moniker)) {
/* 491 */         this._fileOpts = in.readShort();
/*     */         
/* 493 */         int len = in.readInt();
/* 494 */         this._shortFilename = StringUtil.readCompressedUnicode(in, len);
/* 495 */         this._uninterpretedTail = readTail(FILE_TAIL, in);
/* 496 */         int size = in.readInt();
/* 497 */         if (size > 0) {
/* 498 */           int charDataSize = in.readInt();
/*     */           
/*     */ 
/* 501 */           int optFlags = in.readUShort();
/* 502 */           if (optFlags != 3) {
/* 503 */             throw new RecordFormatException("Expected 0x3 but found " + optFlags);
/*     */           }
/* 505 */           this._address = StringUtil.readUnicodeLE(in, charDataSize / 2);
/*     */         } else {
/* 507 */           this._address = null;
/*     */         }
/* 509 */       } else if (STD_MONIKER.equals(this._moniker)) {
/* 510 */         this._fileOpts = in.readShort();
/*     */         
/* 512 */         int len = in.readInt();
/*     */         
/* 514 */         byte[] path_bytes = new byte[len];
/* 515 */         in.readFully(path_bytes);
/*     */         
/* 517 */         this._address = new String(path_bytes);
/*     */       }
/*     */     }
/*     */     
/* 521 */     if ((this._linkOpts & 0x8) != 0)
/*     */     {
/* 523 */       int len = in.readInt();
/* 524 */       this._textMark = in.readUnicodeLEString(len);
/*     */     }
/*     */     
/* 527 */     if (in.remaining() > 0) {
/* 528 */       System.out.println(HexDump.toHex(in.readRemainder()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 533 */     this._range.serialize(out);
/*     */     
/* 535 */     this._guid.serialize(out);
/* 536 */     out.writeInt(2);
/* 537 */     out.writeInt(this._linkOpts);
/*     */     
/* 539 */     if ((this._linkOpts & 0x14) != 0) {
/* 540 */       out.writeInt(this._label.length());
/* 541 */       StringUtil.putUnicodeLE(this._label, out);
/*     */     }
/* 543 */     if ((this._linkOpts & 0x80) != 0) {
/* 544 */       out.writeInt(this._targetFrame.length());
/* 545 */       StringUtil.putUnicodeLE(this._targetFrame, out);
/*     */     }
/*     */     
/* 548 */     if (((this._linkOpts & 0x1) != 0) && ((this._linkOpts & 0x100) != 0)) {
/* 549 */       out.writeInt(this._address.length());
/* 550 */       StringUtil.putUnicodeLE(this._address, out);
/*     */     }
/*     */     
/* 553 */     if (((this._linkOpts & 0x1) != 0) && ((this._linkOpts & 0x100) == 0)) {
/* 554 */       this._moniker.serialize(out);
/* 555 */       if (URL_MONIKER.equals(this._moniker)) {
/* 556 */         if (this._uninterpretedTail == null) {
/* 557 */           out.writeInt(this._address.length() * 2);
/* 558 */           StringUtil.putUnicodeLE(this._address, out);
/*     */         } else {
/* 560 */           out.writeInt(this._address.length() * 2 + TAIL_SIZE);
/* 561 */           StringUtil.putUnicodeLE(this._address, out);
/* 562 */           writeTail(this._uninterpretedTail, out);
/*     */         }
/* 564 */       } else if (FILE_MONIKER.equals(this._moniker)) {
/* 565 */         out.writeShort(this._fileOpts);
/* 566 */         out.writeInt(this._shortFilename.length());
/* 567 */         StringUtil.putCompressedUnicode(this._shortFilename, out);
/* 568 */         writeTail(this._uninterpretedTail, out);
/* 569 */         if (this._address == null) {
/* 570 */           out.writeInt(0);
/*     */         } else {
/* 572 */           int addrLen = this._address.length() * 2;
/* 573 */           out.writeInt(addrLen + 6);
/* 574 */           out.writeInt(addrLen);
/* 575 */           out.writeShort(3);
/* 576 */           StringUtil.putUnicodeLE(this._address, out);
/*     */         }
/*     */       }
/*     */     }
/* 580 */     if ((this._linkOpts & 0x8) != 0) {
/* 581 */       out.writeInt(this._textMark.length());
/* 582 */       StringUtil.putUnicodeLE(this._textMark, out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 587 */     int size = 0;
/* 588 */     size += 8;
/* 589 */     size += 16;
/* 590 */     size += 4;
/* 591 */     size += 4;
/* 592 */     if ((this._linkOpts & 0x14) != 0) {
/* 593 */       size += 4;
/* 594 */       size += this._label.length() * 2;
/*     */     }
/* 596 */     if ((this._linkOpts & 0x80) != 0) {
/* 597 */       size += 4;
/* 598 */       size += this._targetFrame.length() * 2;
/*     */     }
/* 600 */     if (((this._linkOpts & 0x1) != 0) && ((this._linkOpts & 0x100) != 0)) {
/* 601 */       size += 4;
/* 602 */       size += this._address.length() * 2;
/*     */     }
/* 604 */     if (((this._linkOpts & 0x1) != 0) && ((this._linkOpts & 0x100) == 0)) {
/* 605 */       size += 16;
/* 606 */       if (URL_MONIKER.equals(this._moniker)) {
/* 607 */         size += 4;
/* 608 */         size += this._address.length() * 2;
/* 609 */         if (this._uninterpretedTail != null) {
/* 610 */           size += TAIL_SIZE;
/*     */         }
/* 612 */       } else if (FILE_MONIKER.equals(this._moniker)) {
/* 613 */         size += 2;
/* 614 */         size += 4;
/* 615 */         size += this._shortFilename.length();
/* 616 */         size += TAIL_SIZE;
/* 617 */         size += 4;
/* 618 */         if (this._address != null) {
/* 619 */           size += 6;
/* 620 */           size += this._address.length() * 2;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 625 */     if ((this._linkOpts & 0x8) != 0) {
/* 626 */       size += 4;
/* 627 */       size += this._textMark.length() * 2;
/*     */     }
/* 629 */     return size;
/*     */   }
/*     */   
/*     */   private static byte[] readTail(byte[] expectedTail, LittleEndianInput in)
/*     */   {
/* 634 */     byte[] result = new byte[TAIL_SIZE];
/* 635 */     in.readFully(result);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 644 */     return result;
/*     */   }
/*     */   
/* 647 */   private static void writeTail(byte[] tail, LittleEndianOutput out) { out.write(tail); }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 651 */     return 440;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 656 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 658 */     buffer.append("[HYPERLINK RECORD]\n");
/* 659 */     buffer.append("    .range   = ").append(this._range.formatAsString()).append("\n");
/* 660 */     buffer.append("    .guid    = ").append(this._guid.formatAsString()).append("\n");
/* 661 */     buffer.append("    .linkOpts= ").append(HexDump.intToHex(this._linkOpts)).append("\n");
/* 662 */     buffer.append("    .label   = ").append(getLabel()).append("\n");
/* 663 */     if ((this._linkOpts & 0x80) != 0) {
/* 664 */       buffer.append("    .targetFrame= ").append(getTargetFrame()).append("\n");
/*     */     }
/* 666 */     if (((this._linkOpts & 0x1) != 0) && (this._moniker != null)) {
/* 667 */       buffer.append("    .moniker   = ").append(this._moniker.formatAsString()).append("\n");
/*     */     }
/* 669 */     if ((this._linkOpts & 0x8) != 0) {
/* 670 */       buffer.append("    .textMark= ").append(getTextMark()).append("\n");
/*     */     }
/* 672 */     buffer.append("    .address   = ").append(getAddress()).append("\n");
/* 673 */     buffer.append("[/HYPERLINK RECORD]\n");
/* 674 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isUrlLink()
/*     */   {
/* 681 */     return ((this._linkOpts & 0x1) > 0) && ((this._linkOpts & 0x2) > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFileLink()
/*     */   {
/* 688 */     return ((this._linkOpts & 0x1) > 0) && ((this._linkOpts & 0x2) == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDocumentLink()
/*     */   {
/* 695 */     return (this._linkOpts & 0x8) > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void newUrlLink()
/*     */   {
/* 702 */     this._range = new CellRangeAddress(0, 0, 0, 0);
/* 703 */     this._guid = STD_MONIKER;
/* 704 */     this._linkOpts = 23;
/* 705 */     setLabel("");
/* 706 */     this._moniker = URL_MONIKER;
/* 707 */     setAddress("");
/* 708 */     this._uninterpretedTail = URL_TAIL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void newFileLink()
/*     */   {
/* 715 */     this._range = new CellRangeAddress(0, 0, 0, 0);
/* 716 */     this._guid = STD_MONIKER;
/* 717 */     this._linkOpts = 21;
/* 718 */     this._fileOpts = 0;
/* 719 */     setLabel("");
/* 720 */     this._moniker = FILE_MONIKER;
/* 721 */     setAddress(null);
/* 722 */     setShortFilename("");
/* 723 */     this._uninterpretedTail = FILE_TAIL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void newDocumentLink()
/*     */   {
/* 730 */     this._range = new CellRangeAddress(0, 0, 0, 0);
/* 731 */     this._guid = STD_MONIKER;
/* 732 */     this._linkOpts = 28;
/* 733 */     setLabel("");
/* 734 */     this._moniker = FILE_MONIKER;
/* 735 */     setAddress("");
/* 736 */     setTextMark("");
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 740 */     HyperlinkRecord rec = new HyperlinkRecord();
/* 741 */     rec._range = this._range.copy();
/* 742 */     rec._guid = this._guid;
/* 743 */     rec._linkOpts = this._linkOpts;
/* 744 */     rec._fileOpts = this._fileOpts;
/* 745 */     rec._label = this._label;
/* 746 */     rec._address = this._address;
/* 747 */     rec._moniker = this._moniker;
/* 748 */     rec._shortFilename = this._shortFilename;
/* 749 */     rec._targetFrame = this._targetFrame;
/* 750 */     rec._textMark = this._textMark;
/* 751 */     rec._uninterpretedTail = this._uninterpretedTail;
/* 752 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\HyperlinkRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */