/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.IntList;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IndexRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 523;
/*     */   private int field_2_first_row;
/*     */   private int field_3_last_row_add1;
/*     */   private int field_4_zero;
/*     */   private IntList field_5_dbcells;
/*     */   
/*     */   public IndexRecord() {}
/*     */   
/*     */   public IndexRecord(RecordInputStream in)
/*     */   {
/*  45 */     int field_1_zero = in.readInt();
/*  46 */     if (field_1_zero != 0) {
/*  47 */       throw new RecordFormatException("Expected zero for field 1 but got " + field_1_zero);
/*     */     }
/*  49 */     this.field_2_first_row = in.readInt();
/*  50 */     this.field_3_last_row_add1 = in.readInt();
/*  51 */     this.field_4_zero = in.readInt();
/*     */     
/*  53 */     int nCells = in.remaining() / 4;
/*  54 */     this.field_5_dbcells = new IntList(nCells);
/*  55 */     for (int i = 0; i < nCells; i++) {
/*  56 */       this.field_5_dbcells.add(in.readInt());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFirstRow(int row)
/*     */   {
/*  62 */     this.field_2_first_row = row;
/*     */   }
/*     */   
/*     */   public void setLastRowAdd1(int row)
/*     */   {
/*  67 */     this.field_3_last_row_add1 = row;
/*     */   }
/*     */   
/*     */   public void addDbcell(int cell)
/*     */   {
/*  72 */     if (this.field_5_dbcells == null)
/*     */     {
/*  74 */       this.field_5_dbcells = new IntList();
/*     */     }
/*  76 */     this.field_5_dbcells.add(cell);
/*     */   }
/*     */   
/*     */   public void setDbcell(int cell, int value)
/*     */   {
/*  81 */     this.field_5_dbcells.set(cell, value);
/*     */   }
/*     */   
/*     */   public int getFirstRow()
/*     */   {
/*  86 */     return this.field_2_first_row;
/*     */   }
/*     */   
/*     */   public int getLastRowAdd1()
/*     */   {
/*  91 */     return this.field_3_last_row_add1;
/*     */   }
/*     */   
/*     */   public int getNumDbcells()
/*     */   {
/*  96 */     if (this.field_5_dbcells == null)
/*     */     {
/*  98 */       return 0;
/*     */     }
/* 100 */     return this.field_5_dbcells.size();
/*     */   }
/*     */   
/*     */   public int getDbcellAt(int cellnum)
/*     */   {
/* 105 */     return this.field_5_dbcells.get(cellnum);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 110 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 112 */     buffer.append("[INDEX]\n");
/* 113 */     buffer.append("    .firstrow       = ").append(Integer.toHexString(getFirstRow())).append("\n");
/*     */     
/* 115 */     buffer.append("    .lastrowadd1    = ").append(Integer.toHexString(getLastRowAdd1())).append("\n");
/*     */     
/* 117 */     for (int k = 0; k < getNumDbcells(); k++) {
/* 118 */       buffer.append("    .dbcell_").append(k).append(" = ").append(Integer.toHexString(getDbcellAt(k))).append("\n");
/*     */     }
/*     */     
/* 121 */     buffer.append("[/INDEX]\n");
/* 122 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 127 */     out.writeInt(0);
/* 128 */     out.writeInt(getFirstRow());
/* 129 */     out.writeInt(getLastRowAdd1());
/* 130 */     out.writeInt(this.field_4_zero);
/* 131 */     for (int k = 0; k < getNumDbcells(); k++) {
/* 132 */       out.writeInt(getDbcellAt(k));
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 137 */     return 16 + getNumDbcells() * 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getRecordSizeForBlockCount(int blockCount)
/*     */   {
/* 145 */     return 20 + 4 * blockCount;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 149 */     return 523;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 153 */     IndexRecord rec = new IndexRecord();
/* 154 */     rec.field_2_first_row = this.field_2_first_row;
/* 155 */     rec.field_3_last_row_add1 = this.field_3_last_row_add1;
/* 156 */     rec.field_4_zero = this.field_4_zero;
/* 157 */     rec.field_5_dbcells = new IntList();
/* 158 */     rec.field_5_dbcells.addAll(this.field_5_dbcells);
/* 159 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\IndexRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */