/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InterfaceEndRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 226;
/* 32 */   public static final InterfaceEndRecord instance = new InterfaceEndRecord();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Record create(RecordInputStream in)
/*    */   {
/* 39 */     switch (in.remaining()) {
/*    */     case 0: 
/* 41 */       return instance;
/*    */     case 2: 
/* 43 */       return new InterfaceHdrRecord(in);
/*    */     }
/* 45 */     throw new RecordFormatException("Invalid record data size: " + in.remaining());
/*    */   }
/*    */   
/*    */   public String toString() {
/* 49 */     return "[INTERFACEEND/]\n";
/*    */   }
/*    */   
/*    */ 
/*    */   public void serialize(LittleEndianOutput out) {}
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 57 */     return 0;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 61 */     return 226;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\InterfaceEndRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */