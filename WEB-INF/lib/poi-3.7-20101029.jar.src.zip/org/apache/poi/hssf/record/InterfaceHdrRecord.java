/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InterfaceHdrRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 225;
/*    */   private final int _codepage;
/*    */   public static final int CODEPAGE = 1200;
/*    */   
/*    */   public InterfaceHdrRecord(int codePage)
/*    */   {
/* 39 */     this._codepage = codePage;
/*    */   }
/*    */   
/*    */   public InterfaceHdrRecord(RecordInputStream in) {
/* 43 */     this._codepage = in.readShort();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 47 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 49 */     buffer.append("[INTERFACEHDR]\n");
/* 50 */     buffer.append("    .codepage = ").append(HexDump.shortToHex(this._codepage)).append("\n");
/* 51 */     buffer.append("[/INTERFACEHDR]\n");
/* 52 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 56 */     out.writeShort(this._codepage);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 60 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 64 */     return 225;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\InterfaceHdrRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */