/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LabelRecord
/*     */   extends Record
/*     */   implements CellValueRecordInterface
/*     */ {
/*     */   public static final short sid = 516;
/*     */   private int field_1_row;
/*     */   private short field_2_column;
/*     */   private short field_3_xf_index;
/*     */   private short field_4_string_len;
/*     */   private byte field_5_unicode_flag;
/*     */   private String field_6_value;
/*     */   
/*     */   public LabelRecord() {}
/*     */   
/*     */   public LabelRecord(RecordInputStream in)
/*     */   {
/*  51 */     this.field_1_row = in.readUShort();
/*  52 */     this.field_2_column = in.readShort();
/*  53 */     this.field_3_xf_index = in.readShort();
/*  54 */     this.field_4_string_len = in.readShort();
/*  55 */     this.field_5_unicode_flag = in.readByte();
/*  56 */     if (this.field_4_string_len > 0) {
/*  57 */       if (isUnCompressedUnicode()) {
/*  58 */         this.field_6_value = in.readUnicodeLEString(this.field_4_string_len);
/*     */       } else {
/*  60 */         this.field_6_value = in.readCompressedUnicode(this.field_4_string_len);
/*     */       }
/*     */     } else {
/*  63 */       this.field_6_value = "";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/*  72 */     return this.field_1_row;
/*     */   }
/*     */   
/*     */   public short getColumn()
/*     */   {
/*  77 */     return this.field_2_column;
/*     */   }
/*     */   
/*     */   public short getXFIndex()
/*     */   {
/*  82 */     return this.field_3_xf_index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getStringLength()
/*     */   {
/*  91 */     return this.field_4_string_len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnCompressedUnicode()
/*     */   {
/* 100 */     return this.field_5_unicode_flag == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 111 */     return this.field_6_value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int serialize(int offset, byte[] data)
/*     */   {
/* 118 */     throw new RecordFormatException("Label Records are supported READ ONLY...convert to LabelSST");
/*     */   }
/*     */   
/* 121 */   public int getRecordSize() { throw new RecordFormatException("Label Records are supported READ ONLY...convert to LabelSST"); }
/*     */   
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 126 */     return 516;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 131 */     StringBuffer sb = new StringBuffer();
/* 132 */     sb.append("[LABEL]\n");
/* 133 */     sb.append("    .row       = ").append(HexDump.shortToHex(getRow())).append("\n");
/* 134 */     sb.append("    .column    = ").append(HexDump.shortToHex(getColumn())).append("\n");
/* 135 */     sb.append("    .xfindex   = ").append(HexDump.shortToHex(getXFIndex())).append("\n");
/* 136 */     sb.append("    .string_len= ").append(HexDump.shortToHex(this.field_4_string_len)).append("\n");
/* 137 */     sb.append("    .unicode_flag= ").append(HexDump.byteToHex(this.field_5_unicode_flag)).append("\n");
/* 138 */     sb.append("    .value       = ").append(getValue()).append("\n");
/* 139 */     sb.append("[/LABEL]\n");
/* 140 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumn(short col) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRow(int row) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXFIndex(short xf) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 165 */     LabelRecord rec = new LabelRecord();
/* 166 */     rec.field_1_row = this.field_1_row;
/* 167 */     rec.field_2_column = this.field_2_column;
/* 168 */     rec.field_3_xf_index = this.field_3_xf_index;
/* 169 */     rec.field_4_string_len = this.field_4_string_len;
/* 170 */     rec.field_5_unicode_flag = this.field_5_unicode_flag;
/* 171 */     rec.field_6_value = this.field_6_value;
/* 172 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\LabelRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */