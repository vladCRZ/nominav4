/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LabelSSTRecord
/*    */   extends CellRecord
/*    */ {
/*    */   public static final short sid = 253;
/*    */   private int field_4_sst_index;
/*    */   
/*    */   public LabelSSTRecord() {}
/*    */   
/*    */   public LabelSSTRecord(RecordInputStream in)
/*    */   {
/* 40 */     super(in);
/* 41 */     this.field_4_sst_index = in.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSSTIndex(int index)
/*    */   {
/* 51 */     this.field_4_sst_index = index;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getSSTIndex()
/*    */   {
/* 62 */     return this.field_4_sst_index;
/*    */   }
/*    */   
/*    */   protected String getRecordName()
/*    */   {
/* 67 */     return "LABELSST";
/*    */   }
/*    */   
/*    */   protected void appendValueText(StringBuilder sb)
/*    */   {
/* 72 */     sb.append("  .sstIndex = ");
/* 73 */     sb.append(HexDump.shortToHex(getXFIndex()));
/*    */   }
/*    */   
/*    */   protected void serializeValue(LittleEndianOutput out) {
/* 77 */     out.writeInt(getSSTIndex());
/*    */   }
/*    */   
/*    */   protected int getValueDataSize()
/*    */   {
/* 82 */     return 4;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 86 */     return 253;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 90 */     LabelSSTRecord rec = new LabelSSTRecord();
/* 91 */     copyBaseFields(rec);
/* 92 */     rec.field_4_sst_index = this.field_4_sst_index;
/* 93 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\LabelSSTRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */