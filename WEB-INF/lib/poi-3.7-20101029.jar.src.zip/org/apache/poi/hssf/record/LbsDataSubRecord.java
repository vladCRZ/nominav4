/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LbsDataSubRecord
/*     */   extends SubRecord
/*     */ {
/*     */   public static final int sid = 19;
/*     */   private int _cbFContinued;
/*     */   private int _unknownPreFormulaInt;
/*     */   private Ptg _linkPtg;
/*     */   private Byte _unknownPostFormulaByte;
/*     */   private int _cLines;
/*     */   private int _iSel;
/*     */   private int _flags;
/*     */   private int _idEdit;
/*     */   private LbsDropData _dropData;
/*     */   private String[] _rgLines;
/*     */   private boolean[] _bsels;
/*     */   
/*     */   public LbsDataSubRecord(LittleEndianInput in, int cbFContinued, int cmoOt)
/*     */   {
/*  94 */     this._cbFContinued = cbFContinued;
/*     */     
/*  96 */     int encodedTokenLen = in.readUShort();
/*  97 */     if (encodedTokenLen > 0) {
/*  98 */       int formulaSize = in.readUShort();
/*  99 */       this._unknownPreFormulaInt = in.readInt();
/*     */       
/* 101 */       Ptg[] ptgs = Ptg.readTokens(formulaSize, in);
/* 102 */       if (ptgs.length != 1) {
/* 103 */         throw new RecordFormatException("Read " + ptgs.length + " tokens but expected exactly 1");
/*     */       }
/*     */       
/* 106 */       this._linkPtg = ptgs[0];
/* 107 */       switch (encodedTokenLen - formulaSize - 6) {
/*     */       case 1: 
/* 109 */         this._unknownPostFormulaByte = Byte.valueOf(in.readByte());
/* 110 */         break;
/*     */       case 0: 
/* 112 */         this._unknownPostFormulaByte = null;
/* 113 */         break;
/*     */       default: 
/* 115 */         throw new RecordFormatException("Unexpected leftover bytes");
/*     */       }
/*     */       
/*     */     }
/* 119 */     this._cLines = in.readUShort();
/* 120 */     this._iSel = in.readUShort();
/* 121 */     this._flags = in.readUShort();
/* 122 */     this._idEdit = in.readUShort();
/*     */     
/*     */ 
/*     */ 
/* 126 */     if (cmoOt == 20) {
/* 127 */       this._dropData = new LbsDropData(in);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 132 */     if ((this._flags & 0x2) != 0) {
/* 133 */       this._rgLines = new String[this._cLines];
/* 134 */       for (int i = 0; i < this._cLines; i++) {
/* 135 */         this._rgLines[i] = StringUtil.readUnicodeString(in);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */     if ((this._flags >> 4 & 0x2) != 0) {
/* 145 */       this._bsels = new boolean[this._cLines];
/* 146 */       for (int i = 0; i < this._cLines; i++) {
/* 147 */         this._bsels[i] = (in.readByte() == 1 ? 1 : false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   LbsDataSubRecord() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LbsDataSubRecord newAutoFilterInstance()
/*     */   {
/* 163 */     LbsDataSubRecord lbs = new LbsDataSubRecord();
/* 164 */     lbs._cbFContinued = 8174;
/* 165 */     lbs._iSel = 0;
/*     */     
/* 167 */     lbs._flags = 769;
/* 168 */     lbs._dropData = new LbsDropData();
/* 169 */     lbs._dropData._wStyle = LbsDropData.STYLE_COMBO_SIMPLE_DROPDOWN;
/*     */     
/*     */ 
/* 172 */     lbs._dropData._cLine = 8;
/* 173 */     return lbs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTerminating()
/*     */   {
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/* 186 */     int result = 2;
/*     */     
/*     */ 
/* 189 */     if (this._linkPtg != null) {
/* 190 */       result += 2;
/* 191 */       result += 4;
/* 192 */       result += this._linkPtg.getSize();
/* 193 */       if (this._unknownPostFormulaByte != null) {
/* 194 */         result++;
/*     */       }
/*     */     }
/*     */     
/* 198 */     result += 8;
/* 199 */     if (this._dropData != null) {
/* 200 */       result += this._dropData.getDataSize();
/*     */     }
/* 202 */     if (this._rgLines != null) {
/* 203 */       for (String str : this._rgLines) {
/* 204 */         result += StringUtil.getEncodedSize(str);
/*     */       }
/*     */     }
/* 207 */     if (this._bsels != null) {
/* 208 */       result += this._bsels.length;
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 215 */     out.writeShort(19);
/* 216 */     out.writeShort(this._cbFContinued);
/*     */     
/* 218 */     if (this._linkPtg == null) {
/* 219 */       out.writeShort(0);
/*     */     } else {
/* 221 */       int formulaSize = this._linkPtg.getSize();
/* 222 */       int linkSize = formulaSize + 6;
/* 223 */       if (this._unknownPostFormulaByte != null) {
/* 224 */         linkSize++;
/*     */       }
/* 226 */       out.writeShort(linkSize);
/* 227 */       out.writeShort(formulaSize);
/* 228 */       out.writeInt(this._unknownPreFormulaInt);
/* 229 */       this._linkPtg.write(out);
/* 230 */       if (this._unknownPostFormulaByte != null) {
/* 231 */         out.writeByte(this._unknownPostFormulaByte.intValue());
/*     */       }
/*     */     }
/*     */     
/* 235 */     out.writeShort(this._cLines);
/* 236 */     out.writeShort(this._iSel);
/* 237 */     out.writeShort(this._flags);
/* 238 */     out.writeShort(this._idEdit);
/*     */     
/* 240 */     if (this._dropData != null) {
/* 241 */       this._dropData.serialize(out);
/*     */     }
/*     */     
/* 244 */     if (this._rgLines != null) {
/* 245 */       for (String str : this._rgLines) {
/* 246 */         StringUtil.writeUnicodeString(out, str);
/*     */       }
/*     */     }
/*     */     
/* 250 */     if (this._bsels != null) {
/* 251 */       for (boolean val : this._bsels) {
/* 252 */         out.writeByte(val ? 1 : 0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 259 */     return this;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 264 */     StringBuffer sb = new StringBuffer(256);
/*     */     
/* 266 */     sb.append("[ftLbsData]\n");
/* 267 */     sb.append("    .unknownShort1 =").append(HexDump.shortToHex(this._cbFContinued)).append("\n");
/* 268 */     sb.append("    .formula        = ").append('\n');
/* 269 */     if (this._linkPtg != null) sb.append(this._linkPtg.toString()).append(this._linkPtg.getRVAType()).append('\n');
/* 270 */     sb.append("    .nEntryCount   =").append(HexDump.shortToHex(this._cLines)).append("\n");
/* 271 */     sb.append("    .selEntryIx    =").append(HexDump.shortToHex(this._iSel)).append("\n");
/* 272 */     sb.append("    .style         =").append(HexDump.shortToHex(this._flags)).append("\n");
/* 273 */     sb.append("    .unknownShort10=").append(HexDump.shortToHex(this._idEdit)).append("\n");
/* 274 */     if (this._dropData != null) sb.append('\n').append(this._dropData.toString());
/* 275 */     sb.append("[/ftLbsData]\n");
/* 276 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ptg getFormula()
/*     */   {
/* 284 */     return this._linkPtg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNumberOfItems()
/*     */   {
/* 291 */     return this._cLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LbsDropData
/*     */   {
/* 301 */     public static int STYLE_COMBO_DROPDOWN = 0;
/*     */     
/*     */ 
/*     */ 
/* 305 */     public static int STYLE_COMBO_EDIT_DROPDOWN = 1;
/*     */     
/*     */ 
/*     */ 
/* 309 */     public static int STYLE_COMBO_SIMPLE_DROPDOWN = 2;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private int _wStyle;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private int _cLine;
/*     */     
/*     */ 
/*     */ 
/*     */     private int _dxMin;
/*     */     
/*     */ 
/*     */ 
/*     */     private String _str;
/*     */     
/*     */ 
/*     */ 
/*     */     private Byte _unused;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public LbsDropData()
/*     */     {
/* 338 */       this._str = "";
/* 339 */       this._unused = Byte.valueOf((byte)0);
/*     */     }
/*     */     
/*     */     public LbsDropData(LittleEndianInput in) {
/* 343 */       this._wStyle = in.readUShort();
/* 344 */       this._cLine = in.readUShort();
/* 345 */       this._dxMin = in.readUShort();
/* 346 */       this._str = StringUtil.readUnicodeString(in);
/* 347 */       if (StringUtil.getEncodedSize(this._str) % 2 != 0) {
/* 348 */         this._unused = Byte.valueOf(in.readByte());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setStyle(int style)
/*     */     {
/* 363 */       this._wStyle = style;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setNumLines(int num)
/*     */     {
/* 370 */       this._cLine = num;
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/* 374 */       out.writeShort(this._wStyle);
/* 375 */       out.writeShort(this._cLine);
/* 376 */       out.writeShort(this._dxMin);
/* 377 */       StringUtil.writeUnicodeString(out, this._str);
/* 378 */       if (this._unused != null) out.writeByte(this._unused.byteValue());
/*     */     }
/*     */     
/*     */     public int getDataSize() {
/* 382 */       int size = 6;
/* 383 */       size += StringUtil.getEncodedSize(this._str);
/* 384 */       size += this._unused.byteValue();
/* 385 */       return size;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 390 */       StringBuffer sb = new StringBuffer();
/* 391 */       sb.append("[LbsDropData]\n");
/* 392 */       sb.append("  ._wStyle:  ").append(this._wStyle).append('\n');
/* 393 */       sb.append("  ._cLine:  ").append(this._cLine).append('\n');
/* 394 */       sb.append("  ._dxMin:  ").append(this._dxMin).append('\n');
/* 395 */       sb.append("  ._str:  ").append(this._str).append('\n');
/* 396 */       if (this._unused != null) sb.append("  ._unused:  ").append(this._unused).append('\n');
/* 397 */       sb.append("[/LbsDropData]\n");
/*     */       
/* 399 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\LbsDataSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */