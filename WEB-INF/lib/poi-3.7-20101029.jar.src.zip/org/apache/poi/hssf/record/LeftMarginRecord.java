/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LeftMarginRecord
/*    */   extends StandardRecord
/*    */   implements Margin
/*    */ {
/*    */   public static final short sid = 38;
/*    */   private double field_1_margin;
/*    */   
/*    */   public LeftMarginRecord() {}
/*    */   
/*    */   public LeftMarginRecord(RecordInputStream in)
/*    */   {
/* 36 */     this.field_1_margin = in.readDouble();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 41 */     StringBuffer buffer = new StringBuffer();
/* 42 */     buffer.append("[LeftMargin]\n");
/* 43 */     buffer.append("    .margin               = ").append(" (").append(getMargin()).append(" )\n");
/* 44 */     buffer.append("[/LeftMargin]\n");
/* 45 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 49 */     out.writeDouble(this.field_1_margin);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 53 */     return 8;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 57 */     return 38;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public double getMargin()
/*    */   {
/* 64 */     return this.field_1_margin;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMargin(double field_1_margin)
/*    */   {
/* 72 */     this.field_1_margin = field_1_margin;
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/* 77 */     LeftMarginRecord rec = new LeftMarginRecord();
/* 78 */     rec.field_1_margin = this.field_1_margin;
/* 79 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\LeftMarginRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */