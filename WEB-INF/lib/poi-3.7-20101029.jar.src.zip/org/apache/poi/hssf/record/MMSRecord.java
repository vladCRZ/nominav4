/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MMSRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 193;
/*     */   private byte field_1_addMenuCount;
/*     */   private byte field_2_delMenuCount;
/*     */   
/*     */   public MMSRecord() {}
/*     */   
/*     */   public MMSRecord(RecordInputStream in)
/*     */   {
/*  46 */     if (in.remaining() == 0) {
/*  47 */       return;
/*     */     }
/*     */     
/*  50 */     this.field_1_addMenuCount = in.readByte();
/*  51 */     this.field_2_delMenuCount = in.readByte();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddMenuCount(byte am)
/*     */   {
/*  61 */     this.field_1_addMenuCount = am;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDelMenuCount(byte dm)
/*     */   {
/*  71 */     this.field_2_delMenuCount = dm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getAddMenuCount()
/*     */   {
/*  81 */     return this.field_1_addMenuCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getDelMenuCount()
/*     */   {
/*  91 */     return this.field_2_delMenuCount;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  96 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  98 */     buffer.append("[MMS]\n");
/*  99 */     buffer.append("    .addMenu        = ").append(Integer.toHexString(getAddMenuCount())).append("\n");
/*     */     
/* 101 */     buffer.append("    .delMenu        = ").append(Integer.toHexString(getDelMenuCount())).append("\n");
/*     */     
/* 103 */     buffer.append("[/MMS]\n");
/* 104 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 108 */     out.writeByte(getAddMenuCount());
/* 109 */     out.writeByte(getDelMenuCount());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 113 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 118 */     return 193;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\MMSRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */