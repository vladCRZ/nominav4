/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.ss.util.CellRangeAddressList;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MergeCellsRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 229;
/*     */   private CellRangeAddress[] _regions;
/*     */   private final int _startIndex;
/*     */   private final int _numberOfRegions;
/*     */   
/*     */   public MergeCellsRecord(CellRangeAddress[] regions, int startIndex, int numberOfRegions)
/*     */   {
/*  38 */     this._regions = regions;
/*  39 */     this._startIndex = startIndex;
/*  40 */     this._numberOfRegions = numberOfRegions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MergeCellsRecord(RecordInputStream in)
/*     */   {
/*  47 */     int nRegions = in.readUShort();
/*  48 */     CellRangeAddress[] cras = new CellRangeAddress[nRegions];
/*  49 */     for (int i = 0; i < nRegions; i++) {
/*  50 */       cras[i] = new CellRangeAddress(in);
/*     */     }
/*  52 */     this._numberOfRegions = nRegions;
/*  53 */     this._startIndex = 0;
/*  54 */     this._regions = cras;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getNumAreas()
/*     */   {
/*  62 */     return (short)this._numberOfRegions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CellRangeAddress getAreaAt(int index)
/*     */   {
/*  69 */     return this._regions[(this._startIndex + index)];
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  73 */     return CellRangeAddressList.getEncodedSize(this._numberOfRegions);
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  77 */     return 229;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  81 */     int nItems = this._numberOfRegions;
/*  82 */     out.writeShort(nItems);
/*  83 */     for (int i = 0; i < this._numberOfRegions; i++) {
/*  84 */       this._regions[(this._startIndex + i)].serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/*  89 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  91 */     retval.append("[MERGEDCELLS]").append("\n");
/*  92 */     retval.append("     .numregions =").append(getNumAreas()).append("\n");
/*  93 */     for (int k = 0; k < this._numberOfRegions; k++) {
/*  94 */       CellRangeAddress r = this._regions[(this._startIndex + k)];
/*     */       
/*  96 */       retval.append("     .rowfrom =").append(r.getFirstRow()).append("\n");
/*  97 */       retval.append("     .rowto   =").append(r.getLastRow()).append("\n");
/*  98 */       retval.append("     .colfrom =").append(r.getFirstColumn()).append("\n");
/*  99 */       retval.append("     .colto   =").append(r.getLastColumn()).append("\n");
/*     */     }
/* 101 */     retval.append("[MERGEDCELLS]").append("\n");
/* 102 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 106 */     int nRegions = this._numberOfRegions;
/* 107 */     CellRangeAddress[] clonedRegions = new CellRangeAddress[nRegions];
/* 108 */     for (int i = 0; i < clonedRegions.length; i++) {
/* 109 */       clonedRegions[i] = this._regions[(this._startIndex + i)].copy();
/*     */     }
/* 111 */     return new MergeCellsRecord(clonedRegions, 0, nRegions);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\MergeCellsRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */