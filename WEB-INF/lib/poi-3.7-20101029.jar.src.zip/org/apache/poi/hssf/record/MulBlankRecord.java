/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MulBlankRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 190;
/*     */   private final int _row;
/*     */   private final int _firstCol;
/*     */   private final short[] _xfs;
/*     */   private final int _lastCol;
/*     */   
/*     */   public MulBlankRecord(int row, int firstCol, short[] xfs)
/*     */   {
/*  40 */     this._row = row;
/*  41 */     this._firstCol = firstCol;
/*  42 */     this._xfs = xfs;
/*  43 */     this._lastCol = (firstCol + xfs.length - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/*  50 */     return this._row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFirstColumn()
/*     */   {
/*  57 */     return this._firstCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLastColumn()
/*     */   {
/*  64 */     return this._lastCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumColumns()
/*     */   {
/*  72 */     return this._lastCol - this._firstCol + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getXFAt(int coffset)
/*     */   {
/*  81 */     return this._xfs[coffset];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MulBlankRecord(RecordInputStream in)
/*     */   {
/*  88 */     this._row = in.readUShort();
/*  89 */     this._firstCol = in.readShort();
/*  90 */     this._xfs = parseXFs(in);
/*  91 */     this._lastCol = in.readShort();
/*     */   }
/*     */   
/*     */   private static short[] parseXFs(RecordInputStream in) {
/*  95 */     short[] retval = new short[(in.remaining() - 2) / 2];
/*     */     
/*  97 */     for (int idx = 0; idx < retval.length; idx++) {
/*  98 */       retval[idx] = in.readShort();
/*     */     }
/* 100 */     return retval;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 104 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 106 */     buffer.append("[MULBLANK]\n");
/* 107 */     buffer.append("row  = ").append(Integer.toHexString(getRow())).append("\n");
/* 108 */     buffer.append("firstcol  = ").append(Integer.toHexString(getFirstColumn())).append("\n");
/* 109 */     buffer.append(" lastcol  = ").append(Integer.toHexString(this._lastCol)).append("\n");
/* 110 */     for (int k = 0; k < getNumColumns(); k++) {
/* 111 */       buffer.append("xf").append(k).append("\t\t= ").append(Integer.toHexString(getXFAt(k))).append("\n");
/*     */     }
/*     */     
/* 114 */     buffer.append("[/MULBLANK]\n");
/* 115 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 119 */     return 190;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 123 */     out.writeShort(this._row);
/* 124 */     out.writeShort(this._firstCol);
/* 125 */     int nItems = this._xfs.length;
/* 126 */     for (int i = 0; i < nItems; i++) {
/* 127 */       out.writeShort(this._xfs[i]);
/*     */     }
/* 129 */     out.writeShort(this._lastCol);
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/* 134 */     return 6 + this._xfs.length * 2;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 140 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\MulBlankRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */