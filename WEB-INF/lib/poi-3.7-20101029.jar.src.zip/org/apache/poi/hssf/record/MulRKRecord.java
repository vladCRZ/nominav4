/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.util.RKUtil;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MulRKRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 189;
/*     */   private int field_1_row;
/*     */   private short field_2_first_col;
/*     */   private RkRec[] field_3_rks;
/*     */   private short field_4_last_col;
/*     */   
/*     */   public int getRow()
/*     */   {
/*  42 */     return this.field_1_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFirstColumn()
/*     */   {
/*  50 */     return this.field_2_first_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLastColumn()
/*     */   {
/*  58 */     return this.field_4_last_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumColumns()
/*     */   {
/*  66 */     return this.field_4_last_col - this.field_2_first_col + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getXFAt(int coffset)
/*     */   {
/*  74 */     return this.field_3_rks[coffset].xf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getRKNumberAt(int coffset)
/*     */   {
/*  82 */     return RKUtil.decodeNumber(this.field_3_rks[coffset].rk);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MulRKRecord(RecordInputStream in)
/*     */   {
/*  89 */     this.field_1_row = in.readUShort();
/*  90 */     this.field_2_first_col = in.readShort();
/*  91 */     this.field_3_rks = RkRec.parseRKs(in);
/*  92 */     this.field_4_last_col = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  97 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  99 */     buffer.append("[MULRK]\n");
/* 100 */     buffer.append("\t.row\t = ").append(HexDump.shortToHex(getRow())).append("\n");
/* 101 */     buffer.append("\t.firstcol= ").append(HexDump.shortToHex(getFirstColumn())).append("\n");
/* 102 */     buffer.append("\t.lastcol = ").append(HexDump.shortToHex(getLastColumn())).append("\n");
/*     */     
/* 104 */     for (int k = 0; k < getNumColumns(); k++) {
/* 105 */       buffer.append("\txf[").append(k).append("] = ").append(HexDump.shortToHex(getXFAt(k))).append("\n");
/* 106 */       buffer.append("\trk[").append(k).append("] = ").append(getRKNumberAt(k)).append("\n");
/*     */     }
/* 108 */     buffer.append("[/MULRK]\n");
/* 109 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 114 */     return 189;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 118 */     throw new RecordFormatException("Sorry, you can't serialize MulRK in this release");
/*     */   }
/*     */   
/* 121 */   protected int getDataSize() { throw new RecordFormatException("Sorry, you can't serialize MulRK in this release"); }
/*     */   
/*     */   private static final class RkRec
/*     */   {
/*     */     public static final int ENCODED_SIZE = 6;
/*     */     public final short xf;
/*     */     public final int rk;
/*     */     
/*     */     private RkRec(RecordInputStream in) {
/* 130 */       this.xf = in.readShort();
/* 131 */       this.rk = in.readInt();
/*     */     }
/*     */     
/*     */     public static RkRec[] parseRKs(RecordInputStream in) {
/* 135 */       int nItems = (in.remaining() - 2) / 6;
/* 136 */       RkRec[] retval = new RkRec[nItems];
/* 137 */       for (int i = 0; i < nItems; i++) {
/* 138 */         retval[i] = new RkRec(in);
/*     */       }
/* 140 */       return retval;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\MulRKRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */