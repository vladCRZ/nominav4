/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NameCommentRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 2196;
/*     */   private final short field_1_record_type;
/*     */   private final short field_2_frt_cell_ref_flag;
/*     */   private final long field_3_reserved;
/*     */   private String field_6_name_text;
/*     */   private String field_7_comment_text;
/*     */   
/*     */   public NameCommentRecord(String name, String comment)
/*     */   {
/*  47 */     this.field_1_record_type = 0;
/*  48 */     this.field_2_frt_cell_ref_flag = 0;
/*  49 */     this.field_3_reserved = 0L;
/*  50 */     this.field_6_name_text = name;
/*  51 */     this.field_7_comment_text = comment;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/*  56 */     int field_4_name_length = this.field_6_name_text.length();
/*  57 */     int field_5_comment_length = this.field_7_comment_text.length();
/*     */     
/*  59 */     out.writeShort(this.field_1_record_type);
/*  60 */     out.writeShort(this.field_2_frt_cell_ref_flag);
/*  61 */     out.writeLong(this.field_3_reserved);
/*  62 */     out.writeShort(field_4_name_length);
/*  63 */     out.writeShort(field_5_comment_length);
/*     */     
/*  65 */     out.writeByte(0);
/*  66 */     out.write(this.field_6_name_text.getBytes());
/*  67 */     out.writeByte(0);
/*  68 */     out.write(this.field_7_comment_text.getBytes());
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/*  73 */     return 18 + this.field_6_name_text.length() + this.field_7_comment_text.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameCommentRecord(RecordInputStream ris)
/*     */   {
/*  82 */     LittleEndianInput in = ris;
/*  83 */     this.field_1_record_type = in.readShort();
/*  84 */     this.field_2_frt_cell_ref_flag = in.readShort();
/*  85 */     this.field_3_reserved = in.readLong();
/*  86 */     int field_4_name_length = in.readShort();
/*  87 */     int field_5_comment_length = in.readShort();
/*     */     
/*  89 */     in.readByte();
/*  90 */     this.field_6_name_text = StringUtil.readCompressedUnicode(in, field_4_name_length);
/*  91 */     in.readByte();
/*  92 */     this.field_7_comment_text = StringUtil.readCompressedUnicode(in, field_5_comment_length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 100 */     return 2196;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 105 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 107 */     sb.append("[NAMECMT]\n");
/* 108 */     sb.append("    .record type            = ").append(HexDump.shortToHex(this.field_1_record_type)).append("\n");
/* 109 */     sb.append("    .frt cell ref flag      = ").append(HexDump.byteToHex(this.field_2_frt_cell_ref_flag)).append("\n");
/* 110 */     sb.append("    .reserved               = ").append(this.field_3_reserved).append("\n");
/* 111 */     sb.append("    .name length            = ").append(this.field_6_name_text.length()).append("\n");
/* 112 */     sb.append("    .comment length         = ").append(this.field_7_comment_text.length()).append("\n");
/* 113 */     sb.append("    .name                   = ").append(this.field_6_name_text).append("\n");
/* 114 */     sb.append("    .comment                = ").append(this.field_7_comment_text).append("\n");
/* 115 */     sb.append("[/NAMECMT]\n");
/*     */     
/* 117 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNameText()
/*     */   {
/* 124 */     return this.field_6_name_text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNameText(String newName)
/*     */   {
/* 132 */     this.field_6_name_text = newName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCommentText()
/*     */   {
/* 139 */     return this.field_7_comment_text;
/*     */   }
/*     */   
/*     */   public void setCommentText(String comment) {
/* 143 */     this.field_7_comment_text = comment;
/*     */   }
/*     */   
/*     */   public short getRecordType() {
/* 147 */     return this.field_1_record_type;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\NameCommentRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */