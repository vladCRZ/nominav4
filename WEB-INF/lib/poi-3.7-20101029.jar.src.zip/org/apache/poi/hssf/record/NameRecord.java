/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.Area3DPtg;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.record.formula.Ref3DPtg;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NameRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 24;
/*     */   public static final byte BUILTIN_CONSOLIDATE_AREA = 1;
/*     */   public static final byte BUILTIN_AUTO_OPEN = 2;
/*     */   public static final byte BUILTIN_AUTO_CLOSE = 3;
/*     */   public static final byte BUILTIN_DATABASE = 4;
/*     */   public static final byte BUILTIN_CRITERIA = 5;
/*     */   public static final byte BUILTIN_PRINT_AREA = 6;
/*     */   public static final byte BUILTIN_PRINT_TITLE = 7;
/*     */   public static final byte BUILTIN_RECORDER = 8;
/*     */   public static final byte BUILTIN_DATA_FORM = 9;
/*     */   public static final byte BUILTIN_AUTO_ACTIVATE = 10;
/*     */   public static final byte BUILTIN_AUTO_DEACTIVATE = 11;
/*     */   public static final byte BUILTIN_SHEET_TITLE = 12;
/*     */   public static final byte BUILTIN_FILTER_DB = 13;
/*     */   private short field_1_option_flag;
/*     */   private byte field_2_keyboard_shortcut;
/*     */   private short field_5_externSheetIndex_plus1;
/*     */   private int field_6_sheetNumber;
/*     */   private boolean field_11_nameIsMultibyte;
/*     */   private byte field_12_built_in_code;
/*     */   private String field_12_name_text;
/*     */   private Formula field_13_name_definition;
/*     */   private String field_14_custom_menu_text;
/*     */   private String field_15_description_text;
/*     */   private String field_16_help_topic_text;
/*     */   private String field_17_status_bar_text;
/*     */   
/*     */   private static final class Option
/*     */   {
/*     */     public static final int OPT_HIDDEN_NAME = 1;
/*     */     public static final int OPT_FUNCTION_NAME = 2;
/*     */     public static final int OPT_COMMAND_NAME = 4;
/*     */     public static final int OPT_MACRO = 8;
/*     */     public static final int OPT_COMPLEX = 16;
/*     */     public static final int OPT_BUILTIN = 32;
/*     */     public static final int OPT_BINDATA = 4096;
/*     */     
/*     */     public static final boolean isFormula(int optValue)
/*     */     {
/*  76 */       return (optValue & 0xF) == 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRecord()
/*     */   {
/*  98 */     this.field_13_name_definition = Formula.create(Ptg.EMPTY_PTG_ARRAY);
/*     */     
/* 100 */     this.field_12_name_text = "";
/* 101 */     this.field_14_custom_menu_text = "";
/* 102 */     this.field_15_description_text = "";
/* 103 */     this.field_16_help_topic_text = "";
/* 104 */     this.field_17_status_bar_text = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRecord(byte builtin, int sheetNumber)
/*     */   {
/* 113 */     this();
/* 114 */     this.field_12_built_in_code = builtin;
/* 115 */     setOptionFlag((short)(this.field_1_option_flag | 0x20));
/* 116 */     this.field_6_sheetNumber = sheetNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOptionFlag(short flag)
/*     */   {
/* 123 */     this.field_1_option_flag = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeyboardShortcut(byte shortcut)
/*     */   {
/* 131 */     this.field_2_keyboard_shortcut = shortcut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSheetNumber()
/*     */   {
/* 140 */     return this.field_6_sheetNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getFnGroup()
/*     */   {
/* 148 */     int masked = this.field_1_option_flag & 0xFC0;
/* 149 */     return (byte)(masked >> 4);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSheetNumber(int value)
/*     */   {
/* 155 */     this.field_6_sheetNumber = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNameText(String name)
/*     */   {
/* 163 */     this.field_12_name_text = name;
/* 164 */     this.field_11_nameIsMultibyte = StringUtil.hasMultibyte(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCustomMenuText(String text)
/*     */   {
/* 171 */     this.field_14_custom_menu_text = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDescriptionText(String text)
/*     */   {
/* 178 */     this.field_15_description_text = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHelpTopicText(String text)
/*     */   {
/* 185 */     this.field_16_help_topic_text = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setStatusBarText(String text)
/*     */   {
/* 192 */     this.field_17_status_bar_text = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getOptionFlag()
/*     */   {
/* 199 */     return this.field_1_option_flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte getKeyboardShortcut()
/*     */   {
/* 206 */     return this.field_2_keyboard_shortcut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getNameTextLength()
/*     */   {
/* 214 */     if (isBuiltInName()) {
/* 215 */       return 1;
/*     */     }
/* 217 */     return this.field_12_name_text.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */   public boolean isHiddenName() { return (this.field_1_option_flag & 0x1) != 0; }
/*     */   
/*     */   public void setHidden(boolean b) {
/* 228 */     if (b) {
/* 229 */       this.field_1_option_flag = ((short)(this.field_1_option_flag | 0x1));
/*     */     } else {
/* 231 */       this.field_1_option_flag = ((short)(this.field_1_option_flag & 0xFFFFFFFE));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isFunctionName()
/*     */   {
/* 238 */     return (this.field_1_option_flag & 0x2) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFunction(boolean function)
/*     */   {
/* 248 */     if (function) {
/* 249 */       this.field_1_option_flag = ((short)(this.field_1_option_flag | 0x2));
/*     */     } else {
/* 251 */       this.field_1_option_flag = ((short)(this.field_1_option_flag & 0xFFFFFFFD));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasFormula()
/*     */   {
/* 259 */     return (Option.isFormula(this.field_1_option_flag)) && (this.field_13_name_definition.getEncodedTokenSize() > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCommandName()
/*     */   {
/* 266 */     return (this.field_1_option_flag & 0x4) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isMacro()
/*     */   {
/* 272 */     return (this.field_1_option_flag & 0x8) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isComplexFunction()
/*     */   {
/* 278 */     return (this.field_1_option_flag & 0x10) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isBuiltInName()
/*     */   {
/* 285 */     return (this.field_1_option_flag & 0x20) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNameText()
/*     */   {
/* 294 */     return isBuiltInName() ? translateBuiltInName(getBuiltInName()) : this.field_12_name_text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getBuiltInName()
/*     */   {
/* 302 */     return this.field_12_built_in_code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ptg[] getNameDefinition()
/*     */   {
/* 310 */     return this.field_13_name_definition.getTokens();
/*     */   }
/*     */   
/*     */   public void setNameDefinition(Ptg[] ptgs) {
/* 314 */     this.field_13_name_definition = Formula.create(ptgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCustomMenuText()
/*     */   {
/* 321 */     return this.field_14_custom_menu_text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDescriptionText()
/*     */   {
/* 328 */     return this.field_15_description_text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getHelpTopicText()
/*     */   {
/* 335 */     return this.field_16_help_topic_text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStatusBarText()
/*     */   {
/* 342 */     return this.field_17_status_bar_text;
/*     */   }
/*     */   
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 348 */     int field_7_length_custom_menu = this.field_14_custom_menu_text.length();
/* 349 */     int field_8_length_description_text = this.field_15_description_text.length();
/* 350 */     int field_9_length_help_topic_text = this.field_16_help_topic_text.length();
/* 351 */     int field_10_length_status_bar_text = this.field_17_status_bar_text.length();
/*     */     
/*     */ 
/* 354 */     out.writeShort(getOptionFlag());
/* 355 */     out.writeByte(getKeyboardShortcut());
/* 356 */     out.writeByte(getNameTextLength());
/*     */     
/* 358 */     out.writeShort(this.field_13_name_definition.getEncodedTokenSize());
/* 359 */     out.writeShort(this.field_5_externSheetIndex_plus1);
/* 360 */     out.writeShort(this.field_6_sheetNumber);
/* 361 */     out.writeByte(field_7_length_custom_menu);
/* 362 */     out.writeByte(field_8_length_description_text);
/* 363 */     out.writeByte(field_9_length_help_topic_text);
/* 364 */     out.writeByte(field_10_length_status_bar_text);
/* 365 */     out.writeByte(this.field_11_nameIsMultibyte ? 1 : 0);
/*     */     
/* 367 */     if (isBuiltInName())
/*     */     {
/* 369 */       out.writeByte(this.field_12_built_in_code);
/*     */     } else {
/* 371 */       String nameText = this.field_12_name_text;
/* 372 */       if (this.field_11_nameIsMultibyte) {
/* 373 */         StringUtil.putUnicodeLE(nameText, out);
/*     */       } else {
/* 375 */         StringUtil.putCompressedUnicode(nameText, out);
/*     */       }
/*     */     }
/* 378 */     this.field_13_name_definition.serializeTokens(out);
/* 379 */     this.field_13_name_definition.serializeArrayConstantData(out);
/*     */     
/* 381 */     StringUtil.putCompressedUnicode(getCustomMenuText(), out);
/* 382 */     StringUtil.putCompressedUnicode(getDescriptionText(), out);
/* 383 */     StringUtil.putCompressedUnicode(getHelpTopicText(), out);
/* 384 */     StringUtil.putCompressedUnicode(getStatusBarText(), out);
/*     */   }
/*     */   
/* 387 */   private int getNameRawSize() { if (isBuiltInName()) {
/* 388 */       return 1;
/*     */     }
/* 390 */     int nChars = this.field_12_name_text.length();
/* 391 */     if (this.field_11_nameIsMultibyte) {
/* 392 */       return 2 * nChars;
/*     */     }
/* 394 */     return nChars;
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 398 */     return 13 + getNameRawSize() + this.field_14_custom_menu_text.length() + this.field_15_description_text.length() + this.field_16_help_topic_text.length() + this.field_17_status_bar_text.length() + this.field_13_name_definition.getEncodedSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getExternSheetNumber()
/*     */   {
/* 411 */     if (this.field_13_name_definition.getEncodedSize() < 1) {
/* 412 */       return 0;
/*     */     }
/* 414 */     Ptg ptg = this.field_13_name_definition.getTokens()[0];
/*     */     
/* 416 */     if (ptg.getClass() == Area3DPtg.class) {
/* 417 */       return ((Area3DPtg)ptg).getExternSheetIndex();
/*     */     }
/*     */     
/* 420 */     if (ptg.getClass() == Ref3DPtg.class) {
/* 421 */       return ((Ref3DPtg)ptg).getExternSheetIndex();
/*     */     }
/* 423 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NameRecord(RecordInputStream ris)
/*     */   {
/* 433 */     LittleEndianInput in = ris;
/* 434 */     this.field_1_option_flag = in.readShort();
/* 435 */     this.field_2_keyboard_shortcut = in.readByte();
/* 436 */     int field_3_length_name_text = in.readUByte();
/* 437 */     int field_4_length_name_definition = in.readShort();
/* 438 */     this.field_5_externSheetIndex_plus1 = in.readShort();
/* 439 */     this.field_6_sheetNumber = in.readUShort();
/* 440 */     int f7_customMenuLen = in.readUByte();
/* 441 */     int f8_descriptionTextLen = in.readUByte();
/* 442 */     int f9_helpTopicTextLen = in.readUByte();
/* 443 */     int f10_statusBarTextLen = in.readUByte();
/*     */     
/*     */ 
/* 446 */     this.field_11_nameIsMultibyte = (in.readByte() != 0);
/* 447 */     if (isBuiltInName()) {
/* 448 */       this.field_12_built_in_code = in.readByte();
/*     */     }
/* 450 */     else if (this.field_11_nameIsMultibyte) {
/* 451 */       this.field_12_name_text = StringUtil.readUnicodeLE(in, field_3_length_name_text);
/*     */     } else {
/* 453 */       this.field_12_name_text = StringUtil.readCompressedUnicode(in, field_3_length_name_text);
/*     */     }
/*     */     
/*     */ 
/* 457 */     int nBytesAvailable = in.available() - (f7_customMenuLen + f8_descriptionTextLen + f9_helpTopicTextLen + f10_statusBarTextLen);
/*     */     
/* 459 */     this.field_13_name_definition = Formula.read(field_4_length_name_definition, in, nBytesAvailable);
/*     */     
/*     */ 
/* 462 */     this.field_14_custom_menu_text = StringUtil.readCompressedUnicode(in, f7_customMenuLen);
/* 463 */     this.field_15_description_text = StringUtil.readCompressedUnicode(in, f8_descriptionTextLen);
/* 464 */     this.field_16_help_topic_text = StringUtil.readCompressedUnicode(in, f9_helpTopicTextLen);
/* 465 */     this.field_17_status_bar_text = StringUtil.readCompressedUnicode(in, f10_statusBarTextLen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 472 */     return 24;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 526 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 528 */     sb.append("[NAME]\n");
/* 529 */     sb.append("    .option flags           = ").append(HexDump.shortToHex(this.field_1_option_flag)).append("\n");
/* 530 */     sb.append("    .keyboard shortcut      = ").append(HexDump.byteToHex(this.field_2_keyboard_shortcut)).append("\n");
/* 531 */     sb.append("    .length of the name     = ").append(getNameTextLength()).append("\n");
/* 532 */     sb.append("    .extSheetIx(1-based, 0=Global)= ").append(this.field_5_externSheetIndex_plus1).append("\n");
/* 533 */     sb.append("    .sheetTabIx             = ").append(this.field_6_sheetNumber).append("\n");
/* 534 */     sb.append("    .Menu text length       = ").append(this.field_14_custom_menu_text.length()).append("\n");
/* 535 */     sb.append("    .Description text length= ").append(this.field_15_description_text.length()).append("\n");
/* 536 */     sb.append("    .Help topic text length = ").append(this.field_16_help_topic_text.length()).append("\n");
/* 537 */     sb.append("    .Status bar text length = ").append(this.field_17_status_bar_text.length()).append("\n");
/* 538 */     sb.append("    .NameIsMultibyte        = ").append(this.field_11_nameIsMultibyte).append("\n");
/* 539 */     sb.append("    .Name (Unicode text)    = ").append(getNameText()).append("\n");
/* 540 */     Ptg[] ptgs = this.field_13_name_definition.getTokens();
/* 541 */     sb.append("    .Formula (nTokens=").append(ptgs.length).append("):").append("\n");
/* 542 */     for (int i = 0; i < ptgs.length; i++) {
/* 543 */       Ptg ptg = ptgs[i];
/* 544 */       sb.append("       " + ptg.toString()).append(ptg.getRVAType()).append("\n");
/*     */     }
/*     */     
/* 547 */     sb.append("    .Menu text       = ").append(this.field_14_custom_menu_text).append("\n");
/* 548 */     sb.append("    .Description text= ").append(this.field_15_description_text).append("\n");
/* 549 */     sb.append("    .Help topic text = ").append(this.field_16_help_topic_text).append("\n");
/* 550 */     sb.append("    .Status bar text = ").append(this.field_17_status_bar_text).append("\n");
/* 551 */     sb.append("[/NAME]\n");
/*     */     
/* 553 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String translateBuiltInName(byte name)
/*     */   {
/* 561 */     switch (name) {
/*     */     case 10: 
/* 563 */       return "Auto_Activate";
/* 564 */     case 3:  return "Auto_Close";
/* 565 */     case 11:  return "Auto_Deactivate";
/* 566 */     case 2:  return "Auto_Open";
/* 567 */     case 1:  return "Consolidate_Area";
/* 568 */     case 5:  return "Criteria";
/* 569 */     case 4:  return "Database";
/* 570 */     case 9:  return "Data_Form";
/* 571 */     case 6:  return "Print_Area";
/* 572 */     case 7:  return "Print_Titles";
/* 573 */     case 8:  return "Recorder";
/* 574 */     case 12:  return "Sheet_Title";
/* 575 */     case 13:  return "_FilterDatabase";
/*     */     }
/*     */     
/*     */     
/* 579 */     return "Unknown";
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\NameRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */