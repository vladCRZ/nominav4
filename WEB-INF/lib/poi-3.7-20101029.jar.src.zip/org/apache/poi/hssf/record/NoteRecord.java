/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NoteRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 28;
/*  31 */   public static final NoteRecord[] EMPTY_ARRAY = new NoteRecord[0];
/*     */   
/*     */ 
/*     */ 
/*     */   public static final short NOTE_HIDDEN = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final short NOTE_VISIBLE = 2;
/*     */   
/*     */ 
/*     */ 
/*  43 */   private static final Byte DEFAULT_PADDING = Byte.valueOf((byte)0);
/*     */   
/*     */ 
/*     */   private int field_1_row;
/*     */   
/*     */ 
/*     */   private int field_2_col;
/*     */   
/*     */   private short field_3_flags;
/*     */   
/*     */   private int field_4_shapeid;
/*     */   
/*     */   private boolean field_5_hasMultibyte;
/*     */   
/*     */   private String field_6_author;
/*     */   
/*     */   private Byte field_7_padding;
/*     */   
/*     */ 
/*     */   public NoteRecord()
/*     */   {
/*  64 */     this.field_6_author = "";
/*  65 */     this.field_3_flags = 0;
/*  66 */     this.field_7_padding = DEFAULT_PADDING;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/*  73 */     return 28;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NoteRecord(RecordInputStream in)
/*     */   {
/*  80 */     this.field_1_row = in.readUShort();
/*  81 */     this.field_2_col = in.readShort();
/*  82 */     this.field_3_flags = in.readShort();
/*  83 */     this.field_4_shapeid = in.readUShort();
/*  84 */     int length = in.readShort();
/*  85 */     this.field_5_hasMultibyte = (in.readByte() != 0);
/*  86 */     if (this.field_5_hasMultibyte) {
/*  87 */       this.field_6_author = StringUtil.readUnicodeLE(in, length);
/*     */     } else {
/*  89 */       this.field_6_author = StringUtil.readCompressedUnicode(in, length);
/*     */     }
/*  91 */     if (in.available() == 1) {
/*  92 */       this.field_7_padding = Byte.valueOf(in.readByte());
/*     */     }
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  97 */     out.writeShort(this.field_1_row);
/*  98 */     out.writeShort(this.field_2_col);
/*  99 */     out.writeShort(this.field_3_flags);
/* 100 */     out.writeShort(this.field_4_shapeid);
/* 101 */     out.writeShort(this.field_6_author.length());
/* 102 */     out.writeByte(this.field_5_hasMultibyte ? 1 : 0);
/* 103 */     if (this.field_5_hasMultibyte) {
/* 104 */       StringUtil.putUnicodeLE(this.field_6_author, out);
/*     */     } else {
/* 106 */       StringUtil.putCompressedUnicode(this.field_6_author, out);
/*     */     }
/* 108 */     if (this.field_7_padding != null) {
/* 109 */       out.writeByte(this.field_7_padding.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 114 */     return 11 + this.field_6_author.length() * (this.field_5_hasMultibyte ? 2 : 1) + (this.field_7_padding == null ? 0 : 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 126 */     buffer.append("[NOTE]\n");
/* 127 */     buffer.append("    .row    = ").append(this.field_1_row).append("\n");
/* 128 */     buffer.append("    .col    = ").append(this.field_2_col).append("\n");
/* 129 */     buffer.append("    .flags  = ").append(this.field_3_flags).append("\n");
/* 130 */     buffer.append("    .shapeid= ").append(this.field_4_shapeid).append("\n");
/* 131 */     buffer.append("    .author = ").append(this.field_6_author).append("\n");
/* 132 */     buffer.append("[/NOTE]\n");
/* 133 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRow()
/*     */   {
/* 142 */     return this.field_1_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRow(int row)
/*     */   {
/* 151 */     this.field_1_row = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumn()
/*     */   {
/* 160 */     return this.field_2_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumn(int col)
/*     */   {
/* 169 */     this.field_2_col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFlags()
/*     */   {
/* 180 */     return this.field_3_flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlags(short flags)
/*     */   {
/* 191 */     this.field_3_flags = flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean authorIsMultibyte()
/*     */   {
/* 198 */     return this.field_5_hasMultibyte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getShapeId()
/*     */   {
/* 205 */     return this.field_4_shapeid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setShapeId(int id)
/*     */   {
/* 212 */     this.field_4_shapeid = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAuthor()
/*     */   {
/* 221 */     return this.field_6_author;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuthor(String author)
/*     */   {
/* 230 */     this.field_6_author = author;
/* 231 */     this.field_5_hasMultibyte = StringUtil.hasMultibyte(author);
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 235 */     NoteRecord rec = new NoteRecord();
/* 236 */     rec.field_1_row = this.field_1_row;
/* 237 */     rec.field_2_col = this.field_2_col;
/* 238 */     rec.field_3_flags = this.field_3_flags;
/* 239 */     rec.field_4_shapeid = this.field_4_shapeid;
/* 240 */     rec.field_6_author = this.field_6_author;
/* 241 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\NoteRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */