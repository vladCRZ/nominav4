/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NoteStructureSubRecord
/*     */   extends SubRecord
/*     */ {
/*     */   public static final short sid = 13;
/*     */   private static final int ENCODED_SIZE = 22;
/*     */   private byte[] reserved;
/*     */   
/*     */   public NoteStructureSubRecord()
/*     */   {
/*  47 */     this.reserved = new byte[22];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NoteStructureSubRecord(LittleEndianInput in, int size)
/*     */   {
/*  54 */     if (size != 22) {
/*  55 */       throw new RecordFormatException("Unexpected size (" + size + ")");
/*     */     }
/*     */     
/*  58 */     byte[] buf = new byte[size];
/*  59 */     in.readFully(buf);
/*  60 */     this.reserved = buf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  69 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  71 */     buffer.append("[ftNts ]").append("\n");
/*  72 */     buffer.append("  size     = ").append(getDataSize()).append("\n");
/*  73 */     buffer.append("  reserved = ").append(HexDump.toHex(this.reserved)).append("\n");
/*  74 */     buffer.append("[/ftNts ]").append("\n");
/*  75 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/*  84 */     out.writeShort(13);
/*  85 */     out.writeShort(this.reserved.length);
/*  86 */     out.write(this.reserved);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  90 */     return this.reserved.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/*  98 */     return 13;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 102 */     NoteStructureSubRecord rec = new NoteStructureSubRecord();
/* 103 */     byte[] recdata = new byte[this.reserved.length];
/* 104 */     System.arraycopy(this.reserved, 0, recdata, 0, recdata.length);
/* 105 */     rec.reserved = recdata;
/* 106 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\NoteStructureSubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */