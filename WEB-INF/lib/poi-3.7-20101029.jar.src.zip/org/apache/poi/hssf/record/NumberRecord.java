/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.ss.util.NumberToTextConverter;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NumberRecord
/*    */   extends CellRecord
/*    */ {
/*    */   public static final short sid = 515;
/*    */   private double field_4_value;
/*    */   
/*    */   public NumberRecord() {}
/*    */   
/*    */   public NumberRecord(RecordInputStream in)
/*    */   {
/* 42 */     super(in);
/* 43 */     this.field_4_value = in.readDouble();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(double value)
/*    */   {
/* 52 */     this.field_4_value = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getValue()
/*    */   {
/* 61 */     return this.field_4_value;
/*    */   }
/*    */   
/*    */   protected String getRecordName()
/*    */   {
/* 66 */     return "NUMBER";
/*    */   }
/*    */   
/*    */   protected void appendValueText(StringBuilder sb)
/*    */   {
/* 71 */     sb.append("  .value= ").append(NumberToTextConverter.toText(this.field_4_value));
/*    */   }
/*    */   
/*    */   protected void serializeValue(LittleEndianOutput out)
/*    */   {
/* 76 */     out.writeDouble(getValue());
/*    */   }
/*    */   
/*    */   protected int getValueDataSize()
/*    */   {
/* 81 */     return 8;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 85 */     return 515;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 89 */     NumberRecord rec = new NumberRecord();
/* 90 */     copyBaseFields(rec);
/* 91 */     rec.field_4_value = this.field_4_value;
/* 92 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\NumberRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */