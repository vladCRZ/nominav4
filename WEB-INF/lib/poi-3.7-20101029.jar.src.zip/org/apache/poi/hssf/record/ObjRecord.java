/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ import org.apache.poi.util.LittleEndianByteArrayOutputStream;
/*     */ import org.apache.poi.util.LittleEndianInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjRecord
/*     */   extends Record
/*     */ {
/*     */   public static final short sid = 93;
/*     */   private static final int NORMAL_PAD_ALIGNMENT = 2;
/*  40 */   private static int MAX_PAD_ALIGNMENT = 4;
/*     */   
/*     */ 
/*     */   private List<SubRecord> subrecords;
/*     */   
/*     */ 
/*     */   private final byte[] _uninterpretedData;
/*     */   
/*     */ 
/*     */   private boolean _isPaddedToQuadByteMultiple;
/*     */   
/*     */ 
/*     */ 
/*     */   public ObjRecord()
/*     */   {
/*  55 */     this.subrecords = new ArrayList(2);
/*     */     
/*  57 */     this._uninterpretedData = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjRecord(RecordInputStream in)
/*     */   {
/*  72 */     byte[] subRecordData = in.readRemainder();
/*  73 */     if (LittleEndian.getUShort(subRecordData, 0) != 21)
/*     */     {
/*     */ 
/*     */ 
/*  77 */       this._uninterpretedData = subRecordData;
/*  78 */       this.subrecords = null;
/*  79 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     this.subrecords = new ArrayList();
/*  91 */     ByteArrayInputStream bais = new ByteArrayInputStream(subRecordData);
/*  92 */     LittleEndianInputStream subRecStream = new LittleEndianInputStream(bais);
/*  93 */     CommonObjectDataSubRecord cmo = (CommonObjectDataSubRecord)SubRecord.createSubRecord(subRecStream, 0);
/*  94 */     this.subrecords.add(cmo);
/*     */     for (;;) {
/*  96 */       SubRecord subRecord = SubRecord.createSubRecord(subRecStream, cmo.getObjectType());
/*  97 */       this.subrecords.add(subRecord);
/*  98 */       if (subRecord.isTerminating()) {
/*     */         break;
/*     */       }
/*     */     }
/* 102 */     int nRemainingBytes = bais.available();
/* 103 */     if (nRemainingBytes > 0)
/*     */     {
/* 105 */       this._isPaddedToQuadByteMultiple = (subRecordData.length % MAX_PAD_ALIGNMENT == 0);
/* 106 */       if (nRemainingBytes >= (this._isPaddedToQuadByteMultiple ? MAX_PAD_ALIGNMENT : 2)) {
/* 107 */         if (!canPaddingBeDiscarded(subRecordData, nRemainingBytes)) {
/* 108 */           String msg = "Leftover " + nRemainingBytes + " bytes in subrecord data " + HexDump.toHex(subRecordData);
/*     */           
/* 110 */           throw new RecordFormatException(msg);
/*     */         }
/* 112 */         this._isPaddedToQuadByteMultiple = false;
/*     */       }
/*     */     }
/*     */     else {
/* 116 */       this._isPaddedToQuadByteMultiple = false;
/*     */     }
/* 118 */     this._uninterpretedData = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean canPaddingBeDiscarded(byte[] data, int nRemainingBytes)
/*     */   {
/* 132 */     for (int i = data.length - nRemainingBytes; i < data.length; i++) {
/* 133 */       if (data[i] != 0) {
/* 134 */         return false;
/*     */       }
/*     */     }
/* 137 */     return true;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 141 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 143 */     sb.append("[OBJ]\n");
/* 144 */     for (int i = 0; i < this.subrecords.size(); i++) {
/* 145 */       SubRecord record = (SubRecord)this.subrecords.get(i);
/* 146 */       sb.append("SUBRECORD: ").append(record.toString());
/*     */     }
/* 148 */     sb.append("[/OBJ]\n");
/* 149 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public int getRecordSize() {
/* 153 */     if (this._uninterpretedData != null) {
/* 154 */       return this._uninterpretedData.length + 4;
/*     */     }
/* 156 */     int size = 0;
/* 157 */     for (int i = this.subrecords.size() - 1; i >= 0; i--) {
/* 158 */       SubRecord record = (SubRecord)this.subrecords.get(i);
/* 159 */       size += record.getDataSize() + 4;
/*     */     }
/* 161 */     if (this._isPaddedToQuadByteMultiple) {
/* 162 */       while (size % MAX_PAD_ALIGNMENT != 0) {
/* 163 */         size++;
/*     */       }
/*     */     }
/* 166 */     while (size % 2 != 0) {
/* 167 */       size++;
/*     */     }
/*     */     
/* 170 */     return size + 4;
/*     */   }
/*     */   
/*     */   public int serialize(int offset, byte[] data) {
/* 174 */     int recSize = getRecordSize();
/* 175 */     int dataSize = recSize - 4;
/* 176 */     LittleEndianByteArrayOutputStream out = new LittleEndianByteArrayOutputStream(data, offset, recSize);
/*     */     
/* 178 */     out.writeShort(93);
/* 179 */     out.writeShort(dataSize);
/*     */     
/* 181 */     if (this._uninterpretedData == null)
/*     */     {
/* 183 */       for (int i = 0; i < this.subrecords.size(); i++) {
/* 184 */         SubRecord record = (SubRecord)this.subrecords.get(i);
/* 185 */         record.serialize(out);
/*     */       }
/* 187 */       int expectedEndIx = offset + dataSize;
/*     */       
/* 189 */       while (out.getWriteIndex() < expectedEndIx) {
/* 190 */         out.writeByte(0);
/*     */       }
/*     */     } else {
/* 193 */       out.write(this._uninterpretedData);
/*     */     }
/* 195 */     return recSize;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 199 */     return 93;
/*     */   }
/*     */   
/*     */   public List<SubRecord> getSubRecords() {
/* 203 */     return this.subrecords;
/*     */   }
/*     */   
/*     */   public void clearSubRecords() {
/* 207 */     this.subrecords.clear();
/*     */   }
/*     */   
/*     */   public void addSubRecord(int index, SubRecord element) {
/* 211 */     this.subrecords.add(index, element);
/*     */   }
/*     */   
/*     */   public boolean addSubRecord(SubRecord o) {
/* 215 */     return this.subrecords.add(o);
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 219 */     ObjRecord rec = new ObjRecord();
/*     */     
/* 221 */     for (int i = 0; i < this.subrecords.size(); i++) {
/* 222 */       SubRecord record = (SubRecord)this.subrecords.get(i);
/* 223 */       rec.addSubRecord((SubRecord)record.clone());
/*     */     }
/* 225 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ObjRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */