/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PageBreakRecord
/*     */   extends StandardRecord
/*     */ {
/*  40 */   private static final int[] EMPTY_INT_ARRAY = new int[0];
/*     */   
/*     */ 
/*     */   private List<Break> _breaks;
/*     */   
/*     */   private Map<Integer, Break> _breakMap;
/*     */   
/*     */ 
/*     */   public static final class Break
/*     */   {
/*     */     public static final int ENCODED_SIZE = 6;
/*     */     
/*     */     public int main;
/*     */     
/*     */     public int subFrom;
/*     */     
/*     */     public int subTo;
/*     */     
/*     */ 
/*     */     public Break(int main, int subFrom, int subTo)
/*     */     {
/*  61 */       this.main = main;
/*  62 */       this.subFrom = subFrom;
/*  63 */       this.subTo = subTo;
/*     */     }
/*     */     
/*     */     public Break(RecordInputStream in) {
/*  67 */       this.main = (in.readUShort() - 1);
/*  68 */       this.subFrom = in.readUShort();
/*  69 */       this.subTo = in.readUShort();
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  73 */       out.writeShort(this.main + 1);
/*  74 */       out.writeShort(this.subFrom);
/*  75 */       out.writeShort(this.subTo);
/*     */     }
/*     */   }
/*     */   
/*     */   protected PageBreakRecord() {
/*  80 */     this._breaks = new ArrayList();
/*  81 */     this._breakMap = new HashMap();
/*     */   }
/*     */   
/*     */   public PageBreakRecord(RecordInputStream in)
/*     */   {
/*  86 */     int nBreaks = in.readShort();
/*  87 */     this._breaks = new ArrayList(nBreaks + 2);
/*  88 */     this._breakMap = new HashMap();
/*     */     
/*  90 */     for (int k = 0; k < nBreaks; k++) {
/*  91 */       Break br = new Break(in);
/*  92 */       this._breaks.add(br);
/*  93 */       this._breakMap.put(Integer.valueOf(br.main), br);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  99 */     return this._breaks.isEmpty();
/*     */   }
/*     */   
/* 102 */   protected int getDataSize() { return 2 + this._breaks.size() * 6; }
/*     */   
/*     */   public final void serialize(LittleEndianOutput out)
/*     */   {
/* 106 */     int nBreaks = this._breaks.size();
/* 107 */     out.writeShort(nBreaks);
/* 108 */     for (int i = 0; i < nBreaks; i++) {
/* 109 */       ((Break)this._breaks.get(i)).serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getNumBreaks() {
/* 114 */     return this._breaks.size();
/*     */   }
/*     */   
/*     */   public final Iterator<Break> getBreaksIterator() {
/* 118 */     return this._breaks.iterator();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 122 */     StringBuffer retval = new StringBuffer();
/*     */     
/*     */     String subLabel;
/*     */     String label;
/*     */     String mainLabel;
/*     */     String subLabel;
/* 128 */     if (getSid() == 27) {
/* 129 */       String label = "HORIZONTALPAGEBREAK";
/* 130 */       String mainLabel = "row";
/* 131 */       subLabel = "col";
/*     */     } else {
/* 133 */       label = "VERTICALPAGEBREAK";
/* 134 */       mainLabel = "column";
/* 135 */       subLabel = "row";
/*     */     }
/*     */     
/* 138 */     retval.append("[" + label + "]").append("\n");
/* 139 */     retval.append("     .sid        =").append(getSid()).append("\n");
/* 140 */     retval.append("     .numbreaks =").append(getNumBreaks()).append("\n");
/* 141 */     Iterator<Break> iterator = getBreaksIterator();
/* 142 */     for (int k = 0; k < getNumBreaks(); k++)
/*     */     {
/* 144 */       Break region = (Break)iterator.next();
/*     */       
/* 146 */       retval.append("     .").append(mainLabel).append(" (zero-based) =").append(region.main).append("\n");
/* 147 */       retval.append("     .").append(subLabel).append("From    =").append(region.subFrom).append("\n");
/* 148 */       retval.append("     .").append(subLabel).append("To      =").append(region.subTo).append("\n");
/*     */     }
/*     */     
/* 151 */     retval.append("[" + label + "]").append("\n");
/* 152 */     return retval.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBreak(int main, int subFrom, int subTo)
/*     */   {
/* 163 */     Integer key = Integer.valueOf(main);
/* 164 */     Break region = (Break)this._breakMap.get(key);
/* 165 */     if (region == null) {
/* 166 */       region = new Break(main, subFrom, subTo);
/* 167 */       this._breakMap.put(key, region);
/* 168 */       this._breaks.add(region);
/*     */     } else {
/* 170 */       region.main = main;
/* 171 */       region.subFrom = subFrom;
/* 172 */       region.subTo = subTo;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeBreak(int main)
/*     */   {
/* 181 */     Integer rowKey = Integer.valueOf(main);
/* 182 */     Break region = (Break)this._breakMap.get(rowKey);
/* 183 */     this._breaks.remove(region);
/* 184 */     this._breakMap.remove(rowKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Break getBreak(int main)
/*     */   {
/* 193 */     Integer rowKey = Integer.valueOf(main);
/* 194 */     return (Break)this._breakMap.get(rowKey);
/*     */   }
/*     */   
/*     */   public final int[] getBreaks() {
/* 198 */     int count = getNumBreaks();
/* 199 */     if (count < 1) {
/* 200 */       return EMPTY_INT_ARRAY;
/*     */     }
/* 202 */     int[] result = new int[count];
/* 203 */     for (int i = 0; i < count; i++) {
/* 204 */       Break breakItem = (Break)this._breaks.get(i);
/* 205 */       result[i] = breakItem.main;
/*     */     }
/* 207 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PageBreakRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */