/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PaletteRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 146;
/*     */   public static final byte STANDARD_PALETTE_SIZE = 56;
/*     */   public static final short FIRST_COLOR_INDEX = 8;
/*     */   private final List<PColor> _colors;
/*     */   
/*     */   public PaletteRecord()
/*     */   {
/*  41 */     PColor[] defaultPalette = createDefaultPalette();
/*  42 */     this._colors = new ArrayList(defaultPalette.length);
/*  43 */     for (int i = 0; i < defaultPalette.length; i++) {
/*  44 */       this._colors.add(defaultPalette[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public PaletteRecord(RecordInputStream in) {
/*  49 */     int field_1_numcolors = in.readShort();
/*  50 */     this._colors = new ArrayList(field_1_numcolors);
/*  51 */     for (int k = 0; k < field_1_numcolors; k++) {
/*  52 */       this._colors.add(new PColor(in));
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/*  57 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  59 */     buffer.append("[PALETTE]\n");
/*  60 */     buffer.append("  numcolors     = ").append(this._colors.size()).append('\n');
/*  61 */     for (int i = 0; i < this._colors.size(); i++) {
/*  62 */       PColor c = (PColor)this._colors.get(i);
/*  63 */       buffer.append("* colornum      = ").append(i).append('\n');
/*  64 */       buffer.append(c.toString());
/*  65 */       buffer.append("/*colornum      = ").append(i).append('\n');
/*     */     }
/*  67 */     buffer.append("[/PALETTE]\n");
/*  68 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  72 */     out.writeShort(this._colors.size());
/*  73 */     for (int i = 0; i < this._colors.size(); i++) {
/*  74 */       ((PColor)this._colors.get(i)).serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  79 */     return 2 + this._colors.size() * 4;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  83 */     return 146;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getColor(int byteIndex)
/*     */   {
/*  93 */     int i = byteIndex - 8;
/*  94 */     if ((i < 0) || (i >= this._colors.size())) {
/*  95 */       return null;
/*     */     }
/*  97 */     return ((PColor)this._colors.get(i)).getTriplet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColor(short byteIndex, byte red, byte green, byte blue)
/*     */   {
/* 111 */     int i = byteIndex - 8;
/* 112 */     if ((i < 0) || (i >= 56))
/*     */     {
/* 114 */       return;
/*     */     }
/*     */     
/* 117 */     while (this._colors.size() <= i) {
/* 118 */       this._colors.add(new PColor(0, 0, 0));
/*     */     }
/* 120 */     PColor custColor = new PColor(red, green, blue);
/* 121 */     this._colors.set(i, custColor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PColor[] createDefaultPalette()
/*     */   {
/* 129 */     return new PColor[] { pc(0, 0, 0), pc(255, 255, 255), pc(255, 0, 0), pc(0, 255, 0), pc(0, 0, 255), pc(255, 255, 0), pc(255, 0, 255), pc(0, 255, 255), pc(128, 0, 0), pc(0, 128, 0), pc(0, 0, 128), pc(128, 128, 0), pc(128, 0, 128), pc(0, 128, 128), pc(192, 192, 192), pc(128, 128, 128), pc(153, 153, 255), pc(153, 51, 102), pc(255, 255, 204), pc(204, 255, 255), pc(102, 0, 102), pc(255, 128, 128), pc(0, 102, 204), pc(204, 204, 255), pc(0, 0, 128), pc(255, 0, 255), pc(255, 255, 0), pc(0, 255, 255), pc(128, 0, 128), pc(128, 0, 0), pc(0, 128, 128), pc(0, 0, 255), pc(0, 204, 255), pc(204, 255, 255), pc(204, 255, 204), pc(255, 255, 153), pc(153, 204, 255), pc(255, 153, 204), pc(204, 153, 255), pc(255, 204, 153), pc(51, 102, 255), pc(51, 204, 204), pc(153, 204, 0), pc(255, 204, 0), pc(255, 153, 0), pc(255, 102, 0), pc(102, 102, 153), pc(150, 150, 150), pc(0, 51, 102), pc(51, 153, 102), pc(0, 51, 0), pc(51, 51, 0), pc(153, 51, 0), pc(153, 51, 102), pc(51, 51, 153), pc(51, 51, 51) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PColor pc(int r, int g, int b)
/*     */   {
/* 190 */     return new PColor(r, g, b);
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class PColor
/*     */   {
/*     */     public static final short ENCODED_SIZE = 4;
/*     */     private int _red;
/*     */     private int _green;
/*     */     private int _blue;
/*     */     
/*     */     public PColor(int red, int green, int blue)
/*     */     {
/* 203 */       this._red = red;
/* 204 */       this._green = green;
/* 205 */       this._blue = blue;
/*     */     }
/*     */     
/*     */     public byte[] getTriplet() {
/* 209 */       return new byte[] { (byte)this._red, (byte)this._green, (byte)this._blue };
/*     */     }
/*     */     
/*     */     public PColor(RecordInputStream in) {
/* 213 */       this._red = in.readByte();
/* 214 */       this._green = in.readByte();
/* 215 */       this._blue = in.readByte();
/* 216 */       in.readByte();
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/* 220 */       out.writeByte(this._red);
/* 221 */       out.writeByte(this._green);
/* 222 */       out.writeByte(this._blue);
/* 223 */       out.writeByte(0);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 227 */       StringBuffer buffer = new StringBuffer();
/* 228 */       buffer.append("  red   = ").append(this._red & 0xFF).append('\n');
/* 229 */       buffer.append("  green = ").append(this._green & 0xFF).append('\n');
/* 230 */       buffer.append("  blue  = ").append(this._blue & 0xFF).append('\n');
/* 231 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PaletteRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */