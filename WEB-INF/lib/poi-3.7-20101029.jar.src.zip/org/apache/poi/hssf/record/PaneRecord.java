/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PaneRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 65;
/*     */   private short field_1_x;
/*     */   private short field_2_y;
/*     */   private short field_3_topRow;
/*     */   private short field_4_leftColumn;
/*     */   private short field_5_activePane;
/*     */   public static final short ACTIVE_PANE_LOWER_RIGHT = 0;
/*     */   public static final short ACTIVE_PANE_UPPER_RIGHT = 1;
/*     */   public static final short ACTIVE_PANE_LOWER_LEFT = 2;
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static final short ACTIVE_PANE_UPER_LEFT = 3;
/*     */   public static final short ACTIVE_PANE_UPPER_LEFT = 3;
/*     */   
/*     */   public PaneRecord() {}
/*     */   
/*     */   public PaneRecord(RecordInputStream in)
/*     */   {
/*  52 */     this.field_1_x = in.readShort();
/*  53 */     this.field_2_y = in.readShort();
/*  54 */     this.field_3_topRow = in.readShort();
/*  55 */     this.field_4_leftColumn = in.readShort();
/*  56 */     this.field_5_activePane = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  61 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  63 */     buffer.append("[PANE]\n");
/*  64 */     buffer.append("    .x                    = ").append("0x").append(HexDump.toHex(getX())).append(" (").append(getX()).append(" )");
/*     */     
/*     */ 
/*  67 */     buffer.append(System.getProperty("line.separator"));
/*  68 */     buffer.append("    .y                    = ").append("0x").append(HexDump.toHex(getY())).append(" (").append(getY()).append(" )");
/*     */     
/*     */ 
/*  71 */     buffer.append(System.getProperty("line.separator"));
/*  72 */     buffer.append("    .topRow               = ").append("0x").append(HexDump.toHex(getTopRow())).append(" (").append(getTopRow()).append(" )");
/*     */     
/*     */ 
/*  75 */     buffer.append(System.getProperty("line.separator"));
/*  76 */     buffer.append("    .leftColumn           = ").append("0x").append(HexDump.toHex(getLeftColumn())).append(" (").append(getLeftColumn()).append(" )");
/*     */     
/*     */ 
/*  79 */     buffer.append(System.getProperty("line.separator"));
/*  80 */     buffer.append("    .activePane           = ").append("0x").append(HexDump.toHex(getActivePane())).append(" (").append(getActivePane()).append(" )");
/*     */     
/*     */ 
/*  83 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  85 */     buffer.append("[/PANE]\n");
/*  86 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  90 */     out.writeShort(this.field_1_x);
/*  91 */     out.writeShort(this.field_2_y);
/*  92 */     out.writeShort(this.field_3_topRow);
/*  93 */     out.writeShort(this.field_4_leftColumn);
/*  94 */     out.writeShort(this.field_5_activePane);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  98 */     return 10;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 103 */     return 65;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 107 */     PaneRecord rec = new PaneRecord();
/*     */     
/* 109 */     rec.field_1_x = this.field_1_x;
/* 110 */     rec.field_2_y = this.field_2_y;
/* 111 */     rec.field_3_topRow = this.field_3_topRow;
/* 112 */     rec.field_4_leftColumn = this.field_4_leftColumn;
/* 113 */     rec.field_5_activePane = this.field_5_activePane;
/* 114 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getX()
/*     */   {
/* 125 */     return this.field_1_x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setX(short field_1_x)
/*     */   {
/* 133 */     this.field_1_x = field_1_x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getY()
/*     */   {
/* 141 */     return this.field_2_y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setY(short field_2_y)
/*     */   {
/* 149 */     this.field_2_y = field_2_y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getTopRow()
/*     */   {
/* 157 */     return this.field_3_topRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTopRow(short field_3_topRow)
/*     */   {
/* 165 */     this.field_3_topRow = field_3_topRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLeftColumn()
/*     */   {
/* 173 */     return this.field_4_leftColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeftColumn(short field_4_leftColumn)
/*     */   {
/* 181 */     this.field_4_leftColumn = field_4_leftColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getActivePane()
/*     */   {
/* 195 */     return this.field_5_activePane;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActivePane(short field_5_activePane)
/*     */   {
/* 210 */     this.field_5_activePane = field_5_activePane;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PaneRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */