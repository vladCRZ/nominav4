/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PasswordRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 19;
/*     */   private int field_1_password;
/*     */   
/*     */   public PasswordRecord(int password)
/*     */   {
/*  35 */     this.field_1_password = password;
/*     */   }
/*     */   
/*     */   public PasswordRecord(RecordInputStream in) {
/*  39 */     this.field_1_password = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */   public static short hashPassword(String password)
/*     */   {
/*  45 */     byte[] passwordCharacters = password.getBytes();
/*  46 */     int hash = 0;
/*  47 */     if (passwordCharacters.length > 0) {
/*  48 */       int charIndex = passwordCharacters.length;
/*  49 */       while (charIndex-- > 0) {
/*  50 */         hash = hash >> 14 & 0x1 | hash << 1 & 0x7FFF;
/*  51 */         hash ^= passwordCharacters[charIndex];
/*     */       }
/*     */       
/*  54 */       hash = hash >> 14 & 0x1 | hash << 1 & 0x7FFF;
/*  55 */       hash ^= passwordCharacters.length;
/*  56 */       hash ^= 0xCE4B;
/*     */     }
/*  58 */     return (short)hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(int password)
/*     */   {
/*  68 */     this.field_1_password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPassword()
/*     */   {
/*  77 */     return this.field_1_password;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  81 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  83 */     buffer.append("[PASSWORD]\n");
/*  84 */     buffer.append("    .password = ").append(HexDump.shortToHex(this.field_1_password)).append("\n");
/*  85 */     buffer.append("[/PASSWORD]\n");
/*  86 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  90 */     out.writeShort(this.field_1_password);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  94 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  98 */     return 19;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 105 */     return new PasswordRecord(this.field_1_password);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PasswordRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */