/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PasswordRev4Record
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 444;
/*    */   private int field_1_password;
/*    */   
/*    */   public PasswordRev4Record(int pw)
/*    */   {
/* 34 */     this.field_1_password = pw;
/*    */   }
/*    */   
/*    */   public PasswordRev4Record(RecordInputStream in) {
/* 38 */     this.field_1_password = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setPassword(short pw)
/*    */   {
/* 47 */     this.field_1_password = pw;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 53 */     buffer.append("[PROT4REVPASSWORD]\n");
/* 54 */     buffer.append("    .password = ").append(HexDump.shortToHex(this.field_1_password)).append("\n");
/* 55 */     buffer.append("[/PROT4REVPASSWORD]\n");
/* 56 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 60 */     out.writeShort(this.field_1_password);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 64 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 68 */     return 444;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PasswordRev4Record.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */