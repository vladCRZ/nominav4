/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrecisionRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 14;
/*    */   public short field_1_precision;
/*    */   
/*    */   public PrecisionRecord() {}
/*    */   
/*    */   public PrecisionRecord(RecordInputStream in)
/*    */   {
/* 45 */     this.field_1_precision = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setFullPrecision(boolean fullprecision)
/*    */   {
/* 56 */     if (fullprecision == true)
/*    */     {
/* 58 */       this.field_1_precision = 1;
/*    */     }
/*    */     else
/*    */     {
/* 62 */       this.field_1_precision = 0;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getFullPrecision()
/*    */   {
/* 74 */     return this.field_1_precision == 1;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 79 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 81 */     buffer.append("[PRECISION]\n");
/* 82 */     buffer.append("    .precision       = ").append(getFullPrecision()).append("\n");
/*    */     
/* 84 */     buffer.append("[/PRECISION]\n");
/* 85 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 89 */     out.writeShort(this.field_1_precision);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 93 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 98 */     return 14;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PrecisionRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */