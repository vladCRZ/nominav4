/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrintHeadersRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 42;
/*     */   private short field_1_print_headers;
/*     */   
/*     */   public PrintHeadersRecord() {}
/*     */   
/*     */   public PrintHeadersRecord(RecordInputStream in)
/*     */   {
/*  46 */     this.field_1_print_headers = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrintHeaders(boolean p)
/*     */   {
/*  56 */     if (p == true)
/*     */     {
/*  58 */       this.field_1_print_headers = 1;
/*     */     }
/*     */     else
/*     */     {
/*  62 */       this.field_1_print_headers = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getPrintHeaders()
/*     */   {
/*  73 */     return this.field_1_print_headers == 1;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  78 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  80 */     buffer.append("[PRINTHEADERS]\n");
/*  81 */     buffer.append("    .printheaders   = ").append(getPrintHeaders()).append("\n");
/*     */     
/*  83 */     buffer.append("[/PRINTHEADERS]\n");
/*  84 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  88 */     out.writeShort(this.field_1_print_headers);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  92 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  97 */     return 42;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 101 */     PrintHeadersRecord rec = new PrintHeadersRecord();
/* 102 */     rec.field_1_print_headers = this.field_1_print_headers;
/* 103 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PrintHeadersRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */