/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrintSetupRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 161;
/*     */   private short field_1_paper_size;
/*     */   private short field_2_scale;
/*     */   private short field_3_page_start;
/*     */   private short field_4_fit_width;
/*     */   private short field_5_fit_height;
/*     */   private short field_6_options;
/*  43 */   private static final BitField lefttoright = BitFieldFactory.getInstance(1);
/*     */   
/*  45 */   private static final BitField landscape = BitFieldFactory.getInstance(2);
/*     */   
/*  47 */   private static final BitField validsettings = BitFieldFactory.getInstance(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private static final BitField nocolor = BitFieldFactory.getInstance(8);
/*     */   
/*  54 */   private static final BitField draft = BitFieldFactory.getInstance(16);
/*     */   
/*  56 */   private static final BitField notes = BitFieldFactory.getInstance(32);
/*     */   
/*  58 */   private static final BitField noOrientation = BitFieldFactory.getInstance(64);
/*     */   
/*  60 */   private static final BitField usepage = BitFieldFactory.getInstance(128);
/*     */   
/*     */   private short field_7_hresolution;
/*     */   
/*     */   private short field_8_vresolution;
/*     */   
/*     */   private double field_9_headermargin;
/*     */   private double field_10_footermargin;
/*     */   private short field_11_copies;
/*     */   
/*     */   public PrintSetupRecord() {}
/*     */   
/*     */   public PrintSetupRecord(RecordInputStream in)
/*     */   {
/*  74 */     this.field_1_paper_size = in.readShort();
/*  75 */     this.field_2_scale = in.readShort();
/*  76 */     this.field_3_page_start = in.readShort();
/*  77 */     this.field_4_fit_width = in.readShort();
/*  78 */     this.field_5_fit_height = in.readShort();
/*  79 */     this.field_6_options = in.readShort();
/*  80 */     this.field_7_hresolution = in.readShort();
/*  81 */     this.field_8_vresolution = in.readShort();
/*  82 */     this.field_9_headermargin = in.readDouble();
/*  83 */     this.field_10_footermargin = in.readDouble();
/*  84 */     this.field_11_copies = in.readShort();
/*     */   }
/*     */   
/*     */   public void setPaperSize(short size)
/*     */   {
/*  89 */     this.field_1_paper_size = size;
/*     */   }
/*     */   
/*     */   public void setScale(short scale)
/*     */   {
/*  94 */     this.field_2_scale = scale;
/*     */   }
/*     */   
/*     */   public void setPageStart(short start)
/*     */   {
/*  99 */     this.field_3_page_start = start;
/*     */   }
/*     */   
/*     */   public void setFitWidth(short width)
/*     */   {
/* 104 */     this.field_4_fit_width = width;
/*     */   }
/*     */   
/*     */   public void setFitHeight(short height)
/*     */   {
/* 109 */     this.field_5_fit_height = height;
/*     */   }
/*     */   
/*     */   public void setOptions(short options)
/*     */   {
/* 114 */     this.field_6_options = options;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLeftToRight(boolean ltor)
/*     */   {
/* 120 */     this.field_6_options = lefttoright.setShortBoolean(this.field_6_options, ltor);
/*     */   }
/*     */   
/*     */   public void setLandscape(boolean ls)
/*     */   {
/* 125 */     this.field_6_options = landscape.setShortBoolean(this.field_6_options, ls);
/*     */   }
/*     */   
/*     */   public void setValidSettings(boolean valid)
/*     */   {
/* 130 */     this.field_6_options = validsettings.setShortBoolean(this.field_6_options, valid);
/*     */   }
/*     */   
/*     */   public void setNoColor(boolean mono)
/*     */   {
/* 135 */     this.field_6_options = nocolor.setShortBoolean(this.field_6_options, mono);
/*     */   }
/*     */   
/*     */   public void setDraft(boolean d)
/*     */   {
/* 140 */     this.field_6_options = draft.setShortBoolean(this.field_6_options, d);
/*     */   }
/*     */   
/*     */   public void setNotes(boolean printnotes)
/*     */   {
/* 145 */     this.field_6_options = notes.setShortBoolean(this.field_6_options, printnotes);
/*     */   }
/*     */   
/*     */   public void setNoOrientation(boolean orientation)
/*     */   {
/* 150 */     this.field_6_options = noOrientation.setShortBoolean(this.field_6_options, orientation);
/*     */   }
/*     */   
/*     */   public void setUsePage(boolean page)
/*     */   {
/* 155 */     this.field_6_options = usepage.setShortBoolean(this.field_6_options, page);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setHResolution(short resolution)
/*     */   {
/* 161 */     this.field_7_hresolution = resolution;
/*     */   }
/*     */   
/*     */   public void setVResolution(short resolution)
/*     */   {
/* 166 */     this.field_8_vresolution = resolution;
/*     */   }
/*     */   
/*     */   public void setHeaderMargin(double headermargin)
/*     */   {
/* 171 */     this.field_9_headermargin = headermargin;
/*     */   }
/*     */   
/*     */   public void setFooterMargin(double footermargin)
/*     */   {
/* 176 */     this.field_10_footermargin = footermargin;
/*     */   }
/*     */   
/*     */   public void setCopies(short copies)
/*     */   {
/* 181 */     this.field_11_copies = copies;
/*     */   }
/*     */   
/*     */   public short getPaperSize()
/*     */   {
/* 186 */     return this.field_1_paper_size;
/*     */   }
/*     */   
/*     */   public short getScale()
/*     */   {
/* 191 */     return this.field_2_scale;
/*     */   }
/*     */   
/*     */   public short getPageStart()
/*     */   {
/* 196 */     return this.field_3_page_start;
/*     */   }
/*     */   
/*     */   public short getFitWidth()
/*     */   {
/* 201 */     return this.field_4_fit_width;
/*     */   }
/*     */   
/*     */   public short getFitHeight()
/*     */   {
/* 206 */     return this.field_5_fit_height;
/*     */   }
/*     */   
/*     */   public short getOptions()
/*     */   {
/* 211 */     return this.field_6_options;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getLeftToRight()
/*     */   {
/* 217 */     return lefttoright.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getLandscape()
/*     */   {
/* 222 */     return landscape.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getValidSettings()
/*     */   {
/* 227 */     return validsettings.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getNoColor()
/*     */   {
/* 232 */     return nocolor.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getDraft()
/*     */   {
/* 237 */     return draft.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getNotes()
/*     */   {
/* 242 */     return notes.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getNoOrientation()
/*     */   {
/* 247 */     return noOrientation.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */   public boolean getUsePage()
/*     */   {
/* 252 */     return usepage.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */   public short getHResolution()
/*     */   {
/* 258 */     return this.field_7_hresolution;
/*     */   }
/*     */   
/*     */   public short getVResolution()
/*     */   {
/* 263 */     return this.field_8_vresolution;
/*     */   }
/*     */   
/*     */   public double getHeaderMargin()
/*     */   {
/* 268 */     return this.field_9_headermargin;
/*     */   }
/*     */   
/*     */   public double getFooterMargin()
/*     */   {
/* 273 */     return this.field_10_footermargin;
/*     */   }
/*     */   
/*     */   public short getCopies()
/*     */   {
/* 278 */     return this.field_11_copies;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 283 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 285 */     buffer.append("[PRINTSETUP]\n");
/* 286 */     buffer.append("    .papersize      = ").append(getPaperSize()).append("\n");
/*     */     
/* 288 */     buffer.append("    .scale          = ").append(getScale()).append("\n");
/*     */     
/* 290 */     buffer.append("    .pagestart      = ").append(getPageStart()).append("\n");
/*     */     
/* 292 */     buffer.append("    .fitwidth       = ").append(getFitWidth()).append("\n");
/*     */     
/* 294 */     buffer.append("    .fitheight      = ").append(getFitHeight()).append("\n");
/*     */     
/* 296 */     buffer.append("    .options        = ").append(getOptions()).append("\n");
/*     */     
/* 298 */     buffer.append("        .ltor       = ").append(getLeftToRight()).append("\n");
/*     */     
/* 300 */     buffer.append("        .landscape  = ").append(getLandscape()).append("\n");
/*     */     
/* 302 */     buffer.append("        .valid      = ").append(getValidSettings()).append("\n");
/*     */     
/* 304 */     buffer.append("        .mono       = ").append(getNoColor()).append("\n");
/*     */     
/* 306 */     buffer.append("        .draft      = ").append(getDraft()).append("\n");
/*     */     
/* 308 */     buffer.append("        .notes      = ").append(getNotes()).append("\n");
/*     */     
/* 310 */     buffer.append("        .noOrientat = ").append(getNoOrientation()).append("\n");
/*     */     
/* 312 */     buffer.append("        .usepage    = ").append(getUsePage()).append("\n");
/*     */     
/* 314 */     buffer.append("    .hresolution    = ").append(getHResolution()).append("\n");
/*     */     
/* 316 */     buffer.append("    .vresolution    = ").append(getVResolution()).append("\n");
/*     */     
/* 318 */     buffer.append("    .headermargin   = ").append(getHeaderMargin()).append("\n");
/*     */     
/* 320 */     buffer.append("    .footermargin   = ").append(getFooterMargin()).append("\n");
/*     */     
/* 322 */     buffer.append("    .copies         = ").append(getCopies()).append("\n");
/*     */     
/* 324 */     buffer.append("[/PRINTSETUP]\n");
/* 325 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 329 */     out.writeShort(getPaperSize());
/* 330 */     out.writeShort(getScale());
/* 331 */     out.writeShort(getPageStart());
/* 332 */     out.writeShort(getFitWidth());
/* 333 */     out.writeShort(getFitHeight());
/* 334 */     out.writeShort(getOptions());
/* 335 */     out.writeShort(getHResolution());
/* 336 */     out.writeShort(getVResolution());
/* 337 */     out.writeDouble(getHeaderMargin());
/* 338 */     out.writeDouble(getFooterMargin());
/* 339 */     out.writeShort(getCopies());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 343 */     return 34;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 348 */     return 161;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 352 */     PrintSetupRecord rec = new PrintSetupRecord();
/* 353 */     rec.field_1_paper_size = this.field_1_paper_size;
/* 354 */     rec.field_2_scale = this.field_2_scale;
/* 355 */     rec.field_3_page_start = this.field_3_page_start;
/* 356 */     rec.field_4_fit_width = this.field_4_fit_width;
/* 357 */     rec.field_5_fit_height = this.field_5_fit_height;
/* 358 */     rec.field_6_options = this.field_6_options;
/* 359 */     rec.field_7_hresolution = this.field_7_hresolution;
/* 360 */     rec.field_8_vresolution = this.field_8_vresolution;
/* 361 */     rec.field_9_headermargin = this.field_9_headermargin;
/* 362 */     rec.field_10_footermargin = this.field_10_footermargin;
/* 363 */     rec.field_11_copies = this.field_11_copies;
/* 364 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\PrintSetupRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */