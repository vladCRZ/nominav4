/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.BitField;
/*    */ import org.apache.poi.util.BitFieldFactory;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ProtectRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 18;
/* 36 */   private static final BitField protectFlag = BitFieldFactory.getInstance(1);
/*    */   private int _options;
/*    */   
/*    */   private ProtectRecord(int options)
/*    */   {
/* 41 */     this._options = options;
/*    */   }
/*    */   
/*    */   public ProtectRecord(boolean isProtected) {
/* 45 */     this(0);
/* 46 */     setProtect(isProtected);
/*    */   }
/*    */   
/*    */   public ProtectRecord(RecordInputStream in) {
/* 50 */     this(in.readShort());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setProtect(boolean protect)
/*    */   {
/* 58 */     this._options = protectFlag.setBoolean(this._options, protect);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getProtect()
/*    */   {
/* 66 */     return protectFlag.isSet(this._options);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 70 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 72 */     buffer.append("[PROTECT]\n");
/* 73 */     buffer.append("    .options = ").append(HexDump.shortToHex(this._options)).append("\n");
/* 74 */     buffer.append("[/PROTECT]\n");
/* 75 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 79 */     out.writeShort(this._options);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 83 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 87 */     return 18;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 91 */     return new ProtectRecord(this._options);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\ProtectRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */