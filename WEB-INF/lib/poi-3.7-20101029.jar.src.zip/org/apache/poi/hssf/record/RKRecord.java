/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.util.RKUtil;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RKRecord
/*     */   extends CellRecord
/*     */ {
/*     */   public static final short sid = 638;
/*     */   public static final short RK_IEEE_NUMBER = 0;
/*     */   public static final short RK_IEEE_NUMBER_TIMES_100 = 1;
/*     */   public static final short RK_INTEGER = 2;
/*     */   public static final short RK_INTEGER_TIMES_100 = 3;
/*     */   private int field_4_rk_number;
/*     */   
/*     */   private RKRecord() {}
/*     */   
/*     */   public RKRecord(RecordInputStream in)
/*     */   {
/*  52 */     super(in);
/*  53 */     this.field_4_rk_number = in.readInt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getRKNumber()
/*     */   {
/*  74 */     return RKUtil.decodeNumber(this.field_4_rk_number);
/*     */   }
/*     */   
/*     */   protected String getRecordName()
/*     */   {
/*  79 */     return "RK";
/*     */   }
/*     */   
/*     */   protected void appendValueText(StringBuilder sb)
/*     */   {
/*  84 */     sb.append("  .value= ").append(getRKNumber());
/*     */   }
/*     */   
/*     */   protected void serializeValue(LittleEndianOutput out)
/*     */   {
/*  89 */     out.writeInt(this.field_4_rk_number);
/*     */   }
/*     */   
/*     */   protected int getValueDataSize()
/*     */   {
/*  94 */     return 4;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  98 */     return 638;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 102 */     RKRecord rec = new RKRecord();
/* 103 */     copyBaseFields(rec);
/* 104 */     rec.field_4_rk_number = this.field_4_rk_number;
/* 105 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RKRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */