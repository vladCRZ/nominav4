/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RecalcIdRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 449;
/*    */   private final int _reserved0;
/*    */   private final int _engineId;
/*    */   
/*    */   public RecalcIdRecord(RecordInputStream in)
/*    */   {
/* 39 */     in.readUShort();
/* 40 */     this._reserved0 = in.readUShort();
/* 41 */     this._engineId = in.readInt();
/*    */   }
/*    */   
/*    */   public boolean isNeeded() {
/* 45 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 49 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 51 */     buffer.append("[RECALCID]\n");
/* 52 */     buffer.append("    .reserved = ").append(HexDump.shortToHex(this._reserved0)).append("\n");
/* 53 */     buffer.append("    .engineId = ").append(HexDump.intToHex(this._engineId)).append("\n");
/* 54 */     buffer.append("[/RECALCID]\n");
/* 55 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 59 */     out.writeShort(449);
/* 60 */     out.writeShort(this._reserved0);
/* 61 */     out.writeInt(this._engineId);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 65 */     return 8;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 69 */     return 449;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RecalcIdRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */