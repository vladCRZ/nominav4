/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Record
/*    */   extends RecordBase
/*    */ {
/*    */   public final byte[] serialize()
/*    */   {
/* 43 */     byte[] retval = new byte[getRecordSize()];
/*    */     
/* 45 */     serialize(0, retval);
/* 46 */     return retval;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 53 */     return super.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract short getSid();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object clone()
/*    */   {
/* 71 */     throw new RuntimeException("The class " + getClass().getName() + " needs to define a clone method");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Record cloneViaReserialise()
/*    */   {
/* 86 */     byte[] b = serialize();
/* 87 */     RecordInputStream rinp = new RecordInputStream(new ByteArrayInputStream(b));
/* 88 */     rinp.nextRecord();
/*    */     
/* 90 */     Record[] r = RecordFactory.createRecord(rinp);
/* 91 */     if (r.length != 1) {
/* 92 */       throw new IllegalStateException("Re-serialised a record to clone it, but got " + r.length + " records back!");
/*    */     }
/* 94 */     return r[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\Record.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */