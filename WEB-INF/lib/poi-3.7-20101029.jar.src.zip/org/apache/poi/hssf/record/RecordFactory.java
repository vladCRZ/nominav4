/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.poi.hssf.record.chart.BeginRecord;
/*     */ import org.apache.poi.hssf.record.chart.ChartEndBlockRecord;
/*     */ import org.apache.poi.hssf.record.chart.ChartEndObjectRecord;
/*     */ import org.apache.poi.hssf.record.chart.ChartFRTInfoRecord;
/*     */ import org.apache.poi.hssf.record.chart.ChartRecord;
/*     */ import org.apache.poi.hssf.record.chart.ChartTitleFormatRecord;
/*     */ import org.apache.poi.hssf.record.chart.DataFormatRecord;
/*     */ import org.apache.poi.hssf.record.chart.LegendRecord;
/*     */ import org.apache.poi.hssf.record.chart.LinkedDataRecord;
/*     */ import org.apache.poi.hssf.record.chart.SeriesRecord;
/*     */ import org.apache.poi.hssf.record.chart.SeriesTextRecord;
/*     */ import org.apache.poi.hssf.record.chart.SeriesToChartGroupRecord;
/*     */ import org.apache.poi.hssf.record.pivottable.DataItemRecord;
/*     */ import org.apache.poi.hssf.record.pivottable.ExtendedPivotTableViewFieldsRecord;
/*     */ import org.apache.poi.hssf.record.pivottable.PageItemRecord;
/*     */ import org.apache.poi.hssf.record.pivottable.StreamIDRecord;
/*     */ import org.apache.poi.hssf.record.pivottable.ViewFieldsRecord;
/*     */ import org.apache.poi.hssf.record.pivottable.ViewSourceRecord;
/*     */ 
/*     */ 
/*     */ public final class RecordFactory
/*     */ {
/*     */   private static final int NUM_RECORDS = 512;
/*     */   
/*     */   private static abstract interface I_RecordCreator
/*     */   {
/*     */     public abstract Record create(RecordInputStream paramRecordInputStream);
/*     */     
/*     */     public abstract Class<? extends Record> getRecordClass();
/*     */   }
/*     */   
/*     */   private static final class ReflectionConstructorRecordCreator
/*     */     implements RecordFactory.I_RecordCreator
/*     */   {
/*     */     private final Constructor<? extends Record> _c;
/*     */     
/*  52 */     public ReflectionConstructorRecordCreator(Constructor<? extends Record> c) { this._c = c; }
/*     */     
/*     */     public Record create(RecordInputStream in) {
/*  55 */       Object[] args = { in };
/*     */       try {
/*  57 */         return (Record)this._c.newInstance(args);
/*     */       } catch (IllegalArgumentException e) {
/*  59 */         throw new RuntimeException(e);
/*     */       } catch (InstantiationException e) {
/*  61 */         throw new RuntimeException(e);
/*     */       } catch (IllegalAccessException e) {
/*  63 */         throw new RuntimeException(e);
/*     */       } catch (InvocationTargetException e) {
/*  65 */         throw new RecordFormatException("Unable to construct record instance", e.getTargetException());
/*     */       }
/*     */     }
/*     */     
/*  69 */     public Class<? extends Record> getRecordClass() { return this._c.getDeclaringClass(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class ReflectionMethodRecordCreator
/*     */     implements RecordFactory.I_RecordCreator
/*     */   {
/*     */     private final Method _m;
/*     */     
/*     */ 
/*  80 */     public ReflectionMethodRecordCreator(Method m) { this._m = m; }
/*     */     
/*     */     public Record create(RecordInputStream in) {
/*  83 */       Object[] args = { in };
/*     */       try {
/*  85 */         return (Record)this._m.invoke(null, args);
/*     */       } catch (IllegalArgumentException e) {
/*  87 */         throw new RuntimeException(e);
/*     */       } catch (IllegalAccessException e) {
/*  89 */         throw new RuntimeException(e);
/*     */       } catch (InvocationTargetException e) {
/*  91 */         throw new RecordFormatException("Unable to construct record instance", e.getTargetException());
/*     */       }
/*     */     }
/*     */     
/*     */     public Class<? extends Record> getRecordClass() {
/*  96 */       return this._m.getDeclaringClass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 101 */   private static final Class<?>[] CONSTRUCTOR_ARGS = { RecordInputStream.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private static final Class<? extends Record>[] recordClasses = { ArrayRecord.class, AutoFilterInfoRecord.class, BackupRecord.class, BlankRecord.class, BOFRecord.class, BookBoolRecord.class, BoolErrRecord.class, BottomMarginRecord.class, BoundSheetRecord.class, CalcCountRecord.class, CalcModeRecord.class, CFHeaderRecord.class, CFRuleRecord.class, ChartRecord.class, ChartTitleFormatRecord.class, CodepageRecord.class, ColumnInfoRecord.class, ContinueRecord.class, CountryRecord.class, CRNCountRecord.class, CRNRecord.class, DateWindow1904Record.class, DBCellRecord.class, DefaultColWidthRecord.class, DefaultRowHeightRecord.class, DeltaRecord.class, DimensionsRecord.class, DrawingGroupRecord.class, DrawingRecord.class, DrawingSelectionRecord.class, DSFRecord.class, DVALRecord.class, DVRecord.class, EOFRecord.class, ExtendedFormatRecord.class, ExternalNameRecord.class, ExternSheetRecord.class, ExtSSTRecord.class, FeatRecord.class, FeatHdrRecord.class, FilePassRecord.class, FileSharingRecord.class, FnGroupCountRecord.class, FontRecord.class, FooterRecord.class, FormatRecord.class, FormulaRecord.class, GridsetRecord.class, GutsRecord.class, HCenterRecord.class, HeaderRecord.class, HeaderFooterRecord.class, HideObjRecord.class, HorizontalPageBreakRecord.class, HyperlinkRecord.class, IndexRecord.class, InterfaceEndRecord.class, InterfaceHdrRecord.class, IterationRecord.class, LabelRecord.class, LabelSSTRecord.class, LeftMarginRecord.class, LegendRecord.class, MergeCellsRecord.class, MMSRecord.class, MulBlankRecord.class, MulRKRecord.class, NameRecord.class, NameCommentRecord.class, NoteRecord.class, NumberRecord.class, ObjectProtectRecord.class, ObjRecord.class, PaletteRecord.class, PaneRecord.class, PasswordRecord.class, PasswordRev4Record.class, PrecisionRecord.class, PrintGridlinesRecord.class, PrintHeadersRecord.class, PrintSetupRecord.class, ProtectionRev4Record.class, ProtectRecord.class, RecalcIdRecord.class, RefModeRecord.class, RefreshAllRecord.class, RightMarginRecord.class, RKRecord.class, RowRecord.class, SaveRecalcRecord.class, ScenarioProtectRecord.class, SelectionRecord.class, SeriesRecord.class, SeriesTextRecord.class, SharedFormulaRecord.class, SSTRecord.class, StringRecord.class, StyleRecord.class, SupBookRecord.class, TabIdRecord.class, TableRecord.class, TableStylesRecord.class, TextObjectRecord.class, TopMarginRecord.class, UncalcedRecord.class, UseSelFSRecord.class, UserSViewBegin.class, UserSViewEnd.class, org.apache.poi.hssf.record.chart.ValueRangeRecord.class, VCenterRecord.class, VerticalPageBreakRecord.class, WindowOneRecord.class, WindowProtectRecord.class, WindowTwoRecord.class, WriteAccessRecord.class, WriteProtectRecord.class, WSBoolRecord.class, BeginRecord.class, ChartFRTInfoRecord.class, org.apache.poi.hssf.record.chart.ChartStartBlockRecord.class, ChartEndBlockRecord.class, org.apache.poi.hssf.record.chart.ChartStartObjectRecord.class, ChartEndObjectRecord.class, org.apache.poi.hssf.record.chart.CatLabRecord.class, DataFormatRecord.class, org.apache.poi.hssf.record.chart.EndRecord.class, LinkedDataRecord.class, SeriesToChartGroupRecord.class, DataItemRecord.class, ExtendedPivotTableViewFieldsRecord.class, PageItemRecord.class, StreamIDRecord.class, org.apache.poi.hssf.record.pivottable.ViewDefinitionRecord.class, ViewFieldsRecord.class, ViewSourceRecord.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */   private static final Map<Integer, I_RecordCreator> _recordCreatorsById = recordsToMap(recordClasses);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static short[] _allKnownRecordSIDs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<? extends Record> getRecordClass(int sid)
/*     */   {
/* 267 */     I_RecordCreator rc = (I_RecordCreator)_recordCreatorsById.get(Integer.valueOf(sid));
/* 268 */     if (rc == null) {
/* 269 */       return null;
/*     */     }
/* 271 */     return rc.getRecordClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Record[] createRecord(RecordInputStream in)
/*     */   {
/* 279 */     Record record = createSingleRecord(in);
/* 280 */     if ((record instanceof DBCellRecord))
/*     */     {
/* 282 */       return new Record[] { null };
/*     */     }
/* 284 */     if ((record instanceof RKRecord)) {
/* 285 */       return new Record[] { convertToNumberRecord((RKRecord)record) };
/*     */     }
/* 287 */     if ((record instanceof MulRKRecord)) {
/* 288 */       return convertRKRecords((MulRKRecord)record);
/*     */     }
/* 290 */     return new Record[] { record };
/*     */   }
/*     */   
/*     */   public static Record createSingleRecord(RecordInputStream in) {
/* 294 */     I_RecordCreator constructor = (I_RecordCreator)_recordCreatorsById.get(Integer.valueOf(in.getSid()));
/*     */     
/* 296 */     if (constructor == null) {
/* 297 */       return new UnknownRecord(in);
/*     */     }
/*     */     
/* 300 */     return constructor.create(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NumberRecord convertToNumberRecord(RKRecord rk)
/*     */   {
/* 308 */     NumberRecord num = new NumberRecord();
/*     */     
/* 310 */     num.setColumn(rk.getColumn());
/* 311 */     num.setRow(rk.getRow());
/* 312 */     num.setXFIndex(rk.getXFIndex());
/* 313 */     num.setValue(rk.getRKNumber());
/* 314 */     return num;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static NumberRecord[] convertRKRecords(MulRKRecord mrk)
/*     */   {
/* 321 */     NumberRecord[] mulRecs = new NumberRecord[mrk.getNumColumns()];
/* 322 */     for (int k = 0; k < mrk.getNumColumns(); k++) {
/* 323 */       NumberRecord nr = new NumberRecord();
/*     */       
/* 325 */       nr.setColumn((short)(k + mrk.getFirstColumn()));
/* 326 */       nr.setRow(mrk.getRow());
/* 327 */       nr.setXFIndex(mrk.getXFAt(k));
/* 328 */       nr.setValue(mrk.getRKNumberAt(k));
/* 329 */       mulRecs[k] = nr;
/*     */     }
/* 331 */     return mulRecs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static BlankRecord[] convertBlankRecords(MulBlankRecord mbk)
/*     */   {
/* 338 */     BlankRecord[] mulRecs = new BlankRecord[mbk.getNumColumns()];
/* 339 */     for (int k = 0; k < mbk.getNumColumns(); k++) {
/* 340 */       BlankRecord br = new BlankRecord();
/*     */       
/* 342 */       br.setColumn((short)(k + mbk.getFirstColumn()));
/* 343 */       br.setRow(mbk.getRow());
/* 344 */       br.setXFIndex(mbk.getXFAt(k));
/* 345 */       mulRecs[k] = br;
/*     */     }
/* 347 */     return mulRecs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static short[] getAllKnownRecordSIDs()
/*     */   {
/* 354 */     if (_allKnownRecordSIDs == null) {
/* 355 */       short[] results = new short[_recordCreatorsById.size()];
/* 356 */       int i = 0;
/*     */       
/* 358 */       for (Iterator<Integer> iterator = _recordCreatorsById.keySet().iterator(); iterator.hasNext();) {
/* 359 */         Integer sid = (Integer)iterator.next();
/*     */         
/* 361 */         results[(i++)] = sid.shortValue();
/*     */       }
/* 363 */       Arrays.sort(results);
/* 364 */       _allKnownRecordSIDs = results;
/*     */     }
/*     */     
/* 367 */     return (short[])_allKnownRecordSIDs.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<Integer, I_RecordCreator> recordsToMap(Class<? extends Record>[] records)
/*     */   {
/* 376 */     Map<Integer, I_RecordCreator> result = new HashMap();
/* 377 */     Set<Class<?>> uniqueRecClasses = new java.util.HashSet(records.length * 3 / 2);
/*     */     
/* 379 */     for (int i = 0; i < records.length; i++)
/*     */     {
/* 381 */       Class<? extends Record> recClass = records[i];
/* 382 */       if (!Record.class.isAssignableFrom(recClass)) {
/* 383 */         throw new RuntimeException("Invalid record sub-class (" + recClass.getName() + ")");
/*     */       }
/* 385 */       if (Modifier.isAbstract(recClass.getModifiers())) {
/* 386 */         throw new RuntimeException("Invalid record class (" + recClass.getName() + ") - must not be abstract");
/*     */       }
/* 388 */       if (!uniqueRecClasses.add(recClass)) {
/* 389 */         throw new RuntimeException("duplicate record class (" + recClass.getName() + ")");
/*     */       }
/*     */       int sid;
/*     */       try
/*     */       {
/* 394 */         sid = recClass.getField("sid").getShort(null);
/*     */       } catch (Exception illegalArgumentException) {
/* 396 */         throw new RecordFormatException("Unable to determine record types");
/*     */       }
/*     */       
/* 399 */       Integer key = Integer.valueOf(sid);
/* 400 */       if (result.containsKey(key)) {
/* 401 */         Class<?> prevClass = ((I_RecordCreator)result.get(key)).getRecordClass();
/* 402 */         throw new RuntimeException("duplicate record sid 0x" + Integer.toHexString(sid).toUpperCase() + " for classes (" + recClass.getName() + ") and (" + prevClass.getName() + ")");
/*     */       }
/*     */       
/* 405 */       result.put(key, getRecordCreator(recClass));
/*     */     }
/*     */     
/* 408 */     return result;
/*     */   }
/*     */   
/*     */   private static I_RecordCreator getRecordCreator(Class<? extends Record> recClass)
/*     */   {
/*     */     try {
/* 414 */       Constructor<? extends Record> constructor = recClass.getConstructor(CONSTRUCTOR_ARGS);
/* 415 */       return new ReflectionConstructorRecordCreator(constructor);
/*     */     }
/*     */     catch (NoSuchMethodException e)
/*     */     {
/*     */       try {
/* 420 */         Method m = recClass.getDeclaredMethod("create", CONSTRUCTOR_ARGS);
/* 421 */         return new ReflectionMethodRecordCreator(m);
/*     */       } catch (NoSuchMethodException e) {
/* 423 */         throw new RuntimeException("Failed to find constructor or create method for (" + recClass.getName() + ").");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<Record> createRecords(InputStream in)
/*     */     throws RecordFormatException
/*     */   {
/* 437 */     List<Record> records = new ArrayList(512);
/*     */     
/* 439 */     RecordFactoryInputStream recStream = new RecordFactoryInputStream(in, true);
/*     */     
/*     */     Record record;
/* 442 */     while ((record = recStream.nextRecord()) != null) {
/* 443 */       records.add(record);
/*     */     }
/*     */     
/* 446 */     return records;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RecordFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */