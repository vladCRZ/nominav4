/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.EncryptedDocumentException;
/*     */ import org.apache.poi.hssf.record.crypto.Biff8EncryptionKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RecordFactoryInputStream
/*     */ {
/*     */   private final RecordInputStream _recStream;
/*     */   private final boolean _shouldIncludeContinueRecords;
/*     */   private Record[] _unreadRecordBuffer;
/*     */   
/*     */   private static final class StreamEncryptionInfo
/*     */   {
/*     */     private final int _initialRecordsSize;
/*     */     private final FilePassRecord _filePassRec;
/*     */     private final Record _lastRecord;
/*     */     private final boolean _hasBOFRecord;
/*     */     
/*     */     public StreamEncryptionInfo(RecordInputStream rs, List<Record> outputRecs)
/*     */     {
/*  53 */       rs.nextRecord();
/*  54 */       int recSize = 4 + rs.remaining();
/*  55 */       Record rec = RecordFactory.createSingleRecord(rs);
/*  56 */       outputRecs.add(rec);
/*  57 */       FilePassRecord fpr = null;
/*  58 */       if ((rec instanceof BOFRecord)) {
/*  59 */         this._hasBOFRecord = true;
/*  60 */         if (rs.hasNextRecord()) {
/*  61 */           rs.nextRecord();
/*  62 */           rec = RecordFactory.createSingleRecord(rs);
/*  63 */           recSize += rec.getRecordSize();
/*  64 */           outputRecs.add(rec);
/*  65 */           if ((rec instanceof FilePassRecord)) {
/*  66 */             fpr = (FilePassRecord)rec;
/*  67 */             outputRecs.remove(outputRecs.size() - 1);
/*     */             
/*  69 */             rec = (Record)outputRecs.get(0);
/*     */ 
/*     */           }
/*  72 */           else if ((rec instanceof EOFRecord))
/*     */           {
/*     */ 
/*  75 */             throw new IllegalStateException("Nothing between BOF and EOF");
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/*  83 */         this._hasBOFRecord = false;
/*     */       }
/*  85 */       this._initialRecordsSize = recSize;
/*  86 */       this._filePassRec = fpr;
/*  87 */       this._lastRecord = rec;
/*     */     }
/*     */     
/*     */     public RecordInputStream createDecryptingStream(InputStream original) {
/*  91 */       FilePassRecord fpr = this._filePassRec;
/*  92 */       String userPassword = Biff8EncryptionKey.getCurrentUserPassword();
/*     */       Biff8EncryptionKey key;
/*     */       Biff8EncryptionKey key;
/*  95 */       if (userPassword == null) {
/*  96 */         key = Biff8EncryptionKey.create(fpr.getDocId());
/*     */       } else {
/*  98 */         key = Biff8EncryptionKey.create(userPassword, fpr.getDocId());
/*     */       }
/* 100 */       if (!key.validate(fpr.getSaltData(), fpr.getSaltHash())) {
/* 101 */         throw new EncryptedDocumentException((userPassword == null ? "Default" : "Supplied") + " password is invalid for docId/saltData/saltHash");
/*     */       }
/*     */       
/*     */ 
/* 105 */       return new RecordInputStream(original, key, this._initialRecordsSize);
/*     */     }
/*     */     
/*     */     public boolean hasEncryption() {
/* 109 */       return this._filePassRec != null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Record getLastRecord()
/*     */     {
/* 118 */       return this._lastRecord;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean hasBOFRecord()
/*     */     {
/* 125 */       return this._hasBOFRecord;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   private int _unreadRecordIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 148 */   private Record _lastRecord = null;
/*     */   
/*     */ 
/*     */ 
/* 152 */   private DrawingRecord _lastDrawingRecord = new DrawingRecord();
/*     */   
/*     */ 
/*     */ 
/*     */   private int _bofDepth;
/*     */   
/*     */ 
/*     */   private boolean _lastRecordWasEOFLevelZero;
/*     */   
/*     */ 
/*     */ 
/*     */   public RecordFactoryInputStream(InputStream in, boolean shouldIncludeContinueRecords)
/*     */   {
/* 165 */     RecordInputStream rs = new RecordInputStream(in);
/* 166 */     List<Record> records = new ArrayList();
/* 167 */     StreamEncryptionInfo sei = new StreamEncryptionInfo(rs, records);
/* 168 */     if (sei.hasEncryption()) {
/* 169 */       rs = sei.createDecryptingStream(in);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 174 */     if (!records.isEmpty()) {
/* 175 */       this._unreadRecordBuffer = new Record[records.size()];
/* 176 */       records.toArray(this._unreadRecordBuffer);
/* 177 */       this._unreadRecordIndex = 0;
/*     */     }
/* 179 */     this._recStream = rs;
/* 180 */     this._shouldIncludeContinueRecords = shouldIncludeContinueRecords;
/* 181 */     this._lastRecord = sei.getLastRecord();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */     this._bofDepth = (sei.hasBOFRecord() ? 1 : 0);
/* 201 */     this._lastRecordWasEOFLevelZero = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Record nextRecord()
/*     */   {
/* 210 */     Record r = getNextUnreadRecord();
/* 211 */     if (r != null)
/*     */     {
/* 213 */       return r;
/*     */     }
/*     */     do {
/* 216 */       if (!this._recStream.hasNextRecord())
/*     */       {
/* 218 */         return null;
/*     */       }
/*     */       
/* 221 */       if (this._lastRecordWasEOFLevelZero)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */         if (this._recStream.getNextSid() != 2057) {
/* 228 */           return null;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 234 */       this._recStream.nextRecord();
/*     */       
/* 236 */       r = readNextRecord();
/* 237 */     } while (r == null);
/*     */     
/*     */ 
/*     */ 
/* 241 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Record getNextUnreadRecord()
/*     */   {
/* 250 */     if (this._unreadRecordBuffer != null) {
/* 251 */       int ix = this._unreadRecordIndex;
/* 252 */       if (ix < this._unreadRecordBuffer.length) {
/* 253 */         Record result = this._unreadRecordBuffer[ix];
/* 254 */         this._unreadRecordIndex = (ix + 1);
/* 255 */         return result;
/*     */       }
/* 257 */       this._unreadRecordIndex = -1;
/* 258 */       this._unreadRecordBuffer = null;
/*     */     }
/* 260 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Record readNextRecord()
/*     */   {
/* 270 */     Record record = RecordFactory.createSingleRecord(this._recStream);
/* 271 */     this._lastRecordWasEOFLevelZero = false;
/*     */     
/* 273 */     if ((record instanceof BOFRecord)) {
/* 274 */       this._bofDepth += 1;
/* 275 */       return record;
/*     */     }
/*     */     
/* 278 */     if ((record instanceof EOFRecord)) {
/* 279 */       this._bofDepth -= 1;
/* 280 */       if (this._bofDepth < 1) {
/* 281 */         this._lastRecordWasEOFLevelZero = true;
/*     */       }
/*     */       
/* 284 */       return record;
/*     */     }
/*     */     
/* 287 */     if ((record instanceof DBCellRecord))
/*     */     {
/* 289 */       return null;
/*     */     }
/*     */     
/* 292 */     if ((record instanceof RKRecord)) {
/* 293 */       return RecordFactory.convertToNumberRecord((RKRecord)record);
/*     */     }
/*     */     
/* 296 */     if ((record instanceof MulRKRecord)) {
/* 297 */       Record[] records = RecordFactory.convertRKRecords((MulRKRecord)record);
/*     */       
/* 299 */       this._unreadRecordBuffer = records;
/* 300 */       this._unreadRecordIndex = 1;
/* 301 */       return records[0];
/*     */     }
/*     */     
/* 304 */     if ((record.getSid() == 235) && ((this._lastRecord instanceof DrawingGroupRecord)))
/*     */     {
/* 306 */       DrawingGroupRecord lastDGRecord = (DrawingGroupRecord)this._lastRecord;
/* 307 */       lastDGRecord.join((AbstractEscherHolderRecord)record);
/* 308 */       return null;
/*     */     }
/* 310 */     if (record.getSid() == 60) {
/* 311 */       ContinueRecord contRec = (ContinueRecord)record;
/*     */       
/* 313 */       if (((this._lastRecord instanceof ObjRecord)) || ((this._lastRecord instanceof TextObjectRecord)))
/*     */       {
/*     */ 
/* 316 */         this._lastDrawingRecord.processContinueRecord(contRec.getData());
/*     */         
/*     */ 
/* 319 */         if (this._shouldIncludeContinueRecords) {
/* 320 */           return record;
/*     */         }
/* 322 */         return null;
/*     */       }
/* 324 */       if ((this._lastRecord instanceof DrawingGroupRecord)) {
/* 325 */         ((DrawingGroupRecord)this._lastRecord).processContinueRecord(contRec.getData());
/* 326 */         return null;
/*     */       }
/* 328 */       if ((this._lastRecord instanceof DrawingRecord)) {
/* 329 */         ((DrawingRecord)this._lastRecord).processContinueRecord(contRec.getData());
/* 330 */         return null;
/*     */       }
/* 332 */       if ((this._lastRecord instanceof UnknownRecord))
/*     */       {
/*     */ 
/* 335 */         return record;
/*     */       }
/* 337 */       if ((this._lastRecord instanceof EOFRecord))
/*     */       {
/*     */ 
/* 340 */         return record;
/*     */       }
/* 342 */       throw new RecordFormatException("Unhandled Continue Record followining " + this._lastRecord.getClass());
/*     */     }
/* 344 */     this._lastRecord = record;
/* 345 */     if ((record instanceof DrawingRecord)) {
/* 346 */       this._lastDrawingRecord = ((DrawingRecord)record);
/*     */     }
/* 348 */     return record;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RecordFactoryInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */