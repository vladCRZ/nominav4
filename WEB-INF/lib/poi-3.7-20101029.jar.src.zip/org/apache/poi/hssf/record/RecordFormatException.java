/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordFormatException
/*    */   extends org.apache.poi.util.RecordFormatException
/*    */ {
/*    */   public RecordFormatException(String exception)
/*    */   {
/* 32 */     super(exception);
/*    */   }
/*    */   
/*    */   public RecordFormatException(String exception, Throwable thr) {
/* 36 */     super(exception, thr);
/*    */   }
/*    */   
/*    */   public RecordFormatException(Throwable thr) {
/* 40 */     super(thr);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RecordFormatException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */