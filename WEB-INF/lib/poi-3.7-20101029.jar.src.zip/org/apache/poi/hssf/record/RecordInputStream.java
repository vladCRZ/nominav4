/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import org.apache.poi.hssf.record.crypto.Biff8DecryptingStream;
/*     */ import org.apache.poi.hssf.record.crypto.Biff8EncryptionKey;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RecordInputStream
/*     */   implements LittleEndianInput
/*     */ {
/*     */   public static final short MAX_RECORD_DATA_SIZE = 8224;
/*     */   private static final int INVALID_SID_VALUE = -1;
/*     */   private static final int DATA_LEN_NEEDS_TO_BE_READ = -1;
/*  45 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   private final BiffHeaderInput _bhi;
/*     */   private final LittleEndianInput _dataInput;
/*     */   private int _currentSid;
/*     */   private int _currentDataLength;
/*     */   private int _nextSid;
/*     */   private int _currentDataOffset;
/*     */   
/*     */   public static final class LeftoverDataException extends RuntimeException {
/*  54 */     public LeftoverDataException(int sid, int remainingByteCount) { super(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class SimpleHeaderInput
/*     */     implements BiffHeaderInput
/*     */   {
/*     */     private final LittleEndianInput _lei;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public SimpleHeaderInput(InputStream in)
/*     */     {
/*  89 */       this._lei = RecordInputStream.getLEI(in);
/*     */     }
/*     */     
/*  92 */     public int available() { return this._lei.available(); }
/*     */     
/*     */     public int readDataSize() {
/*  95 */       return this._lei.readUShort();
/*     */     }
/*     */     
/*  98 */     public int readRecordSID() { return this._lei.readUShort(); }
/*     */   }
/*     */   
/*     */   public RecordInputStream(InputStream in) throws RecordFormatException
/*     */   {
/* 103 */     this(in, null, 0);
/*     */   }
/*     */   
/*     */   public RecordInputStream(InputStream in, Biff8EncryptionKey key, int initialOffset) throws RecordFormatException {
/* 107 */     if (key == null) {
/* 108 */       this._dataInput = getLEI(in);
/* 109 */       this._bhi = new SimpleHeaderInput(in);
/*     */     } else {
/* 111 */       Biff8DecryptingStream bds = new Biff8DecryptingStream(in, initialOffset, key);
/* 112 */       this._bhi = bds;
/* 113 */       this._dataInput = bds;
/*     */     }
/* 115 */     this._nextSid = readNextSid();
/*     */   }
/*     */   
/*     */   static LittleEndianInput getLEI(InputStream is) {
/* 119 */     if ((is instanceof LittleEndianInput))
/*     */     {
/* 121 */       return (LittleEndianInput)is;
/*     */     }
/*     */     
/* 124 */     return new LittleEndianInputStream(is);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */   {
/* 132 */     return remaining();
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) {
/* 136 */     int limit = Math.min(len, remaining());
/* 137 */     if (limit == 0) {
/* 138 */       return 0;
/*     */     }
/* 140 */     readFully(b, off, limit);
/* 141 */     return limit;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 145 */     return (short)this._currentSid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasNextRecord()
/*     */     throws RecordInputStream.LeftoverDataException
/*     */   {
/* 155 */     if ((this._currentDataLength != -1) && (this._currentDataLength != this._currentDataOffset)) {
/* 156 */       throw new LeftoverDataException(this._currentSid, remaining());
/*     */     }
/* 158 */     if (this._currentDataLength != -1) {
/* 159 */       this._nextSid = readNextSid();
/*     */     }
/* 161 */     return this._nextSid != -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int readNextSid()
/*     */   {
/* 168 */     int nAvailable = this._bhi.available();
/* 169 */     if (nAvailable < 4) {
/* 170 */       if (nAvailable > 0) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 175 */       return -1;
/*     */     }
/* 177 */     int result = this._bhi.readRecordSID();
/* 178 */     if (result == -1) {
/* 179 */       throw new RecordFormatException("Found invalid sid (" + result + ")");
/*     */     }
/* 181 */     this._currentDataLength = -1;
/* 182 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void nextRecord()
/*     */     throws RecordFormatException
/*     */   {
/* 190 */     if (this._nextSid == -1) {
/* 191 */       throw new IllegalStateException("EOF - next record not available");
/*     */     }
/* 193 */     if (this._currentDataLength != -1) {
/* 194 */       throw new IllegalStateException("Cannot call nextRecord() without checking hasNextRecord() first");
/*     */     }
/* 196 */     this._currentSid = this._nextSid;
/* 197 */     this._currentDataOffset = 0;
/* 198 */     this._currentDataLength = this._bhi.readDataSize();
/* 199 */     if (this._currentDataLength > 8224) {
/* 200 */       throw new RecordFormatException("The content of an excel record cannot exceed 8224 bytes");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkRecordPosition(int requiredByteCount)
/*     */   {
/* 207 */     int nAvailable = remaining();
/* 208 */     if (nAvailable >= requiredByteCount)
/*     */     {
/* 210 */       return;
/*     */     }
/* 212 */     if ((nAvailable == 0) && (isContinueNext())) {
/* 213 */       nextRecord();
/* 214 */       return;
/*     */     }
/* 216 */     throw new RecordFormatException("Not enough data (" + nAvailable + ") to read requested (" + requiredByteCount + ") bytes");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte readByte()
/*     */   {
/* 224 */     checkRecordPosition(1);
/* 225 */     this._currentDataOffset += 1;
/* 226 */     return this._dataInput.readByte();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short readShort()
/*     */   {
/* 233 */     checkRecordPosition(2);
/* 234 */     this._currentDataOffset += 2;
/* 235 */     return this._dataInput.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int readInt()
/*     */   {
/* 242 */     checkRecordPosition(4);
/* 243 */     this._currentDataOffset += 4;
/* 244 */     return this._dataInput.readInt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long readLong()
/*     */   {
/* 251 */     checkRecordPosition(8);
/* 252 */     this._currentDataOffset += 8;
/* 253 */     return this._dataInput.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int readUByte()
/*     */   {
/* 260 */     return readByte() & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int readUShort()
/*     */   {
/* 267 */     checkRecordPosition(2);
/* 268 */     this._currentDataOffset += 2;
/* 269 */     return this._dataInput.readUShort();
/*     */   }
/*     */   
/*     */   public double readDouble() {
/* 273 */     long valueLongBits = readLong();
/* 274 */     double result = Double.longBitsToDouble(valueLongBits);
/* 275 */     if (Double.isNaN(result)) {
/* 276 */       throw new RuntimeException("Did not expect to read NaN");
/*     */     }
/* 278 */     return result;
/*     */   }
/*     */   
/* 281 */   public void readFully(byte[] buf) { readFully(buf, 0, buf.length); }
/*     */   
/*     */   public void readFully(byte[] buf, int off, int len)
/*     */   {
/* 285 */     checkRecordPosition(len);
/* 286 */     this._dataInput.readFully(buf, off, len);
/* 287 */     this._currentDataOffset += len;
/*     */   }
/*     */   
/*     */   public String readString() {
/* 291 */     int requestedLength = readUShort();
/* 292 */     byte compressFlag = readByte();
/* 293 */     return readStringCommon(requestedLength, compressFlag == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String readUnicodeLEString(int requestedLength)
/*     */   {
/* 308 */     return readStringCommon(requestedLength, false);
/*     */   }
/*     */   
/*     */   public String readCompressedUnicode(int requestedLength) {
/* 312 */     return readStringCommon(requestedLength, true);
/*     */   }
/*     */   
/*     */   private String readStringCommon(int requestedLength, boolean pIsCompressedEncoding)
/*     */   {
/* 317 */     if ((requestedLength < 0) || (requestedLength > 1048576)) {
/* 318 */       throw new IllegalArgumentException("Bad requested string length (" + requestedLength + ")");
/*     */     }
/* 320 */     char[] buf = new char[requestedLength];
/* 321 */     boolean isCompressedEncoding = pIsCompressedEncoding;
/* 322 */     int curLen = 0;
/*     */     for (;;) {
/* 324 */       int availableChars = isCompressedEncoding ? remaining() : remaining() / 2;
/* 325 */       if (requestedLength - curLen <= availableChars)
/*     */       {
/* 327 */         while (curLen < requestedLength) { char ch;
/*     */           char ch;
/* 329 */           if (isCompressedEncoding) {
/* 330 */             ch = (char)readUByte();
/*     */           } else {
/* 332 */             ch = (char)readShort();
/*     */           }
/* 334 */           buf[curLen] = ch;
/* 335 */           curLen++;
/*     */         }
/* 337 */         return new String(buf);
/*     */       }
/*     */       
/*     */ 
/* 341 */       while (availableChars > 0) { char ch;
/*     */         char ch;
/* 343 */         if (isCompressedEncoding) {
/* 344 */           ch = (char)readUByte();
/*     */         } else {
/* 346 */           ch = (char)readShort();
/*     */         }
/* 348 */         buf[curLen] = ch;
/* 349 */         curLen++;
/* 350 */         availableChars--;
/*     */       }
/* 352 */       if (!isContinueNext()) {
/* 353 */         throw new RecordFormatException("Expected to find a ContinueRecord in order to read remaining " + (requestedLength - curLen) + " of " + requestedLength + " chars");
/*     */       }
/*     */       
/* 356 */       if (remaining() != 0) {
/* 357 */         throw new RecordFormatException("Odd number of bytes(" + remaining() + ") left behind");
/*     */       }
/* 359 */       nextRecord();
/*     */       
/* 361 */       byte compressFlag = readByte();
/* 362 */       isCompressedEncoding = compressFlag == 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] readRemainder()
/*     */   {
/* 371 */     int size = remaining();
/* 372 */     if (size == 0) {
/* 373 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 375 */     byte[] result = new byte[size];
/* 376 */     readFully(result);
/* 377 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public byte[] readAllContinuedRemainder()
/*     */   {
/* 389 */     ByteArrayOutputStream out = new ByteArrayOutputStream(16448);
/*     */     for (;;)
/*     */     {
/* 392 */       byte[] b = readRemainder();
/* 393 */       out.write(b, 0, b.length);
/* 394 */       if (!isContinueNext()) {
/*     */         break;
/*     */       }
/* 397 */       nextRecord();
/*     */     }
/* 399 */     return out.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int remaining()
/*     */   {
/* 407 */     if (this._currentDataLength == -1)
/*     */     {
/* 409 */       return 0;
/*     */     }
/* 411 */     return this._currentDataLength - this._currentDataOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isContinueNext()
/*     */   {
/* 419 */     if ((this._currentDataLength != -1) && (this._currentDataOffset != this._currentDataLength)) {
/* 420 */       throw new IllegalStateException("Should never be called before end of current record");
/*     */     }
/* 422 */     if (!hasNextRecord()) {
/* 423 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 430 */     return this._nextSid == 60;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNextSid()
/*     */   {
/* 437 */     return this._nextSid;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RecordInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */