/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RightMarginRecord
/*    */   extends StandardRecord
/*    */   implements Margin
/*    */ {
/*    */   public static final short sid = 39;
/*    */   private double field_1_margin;
/*    */   
/*    */   public RightMarginRecord() {}
/*    */   
/*    */   public RightMarginRecord(RecordInputStream in)
/*    */   {
/* 35 */     this.field_1_margin = in.readDouble();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 40 */     StringBuffer buffer = new StringBuffer();
/* 41 */     buffer.append("[RightMargin]\n");
/* 42 */     buffer.append("    .margin               = ").append(" (").append(getMargin()).append(" )\n");
/* 43 */     buffer.append("[/RightMargin]\n");
/* 44 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 48 */     out.writeDouble(this.field_1_margin);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 52 */     return 8;
/*    */   }
/*    */   
/* 55 */   public short getSid() { return 39; }
/*    */   
/*    */ 
/*    */   public double getMargin()
/*    */   {
/* 60 */     return this.field_1_margin;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setMargin(double field_1_margin)
/*    */   {
/* 66 */     this.field_1_margin = field_1_margin;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 70 */     RightMarginRecord rec = new RightMarginRecord();
/* 71 */     rec.field_1_margin = this.field_1_margin;
/* 72 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RightMarginRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */