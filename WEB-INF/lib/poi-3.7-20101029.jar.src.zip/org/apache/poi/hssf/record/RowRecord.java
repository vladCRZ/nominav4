/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RowRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 520;
/*     */   public static final int ENCODED_SIZE = 20;
/*     */   private static final int OPTION_BITS_ALWAYS_SET = 256;
/*     */   private static final int DEFAULT_HEIGHT_BIT = 32768;
/*     */   private int field_1_row_number;
/*     */   private int field_2_first_col;
/*     */   private int field_3_last_col;
/*     */   private short field_4_height;
/*     */   private short field_5_optimize;
/*     */   private short field_6_reserved;
/*     */   private int field_7_option_flags;
/*  51 */   private static final BitField outlineLevel = BitFieldFactory.getInstance(7);
/*     */   
/*     */ 
/*  54 */   private static final BitField colapsed = BitFieldFactory.getInstance(16);
/*  55 */   private static final BitField zeroHeight = BitFieldFactory.getInstance(32);
/*  56 */   private static final BitField badFontHeight = BitFieldFactory.getInstance(64);
/*  57 */   private static final BitField formatted = BitFieldFactory.getInstance(128);
/*     */   private short field_8_xf_index;
/*     */   
/*     */   public RowRecord(int rowNumber) {
/*  61 */     this.field_1_row_number = rowNumber;
/*  62 */     this.field_4_height = 255;
/*  63 */     this.field_5_optimize = 0;
/*  64 */     this.field_6_reserved = 0;
/*  65 */     this.field_7_option_flags = 256;
/*     */     
/*  67 */     this.field_8_xf_index = 15;
/*  68 */     setEmpty();
/*     */   }
/*     */   
/*     */   public RowRecord(RecordInputStream in) {
/*  72 */     this.field_1_row_number = in.readUShort();
/*  73 */     this.field_2_first_col = in.readShort();
/*  74 */     this.field_3_last_col = in.readShort();
/*  75 */     this.field_4_height = in.readShort();
/*  76 */     this.field_5_optimize = in.readShort();
/*  77 */     this.field_6_reserved = in.readShort();
/*  78 */     this.field_7_option_flags = in.readShort();
/*  79 */     this.field_8_xf_index = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEmpty()
/*     */   {
/*  87 */     this.field_2_first_col = 0;
/*  88 */     this.field_3_last_col = 0;
/*     */   }
/*     */   
/*  91 */   public boolean isEmpty() { return (this.field_2_first_col | this.field_3_last_col) == 0; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRowNumber(int row)
/*     */   {
/*  99 */     this.field_1_row_number = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFirstCol(int col)
/*     */   {
/* 107 */     this.field_2_first_col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLastCol(int col)
/*     */   {
/* 114 */     this.field_3_last_col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(short height)
/*     */   {
/* 122 */     this.field_4_height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptimize(short optimize)
/*     */   {
/* 130 */     this.field_5_optimize = optimize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutlineLevel(short ol)
/*     */   {
/* 140 */     this.field_7_option_flags = outlineLevel.setValue(this.field_7_option_flags, ol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColapsed(boolean c)
/*     */   {
/* 148 */     this.field_7_option_flags = colapsed.setBoolean(this.field_7_option_flags, c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setZeroHeight(boolean z)
/*     */   {
/* 156 */     this.field_7_option_flags = zeroHeight.setBoolean(this.field_7_option_flags, z);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBadFontHeight(boolean f)
/*     */   {
/* 164 */     this.field_7_option_flags = badFontHeight.setBoolean(this.field_7_option_flags, f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatted(boolean f)
/*     */   {
/* 172 */     this.field_7_option_flags = formatted.setBoolean(this.field_7_option_flags, f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXFIndex(short index)
/*     */   {
/* 183 */     this.field_8_xf_index = index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowNumber()
/*     */   {
/* 191 */     return this.field_1_row_number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFirstCol()
/*     */   {
/* 199 */     return this.field_2_first_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLastCol()
/*     */   {
/* 207 */     return this.field_3_last_col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getHeight()
/*     */   {
/* 215 */     return this.field_4_height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptimize()
/*     */   {
/* 223 */     return this.field_5_optimize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptionFlags()
/*     */   {
/* 232 */     return (short)this.field_7_option_flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOutlineLevel()
/*     */   {
/* 243 */     return (short)outlineLevel.getValue(this.field_7_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getColapsed()
/*     */   {
/* 252 */     return colapsed.isSet(this.field_7_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getZeroHeight()
/*     */   {
/* 261 */     return zeroHeight.isSet(this.field_7_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getBadFontHeight()
/*     */   {
/* 270 */     return badFontHeight.isSet(this.field_7_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFormatted()
/*     */   {
/* 279 */     return formatted.isSet(this.field_7_option_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getXFIndex()
/*     */   {
/* 290 */     return this.field_8_xf_index;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 294 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 296 */     sb.append("[ROW]\n");
/* 297 */     sb.append("    .rownumber      = ").append(Integer.toHexString(getRowNumber())).append("\n");
/*     */     
/* 299 */     sb.append("    .firstcol       = ").append(HexDump.shortToHex(getFirstCol())).append("\n");
/* 300 */     sb.append("    .lastcol        = ").append(HexDump.shortToHex(getLastCol())).append("\n");
/* 301 */     sb.append("    .height         = ").append(HexDump.shortToHex(getHeight())).append("\n");
/* 302 */     sb.append("    .optimize       = ").append(HexDump.shortToHex(getOptimize())).append("\n");
/* 303 */     sb.append("    .reserved       = ").append(HexDump.shortToHex(this.field_6_reserved)).append("\n");
/* 304 */     sb.append("    .optionflags    = ").append(HexDump.shortToHex(getOptionFlags())).append("\n");
/* 305 */     sb.append("        .outlinelvl = ").append(Integer.toHexString(getOutlineLevel())).append("\n");
/* 306 */     sb.append("        .colapsed   = ").append(getColapsed()).append("\n");
/* 307 */     sb.append("        .zeroheight = ").append(getZeroHeight()).append("\n");
/* 308 */     sb.append("        .badfontheig= ").append(getBadFontHeight()).append("\n");
/* 309 */     sb.append("        .formatted  = ").append(getFormatted()).append("\n");
/* 310 */     sb.append("    .xfindex        = ").append(Integer.toHexString(getXFIndex())).append("\n");
/* 311 */     sb.append("[/ROW]\n");
/* 312 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 316 */     out.writeShort(getRowNumber());
/* 317 */     out.writeShort(getFirstCol() == -1 ? 0 : getFirstCol());
/* 318 */     out.writeShort(getLastCol() == -1 ? 0 : getLastCol());
/* 319 */     out.writeShort(getHeight());
/* 320 */     out.writeShort(getOptimize());
/* 321 */     out.writeShort(this.field_6_reserved);
/* 322 */     out.writeShort(getOptionFlags());
/* 323 */     out.writeShort(getXFIndex());
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 327 */     return 16;
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 331 */     return 520;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 335 */     RowRecord rec = new RowRecord(this.field_1_row_number);
/* 336 */     rec.field_2_first_col = this.field_2_first_col;
/* 337 */     rec.field_3_last_col = this.field_3_last_col;
/* 338 */     rec.field_4_height = this.field_4_height;
/* 339 */     rec.field_5_optimize = this.field_5_optimize;
/* 340 */     rec.field_6_reserved = this.field_6_reserved;
/* 341 */     rec.field_7_option_flags = this.field_7_option_flags;
/* 342 */     rec.field_8_xf_index = this.field_8_xf_index;
/* 343 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\RowRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */