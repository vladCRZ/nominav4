/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SCLRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 160;
/*     */   private short field_1_numerator;
/*     */   private short field_2_denominator;
/*     */   
/*     */   public SCLRecord() {}
/*     */   
/*     */   public SCLRecord(RecordInputStream in)
/*     */   {
/*  42 */     this.field_1_numerator = in.readShort();
/*  43 */     this.field_2_denominator = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  48 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  50 */     buffer.append("[SCL]\n");
/*  51 */     buffer.append("    .numerator            = ").append("0x").append(HexDump.toHex(getNumerator())).append(" (").append(getNumerator()).append(" )");
/*     */     
/*     */ 
/*  54 */     buffer.append(System.getProperty("line.separator"));
/*  55 */     buffer.append("    .denominator          = ").append("0x").append(HexDump.toHex(getDenominator())).append(" (").append(getDenominator()).append(" )");
/*     */     
/*     */ 
/*  58 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  60 */     buffer.append("[/SCL]\n");
/*  61 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  65 */     out.writeShort(this.field_1_numerator);
/*  66 */     out.writeShort(this.field_2_denominator);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  70 */     return 4;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  75 */     return 160;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  79 */     SCLRecord rec = new SCLRecord();
/*     */     
/*  81 */     rec.field_1_numerator = this.field_1_numerator;
/*  82 */     rec.field_2_denominator = this.field_2_denominator;
/*  83 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getNumerator()
/*     */   {
/*  94 */     return this.field_1_numerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumerator(short field_1_numerator)
/*     */   {
/* 102 */     this.field_1_numerator = field_1_numerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getDenominator()
/*     */   {
/* 110 */     return this.field_2_denominator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDenominator(short field_2_denominator)
/*     */   {
/* 118 */     this.field_2_denominator = field_2_denominator;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SCLRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */