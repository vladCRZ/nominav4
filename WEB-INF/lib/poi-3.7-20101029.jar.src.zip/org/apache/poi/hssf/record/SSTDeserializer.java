/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.apache.poi.hssf.record.common.UnicodeString;
/*    */ import org.apache.poi.util.IntMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SSTDeserializer
/*    */ {
/*    */   private IntMapper<UnicodeString> strings;
/*    */   
/*    */   public SSTDeserializer(IntMapper<UnicodeString> strings)
/*    */   {
/* 38 */     this.strings = strings;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void manufactureStrings(int stringCount, RecordInputStream in)
/*    */   {
/* 48 */     for (int i = 0; i < stringCount; i++) {
/*    */       UnicodeString str;
/*    */       UnicodeString str;
/* 51 */       if ((in.available() == 0) && (!in.hasNextRecord())) {
/* 52 */         System.err.println("Ran out of data before creating all the strings! String at index " + i + "");
/* 53 */         str = new UnicodeString("");
/*    */       } else {
/* 55 */         str = new UnicodeString(in);
/*    */       }
/* 57 */       addToStringTable(this.strings, str);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void addToStringTable(IntMapper<UnicodeString> strings, UnicodeString string)
/*    */   {
/* 63 */     strings.add(string);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SSTDeserializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */