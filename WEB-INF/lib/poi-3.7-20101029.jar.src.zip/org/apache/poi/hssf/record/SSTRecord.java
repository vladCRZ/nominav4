/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.apache.poi.hssf.record.common.UnicodeString;
/*     */ import org.apache.poi.hssf.record.cont.ContinuableRecord;
/*     */ import org.apache.poi.hssf.record.cont.ContinuableRecordOutput;
/*     */ import org.apache.poi.util.IntMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SSTRecord
/*     */   extends ContinuableRecord
/*     */ {
/*     */   public static final short sid = 252;
/*  46 */   private static final UnicodeString EMPTY_STRING = new UnicodeString("");
/*     */   
/*     */ 
/*     */   static final int STD_RECORD_OVERHEAD = 4;
/*     */   
/*     */ 
/*     */   static final int SST_RECORD_OVERHEAD = 12;
/*     */   
/*     */ 
/*     */   static final int MAX_DATA_SPACE = 8216;
/*     */   
/*     */ 
/*     */   private int field_1_num_strings;
/*     */   
/*     */ 
/*     */   private int field_2_num_unique_strings;
/*     */   
/*     */   private IntMapper<UnicodeString> field_3_strings;
/*     */   
/*     */   private SSTDeserializer deserializer;
/*     */   
/*     */   int[] bucketAbsoluteOffsets;
/*     */   
/*     */   int[] bucketRelativeOffsets;
/*     */   
/*     */ 
/*     */   public SSTRecord()
/*     */   {
/*  74 */     this.field_1_num_strings = 0;
/*  75 */     this.field_2_num_unique_strings = 0;
/*  76 */     this.field_3_strings = new IntMapper();
/*  77 */     this.deserializer = new SSTDeserializer(this.field_3_strings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int addString(UnicodeString string)
/*     */   {
/*  89 */     this.field_1_num_strings += 1;
/*  90 */     UnicodeString ucs = string == null ? EMPTY_STRING : string;
/*     */     
/*     */ 
/*  93 */     int index = this.field_3_strings.getIndex(ucs);
/*     */     int rval;
/*  95 */     int rval; if (index != -1) {
/*  96 */       rval = index;
/*     */     }
/*     */     else
/*     */     {
/* 100 */       rval = this.field_3_strings.size();
/* 101 */       this.field_2_num_unique_strings += 1;
/* 102 */       SSTDeserializer.addToStringTable(this.field_3_strings, ucs);
/*     */     }
/* 104 */     return rval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumStrings()
/*     */   {
/* 112 */     return this.field_1_num_strings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumUniqueStrings()
/*     */   {
/* 120 */     return this.field_2_num_unique_strings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnicodeString getString(int id)
/*     */   {
/* 133 */     return (UnicodeString)this.field_3_strings.get(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 143 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 145 */     buffer.append("[SST]\n");
/* 146 */     buffer.append("    .numstrings     = ").append(Integer.toHexString(getNumStrings())).append("\n");
/*     */     
/* 148 */     buffer.append("    .uniquestrings  = ").append(Integer.toHexString(getNumUniqueStrings())).append("\n");
/*     */     
/* 150 */     for (int k = 0; k < this.field_3_strings.size(); k++)
/*     */     {
/* 152 */       UnicodeString s = (UnicodeString)this.field_3_strings.get(k);
/* 153 */       buffer.append("    .string_" + k + "      = ").append(s.getDebugInfo()).append("\n");
/*     */     }
/*     */     
/* 156 */     buffer.append("[/SST]\n");
/* 157 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 161 */     return 252;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SSTRecord(RecordInputStream in)
/*     */   {
/* 246 */     this.field_1_num_strings = in.readInt();
/* 247 */     this.field_2_num_unique_strings = in.readInt();
/* 248 */     this.field_3_strings = new IntMapper();
/* 249 */     this.deserializer = new SSTDeserializer(this.field_3_strings);
/* 250 */     this.deserializer.manufactureStrings(this.field_2_num_unique_strings, in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Iterator<UnicodeString> getStrings()
/*     */   {
/* 260 */     return this.field_3_strings.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int countStrings()
/*     */   {
/* 267 */     return this.field_3_strings.size();
/*     */   }
/*     */   
/*     */   protected void serialize(ContinuableRecordOutput out) {
/* 271 */     SSTSerializer serializer = new SSTSerializer(this.field_3_strings, getNumStrings(), getNumUniqueStrings());
/* 272 */     serializer.serialize(out);
/* 273 */     this.bucketAbsoluteOffsets = serializer.getBucketAbsoluteOffsets();
/* 274 */     this.bucketRelativeOffsets = serializer.getBucketRelativeOffsets();
/*     */   }
/*     */   
/*     */   SSTDeserializer getDeserializer() {
/* 278 */     return this.deserializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtSSTRecord createExtSSTRecord(int sstOffset)
/*     */   {
/* 295 */     if ((this.bucketAbsoluteOffsets == null) || (this.bucketAbsoluteOffsets == null)) {
/* 296 */       throw new IllegalStateException("SST record has not yet been serialized.");
/*     */     }
/* 298 */     ExtSSTRecord extSST = new ExtSSTRecord();
/* 299 */     extSST.setNumStringsPerBucket((short)8);
/* 300 */     int[] absoluteOffsets = (int[])this.bucketAbsoluteOffsets.clone();
/* 301 */     int[] relativeOffsets = (int[])this.bucketRelativeOffsets.clone();
/* 302 */     for (int i = 0; i < absoluteOffsets.length; i++)
/* 303 */       absoluteOffsets[i] += sstOffset;
/* 304 */     extSST.setBucketOffsets(absoluteOffsets, relativeOffsets);
/* 305 */     return extSST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int calcExtSSTRecordSize()
/*     */   {
/* 315 */     return ExtSSTRecord.getRecordSizeForStrings(this.field_3_strings.size());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SSTRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */