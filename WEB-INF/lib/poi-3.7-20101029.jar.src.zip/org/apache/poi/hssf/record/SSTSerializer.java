/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.hssf.record.common.UnicodeString;
/*    */ import org.apache.poi.hssf.record.cont.ContinuableRecordOutput;
/*    */ import org.apache.poi.util.IntMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SSTSerializer
/*    */ {
/*    */   private final int _numStrings;
/*    */   private final int _numUniqueStrings;
/*    */   private final IntMapper<UnicodeString> strings;
/*    */   private final int[] bucketAbsoluteOffsets;
/*    */   private final int[] bucketRelativeOffsets;
/*    */   int startOfSST;
/*    */   int startOfRecord;
/*    */   
/*    */   public SSTSerializer(IntMapper<UnicodeString> strings, int numStrings, int numUniqueStrings)
/*    */   {
/* 45 */     this.strings = strings;
/* 46 */     this._numStrings = numStrings;
/* 47 */     this._numUniqueStrings = numUniqueStrings;
/*    */     
/* 49 */     int infoRecs = ExtSSTRecord.getNumberOfInfoRecsForStrings(strings.size());
/* 50 */     this.bucketAbsoluteOffsets = new int[infoRecs];
/* 51 */     this.bucketRelativeOffsets = new int[infoRecs];
/*    */   }
/*    */   
/*    */   public void serialize(ContinuableRecordOutput out) {
/* 55 */     out.writeInt(this._numStrings);
/* 56 */     out.writeInt(this._numUniqueStrings);
/*    */     
/* 58 */     for (int k = 0; k < this.strings.size(); k++)
/*    */     {
/* 60 */       if (k % 8 == 0)
/*    */       {
/* 62 */         int rOff = out.getTotalSize();
/* 63 */         int index = k / 8;
/* 64 */         if (index < 128)
/*    */         {
/* 66 */           this.bucketAbsoluteOffsets[index] = rOff;
/* 67 */           this.bucketRelativeOffsets[index] = rOff;
/*    */         }
/*    */       }
/* 70 */       UnicodeString s = getUnicodeString(k);
/* 71 */       s.serialize(out);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private UnicodeString getUnicodeString(int index)
/*    */   {
/* 78 */     return getUnicodeString(this.strings, index);
/*    */   }
/*    */   
/*    */   private static UnicodeString getUnicodeString(IntMapper<UnicodeString> strings, int index)
/*    */   {
/* 83 */     return (UnicodeString)strings.get(index);
/*    */   }
/*    */   
/*    */   public int[] getBucketAbsoluteOffsets()
/*    */   {
/* 88 */     return this.bucketAbsoluteOffsets;
/*    */   }
/*    */   
/*    */   public int[] getBucketRelativeOffsets()
/*    */   {
/* 93 */     return this.bucketRelativeOffsets;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SSTSerializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */