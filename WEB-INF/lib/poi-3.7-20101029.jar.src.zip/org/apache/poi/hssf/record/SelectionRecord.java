/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SelectionRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 29;
/*     */   private byte field_1_pane;
/*     */   private int field_2_row_active_cell;
/*     */   private int field_3_col_active_cell;
/*     */   private int field_4_active_cell_ref_index;
/*     */   private CellRangeAddress8Bit[] field_6_refs;
/*     */   
/*     */   public SelectionRecord(int activeCellRow, int activeCellCol)
/*     */   {
/*  46 */     this.field_1_pane = 3;
/*  47 */     this.field_2_row_active_cell = activeCellRow;
/*  48 */     this.field_3_col_active_cell = activeCellCol;
/*  49 */     this.field_4_active_cell_ref_index = 0;
/*  50 */     this.field_6_refs = new CellRangeAddress8Bit[] { new CellRangeAddress8Bit(activeCellRow, activeCellRow, activeCellCol, activeCellCol) };
/*     */   }
/*     */   
/*     */ 
/*     */   public SelectionRecord(RecordInputStream in)
/*     */   {
/*  56 */     this.field_1_pane = in.readByte();
/*  57 */     this.field_2_row_active_cell = in.readUShort();
/*  58 */     this.field_3_col_active_cell = in.readShort();
/*  59 */     this.field_4_active_cell_ref_index = in.readShort();
/*  60 */     int field_5_num_refs = in.readUShort();
/*     */     
/*  62 */     this.field_6_refs = new CellRangeAddress8Bit[field_5_num_refs];
/*  63 */     for (int i = 0; i < this.field_6_refs.length; i++) {
/*  64 */       this.field_6_refs[i] = new CellRangeAddress8Bit(in);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPane(byte pane)
/*     */   {
/*  72 */     this.field_1_pane = pane;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActiveCellRow(int row)
/*     */   {
/*  80 */     this.field_2_row_active_cell = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActiveCellCol(short col)
/*     */   {
/*  88 */     this.field_3_col_active_cell = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActiveCellRef(short ref)
/*     */   {
/*  96 */     this.field_4_active_cell_ref_index = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte getPane()
/*     */   {
/* 103 */     return this.field_1_pane;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getActiveCellRow()
/*     */   {
/* 111 */     return this.field_2_row_active_cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getActiveCellCol()
/*     */   {
/* 119 */     return this.field_3_col_active_cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getActiveCellRef()
/*     */   {
/* 127 */     return this.field_4_active_cell_ref_index;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 131 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 133 */     sb.append("[SELECTION]\n");
/* 134 */     sb.append("    .pane            = ").append(HexDump.byteToHex(getPane())).append("\n");
/* 135 */     sb.append("    .activecellrow   = ").append(HexDump.shortToHex(getActiveCellRow())).append("\n");
/* 136 */     sb.append("    .activecellcol   = ").append(HexDump.shortToHex(getActiveCellCol())).append("\n");
/* 137 */     sb.append("    .activecellref   = ").append(HexDump.shortToHex(getActiveCellRef())).append("\n");
/* 138 */     sb.append("    .numrefs         = ").append(HexDump.shortToHex(this.field_6_refs.length)).append("\n");
/* 139 */     sb.append("[/SELECTION]\n");
/* 140 */     return sb.toString();
/*     */   }
/*     */   
/* 143 */   protected int getDataSize() { return 9 + CellRangeAddress8Bit.getEncodedSize(this.field_6_refs.length); }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 147 */     out.writeByte(getPane());
/* 148 */     out.writeShort(getActiveCellRow());
/* 149 */     out.writeShort(getActiveCellCol());
/* 150 */     out.writeShort(getActiveCellRef());
/* 151 */     int nRefs = this.field_6_refs.length;
/* 152 */     out.writeShort(nRefs);
/* 153 */     for (int i = 0; i < this.field_6_refs.length; i++) {
/* 154 */       this.field_6_refs[i].serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 159 */     return 29;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 163 */     SelectionRecord rec = new SelectionRecord(this.field_2_row_active_cell, this.field_3_col_active_cell);
/* 164 */     rec.field_1_pane = this.field_1_pane;
/* 165 */     rec.field_4_active_cell_ref_index = this.field_4_active_cell_ref_index;
/* 166 */     rec.field_6_refs = this.field_6_refs;
/* 167 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SelectionRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */