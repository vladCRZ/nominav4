/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.AreaPtg;
/*     */ import org.apache.poi.hssf.record.formula.AreaPtgBase;
/*     */ import org.apache.poi.hssf.record.formula.OperandPtg;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.record.formula.RefPtg;
/*     */ import org.apache.poi.hssf.record.formula.RefPtgBase;
/*     */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SharedFormulaRecord
/*     */   extends SharedValueRecordBase
/*     */ {
/*     */   public static final short sid = 1212;
/*     */   private int field_5_reserved;
/*     */   private Formula field_7_parsed_expr;
/*     */   
/*  45 */   public SharedFormulaRecord() { this(new CellRangeAddress8Bit(0, 0, 0, 0)); }
/*     */   
/*     */   private SharedFormulaRecord(CellRangeAddress8Bit range) {
/*  48 */     super(range);
/*  49 */     this.field_7_parsed_expr = Formula.create(Ptg.EMPTY_PTG_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SharedFormulaRecord(RecordInputStream in)
/*     */   {
/*  56 */     super(in);
/*  57 */     this.field_5_reserved = in.readShort();
/*  58 */     int field_6_expression_len = in.readShort();
/*  59 */     int nAvailableBytes = in.available();
/*  60 */     this.field_7_parsed_expr = Formula.read(field_6_expression_len, in, nAvailableBytes);
/*     */   }
/*     */   
/*     */   protected void serializeExtraData(LittleEndianOutput out) {
/*  64 */     out.writeShort(this.field_5_reserved);
/*  65 */     this.field_7_parsed_expr.serialize(out);
/*     */   }
/*     */   
/*     */   protected int getExtraDataSize() {
/*  69 */     return 2 + this.field_7_parsed_expr.getEncodedSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  78 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  80 */     buffer.append("[SHARED FORMULA (").append(HexDump.intToHex(1212)).append("]\n");
/*  81 */     buffer.append("    .range      = ").append(getRange().toString()).append("\n");
/*  82 */     buffer.append("    .reserved    = ").append(HexDump.shortToHex(this.field_5_reserved)).append("\n");
/*     */     
/*  84 */     Ptg[] ptgs = this.field_7_parsed_expr.getTokens();
/*  85 */     for (int k = 0; k < ptgs.length; k++) {
/*  86 */       buffer.append("Formula[").append(k).append("]");
/*  87 */       Ptg ptg = ptgs[k];
/*  88 */       buffer.append(ptg.toString()).append(ptg.getRVAType()).append("\n");
/*     */     }
/*     */     
/*  91 */     buffer.append("[/SHARED FORMULA]\n");
/*  92 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  96 */     return 1212;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Ptg[] convertSharedFormulas(Ptg[] ptgs, int formulaRow, int formulaColumn)
/*     */   {
/* 107 */     Ptg[] newPtgStack = new Ptg[ptgs.length];
/*     */     
/* 109 */     for (int k = 0; k < ptgs.length; k++) {
/* 110 */       Ptg ptg = ptgs[k];
/* 111 */       byte originalOperandClass = -1;
/* 112 */       if (!ptg.isBaseToken()) {
/* 113 */         originalOperandClass = ptg.getPtgClass();
/*     */       }
/* 115 */       if ((ptg instanceof RefPtgBase)) {
/* 116 */         RefPtgBase refNPtg = (RefPtgBase)ptg;
/* 117 */         ptg = new RefPtg(fixupRelativeRow(formulaRow, refNPtg.getRow(), refNPtg.isRowRelative()), fixupRelativeColumn(formulaColumn, refNPtg.getColumn(), refNPtg.isColRelative()), refNPtg.isRowRelative(), refNPtg.isColRelative());
/*     */         
/*     */ 
/*     */ 
/* 121 */         ptg.setClass(originalOperandClass);
/* 122 */       } else if ((ptg instanceof AreaPtgBase)) {
/* 123 */         AreaPtgBase areaNPtg = (AreaPtgBase)ptg;
/* 124 */         ptg = new AreaPtg(fixupRelativeRow(formulaRow, areaNPtg.getFirstRow(), areaNPtg.isFirstRowRelative()), fixupRelativeRow(formulaRow, areaNPtg.getLastRow(), areaNPtg.isLastRowRelative()), fixupRelativeColumn(formulaColumn, areaNPtg.getFirstColumn(), areaNPtg.isFirstColRelative()), fixupRelativeColumn(formulaColumn, areaNPtg.getLastColumn(), areaNPtg.isLastColRelative()), areaNPtg.isFirstRowRelative(), areaNPtg.isLastRowRelative(), areaNPtg.isFirstColRelative(), areaNPtg.isLastColRelative());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */         ptg.setClass(originalOperandClass);
/* 133 */       } else if ((ptg instanceof OperandPtg))
/*     */       {
/* 135 */         ptg = ((OperandPtg)ptg).copy();
/*     */       }
/*     */       
/*     */ 
/* 139 */       newPtgStack[k] = ptg;
/*     */     }
/* 141 */     return newPtgStack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Ptg[] getFormulaTokens(FormulaRecord formula)
/*     */   {
/* 148 */     int formulaRow = formula.getRow();
/* 149 */     int formulaColumn = formula.getColumn();
/*     */     
/* 151 */     if (!isInRange(formulaRow, formulaColumn)) {
/* 152 */       throw new RuntimeException("Shared Formula Conversion: Coding Error");
/*     */     }
/*     */     
/* 155 */     return convertSharedFormulas(this.field_7_parsed_expr.getTokens(), formulaRow, formulaColumn);
/*     */   }
/*     */   
/*     */   private static int fixupRelativeColumn(int currentcolumn, int column, boolean relative) {
/* 159 */     if (relative)
/*     */     {
/* 161 */       return column + currentcolumn & 0xFF;
/*     */     }
/* 163 */     return column;
/*     */   }
/*     */   
/*     */   private static int fixupRelativeRow(int currentrow, int row, boolean relative) {
/* 167 */     if (relative)
/*     */     {
/* 169 */       return row + currentrow & 0xFFFF;
/*     */     }
/* 171 */     return row;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 175 */     SharedFormulaRecord result = new SharedFormulaRecord(getRange());
/* 176 */     result.field_5_reserved = this.field_5_reserved;
/* 177 */     result.field_7_parsed_expr = this.field_7_parsed_expr.copy();
/* 178 */     return result;
/*     */   }
/*     */   
/* 181 */   public boolean isFormulaSame(SharedFormulaRecord other) { return this.field_7_parsed_expr.isSame(other.field_7_parsed_expr); }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SharedFormulaRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */