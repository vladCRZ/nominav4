/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SharedValueRecordBase
/*     */   extends StandardRecord
/*     */ {
/*     */   private CellRangeAddress8Bit _range;
/*     */   
/*     */   protected SharedValueRecordBase(CellRangeAddress8Bit range)
/*     */   {
/*  35 */     if (range == null) {
/*  36 */       throw new IllegalArgumentException("range must be supplied.");
/*     */     }
/*  38 */     this._range = range;
/*     */   }
/*     */   
/*     */   protected SharedValueRecordBase() {
/*  42 */     this(new CellRangeAddress8Bit(0, 0, 0, 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SharedValueRecordBase(LittleEndianInput in)
/*     */   {
/*  49 */     this._range = new CellRangeAddress8Bit(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final CellRangeAddress8Bit getRange()
/*     */   {
/*  56 */     return this._range;
/*     */   }
/*     */   
/*     */   public final int getFirstRow() {
/*  60 */     return this._range.getFirstRow();
/*     */   }
/*     */   
/*     */   public final int getLastRow() {
/*  64 */     return this._range.getLastRow();
/*     */   }
/*     */   
/*     */   public final int getFirstColumn() {
/*  68 */     return (short)this._range.getFirstColumn();
/*     */   }
/*     */   
/*     */   public final int getLastColumn() {
/*  72 */     return (short)this._range.getLastColumn();
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  76 */     return 6 + getExtraDataSize();
/*     */   }
/*     */   
/*     */   protected abstract int getExtraDataSize();
/*     */   
/*     */   protected abstract void serializeExtraData(LittleEndianOutput paramLittleEndianOutput);
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  84 */     this._range.serialize(out);
/*  85 */     serializeExtraData(out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isInRange(int rowIx, int colIx)
/*     */   {
/*  93 */     CellRangeAddress8Bit r = this._range;
/*  94 */     return (r.getFirstRow() <= rowIx) && (r.getLastRow() >= rowIx) && (r.getFirstColumn() <= colIx) && (r.getLastColumn() >= colIx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isFirstCell(int rowIx, int colIx)
/*     */   {
/* 104 */     CellRangeAddress8Bit r = getRange();
/* 105 */     return (r.getFirstRow() == rowIx) && (r.getFirstColumn() == colIx);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SharedValueRecordBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */