/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.record.cont.ContinuableRecord;
/*     */ import org.apache.poi.hssf.record.cont.ContinuableRecordOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringRecord
/*     */   extends ContinuableRecord
/*     */ {
/*     */   public static final short sid = 519;
/*     */   private boolean _is16bitUnicode;
/*     */   private String _text;
/*     */   
/*     */   public StringRecord() {}
/*     */   
/*     */   public StringRecord(RecordInputStream in)
/*     */   {
/*  47 */     int field_1_string_length = in.readUShort();
/*  48 */     this._is16bitUnicode = (in.readByte() != 0);
/*     */     
/*  50 */     if (this._is16bitUnicode) {
/*  51 */       this._text = in.readUnicodeLEString(field_1_string_length);
/*     */     } else {
/*  53 */       this._text = in.readCompressedUnicode(field_1_string_length);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void serialize(ContinuableRecordOutput out)
/*     */   {
/*  59 */     out.writeShort(this._text.length());
/*  60 */     out.writeStringData(this._text);
/*     */   }
/*     */   
/*     */ 
/*     */   public short getSid()
/*     */   {
/*  66 */     return 519;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/*  74 */     return this._text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setString(String string)
/*     */   {
/*  82 */     this._text = string;
/*  83 */     this._is16bitUnicode = StringUtil.hasMultibyte(string);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  88 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  90 */     buffer.append("[STRING]\n");
/*  91 */     buffer.append("    .string            = ").append(this._text).append("\n");
/*     */     
/*  93 */     buffer.append("[/STRING]\n");
/*  94 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  98 */     StringRecord rec = new StringRecord();
/*  99 */     rec._is16bitUnicode = this._is16bitUnicode;
/* 100 */     rec._text = this._text;
/* 101 */     return rec;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\StringRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */