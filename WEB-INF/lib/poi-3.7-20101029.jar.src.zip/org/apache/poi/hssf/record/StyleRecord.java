/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StyleRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 659;
/*  36 */   private static final BitField styleIndexMask = BitFieldFactory.getInstance(4095);
/*  37 */   private static final BitField isBuiltinFlag = BitFieldFactory.getInstance(32768);
/*     */   
/*     */ 
/*     */   private int field_1_xf_index;
/*     */   
/*     */ 
/*     */   private int field_2_builtin_style;
/*     */   
/*     */   private int field_3_outline_style_level;
/*     */   
/*     */   private boolean field_3_stringHasMultibyte;
/*     */   
/*     */   private String field_4_name;
/*     */   
/*     */ 
/*     */   public StyleRecord()
/*     */   {
/*  54 */     this.field_1_xf_index = isBuiltinFlag.set(this.field_1_xf_index);
/*     */   }
/*     */   
/*     */   public StyleRecord(RecordInputStream in) {
/*  58 */     this.field_1_xf_index = in.readShort();
/*  59 */     if (isBuiltin()) {
/*  60 */       this.field_2_builtin_style = in.readByte();
/*  61 */       this.field_3_outline_style_level = in.readByte();
/*     */     } else {
/*  63 */       int field_2_name_length = in.readShort();
/*     */       
/*  65 */       if (in.remaining() < 1)
/*     */       {
/*     */ 
/*  68 */         if (field_2_name_length != 0) {
/*  69 */           throw new RecordFormatException("Ran out of data reading style record");
/*     */         }
/*     */         
/*  72 */         this.field_4_name = "";
/*     */       }
/*     */       else {
/*  75 */         this.field_3_stringHasMultibyte = (in.readByte() != 0);
/*  76 */         if (this.field_3_stringHasMultibyte) {
/*  77 */           this.field_4_name = StringUtil.readUnicodeLE(in, field_2_name_length);
/*     */         } else {
/*  79 */           this.field_4_name = StringUtil.readCompressedUnicode(in, field_2_name_length);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXFIndex(int xfIndex)
/*     */   {
/*  90 */     this.field_1_xf_index = styleIndexMask.setValue(this.field_1_xf_index, xfIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXFIndex()
/*     */   {
/*  99 */     return styleIndexMask.getValue(this.field_1_xf_index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 107 */     this.field_4_name = name;
/* 108 */     this.field_3_stringHasMultibyte = StringUtil.hasMultibyte(name);
/* 109 */     this.field_1_xf_index = isBuiltinFlag.clear(this.field_1_xf_index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBuiltinStyle(int builtinStyleId)
/*     */   {
/* 118 */     this.field_1_xf_index = isBuiltinFlag.set(this.field_1_xf_index);
/* 119 */     this.field_2_builtin_style = builtinStyleId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOutlineStyleLevel(int level)
/*     */   {
/* 126 */     this.field_3_outline_style_level = (level & 0xFF);
/*     */   }
/*     */   
/*     */   public boolean isBuiltin() {
/* 130 */     return isBuiltinFlag.isSet(this.field_1_xf_index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 138 */     return this.field_4_name;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 142 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 144 */     sb.append("[STYLE]\n");
/* 145 */     sb.append("    .xf_index_raw =").append(HexDump.shortToHex(this.field_1_xf_index)).append("\n");
/* 146 */     sb.append("        .type     =").append(isBuiltin() ? "built-in" : "user-defined").append("\n");
/* 147 */     sb.append("        .xf_index =").append(HexDump.shortToHex(getXFIndex())).append("\n");
/* 148 */     if (isBuiltin()) {
/* 149 */       sb.append("    .builtin_style=").append(HexDump.byteToHex(this.field_2_builtin_style)).append("\n");
/* 150 */       sb.append("    .outline_level=").append(HexDump.byteToHex(this.field_3_outline_style_level)).append("\n");
/*     */     } else {
/* 152 */       sb.append("    .name        =").append(getName()).append("\n");
/*     */     }
/* 154 */     sb.append("[/STYLE]\n");
/* 155 */     return sb.toString();
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/* 160 */     if (isBuiltin()) {
/* 161 */       return 4;
/*     */     }
/* 163 */     return 5 + this.field_4_name.length() * (this.field_3_stringHasMultibyte ? 2 : 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/* 169 */     out.writeShort(this.field_1_xf_index);
/* 170 */     if (isBuiltin()) {
/* 171 */       out.writeByte(this.field_2_builtin_style);
/* 172 */       out.writeByte(this.field_3_outline_style_level);
/*     */     } else {
/* 174 */       out.writeShort(this.field_4_name.length());
/* 175 */       out.writeByte(this.field_3_stringHasMultibyte ? 1 : 0);
/* 176 */       if (this.field_3_stringHasMultibyte) {
/* 177 */         StringUtil.putUnicodeLE(getName(), out);
/*     */       } else {
/* 179 */         StringUtil.putCompressedUnicode(getName(), out);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 185 */     return 659;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\StyleRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */