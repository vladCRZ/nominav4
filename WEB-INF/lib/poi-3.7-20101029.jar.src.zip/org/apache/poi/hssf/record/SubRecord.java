/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.LittleEndianOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SubRecord
/*     */ {
/*     */   public static SubRecord createSubRecord(LittleEndianInput in, int cmoOt)
/*     */   {
/*  44 */     int sid = in.readUShort();
/*  45 */     int secondUShort = in.readUShort();
/*     */     
/*  47 */     switch (sid) {
/*     */     case 21: 
/*  49 */       return new CommonObjectDataSubRecord(in, secondUShort);
/*     */     case 9: 
/*  51 */       return new EmbeddedObjectRefSubRecord(in, secondUShort);
/*     */     case 6: 
/*  53 */       return new GroupMarkerSubRecord(in, secondUShort);
/*     */     case 0: 
/*  55 */       return new EndSubRecord(in, secondUShort);
/*     */     case 13: 
/*  57 */       return new NoteStructureSubRecord(in, secondUShort);
/*     */     case 19: 
/*  59 */       return new LbsDataSubRecord(in, secondUShort, cmoOt);
/*     */     case 12: 
/*  61 */       return new FtCblsSubRecord(in, secondUShort);
/*     */     }
/*  63 */     return new UnknownSubRecord(in, sid, secondUShort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract int getDataSize();
/*     */   
/*     */ 
/*     */   public byte[] serialize()
/*     */   {
/*  73 */     int size = getDataSize() + 4;
/*  74 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(size);
/*  75 */     serialize(new LittleEndianOutputStream(baos));
/*  76 */     if (baos.size() != size) {
/*  77 */       throw new RuntimeException("write size mismatch");
/*     */     }
/*  79 */     return baos.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void serialize(LittleEndianOutput paramLittleEndianOutput);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract Object clone();
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isTerminating()
/*     */   {
/*  94 */     return false;
/*     */   }
/*     */   
/*     */   private static final class UnknownSubRecord extends SubRecord
/*     */   {
/*     */     private final int _sid;
/*     */     private final byte[] _data;
/*     */     
/*     */     public UnknownSubRecord(LittleEndianInput in, int sid, int size) {
/* 103 */       this._sid = sid;
/* 104 */       byte[] buf = new byte[size];
/* 105 */       in.readFully(buf);
/* 106 */       this._data = buf;
/*     */     }
/*     */     
/* 109 */     protected int getDataSize() { return this._data.length; }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/* 112 */       out.writeShort(this._sid);
/* 113 */       out.writeShort(this._data.length);
/* 114 */       out.write(this._data);
/*     */     }
/*     */     
/* 117 */     public Object clone() { return this; }
/*     */     
/*     */     public String toString() {
/* 120 */       StringBuffer sb = new StringBuffer(64);
/* 121 */       sb.append(getClass().getName()).append(" [");
/* 122 */       sb.append("sid=").append(HexDump.shortToHex(this._sid));
/* 123 */       sb.append(" size=").append(this._data.length);
/* 124 */       sb.append(" : ").append(HexDump.toHex(this._data));
/* 125 */       sb.append("]\n");
/* 126 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SubRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */