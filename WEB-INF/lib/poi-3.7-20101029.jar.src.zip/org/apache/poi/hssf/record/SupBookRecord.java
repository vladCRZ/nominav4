/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SupBookRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 430;
/*     */   private static final short SMALL_RECORD_SIZE = 4;
/*     */   private static final short TAG_INTERNAL_REFERENCES = 1025;
/*     */   private static final short TAG_ADD_IN_FUNCTIONS = 14849;
/*     */   private short field_1_number_of_sheets;
/*     */   private String field_2_encoded_url;
/*     */   private String[] field_3_sheet_names;
/*     */   private boolean _isAddInFunctions;
/*     */   
/*     */   public static SupBookRecord createInternalReferences(short numberOfSheets)
/*     */   {
/*  47 */     return new SupBookRecord(false, numberOfSheets);
/*     */   }
/*     */   
/*  50 */   public static SupBookRecord createAddInFunctions() { return new SupBookRecord(true, (short)0); }
/*     */   
/*     */   public static SupBookRecord createExternalReferences(String url, String[] sheetNames) {
/*  53 */     return new SupBookRecord(url, sheetNames);
/*     */   }
/*     */   
/*     */   private SupBookRecord(boolean isAddInFuncs, short numberOfSheets) {
/*  57 */     this.field_1_number_of_sheets = numberOfSheets;
/*  58 */     this.field_2_encoded_url = null;
/*  59 */     this.field_3_sheet_names = null;
/*  60 */     this._isAddInFunctions = isAddInFuncs;
/*     */   }
/*     */   
/*  63 */   public SupBookRecord(String url, String[] sheetNames) { this.field_1_number_of_sheets = ((short)sheetNames.length);
/*  64 */     this.field_2_encoded_url = url;
/*  65 */     this.field_3_sheet_names = sheetNames;
/*  66 */     this._isAddInFunctions = false;
/*     */   }
/*     */   
/*     */   public boolean isExternalReferences() {
/*  70 */     return this.field_3_sheet_names != null;
/*     */   }
/*     */   
/*  73 */   public boolean isInternalReferences() { return (this.field_3_sheet_names == null) && (!this._isAddInFunctions); }
/*     */   
/*     */   public boolean isAddInFunctions() {
/*  76 */     return (this.field_3_sheet_names == null) && (this._isAddInFunctions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupBookRecord(RecordInputStream in)
/*     */   {
/*  85 */     int recLen = in.remaining();
/*     */     
/*  87 */     this.field_1_number_of_sheets = in.readShort();
/*     */     
/*  89 */     if (recLen > 4)
/*     */     {
/*  91 */       this._isAddInFunctions = false;
/*     */       
/*  93 */       this.field_2_encoded_url = in.readString();
/*  94 */       String[] sheetNames = new String[this.field_1_number_of_sheets];
/*  95 */       for (int i = 0; i < sheetNames.length; i++) {
/*  96 */         sheetNames[i] = in.readString();
/*     */       }
/*  98 */       this.field_3_sheet_names = sheetNames;
/*  99 */       return;
/*     */     }
/*     */     
/* 102 */     this.field_2_encoded_url = null;
/* 103 */     this.field_3_sheet_names = null;
/*     */     
/* 105 */     short nextShort = in.readShort();
/* 106 */     if (nextShort == 1025)
/*     */     {
/* 108 */       this._isAddInFunctions = false;
/* 109 */     } else if (nextShort == 14849)
/*     */     {
/* 111 */       this._isAddInFunctions = true;
/* 112 */       if (this.field_1_number_of_sheets != 1) {
/* 113 */         throw new RuntimeException("Expected 0x0001 for number of sheets field in 'Add-In Functions' but got (" + this.field_1_number_of_sheets + ")");
/*     */       }
/*     */     }
/*     */     else {
/* 117 */       throw new RuntimeException("invalid EXTERNALBOOK code (" + Integer.toHexString(nextShort) + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 123 */     StringBuffer sb = new StringBuffer();
/* 124 */     sb.append(getClass().getName()).append(" [SUPBOOK ");
/*     */     
/* 126 */     if (isExternalReferences()) {
/* 127 */       sb.append("External References");
/* 128 */       sb.append(" nSheets=").append(this.field_1_number_of_sheets);
/* 129 */       sb.append(" url=").append(this.field_2_encoded_url);
/* 130 */     } else if (this._isAddInFunctions) {
/* 131 */       sb.append("Add-In Functions");
/*     */     } else {
/* 133 */       sb.append("Internal References ");
/* 134 */       sb.append(" nSheets= ").append(this.field_1_number_of_sheets);
/*     */     }
/* 136 */     sb.append("]");
/* 137 */     return sb.toString();
/*     */   }
/*     */   
/* 140 */   protected int getDataSize() { if (!isExternalReferences()) {
/* 141 */       return 4;
/*     */     }
/* 143 */     int sum = 2;
/*     */     
/* 145 */     sum += StringUtil.getEncodedSize(this.field_2_encoded_url);
/*     */     
/* 147 */     for (int i = 0; i < this.field_3_sheet_names.length; i++) {
/* 148 */       sum += StringUtil.getEncodedSize(this.field_3_sheet_names[i]);
/*     */     }
/* 150 */     return sum;
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 154 */     out.writeShort(this.field_1_number_of_sheets);
/*     */     
/* 156 */     if (isExternalReferences()) {
/* 157 */       StringUtil.writeUnicodeString(out, this.field_2_encoded_url);
/*     */       
/* 159 */       for (int i = 0; i < this.field_3_sheet_names.length; i++) {
/* 160 */         StringUtil.writeUnicodeString(out, this.field_3_sheet_names[i]);
/*     */       }
/*     */     } else {
/* 163 */       int field2val = this._isAddInFunctions ? 14849 : 1025;
/*     */       
/* 165 */       out.writeShort(field2val);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setNumberOfSheets(short number) {
/* 170 */     this.field_1_number_of_sheets = number;
/*     */   }
/*     */   
/*     */   public short getNumberOfSheets() {
/* 174 */     return this.field_1_number_of_sheets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 179 */   public short getSid() { return 430; }
/*     */   
/*     */   public String getURL() {
/* 182 */     String encodedUrl = this.field_2_encoded_url;
/* 183 */     switch (encodedUrl.charAt(0)) {
/*     */     case '\000': 
/* 185 */       return encodedUrl.substring(1);
/*     */     case '\001': 
/* 187 */       return decodeFileName(encodedUrl);
/*     */     case '\002': 
/* 189 */       return encodedUrl.substring(1);
/*     */     }
/*     */     
/* 192 */     return encodedUrl;
/*     */   }
/*     */   
/* 195 */   private static String decodeFileName(String encodedUrl) { return encodedUrl.substring(1); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getSheetNames()
/*     */   {
/* 210 */     return (String[])this.field_3_sheet_names.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\SupBookRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */