/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TabIdRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 317;
/* 32 */   private static final short[] EMPTY_SHORT_ARRAY = new short[0];
/*    */   public short[] _tabids;
/*    */   
/*    */   public TabIdRecord()
/*    */   {
/* 37 */     this._tabids = EMPTY_SHORT_ARRAY;
/*    */   }
/*    */   
/*    */   public TabIdRecord(RecordInputStream in) {
/* 41 */     int nTabs = in.remaining() / 2;
/* 42 */     this._tabids = new short[nTabs];
/* 43 */     for (int i = 0; i < this._tabids.length; i++) {
/* 44 */       this._tabids[i] = in.readShort();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setTabIdArray(short[] array)
/*    */   {
/* 53 */     this._tabids = array;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 57 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 59 */     buffer.append("[TABID]\n");
/* 60 */     buffer.append("    .elements        = ").append(this._tabids.length).append("\n");
/* 61 */     for (int i = 0; i < this._tabids.length; i++) {
/* 62 */       buffer.append("    .element_").append(i).append(" = ").append(this._tabids[i]).append("\n");
/*    */     }
/* 64 */     buffer.append("[/TABID]\n");
/* 65 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 69 */     short[] tabids = this._tabids;
/*    */     
/* 71 */     for (int i = 0; i < tabids.length; i++) {
/* 72 */       out.writeShort(tabids[i]);
/*    */     }
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 77 */     return this._tabids.length * 2;
/*    */   }
/*    */   
/*    */   public short getSid() {
/* 81 */     return 317;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\TabIdRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */