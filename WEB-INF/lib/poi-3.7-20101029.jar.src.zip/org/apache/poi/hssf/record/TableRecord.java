/*     */ package org.apache.poi.hssf.record;
/*     */ 
/*     */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*     */ import org.apache.poi.hssf.util.CellReference;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TableRecord
/*     */   extends SharedValueRecordBase
/*     */ {
/*     */   public static final short sid = 566;
/*  40 */   private static final BitField alwaysCalc = BitFieldFactory.getInstance(1);
/*  41 */   private static final BitField calcOnOpen = BitFieldFactory.getInstance(2);
/*  42 */   private static final BitField rowOrColInpCell = BitFieldFactory.getInstance(4);
/*  43 */   private static final BitField oneOrTwoVar = BitFieldFactory.getInstance(8);
/*  44 */   private static final BitField rowDeleted = BitFieldFactory.getInstance(16);
/*  45 */   private static final BitField colDeleted = BitFieldFactory.getInstance(32);
/*     */   private int field_5_flags;
/*     */   private int field_6_res;
/*     */   private int field_7_rowInputRow;
/*     */   private int field_8_colInputRow;
/*     */   private int field_9_rowInputCol;
/*     */   private int field_10_colInputCol;
/*     */   
/*     */   public TableRecord(RecordInputStream in)
/*     */   {
/*  55 */     super(in);
/*  56 */     this.field_5_flags = in.readByte();
/*  57 */     this.field_6_res = in.readByte();
/*  58 */     this.field_7_rowInputRow = in.readShort();
/*  59 */     this.field_8_colInputRow = in.readShort();
/*  60 */     this.field_9_rowInputCol = in.readShort();
/*  61 */     this.field_10_colInputCol = in.readShort();
/*     */   }
/*     */   
/*     */   public TableRecord(CellRangeAddress8Bit range) {
/*  65 */     super(range);
/*  66 */     this.field_6_res = 0;
/*     */   }
/*     */   
/*     */   public int getFlags() {
/*  70 */     return this.field_5_flags;
/*     */   }
/*     */   
/*  73 */   public void setFlags(int flags) { this.field_5_flags = flags; }
/*     */   
/*     */   public int getRowInputRow()
/*     */   {
/*  77 */     return this.field_7_rowInputRow;
/*     */   }
/*     */   
/*  80 */   public void setRowInputRow(int rowInputRow) { this.field_7_rowInputRow = rowInputRow; }
/*     */   
/*     */   public int getColInputRow()
/*     */   {
/*  84 */     return this.field_8_colInputRow;
/*     */   }
/*     */   
/*  87 */   public void setColInputRow(int colInputRow) { this.field_8_colInputRow = colInputRow; }
/*     */   
/*     */   public int getRowInputCol()
/*     */   {
/*  91 */     return this.field_9_rowInputCol;
/*     */   }
/*     */   
/*  94 */   public void setRowInputCol(int rowInputCol) { this.field_9_rowInputCol = rowInputCol; }
/*     */   
/*     */   public int getColInputCol()
/*     */   {
/*  98 */     return this.field_10_colInputCol;
/*     */   }
/*     */   
/* 101 */   public void setColInputCol(int colInputCol) { this.field_10_colInputCol = colInputCol; }
/*     */   
/*     */ 
/*     */   public boolean isAlwaysCalc()
/*     */   {
/* 106 */     return alwaysCalc.isSet(this.field_5_flags);
/*     */   }
/*     */   
/* 109 */   public void setAlwaysCalc(boolean flag) { this.field_5_flags = alwaysCalc.setBoolean(this.field_5_flags, flag); }
/*     */   
/*     */   public boolean isRowOrColInpCell()
/*     */   {
/* 113 */     return rowOrColInpCell.isSet(this.field_5_flags);
/*     */   }
/*     */   
/* 116 */   public void setRowOrColInpCell(boolean flag) { this.field_5_flags = rowOrColInpCell.setBoolean(this.field_5_flags, flag); }
/*     */   
/*     */   public boolean isOneNotTwoVar()
/*     */   {
/* 120 */     return oneOrTwoVar.isSet(this.field_5_flags);
/*     */   }
/*     */   
/* 123 */   public void setOneNotTwoVar(boolean flag) { this.field_5_flags = oneOrTwoVar.setBoolean(this.field_5_flags, flag); }
/*     */   
/*     */   public boolean isColDeleted()
/*     */   {
/* 127 */     return colDeleted.isSet(this.field_5_flags);
/*     */   }
/*     */   
/* 130 */   public void setColDeleted(boolean flag) { this.field_5_flags = colDeleted.setBoolean(this.field_5_flags, flag); }
/*     */   
/*     */   public boolean isRowDeleted()
/*     */   {
/* 134 */     return rowDeleted.isSet(this.field_5_flags);
/*     */   }
/*     */   
/* 137 */   public void setRowDeleted(boolean flag) { this.field_5_flags = rowDeleted.setBoolean(this.field_5_flags, flag); }
/*     */   
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 142 */     return 566;
/*     */   }
/*     */   
/* 145 */   protected int getExtraDataSize() { return 10; }
/*     */   
/*     */ 
/*     */   protected void serializeExtraData(LittleEndianOutput out)
/*     */   {
/* 150 */     out.writeByte(this.field_5_flags);
/* 151 */     out.writeByte(this.field_6_res);
/* 152 */     out.writeShort(this.field_7_rowInputRow);
/* 153 */     out.writeShort(this.field_8_colInputRow);
/* 154 */     out.writeShort(this.field_9_rowInputCol);
/* 155 */     out.writeShort(this.field_10_colInputCol);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 159 */     StringBuffer buffer = new StringBuffer();
/* 160 */     buffer.append("[TABLE]\n");
/* 161 */     buffer.append("    .range    = ").append(getRange().toString()).append("\n");
/* 162 */     buffer.append("    .flags    = ").append(HexDump.byteToHex(this.field_5_flags)).append("\n");
/* 163 */     buffer.append("    .alwaysClc= ").append(isAlwaysCalc()).append("\n");
/* 164 */     buffer.append("    .reserved = ").append(HexDump.intToHex(this.field_6_res)).append("\n");
/* 165 */     CellReference crRowInput = cr(this.field_7_rowInputRow, this.field_8_colInputRow);
/* 166 */     CellReference crColInput = cr(this.field_9_rowInputCol, this.field_10_colInputCol);
/* 167 */     buffer.append("    .rowInput = ").append(crRowInput.formatAsString()).append("\n");
/* 168 */     buffer.append("    .colInput = ").append(crColInput.formatAsString()).append("\n");
/* 169 */     buffer.append("[/TABLE]\n");
/* 170 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private static CellReference cr(int rowIx, int colIxAndFlags) {
/* 174 */     int colIx = colIxAndFlags & 0xFF;
/* 175 */     boolean isRowAbs = (colIxAndFlags & 0x8000) == 0;
/* 176 */     boolean isColAbs = (colIxAndFlags & 0x4000) == 0;
/* 177 */     return new CellReference(rowIx, colIx, isRowAbs, isColAbs);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\TableRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */