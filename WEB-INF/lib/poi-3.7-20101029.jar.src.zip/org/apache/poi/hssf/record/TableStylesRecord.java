/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ import org.apache.poi.util.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TableStylesRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 2190;
/*    */   private int rt;
/*    */   private int grbitFrt;
/* 34 */   private byte[] unused = new byte[8];
/*    */   
/*    */   private int cts;
/*    */   private String rgchDefListStyle;
/*    */   private String rgchDefPivotStyle;
/*    */   
/*    */   public TableStylesRecord(RecordInputStream in)
/*    */   {
/* 42 */     this.rt = in.readUShort();
/* 43 */     this.grbitFrt = in.readUShort();
/* 44 */     in.readFully(this.unused);
/* 45 */     this.cts = in.readInt();
/* 46 */     int cchDefListStyle = in.readUShort();
/* 47 */     int cchDefPivotStyle = in.readUShort();
/*    */     
/* 49 */     this.rgchDefListStyle = in.readUnicodeLEString(cchDefListStyle);
/* 50 */     this.rgchDefPivotStyle = in.readUnicodeLEString(cchDefPivotStyle);
/*    */   }
/*    */   
/*    */   protected void serialize(LittleEndianOutput out)
/*    */   {
/* 55 */     out.writeShort(this.rt);
/* 56 */     out.writeShort(this.grbitFrt);
/* 57 */     out.write(this.unused);
/* 58 */     out.writeInt(this.cts);
/*    */     
/* 60 */     out.writeShort(this.rgchDefListStyle.length());
/* 61 */     out.writeShort(this.rgchDefPivotStyle.length());
/*    */     
/* 63 */     StringUtil.putUnicodeLE(this.rgchDefListStyle, out);
/* 64 */     StringUtil.putUnicodeLE(this.rgchDefPivotStyle, out);
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 69 */     return 20 + 2 * this.rgchDefListStyle.length() + 2 * this.rgchDefPivotStyle.length();
/*    */   }
/*    */   
/*    */ 
/*    */   public short getSid()
/*    */   {
/* 75 */     return 2190;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 81 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 83 */     buffer.append("[TABLESTYLES]\n");
/* 84 */     buffer.append("    .rt      =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 85 */     buffer.append("    .grbitFrt=").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 86 */     buffer.append("    .unused  =").append(HexDump.toHex(this.unused)).append('\n');
/* 87 */     buffer.append("    .cts=").append(HexDump.intToHex(this.cts)).append('\n');
/* 88 */     buffer.append("    .rgchDefListStyle=").append(this.rgchDefListStyle).append('\n');
/* 89 */     buffer.append("    .rgchDefPivotStyle=").append(this.rgchDefPivotStyle).append('\n');
/*    */     
/* 91 */     buffer.append("[/TABLESTYLES]\n");
/* 92 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\TableStylesRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */