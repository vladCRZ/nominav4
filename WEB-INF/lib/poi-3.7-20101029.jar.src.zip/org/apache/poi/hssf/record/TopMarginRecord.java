/*    */ package org.apache.poi.hssf.record;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TopMarginRecord
/*    */   extends StandardRecord
/*    */   implements Margin
/*    */ {
/*    */   public static final short sid = 40;
/*    */   private double field_1_margin;
/*    */   
/*    */   public TopMarginRecord() {}
/*    */   
/*    */   public TopMarginRecord(RecordInputStream in)
/*    */   {
/* 38 */     this.field_1_margin = in.readDouble();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 43 */     StringBuffer buffer = new StringBuffer();
/* 44 */     buffer.append("[TopMargin]\n");
/* 45 */     buffer.append("    .margin               = ").append(" (").append(getMargin()).append(" )\n");
/* 46 */     buffer.append("[/TopMargin]\n");
/* 47 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 51 */     out.writeDouble(this.field_1_margin);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 55 */     return 8;
/*    */   }
/*    */   
/* 58 */   public short getSid() { return 40; }
/*    */   
/*    */ 
/*    */   public double getMargin()
/*    */   {
/* 63 */     return this.field_1_margin;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setMargin(double field_1_margin)
/*    */   {
/* 69 */     this.field_1_margin = field_1_margin;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 73 */     TopMarginRecord rec = new TopMarginRecord();
/* 74 */     rec.field_1_margin = this.field_1_margin;
/* 75 */     return rec;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\TopMarginRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */