/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.CFHeaderRecord;
/*     */ import org.apache.poi.hssf.record.CFRuleRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.formula.AreaErrPtg;
/*     */ import org.apache.poi.hssf.record.formula.AreaPtg;
/*     */ import org.apache.poi.hssf.record.formula.FormulaShifter;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CFRecordsAggregate
/*     */   extends RecordAggregate
/*     */ {
/*     */   private static final int MAX_CONDTIONAL_FORMAT_RULES = 3;
/*     */   private final CFHeaderRecord header;
/*     */   private final List rules;
/*     */   
/*     */   private CFRecordsAggregate(CFHeaderRecord pHeader, CFRuleRecord[] pRules)
/*     */   {
/*  51 */     if (pHeader == null) {
/*  52 */       throw new IllegalArgumentException("header must not be null");
/*     */     }
/*  54 */     if (pRules == null) {
/*  55 */       throw new IllegalArgumentException("rules must not be null");
/*     */     }
/*  57 */     if (pRules.length > 3) {
/*  58 */       throw new IllegalArgumentException("No more than 3 rules may be specified");
/*     */     }
/*     */     
/*  61 */     if (pRules.length != pHeader.getNumberOfConditionalFormats()) {
/*  62 */       throw new RuntimeException("Mismatch number of rules");
/*     */     }
/*  64 */     this.header = pHeader;
/*  65 */     this.rules = new ArrayList(3);
/*  66 */     for (int i = 0; i < pRules.length; i++) {
/*  67 */       this.rules.add(pRules[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public CFRecordsAggregate(CellRangeAddress[] regions, CFRuleRecord[] rules) {
/*  72 */     this(new CFHeaderRecord(regions, rules.length), rules);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CFRecordsAggregate createCFAggregate(RecordStream rs)
/*     */   {
/*  81 */     Record rec = rs.getNext();
/*  82 */     if (rec.getSid() != 432) {
/*  83 */       throw new IllegalStateException("next record sid was " + rec.getSid() + " instead of " + 432 + " as expected");
/*     */     }
/*     */     
/*     */ 
/*  87 */     CFHeaderRecord header = (CFHeaderRecord)rec;
/*  88 */     int nRules = header.getNumberOfConditionalFormats();
/*     */     
/*  90 */     CFRuleRecord[] rules = new CFRuleRecord[nRules];
/*  91 */     for (int i = 0; i < rules.length; i++) {
/*  92 */       rules[i] = ((CFRuleRecord)rs.getNext());
/*     */     }
/*     */     
/*  95 */     return new CFRecordsAggregate(header, rules);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CFRecordsAggregate cloneCFAggregate()
/*     */   {
/* 104 */     CFRuleRecord[] newRecs = new CFRuleRecord[this.rules.size()];
/* 105 */     for (int i = 0; i < newRecs.length; i++) {
/* 106 */       newRecs[i] = ((CFRuleRecord)getRule(i).clone());
/*     */     }
/* 108 */     return new CFRecordsAggregate((CFHeaderRecord)this.header.clone(), newRecs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CFHeaderRecord getHeader()
/*     */   {
/* 116 */     return this.header;
/*     */   }
/*     */   
/*     */   private void checkRuleIndex(int idx) {
/* 120 */     if ((idx < 0) || (idx >= this.rules.size())) {
/* 121 */       throw new IllegalArgumentException("Bad rule record index (" + idx + ") nRules=" + this.rules.size());
/*     */     }
/*     */   }
/*     */   
/*     */   public CFRuleRecord getRule(int idx) {
/* 126 */     checkRuleIndex(idx);
/* 127 */     return (CFRuleRecord)this.rules.get(idx);
/*     */   }
/*     */   
/* 130 */   public void setRule(int idx, CFRuleRecord r) { if (r == null) {
/* 131 */       throw new IllegalArgumentException("r must not be null");
/*     */     }
/* 133 */     checkRuleIndex(idx);
/* 134 */     this.rules.set(idx, r);
/*     */   }
/*     */   
/* 137 */   public void addRule(CFRuleRecord r) { if (r == null) {
/* 138 */       throw new IllegalArgumentException("r must not be null");
/*     */     }
/* 140 */     if (this.rules.size() >= 3) {
/* 141 */       throw new IllegalStateException("Cannot have more than 3 conditional format rules");
/*     */     }
/*     */     
/* 144 */     this.rules.add(r);
/* 145 */     this.header.setNumberOfConditionalFormats(this.rules.size());
/*     */   }
/*     */   
/* 148 */   public int getNumberOfRules() { return this.rules.size(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 156 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 158 */     buffer.append("[CF]\n");
/* 159 */     if (this.header != null)
/*     */     {
/* 161 */       buffer.append(this.header.toString());
/*     */     }
/* 163 */     for (int i = 0; i < this.rules.size(); i++)
/*     */     {
/* 165 */       CFRuleRecord cfRule = (CFRuleRecord)this.rules.get(i);
/* 166 */       buffer.append(cfRule.toString());
/*     */     }
/* 168 */     buffer.append("[/CF]\n");
/* 169 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 173 */     rv.visitRecord(this.header);
/* 174 */     for (int i = 0; i < this.rules.size(); i++) {
/* 175 */       CFRuleRecord rule = (CFRuleRecord)this.rules.get(i);
/* 176 */       rv.visitRecord(rule);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean updateFormulasAfterCellShift(FormulaShifter shifter, int currentExternSheetIx)
/*     */   {
/* 184 */     CellRangeAddress[] cellRanges = this.header.getCellRanges();
/* 185 */     boolean changed = false;
/* 186 */     List temp = new ArrayList();
/* 187 */     for (int i = 0; i < cellRanges.length; i++) {
/* 188 */       CellRangeAddress craOld = cellRanges[i];
/* 189 */       CellRangeAddress craNew = shiftRange(shifter, craOld, currentExternSheetIx);
/* 190 */       if (craNew == null) {
/* 191 */         changed = true;
/*     */       }
/*     */       else {
/* 194 */         temp.add(craNew);
/* 195 */         if (craNew != craOld) {
/* 196 */           changed = true;
/*     */         }
/*     */       }
/*     */     }
/* 200 */     if (changed) {
/* 201 */       int nRanges = temp.size();
/* 202 */       if (nRanges == 0) {
/* 203 */         return false;
/*     */       }
/* 205 */       CellRangeAddress[] newRanges = new CellRangeAddress[nRanges];
/* 206 */       temp.toArray(newRanges);
/* 207 */       this.header.setCellRanges(newRanges);
/*     */     }
/*     */     
/* 210 */     for (int i = 0; i < this.rules.size(); i++) {
/* 211 */       CFRuleRecord rule = (CFRuleRecord)this.rules.get(i);
/*     */       
/* 213 */       Ptg[] ptgs = rule.getParsedExpression1();
/* 214 */       if ((ptgs != null) && (shifter.adjustFormula(ptgs, currentExternSheetIx))) {
/* 215 */         rule.setParsedExpression1(ptgs);
/*     */       }
/* 217 */       ptgs = rule.getParsedExpression2();
/* 218 */       if ((ptgs != null) && (shifter.adjustFormula(ptgs, currentExternSheetIx))) {
/* 219 */         rule.setParsedExpression2(ptgs);
/*     */       }
/*     */     }
/* 222 */     return true;
/*     */   }
/*     */   
/*     */   private static CellRangeAddress shiftRange(FormulaShifter shifter, CellRangeAddress cra, int currentExternSheetIx)
/*     */   {
/* 227 */     AreaPtg aptg = new AreaPtg(cra.getFirstRow(), cra.getLastRow(), cra.getFirstColumn(), cra.getLastColumn(), false, false, false, false);
/* 228 */     Ptg[] ptgs = { aptg };
/*     */     
/* 230 */     if (!shifter.adjustFormula(ptgs, currentExternSheetIx)) {
/* 231 */       return cra;
/*     */     }
/* 233 */     Ptg ptg0 = ptgs[0];
/* 234 */     if ((ptg0 instanceof AreaPtg)) {
/* 235 */       AreaPtg bptg = (AreaPtg)ptg0;
/* 236 */       return new CellRangeAddress(bptg.getFirstRow(), bptg.getLastRow(), bptg.getFirstColumn(), bptg.getLastColumn());
/*     */     }
/* 238 */     if ((ptg0 instanceof AreaErrPtg)) {
/* 239 */       return null;
/*     */     }
/* 241 */     throw new IllegalStateException("Unexpected shifted ptg class (" + ptg0.getClass().getName() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\CFRecordsAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */