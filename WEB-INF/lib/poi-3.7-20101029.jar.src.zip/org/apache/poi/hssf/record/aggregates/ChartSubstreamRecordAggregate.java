/*    */ package org.apache.poi.hssf.record.aggregates;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.poi.hssf.model.RecordStream;
/*    */ import org.apache.poi.hssf.record.BOFRecord;
/*    */ import org.apache.poi.hssf.record.EOFRecord;
/*    */ import org.apache.poi.hssf.record.HeaderFooterRecord;
/*    */ import org.apache.poi.hssf.record.Record;
/*    */ import org.apache.poi.hssf.record.RecordBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChartSubstreamRecordAggregate
/*    */   extends RecordAggregate
/*    */ {
/*    */   private final BOFRecord _bofRec;
/*    */   private final List<RecordBase> _recs;
/*    */   private PageSettingsBlock _psBlock;
/*    */   
/*    */   public ChartSubstreamRecordAggregate(RecordStream rs)
/*    */   {
/* 42 */     this._bofRec = ((BOFRecord)rs.getNext());
/* 43 */     List<RecordBase> temp = new ArrayList();
/* 44 */     while (rs.peekNextClass() != EOFRecord.class) {
/* 45 */       if (PageSettingsBlock.isComponentRecord(rs.peekNextSid())) {
/* 46 */         if (this._psBlock != null) {
/* 47 */           if (rs.peekNextSid() == 2204)
/*    */           {
/* 49 */             this._psBlock.addLateHeaderFooter((HeaderFooterRecord)rs.getNext());
/*    */           }
/*    */           else {
/* 52 */             throw new IllegalStateException("Found more than one PageSettingsBlock in chart sub-stream");
/*    */           }
/*    */         } else {
/* 55 */           this._psBlock = new PageSettingsBlock(rs);
/* 56 */           temp.add(this._psBlock);
/*    */         }
/*    */       } else
/* 59 */         temp.add(rs.getNext());
/*    */     }
/* 61 */     this._recs = temp;
/* 62 */     Record eof = rs.getNext();
/* 63 */     if (!(eof instanceof EOFRecord)) {
/* 64 */       throw new IllegalStateException("Bad chart EOF");
/*    */     }
/*    */   }
/*    */   
/*    */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 69 */     if (this._recs.isEmpty()) {
/* 70 */       return;
/*    */     }
/* 72 */     rv.visitRecord(this._bofRec);
/* 73 */     for (int i = 0; i < this._recs.size(); i++) {
/* 74 */       RecordBase rb = (RecordBase)this._recs.get(i);
/* 75 */       if ((rb instanceof RecordAggregate)) {
/* 76 */         ((RecordAggregate)rb).visitContainedRecords(rv);
/*    */       } else {
/* 78 */         rv.visitRecord((Record)rb);
/*    */       }
/*    */     }
/* 81 */     rv.visitRecord(EOFRecord.instance);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\ChartSubstreamRecordAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */