/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.ColumnInfoRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ColumnInfoRecordsAggregate
/*     */   extends RecordAggregate
/*     */ {
/*     */   private final List records;
/*     */   
/*     */   private static final class CIRComparator
/*     */     implements Comparator
/*     */   {
/*  39 */     public static final Comparator instance = new CIRComparator();
/*     */     
/*     */ 
/*     */     public int compare(Object a, Object b)
/*     */     {
/*  44 */       return compareColInfos((ColumnInfoRecord)a, (ColumnInfoRecord)b);
/*     */     }
/*     */     
/*  47 */     public static int compareColInfos(ColumnInfoRecord a, ColumnInfoRecord b) { return a.getFirstColumn() - b.getFirstColumn(); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   public ColumnInfoRecordsAggregate() { this.records = new ArrayList(); }
/*     */   
/*     */   public ColumnInfoRecordsAggregate(RecordStream rs) {
/*  58 */     this();
/*     */     
/*  60 */     boolean isInOrder = true;
/*  61 */     ColumnInfoRecord cirPrev = null;
/*  62 */     while (rs.peekNextClass() == ColumnInfoRecord.class) {
/*  63 */       ColumnInfoRecord cir = (ColumnInfoRecord)rs.getNext();
/*  64 */       this.records.add(cir);
/*  65 */       if ((cirPrev != null) && (CIRComparator.compareColInfos(cirPrev, cir) > 0)) {
/*  66 */         isInOrder = false;
/*     */       }
/*  68 */       cirPrev = cir;
/*     */     }
/*  70 */     if (this.records.size() < 1) {
/*  71 */       throw new RuntimeException("No column info records found");
/*     */     }
/*  73 */     if (!isInOrder) {
/*  74 */       Collections.sort(this.records, CIRComparator.instance);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  82 */     ColumnInfoRecordsAggregate rec = new ColumnInfoRecordsAggregate();
/*  83 */     for (int k = 0; k < this.records.size(); k++) {
/*  84 */       ColumnInfoRecord ci = (ColumnInfoRecord)this.records.get(k);
/*  85 */       rec.records.add(ci.clone());
/*     */     }
/*  87 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void insertColumn(ColumnInfoRecord col)
/*     */   {
/*  94 */     this.records.add(col);
/*  95 */     Collections.sort(this.records, CIRComparator.instance);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void insertColumn(int idx, ColumnInfoRecord col)
/*     */   {
/* 103 */     this.records.add(idx, col);
/*     */   }
/*     */   
/*     */   int getNumColumns() {
/* 107 */     return this.records.size();
/*     */   }
/*     */   
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 111 */     int nItems = this.records.size();
/* 112 */     if (nItems < 1) {
/* 113 */       return;
/*     */     }
/* 115 */     ColumnInfoRecord cirPrev = null;
/* 116 */     for (int i = 0; i < nItems; i++) {
/* 117 */       ColumnInfoRecord cir = (ColumnInfoRecord)this.records.get(i);
/* 118 */       rv.visitRecord(cir);
/* 119 */       if ((cirPrev != null) && (CIRComparator.compareColInfos(cirPrev, cir) > 0))
/*     */       {
/*     */ 
/* 122 */         throw new RuntimeException("Column info records are out of order");
/*     */       }
/* 124 */       cirPrev = cir;
/*     */     }
/*     */   }
/*     */   
/*     */   private int findStartOfColumnOutlineGroup(int pIdx)
/*     */   {
/* 130 */     ColumnInfoRecord columnInfo = (ColumnInfoRecord)this.records.get(pIdx);
/* 131 */     int level = columnInfo.getOutlineLevel();
/* 132 */     int idx = pIdx;
/* 133 */     while (idx != 0) {
/* 134 */       ColumnInfoRecord prevColumnInfo = (ColumnInfoRecord)this.records.get(idx - 1);
/* 135 */       if (!prevColumnInfo.isAdjacentBefore(columnInfo)) {
/*     */         break;
/*     */       }
/* 138 */       if (prevColumnInfo.getOutlineLevel() < level) {
/*     */         break;
/*     */       }
/* 141 */       idx--;
/* 142 */       columnInfo = prevColumnInfo;
/*     */     }
/*     */     
/* 145 */     return idx;
/*     */   }
/*     */   
/*     */   private int findEndOfColumnOutlineGroup(int colInfoIndex)
/*     */   {
/* 150 */     ColumnInfoRecord columnInfo = (ColumnInfoRecord)this.records.get(colInfoIndex);
/* 151 */     int level = columnInfo.getOutlineLevel();
/* 152 */     int idx = colInfoIndex;
/* 153 */     while (idx < this.records.size() - 1) {
/* 154 */       ColumnInfoRecord nextColumnInfo = (ColumnInfoRecord)this.records.get(idx + 1);
/* 155 */       if (!columnInfo.isAdjacentBefore(nextColumnInfo)) {
/*     */         break;
/*     */       }
/* 158 */       if (nextColumnInfo.getOutlineLevel() < level) {
/*     */         break;
/*     */       }
/* 161 */       idx++;
/* 162 */       columnInfo = nextColumnInfo;
/*     */     }
/* 164 */     return idx;
/*     */   }
/*     */   
/*     */   private ColumnInfoRecord getColInfo(int idx) {
/* 168 */     return (ColumnInfoRecord)this.records.get(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isColumnGroupCollapsed(int idx)
/*     */   {
/* 177 */     int endOfOutlineGroupIdx = findEndOfColumnOutlineGroup(idx);
/* 178 */     int nextColInfoIx = endOfOutlineGroupIdx + 1;
/* 179 */     if (nextColInfoIx >= this.records.size()) {
/* 180 */       return false;
/*     */     }
/* 182 */     ColumnInfoRecord nextColInfo = getColInfo(nextColInfoIx);
/* 183 */     if (!getColInfo(endOfOutlineGroupIdx).isAdjacentBefore(nextColInfo)) {
/* 184 */       return false;
/*     */     }
/* 186 */     return nextColInfo.getCollapsed();
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isColumnGroupHiddenByParent(int idx)
/*     */   {
/* 192 */     int endLevel = 0;
/* 193 */     boolean endHidden = false;
/* 194 */     int endOfOutlineGroupIdx = findEndOfColumnOutlineGroup(idx);
/* 195 */     if (endOfOutlineGroupIdx < this.records.size()) {
/* 196 */       ColumnInfoRecord nextInfo = getColInfo(endOfOutlineGroupIdx + 1);
/* 197 */       if (getColInfo(endOfOutlineGroupIdx).isAdjacentBefore(nextInfo)) {
/* 198 */         endLevel = nextInfo.getOutlineLevel();
/* 199 */         endHidden = nextInfo.getHidden();
/*     */       }
/*     */     }
/*     */     
/* 203 */     int startLevel = 0;
/* 204 */     boolean startHidden = false;
/* 205 */     int startOfOutlineGroupIdx = findStartOfColumnOutlineGroup(idx);
/* 206 */     if (startOfOutlineGroupIdx > 0) {
/* 207 */       ColumnInfoRecord prevInfo = getColInfo(startOfOutlineGroupIdx - 1);
/* 208 */       if (prevInfo.isAdjacentBefore(getColInfo(startOfOutlineGroupIdx))) {
/* 209 */         startLevel = prevInfo.getOutlineLevel();
/* 210 */         startHidden = prevInfo.getHidden();
/*     */       }
/*     */     }
/* 213 */     if (endLevel > startLevel) {
/* 214 */       return endHidden;
/*     */     }
/* 216 */     return startHidden;
/*     */   }
/*     */   
/*     */   public void collapseColumn(int columnIndex) {
/* 220 */     int colInfoIx = findColInfoIdx(columnIndex, 0);
/* 221 */     if (colInfoIx == -1) {
/* 222 */       return;
/*     */     }
/*     */     
/*     */ 
/* 226 */     int groupStartColInfoIx = findStartOfColumnOutlineGroup(colInfoIx);
/* 227 */     ColumnInfoRecord columnInfo = getColInfo(groupStartColInfoIx);
/*     */     
/*     */ 
/* 230 */     int lastColIx = setGroupHidden(groupStartColInfoIx, columnInfo.getOutlineLevel(), true);
/*     */     
/*     */ 
/* 233 */     setColumn(lastColIx + 1, null, null, null, null, Boolean.TRUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int setGroupHidden(int pIdx, int level, boolean hidden)
/*     */   {
/* 241 */     int idx = pIdx;
/* 242 */     ColumnInfoRecord columnInfo = getColInfo(idx);
/* 243 */     while (idx < this.records.size()) {
/* 244 */       columnInfo.setHidden(hidden);
/* 245 */       if (idx + 1 < this.records.size()) {
/* 246 */         ColumnInfoRecord nextColumnInfo = getColInfo(idx + 1);
/* 247 */         if (!columnInfo.isAdjacentBefore(nextColumnInfo)) {
/*     */           break;
/*     */         }
/* 250 */         if (nextColumnInfo.getOutlineLevel() < level) {
/*     */           break;
/*     */         }
/* 253 */         columnInfo = nextColumnInfo;
/*     */       }
/* 255 */       idx++;
/*     */     }
/* 257 */     return columnInfo.getLastColumn();
/*     */   }
/*     */   
/*     */   public void expandColumn(int columnIndex)
/*     */   {
/* 262 */     int idx = findColInfoIdx(columnIndex, 0);
/* 263 */     if (idx == -1) {
/* 264 */       return;
/*     */     }
/*     */     
/*     */ 
/* 268 */     if (!isColumnGroupCollapsed(idx)) {
/* 269 */       return;
/*     */     }
/*     */     
/*     */ 
/* 273 */     int startIdx = findStartOfColumnOutlineGroup(idx);
/* 274 */     int endIdx = findEndOfColumnOutlineGroup(idx);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */     ColumnInfoRecord columnInfo = getColInfo(endIdx);
/* 284 */     if (!isColumnGroupHiddenByParent(idx)) {
/* 285 */       int outlineLevel = columnInfo.getOutlineLevel();
/* 286 */       for (int i = startIdx; i <= endIdx; i++) {
/* 287 */         ColumnInfoRecord ci = getColInfo(i);
/* 288 */         if (outlineLevel == ci.getOutlineLevel()) {
/* 289 */           ci.setHidden(false);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 294 */     setColumn(columnInfo.getLastColumn() + 1, null, null, null, null, Boolean.FALSE);
/*     */   }
/*     */   
/*     */   private static ColumnInfoRecord copyColInfo(ColumnInfoRecord ci) {
/* 298 */     return (ColumnInfoRecord)ci.clone();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setColumn(int targetColumnIx, Short xfIndex, Integer width, Integer level, Boolean hidden, Boolean collapsed)
/*     */   {
/* 304 */     ColumnInfoRecord ci = null;
/* 305 */     int k = 0;
/*     */     
/* 307 */     for (k = 0; k < this.records.size(); k++) {
/* 308 */       ColumnInfoRecord tci = (ColumnInfoRecord)this.records.get(k);
/* 309 */       if (tci.containsColumn(targetColumnIx)) {
/* 310 */         ci = tci;
/*     */       }
/*     */       else {
/* 313 */         if (tci.getFirstColumn() > targetColumnIx) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 319 */     if (ci == null)
/*     */     {
/* 321 */       ColumnInfoRecord nci = new ColumnInfoRecord();
/*     */       
/* 323 */       nci.setFirstColumn(targetColumnIx);
/* 324 */       nci.setLastColumn(targetColumnIx);
/* 325 */       setColumnInfoFields(nci, xfIndex, width, level, hidden, collapsed);
/* 326 */       insertColumn(k, nci);
/* 327 */       attemptMergeColInfoRecords(k);
/* 328 */       return;
/*     */     }
/*     */     
/* 331 */     boolean styleChanged = (xfIndex != null) && (ci.getXFIndex() != xfIndex.shortValue());
/* 332 */     boolean widthChanged = (width != null) && (ci.getColumnWidth() != width.shortValue());
/* 333 */     boolean levelChanged = (level != null) && (ci.getOutlineLevel() != level.intValue());
/* 334 */     boolean hiddenChanged = (hidden != null) && (ci.getHidden() != hidden.booleanValue());
/* 335 */     boolean collapsedChanged = (collapsed != null) && (ci.getCollapsed() != collapsed.booleanValue());
/*     */     
/* 337 */     boolean columnChanged = (styleChanged) || (widthChanged) || (levelChanged) || (hiddenChanged) || (collapsedChanged);
/* 338 */     if (!columnChanged)
/*     */     {
/* 340 */       return;
/*     */     }
/*     */     
/* 343 */     if ((ci.getFirstColumn() == targetColumnIx) && (ci.getLastColumn() == targetColumnIx))
/*     */     {
/* 345 */       setColumnInfoFields(ci, xfIndex, width, level, hidden, collapsed);
/* 346 */       attemptMergeColInfoRecords(k);
/* 347 */       return;
/*     */     }
/*     */     
/* 350 */     if ((ci.getFirstColumn() == targetColumnIx) || (ci.getLastColumn() == targetColumnIx))
/*     */     {
/*     */ 
/* 353 */       if (ci.getFirstColumn() == targetColumnIx) {
/* 354 */         ci.setFirstColumn(targetColumnIx + 1);
/*     */       } else {
/* 356 */         ci.setLastColumn(targetColumnIx - 1);
/* 357 */         k++;
/*     */       }
/* 359 */       ColumnInfoRecord nci = copyColInfo(ci);
/*     */       
/* 361 */       nci.setFirstColumn(targetColumnIx);
/* 362 */       nci.setLastColumn(targetColumnIx);
/* 363 */       setColumnInfoFields(nci, xfIndex, width, level, hidden, collapsed);
/*     */       
/* 365 */       insertColumn(k, nci);
/* 366 */       attemptMergeColInfoRecords(k);
/*     */     }
/*     */     else {
/* 369 */       ColumnInfoRecord ciStart = ci;
/* 370 */       ColumnInfoRecord ciMid = copyColInfo(ci);
/* 371 */       ColumnInfoRecord ciEnd = copyColInfo(ci);
/* 372 */       int lastcolumn = ci.getLastColumn();
/*     */       
/* 374 */       ciStart.setLastColumn(targetColumnIx - 1);
/*     */       
/* 376 */       ciMid.setFirstColumn(targetColumnIx);
/* 377 */       ciMid.setLastColumn(targetColumnIx);
/* 378 */       setColumnInfoFields(ciMid, xfIndex, width, level, hidden, collapsed);
/* 379 */       insertColumn(++k, ciMid);
/*     */       
/* 381 */       ciEnd.setFirstColumn(targetColumnIx + 1);
/* 382 */       ciEnd.setLastColumn(lastcolumn);
/* 383 */       insertColumn(++k, ciEnd);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void setColumnInfoFields(ColumnInfoRecord ci, Short xfStyle, Integer width, Integer level, Boolean hidden, Boolean collapsed)
/*     */   {
/* 394 */     if (xfStyle != null) {
/* 395 */       ci.setXFIndex(xfStyle.shortValue());
/*     */     }
/* 397 */     if (width != null) {
/* 398 */       ci.setColumnWidth(width.intValue());
/*     */     }
/* 400 */     if (level != null) {
/* 401 */       ci.setOutlineLevel(level.shortValue());
/*     */     }
/* 403 */     if (hidden != null) {
/* 404 */       ci.setHidden(hidden.booleanValue());
/*     */     }
/* 406 */     if (collapsed != null) {
/* 407 */       ci.setCollapsed(collapsed.booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private int findColInfoIdx(int columnIx, int fromColInfoIdx) {
/* 412 */     if (columnIx < 0) {
/* 413 */       throw new IllegalArgumentException("column parameter out of range: " + columnIx);
/*     */     }
/* 415 */     if (fromColInfoIdx < 0) {
/* 416 */       throw new IllegalArgumentException("fromIdx parameter out of range: " + fromColInfoIdx);
/*     */     }
/*     */     
/* 419 */     for (int k = fromColInfoIdx; k < this.records.size(); k++) {
/* 420 */       ColumnInfoRecord ci = getColInfo(k);
/* 421 */       if (ci.containsColumn(columnIx)) {
/* 422 */         return k;
/*     */       }
/* 424 */       if (ci.getFirstColumn() > columnIx) {
/*     */         break;
/*     */       }
/*     */     }
/* 428 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void attemptMergeColInfoRecords(int colInfoIx)
/*     */   {
/* 436 */     int nRecords = this.records.size();
/* 437 */     if ((colInfoIx < 0) || (colInfoIx >= nRecords)) {
/* 438 */       throw new IllegalArgumentException("colInfoIx " + colInfoIx + " is out of range (0.." + (nRecords - 1) + ")");
/*     */     }
/*     */     
/* 441 */     ColumnInfoRecord currentCol = getColInfo(colInfoIx);
/* 442 */     int nextIx = colInfoIx + 1;
/* 443 */     if ((nextIx < nRecords) && 
/* 444 */       (mergeColInfoRecords(currentCol, getColInfo(nextIx)))) {
/* 445 */       this.records.remove(nextIx);
/*     */     }
/*     */     
/* 448 */     if ((colInfoIx > 0) && 
/* 449 */       (mergeColInfoRecords(getColInfo(colInfoIx - 1), currentCol))) {
/* 450 */       this.records.remove(colInfoIx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean mergeColInfoRecords(ColumnInfoRecord ciA, ColumnInfoRecord ciB)
/*     */   {
/* 459 */     if ((ciA.isAdjacentBefore(ciB)) && (ciA.formatMatches(ciB))) {
/* 460 */       ciA.setLastColumn(ciB.getLastColumn());
/* 461 */       return true;
/*     */     }
/* 463 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void groupColumnRange(int fromColumnIx, int toColumnIx, boolean indent)
/*     */   {
/* 481 */     int colInfoSearchStartIdx = 0;
/* 482 */     for (int i = fromColumnIx; i <= toColumnIx; i++) {
/* 483 */       int level = 1;
/* 484 */       int colInfoIdx = findColInfoIdx(i, colInfoSearchStartIdx);
/* 485 */       if (colInfoIdx != -1) {
/* 486 */         level = getColInfo(colInfoIdx).getOutlineLevel();
/* 487 */         if (indent) {
/* 488 */           level++;
/*     */         } else {
/* 490 */           level--;
/*     */         }
/* 492 */         level = Math.max(0, level);
/* 493 */         level = Math.min(7, level);
/* 494 */         colInfoSearchStartIdx = Math.max(0, colInfoIdx - 1);
/*     */       }
/* 496 */       setColumn(i, null, null, Integer.valueOf(level), null, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnInfoRecord findColumnInfo(int columnIndex)
/*     */   {
/* 505 */     int nInfos = this.records.size();
/* 506 */     for (int i = 0; i < nInfos; i++) {
/* 507 */       ColumnInfoRecord ci = getColInfo(i);
/* 508 */       if (ci.containsColumn(columnIndex)) {
/* 509 */         return ci;
/*     */       }
/*     */     }
/* 512 */     return null;
/*     */   }
/*     */   
/* 515 */   public int getMaxOutlineLevel() { int result = 0;
/* 516 */     int count = this.records.size();
/* 517 */     for (int i = 0; i < count; i++) {
/* 518 */       ColumnInfoRecord columnInfoRecord = getColInfo(i);
/* 519 */       result = Math.max(columnInfoRecord.getOutlineLevel(), result);
/*     */     }
/* 521 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\ColumnInfoRecordsAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */