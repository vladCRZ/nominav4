/*    */ package org.apache.poi.hssf.record.aggregates;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.poi.hssf.model.RecordStream;
/*    */ import org.apache.poi.hssf.record.CFHeaderRecord;
/*    */ import org.apache.poi.hssf.record.formula.FormulaShifter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConditionalFormattingTable
/*    */   extends RecordAggregate
/*    */ {
/*    */   private final List _cfHeaders;
/*    */   
/*    */   public ConditionalFormattingTable()
/*    */   {
/* 42 */     this._cfHeaders = new ArrayList();
/*    */   }
/*    */   
/*    */   public ConditionalFormattingTable(RecordStream rs)
/*    */   {
/* 47 */     List temp = new ArrayList();
/* 48 */     while (rs.peekNextClass() == CFHeaderRecord.class) {
/* 49 */       temp.add(CFRecordsAggregate.createCFAggregate(rs));
/*    */     }
/* 51 */     this._cfHeaders = temp;
/*    */   }
/*    */   
/*    */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 55 */     for (int i = 0; i < this._cfHeaders.size(); i++) {
/* 56 */       CFRecordsAggregate subAgg = (CFRecordsAggregate)this._cfHeaders.get(i);
/* 57 */       subAgg.visitContainedRecords(rv);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int add(CFRecordsAggregate cfAggregate)
/*    */   {
/* 65 */     this._cfHeaders.add(cfAggregate);
/* 66 */     return this._cfHeaders.size() - 1;
/*    */   }
/*    */   
/*    */   public int size() {
/* 70 */     return this._cfHeaders.size();
/*    */   }
/*    */   
/*    */   public CFRecordsAggregate get(int index) {
/* 74 */     checkIndex(index);
/* 75 */     return (CFRecordsAggregate)this._cfHeaders.get(index);
/*    */   }
/*    */   
/*    */   public void remove(int index) {
/* 79 */     checkIndex(index);
/* 80 */     this._cfHeaders.remove(index);
/*    */   }
/*    */   
/*    */   private void checkIndex(int index) {
/* 84 */     if ((index < 0) || (index >= this._cfHeaders.size())) {
/* 85 */       throw new IllegalArgumentException("Specified CF index " + index + " is outside the allowable range (0.." + (this._cfHeaders.size() - 1) + ")");
/*    */     }
/*    */   }
/*    */   
/*    */   public void updateFormulasAfterCellShift(FormulaShifter shifter, int externSheetIndex)
/*    */   {
/* 91 */     for (int i = 0; i < this._cfHeaders.size(); i++) {
/* 92 */       CFRecordsAggregate subAgg = (CFRecordsAggregate)this._cfHeaders.get(i);
/* 93 */       boolean shouldKeep = subAgg.updateFormulasAfterCellShift(shifter, externSheetIndex);
/* 94 */       if (!shouldKeep) {
/* 95 */         this._cfHeaders.remove(i);
/* 96 */         i--;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\ConditionalFormattingTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */