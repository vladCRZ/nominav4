/*    */ package org.apache.poi.hssf.record.aggregates;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.poi.hssf.model.RecordStream;
/*    */ import org.apache.poi.hssf.record.Record;
/*    */ import org.apache.poi.hssf.record.RecordBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CustomViewSettingsRecordAggregate
/*    */   extends RecordAggregate
/*    */ {
/*    */   private final Record _begin;
/*    */   private final Record _end;
/*    */   private final List<RecordBase> _recs;
/*    */   private PageSettingsBlock _psBlock;
/*    */   
/*    */   public CustomViewSettingsRecordAggregate(RecordStream rs)
/*    */   {
/* 43 */     this._begin = rs.getNext();
/* 44 */     if (this._begin.getSid() != 426) {
/* 45 */       throw new IllegalStateException("Bad begin record");
/*    */     }
/* 47 */     List<RecordBase> temp = new ArrayList();
/* 48 */     while (rs.peekNextSid() != 427)
/* 49 */       if (PageSettingsBlock.isComponentRecord(rs.peekNextSid())) {
/* 50 */         if (this._psBlock != null) {
/* 51 */           throw new IllegalStateException("Found more than one PageSettingsBlock in custom view settings sub-stream");
/*    */         }
/*    */         
/* 54 */         this._psBlock = new PageSettingsBlock(rs);
/* 55 */         temp.add(this._psBlock);
/*    */       }
/*    */       else {
/* 58 */         temp.add(rs.getNext());
/*    */       }
/* 60 */     this._recs = temp;
/* 61 */     this._end = rs.getNext();
/* 62 */     if (this._end.getSid() != 427) {
/* 63 */       throw new IllegalStateException("Bad custom view settings end record");
/*    */     }
/*    */   }
/*    */   
/*    */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 68 */     if (this._recs.isEmpty()) {
/* 69 */       return;
/*    */     }
/* 71 */     rv.visitRecord(this._begin);
/* 72 */     for (int i = 0; i < this._recs.size(); i++) {
/* 73 */       RecordBase rb = (RecordBase)this._recs.get(i);
/* 74 */       if ((rb instanceof RecordAggregate)) {
/* 75 */         ((RecordAggregate)rb).visitContainedRecords(rv);
/*    */       } else {
/* 77 */         rv.visitRecord((Record)rb);
/*    */       }
/*    */     }
/* 80 */     rv.visitRecord(this._end);
/*    */   }
/*    */   
/*    */   public static boolean isBeginRecord(int sid) {
/* 84 */     return sid == 426;
/*    */   }
/*    */   
/*    */   public void append(RecordBase r) {
/* 88 */     this._recs.add(r);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\CustomViewSettingsRecordAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */