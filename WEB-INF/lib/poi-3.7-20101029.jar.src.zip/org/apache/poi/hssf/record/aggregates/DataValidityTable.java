/*    */ package org.apache.poi.hssf.record.aggregates;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.poi.hssf.model.RecordStream;
/*    */ import org.apache.poi.hssf.record.DVALRecord;
/*    */ import org.apache.poi.hssf.record.DVRecord;
/*    */ import org.apache.poi.hssf.record.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DataValidityTable
/*    */   extends RecordAggregate
/*    */ {
/*    */   private final DVALRecord _headerRec;
/*    */   private final List _validationList;
/*    */   
/*    */   public DataValidityTable(RecordStream rs)
/*    */   {
/* 43 */     this._headerRec = ((DVALRecord)rs.getNext());
/* 44 */     List temp = new ArrayList();
/* 45 */     while (rs.peekNextClass() == DVRecord.class) {
/* 46 */       temp.add(rs.getNext());
/*    */     }
/* 48 */     this._validationList = temp;
/*    */   }
/*    */   
/*    */   public DataValidityTable() {
/* 52 */     this._headerRec = new DVALRecord();
/* 53 */     this._validationList = new ArrayList();
/*    */   }
/*    */   
/*    */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 57 */     if (this._validationList.isEmpty()) {
/* 58 */       return;
/*    */     }
/* 60 */     rv.visitRecord(this._headerRec);
/* 61 */     for (int i = 0; i < this._validationList.size(); i++) {
/* 62 */       rv.visitRecord((Record)this._validationList.get(i));
/*    */     }
/*    */   }
/*    */   
/*    */   public void addDataValidation(DVRecord dvRecord) {
/* 67 */     this._validationList.add(dvRecord);
/* 68 */     this._headerRec.setDVRecNo(this._validationList.size());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\DataValidityTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */