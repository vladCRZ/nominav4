/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import org.apache.poi.hssf.record.ArrayRecord;
/*     */ import org.apache.poi.hssf.record.CellValueRecordInterface;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFormatException;
/*     */ import org.apache.poi.hssf.record.SharedFormulaRecord;
/*     */ import org.apache.poi.hssf.record.StringRecord;
/*     */ import org.apache.poi.hssf.record.formula.ExpPtg;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*     */ import org.apache.poi.hssf.util.CellReference;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormulaRecordAggregate
/*     */   extends RecordAggregate
/*     */   implements CellValueRecordInterface
/*     */ {
/*     */   private final FormulaRecord _formulaRecord;
/*     */   private SharedValueManager _sharedValueManager;
/*     */   private StringRecord _stringRecord;
/*     */   private SharedFormulaRecord _sharedFormulaRecord;
/*     */   
/*     */   public FormulaRecordAggregate(FormulaRecord formulaRec, StringRecord stringRec, SharedValueManager svm)
/*     */   {
/*  55 */     if (svm == null) {
/*  56 */       throw new IllegalArgumentException("sfm must not be null");
/*     */     }
/*  58 */     if (formulaRec.hasCachedResultString()) {
/*  59 */       if (stringRec == null) {
/*  60 */         throw new RecordFormatException("Formula record flag is set but String record was not found");
/*     */       }
/*  62 */       this._stringRecord = stringRec;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  67 */       this._stringRecord = null;
/*     */     }
/*     */     
/*  70 */     this._formulaRecord = formulaRec;
/*  71 */     this._sharedValueManager = svm;
/*  72 */     if (formulaRec.isSharedFormula()) {
/*  73 */       CellReference firstCell = formulaRec.getFormula().getExpReference();
/*  74 */       if (firstCell == null) {
/*  75 */         handleMissingSharedFormulaRecord(formulaRec);
/*     */       } else {
/*  77 */         this._sharedFormulaRecord = svm.linkSharedFormulaRecord(firstCell, this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void handleMissingSharedFormulaRecord(FormulaRecord formula)
/*     */   {
/*  95 */     Ptg firstToken = formula.getParsedExpression()[0];
/*  96 */     if ((firstToken instanceof ExpPtg)) {
/*  97 */       throw new RecordFormatException("SharedFormulaRecord not found for FormulaRecord with (isSharedFormula=true)");
/*     */     }
/*     */     
/*     */ 
/* 101 */     formula.setSharedFormula(false);
/*     */   }
/*     */   
/*     */   public FormulaRecord getFormulaRecord() {
/* 105 */     return this._formulaRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringRecord getStringRecord()
/*     */   {
/* 113 */     return this._stringRecord;
/*     */   }
/*     */   
/*     */   public short getXFIndex() {
/* 117 */     return this._formulaRecord.getXFIndex();
/*     */   }
/*     */   
/*     */   public void setXFIndex(short xf) {
/* 121 */     this._formulaRecord.setXFIndex(xf);
/*     */   }
/*     */   
/*     */   public void setColumn(short col) {
/* 125 */     this._formulaRecord.setColumn(col);
/*     */   }
/*     */   
/*     */   public void setRow(int row) {
/* 129 */     this._formulaRecord.setRow(row);
/*     */   }
/*     */   
/*     */   public short getColumn() {
/* 133 */     return this._formulaRecord.getColumn();
/*     */   }
/*     */   
/*     */   public int getRow() {
/* 137 */     return this._formulaRecord.getRow();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 141 */     return this._formulaRecord.toString();
/*     */   }
/*     */   
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/* 145 */     rv.visitRecord(this._formulaRecord);
/* 146 */     Record sharedFormulaRecord = this._sharedValueManager.getRecordForFirstCell(this);
/* 147 */     if (sharedFormulaRecord != null) {
/* 148 */       rv.visitRecord(sharedFormulaRecord);
/*     */     }
/* 150 */     if ((this._formulaRecord.hasCachedResultString()) && (this._stringRecord != null)) {
/* 151 */       rv.visitRecord(this._stringRecord);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getStringValue() {
/* 156 */     if (this._stringRecord == null) {
/* 157 */       return null;
/*     */     }
/* 159 */     return this._stringRecord.getString();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCachedStringResult(String value)
/*     */   {
/* 165 */     if (this._stringRecord == null) {
/* 166 */       this._stringRecord = new StringRecord();
/*     */     }
/* 168 */     this._stringRecord.setString(value);
/* 169 */     if (value.length() < 1) {
/* 170 */       this._formulaRecord.setCachedResultTypeEmptyString();
/*     */     } else
/* 172 */       this._formulaRecord.setCachedResultTypeString();
/*     */   }
/*     */   
/*     */   public void setCachedBooleanResult(boolean value) {
/* 176 */     this._stringRecord = null;
/* 177 */     this._formulaRecord.setCachedResultBoolean(value);
/*     */   }
/*     */   
/* 180 */   public void setCachedErrorResult(int errorCode) { this._stringRecord = null;
/* 181 */     this._formulaRecord.setCachedResultErrorCode(errorCode);
/*     */   }
/*     */   
/* 184 */   public void setCachedDoubleResult(double value) { this._stringRecord = null;
/* 185 */     this._formulaRecord.setValue(value);
/*     */   }
/*     */   
/*     */   public Ptg[] getFormulaTokens() {
/* 189 */     if (this._sharedFormulaRecord != null) {
/* 190 */       return this._sharedFormulaRecord.getFormulaTokens(this._formulaRecord);
/*     */     }
/* 192 */     CellReference expRef = this._formulaRecord.getFormula().getExpReference();
/* 193 */     if (expRef != null) {
/* 194 */       ArrayRecord arec = this._sharedValueManager.getArrayRecord(expRef.getRow(), expRef.getCol());
/* 195 */       return arec.getFormulaTokens();
/*     */     }
/* 197 */     return this._formulaRecord.getParsedExpression();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParsedExpression(Ptg[] ptgs)
/*     */   {
/* 204 */     notifyFormulaChanging();
/* 205 */     this._formulaRecord.setParsedExpression(ptgs);
/*     */   }
/*     */   
/*     */   public void unlinkSharedFormula() {
/* 209 */     SharedFormulaRecord sfr = this._sharedFormulaRecord;
/* 210 */     if (sfr == null) {
/* 211 */       throw new IllegalStateException("Formula not linked to shared formula");
/*     */     }
/* 213 */     Ptg[] ptgs = sfr.getFormulaTokens(this._formulaRecord);
/* 214 */     this._formulaRecord.setParsedExpression(ptgs);
/*     */     
/* 216 */     this._formulaRecord.setSharedFormula(false);
/* 217 */     this._sharedFormulaRecord = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyFormulaChanging()
/*     */   {
/* 225 */     if (this._sharedFormulaRecord != null)
/* 226 */       this._sharedValueManager.unlink(this._sharedFormulaRecord);
/*     */   }
/*     */   
/*     */   public boolean isPartOfArrayFormula() {
/* 230 */     if (this._sharedFormulaRecord != null) {
/* 231 */       return false;
/*     */     }
/* 233 */     CellReference expRef = this._formulaRecord.getFormula().getExpReference();
/* 234 */     ArrayRecord arec = expRef == null ? null : this._sharedValueManager.getArrayRecord(expRef.getRow(), expRef.getCol());
/* 235 */     return arec != null;
/*     */   }
/*     */   
/*     */   public CellRangeAddress getArrayFormulaRange() {
/* 239 */     if (this._sharedFormulaRecord != null) {
/* 240 */       throw new IllegalStateException("not an array formula cell.");
/*     */     }
/* 242 */     CellReference expRef = this._formulaRecord.getFormula().getExpReference();
/* 243 */     if (expRef == null) {
/* 244 */       throw new IllegalStateException("not an array formula cell.");
/*     */     }
/* 246 */     ArrayRecord arec = this._sharedValueManager.getArrayRecord(expRef.getRow(), expRef.getCol());
/* 247 */     if (arec == null) {
/* 248 */       throw new IllegalStateException("ArrayRecord was not found for the locator " + expRef.formatAsString());
/*     */     }
/* 250 */     CellRangeAddress8Bit a = arec.getRange();
/* 251 */     return new CellRangeAddress(a.getFirstRow(), a.getLastRow(), a.getFirstColumn(), a.getLastColumn());
/*     */   }
/*     */   
/*     */   public void setArrayFormula(CellRangeAddress r, Ptg[] ptgs)
/*     */   {
/* 256 */     ArrayRecord arr = new ArrayRecord(Formula.create(ptgs), new CellRangeAddress8Bit(r.getFirstRow(), r.getLastRow(), r.getFirstColumn(), r.getLastColumn()));
/* 257 */     this._sharedValueManager.addArrayRecord(arr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CellRangeAddress removeArrayFormula(int rowIndex, int columnIndex)
/*     */   {
/* 264 */     CellRangeAddress8Bit a = this._sharedValueManager.removeArrayFormula(rowIndex, columnIndex);
/*     */     
/* 266 */     this._formulaRecord.setParsedExpression(null);
/* 267 */     return new CellRangeAddress(a.getFirstRow(), a.getLastRow(), a.getFirstColumn(), a.getLastColumn());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\FormulaRecordAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */