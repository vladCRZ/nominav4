/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.MergeCellsRecord;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ import org.apache.poi.ss.util.CellRangeAddressList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MergedCellsTable
/*     */   extends RecordAggregate
/*     */ {
/*  33 */   private static int MAX_MERGED_REGIONS = 1027;
/*     */   
/*     */ 
/*     */   private final List _mergedRegions;
/*     */   
/*     */ 
/*     */   public MergedCellsTable()
/*     */   {
/*  41 */     this._mergedRegions = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void read(RecordStream rs)
/*     */   {
/*  49 */     List temp = this._mergedRegions;
/*  50 */     while (rs.peekNextClass() == MergeCellsRecord.class) {
/*  51 */       MergeCellsRecord mcr = (MergeCellsRecord)rs.getNext();
/*  52 */       int nRegions = mcr.getNumAreas();
/*  53 */       for (int i = 0; i < nRegions; i++) {
/*  54 */         CellRangeAddress cra = mcr.getAreaAt(i);
/*  55 */         temp.add(cra);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getRecordSize()
/*     */   {
/*  62 */     int nRegions = this._mergedRegions.size();
/*  63 */     if (nRegions < 1)
/*     */     {
/*  65 */       return 0;
/*     */     }
/*  67 */     int nMergedCellsRecords = nRegions / MAX_MERGED_REGIONS;
/*  68 */     int nLeftoverMergedRegions = nRegions % MAX_MERGED_REGIONS;
/*     */     
/*  70 */     int result = nMergedCellsRecords * (4 + CellRangeAddressList.getEncodedSize(MAX_MERGED_REGIONS)) + 4 + CellRangeAddressList.getEncodedSize(nLeftoverMergedRegions);
/*     */     
/*     */ 
/*  73 */     return result;
/*     */   }
/*     */   
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv) {
/*  77 */     int nRegions = this._mergedRegions.size();
/*  78 */     if (nRegions < 1)
/*     */     {
/*  80 */       return;
/*     */     }
/*     */     
/*  83 */     int nFullMergedCellsRecords = nRegions / MAX_MERGED_REGIONS;
/*  84 */     int nLeftoverMergedRegions = nRegions % MAX_MERGED_REGIONS;
/*  85 */     CellRangeAddress[] cras = new CellRangeAddress[nRegions];
/*  86 */     this._mergedRegions.toArray(cras);
/*     */     
/*  88 */     for (int i = 0; i < nFullMergedCellsRecords; i++) {
/*  89 */       int startIx = i * MAX_MERGED_REGIONS;
/*  90 */       rv.visitRecord(new MergeCellsRecord(cras, startIx, MAX_MERGED_REGIONS));
/*     */     }
/*  92 */     if (nLeftoverMergedRegions > 0) {
/*  93 */       int startIx = nFullMergedCellsRecords * MAX_MERGED_REGIONS;
/*  94 */       rv.visitRecord(new MergeCellsRecord(cras, startIx, nLeftoverMergedRegions));
/*     */     }
/*     */   }
/*     */   
/*  98 */   public void addRecords(MergeCellsRecord[] mcrs) { for (int i = 0; i < mcrs.length; i++) {
/*  99 */       addMergeCellsRecord(mcrs[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMergeCellsRecord(MergeCellsRecord mcr) {
/* 104 */     int nRegions = mcr.getNumAreas();
/* 105 */     for (int i = 0; i < nRegions; i++) {
/* 106 */       CellRangeAddress cra = mcr.getAreaAt(i);
/* 107 */       this._mergedRegions.add(cra);
/*     */     }
/*     */   }
/*     */   
/*     */   public CellRangeAddress get(int index) {
/* 112 */     checkIndex(index);
/* 113 */     return (CellRangeAddress)this._mergedRegions.get(index);
/*     */   }
/*     */   
/*     */   public void remove(int index) {
/* 117 */     checkIndex(index);
/* 118 */     this._mergedRegions.remove(index);
/*     */   }
/*     */   
/*     */   private void checkIndex(int index) {
/* 122 */     if ((index < 0) || (index >= this._mergedRegions.size())) {
/* 123 */       throw new IllegalArgumentException("Specified CF index " + index + " is outside the allowable range (0.." + (this._mergedRegions.size() - 1) + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addArea(int rowFrom, int colFrom, int rowTo, int colTo)
/*     */   {
/* 129 */     this._mergedRegions.add(new CellRangeAddress(rowFrom, rowTo, colFrom, colTo));
/*     */   }
/*     */   
/*     */   public int getNumberOfMergedRegions() {
/* 133 */     return this._mergedRegions.size();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\MergedCellsTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */