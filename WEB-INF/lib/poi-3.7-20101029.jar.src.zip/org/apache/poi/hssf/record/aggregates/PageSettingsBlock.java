/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.BottomMarginRecord;
/*     */ import org.apache.poi.hssf.record.ContinueRecord;
/*     */ import org.apache.poi.hssf.record.FooterRecord;
/*     */ import org.apache.poi.hssf.record.HCenterRecord;
/*     */ import org.apache.poi.hssf.record.HeaderFooterRecord;
/*     */ import org.apache.poi.hssf.record.HeaderRecord;
/*     */ import org.apache.poi.hssf.record.LeftMarginRecord;
/*     */ import org.apache.poi.hssf.record.Margin;
/*     */ import org.apache.poi.hssf.record.PageBreakRecord;
/*     */ import org.apache.poi.hssf.record.PageBreakRecord.Break;
/*     */ import org.apache.poi.hssf.record.PrintSetupRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordBase;
/*     */ import org.apache.poi.hssf.record.RightMarginRecord;
/*     */ import org.apache.poi.hssf.record.TopMarginRecord;
/*     */ import org.apache.poi.hssf.record.VCenterRecord;
/*     */ 
/*     */ public final class PageSettingsBlock extends RecordAggregate
/*     */ {
/*     */   private PageBreakRecord _rowBreaksRecord;
/*     */   private PageBreakRecord _columnBreaksRecord;
/*     */   private HeaderRecord _header;
/*     */   private FooterRecord _footer;
/*     */   private HCenterRecord _hCenter;
/*     */   private VCenterRecord _vCenter;
/*     */   private LeftMarginRecord _leftMargin;
/*     */   private RightMarginRecord _rightMargin;
/*     */   private TopMarginRecord _topMargin;
/*     */   private BottomMarginRecord _bottomMargin;
/*     */   private final List<PLSAggregate> _plsRecords;
/*     */   private PrintSetupRecord _printSetup;
/*     */   private Record _bitmap;
/*     */   private HeaderFooterRecord _headerFooter;
/*     */   
/*     */   private static final class PLSAggregate extends RecordAggregate
/*     */   {
/*  43 */     private static final ContinueRecord[] EMPTY_CONTINUE_RECORD_ARRAY = new ContinueRecord[0];
/*     */     
/*     */ 
/*     */     private final Record _pls;
/*     */     
/*     */ 
/*     */     private ContinueRecord[] _plsContinues;
/*     */     
/*     */ 
/*     */     public PLSAggregate(RecordStream rs)
/*     */     {
/*  54 */       this._pls = rs.getNext();
/*  55 */       if (rs.peekNextSid() == 60) {
/*  56 */         List<ContinueRecord> temp = new ArrayList();
/*  57 */         while (rs.peekNextSid() == 60) {
/*  58 */           temp.add((ContinueRecord)rs.getNext());
/*     */         }
/*  60 */         this._plsContinues = new ContinueRecord[temp.size()];
/*  61 */         temp.toArray(this._plsContinues);
/*     */       } else {
/*  63 */         this._plsContinues = EMPTY_CONTINUE_RECORD_ARRAY;
/*     */       }
/*     */     }
/*     */     
/*     */     public void visitContainedRecords(RecordAggregate.RecordVisitor rv)
/*     */     {
/*  69 */       rv.visitRecord(this._pls);
/*  70 */       for (int i = 0; i < this._plsContinues.length; i++) {
/*  71 */         rv.visitRecord(this._plsContinues[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private List<HeaderFooterRecord> _sviewHeaderFooters = new ArrayList();
/*     */   private Record _printSize;
/*     */   
/*     */   public PageSettingsBlock(RecordStream rs) {
/* 101 */     this._plsRecords = new ArrayList();
/*     */     for (;;) {
/* 103 */       if (!readARecord(rs)) {
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PageSettingsBlock()
/*     */   {
/* 113 */     this._plsRecords = new ArrayList();
/* 114 */     this._rowBreaksRecord = new org.apache.poi.hssf.record.HorizontalPageBreakRecord();
/* 115 */     this._columnBreaksRecord = new org.apache.poi.hssf.record.VerticalPageBreakRecord();
/* 116 */     this._header = new HeaderRecord("");
/* 117 */     this._footer = new FooterRecord("");
/* 118 */     this._hCenter = createHCenter();
/* 119 */     this._vCenter = createVCenter();
/* 120 */     this._printSetup = createPrintSetup();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isComponentRecord(int sid)
/*     */   {
/* 128 */     switch (sid) {
/*     */     case 20: 
/*     */     case 21: 
/*     */     case 26: 
/*     */     case 27: 
/*     */     case 38: 
/*     */     case 39: 
/*     */     case 40: 
/*     */     case 41: 
/*     */     case 51: 
/*     */     case 77: 
/*     */     case 131: 
/*     */     case 132: 
/*     */     case 161: 
/*     */     case 233: 
/*     */     case 2204: 
/* 144 */       return true;
/*     */     }
/* 146 */     return false;
/*     */   }
/*     */   
/*     */   private boolean readARecord(RecordStream rs) {
/* 150 */     switch (rs.peekNextSid()) {
/*     */     case 27: 
/* 152 */       checkNotPresent(this._rowBreaksRecord);
/* 153 */       this._rowBreaksRecord = ((PageBreakRecord)rs.getNext());
/* 154 */       break;
/*     */     case 26: 
/* 156 */       checkNotPresent(this._columnBreaksRecord);
/* 157 */       this._columnBreaksRecord = ((PageBreakRecord)rs.getNext());
/* 158 */       break;
/*     */     case 20: 
/* 160 */       checkNotPresent(this._header);
/* 161 */       this._header = ((HeaderRecord)rs.getNext());
/* 162 */       break;
/*     */     case 21: 
/* 164 */       checkNotPresent(this._footer);
/* 165 */       this._footer = ((FooterRecord)rs.getNext());
/* 166 */       break;
/*     */     case 131: 
/* 168 */       checkNotPresent(this._hCenter);
/* 169 */       this._hCenter = ((HCenterRecord)rs.getNext());
/* 170 */       break;
/*     */     case 132: 
/* 172 */       checkNotPresent(this._vCenter);
/* 173 */       this._vCenter = ((VCenterRecord)rs.getNext());
/* 174 */       break;
/*     */     case 38: 
/* 176 */       checkNotPresent(this._leftMargin);
/* 177 */       this._leftMargin = ((LeftMarginRecord)rs.getNext());
/* 178 */       break;
/*     */     case 39: 
/* 180 */       checkNotPresent(this._rightMargin);
/* 181 */       this._rightMargin = ((RightMarginRecord)rs.getNext());
/* 182 */       break;
/*     */     case 40: 
/* 184 */       checkNotPresent(this._topMargin);
/* 185 */       this._topMargin = ((TopMarginRecord)rs.getNext());
/* 186 */       break;
/*     */     case 41: 
/* 188 */       checkNotPresent(this._bottomMargin);
/* 189 */       this._bottomMargin = ((BottomMarginRecord)rs.getNext());
/* 190 */       break;
/*     */     case 77: 
/* 192 */       this._plsRecords.add(new PLSAggregate(rs));
/* 193 */       break;
/*     */     case 161: 
/* 195 */       checkNotPresent(this._printSetup);
/* 196 */       this._printSetup = ((PrintSetupRecord)rs.getNext());
/* 197 */       break;
/*     */     case 233: 
/* 199 */       checkNotPresent(this._bitmap);
/* 200 */       this._bitmap = rs.getNext();
/* 201 */       break;
/*     */     case 51: 
/* 203 */       checkNotPresent(this._printSize);
/* 204 */       this._printSize = rs.getNext();
/* 205 */       break;
/*     */     
/*     */     case 2204: 
/* 208 */       HeaderFooterRecord hf = (HeaderFooterRecord)rs.getNext();
/* 209 */       if (hf.isCurrentSheet()) { this._headerFooter = hf;
/*     */       } else {
/* 211 */         this._sviewHeaderFooters.add(hf);
/*     */       }
/* 213 */       break;
/*     */     
/*     */     default: 
/* 216 */       return false;
/*     */     }
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   private void checkNotPresent(Record rec) {
/* 222 */     if (rec != null) {
/* 223 */       throw new org.apache.poi.hssf.record.RecordFormatException("Duplicate PageSettingsBlock record (sid=0x" + Integer.toHexString(rec.getSid()) + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   private PageBreakRecord getRowBreaksRecord()
/*     */   {
/* 229 */     if (this._rowBreaksRecord == null) {
/* 230 */       this._rowBreaksRecord = new org.apache.poi.hssf.record.HorizontalPageBreakRecord();
/*     */     }
/* 232 */     return this._rowBreaksRecord;
/*     */   }
/*     */   
/*     */   private PageBreakRecord getColumnBreaksRecord() {
/* 236 */     if (this._columnBreaksRecord == null) {
/* 237 */       this._columnBreaksRecord = new org.apache.poi.hssf.record.VerticalPageBreakRecord();
/*     */     }
/* 239 */     return this._columnBreaksRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnBreak(short column, short fromRow, short toRow)
/*     */   {
/* 248 */     getColumnBreaksRecord().addBreak(column, fromRow, toRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeColumnBreak(int column)
/*     */   {
/* 256 */     getColumnBreaksRecord().removeBreak(column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv)
/*     */   {
/* 265 */     visitIfPresent(this._rowBreaksRecord, rv);
/* 266 */     visitIfPresent(this._columnBreaksRecord, rv);
/*     */     
/* 268 */     if (this._header == null) {
/* 269 */       rv.visitRecord(new HeaderRecord(""));
/*     */     } else {
/* 271 */       rv.visitRecord(this._header);
/*     */     }
/* 273 */     if (this._footer == null) {
/* 274 */       rv.visitRecord(new FooterRecord(""));
/*     */     } else {
/* 276 */       rv.visitRecord(this._footer);
/*     */     }
/* 278 */     visitIfPresent(this._hCenter, rv);
/* 279 */     visitIfPresent(this._vCenter, rv);
/* 280 */     visitIfPresent(this._leftMargin, rv);
/* 281 */     visitIfPresent(this._rightMargin, rv);
/* 282 */     visitIfPresent(this._topMargin, rv);
/* 283 */     visitIfPresent(this._bottomMargin, rv);
/* 284 */     for (RecordAggregate pls : this._plsRecords) {
/* 285 */       pls.visitContainedRecords(rv);
/*     */     }
/* 287 */     visitIfPresent(this._printSetup, rv);
/* 288 */     visitIfPresent(this._bitmap, rv);
/* 289 */     visitIfPresent(this._printSize, rv);
/* 290 */     visitIfPresent(this._headerFooter, rv);
/*     */   }
/*     */   
/* 293 */   private static void visitIfPresent(Record r, RecordAggregate.RecordVisitor rv) { if (r != null)
/* 294 */       rv.visitRecord(r);
/*     */   }
/*     */   
/*     */   private static void visitIfPresent(PageBreakRecord r, RecordAggregate.RecordVisitor rv) {
/* 298 */     if (r != null) {
/* 299 */       if (r.isEmpty())
/*     */       {
/* 301 */         return;
/*     */       }
/* 303 */       rv.visitRecord(r);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static HCenterRecord createHCenter()
/*     */   {
/* 311 */     HCenterRecord retval = new HCenterRecord();
/*     */     
/* 313 */     retval.setHCenter(false);
/* 314 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static VCenterRecord createVCenter()
/*     */   {
/* 321 */     VCenterRecord retval = new VCenterRecord();
/*     */     
/* 323 */     retval.setVCenter(false);
/* 324 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PrintSetupRecord createPrintSetup()
/*     */   {
/* 334 */     PrintSetupRecord retval = new PrintSetupRecord();
/*     */     
/* 336 */     retval.setPaperSize((short)1);
/* 337 */     retval.setScale((short)100);
/* 338 */     retval.setPageStart((short)1);
/* 339 */     retval.setFitWidth((short)1);
/* 340 */     retval.setFitHeight((short)1);
/* 341 */     retval.setOptions((short)2);
/* 342 */     retval.setHResolution((short)300);
/* 343 */     retval.setVResolution((short)300);
/* 344 */     retval.setHeaderMargin(0.5D);
/* 345 */     retval.setFooterMargin(0.5D);
/* 346 */     retval.setCopies((short)1);
/* 347 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeaderRecord getHeader()
/*     */   {
/* 357 */     return this._header;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeader(HeaderRecord newHeader)
/*     */   {
/* 366 */     this._header = newHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FooterRecord getFooter()
/*     */   {
/* 375 */     return this._footer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFooter(FooterRecord newFooter)
/*     */   {
/* 384 */     this._footer = newFooter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrintSetupRecord getPrintSetup()
/*     */   {
/* 393 */     return this._printSetup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrintSetup(PrintSetupRecord newPrintSetup)
/*     */   {
/* 402 */     this._printSetup = newPrintSetup;
/*     */   }
/*     */   
/*     */   private Margin getMarginRec(int marginIndex)
/*     */   {
/* 407 */     switch (marginIndex) {
/* 408 */     case 0:  return this._leftMargin;
/* 409 */     case 1:  return this._rightMargin;
/* 410 */     case 2:  return this._topMargin;
/* 411 */     case 3:  return this._bottomMargin;
/*     */     }
/* 413 */     throw new IllegalArgumentException("Unknown margin constant:  " + marginIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMargin(short margin)
/*     */   {
/* 423 */     Margin m = getMarginRec(margin);
/* 424 */     if (m != null) {
/* 425 */       return m.getMargin();
/*     */     }
/* 427 */     switch (margin) {
/* 428 */     case 0:  return 0.75D;
/* 429 */     case 1:  return 0.75D;
/* 430 */     case 2:  return 1.0D;
/* 431 */     case 3:  return 1.0D;
/*     */     }
/* 433 */     throw new IllegalArgumentException("Unknown margin constant:  " + margin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMargin(short margin, double size)
/*     */   {
/* 442 */     Margin m = getMarginRec(margin);
/* 443 */     if (m == null) {
/* 444 */       switch (margin) {
/*     */       case 0: 
/* 446 */         this._leftMargin = new LeftMarginRecord();
/* 447 */         m = this._leftMargin;
/* 448 */         break;
/*     */       case 1: 
/* 450 */         this._rightMargin = new RightMarginRecord();
/* 451 */         m = this._rightMargin;
/* 452 */         break;
/*     */       case 2: 
/* 454 */         this._topMargin = new TopMarginRecord();
/* 455 */         m = this._topMargin;
/* 456 */         break;
/*     */       case 3: 
/* 458 */         this._bottomMargin = new BottomMarginRecord();
/* 459 */         m = this._bottomMargin;
/* 460 */         break;
/*     */       default: 
/* 462 */         throw new IllegalArgumentException("Unknown margin constant:  " + margin);
/*     */       }
/*     */     }
/* 465 */     m.setMargin(size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void shiftBreaks(PageBreakRecord breaks, int start, int stop, int count)
/*     */   {
/* 477 */     Iterator<PageBreakRecord.Break> iterator = breaks.getBreaksIterator();
/* 478 */     List<PageBreakRecord.Break> shiftedBreak = new ArrayList();
/* 479 */     while (iterator.hasNext())
/*     */     {
/* 481 */       PageBreakRecord.Break breakItem = (PageBreakRecord.Break)iterator.next();
/* 482 */       int breakLocation = breakItem.main;
/* 483 */       boolean inStart = breakLocation >= start;
/* 484 */       boolean inEnd = breakLocation <= stop;
/* 485 */       if ((inStart) && (inEnd)) {
/* 486 */         shiftedBreak.add(breakItem);
/*     */       }
/*     */     }
/* 489 */     iterator = shiftedBreak.iterator();
/* 490 */     while (iterator.hasNext()) {
/* 491 */       PageBreakRecord.Break breakItem = (PageBreakRecord.Break)iterator.next();
/* 492 */       breaks.removeBreak(breakItem.main);
/* 493 */       breaks.addBreak((short)(breakItem.main + count), breakItem.subFrom, breakItem.subTo);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRowBreak(int row, short fromCol, short toCol)
/*     */   {
/* 503 */     getRowBreaksRecord().addBreak((short)row, fromCol, toCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRowBreak(int row)
/*     */   {
/* 511 */     if (getRowBreaksRecord().getBreaks().length < 1)
/* 512 */       throw new IllegalArgumentException("Sheet does not define any row breaks");
/* 513 */     getRowBreaksRecord().removeBreak((short)row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRowBroken(int row)
/*     */   {
/* 522 */     return getRowBreaksRecord().getBreak(row) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isColumnBroken(int column)
/*     */   {
/* 532 */     return getColumnBreaksRecord().getBreak(column) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shiftRowBreaks(int startingRow, int endingRow, int count)
/*     */   {
/* 542 */     shiftBreaks(getRowBreaksRecord(), startingRow, endingRow, count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shiftColumnBreaks(short startingCol, short endingCol, short count)
/*     */   {
/* 552 */     shiftBreaks(getColumnBreaksRecord(), startingCol, endingCol, count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] getRowBreaks()
/*     */   {
/* 559 */     return getRowBreaksRecord().getBreaks();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNumRowBreaks()
/*     */   {
/* 566 */     return getRowBreaksRecord().getNumBreaks();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] getColumnBreaks()
/*     */   {
/* 573 */     return getColumnBreaksRecord().getBreaks();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNumColumnBreaks()
/*     */   {
/* 580 */     return getColumnBreaksRecord().getNumBreaks();
/*     */   }
/*     */   
/*     */   public VCenterRecord getVCenter() {
/* 584 */     return this._vCenter;
/*     */   }
/*     */   
/*     */   public HCenterRecord getHCenter() {
/* 588 */     return this._hCenter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLateHeaderFooter(HeaderFooterRecord rec)
/*     */   {
/* 596 */     if (this._headerFooter != null) {
/* 597 */       throw new IllegalStateException("This page settings block already has a header/footer record");
/*     */     }
/* 599 */     if (rec.getSid() != 2204) {
/* 600 */       throw new org.apache.poi.hssf.record.RecordFormatException("Unexpected header-footer record sid: 0x" + Integer.toHexString(rec.getSid()));
/*     */     }
/* 602 */     this._headerFooter = rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLateRecords(RecordStream rs)
/*     */   {
/*     */     for (;;)
/*     */     {
/* 635 */       if (!readARecord(rs)) {
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void positionRecords(List<RecordBase> sheetRecords)
/*     */   {
/* 655 */     List<HeaderFooterRecord> hfRecordsToIterate = new ArrayList(this._sviewHeaderFooters);
/*     */     
/*     */ 
/*     */ 
/* 659 */     for (Iterator i$ = hfRecordsToIterate.iterator(); i$.hasNext();) { hf = (HeaderFooterRecord)i$.next();
/* 660 */       for (RecordBase rb : sheetRecords) {
/* 661 */         if ((rb instanceof CustomViewSettingsRecordAggregate)) {
/* 662 */           final CustomViewSettingsRecordAggregate cv = (CustomViewSettingsRecordAggregate)rb;
/* 663 */           cv.visitContainedRecords(new RecordAggregate.RecordVisitor() {
/*     */             public void visitRecord(Record r) {
/* 665 */               if (r.getSid() == 426) {
/* 666 */                 byte[] guid1 = ((org.apache.poi.hssf.record.UserSViewBegin)r).getGuid();
/* 667 */                 byte[] guid2 = hf.getGuid();
/* 668 */                 if (java.util.Arrays.equals(guid1, guid2)) {
/* 669 */                   cv.append(hf);
/* 670 */                   PageSettingsBlock.this._sviewHeaderFooters.remove(hf);
/*     */                 }
/*     */               }
/*     */             }
/*     */           });
/*     */         }
/*     */       }
/*     */     }
/*     */     final HeaderFooterRecord hf;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\PageSettingsBlock.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */