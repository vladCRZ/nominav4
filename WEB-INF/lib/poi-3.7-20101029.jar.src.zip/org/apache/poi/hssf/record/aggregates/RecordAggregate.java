/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RecordAggregate
/*     */   extends RecordBase
/*     */ {
/*     */   public abstract void visitContainedRecords(RecordVisitor paramRecordVisitor);
/*     */   
/*     */   public final int serialize(int offset, byte[] data)
/*     */   {
/*  41 */     SerializingRecordVisitor srv = new SerializingRecordVisitor(data, offset);
/*  42 */     visitContainedRecords(srv);
/*  43 */     return srv.countBytesWritten();
/*     */   }
/*     */   
/*  46 */   public int getRecordSize() { RecordSizingVisitor rsv = new RecordSizingVisitor();
/*  47 */     visitContainedRecords(rsv);
/*  48 */     return rsv.getTotalSize();
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface RecordVisitor
/*     */   {
/*     */     public abstract void visitRecord(Record paramRecord);
/*     */   }
/*     */   
/*     */   private static final class SerializingRecordVisitor
/*     */     implements RecordAggregate.RecordVisitor
/*     */   {
/*     */     private final byte[] _data;
/*     */     private final int _startOffset;
/*     */     private int _countBytesWritten;
/*     */     
/*     */     public SerializingRecordVisitor(byte[] data, int startOffset)
/*     */     {
/*  66 */       this._data = data;
/*  67 */       this._startOffset = startOffset;
/*  68 */       this._countBytesWritten = 0;
/*     */     }
/*     */     
/*  71 */     public int countBytesWritten() { return this._countBytesWritten; }
/*     */     
/*     */     public void visitRecord(Record r) {
/*  74 */       int currentOffset = this._startOffset + this._countBytesWritten;
/*  75 */       this._countBytesWritten += r.serialize(currentOffset, this._data);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class RecordSizingVisitor implements RecordAggregate.RecordVisitor {
/*     */     private int _totalSize;
/*     */     
/*     */     public RecordSizingVisitor() {
/*  83 */       this._totalSize = 0;
/*     */     }
/*     */     
/*  86 */     public int getTotalSize() { return this._totalSize; }
/*     */     
/*     */     public void visitRecord(Record r) {
/*  89 */       this._totalSize += r.getRecordSize();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class PositionTrackingVisitor
/*     */     implements RecordAggregate.RecordVisitor
/*     */   {
/*     */     private final RecordAggregate.RecordVisitor _rv;
/*     */     private int _position;
/*     */     
/*     */     public PositionTrackingVisitor(RecordAggregate.RecordVisitor rv, int initialPosition)
/*     */     {
/* 101 */       this._rv = rv;
/* 102 */       this._position = initialPosition;
/*     */     }
/*     */     
/* 105 */     public void visitRecord(Record r) { this._position += r.getRecordSize();
/* 106 */       this._rv.visitRecord(r);
/*     */     }
/*     */     
/* 109 */     public void setPosition(int position) { this._position = position; }
/*     */     
/*     */     public int getPosition() {
/* 112 */       return this._position;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\RecordAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */