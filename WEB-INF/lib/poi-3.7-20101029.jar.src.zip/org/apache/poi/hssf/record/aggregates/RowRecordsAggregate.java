/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.CellValueRecordInterface;
/*     */ import org.apache.poi.hssf.record.DBCellRecord.Builder;
/*     */ import org.apache.poi.hssf.record.DimensionsRecord;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.IndexRecord;
/*     */ import org.apache.poi.hssf.record.MulBlankRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RowRecord;
/*     */ import org.apache.poi.hssf.record.UnknownRecord;
/*     */ import org.apache.poi.hssf.record.formula.FormulaShifter;
/*     */ import org.apache.poi.ss.SpreadsheetVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RowRecordsAggregate
/*     */   extends RecordAggregate
/*     */ {
/*  50 */   private int _firstrow = -1;
/*  51 */   private int _lastrow = -1;
/*     */   
/*     */   private final Map<Integer, RowRecord> _rowRecords;
/*     */   
/*     */   private final ValueRecordsAggregate _valuesAgg;
/*     */   private final List<Record> _unknownRecords;
/*     */   private final SharedValueManager _sharedValueManager;
/*     */   
/*  59 */   public RowRecordsAggregate() { this(SharedValueManager.createEmpty()); }
/*     */   
/*     */   private RowRecordsAggregate(SharedValueManager svm) {
/*  62 */     if (svm == null) {
/*  63 */       throw new IllegalArgumentException("SharedValueManager must be provided.");
/*     */     }
/*  65 */     this._rowRecords = new TreeMap();
/*  66 */     this._valuesAgg = new ValueRecordsAggregate();
/*  67 */     this._unknownRecords = new ArrayList();
/*  68 */     this._sharedValueManager = svm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowRecordsAggregate(RecordStream rs, SharedValueManager svm)
/*     */   {
/*  78 */     this(svm);
/*  79 */     while (rs.hasNext()) {
/*  80 */       Record rec = rs.getNext();
/*  81 */       switch (rec.getSid()) {
/*     */       case 520: 
/*  83 */         insertRow((RowRecord)rec);
/*  84 */         break;
/*     */       
/*     */       case 215: 
/*     */         break;
/*     */       
/*     */       default: 
/*  90 */         if ((rec instanceof UnknownRecord))
/*     */         {
/*  92 */           addUnknownRecord(rec);
/*  93 */           while (rs.peekNextSid() == 60) {
/*  94 */             addUnknownRecord(rs.getNext());
/*     */           }
/*     */           
/*     */         }
/*  98 */         else if ((rec instanceof MulBlankRecord)) {
/*  99 */           this._valuesAgg.addMultipleBlanks((MulBlankRecord)rec);
/*     */         }
/*     */         else {
/* 102 */           if (!(rec instanceof CellValueRecordInterface)) {
/* 103 */             throw new RuntimeException("Unexpected record type (" + rec.getClass().getName() + ")");
/*     */           }
/* 105 */           this._valuesAgg.construct((CellValueRecordInterface)rec, rs, svm);
/*     */         }
/*     */         
/*     */ 
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addUnknownRecord(Record rec)
/*     */   {
/* 119 */     this._unknownRecords.add(rec);
/*     */   }
/*     */   
/*     */   public void insertRow(RowRecord row) {
/* 123 */     this._rowRecords.put(Integer.valueOf(row.getRowNumber()), row);
/* 124 */     if ((row.getRowNumber() < this._firstrow) || (this._firstrow == -1)) {
/* 125 */       this._firstrow = row.getRowNumber();
/*     */     }
/* 127 */     if ((row.getRowNumber() > this._lastrow) || (this._lastrow == -1)) {
/* 128 */       this._lastrow = row.getRowNumber();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeRow(RowRecord row) {
/* 133 */     int rowIndex = row.getRowNumber();
/* 134 */     this._valuesAgg.removeAllCellsValuesForRow(rowIndex);
/* 135 */     Integer key = Integer.valueOf(rowIndex);
/* 136 */     RowRecord rr = (RowRecord)this._rowRecords.remove(key);
/* 137 */     if (rr == null) {
/* 138 */       throw new RuntimeException("Invalid row index (" + key.intValue() + ")");
/*     */     }
/* 140 */     if (row != rr) {
/* 141 */       this._rowRecords.put(key, rr);
/* 142 */       throw new RuntimeException("Attempt to remove row that does not belong to this sheet");
/*     */     }
/*     */   }
/*     */   
/*     */   public RowRecord getRow(int rowIndex) {
/* 147 */     int maxrow = SpreadsheetVersion.EXCEL97.getLastRowIndex();
/* 148 */     if ((rowIndex < 0) || (rowIndex > maxrow)) {
/* 149 */       throw new IllegalArgumentException("The row number must be between 0 and " + maxrow);
/*     */     }
/* 151 */     return (RowRecord)this._rowRecords.get(Integer.valueOf(rowIndex));
/*     */   }
/*     */   
/*     */   public int getPhysicalNumberOfRows()
/*     */   {
/* 156 */     return this._rowRecords.size();
/*     */   }
/*     */   
/*     */   public int getFirstRowNum()
/*     */   {
/* 161 */     return this._firstrow;
/*     */   }
/*     */   
/*     */   public int getLastRowNum()
/*     */   {
/* 166 */     return this._lastrow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowBlockCount()
/*     */   {
/* 174 */     int size = this._rowRecords.size() / 32;
/* 175 */     if (this._rowRecords.size() % 32 != 0)
/* 176 */       size++;
/* 177 */     return size;
/*     */   }
/*     */   
/*     */   private int getRowBlockSize(int block) {
/* 181 */     return 20 * getRowCountForBlock(block);
/*     */   }
/*     */   
/*     */   public int getRowCountForBlock(int block)
/*     */   {
/* 186 */     int startIndex = block * 32;
/* 187 */     int endIndex = startIndex + 32 - 1;
/* 188 */     if (endIndex >= this._rowRecords.size()) {
/* 189 */       endIndex = this._rowRecords.size() - 1;
/*     */     }
/* 191 */     return endIndex - startIndex + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getStartRowNumberForBlock(int block)
/*     */   {
/* 200 */     int startIndex = block * 32;
/* 201 */     Iterator<RowRecord> rowIter = this._rowRecords.values().iterator();
/* 202 */     RowRecord row = null;
/*     */     
/* 204 */     for (int i = 0; i <= startIndex; i++) {
/* 205 */       row = (RowRecord)rowIter.next();
/*     */     }
/* 207 */     if (row == null) {
/* 208 */       throw new RuntimeException("Did not find start row for block " + block);
/*     */     }
/*     */     
/* 211 */     return row.getRowNumber();
/*     */   }
/*     */   
/*     */   private int getEndRowNumberForBlock(int block)
/*     */   {
/* 216 */     int endIndex = (block + 1) * 32 - 1;
/* 217 */     if (endIndex >= this._rowRecords.size()) {
/* 218 */       endIndex = this._rowRecords.size() - 1;
/*     */     }
/* 220 */     Iterator<RowRecord> rowIter = this._rowRecords.values().iterator();
/* 221 */     RowRecord row = null;
/* 222 */     for (int i = 0; i <= endIndex; i++) {
/* 223 */       row = (RowRecord)rowIter.next();
/*     */     }
/* 225 */     if (row == null) {
/* 226 */       throw new RuntimeException("Did not find start row for block " + block);
/*     */     }
/* 228 */     return row.getRowNumber();
/*     */   }
/*     */   
/*     */   private int visitRowRecordsForBlock(int blockIndex, RecordAggregate.RecordVisitor rv) {
/* 232 */     int startIndex = blockIndex * 32;
/* 233 */     int endIndex = startIndex + 32;
/*     */     
/* 235 */     Iterator<RowRecord> rowIterator = this._rowRecords.values().iterator();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */     for (int i = 0; 
/* 242 */         i < startIndex; i++)
/* 243 */       rowIterator.next();
/* 244 */     int result = 0;
/* 245 */     while ((rowIterator.hasNext()) && (i++ < endIndex)) {
/* 246 */       Record rec = (Record)rowIterator.next();
/* 247 */       result += rec.getRecordSize();
/* 248 */       rv.visitRecord(rec);
/*     */     }
/* 250 */     return result;
/*     */   }
/*     */   
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv)
/*     */   {
/* 255 */     RecordAggregate.PositionTrackingVisitor stv = new RecordAggregate.PositionTrackingVisitor(rv, 0);
/*     */     
/* 257 */     int blockCount = getRowBlockCount();
/* 258 */     for (int blockIndex = 0; blockIndex < blockCount; blockIndex++)
/*     */     {
/*     */ 
/* 261 */       int pos = 0;
/*     */       
/* 263 */       int rowBlockSize = visitRowRecordsForBlock(blockIndex, rv);
/* 264 */       pos += rowBlockSize;
/*     */       
/* 266 */       int startRowNumber = getStartRowNumberForBlock(blockIndex);
/* 267 */       int endRowNumber = getEndRowNumberForBlock(blockIndex);
/* 268 */       DBCellRecord.Builder dbcrBuilder = new DBCellRecord.Builder();
/*     */       
/* 270 */       int cellRefOffset = rowBlockSize - 20;
/* 271 */       for (int row = startRowNumber; row <= endRowNumber; row++) {
/* 272 */         if (this._valuesAgg.rowHasCells(row)) {
/* 273 */           stv.setPosition(0);
/* 274 */           this._valuesAgg.visitCellsForRow(row, stv);
/* 275 */           int rowCellSize = stv.getPosition();
/* 276 */           pos += rowCellSize;
/*     */           
/*     */ 
/* 279 */           dbcrBuilder.addCellOffset(cellRefOffset);
/* 280 */           cellRefOffset = rowCellSize;
/*     */         }
/*     */       }
/*     */       
/* 284 */       rv.visitRecord(dbcrBuilder.build(pos));
/*     */     }
/* 286 */     for (int i = 0; i < this._unknownRecords.size(); i++)
/*     */     {
/* 288 */       rv.visitRecord((Record)this._unknownRecords.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator<RowRecord> getIterator() {
/* 293 */     return this._rowRecords.values().iterator();
/*     */   }
/*     */   
/*     */   public int findStartOfRowOutlineGroup(int row)
/*     */   {
/* 298 */     RowRecord rowRecord = getRow(row);
/* 299 */     int level = rowRecord.getOutlineLevel();
/* 300 */     int currentRow = row;
/* 301 */     while (getRow(currentRow) != null) {
/* 302 */       rowRecord = getRow(currentRow);
/* 303 */       if (rowRecord.getOutlineLevel() < level) {
/* 304 */         return currentRow + 1;
/*     */       }
/* 306 */       currentRow--;
/*     */     }
/*     */     
/* 309 */     return currentRow + 1;
/*     */   }
/*     */   
/*     */   public int findEndOfRowOutlineGroup(int row) {
/* 313 */     int level = getRow(row).getOutlineLevel();
/*     */     
/* 315 */     for (int currentRow = row; currentRow < getLastRowNum(); currentRow++) {
/* 316 */       if ((getRow(currentRow) == null) || (getRow(currentRow).getOutlineLevel() < level)) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 321 */     return currentRow - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int writeHidden(RowRecord pRowRecord, int row)
/*     */   {
/* 329 */     int rowIx = row;
/* 330 */     RowRecord rowRecord = pRowRecord;
/* 331 */     int level = rowRecord.getOutlineLevel();
/* 332 */     while ((rowRecord != null) && (getRow(rowIx).getOutlineLevel() >= level)) {
/* 333 */       rowRecord.setZeroHeight(true);
/* 334 */       rowIx++;
/* 335 */       rowRecord = getRow(rowIx);
/*     */     }
/* 337 */     return rowIx;
/*     */   }
/*     */   
/*     */ 
/*     */   public void collapseRow(int rowNumber)
/*     */   {
/* 343 */     int startRow = findStartOfRowOutlineGroup(rowNumber);
/* 344 */     RowRecord rowRecord = getRow(startRow);
/*     */     
/*     */ 
/* 347 */     int nextRowIx = writeHidden(rowRecord, startRow);
/*     */     
/* 349 */     RowRecord row = getRow(nextRowIx);
/* 350 */     if (row == null) {
/* 351 */       row = createRow(nextRowIx);
/* 352 */       insertRow(row);
/*     */     }
/*     */     
/* 355 */     row.setColapsed(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RowRecord createRow(int rowNumber)
/*     */   {
/* 366 */     return new RowRecord(rowNumber);
/*     */   }
/*     */   
/*     */   public boolean isRowGroupCollapsed(int row) {
/* 370 */     int collapseRow = findEndOfRowOutlineGroup(row) + 1;
/*     */     
/* 372 */     if (getRow(collapseRow) == null) {
/* 373 */       return false;
/*     */     }
/* 375 */     return getRow(collapseRow).getColapsed();
/*     */   }
/*     */   
/*     */   public void expandRow(int rowNumber) {
/* 379 */     int idx = rowNumber;
/* 380 */     if (idx == -1) {
/* 381 */       return;
/*     */     }
/*     */     
/* 384 */     if (!isRowGroupCollapsed(idx)) {
/* 385 */       return;
/*     */     }
/*     */     
/*     */ 
/* 389 */     int startIdx = findStartOfRowOutlineGroup(idx);
/* 390 */     RowRecord row = getRow(startIdx);
/*     */     
/*     */ 
/* 393 */     int endIdx = findEndOfRowOutlineGroup(idx);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 402 */     if (!isRowGroupHiddenByParent(idx)) {
/* 403 */       for (int i = startIdx; i <= endIdx; i++) {
/* 404 */         RowRecord otherRow = getRow(i);
/* 405 */         if ((row.getOutlineLevel() == otherRow.getOutlineLevel()) || (!isRowGroupCollapsed(i))) {
/* 406 */           otherRow.setZeroHeight(false);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 412 */     getRow(endIdx + 1).setColapsed(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRowGroupHiddenByParent(int row)
/*     */   {
/* 419 */     int endOfOutlineGroupIdx = findEndOfRowOutlineGroup(row);
/* 420 */     boolean endHidden; int endLevel; boolean endHidden; if (getRow(endOfOutlineGroupIdx + 1) == null) {
/* 421 */       int endLevel = 0;
/* 422 */       endHidden = false;
/*     */     } else {
/* 424 */       endLevel = getRow(endOfOutlineGroupIdx + 1).getOutlineLevel();
/* 425 */       endHidden = getRow(endOfOutlineGroupIdx + 1).getZeroHeight();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 431 */     int startOfOutlineGroupIdx = findStartOfRowOutlineGroup(row);
/* 432 */     boolean startHidden; int startLevel; boolean startHidden; if ((startOfOutlineGroupIdx - 1 < 0) || (getRow(startOfOutlineGroupIdx - 1) == null)) {
/* 433 */       int startLevel = 0;
/* 434 */       startHidden = false;
/*     */     } else {
/* 436 */       startLevel = getRow(startOfOutlineGroupIdx - 1).getOutlineLevel();
/* 437 */       startHidden = getRow(startOfOutlineGroupIdx - 1).getZeroHeight();
/*     */     }
/*     */     
/* 440 */     if (endLevel > startLevel) {
/* 441 */       return endHidden;
/*     */     }
/*     */     
/* 444 */     return startHidden;
/*     */   }
/*     */   
/*     */   public CellValueRecordInterface[] getValueRecords() {
/* 448 */     return this._valuesAgg.getValueRecords();
/*     */   }
/*     */   
/*     */   public IndexRecord createIndexRecord(int indexRecordOffset, int sizeOfInitialSheetRecords) {
/* 452 */     IndexRecord result = new IndexRecord();
/* 453 */     result.setFirstRow(this._firstrow);
/* 454 */     result.setLastRowAdd1(this._lastrow + 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 462 */     int blockCount = getRowBlockCount();
/*     */     
/* 464 */     int indexRecSize = IndexRecord.getRecordSizeForBlockCount(blockCount);
/*     */     
/* 466 */     int currentOffset = indexRecordOffset + indexRecSize + sizeOfInitialSheetRecords;
/*     */     
/* 468 */     for (int block = 0; block < blockCount; block++)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 473 */       currentOffset += getRowBlockSize(block);
/*     */       
/* 475 */       currentOffset += this._valuesAgg.getRowCellBlockSize(getStartRowNumberForBlock(block), getEndRowNumberForBlock(block));
/*     */       
/*     */ 
/*     */ 
/* 479 */       result.addDbcell(currentOffset);
/*     */       
/* 481 */       currentOffset += 8 + getRowCountForBlock(block) * 2;
/*     */     }
/* 483 */     return result;
/*     */   }
/*     */   
/* 486 */   public void insertCell(CellValueRecordInterface cvRec) { this._valuesAgg.insertCell(cvRec); }
/*     */   
/*     */   public void removeCell(CellValueRecordInterface cvRec) {
/* 489 */     if ((cvRec instanceof FormulaRecordAggregate)) {
/* 490 */       ((FormulaRecordAggregate)cvRec).notifyFormulaChanging();
/*     */     }
/* 492 */     this._valuesAgg.removeCell(cvRec);
/*     */   }
/*     */   
/* 495 */   public FormulaRecordAggregate createFormula(int row, int col) { FormulaRecord fr = new FormulaRecord();
/* 496 */     fr.setRow(row);
/* 497 */     fr.setColumn((short)col);
/* 498 */     return new FormulaRecordAggregate(fr, null, this._sharedValueManager);
/*     */   }
/*     */   
/* 501 */   public void updateFormulasAfterRowShift(FormulaShifter formulaShifter, int currentExternSheetIndex) { this._valuesAgg.updateFormulasAfterRowShift(formulaShifter, currentExternSheetIndex); }
/*     */   
/*     */   public DimensionsRecord createDimensions() {
/* 504 */     DimensionsRecord result = new DimensionsRecord();
/* 505 */     result.setFirstRow(this._firstrow);
/* 506 */     result.setLastRow(this._lastrow);
/* 507 */     result.setFirstCol((short)this._valuesAgg.getFirstCellNum());
/* 508 */     result.setLastCol((short)this._valuesAgg.getLastCellNum());
/* 509 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\RowRecordsAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */