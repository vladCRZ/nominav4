/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hssf.record.ArrayRecord;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.SharedFormulaRecord;
/*     */ import org.apache.poi.hssf.record.SharedValueRecordBase;
/*     */ import org.apache.poi.hssf.record.TableRecord;
/*     */ import org.apache.poi.hssf.util.CellRangeAddress8Bit;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.ss.util.CellReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SharedValueManager
/*     */ {
/*     */   private final List<ArrayRecord> _arrayRecords;
/*     */   private final TableRecord[] _tableRecords;
/*     */   private final Map<SharedFormulaRecord, SharedFormulaGroup> _groupsBySharedFormulaRecord;
/*     */   private SharedFormulaGroup[] _groups;
/*     */   
/*     */   private static final class SharedFormulaGroup
/*     */   {
/*     */     private final SharedFormulaRecord _sfr;
/*     */     private final FormulaRecordAggregate[] _frAggs;
/*     */     private int _numberOfFormulas;
/*     */     private final CellReference _firstCell;
/*     */     
/*     */     public SharedFormulaGroup(SharedFormulaRecord sfr, CellReference firstCell)
/*     */     {
/*  62 */       if (!sfr.isInRange(firstCell.getRow(), firstCell.getCol())) {
/*  63 */         throw new IllegalArgumentException("First formula cell " + firstCell.formatAsString() + " is not shared formula range " + sfr.getRange().toString() + ".");
/*     */       }
/*     */       
/*  66 */       this._sfr = sfr;
/*  67 */       this._firstCell = firstCell;
/*  68 */       int width = sfr.getLastColumn() - sfr.getFirstColumn() + 1;
/*  69 */       int height = sfr.getLastRow() - sfr.getFirstRow() + 1;
/*  70 */       this._frAggs = new FormulaRecordAggregate[width * height];
/*  71 */       this._numberOfFormulas = 0;
/*     */     }
/*     */     
/*     */     public void add(FormulaRecordAggregate agg) {
/*  75 */       if ((this._numberOfFormulas == 0) && (
/*  76 */         (this._firstCell.getRow() != agg.getRow()) || (this._firstCell.getCol() != agg.getColumn()))) {
/*  77 */         throw new IllegalStateException("shared formula coding error");
/*     */       }
/*     */       
/*  80 */       if (this._numberOfFormulas >= this._frAggs.length) {
/*  81 */         throw new RuntimeException("Too many formula records for shared formula group");
/*     */       }
/*  83 */       this._frAggs[(this._numberOfFormulas++)] = agg;
/*     */     }
/*     */     
/*     */     public void unlinkSharedFormulas() {
/*  87 */       for (int i = 0; i < this._numberOfFormulas; i++) {
/*  88 */         this._frAggs[i].unlinkSharedFormula();
/*     */       }
/*     */     }
/*     */     
/*     */     public SharedFormulaRecord getSFR() {
/*  93 */       return this._sfr;
/*     */     }
/*     */     
/*     */     public final String toString() {
/*  97 */       StringBuffer sb = new StringBuffer(64);
/*  98 */       sb.append(getClass().getName()).append(" [");
/*  99 */       sb.append(this._sfr.getRange().toString());
/* 100 */       sb.append("]");
/* 101 */       return sb.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isFirstCell(int row, int column)
/*     */     {
/* 111 */       return (this._firstCell.getRow() == row) && (this._firstCell.getCol() == column);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SharedValueManager createEmpty()
/*     */   {
/* 120 */     return new SharedValueManager(new SharedFormulaRecord[0], new CellReference[0], new ArrayRecord[0], new TableRecord[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SharedValueManager(SharedFormulaRecord[] sharedFormulaRecords, CellReference[] firstCells, ArrayRecord[] arrayRecords, TableRecord[] tableRecords)
/*     */   {
/* 131 */     int nShF = sharedFormulaRecords.length;
/* 132 */     if (nShF != firstCells.length) {
/* 133 */       throw new IllegalArgumentException("array sizes don't match: " + nShF + "!=" + firstCells.length + ".");
/*     */     }
/* 135 */     this._arrayRecords = toList(arrayRecords);
/* 136 */     this._tableRecords = tableRecords;
/* 137 */     Map<SharedFormulaRecord, SharedFormulaGroup> m = new HashMap(nShF * 3 / 2);
/* 138 */     for (int i = 0; i < nShF; i++) {
/* 139 */       SharedFormulaRecord sfr = sharedFormulaRecords[i];
/* 140 */       m.put(sfr, new SharedFormulaGroup(sfr, firstCells[i]));
/*     */     }
/* 142 */     this._groupsBySharedFormulaRecord = m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static <Z> List<Z> toList(Z[] zz)
/*     */   {
/* 149 */     List<Z> result = new ArrayList(zz.length);
/* 150 */     for (int i = 0; i < zz.length; i++) {
/* 151 */       result.add(zz[i]);
/*     */     }
/* 153 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static SharedValueManager create(SharedFormulaRecord[] sharedFormulaRecords, CellReference[] firstCells, ArrayRecord[] arrayRecords, TableRecord[] tableRecords)
/*     */   {
/* 160 */     if (sharedFormulaRecords.length + firstCells.length + arrayRecords.length + tableRecords.length < 1) {
/* 161 */       return createEmpty();
/*     */     }
/* 163 */     return new SharedValueManager(sharedFormulaRecords, firstCells, arrayRecords, tableRecords);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedFormulaRecord linkSharedFormulaRecord(CellReference firstCell, FormulaRecordAggregate agg)
/*     */   {
/* 173 */     SharedFormulaGroup result = findFormulaGroup(getGroups(), firstCell);
/* 174 */     result.add(agg);
/* 175 */     return result.getSFR();
/*     */   }
/*     */   
/*     */   private static SharedFormulaGroup findFormulaGroup(SharedFormulaGroup[] groups, CellReference firstCell) {
/* 179 */     int row = firstCell.getRow();
/* 180 */     int column = firstCell.getCol();
/*     */     
/*     */ 
/*     */ 
/* 184 */     for (int i = 0; i < groups.length; i++) {
/* 185 */       SharedFormulaGroup svg = groups[i];
/* 186 */       if (svg.isFirstCell(row, column)) {
/* 187 */         return svg;
/*     */       }
/*     */     }
/*     */     
/* 191 */     throw new RuntimeException("Failed to find a matching shared formula record");
/*     */   }
/*     */   
/*     */   private SharedFormulaGroup[] getGroups() {
/* 195 */     if (this._groups == null) {
/* 196 */       SharedFormulaGroup[] groups = new SharedFormulaGroup[this._groupsBySharedFormulaRecord.size()];
/* 197 */       this._groupsBySharedFormulaRecord.values().toArray(groups);
/* 198 */       Arrays.sort(groups, SVGComparator);
/* 199 */       this._groups = groups;
/*     */     }
/* 201 */     return this._groups;
/*     */   }
/*     */   
/* 204 */   private static final Comparator<SharedFormulaGroup> SVGComparator = new Comparator()
/*     */   {
/*     */     public int compare(SharedValueManager.SharedFormulaGroup a, SharedValueManager.SharedFormulaGroup b) {
/* 207 */       CellRangeAddress8Bit rangeA = a.getSFR().getRange();
/* 208 */       CellRangeAddress8Bit rangeB = b.getSFR().getRange();
/*     */       
/*     */ 
/* 211 */       int cmp = rangeA.getFirstRow() - rangeB.getFirstRow();
/* 212 */       if (cmp != 0) {
/* 213 */         return cmp;
/*     */       }
/* 215 */       cmp = rangeA.getFirstColumn() - rangeB.getFirstColumn();
/* 216 */       if (cmp != 0) {
/* 217 */         return cmp;
/*     */       }
/* 219 */       return 0;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SharedValueRecordBase getRecordForFirstCell(FormulaRecordAggregate agg)
/*     */   {
/* 236 */     CellReference firstCell = agg.getFormulaRecord().getFormula().getExpReference();
/*     */     
/*     */ 
/* 239 */     if (firstCell == null)
/*     */     {
/* 241 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 245 */     int row = firstCell.getRow();
/* 246 */     int column = firstCell.getCol();
/* 247 */     if ((agg.getRow() != row) || (agg.getColumn() != column))
/*     */     {
/* 249 */       return null;
/*     */     }
/* 251 */     SharedFormulaGroup[] groups = getGroups();
/* 252 */     for (int i = 0; i < groups.length; i++)
/*     */     {
/*     */ 
/* 255 */       SharedFormulaGroup sfg = groups[i];
/* 256 */       if (sfg.isFirstCell(row, column)) {
/* 257 */         return sfg.getSFR();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 265 */     for (TableRecord tr : this._tableRecords) {
/* 266 */       if (tr.isFirstCell(row, column)) {
/* 267 */         return tr;
/*     */       }
/*     */     }
/* 270 */     for (ArrayRecord ar : this._arrayRecords) {
/* 271 */       if (ar.isFirstCell(row, column)) {
/* 272 */         return ar;
/*     */       }
/*     */     }
/* 275 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unlink(SharedFormulaRecord sharedFormulaRecord)
/*     */   {
/* 283 */     SharedFormulaGroup svg = (SharedFormulaGroup)this._groupsBySharedFormulaRecord.remove(sharedFormulaRecord);
/* 284 */     if (svg == null) {
/* 285 */       throw new IllegalStateException("Failed to find formulas for shared formula");
/*     */     }
/* 287 */     this._groups = null;
/* 288 */     svg.unlinkSharedFormulas();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addArrayRecord(ArrayRecord ar)
/*     */   {
/* 296 */     this._arrayRecords.add(ar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellRangeAddress8Bit removeArrayFormula(int rowIndex, int columnIndex)
/*     */   {
/* 305 */     for (ArrayRecord ar : this._arrayRecords) {
/* 306 */       if (ar.isInRange(rowIndex, columnIndex)) {
/* 307 */         this._arrayRecords.remove(ar);
/* 308 */         return ar.getRange();
/*     */       }
/*     */     }
/* 311 */     String ref = new CellReference(rowIndex, columnIndex, false, false).formatAsString();
/* 312 */     throw new IllegalArgumentException("Specified cell " + ref + " is not part of an array formula.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayRecord getArrayRecord(int firstRow, int firstColumn)
/*     */   {
/* 320 */     for (ArrayRecord ar : this._arrayRecords) {
/* 321 */       if (ar.isFirstCell(firstRow, firstColumn)) {
/* 322 */         return ar;
/*     */       }
/*     */     }
/* 325 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\SharedValueManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */