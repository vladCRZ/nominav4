/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.BlankRecord;
/*     */ import org.apache.poi.hssf.record.CellValueRecordInterface;
/*     */ import org.apache.poi.hssf.record.FormulaRecord;
/*     */ import org.apache.poi.hssf.record.MulBlankRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordBase;
/*     */ import org.apache.poi.hssf.record.StringRecord;
/*     */ import org.apache.poi.hssf.record.formula.FormulaShifter;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueRecordsAggregate
/*     */ {
/*     */   private static final int MAX_ROW_INDEX = 65535;
/*     */   private static final int INDEX_NOT_SET = -1;
/*  46 */   private int firstcell = -1;
/*  47 */   private int lastcell = -1;
/*     */   
/*     */ 
/*     */   private CellValueRecordInterface[][] records;
/*     */   
/*     */ 
/*  53 */   public ValueRecordsAggregate() { this(-1, -1, new CellValueRecordInterface[30][]); }
/*     */   
/*     */   private ValueRecordsAggregate(int firstCellIx, int lastCellIx, CellValueRecordInterface[][] pRecords) {
/*  56 */     this.firstcell = firstCellIx;
/*  57 */     this.lastcell = lastCellIx;
/*  58 */     this.records = pRecords;
/*     */   }
/*     */   
/*     */   public void insertCell(CellValueRecordInterface cell) {
/*  62 */     short column = cell.getColumn();
/*  63 */     int row = cell.getRow();
/*  64 */     if (row >= this.records.length) {
/*  65 */       CellValueRecordInterface[][] oldRecords = this.records;
/*  66 */       int newSize = oldRecords.length * 2;
/*  67 */       if (newSize < row + 1)
/*  68 */         newSize = row + 1;
/*  69 */       this.records = new CellValueRecordInterface[newSize][];
/*  70 */       System.arraycopy(oldRecords, 0, this.records, 0, oldRecords.length);
/*     */     }
/*  72 */     CellValueRecordInterface[] rowCells = this.records[row];
/*  73 */     if (rowCells == null) {
/*  74 */       int newSize = column + 1;
/*  75 */       if (newSize < 10)
/*  76 */         newSize = 10;
/*  77 */       rowCells = new CellValueRecordInterface[newSize];
/*  78 */       this.records[row] = rowCells;
/*     */     }
/*  80 */     if (column >= rowCells.length) {
/*  81 */       CellValueRecordInterface[] oldRowCells = rowCells;
/*  82 */       int newSize = oldRowCells.length * 2;
/*  83 */       if (newSize < column + 1) {
/*  84 */         newSize = column + 1;
/*     */       }
/*  86 */       rowCells = new CellValueRecordInterface[newSize];
/*  87 */       System.arraycopy(oldRowCells, 0, rowCells, 0, oldRowCells.length);
/*  88 */       this.records[row] = rowCells;
/*     */     }
/*  90 */     rowCells[column] = cell;
/*     */     
/*  92 */     if ((column < this.firstcell) || (this.firstcell == -1)) {
/*  93 */       this.firstcell = column;
/*     */     }
/*  95 */     if ((column > this.lastcell) || (this.lastcell == -1)) {
/*  96 */       this.lastcell = column;
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeCell(CellValueRecordInterface cell) {
/* 101 */     if (cell == null) {
/* 102 */       throw new IllegalArgumentException("cell must not be null");
/*     */     }
/* 104 */     int row = cell.getRow();
/* 105 */     if (row >= this.records.length) {
/* 106 */       throw new RuntimeException("cell row is out of range");
/*     */     }
/* 108 */     CellValueRecordInterface[] rowCells = this.records[row];
/* 109 */     if (rowCells == null) {
/* 110 */       throw new RuntimeException("cell row is already empty");
/*     */     }
/* 112 */     short column = cell.getColumn();
/* 113 */     if (column >= rowCells.length) {
/* 114 */       throw new RuntimeException("cell column is out of range");
/*     */     }
/* 116 */     rowCells[column] = null;
/*     */   }
/*     */   
/*     */   public void removeAllCellsValuesForRow(int rowIndex) {
/* 120 */     if ((rowIndex < 0) || (rowIndex > 65535)) {
/* 121 */       throw new IllegalArgumentException("Specified rowIndex " + rowIndex + " is outside the allowable range (0.." + 65535 + ")");
/*     */     }
/*     */     
/* 124 */     if (rowIndex >= this.records.length)
/*     */     {
/*     */ 
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     this.records[rowIndex] = null;
/*     */   }
/*     */   
/*     */   public int getPhysicalNumberOfCells()
/*     */   {
/* 135 */     int count = 0;
/* 136 */     for (int r = 0; r < this.records.length; r++) {
/* 137 */       CellValueRecordInterface[] rowCells = this.records[r];
/* 138 */       if (rowCells != null) {
/* 139 */         for (int c = 0; c < rowCells.length; c++) {
/* 140 */           if (rowCells[c] != null)
/* 141 */             count++;
/*     */         }
/*     */       }
/*     */     }
/* 145 */     return count;
/*     */   }
/*     */   
/*     */   public int getFirstCellNum() {
/* 149 */     return this.firstcell;
/*     */   }
/*     */   
/*     */   public int getLastCellNum() {
/* 153 */     return this.lastcell;
/*     */   }
/*     */   
/*     */   public void addMultipleBlanks(MulBlankRecord mbr) {
/* 157 */     for (int j = 0; j < mbr.getNumColumns(); j++) {
/* 158 */       BlankRecord br = new BlankRecord();
/*     */       
/* 160 */       br.setColumn((short)(j + mbr.getFirstColumn()));
/* 161 */       br.setRow(mbr.getRow());
/* 162 */       br.setXFIndex(mbr.getXFAt(j));
/* 163 */       insertCell(br);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void construct(CellValueRecordInterface rec, RecordStream rs, SharedValueManager sfh)
/*     */   {
/* 172 */     if ((rec instanceof FormulaRecord)) {
/* 173 */       FormulaRecord formulaRec = (FormulaRecord)rec;
/*     */       
/*     */ 
/* 176 */       Class<? extends Record> nextClass = rs.peekNextClass();
/* 177 */       StringRecord cachedText; StringRecord cachedText; if (nextClass == StringRecord.class) {
/* 178 */         cachedText = (StringRecord)rs.getNext();
/*     */       } else {
/* 180 */         cachedText = null;
/*     */       }
/* 182 */       insertCell(new FormulaRecordAggregate(formulaRec, cachedText, sfh));
/*     */     } else {
/* 184 */       insertCell(rec);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRowCellBlockSize(int startRow, int endRow)
/*     */   {
/* 192 */     int result = 0;
/* 193 */     for (int rowIx = startRow; (rowIx <= endRow) && (rowIx < this.records.length); rowIx++) {
/* 194 */       result += getRowSerializedSize(this.records[rowIx]);
/*     */     }
/* 196 */     return result;
/*     */   }
/*     */   
/*     */   public boolean rowHasCells(int row)
/*     */   {
/* 201 */     if (row >= this.records.length) {
/* 202 */       return false;
/*     */     }
/* 204 */     CellValueRecordInterface[] rowCells = this.records[row];
/* 205 */     if (rowCells == null) return false;
/* 206 */     for (int col = 0; col < rowCells.length; col++) {
/* 207 */       if (rowCells[col] != null) return true;
/*     */     }
/* 209 */     return false;
/*     */   }
/*     */   
/*     */   private static int getRowSerializedSize(CellValueRecordInterface[] rowCells) {
/* 213 */     if (rowCells == null) {
/* 214 */       return 0;
/*     */     }
/* 216 */     int result = 0;
/* 217 */     for (int i = 0; i < rowCells.length; i++) {
/* 218 */       RecordBase cvr = (RecordBase)rowCells[i];
/* 219 */       if (cvr != null)
/*     */       {
/*     */ 
/* 222 */         int nBlank = countBlanks(rowCells, i);
/* 223 */         if (nBlank > 1) {
/* 224 */           result += 10 + 2 * nBlank;
/* 225 */           i += nBlank - 1;
/*     */         } else {
/* 227 */           result += cvr.getRecordSize();
/*     */         }
/*     */       } }
/* 230 */     return result;
/*     */   }
/*     */   
/*     */   public void visitCellsForRow(int rowIndex, RecordAggregate.RecordVisitor rv)
/*     */   {
/* 235 */     CellValueRecordInterface[] rowCells = this.records[rowIndex];
/* 236 */     if (rowCells == null) {
/* 237 */       throw new IllegalArgumentException("Row [" + rowIndex + "] is empty");
/*     */     }
/*     */     
/*     */ 
/* 241 */     for (int i = 0; i < rowCells.length; i++) {
/* 242 */       RecordBase cvr = (RecordBase)rowCells[i];
/* 243 */       if (cvr != null)
/*     */       {
/*     */ 
/* 246 */         int nBlank = countBlanks(rowCells, i);
/* 247 */         if (nBlank > 1) {
/* 248 */           rv.visitRecord(createMBR(rowCells, i, nBlank));
/* 249 */           i += nBlank - 1;
/* 250 */         } else if ((cvr instanceof RecordAggregate)) {
/* 251 */           RecordAggregate agg = (RecordAggregate)cvr;
/* 252 */           agg.visitContainedRecords(rv);
/*     */         } else {
/* 254 */           rv.visitRecord((Record)cvr);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int countBlanks(CellValueRecordInterface[] rowCellValues, int startIx)
/*     */   {
/* 264 */     int i = startIx;
/* 265 */     while (i < rowCellValues.length) {
/* 266 */       CellValueRecordInterface cvr = rowCellValues[i];
/* 267 */       if (!(cvr instanceof BlankRecord)) {
/*     */         break;
/*     */       }
/* 270 */       i++;
/*     */     }
/* 272 */     return i - startIx;
/*     */   }
/*     */   
/*     */   private MulBlankRecord createMBR(CellValueRecordInterface[] cellValues, int startIx, int nBlank)
/*     */   {
/* 277 */     short[] xfs = new short[nBlank];
/* 278 */     for (int i = 0; i < xfs.length; i++) {
/* 279 */       xfs[i] = ((BlankRecord)cellValues[(startIx + i)]).getXFIndex();
/*     */     }
/* 281 */     int rowIx = cellValues[startIx].getRow();
/* 282 */     return new MulBlankRecord(rowIx, startIx, xfs);
/*     */   }
/*     */   
/*     */   public void updateFormulasAfterRowShift(FormulaShifter shifter, int currentExternSheetIndex) {
/* 286 */     for (int i = 0; i < this.records.length; i++) {
/* 287 */       CellValueRecordInterface[] rowCells = this.records[i];
/* 288 */       if (rowCells != null)
/*     */       {
/*     */ 
/* 291 */         for (int j = 0; j < rowCells.length; j++) {
/* 292 */           CellValueRecordInterface cell = rowCells[j];
/* 293 */           if ((cell instanceof FormulaRecordAggregate)) {
/* 294 */             FormulaRecord fr = ((FormulaRecordAggregate)cell).getFormulaRecord();
/* 295 */             Ptg[] ptgs = fr.getParsedExpression();
/* 296 */             if (shifter.adjustFormula(ptgs, currentExternSheetIndex)) {
/* 297 */               fr.setParsedExpression(ptgs);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CellValueRecordInterface[] getValueRecords()
/*     */   {
/* 309 */     List<CellValueRecordInterface> temp = new ArrayList();
/*     */     
/* 311 */     for (int rowIx = 0; rowIx < this.records.length; rowIx++) {
/* 312 */       CellValueRecordInterface[] rowCells = this.records[rowIx];
/* 313 */       if (rowCells != null)
/*     */       {
/*     */ 
/* 316 */         for (int colIx = 0; colIx < rowCells.length; colIx++) {
/* 317 */           CellValueRecordInterface cell = rowCells[colIx];
/* 318 */           if (cell != null) {
/* 319 */             temp.add(cell);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 324 */     CellValueRecordInterface[] result = new CellValueRecordInterface[temp.size()];
/* 325 */     temp.toArray(result);
/* 326 */     return result;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 330 */     throw new RuntimeException("clone() should not be called.  ValueRecordsAggregate should be copied via Sheet.cloneSheet()");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\ValueRecordsAggregate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */