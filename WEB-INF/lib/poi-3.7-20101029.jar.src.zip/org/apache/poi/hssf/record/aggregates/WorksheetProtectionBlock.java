/*     */ package org.apache.poi.hssf.record.aggregates;
/*     */ 
/*     */ import org.apache.poi.hssf.model.RecordStream;
/*     */ import org.apache.poi.hssf.record.ObjectProtectRecord;
/*     */ import org.apache.poi.hssf.record.PasswordRecord;
/*     */ import org.apache.poi.hssf.record.ProtectRecord;
/*     */ import org.apache.poi.hssf.record.Record;
/*     */ import org.apache.poi.hssf.record.RecordFormatException;
/*     */ import org.apache.poi.hssf.record.ScenarioProtectRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WorksheetProtectionBlock
/*     */   extends RecordAggregate
/*     */ {
/*     */   private ProtectRecord _protectRecord;
/*     */   private ObjectProtectRecord _objectProtectRecord;
/*     */   private ScenarioProtectRecord _scenarioProtectRecord;
/*     */   private PasswordRecord _passwordRecord;
/*     */   
/*     */   public static boolean isComponentRecord(int sid)
/*     */   {
/*  57 */     switch (sid) {
/*     */     case 18: 
/*     */     case 19: 
/*     */     case 99: 
/*     */     case 221: 
/*  62 */       return true;
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */   
/*     */   private boolean readARecord(RecordStream rs) {
/*  68 */     switch (rs.peekNextSid()) {
/*     */     case 18: 
/*  70 */       checkNotPresent(this._protectRecord);
/*  71 */       this._protectRecord = ((ProtectRecord)rs.getNext());
/*  72 */       break;
/*     */     case 99: 
/*  74 */       checkNotPresent(this._objectProtectRecord);
/*  75 */       this._objectProtectRecord = ((ObjectProtectRecord)rs.getNext());
/*  76 */       break;
/*     */     case 221: 
/*  78 */       checkNotPresent(this._scenarioProtectRecord);
/*  79 */       this._scenarioProtectRecord = ((ScenarioProtectRecord)rs.getNext());
/*  80 */       break;
/*     */     case 19: 
/*  82 */       checkNotPresent(this._passwordRecord);
/*  83 */       this._passwordRecord = ((PasswordRecord)rs.getNext());
/*  84 */       break;
/*     */     
/*     */     default: 
/*  87 */       return false;
/*     */     }
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   private void checkNotPresent(Record rec) {
/*  93 */     if (rec != null) {
/*  94 */       throw new RecordFormatException("Duplicate PageSettingsBlock record (sid=0x" + Integer.toHexString(rec.getSid()) + ")");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void visitContainedRecords(RecordAggregate.RecordVisitor rv)
/*     */   {
/* 102 */     visitIfPresent(this._protectRecord, rv);
/* 103 */     visitIfPresent(this._objectProtectRecord, rv);
/* 104 */     visitIfPresent(this._scenarioProtectRecord, rv);
/* 105 */     visitIfPresent(this._passwordRecord, rv);
/*     */   }
/*     */   
/*     */   private static void visitIfPresent(Record r, RecordAggregate.RecordVisitor rv) {
/* 109 */     if (r != null) {
/* 110 */       rv.visitRecord(r);
/*     */     }
/*     */   }
/*     */   
/*     */   public PasswordRecord getPasswordRecord() {
/* 115 */     return this._passwordRecord;
/*     */   }
/*     */   
/*     */   public ScenarioProtectRecord getHCenter() {
/* 119 */     return this._scenarioProtectRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRecords(RecordStream rs)
/*     */   {
/*     */     for (;;)
/*     */     {
/* 140 */       if (!readARecord(rs)) {
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ProtectRecord getProtect()
/*     */   {
/* 151 */     if (this._protectRecord == null) {
/* 152 */       this._protectRecord = new ProtectRecord(false);
/*     */     }
/* 154 */     return this._protectRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PasswordRecord getPassword()
/*     */   {
/* 162 */     if (this._passwordRecord == null) {
/* 163 */       this._passwordRecord = createPassword();
/*     */     }
/* 165 */     return this._passwordRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void protectSheet(String password, boolean shouldProtectObjects, boolean shouldProtectScenarios)
/*     */   {
/* 178 */     if (password == null) {
/* 179 */       this._passwordRecord = null;
/* 180 */       this._protectRecord = null;
/* 181 */       this._objectProtectRecord = null;
/* 182 */       this._scenarioProtectRecord = null;
/* 183 */       return;
/*     */     }
/*     */     
/* 186 */     ProtectRecord prec = getProtect();
/* 187 */     PasswordRecord pass = getPassword();
/* 188 */     prec.setProtect(true);
/* 189 */     pass.setPassword(PasswordRecord.hashPassword(password));
/* 190 */     if ((this._objectProtectRecord == null) && (shouldProtectObjects)) {
/* 191 */       ObjectProtectRecord rec = createObjectProtect();
/* 192 */       rec.setProtect(true);
/* 193 */       this._objectProtectRecord = rec;
/*     */     }
/* 195 */     if ((this._scenarioProtectRecord == null) && (shouldProtectScenarios)) {
/* 196 */       ScenarioProtectRecord srec = createScenarioProtect();
/* 197 */       srec.setProtect(true);
/* 198 */       this._scenarioProtectRecord = srec;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isSheetProtected() {
/* 203 */     return (this._protectRecord != null) && (this._protectRecord.getProtect());
/*     */   }
/*     */   
/*     */   public boolean isObjectProtected() {
/* 207 */     return (this._objectProtectRecord != null) && (this._objectProtectRecord.getProtect());
/*     */   }
/*     */   
/*     */   public boolean isScenarioProtected() {
/* 211 */     return (this._scenarioProtectRecord != null) && (this._scenarioProtectRecord.getProtect());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static ObjectProtectRecord createObjectProtect()
/*     */   {
/* 218 */     ObjectProtectRecord retval = new ObjectProtectRecord();
/* 219 */     retval.setProtect(false);
/* 220 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static ScenarioProtectRecord createScenarioProtect()
/*     */   {
/* 227 */     ScenarioProtectRecord retval = new ScenarioProtectRecord();
/* 228 */     retval.setProtect(false);
/* 229 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static PasswordRecord createPassword()
/*     */   {
/* 236 */     return new PasswordRecord(0);
/*     */   }
/*     */   
/*     */   public int getPasswordHash() {
/* 240 */     if (this._passwordRecord == null) {
/* 241 */       return 0;
/*     */     }
/* 243 */     return this._passwordRecord.getPassword();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\aggregates\WorksheetProtectionBlock.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */