/*     */ package org.apache.poi.hssf.record.cf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.ss.util.CellRangeAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CellRangeUtil
/*     */ {
/*     */   public static final int NO_INTERSECTION = 1;
/*     */   public static final int OVERLAP = 2;
/*     */   public static final int INSIDE = 3;
/*     */   public static final int ENCLOSES = 4;
/*     */   
/*     */   public static int intersect(CellRangeAddress crA, CellRangeAddress crB)
/*     */   {
/*  57 */     int firstRow = crB.getFirstRow();
/*  58 */     int lastRow = crB.getLastRow();
/*  59 */     int firstCol = crB.getFirstColumn();
/*  60 */     int lastCol = crB.getLastColumn();
/*     */     
/*  62 */     if ((gt(crA.getFirstRow(), lastRow)) || (lt(crA.getLastRow(), firstRow)) || (gt(crA.getFirstColumn(), lastCol)) || (lt(crA.getLastColumn(), firstCol)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */       return 1;
/*     */     }
/*  72 */     if (contains(crA, crB))
/*     */     {
/*  74 */       return 3;
/*     */     }
/*  76 */     if (contains(crB, crA))
/*     */     {
/*  78 */       return 4;
/*     */     }
/*     */     
/*     */ 
/*  82 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CellRangeAddress[] mergeCellRanges(CellRangeAddress[] cellRanges)
/*     */   {
/*  95 */     if (cellRanges.length < 1) {
/*  96 */       return cellRanges;
/*     */     }
/*     */     
/*  99 */     List<CellRangeAddress> lst = new ArrayList();
/* 100 */     for (CellRangeAddress cr : cellRanges) lst.add(cr);
/* 101 */     List temp = mergeCellRanges(lst);
/* 102 */     return toArray(temp);
/*     */   }
/*     */   
/*     */   private static List mergeCellRanges(List cellRangeList)
/*     */   {
/* 107 */     while (cellRangeList.size() > 1)
/*     */     {
/* 109 */       boolean somethingGotMerged = false;
/*     */       
/* 111 */       for (int i = 0; i < cellRangeList.size(); i++)
/*     */       {
/* 113 */         CellRangeAddress range1 = (CellRangeAddress)cellRangeList.get(i);
/* 114 */         for (int j = i + 1; j < cellRangeList.size(); j++)
/*     */         {
/* 116 */           CellRangeAddress range2 = (CellRangeAddress)cellRangeList.get(j);
/*     */           
/* 118 */           CellRangeAddress[] mergeResult = mergeRanges(range1, range2);
/* 119 */           if (mergeResult != null)
/*     */           {
/*     */ 
/* 122 */             somethingGotMerged = true;
/*     */             
/* 124 */             cellRangeList.set(i, mergeResult[0]);
/*     */             
/* 126 */             cellRangeList.remove(j--);
/*     */             
/* 128 */             for (int k = 1; k < mergeResult.length; k++) {
/* 129 */               j++;
/* 130 */               cellRangeList.add(j, mergeResult[k]);
/*     */             }
/*     */           }
/*     */         } }
/* 134 */       if (!somethingGotMerged) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 140 */     return cellRangeList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static CellRangeAddress[] mergeRanges(CellRangeAddress range1, CellRangeAddress range2)
/*     */   {
/* 148 */     int x = intersect(range1, range2);
/* 149 */     switch (x)
/*     */     {
/*     */     case 1: 
/* 152 */       if (hasExactSharedBorder(range1, range2)) {
/* 153 */         return new CellRangeAddress[] { createEnclosingCellRange(range1, range2) };
/*     */       }
/*     */       
/* 156 */       return null;
/*     */     case 2: 
/* 158 */       return resolveRangeOverlap(range1, range2);
/*     */     
/*     */     case 3: 
/* 161 */       return new CellRangeAddress[] { range1 };
/*     */     
/*     */     case 4: 
/* 164 */       return new CellRangeAddress[] { range2 };
/*     */     }
/* 166 */     throw new RuntimeException("unexpected intersection result (" + x + ")");
/*     */   }
/*     */   
/*     */ 
/*     */   static CellRangeAddress[] resolveRangeOverlap(CellRangeAddress rangeA, CellRangeAddress rangeB)
/*     */   {
/* 172 */     if (rangeA.isFullColumnRange()) {
/* 173 */       if (rangeA.isFullRowRange())
/*     */       {
/* 175 */         return null;
/*     */       }
/* 177 */       return sliceUp(rangeA, rangeB);
/*     */     }
/* 179 */     if (rangeA.isFullRowRange()) {
/* 180 */       if (rangeB.isFullColumnRange())
/*     */       {
/* 182 */         return null;
/*     */       }
/* 184 */       return sliceUp(rangeA, rangeB);
/*     */     }
/* 186 */     if (rangeB.isFullColumnRange()) {
/* 187 */       return sliceUp(rangeB, rangeA);
/*     */     }
/* 189 */     if (rangeB.isFullRowRange()) {
/* 190 */       return sliceUp(rangeB, rangeA);
/*     */     }
/* 192 */     return sliceUp(rangeA, rangeB);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static CellRangeAddress[] sliceUp(CellRangeAddress crA, CellRangeAddress crB)
/*     */   {
/* 202 */     List temp = new ArrayList();
/*     */     
/*     */ 
/* 205 */     temp.add(crB);
/* 206 */     if (!crA.isFullColumnRange()) {
/* 207 */       temp = cutHorizontally(crA.getFirstRow(), temp);
/* 208 */       temp = cutHorizontally(crA.getLastRow() + 1, temp);
/*     */     }
/* 210 */     if (!crA.isFullRowRange()) {
/* 211 */       temp = cutVertically(crA.getFirstColumn(), temp);
/* 212 */       temp = cutVertically(crA.getLastColumn() + 1, temp);
/*     */     }
/* 214 */     CellRangeAddress[] crParts = toArray(temp);
/*     */     
/*     */ 
/* 217 */     temp.clear();
/* 218 */     temp.add(crA);
/*     */     
/* 220 */     for (int i = 0; i < crParts.length; i++) {
/* 221 */       CellRangeAddress crPart = crParts[i];
/*     */       
/* 223 */       if (intersect(crA, crPart) != 4) {
/* 224 */         temp.add(crPart);
/*     */       }
/*     */     }
/* 227 */     return toArray(temp);
/*     */   }
/*     */   
/*     */   private static List cutHorizontally(int cutRow, List input)
/*     */   {
/* 232 */     List result = new ArrayList();
/* 233 */     CellRangeAddress[] crs = toArray(input);
/* 234 */     for (int i = 0; i < crs.length; i++) {
/* 235 */       CellRangeAddress cr = crs[i];
/* 236 */       if ((cr.getFirstRow() < cutRow) && (cutRow < cr.getLastRow())) {
/* 237 */         result.add(new CellRangeAddress(cr.getFirstRow(), cutRow, cr.getFirstColumn(), cr.getLastColumn()));
/* 238 */         result.add(new CellRangeAddress(cutRow + 1, cr.getLastRow(), cr.getFirstColumn(), cr.getLastColumn()));
/*     */       } else {
/* 240 */         result.add(cr);
/*     */       }
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */   
/*     */   private static List cutVertically(int cutColumn, List input) {
/* 247 */     List result = new ArrayList();
/* 248 */     CellRangeAddress[] crs = toArray(input);
/* 249 */     for (int i = 0; i < crs.length; i++) {
/* 250 */       CellRangeAddress cr = crs[i];
/* 251 */       if ((cr.getFirstColumn() < cutColumn) && (cutColumn < cr.getLastColumn())) {
/* 252 */         result.add(new CellRangeAddress(cr.getFirstRow(), cr.getLastRow(), cr.getFirstColumn(), cutColumn));
/* 253 */         result.add(new CellRangeAddress(cr.getFirstRow(), cr.getLastRow(), cutColumn + 1, cr.getLastColumn()));
/*     */       } else {
/* 255 */         result.add(cr);
/*     */       }
/*     */     }
/* 258 */     return result;
/*     */   }
/*     */   
/*     */   private static CellRangeAddress[] toArray(List temp)
/*     */   {
/* 263 */     CellRangeAddress[] result = new CellRangeAddress[temp.size()];
/* 264 */     temp.toArray(result);
/* 265 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean contains(CellRangeAddress crA, CellRangeAddress crB)
/*     */   {
/* 278 */     int firstRow = crB.getFirstRow();
/* 279 */     int lastRow = crB.getLastRow();
/* 280 */     int firstCol = crB.getFirstColumn();
/* 281 */     int lastCol = crB.getLastColumn();
/* 282 */     return (le(crA.getFirstRow(), firstRow)) && (ge(crA.getLastRow(), lastRow)) && (le(crA.getFirstColumn(), firstCol)) && (ge(crA.getLastColumn(), lastCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean hasExactSharedBorder(CellRangeAddress crA, CellRangeAddress crB)
/*     */   {
/* 293 */     int oFirstRow = crB.getFirstRow();
/* 294 */     int oLastRow = crB.getLastRow();
/* 295 */     int oFirstCol = crB.getFirstColumn();
/* 296 */     int oLastCol = crB.getLastColumn();
/*     */     
/* 298 */     if (((crA.getFirstRow() > 0) && (crA.getFirstRow() - 1 == oLastRow)) || ((oFirstRow > 0) && (oFirstRow - 1 == crA.getLastRow())))
/*     */     {
/*     */ 
/*     */ 
/* 302 */       return (crA.getFirstColumn() == oFirstCol) && (crA.getLastColumn() == oLastCol);
/*     */     }
/*     */     
/* 305 */     if (((crA.getFirstColumn() > 0) && (crA.getFirstColumn() - 1 == oLastCol)) || ((oFirstCol > 0) && (crA.getLastColumn() == oFirstCol - 1)))
/*     */     {
/*     */ 
/*     */ 
/* 309 */       return (crA.getFirstRow() == oFirstRow) && (crA.getLastRow() == oLastRow);
/*     */     }
/* 311 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CellRangeAddress createEnclosingCellRange(CellRangeAddress crA, CellRangeAddress crB)
/*     */   {
/* 320 */     if (crB == null) {
/* 321 */       return crA.copy();
/*     */     }
/*     */     
/* 324 */     return new CellRangeAddress(lt(crB.getFirstRow(), crA.getFirstRow()) ? crB.getFirstRow() : crA.getFirstRow(), gt(crB.getLastRow(), crA.getLastRow()) ? crB.getLastRow() : crA.getLastRow(), lt(crB.getFirstColumn(), crA.getFirstColumn()) ? crB.getFirstColumn() : crA.getFirstColumn(), gt(crB.getLastColumn(), crA.getLastColumn()) ? crB.getLastColumn() : crA.getLastColumn());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean lt(int a, int b)
/*     */   {
/* 339 */     return a != -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean le(int a, int b)
/*     */   {
/* 347 */     return (a == b) || (lt(a, b));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean gt(int a, int b)
/*     */   {
/* 355 */     return lt(b, a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean ge(int a, int b)
/*     */   {
/* 363 */     return !lt(a, b);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\cf\CellRangeUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */