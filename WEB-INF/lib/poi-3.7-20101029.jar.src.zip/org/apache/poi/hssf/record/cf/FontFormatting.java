/*     */ package org.apache.poi.hssf.record.cf;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndian;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FontFormatting
/*     */ {
/*     */   private byte[] _rawData;
/*     */   private static final int OFFSET_FONT_NAME = 0;
/*     */   private static final int OFFSET_FONT_HEIGHT = 64;
/*     */   private static final int OFFSET_FONT_OPTIONS = 68;
/*     */   private static final int OFFSET_FONT_WEIGHT = 72;
/*     */   private static final int OFFSET_ESCAPEMENT_TYPE = 74;
/*     */   private static final int OFFSET_UNDERLINE_TYPE = 76;
/*     */   private static final int OFFSET_FONT_COLOR_INDEX = 80;
/*     */   private static final int OFFSET_OPTION_FLAGS = 88;
/*     */   private static final int OFFSET_ESCAPEMENT_TYPE_MODIFIED = 92;
/*     */   private static final int OFFSET_UNDERLINE_TYPE_MODIFIED = 96;
/*     */   private static final int OFFSET_FONT_WEIGHT_MODIFIED = 100;
/*     */   private static final int OFFSET_NOT_USED1 = 104;
/*     */   private static final int OFFSET_NOT_USED2 = 108;
/*     */   private static final int OFFSET_NOT_USED3 = 112;
/*     */   private static final int OFFSET_FONT_FORMATING_END = 116;
/*     */   private static final int RAW_DATA_SIZE = 118;
/*     */   public static final int FONT_CELL_HEIGHT_PRESERVED = -1;
/*  56 */   private static final BitField posture = BitFieldFactory.getInstance(2);
/*  57 */   private static final BitField outline = BitFieldFactory.getInstance(8);
/*  58 */   private static final BitField shadow = BitFieldFactory.getInstance(16);
/*  59 */   private static final BitField cancellation = BitFieldFactory.getInstance(128);
/*     */   
/*     */ 
/*     */ 
/*  63 */   private static final BitField styleModified = BitFieldFactory.getInstance(2);
/*  64 */   private static final BitField outlineModified = BitFieldFactory.getInstance(8);
/*  65 */   private static final BitField shadowModified = BitFieldFactory.getInstance(16);
/*  66 */   private static final BitField cancellationModified = BitFieldFactory.getInstance(128);
/*     */   
/*     */ 
/*     */   public static final short SS_NONE = 0;
/*     */   
/*     */ 
/*     */   public static final short SS_SUPER = 1;
/*     */   
/*     */   public static final short SS_SUB = 2;
/*     */   
/*     */   public static final byte U_NONE = 0;
/*     */   
/*     */   public static final byte U_SINGLE = 1;
/*     */   
/*     */   public static final byte U_DOUBLE = 2;
/*     */   
/*     */   public static final byte U_SINGLE_ACCOUNTING = 33;
/*     */   
/*     */   public static final byte U_DOUBLE_ACCOUNTING = 34;
/*     */   
/*     */   private static final short FONT_WEIGHT_NORMAL = 400;
/*     */   
/*     */   private static final short FONT_WEIGHT_BOLD = 700;
/*     */   
/*     */ 
/*     */   private FontFormatting(byte[] rawData)
/*     */   {
/*  93 */     this._rawData = rawData;
/*     */   }
/*     */   
/*     */   public FontFormatting()
/*     */   {
/*  98 */     this(new byte[118]);
/*     */     
/* 100 */     setFontHeight(-1);
/* 101 */     setItalic(false);
/* 102 */     setFontWieghtModified(false);
/* 103 */     setOutline(false);
/* 104 */     setShadow(false);
/* 105 */     setStrikeout(false);
/* 106 */     setEscapementType((short)0);
/* 107 */     setUnderlineType((short)0);
/* 108 */     setFontColorIndex((short)-1);
/*     */     
/* 110 */     setFontStyleModified(false);
/* 111 */     setFontOutlineModified(false);
/* 112 */     setFontShadowModified(false);
/* 113 */     setFontCancellationModified(false);
/*     */     
/* 115 */     setEscapementTypeModified(false);
/* 116 */     setUnderlineTypeModified(false);
/*     */     
/* 118 */     setShort(0, 0);
/* 119 */     setInt(104, 1);
/* 120 */     setInt(108, 0);
/* 121 */     setInt(112, Integer.MAX_VALUE);
/* 122 */     setShort(116, 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public FontFormatting(RecordInputStream in)
/*     */   {
/* 128 */     this(new byte[118]);
/* 129 */     for (int i = 0; i < this._rawData.length; i++)
/*     */     {
/* 131 */       this._rawData[i] = in.readByte();
/*     */     }
/*     */   }
/*     */   
/*     */   private short getShort(int offset) {
/* 136 */     return LittleEndian.getShort(this._rawData, offset);
/*     */   }
/*     */   
/* 139 */   private void setShort(int offset, int value) { LittleEndian.putShort(this._rawData, offset, (short)value); }
/*     */   
/*     */   private int getInt(int offset) {
/* 142 */     return LittleEndian.getInt(this._rawData, offset);
/*     */   }
/*     */   
/* 145 */   private void setInt(int offset, int value) { LittleEndian.putInt(this._rawData, offset, value); }
/*     */   
/*     */ 
/*     */   public byte[] getRawRecord()
/*     */   {
/* 150 */     return this._rawData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontHeight(int height)
/*     */   {
/* 162 */     setInt(64, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFontHeight()
/*     */   {
/* 172 */     return getInt(64);
/*     */   }
/*     */   
/*     */   private void setFontOption(boolean option, BitField field)
/*     */   {
/* 177 */     int options = getInt(68);
/* 178 */     options = field.setBoolean(options, option);
/* 179 */     setInt(68, options);
/*     */   }
/*     */   
/*     */   private boolean getFontOption(BitField field)
/*     */   {
/* 184 */     int options = getInt(68);
/* 185 */     return field.isSet(options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItalic(boolean italic)
/*     */   {
/* 197 */     setFontOption(italic, posture);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isItalic()
/*     */   {
/* 209 */     return getFontOption(posture);
/*     */   }
/*     */   
/*     */   public void setOutline(boolean on)
/*     */   {
/* 214 */     setFontOption(on, outline);
/*     */   }
/*     */   
/*     */   public boolean isOutlineOn()
/*     */   {
/* 219 */     return getFontOption(outline);
/*     */   }
/*     */   
/*     */   public void setShadow(boolean on)
/*     */   {
/* 224 */     setFontOption(on, shadow);
/*     */   }
/*     */   
/*     */   public boolean isShadowOn()
/*     */   {
/* 229 */     return getFontOption(shadow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStrikeout(boolean strike)
/*     */   {
/* 240 */     setFontOption(strike, cancellation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStruckout()
/*     */   {
/* 252 */     return getFontOption(cancellation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setFontWeight(short pbw)
/*     */   {
/* 264 */     short bw = pbw;
/* 265 */     if (bw < 100) bw = 100;
/* 266 */     if (bw > 1000) bw = 1000;
/* 267 */     setShort(72, bw);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBold(boolean bold)
/*     */   {
/* 277 */     setFontWeight((short)(bold ? 700 : 400));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFontWeight()
/*     */   {
/* 289 */     return getShort(72);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBold()
/*     */   {
/* 300 */     return getFontWeight() == 700;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getEscapementType()
/*     */   {
/* 313 */     return getShort(74);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEscapementType(short escapementType)
/*     */   {
/* 326 */     setShort(74, escapementType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getUnderlineType()
/*     */   {
/* 343 */     return getShort(76);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnderlineType(short underlineType)
/*     */   {
/* 359 */     setShort(76, underlineType);
/*     */   }
/*     */   
/*     */ 
/*     */   public short getFontColorIndex()
/*     */   {
/* 365 */     return (short)getInt(80);
/*     */   }
/*     */   
/*     */   public void setFontColorIndex(short fci)
/*     */   {
/* 370 */     setInt(80, fci);
/*     */   }
/*     */   
/*     */   private boolean getOptionFlag(BitField field)
/*     */   {
/* 375 */     int optionFlags = getInt(88);
/* 376 */     int value = field.getValue(optionFlags);
/* 377 */     return value == 0;
/*     */   }
/*     */   
/*     */   private void setOptionFlag(boolean modified, BitField field)
/*     */   {
/* 382 */     int value = modified ? 0 : 1;
/* 383 */     int optionFlags = getInt(88);
/* 384 */     optionFlags = field.setValue(optionFlags, value);
/* 385 */     setInt(88, optionFlags);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isFontStyleModified()
/*     */   {
/* 391 */     return getOptionFlag(styleModified);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFontStyleModified(boolean modified)
/*     */   {
/* 397 */     setOptionFlag(modified, styleModified);
/*     */   }
/*     */   
/*     */   public boolean isFontOutlineModified()
/*     */   {
/* 402 */     return getOptionFlag(outlineModified);
/*     */   }
/*     */   
/*     */   public void setFontOutlineModified(boolean modified)
/*     */   {
/* 407 */     setOptionFlag(modified, outlineModified);
/*     */   }
/*     */   
/*     */   public boolean isFontShadowModified()
/*     */   {
/* 412 */     return getOptionFlag(shadowModified);
/*     */   }
/*     */   
/*     */   public void setFontShadowModified(boolean modified)
/*     */   {
/* 417 */     setOptionFlag(modified, shadowModified);
/*     */   }
/*     */   
/*     */   public void setFontCancellationModified(boolean modified) {
/* 421 */     setOptionFlag(modified, cancellationModified);
/*     */   }
/*     */   
/*     */   public boolean isFontCancellationModified()
/*     */   {
/* 426 */     return getOptionFlag(cancellationModified);
/*     */   }
/*     */   
/*     */   public void setEscapementTypeModified(boolean modified)
/*     */   {
/* 431 */     int value = modified ? 0 : 1;
/* 432 */     setInt(92, value);
/*     */   }
/*     */   
/*     */   public boolean isEscapementTypeModified() {
/* 436 */     int escapementModified = getInt(92);
/* 437 */     return escapementModified == 0;
/*     */   }
/*     */   
/*     */   public void setUnderlineTypeModified(boolean modified)
/*     */   {
/* 442 */     int value = modified ? 0 : 1;
/* 443 */     setInt(96, value);
/*     */   }
/*     */   
/*     */   public boolean isUnderlineTypeModified()
/*     */   {
/* 448 */     int underlineModified = getInt(96);
/* 449 */     return underlineModified == 0;
/*     */   }
/*     */   
/*     */   public void setFontWieghtModified(boolean modified)
/*     */   {
/* 454 */     int value = modified ? 0 : 1;
/* 455 */     setInt(100, value);
/*     */   }
/*     */   
/*     */   public boolean isFontWeightModified()
/*     */   {
/* 460 */     int fontStyleModified = getInt(100);
/* 461 */     return fontStyleModified == 0;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 466 */     StringBuffer buffer = new StringBuffer();
/* 467 */     buffer.append("\t[Font Formatting]\n");
/*     */     
/* 469 */     buffer.append("\t.font height = ").append(getFontHeight()).append(" twips\n");
/*     */     
/* 471 */     if (isFontStyleModified())
/*     */     {
/* 473 */       buffer.append("\t.font posture = ").append(isItalic() ? "Italic" : "Normal").append("\n");
/*     */     }
/*     */     else
/*     */     {
/* 477 */       buffer.append("\t.font posture = ]not modified]").append("\n");
/*     */     }
/*     */     
/* 480 */     if (isFontOutlineModified())
/*     */     {
/* 482 */       buffer.append("\t.font outline = ").append(isOutlineOn()).append("\n");
/*     */     }
/*     */     else
/*     */     {
/* 486 */       buffer.append("\t.font outline is not modified\n");
/*     */     }
/*     */     
/* 489 */     if (isFontShadowModified())
/*     */     {
/* 491 */       buffer.append("\t.font shadow = ").append(isShadowOn()).append("\n");
/*     */     }
/*     */     else
/*     */     {
/* 495 */       buffer.append("\t.font shadow is not modified\n");
/*     */     }
/*     */     
/* 498 */     if (isFontCancellationModified())
/*     */     {
/* 500 */       buffer.append("\t.font strikeout = ").append(isStruckout()).append("\n");
/*     */     }
/*     */     else
/*     */     {
/* 504 */       buffer.append("\t.font strikeout is not modified\n");
/*     */     }
/*     */     
/* 507 */     if (isFontStyleModified())
/*     */     {
/* 509 */       buffer.append("\t.font weight = ").append(getFontWeight()).append("0x" + Integer.toHexString(getFontWeight())).append("\n");
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 518 */       buffer.append("\t.font weight = ]not modified]").append("\n");
/*     */     }
/*     */     
/* 521 */     if (isEscapementTypeModified())
/*     */     {
/* 523 */       buffer.append("\t.escapement type = ").append(getEscapementType()).append("\n");
/*     */     }
/*     */     else
/*     */     {
/* 527 */       buffer.append("\t.escapement type is not modified\n");
/*     */     }
/*     */     
/* 530 */     if (isUnderlineTypeModified())
/*     */     {
/* 532 */       buffer.append("\t.underline type = ").append(getUnderlineType()).append("\n");
/*     */     }
/*     */     else
/*     */     {
/* 536 */       buffer.append("\t.underline type is not modified\n");
/*     */     }
/* 538 */     buffer.append("\t.color index = ").append("0x" + Integer.toHexString(getFontColorIndex()).toUpperCase()).append("\n");
/*     */     
/* 540 */     buffer.append("\t[/Font Formatting]\n");
/* 541 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 546 */     byte[] rawData = (byte[])this._rawData.clone();
/* 547 */     return new FontFormatting(rawData);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\cf\FontFormatting.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */