/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AreaFormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4106;
/*  35 */   private static final BitField automatic = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField invert = BitFieldFactory.getInstance(2);
/*     */   
/*     */   private int field_1_foregroundColor;
/*     */   
/*     */   private int field_2_backgroundColor;
/*     */   
/*     */   private short field_3_pattern;
/*     */   
/*     */   private short field_4_formatFlags;
/*     */   
/*     */   private short field_5_forecolorIndex;
/*     */   private short field_6_backcolorIndex;
/*     */   
/*     */   public AreaFormatRecord() {}
/*     */   
/*     */   public AreaFormatRecord(RecordInputStream in)
/*     */   {
/*  53 */     this.field_1_foregroundColor = in.readInt();
/*  54 */     this.field_2_backgroundColor = in.readInt();
/*  55 */     this.field_3_pattern = in.readShort();
/*  56 */     this.field_4_formatFlags = in.readShort();
/*  57 */     this.field_5_forecolorIndex = in.readShort();
/*  58 */     this.field_6_backcolorIndex = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  64 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  66 */     buffer.append("[AREAFORMAT]\n");
/*  67 */     buffer.append("    .foregroundColor      = ").append("0x").append(HexDump.toHex(getForegroundColor())).append(" (").append(getForegroundColor()).append(" )");
/*     */     
/*     */ 
/*  70 */     buffer.append(System.getProperty("line.separator"));
/*  71 */     buffer.append("    .backgroundColor      = ").append("0x").append(HexDump.toHex(getBackgroundColor())).append(" (").append(getBackgroundColor()).append(" )");
/*     */     
/*     */ 
/*  74 */     buffer.append(System.getProperty("line.separator"));
/*  75 */     buffer.append("    .pattern              = ").append("0x").append(HexDump.toHex(getPattern())).append(" (").append(getPattern()).append(" )");
/*     */     
/*     */ 
/*  78 */     buffer.append(System.getProperty("line.separator"));
/*  79 */     buffer.append("    .formatFlags          = ").append("0x").append(HexDump.toHex(getFormatFlags())).append(" (").append(getFormatFlags()).append(" )");
/*     */     
/*     */ 
/*  82 */     buffer.append(System.getProperty("line.separator"));
/*  83 */     buffer.append("         .automatic                = ").append(isAutomatic()).append('\n');
/*  84 */     buffer.append("         .invert                   = ").append(isInvert()).append('\n');
/*  85 */     buffer.append("    .forecolorIndex       = ").append("0x").append(HexDump.toHex(getForecolorIndex())).append(" (").append(getForecolorIndex()).append(" )");
/*     */     
/*     */ 
/*  88 */     buffer.append(System.getProperty("line.separator"));
/*  89 */     buffer.append("    .backcolorIndex       = ").append("0x").append(HexDump.toHex(getBackcolorIndex())).append(" (").append(getBackcolorIndex()).append(" )");
/*     */     
/*     */ 
/*  92 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  94 */     buffer.append("[/AREAFORMAT]\n");
/*  95 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  99 */     out.writeInt(this.field_1_foregroundColor);
/* 100 */     out.writeInt(this.field_2_backgroundColor);
/* 101 */     out.writeShort(this.field_3_pattern);
/* 102 */     out.writeShort(this.field_4_formatFlags);
/* 103 */     out.writeShort(this.field_5_forecolorIndex);
/* 104 */     out.writeShort(this.field_6_backcolorIndex);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 108 */     return 16;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 113 */     return 4106;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 117 */     AreaFormatRecord rec = new AreaFormatRecord();
/*     */     
/* 119 */     rec.field_1_foregroundColor = this.field_1_foregroundColor;
/* 120 */     rec.field_2_backgroundColor = this.field_2_backgroundColor;
/* 121 */     rec.field_3_pattern = this.field_3_pattern;
/* 122 */     rec.field_4_formatFlags = this.field_4_formatFlags;
/* 123 */     rec.field_5_forecolorIndex = this.field_5_forecolorIndex;
/* 124 */     rec.field_6_backcolorIndex = this.field_6_backcolorIndex;
/* 125 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getForegroundColor()
/*     */   {
/* 136 */     return this.field_1_foregroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForegroundColor(int field_1_foregroundColor)
/*     */   {
/* 144 */     this.field_1_foregroundColor = field_1_foregroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBackgroundColor()
/*     */   {
/* 152 */     return this.field_2_backgroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackgroundColor(int field_2_backgroundColor)
/*     */   {
/* 160 */     this.field_2_backgroundColor = field_2_backgroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getPattern()
/*     */   {
/* 168 */     return this.field_3_pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(short field_3_pattern)
/*     */   {
/* 176 */     this.field_3_pattern = field_3_pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFormatFlags()
/*     */   {
/* 184 */     return this.field_4_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatFlags(short field_4_formatFlags)
/*     */   {
/* 192 */     this.field_4_formatFlags = field_4_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getForecolorIndex()
/*     */   {
/* 200 */     return this.field_5_forecolorIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForecolorIndex(short field_5_forecolorIndex)
/*     */   {
/* 208 */     this.field_5_forecolorIndex = field_5_forecolorIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getBackcolorIndex()
/*     */   {
/* 216 */     return this.field_6_backcolorIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackcolorIndex(short field_6_backcolorIndex)
/*     */   {
/* 224 */     this.field_6_backcolorIndex = field_6_backcolorIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomatic(boolean value)
/*     */   {
/* 233 */     this.field_4_formatFlags = automatic.setShortBoolean(this.field_4_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomatic()
/*     */   {
/* 242 */     return automatic.isSet(this.field_4_formatFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInvert(boolean value)
/*     */   {
/* 251 */     this.field_4_formatFlags = invert.setShortBoolean(this.field_4_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInvert()
/*     */   {
/* 260 */     return invert.isSet(this.field_4_formatFlags);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\AreaFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */