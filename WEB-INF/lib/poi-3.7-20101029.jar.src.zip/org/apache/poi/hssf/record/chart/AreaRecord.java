/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AreaRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4122;
/*     */   private short field_1_formatFlags;
/*  35 */   private static final BitField stacked = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField displayAsPercentage = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField shadow = BitFieldFactory.getInstance(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AreaRecord() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public AreaRecord(RecordInputStream in)
/*     */   {
/*  48 */     this.field_1_formatFlags = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  53 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  55 */     buffer.append("[AREA]\n");
/*  56 */     buffer.append("    .formatFlags          = ").append("0x").append(HexDump.toHex(getFormatFlags())).append(" (").append(getFormatFlags()).append(" )");
/*     */     
/*     */ 
/*  59 */     buffer.append(System.getProperty("line.separator"));
/*  60 */     buffer.append("         .stacked                  = ").append(isStacked()).append('\n');
/*  61 */     buffer.append("         .displayAsPercentage      = ").append(isDisplayAsPercentage()).append('\n');
/*  62 */     buffer.append("         .shadow                   = ").append(isShadow()).append('\n');
/*     */     
/*  64 */     buffer.append("[/AREA]\n");
/*  65 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  69 */     out.writeShort(this.field_1_formatFlags);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  73 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  78 */     return 4122;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  82 */     AreaRecord rec = new AreaRecord();
/*     */     
/*  84 */     rec.field_1_formatFlags = this.field_1_formatFlags;
/*  85 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFormatFlags()
/*     */   {
/*  96 */     return this.field_1_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatFlags(short field_1_formatFlags)
/*     */   {
/* 104 */     this.field_1_formatFlags = field_1_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStacked(boolean value)
/*     */   {
/* 113 */     this.field_1_formatFlags = stacked.setShortBoolean(this.field_1_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStacked()
/*     */   {
/* 122 */     return stacked.isSet(this.field_1_formatFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplayAsPercentage(boolean value)
/*     */   {
/* 131 */     this.field_1_formatFlags = displayAsPercentage.setShortBoolean(this.field_1_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisplayAsPercentage()
/*     */   {
/* 140 */     return displayAsPercentage.isSet(this.field_1_formatFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShadow(boolean value)
/*     */   {
/* 149 */     this.field_1_formatFlags = shadow.setShortBoolean(this.field_1_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShadow()
/*     */   {
/* 158 */     return shadow.isSet(this.field_1_formatFlags);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\AreaRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */