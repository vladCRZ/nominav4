/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AxisLineFormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4129;
/*     */   private short field_1_axisType;
/*     */   public static final short AXIS_TYPE_AXIS_LINE = 0;
/*     */   public static final short AXIS_TYPE_MAJOR_GRID_LINE = 1;
/*     */   public static final short AXIS_TYPE_MINOR_GRID_LINE = 2;
/*     */   public static final short AXIS_TYPE_WALLS_OR_FLOOR = 3;
/*     */   
/*     */   public AxisLineFormatRecord() {}
/*     */   
/*     */   public AxisLineFormatRecord(RecordInputStream in)
/*     */   {
/*  46 */     this.field_1_axisType = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  51 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  53 */     buffer.append("[AXISLINEFORMAT]\n");
/*  54 */     buffer.append("    .axisType             = ").append("0x").append(HexDump.toHex(getAxisType())).append(" (").append(getAxisType()).append(" )");
/*     */     
/*     */ 
/*  57 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  59 */     buffer.append("[/AXISLINEFORMAT]\n");
/*  60 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  64 */     out.writeShort(this.field_1_axisType);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  68 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  73 */     return 4129;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  77 */     AxisLineFormatRecord rec = new AxisLineFormatRecord();
/*     */     
/*  79 */     rec.field_1_axisType = this.field_1_axisType;
/*  80 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getAxisType()
/*     */   {
/*  97 */     return this.field_1_axisType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAxisType(short field_1_axisType)
/*     */   {
/* 112 */     this.field_1_axisType = field_1_axisType;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\AxisLineFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */