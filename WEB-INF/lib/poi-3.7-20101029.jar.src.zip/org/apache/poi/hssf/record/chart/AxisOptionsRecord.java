/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AxisOptionsRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4194;
/*  35 */   private static final BitField defaultMinimum = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField defaultMaximum = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField defaultMajor = BitFieldFactory.getInstance(4);
/*  38 */   private static final BitField defaultMinorUnit = BitFieldFactory.getInstance(8);
/*  39 */   private static final BitField isDate = BitFieldFactory.getInstance(16);
/*  40 */   private static final BitField defaultBase = BitFieldFactory.getInstance(32);
/*  41 */   private static final BitField defaultCross = BitFieldFactory.getInstance(64);
/*  42 */   private static final BitField defaultDateSettings = BitFieldFactory.getInstance(128);
/*     */   
/*     */   private short field_1_minimumCategory;
/*     */   
/*     */   private short field_2_maximumCategory;
/*     */   
/*     */   private short field_3_majorUnitValue;
/*     */   
/*     */   private short field_4_majorUnit;
/*     */   
/*     */   private short field_5_minorUnitValue;
/*     */   private short field_6_minorUnit;
/*     */   private short field_7_baseUnit;
/*     */   private short field_8_crossingPoint;
/*     */   private short field_9_options;
/*     */   
/*     */   public AxisOptionsRecord() {}
/*     */   
/*     */   public AxisOptionsRecord(RecordInputStream in)
/*     */   {
/*  62 */     this.field_1_minimumCategory = in.readShort();
/*  63 */     this.field_2_maximumCategory = in.readShort();
/*  64 */     this.field_3_majorUnitValue = in.readShort();
/*  65 */     this.field_4_majorUnit = in.readShort();
/*  66 */     this.field_5_minorUnitValue = in.readShort();
/*  67 */     this.field_6_minorUnit = in.readShort();
/*  68 */     this.field_7_baseUnit = in.readShort();
/*  69 */     this.field_8_crossingPoint = in.readShort();
/*  70 */     this.field_9_options = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  75 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  77 */     buffer.append("[AXCEXT]\n");
/*  78 */     buffer.append("    .minimumCategory      = ").append("0x").append(HexDump.toHex(getMinimumCategory())).append(" (").append(getMinimumCategory()).append(" )");
/*     */     
/*     */ 
/*  81 */     buffer.append(System.getProperty("line.separator"));
/*  82 */     buffer.append("    .maximumCategory      = ").append("0x").append(HexDump.toHex(getMaximumCategory())).append(" (").append(getMaximumCategory()).append(" )");
/*     */     
/*     */ 
/*  85 */     buffer.append(System.getProperty("line.separator"));
/*  86 */     buffer.append("    .majorUnitValue       = ").append("0x").append(HexDump.toHex(getMajorUnitValue())).append(" (").append(getMajorUnitValue()).append(" )");
/*     */     
/*     */ 
/*  89 */     buffer.append(System.getProperty("line.separator"));
/*  90 */     buffer.append("    .majorUnit            = ").append("0x").append(HexDump.toHex(getMajorUnit())).append(" (").append(getMajorUnit()).append(" )");
/*     */     
/*     */ 
/*  93 */     buffer.append(System.getProperty("line.separator"));
/*  94 */     buffer.append("    .minorUnitValue       = ").append("0x").append(HexDump.toHex(getMinorUnitValue())).append(" (").append(getMinorUnitValue()).append(" )");
/*     */     
/*     */ 
/*  97 */     buffer.append(System.getProperty("line.separator"));
/*  98 */     buffer.append("    .minorUnit            = ").append("0x").append(HexDump.toHex(getMinorUnit())).append(" (").append(getMinorUnit()).append(" )");
/*     */     
/*     */ 
/* 101 */     buffer.append(System.getProperty("line.separator"));
/* 102 */     buffer.append("    .baseUnit             = ").append("0x").append(HexDump.toHex(getBaseUnit())).append(" (").append(getBaseUnit()).append(" )");
/*     */     
/*     */ 
/* 105 */     buffer.append(System.getProperty("line.separator"));
/* 106 */     buffer.append("    .crossingPoint        = ").append("0x").append(HexDump.toHex(getCrossingPoint())).append(" (").append(getCrossingPoint()).append(" )");
/*     */     
/*     */ 
/* 109 */     buffer.append(System.getProperty("line.separator"));
/* 110 */     buffer.append("    .options              = ").append("0x").append(HexDump.toHex(getOptions())).append(" (").append(getOptions()).append(" )");
/*     */     
/*     */ 
/* 113 */     buffer.append(System.getProperty("line.separator"));
/* 114 */     buffer.append("         .defaultMinimum           = ").append(isDefaultMinimum()).append('\n');
/* 115 */     buffer.append("         .defaultMaximum           = ").append(isDefaultMaximum()).append('\n');
/* 116 */     buffer.append("         .defaultMajor             = ").append(isDefaultMajor()).append('\n');
/* 117 */     buffer.append("         .defaultMinorUnit         = ").append(isDefaultMinorUnit()).append('\n');
/* 118 */     buffer.append("         .isDate                   = ").append(isIsDate()).append('\n');
/* 119 */     buffer.append("         .defaultBase              = ").append(isDefaultBase()).append('\n');
/* 120 */     buffer.append("         .defaultCross             = ").append(isDefaultCross()).append('\n');
/* 121 */     buffer.append("         .defaultDateSettings      = ").append(isDefaultDateSettings()).append('\n');
/*     */     
/* 123 */     buffer.append("[/AXCEXT]\n");
/* 124 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 128 */     out.writeShort(this.field_1_minimumCategory);
/* 129 */     out.writeShort(this.field_2_maximumCategory);
/* 130 */     out.writeShort(this.field_3_majorUnitValue);
/* 131 */     out.writeShort(this.field_4_majorUnit);
/* 132 */     out.writeShort(this.field_5_minorUnitValue);
/* 133 */     out.writeShort(this.field_6_minorUnit);
/* 134 */     out.writeShort(this.field_7_baseUnit);
/* 135 */     out.writeShort(this.field_8_crossingPoint);
/* 136 */     out.writeShort(this.field_9_options);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 140 */     return 18;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 145 */     return 4194;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 149 */     AxisOptionsRecord rec = new AxisOptionsRecord();
/*     */     
/* 151 */     rec.field_1_minimumCategory = this.field_1_minimumCategory;
/* 152 */     rec.field_2_maximumCategory = this.field_2_maximumCategory;
/* 153 */     rec.field_3_majorUnitValue = this.field_3_majorUnitValue;
/* 154 */     rec.field_4_majorUnit = this.field_4_majorUnit;
/* 155 */     rec.field_5_minorUnitValue = this.field_5_minorUnitValue;
/* 156 */     rec.field_6_minorUnit = this.field_6_minorUnit;
/* 157 */     rec.field_7_baseUnit = this.field_7_baseUnit;
/* 158 */     rec.field_8_crossingPoint = this.field_8_crossingPoint;
/* 159 */     rec.field_9_options = this.field_9_options;
/* 160 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getMinimumCategory()
/*     */   {
/* 171 */     return this.field_1_minimumCategory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimumCategory(short field_1_minimumCategory)
/*     */   {
/* 179 */     this.field_1_minimumCategory = field_1_minimumCategory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getMaximumCategory()
/*     */   {
/* 187 */     return this.field_2_maximumCategory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximumCategory(short field_2_maximumCategory)
/*     */   {
/* 195 */     this.field_2_maximumCategory = field_2_maximumCategory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getMajorUnitValue()
/*     */   {
/* 203 */     return this.field_3_majorUnitValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMajorUnitValue(short field_3_majorUnitValue)
/*     */   {
/* 211 */     this.field_3_majorUnitValue = field_3_majorUnitValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getMajorUnit()
/*     */   {
/* 219 */     return this.field_4_majorUnit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMajorUnit(short field_4_majorUnit)
/*     */   {
/* 227 */     this.field_4_majorUnit = field_4_majorUnit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getMinorUnitValue()
/*     */   {
/* 235 */     return this.field_5_minorUnitValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinorUnitValue(short field_5_minorUnitValue)
/*     */   {
/* 243 */     this.field_5_minorUnitValue = field_5_minorUnitValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getMinorUnit()
/*     */   {
/* 251 */     return this.field_6_minorUnit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinorUnit(short field_6_minorUnit)
/*     */   {
/* 259 */     this.field_6_minorUnit = field_6_minorUnit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getBaseUnit()
/*     */   {
/* 267 */     return this.field_7_baseUnit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaseUnit(short field_7_baseUnit)
/*     */   {
/* 275 */     this.field_7_baseUnit = field_7_baseUnit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCrossingPoint()
/*     */   {
/* 283 */     return this.field_8_crossingPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrossingPoint(short field_8_crossingPoint)
/*     */   {
/* 291 */     this.field_8_crossingPoint = field_8_crossingPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 299 */     return this.field_9_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_9_options)
/*     */   {
/* 307 */     this.field_9_options = field_9_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultMinimum(boolean value)
/*     */   {
/* 316 */     this.field_9_options = defaultMinimum.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultMinimum()
/*     */   {
/* 325 */     return defaultMinimum.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultMaximum(boolean value)
/*     */   {
/* 334 */     this.field_9_options = defaultMaximum.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultMaximum()
/*     */   {
/* 343 */     return defaultMaximum.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultMajor(boolean value)
/*     */   {
/* 352 */     this.field_9_options = defaultMajor.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultMajor()
/*     */   {
/* 361 */     return defaultMajor.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultMinorUnit(boolean value)
/*     */   {
/* 370 */     this.field_9_options = defaultMinorUnit.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultMinorUnit()
/*     */   {
/* 379 */     return defaultMinorUnit.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIsDate(boolean value)
/*     */   {
/* 388 */     this.field_9_options = isDate.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIsDate()
/*     */   {
/* 397 */     return isDate.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultBase(boolean value)
/*     */   {
/* 406 */     this.field_9_options = defaultBase.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultBase()
/*     */   {
/* 415 */     return defaultBase.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultCross(boolean value)
/*     */   {
/* 424 */     this.field_9_options = defaultCross.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultCross()
/*     */   {
/* 433 */     return defaultCross.isSet(this.field_9_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultDateSettings(boolean value)
/*     */   {
/* 442 */     this.field_9_options = defaultDateSettings.setShortBoolean(this.field_9_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultDateSettings()
/*     */   {
/* 451 */     return defaultDateSettings.isSet(this.field_9_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\AxisOptionsRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */