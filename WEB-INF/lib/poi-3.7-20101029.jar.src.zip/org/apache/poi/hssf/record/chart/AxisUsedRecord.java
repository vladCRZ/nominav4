/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AxisUsedRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 4166;
/*    */   private short field_1_numAxis;
/*    */   
/*    */   public AxisUsedRecord() {}
/*    */   
/*    */   public AxisUsedRecord(RecordInputStream in)
/*    */   {
/* 42 */     this.field_1_numAxis = in.readShort();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 47 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 49 */     buffer.append("[AXISUSED]\n");
/* 50 */     buffer.append("    .numAxis              = ").append("0x").append(HexDump.toHex(getNumAxis())).append(" (").append(getNumAxis()).append(" )");
/*    */     
/*    */ 
/* 53 */     buffer.append(System.getProperty("line.separator"));
/*    */     
/* 55 */     buffer.append("[/AXISUSED]\n");
/* 56 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 60 */     out.writeShort(this.field_1_numAxis);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 64 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 69 */     return 4166;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 73 */     AxisUsedRecord rec = new AxisUsedRecord();
/*    */     
/* 75 */     rec.field_1_numAxis = this.field_1_numAxis;
/* 76 */     return rec;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getNumAxis()
/*    */   {
/* 87 */     return this.field_1_numAxis;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setNumAxis(short field_1_numAxis)
/*    */   {
/* 95 */     this.field_1_numAxis = field_1_numAxis;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\AxisUsedRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */