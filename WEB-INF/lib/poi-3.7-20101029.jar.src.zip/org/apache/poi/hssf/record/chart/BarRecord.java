/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BarRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4119;
/*  35 */   private static final BitField horizontal = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField stacked = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField displayAsPercentage = BitFieldFactory.getInstance(4);
/*  38 */   private static final BitField shadow = BitFieldFactory.getInstance(8);
/*     */   
/*     */   private short field_1_barSpace;
/*     */   
/*     */   private short field_2_categorySpace;
/*     */   
/*     */   private short field_3_formatFlags;
/*     */   
/*     */ 
/*     */   public BarRecord() {}
/*     */   
/*     */ 
/*     */   public BarRecord(RecordInputStream in)
/*     */   {
/*  52 */     this.field_1_barSpace = in.readShort();
/*  53 */     this.field_2_categorySpace = in.readShort();
/*  54 */     this.field_3_formatFlags = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  59 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  61 */     buffer.append("[BAR]\n");
/*  62 */     buffer.append("    .barSpace             = ").append("0x").append(HexDump.toHex(getBarSpace())).append(" (").append(getBarSpace()).append(" )");
/*     */     
/*     */ 
/*  65 */     buffer.append(System.getProperty("line.separator"));
/*  66 */     buffer.append("    .categorySpace        = ").append("0x").append(HexDump.toHex(getCategorySpace())).append(" (").append(getCategorySpace()).append(" )");
/*     */     
/*     */ 
/*  69 */     buffer.append(System.getProperty("line.separator"));
/*  70 */     buffer.append("    .formatFlags          = ").append("0x").append(HexDump.toHex(getFormatFlags())).append(" (").append(getFormatFlags()).append(" )");
/*     */     
/*     */ 
/*  73 */     buffer.append(System.getProperty("line.separator"));
/*  74 */     buffer.append("         .horizontal               = ").append(isHorizontal()).append('\n');
/*  75 */     buffer.append("         .stacked                  = ").append(isStacked()).append('\n');
/*  76 */     buffer.append("         .displayAsPercentage      = ").append(isDisplayAsPercentage()).append('\n');
/*  77 */     buffer.append("         .shadow                   = ").append(isShadow()).append('\n');
/*     */     
/*  79 */     buffer.append("[/BAR]\n");
/*  80 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  84 */     out.writeShort(this.field_1_barSpace);
/*  85 */     out.writeShort(this.field_2_categorySpace);
/*  86 */     out.writeShort(this.field_3_formatFlags);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  90 */     return 6;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  95 */     return 4119;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  99 */     BarRecord rec = new BarRecord();
/*     */     
/* 101 */     rec.field_1_barSpace = this.field_1_barSpace;
/* 102 */     rec.field_2_categorySpace = this.field_2_categorySpace;
/* 103 */     rec.field_3_formatFlags = this.field_3_formatFlags;
/* 104 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getBarSpace()
/*     */   {
/* 115 */     return this.field_1_barSpace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBarSpace(short field_1_barSpace)
/*     */   {
/* 123 */     this.field_1_barSpace = field_1_barSpace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCategorySpace()
/*     */   {
/* 131 */     return this.field_2_categorySpace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCategorySpace(short field_2_categorySpace)
/*     */   {
/* 139 */     this.field_2_categorySpace = field_2_categorySpace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFormatFlags()
/*     */   {
/* 147 */     return this.field_3_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatFlags(short field_3_formatFlags)
/*     */   {
/* 155 */     this.field_3_formatFlags = field_3_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHorizontal(boolean value)
/*     */   {
/* 164 */     this.field_3_formatFlags = horizontal.setShortBoolean(this.field_3_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHorizontal()
/*     */   {
/* 173 */     return horizontal.isSet(this.field_3_formatFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStacked(boolean value)
/*     */   {
/* 182 */     this.field_3_formatFlags = stacked.setShortBoolean(this.field_3_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStacked()
/*     */   {
/* 191 */     return stacked.isSet(this.field_3_formatFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplayAsPercentage(boolean value)
/*     */   {
/* 200 */     this.field_3_formatFlags = displayAsPercentage.setShortBoolean(this.field_3_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisplayAsPercentage()
/*     */   {
/* 209 */     return displayAsPercentage.isSet(this.field_3_formatFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShadow(boolean value)
/*     */   {
/* 218 */     this.field_3_formatFlags = shadow.setShortBoolean(this.field_3_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShadow()
/*     */   {
/* 227 */     return shadow.isSet(this.field_3_formatFlags);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\BarRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */