/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BeginRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 4147;
/*    */   
/*    */   public BeginRecord() {}
/*    */   
/*    */   public BeginRecord(RecordInputStream in) {}
/*    */   
/*    */   public String toString()
/*    */   {
/* 48 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 50 */     buffer.append("[BEGIN]\n");
/* 51 */     buffer.append("[/BEGIN]\n");
/* 52 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {}
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 59 */     return 0;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 64 */     return 4147;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 68 */     BeginRecord br = new BeginRecord();
/*    */     
/* 70 */     return br;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\BeginRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */