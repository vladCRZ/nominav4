/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CatLabRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 2134;
/*    */   private short rt;
/*    */   private short grbitFrt;
/*    */   private short wOffset;
/*    */   private short at;
/*    */   private short grbit;
/*    */   private Short unused;
/*    */   
/*    */   public CatLabRecord(RecordInputStream in)
/*    */   {
/* 41 */     this.rt = in.readShort();
/* 42 */     this.grbitFrt = in.readShort();
/* 43 */     this.wOffset = in.readShort();
/* 44 */     this.at = in.readShort();
/* 45 */     this.grbit = in.readShort();
/*    */     
/*    */ 
/* 48 */     if (in.available() == 0) {
/* 49 */       this.unused = null;
/*    */     } else {
/* 51 */       this.unused = Short.valueOf(in.readShort());
/*    */     }
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 57 */     return 10 + (this.unused == null ? 0 : 2);
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 62 */     return 2134;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out)
/*    */   {
/* 67 */     out.writeShort(this.rt);
/* 68 */     out.writeShort(this.grbitFrt);
/* 69 */     out.writeShort(this.wOffset);
/* 70 */     out.writeShort(this.at);
/* 71 */     out.writeShort(this.grbit);
/* 72 */     if (this.unused != null) {
/* 73 */       out.writeShort(this.unused.shortValue());
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString() {
/* 78 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 80 */     buffer.append("[CATLAB]\n");
/* 81 */     buffer.append("    .rt      =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 82 */     buffer.append("    .grbitFrt=").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 83 */     buffer.append("    .wOffset =").append(HexDump.shortToHex(this.wOffset)).append('\n');
/* 84 */     buffer.append("    .at      =").append(HexDump.shortToHex(this.at)).append('\n');
/* 85 */     buffer.append("    .grbit   =").append(HexDump.shortToHex(this.grbit)).append('\n');
/* 86 */     buffer.append("    .unused  =").append(HexDump.shortToHex(this.unused.shortValue())).append('\n');
/*    */     
/* 88 */     buffer.append("[/CATLAB]\n");
/* 89 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\CatLabRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */