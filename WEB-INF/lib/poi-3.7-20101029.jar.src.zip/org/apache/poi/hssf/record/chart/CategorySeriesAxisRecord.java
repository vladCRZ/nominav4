/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CategorySeriesAxisRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4128;
/*  35 */   private static final BitField valueAxisCrossing = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField crossesFarRight = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField reversed = BitFieldFactory.getInstance(4);
/*     */   
/*     */   private short field_1_crossingPoint;
/*     */   
/*     */   private short field_2_labelFrequency;
/*     */   
/*     */   private short field_3_tickMarkFrequency;
/*     */   
/*     */   private short field_4_options;
/*     */   
/*     */ 
/*     */   public CategorySeriesAxisRecord() {}
/*     */   
/*     */   public CategorySeriesAxisRecord(RecordInputStream in)
/*     */   {
/*  52 */     this.field_1_crossingPoint = in.readShort();
/*  53 */     this.field_2_labelFrequency = in.readShort();
/*  54 */     this.field_3_tickMarkFrequency = in.readShort();
/*  55 */     this.field_4_options = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  60 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  62 */     buffer.append("[CATSERRANGE]\n");
/*  63 */     buffer.append("    .crossingPoint        = ").append("0x").append(HexDump.toHex(getCrossingPoint())).append(" (").append(getCrossingPoint()).append(" )");
/*     */     
/*     */ 
/*  66 */     buffer.append(System.getProperty("line.separator"));
/*  67 */     buffer.append("    .labelFrequency       = ").append("0x").append(HexDump.toHex(getLabelFrequency())).append(" (").append(getLabelFrequency()).append(" )");
/*     */     
/*     */ 
/*  70 */     buffer.append(System.getProperty("line.separator"));
/*  71 */     buffer.append("    .tickMarkFrequency    = ").append("0x").append(HexDump.toHex(getTickMarkFrequency())).append(" (").append(getTickMarkFrequency()).append(" )");
/*     */     
/*     */ 
/*  74 */     buffer.append(System.getProperty("line.separator"));
/*  75 */     buffer.append("    .options              = ").append("0x").append(HexDump.toHex(getOptions())).append(" (").append(getOptions()).append(" )");
/*     */     
/*     */ 
/*  78 */     buffer.append(System.getProperty("line.separator"));
/*  79 */     buffer.append("         .valueAxisCrossing        = ").append(isValueAxisCrossing()).append('\n');
/*  80 */     buffer.append("         .crossesFarRight          = ").append(isCrossesFarRight()).append('\n');
/*  81 */     buffer.append("         .reversed                 = ").append(isReversed()).append('\n');
/*     */     
/*  83 */     buffer.append("[/CATSERRANGE]\n");
/*  84 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  88 */     out.writeShort(this.field_1_crossingPoint);
/*  89 */     out.writeShort(this.field_2_labelFrequency);
/*  90 */     out.writeShort(this.field_3_tickMarkFrequency);
/*  91 */     out.writeShort(this.field_4_options);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  95 */     return 8;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 100 */     return 4128;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 104 */     CategorySeriesAxisRecord rec = new CategorySeriesAxisRecord();
/*     */     
/* 106 */     rec.field_1_crossingPoint = this.field_1_crossingPoint;
/* 107 */     rec.field_2_labelFrequency = this.field_2_labelFrequency;
/* 108 */     rec.field_3_tickMarkFrequency = this.field_3_tickMarkFrequency;
/* 109 */     rec.field_4_options = this.field_4_options;
/* 110 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCrossingPoint()
/*     */   {
/* 121 */     return this.field_1_crossingPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrossingPoint(short field_1_crossingPoint)
/*     */   {
/* 129 */     this.field_1_crossingPoint = field_1_crossingPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLabelFrequency()
/*     */   {
/* 137 */     return this.field_2_labelFrequency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabelFrequency(short field_2_labelFrequency)
/*     */   {
/* 145 */     this.field_2_labelFrequency = field_2_labelFrequency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getTickMarkFrequency()
/*     */   {
/* 153 */     return this.field_3_tickMarkFrequency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTickMarkFrequency(short field_3_tickMarkFrequency)
/*     */   {
/* 161 */     this.field_3_tickMarkFrequency = field_3_tickMarkFrequency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 169 */     return this.field_4_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_4_options)
/*     */   {
/* 177 */     this.field_4_options = field_4_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueAxisCrossing(boolean value)
/*     */   {
/* 186 */     this.field_4_options = valueAxisCrossing.setShortBoolean(this.field_4_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValueAxisCrossing()
/*     */   {
/* 195 */     return valueAxisCrossing.isSet(this.field_4_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrossesFarRight(boolean value)
/*     */   {
/* 204 */     this.field_4_options = crossesFarRight.setShortBoolean(this.field_4_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCrossesFarRight()
/*     */   {
/* 213 */     return crossesFarRight.isSet(this.field_4_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReversed(boolean value)
/*     */   {
/* 222 */     this.field_4_options = reversed.setShortBoolean(this.field_4_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReversed()
/*     */   {
/* 231 */     return reversed.isSet(this.field_4_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\CategorySeriesAxisRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */