/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChartEndBlockRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 2131;
/*    */   private short rt;
/*    */   private short grbitFrt;
/*    */   private short iObjectKind;
/*    */   private byte[] unused;
/*    */   
/*    */   public ChartEndBlockRecord() {}
/*    */   
/*    */   public ChartEndBlockRecord(RecordInputStream in)
/*    */   {
/* 42 */     this.rt = in.readShort();
/* 43 */     this.grbitFrt = in.readShort();
/* 44 */     this.iObjectKind = in.readShort();
/*    */     
/*    */ 
/* 47 */     if (in.available() == 0) {
/* 48 */       this.unused = new byte[0];
/*    */     } else {
/* 50 */       this.unused = new byte[6];
/* 51 */       in.readFully(this.unused);
/*    */     }
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 57 */     return 6 + this.unused.length;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 62 */     return 2131;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out)
/*    */   {
/* 67 */     out.writeShort(this.rt);
/* 68 */     out.writeShort(this.grbitFrt);
/* 69 */     out.writeShort(this.iObjectKind);
/*    */     
/* 71 */     out.write(this.unused);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 76 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 78 */     buffer.append("[ENDBLOCK]\n");
/* 79 */     buffer.append("    .rt         =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 80 */     buffer.append("    .grbitFrt   =").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 81 */     buffer.append("    .iObjectKind=").append(HexDump.shortToHex(this.iObjectKind)).append('\n');
/* 82 */     buffer.append("    .unused     =").append(HexDump.toHex(this.unused)).append('\n');
/* 83 */     buffer.append("[/ENDBLOCK]\n");
/* 84 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public ChartEndBlockRecord clone()
/*    */   {
/* 89 */     ChartEndBlockRecord record = new ChartEndBlockRecord();
/*    */     
/* 91 */     record.rt = this.rt;
/* 92 */     record.grbitFrt = this.grbitFrt;
/* 93 */     record.iObjectKind = this.iObjectKind;
/* 94 */     record.unused = ((byte[])this.unused.clone());
/*    */     
/* 96 */     return record;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartEndBlockRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */