/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChartEndObjectRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 2133;
/*    */   private short rt;
/*    */   private short grbitFrt;
/*    */   private short iObjectKind;
/*    */   private byte[] unused;
/*    */   
/*    */   public ChartEndObjectRecord(RecordInputStream in)
/*    */   {
/* 39 */     this.rt = in.readShort();
/* 40 */     this.grbitFrt = in.readShort();
/* 41 */     this.iObjectKind = in.readShort();
/*    */     
/* 43 */     this.unused = new byte[6];
/* 44 */     in.readFully(this.unused);
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 49 */     return 12;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 54 */     return 2133;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out)
/*    */   {
/* 59 */     out.writeShort(this.rt);
/* 60 */     out.writeShort(this.grbitFrt);
/* 61 */     out.writeShort(this.iObjectKind);
/*    */     
/* 63 */     out.write(this.unused);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 68 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 70 */     buffer.append("[ENDOBJECT]\n");
/* 71 */     buffer.append("    .rt         =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 72 */     buffer.append("    .grbitFrt   =").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 73 */     buffer.append("    .iObjectKind=").append(HexDump.shortToHex(this.iObjectKind)).append('\n');
/* 74 */     buffer.append("    .unused     =").append(HexDump.toHex(this.unused)).append('\n');
/* 75 */     buffer.append("[/ENDOBJECT]\n");
/* 76 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartEndObjectRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */