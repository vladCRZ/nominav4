/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChartFRTInfoRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 2128;
/*     */   private short rt;
/*     */   private short grbitFrt;
/*     */   private byte verOriginator;
/*     */   private byte verWriter;
/*     */   private CFRTID[] rgCFRTID;
/*     */   
/*     */   private static final class CFRTID
/*     */   {
/*     */     public static final int ENCODED_SIZE = 4;
/*     */     private int rtFirst;
/*     */     private int rtLast;
/*     */     
/*     */     public CFRTID(LittleEndianInput in)
/*     */     {
/*  46 */       this.rtFirst = in.readShort();
/*  47 */       this.rtLast = in.readShort();
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  51 */       out.writeShort(this.rtFirst);
/*  52 */       out.writeShort(this.rtLast);
/*     */     }
/*     */   }
/*     */   
/*     */   public ChartFRTInfoRecord(RecordInputStream in) {
/*  57 */     this.rt = in.readShort();
/*  58 */     this.grbitFrt = in.readShort();
/*  59 */     this.verOriginator = in.readByte();
/*  60 */     this.verWriter = in.readByte();
/*  61 */     int cCFRTID = in.readShort();
/*     */     
/*  63 */     this.rgCFRTID = new CFRTID[cCFRTID];
/*  64 */     for (int i = 0; i < cCFRTID; i++) {
/*  65 */       this.rgCFRTID[i] = new CFRTID(in);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/*  71 */     return 8 + this.rgCFRTID.length * 4;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  76 */     return 2128;
/*     */   }
/*     */   
/*     */ 
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/*  82 */     out.writeShort(this.rt);
/*  83 */     out.writeShort(this.grbitFrt);
/*  84 */     out.writeByte(this.verOriginator);
/*  85 */     out.writeByte(this.verWriter);
/*  86 */     int nCFRTIDs = this.rgCFRTID.length;
/*  87 */     out.writeShort(nCFRTIDs);
/*     */     
/*  89 */     for (int i = 0; i < nCFRTIDs; i++) {
/*  90 */       this.rgCFRTID[i].serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  96 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  98 */     buffer.append("[CHARTFRTINFO]\n");
/*  99 */     buffer.append("    .rt           =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 100 */     buffer.append("    .grbitFrt     =").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 101 */     buffer.append("    .verOriginator=").append(HexDump.byteToHex(this.verOriginator)).append('\n');
/* 102 */     buffer.append("    .verWriter    =").append(HexDump.byteToHex(this.verOriginator)).append('\n');
/* 103 */     buffer.append("    .nCFRTIDs     =").append(HexDump.shortToHex(this.rgCFRTID.length)).append('\n');
/* 104 */     buffer.append("[/CHARTFRTINFO]\n");
/* 105 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartFRTInfoRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */