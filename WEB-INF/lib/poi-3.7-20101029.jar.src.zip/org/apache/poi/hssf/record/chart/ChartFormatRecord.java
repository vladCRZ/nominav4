/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChartFormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4116;
/*  38 */   private static final BitField varyDisplayPattern = BitFieldFactory.getInstance(1);
/*     */   
/*     */   private int field1_x_position;
/*     */   
/*     */   private int field2_y_position;
/*     */   
/*     */   private int field3_width;
/*     */   private int field4_height;
/*     */   private int field5_grbit;
/*     */   private int field6_unknown;
/*     */   
/*     */   public ChartFormatRecord() {}
/*     */   
/*     */   public ChartFormatRecord(RecordInputStream in)
/*     */   {
/*  53 */     this.field1_x_position = in.readInt();
/*  54 */     this.field2_y_position = in.readInt();
/*  55 */     this.field3_width = in.readInt();
/*  56 */     this.field4_height = in.readInt();
/*  57 */     this.field5_grbit = in.readUShort();
/*  58 */     this.field6_unknown = in.readUShort();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  62 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  64 */     buffer.append("[CHARTFORMAT]\n");
/*  65 */     buffer.append("    .xPosition       = ").append(getXPosition()).append("\n");
/*  66 */     buffer.append("    .yPosition       = ").append(getYPosition()).append("\n");
/*  67 */     buffer.append("    .width           = ").append(getWidth()).append("\n");
/*  68 */     buffer.append("    .height          = ").append(getHeight()).append("\n");
/*  69 */     buffer.append("    .grBit           = ").append(HexDump.intToHex(this.field5_grbit)).append("\n");
/*  70 */     buffer.append("[/CHARTFORMAT]\n");
/*  71 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  75 */     out.writeInt(getXPosition());
/*  76 */     out.writeInt(getYPosition());
/*  77 */     out.writeInt(getWidth());
/*  78 */     out.writeInt(getHeight());
/*  79 */     out.writeShort(this.field5_grbit);
/*  80 */     out.writeShort(this.field6_unknown);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  84 */     return 20;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  88 */     return 4116;
/*     */   }
/*     */   
/*     */   public int getXPosition() {
/*  92 */     return this.field1_x_position;
/*     */   }
/*     */   
/*     */   public void setXPosition(int xPosition) {
/*  96 */     this.field1_x_position = xPosition;
/*     */   }
/*     */   
/*     */   public int getYPosition() {
/* 100 */     return this.field2_y_position;
/*     */   }
/*     */   
/*     */   public void setYPosition(int yPosition) {
/* 104 */     this.field2_y_position = yPosition;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 108 */     return this.field3_width;
/*     */   }
/*     */   
/*     */   public void setWidth(int width) {
/* 112 */     this.field3_width = width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 116 */     return this.field4_height;
/*     */   }
/*     */   
/*     */   public void setHeight(int height) {
/* 120 */     this.field4_height = height;
/*     */   }
/*     */   
/*     */   public boolean getVaryDisplayPattern() {
/* 124 */     return varyDisplayPattern.isSet(this.field5_grbit);
/*     */   }
/*     */   
/*     */   public void setVaryDisplayPattern(boolean value) {
/* 128 */     this.field5_grbit = varyDisplayPattern.setBoolean(this.field5_grbit, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */