/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChartRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4098;
/*     */   private int field_1_x;
/*     */   private int field_2_y;
/*     */   private int field_3_width;
/*     */   private int field_4_height;
/*     */   
/*     */   public ChartRecord() {}
/*     */   
/*     */   public ChartRecord(RecordInputStream in)
/*     */   {
/*  56 */     this.field_1_x = in.readInt();
/*  57 */     this.field_2_y = in.readInt();
/*  58 */     this.field_3_width = in.readInt();
/*  59 */     this.field_4_height = in.readInt();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  63 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  65 */     sb.append("[CHART]\n");
/*  66 */     sb.append("    .x     = ").append(getX()).append('\n');
/*  67 */     sb.append("    .y     = ").append(getY()).append('\n');
/*  68 */     sb.append("    .width = ").append(getWidth()).append('\n');
/*  69 */     sb.append("    .height= ").append(getHeight()).append('\n');
/*  70 */     sb.append("[/CHART]\n");
/*  71 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  75 */     out.writeInt(this.field_1_x);
/*  76 */     out.writeInt(this.field_2_y);
/*  77 */     out.writeInt(this.field_3_width);
/*  78 */     out.writeInt(this.field_4_height);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  82 */     return 16;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  87 */     return 4098;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  91 */     ChartRecord rec = new ChartRecord();
/*     */     
/*  93 */     rec.field_1_x = this.field_1_x;
/*  94 */     rec.field_2_y = this.field_2_y;
/*  95 */     rec.field_3_width = this.field_3_width;
/*  96 */     rec.field_4_height = this.field_4_height;
/*  97 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getX()
/*     */   {
/* 107 */     return this.field_1_x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setX(int x)
/*     */   {
/* 114 */     this.field_1_x = x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getY()
/*     */   {
/* 121 */     return this.field_2_y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setY(int y)
/*     */   {
/* 128 */     this.field_2_y = y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 135 */     return this.field_3_width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 142 */     this.field_3_width = width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 149 */     return this.field_4_height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 156 */     this.field_4_height = height;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */