/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChartStartBlockRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 2130;
/*    */   private short rt;
/*    */   private short grbitFrt;
/*    */   private short iObjectKind;
/*    */   private short iObjectContext;
/*    */   private short iObjectInstance1;
/*    */   private short iObjectInstance2;
/*    */   
/*    */   public ChartStartBlockRecord() {}
/*    */   
/*    */   public ChartStartBlockRecord(RecordInputStream in)
/*    */   {
/* 44 */     this.rt = in.readShort();
/* 45 */     this.grbitFrt = in.readShort();
/* 46 */     this.iObjectKind = in.readShort();
/* 47 */     this.iObjectContext = in.readShort();
/* 48 */     this.iObjectInstance1 = in.readShort();
/* 49 */     this.iObjectInstance2 = in.readShort();
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 54 */     return 12;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 59 */     return 2130;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out)
/*    */   {
/* 64 */     out.writeShort(this.rt);
/* 65 */     out.writeShort(this.grbitFrt);
/* 66 */     out.writeShort(this.iObjectKind);
/* 67 */     out.writeShort(this.iObjectContext);
/* 68 */     out.writeShort(this.iObjectInstance1);
/* 69 */     out.writeShort(this.iObjectInstance2);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 74 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 76 */     buffer.append("[STARTBLOCK]\n");
/* 77 */     buffer.append("    .rt              =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 78 */     buffer.append("    .grbitFrt        =").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 79 */     buffer.append("    .iObjectKind     =").append(HexDump.shortToHex(this.iObjectKind)).append('\n');
/* 80 */     buffer.append("    .iObjectContext  =").append(HexDump.shortToHex(this.iObjectContext)).append('\n');
/* 81 */     buffer.append("    .iObjectInstance1=").append(HexDump.shortToHex(this.iObjectInstance1)).append('\n');
/* 82 */     buffer.append("    .iObjectInstance2=").append(HexDump.shortToHex(this.iObjectInstance2)).append('\n');
/* 83 */     buffer.append("[/STARTBLOCK]\n");
/* 84 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public ChartStartBlockRecord clone()
/*    */   {
/* 89 */     ChartStartBlockRecord record = new ChartStartBlockRecord();
/*    */     
/* 91 */     record.rt = this.rt;
/* 92 */     record.grbitFrt = this.grbitFrt;
/* 93 */     record.iObjectKind = this.iObjectKind;
/* 94 */     record.iObjectContext = this.iObjectContext;
/* 95 */     record.iObjectInstance1 = this.iObjectInstance1;
/* 96 */     record.iObjectInstance2 = this.iObjectInstance2;
/*    */     
/* 98 */     return record;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartStartBlockRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */