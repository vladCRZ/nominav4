/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChartStartObjectRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 2132;
/*    */   private short rt;
/*    */   private short grbitFrt;
/*    */   private short iObjectKind;
/*    */   private short iObjectContext;
/*    */   private short iObjectInstance1;
/*    */   private short iObjectInstance2;
/*    */   
/*    */   public ChartStartObjectRecord(RecordInputStream in)
/*    */   {
/* 41 */     this.rt = in.readShort();
/* 42 */     this.grbitFrt = in.readShort();
/* 43 */     this.iObjectKind = in.readShort();
/* 44 */     this.iObjectContext = in.readShort();
/* 45 */     this.iObjectInstance1 = in.readShort();
/* 46 */     this.iObjectInstance2 = in.readShort();
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 51 */     return 12;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 56 */     return 2132;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out)
/*    */   {
/* 61 */     out.writeShort(this.rt);
/* 62 */     out.writeShort(this.grbitFrt);
/* 63 */     out.writeShort(this.iObjectKind);
/* 64 */     out.writeShort(this.iObjectContext);
/* 65 */     out.writeShort(this.iObjectInstance1);
/* 66 */     out.writeShort(this.iObjectInstance2);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 71 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 73 */     buffer.append("[STARTOBJECT]\n");
/* 74 */     buffer.append("    .rt              =").append(HexDump.shortToHex(this.rt)).append('\n');
/* 75 */     buffer.append("    .grbitFrt        =").append(HexDump.shortToHex(this.grbitFrt)).append('\n');
/* 76 */     buffer.append("    .iObjectKind     =").append(HexDump.shortToHex(this.iObjectKind)).append('\n');
/* 77 */     buffer.append("    .iObjectContext  =").append(HexDump.shortToHex(this.iObjectContext)).append('\n');
/* 78 */     buffer.append("    .iObjectInstance1=").append(HexDump.shortToHex(this.iObjectInstance1)).append('\n');
/* 79 */     buffer.append("    .iObjectInstance2=").append(HexDump.shortToHex(this.iObjectInstance2)).append('\n');
/* 80 */     buffer.append("[/STARTOBJECT]\n");
/* 81 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartStartObjectRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */