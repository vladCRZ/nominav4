/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChartTitleFormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4176;
/*     */   private CTFormat[] _formats;
/*     */   
/*     */   private static final class CTFormat
/*     */   {
/*     */     public static final int ENCODED_SIZE = 4;
/*     */     private int _offset;
/*     */     private int _fontIndex;
/*     */     
/*     */     protected CTFormat(short offset, short fontIdx)
/*     */     {
/*  42 */       this._offset = offset;
/*  43 */       this._fontIndex = fontIdx;
/*     */     }
/*     */     
/*     */     public CTFormat(RecordInputStream in) {
/*  47 */       this._offset = in.readShort();
/*  48 */       this._fontIndex = in.readShort();
/*     */     }
/*     */     
/*     */     public int getOffset() {
/*  52 */       return this._offset;
/*     */     }
/*     */     
/*  55 */     public void setOffset(int newOff) { this._offset = newOff; }
/*     */     
/*     */     public int getFontIndex() {
/*  58 */       return this._fontIndex;
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  62 */       out.writeShort(this._offset);
/*  63 */       out.writeShort(this._fontIndex);
/*     */     }
/*     */   }
/*     */   
/*     */   public ChartTitleFormatRecord(RecordInputStream in)
/*     */   {
/*  69 */     int nRecs = in.readUShort();
/*  70 */     this._formats = new CTFormat[nRecs];
/*     */     
/*  72 */     for (int i = 0; i < nRecs; i++) {
/*  73 */       this._formats[i] = new CTFormat(in);
/*     */     }
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  78 */     out.writeShort(this._formats.length);
/*  79 */     for (int i = 0; i < this._formats.length; i++) {
/*  80 */       this._formats[i].serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  85 */     return 2 + 4 * this._formats.length;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  89 */     return 4176;
/*     */   }
/*     */   
/*     */   public int getFormatCount() {
/*  93 */     return this._formats.length;
/*     */   }
/*     */   
/*     */   public void modifyFormatRun(short oldPos, short newLen) {
/*  97 */     int shift = 0;
/*  98 */     for (int i = 0; i < this._formats.length; i++) {
/*  99 */       CTFormat ctf = this._formats[i];
/* 100 */       if (shift != 0) {
/* 101 */         ctf.setOffset(ctf.getOffset() + shift);
/* 102 */       } else if ((oldPos == ctf.getOffset()) && (i < this._formats.length - 1)) {
/* 103 */         CTFormat nextCTF = this._formats[(i + 1)];
/* 104 */         shift = newLen - (nextCTF.getOffset() - ctf.getOffset());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 110 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 112 */     buffer.append("[CHARTTITLEFORMAT]\n");
/* 113 */     buffer.append("    .format_runs       = ").append(this._formats.length).append("\n");
/* 114 */     for (int i = 0; i < this._formats.length; i++) {
/* 115 */       CTFormat ctf = this._formats[i];
/* 116 */       buffer.append("       .char_offset= ").append(ctf.getOffset());
/* 117 */       buffer.append(",.fontidx= ").append(ctf.getFontIndex());
/* 118 */       buffer.append("\n");
/*     */     }
/* 120 */     buffer.append("[/CHARTTITLEFORMAT]\n");
/* 121 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ChartTitleFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */