/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4195;
/*  35 */   private static final BitField horizontalBorder = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField verticalBorder = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField border = BitFieldFactory.getInstance(4);
/*  38 */   private static final BitField showSeriesKey = BitFieldFactory.getInstance(8);
/*     */   
/*     */ 
/*     */   private short field_1_options;
/*     */   
/*     */ 
/*     */ 
/*     */   public DatRecord() {}
/*     */   
/*     */ 
/*     */   public DatRecord(RecordInputStream in)
/*     */   {
/*  50 */     this.field_1_options = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  55 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  57 */     buffer.append("[DAT]\n");
/*  58 */     buffer.append("    .options              = ").append("0x").append(HexDump.toHex(getOptions())).append(" (").append(getOptions()).append(" )");
/*     */     
/*     */ 
/*  61 */     buffer.append(System.getProperty("line.separator"));
/*  62 */     buffer.append("         .horizontalBorder         = ").append(isHorizontalBorder()).append('\n');
/*  63 */     buffer.append("         .verticalBorder           = ").append(isVerticalBorder()).append('\n');
/*  64 */     buffer.append("         .border                   = ").append(isBorder()).append('\n');
/*  65 */     buffer.append("         .showSeriesKey            = ").append(isShowSeriesKey()).append('\n');
/*     */     
/*  67 */     buffer.append("[/DAT]\n");
/*  68 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  72 */     out.writeShort(this.field_1_options);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  76 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  81 */     return 4195;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  85 */     DatRecord rec = new DatRecord();
/*     */     
/*  87 */     rec.field_1_options = this.field_1_options;
/*  88 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/*  99 */     return this.field_1_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_1_options)
/*     */   {
/* 107 */     this.field_1_options = field_1_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHorizontalBorder(boolean value)
/*     */   {
/* 116 */     this.field_1_options = horizontalBorder.setShortBoolean(this.field_1_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHorizontalBorder()
/*     */   {
/* 125 */     return horizontalBorder.isSet(this.field_1_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVerticalBorder(boolean value)
/*     */   {
/* 134 */     this.field_1_options = verticalBorder.setShortBoolean(this.field_1_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVerticalBorder()
/*     */   {
/* 143 */     return verticalBorder.isSet(this.field_1_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorder(boolean value)
/*     */   {
/* 152 */     this.field_1_options = border.setShortBoolean(this.field_1_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBorder()
/*     */   {
/* 161 */     return border.isSet(this.field_1_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowSeriesKey(boolean value)
/*     */   {
/* 170 */     this.field_1_options = showSeriesKey.setShortBoolean(this.field_1_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShowSeriesKey()
/*     */   {
/* 179 */     return showSeriesKey.isSet(this.field_1_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\DatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */