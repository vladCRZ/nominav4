/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DataFormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4102;
/*  35 */   private static final BitField useExcel4Colors = BitFieldFactory.getInstance(1);
/*     */   
/*     */   private short field_1_pointNumber;
/*     */   
/*     */   private short field_2_seriesIndex;
/*     */   
/*     */   private short field_3_seriesNumber;
/*     */   
/*     */   private short field_4_formatFlags;
/*     */   
/*     */ 
/*     */   public DataFormatRecord() {}
/*     */   
/*     */   public DataFormatRecord(RecordInputStream in)
/*     */   {
/*  50 */     this.field_1_pointNumber = in.readShort();
/*  51 */     this.field_2_seriesIndex = in.readShort();
/*  52 */     this.field_3_seriesNumber = in.readShort();
/*  53 */     this.field_4_formatFlags = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  58 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  60 */     buffer.append("[DATAFORMAT]\n");
/*  61 */     buffer.append("    .pointNumber          = ").append("0x").append(HexDump.toHex(getPointNumber())).append(" (").append(getPointNumber()).append(" )");
/*     */     
/*     */ 
/*  64 */     buffer.append(System.getProperty("line.separator"));
/*  65 */     buffer.append("    .seriesIndex          = ").append("0x").append(HexDump.toHex(getSeriesIndex())).append(" (").append(getSeriesIndex()).append(" )");
/*     */     
/*     */ 
/*  68 */     buffer.append(System.getProperty("line.separator"));
/*  69 */     buffer.append("    .seriesNumber         = ").append("0x").append(HexDump.toHex(getSeriesNumber())).append(" (").append(getSeriesNumber()).append(" )");
/*     */     
/*     */ 
/*  72 */     buffer.append(System.getProperty("line.separator"));
/*  73 */     buffer.append("    .formatFlags          = ").append("0x").append(HexDump.toHex(getFormatFlags())).append(" (").append(getFormatFlags()).append(" )");
/*     */     
/*     */ 
/*  76 */     buffer.append(System.getProperty("line.separator"));
/*  77 */     buffer.append("         .useExcel4Colors          = ").append(isUseExcel4Colors()).append('\n');
/*     */     
/*  79 */     buffer.append("[/DATAFORMAT]\n");
/*  80 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  84 */     out.writeShort(this.field_1_pointNumber);
/*  85 */     out.writeShort(this.field_2_seriesIndex);
/*  86 */     out.writeShort(this.field_3_seriesNumber);
/*  87 */     out.writeShort(this.field_4_formatFlags);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  91 */     return 8;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  96 */     return 4102;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 100 */     DataFormatRecord rec = new DataFormatRecord();
/*     */     
/* 102 */     rec.field_1_pointNumber = this.field_1_pointNumber;
/* 103 */     rec.field_2_seriesIndex = this.field_2_seriesIndex;
/* 104 */     rec.field_3_seriesNumber = this.field_3_seriesNumber;
/* 105 */     rec.field_4_formatFlags = this.field_4_formatFlags;
/* 106 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getPointNumber()
/*     */   {
/* 117 */     return this.field_1_pointNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPointNumber(short field_1_pointNumber)
/*     */   {
/* 125 */     this.field_1_pointNumber = field_1_pointNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSeriesIndex()
/*     */   {
/* 133 */     return this.field_2_seriesIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSeriesIndex(short field_2_seriesIndex)
/*     */   {
/* 141 */     this.field_2_seriesIndex = field_2_seriesIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getSeriesNumber()
/*     */   {
/* 149 */     return this.field_3_seriesNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSeriesNumber(short field_3_seriesNumber)
/*     */   {
/* 157 */     this.field_3_seriesNumber = field_3_seriesNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFormatFlags()
/*     */   {
/* 165 */     return this.field_4_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormatFlags(short field_4_formatFlags)
/*     */   {
/* 173 */     this.field_4_formatFlags = field_4_formatFlags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseExcel4Colors(boolean value)
/*     */   {
/* 182 */     this.field_4_formatFlags = useExcel4Colors.setShortBoolean(this.field_4_formatFlags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUseExcel4Colors()
/*     */   {
/* 191 */     return useExcel4Colors.isSet(this.field_4_formatFlags);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\DataFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */