/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultDataLabelTextPropertiesRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4132;
/*     */   private short field_1_categoryDataType;
/*     */   public static final short CATEGORY_DATA_TYPE_SHOW_LABELS_CHARACTERISTIC = 0;
/*     */   public static final short CATEGORY_DATA_TYPE_VALUE_AND_PERCENTAGE_CHARACTERISTIC = 1;
/*     */   public static final short CATEGORY_DATA_TYPE_ALL_TEXT_CHARACTERISTIC = 2;
/*     */   
/*     */   public DefaultDataLabelTextPropertiesRecord() {}
/*     */   
/*     */   public DefaultDataLabelTextPropertiesRecord(RecordInputStream in)
/*     */   {
/*  45 */     this.field_1_categoryDataType = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  50 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  52 */     buffer.append("[DEFAULTTEXT]\n");
/*  53 */     buffer.append("    .categoryDataType     = ").append("0x").append(HexDump.toHex(getCategoryDataType())).append(" (").append(getCategoryDataType()).append(" )");
/*     */     
/*     */ 
/*  56 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  58 */     buffer.append("[/DEFAULTTEXT]\n");
/*  59 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  63 */     out.writeShort(this.field_1_categoryDataType);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  67 */     return 2;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  72 */     return 4132;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  76 */     DefaultDataLabelTextPropertiesRecord rec = new DefaultDataLabelTextPropertiesRecord();
/*     */     
/*  78 */     rec.field_1_categoryDataType = this.field_1_categoryDataType;
/*  79 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCategoryDataType()
/*     */   {
/*  95 */     return this.field_1_categoryDataType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCategoryDataType(short field_1_categoryDataType)
/*     */   {
/* 109 */     this.field_1_categoryDataType = field_1_categoryDataType;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\DefaultDataLabelTextPropertiesRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */