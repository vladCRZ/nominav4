/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EndRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 4148;
/*    */   
/*    */   public EndRecord() {}
/*    */   
/*    */   public EndRecord(RecordInputStream in) {}
/*    */   
/*    */   public String toString()
/*    */   {
/* 49 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 51 */     buffer.append("[END]\n");
/* 52 */     buffer.append("[/END]\n");
/* 53 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {}
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 60 */     return 0;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 65 */     return 4148;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 69 */     EndRecord er = new EndRecord();
/*    */     
/* 71 */     return er;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\EndRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */