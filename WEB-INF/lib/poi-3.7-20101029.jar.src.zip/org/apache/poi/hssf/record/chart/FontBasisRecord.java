/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FontBasisRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4192;
/*     */   private short field_1_xBasis;
/*     */   private short field_2_yBasis;
/*     */   private short field_3_heightBasis;
/*     */   private short field_4_scale;
/*     */   private short field_5_indexToFontTable;
/*     */   
/*     */   public FontBasisRecord() {}
/*     */   
/*     */   public FontBasisRecord(RecordInputStream in)
/*     */   {
/*  46 */     this.field_1_xBasis = in.readShort();
/*  47 */     this.field_2_yBasis = in.readShort();
/*  48 */     this.field_3_heightBasis = in.readShort();
/*  49 */     this.field_4_scale = in.readShort();
/*  50 */     this.field_5_indexToFontTable = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  55 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  57 */     buffer.append("[FBI]\n");
/*  58 */     buffer.append("    .xBasis               = ").append("0x").append(HexDump.toHex(getXBasis())).append(" (").append(getXBasis()).append(" )");
/*     */     
/*     */ 
/*  61 */     buffer.append(System.getProperty("line.separator"));
/*  62 */     buffer.append("    .yBasis               = ").append("0x").append(HexDump.toHex(getYBasis())).append(" (").append(getYBasis()).append(" )");
/*     */     
/*     */ 
/*  65 */     buffer.append(System.getProperty("line.separator"));
/*  66 */     buffer.append("    .heightBasis          = ").append("0x").append(HexDump.toHex(getHeightBasis())).append(" (").append(getHeightBasis()).append(" )");
/*     */     
/*     */ 
/*  69 */     buffer.append(System.getProperty("line.separator"));
/*  70 */     buffer.append("    .scale                = ").append("0x").append(HexDump.toHex(getScale())).append(" (").append(getScale()).append(" )");
/*     */     
/*     */ 
/*  73 */     buffer.append(System.getProperty("line.separator"));
/*  74 */     buffer.append("    .indexToFontTable     = ").append("0x").append(HexDump.toHex(getIndexToFontTable())).append(" (").append(getIndexToFontTable()).append(" )");
/*     */     
/*     */ 
/*  77 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  79 */     buffer.append("[/FBI]\n");
/*  80 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  84 */     out.writeShort(this.field_1_xBasis);
/*  85 */     out.writeShort(this.field_2_yBasis);
/*  86 */     out.writeShort(this.field_3_heightBasis);
/*  87 */     out.writeShort(this.field_4_scale);
/*  88 */     out.writeShort(this.field_5_indexToFontTable);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  92 */     return 10;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  97 */     return 4192;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 101 */     FontBasisRecord rec = new FontBasisRecord();
/*     */     
/* 103 */     rec.field_1_xBasis = this.field_1_xBasis;
/* 104 */     rec.field_2_yBasis = this.field_2_yBasis;
/* 105 */     rec.field_3_heightBasis = this.field_3_heightBasis;
/* 106 */     rec.field_4_scale = this.field_4_scale;
/* 107 */     rec.field_5_indexToFontTable = this.field_5_indexToFontTable;
/* 108 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getXBasis()
/*     */   {
/* 119 */     return this.field_1_xBasis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXBasis(short field_1_xBasis)
/*     */   {
/* 127 */     this.field_1_xBasis = field_1_xBasis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getYBasis()
/*     */   {
/* 135 */     return this.field_2_yBasis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYBasis(short field_2_yBasis)
/*     */   {
/* 143 */     this.field_2_yBasis = field_2_yBasis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getHeightBasis()
/*     */   {
/* 151 */     return this.field_3_heightBasis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeightBasis(short field_3_heightBasis)
/*     */   {
/* 159 */     this.field_3_heightBasis = field_3_heightBasis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getScale()
/*     */   {
/* 167 */     return this.field_4_scale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScale(short field_4_scale)
/*     */   {
/* 175 */     this.field_4_scale = field_4_scale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getIndexToFontTable()
/*     */   {
/* 183 */     return this.field_5_indexToFontTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndexToFontTable(short field_5_indexToFontTable)
/*     */   {
/* 191 */     this.field_5_indexToFontTable = field_5_indexToFontTable;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\FontBasisRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */