/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FrameRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4146;
/*  35 */   private static final BitField autoSize = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField autoPosition = BitFieldFactory.getInstance(2);
/*     */   
/*     */   private short field_1_borderType;
/*     */   
/*     */   public static final short BORDER_TYPE_REGULAR = 0;
/*     */   
/*     */   public static final short BORDER_TYPE_SHADOW = 1;
/*     */   
/*     */   private short field_2_options;
/*     */   
/*     */ 
/*     */   public FrameRecord() {}
/*     */   
/*     */   public FrameRecord(RecordInputStream in)
/*     */   {
/*  51 */     this.field_1_borderType = in.readShort();
/*  52 */     this.field_2_options = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  57 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  59 */     buffer.append("[FRAME]\n");
/*  60 */     buffer.append("    .borderType           = ").append("0x").append(HexDump.toHex(getBorderType())).append(" (").append(getBorderType()).append(" )");
/*     */     
/*     */ 
/*  63 */     buffer.append(System.getProperty("line.separator"));
/*  64 */     buffer.append("    .options              = ").append("0x").append(HexDump.toHex(getOptions())).append(" (").append(getOptions()).append(" )");
/*     */     
/*     */ 
/*  67 */     buffer.append(System.getProperty("line.separator"));
/*  68 */     buffer.append("         .autoSize                 = ").append(isAutoSize()).append('\n');
/*  69 */     buffer.append("         .autoPosition             = ").append(isAutoPosition()).append('\n');
/*     */     
/*  71 */     buffer.append("[/FRAME]\n");
/*  72 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  76 */     out.writeShort(this.field_1_borderType);
/*  77 */     out.writeShort(this.field_2_options);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  81 */     return 4;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  86 */     return 4146;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  90 */     FrameRecord rec = new FrameRecord();
/*     */     
/*  92 */     rec.field_1_borderType = this.field_1_borderType;
/*  93 */     rec.field_2_options = this.field_2_options;
/*  94 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getBorderType()
/*     */   {
/* 109 */     return this.field_1_borderType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorderType(short field_1_borderType)
/*     */   {
/* 122 */     this.field_1_borderType = field_1_borderType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 130 */     return this.field_2_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_2_options)
/*     */   {
/* 138 */     this.field_2_options = field_2_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoSize(boolean value)
/*     */   {
/* 147 */     this.field_2_options = autoSize.setShortBoolean(this.field_2_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoSize()
/*     */   {
/* 156 */     return autoSize.isSet(this.field_2_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoPosition(boolean value)
/*     */   {
/* 165 */     this.field_2_options = autoPosition.setShortBoolean(this.field_2_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoPosition()
/*     */   {
/* 174 */     return autoPosition.isSet(this.field_2_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\FrameRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */