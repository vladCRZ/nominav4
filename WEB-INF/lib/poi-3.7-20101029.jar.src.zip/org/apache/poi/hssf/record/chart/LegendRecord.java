/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LegendRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4117;
/*  35 */   private static final BitField autoPosition = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField autoSeries = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField autoXPositioning = BitFieldFactory.getInstance(4);
/*  38 */   private static final BitField autoYPositioning = BitFieldFactory.getInstance(8);
/*  39 */   private static final BitField vertical = BitFieldFactory.getInstance(16);
/*  40 */   private static final BitField dataTable = BitFieldFactory.getInstance(32);
/*     */   
/*     */   private int field_1_xAxisUpperLeft;
/*     */   
/*     */   private int field_2_yAxisUpperLeft;
/*     */   
/*     */   private int field_3_xSize;
/*     */   
/*     */   private int field_4_ySize;
/*     */   
/*     */   private byte field_5_type;
/*     */   public static final byte TYPE_BOTTOM = 0;
/*     */   public static final byte TYPE_CORNER = 1;
/*     */   public static final byte TYPE_TOP = 2;
/*     */   public static final byte TYPE_RIGHT = 3;
/*     */   public static final byte TYPE_LEFT = 4;
/*     */   public static final byte TYPE_UNDOCKED = 7;
/*     */   private byte field_6_spacing;
/*     */   public static final byte SPACING_CLOSE = 0;
/*     */   public static final byte SPACING_MEDIUM = 1;
/*     */   public static final byte SPACING_OPEN = 2;
/*     */   private short field_7_options;
/*     */   
/*     */   public LegendRecord() {}
/*     */   
/*     */   public LegendRecord(RecordInputStream in)
/*     */   {
/*  67 */     this.field_1_xAxisUpperLeft = in.readInt();
/*  68 */     this.field_2_yAxisUpperLeft = in.readInt();
/*  69 */     this.field_3_xSize = in.readInt();
/*  70 */     this.field_4_ySize = in.readInt();
/*  71 */     this.field_5_type = in.readByte();
/*  72 */     this.field_6_spacing = in.readByte();
/*  73 */     this.field_7_options = in.readShort();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  78 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  80 */     buffer.append("[LEGEND]\n");
/*  81 */     buffer.append("    .xAxisUpperLeft       = ").append("0x").append(HexDump.toHex(getXAxisUpperLeft())).append(" (").append(getXAxisUpperLeft()).append(" )");
/*     */     
/*     */ 
/*  84 */     buffer.append(System.getProperty("line.separator"));
/*  85 */     buffer.append("    .yAxisUpperLeft       = ").append("0x").append(HexDump.toHex(getYAxisUpperLeft())).append(" (").append(getYAxisUpperLeft()).append(" )");
/*     */     
/*     */ 
/*  88 */     buffer.append(System.getProperty("line.separator"));
/*  89 */     buffer.append("    .xSize                = ").append("0x").append(HexDump.toHex(getXSize())).append(" (").append(getXSize()).append(" )");
/*     */     
/*     */ 
/*  92 */     buffer.append(System.getProperty("line.separator"));
/*  93 */     buffer.append("    .ySize                = ").append("0x").append(HexDump.toHex(getYSize())).append(" (").append(getYSize()).append(" )");
/*     */     
/*     */ 
/*  96 */     buffer.append(System.getProperty("line.separator"));
/*  97 */     buffer.append("    .type                 = ").append("0x").append(HexDump.toHex(getType())).append(" (").append(getType()).append(" )");
/*     */     
/*     */ 
/* 100 */     buffer.append(System.getProperty("line.separator"));
/* 101 */     buffer.append("    .spacing              = ").append("0x").append(HexDump.toHex(getSpacing())).append(" (").append(getSpacing()).append(" )");
/*     */     
/*     */ 
/* 104 */     buffer.append(System.getProperty("line.separator"));
/* 105 */     buffer.append("    .options              = ").append("0x").append(HexDump.toHex(getOptions())).append(" (").append(getOptions()).append(" )");
/*     */     
/*     */ 
/* 108 */     buffer.append(System.getProperty("line.separator"));
/* 109 */     buffer.append("         .autoPosition             = ").append(isAutoPosition()).append('\n');
/* 110 */     buffer.append("         .autoSeries               = ").append(isAutoSeries()).append('\n');
/* 111 */     buffer.append("         .autoXPositioning         = ").append(isAutoXPositioning()).append('\n');
/* 112 */     buffer.append("         .autoYPositioning         = ").append(isAutoYPositioning()).append('\n');
/* 113 */     buffer.append("         .vertical                 = ").append(isVertical()).append('\n');
/* 114 */     buffer.append("         .dataTable                = ").append(isDataTable()).append('\n');
/*     */     
/* 116 */     buffer.append("[/LEGEND]\n");
/* 117 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 121 */     out.writeInt(this.field_1_xAxisUpperLeft);
/* 122 */     out.writeInt(this.field_2_yAxisUpperLeft);
/* 123 */     out.writeInt(this.field_3_xSize);
/* 124 */     out.writeInt(this.field_4_ySize);
/* 125 */     out.writeByte(this.field_5_type);
/* 126 */     out.writeByte(this.field_6_spacing);
/* 127 */     out.writeShort(this.field_7_options);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 131 */     return 20;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 136 */     return 4117;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 140 */     LegendRecord rec = new LegendRecord();
/*     */     
/* 142 */     rec.field_1_xAxisUpperLeft = this.field_1_xAxisUpperLeft;
/* 143 */     rec.field_2_yAxisUpperLeft = this.field_2_yAxisUpperLeft;
/* 144 */     rec.field_3_xSize = this.field_3_xSize;
/* 145 */     rec.field_4_ySize = this.field_4_ySize;
/* 146 */     rec.field_5_type = this.field_5_type;
/* 147 */     rec.field_6_spacing = this.field_6_spacing;
/* 148 */     rec.field_7_options = this.field_7_options;
/* 149 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXAxisUpperLeft()
/*     */   {
/* 160 */     return this.field_1_xAxisUpperLeft;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXAxisUpperLeft(int field_1_xAxisUpperLeft)
/*     */   {
/* 168 */     this.field_1_xAxisUpperLeft = field_1_xAxisUpperLeft;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getYAxisUpperLeft()
/*     */   {
/* 176 */     return this.field_2_yAxisUpperLeft;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYAxisUpperLeft(int field_2_yAxisUpperLeft)
/*     */   {
/* 184 */     this.field_2_yAxisUpperLeft = field_2_yAxisUpperLeft;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getXSize()
/*     */   {
/* 192 */     return this.field_3_xSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXSize(int field_3_xSize)
/*     */   {
/* 200 */     this.field_3_xSize = field_3_xSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getYSize()
/*     */   {
/* 208 */     return this.field_4_ySize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYSize(int field_4_ySize)
/*     */   {
/* 216 */     this.field_4_ySize = field_4_ySize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getType()
/*     */   {
/* 232 */     return this.field_5_type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(byte field_5_type)
/*     */   {
/* 249 */     this.field_5_type = field_5_type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getSpacing()
/*     */   {
/* 262 */     return this.field_6_spacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSpacing(byte field_6_spacing)
/*     */   {
/* 276 */     this.field_6_spacing = field_6_spacing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 284 */     return this.field_7_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_7_options)
/*     */   {
/* 292 */     this.field_7_options = field_7_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoPosition(boolean value)
/*     */   {
/* 301 */     this.field_7_options = autoPosition.setShortBoolean(this.field_7_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoPosition()
/*     */   {
/* 310 */     return autoPosition.isSet(this.field_7_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoSeries(boolean value)
/*     */   {
/* 319 */     this.field_7_options = autoSeries.setShortBoolean(this.field_7_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoSeries()
/*     */   {
/* 328 */     return autoSeries.isSet(this.field_7_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoXPositioning(boolean value)
/*     */   {
/* 337 */     this.field_7_options = autoXPositioning.setShortBoolean(this.field_7_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoXPositioning()
/*     */   {
/* 346 */     return autoXPositioning.isSet(this.field_7_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoYPositioning(boolean value)
/*     */   {
/* 355 */     this.field_7_options = autoYPositioning.setShortBoolean(this.field_7_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoYPositioning()
/*     */   {
/* 364 */     return autoYPositioning.isSet(this.field_7_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVertical(boolean value)
/*     */   {
/* 373 */     this.field_7_options = vertical.setShortBoolean(this.field_7_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVertical()
/*     */   {
/* 382 */     return vertical.isSet(this.field_7_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataTable(boolean value)
/*     */   {
/* 391 */     this.field_7_options = dataTable.setShortBoolean(this.field_7_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDataTable()
/*     */   {
/* 400 */     return dataTable.isSet(this.field_7_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\LegendRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */