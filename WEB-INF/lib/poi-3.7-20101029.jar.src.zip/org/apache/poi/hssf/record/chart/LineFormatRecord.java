/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LineFormatRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4103;
/*  35 */   private static final BitField auto = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField drawTicks = BitFieldFactory.getInstance(4);
/*  37 */   private static final BitField unknown = BitFieldFactory.getInstance(4);
/*     */   
/*     */   private int field_1_lineColor;
/*     */   
/*     */   private short field_2_linePattern;
/*     */   
/*     */   public static final short LINE_PATTERN_SOLID = 0;
/*     */   
/*     */   public static final short LINE_PATTERN_DASH = 1;
/*     */   
/*     */   public static final short LINE_PATTERN_DOT = 2;
/*     */   public static final short LINE_PATTERN_DASH_DOT = 3;
/*     */   public static final short LINE_PATTERN_DASH_DOT_DOT = 4;
/*     */   public static final short LINE_PATTERN_NONE = 5;
/*     */   public static final short LINE_PATTERN_DARK_GRAY_PATTERN = 6;
/*     */   public static final short LINE_PATTERN_MEDIUM_GRAY_PATTERN = 7;
/*     */   public static final short LINE_PATTERN_LIGHT_GRAY_PATTERN = 8;
/*     */   private short field_3_weight;
/*     */   public static final short WEIGHT_HAIRLINE = -1;
/*     */   public static final short WEIGHT_NARROW = 0;
/*     */   public static final short WEIGHT_MEDIUM = 1;
/*     */   public static final short WEIGHT_WIDE = 2;
/*     */   private short field_4_format;
/*     */   private short field_5_colourPaletteIndex;
/*     */   
/*     */   public LineFormatRecord() {}
/*     */   
/*     */   public LineFormatRecord(RecordInputStream in)
/*     */   {
/*  66 */     this.field_1_lineColor = in.readInt();
/*  67 */     this.field_2_linePattern = in.readShort();
/*  68 */     this.field_3_weight = in.readShort();
/*  69 */     this.field_4_format = in.readShort();
/*  70 */     this.field_5_colourPaletteIndex = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  76 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  78 */     buffer.append("[LINEFORMAT]\n");
/*  79 */     buffer.append("    .lineColor            = ").append("0x").append(HexDump.toHex(getLineColor())).append(" (").append(getLineColor()).append(" )");
/*     */     
/*     */ 
/*  82 */     buffer.append(System.getProperty("line.separator"));
/*  83 */     buffer.append("    .linePattern          = ").append("0x").append(HexDump.toHex(getLinePattern())).append(" (").append(getLinePattern()).append(" )");
/*     */     
/*     */ 
/*  86 */     buffer.append(System.getProperty("line.separator"));
/*  87 */     buffer.append("    .weight               = ").append("0x").append(HexDump.toHex(getWeight())).append(" (").append(getWeight()).append(" )");
/*     */     
/*     */ 
/*  90 */     buffer.append(System.getProperty("line.separator"));
/*  91 */     buffer.append("    .format               = ").append("0x").append(HexDump.toHex(getFormat())).append(" (").append(getFormat()).append(" )");
/*     */     
/*     */ 
/*  94 */     buffer.append(System.getProperty("line.separator"));
/*  95 */     buffer.append("         .auto                     = ").append(isAuto()).append('\n');
/*  96 */     buffer.append("         .drawTicks                = ").append(isDrawTicks()).append('\n');
/*  97 */     buffer.append("         .unknown                  = ").append(isUnknown()).append('\n');
/*  98 */     buffer.append("    .colourPaletteIndex   = ").append("0x").append(HexDump.toHex(getColourPaletteIndex())).append(" (").append(getColourPaletteIndex()).append(" )");
/*     */     
/*     */ 
/* 101 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/* 103 */     buffer.append("[/LINEFORMAT]\n");
/* 104 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 108 */     out.writeInt(this.field_1_lineColor);
/* 109 */     out.writeShort(this.field_2_linePattern);
/* 110 */     out.writeShort(this.field_3_weight);
/* 111 */     out.writeShort(this.field_4_format);
/* 112 */     out.writeShort(this.field_5_colourPaletteIndex);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 116 */     return 12;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 121 */     return 4103;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 125 */     LineFormatRecord rec = new LineFormatRecord();
/*     */     
/* 127 */     rec.field_1_lineColor = this.field_1_lineColor;
/* 128 */     rec.field_2_linePattern = this.field_2_linePattern;
/* 129 */     rec.field_3_weight = this.field_3_weight;
/* 130 */     rec.field_4_format = this.field_4_format;
/* 131 */     rec.field_5_colourPaletteIndex = this.field_5_colourPaletteIndex;
/* 132 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineColor()
/*     */   {
/* 143 */     return this.field_1_lineColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineColor(int field_1_lineColor)
/*     */   {
/* 151 */     this.field_1_lineColor = field_1_lineColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLinePattern()
/*     */   {
/* 170 */     return this.field_2_linePattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLinePattern(short field_2_linePattern)
/*     */   {
/* 190 */     this.field_2_linePattern = field_2_linePattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getWeight()
/*     */   {
/* 204 */     return this.field_3_weight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWeight(short field_3_weight)
/*     */   {
/* 219 */     this.field_3_weight = field_3_weight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFormat()
/*     */   {
/* 227 */     return this.field_4_format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(short field_4_format)
/*     */   {
/* 235 */     this.field_4_format = field_4_format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getColourPaletteIndex()
/*     */   {
/* 243 */     return this.field_5_colourPaletteIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColourPaletteIndex(short field_5_colourPaletteIndex)
/*     */   {
/* 251 */     this.field_5_colourPaletteIndex = field_5_colourPaletteIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAuto(boolean value)
/*     */   {
/* 260 */     this.field_4_format = auto.setShortBoolean(this.field_4_format, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAuto()
/*     */   {
/* 269 */     return auto.isSet(this.field_4_format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDrawTicks(boolean value)
/*     */   {
/* 278 */     this.field_4_format = drawTicks.setShortBoolean(this.field_4_format, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDrawTicks()
/*     */   {
/* 287 */     return drawTicks.isSet(this.field_4_format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnknown(boolean value)
/*     */   {
/* 296 */     this.field_4_format = unknown.setShortBoolean(this.field_4_format, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnknown()
/*     */   {
/* 305 */     return unknown.isSet(this.field_4_format);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\LineFormatRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */