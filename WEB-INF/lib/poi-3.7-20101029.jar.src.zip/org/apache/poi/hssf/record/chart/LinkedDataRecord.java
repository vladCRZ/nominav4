/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.hssf.record.formula.Ptg;
/*     */ import org.apache.poi.ss.formula.Formula;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LinkedDataRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4177;
/*  37 */   private static final BitField customNumberFormat = BitFieldFactory.getInstance(1);
/*     */   
/*     */   private byte field_1_linkType;
/*     */   
/*     */   public static final byte LINK_TYPE_TITLE_OR_TEXT = 0;
/*     */   
/*     */   public static final byte LINK_TYPE_VALUES = 1;
/*     */   
/*     */   public static final byte LINK_TYPE_CATEGORIES = 2;
/*     */   
/*     */   private byte field_2_referenceType;
/*     */   public static final byte REFERENCE_TYPE_DEFAULT_CATEGORIES = 0;
/*     */   public static final byte REFERENCE_TYPE_DIRECT = 1;
/*     */   public static final byte REFERENCE_TYPE_WORKSHEET = 2;
/*     */   public static final byte REFERENCE_TYPE_NOT_USED = 3;
/*     */   public static final byte REFERENCE_TYPE_ERROR_REPORTED = 4;
/*     */   private short field_3_options;
/*     */   private short field_4_indexNumberFmtRecord;
/*     */   private Formula field_5_formulaOfLink;
/*     */   
/*     */   public LinkedDataRecord() {}
/*     */   
/*     */   public LinkedDataRecord(RecordInputStream in)
/*     */   {
/*  61 */     this.field_1_linkType = in.readByte();
/*  62 */     this.field_2_referenceType = in.readByte();
/*  63 */     this.field_3_options = in.readShort();
/*  64 */     this.field_4_indexNumberFmtRecord = in.readShort();
/*  65 */     int encodedTokenLen = in.readUShort();
/*  66 */     this.field_5_formulaOfLink = Formula.read(encodedTokenLen, in);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  70 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  72 */     buffer.append("[AI]\n");
/*  73 */     buffer.append("    .linkType             = ").append(HexDump.byteToHex(getLinkType())).append('\n');
/*  74 */     buffer.append("    .referenceType        = ").append(HexDump.byteToHex(getReferenceType())).append('\n');
/*  75 */     buffer.append("    .options              = ").append(HexDump.shortToHex(getOptions())).append('\n');
/*  76 */     buffer.append("    .customNumberFormat   = ").append(isCustomNumberFormat()).append('\n');
/*  77 */     buffer.append("    .indexNumberFmtRecord = ").append(HexDump.shortToHex(getIndexNumberFmtRecord())).append('\n');
/*  78 */     buffer.append("    .formulaOfLink        = ").append('\n');
/*  79 */     Ptg[] ptgs = this.field_5_formulaOfLink.getTokens();
/*  80 */     for (int i = 0; i < ptgs.length; i++) {
/*  81 */       Ptg ptg = ptgs[i];
/*  82 */       buffer.append(ptg.toString()).append(ptg.getRVAType()).append('\n');
/*     */     }
/*     */     
/*  85 */     buffer.append("[/AI]\n");
/*  86 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  90 */     out.writeByte(this.field_1_linkType);
/*  91 */     out.writeByte(this.field_2_referenceType);
/*  92 */     out.writeShort(this.field_3_options);
/*  93 */     out.writeShort(this.field_4_indexNumberFmtRecord);
/*  94 */     this.field_5_formulaOfLink.serialize(out);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  98 */     return 6 + this.field_5_formulaOfLink.getEncodedSize();
/*     */   }
/*     */   
/*     */   public short getSid() {
/* 102 */     return 4177;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 106 */     LinkedDataRecord rec = new LinkedDataRecord();
/*     */     
/* 108 */     rec.field_1_linkType = this.field_1_linkType;
/* 109 */     rec.field_2_referenceType = this.field_2_referenceType;
/* 110 */     rec.field_3_options = this.field_3_options;
/* 111 */     rec.field_4_indexNumberFmtRecord = this.field_4_indexNumberFmtRecord;
/* 112 */     rec.field_5_formulaOfLink = this.field_5_formulaOfLink.copy();
/* 113 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getLinkType()
/*     */   {
/* 129 */     return this.field_1_linkType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLinkType(byte field_1_linkType)
/*     */   {
/* 143 */     this.field_1_linkType = field_1_linkType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getReferenceType()
/*     */   {
/* 158 */     return this.field_2_referenceType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReferenceType(byte field_2_referenceType)
/*     */   {
/* 174 */     this.field_2_referenceType = field_2_referenceType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 182 */     return this.field_3_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_3_options)
/*     */   {
/* 190 */     this.field_3_options = field_3_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getIndexNumberFmtRecord()
/*     */   {
/* 198 */     return this.field_4_indexNumberFmtRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndexNumberFmtRecord(short field_4_indexNumberFmtRecord)
/*     */   {
/* 206 */     this.field_4_indexNumberFmtRecord = field_4_indexNumberFmtRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Ptg[] getFormulaOfLink()
/*     */   {
/* 213 */     return this.field_5_formulaOfLink.getTokens();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormulaOfLink(Ptg[] ptgs)
/*     */   {
/* 221 */     this.field_5_formulaOfLink = Formula.create(ptgs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomNumberFormat(boolean value)
/*     */   {
/* 230 */     this.field_3_options = customNumberFormat.setShortBoolean(this.field_3_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCustomNumberFormat()
/*     */   {
/* 239 */     return customNumberFormat.isSet(this.field_3_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\LinkedDataRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */