/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NumberFormatIndexRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 4174;
/*    */   private short field_1_formatIndex;
/*    */   
/*    */   public NumberFormatIndexRecord() {}
/*    */   
/*    */   public NumberFormatIndexRecord(RecordInputStream in)
/*    */   {
/* 42 */     this.field_1_formatIndex = in.readShort();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 47 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 49 */     buffer.append("[IFMT]\n");
/* 50 */     buffer.append("    .formatIndex          = ").append("0x").append(HexDump.toHex(getFormatIndex())).append(" (").append(getFormatIndex()).append(" )");
/*    */     
/*    */ 
/* 53 */     buffer.append(System.getProperty("line.separator"));
/*    */     
/* 55 */     buffer.append("[/IFMT]\n");
/* 56 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 60 */     out.writeShort(this.field_1_formatIndex);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 64 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 69 */     return 4174;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 73 */     NumberFormatIndexRecord rec = new NumberFormatIndexRecord();
/*    */     
/* 75 */     rec.field_1_formatIndex = this.field_1_formatIndex;
/* 76 */     return rec;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getFormatIndex()
/*    */   {
/* 87 */     return this.field_1_formatIndex;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setFormatIndex(short field_1_formatIndex)
/*    */   {
/* 95 */     this.field_1_formatIndex = field_1_formatIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\NumberFormatIndexRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */