/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectLinkRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4135;
/*     */   private short field_1_anchorId;
/*     */   public static final short ANCHOR_ID_CHART_TITLE = 1;
/*     */   public static final short ANCHOR_ID_Y_AXIS = 2;
/*     */   public static final short ANCHOR_ID_X_AXIS = 3;
/*     */   public static final short ANCHOR_ID_SERIES_OR_POINT = 4;
/*     */   public static final short ANCHOR_ID_Z_AXIS = 7;
/*     */   private short field_2_link1;
/*     */   private short field_3_link2;
/*     */   
/*     */   public ObjectLinkRecord() {}
/*     */   
/*     */   public ObjectLinkRecord(RecordInputStream in)
/*     */   {
/*  49 */     this.field_1_anchorId = in.readShort();
/*  50 */     this.field_2_link1 = in.readShort();
/*  51 */     this.field_3_link2 = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  57 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  59 */     buffer.append("[OBJECTLINK]\n");
/*  60 */     buffer.append("    .anchorId             = ").append("0x").append(HexDump.toHex(getAnchorId())).append(" (").append(getAnchorId()).append(" )");
/*     */     
/*     */ 
/*  63 */     buffer.append(System.getProperty("line.separator"));
/*  64 */     buffer.append("    .link1                = ").append("0x").append(HexDump.toHex(getLink1())).append(" (").append(getLink1()).append(" )");
/*     */     
/*     */ 
/*  67 */     buffer.append(System.getProperty("line.separator"));
/*  68 */     buffer.append("    .link2                = ").append("0x").append(HexDump.toHex(getLink2())).append(" (").append(getLink2()).append(" )");
/*     */     
/*     */ 
/*  71 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  73 */     buffer.append("[/OBJECTLINK]\n");
/*  74 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  78 */     out.writeShort(this.field_1_anchorId);
/*  79 */     out.writeShort(this.field_2_link1);
/*  80 */     out.writeShort(this.field_3_link2);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  84 */     return 6;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  89 */     return 4135;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  93 */     ObjectLinkRecord rec = new ObjectLinkRecord();
/*     */     
/*  95 */     rec.field_1_anchorId = this.field_1_anchorId;
/*  96 */     rec.field_2_link1 = this.field_2_link1;
/*  97 */     rec.field_3_link2 = this.field_3_link2;
/*  98 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getAnchorId()
/*     */   {
/* 116 */     return this.field_1_anchorId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAnchorId(short field_1_anchorId)
/*     */   {
/* 132 */     this.field_1_anchorId = field_1_anchorId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLink1()
/*     */   {
/* 140 */     return this.field_2_link1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLink1(short field_2_link1)
/*     */   {
/* 148 */     this.field_2_link1 = field_2_link1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getLink2()
/*     */   {
/* 156 */     return this.field_3_link2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLink2(short field_3_link2)
/*     */   {
/* 164 */     this.field_3_link2 = field_3_link2;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ObjectLinkRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */