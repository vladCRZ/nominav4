/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PlotGrowthRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4196;
/*     */   private int field_1_horizontalScale;
/*     */   private int field_2_verticalScale;
/*     */   
/*     */   public PlotGrowthRecord() {}
/*     */   
/*     */   public PlotGrowthRecord(RecordInputStream in)
/*     */   {
/*  43 */     this.field_1_horizontalScale = in.readInt();
/*  44 */     this.field_2_verticalScale = in.readInt();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  50 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  52 */     buffer.append("[PLOTGROWTH]\n");
/*  53 */     buffer.append("    .horizontalScale      = ").append("0x").append(HexDump.toHex(getHorizontalScale())).append(" (").append(getHorizontalScale()).append(" )");
/*     */     
/*     */ 
/*  56 */     buffer.append(System.getProperty("line.separator"));
/*  57 */     buffer.append("    .verticalScale        = ").append("0x").append(HexDump.toHex(getVerticalScale())).append(" (").append(getVerticalScale()).append(" )");
/*     */     
/*     */ 
/*  60 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  62 */     buffer.append("[/PLOTGROWTH]\n");
/*  63 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  67 */     out.writeInt(this.field_1_horizontalScale);
/*  68 */     out.writeInt(this.field_2_verticalScale);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  72 */     return 8;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  77 */     return 4196;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  81 */     PlotGrowthRecord rec = new PlotGrowthRecord();
/*     */     
/*  83 */     rec.field_1_horizontalScale = this.field_1_horizontalScale;
/*  84 */     rec.field_2_verticalScale = this.field_2_verticalScale;
/*  85 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHorizontalScale()
/*     */   {
/*  96 */     return this.field_1_horizontalScale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHorizontalScale(int field_1_horizontalScale)
/*     */   {
/* 104 */     this.field_1_horizontalScale = field_1_horizontalScale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVerticalScale()
/*     */   {
/* 112 */     return this.field_2_verticalScale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVerticalScale(int field_2_verticalScale)
/*     */   {
/* 120 */     this.field_2_verticalScale = field_2_verticalScale;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\PlotGrowthRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */