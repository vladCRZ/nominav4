/*    */ package org.apache.poi.hssf.record.chart;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SeriesIndexRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 4197;
/*    */   private short field_1_index;
/*    */   
/*    */   public SeriesIndexRecord() {}
/*    */   
/*    */   public SeriesIndexRecord(RecordInputStream in)
/*    */   {
/* 42 */     this.field_1_index = in.readShort();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 47 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 49 */     buffer.append("[SINDEX]\n");
/* 50 */     buffer.append("    .index                = ").append("0x").append(HexDump.toHex(getIndex())).append(" (").append(getIndex()).append(" )");
/*    */     
/*    */ 
/* 53 */     buffer.append(System.getProperty("line.separator"));
/*    */     
/* 55 */     buffer.append("[/SINDEX]\n");
/* 56 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 60 */     out.writeShort(this.field_1_index);
/*    */   }
/*    */   
/*    */   protected int getDataSize() {
/* 64 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 69 */     return 4197;
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 73 */     SeriesIndexRecord rec = new SeriesIndexRecord();
/*    */     
/* 75 */     rec.field_1_index = this.field_1_index;
/* 76 */     return rec;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public short getIndex()
/*    */   {
/* 87 */     return this.field_1_index;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setIndex(short field_1_index)
/*    */   {
/* 95 */     this.field_1_index = field_1_index;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\SeriesIndexRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */