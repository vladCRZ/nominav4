/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SeriesRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4099;
/*     */   private short field_1_categoryDataType;
/*     */   public static final short CATEGORY_DATA_TYPE_DATES = 0;
/*     */   public static final short CATEGORY_DATA_TYPE_NUMERIC = 1;
/*     */   public static final short CATEGORY_DATA_TYPE_SEQUENCE = 2;
/*     */   public static final short CATEGORY_DATA_TYPE_TEXT = 3;
/*     */   private short field_2_valuesDataType;
/*     */   public static final short VALUES_DATA_TYPE_DATES = 0;
/*     */   public static final short VALUES_DATA_TYPE_NUMERIC = 1;
/*     */   public static final short VALUES_DATA_TYPE_SEQUENCE = 2;
/*     */   public static final short VALUES_DATA_TYPE_TEXT = 3;
/*     */   private short field_3_numCategories;
/*     */   private short field_4_numValues;
/*     */   private short field_5_bubbleSeriesType;
/*     */   public static final short BUBBLE_SERIES_TYPE_DATES = 0;
/*     */   public static final short BUBBLE_SERIES_TYPE_NUMERIC = 1;
/*     */   public static final short BUBBLE_SERIES_TYPE_SEQUENCE = 2;
/*     */   public static final short BUBBLE_SERIES_TYPE_TEXT = 3;
/*     */   private short field_6_numBubbleValues;
/*     */   
/*     */   public SeriesRecord() {}
/*     */   
/*     */   public SeriesRecord(RecordInputStream in)
/*     */   {
/*  59 */     this.field_1_categoryDataType = in.readShort();
/*  60 */     this.field_2_valuesDataType = in.readShort();
/*  61 */     this.field_3_numCategories = in.readShort();
/*  62 */     this.field_4_numValues = in.readShort();
/*  63 */     this.field_5_bubbleSeriesType = in.readShort();
/*  64 */     this.field_6_numBubbleValues = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  70 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  72 */     buffer.append("[SERIES]\n");
/*  73 */     buffer.append("    .categoryDataType     = ").append("0x").append(HexDump.toHex(getCategoryDataType())).append(" (").append(getCategoryDataType()).append(" )");
/*     */     
/*     */ 
/*  76 */     buffer.append(System.getProperty("line.separator"));
/*  77 */     buffer.append("    .valuesDataType       = ").append("0x").append(HexDump.toHex(getValuesDataType())).append(" (").append(getValuesDataType()).append(" )");
/*     */     
/*     */ 
/*  80 */     buffer.append(System.getProperty("line.separator"));
/*  81 */     buffer.append("    .numCategories        = ").append("0x").append(HexDump.toHex(getNumCategories())).append(" (").append(getNumCategories()).append(" )");
/*     */     
/*     */ 
/*  84 */     buffer.append(System.getProperty("line.separator"));
/*  85 */     buffer.append("    .numValues            = ").append("0x").append(HexDump.toHex(getNumValues())).append(" (").append(getNumValues()).append(" )");
/*     */     
/*     */ 
/*  88 */     buffer.append(System.getProperty("line.separator"));
/*  89 */     buffer.append("    .bubbleSeriesType     = ").append("0x").append(HexDump.toHex(getBubbleSeriesType())).append(" (").append(getBubbleSeriesType()).append(" )");
/*     */     
/*     */ 
/*  92 */     buffer.append(System.getProperty("line.separator"));
/*  93 */     buffer.append("    .numBubbleValues      = ").append("0x").append(HexDump.toHex(getNumBubbleValues())).append(" (").append(getNumBubbleValues()).append(" )");
/*     */     
/*     */ 
/*  96 */     buffer.append(System.getProperty("line.separator"));
/*     */     
/*  98 */     buffer.append("[/SERIES]\n");
/*  99 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 103 */     out.writeShort(this.field_1_categoryDataType);
/* 104 */     out.writeShort(this.field_2_valuesDataType);
/* 105 */     out.writeShort(this.field_3_numCategories);
/* 106 */     out.writeShort(this.field_4_numValues);
/* 107 */     out.writeShort(this.field_5_bubbleSeriesType);
/* 108 */     out.writeShort(this.field_6_numBubbleValues);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 112 */     return 12;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 117 */     return 4099;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 121 */     SeriesRecord rec = new SeriesRecord();
/*     */     
/* 123 */     rec.field_1_categoryDataType = this.field_1_categoryDataType;
/* 124 */     rec.field_2_valuesDataType = this.field_2_valuesDataType;
/* 125 */     rec.field_3_numCategories = this.field_3_numCategories;
/* 126 */     rec.field_4_numValues = this.field_4_numValues;
/* 127 */     rec.field_5_bubbleSeriesType = this.field_5_bubbleSeriesType;
/* 128 */     rec.field_6_numBubbleValues = this.field_6_numBubbleValues;
/* 129 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCategoryDataType()
/*     */   {
/* 146 */     return this.field_1_categoryDataType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCategoryDataType(short field_1_categoryDataType)
/*     */   {
/* 161 */     this.field_1_categoryDataType = field_1_categoryDataType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getValuesDataType()
/*     */   {
/* 175 */     return this.field_2_valuesDataType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValuesDataType(short field_2_valuesDataType)
/*     */   {
/* 190 */     this.field_2_valuesDataType = field_2_valuesDataType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getNumCategories()
/*     */   {
/* 198 */     return this.field_3_numCategories;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumCategories(short field_3_numCategories)
/*     */   {
/* 206 */     this.field_3_numCategories = field_3_numCategories;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getNumValues()
/*     */   {
/* 214 */     return this.field_4_numValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumValues(short field_4_numValues)
/*     */   {
/* 222 */     this.field_4_numValues = field_4_numValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getBubbleSeriesType()
/*     */   {
/* 236 */     return this.field_5_bubbleSeriesType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBubbleSeriesType(short field_5_bubbleSeriesType)
/*     */   {
/* 251 */     this.field_5_bubbleSeriesType = field_5_bubbleSeriesType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getNumBubbleValues()
/*     */   {
/* 259 */     return this.field_6_numBubbleValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumBubbleValues(short field_6_numBubbleValues)
/*     */   {
/* 267 */     this.field_6_numBubbleValues = field_6_numBubbleValues;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\SeriesRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */