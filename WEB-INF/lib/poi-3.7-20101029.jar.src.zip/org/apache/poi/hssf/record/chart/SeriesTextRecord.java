/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SeriesTextRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4109;
/*     */   private static final int MAX_LEN = 255;
/*     */   private int field_1_id;
/*     */   private boolean is16bit;
/*     */   private String field_4_text;
/*     */   
/*     */   public SeriesTextRecord()
/*     */   {
/*  42 */     this.field_4_text = "";
/*  43 */     this.is16bit = false;
/*     */   }
/*     */   
/*     */   public SeriesTextRecord(RecordInputStream in) {
/*  47 */     this.field_1_id = in.readUShort();
/*  48 */     int field_2_textLength = in.readUByte();
/*  49 */     this.is16bit = ((in.readUByte() & 0x1) != 0);
/*  50 */     if (this.is16bit) {
/*  51 */       this.field_4_text = in.readUnicodeLEString(field_2_textLength);
/*     */     } else {
/*  53 */       this.field_4_text = in.readCompressedUnicode(field_2_textLength);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/*  58 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  60 */     sb.append("[SERIESTEXT]\n");
/*  61 */     sb.append("  .id     =").append(HexDump.shortToHex(getId())).append('\n');
/*  62 */     sb.append("  .textLen=").append(this.field_4_text.length()).append('\n');
/*  63 */     sb.append("  .is16bit=").append(this.is16bit).append('\n');
/*  64 */     sb.append("  .text   =").append(" (").append(getText()).append(" )").append('\n');
/*  65 */     sb.append("[/SERIESTEXT]\n");
/*  66 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out)
/*     */   {
/*  71 */     out.writeShort(this.field_1_id);
/*  72 */     out.writeByte(this.field_4_text.length());
/*  73 */     if (this.is16bit)
/*     */     {
/*  75 */       out.writeByte(1);
/*  76 */       StringUtil.putUnicodeLE(this.field_4_text, out);
/*     */     }
/*     */     else {
/*  79 */       out.writeByte(0);
/*  80 */       StringUtil.putCompressedUnicode(this.field_4_text, out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  85 */     return 4 + this.field_4_text.length() * (this.is16bit ? 2 : 1);
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  89 */     return 4109;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  93 */     SeriesTextRecord rec = new SeriesTextRecord();
/*     */     
/*  95 */     rec.field_1_id = this.field_1_id;
/*  96 */     rec.is16bit = this.is16bit;
/*  97 */     rec.field_4_text = this.field_4_text;
/*  98 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getId()
/*     */   {
/* 105 */     return this.field_1_id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setId(int id)
/*     */   {
/* 112 */     this.field_1_id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 119 */     return this.field_4_text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setText(String text)
/*     */   {
/* 126 */     if (text.length() > 255) {
/* 127 */       throw new IllegalArgumentException("Text is too long (" + text.length() + ">" + 255 + ")");
/*     */     }
/*     */     
/* 130 */     this.field_4_text = text;
/* 131 */     this.is16bit = StringUtil.hasMultibyte(text);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\SeriesTextRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */