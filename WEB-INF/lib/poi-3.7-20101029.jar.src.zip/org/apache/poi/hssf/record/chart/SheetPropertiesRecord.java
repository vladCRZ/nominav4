/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SheetPropertiesRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4164;
/*  38 */   private static final BitField chartTypeManuallyFormatted = BitFieldFactory.getInstance(1);
/*  39 */   private static final BitField plotVisibleOnly = BitFieldFactory.getInstance(2);
/*  40 */   private static final BitField doNotSizeWithWindow = BitFieldFactory.getInstance(4);
/*  41 */   private static final BitField defaultPlotDimensions = BitFieldFactory.getInstance(8);
/*  42 */   private static final BitField autoPlotArea = BitFieldFactory.getInstance(16);
/*     */   
/*     */   private int field_1_flags;
/*     */   
/*     */   private int field_2_empty;
/*     */   
/*     */   public static final byte EMPTY_NOT_PLOTTED = 0;
/*     */   public static final byte EMPTY_ZERO = 1;
/*     */   public static final byte EMPTY_INTERPOLATED = 2;
/*     */   
/*     */   public SheetPropertiesRecord() {}
/*     */   
/*     */   public SheetPropertiesRecord(RecordInputStream in)
/*     */   {
/*  56 */     this.field_1_flags = in.readUShort();
/*  57 */     this.field_2_empty = in.readUShort();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  61 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  63 */     buffer.append("[SHTPROPS]\n");
/*  64 */     buffer.append("    .flags                = ").append(HexDump.shortToHex(this.field_1_flags)).append('\n');
/*  65 */     buffer.append("         .chartTypeManuallyFormatted= ").append(isChartTypeManuallyFormatted()).append('\n');
/*  66 */     buffer.append("         .plotVisibleOnly           = ").append(isPlotVisibleOnly()).append('\n');
/*  67 */     buffer.append("         .doNotSizeWithWindow       = ").append(isDoNotSizeWithWindow()).append('\n');
/*  68 */     buffer.append("         .defaultPlotDimensions     = ").append(isDefaultPlotDimensions()).append('\n');
/*  69 */     buffer.append("         .autoPlotArea              = ").append(isAutoPlotArea()).append('\n');
/*  70 */     buffer.append("    .empty                = ").append(HexDump.shortToHex(this.field_2_empty)).append('\n');
/*     */     
/*  72 */     buffer.append("[/SHTPROPS]\n");
/*  73 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  77 */     out.writeShort(this.field_1_flags);
/*  78 */     out.writeShort(this.field_2_empty);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/*  82 */     return 4;
/*     */   }
/*     */   
/*     */   public short getSid() {
/*  86 */     return 4164;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  90 */     SheetPropertiesRecord rec = new SheetPropertiesRecord();
/*     */     
/*  92 */     rec.field_1_flags = this.field_1_flags;
/*  93 */     rec.field_2_empty = this.field_2_empty;
/*  94 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFlags()
/*     */   {
/* 101 */     return this.field_1_flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEmpty()
/*     */   {
/* 113 */     return this.field_2_empty;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEmpty(byte empty)
/*     */   {
/* 126 */     this.field_2_empty = empty;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChartTypeManuallyFormatted(boolean value)
/*     */   {
/* 134 */     this.field_1_flags = chartTypeManuallyFormatted.setBoolean(this.field_1_flags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isChartTypeManuallyFormatted()
/*     */   {
/* 142 */     return chartTypeManuallyFormatted.isSet(this.field_1_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPlotVisibleOnly(boolean value)
/*     */   {
/* 150 */     this.field_1_flags = plotVisibleOnly.setBoolean(this.field_1_flags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPlotVisibleOnly()
/*     */   {
/* 158 */     return plotVisibleOnly.isSet(this.field_1_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDoNotSizeWithWindow(boolean value)
/*     */   {
/* 166 */     this.field_1_flags = doNotSizeWithWindow.setBoolean(this.field_1_flags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDoNotSizeWithWindow()
/*     */   {
/* 174 */     return doNotSizeWithWindow.isSet(this.field_1_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultPlotDimensions(boolean value)
/*     */   {
/* 182 */     this.field_1_flags = defaultPlotDimensions.setBoolean(this.field_1_flags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDefaultPlotDimensions()
/*     */   {
/* 190 */     return defaultPlotDimensions.isSet(this.field_1_flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoPlotArea(boolean value)
/*     */   {
/* 198 */     this.field_1_flags = autoPlotArea.setBoolean(this.field_1_flags, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoPlotArea()
/*     */   {
/* 206 */     return autoPlotArea.isSet(this.field_1_flags);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\SheetPropertiesRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */