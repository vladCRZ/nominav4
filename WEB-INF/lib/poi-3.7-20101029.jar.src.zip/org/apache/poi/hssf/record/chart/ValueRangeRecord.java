/*     */ package org.apache.poi.hssf.record.chart;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueRangeRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 4127;
/*  35 */   private static final BitField automaticMinimum = BitFieldFactory.getInstance(1);
/*  36 */   private static final BitField automaticMaximum = BitFieldFactory.getInstance(2);
/*  37 */   private static final BitField automaticMajor = BitFieldFactory.getInstance(4);
/*  38 */   private static final BitField automaticMinor = BitFieldFactory.getInstance(8);
/*  39 */   private static final BitField automaticCategoryCrossing = BitFieldFactory.getInstance(16);
/*  40 */   private static final BitField logarithmicScale = BitFieldFactory.getInstance(32);
/*  41 */   private static final BitField valuesInReverse = BitFieldFactory.getInstance(64);
/*  42 */   private static final BitField crossCategoryAxisAtMaximum = BitFieldFactory.getInstance(128);
/*  43 */   private static final BitField reserved = BitFieldFactory.getInstance(256);
/*     */   
/*     */   private double field_1_minimumAxisValue;
/*     */   
/*     */   private double field_2_maximumAxisValue;
/*     */   
/*     */   private double field_3_majorIncrement;
/*     */   
/*     */   private double field_4_minorIncrement;
/*     */   
/*     */   private double field_5_categoryAxisCross;
/*     */   private short field_6_options;
/*     */   
/*     */   public ValueRangeRecord() {}
/*     */   
/*     */   public ValueRangeRecord(RecordInputStream in)
/*     */   {
/*  60 */     this.field_1_minimumAxisValue = in.readDouble();
/*  61 */     this.field_2_maximumAxisValue = in.readDouble();
/*  62 */     this.field_3_majorIncrement = in.readDouble();
/*  63 */     this.field_4_minorIncrement = in.readDouble();
/*  64 */     this.field_5_categoryAxisCross = in.readDouble();
/*  65 */     this.field_6_options = in.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  71 */     StringBuffer buffer = new StringBuffer();
/*     */     
/*  73 */     buffer.append("[VALUERANGE]\n");
/*  74 */     buffer.append("    .minimumAxisValue     = ").append(" (").append(getMinimumAxisValue()).append(" )");
/*     */     
/*  76 */     buffer.append(System.getProperty("line.separator"));
/*  77 */     buffer.append("    .maximumAxisValue     = ").append(" (").append(getMaximumAxisValue()).append(" )");
/*     */     
/*  79 */     buffer.append(System.getProperty("line.separator"));
/*  80 */     buffer.append("    .majorIncrement       = ").append(" (").append(getMajorIncrement()).append(" )");
/*     */     
/*  82 */     buffer.append(System.getProperty("line.separator"));
/*  83 */     buffer.append("    .minorIncrement       = ").append(" (").append(getMinorIncrement()).append(" )");
/*     */     
/*  85 */     buffer.append(System.getProperty("line.separator"));
/*  86 */     buffer.append("    .categoryAxisCross    = ").append(" (").append(getCategoryAxisCross()).append(" )");
/*     */     
/*  88 */     buffer.append(System.getProperty("line.separator"));
/*  89 */     buffer.append("    .options              = ").append("0x").append(HexDump.toHex(getOptions())).append(" (").append(getOptions()).append(" )");
/*     */     
/*     */ 
/*  92 */     buffer.append(System.getProperty("line.separator"));
/*  93 */     buffer.append("         .automaticMinimum         = ").append(isAutomaticMinimum()).append('\n');
/*  94 */     buffer.append("         .automaticMaximum         = ").append(isAutomaticMaximum()).append('\n');
/*  95 */     buffer.append("         .automaticMajor           = ").append(isAutomaticMajor()).append('\n');
/*  96 */     buffer.append("         .automaticMinor           = ").append(isAutomaticMinor()).append('\n');
/*  97 */     buffer.append("         .automaticCategoryCrossing     = ").append(isAutomaticCategoryCrossing()).append('\n');
/*  98 */     buffer.append("         .logarithmicScale         = ").append(isLogarithmicScale()).append('\n');
/*  99 */     buffer.append("         .valuesInReverse          = ").append(isValuesInReverse()).append('\n');
/* 100 */     buffer.append("         .crossCategoryAxisAtMaximum     = ").append(isCrossCategoryAxisAtMaximum()).append('\n');
/* 101 */     buffer.append("         .reserved                 = ").append(isReserved()).append('\n');
/*     */     
/* 103 */     buffer.append("[/VALUERANGE]\n");
/* 104 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/* 108 */     out.writeDouble(this.field_1_minimumAxisValue);
/* 109 */     out.writeDouble(this.field_2_maximumAxisValue);
/* 110 */     out.writeDouble(this.field_3_majorIncrement);
/* 111 */     out.writeDouble(this.field_4_minorIncrement);
/* 112 */     out.writeDouble(this.field_5_categoryAxisCross);
/* 113 */     out.writeShort(this.field_6_options);
/*     */   }
/*     */   
/*     */   protected int getDataSize() {
/* 117 */     return 42;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/* 122 */     return 4127;
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 126 */     ValueRangeRecord rec = new ValueRangeRecord();
/*     */     
/* 128 */     rec.field_1_minimumAxisValue = this.field_1_minimumAxisValue;
/* 129 */     rec.field_2_maximumAxisValue = this.field_2_maximumAxisValue;
/* 130 */     rec.field_3_majorIncrement = this.field_3_majorIncrement;
/* 131 */     rec.field_4_minorIncrement = this.field_4_minorIncrement;
/* 132 */     rec.field_5_categoryAxisCross = this.field_5_categoryAxisCross;
/* 133 */     rec.field_6_options = this.field_6_options;
/* 134 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMinimumAxisValue()
/*     */   {
/* 145 */     return this.field_1_minimumAxisValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimumAxisValue(double field_1_minimumAxisValue)
/*     */   {
/* 153 */     this.field_1_minimumAxisValue = field_1_minimumAxisValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMaximumAxisValue()
/*     */   {
/* 161 */     return this.field_2_maximumAxisValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximumAxisValue(double field_2_maximumAxisValue)
/*     */   {
/* 169 */     this.field_2_maximumAxisValue = field_2_maximumAxisValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMajorIncrement()
/*     */   {
/* 177 */     return this.field_3_majorIncrement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMajorIncrement(double field_3_majorIncrement)
/*     */   {
/* 185 */     this.field_3_majorIncrement = field_3_majorIncrement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMinorIncrement()
/*     */   {
/* 193 */     return this.field_4_minorIncrement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinorIncrement(double field_4_minorIncrement)
/*     */   {
/* 201 */     this.field_4_minorIncrement = field_4_minorIncrement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getCategoryAxisCross()
/*     */   {
/* 209 */     return this.field_5_categoryAxisCross;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCategoryAxisCross(double field_5_categoryAxisCross)
/*     */   {
/* 217 */     this.field_5_categoryAxisCross = field_5_categoryAxisCross;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getOptions()
/*     */   {
/* 225 */     return this.field_6_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptions(short field_6_options)
/*     */   {
/* 233 */     this.field_6_options = field_6_options;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticMinimum(boolean value)
/*     */   {
/* 242 */     this.field_6_options = automaticMinimum.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomaticMinimum()
/*     */   {
/* 251 */     return automaticMinimum.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticMaximum(boolean value)
/*     */   {
/* 260 */     this.field_6_options = automaticMaximum.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomaticMaximum()
/*     */   {
/* 269 */     return automaticMaximum.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticMajor(boolean value)
/*     */   {
/* 278 */     this.field_6_options = automaticMajor.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomaticMajor()
/*     */   {
/* 287 */     return automaticMajor.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticMinor(boolean value)
/*     */   {
/* 296 */     this.field_6_options = automaticMinor.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomaticMinor()
/*     */   {
/* 305 */     return automaticMinor.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutomaticCategoryCrossing(boolean value)
/*     */   {
/* 314 */     this.field_6_options = automaticCategoryCrossing.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutomaticCategoryCrossing()
/*     */   {
/* 323 */     return automaticCategoryCrossing.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogarithmicScale(boolean value)
/*     */   {
/* 332 */     this.field_6_options = logarithmicScale.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLogarithmicScale()
/*     */   {
/* 341 */     return logarithmicScale.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValuesInReverse(boolean value)
/*     */   {
/* 350 */     this.field_6_options = valuesInReverse.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValuesInReverse()
/*     */   {
/* 359 */     return valuesInReverse.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrossCategoryAxisAtMaximum(boolean value)
/*     */   {
/* 368 */     this.field_6_options = crossCategoryAxisAtMaximum.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCrossCategoryAxisAtMaximum()
/*     */   {
/* 377 */     return crossCategoryAxisAtMaximum.isSet(this.field_6_options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReserved(boolean value)
/*     */   {
/* 386 */     this.field_6_options = reserved.setShortBoolean(this.field_6_options, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReserved()
/*     */   {
/* 395 */     return reserved.isSet(this.field_6_options);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\chart\ValueRangeRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */