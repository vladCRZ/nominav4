/*     */ package org.apache.poi.hssf.record.common;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FeatFormulaErr2
/*     */   implements SharedFeature
/*     */ {
/*  38 */   static BitField checkCalculationErrors = BitFieldFactory.getInstance(1);
/*     */   
/*  40 */   static BitField checkEmptyCellRef = BitFieldFactory.getInstance(2);
/*     */   
/*  42 */   static BitField checkNumbersAsText = BitFieldFactory.getInstance(4);
/*     */   
/*  44 */   static BitField checkInconsistentRanges = BitFieldFactory.getInstance(8);
/*     */   
/*  46 */   static BitField checkInconsistentFormulas = BitFieldFactory.getInstance(16);
/*     */   
/*  48 */   static BitField checkDateTimeFormats = BitFieldFactory.getInstance(32);
/*     */   
/*  50 */   static BitField checkUnprotectedFormulas = BitFieldFactory.getInstance(64);
/*     */   
/*  52 */   static BitField performDataValidation = BitFieldFactory.getInstance(128);
/*     */   
/*     */ 
/*     */   private int errorCheck;
/*     */   
/*     */ 
/*     */ 
/*     */   public FeatFormulaErr2() {}
/*     */   
/*     */ 
/*     */   public FeatFormulaErr2(RecordInputStream in)
/*     */   {
/*  64 */     this.errorCheck = in.readInt();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  68 */     StringBuffer buffer = new StringBuffer();
/*  69 */     buffer.append(" [FEATURE FORMULA ERRORS]\n");
/*  70 */     buffer.append("  checkCalculationErrors    = ");
/*  71 */     buffer.append("  checkEmptyCellRef         = ");
/*  72 */     buffer.append("  checkNumbersAsText        = ");
/*  73 */     buffer.append("  checkInconsistentRanges   = ");
/*  74 */     buffer.append("  checkInconsistentFormulas = ");
/*  75 */     buffer.append("  checkDateTimeFormats      = ");
/*  76 */     buffer.append("  checkUnprotectedFormulas  = ");
/*  77 */     buffer.append("  performDataValidation     = ");
/*  78 */     buffer.append(" [/FEATURE FORMULA ERRORS]\n");
/*  79 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  83 */     out.writeInt(this.errorCheck);
/*     */   }
/*     */   
/*     */   public int getDataSize() {
/*  87 */     return 4;
/*     */   }
/*     */   
/*     */   public int _getRawErrorCheckValue() {
/*  91 */     return this.errorCheck;
/*     */   }
/*     */   
/*     */   public boolean getCheckCalculationErrors() {
/*  95 */     return checkCalculationErrors.isSet(this.errorCheck);
/*     */   }
/*     */   
/*  98 */   public void setCheckCalculationErrors(boolean checkCalculationErrors) { checkCalculationErrors.setBoolean(this.errorCheck, checkCalculationErrors); }
/*     */   
/*     */ 
/*     */   public boolean getCheckEmptyCellRef()
/*     */   {
/* 103 */     return checkEmptyCellRef.isSet(this.errorCheck);
/*     */   }
/*     */   
/* 106 */   public void setCheckEmptyCellRef(boolean checkEmptyCellRef) { checkEmptyCellRef.setBoolean(this.errorCheck, checkEmptyCellRef); }
/*     */   
/*     */ 
/*     */   public boolean getCheckNumbersAsText()
/*     */   {
/* 111 */     return checkNumbersAsText.isSet(this.errorCheck);
/*     */   }
/*     */   
/* 114 */   public void setCheckNumbersAsText(boolean checkNumbersAsText) { checkNumbersAsText.setBoolean(this.errorCheck, checkNumbersAsText); }
/*     */   
/*     */ 
/*     */   public boolean getCheckInconsistentRanges()
/*     */   {
/* 119 */     return checkInconsistentRanges.isSet(this.errorCheck);
/*     */   }
/*     */   
/* 122 */   public void setCheckInconsistentRanges(boolean checkInconsistentRanges) { checkInconsistentRanges.setBoolean(this.errorCheck, checkInconsistentRanges); }
/*     */   
/*     */ 
/*     */   public boolean getCheckInconsistentFormulas()
/*     */   {
/* 127 */     return checkInconsistentFormulas.isSet(this.errorCheck);
/*     */   }
/*     */   
/*     */   public void setCheckInconsistentFormulas(boolean checkInconsistentFormulas) {
/* 131 */     checkInconsistentFormulas.setBoolean(this.errorCheck, checkInconsistentFormulas);
/*     */   }
/*     */   
/*     */   public boolean getCheckDateTimeFormats()
/*     */   {
/* 136 */     return checkDateTimeFormats.isSet(this.errorCheck);
/*     */   }
/*     */   
/* 139 */   public void setCheckDateTimeFormats(boolean checkDateTimeFormats) { checkDateTimeFormats.setBoolean(this.errorCheck, checkDateTimeFormats); }
/*     */   
/*     */ 
/*     */   public boolean getCheckUnprotectedFormulas()
/*     */   {
/* 144 */     return checkUnprotectedFormulas.isSet(this.errorCheck);
/*     */   }
/*     */   
/* 147 */   public void setCheckUnprotectedFormulas(boolean checkUnprotectedFormulas) { checkUnprotectedFormulas.setBoolean(this.errorCheck, checkUnprotectedFormulas); }
/*     */   
/*     */ 
/*     */   public boolean getPerformDataValidation()
/*     */   {
/* 152 */     return performDataValidation.isSet(this.errorCheck);
/*     */   }
/*     */   
/* 155 */   public void setPerformDataValidation(boolean performDataValidation) { performDataValidation.setBoolean(this.errorCheck, performDataValidation); }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\common\FeatFormulaErr2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */