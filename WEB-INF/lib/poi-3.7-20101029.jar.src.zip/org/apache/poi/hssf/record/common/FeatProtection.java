/*     */ package org.apache.poi.hssf.record.common;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FeatProtection
/*     */   implements SharedFeature
/*     */ {
/*  37 */   public static long NO_SELF_RELATIVE_SECURITY_FEATURE = 0L;
/*  38 */   public static long HAS_SELF_RELATIVE_SECURITY_FEATURE = 1L;
/*     */   
/*     */ 
/*     */   private int fSD;
/*     */   
/*     */ 
/*     */   private int passwordVerifier;
/*     */   
/*     */ 
/*     */   private String title;
/*     */   
/*     */   private byte[] securityDescriptor;
/*     */   
/*     */ 
/*     */   public FeatProtection()
/*     */   {
/*  54 */     this.securityDescriptor = new byte[0];
/*     */   }
/*     */   
/*     */   public FeatProtection(RecordInputStream in) {
/*  58 */     this.fSD = in.readInt();
/*  59 */     this.passwordVerifier = in.readInt();
/*     */     
/*  61 */     this.title = StringUtil.readUnicodeString(in);
/*     */     
/*  63 */     this.securityDescriptor = in.readRemainder();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  67 */     StringBuffer buffer = new StringBuffer();
/*  68 */     buffer.append(" [FEATURE PROTECTION]\n");
/*  69 */     buffer.append("   Self Relative = " + this.fSD);
/*  70 */     buffer.append("   Password Verifier = " + this.passwordVerifier);
/*  71 */     buffer.append("   Title = " + this.title);
/*  72 */     buffer.append("   Security Descriptor Size = " + this.securityDescriptor.length);
/*  73 */     buffer.append(" [/FEATURE PROTECTION]\n");
/*  74 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public void serialize(LittleEndianOutput out) {
/*  78 */     out.writeInt(this.fSD);
/*  79 */     out.writeInt(this.passwordVerifier);
/*  80 */     StringUtil.writeUnicodeString(out, this.title);
/*  81 */     out.write(this.securityDescriptor);
/*     */   }
/*     */   
/*     */   public int getDataSize() {
/*  85 */     return 8 + StringUtil.getEncodedSize(this.title) + this.securityDescriptor.length;
/*     */   }
/*     */   
/*     */   public int getPasswordVerifier() {
/*  89 */     return this.passwordVerifier;
/*     */   }
/*     */   
/*  92 */   public void setPasswordVerifier(int passwordVerifier) { this.passwordVerifier = passwordVerifier; }
/*     */   
/*     */   public String getTitle()
/*     */   {
/*  96 */     return this.title;
/*     */   }
/*     */   
/*  99 */   public void setTitle(String title) { this.title = title; }
/*     */   
/*     */   public int getFSD()
/*     */   {
/* 103 */     return this.fSD;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\common\FeatProtection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */