/*    */ package org.apache.poi.hssf.record.common;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FeatSmartTag
/*    */   implements SharedFeature
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public FeatSmartTag()
/*    */   {
/* 41 */     this.data = new byte[0];
/*    */   }
/*    */   
/*    */   public FeatSmartTag(RecordInputStream in) {
/* 45 */     this.data = in.readRemainder();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 49 */     StringBuffer buffer = new StringBuffer();
/* 50 */     buffer.append(" [FEATURE SMART TAGS]\n");
/* 51 */     buffer.append(" [/FEATURE SMART TAGS]\n");
/* 52 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public int getDataSize() {
/* 56 */     return this.data.length;
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 60 */     out.write(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\common\FeatSmartTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */