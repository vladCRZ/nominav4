/*    */ package org.apache.poi.hssf.record.common;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FtrHeader
/*    */ {
/*    */   private short recordType;
/*    */   private short grbitFrt;
/*    */   private byte[] reserved;
/*    */   
/*    */   public FtrHeader()
/*    */   {
/* 39 */     this.reserved = new byte[8];
/*    */   }
/*    */   
/*    */   public FtrHeader(RecordInputStream in) {
/* 43 */     this.recordType = in.readShort();
/* 44 */     this.grbitFrt = in.readShort();
/*    */     
/* 46 */     this.reserved = new byte[8];
/* 47 */     in.read(this.reserved, 0, 8);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     StringBuffer buffer = new StringBuffer();
/* 52 */     buffer.append(" [FUTURE HEADER]\n");
/* 53 */     buffer.append("   Type " + this.recordType);
/* 54 */     buffer.append("   Flags " + this.grbitFrt);
/* 55 */     buffer.append(" [/FUTURE HEADER]\n");
/* 56 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public void serialize(LittleEndianOutput out) {
/* 60 */     out.writeShort(this.recordType);
/* 61 */     out.writeShort(this.grbitFrt);
/* 62 */     out.write(this.reserved);
/*    */   }
/*    */   
/*    */   public static int getDataSize() {
/* 66 */     return 12;
/*    */   }
/*    */   
/*    */   public short getRecordType() {
/* 70 */     return this.recordType;
/*    */   }
/*    */   
/* 73 */   public void setRecordType(short recordType) { this.recordType = recordType; }
/*    */   
/*    */   public short getGrbitFrt()
/*    */   {
/* 77 */     return this.grbitFrt;
/*    */   }
/*    */   
/* 80 */   public void setGrbitFrt(short grbitFrt) { this.grbitFrt = grbitFrt; }
/*    */   
/*    */   public byte[] getReserved()
/*    */   {
/* 84 */     return this.reserved;
/*    */   }
/*    */   
/* 87 */   public void setReserved(byte[] reserved) { this.reserved = reserved; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\common\FtrHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */