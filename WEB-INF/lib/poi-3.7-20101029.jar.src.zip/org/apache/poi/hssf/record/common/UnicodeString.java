/*     */ package org.apache.poi.hssf.record.common;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.cont.ContinuableRecordOutput;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnicodeString
/*     */   implements Comparable<UnicodeString>
/*     */ {
/*     */   private short field_1_charCount;
/*     */   private byte field_2_optionflags;
/*     */   private String field_3_string;
/*     */   private List<FormatRun> field_4_format_runs;
/*     */   private ExtRst field_5_ext_rst;
/*  47 */   private static final BitField highByte = BitFieldFactory.getInstance(1);
/*     */   
/*  49 */   private static final BitField extBit = BitFieldFactory.getInstance(4);
/*  50 */   private static final BitField richText = BitFieldFactory.getInstance(8);
/*     */   private UnicodeString() {}
/*     */   
/*     */   public static class FormatRun implements Comparable<FormatRun> {
/*     */     final short _character;
/*     */     short _fontIndex;
/*     */     
/*  57 */     public FormatRun(short character, short fontIndex) { this._character = character;
/*  58 */       this._fontIndex = fontIndex;
/*     */     }
/*     */     
/*     */     public FormatRun(LittleEndianInput in) {
/*  62 */       this(in.readShort(), in.readShort());
/*     */     }
/*     */     
/*     */     public short getCharacterPos() {
/*  66 */       return this._character;
/*     */     }
/*     */     
/*     */     public short getFontIndex() {
/*  70 */       return this._fontIndex;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/*  74 */       if (!(o instanceof FormatRun)) {
/*  75 */         return false;
/*     */       }
/*  77 */       FormatRun other = (FormatRun)o;
/*     */       
/*  79 */       return (this._character == other._character) && (this._fontIndex == other._fontIndex);
/*     */     }
/*     */     
/*     */     public int compareTo(FormatRun r) {
/*  83 */       if ((this._character == r._character) && (this._fontIndex == r._fontIndex)) {
/*  84 */         return 0;
/*     */       }
/*  86 */       if (this._character == r._character) {
/*  87 */         return this._fontIndex - r._fontIndex;
/*     */       }
/*  89 */       return this._character - r._character;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  93 */       return "character=" + this._character + ",fontIndex=" + this._fontIndex;
/*     */     }
/*     */     
/*     */     public void serialize(LittleEndianOutput out) {
/*  97 */       out.writeShort(this._character);
/*  98 */       out.writeShort(this._fontIndex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class ExtRst
/*     */     implements Comparable<ExtRst>
/*     */   {
/*     */     private short reserved;
/*     */     
/*     */     private short formattingFontIndex;
/*     */     
/*     */     private short formattingOptions;
/*     */     
/*     */     private int numberOfRuns;
/*     */     
/*     */     private String phoneticText;
/*     */     private UnicodeString.PhRun[] phRuns;
/*     */     private byte[] extraData;
/*     */     
/*     */     private void populateEmpty()
/*     */     {
/* 120 */       this.reserved = 1;
/* 121 */       this.phoneticText = "";
/* 122 */       this.phRuns = new UnicodeString.PhRun[0];
/* 123 */       this.extraData = new byte[0];
/*     */     }
/*     */     
/*     */ 
/* 127 */     protected ExtRst() { populateEmpty(); }
/*     */     
/*     */     protected ExtRst(LittleEndianInput in, int expectedLength) {
/* 130 */       this.reserved = in.readShort();
/*     */       
/*     */ 
/* 133 */       if (this.reserved == -1) {
/* 134 */         populateEmpty();
/* 135 */         return;
/*     */       }
/*     */       
/*     */ 
/* 139 */       if (this.reserved != 1) {
/* 140 */         System.err.println("Warning - ExtRst was has wrong magic marker, expecting 1 but found " + this.reserved + " - ignoring");
/*     */         
/* 142 */         for (int i = 0; i < expectedLength - 2; i++) {
/* 143 */           in.readByte();
/*     */         }
/*     */         
/* 146 */         populateEmpty();
/* 147 */         return;
/*     */       }
/*     */       
/*     */ 
/* 151 */       short stringDataSize = in.readShort();
/*     */       
/* 153 */       this.formattingFontIndex = in.readShort();
/* 154 */       this.formattingOptions = in.readShort();
/*     */       
/*     */ 
/* 157 */       this.numberOfRuns = in.readUShort();
/* 158 */       short length1 = in.readShort();
/*     */       
/*     */ 
/* 161 */       short length2 = in.readShort();
/*     */       
/* 163 */       if ((length1 == 0) && (length2 > 0)) {
/* 164 */         length2 = 0;
/*     */       }
/* 166 */       if (length1 != length2) {
/* 167 */         throw new IllegalStateException("The two length fields of the Phonetic Text don't agree! " + length1 + " vs " + length2);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 172 */       this.phoneticText = StringUtil.readUnicodeLE(in, length1);
/*     */       
/* 174 */       int runData = stringDataSize - 4 - 6 - 2 * this.phoneticText.length();
/* 175 */       int numRuns = runData / 6;
/* 176 */       this.phRuns = new UnicodeString.PhRun[numRuns];
/* 177 */       for (int i = 0; i < this.phRuns.length; i++) {
/* 178 */         this.phRuns[i] = new UnicodeString.PhRun(in, null);
/*     */       }
/*     */       
/* 181 */       int extraDataLength = runData - numRuns * 6;
/* 182 */       if (extraDataLength < 0) {
/* 183 */         System.err.println("Warning - ExtRst overran by " + (0 - extraDataLength) + " bytes");
/* 184 */         extraDataLength = 0;
/*     */       }
/* 186 */       this.extraData = new byte[extraDataLength];
/* 187 */       for (int i = 0; i < this.extraData.length; i++) {
/* 188 */         this.extraData[i] = in.readByte();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected int getDataSize()
/*     */     {
/* 196 */       return 10 + 2 * this.phoneticText.length() + 6 * this.phRuns.length + this.extraData.length;
/*     */     }
/*     */     
/*     */     protected void serialize(ContinuableRecordOutput out) {
/* 200 */       int dataSize = getDataSize();
/*     */       
/* 202 */       out.writeContinueIfRequired(8);
/* 203 */       out.writeShort(this.reserved);
/* 204 */       out.writeShort(dataSize);
/* 205 */       out.writeShort(this.formattingFontIndex);
/* 206 */       out.writeShort(this.formattingOptions);
/*     */       
/* 208 */       out.writeContinueIfRequired(6);
/* 209 */       out.writeShort(this.numberOfRuns);
/* 210 */       out.writeShort(this.phoneticText.length());
/* 211 */       out.writeShort(this.phoneticText.length());
/*     */       
/* 213 */       out.writeContinueIfRequired(this.phoneticText.length() * 2);
/* 214 */       StringUtil.putUnicodeLE(this.phoneticText, out);
/*     */       
/* 216 */       for (int i = 0; i < this.phRuns.length; i++) {
/* 217 */         this.phRuns[i].serialize(out);
/*     */       }
/*     */       
/* 220 */       out.write(this.extraData);
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/* 224 */       if (!(obj instanceof ExtRst)) {
/* 225 */         return false;
/*     */       }
/* 227 */       ExtRst other = (ExtRst)obj;
/* 228 */       return compareTo(other) == 0;
/*     */     }
/*     */     
/*     */     public int compareTo(ExtRst o)
/*     */     {
/* 233 */       int result = this.reserved - o.reserved;
/* 234 */       if (result != 0) return result;
/* 235 */       result = this.formattingFontIndex - o.formattingFontIndex;
/* 236 */       if (result != 0) return result;
/* 237 */       result = this.formattingOptions - o.formattingOptions;
/* 238 */       if (result != 0) return result;
/* 239 */       result = this.numberOfRuns - o.numberOfRuns;
/* 240 */       if (result != 0) { return result;
/*     */       }
/* 242 */       result = this.phoneticText.compareTo(o.phoneticText);
/* 243 */       if (result != 0) { return result;
/*     */       }
/* 245 */       result = this.phRuns.length - o.phRuns.length;
/* 246 */       if (result != 0) return result;
/* 247 */       for (int i = 0; i < this.phRuns.length; i++) {
/* 248 */         result = this.phRuns[i].phoneticTextFirstCharacterOffset - o.phRuns[i].phoneticTextFirstCharacterOffset;
/* 249 */         if (result != 0) return result;
/* 250 */         result = this.phRuns[i].realTextFirstCharacterOffset - o.phRuns[i].realTextFirstCharacterOffset;
/* 251 */         if (result != 0) return result;
/* 252 */         result = this.phRuns[i].realTextFirstCharacterOffset - o.phRuns[i].realTextLength;
/* 253 */         if (result != 0) { return result;
/*     */         }
/*     */       }
/* 256 */       result = this.extraData.length - o.extraData.length;
/* 257 */       if (result != 0) { return result;
/*     */       }
/*     */       
/* 260 */       return 0;
/*     */     }
/*     */     
/*     */     protected ExtRst clone() {
/* 264 */       ExtRst ext = new ExtRst();
/* 265 */       ext.reserved = this.reserved;
/* 266 */       ext.formattingFontIndex = this.formattingFontIndex;
/* 267 */       ext.formattingOptions = this.formattingOptions;
/* 268 */       ext.numberOfRuns = this.numberOfRuns;
/* 269 */       ext.phoneticText = new String(this.phoneticText);
/* 270 */       ext.phRuns = new UnicodeString.PhRun[this.phRuns.length];
/* 271 */       for (int i = 0; i < ext.phRuns.length; i++) {
/* 272 */         ext.phRuns[i] = new UnicodeString.PhRun(this.phRuns[i].phoneticTextFirstCharacterOffset, this.phRuns[i].realTextFirstCharacterOffset, this.phRuns[i].realTextLength);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 278 */       return ext;
/*     */     }
/*     */     
/*     */     public short getFormattingFontIndex() {
/* 282 */       return this.formattingFontIndex;
/*     */     }
/*     */     
/* 285 */     public short getFormattingOptions() { return this.formattingOptions; }
/*     */     
/*     */     public int getNumberOfRuns() {
/* 288 */       return this.numberOfRuns;
/*     */     }
/*     */     
/* 291 */     public String getPhoneticText() { return this.phoneticText; }
/*     */     
/*     */     public UnicodeString.PhRun[] getPhRuns() {
/* 294 */       return this.phRuns;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PhRun {
/*     */     private int phoneticTextFirstCharacterOffset;
/*     */     private int realTextFirstCharacterOffset;
/*     */     private int realTextLength;
/*     */     
/*     */     public PhRun(int phoneticTextFirstCharacterOffset, int realTextFirstCharacterOffset, int realTextLength) {
/* 304 */       this.phoneticTextFirstCharacterOffset = phoneticTextFirstCharacterOffset;
/* 305 */       this.realTextFirstCharacterOffset = realTextFirstCharacterOffset;
/* 306 */       this.realTextLength = realTextLength;
/*     */     }
/*     */     
/* 309 */     private PhRun(LittleEndianInput in) { this.phoneticTextFirstCharacterOffset = in.readUShort();
/* 310 */       this.realTextFirstCharacterOffset = in.readUShort();
/* 311 */       this.realTextLength = in.readUShort();
/*     */     }
/*     */     
/* 314 */     private void serialize(ContinuableRecordOutput out) { out.writeContinueIfRequired(6);
/* 315 */       out.writeShort(this.phoneticTextFirstCharacterOffset);
/* 316 */       out.writeShort(this.realTextFirstCharacterOffset);
/* 317 */       out.writeShort(this.realTextLength);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnicodeString(String str)
/*     */   {
/* 327 */     setString(str);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 334 */     int stringHash = 0;
/* 335 */     if (this.field_3_string != null)
/* 336 */       stringHash = this.field_3_string.hashCode();
/* 337 */     return this.field_1_charCount + stringHash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 349 */     if (!(o instanceof UnicodeString)) {
/* 350 */       return false;
/*     */     }
/* 352 */     UnicodeString other = (UnicodeString)o;
/*     */     
/*     */ 
/* 355 */     boolean eq = (this.field_1_charCount == other.field_1_charCount) && (this.field_2_optionflags == other.field_2_optionflags) && (this.field_3_string.equals(other.field_3_string));
/*     */     
/*     */ 
/* 358 */     if (!eq) { return false;
/*     */     }
/*     */     
/* 361 */     if ((this.field_4_format_runs == null) && (other.field_4_format_runs == null))
/*     */     {
/* 363 */       return true; }
/* 364 */     if (((this.field_4_format_runs == null) && (other.field_4_format_runs != null)) || ((this.field_4_format_runs != null) && (other.field_4_format_runs == null)))
/*     */     {
/*     */ 
/* 367 */       return false;
/*     */     }
/*     */     
/* 370 */     int size = this.field_4_format_runs.size();
/* 371 */     if (size != other.field_4_format_runs.size()) {
/* 372 */       return false;
/*     */     }
/* 374 */     for (int i = 0; i < size; i++) {
/* 375 */       FormatRun run1 = (FormatRun)this.field_4_format_runs.get(i);
/* 376 */       FormatRun run2 = (FormatRun)other.field_4_format_runs.get(i);
/*     */       
/* 378 */       if (!run1.equals(run2)) {
/* 379 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 383 */     if ((this.field_5_ext_rst != null) || (other.field_5_ext_rst != null))
/*     */     {
/* 385 */       if ((this.field_5_ext_rst != null) && (other.field_5_ext_rst != null)) {
/* 386 */         int extCmp = this.field_5_ext_rst.compareTo(other.field_5_ext_rst);
/* 387 */         if (extCmp != 0)
/*     */         {
/*     */ 
/* 390 */           return false;
/*     */         }
/*     */       } else {
/* 393 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 398 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnicodeString(RecordInputStream in)
/*     */   {
/* 406 */     this.field_1_charCount = in.readShort();
/* 407 */     this.field_2_optionflags = in.readByte();
/*     */     
/* 409 */     int runCount = 0;
/* 410 */     int extensionLength = 0;
/*     */     
/* 412 */     if (isRichText())
/*     */     {
/* 414 */       runCount = in.readShort();
/*     */     }
/*     */     
/* 417 */     if (isExtendedText())
/*     */     {
/* 419 */       extensionLength = in.readInt();
/*     */     }
/*     */     
/* 422 */     boolean isCompressed = (this.field_2_optionflags & 0x1) == 0;
/* 423 */     if (isCompressed) {
/* 424 */       this.field_3_string = in.readCompressedUnicode(getCharCount());
/*     */     } else {
/* 426 */       this.field_3_string = in.readUnicodeLEString(getCharCount());
/*     */     }
/*     */     
/*     */ 
/* 430 */     if ((isRichText()) && (runCount > 0)) {
/* 431 */       this.field_4_format_runs = new ArrayList(runCount);
/* 432 */       for (int i = 0; i < runCount; i++) {
/* 433 */         this.field_4_format_runs.add(new FormatRun(in));
/*     */       }
/*     */     }
/*     */     
/* 437 */     if ((isExtendedText()) && (extensionLength > 0)) {
/* 438 */       this.field_5_ext_rst = new ExtRst(in, extensionLength);
/* 439 */       if (this.field_5_ext_rst.getDataSize() + 4 != extensionLength) {
/* 440 */         System.err.println("ExtRst was supposed to be " + extensionLength + " bytes long, but seems to actually be " + (this.field_5_ext_rst.getDataSize() + 4));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCharCount()
/*     */   {
/* 454 */     if (this.field_1_charCount < 0) {
/* 455 */       return this.field_1_charCount + 65536;
/*     */     }
/* 457 */     return this.field_1_charCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getCharCountShort()
/*     */   {
/* 467 */     return this.field_1_charCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharCount(short cc)
/*     */   {
/* 477 */     this.field_1_charCount = cc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getOptionFlags()
/*     */   {
/* 490 */     return this.field_2_optionflags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptionFlags(byte of)
/*     */   {
/* 503 */     this.field_2_optionflags = of;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString()
/*     */   {
/* 511 */     return this.field_3_string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setString(String string)
/*     */   {
/* 521 */     this.field_3_string = string;
/* 522 */     setCharCount((short)this.field_3_string.length());
/*     */     
/*     */ 
/*     */ 
/* 526 */     boolean useUTF16 = false;
/* 527 */     int strlen = string.length();
/*     */     
/* 529 */     for (int j = 0; j < strlen; j++)
/*     */     {
/* 531 */       if (string.charAt(j) > 'ÿ')
/*     */       {
/* 533 */         useUTF16 = true;
/* 534 */         break;
/*     */       }
/*     */     }
/* 537 */     if (useUTF16)
/*     */     {
/* 539 */       this.field_2_optionflags = highByte.setByte(this.field_2_optionflags); } else
/* 540 */       this.field_2_optionflags = highByte.clearByte(this.field_2_optionflags);
/*     */   }
/*     */   
/*     */   public int getFormatRunCount() {
/* 544 */     if (this.field_4_format_runs == null)
/* 545 */       return 0;
/* 546 */     return this.field_4_format_runs.size();
/*     */   }
/*     */   
/*     */   public FormatRun getFormatRun(int index) {
/* 550 */     if (this.field_4_format_runs == null) {
/* 551 */       return null;
/*     */     }
/* 553 */     if ((index < 0) || (index >= this.field_4_format_runs.size())) {
/* 554 */       return null;
/*     */     }
/* 556 */     return (FormatRun)this.field_4_format_runs.get(index);
/*     */   }
/*     */   
/*     */   private int findFormatRunAt(int characterPos) {
/* 560 */     int size = this.field_4_format_runs.size();
/* 561 */     for (int i = 0; i < size; i++) {
/* 562 */       FormatRun r = (FormatRun)this.field_4_format_runs.get(i);
/* 563 */       if (r._character == characterPos)
/* 564 */         return i;
/* 565 */       if (r._character > characterPos)
/* 566 */         return -1;
/*     */     }
/* 568 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFormatRun(FormatRun r)
/*     */   {
/* 577 */     if (this.field_4_format_runs == null) {
/* 578 */       this.field_4_format_runs = new ArrayList();
/*     */     }
/*     */     
/* 581 */     int index = findFormatRunAt(r._character);
/* 582 */     if (index != -1) {
/* 583 */       this.field_4_format_runs.remove(index);
/*     */     }
/* 585 */     this.field_4_format_runs.add(r);
/*     */     
/*     */ 
/* 588 */     Collections.sort(this.field_4_format_runs);
/*     */     
/*     */ 
/* 591 */     this.field_2_optionflags = richText.setByte(this.field_2_optionflags);
/*     */   }
/*     */   
/*     */   public Iterator<FormatRun> formatIterator() {
/* 595 */     if (this.field_4_format_runs != null) {
/* 596 */       return this.field_4_format_runs.iterator();
/*     */     }
/* 598 */     return null;
/*     */   }
/*     */   
/*     */   public void removeFormatRun(FormatRun r) {
/* 602 */     this.field_4_format_runs.remove(r);
/* 603 */     if (this.field_4_format_runs.size() == 0) {
/* 604 */       this.field_4_format_runs = null;
/* 605 */       this.field_2_optionflags = richText.clearByte(this.field_2_optionflags);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearFormatting() {
/* 610 */     this.field_4_format_runs = null;
/* 611 */     this.field_2_optionflags = richText.clearByte(this.field_2_optionflags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 616 */   public ExtRst getExtendedRst() { return this.field_5_ext_rst; }
/*     */   
/*     */   void setExtendedRst(ExtRst ext_rst) {
/* 619 */     if (ext_rst != null) {
/* 620 */       this.field_2_optionflags = extBit.setByte(this.field_2_optionflags);
/*     */     } else {
/* 622 */       this.field_2_optionflags = extBit.clearByte(this.field_2_optionflags);
/*     */     }
/* 624 */     this.field_5_ext_rst = ext_rst;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void swapFontUse(short oldFontIndex, short newFontIndex)
/*     */   {
/* 635 */     for (FormatRun run : this.field_4_format_runs) {
/* 636 */       if (run._fontIndex == oldFontIndex) {
/* 637 */         run._fontIndex = newFontIndex;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 650 */     return getString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDebugInfo()
/*     */   {
/* 662 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 664 */     buffer.append("[UNICODESTRING]\n");
/* 665 */     buffer.append("    .charcount       = ").append(Integer.toHexString(getCharCount())).append("\n");
/*     */     
/* 667 */     buffer.append("    .optionflags     = ").append(Integer.toHexString(getOptionFlags())).append("\n");
/*     */     
/* 669 */     buffer.append("    .string          = ").append(getString()).append("\n");
/* 670 */     if (this.field_4_format_runs != null) {
/* 671 */       for (int i = 0; i < this.field_4_format_runs.size(); i++) {
/* 672 */         FormatRun r = (FormatRun)this.field_4_format_runs.get(i);
/* 673 */         buffer.append("      .format_run" + i + "          = ").append(r.toString()).append("\n");
/*     */       }
/*     */     }
/* 676 */     if (this.field_5_ext_rst != null) {
/* 677 */       buffer.append("    .field_5_ext_rst          = ").append("\n");
/* 678 */       buffer.append(this.field_5_ext_rst.toString()).append("\n");
/*     */     }
/* 680 */     buffer.append("[/UNICODESTRING]\n");
/* 681 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void serialize(ContinuableRecordOutput out)
/*     */   {
/* 690 */     int numberOfRichTextRuns = 0;
/* 691 */     int extendedDataSize = 0;
/* 692 */     if ((isRichText()) && (this.field_4_format_runs != null)) {
/* 693 */       numberOfRichTextRuns = this.field_4_format_runs.size();
/*     */     }
/* 695 */     if ((isExtendedText()) && (this.field_5_ext_rst != null)) {
/* 696 */       extendedDataSize = 4 + this.field_5_ext_rst.getDataSize();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 701 */     out.writeString(this.field_3_string, numberOfRichTextRuns, extendedDataSize);
/*     */     
/* 703 */     if (numberOfRichTextRuns > 0)
/*     */     {
/*     */ 
/* 706 */       for (int i = 0; i < numberOfRichTextRuns; i++) {
/* 707 */         if (out.getAvailableSpace() < 4) {
/* 708 */           out.writeContinue();
/*     */         }
/* 710 */         FormatRun r = (FormatRun)this.field_4_format_runs.get(i);
/* 711 */         r.serialize(out);
/*     */       }
/*     */     }
/*     */     
/* 715 */     if (extendedDataSize > 0) {
/* 716 */       this.field_5_ext_rst.serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public int compareTo(UnicodeString str)
/*     */   {
/* 722 */     int result = getString().compareTo(str.getString());
/*     */     
/*     */ 
/* 725 */     if (result != 0) {
/* 726 */       return result;
/*     */     }
/*     */     
/* 729 */     if ((this.field_4_format_runs == null) && (str.field_4_format_runs == null))
/*     */     {
/* 731 */       return 0;
/*     */     }
/* 733 */     if ((this.field_4_format_runs == null) && (str.field_4_format_runs != null))
/*     */     {
/* 735 */       return 1; }
/* 736 */     if ((this.field_4_format_runs != null) && (str.field_4_format_runs == null))
/*     */     {
/* 738 */       return -1;
/*     */     }
/*     */     
/* 741 */     int size = this.field_4_format_runs.size();
/* 742 */     if (size != str.field_4_format_runs.size()) {
/* 743 */       return size - str.field_4_format_runs.size();
/*     */     }
/* 745 */     for (int i = 0; i < size; i++) {
/* 746 */       FormatRun run1 = (FormatRun)this.field_4_format_runs.get(i);
/* 747 */       FormatRun run2 = (FormatRun)str.field_4_format_runs.get(i);
/*     */       
/* 749 */       result = run1.compareTo(run2);
/* 750 */       if (result != 0) {
/* 751 */         return result;
/*     */       }
/*     */     }
/*     */     
/* 755 */     if ((this.field_5_ext_rst == null) && (str.field_5_ext_rst == null))
/* 756 */       return 0;
/* 757 */     if ((this.field_5_ext_rst == null) && (str.field_5_ext_rst != null))
/* 758 */       return 1;
/* 759 */     if ((this.field_5_ext_rst != null) && (str.field_5_ext_rst == null)) {
/* 760 */       return -1;
/*     */     }
/* 762 */     result = this.field_5_ext_rst.compareTo(str.field_5_ext_rst);
/* 763 */     if (result != 0) {
/* 764 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 768 */     return 0;
/*     */   }
/*     */   
/*     */   private boolean isRichText()
/*     */   {
/* 773 */     return richText.isSet(getOptionFlags());
/*     */   }
/*     */   
/*     */   private boolean isExtendedText()
/*     */   {
/* 778 */     return extBit.isSet(getOptionFlags());
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 782 */     UnicodeString str = new UnicodeString();
/* 783 */     str.field_1_charCount = this.field_1_charCount;
/* 784 */     str.field_2_optionflags = this.field_2_optionflags;
/* 785 */     str.field_3_string = this.field_3_string;
/* 786 */     if (this.field_4_format_runs != null) {
/* 787 */       str.field_4_format_runs = new ArrayList();
/* 788 */       for (FormatRun r : this.field_4_format_runs) {
/* 789 */         str.field_4_format_runs.add(new FormatRun(r._character, r._fontIndex));
/*     */       }
/*     */     }
/* 792 */     if (this.field_5_ext_rst != null) {
/* 793 */       str.field_5_ext_rst = this.field_5_ext_rst.clone();
/*     */     }
/*     */     
/* 796 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\common\UnicodeString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */