/*     */ package org.apache.poi.hssf.record.constant;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConstantValueParser
/*     */ {
/*     */   private static final int TYPE_EMPTY = 0;
/*     */   private static final int TYPE_NUMBER = 1;
/*     */   private static final int TYPE_STRING = 2;
/*     */   private static final int TYPE_BOOLEAN = 4;
/*     */   private static final int TYPE_ERROR_CODE = 16;
/*     */   private static final int TRUE_ENCODING = 1;
/*     */   private static final int FALSE_ENCODING = 0;
/*  43 */   private static final Object EMPTY_REPRESENTATION = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object[] parse(LittleEndianInput in, int nValues)
/*     */   {
/*  50 */     Object[] result = new Object[nValues];
/*  51 */     for (int i = 0; i < result.length; i++) {
/*  52 */       result[i] = readAConstantValue(in);
/*     */     }
/*  54 */     return result;
/*     */   }
/*     */   
/*     */   private static Object readAConstantValue(LittleEndianInput in) {
/*  58 */     byte grbit = in.readByte();
/*  59 */     switch (grbit) {
/*     */     case 0: 
/*  61 */       in.readLong();
/*  62 */       return EMPTY_REPRESENTATION;
/*     */     case 1: 
/*  64 */       return new Double(in.readDouble());
/*     */     case 2: 
/*  66 */       return StringUtil.readUnicodeString(in);
/*     */     case 4: 
/*  68 */       return readBoolean(in);
/*     */     case 16: 
/*  70 */       int errCode = in.readUShort();
/*     */       
/*  72 */       in.readUShort();
/*  73 */       in.readInt();
/*  74 */       return ErrorConstant.valueOf(errCode);
/*     */     }
/*  76 */     throw new RuntimeException("Unknown grbit value (" + grbit + ")");
/*     */   }
/*     */   
/*     */   private static Object readBoolean(LittleEndianInput in) {
/*  80 */     byte val = (byte)(int)in.readLong();
/*  81 */     switch (val) {
/*     */     case 0: 
/*  83 */       return Boolean.FALSE;
/*     */     case 1: 
/*  85 */       return Boolean.TRUE;
/*     */     }
/*     */     
/*  88 */     throw new RuntimeException("unexpected boolean encoding (" + val + ")");
/*     */   }
/*     */   
/*     */   public static int getEncodedSize(Object[] values)
/*     */   {
/*  93 */     int result = values.length * 1;
/*  94 */     for (int i = 0; i < values.length; i++) {
/*  95 */       result += getEncodedSize(values[i]);
/*     */     }
/*  97 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int getEncodedSize(Object object)
/*     */   {
/* 104 */     if (object == EMPTY_REPRESENTATION) {
/* 105 */       return 8;
/*     */     }
/* 107 */     Class cls = object.getClass();
/*     */     
/* 109 */     if ((cls == Boolean.class) || (cls == Double.class) || (cls == ErrorConstant.class)) {
/* 110 */       return 8;
/*     */     }
/* 112 */     String strVal = (String)object;
/* 113 */     return StringUtil.getEncodedSize(strVal);
/*     */   }
/*     */   
/*     */   public static void encode(LittleEndianOutput out, Object[] values) {
/* 117 */     for (int i = 0; i < values.length; i++) {
/* 118 */       encodeSingleValue(out, values[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void encodeSingleValue(LittleEndianOutput out, Object value) {
/* 123 */     if (value == EMPTY_REPRESENTATION) {
/* 124 */       out.writeByte(0);
/* 125 */       out.writeLong(0L);
/* 126 */       return;
/*     */     }
/* 128 */     if ((value instanceof Boolean)) {
/* 129 */       Boolean bVal = (Boolean)value;
/* 130 */       out.writeByte(4);
/* 131 */       long longVal = bVal.booleanValue() ? 1L : 0L;
/* 132 */       out.writeLong(longVal);
/* 133 */       return;
/*     */     }
/* 135 */     if ((value instanceof Double)) {
/* 136 */       Double dVal = (Double)value;
/* 137 */       out.writeByte(1);
/* 138 */       out.writeDouble(dVal.doubleValue());
/* 139 */       return;
/*     */     }
/* 141 */     if ((value instanceof String)) {
/* 142 */       String val = (String)value;
/* 143 */       out.writeByte(2);
/* 144 */       StringUtil.writeUnicodeString(out, val);
/* 145 */       return;
/*     */     }
/* 147 */     if ((value instanceof ErrorConstant)) {
/* 148 */       ErrorConstant ecVal = (ErrorConstant)value;
/* 149 */       out.writeByte(16);
/* 150 */       long longVal = ecVal.getErrorCode();
/* 151 */       out.writeLong(longVal);
/* 152 */       return;
/*     */     }
/*     */     
/* 155 */     throw new IllegalStateException("Unexpected value type (" + value.getClass().getName() + "'");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\constant\ConstantValueParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */