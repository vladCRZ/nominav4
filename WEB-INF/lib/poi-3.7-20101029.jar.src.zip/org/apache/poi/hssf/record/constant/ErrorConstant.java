/*    */ package org.apache.poi.hssf.record.constant;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.apache.poi.hssf.usermodel.HSSFErrorConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorConstant
/*    */ {
/* 31 */   private static final HSSFErrorConstants EC = null;
/*    */   
/* 33 */   private static final ErrorConstant NULL = new ErrorConstant(0);
/* 34 */   private static final ErrorConstant DIV_0 = new ErrorConstant(7);
/* 35 */   private static final ErrorConstant VALUE = new ErrorConstant(15);
/* 36 */   private static final ErrorConstant REF = new ErrorConstant(23);
/* 37 */   private static final ErrorConstant NAME = new ErrorConstant(29);
/* 38 */   private static final ErrorConstant NUM = new ErrorConstant(36);
/* 39 */   private static final ErrorConstant NA = new ErrorConstant(42);
/*    */   private final int _errorCode;
/*    */   
/*    */   private ErrorConstant(int errorCode)
/*    */   {
/* 44 */     this._errorCode = errorCode;
/*    */   }
/*    */   
/*    */ 
/* 48 */   public int getErrorCode() { return this._errorCode; }
/*    */   
/*    */   public String getText() {
/* 51 */     if (HSSFErrorConstants.isValidCode(this._errorCode)) {
/* 52 */       return HSSFErrorConstants.getText(this._errorCode);
/*    */     }
/* 54 */     return "unknown error code (" + this._errorCode + ")";
/*    */   }
/*    */   
/*    */   public static ErrorConstant valueOf(int errorCode) {
/* 58 */     switch (errorCode) {
/* 59 */     case 0:  return NULL;
/* 60 */     case 7:  return DIV_0;
/* 61 */     case 15:  return VALUE;
/* 62 */     case 23:  return REF;
/* 63 */     case 29:  return NAME;
/* 64 */     case 36:  return NUM;
/* 65 */     case 42:  return NA;
/*    */     }
/* 67 */     System.err.println("Warning - unexpected error code (" + errorCode + ")");
/* 68 */     return new ErrorConstant(errorCode);
/*    */   }
/*    */   
/* 71 */   public String toString() { StringBuffer sb = new StringBuffer(64);
/* 72 */     sb.append(getClass().getName()).append(" [");
/* 73 */     sb.append(getText());
/* 74 */     sb.append("]");
/* 75 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\constant\ErrorConstant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */