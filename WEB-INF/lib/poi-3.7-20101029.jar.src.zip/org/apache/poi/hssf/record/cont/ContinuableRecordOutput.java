/*     */ package org.apache.poi.hssf.record.cont;
/*     */ 
/*     */ import org.apache.poi.util.DelayableLittleEndianOutput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContinuableRecordOutput
/*     */   implements LittleEndianOutput
/*     */ {
/*     */   private final LittleEndianOutput _out;
/*     */   private UnknownLengthRecordOutput _ulrOutput;
/*     */   private int _totalPreviousRecordsSize;
/*     */   
/*     */   public ContinuableRecordOutput(LittleEndianOutput out, int sid)
/*     */   {
/*  39 */     this._ulrOutput = new UnknownLengthRecordOutput(out, sid);
/*  40 */     this._out = out;
/*  41 */     this._totalPreviousRecordsSize = 0;
/*     */   }
/*     */   
/*     */   public static ContinuableRecordOutput createForCountingOnly() {
/*  45 */     return new ContinuableRecordOutput(NOPOutput, 64759);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getTotalSize()
/*     */   {
/*  52 */     return this._totalPreviousRecordsSize + this._ulrOutput.getTotalSize();
/*     */   }
/*     */   
/*     */ 
/*     */   void terminate()
/*     */   {
/*  58 */     this._ulrOutput.terminate();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getAvailableSpace()
/*     */   {
/*  64 */     return this._ulrOutput.getAvailableSpace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeContinue()
/*     */   {
/*  72 */     this._ulrOutput.terminate();
/*  73 */     this._totalPreviousRecordsSize += this._ulrOutput.getTotalSize();
/*  74 */     this._ulrOutput = new UnknownLengthRecordOutput(this._out, 60);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeContinueIfRequired(int requiredContinuousSize)
/*     */   {
/*  82 */     if (this._ulrOutput.getAvailableSpace() < requiredContinuousSize) {
/*  83 */       writeContinue();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeStringData(String text)
/*     */   {
/* 105 */     boolean is16bitEncoded = StringUtil.hasMultibyte(text);
/*     */     
/* 107 */     int keepTogetherSize = 2;
/* 108 */     int optionFlags = 0;
/* 109 */     if (is16bitEncoded) {
/* 110 */       optionFlags |= 0x1;
/* 111 */       keepTogetherSize++;
/*     */     }
/* 113 */     writeContinueIfRequired(keepTogetherSize);
/* 114 */     writeByte(optionFlags);
/* 115 */     writeCharacterData(text, is16bitEncoded);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeString(String text, int numberOfRichTextRuns, int extendedDataSize)
/*     */   {
/* 144 */     boolean is16bitEncoded = StringUtil.hasMultibyte(text);
/*     */     
/* 146 */     int keepTogetherSize = 4;
/* 147 */     int optionFlags = 0;
/* 148 */     if (is16bitEncoded) {
/* 149 */       optionFlags |= 0x1;
/* 150 */       keepTogetherSize++;
/*     */     }
/* 152 */     if (numberOfRichTextRuns > 0) {
/* 153 */       optionFlags |= 0x8;
/* 154 */       keepTogetherSize += 2;
/*     */     }
/* 156 */     if (extendedDataSize > 0) {
/* 157 */       optionFlags |= 0x4;
/* 158 */       keepTogetherSize += 4;
/*     */     }
/* 160 */     writeContinueIfRequired(keepTogetherSize);
/* 161 */     writeShort(text.length());
/* 162 */     writeByte(optionFlags);
/* 163 */     if (numberOfRichTextRuns > 0) {
/* 164 */       writeShort(numberOfRichTextRuns);
/*     */     }
/* 166 */     if (extendedDataSize > 0) {
/* 167 */       writeInt(extendedDataSize);
/*     */     }
/* 169 */     writeCharacterData(text, is16bitEncoded);
/*     */   }
/*     */   
/*     */   private void writeCharacterData(String text, boolean is16bitEncoded)
/*     */   {
/* 174 */     int nChars = text.length();
/* 175 */     int i = 0;
/* 176 */     if (is16bitEncoded) {
/*     */       for (;;) {
/* 178 */         for (int nWritableChars = Math.min(nChars - i, this._ulrOutput.getAvailableSpace() / 2); 
/* 179 */             nWritableChars > 0; nWritableChars--) {
/* 180 */           this._ulrOutput.writeShort(text.charAt(i++));
/*     */         }
/* 182 */         if (i >= nChars) {
/*     */           break;
/*     */         }
/* 185 */         writeContinue();
/* 186 */         writeByte(1);
/*     */       }
/*     */     }
/*     */     for (;;) {
/* 190 */       for (int nWritableChars = Math.min(nChars - i, this._ulrOutput.getAvailableSpace() / 1); 
/* 191 */           nWritableChars > 0; nWritableChars--) {
/* 192 */         this._ulrOutput.writeByte(text.charAt(i++));
/*     */       }
/* 194 */       if (i >= nChars) {
/*     */         break;
/*     */       }
/* 197 */       writeContinue();
/* 198 */       writeByte(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(byte[] b)
/*     */   {
/* 204 */     writeContinueIfRequired(b.length);
/* 205 */     this._ulrOutput.write(b);
/*     */   }
/*     */   
/* 208 */   public void write(byte[] b, int offset, int len) { writeContinueIfRequired(len);
/* 209 */     this._ulrOutput.write(b, offset, len);
/*     */   }
/*     */   
/* 212 */   public void writeByte(int v) { writeContinueIfRequired(1);
/* 213 */     this._ulrOutput.writeByte(v);
/*     */   }
/*     */   
/* 216 */   public void writeDouble(double v) { writeContinueIfRequired(8);
/* 217 */     this._ulrOutput.writeDouble(v);
/*     */   }
/*     */   
/* 220 */   public void writeInt(int v) { writeContinueIfRequired(4);
/* 221 */     this._ulrOutput.writeInt(v);
/*     */   }
/*     */   
/* 224 */   public void writeLong(long v) { writeContinueIfRequired(8);
/* 225 */     this._ulrOutput.writeLong(v);
/*     */   }
/*     */   
/* 228 */   public void writeShort(int v) { writeContinueIfRequired(2);
/* 229 */     this._ulrOutput.writeShort(v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 235 */   private static final LittleEndianOutput NOPOutput = new DelayableLittleEndianOutput()
/*     */   {
/*     */     public LittleEndianOutput createDelayedOutput(int size) {
/* 238 */       return this;
/*     */     }
/*     */     
/*     */     public void write(byte[] b) {}
/*     */     
/*     */     public void write(byte[] b, int offset, int len) {}
/*     */     
/*     */     public void writeByte(int v) {}
/*     */     
/*     */     public void writeDouble(double v) {}
/*     */     
/*     */     public void writeInt(int v) {}
/*     */     
/*     */     public void writeLong(long v) {}
/*     */     
/*     */     public void writeShort(int v) {}
/*     */   };
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\cont\ContinuableRecordOutput.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */