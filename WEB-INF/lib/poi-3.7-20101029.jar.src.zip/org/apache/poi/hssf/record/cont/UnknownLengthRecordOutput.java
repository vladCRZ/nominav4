/*     */ package org.apache.poi.hssf.record.cont;
/*     */ 
/*     */ import org.apache.poi.util.DelayableLittleEndianOutput;
/*     */ import org.apache.poi.util.LittleEndianByteArrayOutputStream;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UnknownLengthRecordOutput
/*     */   implements LittleEndianOutput
/*     */ {
/*     */   private static final int MAX_DATA_SIZE = 8224;
/*     */   private final LittleEndianOutput _originalOut;
/*     */   private final LittleEndianOutput _dataSizeOutput;
/*     */   private final byte[] _byteBuffer;
/*     */   private LittleEndianOutput _out;
/*     */   private int _size;
/*     */   
/*     */   public UnknownLengthRecordOutput(LittleEndianOutput out, int sid)
/*     */   {
/*  42 */     this._originalOut = out;
/*  43 */     out.writeShort(sid);
/*  44 */     if ((out instanceof DelayableLittleEndianOutput))
/*     */     {
/*  46 */       DelayableLittleEndianOutput dleo = (DelayableLittleEndianOutput)out;
/*  47 */       this._dataSizeOutput = dleo.createDelayedOutput(2);
/*  48 */       this._byteBuffer = null;
/*  49 */       this._out = out;
/*     */     }
/*     */     else {
/*  52 */       this._dataSizeOutput = out;
/*  53 */       this._byteBuffer = new byte['†'];
/*  54 */       this._out = new LittleEndianByteArrayOutputStream(this._byteBuffer, 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   public int getTotalSize() { return 4 + this._size; }
/*     */   
/*     */   public int getAvailableSpace() {
/*  64 */     if (this._out == null) {
/*  65 */       throw new IllegalStateException("Record already terminated");
/*     */     }
/*  67 */     return 8224 - this._size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void terminate()
/*     */   {
/*  74 */     if (this._out == null) {
/*  75 */       throw new IllegalStateException("Record already terminated");
/*     */     }
/*  77 */     this._dataSizeOutput.writeShort(this._size);
/*  78 */     if (this._byteBuffer != null) {
/*  79 */       this._originalOut.write(this._byteBuffer, 0, this._size);
/*  80 */       this._out = null;
/*  81 */       return;
/*     */     }
/*  83 */     this._out = null;
/*     */   }
/*     */   
/*     */   public void write(byte[] b) {
/*  87 */     this._out.write(b);
/*  88 */     this._size += b.length;
/*     */   }
/*     */   
/*  91 */   public void write(byte[] b, int offset, int len) { this._out.write(b, offset, len);
/*  92 */     this._size += len;
/*     */   }
/*     */   
/*  95 */   public void writeByte(int v) { this._out.writeByte(v);
/*  96 */     this._size += 1;
/*     */   }
/*     */   
/*  99 */   public void writeDouble(double v) { this._out.writeDouble(v);
/* 100 */     this._size += 8;
/*     */   }
/*     */   
/* 103 */   public void writeInt(int v) { this._out.writeInt(v);
/* 104 */     this._size += 4;
/*     */   }
/*     */   
/* 107 */   public void writeLong(long v) { this._out.writeLong(v);
/* 108 */     this._size += 8;
/*     */   }
/*     */   
/* 111 */   public void writeShort(int v) { this._out.writeShort(v);
/* 112 */     this._size += 2;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\cont\UnknownLengthRecordOutput.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */