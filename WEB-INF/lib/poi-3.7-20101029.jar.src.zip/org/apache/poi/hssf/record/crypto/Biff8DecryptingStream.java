/*     */ package org.apache.poi.hssf.record.crypto;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import org.apache.poi.hssf.record.BiffHeaderInput;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Biff8DecryptingStream
/*     */   implements BiffHeaderInput, LittleEndianInput
/*     */ {
/*     */   private final LittleEndianInput _le;
/*     */   private final Biff8RC4 _rc4;
/*     */   
/*     */   public Biff8DecryptingStream(InputStream in, int initialOffset, Biff8EncryptionKey key)
/*     */   {
/*  36 */     this._rc4 = new Biff8RC4(initialOffset, key);
/*     */     
/*  38 */     if ((in instanceof LittleEndianInput))
/*     */     {
/*  40 */       this._le = ((LittleEndianInput)in);
/*     */     }
/*     */     else {
/*  43 */       this._le = new LittleEndianInputStream(in);
/*     */     }
/*     */   }
/*     */   
/*     */   public int available() {
/*  48 */     return this._le.available();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int readRecordSID()
/*     */   {
/*  55 */     int sid = this._le.readUShort();
/*  56 */     this._rc4.skipTwoBytes();
/*  57 */     this._rc4.startRecord(sid);
/*  58 */     return sid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int readDataSize()
/*     */   {
/*  65 */     int dataSize = this._le.readUShort();
/*  66 */     this._rc4.skipTwoBytes();
/*  67 */     return dataSize;
/*     */   }
/*     */   
/*     */   public double readDouble() {
/*  71 */     long valueLongBits = readLong();
/*  72 */     double result = Double.longBitsToDouble(valueLongBits);
/*  73 */     if (Double.isNaN(result)) {
/*  74 */       throw new RuntimeException("Did not expect to read NaN");
/*     */     }
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   public void readFully(byte[] buf) {
/*  80 */     readFully(buf, 0, buf.length);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] buf, int off, int len) {
/*  84 */     this._le.readFully(buf, off, len);
/*  85 */     this._rc4.xor(buf, off, len);
/*     */   }
/*     */   
/*     */   public int readUByte()
/*     */   {
/*  90 */     return this._rc4.xorByte(this._le.readUByte());
/*     */   }
/*     */   
/*  93 */   public byte readByte() { return (byte)this._rc4.xorByte(this._le.readUByte()); }
/*     */   
/*     */ 
/*     */   public int readUShort()
/*     */   {
/*  98 */     return this._rc4.xorShort(this._le.readUShort());
/*     */   }
/*     */   
/* 101 */   public short readShort() { return (short)this._rc4.xorShort(this._le.readUShort()); }
/*     */   
/*     */   public int readInt()
/*     */   {
/* 105 */     return this._rc4.xorInt(this._le.readInt());
/*     */   }
/*     */   
/*     */   public long readLong() {
/* 109 */     return this._rc4.xorLong(this._le.readLong());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\crypto\Biff8DecryptingStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */