/*     */ package org.apache.poi.hssf.record.crypto;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Biff8EncryptionKey
/*     */ {
/*     */   private static final int KEY_DIGEST_LENGTH = 5;
/*     */   private static final int PASSWORD_HASH_NUMBER_OF_BYTES_USED = 5;
/*     */   private final byte[] _keyDigest;
/*     */   
/*     */   public static Biff8EncryptionKey create(byte[] docId)
/*     */   {
/*  40 */     return new Biff8EncryptionKey(createKeyDigest("VelvetSweatshop", docId));
/*     */   }
/*     */   
/*  43 */   public static Biff8EncryptionKey create(String password, byte[] docIdData) { return new Biff8EncryptionKey(createKeyDigest(password, docIdData)); }
/*     */   
/*     */   Biff8EncryptionKey(byte[] keyDigest)
/*     */   {
/*  47 */     if (keyDigest.length != 5) {
/*  48 */       throw new IllegalArgumentException("Expected 5 byte key digest, but got " + HexDump.toHex(keyDigest));
/*     */     }
/*  50 */     this._keyDigest = keyDigest;
/*     */   }
/*     */   
/*     */   static byte[] createKeyDigest(String password, byte[] docIdData) {
/*  54 */     check16Bytes(docIdData, "docId");
/*  55 */     int nChars = Math.min(password.length(), 16);
/*  56 */     byte[] passwordData = new byte[nChars * 2];
/*  57 */     for (int i = 0; i < nChars; i++) {
/*  58 */       char ch = password.charAt(i);
/*  59 */       passwordData[(i * 2 + 0)] = ((byte)(ch << '\000' & 0xFF));
/*  60 */       passwordData[(i * 2 + 1)] = ((byte)(ch << '\b' & 0xFF));
/*     */     }
/*     */     
/*     */     MessageDigest md5;
/*     */     try
/*     */     {
/*  66 */       md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException e) {
/*  68 */       throw new RuntimeException(e);
/*     */     }
/*     */     
/*  71 */     md5.update(passwordData);
/*  72 */     byte[] passwordHash = md5.digest();
/*  73 */     md5.reset();
/*     */     
/*  75 */     for (int i = 0; i < 16; i++) {
/*  76 */       md5.update(passwordHash, 0, 5);
/*  77 */       md5.update(docIdData, 0, docIdData.length);
/*     */     }
/*  79 */     byte[] kd = md5.digest();
/*  80 */     byte[] result = new byte[5];
/*  81 */     System.arraycopy(kd, 0, result, 0, 5);
/*  82 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean validate(byte[] saltData, byte[] saltHash)
/*     */   {
/*  89 */     check16Bytes(saltData, "saltData");
/*  90 */     check16Bytes(saltHash, "saltHash");
/*     */     
/*     */ 
/*  93 */     RC4 rc4 = createRC4(0);
/*  94 */     byte[] saltDataPrime = (byte[])saltData.clone();
/*  95 */     rc4.encrypt(saltDataPrime);
/*     */     
/*  97 */     byte[] saltHashPrime = (byte[])saltHash.clone();
/*  98 */     rc4.encrypt(saltHashPrime);
/*     */     MessageDigest md5;
/*     */     try
/*     */     {
/* 102 */       md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException e) {
/* 104 */       throw new RuntimeException(e);
/*     */     }
/* 106 */     md5.update(saltDataPrime);
/* 107 */     byte[] finalSaltResult = md5.digest();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     return Arrays.equals(saltHashPrime, finalSaltResult);
/*     */   }
/*     */   
/*     */   private static byte[] xor(byte[] a, byte[] b) {
/* 118 */     byte[] c = new byte[a.length];
/* 119 */     for (int i = 0; i < c.length; i++) {
/* 120 */       c[i] = ((byte)(a[i] ^ b[i]));
/*     */     }
/* 122 */     return c;
/*     */   }
/*     */   
/* 125 */   private static void check16Bytes(byte[] data, String argName) { if (data.length != 16) {
/* 126 */       throw new IllegalArgumentException("Expected 16 byte " + argName + ", but got " + HexDump.toHex(data));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   RC4 createRC4(int keyBlockNo)
/*     */   {
/*     */     MessageDigest md5;
/*     */     
/*     */     try
/*     */     {
/* 137 */       md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException e) {
/* 139 */       throw new RuntimeException(e);
/*     */     }
/*     */     
/* 142 */     md5.update(this._keyDigest);
/* 143 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(4);
/* 144 */     new LittleEndianOutputStream(baos).writeInt(keyBlockNo);
/* 145 */     md5.update(baos.toByteArray());
/*     */     
/* 147 */     byte[] digest = md5.digest();
/* 148 */     return new RC4(digest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */   private static final ThreadLocal<String> _userPasswordTLS = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCurrentUserPassword(String password)
/*     */   {
/* 165 */     _userPasswordTLS.set(password);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCurrentUserPassword()
/*     */   {
/* 173 */     return (String)_userPasswordTLS.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\crypto\Biff8EncryptionKey.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */