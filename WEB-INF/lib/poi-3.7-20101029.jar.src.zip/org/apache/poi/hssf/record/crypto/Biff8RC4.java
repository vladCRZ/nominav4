/*     */ package org.apache.poi.hssf.record.crypto;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Biff8RC4
/*     */ {
/*     */   private static final int RC4_REKEYING_INTERVAL = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private RC4 _rc4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int _streamPos;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int _nextRC4BlockStart;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int _currentKeyIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean _shouldSkipEncryptionOnCurrentRecord;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Biff8EncryptionKey _key;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Biff8RC4(int initialOffset, Biff8EncryptionKey key)
/*     */   {
/*  48 */     if (initialOffset >= 1024) {
/*  49 */       throw new RuntimeException("initialOffset (" + initialOffset + ")>" + 1024 + " not supported yet");
/*     */     }
/*     */     
/*  52 */     this._key = key;
/*  53 */     this._streamPos = 0;
/*  54 */     rekeyForNextBlock();
/*  55 */     this._streamPos = initialOffset;
/*  56 */     for (int i = initialOffset; i > 0; i--) {
/*  57 */       this._rc4.output();
/*     */     }
/*  59 */     this._shouldSkipEncryptionOnCurrentRecord = false;
/*     */   }
/*     */   
/*     */   private void rekeyForNextBlock() {
/*  63 */     this._currentKeyIndex = (this._streamPos / 1024);
/*  64 */     this._rc4 = this._key.createRC4(this._currentKeyIndex);
/*  65 */     this._nextRC4BlockStart = ((this._currentKeyIndex + 1) * 1024);
/*     */   }
/*     */   
/*     */   private int getNextRC4Byte() {
/*  69 */     if (this._streamPos >= this._nextRC4BlockStart) {
/*  70 */       rekeyForNextBlock();
/*     */     }
/*  72 */     byte mask = this._rc4.output();
/*  73 */     this._streamPos += 1;
/*  74 */     if (this._shouldSkipEncryptionOnCurrentRecord) {
/*  75 */       return 0;
/*     */     }
/*  77 */     return mask & 0xFF;
/*     */   }
/*     */   
/*     */   public void startRecord(int currentSid) {
/*  81 */     this._shouldSkipEncryptionOnCurrentRecord = isNeverEncryptedRecord(currentSid);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isNeverEncryptedRecord(int sid)
/*     */   {
/*  90 */     switch (sid)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 47: 
/*     */     case 225: 
/*     */     case 2057: 
/* 106 */       return true; }
/*     */     
/* 108 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void skipTwoBytes()
/*     */   {
/* 116 */     getNextRC4Byte();
/* 117 */     getNextRC4Byte();
/*     */   }
/*     */   
/*     */   public void xor(byte[] buf, int pOffset, int pLen)
/*     */   {
/* 122 */     int nLeftInBlock = this._nextRC4BlockStart - this._streamPos;
/* 123 */     if (pLen <= nLeftInBlock)
/*     */     {
/* 125 */       this._rc4.encrypt(buf, pOffset, pLen);
/* 126 */       this._streamPos += pLen;
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     int offset = pOffset;
/* 131 */     int len = pLen;
/*     */     
/*     */ 
/* 134 */     if (len > nLeftInBlock) {
/* 135 */       if (nLeftInBlock > 0) {
/* 136 */         this._rc4.encrypt(buf, offset, nLeftInBlock);
/* 137 */         this._streamPos += nLeftInBlock;
/* 138 */         offset += nLeftInBlock;
/* 139 */         len -= nLeftInBlock;
/*     */       }
/* 141 */       rekeyForNextBlock();
/*     */     }
/*     */     
/* 144 */     while (len > 1024) {
/* 145 */       this._rc4.encrypt(buf, offset, 1024);
/* 146 */       this._streamPos += 1024;
/* 147 */       offset += 1024;
/* 148 */       len -= 1024;
/* 149 */       rekeyForNextBlock();
/*     */     }
/*     */     
/* 152 */     this._rc4.encrypt(buf, offset, len);
/* 153 */     this._streamPos += len;
/*     */   }
/*     */   
/*     */   public int xorByte(int rawVal) {
/* 157 */     int mask = getNextRC4Byte();
/* 158 */     return (byte)(rawVal ^ mask);
/*     */   }
/*     */   
/*     */   public int xorShort(int rawVal) {
/* 162 */     int b0 = getNextRC4Byte();
/* 163 */     int b1 = getNextRC4Byte();
/* 164 */     int mask = (b1 << 8) + (b0 << 0);
/* 165 */     return rawVal ^ mask;
/*     */   }
/*     */   
/*     */   public int xorInt(int rawVal) {
/* 169 */     int b0 = getNextRC4Byte();
/* 170 */     int b1 = getNextRC4Byte();
/* 171 */     int b2 = getNextRC4Byte();
/* 172 */     int b3 = getNextRC4Byte();
/* 173 */     int mask = (b3 << 24) + (b2 << 16) + (b1 << 8) + (b0 << 0);
/* 174 */     return rawVal ^ mask;
/*     */   }
/*     */   
/*     */   public long xorLong(long rawVal) {
/* 178 */     int b0 = getNextRC4Byte();
/* 179 */     int b1 = getNextRC4Byte();
/* 180 */     int b2 = getNextRC4Byte();
/* 181 */     int b3 = getNextRC4Byte();
/* 182 */     int b4 = getNextRC4Byte();
/* 183 */     int b5 = getNextRC4Byte();
/* 184 */     int b6 = getNextRC4Byte();
/* 185 */     int b7 = getNextRC4Byte();
/* 186 */     long mask = (b7 << 56) + (b6 << 48) + (b5 << 40) + (b4 << 32) + (b3 << 24) + (b2 << 16) + (b1 << 8) + (b0 << 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */     return rawVal ^ mask;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\crypto\Biff8RC4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */