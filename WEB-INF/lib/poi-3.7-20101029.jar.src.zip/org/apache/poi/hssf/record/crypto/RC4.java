/*    */ package org.apache.poi.hssf.record.crypto;
/*    */ 
/*    */ import org.apache.poi.util.HexDump;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RC4
/*    */ {
/*    */   private int _i;
/*    */   private int _j;
/* 32 */   private final byte[] _s = new byte['Ā'];
/*    */   
/*    */   public RC4(byte[] key) {
/* 35 */     int key_length = key.length;
/*    */     
/* 37 */     for (int i = 0; i < 256; i++) {
/* 38 */       this._s[i] = ((byte)i);
/*    */     }
/* 40 */     int i = 0; for (int j = 0; i < 256; i++)
/*    */     {
/*    */ 
/* 43 */       j = j + key[(i % key_length)] + this._s[i] & 0xFF;
/* 44 */       byte temp = this._s[i];
/* 45 */       this._s[i] = this._s[j];
/* 46 */       this._s[j] = temp;
/*    */     }
/*    */     
/* 49 */     this._i = 0;
/* 50 */     this._j = 0;
/*    */   }
/*    */   
/*    */   public byte output()
/*    */   {
/* 55 */     this._i = (this._i + 1 & 0xFF);
/* 56 */     this._j = (this._j + this._s[this._i] & 0xFF);
/*    */     
/* 58 */     byte temp = this._s[this._i];
/* 59 */     this._s[this._i] = this._s[this._j];
/* 60 */     this._s[this._j] = temp;
/*    */     
/* 62 */     return this._s[(this._s[this._i] + this._s[this._j] & 0xFF)];
/*    */   }
/*    */   
/*    */   public void encrypt(byte[] in) {
/* 66 */     for (int i = 0; i < in.length; i++)
/* 67 */       in[i] = ((byte)(in[i] ^ output()));
/*    */   }
/*    */   
/*    */   public void encrypt(byte[] in, int offset, int len) {
/* 71 */     int end = offset + len;
/* 72 */     for (int i = offset; i < end; i++) {
/* 73 */       in[i] = ((byte)(in[i] ^ output()));
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 79 */     StringBuffer sb = new StringBuffer();
/*    */     
/* 81 */     sb.append(getClass().getName()).append(" [");
/* 82 */     sb.append("i=").append(this._i);
/* 83 */     sb.append(" j=").append(this._j);
/* 84 */     sb.append("]");
/* 85 */     sb.append("\n");
/* 86 */     sb.append(HexDump.dump(this._s, 0L, 0));
/*    */     
/* 88 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\crypto\RC4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */