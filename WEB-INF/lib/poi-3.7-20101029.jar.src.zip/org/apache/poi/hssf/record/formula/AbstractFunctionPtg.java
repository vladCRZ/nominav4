/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.function.FunctionMetadata;
/*     */ import org.apache.poi.hssf.record.formula.function.FunctionMetadataRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFunctionPtg
/*     */   extends OperationPtg
/*     */ {
/*     */   public static final String FUNCTION_NAME_IF = "IF";
/*     */   private static final short FUNCTION_INDEX_EXTERNAL = 255;
/*     */   private final byte returnClass;
/*     */   private final byte[] paramClass;
/*     */   private final byte _numberOfArgs;
/*     */   private final short _functionIndex;
/*     */   
/*     */   protected AbstractFunctionPtg(int functionIndex, int pReturnClass, byte[] paramTypes, int nParams)
/*     */   {
/*  47 */     this._numberOfArgs = ((byte)nParams);
/*  48 */     this._functionIndex = ((short)functionIndex);
/*  49 */     this.returnClass = ((byte)pReturnClass);
/*  50 */     this.paramClass = paramTypes;
/*     */   }
/*     */   
/*  53 */   public final boolean isBaseToken() { return false; }
/*     */   
/*     */   public final String toString()
/*     */   {
/*  57 */     StringBuilder sb = new StringBuilder(64);
/*  58 */     sb.append(getClass().getName()).append(" [");
/*  59 */     sb.append(lookupName(this._functionIndex));
/*  60 */     sb.append(" nArgs=").append(this._numberOfArgs);
/*  61 */     sb.append("]");
/*  62 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public final short getFunctionIndex() {
/*  66 */     return this._functionIndex;
/*     */   }
/*     */   
/*  69 */   public final int getNumberOfOperands() { return this._numberOfArgs; }
/*     */   
/*     */   public final String getName()
/*     */   {
/*  73 */     return lookupName(this._functionIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isExternalFunction()
/*     */   {
/*  80 */     return this._functionIndex == 255;
/*     */   }
/*     */   
/*     */   public final String toFormulaString() {
/*  84 */     return getName();
/*     */   }
/*     */   
/*     */   public String toFormulaString(String[] operands) {
/*  88 */     StringBuilder buf = new StringBuilder();
/*     */     
/*  90 */     if (isExternalFunction()) {
/*  91 */       buf.append(operands[0]);
/*  92 */       appendArgs(buf, 1, operands);
/*     */     } else {
/*  94 */       buf.append(getName());
/*  95 */       appendArgs(buf, 0, operands);
/*     */     }
/*  97 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private static void appendArgs(StringBuilder buf, int firstArgIx, String[] operands) {
/* 101 */     buf.append('(');
/* 102 */     for (int i = firstArgIx; i < operands.length; i++) {
/* 103 */       if (i > firstArgIx) {
/* 104 */         buf.append(',');
/*     */       }
/* 106 */       buf.append(operands[i]);
/*     */     }
/* 108 */     buf.append(")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getSize();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean isBuiltInFunctionName(String name)
/*     */   {
/* 122 */     short ix = FunctionMetadataRegistry.lookupIndexByName(name.toUpperCase());
/* 123 */     return ix >= 0;
/*     */   }
/*     */   
/*     */   protected final String lookupName(short index) {
/* 127 */     if (index == 255) {
/* 128 */       return "#external#";
/*     */     }
/* 130 */     FunctionMetadata fm = FunctionMetadataRegistry.getFunctionByIndex(index);
/* 131 */     if (fm == null) {
/* 132 */       throw new RuntimeException("bad function index (" + index + ")");
/*     */     }
/* 134 */     return fm.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static short lookupIndex(String name)
/*     */   {
/* 144 */     short ix = FunctionMetadataRegistry.lookupIndexByName(name.toUpperCase());
/* 145 */     if (ix < 0) {
/* 146 */       return 255;
/*     */     }
/* 148 */     return ix;
/*     */   }
/*     */   
/*     */   public byte getDefaultOperandClass() {
/* 152 */     return this.returnClass;
/*     */   }
/*     */   
/*     */   public final byte getParameterClass(int index) {
/* 156 */     if (index >= this.paramClass.length)
/*     */     {
/*     */ 
/*     */ 
/* 160 */       return this.paramClass[(this.paramClass.length - 1)];
/*     */     }
/* 162 */     return this.paramClass[index];
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AbstractFunctionPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */