/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AddPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final byte sid = 3;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String ADD = "+";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 31 */   public static final ValueOperatorPtg instance = new AddPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 38 */     return 3;
/*    */   }
/*    */   
/*    */   public int getNumberOfOperands() {
/* 42 */     return 2;
/*    */   }
/*    */   
/*    */   public String toFormulaString(String[] operands)
/*    */   {
/* 47 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 49 */     buffer.append(operands[0]);
/* 50 */     buffer.append("+");
/* 51 */     buffer.append(operands[1]);
/* 52 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AddPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */