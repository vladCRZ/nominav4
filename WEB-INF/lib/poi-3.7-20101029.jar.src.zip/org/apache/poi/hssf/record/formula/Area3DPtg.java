/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import org.apache.poi.ss.formula.ExternSheetReferenceToken;
/*     */ import org.apache.poi.ss.formula.FormulaRenderingWorkbook;
/*     */ import org.apache.poi.ss.formula.WorkbookDependentFormula;
/*     */ import org.apache.poi.ss.util.AreaReference;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Area3DPtg
/*     */   extends AreaPtgBase
/*     */   implements WorkbookDependentFormula, ExternSheetReferenceToken
/*     */ {
/*     */   public static final byte sid = 59;
/*     */   private static final int SIZE = 11;
/*     */   private int field_1_index_extern_sheet;
/*     */   
/*     */   public Area3DPtg(String arearef, int externIdx)
/*     */   {
/*  43 */     super(new AreaReference(arearef));
/*  44 */     setExternSheetIndex(externIdx);
/*     */   }
/*     */   
/*     */   public Area3DPtg(LittleEndianInput in) {
/*  48 */     this.field_1_index_extern_sheet = in.readShort();
/*  49 */     readCoordinates(in);
/*     */   }
/*     */   
/*     */ 
/*     */   public Area3DPtg(int firstRow, int lastRow, int firstColumn, int lastColumn, boolean firstRowRelative, boolean lastRowRelative, boolean firstColRelative, boolean lastColRelative, int externalSheetIndex)
/*     */   {
/*  55 */     super(firstRow, lastRow, firstColumn, lastColumn, firstRowRelative, lastRowRelative, firstColRelative, lastColRelative);
/*  56 */     setExternSheetIndex(externalSheetIndex);
/*     */   }
/*     */   
/*     */   public Area3DPtg(AreaReference arearef, int externIdx) {
/*  60 */     super(arearef);
/*  61 */     setExternSheetIndex(externIdx);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  65 */     StringBuffer sb = new StringBuffer();
/*  66 */     sb.append(getClass().getName());
/*  67 */     sb.append(" [");
/*  68 */     sb.append("sheetIx=").append(getExternSheetIndex());
/*  69 */     sb.append(" ! ");
/*  70 */     sb.append(formatReferenceAsString());
/*  71 */     sb.append("]");
/*  72 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void write(LittleEndianOutput out) {
/*  76 */     out.writeByte(59 + getPtgClass());
/*  77 */     out.writeShort(this.field_1_index_extern_sheet);
/*  78 */     writeCoordinates(out);
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  82 */     return 11;
/*     */   }
/*     */   
/*     */   public int getExternSheetIndex() {
/*  86 */     return this.field_1_index_extern_sheet;
/*     */   }
/*     */   
/*     */   public void setExternSheetIndex(int index) {
/*  90 */     this.field_1_index_extern_sheet = index;
/*     */   }
/*     */   
/*  93 */   public String format2DRefAsString() { return formatReferenceAsString(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toFormulaString(FormulaRenderingWorkbook book)
/*     */   {
/* 100 */     return ExternSheetNameResolver.prependSheetName(book, this.field_1_index_extern_sheet, formatReferenceAsString());
/*     */   }
/*     */   
/* 103 */   public String toFormulaString() { throw new RuntimeException("3D references need a workbook to determine formula text"); }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\Area3DPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */