/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.usermodel.HSSFErrorConstants;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AreaErrPtg
/*    */   extends OperandPtg
/*    */ {
/*    */   public static final byte sid = 43;
/*    */   private final int unused1;
/*    */   private final int unused2;
/*    */   
/*    */   public AreaErrPtg()
/*    */   {
/* 35 */     this.unused1 = 0;
/* 36 */     this.unused2 = 0;
/*    */   }
/*    */   
/*    */   public AreaErrPtg(LittleEndianInput in)
/*    */   {
/* 41 */     this.unused1 = in.readInt();
/* 42 */     this.unused2 = in.readInt();
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 46 */     out.writeByte(43 + getPtgClass());
/* 47 */     out.writeInt(this.unused1);
/* 48 */     out.writeInt(this.unused2);
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 52 */     return HSSFErrorConstants.getText(23);
/*    */   }
/*    */   
/*    */   public byte getDefaultOperandClass() {
/* 56 */     return 0;
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 60 */     return 9;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AreaErrPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */