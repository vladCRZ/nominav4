/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface AreaI
/*    */ {
/*    */   public abstract int getFirstRow();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract int getLastRow();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract int getFirstColumn();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract int getLastColumn();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static class OffsetArea
/*    */     implements AreaI
/*    */   {
/*    */     private final int _firstColumn;
/*    */     
/*    */ 
/*    */ 
/*    */     private final int _firstRow;
/*    */     
/*    */ 
/*    */ 
/*    */     private final int _lastColumn;
/*    */     
/*    */ 
/*    */ 
/*    */     private final int _lastRow;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     public OffsetArea(int baseRow, int baseColumn, int relFirstRowIx, int relLastRowIx, int relFirstColIx, int relLastColIx)
/*    */     {
/* 53 */       this._firstRow = (baseRow + Math.min(relFirstRowIx, relLastRowIx));
/* 54 */       this._lastRow = (baseRow + Math.max(relFirstRowIx, relLastRowIx));
/* 55 */       this._firstColumn = (baseColumn + Math.min(relFirstColIx, relLastColIx));
/* 56 */       this._lastColumn = (baseColumn + Math.max(relFirstColIx, relLastColIx));
/*    */     }
/*    */     
/*    */     public int getFirstColumn() {
/* 60 */       return this._firstColumn;
/*    */     }
/*    */     
/*    */     public int getFirstRow() {
/* 64 */       return this._firstRow;
/*    */     }
/*    */     
/*    */     public int getLastColumn() {
/* 68 */       return this._lastColumn;
/*    */     }
/*    */     
/*    */     public int getLastRow() {
/* 72 */       return this._lastRow;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AreaI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */