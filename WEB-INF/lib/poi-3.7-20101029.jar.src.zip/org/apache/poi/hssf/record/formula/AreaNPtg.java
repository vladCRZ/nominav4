/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AreaNPtg
/*    */   extends Area2DPtgBase
/*    */ {
/*    */   public static final short sid = 45;
/*    */   
/*    */   public AreaNPtg(LittleEndianInput in)
/*    */   {
/* 30 */     super(in);
/*    */   }
/*    */   
/*    */   protected byte getSid() {
/* 34 */     return 45;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AreaNPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */