/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.util.AreaReference;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AreaPtg
/*    */   extends Area2DPtgBase
/*    */ {
/*    */   public static final short sid = 37;
/*    */   
/*    */   public AreaPtg(int firstRow, int lastRow, int firstColumn, int lastColumn, boolean firstRowRelative, boolean lastRowRelative, boolean firstColRelative, boolean lastColRelative)
/*    */   {
/* 31 */     super(firstRow, lastRow, firstColumn, lastColumn, firstRowRelative, lastRowRelative, firstColRelative, lastColRelative);
/*    */   }
/*    */   
/* 34 */   public AreaPtg(LittleEndianInput in) { super(in); }
/*    */   
/*    */   public AreaPtg(String arearef) {
/* 37 */     super(new AreaReference(arearef));
/*    */   }
/*    */   
/* 40 */   public AreaPtg(AreaReference areaRef) { super(areaRef); }
/*    */   
/*    */   protected byte getSid() {
/* 43 */     return 37;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AreaPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */