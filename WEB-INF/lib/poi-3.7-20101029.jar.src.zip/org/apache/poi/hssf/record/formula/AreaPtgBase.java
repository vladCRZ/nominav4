/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import org.apache.poi.ss.util.AreaReference;
/*     */ import org.apache.poi.ss.util.CellReference;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AreaPtgBase
/*     */   extends OperandPtg
/*     */   implements AreaI
/*     */ {
/*     */   private int field_1_first_row;
/*     */   private int field_2_last_row;
/*     */   private int field_3_first_column;
/*     */   private int field_4_last_column;
/*     */   
/*     */   protected final RuntimeException notImplemented()
/*     */   {
/*  38 */     return new RuntimeException("Coding Error: This method should never be called. This ptg should be converted");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private static final BitField rowRelative = BitFieldFactory.getInstance(32768);
/*  51 */   private static final BitField colRelative = BitFieldFactory.getInstance(16384);
/*  52 */   private static final BitField columnMask = BitFieldFactory.getInstance(16383);
/*     */   
/*     */ 
/*     */   protected AreaPtgBase() {}
/*     */   
/*     */   protected AreaPtgBase(AreaReference ar)
/*     */   {
/*  59 */     CellReference firstCell = ar.getFirstCell();
/*  60 */     CellReference lastCell = ar.getLastCell();
/*  61 */     setFirstRow(firstCell.getRow());
/*  62 */     setFirstColumn(firstCell.getCol() == -1 ? 0 : firstCell.getCol());
/*  63 */     setLastRow(lastCell.getRow());
/*  64 */     setLastColumn(lastCell.getCol() == -1 ? 255 : lastCell.getCol());
/*  65 */     setFirstColRelative(!firstCell.isColAbsolute());
/*  66 */     setLastColRelative(!lastCell.isColAbsolute());
/*  67 */     setFirstRowRelative(!firstCell.isRowAbsolute());
/*  68 */     setLastRowRelative(!lastCell.isRowAbsolute());
/*     */   }
/*     */   
/*     */ 
/*     */   protected AreaPtgBase(int firstRow, int lastRow, int firstColumn, int lastColumn, boolean firstRowRelative, boolean lastRowRelative, boolean firstColRelative, boolean lastColRelative)
/*     */   {
/*  74 */     if (lastRow > firstRow) {
/*  75 */       setFirstRow(firstRow);
/*  76 */       setLastRow(lastRow);
/*  77 */       setFirstRowRelative(firstRowRelative);
/*  78 */       setLastRowRelative(lastRowRelative);
/*     */     } else {
/*  80 */       setFirstRow(lastRow);
/*  81 */       setLastRow(firstRow);
/*  82 */       setFirstRowRelative(lastRowRelative);
/*  83 */       setLastRowRelative(firstRowRelative);
/*     */     }
/*     */     
/*  86 */     if (lastColumn > firstColumn) {
/*  87 */       setFirstColumn(firstColumn);
/*  88 */       setLastColumn(lastColumn);
/*  89 */       setFirstColRelative(firstColRelative);
/*  90 */       setLastColRelative(lastColRelative);
/*     */     } else {
/*  92 */       setFirstColumn(lastColumn);
/*  93 */       setLastColumn(firstColumn);
/*  94 */       setFirstColRelative(lastColRelative);
/*  95 */       setLastColRelative(firstColRelative);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void readCoordinates(LittleEndianInput in) {
/* 100 */     this.field_1_first_row = in.readUShort();
/* 101 */     this.field_2_last_row = in.readUShort();
/* 102 */     this.field_3_first_column = in.readUShort();
/* 103 */     this.field_4_last_column = in.readUShort();
/*     */   }
/*     */   
/* 106 */   protected final void writeCoordinates(LittleEndianOutput out) { out.writeShort(this.field_1_first_row);
/* 107 */     out.writeShort(this.field_2_last_row);
/* 108 */     out.writeShort(this.field_3_first_column);
/* 109 */     out.writeShort(this.field_4_last_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getFirstRow()
/*     */   {
/* 116 */     return this.field_1_first_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setFirstRow(int rowIx)
/*     */   {
/* 124 */     this.field_1_first_row = rowIx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getLastRow()
/*     */   {
/* 131 */     return this.field_2_last_row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setLastRow(int rowIx)
/*     */   {
/* 138 */     this.field_2_last_row = rowIx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getFirstColumn()
/*     */   {
/* 145 */     return columnMask.getValue(this.field_3_first_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final short getFirstColumnRaw()
/*     */   {
/* 152 */     return (short)this.field_3_first_column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isFirstRowRelative()
/*     */   {
/* 159 */     return rowRelative.isSet(this.field_3_first_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setFirstRowRelative(boolean rel)
/*     */   {
/* 167 */     this.field_3_first_column = rowRelative.setBoolean(this.field_3_first_column, rel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isFirstColRelative()
/*     */   {
/* 174 */     return colRelative.isSet(this.field_3_first_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setFirstColRelative(boolean rel)
/*     */   {
/* 181 */     this.field_3_first_column = colRelative.setBoolean(this.field_3_first_column, rel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setFirstColumn(int colIx)
/*     */   {
/* 188 */     this.field_3_first_column = columnMask.setValue(this.field_3_first_column, colIx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setFirstColumnRaw(int column)
/*     */   {
/* 195 */     this.field_3_first_column = column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getLastColumn()
/*     */   {
/* 202 */     return columnMask.getValue(this.field_4_last_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final short getLastColumnRaw()
/*     */   {
/* 209 */     return (short)this.field_4_last_column;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isLastRowRelative()
/*     */   {
/* 216 */     return rowRelative.isSet(this.field_4_last_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLastRowRelative(boolean rel)
/*     */   {
/* 225 */     this.field_4_last_column = rowRelative.setBoolean(this.field_4_last_column, rel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isLastColRelative()
/*     */   {
/* 232 */     return colRelative.isSet(this.field_4_last_column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setLastColRelative(boolean rel)
/*     */   {
/* 239 */     this.field_4_last_column = colRelative.setBoolean(this.field_4_last_column, rel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setLastColumn(int colIx)
/*     */   {
/* 246 */     this.field_4_last_column = columnMask.setValue(this.field_4_last_column, colIx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */   public final void setLastColumnRaw(short column) { this.field_4_last_column = column; }
/*     */   
/*     */   protected final String formatReferenceAsString() {
/* 256 */     CellReference topLeft = new CellReference(getFirstRow(), getFirstColumn(), !isFirstRowRelative(), !isFirstColRelative());
/* 257 */     CellReference botRight = new CellReference(getLastRow(), getLastColumn(), !isLastRowRelative(), !isLastColRelative());
/*     */     
/* 259 */     if (AreaReference.isWholeColumnReference(topLeft, botRight)) {
/* 260 */       return new AreaReference(topLeft, botRight).formatAsString();
/*     */     }
/* 262 */     return topLeft.formatAsString() + ":" + botRight.formatAsString();
/*     */   }
/*     */   
/*     */   public String toFormulaString() {
/* 266 */     return formatReferenceAsString();
/*     */   }
/*     */   
/*     */   public byte getDefaultOperandClass() {
/* 270 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\AreaPtgBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */