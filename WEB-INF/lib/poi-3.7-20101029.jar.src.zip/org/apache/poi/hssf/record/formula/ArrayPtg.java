/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import org.apache.poi.hssf.record.constant.ConstantValueParser;
/*     */ import org.apache.poi.hssf.record.constant.ErrorConstant;
/*     */ import org.apache.poi.ss.util.NumberToTextConverter;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ArrayPtg
/*     */   extends Ptg
/*     */ {
/*     */   public static final byte sid = 32;
/*     */   private static final int RESERVED_FIELD_LEN = 7;
/*     */   public static final int PLAIN_TOKEN_SIZE = 8;
/*     */   private final int _reserved0Int;
/*     */   private final int _reserved1Short;
/*     */   private final int _reserved2Byte;
/*     */   private final int _nColumns;
/*     */   private final int _nRows;
/*     */   private final Object[] _arrayValues;
/*     */   
/*     */   ArrayPtg(int reserved0, int reserved1, int reserved2, int nColumns, int nRows, Object[] arrayValues)
/*     */   {
/*  58 */     this._reserved0Int = reserved0;
/*  59 */     this._reserved1Short = reserved1;
/*  60 */     this._reserved2Byte = reserved2;
/*  61 */     this._nColumns = nColumns;
/*  62 */     this._nRows = nRows;
/*  63 */     this._arrayValues = arrayValues;
/*     */   }
/*     */   
/*     */ 
/*     */   public ArrayPtg(Object[][] values2d)
/*     */   {
/*  69 */     int nColumns = values2d[0].length;
/*  70 */     int nRows = values2d.length;
/*     */     
/*  72 */     this._nColumns = ((short)nColumns);
/*  73 */     this._nRows = ((short)nRows);
/*     */     
/*  75 */     Object[] vv = new Object[this._nColumns * this._nRows];
/*  76 */     for (int r = 0; r < nRows; r++) {
/*  77 */       Object[] rowData = values2d[r];
/*  78 */       for (int c = 0; c < nColumns; c++) {
/*  79 */         vv[getValueIndex(c, r)] = rowData[c];
/*     */       }
/*     */     }
/*     */     
/*  83 */     this._arrayValues = vv;
/*  84 */     this._reserved0Int = 0;
/*  85 */     this._reserved1Short = 0;
/*  86 */     this._reserved2Byte = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object[][] getTokenArrayValues()
/*     */   {
/*  92 */     if (this._arrayValues == null) {
/*  93 */       throw new IllegalStateException("array values not read yet");
/*     */     }
/*  95 */     Object[][] result = new Object[this._nRows][this._nColumns];
/*  96 */     for (int r = 0; r < this._nRows; r++) {
/*  97 */       Object[] rowData = result[r];
/*  98 */       for (int c = 0; c < this._nColumns; c++) {
/*  99 */         rowData[c] = this._arrayValues[getValueIndex(c, r)];
/*     */       }
/*     */     }
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isBaseToken() {
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 110 */     StringBuffer sb = new StringBuffer("[ArrayPtg]\n");
/*     */     
/* 112 */     sb.append("nRows = ").append(getRowCount()).append("\n");
/* 113 */     sb.append("nCols = ").append(getColumnCount()).append("\n");
/* 114 */     if (this._arrayValues == null) {
/* 115 */       sb.append("  #values#uninitialised#\n");
/*     */     } else {
/* 117 */       sb.append("  ").append(toFormulaString());
/*     */     }
/* 119 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getValueIndex(int colIx, int rowIx)
/*     */   {
/* 127 */     if ((colIx < 0) || (colIx >= this._nColumns)) {
/* 128 */       throw new IllegalArgumentException("Specified colIx (" + colIx + ") is outside the allowed range (0.." + (this._nColumns - 1) + ")");
/*     */     }
/*     */     
/* 131 */     if ((rowIx < 0) || (rowIx >= this._nRows)) {
/* 132 */       throw new IllegalArgumentException("Specified rowIx (" + rowIx + ") is outside the allowed range (0.." + (this._nRows - 1) + ")");
/*     */     }
/*     */     
/* 135 */     return rowIx * this._nColumns + colIx;
/*     */   }
/*     */   
/*     */   public void write(LittleEndianOutput out) {
/* 139 */     out.writeByte(32 + getPtgClass());
/* 140 */     out.writeInt(this._reserved0Int);
/* 141 */     out.writeShort(this._reserved1Short);
/* 142 */     out.writeByte(this._reserved2Byte);
/*     */   }
/*     */   
/*     */   public int writeTokenValueBytes(LittleEndianOutput out)
/*     */   {
/* 147 */     out.writeByte(this._nColumns - 1);
/* 148 */     out.writeShort(this._nRows - 1);
/* 149 */     ConstantValueParser.encode(out, this._arrayValues);
/* 150 */     return 3 + ConstantValueParser.getEncodedSize(this._arrayValues);
/*     */   }
/*     */   
/*     */   public int getRowCount() {
/* 154 */     return this._nRows;
/*     */   }
/*     */   
/*     */   public int getColumnCount() {
/* 158 */     return this._nColumns;
/*     */   }
/*     */   
/*     */   public int getSize()
/*     */   {
/* 163 */     return 11 + ConstantValueParser.getEncodedSize(this._arrayValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toFormulaString()
/*     */   {
/* 170 */     StringBuffer b = new StringBuffer();
/* 171 */     b.append("{");
/* 172 */     for (int y = 0; y < getRowCount(); y++) {
/* 173 */       if (y > 0) {
/* 174 */         b.append(";");
/*     */       }
/* 176 */       for (int x = 0; x < getColumnCount(); x++) {
/* 177 */         if (x > 0) {
/* 178 */           b.append(",");
/*     */         }
/* 180 */         Object o = this._arrayValues[getValueIndex(x, y)];
/* 181 */         b.append(getConstantText(o));
/*     */       }
/*     */     }
/* 184 */     b.append("}");
/* 185 */     return b.toString();
/*     */   }
/*     */   
/*     */   private static String getConstantText(Object o)
/*     */   {
/* 190 */     if (o == null) {
/* 191 */       throw new RuntimeException("Array item cannot be null");
/*     */     }
/* 193 */     if ((o instanceof String)) {
/* 194 */       return "\"" + (String)o + "\"";
/*     */     }
/* 196 */     if ((o instanceof Double)) {
/* 197 */       return NumberToTextConverter.toText(((Double)o).doubleValue());
/*     */     }
/* 199 */     if ((o instanceof Boolean)) {
/* 200 */       return ((Boolean)o).booleanValue() ? "TRUE" : "FALSE";
/*     */     }
/* 202 */     if ((o instanceof ErrorConstant)) {
/* 203 */       return ((ErrorConstant)o).getText();
/*     */     }
/* 205 */     throw new IllegalArgumentException("Unexpected constant class (" + o.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */   public byte getDefaultOperandClass() {
/* 209 */     return 64;
/*     */   }
/*     */   
/*     */ 
/*     */   static final class Initial
/*     */     extends Ptg
/*     */   {
/*     */     private final int _reserved0;
/*     */     
/*     */     private final int _reserved1;
/*     */     
/*     */     private final int _reserved2;
/*     */     
/*     */     public Initial(LittleEndianInput in)
/*     */     {
/* 224 */       this._reserved0 = in.readInt();
/* 225 */       this._reserved1 = in.readUShort();
/* 226 */       this._reserved2 = in.readUByte();
/*     */     }
/*     */     
/* 229 */     private static RuntimeException invalid() { throw new IllegalStateException("This object is a partially initialised tArray, and cannot be used as a Ptg"); }
/*     */     
/*     */     public byte getDefaultOperandClass() {
/* 232 */       throw invalid();
/*     */     }
/*     */     
/* 235 */     public int getSize() { return 8; }
/*     */     
/*     */     public boolean isBaseToken() {
/* 238 */       return false;
/*     */     }
/*     */     
/* 241 */     public String toFormulaString() { throw invalid(); }
/*     */     
/*     */     public void write(LittleEndianOutput out) {
/* 244 */       throw invalid();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public ArrayPtg finishReading(LittleEndianInput in)
/*     */     {
/* 252 */       int nColumns = in.readUByte();
/* 253 */       short nRows = in.readShort();
/*     */       
/*     */ 
/*     */ 
/* 257 */       nColumns++;
/* 258 */       nRows = (short)(nRows + 1);
/*     */       
/* 260 */       int totalCount = nRows * nColumns;
/* 261 */       Object[] arrayValues = ConstantValueParser.parse(in, totalCount);
/*     */       
/* 263 */       ArrayPtg result = new ArrayPtg(this._reserved0, this._reserved1, this._reserved2, nColumns, nRows, arrayValues);
/* 264 */       result.setClass(getPtgClass());
/* 265 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ArrayPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */