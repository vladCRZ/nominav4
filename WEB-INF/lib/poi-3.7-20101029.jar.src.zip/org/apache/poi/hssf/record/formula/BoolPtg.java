/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BoolPtg
/*    */   extends ScalarConstantPtg
/*    */ {
/*    */   public static final int SIZE = 2;
/*    */   public static final byte sid = 29;
/* 34 */   private static final BoolPtg FALSE = new BoolPtg(false);
/* 35 */   private static final BoolPtg TRUE = new BoolPtg(true);
/*    */   private final boolean _value;
/*    */   
/*    */   private BoolPtg(boolean b)
/*    */   {
/* 40 */     this._value = b;
/*    */   }
/*    */   
/*    */   public static BoolPtg valueOf(boolean b) {
/* 44 */     return b ? TRUE : FALSE;
/*    */   }
/*    */   
/* 47 */   public static BoolPtg read(LittleEndianInput in) { return valueOf(in.readByte() == 1); }
/*    */   
/*    */   public boolean getValue()
/*    */   {
/* 51 */     return this._value;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 55 */     out.writeByte(29 + getPtgClass());
/* 56 */     out.writeByte(this._value ? 1 : 0);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 60 */     return 2;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 64 */     return this._value ? "TRUE" : "FALSE";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\BoolPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */