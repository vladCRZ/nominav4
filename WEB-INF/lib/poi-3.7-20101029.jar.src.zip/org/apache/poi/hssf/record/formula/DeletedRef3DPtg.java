/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.usermodel.HSSFErrorConstants;
/*    */ import org.apache.poi.ss.formula.FormulaRenderingWorkbook;
/*    */ import org.apache.poi.ss.formula.WorkbookDependentFormula;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DeletedRef3DPtg
/*    */   extends OperandPtg
/*    */   implements WorkbookDependentFormula
/*    */ {
/*    */   public static final byte sid = 60;
/*    */   private final int field_1_index_extern_sheet;
/*    */   private final int unused1;
/*    */   
/*    */   public DeletedRef3DPtg(LittleEndianInput in)
/*    */   {
/* 41 */     this.field_1_index_extern_sheet = in.readUShort();
/* 42 */     this.unused1 = in.readInt();
/*    */   }
/*    */   
/*    */   public DeletedRef3DPtg(int externSheetIndex) {
/* 46 */     this.field_1_index_extern_sheet = externSheetIndex;
/* 47 */     this.unused1 = 0;
/*    */   }
/*    */   
/*    */   public String toFormulaString(FormulaRenderingWorkbook book) {
/* 51 */     return ExternSheetNameResolver.prependSheetName(book, this.field_1_index_extern_sheet, HSSFErrorConstants.getText(23));
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 55 */     throw new RuntimeException("3D references need a workbook to determine formula text");
/*    */   }
/*    */   
/* 58 */   public byte getDefaultOperandClass() { return 0; }
/*    */   
/*    */ 
/* 61 */   public int getSize() { return 7; }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 64 */     out.writeByte(60 + getPtgClass());
/* 65 */     out.writeShort(this.field_1_index_extern_sheet);
/* 66 */     out.writeInt(this.unused1);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\DeletedRef3DPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */