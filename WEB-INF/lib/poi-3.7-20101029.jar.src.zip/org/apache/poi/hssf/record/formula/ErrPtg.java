/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.usermodel.HSSFErrorConstants;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ErrPtg
/*    */   extends ScalarConstantPtg
/*    */ {
/* 30 */   private static final HSSFErrorConstants EC = null;
/*    */   
/*    */ 
/* 33 */   public static final ErrPtg NULL_INTERSECTION = new ErrPtg(0);
/*    */   
/* 35 */   public static final ErrPtg DIV_ZERO = new ErrPtg(7);
/*    */   
/* 37 */   public static final ErrPtg VALUE_INVALID = new ErrPtg(15);
/*    */   
/* 39 */   public static final ErrPtg REF_INVALID = new ErrPtg(23);
/*    */   
/* 41 */   public static final ErrPtg NAME_INVALID = new ErrPtg(29);
/*    */   
/* 43 */   public static final ErrPtg NUM_ERROR = new ErrPtg(36);
/*    */   
/* 45 */   public static final ErrPtg N_A = new ErrPtg(42);
/*    */   
/*    */   public static final short sid = 28;
/*    */   
/*    */   private static final int SIZE = 2;
/*    */   
/*    */   private final int field_1_error_code;
/*    */   
/*    */   private ErrPtg(int errorCode)
/*    */   {
/* 55 */     if (!HSSFErrorConstants.isValidCode(errorCode)) {
/* 56 */       throw new IllegalArgumentException("Invalid error code (" + errorCode + ")");
/*    */     }
/* 58 */     this.field_1_error_code = errorCode;
/*    */   }
/*    */   
/*    */   public static ErrPtg read(LittleEndianInput in) {
/* 62 */     return valueOf(in.readByte());
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 66 */     out.writeByte(28 + getPtgClass());
/* 67 */     out.writeByte(this.field_1_error_code);
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 71 */     return HSSFErrorConstants.getText(this.field_1_error_code);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 75 */     return 2;
/*    */   }
/*    */   
/*    */   public int getErrorCode() {
/* 79 */     return this.field_1_error_code;
/*    */   }
/*    */   
/*    */   public static ErrPtg valueOf(int code) {
/* 83 */     switch (code) {
/* 84 */     case 7:  return DIV_ZERO;
/* 85 */     case 42:  return N_A;
/* 86 */     case 29:  return NAME_INVALID;
/* 87 */     case 0:  return NULL_INTERSECTION;
/* 88 */     case 36:  return NUM_ERROR;
/* 89 */     case 23:  return REF_INVALID;
/* 90 */     case 15:  return VALUE_INVALID;
/*    */     }
/* 92 */     throw new RuntimeException("Unexpected error code (" + code + ")");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ErrPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */