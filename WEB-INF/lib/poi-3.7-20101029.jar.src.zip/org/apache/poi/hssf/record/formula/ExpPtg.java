/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordFormatException;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExpPtg
/*    */   extends ControlPtg
/*    */ {
/*    */   private static final int SIZE = 5;
/*    */   public static final short sid = 1;
/*    */   private final int field_1_first_row;
/*    */   private final int field_2_first_col;
/*    */   
/*    */   public ExpPtg(LittleEndianInput in)
/*    */   {
/* 37 */     this.field_1_first_row = in.readShort();
/* 38 */     this.field_2_first_col = in.readShort();
/*    */   }
/*    */   
/*    */   public ExpPtg(int firstRow, int firstCol) {
/* 42 */     this.field_1_first_row = firstRow;
/* 43 */     this.field_2_first_col = firstCol;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 47 */     out.writeByte(1 + getPtgClass());
/* 48 */     out.writeShort(this.field_1_first_row);
/* 49 */     out.writeShort(this.field_2_first_col);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 53 */     return 5;
/*    */   }
/*    */   
/*    */   public int getRow() {
/* 57 */     return this.field_1_first_row;
/*    */   }
/*    */   
/*    */   public int getColumn() {
/* 61 */     return this.field_2_first_col;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 65 */     throw new RecordFormatException("Coding Error: Expected ExpPtg to be converted from Shared to Non-Shared Formula by ValueRecordsAggregate, but it wasn't");
/*    */   }
/*    */   
/*    */   public String toString() {
/* 69 */     StringBuffer buffer = new StringBuffer("[Array Formula or Shared Formula]\n");
/* 70 */     buffer.append("row = ").append(getRow()).append("\n");
/* 71 */     buffer.append("col = ").append(getColumn()).append("\n");
/* 72 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ExpPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */