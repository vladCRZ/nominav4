/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.formula.EvaluationWorkbook.ExternalSheet;
/*    */ import org.apache.poi.ss.formula.FormulaRenderingWorkbook;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExternSheetNameResolver
/*    */ {
/*    */   public static String prependSheetName(FormulaRenderingWorkbook book, int field_1_index_extern_sheet, String cellRefText)
/*    */   {
/* 33 */     EvaluationWorkbook.ExternalSheet externalSheet = book.getExternalSheet(field_1_index_extern_sheet);
/*    */     StringBuffer sb;
/* 35 */     if (externalSheet != null) {
/* 36 */       String wbName = externalSheet.getWorkbookName();
/* 37 */       String sheetName = externalSheet.getSheetName();
/* 38 */       StringBuffer sb = new StringBuffer(wbName.length() + sheetName.length() + cellRefText.length() + 4);
/* 39 */       SheetNameFormatter.appendFormat(sb, wbName, sheetName);
/*    */     } else {
/* 41 */       String sheetName = book.getSheetNameByExternSheet(field_1_index_extern_sheet);
/* 42 */       sb = new StringBuffer(sheetName.length() + cellRefText.length() + 4);
/* 43 */       if (sheetName.length() < 1)
/*    */       {
/* 45 */         sb.append("#REF");
/*    */       } else {
/* 47 */         SheetNameFormatter.appendFormat(sb, sheetName);
/*    */       }
/*    */     }
/* 50 */     sb.append('!');
/* 51 */     sb.append(cellRefText);
/* 52 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ExternSheetNameResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */