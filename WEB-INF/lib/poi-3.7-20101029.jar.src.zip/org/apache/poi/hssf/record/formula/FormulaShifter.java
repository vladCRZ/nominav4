/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormulaShifter
/*     */ {
/*     */   private final int _externSheetIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int _firstMovedIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int _lastMovedIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int _amountToMove;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FormulaShifter(int externSheetIndex, int firstMovedIndex, int lastMovedIndex, int amountToMove)
/*     */   {
/*  35 */     if (amountToMove == 0) {
/*  36 */       throw new IllegalArgumentException("amountToMove must not be zero");
/*     */     }
/*  38 */     if (firstMovedIndex > lastMovedIndex) {
/*  39 */       throw new IllegalArgumentException("firstMovedIndex, lastMovedIndex out of order");
/*     */     }
/*  41 */     this._externSheetIndex = externSheetIndex;
/*  42 */     this._firstMovedIndex = firstMovedIndex;
/*  43 */     this._lastMovedIndex = lastMovedIndex;
/*  44 */     this._amountToMove = amountToMove;
/*     */   }
/*     */   
/*     */   public static FormulaShifter createForRowShift(int externSheetIndex, int firstMovedRowIndex, int lastMovedRowIndex, int numberOfRowsToMove) {
/*  48 */     return new FormulaShifter(externSheetIndex, firstMovedRowIndex, lastMovedRowIndex, numberOfRowsToMove);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  52 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  54 */     sb.append(getClass().getName());
/*  55 */     sb.append(" [");
/*  56 */     sb.append(this._firstMovedIndex);
/*  57 */     sb.append(this._lastMovedIndex);
/*  58 */     sb.append(this._amountToMove);
/*  59 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean adjustFormula(Ptg[] ptgs, int currentExternSheetIx)
/*     */   {
/*  68 */     boolean refsWereChanged = false;
/*  69 */     for (int i = 0; i < ptgs.length; i++) {
/*  70 */       Ptg newPtg = adjustPtg(ptgs[i], currentExternSheetIx);
/*  71 */       if (newPtg != null) {
/*  72 */         refsWereChanged = true;
/*  73 */         ptgs[i] = newPtg;
/*     */       }
/*     */     }
/*  76 */     return refsWereChanged;
/*     */   }
/*     */   
/*     */   private Ptg adjustPtg(Ptg ptg, int currentExternSheetIx) {
/*  80 */     return adjustPtgDueToRowMove(ptg, currentExternSheetIx);
/*     */   }
/*     */   
/*     */ 
/*     */   private Ptg adjustPtgDueToRowMove(Ptg ptg, int currentExternSheetIx)
/*     */   {
/*  86 */     if ((ptg instanceof RefPtg)) {
/*  87 */       if (currentExternSheetIx != this._externSheetIndex)
/*     */       {
/*  89 */         return null;
/*     */       }
/*  91 */       RefPtg rptg = (RefPtg)ptg;
/*  92 */       return rowMoveRefPtg(rptg);
/*     */     }
/*  94 */     if ((ptg instanceof Ref3DPtg)) {
/*  95 */       Ref3DPtg rptg = (Ref3DPtg)ptg;
/*  96 */       if (this._externSheetIndex != rptg.getExternSheetIndex())
/*     */       {
/*     */ 
/*  99 */         return null;
/*     */       }
/* 101 */       return rowMoveRefPtg(rptg);
/*     */     }
/* 103 */     if ((ptg instanceof Area2DPtgBase)) {
/* 104 */       if (currentExternSheetIx != this._externSheetIndex)
/*     */       {
/* 106 */         return ptg;
/*     */       }
/* 108 */       return rowMoveAreaPtg((Area2DPtgBase)ptg);
/*     */     }
/* 110 */     if ((ptg instanceof Area3DPtg)) {
/* 111 */       Area3DPtg aptg = (Area3DPtg)ptg;
/* 112 */       if (this._externSheetIndex != aptg.getExternSheetIndex())
/*     */       {
/*     */ 
/* 115 */         return null;
/*     */       }
/* 117 */       return rowMoveAreaPtg(aptg);
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   private Ptg rowMoveRefPtg(RefPtgBase rptg) {
/* 123 */     int refRow = rptg.getRow();
/* 124 */     if ((this._firstMovedIndex <= refRow) && (refRow <= this._lastMovedIndex))
/*     */     {
/*     */ 
/* 127 */       rptg.setRow(refRow + this._amountToMove);
/* 128 */       return rptg;
/*     */     }
/*     */     
/*     */ 
/* 132 */     int destFirstRowIndex = this._firstMovedIndex + this._amountToMove;
/* 133 */     int destLastRowIndex = this._lastMovedIndex + this._amountToMove;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 138 */     if ((destLastRowIndex < refRow) || (refRow < destFirstRowIndex))
/*     */     {
/* 140 */       return null;
/*     */     }
/*     */     
/* 143 */     if ((destFirstRowIndex <= refRow) && (refRow <= destLastRowIndex))
/*     */     {
/* 145 */       return createDeletedRef(rptg);
/*     */     }
/* 147 */     throw new IllegalStateException("Situation not covered: (" + this._firstMovedIndex + ", " + this._lastMovedIndex + ", " + this._amountToMove + ", " + refRow + ", " + refRow + ")");
/*     */   }
/*     */   
/*     */   private Ptg rowMoveAreaPtg(AreaPtgBase aptg)
/*     */   {
/* 152 */     int aFirstRow = aptg.getFirstRow();
/* 153 */     int aLastRow = aptg.getLastRow();
/* 154 */     if ((this._firstMovedIndex <= aFirstRow) && (aLastRow <= this._lastMovedIndex))
/*     */     {
/*     */ 
/* 157 */       aptg.setFirstRow(aFirstRow + this._amountToMove);
/* 158 */       aptg.setLastRow(aLastRow + this._amountToMove);
/* 159 */       return aptg;
/*     */     }
/*     */     
/*     */ 
/* 163 */     int destFirstRowIndex = this._firstMovedIndex + this._amountToMove;
/* 164 */     int destLastRowIndex = this._lastMovedIndex + this._amountToMove;
/*     */     
/* 166 */     if ((aFirstRow < this._firstMovedIndex) && (this._lastMovedIndex < aLastRow))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 171 */       if ((destFirstRowIndex < aFirstRow) && (aFirstRow <= destLastRowIndex))
/*     */       {
/* 173 */         aptg.setFirstRow(destLastRowIndex + 1);
/* 174 */         return aptg; }
/* 175 */       if ((destFirstRowIndex <= aLastRow) && (aLastRow < destLastRowIndex))
/*     */       {
/* 177 */         aptg.setLastRow(destFirstRowIndex - 1);
/* 178 */         return aptg;
/*     */       }
/*     */       
/*     */ 
/* 182 */       return null;
/*     */     }
/* 184 */     if ((this._firstMovedIndex <= aFirstRow) && (aFirstRow <= this._lastMovedIndex))
/*     */     {
/*     */ 
/* 187 */       if (this._amountToMove < 0)
/*     */       {
/* 189 */         aptg.setFirstRow(aFirstRow + this._amountToMove);
/* 190 */         return aptg;
/*     */       }
/* 192 */       if (destFirstRowIndex > aLastRow)
/*     */       {
/* 194 */         return null;
/*     */       }
/* 196 */       int newFirstRowIx = aFirstRow + this._amountToMove;
/* 197 */       if (destLastRowIndex < aLastRow)
/*     */       {
/*     */ 
/* 200 */         aptg.setFirstRow(newFirstRowIx);
/* 201 */         return aptg;
/*     */       }
/*     */       
/* 204 */       int areaRemainingTopRowIx = this._lastMovedIndex + 1;
/* 205 */       if (destFirstRowIndex > areaRemainingTopRowIx)
/*     */       {
/* 207 */         newFirstRowIx = areaRemainingTopRowIx;
/*     */       }
/* 209 */       aptg.setFirstRow(newFirstRowIx);
/* 210 */       aptg.setLastRow(Math.max(aLastRow, destLastRowIndex));
/* 211 */       return aptg;
/*     */     }
/* 213 */     if ((this._firstMovedIndex <= aLastRow) && (aLastRow <= this._lastMovedIndex))
/*     */     {
/*     */ 
/* 216 */       if (this._amountToMove > 0)
/*     */       {
/* 218 */         aptg.setLastRow(aLastRow + this._amountToMove);
/* 219 */         return aptg;
/*     */       }
/* 221 */       if (destLastRowIndex < aFirstRow)
/*     */       {
/* 223 */         return null;
/*     */       }
/* 225 */       int newLastRowIx = aLastRow + this._amountToMove;
/* 226 */       if (destFirstRowIndex > aFirstRow)
/*     */       {
/*     */ 
/* 229 */         aptg.setLastRow(newLastRowIx);
/* 230 */         return aptg;
/*     */       }
/*     */       
/* 233 */       int areaRemainingBottomRowIx = this._firstMovedIndex - 1;
/* 234 */       if (destLastRowIndex < areaRemainingBottomRowIx)
/*     */       {
/* 236 */         newLastRowIx = areaRemainingBottomRowIx;
/*     */       }
/* 238 */       aptg.setFirstRow(Math.min(aFirstRow, destFirstRowIndex));
/* 239 */       aptg.setLastRow(newLastRowIx);
/* 240 */       return aptg;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 245 */     if ((destLastRowIndex < aFirstRow) || (aLastRow < destFirstRowIndex))
/*     */     {
/* 247 */       return null;
/*     */     }
/*     */     
/* 250 */     if ((destFirstRowIndex <= aFirstRow) && (aLastRow <= destLastRowIndex))
/*     */     {
/* 252 */       return createDeletedRef(aptg);
/*     */     }
/*     */     
/* 255 */     if ((aFirstRow <= destFirstRowIndex) && (destLastRowIndex <= aLastRow))
/*     */     {
/* 257 */       return null;
/*     */     }
/*     */     
/* 260 */     if ((destFirstRowIndex < aFirstRow) && (aFirstRow <= destLastRowIndex))
/*     */     {
/*     */ 
/* 263 */       aptg.setFirstRow(destLastRowIndex + 1);
/* 264 */       return aptg;
/*     */     }
/* 266 */     if ((destFirstRowIndex < aLastRow) && (aLastRow <= destLastRowIndex))
/*     */     {
/*     */ 
/* 269 */       aptg.setLastRow(destFirstRowIndex - 1);
/* 270 */       return aptg;
/*     */     }
/* 272 */     throw new IllegalStateException("Situation not covered: (" + this._firstMovedIndex + ", " + this._lastMovedIndex + ", " + this._amountToMove + ", " + aFirstRow + ", " + aLastRow + ")");
/*     */   }
/*     */   
/*     */   private static Ptg createDeletedRef(Ptg ptg)
/*     */   {
/* 277 */     if ((ptg instanceof RefPtg)) {
/* 278 */       return new RefErrorPtg();
/*     */     }
/* 280 */     if ((ptg instanceof Ref3DPtg)) {
/* 281 */       Ref3DPtg rptg = (Ref3DPtg)ptg;
/* 282 */       return new DeletedRef3DPtg(rptg.getExternSheetIndex());
/*     */     }
/* 284 */     if ((ptg instanceof AreaPtg)) {
/* 285 */       return new AreaErrPtg();
/*     */     }
/* 287 */     if ((ptg instanceof Area3DPtg)) {
/* 288 */       Area3DPtg area3DPtg = (Area3DPtg)ptg;
/* 289 */       return new DeletedArea3DPtg(area3DPtg.getExternSheetIndex());
/*     */     }
/*     */     
/* 292 */     throw new IllegalArgumentException("Unexpected ref ptg class (" + ptg.getClass().getName() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\FormulaShifter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */