/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.function.FunctionMetadata;
/*    */ import org.apache.poi.hssf.record.formula.function.FunctionMetadataRegistry;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FuncPtg
/*    */   extends AbstractFunctionPtg
/*    */ {
/*    */   public static final byte sid = 33;
/*    */   public static final int SIZE = 3;
/*    */   
/*    */   public static FuncPtg create(LittleEndianInput in)
/*    */   {
/* 36 */     return create(in.readUShort());
/*    */   }
/*    */   
/*    */   private FuncPtg(int funcIndex, FunctionMetadata fm) {
/* 40 */     super(funcIndex, fm.getReturnClassCode(), fm.getParameterClassCodes(), fm.getMinParams());
/*    */   }
/*    */   
/*    */   public static FuncPtg create(int functionIndex) {
/* 44 */     FunctionMetadata fm = FunctionMetadataRegistry.getFunctionByIndex(functionIndex);
/* 45 */     if (fm == null) {
/* 46 */       throw new RuntimeException("Invalid built-in function index (" + functionIndex + ")");
/*    */     }
/* 48 */     return new FuncPtg(functionIndex, fm);
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out)
/*    */   {
/* 53 */     out.writeByte(33 + getPtgClass());
/* 54 */     out.writeShort(getFunctionIndex());
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 58 */     return 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\FuncPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */