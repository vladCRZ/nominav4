/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.function.FunctionMetadata;
/*    */ import org.apache.poi.hssf.record.formula.function.FunctionMetadataRegistry;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FuncVarPtg
/*    */   extends AbstractFunctionPtg
/*    */ {
/*    */   public static final byte sid = 34;
/*    */   private static final int SIZE = 4;
/* 35 */   public static final OperationPtg SUM = create("SUM", 1);
/*    */   
/*    */   private FuncVarPtg(int functionIndex, int returnClass, byte[] paramClasses, int numArgs) {
/* 38 */     super(functionIndex, returnClass, paramClasses, numArgs);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static FuncVarPtg create(LittleEndianInput in)
/*    */   {
/* 45 */     return create(in.readByte(), in.readShort());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static FuncVarPtg create(String pName, int numArgs)
/*    */   {
/* 52 */     return create(numArgs, lookupIndex(pName));
/*    */   }
/*    */   
/*    */   private static FuncVarPtg create(int numArgs, int functionIndex) {
/* 56 */     FunctionMetadata fm = FunctionMetadataRegistry.getFunctionByIndex(functionIndex);
/* 57 */     if (fm == null)
/*    */     {
/* 59 */       return new FuncVarPtg(functionIndex, 32, new byte[] { 32 }, numArgs);
/*    */     }
/* 61 */     return new FuncVarPtg(functionIndex, fm.getReturnClassCode(), fm.getParameterClassCodes(), numArgs);
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 65 */     out.writeByte(34 + getPtgClass());
/* 66 */     out.writeByte(getNumberOfOperands());
/* 67 */     out.writeShort(getFunctionIndex());
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 71 */     return 4;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\FuncVarPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */