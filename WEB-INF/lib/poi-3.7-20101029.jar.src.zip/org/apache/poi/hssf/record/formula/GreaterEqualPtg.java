/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GreaterEqualPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final int SIZE = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final byte sid = 12;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 30 */   public static final ValueOperatorPtg instance = new GreaterEqualPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 37 */     return 12;
/*    */   }
/*    */   
/*    */   public int getNumberOfOperands() {
/* 41 */     return 2;
/*    */   }
/*    */   
/*    */   public String toFormulaString(String[] operands) {
/* 45 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 47 */     buffer.append(operands[0]);
/*    */     
/* 49 */     buffer.append(">=");
/* 50 */     buffer.append(operands[1]);
/*    */     
/* 52 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\GreaterEqualPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */