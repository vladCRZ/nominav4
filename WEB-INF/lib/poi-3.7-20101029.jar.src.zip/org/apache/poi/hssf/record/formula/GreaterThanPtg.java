/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GreaterThanPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final byte sid = 13;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String GREATERTHAN = ">";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 29 */   public static final ValueOperatorPtg instance = new GreaterThanPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 36 */     return 13;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getNumberOfOperands()
/*    */   {
/* 44 */     return 2;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toFormulaString(String[] operands)
/*    */   {
/* 54 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 56 */     buffer.append(operands[0]);
/* 57 */     buffer.append(">");
/* 58 */     buffer.append(operands[1]);
/* 59 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\GreaterThanPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */