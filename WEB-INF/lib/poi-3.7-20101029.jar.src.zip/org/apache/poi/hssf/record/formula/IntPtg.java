/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntPtg
/*    */   extends ScalarConstantPtg
/*    */ {
/*    */   private static final int MIN_VALUE = 0;
/*    */   private static final int MAX_VALUE = 65535;
/*    */   public static final int SIZE = 3;
/*    */   public static final byte sid = 30;
/*    */   private final int field_1_value;
/*    */   
/*    */   public static boolean isInRange(int i)
/*    */   {
/* 42 */     return (i >= 0) && (i <= 65535);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public IntPtg(LittleEndianInput in)
/*    */   {
/* 50 */     this(in.readUShort());
/*    */   }
/*    */   
/*    */   public IntPtg(int value) {
/* 54 */     if (!isInRange(value)) {
/* 55 */       throw new IllegalArgumentException("value is out of range: " + value);
/*    */     }
/* 57 */     this.field_1_value = value;
/*    */   }
/*    */   
/*    */   public int getValue() {
/* 61 */     return this.field_1_value;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 65 */     out.writeByte(30 + getPtgClass());
/* 66 */     out.writeShort(getValue());
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 70 */     return 3;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 74 */     return String.valueOf(getValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\IntPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */