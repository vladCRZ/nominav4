/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LessThanPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final byte sid = 9;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String LESSTHAN = "<";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 33 */   public static final ValueOperatorPtg instance = new LessThanPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 40 */     return 9;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getNumberOfOperands()
/*    */   {
/* 48 */     return 2;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toFormulaString(String[] operands)
/*    */   {
/* 58 */     StringBuffer buffer = new StringBuffer();
/* 59 */     buffer.append(operands[0]);
/* 60 */     buffer.append("<");
/* 61 */     buffer.append(operands[1]);
/* 62 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\LessThanPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */