/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MemAreaPtg
/*    */   extends OperandPtg
/*    */ {
/*    */   public static final short sid = 38;
/*    */   private static final int SIZE = 7;
/*    */   private final int field_1_reserved;
/*    */   private final int field_2_subex_len;
/*    */   
/*    */   public MemAreaPtg(int subexLen)
/*    */   {
/* 35 */     this.field_1_reserved = 0;
/* 36 */     this.field_2_subex_len = subexLen;
/*    */   }
/*    */   
/*    */   public MemAreaPtg(LittleEndianInput in) {
/* 40 */     this.field_1_reserved = in.readInt();
/* 41 */     this.field_2_subex_len = in.readShort();
/*    */   }
/*    */   
/*    */   public int getLenRefSubexpression() {
/* 45 */     return this.field_2_subex_len;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 49 */     out.writeByte(38 + getPtgClass());
/* 50 */     out.writeInt(this.field_1_reserved);
/* 51 */     out.writeShort(this.field_2_subex_len);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 55 */     return 7;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 59 */     return "";
/*    */   }
/*    */   
/*    */   public byte getDefaultOperandClass() {
/* 63 */     return 32;
/*    */   }
/*    */   
/*    */   public final String toString()
/*    */   {
/* 68 */     StringBuffer sb = new StringBuffer(64);
/* 69 */     sb.append(getClass().getName()).append(" [len=");
/* 70 */     sb.append(this.field_2_subex_len);
/* 71 */     sb.append("]");
/* 72 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\MemAreaPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */