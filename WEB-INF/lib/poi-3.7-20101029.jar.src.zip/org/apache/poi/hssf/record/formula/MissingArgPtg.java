/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MissingArgPtg
/*    */   extends ScalarConstantPtg
/*    */ {
/*    */   private static final int SIZE = 1;
/*    */   public static final byte sid = 22;
/* 34 */   public static final Ptg instance = new MissingArgPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void write(LittleEndianOutput out)
/*    */   {
/* 41 */     out.writeByte(22 + getPtgClass());
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 45 */     return 1;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 49 */     return " ";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\MissingArgPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */