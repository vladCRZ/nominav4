/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MultiplyPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final byte sid = 5;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 28 */   public static final ValueOperatorPtg instance = new MultiplyPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 35 */     return 5;
/*    */   }
/*    */   
/*    */   public int getNumberOfOperands() {
/* 39 */     return 2;
/*    */   }
/*    */   
/*    */   public String toFormulaString(String[] operands) {
/* 43 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 45 */     buffer.append(operands[0]);
/* 46 */     buffer.append("*");
/* 47 */     buffer.append(operands[1]);
/* 48 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\MultiplyPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */