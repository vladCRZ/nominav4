/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.formula.FormulaRenderingWorkbook;
/*    */ import org.apache.poi.ss.formula.WorkbookDependentFormula;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NamePtg
/*    */   extends OperandPtg
/*    */   implements WorkbookDependentFormula
/*    */ {
/*    */   public static final short sid = 35;
/*    */   private static final int SIZE = 5;
/*    */   private int field_1_label_index;
/*    */   private short field_2_zero;
/*    */   
/*    */   public NamePtg(int nameIndex)
/*    */   {
/* 41 */     this.field_1_label_index = (1 + nameIndex);
/*    */   }
/*    */   
/*    */ 
/*    */   public NamePtg(LittleEndianInput in)
/*    */   {
/* 47 */     this.field_1_label_index = in.readShort();
/* 48 */     this.field_2_zero = in.readShort();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getIndex()
/*    */   {
/* 55 */     return this.field_1_label_index - 1;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 59 */     out.writeByte(35 + getPtgClass());
/* 60 */     out.writeShort(this.field_1_label_index);
/* 61 */     out.writeShort(this.field_2_zero);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 65 */     return 5;
/*    */   }
/*    */   
/*    */   public String toFormulaString(FormulaRenderingWorkbook book) {
/* 69 */     return book.getNameText(this);
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 73 */     throw new RuntimeException("3D references need a workbook to determine formula text");
/*    */   }
/*    */   
/*    */   public byte getDefaultOperandClass() {
/* 77 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\NamePtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */