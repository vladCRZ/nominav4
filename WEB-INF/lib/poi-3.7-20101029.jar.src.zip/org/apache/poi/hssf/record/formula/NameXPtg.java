/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.formula.FormulaRenderingWorkbook;
/*    */ import org.apache.poi.ss.formula.WorkbookDependentFormula;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NameXPtg
/*    */   extends OperandPtg
/*    */   implements WorkbookDependentFormula
/*    */ {
/*    */   public static final short sid = 57;
/*    */   private static final int SIZE = 7;
/*    */   private final int _sheetRefIndex;
/*    */   private final int _nameNumber;
/*    */   private final int _reserved;
/*    */   
/*    */   private NameXPtg(int sheetRefIndex, int nameNumber, int reserved)
/*    */   {
/* 41 */     this._sheetRefIndex = sheetRefIndex;
/* 42 */     this._nameNumber = nameNumber;
/* 43 */     this._reserved = reserved;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NameXPtg(int sheetRefIndex, int nameIndex)
/*    */   {
/* 51 */     this(sheetRefIndex, nameIndex + 1, 0);
/*    */   }
/*    */   
/*    */   public NameXPtg(LittleEndianInput in) {
/* 55 */     this(in.readUShort(), in.readUShort(), in.readUShort());
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 59 */     out.writeByte(57 + getPtgClass());
/* 60 */     out.writeShort(this._sheetRefIndex);
/* 61 */     out.writeShort(this._nameNumber);
/* 62 */     out.writeShort(this._reserved);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 66 */     return 7;
/*    */   }
/*    */   
/*    */   public String toFormulaString(FormulaRenderingWorkbook book)
/*    */   {
/* 71 */     return book.resolveNameXText(this);
/*    */   }
/*    */   
/* 74 */   public String toFormulaString() { throw new RuntimeException("3D references need a workbook to determine formula text"); }
/*    */   
/*    */   public String toString()
/*    */   {
/* 78 */     String retValue = "NameXPtg:[sheetRefIndex:" + this._sheetRefIndex + " , nameNumber:" + this._nameNumber + "]";
/*    */     
/* 80 */     return retValue;
/*    */   }
/*    */   
/*    */   public byte getDefaultOperandClass() {
/* 84 */     return 32;
/*    */   }
/*    */   
/*    */   public int getSheetRefIndex() {
/* 88 */     return this._sheetRefIndex;
/*    */   }
/*    */   
/* 91 */   public int getNameIndex() { return this._nameNumber - 1; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\NameXPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */