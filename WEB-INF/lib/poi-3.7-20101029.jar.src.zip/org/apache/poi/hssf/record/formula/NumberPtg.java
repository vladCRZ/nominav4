/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.util.NumberToTextConverter;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NumberPtg
/*    */   extends ScalarConstantPtg
/*    */ {
/*    */   public static final int SIZE = 9;
/*    */   public static final byte sid = 31;
/*    */   private final double field_1_value;
/*    */   
/*    */   public NumberPtg(LittleEndianInput in)
/*    */   {
/* 37 */     this(in.readDouble());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NumberPtg(String value)
/*    */   {
/* 48 */     this(Double.parseDouble(value));
/*    */   }
/*    */   
/*    */   public NumberPtg(double value) {
/* 52 */     this.field_1_value = value;
/*    */   }
/*    */   
/*    */   public double getValue() {
/* 56 */     return this.field_1_value;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 60 */     out.writeByte(31 + getPtgClass());
/* 61 */     out.writeDouble(getValue());
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 65 */     return 9;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 69 */     return NumberToTextConverter.toText(this.field_1_value);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\NumberPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */