/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OperandPtg
/*    */   extends Ptg
/*    */   implements Cloneable
/*    */ {
/* 29 */   public final boolean isBaseToken() { return false; }
/*    */   
/*    */   public final OperandPtg copy() {
/*    */     try {
/* 33 */       return (OperandPtg)clone();
/*    */     } catch (CloneNotSupportedException e) {
/* 35 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\OperandPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */