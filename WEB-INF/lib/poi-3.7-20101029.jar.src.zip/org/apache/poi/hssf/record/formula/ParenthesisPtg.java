/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParenthesisPtg
/*    */   extends ControlPtg
/*    */ {
/*    */   private static final int SIZE = 1;
/*    */   public static final byte sid = 21;
/* 37 */   public static final ControlPtg instance = new ParenthesisPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void write(LittleEndianOutput out)
/*    */   {
/* 44 */     out.writeByte(21 + getPtgClass());
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 48 */     return 1;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 52 */     return "()";
/*    */   }
/*    */   
/*    */   public String toFormulaString(String[] operands) {
/* 56 */     return "(" + operands[0] + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ParenthesisPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */