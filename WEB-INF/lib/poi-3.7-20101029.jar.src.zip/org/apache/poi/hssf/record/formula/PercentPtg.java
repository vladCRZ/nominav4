/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PercentPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final int SIZE = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final byte sid = 20;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String PERCENT = "%";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 31 */   public static final ValueOperatorPtg instance = new PercentPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 38 */     return 20;
/*    */   }
/*    */   
/*    */   public int getNumberOfOperands() {
/* 42 */     return 1;
/*    */   }
/*    */   
/*    */   public String toFormulaString(String[] operands) {
/* 46 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 48 */     buffer.append(operands[0]);
/* 49 */     buffer.append("%");
/* 50 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\PercentPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */