/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.util.LittleEndianByteArrayOutputStream;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Ptg
/*     */ {
/*  44 */   public static final Ptg[] EMPTY_PTG_ARRAY = new Ptg[0];
/*     */   
/*     */   public static final byte CLASS_REF = 0;
/*     */   public static final byte CLASS_VALUE = 32;
/*     */   public static final byte CLASS_ARRAY = 64;
/*     */   
/*     */   public static Ptg[] readTokens(int size, LittleEndianInput in)
/*     */   {
/*  52 */     List<Ptg> temp = new ArrayList(4 + size / 2);
/*  53 */     int pos = 0;
/*  54 */     boolean hasArrayPtgs = false;
/*  55 */     while (pos < size) {
/*  56 */       Ptg ptg = createPtg(in);
/*  57 */       if ((ptg instanceof ArrayPtg.Initial)) {
/*  58 */         hasArrayPtgs = true;
/*     */       }
/*  60 */       pos += ptg.getSize();
/*  61 */       temp.add(ptg);
/*     */     }
/*  63 */     if (pos != size) {
/*  64 */       throw new RuntimeException("Ptg array size mismatch");
/*     */     }
/*  66 */     if (hasArrayPtgs) {
/*  67 */       Ptg[] result = toPtgArray(temp);
/*  68 */       for (int i = 0; i < result.length; i++) {
/*  69 */         if ((result[i] instanceof ArrayPtg.Initial)) {
/*  70 */           result[i] = ((ArrayPtg.Initial)result[i]).finishReading(in);
/*     */         }
/*     */       }
/*  73 */       return result;
/*     */     }
/*  75 */     return toPtgArray(temp);
/*     */   }
/*     */   
/*     */   public static Ptg createPtg(LittleEndianInput in) {
/*  79 */     byte id = in.readByte();
/*     */     
/*  81 */     if (id < 32) {
/*  82 */       return createBasePtg(id, in);
/*     */     }
/*     */     
/*  85 */     Ptg retval = createClassifiedPtg(id, in);
/*     */     
/*  87 */     if (id >= 96) {
/*  88 */       retval.setClass((byte)64);
/*  89 */     } else if (id >= 64) {
/*  90 */       retval.setClass((byte)32);
/*     */     } else {
/*  92 */       retval.setClass((byte)0);
/*     */     }
/*  94 */     return retval;
/*     */   }
/*     */   
/*     */   private static Ptg createClassifiedPtg(byte id, LittleEndianInput in)
/*     */   {
/*  99 */     int baseId = id & 0x1F | 0x20;
/*     */     
/* 101 */     switch (baseId) {
/* 102 */     case 32:  return new ArrayPtg.Initial(in);
/* 103 */     case 33:  return FuncPtg.create(in);
/* 104 */     case 34:  return FuncVarPtg.create(in);
/* 105 */     case 35:  return new NamePtg(in);
/* 106 */     case 36:  return new RefPtg(in);
/* 107 */     case 37:  return new AreaPtg(in);
/* 108 */     case 38:  return new MemAreaPtg(in);
/* 109 */     case 39:  return new MemErrPtg(in);
/* 110 */     case 41:  return new MemFuncPtg(in);
/* 111 */     case 42:  return new RefErrorPtg(in);
/* 112 */     case 43:  return new AreaErrPtg(in);
/* 113 */     case 44:  return new RefNPtg(in);
/* 114 */     case 45:  return new AreaNPtg(in);
/*     */     case 57: 
/* 116 */       return new NameXPtg(in);
/* 117 */     case 58:  return new Ref3DPtg(in);
/* 118 */     case 59:  return new Area3DPtg(in);
/* 119 */     case 60:  return new DeletedRef3DPtg(in);
/* 120 */     case 61:  return new DeletedArea3DPtg(in);
/*     */     }
/* 122 */     throw new UnsupportedOperationException(" Unknown Ptg in Formula: 0x" + Integer.toHexString(id) + " (" + id + ")");
/*     */   }
/*     */   
/*     */   private static Ptg createBasePtg(byte id, LittleEndianInput in)
/*     */   {
/* 127 */     switch (id) {
/* 128 */     case 0:  return new UnknownPtg(id);
/* 129 */     case 1:  return new ExpPtg(in);
/* 130 */     case 2:  return new TblPtg(in);
/* 131 */     case 3:  return AddPtg.instance;
/* 132 */     case 4:  return SubtractPtg.instance;
/* 133 */     case 5:  return MultiplyPtg.instance;
/* 134 */     case 6:  return DividePtg.instance;
/* 135 */     case 7:  return PowerPtg.instance;
/* 136 */     case 8:  return ConcatPtg.instance;
/* 137 */     case 9:  return LessThanPtg.instance;
/* 138 */     case 10:  return LessEqualPtg.instance;
/* 139 */     case 11:  return EqualPtg.instance;
/* 140 */     case 12:  return GreaterEqualPtg.instance;
/* 141 */     case 13:  return GreaterThanPtg.instance;
/* 142 */     case 14:  return NotEqualPtg.instance;
/* 143 */     case 15:  return IntersectionPtg.instance;
/* 144 */     case 16:  return UnionPtg.instance;
/* 145 */     case 17:  return RangePtg.instance;
/* 146 */     case 18:  return UnaryPlusPtg.instance;
/* 147 */     case 19:  return UnaryMinusPtg.instance;
/* 148 */     case 20:  return PercentPtg.instance;
/* 149 */     case 21:  return ParenthesisPtg.instance;
/* 150 */     case 22:  return MissingArgPtg.instance;
/*     */     case 23: 
/* 152 */       return new StringPtg(in);
/* 153 */     case 25:  return new AttrPtg(in);
/* 154 */     case 28:  return ErrPtg.read(in);
/* 155 */     case 29:  return BoolPtg.read(in);
/* 156 */     case 30:  return new IntPtg(in);
/* 157 */     case 31:  return new NumberPtg(in);
/*     */     }
/* 159 */     throw new RuntimeException("Unexpected base token id (" + id + ")");
/*     */   }
/*     */   
/*     */   private static Ptg[] toPtgArray(List<Ptg> l) {
/* 163 */     if (l.isEmpty()) {
/* 164 */       return EMPTY_PTG_ARRAY;
/*     */     }
/* 166 */     Ptg[] result = new Ptg[l.size()];
/* 167 */     l.toArray(result);
/* 168 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getEncodedSize(Ptg[] ptgs)
/*     */   {
/* 176 */     int result = 0;
/* 177 */     for (int i = 0; i < ptgs.length; i++) {
/* 178 */       result += ptgs[i].getSize();
/*     */     }
/* 180 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int getEncodedSizeWithoutArrayData(Ptg[] ptgs)
/*     */   {
/* 187 */     int result = 0;
/* 188 */     for (int i = 0; i < ptgs.length; i++) {
/* 189 */       Ptg ptg = ptgs[i];
/* 190 */       if ((ptg instanceof ArrayPtg)) {
/* 191 */         result += 8;
/*     */       } else {
/* 193 */         result += ptg.getSize();
/*     */       }
/*     */     }
/* 196 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int serializePtgs(Ptg[] ptgs, byte[] array, int offset)
/*     */   {
/* 206 */     int nTokens = ptgs.length;
/*     */     
/* 208 */     LittleEndianByteArrayOutputStream out = new LittleEndianByteArrayOutputStream(array, offset);
/*     */     
/* 210 */     List<Ptg> arrayPtgs = null;
/*     */     
/* 212 */     for (int k = 0; k < nTokens; k++) {
/* 213 */       Ptg ptg = ptgs[k];
/*     */       
/* 215 */       ptg.write(out);
/* 216 */       if ((ptg instanceof ArrayPtg)) {
/* 217 */         if (arrayPtgs == null) {
/* 218 */           arrayPtgs = new ArrayList(5);
/*     */         }
/* 220 */         arrayPtgs.add(ptg);
/*     */       }
/*     */     }
/* 223 */     if (arrayPtgs != null) {
/* 224 */       for (int i = 0; i < arrayPtgs.size(); i++) {
/* 225 */         ArrayPtg p = (ArrayPtg)arrayPtgs.get(i);
/* 226 */         p.writeTokenValueBytes(out);
/*     */       }
/*     */     }
/* 229 */     return out.getWriteIndex() - offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getSize();
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void write(LittleEndianOutput paramLittleEndianOutput);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String toFormulaString();
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 249 */     return getClass().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 256 */   private byte ptgClass = 0;
/*     */   
/*     */   public final void setClass(byte thePtgClass) {
/* 259 */     if (isBaseToken()) {
/* 260 */       throw new RuntimeException("setClass should not be called on a base token");
/*     */     }
/* 262 */     this.ptgClass = thePtgClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final byte getPtgClass()
/*     */   {
/* 269 */     return this.ptgClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final char getRVAType()
/*     */   {
/* 277 */     if (isBaseToken()) {
/* 278 */       return '.';
/*     */     }
/* 280 */     switch (this.ptgClass) {
/* 281 */     case 0:  return 'R';
/* 282 */     case 32:  return 'V';
/* 283 */     case 64:  return 'A';
/*     */     }
/* 285 */     throw new RuntimeException("Unknown operand class (" + this.ptgClass + ")");
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract byte getDefaultOperandClass();
/*     */   
/*     */ 
/*     */   public abstract boolean isBaseToken();
/*     */   
/*     */   public static boolean doesFormulaReferToDeletedCell(Ptg[] ptgs)
/*     */   {
/* 296 */     for (int i = 0; i < ptgs.length; i++) {
/* 297 */       if (isDeletedCellRef(ptgs[i])) {
/* 298 */         return true;
/*     */       }
/*     */     }
/* 301 */     return false;
/*     */   }
/*     */   
/* 304 */   private static boolean isDeletedCellRef(Ptg ptg) { if (ptg == ErrPtg.REF_INVALID) {
/* 305 */       return true;
/*     */     }
/* 307 */     if ((ptg instanceof DeletedArea3DPtg)) {
/* 308 */       return true;
/*     */     }
/* 310 */     if ((ptg instanceof DeletedRef3DPtg)) {
/* 311 */       return true;
/*     */     }
/* 313 */     if ((ptg instanceof AreaErrPtg)) {
/* 314 */       return true;
/*     */     }
/* 316 */     if ((ptg instanceof RefErrorPtg)) {
/* 317 */       return true;
/*     */     }
/* 319 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\Ptg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */