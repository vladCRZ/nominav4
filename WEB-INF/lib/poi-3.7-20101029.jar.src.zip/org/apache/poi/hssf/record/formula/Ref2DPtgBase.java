/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.util.CellReference;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Ref2DPtgBase
/*    */   extends RefPtgBase
/*    */ {
/*    */   private static final int SIZE = 5;
/*    */   
/*    */   protected Ref2DPtgBase(int row, int column, boolean isRowRelative, boolean isColumnRelative)
/*    */   {
/* 32 */     setRow(row);
/* 33 */     setColumn(column);
/* 34 */     setRowRelative(isRowRelative);
/* 35 */     setColRelative(isColumnRelative);
/*    */   }
/*    */   
/*    */   protected Ref2DPtgBase(LittleEndianInput in) {
/* 39 */     readCoordinates(in);
/*    */   }
/*    */   
/*    */   protected Ref2DPtgBase(CellReference cr) {
/* 43 */     super(cr);
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 47 */     out.writeByte(getSid() + getPtgClass());
/* 48 */     writeCoordinates(out);
/*    */   }
/*    */   
/*    */   public final String toFormulaString() {
/* 52 */     return formatReferenceAsString();
/*    */   }
/*    */   
/*    */   protected abstract byte getSid();
/*    */   
/*    */   public final int getSize() {
/* 58 */     return 5;
/*    */   }
/*    */   
/*    */   public final String toString() {
/* 62 */     StringBuffer sb = new StringBuffer();
/* 63 */     sb.append(getClass().getName());
/* 64 */     sb.append(" [");
/* 65 */     sb.append(formatReferenceAsString());
/* 66 */     sb.append("]");
/* 67 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\Ref2DPtgBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */