/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.formula.ExternSheetReferenceToken;
/*    */ import org.apache.poi.ss.formula.FormulaRenderingWorkbook;
/*    */ import org.apache.poi.ss.formula.WorkbookDependentFormula;
/*    */ import org.apache.poi.ss.util.CellReference;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Ref3DPtg
/*    */   extends RefPtgBase
/*    */   implements WorkbookDependentFormula, ExternSheetReferenceToken
/*    */ {
/*    */   public static final byte sid = 58;
/*    */   private static final int SIZE = 7;
/*    */   private int field_1_index_extern_sheet;
/*    */   
/*    */   public Ref3DPtg(LittleEndianInput in)
/*    */   {
/* 42 */     this.field_1_index_extern_sheet = in.readShort();
/* 43 */     readCoordinates(in);
/*    */   }
/*    */   
/*    */   public Ref3DPtg(String cellref, int externIdx) {
/* 47 */     this(new CellReference(cellref), externIdx);
/*    */   }
/*    */   
/*    */   public Ref3DPtg(CellReference c, int externIdx) {
/* 51 */     super(c);
/* 52 */     setExternSheetIndex(externIdx);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 56 */     StringBuffer sb = new StringBuffer();
/* 57 */     sb.append(getClass().getName());
/* 58 */     sb.append(" [");
/* 59 */     sb.append("sheetIx=").append(getExternSheetIndex());
/* 60 */     sb.append(" ! ");
/* 61 */     sb.append(formatReferenceAsString());
/* 62 */     sb.append("]");
/* 63 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 67 */     out.writeByte(58 + getPtgClass());
/* 68 */     out.writeShort(getExternSheetIndex());
/* 69 */     writeCoordinates(out);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 73 */     return 7;
/*    */   }
/*    */   
/*    */   public int getExternSheetIndex() {
/* 77 */     return this.field_1_index_extern_sheet;
/*    */   }
/*    */   
/*    */   public void setExternSheetIndex(int index) {
/* 81 */     this.field_1_index_extern_sheet = index;
/*    */   }
/*    */   
/* 84 */   public String format2DRefAsString() { return formatReferenceAsString(); }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toFormulaString(FormulaRenderingWorkbook book)
/*    */   {
/* 91 */     return ExternSheetNameResolver.prependSheetName(book, this.field_1_index_extern_sheet, formatReferenceAsString());
/*    */   }
/*    */   
/* 94 */   public String toFormulaString() { throw new RuntimeException("3D references need a workbook to determine formula text"); }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\Ref3DPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */