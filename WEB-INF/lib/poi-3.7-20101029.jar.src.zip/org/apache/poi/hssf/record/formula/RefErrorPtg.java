/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.usermodel.HSSFErrorConstants;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RefErrorPtg
/*    */   extends OperandPtg
/*    */ {
/*    */   private static final int SIZE = 5;
/*    */   public static final byte sid = 42;
/*    */   private int field_1_reserved;
/*    */   
/*    */   public RefErrorPtg()
/*    */   {
/* 35 */     this.field_1_reserved = 0;
/*    */   }
/*    */   
/* 38 */   public RefErrorPtg(LittleEndianInput in) { this.field_1_reserved = in.readInt(); }
/*    */   
/*    */   public String toString()
/*    */   {
/* 42 */     return getClass().getName();
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 46 */     out.writeByte(42 + getPtgClass());
/* 47 */     out.writeInt(this.field_1_reserved);
/*    */   }
/*    */   
/*    */   public int getSize()
/*    */   {
/* 52 */     return 5;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 56 */     return HSSFErrorConstants.getText(23);
/*    */   }
/*    */   
/*    */   public byte getDefaultOperandClass() {
/* 60 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\RefErrorPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */