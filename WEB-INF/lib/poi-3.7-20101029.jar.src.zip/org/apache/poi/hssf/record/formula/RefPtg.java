/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.ss.util.CellReference;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RefPtg
/*    */   extends Ref2DPtgBase
/*    */ {
/*    */   public static final byte sid = 36;
/*    */   
/*    */   public RefPtg(String cellref)
/*    */   {
/* 36 */     super(new CellReference(cellref));
/*    */   }
/*    */   
/*    */   public RefPtg(int row, int column, boolean isRowRelative, boolean isColumnRelative) {
/* 40 */     super(row, column, isRowRelative, isColumnRelative);
/*    */   }
/*    */   
/*    */   public RefPtg(LittleEndianInput in) {
/* 44 */     super(in);
/*    */   }
/*    */   
/*    */   public RefPtg(CellReference cr) {
/* 48 */     super(cr);
/*    */   }
/*    */   
/*    */   protected byte getSid() {
/* 52 */     return 36;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\RefPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */