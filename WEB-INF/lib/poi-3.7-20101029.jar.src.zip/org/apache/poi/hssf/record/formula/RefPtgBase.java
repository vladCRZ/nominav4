/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import org.apache.poi.ss.util.CellReference;
/*     */ import org.apache.poi.util.BitField;
/*     */ import org.apache.poi.util.BitFieldFactory;
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RefPtgBase
/*     */   extends OperandPtg
/*     */ {
/*     */   private int field_1_row;
/*     */   private int field_2_col;
/*  41 */   private static final BitField rowRelative = BitFieldFactory.getInstance(32768);
/*  42 */   private static final BitField colRelative = BitFieldFactory.getInstance(16384);
/*  43 */   private static final BitField column = BitFieldFactory.getInstance(255);
/*     */   
/*     */ 
/*     */   protected RefPtgBase() {}
/*     */   
/*     */   protected RefPtgBase(CellReference c)
/*     */   {
/*  50 */     setRow(c.getRow());
/*  51 */     setColumn(c.getCol());
/*  52 */     setColRelative(!c.isColAbsolute());
/*  53 */     setRowRelative(!c.isRowAbsolute());
/*     */   }
/*     */   
/*     */   protected final void readCoordinates(LittleEndianInput in) {
/*  57 */     this.field_1_row = in.readUShort();
/*  58 */     this.field_2_col = in.readUShort();
/*     */   }
/*     */   
/*     */   protected final void writeCoordinates(LittleEndianOutput out) {
/*  62 */     out.writeShort(this.field_1_row);
/*  63 */     out.writeShort(this.field_2_col);
/*     */   }
/*     */   
/*     */   public final void setRow(int rowIndex) {
/*  67 */     this.field_1_row = rowIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getRow()
/*     */   {
/*  74 */     return this.field_1_row;
/*     */   }
/*     */   
/*     */   public final boolean isRowRelative() {
/*  78 */     return rowRelative.isSet(this.field_2_col);
/*     */   }
/*     */   
/*     */   public final void setRowRelative(boolean rel) {
/*  82 */     this.field_2_col = rowRelative.setBoolean(this.field_2_col, rel);
/*     */   }
/*     */   
/*     */   public final boolean isColRelative() {
/*  86 */     return colRelative.isSet(this.field_2_col);
/*     */   }
/*     */   
/*     */   public final void setColRelative(boolean rel) {
/*  90 */     this.field_2_col = colRelative.setBoolean(this.field_2_col, rel);
/*     */   }
/*     */   
/*     */   public final void setColumn(int col) {
/*  94 */     this.field_2_col = column.setValue(this.field_2_col, col);
/*     */   }
/*     */   
/*     */   public final int getColumn() {
/*  98 */     return column.getValue(this.field_2_col);
/*     */   }
/*     */   
/*     */   protected final String formatReferenceAsString()
/*     */   {
/* 103 */     CellReference cr = new CellReference(getRow(), getColumn(), !isRowRelative(), !isColRelative());
/* 104 */     return cr.formatAsString();
/*     */   }
/*     */   
/*     */   public final byte getDefaultOperandClass() {
/* 108 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\RefPtgBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */