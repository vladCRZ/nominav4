/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ScalarConstantPtg
/*    */   extends Ptg
/*    */ {
/*    */   public final boolean isBaseToken()
/*    */   {
/* 28 */     return true;
/*    */   }
/*    */   
/*    */   public final byte getDefaultOperandClass() {
/* 32 */     return 32;
/*    */   }
/*    */   
/*    */   public final String toString() {
/* 36 */     StringBuffer sb = new StringBuffer(64);
/* 37 */     sb.append(getClass().getName()).append(" [");
/* 38 */     sb.append(toFormulaString());
/* 39 */     sb.append("]");
/* 40 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ScalarConstantPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */