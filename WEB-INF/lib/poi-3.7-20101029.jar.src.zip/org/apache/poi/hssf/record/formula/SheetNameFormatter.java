/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.poi.hssf.util.CellReference;
/*     */ import org.apache.poi.ss.SpreadsheetVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SheetNameFormatter
/*     */ {
/*     */   private static final char DELIMITER = '\'';
/*  38 */   private static final Pattern CELL_REF_PATTERN = Pattern.compile("([A-Za-z]+)([0-9]+)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format(String rawSheetName)
/*     */   {
/*  50 */     StringBuffer sb = new StringBuffer(rawSheetName.length() + 2);
/*  51 */     appendFormat(sb, rawSheetName);
/*  52 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void appendFormat(StringBuffer out, String rawSheetName)
/*     */   {
/*  61 */     boolean needsQuotes = needsDelimiting(rawSheetName);
/*  62 */     if (needsQuotes) {
/*  63 */       out.append('\'');
/*  64 */       appendAndEscape(out, rawSheetName);
/*  65 */       out.append('\'');
/*     */     } else {
/*  67 */       out.append(rawSheetName);
/*     */     }
/*     */   }
/*     */   
/*  71 */   public static void appendFormat(StringBuffer out, String workbookName, String rawSheetName) { boolean needsQuotes = (needsDelimiting(workbookName)) || (needsDelimiting(rawSheetName));
/*  72 */     if (needsQuotes) {
/*  73 */       out.append('\'');
/*  74 */       out.append('[');
/*  75 */       appendAndEscape(out, workbookName.replace('[', '(').replace(']', ')'));
/*  76 */       out.append(']');
/*  77 */       appendAndEscape(out, rawSheetName);
/*  78 */       out.append('\'');
/*     */     } else {
/*  80 */       out.append('[');
/*  81 */       out.append(workbookName);
/*  82 */       out.append(']');
/*  83 */       out.append(rawSheetName);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void appendAndEscape(StringBuffer sb, String rawSheetName) {
/*  88 */     int len = rawSheetName.length();
/*  89 */     for (int i = 0; i < len; i++) {
/*  90 */       char ch = rawSheetName.charAt(i);
/*  91 */       if (ch == '\'')
/*     */       {
/*  93 */         sb.append('\'');
/*     */       }
/*  95 */       sb.append(ch);
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean needsDelimiting(String rawSheetName) {
/* 100 */     int len = rawSheetName.length();
/* 101 */     if (len < 1) {
/* 102 */       throw new RuntimeException("Zero length string is an invalid sheet name");
/*     */     }
/* 104 */     if (Character.isDigit(rawSheetName.charAt(0)))
/*     */     {
/* 106 */       return true;
/*     */     }
/* 108 */     for (int i = 0; i < len; i++) {
/* 109 */       char ch = rawSheetName.charAt(i);
/* 110 */       if (isSpecialChar(ch)) {
/* 111 */         return true;
/*     */       }
/*     */     }
/* 114 */     if ((Character.isLetter(rawSheetName.charAt(0))) && (Character.isDigit(rawSheetName.charAt(len - 1))))
/*     */     {
/*     */ 
/* 117 */       if (nameLooksLikePlainCellReference(rawSheetName)) {
/* 118 */         return true;
/*     */       }
/*     */     }
/* 121 */     if (nameLooksLikeBooleanLiteral(rawSheetName)) {
/* 122 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 126 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean nameLooksLikeBooleanLiteral(String rawSheetName) {
/* 130 */     switch (rawSheetName.charAt(0)) {
/*     */     case 'T': case 't': 
/* 132 */       return "TRUE".equalsIgnoreCase(rawSheetName);
/*     */     case 'F': case 'f': 
/* 134 */       return "FALSE".equalsIgnoreCase(rawSheetName);
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isSpecialChar(char ch)
/*     */   {
/* 145 */     if (Character.isLetterOrDigit(ch)) {
/* 146 */       return false;
/*     */     }
/* 148 */     switch (ch) {
/*     */     case '.': 
/*     */     case '_': 
/* 151 */       return false;
/*     */     case '\t': 
/*     */     case '\n': 
/*     */     case '\r': 
/* 155 */       throw new RuntimeException("Illegal character (0x" + Integer.toHexString(ch) + ") found in sheet name");
/*     */     }
/*     */     
/* 158 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean cellReferenceIsWithinRange(String lettersPrefix, String numbersSuffix)
/*     */   {
/* 187 */     return CellReference.cellReferenceIsWithinRange(lettersPrefix, numbersSuffix, SpreadsheetVersion.EXCEL97);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean nameLooksLikePlainCellReference(String rawSheetName)
/*     */   {
/* 213 */     Matcher matcher = CELL_REF_PATTERN.matcher(rawSheetName);
/* 214 */     if (!matcher.matches()) {
/* 215 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 219 */     String lettersPrefix = matcher.group(1);
/* 220 */     String numbersSuffix = matcher.group(2);
/* 221 */     return cellReferenceIsWithinRange(lettersPrefix, numbersSuffix);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\SheetNameFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */