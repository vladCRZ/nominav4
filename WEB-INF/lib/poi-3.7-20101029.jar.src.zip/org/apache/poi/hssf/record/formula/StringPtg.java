/*     */ package org.apache.poi.hssf.record.formula;
/*     */ 
/*     */ import org.apache.poi.util.LittleEndianInput;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringPtg
/*     */   extends ScalarConstantPtg
/*     */ {
/*     */   public static final byte sid = 23;
/*     */   private static final char FORMULA_DELIMITER = '"';
/*     */   private final boolean _is16bitUnicode;
/*     */   private final String field_3_string;
/*     */   
/*     */   public StringPtg(LittleEndianInput in)
/*     */   {
/*  46 */     int nChars = in.readUByte();
/*  47 */     this._is16bitUnicode = ((in.readByte() & 0x1) != 0);
/*  48 */     if (this._is16bitUnicode) {
/*  49 */       this.field_3_string = StringUtil.readUnicodeLE(in, nChars);
/*     */     } else {
/*  51 */       this.field_3_string = StringUtil.readCompressedUnicode(in, nChars);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringPtg(String value)
/*     */   {
/*  64 */     if (value.length() > 255) {
/*  65 */       throw new IllegalArgumentException("String literals in formulas can't be bigger than 255 characters ASCII");
/*     */     }
/*     */     
/*  68 */     this._is16bitUnicode = StringUtil.hasMultibyte(value);
/*  69 */     this.field_3_string = value;
/*     */   }
/*     */   
/*     */   public String getValue() {
/*  73 */     return this.field_3_string;
/*     */   }
/*     */   
/*     */   public void write(LittleEndianOutput out) {
/*  77 */     out.writeByte(23 + getPtgClass());
/*  78 */     out.writeByte(this.field_3_string.length());
/*  79 */     out.writeByte(this._is16bitUnicode ? 1 : 0);
/*  80 */     if (this._is16bitUnicode) {
/*  81 */       StringUtil.putUnicodeLE(this.field_3_string, out);
/*     */     } else {
/*  83 */       StringUtil.putCompressedUnicode(this.field_3_string, out);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getSize() {
/*  88 */     return 3 + this.field_3_string.length() * (this._is16bitUnicode ? 2 : 1);
/*     */   }
/*     */   
/*     */   public String toFormulaString() {
/*  92 */     String value = this.field_3_string;
/*  93 */     int len = value.length();
/*  94 */     StringBuffer sb = new StringBuffer(len + 4);
/*  95 */     sb.append('"');
/*     */     
/*  97 */     for (int i = 0; i < len; i++) {
/*  98 */       char c = value.charAt(i);
/*  99 */       if (c == '"') {
/* 100 */         sb.append('"');
/*     */       }
/* 102 */       sb.append(c);
/*     */     }
/*     */     
/* 105 */     sb.append('"');
/* 106 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\StringPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */