/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordFormatException;
/*    */ import org.apache.poi.util.LittleEndianInput;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TblPtg
/*    */   extends ControlPtg
/*    */ {
/*    */   private static final int SIZE = 5;
/*    */   public static final short sid = 2;
/*    */   private final int field_1_first_row;
/*    */   private final int field_2_first_col;
/*    */   
/*    */   public TblPtg(LittleEndianInput in)
/*    */   {
/* 47 */     this.field_1_first_row = in.readUShort();
/* 48 */     this.field_2_first_col = in.readUShort();
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 52 */     out.writeByte(2 + getPtgClass());
/* 53 */     out.writeShort(this.field_1_first_row);
/* 54 */     out.writeShort(this.field_2_first_col);
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 58 */     return 5;
/*    */   }
/*    */   
/*    */   public int getRow() {
/* 62 */     return this.field_1_first_row;
/*    */   }
/*    */   
/*    */   public int getColumn() {
/* 66 */     return this.field_2_first_col;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toFormulaString()
/*    */   {
/* 72 */     throw new RecordFormatException("Table and Arrays are not yet supported");
/*    */   }
/*    */   
/*    */   public String toString() {
/* 76 */     StringBuffer buffer = new StringBuffer("[Data Table - Parent cell is an interior cell in a data table]\n");
/* 77 */     buffer.append("top left row = ").append(getRow()).append("\n");
/* 78 */     buffer.append("top left col = ").append(getColumn()).append("\n");
/* 79 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\TblPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */