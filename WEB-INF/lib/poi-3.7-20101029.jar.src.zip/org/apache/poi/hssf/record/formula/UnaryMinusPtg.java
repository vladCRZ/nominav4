/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnaryMinusPtg
/*    */   extends ValueOperatorPtg
/*    */ {
/*    */   public static final byte sid = 19;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String MINUS = "-";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 30 */   public static final ValueOperatorPtg instance = new UnaryMinusPtg();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected byte getSid()
/*    */   {
/* 37 */     return 19;
/*    */   }
/*    */   
/*    */   public int getNumberOfOperands() {
/* 41 */     return 1;
/*    */   }
/*    */   
/*    */   public String toFormulaString(String[] operands)
/*    */   {
/* 46 */     StringBuffer buffer = new StringBuffer();
/* 47 */     buffer.append("-");
/* 48 */     buffer.append(operands[0]);
/* 49 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\UnaryMinusPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */