/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownPtg
/*    */   extends Ptg
/*    */ {
/* 26 */   private short size = 1;
/*    */   private final int _sid;
/*    */   
/*    */   public UnknownPtg(int sid) {
/* 30 */     this._sid = sid;
/*    */   }
/*    */   
/*    */   public boolean isBaseToken() {
/* 34 */     return true;
/*    */   }
/*    */   
/* 37 */   public void write(LittleEndianOutput out) { out.writeByte(this._sid); }
/*    */   
/*    */   public int getSize()
/*    */   {
/* 41 */     return this.size;
/*    */   }
/*    */   
/*    */   public String toFormulaString() {
/* 45 */     return "UNKNOWN";
/*    */   }
/*    */   
/* 48 */   public byte getDefaultOperandClass() { return 32; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\UnknownPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */