/*    */ package org.apache.poi.hssf.record.formula;
/*    */ 
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ValueOperatorPtg
/*    */   extends OperationPtg
/*    */ {
/*    */   public final boolean isBaseToken()
/*    */   {
/* 35 */     return true;
/*    */   }
/*    */   
/*    */   public final byte getDefaultOperandClass() {
/* 39 */     return 32;
/*    */   }
/*    */   
/*    */   public void write(LittleEndianOutput out) {
/* 43 */     out.writeByte(getSid());
/*    */   }
/*    */   
/*    */   protected abstract byte getSid();
/*    */   
/*    */   public final int getSize() {
/* 49 */     return 1;
/*    */   }
/*    */   
/*    */   public final String toFormulaString()
/*    */   {
/* 54 */     throw new RuntimeException("toFormulaString(String[] operands) should be used for subclasses of OperationPtgs");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\ValueOperatorPtg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */