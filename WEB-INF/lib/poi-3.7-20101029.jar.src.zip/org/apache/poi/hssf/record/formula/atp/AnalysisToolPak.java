/*     */ package org.apache.poi.hssf.record.formula.atp;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.hssf.record.formula.functions.FreeRefFunction;
/*     */ import org.apache.poi.hssf.record.formula.udf.UDFFinder;
/*     */ import org.apache.poi.ss.formula.OperationEvaluationContext;
/*     */ import org.apache.poi.ss.formula.eval.NotImplementedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnalysisToolPak
/*     */   implements UDFFinder
/*     */ {
/*  35 */   public static final UDFFinder instance = new AnalysisToolPak();
/*     */   
/*     */   private static final class NotImplemented implements FreeRefFunction {
/*     */     private final String _functionName;
/*     */     
/*     */     public NotImplemented(String functionName) {
/*  41 */       this._functionName = functionName;
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(ValueEval[] args, OperationEvaluationContext ec) {
/*  45 */       throw new NotImplementedException(this._functionName);
/*     */     }
/*     */   }
/*     */   
/*  49 */   private final Map<String, FreeRefFunction> _functionsByName = createFunctionsMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FreeRefFunction findFunction(String name)
/*     */   {
/*  57 */     return (FreeRefFunction)this._functionsByName.get(name);
/*     */   }
/*     */   
/*     */   private Map<String, FreeRefFunction> createFunctionsMap() {
/*  61 */     Map<String, FreeRefFunction> m = new HashMap(100);
/*     */     
/*  63 */     r(m, "ACCRINT", null);
/*  64 */     r(m, "ACCRINTM", null);
/*  65 */     r(m, "AMORDEGRC", null);
/*  66 */     r(m, "AMORLINC", null);
/*  67 */     r(m, "BESSELI", null);
/*  68 */     r(m, "BESSELJ", null);
/*  69 */     r(m, "BESSELK", null);
/*  70 */     r(m, "BESSELY", null);
/*  71 */     r(m, "BIN2DEC", null);
/*  72 */     r(m, "BIN2HEX", null);
/*  73 */     r(m, "BIN2OCT", null);
/*  74 */     r(m, "CO MPLEX", null);
/*  75 */     r(m, "CONVERT", null);
/*  76 */     r(m, "COUPDAYBS", null);
/*  77 */     r(m, "COUPDAYS", null);
/*  78 */     r(m, "COUPDAYSNC", null);
/*  79 */     r(m, "COUPNCD", null);
/*  80 */     r(m, "COUPNUM", null);
/*  81 */     r(m, "COUPPCD", null);
/*  82 */     r(m, "CUMIPMT", null);
/*  83 */     r(m, "CUMPRINC", null);
/*  84 */     r(m, "DEC2BIN", null);
/*  85 */     r(m, "DEC2HEX", null);
/*  86 */     r(m, "DEC2OCT", null);
/*  87 */     r(m, "DELTA", null);
/*  88 */     r(m, "DISC", null);
/*  89 */     r(m, "DOLLARDE", null);
/*  90 */     r(m, "DOLLARFR", null);
/*  91 */     r(m, "DURATION", null);
/*  92 */     r(m, "EDATE", null);
/*  93 */     r(m, "EFFECT", null);
/*  94 */     r(m, "EOMONTH", null);
/*  95 */     r(m, "ERF", null);
/*  96 */     r(m, "ERFC", null);
/*  97 */     r(m, "FACTDOUBLE", null);
/*  98 */     r(m, "FVSCHEDULE", null);
/*  99 */     r(m, "GCD", null);
/* 100 */     r(m, "GESTEP", null);
/* 101 */     r(m, "HEX2BIN", null);
/* 102 */     r(m, "HEX2DEC", null);
/* 103 */     r(m, "HEX2OCT", null);
/* 104 */     r(m, "IMABS", null);
/* 105 */     r(m, "IMAGINARY", null);
/* 106 */     r(m, "IMARGUMENT", null);
/* 107 */     r(m, "IMCONJUGATE", null);
/* 108 */     r(m, "IMCOS", null);
/* 109 */     r(m, "IMDIV", null);
/* 110 */     r(m, "IMEXP", null);
/* 111 */     r(m, "IMLN", null);
/* 112 */     r(m, "IMLOG10", null);
/* 113 */     r(m, "IMLOG2", null);
/* 114 */     r(m, "IMPOWER", null);
/* 115 */     r(m, "IMPRODUCT", null);
/* 116 */     r(m, "IMREAL", null);
/* 117 */     r(m, "IMSIN", null);
/* 118 */     r(m, "IMSQRT", null);
/* 119 */     r(m, "IMSUB", null);
/* 120 */     r(m, "IMSUM", null);
/* 121 */     r(m, "INTRATE", null);
/* 122 */     r(m, "ISEVEN", ParityFunction.IS_EVEN);
/* 123 */     r(m, "ISODD", ParityFunction.IS_ODD);
/* 124 */     r(m, "LCM", null);
/* 125 */     r(m, "MDURATION", null);
/* 126 */     r(m, "MROUND", null);
/* 127 */     r(m, "MULTINOMIAL", null);
/* 128 */     r(m, "NETWORKDAYS", null);
/* 129 */     r(m, "NOMINAL", null);
/* 130 */     r(m, "OCT2BIN", null);
/* 131 */     r(m, "OCT2DEC", null);
/* 132 */     r(m, "OCT2HEX", null);
/* 133 */     r(m, "ODDFPRICE", null);
/* 134 */     r(m, "ODDFYIELD", null);
/* 135 */     r(m, "ODDLPRICE", null);
/* 136 */     r(m, "ODDLYIELD", null);
/* 137 */     r(m, "PRICE", null);
/* 138 */     r(m, "PRICEDISC", null);
/* 139 */     r(m, "PRICEMAT", null);
/* 140 */     r(m, "QUOTIENT", null);
/* 141 */     r(m, "RANDBETWEEN", RandBetween.instance);
/* 142 */     r(m, "RECEIVED", null);
/* 143 */     r(m, "SERIESSUM", null);
/* 144 */     r(m, "SQRTPI", null);
/* 145 */     r(m, "TBILLEQ", null);
/* 146 */     r(m, "TBILLPRICE", null);
/* 147 */     r(m, "TBILLYIELD", null);
/* 148 */     r(m, "WEEKNUM", null);
/* 149 */     r(m, "WORKDAY", null);
/* 150 */     r(m, "XIRR", null);
/* 151 */     r(m, "XNPV", null);
/* 152 */     r(m, "YEARFRAC", YearFrac.instance);
/* 153 */     r(m, "YIELD", null);
/* 154 */     r(m, "YIELDDISC", null);
/* 155 */     r(m, "YIELDMAT", null);
/*     */     
/* 157 */     return m;
/*     */   }
/*     */   
/*     */   private static void r(Map<String, FreeRefFunction> m, String functionName, FreeRefFunction pFunc) {
/* 161 */     FreeRefFunction func = pFunc == null ? new NotImplemented(functionName) : pFunc;
/* 162 */     m.put(functionName, func);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\atp\AnalysisToolPak.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */