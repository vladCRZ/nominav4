/*    */ package org.apache.poi.hssf.record.formula.atp;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.hssf.record.formula.functions.FreeRefFunction;
/*    */ import org.apache.poi.ss.formula.OperationEvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParityFunction
/*    */   implements FreeRefFunction
/*    */ {
/* 34 */   public static final FreeRefFunction IS_EVEN = new ParityFunction(0);
/* 35 */   public static final FreeRefFunction IS_ODD = new ParityFunction(1);
/*    */   private final int _desiredParity;
/*    */   
/*    */   private ParityFunction(int desiredParity) {
/* 39 */     this._desiredParity = desiredParity;
/*    */   }
/*    */   
/*    */   public ValueEval evaluate(ValueEval[] args, OperationEvaluationContext ec) {
/* 43 */     if (args.length != 1) {
/* 44 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     int val;
/*    */     try
/*    */     {
/* 49 */       val = evaluateArgParity(args[0], ec.getRowIndex(), ec.getColumnIndex());
/*    */     } catch (EvaluationException e) {
/* 51 */       return e.getErrorEval();
/*    */     }
/*    */     
/* 54 */     return BoolEval.valueOf(val == this._desiredParity);
/*    */   }
/*    */   
/*    */   private static int evaluateArgParity(ValueEval arg, int srcCellRow, int srcCellCol) throws EvaluationException {
/* 58 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, (short)srcCellCol);
/*    */     
/* 60 */     double d = OperandResolver.coerceValueToDouble(ve);
/* 61 */     if (d < 0.0D) {
/* 62 */       d = -d;
/*    */     }
/* 64 */     long v = Math.floor(d);
/* 65 */     return (int)(v & 1L);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\atp\ParityFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */