/*    */ package org.apache.poi.hssf.record.formula.atp;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.hssf.record.formula.functions.FreeRefFunction;
/*    */ import org.apache.poi.ss.formula.OperationEvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RandBetween
/*    */   implements FreeRefFunction
/*    */ {
/* 42 */   public static final FreeRefFunction instance = new RandBetween();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ValueEval evaluate(ValueEval[] args, OperationEvaluationContext ec)
/*    */   {
/* 59 */     if (args.length != 2) {
/* 60 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     try
/*    */     {
/* 64 */       bottom = OperandResolver.coerceValueToDouble(OperandResolver.getSingleValue(args[0], ec.getRowIndex(), ec.getColumnIndex()));
/* 65 */       top = OperandResolver.coerceValueToDouble(OperandResolver.getSingleValue(args[1], ec.getRowIndex(), ec.getColumnIndex()));
/* 66 */       if (bottom > top) {
/* 67 */         return ErrorEval.NUM_ERROR;
/*    */       }
/*    */     } catch (EvaluationException e) {
/* 70 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     
/* 73 */     double bottom = Math.ceil(bottom);
/* 74 */     double top = Math.floor(top);
/*    */     
/* 76 */     if (bottom > top) {
/* 77 */       top = bottom;
/*    */     }
/*    */     
/* 80 */     return new NumberEval(bottom + (int)(Math.random() * (top - bottom + 1.0D)));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\atp\RandBetween.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */