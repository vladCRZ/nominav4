/*     */ package org.apache.poi.hssf.record.formula.atp;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.hssf.record.formula.functions.FreeRefFunction;
/*     */ import org.apache.poi.ss.formula.OperationEvaluationContext;
/*     */ import org.apache.poi.ss.usermodel.DateUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class YearFrac
/*     */   implements FreeRefFunction
/*     */ {
/*  55 */   public static final FreeRefFunction instance = new YearFrac();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueEval evaluate(ValueEval[] args, OperationEvaluationContext ec)
/*     */   {
/*  62 */     int srcCellRow = ec.getRowIndex();
/*  63 */     int srcCellCol = ec.getColumnIndex();
/*     */     double result;
/*     */     try {
/*  66 */       int basis = 0;
/*  67 */       switch (args.length) {
/*     */       case 3: 
/*  69 */         basis = evaluateIntArg(args[2], srcCellRow, srcCellCol);
/*     */       case 2: 
/*     */         break;
/*     */       default: 
/*  73 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*  75 */       double startDateVal = evaluateDateArg(args[0], srcCellRow, srcCellCol);
/*  76 */       double endDateVal = evaluateDateArg(args[1], srcCellRow, srcCellCol);
/*  77 */       result = YearFracCalculator.calculate(startDateVal, endDateVal, basis);
/*     */     } catch (EvaluationException e) {
/*  79 */       return e.getErrorEval();
/*     */     }
/*     */     
/*  82 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   private static double evaluateDateArg(ValueEval arg, int srcCellRow, int srcCellCol) throws EvaluationException {
/*  86 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, (short)srcCellCol);
/*     */     
/*  88 */     if ((ve instanceof StringEval)) {
/*  89 */       String strVal = ((StringEval)ve).getStringValue();
/*  90 */       Double dVal = OperandResolver.parseDouble(strVal);
/*  91 */       if (dVal != null) {
/*  92 */         return dVal.doubleValue();
/*     */       }
/*  94 */       Calendar date = parseDate(strVal);
/*  95 */       return DateUtil.getExcelDate(date, false);
/*     */     }
/*  97 */     return OperandResolver.coerceValueToDouble(ve);
/*     */   }
/*     */   
/*     */   private static Calendar parseDate(String strVal) throws EvaluationException {
/* 101 */     String[] parts = Pattern.compile("/").split(strVal);
/* 102 */     if (parts.length != 3) {
/* 103 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/* 105 */     String part2 = parts[2];
/* 106 */     int spacePos = part2.indexOf(' ');
/* 107 */     if (spacePos > 0)
/*     */     {
/* 109 */       part2 = part2.substring(0, spacePos);
/*     */     }
/*     */     int f0;
/*     */     int f1;
/*     */     int f2;
/*     */     try {
/* 115 */       f0 = Integer.parseInt(parts[0]);
/* 116 */       f1 = Integer.parseInt(parts[1]);
/* 117 */       f2 = Integer.parseInt(part2);
/*     */     } catch (NumberFormatException e) {
/* 119 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/* 121 */     if ((f0 < 0) || (f1 < 0) || (f2 < 0) || ((f0 > 12) && (f1 > 12) && (f2 > 12)))
/*     */     {
/* 123 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/*     */     
/* 126 */     if ((f0 >= 1900) && (f0 < 9999))
/*     */     {
/* 128 */       return makeDate(f0, f1, f2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */     throw new RuntimeException("Unable to determine date format for text '" + strVal + "'");
/*     */   }
/*     */   
/*     */ 
/*     */   private static Calendar makeDate(int year, int month, int day)
/*     */     throws EvaluationException
/*     */   {
/* 143 */     if ((month < 1) || (month > 12)) {
/* 144 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/* 146 */     Calendar cal = new GregorianCalendar(year, month - 1, 1, 0, 0, 0);
/* 147 */     cal.set(14, 0);
/* 148 */     if ((day < 1) || (day > cal.getActualMaximum(5))) {
/* 149 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/* 151 */     cal.set(5, day);
/* 152 */     return cal;
/*     */   }
/*     */   
/*     */   private static int evaluateIntArg(ValueEval arg, int srcCellRow, int srcCellCol) throws EvaluationException {
/* 156 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, (short)srcCellCol);
/* 157 */     return OperandResolver.coerceValueToInt(ve);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\atp\YearFrac.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */