/*     */ package org.apache.poi.hssf.record.formula.atp;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.usermodel.HSSFDateUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class YearFracCalculator
/*     */ {
/*  38 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*     */   
/*     */   private static final int MS_PER_HOUR = 3600000;
/*     */   
/*     */   private static final int MS_PER_DAY = 86400000;
/*     */   
/*     */   private static final int DAYS_PER_NORMAL_YEAR = 365;
/*     */   
/*     */   private static final int DAYS_PER_LEAP_YEAR = 366;
/*     */   
/*     */   private static final int LONG_MONTH_LEN = 31;
/*     */   
/*     */   private static final int SHORT_MONTH_LEN = 30;
/*     */   
/*     */   private static final int SHORT_FEB_LEN = 28;
/*     */   private static final int LONG_FEB_LEN = 29;
/*     */   
/*     */   public static double calculate(double pStartDateVal, double pEndDateVal, int basis)
/*     */     throws EvaluationException
/*     */   {
/*  58 */     if ((basis < 0) || (basis >= 5))
/*     */     {
/*  60 */       throw new EvaluationException(ErrorEval.NUM_ERROR);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  66 */     int startDateVal = (int)Math.floor(pStartDateVal);
/*  67 */     int endDateVal = (int)Math.floor(pEndDateVal);
/*  68 */     if (startDateVal == endDateVal)
/*     */     {
/*  70 */       return 0.0D;
/*     */     }
/*     */     
/*  73 */     if (startDateVal > endDateVal) {
/*  74 */       int temp = startDateVal;
/*  75 */       startDateVal = endDateVal;
/*  76 */       endDateVal = temp;
/*     */     }
/*     */     
/*  79 */     switch (basis) {
/*  80 */     case 0:  return basis0(startDateVal, endDateVal);
/*  81 */     case 1:  return basis1(startDateVal, endDateVal);
/*  82 */     case 2:  return basis2(startDateVal, endDateVal);
/*  83 */     case 3:  return basis3(startDateVal, endDateVal);
/*  84 */     case 4:  return basis4(startDateVal, endDateVal);
/*     */     }
/*  86 */     throw new IllegalStateException("cannot happen");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double basis0(int startDateVal, int endDateVal)
/*     */   {
/*  95 */     SimpleDate startDate = createDate(startDateVal);
/*  96 */     SimpleDate endDate = createDate(endDateVal);
/*  97 */     int date1day = startDate.day;
/*  98 */     int date2day = endDate.day;
/*     */     
/*     */ 
/* 101 */     if ((date1day == 31) && (date2day == 31)) {
/* 102 */       date1day = 30;
/* 103 */       date2day = 30;
/* 104 */     } else if (date1day == 31) {
/* 105 */       date1day = 30;
/* 106 */     } else if ((date1day == 30) && (date2day == 31)) {
/* 107 */       date2day = 30;
/*     */ 
/*     */     }
/* 110 */     else if ((startDate.month == 2) && (isLastDayOfMonth(startDate)))
/*     */     {
/* 112 */       date1day = 30;
/* 113 */       if ((endDate.month == 2) && (isLastDayOfMonth(endDate)))
/*     */       {
/* 115 */         date2day = 30;
/*     */       }
/*     */     }
/* 118 */     return calculateAdjusted(startDate, endDate, date1day, date2day);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static double basis1(int startDateVal, int endDateVal)
/*     */   {
/* 125 */     SimpleDate startDate = createDate(startDateVal);
/* 126 */     SimpleDate endDate = createDate(endDateVal);
/*     */     double yearLength;
/* 128 */     double yearLength; if (isGreaterThanOneYear(startDate, endDate)) {
/* 129 */       yearLength = averageYearLength(startDate.year, endDate.year); } else { double yearLength;
/* 130 */       if (shouldCountFeb29(startDate, endDate)) {
/* 131 */         yearLength = 366.0D;
/*     */       } else
/* 133 */         yearLength = 365.0D;
/*     */     }
/* 135 */     return dateDiff(startDate.tsMilliseconds, endDate.tsMilliseconds) / yearLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double basis2(int startDateVal, int endDateVal)
/*     */   {
/* 143 */     return (endDateVal - startDateVal) / 360.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static double basis3(double startDateVal, double endDateVal)
/*     */   {
/* 150 */     return (endDateVal - startDateVal) / 365.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static double basis4(int startDateVal, int endDateVal)
/*     */   {
/* 157 */     SimpleDate startDate = createDate(startDateVal);
/* 158 */     SimpleDate endDate = createDate(endDateVal);
/* 159 */     int date1day = startDate.day;
/* 160 */     int date2day = endDate.day;
/*     */     
/*     */ 
/*     */ 
/* 164 */     if (date1day == 31) {
/* 165 */       date1day = 30;
/*     */     }
/* 167 */     if (date2day == 31) {
/* 168 */       date2day = 30;
/*     */     }
/*     */     
/* 171 */     return calculateAdjusted(startDate, endDate, date1day, date2day);
/*     */   }
/*     */   
/*     */ 
/*     */   private static double calculateAdjusted(SimpleDate startDate, SimpleDate endDate, int date1day, int date2day)
/*     */   {
/* 177 */     double dayCount = (endDate.year - startDate.year) * 360 + (endDate.month - startDate.month) * 30 + (date2day - date1day) * 1;
/*     */     
/*     */ 
/*     */ 
/* 181 */     return dayCount / 360.0D;
/*     */   }
/*     */   
/*     */   private static boolean isLastDayOfMonth(SimpleDate date) {
/* 185 */     if (date.day < 28) {
/* 186 */       return false;
/*     */     }
/* 188 */     return date.day == getLastDayOfMonth(date);
/*     */   }
/*     */   
/*     */   private static int getLastDayOfMonth(SimpleDate date) {
/* 192 */     switch (date.month) {
/*     */     case 1: 
/*     */     case 3: 
/*     */     case 5: 
/*     */     case 7: 
/*     */     case 8: 
/*     */     case 10: 
/*     */     case 12: 
/* 200 */       return 31;
/*     */     case 4: 
/*     */     case 6: 
/*     */     case 9: 
/*     */     case 11: 
/* 205 */       return 30;
/*     */     }
/* 207 */     if (isLeapYear(date.year)) {
/* 208 */       return 29;
/*     */     }
/* 210 */     return 28;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean shouldCountFeb29(SimpleDate start, SimpleDate end)
/*     */   {
/* 218 */     boolean startIsLeapYear = isLeapYear(start.year);
/* 219 */     if ((startIsLeapYear) && (start.year == end.year))
/*     */     {
/* 221 */       return true;
/*     */     }
/*     */     
/* 224 */     boolean endIsLeapYear = isLeapYear(end.year);
/* 225 */     if ((!startIsLeapYear) && (!endIsLeapYear)) {
/* 226 */       return false;
/*     */     }
/* 228 */     if (startIsLeapYear) {
/* 229 */       switch (start.month) {
/*     */       case 1: 
/*     */       case 2: 
/* 232 */         return true;
/*     */       }
/* 234 */       return false;
/*     */     }
/* 236 */     if (endIsLeapYear) {
/* 237 */       switch (end.month) {
/*     */       case 1: 
/* 239 */         return false;
/*     */       case 2: 
/*     */         break;
/*     */       default: 
/* 243 */         return true;
/*     */       }
/* 245 */       return end.day == 29;
/*     */     }
/* 247 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int dateDiff(long startDateMS, long endDateMS)
/*     */   {
/* 255 */     long msDiff = endDateMS - startDateMS;
/*     */     
/*     */ 
/* 258 */     int remainderHours = (int)(msDiff % 86400000L / 3600000L);
/* 259 */     switch (remainderHours)
/*     */     {
/*     */     case 0: 
/*     */       break;
/*     */     case 1: 
/*     */     case 23: 
/*     */     default: 
/* 266 */       throw new RuntimeException("Unexpected date diff between " + startDateMS + " and " + endDateMS);
/*     */     }
/*     */     
/* 269 */     return (int)(0.5D + msDiff / 8.64E7D);
/*     */   }
/*     */   
/*     */   private static double averageYearLength(int startYear, int endYear) {
/* 273 */     int dayCount = 0;
/* 274 */     for (int i = startYear; i <= endYear; i++) {
/* 275 */       dayCount += 365;
/* 276 */       if (isLeapYear(i)) {
/* 277 */         dayCount++;
/*     */       }
/*     */     }
/* 280 */     double numberOfYears = endYear - startYear + 1;
/* 281 */     return dayCount / numberOfYears;
/*     */   }
/*     */   
/*     */   private static boolean isLeapYear(int i)
/*     */   {
/* 286 */     if (i % 4 != 0) {
/* 287 */       return false;
/*     */     }
/*     */     
/* 290 */     if (i % 400 == 0) {
/* 291 */       return true;
/*     */     }
/*     */     
/* 294 */     if (i % 100 == 0) {
/* 295 */       return false;
/*     */     }
/* 297 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isGreaterThanOneYear(SimpleDate start, SimpleDate end) {
/* 301 */     if (start.year == end.year) {
/* 302 */       return false;
/*     */     }
/* 304 */     if (start.year + 1 != end.year) {
/* 305 */       return true;
/*     */     }
/*     */     
/* 308 */     if (start.month > end.month) {
/* 309 */       return false;
/*     */     }
/* 311 */     if (start.month < end.month) {
/* 312 */       return true;
/*     */     }
/*     */     
/* 315 */     return start.day < end.day;
/*     */   }
/*     */   
/*     */   private static SimpleDate createDate(int dayCount) {
/* 319 */     GregorianCalendar calendar = new GregorianCalendar(UTC_TIME_ZONE);
/* 320 */     HSSFDateUtil.setCalendar(calendar, dayCount, 0, false);
/* 321 */     return new SimpleDate(calendar);
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class SimpleDate
/*     */   {
/*     */     public static final int JANUARY = 1;
/*     */     
/*     */     public static final int FEBRUARY = 2;
/*     */     
/*     */     public final int year;
/*     */     public final int month;
/*     */     public final int day;
/*     */     public long tsMilliseconds;
/*     */     
/*     */     public SimpleDate(Calendar cal)
/*     */     {
/* 338 */       this.year = cal.get(1);
/* 339 */       this.month = (cal.get(2) + 1);
/* 340 */       this.day = cal.get(5);
/* 341 */       this.tsMilliseconds = cal.getTimeInMillis();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\atp\YearFracCalculator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */