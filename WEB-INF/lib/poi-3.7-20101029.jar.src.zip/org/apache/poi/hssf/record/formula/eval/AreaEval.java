package org.apache.poi.hssf.record.formula.eval;

import org.apache.poi.ss.formula.TwoDEval;

public abstract interface AreaEval
  extends TwoDEval
{
  public abstract int getFirstRow();
  
  public abstract int getLastRow();
  
  public abstract int getFirstColumn();
  
  public abstract int getLastColumn();
  
  public abstract ValueEval getAbsoluteValue(int paramInt1, int paramInt2);
  
  public abstract boolean contains(int paramInt1, int paramInt2);
  
  public abstract boolean containsColumn(int paramInt);
  
  public abstract boolean containsRow(int paramInt);
  
  public abstract int getWidth();
  
  public abstract int getHeight();
  
  public abstract ValueEval getRelativeValue(int paramInt1, int paramInt2);
  
  public abstract AreaEval offset(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\AreaEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */