/*     */ package org.apache.poi.hssf.record.formula.eval;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.AreaI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AreaEvalBase
/*     */   implements AreaEval
/*     */ {
/*     */   private final int _firstColumn;
/*     */   private final int _firstRow;
/*     */   private final int _lastColumn;
/*     */   private final int _lastRow;
/*     */   private final int _nColumns;
/*     */   private final int _nRows;
/*     */   
/*     */   protected AreaEvalBase(int firstRow, int firstColumn, int lastRow, int lastColumn)
/*     */   {
/*  35 */     this._firstColumn = firstColumn;
/*  36 */     this._firstRow = firstRow;
/*  37 */     this._lastColumn = lastColumn;
/*  38 */     this._lastRow = lastRow;
/*     */     
/*  40 */     this._nColumns = (this._lastColumn - this._firstColumn + 1);
/*  41 */     this._nRows = (this._lastRow - this._firstRow + 1);
/*     */   }
/*     */   
/*     */   protected AreaEvalBase(AreaI ptg) {
/*  45 */     this._firstRow = ptg.getFirstRow();
/*  46 */     this._firstColumn = ptg.getFirstColumn();
/*  47 */     this._lastRow = ptg.getLastRow();
/*  48 */     this._lastColumn = ptg.getLastColumn();
/*     */     
/*  50 */     this._nColumns = (this._lastColumn - this._firstColumn + 1);
/*  51 */     this._nRows = (this._lastRow - this._firstRow + 1);
/*     */   }
/*     */   
/*     */   public final int getFirstColumn() {
/*  55 */     return this._firstColumn;
/*     */   }
/*     */   
/*     */   public final int getFirstRow() {
/*  59 */     return this._firstRow;
/*     */   }
/*     */   
/*     */   public final int getLastColumn() {
/*  63 */     return this._lastColumn;
/*     */   }
/*     */   
/*     */ 
/*  67 */   public final int getLastRow() { return this._lastRow; }
/*     */   
/*     */   public final ValueEval getAbsoluteValue(int row, int col) {
/*  70 */     int rowOffsetIx = row - this._firstRow;
/*  71 */     int colOffsetIx = col - this._firstColumn;
/*     */     
/*  73 */     if ((rowOffsetIx < 0) || (rowOffsetIx >= this._nRows)) {
/*  74 */       throw new IllegalArgumentException("Specified row index (" + row + ") is outside the allowed range (" + this._firstRow + ".." + this._lastRow + ")");
/*     */     }
/*     */     
/*  77 */     if ((colOffsetIx < 0) || (colOffsetIx >= this._nColumns)) {
/*  78 */       throw new IllegalArgumentException("Specified column index (" + col + ") is outside the allowed range (" + this._firstColumn + ".." + col + ")");
/*     */     }
/*     */     
/*  81 */     return getRelativeValue(rowOffsetIx, colOffsetIx);
/*     */   }
/*     */   
/*     */   public final boolean contains(int row, int col) {
/*  85 */     return (this._firstRow <= row) && (this._lastRow >= row) && (this._firstColumn <= col) && (this._lastColumn >= col);
/*     */   }
/*     */   
/*     */   public final boolean containsRow(int row)
/*     */   {
/*  90 */     return (this._firstRow <= row) && (this._lastRow >= row);
/*     */   }
/*     */   
/*     */   public final boolean containsColumn(int col) {
/*  94 */     return (this._firstColumn <= col) && (this._lastColumn >= col);
/*     */   }
/*     */   
/*     */   public final boolean isColumn() {
/*  98 */     return this._firstColumn == this._lastColumn;
/*     */   }
/*     */   
/*     */   public final boolean isRow() {
/* 102 */     return this._firstRow == this._lastRow;
/*     */   }
/*     */   
/* 105 */   public int getHeight() { return this._lastRow - this._firstRow + 1; }
/*     */   
/*     */   public final ValueEval getValue(int row, int col)
/*     */   {
/* 109 */     return getRelativeValue(row, col);
/*     */   }
/*     */   
/*     */   public abstract ValueEval getRelativeValue(int paramInt1, int paramInt2);
/*     */   
/*     */   public int getWidth() {
/* 115 */     return this._lastColumn - this._firstColumn + 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\AreaEvalBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */