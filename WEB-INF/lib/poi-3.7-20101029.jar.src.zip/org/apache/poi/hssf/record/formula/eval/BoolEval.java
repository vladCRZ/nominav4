/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BoolEval
/*    */   implements NumericValueEval, StringValueEval
/*    */ {
/*    */   private boolean _value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 27 */   public static final BoolEval FALSE = new BoolEval(false);
/*    */   
/* 29 */   public static final BoolEval TRUE = new BoolEval(true);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final BoolEval valueOf(boolean b)
/*    */   {
/* 38 */     return b ? TRUE : FALSE;
/*    */   }
/*    */   
/*    */   private BoolEval(boolean value) {
/* 42 */     this._value = value;
/*    */   }
/*    */   
/*    */   public boolean getBooleanValue() {
/* 46 */     return this._value;
/*    */   }
/*    */   
/*    */   public double getNumberValue() {
/* 50 */     return this._value ? 1.0D : 0.0D;
/*    */   }
/*    */   
/*    */   public String getStringValue() {
/* 54 */     return this._value ? "TRUE" : "FALSE";
/*    */   }
/*    */   
/*    */   public String toString() {
/* 58 */     StringBuilder sb = new StringBuilder(64);
/* 59 */     sb.append(getClass().getName()).append(" [");
/* 60 */     sb.append(getStringValue());
/* 61 */     sb.append("]");
/* 62 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\BoolEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */