/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed2ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConcatEval
/*    */   extends Fixed2ArgFunction
/*    */ {
/* 28 */   public static final Function instance = new ConcatEval();
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*    */   {
/*    */     ValueEval ve0;
/*    */     
/*    */     ValueEval ve1;
/*    */     try
/*    */     {
/* 38 */       ve0 = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 39 */       ve1 = OperandResolver.getSingleValue(arg1, srcRowIndex, srcColumnIndex);
/*    */     } catch (EvaluationException e) {
/* 41 */       return e.getErrorEval();
/*    */     }
/* 43 */     StringBuilder sb = new StringBuilder();
/* 44 */     sb.append(getText(ve0));
/* 45 */     sb.append(getText(ve1));
/* 46 */     return new StringEval(sb.toString());
/*    */   }
/*    */   
/*    */   private Object getText(ValueEval ve) {
/* 50 */     if ((ve instanceof StringValueEval)) {
/* 51 */       StringValueEval sve = (StringValueEval)ve;
/* 52 */       return sve.getStringValue();
/*    */     }
/* 54 */     if (ve == BlankEval.instance) {
/* 55 */       return "";
/*    */     }
/* 57 */     throw new IllegalAccessError("Unexpected value type (" + ve.getClass().getName() + ")");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\ConcatEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */