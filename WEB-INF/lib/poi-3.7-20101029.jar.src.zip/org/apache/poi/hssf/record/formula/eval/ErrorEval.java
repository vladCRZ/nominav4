/*     */ package org.apache.poi.hssf.record.formula.eval;
/*     */ 
/*     */ import org.apache.poi.hssf.usermodel.HSSFErrorConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ErrorEval
/*     */   implements ValueEval
/*     */ {
/*  29 */   private static final HSSFErrorConstants EC = null;
/*     */   
/*     */ 
/*  32 */   public static final ErrorEval NULL_INTERSECTION = new ErrorEval(0);
/*     */   
/*  34 */   public static final ErrorEval DIV_ZERO = new ErrorEval(7);
/*     */   
/*  36 */   public static final ErrorEval VALUE_INVALID = new ErrorEval(15);
/*     */   
/*  38 */   public static final ErrorEval REF_INVALID = new ErrorEval(23);
/*     */   
/*  40 */   public static final ErrorEval NAME_INVALID = new ErrorEval(29);
/*     */   
/*  42 */   public static final ErrorEval NUM_ERROR = new ErrorEval(36);
/*     */   
/*  44 */   public static final ErrorEval NA = new ErrorEval(42);
/*     */   
/*     */ 
/*     */   private static final int CIRCULAR_REF_ERROR_CODE = -60;
/*     */   
/*     */ 
/*     */   private static final int FUNCTION_NOT_IMPLEMENTED_CODE = -30;
/*     */   
/*  52 */   public static final ErrorEval CIRCULAR_REF_ERROR = new ErrorEval(-60);
/*     */   
/*     */ 
/*     */   private int _errorCode;
/*     */   
/*     */ 
/*     */   public static ErrorEval valueOf(int errorCode)
/*     */   {
/*  60 */     switch (errorCode) {
/*  61 */     case 0:  return NULL_INTERSECTION;
/*  62 */     case 7:  return DIV_ZERO;
/*  63 */     case 15:  return VALUE_INVALID;
/*  64 */     case 23:  return REF_INVALID;
/*  65 */     case 29:  return NAME_INVALID;
/*  66 */     case 36:  return NUM_ERROR;
/*  67 */     case 42:  return NA;
/*     */     case -60: 
/*  69 */       return CIRCULAR_REF_ERROR;
/*     */     }
/*  71 */     throw new RuntimeException("Unexpected error code (" + errorCode + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getText(int errorCode)
/*     */   {
/*  80 */     if (HSSFErrorConstants.isValidCode(errorCode)) {
/*  81 */       return HSSFErrorConstants.getText(errorCode);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  86 */     switch (errorCode) {
/*  87 */     case -60:  return "~CIRCULAR~REF~";
/*  88 */     case -30:  return "~FUNCTION~NOT~IMPLEMENTED~";
/*     */     }
/*  90 */     return "~non~std~err(" + errorCode + ")~";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ErrorEval(int errorCode)
/*     */   {
/*  98 */     this._errorCode = errorCode;
/*     */   }
/*     */   
/*     */ 
/* 102 */   public int getErrorCode() { return this._errorCode; }
/*     */   
/*     */   public String toString() {
/* 105 */     StringBuffer sb = new StringBuffer(64);
/* 106 */     sb.append(getClass().getName()).append(" [");
/* 107 */     sb.append(getText(this._errorCode));
/* 108 */     sb.append("]");
/* 109 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\ErrorEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */