/*     */ package org.apache.poi.hssf.record.formula.eval;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.function.FunctionMetadata;
/*     */ import org.apache.poi.hssf.record.formula.function.FunctionMetadataRegistry;
/*     */ import org.apache.poi.hssf.record.formula.functions.AggregateFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.BooleanFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.CalendarFieldFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.Columns;
/*     */ import org.apache.poi.hssf.record.formula.functions.Count;
/*     */ import org.apache.poi.hssf.record.formula.functions.Counta;
/*     */ import org.apache.poi.hssf.record.formula.functions.Countif;
/*     */ import org.apache.poi.hssf.record.formula.functions.Errortype;
/*     */ import org.apache.poi.hssf.record.formula.functions.Even;
/*     */ import org.apache.poi.hssf.record.formula.functions.FinanceFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.Function;
/*     */ import org.apache.poi.hssf.record.formula.functions.Hlookup;
/*     */ import org.apache.poi.hssf.record.formula.functions.IfFunc;
/*     */ import org.apache.poi.hssf.record.formula.functions.Index;
/*     */ import org.apache.poi.hssf.record.formula.functions.LogicalFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.Lookup;
/*     */ import org.apache.poi.hssf.record.formula.functions.Match;
/*     */ import org.apache.poi.hssf.record.formula.functions.MinaMaxa;
/*     */ import org.apache.poi.hssf.record.formula.functions.Na;
/*     */ import org.apache.poi.hssf.record.formula.functions.NotImplementedFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.Now;
/*     */ import org.apache.poi.hssf.record.formula.functions.NumericFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.Odd;
/*     */ import org.apache.poi.hssf.record.formula.functions.Offset;
/*     */ import org.apache.poi.hssf.record.formula.functions.Replace;
/*     */ import org.apache.poi.hssf.record.formula.functions.Rows;
/*     */ import org.apache.poi.hssf.record.formula.functions.Substitute;
/*     */ import org.apache.poi.hssf.record.formula.functions.Subtotal;
/*     */ import org.apache.poi.hssf.record.formula.functions.Sumif;
/*     */ import org.apache.poi.hssf.record.formula.functions.Sumproduct;
/*     */ import org.apache.poi.hssf.record.formula.functions.Sumx2my2;
/*     */ import org.apache.poi.hssf.record.formula.functions.Sumx2py2;
/*     */ import org.apache.poi.hssf.record.formula.functions.Sumxmy2;
/*     */ import org.apache.poi.hssf.record.formula.functions.T;
/*     */ import org.apache.poi.hssf.record.formula.functions.TextFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.TimeFunc;
/*     */ import org.apache.poi.hssf.record.formula.functions.Today;
/*     */ import org.apache.poi.hssf.record.formula.functions.Value;
/*     */ import org.apache.poi.ss.formula.eval.NotImplementedException;
/*     */ 
/*     */ public final class FunctionEval
/*     */ {
/*  47 */   private static final FunctionID ID = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   protected static final Function[] functions = produceFunctions();
/*     */   
/*     */   private static Function[] produceFunctions() {
/*  55 */     Function[] retval = new Function['Ű'];
/*     */     
/*  57 */     retval[0] = new Count();
/*  58 */     retval[1] = new IfFunc();
/*  59 */     retval[2] = LogicalFunction.ISNA;
/*  60 */     retval[3] = LogicalFunction.ISERROR;
/*  61 */     retval[4] = AggregateFunction.SUM;
/*  62 */     retval[5] = AggregateFunction.AVERAGE;
/*  63 */     retval[6] = AggregateFunction.MIN;
/*  64 */     retval[7] = AggregateFunction.MAX;
/*  65 */     retval[8] = new org.apache.poi.hssf.record.formula.functions.RowFunc();
/*  66 */     retval[9] = new org.apache.poi.hssf.record.formula.functions.Column();
/*  67 */     retval[10] = new Na();
/*  68 */     retval[11] = new org.apache.poi.hssf.record.formula.functions.Npv();
/*  69 */     retval[12] = AggregateFunction.STDEV;
/*  70 */     retval[13] = NumericFunction.DOLLAR;
/*     */     
/*  72 */     retval[15] = NumericFunction.SIN;
/*  73 */     retval[16] = NumericFunction.COS;
/*  74 */     retval[17] = NumericFunction.TAN;
/*  75 */     retval[18] = NumericFunction.ATAN;
/*  76 */     retval[19] = NumericFunction.PI;
/*  77 */     retval[20] = NumericFunction.SQRT;
/*  78 */     retval[21] = NumericFunction.EXP;
/*  79 */     retval[22] = NumericFunction.LN;
/*  80 */     retval[23] = NumericFunction.LOG10;
/*  81 */     retval[24] = NumericFunction.ABS;
/*  82 */     retval[25] = NumericFunction.INT;
/*  83 */     retval[26] = NumericFunction.SIGN;
/*  84 */     retval[27] = NumericFunction.ROUND;
/*  85 */     retval[28] = new Lookup();
/*  86 */     retval[29] = new Index();
/*     */     
/*  88 */     retval[31] = TextFunction.MID;
/*  89 */     retval[32] = TextFunction.LEN;
/*  90 */     retval[33] = new Value();
/*  91 */     retval[34] = BooleanFunction.TRUE;
/*  92 */     retval[35] = BooleanFunction.FALSE;
/*  93 */     retval[36] = BooleanFunction.AND;
/*  94 */     retval[37] = BooleanFunction.OR;
/*  95 */     retval[38] = BooleanFunction.NOT;
/*  96 */     retval[39] = NumericFunction.MOD;
/*  97 */     retval[48] = TextFunction.TEXT;
/*     */     
/*  99 */     retval[56] = FinanceFunction.PV;
/* 100 */     retval[57] = FinanceFunction.FV;
/* 101 */     retval[58] = FinanceFunction.NPER;
/* 102 */     retval[59] = FinanceFunction.PMT;
/*     */     
/* 104 */     retval[63] = NumericFunction.RAND;
/* 105 */     retval[64] = new Match();
/* 106 */     retval[65] = org.apache.poi.hssf.record.formula.functions.DateFunc.instance;
/* 107 */     retval[66] = new TimeFunc();
/* 108 */     retval[67] = CalendarFieldFunction.DAY;
/* 109 */     retval[68] = CalendarFieldFunction.MONTH;
/* 110 */     retval[69] = CalendarFieldFunction.YEAR;
/*     */     
/* 112 */     retval[74] = new Now();
/*     */     
/* 114 */     retval[76] = new Rows();
/* 115 */     retval[77] = new Columns();
/* 116 */     retval[82] = TextFunction.SEARCH;
/* 117 */     retval[78] = new Offset();
/* 118 */     retval[82] = TextFunction.SEARCH;
/*     */     
/* 120 */     retval[97] = NumericFunction.ATAN2;
/* 121 */     retval[98] = NumericFunction.ASIN;
/* 122 */     retval[99] = NumericFunction.ACOS;
/* 123 */     retval[100] = new org.apache.poi.hssf.record.formula.functions.Choose();
/* 124 */     retval[101] = new Hlookup();
/* 125 */     retval[102] = new org.apache.poi.hssf.record.formula.functions.Vlookup();
/*     */     
/* 127 */     retval[105] = LogicalFunction.ISREF;
/*     */     
/* 129 */     retval[109] = NumericFunction.LOG;
/*     */     
/* 131 */     retval[112] = TextFunction.LOWER;
/* 132 */     retval[113] = TextFunction.UPPER;
/*     */     
/* 134 */     retval[115] = TextFunction.LEFT;
/* 135 */     retval[116] = TextFunction.RIGHT;
/* 136 */     retval[117] = TextFunction.EXACT;
/* 137 */     retval[118] = TextFunction.TRIM;
/* 138 */     retval[119] = new Replace();
/* 139 */     retval[120] = new Substitute();
/*     */     
/* 141 */     retval[124] = TextFunction.FIND;
/*     */     
/* 143 */     retval[127] = LogicalFunction.ISTEXT;
/* 144 */     retval[''] = LogicalFunction.ISNUMBER;
/* 145 */     retval[''] = LogicalFunction.ISBLANK;
/* 146 */     retval[''] = new T();
/*     */     
/* 148 */     retval[''] = null;
/*     */     
/* 150 */     retval['©'] = new Counta();
/*     */     
/* 152 */     retval['·'] = AggregateFunction.PRODUCT;
/* 153 */     retval['¸'] = NumericFunction.FACT;
/*     */     
/* 155 */     retval['¾'] = LogicalFunction.ISNONTEXT;
/* 156 */     retval['Å'] = NumericFunction.TRUNC;
/* 157 */     retval['Æ'] = LogicalFunction.ISLOGICAL;
/*     */     
/* 159 */     retval['Ô'] = NumericFunction.ROUNDUP;
/* 160 */     retval['Õ'] = NumericFunction.ROUNDDOWN;
/*     */     
/* 162 */     retval['Ü'] = new org.apache.poi.hssf.record.formula.functions.Days360();
/* 163 */     retval['Ý'] = new Today();
/*     */     
/* 165 */     retval['ã'] = AggregateFunction.MEDIAN;
/* 166 */     retval['ä'] = new Sumproduct();
/* 167 */     retval['å'] = NumericFunction.SINH;
/* 168 */     retval['æ'] = NumericFunction.COSH;
/* 169 */     retval['ç'] = NumericFunction.TANH;
/* 170 */     retval['è'] = NumericFunction.ASINH;
/* 171 */     retval['é'] = NumericFunction.ACOSH;
/* 172 */     retval['ê'] = NumericFunction.ATANH;
/*     */     
/* 174 */     retval['ÿ'] = null;
/*     */     
/* 176 */     retval['ą'] = new Errortype();
/*     */     
/* 178 */     retval['č'] = AggregateFunction.AVEDEV;
/*     */     
/* 180 */     retval['Ĕ'] = NumericFunction.COMBIN;
/*     */     
/* 182 */     retval['ė'] = new Even();
/*     */     
/* 184 */     retval['ĝ'] = NumericFunction.FLOOR;
/*     */     
/* 186 */     retval['Ġ'] = NumericFunction.CEILING;
/*     */     
/* 188 */     retval['Ī'] = new Odd();
/*     */     
/* 190 */     retval['Ĭ'] = NumericFunction.POISSON;
/*     */     
/* 192 */     retval['į'] = new Sumxmy2();
/* 193 */     retval['İ'] = new Sumx2my2();
/* 194 */     retval['ı'] = new Sumx2py2();
/*     */     
/* 196 */     retval['ľ'] = AggregateFunction.DEVSQ;
/*     */     
/* 198 */     retval['Ł'] = AggregateFunction.SUMSQ;
/*     */     
/* 200 */     retval['Ņ'] = AggregateFunction.LARGE;
/* 201 */     retval['ņ'] = AggregateFunction.SMALL;
/*     */     
/* 203 */     retval['Ŋ'] = new org.apache.poi.hssf.record.formula.functions.Mode();
/*     */     
/* 205 */     retval['Ő'] = TextFunction.CONCATENATE;
/* 206 */     retval['ő'] = NumericFunction.POWER;
/*     */     
/* 208 */     retval['Ŗ'] = NumericFunction.RADIANS;
/* 209 */     retval['ŗ'] = NumericFunction.DEGREES;
/*     */     
/* 211 */     retval['Ř'] = new Subtotal();
/* 212 */     retval['ř'] = new Sumif();
/* 213 */     retval['Ś'] = new Countif();
/* 214 */     retval['ś'] = new org.apache.poi.hssf.record.formula.functions.Countblank();
/*     */     
/* 216 */     retval['ŧ'] = new org.apache.poi.hssf.record.formula.functions.Hyperlink();
/*     */     
/* 218 */     retval['Ū'] = MinaMaxa.MAXA;
/* 219 */     retval['ū'] = MinaMaxa.MINA;
/*     */     
/* 221 */     for (int i = 0; i < retval.length; i++) {
/* 222 */       Function f = retval[i];
/* 223 */       if (f == null) {
/* 224 */         FunctionMetadata fm = FunctionMetadataRegistry.getFunctionByIndex(i);
/* 225 */         if (fm != null)
/*     */         {
/*     */ 
/* 228 */           retval[i] = new NotImplementedFunction(fm.getName()); }
/*     */       }
/*     */     }
/* 231 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Function getBasicFunction(int functionIndex)
/*     */   {
/* 238 */     switch (functionIndex) {
/*     */     case 148: 
/*     */     case 255: 
/* 241 */       return null;
/*     */     }
/*     */     
/* 244 */     Function result = functions[functionIndex];
/* 245 */     if (result == null) {
/* 246 */       throw new NotImplementedException("FuncIx=" + functionIndex);
/*     */     }
/* 248 */     return result;
/*     */   }
/*     */   
/*     */   private static final class FunctionID
/*     */   {
/*     */     public static final int IF = 1;
/*     */     public static final int SUM = 4;
/*     */     public static final int OFFSET = 78;
/*     */     public static final int CHOOSE = 100;
/*     */     public static final int INDIRECT = 148;
/*     */     public static final int EXTERNAL_FUNC = 255;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\FunctionEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */