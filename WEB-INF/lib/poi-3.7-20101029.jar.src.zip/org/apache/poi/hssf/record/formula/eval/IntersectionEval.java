/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed2ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntersectionEval
/*    */   extends Fixed2ArgFunction
/*    */ {
/* 28 */   public static final Function instance = new IntersectionEval();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*    */   {
/*    */     try
/*    */     {
/* 37 */       AreaEval reA = evaluateRef(arg0);
/* 38 */       AreaEval reB = evaluateRef(arg1);
/* 39 */       AreaEval result = resolveRange(reA, reB);
/* 40 */       if (result == null) {
/* 41 */         return ErrorEval.NULL_INTERSECTION;
/*    */       }
/* 43 */       return result;
/*    */     } catch (EvaluationException e) {
/* 45 */       return e.getErrorEval();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static AreaEval resolveRange(AreaEval aeA, AreaEval aeB)
/*    */   {
/* 55 */     int aeAfr = aeA.getFirstRow();
/* 56 */     int aeAfc = aeA.getFirstColumn();
/* 57 */     int aeBlc = aeB.getLastColumn();
/* 58 */     if (aeAfc > aeBlc) {
/* 59 */       return null;
/*    */     }
/* 61 */     int aeBfc = aeB.getFirstColumn();
/* 62 */     if (aeBfc > aeA.getLastColumn()) {
/* 63 */       return null;
/*    */     }
/* 65 */     int aeBlr = aeB.getLastRow();
/* 66 */     if (aeAfr > aeBlr) {
/* 67 */       return null;
/*    */     }
/* 69 */     int aeBfr = aeB.getFirstRow();
/* 70 */     int aeAlr = aeA.getLastRow();
/* 71 */     if (aeBfr > aeAlr) {
/* 72 */       return null;
/*    */     }
/*    */     
/*    */ 
/* 76 */     int top = Math.max(aeAfr, aeBfr);
/* 77 */     int bottom = Math.min(aeAlr, aeBlr);
/* 78 */     int left = Math.max(aeAfc, aeBfc);
/* 79 */     int right = Math.min(aeA.getLastColumn(), aeBlc);
/*    */     
/* 81 */     return aeA.offset(top - aeAfr, bottom - aeAfr, left - aeAfc, right - aeAfc);
/*    */   }
/*    */   
/*    */   private static AreaEval evaluateRef(ValueEval arg) throws EvaluationException {
/* 85 */     if ((arg instanceof AreaEval)) {
/* 86 */       return (AreaEval)arg;
/*    */     }
/* 88 */     if ((arg instanceof RefEval)) {
/* 89 */       return ((RefEval)arg).offset(0, 0, 0, 0);
/*    */     }
/* 91 */     if ((arg instanceof ErrorEval)) {
/* 92 */       throw new EvaluationException((ErrorEval)arg);
/*    */     }
/* 94 */     throw new IllegalArgumentException("Unexpected ref arg class (" + arg.getClass().getName() + ")");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\IntersectionEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */