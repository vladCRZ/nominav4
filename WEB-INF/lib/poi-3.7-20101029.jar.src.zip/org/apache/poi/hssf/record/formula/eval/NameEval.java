/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NameEval
/*    */   implements ValueEval
/*    */ {
/*    */   private final String _functionName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NameEval(String functionName)
/*    */   {
/* 31 */     this._functionName = functionName;
/*    */   }
/*    */   
/*    */   public String getFunctionName()
/*    */   {
/* 36 */     return this._functionName;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 40 */     StringBuffer sb = new StringBuffer(64);
/* 41 */     sb.append(getClass().getName()).append(" [");
/* 42 */     sb.append(this._functionName);
/* 43 */     sb.append("]");
/* 44 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\NameEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */