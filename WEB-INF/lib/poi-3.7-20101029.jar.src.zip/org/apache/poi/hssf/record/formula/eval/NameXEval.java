/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.NameXPtg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NameXEval
/*    */   implements ValueEval
/*    */ {
/*    */   private final NameXPtg _ptg;
/*    */   
/*    */   public NameXEval(NameXPtg ptg)
/*    */   {
/* 30 */     this._ptg = ptg;
/*    */   }
/*    */   
/*    */   public NameXPtg getPtg() {
/* 34 */     return this._ptg;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 38 */     StringBuffer sb = new StringBuffer(64);
/* 39 */     sb.append(getClass().getName()).append(" [");
/* 40 */     sb.append(this._ptg.getSheetRefIndex()).append(", ").append(this._ptg.getNameIndex());
/* 41 */     sb.append("]");
/* 42 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\NameXEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */