/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.IntPtg;
/*    */ import org.apache.poi.hssf.record.formula.NumberPtg;
/*    */ import org.apache.poi.hssf.record.formula.Ptg;
/*    */ import org.apache.poi.ss.util.NumberToTextConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NumberEval
/*    */   implements NumericValueEval, StringValueEval
/*    */ {
/* 34 */   public static final NumberEval ZERO = new NumberEval(0.0D);
/*    */   private final double _value;
/*    */   private String _stringValue;
/*    */   
/*    */   public NumberEval(Ptg ptg)
/*    */   {
/* 40 */     if (ptg == null) {
/* 41 */       throw new IllegalArgumentException("ptg must not be null");
/*    */     }
/* 43 */     if ((ptg instanceof IntPtg)) {
/* 44 */       this._value = ((IntPtg)ptg).getValue();
/* 45 */     } else if ((ptg instanceof NumberPtg)) {
/* 46 */       this._value = ((NumberPtg)ptg).getValue();
/*    */     } else {
/* 48 */       throw new IllegalArgumentException("bad argument type (" + ptg.getClass().getName() + ")");
/*    */     }
/*    */   }
/*    */   
/*    */   public NumberEval(double value) {
/* 53 */     this._value = value;
/*    */   }
/*    */   
/*    */   public double getNumberValue() {
/* 57 */     return this._value;
/*    */   }
/*    */   
/*    */   public String getStringValue() {
/* 61 */     if (this._stringValue == null) {
/* 62 */       this._stringValue = NumberToTextConverter.toText(this._value);
/*    */     }
/* 64 */     return this._stringValue;
/*    */   }
/*    */   
/* 67 */   public final String toString() { StringBuffer sb = new StringBuffer(64);
/* 68 */     sb.append(getClass().getName()).append(" [");
/* 69 */     sb.append(getStringValue());
/* 70 */     sb.append("]");
/* 71 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\NumberEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */