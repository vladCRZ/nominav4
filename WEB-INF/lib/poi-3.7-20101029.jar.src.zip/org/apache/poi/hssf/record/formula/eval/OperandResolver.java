/*     */ package org.apache.poi.hssf.record.formula.eval;
/*     */ 
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OperandResolver
/*     */ {
/*     */   private static final String Digits = "(\\p{Digit}+)";
/*     */   private static final String Exp = "[eE][+-]?(\\p{Digit}+)";
/*     */   private static final String fpRegex = "[\\x00-\\x20]*[+-]?(((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?))))[\\x00-\\x20]*";
/*     */   
/*     */   public static ValueEval getSingleValue(ValueEval arg, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/*     */     ValueEval result;
/*     */     ValueEval result;
/*  61 */     if ((arg instanceof RefEval)) {
/*  62 */       result = ((RefEval)arg).getInnerValueEval(); } else { ValueEval result;
/*  63 */       if ((arg instanceof AreaEval)) {
/*  64 */         result = chooseSingleElementFromArea((AreaEval)arg, srcCellRow, srcCellCol);
/*     */       } else
/*  66 */         result = arg;
/*     */     }
/*  68 */     if ((result instanceof ErrorEval)) {
/*  69 */       throw new EvaluationException((ErrorEval)result);
/*     */     }
/*  71 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueEval chooseSingleElementFromArea(AreaEval ae, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 120 */     ValueEval result = chooseSingleElementFromAreaInternal(ae, srcCellRow, srcCellCol);
/* 121 */     if ((result instanceof ErrorEval)) {
/* 122 */       throw new EvaluationException((ErrorEval)result);
/*     */     }
/* 124 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ValueEval chooseSingleElementFromAreaInternal(AreaEval ae, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 156 */     if (ae.isColumn()) {
/* 157 */       if (ae.isRow()) {
/* 158 */         return ae.getRelativeValue(0, 0);
/*     */       }
/* 160 */       if (!ae.containsRow(srcCellRow)) {
/* 161 */         throw EvaluationException.invalidValue();
/*     */       }
/* 163 */       return ae.getAbsoluteValue(srcCellRow, ae.getFirstColumn());
/*     */     }
/* 165 */     if (!ae.isRow())
/*     */     {
/* 167 */       if ((ae.containsRow(srcCellRow)) && (ae.containsColumn(srcCellCol))) {
/* 168 */         return ae.getAbsoluteValue(ae.getFirstRow(), ae.getFirstColumn());
/*     */       }
/* 170 */       throw EvaluationException.invalidValue();
/*     */     }
/* 172 */     if (!ae.containsColumn(srcCellCol)) {
/* 173 */       throw EvaluationException.invalidValue();
/*     */     }
/* 175 */     return ae.getAbsoluteValue(ae.getFirstRow(), srcCellCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int coerceValueToInt(ValueEval ev)
/*     */     throws EvaluationException
/*     */   {
/* 191 */     if (ev == BlankEval.instance) {
/* 192 */       return 0;
/*     */     }
/* 194 */     double d = coerceValueToDouble(ev);
/*     */     
/*     */ 
/* 197 */     return (int)Math.floor(d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double coerceValueToDouble(ValueEval ev)
/*     */     throws EvaluationException
/*     */   {
/* 213 */     if (ev == BlankEval.instance) {
/* 214 */       return 0.0D;
/*     */     }
/* 216 */     if ((ev instanceof NumericValueEval))
/*     */     {
/* 218 */       return ((NumericValueEval)ev).getNumberValue();
/*     */     }
/* 220 */     if ((ev instanceof StringEval)) {
/* 221 */       Double dd = parseDouble(((StringEval)ev).getStringValue());
/* 222 */       if (dd == null) {
/* 223 */         throw EvaluationException.invalidValue();
/*     */       }
/* 225 */       return dd.doubleValue();
/*     */     }
/* 227 */     throw new RuntimeException("Unexpected arg eval type (" + ev.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Double parseDouble(String pText)
/*     */   {
/* 251 */     if (Pattern.matches("[\\x00-\\x20]*[+-]?(((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?))))[\\x00-\\x20]*", pText)) {
/*     */       try {
/* 253 */         return Double.valueOf(Double.parseDouble(pText));
/*     */       } catch (NumberFormatException e) {
/* 255 */         return null;
/*     */       }
/*     */     }
/* 258 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String coerceValueToString(ValueEval ve)
/*     */   {
/* 268 */     if ((ve instanceof StringValueEval)) {
/* 269 */       StringValueEval sve = (StringValueEval)ve;
/* 270 */       return sve.getStringValue();
/*     */     }
/* 272 */     if (ve == BlankEval.instance) {
/* 273 */       return "";
/*     */     }
/* 275 */     throw new IllegalArgumentException("Unexpected eval class (" + ve.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean coerceValueToBoolean(ValueEval ve, boolean stringsAreBlanks)
/*     */     throws EvaluationException
/*     */   {
/* 284 */     if ((ve == null) || (ve == BlankEval.instance))
/*     */     {
/* 286 */       return null;
/*     */     }
/* 288 */     if ((ve instanceof BoolEval)) {
/* 289 */       return Boolean.valueOf(((BoolEval)ve).getBooleanValue());
/*     */     }
/*     */     
/* 292 */     if (ve == BlankEval.instance) {
/* 293 */       return null;
/*     */     }
/*     */     
/* 296 */     if ((ve instanceof StringEval)) {
/* 297 */       if (stringsAreBlanks) {
/* 298 */         return null;
/*     */       }
/* 300 */       String str = ((StringEval)ve).getStringValue();
/* 301 */       if (str.equalsIgnoreCase("true")) {
/* 302 */         return Boolean.TRUE;
/*     */       }
/* 304 */       if (str.equalsIgnoreCase("false")) {
/* 305 */         return Boolean.FALSE;
/*     */       }
/*     */       
/* 308 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/*     */     
/* 311 */     if ((ve instanceof NumericValueEval)) {
/* 312 */       NumericValueEval ne = (NumericValueEval)ve;
/* 313 */       double d = ne.getNumberValue();
/* 314 */       if (Double.isNaN(d)) {
/* 315 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/* 317 */       return Boolean.valueOf(d != 0.0D);
/*     */     }
/* 319 */     if ((ve instanceof ErrorEval)) {
/* 320 */       throw new EvaluationException((ErrorEval)ve);
/*     */     }
/* 322 */     throw new RuntimeException("Unexpected eval (" + ve.getClass().getName() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\OperandResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */