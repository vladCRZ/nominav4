/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed1ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PercentEval
/*    */   extends Fixed1ArgFunction
/*    */ {
/* 30 */   public static final Function instance = new PercentEval();
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*    */   {
/*    */     double d;
/*    */     
/*    */     try
/*    */     {
/* 39 */       ValueEval ve = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 40 */       d = OperandResolver.coerceValueToDouble(ve);
/*    */     } catch (EvaluationException e) {
/* 42 */       return e.getErrorEval();
/*    */     }
/* 44 */     if (d == 0.0D) {
/* 45 */       return NumberEval.ZERO;
/*    */     }
/* 47 */     return new NumberEval(d / 100.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\PercentEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */