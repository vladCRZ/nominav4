/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed2ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RangeEval
/*    */   extends Fixed2ArgFunction
/*    */ {
/* 30 */   public static final Function instance = new RangeEval();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*    */   {
/*    */     try
/*    */     {
/* 39 */       AreaEval reA = evaluateRef(arg0);
/* 40 */       AreaEval reB = evaluateRef(arg1);
/* 41 */       return resolveRange(reA, reB);
/*    */     } catch (EvaluationException e) {
/* 43 */       return e.getErrorEval();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static AreaEval resolveRange(AreaEval aeA, AreaEval aeB)
/*    */   {
/* 52 */     int aeAfr = aeA.getFirstRow();
/* 53 */     int aeAfc = aeA.getFirstColumn();
/*    */     
/* 55 */     int top = Math.min(aeAfr, aeB.getFirstRow());
/* 56 */     int bottom = Math.max(aeA.getLastRow(), aeB.getLastRow());
/* 57 */     int left = Math.min(aeAfc, aeB.getFirstColumn());
/* 58 */     int right = Math.max(aeA.getLastColumn(), aeB.getLastColumn());
/*    */     
/* 60 */     return aeA.offset(top - aeAfr, bottom - aeAfr, left - aeAfc, right - aeAfc);
/*    */   }
/*    */   
/*    */   private static AreaEval evaluateRef(ValueEval arg) throws EvaluationException {
/* 64 */     if ((arg instanceof AreaEval)) {
/* 65 */       return (AreaEval)arg;
/*    */     }
/* 67 */     if ((arg instanceof RefEval)) {
/* 68 */       return ((RefEval)arg).offset(0, 0, 0, 0);
/*    */     }
/* 70 */     if ((arg instanceof ErrorEval)) {
/* 71 */       throw new EvaluationException((ErrorEval)arg);
/*    */     }
/* 73 */     throw new IllegalArgumentException("Unexpected ref arg class (" + arg.getClass().getName() + ")");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\RangeEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */