/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RefEvalBase
/*    */   implements RefEval
/*    */ {
/*    */   private final int _rowIndex;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final int _columnIndex;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected RefEvalBase(int rowIndex, int columnIndex)
/*    */   {
/* 31 */     this._rowIndex = rowIndex;
/* 32 */     this._columnIndex = columnIndex;
/*    */   }
/*    */   
/* 35 */   public final int getRow() { return this._rowIndex; }
/*    */   
/*    */   public final int getColumn() {
/* 38 */     return this._columnIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\RefEvalBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */