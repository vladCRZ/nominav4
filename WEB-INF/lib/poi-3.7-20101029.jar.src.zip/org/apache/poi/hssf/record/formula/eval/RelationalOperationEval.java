/*     */ package org.apache.poi.hssf.record.formula.eval;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.functions.Fixed2ArgFunction;
/*     */ import org.apache.poi.hssf.record.formula.functions.Function;
/*     */ import org.apache.poi.ss.util.NumberComparer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RelationalOperationEval
/*     */   extends Fixed2ArgFunction
/*     */ {
/*     */   protected abstract boolean convertComparisonResult(int paramInt);
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*     */     ValueEval vA;
/*     */     ValueEval vB;
/*     */     try
/*     */     {
/*  64 */       vA = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/*  65 */       vB = OperandResolver.getSingleValue(arg1, srcRowIndex, srcColumnIndex);
/*     */     } catch (EvaluationException e) {
/*  67 */       return e.getErrorEval();
/*     */     }
/*  69 */     int cmpResult = doCompare(vA, vB);
/*  70 */     boolean result = convertComparisonResult(cmpResult);
/*  71 */     return BoolEval.valueOf(result);
/*     */   }
/*     */   
/*     */   private static int doCompare(ValueEval va, ValueEval vb)
/*     */   {
/*  76 */     if (va == BlankEval.instance) {
/*  77 */       return compareBlank(vb);
/*     */     }
/*  79 */     if (vb == BlankEval.instance) {
/*  80 */       return -compareBlank(va);
/*     */     }
/*     */     
/*  83 */     if ((va instanceof BoolEval)) {
/*  84 */       if ((vb instanceof BoolEval)) {
/*  85 */         BoolEval bA = (BoolEval)va;
/*  86 */         BoolEval bB = (BoolEval)vb;
/*  87 */         if (bA.getBooleanValue() == bB.getBooleanValue()) {
/*  88 */           return 0;
/*     */         }
/*  90 */         return bA.getBooleanValue() ? 1 : -1;
/*     */       }
/*  92 */       return 1;
/*     */     }
/*  94 */     if ((vb instanceof BoolEval)) {
/*  95 */       return -1;
/*     */     }
/*  97 */     if ((va instanceof StringEval)) {
/*  98 */       if ((vb instanceof StringEval)) {
/*  99 */         StringEval sA = (StringEval)va;
/* 100 */         StringEval sB = (StringEval)vb;
/* 101 */         return sA.getStringValue().compareToIgnoreCase(sB.getStringValue());
/*     */       }
/* 103 */       return 1;
/*     */     }
/* 105 */     if ((vb instanceof StringEval)) {
/* 106 */       return -1;
/*     */     }
/* 108 */     if (((va instanceof NumberEval)) && 
/* 109 */       ((vb instanceof NumberEval))) {
/* 110 */       NumberEval nA = (NumberEval)va;
/* 111 */       NumberEval nB = (NumberEval)vb;
/* 112 */       return NumberComparer.compare(nA.getNumberValue(), nB.getNumberValue());
/*     */     }
/*     */     
/* 115 */     throw new IllegalArgumentException("Bad operand types (" + va.getClass().getName() + "), (" + vb.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */   private static int compareBlank(ValueEval v)
/*     */   {
/* 120 */     if (v == BlankEval.instance) {
/* 121 */       return 0;
/*     */     }
/* 123 */     if ((v instanceof BoolEval)) {
/* 124 */       BoolEval boolEval = (BoolEval)v;
/* 125 */       return boolEval.getBooleanValue() ? -1 : 0;
/*     */     }
/* 127 */     if ((v instanceof NumberEval)) {
/* 128 */       NumberEval ne = (NumberEval)v;
/* 129 */       return NumberComparer.compare(0.0D, ne.getNumberValue());
/*     */     }
/* 131 */     if ((v instanceof StringEval)) {
/* 132 */       StringEval se = (StringEval)v;
/* 133 */       return se.getStringValue().length() < 1 ? 0 : -1;
/*     */     }
/* 135 */     throw new IllegalArgumentException("bad value class (" + v.getClass().getName() + ")");
/*     */   }
/*     */   
/* 138 */   public static final Function EqualEval = new RelationalOperationEval() {
/*     */     protected boolean convertComparisonResult(int cmpResult) {
/* 140 */       return cmpResult == 0;
/*     */     }
/*     */   };
/* 143 */   public static final Function GreaterEqualEval = new RelationalOperationEval() {
/*     */     protected boolean convertComparisonResult(int cmpResult) {
/* 145 */       return cmpResult >= 0;
/*     */     }
/*     */   };
/* 148 */   public static final Function GreaterThanEval = new RelationalOperationEval() {
/*     */     protected boolean convertComparisonResult(int cmpResult) {
/* 150 */       return cmpResult > 0;
/*     */     }
/*     */   };
/* 153 */   public static final Function LessEqualEval = new RelationalOperationEval() {
/*     */     protected boolean convertComparisonResult(int cmpResult) {
/* 155 */       return cmpResult <= 0;
/*     */     }
/*     */   };
/* 158 */   public static final Function LessThanEval = new RelationalOperationEval() {
/*     */     protected boolean convertComparisonResult(int cmpResult) {
/* 160 */       return cmpResult < 0;
/*     */     }
/*     */   };
/* 163 */   public static final Function NotEqualEval = new RelationalOperationEval() {
/*     */     protected boolean convertComparisonResult(int cmpResult) {
/* 165 */       return cmpResult != 0;
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\RelationalOperationEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */