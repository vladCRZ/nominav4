/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.Ptg;
/*    */ import org.apache.poi.hssf.record.formula.StringPtg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringEval
/*    */   implements StringValueEval
/*    */ {
/* 28 */   public static final StringEval EMPTY_INSTANCE = new StringEval("");
/*    */   private final String _value;
/*    */   
/*    */   public StringEval(Ptg ptg)
/*    */   {
/* 33 */     this(((StringPtg)ptg).getValue());
/*    */   }
/*    */   
/*    */   public StringEval(String value) {
/* 37 */     if (value == null) {
/* 38 */       throw new IllegalArgumentException("value must not be null");
/*    */     }
/* 40 */     this._value = value;
/*    */   }
/*    */   
/*    */   public String getStringValue() {
/* 44 */     return this._value;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 48 */     StringBuilder sb = new StringBuilder(64);
/* 49 */     sb.append(getClass().getName()).append(" [");
/* 50 */     sb.append(this._value);
/* 51 */     sb.append("]");
/* 52 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\StringEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */