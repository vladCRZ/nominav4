/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed2ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TwoOperandNumericOperation
/*    */   extends Fixed2ArgFunction
/*    */ {
/*    */   protected final double singleOperandEvaluate(ValueEval arg, int srcCellRow, int srcCellCol)
/*    */     throws EvaluationException
/*    */   {
/* 29 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, srcCellCol);
/* 30 */     return OperandResolver.coerceValueToDouble(ve);
/*    */   }
/*    */   
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1) {
/*    */     double result;
/* 35 */     try { double d0 = singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 36 */       double d1 = singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/* 37 */       result = evaluate(d0, d1);
/* 38 */       if (result == 0.0D)
/*    */       {
/* 40 */         if (!(this instanceof SubtractEvalClass)) {
/* 41 */           return NumberEval.ZERO;
/*    */         }
/*    */       }
/* 44 */       if ((Double.isNaN(result)) || (Double.isInfinite(result))) {
/* 45 */         return ErrorEval.NUM_ERROR;
/*    */       }
/*    */     } catch (EvaluationException e) {
/* 48 */       return e.getErrorEval();
/*    */     }
/* 50 */     return new NumberEval(result);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 55 */   public static final Function AddEval = new TwoOperandNumericOperation() {
/*    */     protected double evaluate(double d0, double d1) {
/* 57 */       return d0 + d1;
/*    */     }
/*    */   };
/* 60 */   public static final Function DivideEval = new TwoOperandNumericOperation() {
/*    */     protected double evaluate(double d0, double d1) throws EvaluationException {
/* 62 */       if (d1 == 0.0D) {
/* 63 */         throw new EvaluationException(ErrorEval.DIV_ZERO);
/*    */       }
/* 65 */       return d0 / d1;
/*    */     }
/*    */   };
/* 68 */   public static final Function MultiplyEval = new TwoOperandNumericOperation() {
/*    */     protected double evaluate(double d0, double d1) {
/* 70 */       return d0 * d1;
/*    */     }
/*    */   };
/* 73 */   public static final Function PowerEval = new TwoOperandNumericOperation() {
/*    */     protected double evaluate(double d0, double d1) {
/* 75 */       return Math.pow(d0, d1);
/*    */     }
/*    */   };
/*    */   
/*    */   protected abstract double evaluate(double paramDouble1, double paramDouble2) throws EvaluationException;
/*    */   
/*    */   private static final class SubtractEvalClass
/*    */     extends TwoOperandNumericOperation {
/* 83 */     protected double evaluate(double d0, double d1) { return d0 - d1; }
/*    */   }
/*    */   
/* 86 */   public static final Function SubtractEval = new SubtractEvalClass();
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\TwoOperandNumericOperation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */