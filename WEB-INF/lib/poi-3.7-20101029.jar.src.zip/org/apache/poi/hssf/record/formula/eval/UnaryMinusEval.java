/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed1ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnaryMinusEval
/*    */   extends Fixed1ArgFunction
/*    */ {
/* 28 */   public static final Function instance = new UnaryMinusEval();
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*    */   {
/*    */     double d;
/*    */     
/*    */     try
/*    */     {
/* 37 */       ValueEval ve = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 38 */       d = OperandResolver.coerceValueToDouble(ve);
/*    */     } catch (EvaluationException e) {
/* 40 */       return e.getErrorEval();
/*    */     }
/* 42 */     if (d == 0.0D) {
/* 43 */       return NumberEval.ZERO;
/*    */     }
/* 45 */     return new NumberEval(-d);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\UnaryMinusEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */