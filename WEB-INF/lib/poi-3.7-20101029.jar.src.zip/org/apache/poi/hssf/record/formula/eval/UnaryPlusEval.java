/*    */ package org.apache.poi.hssf.record.formula.eval;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.functions.Fixed1ArgFunction;
/*    */ import org.apache.poi.hssf.record.formula.functions.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnaryPlusEval
/*    */   extends Fixed1ArgFunction
/*    */ {
/* 29 */   public static final Function instance = new UnaryPlusEval();
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcCellRow, int srcCellCol, ValueEval arg0)
/*    */   {
/*    */     double d;
/*    */     
/*    */     try
/*    */     {
/* 38 */       ValueEval ve = OperandResolver.getSingleValue(arg0, srcCellRow, srcCellCol);
/* 39 */       if ((ve instanceof StringEval))
/*    */       {
/*    */ 
/*    */ 
/* 43 */         return ve;
/*    */       }
/* 45 */       d = OperandResolver.coerceValueToDouble(ve);
/*    */     } catch (EvaluationException e) {
/* 47 */       return e.getErrorEval();
/*    */     }
/* 49 */     return new NumberEval(d);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\eval\UnaryPlusEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */