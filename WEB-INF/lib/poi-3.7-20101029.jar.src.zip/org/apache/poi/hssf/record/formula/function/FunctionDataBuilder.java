/*    */ package org.apache.poi.hssf.record.formula.function;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FunctionDataBuilder
/*    */ {
/*    */   private int _maxFunctionIndex;
/*    */   private final Map _functionDataByName;
/*    */   private final Map _functionDataByIndex;
/*    */   private final Set _mutatingFunctionIndexes;
/*    */   
/*    */   public FunctionDataBuilder(int sizeEstimate)
/*    */   {
/* 39 */     this._maxFunctionIndex = -1;
/* 40 */     this._functionDataByName = new HashMap(sizeEstimate * 3 / 2);
/* 41 */     this._functionDataByIndex = new HashMap(sizeEstimate * 3 / 2);
/* 42 */     this._mutatingFunctionIndexes = new HashSet();
/*    */   }
/*    */   
/*    */   public void add(int functionIndex, String functionName, int minParams, int maxParams, byte returnClassCode, byte[] parameterClassCodes, boolean hasFootnote)
/*    */   {
/* 47 */     FunctionMetadata fm = new FunctionMetadata(functionIndex, functionName, minParams, maxParams, returnClassCode, parameterClassCodes);
/*    */     
/*    */ 
/* 50 */     Integer indexKey = Integer.valueOf(functionIndex);
/*    */     
/*    */ 
/* 53 */     if (functionIndex > this._maxFunctionIndex) {
/* 54 */       this._maxFunctionIndex = functionIndex;
/*    */     }
/*    */     
/*    */ 
/* 58 */     FunctionMetadata prevFM = (FunctionMetadata)this._functionDataByName.get(functionName);
/* 59 */     if (prevFM != null) {
/* 60 */       if ((!hasFootnote) || (!this._mutatingFunctionIndexes.contains(indexKey))) {
/* 61 */         throw new RuntimeException("Multiple entries for function name '" + functionName + "'");
/*    */       }
/* 63 */       this._functionDataByIndex.remove(Integer.valueOf(prevFM.getIndex()));
/*    */     }
/* 65 */     prevFM = (FunctionMetadata)this._functionDataByIndex.get(indexKey);
/* 66 */     if (prevFM != null) {
/* 67 */       if ((!hasFootnote) || (!this._mutatingFunctionIndexes.contains(indexKey))) {
/* 68 */         throw new RuntimeException("Multiple entries for function index (" + functionIndex + ")");
/*    */       }
/* 70 */       this._functionDataByName.remove(prevFM.getName());
/*    */     }
/* 72 */     if (hasFootnote) {
/* 73 */       this._mutatingFunctionIndexes.add(indexKey);
/*    */     }
/* 75 */     this._functionDataByIndex.put(indexKey, fm);
/* 76 */     this._functionDataByName.put(functionName, fm);
/*    */   }
/*    */   
/*    */   public FunctionMetadataRegistry build()
/*    */   {
/* 81 */     FunctionMetadata[] jumbledArray = new FunctionMetadata[this._functionDataByName.size()];
/* 82 */     this._functionDataByName.values().toArray(jumbledArray);
/* 83 */     FunctionMetadata[] fdIndexArray = new FunctionMetadata[this._maxFunctionIndex + 1];
/* 84 */     for (int i = 0; i < jumbledArray.length; i++) {
/* 85 */       FunctionMetadata fd = jumbledArray[i];
/* 86 */       fdIndexArray[fd.getIndex()] = fd;
/*    */     }
/*    */     
/* 89 */     return new FunctionMetadataRegistry(fdIndexArray, this._functionDataByName);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\function\FunctionDataBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */