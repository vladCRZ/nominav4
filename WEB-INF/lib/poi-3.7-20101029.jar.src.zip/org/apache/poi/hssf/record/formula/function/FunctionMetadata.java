/*    */ package org.apache.poi.hssf.record.formula.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FunctionMetadata
/*    */ {
/*    */   private static final short FUNCTION_MAX_PARAMS = 30;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final int _index;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String _name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final int _minParams;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final int _maxParams;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final byte _returnClassCode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final byte[] _parameterClassCodes;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   FunctionMetadata(int index, String name, int minParams, int maxParams, byte returnClassCode, byte[] parameterClassCodes)
/*    */   {
/* 47 */     this._index = index;
/* 48 */     this._name = name;
/* 49 */     this._minParams = minParams;
/* 50 */     this._maxParams = maxParams;
/* 51 */     this._returnClassCode = returnClassCode;
/* 52 */     this._parameterClassCodes = parameterClassCodes;
/*    */   }
/*    */   
/* 55 */   public int getIndex() { return this._index; }
/*    */   
/*    */   public String getName() {
/* 58 */     return this._name;
/*    */   }
/*    */   
/* 61 */   public int getMinParams() { return this._minParams; }
/*    */   
/*    */   public int getMaxParams() {
/* 64 */     return this._maxParams;
/*    */   }
/*    */   
/* 67 */   public boolean hasFixedArgsLength() { return this._minParams == this._maxParams; }
/*    */   
/*    */   public byte getReturnClassCode() {
/* 70 */     return this._returnClassCode;
/*    */   }
/*    */   
/* 73 */   public byte[] getParameterClassCodes() { return (byte[])this._parameterClassCodes.clone(); }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 83 */   public boolean hasUnlimitedVarags() { return 30 == this._maxParams; }
/*    */   
/*    */   public String toString() {
/* 86 */     StringBuffer sb = new StringBuffer(64);
/* 87 */     sb.append(getClass().getName()).append(" [");
/* 88 */     sb.append(this._index).append(" ").append(this._name);
/* 89 */     sb.append("]");
/* 90 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\function\FunctionMetadata.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */