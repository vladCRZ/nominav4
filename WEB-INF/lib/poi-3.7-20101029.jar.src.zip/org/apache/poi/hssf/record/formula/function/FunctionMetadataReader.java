/*     */ package org.apache.poi.hssf.record.formula.function;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FunctionMetadataReader
/*     */ {
/*     */   private static final String METADATA_FILE_NAME = "functionMetadata.txt";
/*     */   private static final String ELLIPSIS = "...";
/*  44 */   private static final Pattern TAB_DELIM_PATTERN = Pattern.compile("\t");
/*  45 */   private static final Pattern SPACE_DELIM_PATTERN = Pattern.compile(" ");
/*  46 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   
/*  48 */   private static final String[] DIGIT_ENDING_FUNCTION_NAMES = { "LOG10", "ATAN2", "DAYS360", "SUMXMY2", "SUMX2MY2", "SUMX2PY2" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private static final Set DIGIT_ENDING_FUNCTION_NAMES_SET = new HashSet(Arrays.asList(DIGIT_ENDING_FUNCTION_NAMES));
/*     */   
/*     */   public static FunctionMetadataRegistry createRegistry() {
/*  56 */     InputStream is = FunctionMetadataReader.class.getResourceAsStream("functionMetadata.txt");
/*  57 */     if (is == null) {
/*  58 */       throw new RuntimeException("resource 'functionMetadata.txt' not found");
/*     */     }
/*     */     BufferedReader br;
/*     */     try
/*     */     {
/*  63 */       br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/*     */     } catch (UnsupportedEncodingException e) {
/*  65 */       throw new RuntimeException(e);
/*     */     }
/*  67 */     FunctionDataBuilder fdb = new FunctionDataBuilder(400);
/*     */     try
/*     */     {
/*     */       for (;;) {
/*  71 */         String line = br.readLine();
/*  72 */         if (line == null) {
/*     */           break;
/*     */         }
/*  75 */         if ((line.length() >= 1) && (line.charAt(0) != '#'))
/*     */         {
/*     */ 
/*  78 */           String trimLine = line.trim();
/*  79 */           if (trimLine.length() >= 1)
/*     */           {
/*     */ 
/*  82 */             processLine(fdb, line); }
/*     */         } }
/*  84 */       br.close();
/*     */     } catch (IOException e) {
/*  86 */       throw new RuntimeException(e);
/*     */     }
/*     */     
/*  89 */     return fdb.build();
/*     */   }
/*     */   
/*     */   private static void processLine(FunctionDataBuilder fdb, String line)
/*     */   {
/*  94 */     String[] parts = TAB_DELIM_PATTERN.split(line, -2);
/*  95 */     if (parts.length != 8) {
/*  96 */       throw new RuntimeException("Bad line format '" + line + "' - expected 8 data fields");
/*     */     }
/*  98 */     int functionIndex = parseInt(parts[0]);
/*  99 */     String functionName = parts[1];
/* 100 */     int minParams = parseInt(parts[2]);
/* 101 */     int maxParams = parseInt(parts[3]);
/* 102 */     byte returnClassCode = parseReturnTypeCode(parts[4]);
/* 103 */     byte[] parameterClassCodes = parseOperandTypeCodes(parts[5]);
/*     */     
/* 105 */     boolean hasNote = parts[7].length() > 0;
/*     */     
/* 107 */     validateFunctionName(functionName);
/*     */     
/* 109 */     fdb.add(functionIndex, functionName, minParams, maxParams, returnClassCode, parameterClassCodes, hasNote);
/*     */   }
/*     */   
/*     */ 
/*     */   private static byte parseReturnTypeCode(String code)
/*     */   {
/* 115 */     if (code.length() == 0) {
/* 116 */       return 0;
/*     */     }
/* 118 */     return parseOperandTypeCode(code);
/*     */   }
/*     */   
/*     */   private static byte[] parseOperandTypeCodes(String codes) {
/* 122 */     if (codes.length() < 1) {
/* 123 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 125 */     if (isDash(codes))
/*     */     {
/* 127 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/* 129 */     String[] array = SPACE_DELIM_PATTERN.split(codes);
/* 130 */     int nItems = array.length;
/* 131 */     if ("...".equals(array[(nItems - 1)]))
/*     */     {
/*     */ 
/* 134 */       nItems--;
/*     */     }
/* 136 */     byte[] result = new byte[nItems];
/* 137 */     for (int i = 0; i < nItems; i++) {
/* 138 */       result[i] = parseOperandTypeCode(array[i]);
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */   
/*     */   private static boolean isDash(String codes) {
/* 144 */     if (codes.length() == 1) {
/* 145 */       switch (codes.charAt(0)) {
/*     */       case '-': 
/* 147 */         return true;
/*     */       }
/*     */     }
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   private static byte parseOperandTypeCode(String code) {
/* 154 */     if (code.length() != 1) {
/* 155 */       throw new RuntimeException("Bad operand type code format '" + code + "' expected single char");
/*     */     }
/* 157 */     switch (code.charAt(0)) {
/* 158 */     case 'V':  return 32;
/* 159 */     case 'R':  return 0;
/* 160 */     case 'A':  return 64;
/*     */     }
/* 162 */     throw new IllegalArgumentException("Unexpected operand type code '" + code + "' (" + code.charAt(0) + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void validateFunctionName(String functionName)
/*     */   {
/* 170 */     int len = functionName.length();
/* 171 */     int ix = len - 1;
/* 172 */     if (!Character.isDigit(functionName.charAt(ix))) {
/* 173 */       return;
/*     */     }
/* 175 */     while ((ix >= 0) && 
/* 176 */       (Character.isDigit(functionName.charAt(ix))))
/*     */     {
/*     */ 
/* 179 */       ix--;
/*     */     }
/* 181 */     if (DIGIT_ENDING_FUNCTION_NAMES_SET.contains(functionName)) {
/* 182 */       return;
/*     */     }
/* 184 */     throw new RuntimeException("Invalid function name '" + functionName + "' (is footnote number incorrectly appended)");
/*     */   }
/*     */   
/*     */   private static int parseInt(String valStr)
/*     */   {
/*     */     try {
/* 190 */       return Integer.parseInt(valStr);
/*     */     } catch (NumberFormatException e) {
/* 192 */       throw new RuntimeException("Value '" + valStr + "' could not be parsed as an integer");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\function\FunctionMetadataReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */