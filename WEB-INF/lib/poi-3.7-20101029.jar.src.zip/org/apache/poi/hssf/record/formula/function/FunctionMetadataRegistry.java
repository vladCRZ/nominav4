/*    */ package org.apache.poi.hssf.record.formula.function;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FunctionMetadataRegistry
/*    */ {
/*    */   public static final String FUNCTION_NAME_IF = "IF";
/*    */   public static final int FUNCTION_INDEX_IF = 1;
/*    */   public static final short FUNCTION_INDEX_SUM = 4;
/*    */   public static final int FUNCTION_INDEX_CHOOSE = 100;
/*    */   public static final short FUNCTION_INDEX_INDIRECT = 148;
/*    */   public static final short FUNCTION_INDEX_EXTERNAL = 255;
/*    */   private static FunctionMetadataRegistry _instance;
/*    */   private final FunctionMetadata[] _functionDataByIndex;
/*    */   private final Map<String, FunctionMetadata> _functionDataByName;
/*    */   
/*    */   private static FunctionMetadataRegistry getInstance()
/*    */   {
/* 45 */     if (_instance == null) {
/* 46 */       _instance = FunctionMetadataReader.createRegistry();
/*    */     }
/* 48 */     return _instance;
/*    */   }
/*    */   
/*    */   FunctionMetadataRegistry(FunctionMetadata[] functionDataByIndex, Map<String, FunctionMetadata> functionDataByName) {
/* 52 */     this._functionDataByIndex = functionDataByIndex;
/* 53 */     this._functionDataByName = functionDataByName;
/*    */   }
/*    */   
/*    */   Set<String> getAllFunctionNames() {
/* 57 */     return this._functionDataByName.keySet();
/*    */   }
/*    */   
/*    */   public static FunctionMetadata getFunctionByIndex(int index)
/*    */   {
/* 62 */     return getInstance().getFunctionByIndexInternal(index);
/*    */   }
/*    */   
/*    */   private FunctionMetadata getFunctionByIndexInternal(int index) {
/* 66 */     return this._functionDataByIndex[index];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static short lookupIndexByName(String name)
/*    */   {
/* 75 */     FunctionMetadata fd = getInstance().getFunctionByNameInternal(name);
/* 76 */     if (fd == null) {
/* 77 */       return -1;
/*    */     }
/* 79 */     return (short)fd.getIndex();
/*    */   }
/*    */   
/*    */   private FunctionMetadata getFunctionByNameInternal(String name) {
/* 83 */     return (FunctionMetadata)this._functionDataByName.get(name);
/*    */   }
/*    */   
/*    */   public static FunctionMetadata getFunctionByName(String name)
/*    */   {
/* 88 */     return getInstance().getFunctionByNameInternal(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\function\FunctionMetadataRegistry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */