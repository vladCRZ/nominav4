/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AggregateFunction
/*     */   extends MultiOperandNumericFunction
/*     */ {
/*     */   private static final class LargeSmall
/*     */     extends Fixed2ArgFunction
/*     */   {
/*     */     private final boolean _isLarge;
/*     */     
/*     */     protected LargeSmall(boolean isLarge)
/*     */     {
/*  34 */       this._isLarge = isLarge;
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */     {
/*     */       double dn;
/*     */       try {
/*  41 */         ValueEval ve1 = OperandResolver.getSingleValue(arg1, srcRowIndex, srcColumnIndex);
/*  42 */         dn = OperandResolver.coerceValueToDouble(ve1);
/*     */       }
/*     */       catch (EvaluationException e1) {
/*  45 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*     */       
/*  48 */       if (dn < 1.0D)
/*     */       {
/*  50 */         return ErrorEval.NUM_ERROR;
/*     */       }
/*     */       
/*  53 */       int k = (int)Math.ceil(dn);
/*     */       double result;
/*     */       try
/*     */       {
/*  57 */         double[] ds = AggregateFunction.ValueCollector.collectValues(new ValueEval[] { arg0 });
/*  58 */         if (k > ds.length) {
/*  59 */           return ErrorEval.NUM_ERROR;
/*     */         }
/*  61 */         result = this._isLarge ? StatsLib.kthLargest(ds, k) : StatsLib.kthSmallest(ds, k);
/*  62 */         NumericFunction.checkValue(result);
/*     */       } catch (EvaluationException e) {
/*  64 */         return e.getErrorEval();
/*     */       }
/*     */       
/*  67 */       return new NumberEval(result);
/*     */     }
/*     */   }
/*     */   
/*  71 */   private static final class ValueCollector extends MultiOperandNumericFunction { private static final ValueCollector instance = new ValueCollector();
/*     */     
/*  73 */     public ValueCollector() { super(false); }
/*     */     
/*     */     public static double[] collectValues(ValueEval... operands) throws EvaluationException {
/*  76 */       return instance.getNumberArray(operands);
/*     */     }
/*     */     
/*  79 */     protected double evaluate(double[] values) { throw new IllegalStateException("should not be called"); }
/*     */   }
/*     */   
/*     */   protected AggregateFunction()
/*     */   {
/*  84 */     super(false, false);
/*     */   }
/*     */   
/*  87 */   public static final Function AVEDEV = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/*  89 */       return StatsLib.avedev(values);
/*     */     }
/*     */   };
/*  92 */   public static final Function AVERAGE = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) throws EvaluationException {
/*  94 */       if (values.length < 1) {
/*  95 */         throw new EvaluationException(ErrorEval.DIV_ZERO);
/*     */       }
/*  97 */       return MathX.average(values);
/*     */     }
/*     */   };
/* 100 */   public static final Function DEVSQ = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 102 */       return StatsLib.devsq(values);
/*     */     }
/*     */   };
/* 105 */   public static final Function LARGE = new LargeSmall(true);
/* 106 */   public static final Function MAX = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 108 */       return values.length > 0 ? MathX.max(values) : 0.0D;
/*     */     }
/*     */   };
/* 111 */   public static final Function MEDIAN = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 113 */       return StatsLib.median(values);
/*     */     }
/*     */   };
/* 116 */   public static final Function MIN = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 118 */       return values.length > 0 ? MathX.min(values) : 0.0D;
/*     */     }
/*     */   };
/* 121 */   public static final Function PRODUCT = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 123 */       return MathX.product(values);
/*     */     }
/*     */   };
/* 126 */   public static final Function SMALL = new LargeSmall(false);
/* 127 */   public static final Function STDEV = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) throws EvaluationException {
/* 129 */       if (values.length < 1) {
/* 130 */         throw new EvaluationException(ErrorEval.DIV_ZERO);
/*     */       }
/* 132 */       return StatsLib.stdev(values);
/*     */     }
/*     */   };
/* 135 */   public static final Function SUM = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 137 */       return MathX.sum(values);
/*     */     }
/*     */   };
/* 140 */   public static final Function SUMSQ = new AggregateFunction() {
/*     */     protected double evaluate(double[] values) {
/* 142 */       return MathX.sumsq(values);
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\AggregateFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */