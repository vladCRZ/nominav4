/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BooleanFunction
/*     */   implements Function
/*     */ {
/*     */   public final ValueEval evaluate(ValueEval[] args, int srcRow, int srcCol)
/*     */   {
/*  42 */     if (args.length < 1) {
/*  43 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*     */     boolean boolResult;
/*     */     try {
/*  47 */       boolResult = calculate(args);
/*     */     } catch (EvaluationException e) {
/*  49 */       return e.getErrorEval();
/*     */     }
/*  51 */     return BoolEval.valueOf(boolResult);
/*     */   }
/*     */   
/*     */   private boolean calculate(ValueEval[] args) throws EvaluationException
/*     */   {
/*  56 */     boolean result = getInitialResultValue();
/*  57 */     boolean atleastOneNonBlank = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  62 */     int i = 0; for (int iSize = args.length; i < iSize; i++) {
/*  63 */       ValueEval arg = args[i];
/*  64 */       if ((arg instanceof TwoDEval)) {
/*  65 */         TwoDEval ae = (TwoDEval)arg;
/*  66 */         int height = ae.getHeight();
/*  67 */         int width = ae.getWidth();
/*  68 */         for (int rrIx = 0; rrIx < height; rrIx++) {
/*  69 */           for (int rcIx = 0; rcIx < width; rcIx++) {
/*  70 */             ValueEval ve = ae.getValue(rrIx, rcIx);
/*  71 */             Boolean tempVe = OperandResolver.coerceValueToBoolean(ve, true);
/*  72 */             if (tempVe != null) {
/*  73 */               result = partialEvaluate(result, tempVe.booleanValue());
/*  74 */               atleastOneNonBlank = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/*     */         Boolean tempVe;
/*     */         Boolean tempVe;
/*  81 */         if ((arg instanceof RefEval)) {
/*  82 */           ValueEval ve = ((RefEval)arg).getInnerValueEval();
/*  83 */           tempVe = OperandResolver.coerceValueToBoolean(ve, true);
/*     */         } else {
/*  85 */           tempVe = OperandResolver.coerceValueToBoolean(arg, false);
/*     */         }
/*     */         
/*     */ 
/*  89 */         if (tempVe != null) {
/*  90 */           result = partialEvaluate(result, tempVe.booleanValue());
/*  91 */           atleastOneNonBlank = true;
/*     */         }
/*     */       }
/*     */     }
/*  95 */     if (!atleastOneNonBlank) {
/*  96 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/*  98 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */   public static final Function AND = new BooleanFunction() {
/*     */     protected boolean getInitialResultValue() {
/* 108 */       return true;
/*     */     }
/*     */     
/* 111 */     protected boolean partialEvaluate(boolean cumulativeResult, boolean currentValue) { return (cumulativeResult) && (currentValue); }
/*     */   };
/*     */   
/* 114 */   public static final Function OR = new BooleanFunction() {
/*     */     protected boolean getInitialResultValue() {
/* 116 */       return false;
/*     */     }
/*     */     
/* 119 */     protected boolean partialEvaluate(boolean cumulativeResult, boolean currentValue) { return (cumulativeResult) || (currentValue); }
/*     */   };
/*     */   
/* 122 */   public static final Function FALSE = new Fixed0ArgFunction() {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex) {
/* 124 */       return BoolEval.FALSE;
/*     */     }
/*     */   };
/* 127 */   public static final Function TRUE = new Fixed0ArgFunction() {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex) {
/* 129 */       return BoolEval.TRUE;
/*     */     }
/*     */   };
/* 132 */   public static final Function NOT = new Fixed1ArgFunction() {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/*     */       boolean boolArgVal;
/*     */       try {
/* 136 */         ValueEval ve = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 137 */         Boolean b = OperandResolver.coerceValueToBoolean(ve, false);
/* 138 */         boolArgVal = b == null ? false : b.booleanValue();
/*     */       } catch (EvaluationException e) {
/* 140 */         return e.getErrorEval();
/*     */       }
/*     */       
/* 143 */       return BoolEval.valueOf(!boolArgVal);
/*     */     }
/*     */   };
/*     */   
/*     */   protected abstract boolean getInitialResultValue();
/*     */   
/*     */   protected abstract boolean partialEvaluate(boolean paramBoolean1, boolean paramBoolean2);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\BooleanFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */