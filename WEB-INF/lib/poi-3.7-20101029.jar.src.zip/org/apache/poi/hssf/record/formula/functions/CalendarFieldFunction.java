/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.GregorianCalendar;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.hssf.usermodel.HSSFDateUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CalendarFieldFunction
/*    */   extends Fixed1ArgFunction
/*    */ {
/* 39 */   public static final Function YEAR = new CalendarFieldFunction(1, false);
/* 40 */   public static final Function MONTH = new CalendarFieldFunction(2, true);
/* 41 */   public static final Function DAY = new CalendarFieldFunction(5, false);
/*    */   private final int _dateFieldId;
/*    */   private final boolean _needsOneBaseAdjustment;
/*    */   
/*    */   private CalendarFieldFunction(int dateFieldId, boolean needsOneBaseAdjustment)
/*    */   {
/* 47 */     this._dateFieldId = dateFieldId;
/* 48 */     this._needsOneBaseAdjustment = needsOneBaseAdjustment;
/*    */   }
/*    */   
/*    */   public final ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/*    */     int val;
/*    */     try {
/* 54 */       ValueEval ve = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 55 */       val = OperandResolver.coerceValueToInt(ve);
/*    */     } catch (EvaluationException e) {
/* 57 */       return e.getErrorEval();
/*    */     }
/* 59 */     if (val < 0) {
/* 60 */       return ErrorEval.NUM_ERROR;
/*    */     }
/* 62 */     return new NumberEval(getCalField(val));
/*    */   }
/*    */   
/*    */   private int getCalField(int serialDay) {
/* 66 */     if (serialDay == 0)
/*    */     {
/*    */ 
/* 69 */       switch (this._dateFieldId) {
/* 70 */       case 1:  return 1900;
/* 71 */       case 2:  return 1;
/* 72 */       case 5:  return 0;
/*    */       }
/* 74 */       throw new IllegalStateException("bad date field " + this._dateFieldId);
/*    */     }
/* 76 */     Date d = HSSFDateUtil.getJavaDate(serialDay, false);
/*    */     
/* 78 */     Calendar c = new GregorianCalendar();
/* 79 */     c.setTime(d);
/*    */     
/* 81 */     int result = c.get(this._dateFieldId);
/* 82 */     if (this._needsOneBaseAdjustment) {
/* 83 */       result++;
/*    */     }
/* 85 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\CalendarFieldFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */