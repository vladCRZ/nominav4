/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.MissingArgEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Choose
/*    */   implements Function
/*    */ {
/*    */   public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 33 */     if (args.length < 2) {
/* 34 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     try
/*    */     {
/* 38 */       int ix = evaluateFirstArg(args[0], srcRowIndex, srcColumnIndex);
/* 39 */       if ((ix < 1) || (ix >= args.length)) {
/* 40 */         return ErrorEval.VALUE_INVALID;
/*    */       }
/* 42 */       ValueEval result = OperandResolver.getSingleValue(args[ix], srcRowIndex, srcColumnIndex);
/* 43 */       if (result == MissingArgEval.instance) {
/* 44 */         return BlankEval.instance;
/*    */       }
/* 46 */       return result;
/*    */     } catch (EvaluationException e) {
/* 48 */       return e.getErrorEval();
/*    */     }
/*    */   }
/*    */   
/*    */   public static int evaluateFirstArg(ValueEval arg0, int srcRowIndex, int srcColumnIndex) throws EvaluationException
/*    */   {
/* 54 */     ValueEval ev = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 55 */     return OperandResolver.coerceValueToInt(ev);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Choose.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */