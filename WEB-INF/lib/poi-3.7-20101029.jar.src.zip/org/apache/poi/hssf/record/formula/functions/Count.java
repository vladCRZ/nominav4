/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.MissingArgEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Count
/*    */   implements Function
/*    */ {
/*    */   public ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol)
/*    */   {
/* 40 */     int nArgs = args.length;
/* 41 */     if (nArgs < 1)
/*    */     {
/* 43 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     
/* 46 */     if (nArgs > 30)
/*    */     {
/* 48 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     
/* 51 */     int temp = 0;
/*    */     
/* 53 */     for (int i = 0; i < nArgs; i++) {
/* 54 */       temp += CountUtils.countArg(args[i], predicate);
/*    */     }
/*    */     
/* 57 */     return new NumberEval(temp);
/*    */   }
/*    */   
/* 60 */   private static final CountUtils.I_MatchPredicate predicate = new CountUtils.I_MatchPredicate()
/*    */   {
/*    */     public boolean matches(ValueEval valueEval)
/*    */     {
/* 64 */       if ((valueEval instanceof NumberEval))
/*    */       {
/* 66 */         return true;
/*    */       }
/* 68 */       if (valueEval == MissingArgEval.instance)
/*    */       {
/* 70 */         return true;
/*    */       }
/*    */       
/*    */ 
/* 74 */       return false;
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Count.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */