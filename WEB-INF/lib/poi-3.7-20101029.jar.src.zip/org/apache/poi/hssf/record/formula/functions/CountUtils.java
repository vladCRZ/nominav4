/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.TwoDEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CountUtils
/*    */ {
/*    */   public static int countMatchingCellsInArea(TwoDEval areaEval, I_MatchPredicate criteriaPredicate)
/*    */   {
/* 45 */     int result = 0;
/*    */     
/* 47 */     int height = areaEval.getHeight();
/* 48 */     int width = areaEval.getWidth();
/* 49 */     for (int rrIx = 0; rrIx < height; rrIx++) {
/* 50 */       for (int rcIx = 0; rcIx < width; rcIx++) {
/* 51 */         ValueEval ve = areaEval.getValue(rrIx, rcIx);
/* 52 */         if (criteriaPredicate.matches(ve)) {
/* 53 */           result++;
/*    */         }
/*    */       }
/*    */     }
/* 57 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public static int countMatchingCell(RefEval refEval, I_MatchPredicate criteriaPredicate)
/*    */   {
/* 63 */     if (criteriaPredicate.matches(refEval.getInnerValueEval())) {
/* 64 */       return 1;
/*    */     }
/* 66 */     return 0;
/*    */   }
/*    */   
/* 69 */   public static int countArg(ValueEval eval, I_MatchPredicate criteriaPredicate) { if (eval == null) {
/* 70 */       throw new IllegalArgumentException("eval must not be null");
/*    */     }
/* 72 */     if ((eval instanceof TwoDEval)) {
/* 73 */       return countMatchingCellsInArea((TwoDEval)eval, criteriaPredicate);
/*    */     }
/* 75 */     if ((eval instanceof RefEval)) {
/* 76 */       return countMatchingCell((RefEval)eval, criteriaPredicate);
/*    */     }
/* 78 */     return criteriaPredicate.matches(eval) ? 1 : 0;
/*    */   }
/*    */   
/*    */   public static abstract interface I_MatchPredicate
/*    */   {
/*    */     public abstract boolean matches(ValueEval paramValueEval);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\CountUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */