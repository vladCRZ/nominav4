/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Counta
/*    */   implements Function
/*    */ {
/*    */   public ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol)
/*    */   {
/* 38 */     int nArgs = args.length;
/* 39 */     if (nArgs < 1)
/*    */     {
/* 41 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     
/* 44 */     if (nArgs > 30)
/*    */     {
/* 46 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     
/* 49 */     int temp = 0;
/*    */     
/* 51 */     for (int i = 0; i < nArgs; i++) {
/* 52 */       temp += CountUtils.countArg(args[i], predicate);
/*    */     }
/*    */     
/* 55 */     return new NumberEval(temp);
/*    */   }
/*    */   
/* 58 */   private static final CountUtils.I_MatchPredicate predicate = new CountUtils.I_MatchPredicate()
/*    */   {
/*    */ 
/*    */ 
/*    */     public boolean matches(ValueEval valueEval)
/*    */     {
/*    */ 
/* 65 */       if (valueEval == BlankEval.instance) {
/* 66 */         return false;
/*    */       }
/*    */       
/* 69 */       return true;
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Counta.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */