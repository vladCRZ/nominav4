/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.TwoDEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Countblank
/*    */   extends Fixed1ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*    */   {
/*    */     double result;
/* 43 */     if ((arg0 instanceof RefEval)) {
/* 44 */       result = CountUtils.countMatchingCell((RefEval)arg0, predicate); } else { double result;
/* 45 */       if ((arg0 instanceof TwoDEval)) {
/* 46 */         result = CountUtils.countMatchingCellsInArea((TwoDEval)arg0, predicate);
/*    */       } else
/* 48 */         throw new IllegalArgumentException("Bad range arg type (" + arg0.getClass().getName() + ")"); }
/*    */     double result;
/* 50 */     return new NumberEval(result);
/*    */   }
/*    */   
/* 53 */   private static final CountUtils.I_MatchPredicate predicate = new CountUtils.I_MatchPredicate()
/*    */   {
/*    */     public boolean matches(ValueEval valueEval)
/*    */     {
/* 57 */       return valueEval == BlankEval.instance;
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Countblank.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */