/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ import org.apache.poi.ss.usermodel.ErrorConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Countif
/*     */   extends Fixed2ArgFunction
/*     */ {
/*     */   private static final class CmpOp
/*     */   {
/*     */     public static final int NONE = 0;
/*     */     public static final int EQ = 1;
/*     */     public static final int NE = 2;
/*     */     public static final int LE = 3;
/*     */     public static final int LT = 4;
/*     */     public static final int GT = 5;
/*     */     public static final int GE = 6;
/*  58 */     public static final CmpOp OP_NONE = op("", 0);
/*  59 */     public static final CmpOp OP_EQ = op("=", 1);
/*  60 */     public static final CmpOp OP_NE = op("<>", 2);
/*  61 */     public static final CmpOp OP_LE = op("<=", 3);
/*  62 */     public static final CmpOp OP_LT = op("<", 4);
/*  63 */     public static final CmpOp OP_GT = op(">", 5);
/*  64 */     public static final CmpOp OP_GE = op(">=", 6);
/*     */     
/*     */     private final String _representation;
/*     */     private final int _code;
/*     */     
/*  69 */     private static CmpOp op(String rep, int code) { return new CmpOp(rep, code); }
/*     */     
/*     */     private CmpOp(String representation, int code) {
/*  72 */       this._representation = representation;
/*  73 */       this._code = code;
/*     */     }
/*     */     
/*     */ 
/*     */     public int getLength()
/*     */     {
/*  79 */       return this._representation.length();
/*     */     }
/*     */     
/*  82 */     public int getCode() { return this._code; }
/*     */     
/*     */     public static CmpOp getOperator(String value) {
/*  85 */       int len = value.length();
/*  86 */       if (len < 1) {
/*  87 */         return OP_NONE;
/*     */       }
/*     */       
/*  90 */       char firstChar = value.charAt(0);
/*     */       
/*  92 */       switch (firstChar) {
/*     */       case '=': 
/*  94 */         return OP_EQ;
/*     */       case '>': 
/*  96 */         if (len > 1) {
/*  97 */           switch (value.charAt(1)) {
/*     */           case '=': 
/*  99 */             return OP_GE;
/*     */           }
/*     */         }
/* 102 */         return OP_GT;
/*     */       case '<': 
/* 104 */         if (len > 1) {
/* 105 */           switch (value.charAt(1)) {
/*     */           case '=': 
/* 107 */             return OP_LE;
/*     */           case '>': 
/* 109 */             return OP_NE;
/*     */           }
/*     */         }
/* 112 */         return OP_LT;
/*     */       }
/* 114 */       return OP_NONE;
/*     */     }
/*     */     
/* 117 */     public boolean evaluate(boolean cmpResult) { switch (this._code) {
/*     */       case 0: 
/*     */       case 1: 
/* 120 */         return cmpResult;
/*     */       case 2: 
/* 122 */         return !cmpResult;
/*     */       }
/* 124 */       throw new RuntimeException("Cannot call boolean evaluate on non-equality operator '" + this._representation + "'");
/*     */     }
/*     */     
/*     */     public boolean evaluate(int cmpResult) {
/* 128 */       switch (this._code) {
/*     */       case 0: 
/*     */       case 1: 
/* 131 */         return cmpResult == 0;
/* 132 */       case 2:  return cmpResult != 0;
/* 133 */       case 4:  return cmpResult < 0;
/* 134 */       case 3:  return cmpResult <= 0;
/* 135 */       case 5:  return cmpResult > 0;
/* 136 */       case 6:  return cmpResult <= 0;
/*     */       }
/* 138 */       throw new RuntimeException("Cannot call boolean evaluate on non-equality operator '" + this._representation + "'");
/*     */     }
/*     */     
/*     */     public String toString() {
/* 142 */       StringBuffer sb = new StringBuffer(64);
/* 143 */       sb.append(getClass().getName());
/* 144 */       sb.append(" [").append(this._representation).append("]");
/* 145 */       return sb.toString();
/*     */     }
/*     */     
/* 148 */     public String getRepresentation() { return this._representation; }
/*     */   }
/*     */   
/*     */   private static abstract class MatcherBase implements CountUtils.I_MatchPredicate
/*     */   {
/*     */     private final Countif.CmpOp _operator;
/*     */     
/*     */     MatcherBase(Countif.CmpOp operator) {
/* 156 */       this._operator = operator;
/*     */     }
/*     */     
/* 159 */     protected final int getCode() { return this._operator.getCode(); }
/*     */     
/*     */     protected final boolean evaluate(int cmpResult) {
/* 162 */       return this._operator.evaluate(cmpResult);
/*     */     }
/*     */     
/* 165 */     protected final boolean evaluate(boolean cmpResult) { return this._operator.evaluate(cmpResult); }
/*     */     
/*     */     public final String toString()
/*     */     {
/* 169 */       StringBuffer sb = new StringBuffer(64);
/* 170 */       sb.append(getClass().getName()).append(" [");
/* 171 */       sb.append(this._operator.getRepresentation());
/* 172 */       sb.append(getValueText());
/* 173 */       sb.append("]");
/* 174 */       return sb.toString();
/*     */     }
/*     */     
/*     */     protected abstract String getValueText();
/*     */   }
/*     */   
/*     */   private static final class NumberMatcher extends Countif.MatcherBase {
/*     */     private final double _value;
/*     */     
/*     */     public NumberMatcher(double value, Countif.CmpOp operator) {
/* 184 */       super();
/* 185 */       this._value = value;
/*     */     }
/*     */     
/*     */     protected String getValueText() {
/* 189 */       return String.valueOf(this._value);
/*     */     }
/*     */     
/*     */     public boolean matches(ValueEval x)
/*     */     {
/* 194 */       if ((x instanceof StringEval))
/*     */       {
/*     */ 
/* 197 */         switch (getCode())
/*     */         {
/*     */         case 0: 
/*     */         case 1: 
/*     */           break;
/*     */         
/*     */         case 2: 
/* 204 */           return true;
/*     */         
/*     */ 
/*     */         default: 
/* 208 */           return false;
/*     */         }
/* 210 */         StringEval se = (StringEval)x;
/* 211 */         Double val = OperandResolver.parseDouble(se.getStringValue());
/* 212 */         if (val == null)
/*     */         {
/* 214 */           return false;
/*     */         }
/* 216 */         return this._value == val.doubleValue(); }
/* 217 */       double testValue; if ((x instanceof NumberEval)) {
/* 218 */         NumberEval ne = (NumberEval)x;
/* 219 */         testValue = ne.getNumberValue();
/*     */       } else {
/* 221 */         return false; }
/*     */       double testValue;
/* 223 */       return evaluate(Double.compare(testValue, this._value));
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class BooleanMatcher extends Countif.MatcherBase {
/*     */     private final int _value;
/*     */     
/*     */     public BooleanMatcher(boolean value, Countif.CmpOp operator) {
/* 231 */       super();
/* 232 */       this._value = boolToInt(value);
/*     */     }
/*     */     
/*     */     protected String getValueText() {
/* 236 */       return this._value == 1 ? "TRUE" : "FALSE";
/*     */     }
/*     */     
/*     */     private static int boolToInt(boolean value) {
/* 240 */       return value ? 1 : 0;
/*     */     }
/*     */     
/*     */     public boolean matches(ValueEval x)
/*     */     {
/* 245 */       if ((x instanceof StringEval))
/*     */       {
/*     */ 
/*     */ 
/* 249 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       int testValue;
/*     */       
/*     */ 
/*     */ 
/* 258 */       if ((x instanceof BoolEval)) {
/* 259 */         BoolEval be = (BoolEval)x;
/* 260 */         testValue = boolToInt(be.getBooleanValue());
/*     */       } else {
/* 262 */         return false; }
/*     */       int testValue;
/* 264 */       return evaluate(testValue - this._value);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ErrorMatcher extends Countif.MatcherBase {
/*     */     private final int _value;
/*     */     
/*     */     public ErrorMatcher(int errorCode, Countif.CmpOp operator) {
/* 272 */       super();
/* 273 */       this._value = errorCode;
/*     */     }
/*     */     
/*     */     protected String getValueText() {
/* 277 */       return ErrorConstants.getText(this._value);
/*     */     }
/*     */     
/*     */     public boolean matches(ValueEval x) {
/* 281 */       if ((x instanceof ErrorEval)) {
/* 282 */         int testValue = ((ErrorEval)x).getErrorCode();
/* 283 */         return evaluate(testValue - this._value);
/*     */       }
/* 285 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class StringMatcher extends Countif.MatcherBase {
/*     */     private final String _value;
/*     */     private final Pattern _pattern;
/*     */     
/*     */     public StringMatcher(String value, Countif.CmpOp operator) {
/* 294 */       super();
/* 295 */       this._value = value;
/* 296 */       switch (operator.getCode()) {
/*     */       case 0: 
/*     */       case 1: 
/*     */       case 2: 
/* 300 */         this._pattern = getWildCardPattern(value);
/* 301 */         break;
/*     */       
/*     */       default: 
/* 304 */         this._pattern = null;
/*     */       }
/*     */     }
/*     */     
/*     */     protected String getValueText() {
/* 309 */       if (this._pattern == null) {
/* 310 */         return this._value;
/*     */       }
/* 312 */       return this._pattern.pattern();
/*     */     }
/*     */     
/*     */     public boolean matches(ValueEval x) {
/* 316 */       if ((x instanceof BlankEval)) {
/* 317 */         switch (getCode()) {
/*     */         case 0: 
/*     */         case 1: 
/* 320 */           return this._value.length() == 0;
/*     */         }
/*     */         
/* 323 */         return false;
/*     */       }
/* 325 */       if (!(x instanceof StringEval))
/*     */       {
/*     */ 
/*     */ 
/* 329 */         return false;
/*     */       }
/* 331 */       String testedValue = ((StringEval)x).getStringValue();
/* 332 */       if ((testedValue.length() < 1) && (this._value.length() < 1))
/*     */       {
/*     */ 
/* 335 */         switch (getCode()) {
/* 336 */         case 0:  return true;
/* 337 */         case 1:  return false;
/* 338 */         case 2:  return true;
/*     */         }
/* 340 */         return false;
/*     */       }
/* 342 */       if (this._pattern != null) {
/* 343 */         return evaluate(this._pattern.matcher(testedValue).matches());
/*     */       }
/* 345 */       return evaluate(testedValue.compareTo(this._value));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static Pattern getWildCardPattern(String value)
/*     */     {
/* 352 */       int len = value.length();
/* 353 */       StringBuffer sb = new StringBuffer(len);
/* 354 */       boolean hasWildCard = false;
/* 355 */       for (int i = 0; i < len; i++) {
/* 356 */         char ch = value.charAt(i);
/* 357 */         switch (ch) {
/*     */         case '?': 
/* 359 */           hasWildCard = true;
/*     */           
/* 361 */           sb.append('.');
/* 362 */           break;
/*     */         case '*': 
/* 364 */           hasWildCard = true;
/*     */           
/* 366 */           sb.append(".*");
/* 367 */           break;
/*     */         case '~': 
/* 369 */           if (i + 1 < len) {
/* 370 */             ch = value.charAt(i + 1);
/* 371 */             switch (ch) {
/*     */             case '*': 
/*     */             case '?': 
/* 374 */               hasWildCard = true;
/* 375 */               sb.append('[').append(ch).append(']');
/* 376 */               i++;
/* 377 */               break;
/*     */             }
/*     */           }
/*     */           else {
/* 381 */             sb.append('~'); }
/* 382 */           break;
/*     */         
/*     */         case '$': 
/*     */         case '(': 
/*     */         case ')': 
/*     */         case '.': 
/*     */         case '[': 
/*     */         case ']': 
/*     */         case '^': 
/* 391 */           sb.append("\\").append(ch);
/* 392 */           break;
/*     */         default: 
/* 394 */           sb.append(ch); }
/*     */       }
/* 396 */       if (hasWildCard) {
/* 397 */         return Pattern.compile(sb.toString());
/*     */       }
/* 399 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/* 405 */     CountUtils.I_MatchPredicate mp = createCriteriaPredicate(arg1, srcRowIndex, srcColumnIndex);
/* 406 */     if (mp == null)
/*     */     {
/* 408 */       return NumberEval.ZERO;
/*     */     }
/* 410 */     double result = countMatchingCellsInArea(arg0, mp);
/* 411 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private double countMatchingCellsInArea(ValueEval rangeArg, CountUtils.I_MatchPredicate criteriaPredicate)
/*     */   {
/* 418 */     if ((rangeArg instanceof RefEval))
/* 419 */       return CountUtils.countMatchingCell((RefEval)rangeArg, criteriaPredicate);
/* 420 */     if ((rangeArg instanceof TwoDEval)) {
/* 421 */       return CountUtils.countMatchingCellsInArea((TwoDEval)rangeArg, criteriaPredicate);
/*     */     }
/* 423 */     throw new IllegalArgumentException("Bad range arg type (" + rangeArg.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static CountUtils.I_MatchPredicate createCriteriaPredicate(ValueEval arg, int srcRowIndex, int srcColumnIndex)
/*     */   {
/* 433 */     ValueEval evaluatedCriteriaArg = evaluateCriteriaArg(arg, srcRowIndex, srcColumnIndex);
/*     */     
/* 435 */     if ((evaluatedCriteriaArg instanceof NumberEval)) {
/* 436 */       return new NumberMatcher(((NumberEval)evaluatedCriteriaArg).getNumberValue(), CmpOp.OP_NONE);
/*     */     }
/* 438 */     if ((evaluatedCriteriaArg instanceof BoolEval)) {
/* 439 */       return new BooleanMatcher(((BoolEval)evaluatedCriteriaArg).getBooleanValue(), CmpOp.OP_NONE);
/*     */     }
/*     */     
/* 442 */     if ((evaluatedCriteriaArg instanceof StringEval)) {
/* 443 */       return createGeneralMatchPredicate((StringEval)evaluatedCriteriaArg);
/*     */     }
/* 445 */     if ((evaluatedCriteriaArg instanceof ErrorEval)) {
/* 446 */       return new ErrorMatcher(((ErrorEval)evaluatedCriteriaArg).getErrorCode(), CmpOp.OP_NONE);
/*     */     }
/* 448 */     if (evaluatedCriteriaArg == BlankEval.instance) {
/* 449 */       return null;
/*     */     }
/* 451 */     throw new RuntimeException("Unexpected type for criteria (" + evaluatedCriteriaArg.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ValueEval evaluateCriteriaArg(ValueEval arg, int srcRowIndex, int srcColumnIndex)
/*     */   {
/*     */     try
/*     */     {
/* 461 */       return OperandResolver.getSingleValue(arg, srcRowIndex, (short)srcColumnIndex);
/*     */     } catch (EvaluationException e) {
/* 463 */       return e.getErrorEval();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static CountUtils.I_MatchPredicate createGeneralMatchPredicate(StringEval stringEval)
/*     */   {
/* 470 */     String value = stringEval.getStringValue();
/* 471 */     CmpOp operator = CmpOp.getOperator(value);
/* 472 */     value = value.substring(operator.getLength());
/*     */     
/* 474 */     Boolean booleanVal = parseBoolean(value);
/* 475 */     if (booleanVal != null) {
/* 476 */       return new BooleanMatcher(booleanVal.booleanValue(), operator);
/*     */     }
/*     */     
/* 479 */     Double doubleVal = OperandResolver.parseDouble(value);
/* 480 */     if (doubleVal != null) {
/* 481 */       return new NumberMatcher(doubleVal.doubleValue(), operator);
/*     */     }
/* 483 */     ErrorEval ee = parseError(value);
/* 484 */     if (ee != null) {
/* 485 */       return new ErrorMatcher(ee.getErrorCode(), operator);
/*     */     }
/*     */     
/*     */ 
/* 489 */     return new StringMatcher(value, operator);
/*     */   }
/*     */   
/* 492 */   private static ErrorEval parseError(String value) { if ((value.length() < 4) || (value.charAt(0) != '#')) {
/* 493 */       return null;
/*     */     }
/* 495 */     if (value.equals("#NULL!")) return ErrorEval.NULL_INTERSECTION;
/* 496 */     if (value.equals("#DIV/0!")) return ErrorEval.DIV_ZERO;
/* 497 */     if (value.equals("#VALUE!")) return ErrorEval.VALUE_INVALID;
/* 498 */     if (value.equals("#REF!")) return ErrorEval.REF_INVALID;
/* 499 */     if (value.equals("#NAME?")) return ErrorEval.NAME_INVALID;
/* 500 */     if (value.equals("#NUM!")) return ErrorEval.NUM_ERROR;
/* 501 */     if (value.equals("#N/A")) { return ErrorEval.NA;
/*     */     }
/* 503 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   static Boolean parseBoolean(String strRep)
/*     */   {
/* 509 */     if (strRep.length() < 1) {
/* 510 */       return null;
/*     */     }
/* 512 */     switch (strRep.charAt(0)) {
/*     */     case 'T': 
/*     */     case 't': 
/* 515 */       if ("TRUE".equalsIgnoreCase(strRep)) {
/* 516 */         return Boolean.TRUE;
/*     */       }
/*     */       break;
/*     */     case 'F': 
/*     */     case 'f': 
/* 521 */       if ("FALSE".equalsIgnoreCase(strRep)) {
/* 522 */         return Boolean.FALSE;
/*     */       }
/*     */       break;
/*     */     }
/* 526 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Countif.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */