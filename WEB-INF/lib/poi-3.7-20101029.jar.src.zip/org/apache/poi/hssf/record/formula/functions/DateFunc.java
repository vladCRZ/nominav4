/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.GregorianCalendar;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.hssf.usermodel.HSSFDateUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DateFunc
/*    */   extends Fixed3ArgFunction
/*    */ {
/* 37 */   public static final Function instance = new DateFunc();
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*    */   {
/*    */     double result;
/*    */     
/*    */     try
/*    */     {
/* 46 */       double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 47 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/* 48 */       double d2 = NumericFunction.singleOperandEvaluate(arg2, srcRowIndex, srcColumnIndex);
/* 49 */       result = evaluate(getYear(d0), (int)(d1 - 1.0D), (int)d2);
/* 50 */       NumericFunction.checkValue(result);
/*    */     } catch (EvaluationException e) {
/* 52 */       return e.getErrorEval();
/*    */     }
/* 54 */     return new NumberEval(result);
/*    */   }
/*    */   
/*    */   private static double evaluate(int year, int month, int pDay) throws EvaluationException
/*    */   {
/* 59 */     if ((year < 0) || (month < 0) || (pDay < 0)) {
/* 60 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*    */     }
/*    */     
/* 63 */     if ((year == 1900) && (month == 1) && (pDay == 29)) {
/* 64 */       return 60.0D;
/*    */     }
/*    */     
/* 67 */     int day = pDay;
/* 68 */     if ((year == 1900) && (
/* 69 */       ((month == 0) && (day >= 60)) || ((month == 1) && (day >= 30))))
/*    */     {
/* 71 */       day--;
/*    */     }
/*    */     
/*    */ 
/* 75 */     Calendar c = new GregorianCalendar();
/*    */     
/* 77 */     c.set(year, month, day, 0, 0, 0);
/* 78 */     c.set(14, 0);
/*    */     
/* 80 */     return HSSFDateUtil.getExcelDate(c.getTime(), false);
/*    */   }
/*    */   
/*    */   private static int getYear(double d) {
/* 84 */     int year = (int)d;
/*    */     
/* 86 */     if (year < 0) {
/* 87 */       return -1;
/*    */     }
/*    */     
/* 90 */     return year < 1900 ? 1900 + year : year;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\DateFunc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */