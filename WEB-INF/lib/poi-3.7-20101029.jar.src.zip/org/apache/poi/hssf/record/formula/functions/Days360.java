/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.usermodel.DateUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Days360
/*     */   extends Var2or3ArgFunction
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*     */     double result;
/*     */     try
/*     */     {
/*  41 */       double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  42 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*  43 */       result = evaluate(d0, d1, false);
/*     */     } catch (EvaluationException e) {
/*  45 */       return e.getErrorEval();
/*     */     }
/*  47 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */   {
/*     */     double result;
/*     */     try {
/*  54 */       double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  55 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*  56 */       ValueEval ve = OperandResolver.getSingleValue(arg2, srcRowIndex, srcColumnIndex);
/*  57 */       Boolean method = OperandResolver.coerceValueToBoolean(ve, false);
/*  58 */       result = evaluate(d0, d1, method == null ? false : method.booleanValue());
/*     */     } catch (EvaluationException e) {
/*  60 */       return e.getErrorEval();
/*     */     }
/*  62 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   private static double evaluate(double d0, double d1, boolean method) {
/*  66 */     Calendar startingDate = getStartingDate(d0);
/*  67 */     Calendar endingDate = getEndingDateAccordingToStartingDate(d1, startingDate);
/*  68 */     long startingDay = startingDate.get(2) * 30 + startingDate.get(5);
/*  69 */     long endingDay = (endingDate.get(1) - startingDate.get(1)) * 360 + endingDate.get(2) * 30 + endingDate.get(5);
/*     */     
/*  71 */     return endingDay - startingDay;
/*     */   }
/*     */   
/*     */   private static Calendar getDate(double date) {
/*  75 */     Calendar processedDate = new GregorianCalendar();
/*  76 */     processedDate.setTime(DateUtil.getJavaDate(date, false));
/*  77 */     return processedDate;
/*     */   }
/*     */   
/*     */   private static Calendar getStartingDate(double date) {
/*  81 */     Calendar startingDate = getDate(date);
/*  82 */     if (isLastDayOfMonth(startingDate)) {
/*  83 */       startingDate.set(5, 30);
/*     */     }
/*  85 */     return startingDate;
/*     */   }
/*     */   
/*     */   private static Calendar getEndingDateAccordingToStartingDate(double date, Calendar startingDate) {
/*  89 */     Calendar endingDate = getDate(date);
/*  90 */     endingDate.setTime(DateUtil.getJavaDate(date, false));
/*  91 */     if ((isLastDayOfMonth(endingDate)) && 
/*  92 */       (startingDate.get(5) < 30)) {
/*  93 */       endingDate = getFirstDayOfNextMonth(endingDate);
/*     */     }
/*     */     
/*  96 */     return endingDate;
/*     */   }
/*     */   
/*     */   private static boolean isLastDayOfMonth(Calendar date) {
/* 100 */     Calendar clone = (Calendar)date.clone();
/* 101 */     clone.add(2, 1);
/* 102 */     clone.add(5, -1);
/* 103 */     int lastDayOfMonth = clone.get(5);
/* 104 */     return date.get(5) == lastDayOfMonth;
/*     */   }
/*     */   
/*     */   private static Calendar getFirstDayOfNextMonth(Calendar date) {
/* 108 */     Calendar newDate = (Calendar)date.clone();
/* 109 */     if (date.get(2) < 11) {
/* 110 */       newDate.set(2, date.get(2) + 1);
/*     */     } else {
/* 112 */       newDate.set(2, 1);
/* 113 */       newDate.set(1, date.get(1) + 1);
/*     */     }
/* 115 */     newDate.set(5, 1);
/* 116 */     return newDate;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Days360.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */