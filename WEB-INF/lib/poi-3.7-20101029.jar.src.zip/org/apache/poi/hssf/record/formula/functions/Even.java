/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Even
/*    */   extends NumericFunction.OneArg
/*    */ {
/*    */   private static final long PARITY_MASK = -2L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected double evaluate(double d)
/*    */   {
/* 30 */     if (d == 0.0D)
/* 31 */       return 0.0D;
/*    */     long result;
/*    */     long result;
/* 34 */     if (d > 0.0D) {
/* 35 */       result = calcEven(d);
/*    */     } else {
/* 37 */       result = -calcEven(-d);
/*    */     }
/* 39 */     return result;
/*    */   }
/*    */   
/*    */   private static long calcEven(double d) {
/* 43 */     long x = d & 0xFFFFFFFFFFFFFFFE;
/* 44 */     if (x == d) {
/* 45 */       return x;
/*    */     }
/* 47 */     return x + 2L;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Even.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */