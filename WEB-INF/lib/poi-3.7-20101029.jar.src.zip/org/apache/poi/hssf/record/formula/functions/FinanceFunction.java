/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FinanceFunction
/*     */   implements Function3Arg, Function4Arg
/*     */ {
/*  30 */   private static final ValueEval DEFAULT_ARG3 = NumberEval.ZERO;
/*  31 */   private static final ValueEval DEFAULT_ARG4 = BoolEval.FALSE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */   {
/*  40 */     return evaluate(srcRowIndex, srcColumnIndex, arg0, arg1, arg2, DEFAULT_ARG3);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3) {
/*  44 */     return evaluate(srcRowIndex, srcColumnIndex, arg0, arg1, arg2, arg3, DEFAULT_ARG4);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3, ValueEval arg4) {
/*     */     double result;
/*     */     try {
/*  50 */       double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  51 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*  52 */       double d2 = NumericFunction.singleOperandEvaluate(arg2, srcRowIndex, srcColumnIndex);
/*  53 */       double d3 = NumericFunction.singleOperandEvaluate(arg3, srcRowIndex, srcColumnIndex);
/*  54 */       double d4 = NumericFunction.singleOperandEvaluate(arg4, srcRowIndex, srcColumnIndex);
/*  55 */       result = evaluate(d0, d1, d2, d3, d4 != 0.0D);
/*  56 */       NumericFunction.checkValue(result);
/*     */     } catch (EvaluationException e) {
/*  58 */       return e.getErrorEval();
/*     */     }
/*  60 */     return new NumberEval(result);
/*     */   }
/*     */   
/*  63 */   public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex) { switch (args.length) {
/*     */     case 3: 
/*  65 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1], args[2], DEFAULT_ARG3, DEFAULT_ARG4);
/*     */     case 4: 
/*  67 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1], args[2], args[3], DEFAULT_ARG4);
/*     */     case 5: 
/*  69 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1], args[2], args[3], args[4]);
/*     */     }
/*  71 */     return ErrorEval.VALUE_INVALID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected double evaluate(double[] ds)
/*     */     throws EvaluationException
/*     */   {
/*  79 */     double arg3 = 0.0D;
/*  80 */     double arg4 = 0.0D;
/*     */     
/*  82 */     switch (ds.length) {
/*     */     case 5: 
/*  84 */       arg4 = ds[4];
/*     */     case 4: 
/*  86 */       arg3 = ds[3];
/*     */     case 3: 
/*     */       break;
/*     */     default: 
/*  90 */       throw new IllegalStateException("Wrong number of arguments");
/*     */     }
/*  92 */     return evaluate(ds[0], ds[1], ds[2], arg3, arg4 != 0.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  98 */   public static final Function FV = new FinanceFunction() {
/*     */     protected double evaluate(double rate, double arg1, double arg2, double arg3, boolean type) {
/* 100 */       return FinanceLib.fv(rate, arg1, arg2, arg3, type);
/*     */     }
/*     */   };
/* 103 */   public static final Function NPER = new FinanceFunction() {
/*     */     protected double evaluate(double rate, double arg1, double arg2, double arg3, boolean type) {
/* 105 */       return FinanceLib.nper(rate, arg1, arg2, arg3, type);
/*     */     }
/*     */   };
/* 108 */   public static final Function PMT = new FinanceFunction() {
/*     */     protected double evaluate(double rate, double arg1, double arg2, double arg3, boolean type) {
/* 110 */       return FinanceLib.pmt(rate, arg1, arg2, arg3, type);
/*     */     }
/*     */   };
/* 113 */   public static final Function PV = new FinanceFunction() {
/*     */     protected double evaluate(double rate, double arg1, double arg2, double arg3, boolean type) {
/* 115 */       return FinanceLib.pv(rate, arg1, arg2, arg3, type);
/*     */     }
/*     */   };
/*     */   
/*     */   protected abstract double evaluate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean)
/*     */     throws EvaluationException;
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\FinanceFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */