/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FinanceLib
/*     */ {
/*     */   public static double fv(double r, double n, double y, double p, boolean t)
/*     */   {
/*  77 */     double retval = 0.0D;
/*  78 */     if (r == 0.0D) {
/*  79 */       retval = -1.0D * (p + n * y);
/*     */     }
/*     */     else {
/*  82 */       double r1 = r + 1.0D;
/*  83 */       retval = (1.0D - Math.pow(r1, n)) * (t ? r1 : 1.0D) * y / r - p * Math.pow(r1, n);
/*     */     }
/*     */     
/*     */ 
/*  87 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double pv(double r, double n, double y, double f, boolean t)
/*     */   {
/* 102 */     double retval = 0.0D;
/* 103 */     if (r == 0.0D) {
/* 104 */       retval = -1.0D * (n * y + f);
/*     */     }
/*     */     else {
/* 107 */       double r1 = r + 1.0D;
/* 108 */       retval = ((1.0D - Math.pow(r1, n)) / r * (t ? r1 : 1.0D) * y - f) / Math.pow(r1, n);
/*     */     }
/*     */     
/*     */ 
/* 112 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double npv(double r, double[] cfs)
/*     */   {
/* 125 */     double npv = 0.0D;
/* 126 */     double r1 = r + 1.0D;
/* 127 */     double trate = r1;
/* 128 */     int i = 0; for (int iSize = cfs.length; i < iSize; i++) {
/* 129 */       npv += cfs[i] / trate;
/* 130 */       trate *= r1;
/*     */     }
/* 132 */     return npv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double pmt(double r, double n, double p, double f, boolean t)
/*     */   {
/* 144 */     double retval = 0.0D;
/* 145 */     if (r == 0.0D) {
/* 146 */       retval = -1.0D * (f + p) / n;
/*     */     }
/*     */     else {
/* 149 */       double r1 = r + 1.0D;
/* 150 */       retval = (f + p * Math.pow(r1, n)) * r / ((t ? r1 : 1.0D) * (1.0D - Math.pow(r1, n)));
/*     */     }
/*     */     
/*     */ 
/* 154 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double nper(double r, double y, double p, double f, boolean t)
/*     */   {
/* 166 */     double retval = 0.0D;
/* 167 */     if (r == 0.0D) {
/* 168 */       retval = -1.0D * (f + p) / y;
/*     */     } else {
/* 170 */       double r1 = r + 1.0D;
/* 171 */       double ryr = (t ? r1 : 1.0D) * y / r;
/* 172 */       double a1 = ryr - f < 0.0D ? Math.log(f - ryr) : Math.log(ryr - f);
/*     */       
/*     */ 
/* 175 */       double a2 = ryr - f < 0.0D ? Math.log(-p - ryr) : Math.log(p + ryr);
/*     */       
/*     */ 
/* 178 */       double a3 = Math.log(r1);
/* 179 */       retval = (a1 - a2) / a3;
/*     */     }
/* 181 */     return retval;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\FinanceLib.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */