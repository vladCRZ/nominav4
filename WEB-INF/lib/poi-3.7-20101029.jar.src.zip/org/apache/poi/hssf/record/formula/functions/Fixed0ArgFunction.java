/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Fixed0ArgFunction
/*    */   implements Function0Arg
/*    */ {
/*    */   public final ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 30 */     if (args.length != 0) {
/* 31 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/* 33 */     return evaluate(srcRowIndex, srcColumnIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Fixed0ArgFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */