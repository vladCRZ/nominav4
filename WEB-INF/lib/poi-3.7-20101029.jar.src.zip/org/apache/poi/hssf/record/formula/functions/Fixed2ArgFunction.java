/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Fixed2ArgFunction
/*    */   implements Function2Arg
/*    */ {
/*    */   public final ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 30 */     if (args.length != 2) {
/* 31 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/* 33 */     return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1]);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Fixed2ArgFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */