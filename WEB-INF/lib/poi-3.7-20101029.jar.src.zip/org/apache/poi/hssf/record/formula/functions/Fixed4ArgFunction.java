/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Fixed4ArgFunction
/*    */   implements Function4Arg
/*    */ {
/*    */   public final ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 30 */     if (args.length != 4) {
/* 31 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/* 33 */     return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1], args[2], args[3]);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Fixed4ArgFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */