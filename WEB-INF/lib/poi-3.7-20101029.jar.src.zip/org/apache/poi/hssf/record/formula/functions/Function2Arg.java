package org.apache.poi.hssf.record.formula.functions;

import org.apache.poi.hssf.record.formula.eval.ValueEval;

public abstract interface Function2Arg
  extends Function
{
  public abstract ValueEval evaluate(int paramInt1, int paramInt2, ValueEval paramValueEval1, ValueEval paramValueEval2);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Function2Arg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */