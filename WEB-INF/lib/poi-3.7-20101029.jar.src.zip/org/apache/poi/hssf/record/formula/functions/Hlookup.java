/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.TwoDEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Hlookup
/*    */   extends Var3or4ArgFunction
/*    */ {
/* 43 */   private static final ValueEval DEFAULT_ARG3 = BoolEval.TRUE;
/*    */   
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*    */   {
/* 47 */     return evaluate(srcRowIndex, srcColumnIndex, arg0, arg1, arg2, DEFAULT_ARG3);
/*    */   }
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3)
/*    */   {
/*    */     try
/*    */     {
/* 55 */       ValueEval lookupValue = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 56 */       TwoDEval tableArray = LookupUtils.resolveTableArrayArg(arg1);
/* 57 */       boolean isRangeLookup = LookupUtils.resolveRangeLookupArg(arg3, srcRowIndex, srcColumnIndex);
/* 58 */       int colIndex = LookupUtils.lookupIndexOfValue(lookupValue, LookupUtils.createRowVector(tableArray, 0), isRangeLookup);
/* 59 */       int rowIndex = LookupUtils.resolveRowOrColIndexArg(arg2, srcRowIndex, srcColumnIndex);
/* 60 */       LookupUtils.ValueVector resultCol = createResultColumnVector(tableArray, rowIndex);
/* 61 */       return resultCol.getItem(colIndex);
/*    */     } catch (EvaluationException e) {
/* 63 */       return e.getErrorEval();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private LookupUtils.ValueVector createResultColumnVector(TwoDEval tableArray, int rowIndex)
/*    */     throws EvaluationException
/*    */   {
/* 75 */     if (rowIndex >= tableArray.getHeight()) {
/* 76 */       throw EvaluationException.invalidRef();
/*    */     }
/* 78 */     return LookupUtils.createRowVector(tableArray, rowIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Hlookup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */