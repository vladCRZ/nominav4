/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.MissingArgEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IfFunc
/*    */   extends Var2or3ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*    */   {
/*    */     boolean b;
/*    */     try
/*    */     {
/* 37 */       b = evaluateFirstArg(arg0, srcRowIndex, srcColumnIndex);
/*    */     } catch (EvaluationException e) {
/* 39 */       return e.getErrorEval();
/*    */     }
/* 41 */     if (b) {
/* 42 */       if (arg1 == MissingArgEval.instance) {
/* 43 */         return BlankEval.instance;
/*    */       }
/* 45 */       return arg1;
/*    */     }
/* 47 */     return BoolEval.FALSE;
/*    */   }
/*    */   
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*    */   {
/*    */     boolean b;
/*    */     try {
/* 54 */       b = evaluateFirstArg(arg0, srcRowIndex, srcColumnIndex);
/*    */     } catch (EvaluationException e) {
/* 56 */       return e.getErrorEval();
/*    */     }
/* 58 */     if (b) {
/* 59 */       if (arg1 == MissingArgEval.instance) {
/* 60 */         return BlankEval.instance;
/*    */       }
/* 62 */       return arg1;
/*    */     }
/* 64 */     if (arg2 == MissingArgEval.instance) {
/* 65 */       return BlankEval.instance;
/*    */     }
/* 67 */     return arg2;
/*    */   }
/*    */   
/*    */   public static boolean evaluateFirstArg(ValueEval arg, int srcCellRow, int srcCellCol) throws EvaluationException
/*    */   {
/* 72 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, srcCellCol);
/* 73 */     Boolean b = OperandResolver.coerceValueToBoolean(ve, false);
/* 74 */     if (b == null) {
/* 75 */       return false;
/*    */     }
/* 77 */     return b.booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\IfFunc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */