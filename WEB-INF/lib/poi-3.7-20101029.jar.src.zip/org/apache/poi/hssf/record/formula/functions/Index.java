/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.MissingArgEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Index
/*     */   implements Function2Arg, Function3Arg, Function4Arg
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*  50 */     TwoDEval reference = convertFirstArg(arg0);
/*     */     
/*  52 */     int columnIx = 0;
/*     */     try {
/*  54 */       int rowIx = resolveIndexArg(arg1, srcRowIndex, srcColumnIndex);
/*     */       
/*  56 */       if (!reference.isColumn()) {
/*  57 */         if (!reference.isRow())
/*     */         {
/*     */ 
/*  60 */           return ErrorEval.REF_INVALID;
/*     */         }
/*     */         
/*     */ 
/*  64 */         columnIx = rowIx;
/*  65 */         rowIx = 0;
/*     */       }
/*     */       
/*  68 */       return getValueFromArea(reference, rowIx, columnIx);
/*     */     } catch (EvaluationException e) {
/*  70 */       return e.getErrorEval();
/*     */     }
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2) {
/*  75 */     TwoDEval reference = convertFirstArg(arg0);
/*     */     try
/*     */     {
/*  78 */       int columnIx = resolveIndexArg(arg2, srcRowIndex, srcColumnIndex);
/*  79 */       int rowIx = resolveIndexArg(arg1, srcRowIndex, srcColumnIndex);
/*  80 */       return getValueFromArea(reference, rowIx, columnIx);
/*     */     } catch (EvaluationException e) {
/*  82 */       return e.getErrorEval();
/*     */     }
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3) {
/*  87 */     throw new RuntimeException("Incomplete code - don't know how to support the 'area_num' parameter yet)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TwoDEval convertFirstArg(ValueEval arg0)
/*     */   {
/*  96 */     ValueEval firstArg = arg0;
/*  97 */     if ((firstArg instanceof RefEval))
/*     */     {
/*  99 */       return ((RefEval)firstArg).offset(0, 0, 0, 0);
/*     */     }
/* 101 */     if ((firstArg instanceof TwoDEval)) {
/* 102 */       return (TwoDEval)firstArg;
/*     */     }
/*     */     
/*     */ 
/* 106 */     throw new RuntimeException("Incomplete code - cannot handle first arg of type (" + firstArg.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */   public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex)
/*     */   {
/* 112 */     switch (args.length) {
/*     */     case 2: 
/* 114 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1]);
/*     */     case 3: 
/* 116 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1], args[2]);
/*     */     case 4: 
/* 118 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1], args[2], args[3]);
/*     */     }
/* 120 */     return ErrorEval.VALUE_INVALID;
/*     */   }
/*     */   
/*     */   private static ValueEval getValueFromArea(TwoDEval ae, int pRowIx, int pColumnIx) throws EvaluationException
/*     */   {
/* 125 */     assert (pRowIx >= 0);
/* 126 */     assert (pColumnIx >= 0);
/*     */     
/* 128 */     TwoDEval result = ae;
/*     */     
/* 130 */     if (pRowIx != 0)
/*     */     {
/* 132 */       if (pRowIx > ae.getHeight())
/*     */       {
/* 134 */         throw new EvaluationException(ErrorEval.REF_INVALID);
/*     */       }
/* 136 */       result = result.getRow(pRowIx - 1);
/*     */     }
/*     */     
/* 139 */     if (pColumnIx != 0)
/*     */     {
/* 141 */       if (pColumnIx > ae.getWidth())
/*     */       {
/* 143 */         throw new EvaluationException(ErrorEval.REF_INVALID);
/*     */       }
/* 145 */       result = result.getColumn(pColumnIx - 1);
/*     */     }
/* 147 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int resolveIndexArg(ValueEval arg, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 158 */     ValueEval ev = OperandResolver.getSingleValue(arg, srcCellRow, srcCellCol);
/* 159 */     if (ev == MissingArgEval.instance) {
/* 160 */       return 0;
/*     */     }
/* 162 */     if (ev == BlankEval.instance) {
/* 163 */       return 0;
/*     */     }
/* 165 */     int result = OperandResolver.coerceValueToInt(ev);
/* 166 */     if (result < 0) {
/* 167 */       throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */     }
/* 169 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Index.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */