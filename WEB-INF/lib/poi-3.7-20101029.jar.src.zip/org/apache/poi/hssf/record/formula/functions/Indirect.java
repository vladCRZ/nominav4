/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.MissingArgEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.OperationEvaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Indirect
/*     */   implements FreeRefFunction
/*     */ {
/*  45 */   public static final FreeRefFunction instance = new Indirect();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueEval evaluate(ValueEval[] args, OperationEvaluationContext ec)
/*     */   {
/*  52 */     if (args.length < 1) {
/*  53 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*     */     String text;
/*     */     boolean isA1style;
/*     */     try
/*     */     {
/*  59 */       ValueEval ve = OperandResolver.getSingleValue(args[0], ec.getRowIndex(), ec.getColumnIndex());
/*     */       
/*  61 */       text = OperandResolver.coerceValueToString(ve);
/*  62 */       switch (args.length) {
/*     */       case 1: 
/*  64 */         isA1style = true;
/*  65 */         break;
/*     */       case 2: 
/*  67 */         isA1style = evaluateBooleanArg(args[1], ec);
/*  68 */         break;
/*     */       default: 
/*  70 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*     */     } catch (EvaluationException e) {
/*  73 */       return e.getErrorEval();
/*     */     }
/*     */     
/*  76 */     return evaluateIndirect(ec, text, isA1style);
/*     */   }
/*     */   
/*     */   private static boolean evaluateBooleanArg(ValueEval arg, OperationEvaluationContext ec) throws EvaluationException
/*     */   {
/*  81 */     ValueEval ve = OperandResolver.getSingleValue(arg, ec.getRowIndex(), ec.getColumnIndex());
/*     */     
/*  83 */     if ((ve == BlankEval.instance) || (ve == MissingArgEval.instance)) {
/*  84 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  88 */     return OperandResolver.coerceValueToBoolean(ve, false).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */   private static ValueEval evaluateIndirect(OperationEvaluationContext ec, String text, boolean isA1style)
/*     */   {
/*  94 */     int plingPos = text.lastIndexOf('!');
/*     */     String refText;
/*     */     String workbookName;
/*     */     String sheetName;
/*     */     String refText;
/*  99 */     if (plingPos < 0) {
/* 100 */       String workbookName = null;
/* 101 */       String sheetName = null;
/* 102 */       refText = text;
/*     */     } else {
/* 104 */       String[] parts = parseWorkbookAndSheetName(text.subSequence(0, plingPos));
/* 105 */       if (parts == null) {
/* 106 */         return ErrorEval.REF_INVALID;
/*     */       }
/* 108 */       workbookName = parts[0];
/* 109 */       sheetName = parts[1];
/* 110 */       refText = text.substring(plingPos + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 116 */     int colonPos = refText.indexOf(':');
/* 117 */     String refStrPart2; String refStrPart1; String refStrPart2; if (colonPos < 0) {
/* 118 */       String refStrPart1 = refText.trim();
/* 119 */       refStrPart2 = null;
/*     */     } else {
/* 121 */       refStrPart1 = refText.substring(0, colonPos).trim();
/* 122 */       refStrPart2 = refText.substring(colonPos + 1).trim();
/*     */     }
/* 124 */     return ec.getDynamicReference(workbookName, sheetName, refStrPart1, refStrPart2, isA1style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String[] parseWorkbookAndSheetName(CharSequence text)
/*     */   {
/* 133 */     int lastIx = text.length() - 1;
/* 134 */     if (lastIx < 0) {
/* 135 */       return null;
/*     */     }
/* 137 */     if (canTrim(text)) {
/* 138 */       return null;
/*     */     }
/* 140 */     char firstChar = text.charAt(0);
/* 141 */     if (Character.isWhitespace(firstChar)) {
/* 142 */       return null;
/*     */     }
/* 144 */     if (firstChar == '\'')
/*     */     {
/*     */ 
/* 147 */       if (text.charAt(lastIx) != '\'') {
/* 148 */         return null;
/*     */       }
/* 150 */       firstChar = text.charAt(1);
/* 151 */       if (Character.isWhitespace(firstChar))
/* 152 */         return null;
/*     */       int sheetStartPos;
/*     */       String wbName;
/*     */       int sheetStartPos;
/* 156 */       if (firstChar == '[') {
/* 157 */         int rbPos = text.toString().lastIndexOf(']');
/* 158 */         if (rbPos < 0) {
/* 159 */           return null;
/*     */         }
/* 161 */         String wbName = unescapeString(text.subSequence(2, rbPos));
/* 162 */         if ((wbName == null) || (canTrim(wbName))) {
/* 163 */           return null;
/*     */         }
/* 165 */         sheetStartPos = rbPos + 1;
/*     */       } else {
/* 167 */         wbName = null;
/* 168 */         sheetStartPos = 1;
/*     */       }
/*     */       
/*     */ 
/* 172 */       String sheetName = unescapeString(text.subSequence(sheetStartPos, lastIx));
/* 173 */       if (sheetName == null)
/*     */       {
/* 175 */         return null;
/*     */       }
/* 177 */       return new String[] { wbName, sheetName };
/*     */     }
/*     */     
/* 180 */     if (firstChar == '[') {
/* 181 */       int rbPos = text.toString().lastIndexOf(']');
/* 182 */       if (rbPos < 0) {
/* 183 */         return null;
/*     */       }
/* 185 */       CharSequence wbName = text.subSequence(1, rbPos);
/* 186 */       if (canTrim(wbName)) {
/* 187 */         return null;
/*     */       }
/* 189 */       CharSequence sheetName = text.subSequence(rbPos + 1, text.length());
/* 190 */       if (canTrim(sheetName)) {
/* 191 */         return null;
/*     */       }
/* 193 */       return new String[] { wbName.toString(), sheetName.toString() };
/*     */     }
/*     */     
/* 196 */     return new String[] { null, text.toString() };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String unescapeString(CharSequence text)
/*     */   {
/* 204 */     int len = text.length();
/* 205 */     StringBuilder sb = new StringBuilder(len);
/* 206 */     int i = 0;
/* 207 */     while (i < len) {
/* 208 */       char ch = text.charAt(i);
/* 209 */       if (ch == '\'')
/*     */       {
/* 211 */         i++;
/* 212 */         if (i >= len) {
/* 213 */           return null;
/*     */         }
/* 215 */         ch = text.charAt(i);
/* 216 */         if (ch != '\'') {
/* 217 */           return null;
/*     */         }
/*     */       }
/* 220 */       sb.append(ch);
/* 221 */       i++;
/*     */     }
/* 223 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static boolean canTrim(CharSequence text) {
/* 227 */     int lastIx = text.length() - 1;
/* 228 */     if (lastIx < 0) {
/* 229 */       return false;
/*     */     }
/* 231 */     if (Character.isWhitespace(text.charAt(0))) {
/* 232 */       return true;
/*     */     }
/* 234 */     if (Character.isWhitespace(text.charAt(lastIx))) {
/* 235 */       return true;
/*     */     }
/* 237 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Indirect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */