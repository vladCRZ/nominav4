/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.AreaEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LogicalFunction
/*     */   extends Fixed1ArgFunction
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*     */   {
/*     */     ValueEval ve;
/*     */     try
/*     */     {
/*  40 */       ve = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (EvaluationException e)
/*     */     {
/*     */ 
/*     */ 
/*  48 */       ve = e.getErrorEval();
/*     */     }
/*  50 */     return BoolEval.valueOf(evaluate(ve));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   public static final Function ISLOGICAL = new LogicalFunction() {
/*     */     protected boolean evaluate(ValueEval arg) {
/*  60 */       return arg instanceof BoolEval;
/*     */     }
/*     */   };
/*  63 */   public static final Function ISNONTEXT = new LogicalFunction() {
/*     */     protected boolean evaluate(ValueEval arg) {
/*  65 */       return !(arg instanceof StringEval);
/*     */     }
/*     */   };
/*  68 */   public static final Function ISNUMBER = new LogicalFunction() {
/*     */     protected boolean evaluate(ValueEval arg) {
/*  70 */       return arg instanceof NumberEval;
/*     */     }
/*     */   };
/*  73 */   public static final Function ISTEXT = new LogicalFunction() {
/*     */     protected boolean evaluate(ValueEval arg) {
/*  75 */       return arg instanceof StringEval;
/*     */     }
/*     */   };
/*     */   
/*  79 */   public static final Function ISBLANK = new LogicalFunction()
/*     */   {
/*     */     protected boolean evaluate(ValueEval arg) {
/*  82 */       return arg instanceof BlankEval;
/*     */     }
/*     */   };
/*     */   
/*  86 */   public static final Function ISERROR = new LogicalFunction()
/*     */   {
/*     */     protected boolean evaluate(ValueEval arg) {
/*  89 */       return arg instanceof ErrorEval;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   public static final Function ISNA = new LogicalFunction()
/*     */   {
/*     */     protected boolean evaluate(ValueEval arg) {
/* 106 */       return arg == ErrorEval.NA;
/*     */     }
/*     */   };
/*     */   
/* 110 */   public static final Function ISREF = new Fixed1ArgFunction()
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/* 113 */       if (((arg0 instanceof RefEval)) || ((arg0 instanceof AreaEval))) {
/* 114 */         return BoolEval.TRUE;
/*     */       }
/* 116 */       return BoolEval.FALSE;
/*     */     }
/*     */   };
/*     */   
/*     */   protected abstract boolean evaluate(ValueEval paramValueEval);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\LogicalFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */