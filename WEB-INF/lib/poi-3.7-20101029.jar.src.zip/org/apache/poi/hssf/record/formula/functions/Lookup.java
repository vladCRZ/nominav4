/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.TwoDEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Lookup
/*    */   extends Var2or3ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*    */   {
/* 44 */     throw new RuntimeException("Two arg version of LOOKUP not supported yet");
/*    */   }
/*    */   
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*    */   {
/*    */     try {
/* 50 */       ValueEval lookupValue = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 51 */       TwoDEval aeLookupVector = LookupUtils.resolveTableArrayArg(arg1);
/* 52 */       TwoDEval aeResultVector = LookupUtils.resolveTableArrayArg(arg2);
/*    */       
/* 54 */       LookupUtils.ValueVector lookupVector = createVector(aeLookupVector);
/* 55 */       LookupUtils.ValueVector resultVector = createVector(aeResultVector);
/* 56 */       if (lookupVector.getSize() > resultVector.getSize())
/*    */       {
/* 58 */         throw new RuntimeException("Lookup vector and result vector of differing sizes not supported yet");
/*    */       }
/* 60 */       int index = LookupUtils.lookupIndexOfValue(lookupValue, lookupVector, true);
/*    */       
/* 62 */       return resultVector.getItem(index);
/*    */     } catch (EvaluationException e) {
/* 64 */       return e.getErrorEval();
/*    */     }
/*    */   }
/*    */   
/*    */   private static LookupUtils.ValueVector createVector(TwoDEval ae) {
/* 69 */     LookupUtils.ValueVector result = LookupUtils.createVector(ae);
/* 70 */     if (result != null) {
/* 71 */       return result;
/*    */     }
/*    */     
/* 74 */     throw new RuntimeException("non-vector lookup or result areas not supported yet");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Lookup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */