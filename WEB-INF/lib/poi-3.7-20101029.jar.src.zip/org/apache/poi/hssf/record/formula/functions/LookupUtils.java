/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumericValueEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LookupUtils
/*     */ {
/*     */   public static abstract interface ValueVector
/*     */   {
/*     */     public abstract ValueEval getItem(int paramInt);
/*     */     
/*     */     public abstract int getSize();
/*     */   }
/*     */   
/*     */   private static final class RowVector
/*     */     implements LookupUtils.ValueVector
/*     */   {
/*     */     private final TwoDEval _tableArray;
/*     */     private final int _size;
/*     */     private final int _rowIndex;
/*     */     
/*     */     public RowVector(TwoDEval tableArray, int rowIndex)
/*     */     {
/*  55 */       this._rowIndex = rowIndex;
/*  56 */       int lastRowIx = tableArray.getHeight() - 1;
/*  57 */       if ((rowIndex < 0) || (rowIndex > lastRowIx)) {
/*  58 */         throw new IllegalArgumentException("Specified row index (" + rowIndex + ") is outside the allowed range (0.." + lastRowIx + ")");
/*     */       }
/*     */       
/*  61 */       this._tableArray = tableArray;
/*  62 */       this._size = tableArray.getWidth();
/*     */     }
/*     */     
/*     */     public ValueEval getItem(int index) {
/*  66 */       if (index > this._size) {
/*  67 */         throw new ArrayIndexOutOfBoundsException("Specified index (" + index + ") is outside the allowed range (0.." + (this._size - 1) + ")");
/*     */       }
/*     */       
/*  70 */       return this._tableArray.getValue(this._rowIndex, index);
/*     */     }
/*     */     
/*  73 */     public int getSize() { return this._size; }
/*     */   }
/*     */   
/*     */   private static final class ColumnVector implements LookupUtils.ValueVector
/*     */   {
/*     */     private final TwoDEval _tableArray;
/*     */     private final int _size;
/*     */     private final int _columnIndex;
/*     */     
/*     */     public ColumnVector(TwoDEval tableArray, int columnIndex)
/*     */     {
/*  84 */       this._columnIndex = columnIndex;
/*  85 */       int lastColIx = tableArray.getWidth() - 1;
/*  86 */       if ((columnIndex < 0) || (columnIndex > lastColIx)) {
/*  87 */         throw new IllegalArgumentException("Specified column index (" + columnIndex + ") is outside the allowed range (0.." + lastColIx + ")");
/*     */       }
/*     */       
/*  90 */       this._tableArray = tableArray;
/*  91 */       this._size = this._tableArray.getHeight();
/*     */     }
/*     */     
/*     */     public ValueEval getItem(int index) {
/*  95 */       if (index > this._size) {
/*  96 */         throw new ArrayIndexOutOfBoundsException("Specified index (" + index + ") is outside the allowed range (0.." + (this._size - 1) + ")");
/*     */       }
/*     */       
/*  99 */       return this._tableArray.getValue(index, this._columnIndex);
/*     */     }
/*     */     
/* 102 */     public int getSize() { return this._size; }
/*     */   }
/*     */   
/*     */   public static ValueVector createRowVector(TwoDEval tableArray, int relativeRowIndex)
/*     */   {
/* 107 */     return new RowVector(tableArray, relativeRowIndex);
/*     */   }
/*     */   
/* 110 */   public static ValueVector createColumnVector(TwoDEval tableArray, int relativeColumnIndex) { return new ColumnVector(tableArray, relativeColumnIndex); }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ValueVector createVector(TwoDEval ae)
/*     */   {
/* 116 */     if (ae.isColumn()) {
/* 117 */       return createColumnVector(ae, 0);
/*     */     }
/* 119 */     if (ae.isRow()) {
/* 120 */       return createRowVector(ae, 0);
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final class CompareResult
/*     */   {
/*     */     private final boolean _isTypeMismatch;
/*     */     
/*     */ 
/*     */     private final boolean _isLessThan;
/*     */     
/*     */ 
/*     */     private final boolean _isEqual;
/*     */     
/*     */ 
/*     */     private final boolean _isGreaterThan;
/*     */     
/*     */ 
/*     */     private CompareResult(boolean isTypeMismatch, int simpleCompareResult)
/*     */     {
/* 143 */       if (isTypeMismatch) {
/* 144 */         this._isTypeMismatch = true;
/* 145 */         this._isLessThan = false;
/* 146 */         this._isEqual = false;
/* 147 */         this._isGreaterThan = false;
/*     */       } else {
/* 149 */         this._isTypeMismatch = false;
/* 150 */         this._isLessThan = (simpleCompareResult < 0);
/* 151 */         this._isEqual = (simpleCompareResult == 0);
/* 152 */         this._isGreaterThan = (simpleCompareResult > 0);
/*     */       } }
/*     */     
/* 155 */     public static final CompareResult TYPE_MISMATCH = new CompareResult(true, 0);
/* 156 */     public static final CompareResult LESS_THAN = new CompareResult(false, -1);
/* 157 */     public static final CompareResult EQUAL = new CompareResult(false, 0);
/* 158 */     public static final CompareResult GREATER_THAN = new CompareResult(false, 1);
/*     */     
/*     */     public static final CompareResult valueOf(int simpleCompareResult) {
/* 161 */       if (simpleCompareResult < 0) {
/* 162 */         return LESS_THAN;
/*     */       }
/* 164 */       if (simpleCompareResult > 0) {
/* 165 */         return GREATER_THAN;
/*     */       }
/* 167 */       return EQUAL;
/*     */     }
/*     */     
/*     */     public boolean isTypeMismatch() {
/* 171 */       return this._isTypeMismatch;
/*     */     }
/*     */     
/* 174 */     public boolean isLessThan() { return this._isLessThan; }
/*     */     
/*     */     public boolean isEqual() {
/* 177 */       return this._isEqual;
/*     */     }
/*     */     
/* 180 */     public boolean isGreaterThan() { return this._isGreaterThan; }
/*     */     
/*     */     public String toString() {
/* 183 */       StringBuffer sb = new StringBuffer(64);
/* 184 */       sb.append(getClass().getName()).append(" [");
/* 185 */       sb.append(formatAsString());
/* 186 */       sb.append("]");
/* 187 */       return sb.toString();
/*     */     }
/*     */     
/*     */     private String formatAsString() {
/* 191 */       if (this._isTypeMismatch) {
/* 192 */         return "TYPE_MISMATCH";
/*     */       }
/* 194 */       if (this._isLessThan) {
/* 195 */         return "LESS_THAN";
/*     */       }
/* 197 */       if (this._isEqual) {
/* 198 */         return "EQUAL";
/*     */       }
/* 200 */       if (this._isGreaterThan) {
/* 201 */         return "GREATER_THAN";
/*     */       }
/*     */       
/* 204 */       return "??error??";
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface LookupValueComparer
/*     */   {
/*     */     public abstract LookupUtils.CompareResult compareTo(ValueEval paramValueEval);
/*     */   }
/*     */   
/*     */   private static abstract class LookupValueComparerBase
/*     */     implements LookupUtils.LookupValueComparer
/*     */   {
/*     */     private final Class<? extends ValueEval> _targetClass;
/*     */     
/*     */     protected LookupValueComparerBase(ValueEval targetValue)
/*     */     {
/* 220 */       if (targetValue == null) {
/* 221 */         throw new RuntimeException("targetValue cannot be null");
/*     */       }
/* 223 */       this._targetClass = targetValue.getClass();
/*     */     }
/*     */     
/* 226 */     public final LookupUtils.CompareResult compareTo(ValueEval other) { if (other == null) {
/* 227 */         throw new RuntimeException("compare to value cannot be null");
/*     */       }
/* 229 */       if (this._targetClass != other.getClass()) {
/* 230 */         return LookupUtils.CompareResult.TYPE_MISMATCH;
/*     */       }
/* 232 */       return compareSameType(other);
/*     */     }
/*     */     
/* 235 */     public String toString() { StringBuffer sb = new StringBuffer(64);
/* 236 */       sb.append(getClass().getName()).append(" [");
/* 237 */       sb.append(getValueAsString());
/* 238 */       sb.append("]");
/* 239 */       return sb.toString();
/*     */     }
/*     */     
/*     */     protected abstract LookupUtils.CompareResult compareSameType(ValueEval paramValueEval);
/*     */     
/*     */     protected abstract String getValueAsString();
/*     */   }
/*     */   
/*     */   private static final class StringLookupComparer extends LookupUtils.LookupValueComparerBase {
/*     */     private String _value;
/*     */     
/* 250 */     protected StringLookupComparer(StringEval se) { super();
/* 251 */       this._value = se.getStringValue();
/*     */     }
/*     */     
/* 254 */     protected LookupUtils.CompareResult compareSameType(ValueEval other) { StringEval se = (StringEval)other;
/* 255 */       return LookupUtils.CompareResult.valueOf(this._value.compareToIgnoreCase(se.getStringValue()));
/*     */     }
/*     */     
/* 258 */     protected String getValueAsString() { return this._value; }
/*     */   }
/*     */   
/*     */   private static final class NumberLookupComparer extends LookupUtils.LookupValueComparerBase {
/*     */     private double _value;
/*     */     
/*     */     protected NumberLookupComparer(NumberEval ne) {
/* 265 */       super();
/* 266 */       this._value = ne.getNumberValue();
/*     */     }
/*     */     
/* 269 */     protected LookupUtils.CompareResult compareSameType(ValueEval other) { NumberEval ne = (NumberEval)other;
/* 270 */       return LookupUtils.CompareResult.valueOf(Double.compare(this._value, ne.getNumberValue()));
/*     */     }
/*     */     
/* 273 */     protected String getValueAsString() { return String.valueOf(this._value); }
/*     */   }
/*     */   
/*     */   private static final class BooleanLookupComparer extends LookupUtils.LookupValueComparerBase {
/*     */     private boolean _value;
/*     */     
/*     */     protected BooleanLookupComparer(BoolEval be) {
/* 280 */       super();
/* 281 */       this._value = be.getBooleanValue();
/*     */     }
/*     */     
/* 284 */     protected LookupUtils.CompareResult compareSameType(ValueEval other) { BoolEval be = (BoolEval)other;
/* 285 */       boolean otherVal = be.getBooleanValue();
/* 286 */       if (this._value == otherVal) {
/* 287 */         return LookupUtils.CompareResult.EQUAL;
/*     */       }
/*     */       
/* 290 */       if (this._value) {
/* 291 */         return LookupUtils.CompareResult.GREATER_THAN;
/*     */       }
/* 293 */       return LookupUtils.CompareResult.LESS_THAN;
/*     */     }
/*     */     
/* 296 */     protected String getValueAsString() { return String.valueOf(this._value); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int resolveRowOrColIndexArg(ValueEval rowColIndexArg, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 324 */     if (rowColIndexArg == null) {
/* 325 */       throw new IllegalArgumentException("argument must not be null");
/*     */     }
/*     */     ValueEval veRowColIndexArg;
/*     */     try
/*     */     {
/* 330 */       veRowColIndexArg = OperandResolver.getSingleValue(rowColIndexArg, srcCellRow, (short)srcCellCol);
/*     */     }
/*     */     catch (EvaluationException e) {
/* 333 */       throw EvaluationException.invalidRef();
/*     */     }
/*     */     
/* 336 */     if ((veRowColIndexArg instanceof StringEval)) {
/* 337 */       StringEval se = (StringEval)veRowColIndexArg;
/* 338 */       String strVal = se.getStringValue();
/* 339 */       Double dVal = OperandResolver.parseDouble(strVal);
/* 340 */       if (dVal == null)
/*     */       {
/* 342 */         throw EvaluationException.invalidRef();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 348 */     int oneBasedIndex = OperandResolver.coerceValueToInt(veRowColIndexArg);
/* 349 */     if (oneBasedIndex < 1)
/*     */     {
/* 351 */       throw EvaluationException.invalidValue();
/*     */     }
/* 353 */     return oneBasedIndex - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TwoDEval resolveTableArrayArg(ValueEval eval)
/*     */     throws EvaluationException
/*     */   {
/* 363 */     if ((eval instanceof TwoDEval)) {
/* 364 */       return (TwoDEval)eval;
/*     */     }
/*     */     
/* 367 */     if ((eval instanceof RefEval)) {
/* 368 */       RefEval refEval = (RefEval)eval;
/*     */       
/*     */ 
/*     */ 
/* 372 */       return refEval.offset(0, 0, 0, 0);
/*     */     }
/* 374 */     throw EvaluationException.invalidValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean resolveRangeLookupArg(ValueEval rangeLookupArg, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 384 */     ValueEval valEval = OperandResolver.getSingleValue(rangeLookupArg, srcCellRow, srcCellCol);
/* 385 */     if ((valEval instanceof BlankEval))
/*     */     {
/*     */ 
/*     */ 
/* 389 */       return false;
/*     */     }
/* 391 */     if ((valEval instanceof BoolEval))
/*     */     {
/* 393 */       BoolEval boolEval = (BoolEval)valEval;
/* 394 */       return boolEval.getBooleanValue();
/*     */     }
/*     */     
/* 397 */     if ((valEval instanceof StringEval)) {
/* 398 */       String stringValue = ((StringEval)valEval).getStringValue();
/* 399 */       if (stringValue.length() < 1)
/*     */       {
/*     */ 
/* 402 */         throw EvaluationException.invalidValue();
/*     */       }
/*     */       
/* 405 */       Boolean b = Countif.parseBoolean(stringValue);
/* 406 */       if (b != null)
/*     */       {
/* 408 */         return b.booleanValue();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 413 */       throw EvaluationException.invalidValue();
/*     */     }
/*     */     
/*     */ 
/* 417 */     if ((valEval instanceof NumericValueEval)) {
/* 418 */       NumericValueEval nve = (NumericValueEval)valEval;
/*     */       
/* 420 */       return 0.0D != nve.getNumberValue();
/*     */     }
/* 422 */     throw new RuntimeException("Unexpected eval type (" + valEval.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */   public static int lookupIndexOfValue(ValueEval lookupValue, ValueVector vector, boolean isRangeLookup) throws EvaluationException {
/* 426 */     LookupValueComparer lookupComparer = createLookupComparer(lookupValue);
/*     */     int result;
/* 428 */     int result; if (isRangeLookup) {
/* 429 */       result = performBinarySearch(vector, lookupComparer);
/*     */     } else {
/* 431 */       result = lookupIndexOfExactValue(lookupComparer, vector);
/*     */     }
/* 433 */     if (result < 0) {
/* 434 */       throw new EvaluationException(ErrorEval.NA);
/*     */     }
/* 436 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int lookupIndexOfExactValue(LookupValueComparer lookupComparer, ValueVector vector)
/*     */   {
/* 450 */     int size = vector.getSize();
/* 451 */     for (int i = 0; i < size; i++) {
/* 452 */       if (lookupComparer.compareTo(vector.getItem(i)).isEqual()) {
/* 453 */         return i;
/*     */       }
/*     */     }
/* 456 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class BinarySearchIndexes
/*     */   {
/*     */     private int _lowIx;
/*     */     
/*     */     private int _highIx;
/*     */     
/*     */ 
/*     */     public BinarySearchIndexes(int highIx)
/*     */     {
/* 470 */       this._lowIx = -1;
/* 471 */       this._highIx = highIx;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getMidIx()
/*     */     {
/* 478 */       int ixDiff = this._highIx - this._lowIx;
/* 479 */       if (ixDiff < 2) {
/* 480 */         return -1;
/*     */       }
/* 482 */       return this._lowIx + ixDiff / 2;
/*     */     }
/*     */     
/*     */     public int getLowIx() {
/* 486 */       return this._lowIx;
/*     */     }
/*     */     
/* 489 */     public int getHighIx() { return this._highIx; }
/*     */     
/*     */     public void narrowSearch(int midIx, boolean isLessThan) {
/* 492 */       if (isLessThan) {
/* 493 */         this._highIx = midIx;
/*     */       } else {
/* 495 */         this._lowIx = midIx;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int performBinarySearch(ValueVector vector, LookupValueComparer lookupComparer)
/*     */   {
/* 505 */     BinarySearchIndexes bsi = new BinarySearchIndexes(vector.getSize());
/*     */     for (;;)
/*     */     {
/* 508 */       int midIx = bsi.getMidIx();
/*     */       
/* 510 */       if (midIx < 0) {
/* 511 */         return bsi.getLowIx();
/*     */       }
/* 513 */       CompareResult cr = lookupComparer.compareTo(vector.getItem(midIx));
/* 514 */       if (cr.isTypeMismatch()) {
/* 515 */         int newMidIx = handleMidValueTypeMismatch(lookupComparer, vector, bsi, midIx);
/* 516 */         if (newMidIx >= 0)
/*     */         {
/*     */ 
/* 519 */           midIx = newMidIx;
/* 520 */           cr = lookupComparer.compareTo(vector.getItem(midIx));
/*     */         }
/* 522 */       } else { if (cr.isEqual()) {
/* 523 */           return findLastIndexInRunOfEqualValues(lookupComparer, vector, midIx, bsi.getHighIx());
/*     */         }
/* 525 */         bsi.narrowSearch(midIx, cr.isLessThan());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int handleMidValueTypeMismatch(LookupValueComparer lookupComparer, ValueVector vector, BinarySearchIndexes bsi, int midIx)
/*     */   {
/* 537 */     int newMid = midIx;
/* 538 */     int highIx = bsi.getHighIx();
/*     */     CompareResult cr;
/*     */     do {
/* 541 */       newMid++;
/* 542 */       if (newMid == highIx)
/*     */       {
/*     */ 
/* 545 */         bsi.narrowSearch(midIx, true);
/* 546 */         return -1;
/*     */       }
/* 548 */       cr = lookupComparer.compareTo(vector.getItem(newMid));
/* 549 */       if ((cr.isLessThan()) && (newMid == highIx - 1))
/*     */       {
/* 551 */         bsi.narrowSearch(midIx, true);
/* 552 */         return -1;
/*     */       }
/*     */       
/*     */     }
/* 556 */     while (cr.isTypeMismatch());
/*     */     
/*     */ 
/*     */ 
/* 560 */     if (cr.isEqual()) {
/* 561 */       return newMid;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 566 */     bsi.narrowSearch(newMid, cr.isLessThan());
/* 567 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findLastIndexInRunOfEqualValues(LookupValueComparer lookupComparer, ValueVector vector, int firstFoundIndex, int maxIx)
/*     */   {
/* 576 */     for (int i = firstFoundIndex + 1; i < maxIx; i++) {
/* 577 */       if (!lookupComparer.compareTo(vector.getItem(i)).isEqual()) {
/* 578 */         return i - 1;
/*     */       }
/*     */     }
/* 581 */     return maxIx - 1;
/*     */   }
/*     */   
/*     */   public static LookupValueComparer createLookupComparer(ValueEval lookupValue)
/*     */   {
/* 586 */     if (lookupValue == BlankEval.instance)
/*     */     {
/*     */ 
/*     */ 
/* 590 */       return new NumberLookupComparer(NumberEval.ZERO);
/*     */     }
/* 592 */     if ((lookupValue instanceof StringEval)) {
/* 593 */       return new StringLookupComparer((StringEval)lookupValue);
/*     */     }
/* 595 */     if ((lookupValue instanceof NumberEval)) {
/* 596 */       return new NumberLookupComparer((NumberEval)lookupValue);
/*     */     }
/* 598 */     if ((lookupValue instanceof BoolEval)) {
/* 599 */       return new BooleanLookupComparer((BoolEval)lookupValue);
/*     */     }
/* 601 */     throw new IllegalArgumentException("Bad lookup value type (" + lookupValue.getClass().getName() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\LookupUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */