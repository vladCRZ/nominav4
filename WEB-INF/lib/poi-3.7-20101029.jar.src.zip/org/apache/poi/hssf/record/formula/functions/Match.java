/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumericValueEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Match
/*     */   extends Var2or3ArgFunction
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*  70 */     return eval(srcRowIndex, srcColumnIndex, arg0, arg1, 1.0D);
/*     */   }
/*     */   
/*     */ 
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */   {
/*     */     double match_type;
/*     */     
/*     */     try
/*     */     {
/*  80 */       match_type = evaluateMatchTypeArg(arg2, srcRowIndex, srcColumnIndex);
/*     */ 
/*     */     }
/*     */     catch (EvaluationException e)
/*     */     {
/*  85 */       return ErrorEval.REF_INVALID;
/*     */     }
/*     */     
/*  88 */     return eval(srcRowIndex, srcColumnIndex, arg0, arg1, match_type);
/*     */   }
/*     */   
/*     */   private static ValueEval eval(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, double match_type)
/*     */   {
/*  93 */     boolean matchExact = match_type == 0.0D;
/*     */     
/*  95 */     boolean findLargestLessThanOrEqual = match_type > 0.0D;
/*     */     try
/*     */     {
/*  98 */       ValueEval lookupValue = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/*  99 */       LookupUtils.ValueVector lookupRange = evaluateLookupRange(arg1);
/* 100 */       int index = findIndexOfValue(lookupValue, lookupRange, matchExact, findLargestLessThanOrEqual);
/* 101 */       return new NumberEval(index + 1);
/*     */     } catch (EvaluationException e) {
/* 103 */       return e.getErrorEval();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class SingleValueVector implements LookupUtils.ValueVector
/*     */   {
/*     */     private final ValueEval _value;
/*     */     
/*     */     public SingleValueVector(ValueEval value) {
/* 112 */       this._value = value;
/*     */     }
/*     */     
/*     */     public ValueEval getItem(int index) {
/* 116 */       if (index != 0) {
/* 117 */         throw new RuntimeException("Invalid index (" + index + ") only zero is allowed");
/*     */       }
/*     */       
/* 120 */       return this._value;
/*     */     }
/*     */     
/*     */     public int getSize() {
/* 124 */       return 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private static LookupUtils.ValueVector evaluateLookupRange(ValueEval eval) throws EvaluationException {
/* 129 */     if ((eval instanceof RefEval)) {
/* 130 */       RefEval re = (RefEval)eval;
/* 131 */       return new SingleValueVector(re.getInnerValueEval());
/*     */     }
/* 133 */     if ((eval instanceof TwoDEval)) {
/* 134 */       LookupUtils.ValueVector result = LookupUtils.createVector((TwoDEval)eval);
/* 135 */       if (result == null) {
/* 136 */         throw new EvaluationException(ErrorEval.NA);
/*     */       }
/* 138 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 142 */     if ((eval instanceof NumericValueEval)) {
/* 143 */       throw new EvaluationException(ErrorEval.NA);
/*     */     }
/* 145 */     if ((eval instanceof StringEval)) {
/* 146 */       StringEval se = (StringEval)eval;
/* 147 */       Double d = OperandResolver.parseDouble(se.getStringValue());
/* 148 */       if (d == null)
/*     */       {
/* 150 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/*     */       
/* 153 */       throw new EvaluationException(ErrorEval.NA);
/*     */     }
/* 155 */     throw new RuntimeException("Unexpected eval type (" + eval.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */   private static double evaluateMatchTypeArg(ValueEval arg, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 162 */     ValueEval match_type = OperandResolver.getSingleValue(arg, srcCellRow, srcCellCol);
/*     */     
/* 164 */     if ((match_type instanceof ErrorEval)) {
/* 165 */       throw new EvaluationException((ErrorEval)match_type);
/*     */     }
/* 167 */     if ((match_type instanceof NumericValueEval)) {
/* 168 */       NumericValueEval ne = (NumericValueEval)match_type;
/* 169 */       return ne.getNumberValue();
/*     */     }
/* 171 */     if ((match_type instanceof StringEval)) {
/* 172 */       StringEval se = (StringEval)match_type;
/* 173 */       Double d = OperandResolver.parseDouble(se.getStringValue());
/* 174 */       if (d == null)
/*     */       {
/* 176 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/*     */       
/* 179 */       return d.doubleValue();
/*     */     }
/* 181 */     throw new RuntimeException("Unexpected match_type type (" + match_type.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findIndexOfValue(ValueEval lookupValue, LookupUtils.ValueVector lookupRange, boolean matchExact, boolean findLargestLessThanOrEqual)
/*     */     throws EvaluationException
/*     */   {
/* 190 */     LookupUtils.LookupValueComparer lookupComparer = createLookupComparer(lookupValue, matchExact);
/*     */     
/* 192 */     int size = lookupRange.getSize();
/* 193 */     if (matchExact) {
/* 194 */       for (int i = 0; i < size; i++) {
/* 195 */         if (lookupComparer.compareTo(lookupRange.getItem(i)).isEqual()) {
/* 196 */           return i;
/*     */         }
/*     */       }
/* 199 */       throw new EvaluationException(ErrorEval.NA);
/*     */     }
/*     */     
/* 202 */     if (findLargestLessThanOrEqual)
/*     */     {
/* 204 */       for (int i = size - 1; i >= 0; i--) {
/* 205 */         LookupUtils.CompareResult cmp = lookupComparer.compareTo(lookupRange.getItem(i));
/* 206 */         if (!cmp.isTypeMismatch())
/*     */         {
/*     */ 
/* 209 */           if (!cmp.isLessThan())
/* 210 */             return i;
/*     */         }
/*     */       }
/* 213 */       throw new EvaluationException(ErrorEval.NA);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 218 */     for (int i = 0; i < size; i++) {
/* 219 */       LookupUtils.CompareResult cmp = lookupComparer.compareTo(lookupRange.getItem(i));
/* 220 */       if (cmp.isEqual()) {
/* 221 */         return i;
/*     */       }
/* 223 */       if (cmp.isGreaterThan()) {
/* 224 */         if (i < 1) {
/* 225 */           throw new EvaluationException(ErrorEval.NA);
/*     */         }
/* 227 */         return i - 1;
/*     */       }
/*     */     }
/*     */     
/* 231 */     throw new EvaluationException(ErrorEval.NA);
/*     */   }
/*     */   
/*     */   private static LookupUtils.LookupValueComparer createLookupComparer(ValueEval lookupValue, boolean matchExact) {
/* 235 */     if ((matchExact) && ((lookupValue instanceof StringEval))) {
/* 236 */       String stringValue = ((StringEval)lookupValue).getStringValue();
/* 237 */       if (isLookupValueWild(stringValue)) {
/* 238 */         throw new RuntimeException("Wildcard lookup values '" + stringValue + "' not supported yet");
/*     */       }
/*     */     }
/*     */     
/* 242 */     return LookupUtils.createLookupComparer(lookupValue);
/*     */   }
/*     */   
/*     */   private static boolean isLookupValueWild(String stringValue) {
/* 246 */     if ((stringValue.indexOf('?') >= 0) || (stringValue.indexOf('*') >= 0)) {
/* 247 */       return true;
/*     */     }
/* 249 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Match.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */