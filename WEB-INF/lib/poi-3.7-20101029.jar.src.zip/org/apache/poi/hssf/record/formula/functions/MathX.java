/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MathX
/*     */ {
/*     */   public static double round(double n, int p)
/*     */   {
/*     */     double retval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     double retval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */     if ((Double.isNaN(n)) || (Double.isInfinite(n))) {
/*  53 */       retval = NaN.0D;
/*     */     } else {
/*     */       double retval;
/*  56 */       if (p != 0) {
/*  57 */         double temp = Math.pow(10.0D, p);
/*  58 */         retval = Math.round(n * temp) / temp;
/*     */       }
/*     */       else {
/*  61 */         retval = Math.round(n);
/*     */       }
/*     */     }
/*     */     
/*  65 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double roundUp(double n, int p)
/*     */   {
/*     */     double retval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     double retval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  86 */     if ((Double.isNaN(n)) || (Double.isInfinite(n))) {
/*  87 */       retval = NaN.0D;
/*     */     } else {
/*     */       double retval;
/*  90 */       if (p != 0) {
/*  91 */         double temp = Math.pow(10.0D, p);
/*  92 */         double nat = Math.abs(n * temp);
/*     */         
/*  94 */         retval = sign(n) * (nat == nat ? nat / temp : Math.round(nat + 0.5D) / temp);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 100 */         double na = Math.abs(n);
/* 101 */         retval = sign(n) * (na == na ? na : na + 1L);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 108 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double roundDown(double n, int p)
/*     */   {
/*     */     double retval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     double retval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     if ((Double.isNaN(n)) || (Double.isInfinite(n))) {
/* 130 */       retval = NaN.0D;
/*     */     } else {
/*     */       double retval;
/* 133 */       if (p != 0) {
/* 134 */         double temp = Math.pow(10.0D, p);
/* 135 */         retval = sign(n) * Math.round(Math.abs(n) * temp - 0.5D) / temp;
/*     */       }
/*     */       else {
/* 138 */         retval = n;
/*     */       }
/*     */     }
/*     */     
/* 142 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static short sign(double d)
/*     */   {
/* 157 */     return (short)(d < 0.0D ? -1 : d == 0.0D ? 0 : 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double average(double[] values)
/*     */   {
/* 169 */     double ave = 0.0D;
/* 170 */     double sum = 0.0D;
/* 171 */     int i = 0; for (int iSize = values.length; i < iSize; i++) {
/* 172 */       sum += values[i];
/*     */     }
/* 174 */     ave = sum / values.length;
/* 175 */     return ave;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double sum(double[] values)
/*     */   {
/* 184 */     double sum = 0.0D;
/* 185 */     int i = 0; for (int iSize = values.length; i < iSize; i++) {
/* 186 */       sum += values[i];
/*     */     }
/* 188 */     return sum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double sumsq(double[] values)
/*     */   {
/* 196 */     double sumsq = 0.0D;
/* 197 */     int i = 0; for (int iSize = values.length; i < iSize; i++) {
/* 198 */       sumsq += values[i] * values[i];
/*     */     }
/* 200 */     return sumsq;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double product(double[] values)
/*     */   {
/* 209 */     double product = 0.0D;
/* 210 */     if ((values != null) && (values.length > 0)) {
/* 211 */       product = 1.0D;
/* 212 */       int i = 0; for (int iSize = values.length; i < iSize; i++) {
/* 213 */         product *= values[i];
/*     */       }
/*     */     }
/* 216 */     return product;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double min(double[] values)
/*     */   {
/* 225 */     double min = Double.POSITIVE_INFINITY;
/* 226 */     int i = 0; for (int iSize = values.length; i < iSize; i++) {
/* 227 */       min = Math.min(min, values[i]);
/*     */     }
/* 229 */     return min;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double max(double[] values)
/*     */   {
/* 238 */     double max = Double.NEGATIVE_INFINITY;
/* 239 */     int i = 0; for (int iSize = values.length; i < iSize; i++) {
/* 240 */       max = Math.max(max, values[i]);
/*     */     }
/* 242 */     return max;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double floor(double n, double s)
/*     */   {
/*     */     double f;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     double f;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 263 */     if (((n < 0.0D) && (s > 0.0D)) || ((n > 0.0D) && (s < 0.0D)) || ((s == 0.0D) && (n != 0.0D))) {
/* 264 */       f = NaN.0D;
/*     */     }
/*     */     else {
/* 267 */       f = (n == 0.0D) || (s == 0.0D) ? 0.0D : Math.floor(n / s) * s;
/*     */     }
/*     */     
/* 270 */     return f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double ceiling(double n, double s)
/*     */   {
/*     */     double c;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     double c;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 291 */     if (((n < 0.0D) && (s > 0.0D)) || ((n > 0.0D) && (s < 0.0D))) {
/* 292 */       c = NaN.0D;
/*     */     }
/*     */     else {
/* 295 */       c = (n == 0.0D) || (s == 0.0D) ? 0.0D : Math.ceil(n / s) * s;
/*     */     }
/*     */     
/* 298 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double factorial(int n)
/*     */   {
/* 312 */     double d = 1.0D;
/*     */     
/* 314 */     if (n >= 0) {
/* 315 */       if (n <= 170) {
/* 316 */         for (int i = 1; i <= n; i++) {
/* 317 */           d *= i;
/*     */         }
/*     */         
/*     */       } else {
/* 321 */         d = Double.POSITIVE_INFINITY;
/*     */       }
/*     */     }
/*     */     else {
/* 325 */       d = NaN.0D;
/*     */     }
/* 327 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double mod(double n, double d)
/*     */   {
/* 347 */     double result = 0.0D;
/*     */     
/* 349 */     if (d == 0.0D) {
/* 350 */       result = NaN.0D;
/*     */     }
/* 352 */     else if (sign(n) == sign(d)) {
/* 353 */       result = n % d;
/*     */     }
/*     */     else {
/* 356 */       result = (n % d + d) % d;
/*     */     }
/*     */     
/* 359 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double acosh(double d)
/*     */   {
/* 367 */     return Math.log(Math.sqrt(Math.pow(d, 2.0D) - 1.0D) + d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double asinh(double d)
/*     */   {
/* 375 */     return Math.log(Math.sqrt(d * d + 1.0D) + d);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double atanh(double d)
/*     */   {
/* 383 */     return Math.log((1.0D + d) / (1.0D - d)) / 2.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double cosh(double d)
/*     */   {
/* 391 */     double ePowX = Math.pow(2.718281828459045D, d);
/* 392 */     double ePowNegX = Math.pow(2.718281828459045D, -d);
/* 393 */     return (ePowX + ePowNegX) / 2.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double sinh(double d)
/*     */   {
/* 401 */     double ePowX = Math.pow(2.718281828459045D, d);
/* 402 */     double ePowNegX = Math.pow(2.718281828459045D, -d);
/* 403 */     return (ePowX - ePowNegX) / 2.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double tanh(double d)
/*     */   {
/* 411 */     double ePowX = Math.pow(2.718281828459045D, d);
/* 412 */     double ePowNegX = Math.pow(2.718281828459045D, -d);
/* 413 */     return (ePowX - ePowNegX) / (ePowX + ePowNegX);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double nChooseK(int n, int k)
/*     */   {
/* 428 */     double d = 1.0D;
/* 429 */     if ((n < 0) || (k < 0) || (n < k)) {
/* 430 */       d = NaN.0D;
/*     */     }
/*     */     else {
/* 433 */       int minnk = Math.min(n - k, k);
/* 434 */       int maxnk = Math.max(n - k, k);
/* 435 */       for (int i = maxnk; i < n; i++) {
/* 436 */         d *= (i + 1);
/*     */       }
/* 438 */       d /= factorial(minnk);
/*     */     }
/*     */     
/* 441 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\MathX.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */