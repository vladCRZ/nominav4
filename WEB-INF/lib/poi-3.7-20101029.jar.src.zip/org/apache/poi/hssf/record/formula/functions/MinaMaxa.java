/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MinaMaxa
/*    */   extends MultiOperandNumericFunction
/*    */ {
/*    */   protected MinaMaxa()
/*    */   {
/* 27 */     super(true, true);
/*    */   }
/*    */   
/* 30 */   public static final Function MAXA = new MinaMaxa() {
/*    */     protected double evaluate(double[] values) {
/* 32 */       return values.length > 0 ? MathX.max(values) : 0.0D;
/*    */     }
/*    */   };
/* 35 */   public static final Function MINA = new MinaMaxa() {
/*    */     protected double evaluate(double[] values) {
/* 37 */       return values.length > 0 ? MathX.min(values) : 0.0D;
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\MinaMaxa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */