/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Mode
/*     */   implements Function
/*     */ {
/*     */   public static double evaluate(double[] v)
/*     */     throws EvaluationException
/*     */   {
/*  48 */     if (v.length < 2) {
/*  49 */       throw new EvaluationException(ErrorEval.NA);
/*     */     }
/*     */     
/*     */ 
/*  53 */     int[] counts = new int[v.length];
/*  54 */     Arrays.fill(counts, 1);
/*  55 */     int i = 0; for (int iSize = v.length; i < iSize; i++) {
/*  56 */       int j = i + 1; for (int jSize = v.length; j < jSize; j++) {
/*  57 */         if (v[i] == v[j])
/*  58 */           counts[i] += 1;
/*     */       }
/*     */     }
/*  61 */     double maxv = 0.0D;
/*  62 */     int maxc = 0;
/*  63 */     int i = 0; for (int iSize = counts.length; i < iSize; i++) {
/*  64 */       if (counts[i] > maxc) {
/*  65 */         maxv = v[i];
/*  66 */         maxc = counts[i];
/*     */       }
/*     */     }
/*  69 */     if (maxc > 1) {
/*  70 */       return maxv;
/*     */     }
/*  72 */     throw new EvaluationException(ErrorEval.NA);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol)
/*     */   {
/*     */     double result;
/*     */     try {
/*  79 */       List<Double> temp = new ArrayList();
/*  80 */       for (int i = 0; i < args.length; i++) {
/*  81 */         collectValues(args[i], temp);
/*     */       }
/*  83 */       double[] values = new double[temp.size()];
/*  84 */       for (int i = 0; i < values.length; i++) {
/*  85 */         values[i] = ((Double)temp.get(i)).doubleValue();
/*     */       }
/*  87 */       result = evaluate(values);
/*     */     } catch (EvaluationException e) {
/*  89 */       return e.getErrorEval();
/*     */     }
/*  91 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   private static void collectValues(ValueEval arg, List<Double> temp) throws EvaluationException {
/*  95 */     if ((arg instanceof TwoDEval)) {
/*  96 */       TwoDEval ae = (TwoDEval)arg;
/*  97 */       int width = ae.getWidth();
/*  98 */       int height = ae.getHeight();
/*  99 */       for (int rrIx = 0; rrIx < height; rrIx++) {
/* 100 */         for (int rcIx = 0; rcIx < width; rcIx++) {
/* 101 */           ValueEval ve1 = ae.getValue(rrIx, rcIx);
/* 102 */           collectValue(ve1, temp, false);
/*     */         }
/*     */       }
/* 105 */       return;
/*     */     }
/* 107 */     if ((arg instanceof RefEval)) {
/* 108 */       RefEval re = (RefEval)arg;
/* 109 */       collectValue(re.getInnerValueEval(), temp, true);
/* 110 */       return;
/*     */     }
/* 112 */     collectValue(arg, temp, true);
/*     */   }
/*     */   
/*     */   private static void collectValue(ValueEval arg, List<Double> temp, boolean mustBeNumber)
/*     */     throws EvaluationException
/*     */   {
/* 118 */     if ((arg instanceof ErrorEval)) {
/* 119 */       throw new EvaluationException((ErrorEval)arg);
/*     */     }
/* 121 */     if ((arg == BlankEval.instance) || ((arg instanceof BoolEval)) || ((arg instanceof StringEval))) {
/* 122 */       if (mustBeNumber) {
/* 123 */         throw EvaluationException.invalidValue();
/*     */       }
/* 125 */       return;
/*     */     }
/* 127 */     if ((arg instanceof NumberEval)) {
/* 128 */       temp.add(new Double(((NumberEval)arg).getNumberValue()));
/* 129 */       return;
/*     */     }
/* 131 */     throw new RuntimeException("Unexpected value type (" + arg.getClass().getName() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Mode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */