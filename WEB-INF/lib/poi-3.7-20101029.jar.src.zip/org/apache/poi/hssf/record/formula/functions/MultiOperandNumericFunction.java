/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MultiOperandNumericFunction
/*     */   implements Function
/*     */ {
/*     */   private final boolean _isReferenceBoolCounted;
/*     */   private final boolean _isBlankCounted;
/*     */   
/*     */   protected MultiOperandNumericFunction(boolean isReferenceBoolCounted, boolean isBlankCounted)
/*     */   {
/*  43 */     this._isReferenceBoolCounted = isReferenceBoolCounted;
/*  44 */     this._isBlankCounted = isBlankCounted;
/*     */   }
/*     */   
/*  47 */   static final double[] EMPTY_DOUBLE_ARRAY = new double[0];
/*     */   private static final int DEFAULT_MAX_NUM_OPERANDS = 30;
/*     */   
/*     */   private static class DoubleList {
/*     */     private double[] _array;
/*     */     private int _count;
/*     */     
/*  54 */     public DoubleList() { this._array = new double[8];
/*  55 */       this._count = 0;
/*     */     }
/*     */     
/*     */     public double[] toArray() {
/*  59 */       if (this._count < 1) {
/*  60 */         return MultiOperandNumericFunction.EMPTY_DOUBLE_ARRAY;
/*     */       }
/*  62 */       double[] result = new double[this._count];
/*  63 */       System.arraycopy(this._array, 0, result, 0, this._count);
/*  64 */       return result;
/*     */     }
/*     */     
/*     */     private void ensureCapacity(int reqSize) {
/*  68 */       if (reqSize > this._array.length) {
/*  69 */         int newSize = reqSize * 3 / 2;
/*  70 */         double[] newArr = new double[newSize];
/*  71 */         System.arraycopy(this._array, 0, newArr, 0, this._count);
/*  72 */         this._array = newArr;
/*     */       }
/*     */     }
/*     */     
/*     */     public void add(double value) {
/*  77 */       ensureCapacity(this._count + 1);
/*  78 */       this._array[this._count] = value;
/*  79 */       this._count += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol)
/*     */   {
/*     */     double d;
/*     */     try
/*     */     {
/*  89 */       double[] values = getNumberArray(args);
/*  90 */       d = evaluate(values);
/*     */     } catch (EvaluationException e) {
/*  92 */       return e.getErrorEval();
/*     */     }
/*     */     
/*  95 */     if ((Double.isNaN(d)) || (Double.isInfinite(d))) {
/*  96 */       return ErrorEval.NUM_ERROR;
/*     */     }
/*  98 */     return new NumberEval(d);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract double evaluate(double[] paramArrayOfDouble)
/*     */     throws EvaluationException;
/*     */   
/*     */ 
/*     */   protected int getMaxNumOperands()
/*     */   {
/* 108 */     return 30;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final double[] getNumberArray(ValueEval[] operands)
/*     */     throws EvaluationException
/*     */   {
/* 121 */     if (operands.length > getMaxNumOperands()) {
/* 122 */       throw EvaluationException.invalidValue();
/*     */     }
/* 124 */     DoubleList retval = new DoubleList();
/*     */     
/* 126 */     int i = 0; for (int iSize = operands.length; i < iSize; i++) {
/* 127 */       collectValues(operands[i], retval);
/*     */     }
/* 129 */     return retval.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void collectValues(ValueEval operand, DoubleList temp)
/*     */     throws EvaluationException
/*     */   {
/* 137 */     if ((operand instanceof TwoDEval)) {
/* 138 */       TwoDEval ae = (TwoDEval)operand;
/* 139 */       int width = ae.getWidth();
/* 140 */       int height = ae.getHeight();
/* 141 */       for (int rrIx = 0; rrIx < height; rrIx++) {
/* 142 */         for (int rcIx = 0; rcIx < width; rcIx++) {
/* 143 */           ValueEval ve = ae.getValue(rrIx, rcIx);
/* 144 */           collectValue(ve, true, temp);
/*     */         }
/*     */       }
/* 147 */       return;
/*     */     }
/* 149 */     if ((operand instanceof RefEval)) {
/* 150 */       RefEval re = (RefEval)operand;
/* 151 */       collectValue(re.getInnerValueEval(), true, temp);
/* 152 */       return;
/*     */     }
/* 154 */     collectValue(operand, false, temp);
/*     */   }
/*     */   
/* 157 */   private void collectValue(ValueEval ve, boolean isViaReference, DoubleList temp) throws EvaluationException { if (ve == null) {
/* 158 */       throw new IllegalArgumentException("ve must not be null");
/*     */     }
/* 160 */     if ((ve instanceof NumberEval)) {
/* 161 */       NumberEval ne = (NumberEval)ve;
/* 162 */       temp.add(ne.getNumberValue());
/* 163 */       return;
/*     */     }
/* 165 */     if ((ve instanceof ErrorEval)) {
/* 166 */       throw new EvaluationException((ErrorEval)ve);
/*     */     }
/* 168 */     if ((ve instanceof StringEval)) {
/* 169 */       if (isViaReference)
/*     */       {
/* 171 */         return;
/*     */       }
/* 173 */       String s = ((StringEval)ve).getStringValue();
/* 174 */       Double d = OperandResolver.parseDouble(s);
/* 175 */       if (d == null) {
/* 176 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/* 178 */       temp.add(d.doubleValue());
/* 179 */       return;
/*     */     }
/* 181 */     if ((ve instanceof BoolEval)) {
/* 182 */       if ((!isViaReference) || (this._isReferenceBoolCounted)) {
/* 183 */         BoolEval boolEval = (BoolEval)ve;
/* 184 */         temp.add(boolEval.getNumberValue());
/*     */       }
/* 186 */       return;
/*     */     }
/* 188 */     if (ve == BlankEval.instance) {
/* 189 */       if (this._isBlankCounted) {
/* 190 */         temp.add(0.0D);
/*     */       }
/* 192 */       return;
/*     */     }
/* 194 */     throw new RuntimeException("Invalid ValueEval type passed for conversion: (" + ve.getClass() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\MultiOperandNumericFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */