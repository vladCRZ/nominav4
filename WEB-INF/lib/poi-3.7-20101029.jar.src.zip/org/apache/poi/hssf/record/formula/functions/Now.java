/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.hssf.usermodel.HSSFDateUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Now
/*    */   extends Fixed0ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 34 */     Date now = new Date(System.currentTimeMillis());
/* 35 */     return new NumberEval(HSSFDateUtil.getExcelDate(now));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Now.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */