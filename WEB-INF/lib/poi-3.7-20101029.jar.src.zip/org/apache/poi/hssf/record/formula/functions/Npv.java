/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Npv
/*     */   implements Function2Arg, Function3Arg, Function4Arg
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*     */     double result;
/*     */     try
/*     */     {
/*  40 */       double rate = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  41 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*  42 */       result = evaluate(rate, new double[] { d1 });
/*  43 */       NumericFunction.checkValue(result);
/*     */     } catch (EvaluationException e) {
/*  45 */       return e.getErrorEval();
/*     */     }
/*  47 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2) {
/*     */     double result;
/*     */     try {
/*  53 */       double rate = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  54 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*  55 */       double d2 = NumericFunction.singleOperandEvaluate(arg2, srcRowIndex, srcColumnIndex);
/*  56 */       result = evaluate(rate, new double[] { d1, d2 });
/*  57 */       NumericFunction.checkValue(result);
/*     */     } catch (EvaluationException e) {
/*  59 */       return e.getErrorEval();
/*     */     }
/*  61 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3) {
/*     */     double result;
/*     */     try {
/*  67 */       double rate = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  68 */       double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*  69 */       double d2 = NumericFunction.singleOperandEvaluate(arg2, srcRowIndex, srcColumnIndex);
/*  70 */       double d3 = NumericFunction.singleOperandEvaluate(arg3, srcRowIndex, srcColumnIndex);
/*  71 */       result = evaluate(rate, new double[] { d1, d2, d3 });
/*  72 */       NumericFunction.checkValue(result);
/*     */     } catch (EvaluationException e) {
/*  74 */       return e.getErrorEval();
/*     */     }
/*  76 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex) {
/*  80 */     int nArgs = args.length;
/*  81 */     if (nArgs < 2) {
/*  82 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*  84 */     int np = nArgs - 1;
/*  85 */     double[] ds = new double[np];
/*     */     double result;
/*     */     try {
/*  88 */       double rate = NumericFunction.singleOperandEvaluate(args[0], srcRowIndex, srcColumnIndex);
/*  89 */       for (int i = 0; i < ds.length; i++) {
/*  90 */         ds[i] = NumericFunction.singleOperandEvaluate(args[(i + 1)], srcRowIndex, srcColumnIndex);
/*     */       }
/*  92 */       result = evaluate(rate, ds);
/*  93 */       NumericFunction.checkValue(result);
/*     */     } catch (EvaluationException e) {
/*  95 */       return e.getErrorEval();
/*     */     }
/*  97 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   private static double evaluate(double rate, double... ds) {
/* 101 */     double sum = 0.0D;
/* 102 */     for (int i = 0; i < ds.length; i++) {
/* 103 */       sum += ds[i] / Math.pow(rate + 1.0D, i);
/*     */     }
/* 105 */     return sum;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Npv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */