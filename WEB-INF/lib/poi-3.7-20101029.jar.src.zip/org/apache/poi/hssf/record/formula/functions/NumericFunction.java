/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NumericFunction
/*     */   implements Function
/*     */ {
/*     */   static final double ZERO = 0.0D;
/*     */   static final double TEN = 10.0D;
/*  31 */   static final double LOG_10_TO_BASE_e = Math.log(10.0D);
/*     */   
/*     */   protected static final double singleOperandEvaluate(ValueEval arg, int srcRowIndex, int srcColumnIndex) throws EvaluationException {
/*  34 */     if (arg == null) {
/*  35 */       throw new IllegalArgumentException("arg must not be null");
/*     */     }
/*  37 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcRowIndex, srcColumnIndex);
/*  38 */     double result = OperandResolver.coerceValueToDouble(ve);
/*  39 */     checkValue(result);
/*  40 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   static final void checkValue(double result)
/*     */     throws EvaluationException
/*     */   {
/*  47 */     if ((Double.isNaN(result)) || (Double.isInfinite(result))) {
/*  48 */       throw new EvaluationException(ErrorEval.NUM_ERROR);
/*     */     }
/*     */   }
/*     */   
/*     */   public final ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol) {
/*     */     double result;
/*     */     try {
/*  55 */       result = eval(args, srcCellRow, srcCellCol);
/*  56 */       checkValue(result);
/*     */     } catch (EvaluationException e) {
/*  58 */       return e.getErrorEval();
/*     */     }
/*  60 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract double eval(ValueEval[] paramArrayOfValueEval, int paramInt1, int paramInt2)
/*     */     throws EvaluationException;
/*     */   
/*     */   public static abstract class OneArg
/*     */     extends Fixed1ArgFunction
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*     */     {
/*     */       double result;
/*     */       try
/*     */       {
/*  75 */         double d = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/*  76 */         result = evaluate(d);
/*  77 */         NumericFunction.checkValue(result);
/*     */       } catch (EvaluationException e) {
/*  79 */         return e.getErrorEval();
/*     */       }
/*  81 */       return new NumberEval(result);
/*     */     }
/*     */     
/*  84 */     protected final double eval(ValueEval[] args, int srcCellRow, int srcCellCol) throws EvaluationException { if (args.length != 1) {
/*  85 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/*  87 */       double d = NumericFunction.singleOperandEvaluate(args[0], srcCellRow, srcCellCol);
/*  88 */       return evaluate(d);
/*     */     }
/*     */     
/*     */     protected abstract double evaluate(double paramDouble) throws EvaluationException;
/*     */   }
/*     */   
/*     */   public static abstract class TwoArg
/*     */     extends Fixed2ArgFunction
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */     {
/*     */       double result;
/*     */       try
/*     */       {
/* 102 */         double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 103 */         double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/* 104 */         result = evaluate(d0, d1);
/* 105 */         NumericFunction.checkValue(result);
/*     */       } catch (EvaluationException e) {
/* 107 */         return e.getErrorEval();
/*     */       }
/* 109 */       return new NumberEval(result);
/*     */     }
/*     */     
/*     */ 
/*     */     protected abstract double evaluate(double paramDouble1, double paramDouble2)
/*     */       throws EvaluationException;
/*     */   }
/*     */   
/* 117 */   public static final Function ABS = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 119 */       return Math.abs(d);
/*     */     }
/*     */   };
/* 122 */   public static final Function ACOS = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 124 */       return Math.acos(d);
/*     */     }
/*     */   };
/* 127 */   public static final Function ACOSH = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 129 */       return MathX.acosh(d);
/*     */     }
/*     */   };
/* 132 */   public static final Function ASIN = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 134 */       return Math.asin(d);
/*     */     }
/*     */   };
/* 137 */   public static final Function ASINH = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 139 */       return MathX.asinh(d);
/*     */     }
/*     */   };
/* 142 */   public static final Function ATAN = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 144 */       return Math.atan(d);
/*     */     }
/*     */   };
/* 147 */   public static final Function ATANH = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 149 */       return MathX.atanh(d);
/*     */     }
/*     */   };
/* 152 */   public static final Function COS = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 154 */       return Math.cos(d);
/*     */     }
/*     */   };
/* 157 */   public static final Function COSH = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 159 */       return MathX.cosh(d);
/*     */     }
/*     */   };
/* 162 */   public static final Function DEGREES = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 164 */       return Math.toDegrees(d);
/*     */     }
/*     */   };
/* 167 */   static final NumberEval DOLLAR_ARG2_DEFAULT = new NumberEval(2.0D);
/* 168 */   public static final Function DOLLAR = new Var1or2ArgFunction() {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/* 170 */       return evaluate(srcRowIndex, srcColumnIndex, arg0, NumericFunction.DOLLAR_ARG2_DEFAULT);
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */     {
/*     */       double val;
/*     */       double d1;
/*     */       try {
/* 178 */         val = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 179 */         d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*     */       } catch (EvaluationException e) {
/* 181 */         return e.getErrorEval();
/*     */       }
/*     */       
/* 184 */       int nPlaces = (int)d1;
/*     */       
/* 186 */       if (nPlaces > 127) {
/* 187 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */       return new NumberEval(val);
/*     */     }
/*     */   };
/* 197 */   public static final Function EXP = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 199 */       return Math.pow(2.718281828459045D, d);
/*     */     }
/*     */   };
/* 202 */   public static final Function FACT = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 204 */       return MathX.factorial((int)d);
/*     */     }
/*     */   };
/* 207 */   public static final Function INT = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 209 */       return Math.round(d - 0.5D);
/*     */     }
/*     */   };
/* 212 */   public static final Function LN = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 214 */       return Math.log(d);
/*     */     }
/*     */   };
/* 217 */   public static final Function LOG10 = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 219 */       return Math.log(d) / NumericFunction.LOG_10_TO_BASE_e;
/*     */     }
/*     */   };
/* 222 */   public static final Function RADIANS = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 224 */       return Math.toRadians(d);
/*     */     }
/*     */   };
/* 227 */   public static final Function SIGN = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 229 */       return MathX.sign(d);
/*     */     }
/*     */   };
/* 232 */   public static final Function SIN = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 234 */       return Math.sin(d);
/*     */     }
/*     */   };
/* 237 */   public static final Function SINH = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 239 */       return MathX.sinh(d);
/*     */     }
/*     */   };
/* 242 */   public static final Function SQRT = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 244 */       return Math.sqrt(d);
/*     */     }
/*     */   };
/*     */   
/* 248 */   public static final Function TAN = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 250 */       return Math.tan(d);
/*     */     }
/*     */   };
/* 253 */   public static final Function TANH = new OneArg() {
/*     */     protected double evaluate(double d) {
/* 255 */       return MathX.tanh(d);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/* 261 */   public static final Function ATAN2 = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) throws EvaluationException {
/* 263 */       if ((d0 == 0.0D) && (d1 == 0.0D)) {
/* 264 */         throw new EvaluationException(ErrorEval.DIV_ZERO);
/*     */       }
/* 266 */       return Math.atan2(d1, d0);
/*     */     }
/*     */   };
/* 269 */   public static final Function CEILING = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) {
/* 271 */       return MathX.ceiling(d0, d1);
/*     */     }
/*     */   };
/* 274 */   public static final Function COMBIN = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) throws EvaluationException {
/* 276 */       if ((d0 > 2.147483647E9D) || (d1 > 2.147483647E9D)) {
/* 277 */         throw new EvaluationException(ErrorEval.NUM_ERROR);
/*     */       }
/* 279 */       return MathX.nChooseK((int)d0, (int)d1);
/*     */     }
/*     */   };
/* 282 */   public static final Function FLOOR = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) throws EvaluationException {
/* 284 */       if (d1 == 0.0D) {
/* 285 */         if (d0 == 0.0D) {
/* 286 */           return 0.0D;
/*     */         }
/* 288 */         throw new EvaluationException(ErrorEval.DIV_ZERO);
/*     */       }
/* 290 */       return MathX.floor(d0, d1);
/*     */     }
/*     */   };
/* 293 */   public static final Function MOD = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) throws EvaluationException {
/* 295 */       if (d1 == 0.0D) {
/* 296 */         throw new EvaluationException(ErrorEval.DIV_ZERO);
/*     */       }
/* 298 */       return MathX.mod(d0, d1);
/*     */     }
/*     */   };
/* 301 */   public static final Function POWER = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) {
/* 303 */       return Math.pow(d0, d1);
/*     */     }
/*     */   };
/* 306 */   public static final Function ROUND = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) {
/* 308 */       return MathX.round(d0, (int)d1);
/*     */     }
/*     */   };
/* 311 */   public static final Function ROUNDDOWN = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) {
/* 313 */       return MathX.roundDown(d0, (int)d1);
/*     */     }
/*     */   };
/* 316 */   public static final Function ROUNDUP = new TwoArg() {
/*     */     protected double evaluate(double d0, double d1) {
/* 318 */       return MathX.roundUp(d0, (int)d1);
/*     */     }
/*     */   };
/* 321 */   static final NumberEval TRUNC_ARG2_DEFAULT = new NumberEval(0.0D);
/* 322 */   public static final Function TRUNC = new Var1or2ArgFunction()
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/* 325 */       return evaluate(srcRowIndex, srcColumnIndex, arg0, NumericFunction.TRUNC_ARG2_DEFAULT);
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1) {
/*     */       double result;
/*     */       try {
/* 331 */         double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 332 */         double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/* 333 */         double multi = Math.pow(10.0D, d1);
/* 334 */         result = Math.floor(d0 * multi) / multi;
/* 335 */         NumericFunction.checkValue(result);
/*     */       } catch (EvaluationException e) {
/* 337 */         return e.getErrorEval();
/*     */       }
/* 339 */       return new NumberEval(result);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   private static final class Log
/*     */     extends Var1or2ArgFunction
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*     */     {
/*     */       double result;
/*     */       try
/*     */       {
/* 352 */         double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 353 */         result = Math.log(d0) / NumericFunction.LOG_10_TO_BASE_e;
/* 354 */         NumericFunction.checkValue(result);
/*     */       } catch (EvaluationException e) {
/* 356 */         return e.getErrorEval();
/*     */       }
/* 358 */       return new NumberEval(result);
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1) {
/*     */       double result;
/*     */       try {
/* 364 */         double d0 = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 365 */         double d1 = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/* 366 */         double logE = Math.log(d0);
/* 367 */         double base = d1;
/* 368 */         double result; if (base == 2.718281828459045D) {
/* 369 */           result = logE;
/*     */         } else {
/* 371 */           result = logE / Math.log(base);
/*     */         }
/* 373 */         NumericFunction.checkValue(result);
/*     */       } catch (EvaluationException e) {
/* 375 */         return e.getErrorEval();
/*     */       }
/* 377 */       return new NumberEval(result);
/*     */     }
/*     */   }
/*     */   
/* 381 */   public static final Function LOG = new Log();
/*     */   
/* 383 */   static final NumberEval PI_EVAL = new NumberEval(3.141592653589793D);
/* 384 */   public static final Function PI = new Fixed0ArgFunction() {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex) {
/* 386 */       return NumericFunction.PI_EVAL;
/*     */     }
/*     */   };
/* 389 */   public static final Function RAND = new Fixed0ArgFunction() {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex) {
/* 391 */       return new NumberEval(Math.random());
/*     */     }
/*     */   };
/* 394 */   public static final Function POISSON = new Fixed3ArgFunction()
/*     */   {
/*     */     private static final double DEFAULT_RETURN_RESULT = 1.0D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean isDefaultResult(double x, double mean)
/*     */     {
/* 408 */       if ((x == 0.0D) && (mean == 0.0D)) {
/* 409 */         return true;
/*     */       }
/* 411 */       return false;
/*     */     }
/*     */     
/*     */     private boolean checkArgument(double aDouble) throws EvaluationException
/*     */     {
/* 416 */       NumericFunction.checkValue(aDouble);
/*     */       
/*     */ 
/* 419 */       if (aDouble < 0.0D) {
/* 420 */         throw new EvaluationException(ErrorEval.NUM_ERROR);
/*     */       }
/*     */       
/* 423 */       return true;
/*     */     }
/*     */     
/*     */     private double probability(int k, double lambda) {
/* 427 */       return Math.pow(lambda, k) * Math.exp(-lambda) / factorial(k);
/*     */     }
/*     */     
/*     */     private double cumulativeProbability(int x, double lambda) {
/* 431 */       double result = 0.0D;
/* 432 */       for (int k = 0; k <= x; k++) {
/* 433 */         result += probability(k, lambda);
/*     */       }
/* 435 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 439 */     private final long[] FACTORIALS = { 1L, 1L, 2L, 6L, 24L, 120L, 720L, 5040L, 40320L, 362880L, 3628800L, 39916800L, 479001600L, 6227020800L, 87178291200L, 1307674368000L, 20922789888000L, 355687428096000L, 6402373705728000L, 121645100408832000L, 2432902008176640000L };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public long factorial(int n)
/*     */     {
/* 450 */       if ((n < 0) || (n > 20)) {
/* 451 */         throw new IllegalArgumentException("Valid argument should be in the range [0..20]");
/*     */       }
/* 453 */       return this.FACTORIALS[n];
/*     */     }
/*     */     
/*     */ 
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */     {
/* 459 */       double mean = 0.0D;
/* 460 */       double x = 0.0D;
/* 461 */       boolean cumulative = ((BoolEval)arg2).getBooleanValue();
/* 462 */       double result = 0.0D;
/*     */       try
/*     */       {
/* 465 */         x = NumericFunction.singleOperandEvaluate(arg0, srcRowIndex, srcColumnIndex);
/* 466 */         mean = NumericFunction.singleOperandEvaluate(arg1, srcRowIndex, srcColumnIndex);
/*     */         
/*     */ 
/*     */ 
/* 470 */         if (isDefaultResult(x, mean)) {
/* 471 */           return new NumberEval(1.0D);
/*     */         }
/*     */         
/* 474 */         checkArgument(x);
/* 475 */         checkArgument(mean);
/*     */         
/*     */ 
/* 478 */         if (cumulative) {
/* 479 */           result = cumulativeProbability((int)x, mean);
/*     */         } else {
/* 481 */           result = probability((int)x, mean);
/*     */         }
/*     */         
/*     */ 
/* 485 */         NumericFunction.checkValue(result);
/*     */       }
/*     */       catch (EvaluationException e) {
/* 488 */         return e.getErrorEval();
/*     */       }
/*     */       
/* 491 */       return new NumberEval(result);
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\NumericFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */