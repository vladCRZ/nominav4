/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Odd
/*    */   extends NumericFunction.OneArg
/*    */ {
/*    */   private static final long PARITY_MASK = -2L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected double evaluate(double d)
/*    */   {
/* 28 */     if (d == 0.0D) {
/* 29 */       return 1.0D;
/*    */     }
/* 31 */     if (d > 0.0D) {
/* 32 */       return calcOdd(d);
/*    */     }
/* 34 */     return -calcOdd(-d);
/*    */   }
/*    */   
/*    */   private static long calcOdd(double d) {
/* 38 */     double dpm1 = d + 1.0D;
/* 39 */     long x = dpm1 & 0xFFFFFFFFFFFFFFFE;
/* 40 */     if (x == dpm1) {
/* 41 */       return x - 1L;
/*    */     }
/* 43 */     return x + 1L;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Odd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */