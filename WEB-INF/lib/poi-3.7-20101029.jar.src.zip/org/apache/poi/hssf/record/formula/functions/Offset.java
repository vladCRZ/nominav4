/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.AreaEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Offset
/*     */   implements Function
/*     */ {
/*     */   private static final int LAST_VALID_ROW_INDEX = 65535;
/*     */   private static final int LAST_VALID_COLUMN_INDEX = 255;
/*     */   
/*     */   static final class LinearOffsetRange
/*     */   {
/*     */     private final int _offset;
/*     */     private final int _length;
/*     */     
/*     */     public LinearOffsetRange(int offset, int length)
/*     */     {
/*  58 */       if (length == 0)
/*     */       {
/*  60 */         throw new RuntimeException("length may not be zero");
/*     */       }
/*  62 */       this._offset = offset;
/*  63 */       this._length = length;
/*     */     }
/*     */     
/*     */     public short getFirstIndex() {
/*  67 */       return (short)this._offset;
/*     */     }
/*     */     
/*  70 */     public short getLastIndex() { return (short)(this._offset + this._length - 1); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public LinearOffsetRange normaliseAndTranslate(int translationAmount)
/*     */     {
/*  85 */       if (this._length > 0) {
/*  86 */         if (translationAmount == 0) {
/*  87 */           return this;
/*     */         }
/*  89 */         return new LinearOffsetRange(translationAmount + this._offset, this._length);
/*     */       }
/*  91 */       return new LinearOffsetRange(translationAmount + this._offset + this._length + 1, -this._length);
/*     */     }
/*     */     
/*     */     public boolean isOutOfBounds(int lowValidIx, int highValidIx) {
/*  95 */       if (this._offset < lowValidIx) {
/*  96 */         return true;
/*     */       }
/*  98 */       if (getLastIndex() > highValidIx) {
/*  99 */         return true;
/*     */       }
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     public String toString() { StringBuffer sb = new StringBuffer(64);
/* 105 */       sb.append(getClass().getName()).append(" [");
/* 106 */       sb.append(this._offset).append("...").append(getLastIndex());
/* 107 */       sb.append("]");
/* 108 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class BaseRef
/*     */   {
/*     */     private final int _firstRowIndex;
/*     */     private final int _firstColumnIndex;
/*     */     private final int _width;
/*     */     private final int _height;
/*     */     private final RefEval _refEval;
/*     */     private final AreaEval _areaEval;
/*     */     
/*     */     public BaseRef(RefEval re)
/*     */     {
/* 124 */       this._refEval = re;
/* 125 */       this._areaEval = null;
/* 126 */       this._firstRowIndex = re.getRow();
/* 127 */       this._firstColumnIndex = re.getColumn();
/* 128 */       this._height = 1;
/* 129 */       this._width = 1;
/*     */     }
/*     */     
/*     */     public BaseRef(AreaEval ae) {
/* 133 */       this._refEval = null;
/* 134 */       this._areaEval = ae;
/* 135 */       this._firstRowIndex = ae.getFirstRow();
/* 136 */       this._firstColumnIndex = ae.getFirstColumn();
/* 137 */       this._height = (ae.getLastRow() - ae.getFirstRow() + 1);
/* 138 */       this._width = (ae.getLastColumn() - ae.getFirstColumn() + 1);
/*     */     }
/*     */     
/*     */     public int getWidth() {
/* 142 */       return this._width;
/*     */     }
/*     */     
/* 145 */     public int getHeight() { return this._height; }
/*     */     
/*     */     public int getFirstRowIndex() {
/* 148 */       return this._firstRowIndex;
/*     */     }
/*     */     
/* 151 */     public int getFirstColumnIndex() { return this._firstColumnIndex; }
/*     */     
/*     */ 
/*     */     public AreaEval offset(int relFirstRowIx, int relLastRowIx, int relFirstColIx, int relLastColIx)
/*     */     {
/* 156 */       if (this._refEval == null) {
/* 157 */         return this._areaEval.offset(relFirstRowIx, relLastRowIx, relFirstColIx, relLastColIx);
/*     */       }
/* 159 */       return this._refEval.offset(relFirstRowIx, relLastRowIx, relFirstColIx, relLastColIx);
/*     */     }
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol) {
/* 164 */     if ((args.length < 3) || (args.length > 5)) {
/* 165 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*     */     try
/*     */     {
/* 169 */       BaseRef baseRef = evaluateBaseRef(args[0]);
/* 170 */       int rowOffset = evaluateIntArg(args[1], srcCellRow, srcCellCol);
/* 171 */       int columnOffset = evaluateIntArg(args[2], srcCellRow, srcCellCol);
/* 172 */       int height = baseRef.getHeight();
/* 173 */       int width = baseRef.getWidth();
/* 174 */       switch (args.length) {
/*     */       case 5: 
/* 176 */         width = evaluateIntArg(args[4], srcCellRow, srcCellCol);
/*     */       case 4: 
/* 178 */         height = evaluateIntArg(args[3], srcCellRow, srcCellCol);
/*     */       }
/*     */       
/* 181 */       if ((height == 0) || (width == 0)) {
/* 182 */         return ErrorEval.REF_INVALID;
/*     */       }
/* 184 */       LinearOffsetRange rowOffsetRange = new LinearOffsetRange(rowOffset, height);
/* 185 */       LinearOffsetRange colOffsetRange = new LinearOffsetRange(columnOffset, width);
/* 186 */       return createOffset(baseRef, rowOffsetRange, colOffsetRange);
/*     */     } catch (EvaluationException e) {
/* 188 */       return e.getErrorEval();
/*     */     }
/*     */   }
/*     */   
/*     */   private static AreaEval createOffset(BaseRef baseRef, LinearOffsetRange orRow, LinearOffsetRange orCol) throws EvaluationException
/*     */   {
/* 194 */     LinearOffsetRange absRows = orRow.normaliseAndTranslate(baseRef.getFirstRowIndex());
/* 195 */     LinearOffsetRange absCols = orCol.normaliseAndTranslate(baseRef.getFirstColumnIndex());
/*     */     
/* 197 */     if (absRows.isOutOfBounds(0, 65535)) {
/* 198 */       throw new EvaluationException(ErrorEval.REF_INVALID);
/*     */     }
/* 200 */     if (absCols.isOutOfBounds(0, 255)) {
/* 201 */       throw new EvaluationException(ErrorEval.REF_INVALID);
/*     */     }
/* 203 */     return baseRef.offset(orRow.getFirstIndex(), orRow.getLastIndex(), orCol.getFirstIndex(), orCol.getLastIndex());
/*     */   }
/*     */   
/*     */   private static BaseRef evaluateBaseRef(ValueEval eval) throws EvaluationException
/*     */   {
/* 208 */     if ((eval instanceof RefEval)) {
/* 209 */       return new BaseRef((RefEval)eval);
/*     */     }
/* 211 */     if ((eval instanceof AreaEval)) {
/* 212 */       return new BaseRef((AreaEval)eval);
/*     */     }
/* 214 */     if ((eval instanceof ErrorEval)) {
/* 215 */       throw new EvaluationException((ErrorEval)eval);
/*     */     }
/* 217 */     throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */   }
/*     */   
/*     */ 
/*     */   static int evaluateIntArg(ValueEval eval, int srcCellRow, int srcCellCol)
/*     */     throws EvaluationException
/*     */   {
/* 224 */     ValueEval ve = OperandResolver.getSingleValue(eval, srcCellRow, srcCellCol);
/* 225 */     return OperandResolver.coerceValueToInt(ve);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Offset.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */