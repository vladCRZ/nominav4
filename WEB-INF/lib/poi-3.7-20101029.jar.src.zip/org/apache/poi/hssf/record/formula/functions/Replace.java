/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Replace
/*    */   extends Fixed4ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3)
/*    */   {
/*    */     String oldStr;
/*    */     int startNum;
/*    */     int numChars;
/*    */     String newStr;
/*    */     try
/*    */     {
/* 50 */       oldStr = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/* 51 */       startNum = TextFunction.evaluateIntArg(arg1, srcRowIndex, srcColumnIndex);
/* 52 */       numChars = TextFunction.evaluateIntArg(arg2, srcRowIndex, srcColumnIndex);
/* 53 */       newStr = TextFunction.evaluateStringArg(arg3, srcRowIndex, srcColumnIndex);
/*    */     } catch (EvaluationException e) {
/* 55 */       return e.getErrorEval();
/*    */     }
/*    */     
/* 58 */     if ((startNum < 1) || (numChars < 0)) {
/* 59 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/* 61 */     StringBuffer strBuff = new StringBuffer(oldStr);
/*    */     
/* 63 */     if ((startNum <= oldStr.length()) && (numChars != 0)) {
/* 64 */       strBuff.delete(startNum - 1, startNum - 1 + numChars);
/*    */     }
/*    */     
/* 67 */     if (startNum > strBuff.length()) {
/* 68 */       strBuff.append(newStr);
/*    */     } else {
/* 70 */       strBuff.insert(startNum - 1, newStr);
/*    */     }
/* 72 */     return new StringEval(strBuff.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Replace.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */