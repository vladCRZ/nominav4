/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.AreaEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RowFunc
/*    */   implements Function0Arg, Function1Arg
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 34 */     return new NumberEval(srcRowIndex + 1);
/*    */   }
/*    */   
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/*    */     int rnum;
/* 39 */     if ((arg0 instanceof AreaEval)) {
/* 40 */       rnum = ((AreaEval)arg0).getFirstRow(); } else { int rnum;
/* 41 */       if ((arg0 instanceof RefEval)) {
/* 42 */         rnum = ((RefEval)arg0).getRow();
/*    */       }
/*    */       else
/* 45 */         return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     int rnum;
/* 48 */     return new NumberEval(rnum + 1);
/*    */   }
/*    */   
/* 51 */   public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex) { switch (args.length) {
/*    */     case 1: 
/* 53 */       return evaluate(srcRowIndex, srcColumnIndex, args[0]);
/*    */     case 0: 
/* 55 */       return new NumberEval(srcRowIndex + 1);
/*    */     }
/* 57 */     return ErrorEval.VALUE_INVALID;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\RowFunc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */