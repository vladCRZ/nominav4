/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.TwoDEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Rows
/*    */   extends Fixed1ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*    */   {
/*    */     int result;
/* 36 */     if ((arg0 instanceof TwoDEval)) {
/* 37 */       result = ((TwoDEval)arg0).getHeight(); } else { int result;
/* 38 */       if ((arg0 instanceof RefEval)) {
/* 39 */         result = 1;
/*    */       } else
/* 41 */         return ErrorEval.VALUE_INVALID; }
/*    */     int result;
/* 43 */     return new NumberEval(result);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Rows.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */