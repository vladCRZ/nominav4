/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StatsLib
/*     */ {
/*     */   public static double avedev(double[] v)
/*     */   {
/*  39 */     double r = 0.0D;
/*  40 */     double m = 0.0D;
/*  41 */     double s = 0.0D;
/*  42 */     int i = 0; for (int iSize = v.length; i < iSize; i++) {
/*  43 */       s += v[i];
/*     */     }
/*  45 */     m = s / v.length;
/*  46 */     s = 0.0D;
/*  47 */     int i = 0; for (int iSize = v.length; i < iSize; i++) {
/*  48 */       s += Math.abs(v[i] - m);
/*     */     }
/*  50 */     r = s / v.length;
/*  51 */     return r;
/*     */   }
/*     */   
/*     */   public static double stdev(double[] v) {
/*  55 */     double r = NaN.0D;
/*  56 */     if ((v != null) && (v.length > 1)) {
/*  57 */       r = Math.sqrt(devsq(v) / (v.length - 1));
/*     */     }
/*  59 */     return r;
/*     */   }
/*     */   
/*     */   public static double median(double[] v)
/*     */   {
/*  64 */     double r = NaN.0D;
/*     */     
/*  66 */     if ((v != null) && (v.length >= 1)) {
/*  67 */       int n = v.length;
/*  68 */       Arrays.sort(v);
/*  69 */       r = n % 2 == 0 ? (v[(n / 2)] + v[(n / 2 - 1)]) / 2.0D : v[(n / 2)];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  74 */     return r;
/*     */   }
/*     */   
/*     */   public static double devsq(double[] v)
/*     */   {
/*  79 */     double r = NaN.0D;
/*  80 */     if ((v != null) && (v.length >= 1)) {
/*  81 */       double m = 0.0D;
/*  82 */       double s = 0.0D;
/*  83 */       int n = v.length;
/*  84 */       for (int i = 0; i < n; i++) {
/*  85 */         s += v[i];
/*     */       }
/*  87 */       m = s / n;
/*  88 */       s = 0.0D;
/*  89 */       for (int i = 0; i < n; i++) {
/*  90 */         s += (v[i] - m) * (v[i] - m);
/*     */       }
/*     */       
/*  93 */       r = n == 1 ? 0.0D : s;
/*     */     }
/*     */     
/*     */ 
/*  97 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double kthLargest(double[] v, int k)
/*     */   {
/* 109 */     double r = NaN.0D;
/* 110 */     int index = k - 1;
/* 111 */     if ((v != null) && (v.length > index) && (index >= 0)) {
/* 112 */       Arrays.sort(v);
/* 113 */       r = v[(v.length - index - 1)];
/*     */     }
/* 115 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double kthSmallest(double[] v, int k)
/*     */   {
/* 129 */     double r = NaN.0D;
/* 130 */     int index = k - 1;
/* 131 */     if ((v != null) && (v.length > index) && (index >= 0)) {
/* 132 */       Arrays.sort(v);
/* 133 */       r = v[index];
/*     */     }
/* 135 */     return r;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\StatsLib.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */