/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Substitute
/*     */   extends Var3or4ArgFunction
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */   {
/*     */     String result;
/*     */     try
/*     */     {
/*  36 */       String oldStr = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/*  37 */       String searchStr = TextFunction.evaluateStringArg(arg1, srcRowIndex, srcColumnIndex);
/*  38 */       String newStr = TextFunction.evaluateStringArg(arg2, srcRowIndex, srcColumnIndex);
/*     */       
/*  40 */       result = replaceAllOccurrences(oldStr, searchStr, newStr);
/*     */     } catch (EvaluationException e) {
/*  42 */       return e.getErrorEval();
/*     */     }
/*  44 */     return new StringEval(result);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3)
/*     */   {
/*     */     String result;
/*     */     try {
/*  51 */       String oldStr = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/*  52 */       String searchStr = TextFunction.evaluateStringArg(arg1, srcRowIndex, srcColumnIndex);
/*  53 */       String newStr = TextFunction.evaluateStringArg(arg2, srcRowIndex, srcColumnIndex);
/*     */       
/*  55 */       int instanceNumber = TextFunction.evaluateIntArg(arg3, srcRowIndex, srcColumnIndex);
/*  56 */       if (instanceNumber < 1) {
/*  57 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*  59 */       result = replaceOneOccurrence(oldStr, searchStr, newStr, instanceNumber);
/*     */     } catch (EvaluationException e) {
/*  61 */       return e.getErrorEval();
/*     */     }
/*  63 */     return new StringEval(result);
/*     */   }
/*     */   
/*     */   private static String replaceAllOccurrences(String oldStr, String searchStr, String newStr) {
/*  67 */     StringBuffer sb = new StringBuffer();
/*  68 */     int startIndex = 0;
/*  69 */     int nextMatch = -1;
/*     */     for (;;) {
/*  71 */       nextMatch = oldStr.indexOf(searchStr, startIndex);
/*  72 */       if (nextMatch < 0)
/*     */       {
/*  74 */         sb.append(oldStr.substring(startIndex));
/*  75 */         return sb.toString();
/*     */       }
/*     */       
/*  78 */       sb.append(oldStr.substring(startIndex, nextMatch));
/*  79 */       sb.append(newStr);
/*  80 */       startIndex = nextMatch + searchStr.length();
/*     */     }
/*     */   }
/*     */   
/*     */   private static String replaceOneOccurrence(String oldStr, String searchStr, String newStr, int instanceNumber) {
/*  85 */     if (searchStr.length() < 1) {
/*  86 */       return oldStr;
/*     */     }
/*  88 */     int startIndex = 0;
/*  89 */     int nextMatch = -1;
/*  90 */     int count = 0;
/*     */     for (;;) {
/*  92 */       nextMatch = oldStr.indexOf(searchStr, startIndex);
/*  93 */       if (nextMatch < 0)
/*     */       {
/*  95 */         return oldStr;
/*     */       }
/*  97 */       count++;
/*  98 */       if (count == instanceNumber) {
/*  99 */         StringBuffer sb = new StringBuffer(oldStr.length() + newStr.length());
/* 100 */         sb.append(oldStr.substring(0, nextMatch));
/* 101 */         sb.append(newStr);
/* 102 */         sb.append(oldStr.substring(nextMatch + searchStr.length()));
/* 103 */         return sb.toString();
/*     */       }
/* 105 */       startIndex = nextMatch + searchStr.length();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Substitute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */