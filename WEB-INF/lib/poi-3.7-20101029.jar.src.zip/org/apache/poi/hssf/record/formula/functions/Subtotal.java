/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.eval.NotImplementedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Subtotal
/*    */   implements Function
/*    */ {
/*    */   private static Function findFunction(int functionCode)
/*    */     throws EvaluationException
/*    */   {
/* 61 */     switch (functionCode) {
/* 62 */     case 1:  return AggregateFunction.AVERAGE;
/* 63 */     case 2:  return new Count();
/* 64 */     case 3:  return new Counta();
/* 65 */     case 4:  return AggregateFunction.MAX;
/* 66 */     case 5:  return AggregateFunction.MIN;
/* 67 */     case 6:  return AggregateFunction.PRODUCT;
/* 68 */     case 7:  return AggregateFunction.STDEV;
/* 69 */     case 8:  throw new NotImplementedException("STDEVP");
/* 70 */     case 9:  return AggregateFunction.SUM;
/* 71 */     case 10:  throw new NotImplementedException("VAR");
/* 72 */     case 11:  throw new NotImplementedException("VARP");
/*    */     }
/* 74 */     if ((functionCode > 100) && (functionCode < 112)) {
/* 75 */       throw new NotImplementedException("SUBTOTAL - with 'exclude hidden values' option");
/*    */     }
/* 77 */     throw EvaluationException.invalidValue();
/*    */   }
/*    */   
/*    */   public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex) {
/* 81 */     int nInnerArgs = args.length - 1;
/* 82 */     if (nInnerArgs < 1) {
/* 83 */       return ErrorEval.VALUE_INVALID;
/*    */     }
/*    */     Function innerFunc;
/*    */     try
/*    */     {
/* 88 */       ValueEval ve = OperandResolver.getSingleValue(args[0], srcRowIndex, srcColumnIndex);
/* 89 */       int functionCode = OperandResolver.coerceValueToInt(ve);
/* 90 */       innerFunc = findFunction(functionCode);
/*    */     } catch (EvaluationException e) {
/* 92 */       return e.getErrorEval();
/*    */     }
/*    */     
/* 95 */     ValueEval[] innerArgs = new ValueEval[nInnerArgs];
/* 96 */     System.arraycopy(args, 1, innerArgs, 0, nInnerArgs);
/*    */     
/* 98 */     return innerFunc.evaluate(innerArgs, srcRowIndex, srcColumnIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Subtotal.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */