/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.AreaEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Sumif
/*     */   extends Var2or3ArgFunction
/*     */ {
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*     */     AreaEval aeRange;
/*     */     try
/*     */     {
/*  47 */       aeRange = convertRangeArg(arg0);
/*     */     } catch (EvaluationException e) {
/*  49 */       return e.getErrorEval();
/*     */     }
/*  51 */     return eval(srcRowIndex, srcColumnIndex, arg1, aeRange, aeRange);
/*     */   }
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */   {
/*     */     AreaEval aeRange;
/*     */     AreaEval aeSum;
/*     */     try
/*     */     {
/*  60 */       aeRange = convertRangeArg(arg0);
/*  61 */       aeSum = createSumRange(arg2, aeRange);
/*     */     } catch (EvaluationException e) {
/*  63 */       return e.getErrorEval();
/*     */     }
/*  65 */     return eval(srcRowIndex, srcColumnIndex, arg1, aeRange, aeSum);
/*     */   }
/*     */   
/*     */ 
/*     */   private static ValueEval eval(int srcRowIndex, int srcColumnIndex, ValueEval arg1, AreaEval aeRange, AreaEval aeSum)
/*     */   {
/*  71 */     CountUtils.I_MatchPredicate mp = Countif.createCriteriaPredicate(arg1, srcRowIndex, srcColumnIndex);
/*  72 */     double result = sumMatchingCells(aeRange, mp, aeSum);
/*  73 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   private static double sumMatchingCells(AreaEval aeRange, CountUtils.I_MatchPredicate mp, AreaEval aeSum) {
/*  77 */     int height = aeRange.getHeight();
/*  78 */     int width = aeRange.getWidth();
/*     */     
/*  80 */     double result = 0.0D;
/*  81 */     for (int r = 0; r < height; r++) {
/*  82 */       for (int c = 0; c < width; c++) {
/*  83 */         result += accumulate(aeRange, mp, aeSum, r, c);
/*     */       }
/*     */     }
/*  86 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private static double accumulate(AreaEval aeRange, CountUtils.I_MatchPredicate mp, AreaEval aeSum, int relRowIndex, int relColIndex)
/*     */   {
/*  92 */     if (!mp.matches(aeRange.getRelativeValue(relRowIndex, relColIndex))) {
/*  93 */       return 0.0D;
/*     */     }
/*  95 */     ValueEval addend = aeSum.getRelativeValue(relRowIndex, relColIndex);
/*  96 */     if ((addend instanceof NumberEval)) {
/*  97 */       return ((NumberEval)addend).getNumberValue();
/*     */     }
/*     */     
/* 100 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static AreaEval createSumRange(ValueEval eval, AreaEval aeRange)
/*     */     throws EvaluationException
/*     */   {
/* 108 */     if ((eval instanceof AreaEval)) {
/* 109 */       return ((AreaEval)eval).offset(0, aeRange.getHeight() - 1, 0, aeRange.getWidth() - 1);
/*     */     }
/* 111 */     if ((eval instanceof RefEval)) {
/* 112 */       return ((RefEval)eval).offset(0, aeRange.getHeight() - 1, 0, aeRange.getWidth() - 1);
/*     */     }
/* 114 */     throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */   }
/*     */   
/*     */   private static AreaEval convertRangeArg(ValueEval eval) throws EvaluationException {
/* 118 */     if ((eval instanceof AreaEval)) {
/* 119 */       return (AreaEval)eval;
/*     */     }
/* 121 */     if ((eval instanceof RefEval)) {
/* 122 */       return ((RefEval)eval).offset(0, 0, 0, 0);
/*     */     }
/* 124 */     throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Sumif.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */