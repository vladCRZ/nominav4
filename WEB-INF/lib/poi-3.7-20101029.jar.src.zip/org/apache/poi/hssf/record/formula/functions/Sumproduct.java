/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.AreaEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.BlankEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumericValueEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Sumproduct
/*     */   implements Function
/*     */ {
/*     */   public ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol)
/*     */   {
/*  59 */     int maxN = args.length;
/*     */     
/*  61 */     if (maxN < 1) {
/*  62 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*  64 */     ValueEval firstArg = args[0];
/*     */     try {
/*  66 */       if ((firstArg instanceof NumericValueEval)) {
/*  67 */         return evaluateSingleProduct(args);
/*     */       }
/*  69 */       if ((firstArg instanceof RefEval)) {
/*  70 */         return evaluateSingleProduct(args);
/*     */       }
/*  72 */       if ((firstArg instanceof TwoDEval)) {
/*  73 */         TwoDEval ae = (TwoDEval)firstArg;
/*  74 */         if ((ae.isRow()) && (ae.isColumn())) {
/*  75 */           return evaluateSingleProduct(args);
/*     */         }
/*  77 */         return evaluateAreaSumProduct(args);
/*     */       }
/*     */     } catch (EvaluationException e) {
/*  80 */       return e.getErrorEval();
/*     */     }
/*  82 */     throw new RuntimeException("Invalid arg type for SUMPRODUCT: (" + firstArg.getClass().getName() + ")");
/*     */   }
/*     */   
/*     */   private static ValueEval evaluateSingleProduct(ValueEval[] evalArgs) throws EvaluationException
/*     */   {
/*  87 */     int maxN = evalArgs.length;
/*     */     
/*  89 */     double term = 1.0D;
/*  90 */     for (int n = 0; n < maxN; n++) {
/*  91 */       double val = getScalarValue(evalArgs[n]);
/*  92 */       term *= val;
/*     */     }
/*  94 */     return new NumberEval(term);
/*     */   }
/*     */   
/*     */   private static double getScalarValue(ValueEval arg) throws EvaluationException {
/*     */     ValueEval eval;
/*     */     ValueEval eval;
/* 100 */     if ((arg instanceof RefEval)) {
/* 101 */       RefEval re = (RefEval)arg;
/* 102 */       eval = re.getInnerValueEval();
/*     */     } else {
/* 104 */       eval = arg;
/*     */     }
/*     */     
/* 107 */     if (eval == null) {
/* 108 */       throw new RuntimeException("parameter may not be null");
/*     */     }
/* 110 */     if ((eval instanceof AreaEval)) {
/* 111 */       AreaEval ae = (AreaEval)eval;
/*     */       
/* 113 */       if ((!ae.isColumn()) || (!ae.isRow())) {
/* 114 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/* 116 */       eval = ae.getRelativeValue(0, 0);
/*     */     }
/*     */     
/* 119 */     return getProductTerm(eval, true);
/*     */   }
/*     */   
/*     */   private static ValueEval evaluateAreaSumProduct(ValueEval[] evalArgs) throws EvaluationException {
/* 123 */     int maxN = evalArgs.length;
/* 124 */     TwoDEval[] args = new TwoDEval[maxN];
/*     */     try {
/* 126 */       System.arraycopy(evalArgs, 0, args, 0, maxN);
/*     */     }
/*     */     catch (ArrayStoreException e) {
/* 129 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*     */     
/*     */ 
/* 133 */     TwoDEval firstArg = args[0];
/*     */     
/* 135 */     int height = firstArg.getHeight();
/* 136 */     int width = firstArg.getWidth();
/*     */     
/*     */ 
/* 139 */     if (!areasAllSameSize(args, height, width))
/*     */     {
/*     */ 
/* 142 */       for (int i = 1; i < args.length; i++) {
/* 143 */         throwFirstError(args[i]);
/*     */       }
/* 145 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*     */     
/* 148 */     double acc = 0.0D;
/*     */     
/* 150 */     for (int rrIx = 0; rrIx < height; rrIx++) {
/* 151 */       for (int rcIx = 0; rcIx < width; rcIx++) {
/* 152 */         double term = 1.0D;
/* 153 */         for (int n = 0; n < maxN; n++) {
/* 154 */           double val = getProductTerm(args[n].getValue(rrIx, rcIx), false);
/* 155 */           term *= val;
/*     */         }
/* 157 */         acc += term;
/*     */       }
/*     */     }
/*     */     
/* 161 */     return new NumberEval(acc);
/*     */   }
/*     */   
/*     */   private static void throwFirstError(TwoDEval areaEval) throws EvaluationException {
/* 165 */     int height = areaEval.getHeight();
/* 166 */     int width = areaEval.getWidth();
/* 167 */     for (int rrIx = 0; rrIx < height; rrIx++) {
/* 168 */       for (int rcIx = 0; rcIx < width; rcIx++) {
/* 169 */         ValueEval ve = areaEval.getValue(rrIx, rcIx);
/* 170 */         if ((ve instanceof ErrorEval)) {
/* 171 */           throw new EvaluationException((ErrorEval)ve);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean areasAllSameSize(TwoDEval[] args, int height, int width) {
/* 178 */     for (int i = 0; i < args.length; i++) {
/* 179 */       TwoDEval areaEval = args[i];
/*     */       
/* 181 */       if (areaEval.getHeight() != height) {
/* 182 */         return false;
/*     */       }
/* 184 */       if (areaEval.getWidth() != width) {
/* 185 */         return false;
/*     */       }
/*     */     }
/* 188 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static double getProductTerm(ValueEval ve, boolean isScalarProduct)
/*     */     throws EvaluationException
/*     */   {
/* 204 */     if (((ve instanceof BlankEval)) || (ve == null))
/*     */     {
/*     */ 
/* 207 */       if (isScalarProduct) {
/* 208 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/* 210 */       return 0.0D;
/*     */     }
/*     */     
/* 213 */     if ((ve instanceof ErrorEval)) {
/* 214 */       throw new EvaluationException((ErrorEval)ve);
/*     */     }
/* 216 */     if ((ve instanceof StringEval)) {
/* 217 */       if (isScalarProduct) {
/* 218 */         throw new EvaluationException(ErrorEval.VALUE_INVALID);
/*     */       }
/*     */       
/*     */ 
/* 222 */       return 0.0D;
/*     */     }
/* 224 */     if ((ve instanceof NumericValueEval)) {
/* 225 */       NumericValueEval nve = (NumericValueEval)ve;
/* 226 */       return nve.getNumberValue();
/*     */     }
/* 228 */     throw new RuntimeException("Unexpected value eval class (" + ve.getClass().getName() + ")");
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Sumproduct.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */