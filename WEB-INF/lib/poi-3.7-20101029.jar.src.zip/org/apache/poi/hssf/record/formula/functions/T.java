/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.AreaEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class T
/*    */   extends Fixed1ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*    */   {
/* 36 */     ValueEval arg = arg0;
/* 37 */     if ((arg instanceof RefEval)) {
/* 38 */       arg = ((RefEval)arg).getInnerValueEval();
/* 39 */     } else if ((arg instanceof AreaEval))
/*    */     {
/* 41 */       arg = ((AreaEval)arg).getRelativeValue(0, 0);
/*    */     }
/*    */     
/* 44 */     if ((arg instanceof StringEval))
/*    */     {
/* 46 */       return arg;
/*    */     }
/*    */     
/* 49 */     if ((arg instanceof ErrorEval))
/*    */     {
/* 51 */       return arg;
/*    */     }
/*    */     
/* 54 */     return StringEval.EMPTY_INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\T.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */