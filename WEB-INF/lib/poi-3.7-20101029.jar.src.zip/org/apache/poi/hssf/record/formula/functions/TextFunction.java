/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.StringEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TextFunction
/*     */   implements Function
/*     */ {
/*     */   protected static final String EMPTY_STRING = "";
/*     */   
/*     */   protected static final String evaluateStringArg(ValueEval eval, int srcRow, int srcCol)
/*     */     throws EvaluationException
/*     */   {
/*  44 */     ValueEval ve = OperandResolver.getSingleValue(eval, srcRow, srcCol);
/*  45 */     return OperandResolver.coerceValueToString(ve);
/*     */   }
/*     */   
/*  48 */   protected static final int evaluateIntArg(ValueEval arg, int srcCellRow, int srcCellCol) throws EvaluationException { ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, srcCellCol);
/*  49 */     return OperandResolver.coerceValueToInt(ve);
/*     */   }
/*     */   
/*     */   protected static final double evaluateDoubleArg(ValueEval arg, int srcCellRow, int srcCellCol) throws EvaluationException {
/*  53 */     ValueEval ve = OperandResolver.getSingleValue(arg, srcCellRow, srcCellCol);
/*  54 */     return OperandResolver.coerceValueToDouble(ve);
/*     */   }
/*     */   
/*     */   public final ValueEval evaluate(ValueEval[] args, int srcCellRow, int srcCellCol) {
/*     */     try {
/*  59 */       return evaluateFunc(args, srcCellRow, srcCellCol);
/*     */     } catch (EvaluationException e) {
/*  61 */       return e.getErrorEval();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract ValueEval evaluateFunc(ValueEval[] paramArrayOfValueEval, int paramInt1, int paramInt2)
/*     */     throws EvaluationException;
/*     */   
/*     */   private static abstract class SingleArgTextFunc
/*     */     extends Fixed1ArgFunction
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0)
/*     */     {
/*     */       String arg;
/*     */       try
/*     */       {
/*  77 */         arg = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/*     */       } catch (EvaluationException e) {
/*  79 */         return e.getErrorEval();
/*     */       }
/*  81 */       return evaluate(arg);
/*     */     }
/*     */     
/*     */     protected abstract ValueEval evaluate(String paramString); }
/*     */   
/*  86 */   public static final Function LEN = new SingleArgTextFunc() {
/*     */     protected ValueEval evaluate(String arg) {
/*  88 */       return new NumberEval(arg.length());
/*     */     }
/*     */   };
/*  91 */   public static final Function LOWER = new SingleArgTextFunc() {
/*     */     protected ValueEval evaluate(String arg) {
/*  93 */       return new StringEval(arg.toLowerCase());
/*     */     }
/*     */   };
/*  96 */   public static final Function UPPER = new SingleArgTextFunc() {
/*     */     protected ValueEval evaluate(String arg) {
/*  98 */       return new StringEval(arg.toUpperCase());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   public static final Function TRIM = new SingleArgTextFunc() {
/*     */     protected ValueEval evaluate(String arg) {
/* 109 */       return new StringEval(arg.trim());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */   public static final Function MID = new Fixed3ArgFunction()
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*     */     {
/*     */       String text;
/*     */       int startCharNum;
/*     */       int numChars;
/*     */       try {
/* 131 */         text = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/* 132 */         startCharNum = TextFunction.evaluateIntArg(arg1, srcRowIndex, srcColumnIndex);
/* 133 */         numChars = TextFunction.evaluateIntArg(arg2, srcRowIndex, srcColumnIndex);
/*     */       } catch (EvaluationException e) {
/* 135 */         return e.getErrorEval();
/*     */       }
/* 137 */       int startIx = startCharNum - 1;
/*     */       
/*     */ 
/*     */ 
/* 141 */       if (startIx < 0) {
/* 142 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/* 144 */       if (numChars < 0) {
/* 145 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/* 147 */       int len = text.length();
/* 148 */       if ((numChars < 0) || (startIx > len)) {
/* 149 */         return new StringEval("");
/*     */       }
/* 151 */       int endIx = Math.min(startIx + numChars, len);
/* 152 */       String result = text.substring(startIx, endIx);
/* 153 */       return new StringEval(result);
/*     */     }
/*     */   };
/*     */   
/*     */   private static final class LeftRight extends Var1or2ArgFunction {
/* 158 */     private static final ValueEval DEFAULT_ARG1 = new NumberEval(1.0D);
/*     */     private final boolean _isLeft;
/*     */     
/* 161 */     protected LeftRight(boolean isLeft) { this._isLeft = isLeft; }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/* 164 */       return evaluate(srcRowIndex, srcColumnIndex, arg0, DEFAULT_ARG1);
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1) {
/*     */       String arg;
/*     */       int index;
/*     */       try {
/* 171 */         arg = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/* 172 */         index = TextFunction.evaluateIntArg(arg1, srcRowIndex, srcColumnIndex);
/*     */       } catch (EvaluationException e) {
/* 174 */         return e.getErrorEval();
/*     */       }
/*     */       
/* 177 */       if (index < 0) {
/* 178 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*     */       String result;
/*     */       String result;
/* 182 */       if (this._isLeft) {
/* 183 */         result = arg.substring(0, Math.min(arg.length(), index));
/*     */       } else {
/* 185 */         result = arg.substring(Math.max(0, arg.length() - index));
/*     */       }
/* 187 */       return new StringEval(result);
/*     */     }
/*     */   }
/*     */   
/* 191 */   public static final Function LEFT = new LeftRight(true);
/* 192 */   public static final Function RIGHT = new LeftRight(false);
/*     */   
/* 194 */   public static final Function CONCATENATE = new Function()
/*     */   {
/*     */     public ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex) {
/* 197 */       StringBuilder sb = new StringBuilder();
/* 198 */       int i = 0; for (int iSize = args.length; i < iSize; i++) {
/*     */         try {
/* 200 */           sb.append(TextFunction.evaluateStringArg(args[i], srcRowIndex, srcColumnIndex));
/*     */         } catch (EvaluationException e) {
/* 202 */           return e.getErrorEval();
/*     */         }
/*     */       }
/* 205 */       return new StringEval(sb.toString());
/*     */     }
/*     */   };
/*     */   
/* 209 */   public static final Function EXACT = new Fixed2ArgFunction()
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */     {
/*     */       String s0;
/*     */       String s1;
/*     */       try {
/* 216 */         s0 = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/* 217 */         s1 = TextFunction.evaluateStringArg(arg1, srcRowIndex, srcColumnIndex);
/*     */       } catch (EvaluationException e) {
/* 219 */         return e.getErrorEval();
/*     */       }
/* 221 */       return BoolEval.valueOf(s0.equals(s1));
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 236 */   public static final Function TEXT = new Fixed2ArgFunction()
/*     */   {
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1) {
/*     */       double s0;
/*     */       String s1;
/*     */       try {
/* 242 */         s0 = TextFunction.evaluateDoubleArg(arg0, srcRowIndex, srcColumnIndex);
/* 243 */         s1 = TextFunction.evaluateStringArg(arg1, srcRowIndex, srcColumnIndex);
/*     */       } catch (EvaluationException e) {
/* 245 */         return e.getErrorEval();
/*     */       }
/* 247 */       if (s1.matches("[\\d,\\#,\\.,\\$,\\,]+")) {
/* 248 */         NumberFormat formatter = new DecimalFormat(s1);
/* 249 */         return new StringEval(formatter.format(s0)); }
/* 250 */       if ((s1.indexOf("/") == s1.lastIndexOf("/")) && (s1.indexOf("/") >= 0) && (!s1.contains("-"))) {
/* 251 */         double wholePart = Math.floor(s0);
/* 252 */         double decPart = s0 - wholePart;
/* 253 */         if (wholePart * decPart == 0.0D) {
/* 254 */           return new StringEval("0");
/*     */         }
/* 256 */         String[] parts = s1.split(" ");
/*     */         String[] fractParts;
/* 258 */         String[] fractParts; if (parts.length == 2) {
/* 259 */           fractParts = parts[1].split("/");
/*     */         } else {
/* 261 */           fractParts = s1.split("/");
/*     */         }
/*     */         
/* 264 */         if (fractParts.length == 2) {
/* 265 */           double minVal = 1.0D;
/* 266 */           double currDenom = Math.pow(10.0D, fractParts[1].length()) - 1.0D;
/* 267 */           double currNeum = 0.0D;
/* 268 */           for (int i = (int)(Math.pow(10.0D, fractParts[1].length()) - 1.0D); i > 0; i--) {
/* 269 */             for (int i2 = (int)(Math.pow(10.0D, fractParts[1].length()) - 1.0D); i2 > 0; i2--) {
/* 270 */               if (minVal >= Math.abs(i2 / i - decPart)) {
/* 271 */                 currDenom = i;
/* 272 */                 currNeum = i2;
/* 273 */                 minVal = Math.abs(i2 / i - decPart);
/*     */               }
/*     */             }
/*     */           }
/* 277 */           NumberFormat neumFormatter = new DecimalFormat(fractParts[0]);
/* 278 */           NumberFormat denomFormatter = new DecimalFormat(fractParts[1]);
/* 279 */           if (parts.length == 2) {
/* 280 */             NumberFormat wholeFormatter = new DecimalFormat(parts[0]);
/* 281 */             String result = wholeFormatter.format(wholePart) + " " + neumFormatter.format(currNeum) + "/" + denomFormatter.format(currDenom);
/* 282 */             return new StringEval(result);
/*     */           }
/* 284 */           String result = neumFormatter.format(currNeum + currDenom * wholePart) + "/" + denomFormatter.format(currDenom);
/* 285 */           return new StringEval(result);
/*     */         }
/*     */         
/* 288 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/*     */       try
/*     */       {
/* 292 */         DateFormat dateFormatter = new SimpleDateFormat(s1);
/* 293 */         Calendar cal = new GregorianCalendar(1899, 11, 30, 0, 0, 0);
/* 294 */         cal.add(5, (int)Math.floor(s0));
/* 295 */         double dayFraction = s0 - Math.floor(s0);
/* 296 */         cal.add(14, (int)Math.round(dayFraction * 24.0D * 60.0D * 60.0D * 1000.0D));
/* 297 */         return new StringEval(dateFormatter.format(cal.getTime()));
/*     */       } catch (Exception e) {}
/* 299 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   private static final class SearchFind
/*     */     extends Var2or3ArgFunction
/*     */   {
/*     */     private final boolean _isCaseSensitive;
/*     */     
/*     */ 
/* 310 */     public SearchFind(boolean isCaseSensitive) { this._isCaseSensitive = isCaseSensitive; }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1) {
/*     */       try {
/* 314 */         String needle = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/* 315 */         String haystack = TextFunction.evaluateStringArg(arg1, srcRowIndex, srcColumnIndex);
/* 316 */         return eval(haystack, needle, 0);
/*     */       } catch (EvaluationException e) {
/* 318 */         return e.getErrorEval();
/*     */       }
/*     */     }
/*     */     
/*     */     public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2) {
/*     */       try {
/* 324 */         String needle = TextFunction.evaluateStringArg(arg0, srcRowIndex, srcColumnIndex);
/* 325 */         String haystack = TextFunction.evaluateStringArg(arg1, srcRowIndex, srcColumnIndex);
/*     */         
/* 327 */         int startpos = TextFunction.evaluateIntArg(arg2, srcRowIndex, srcColumnIndex) - 1;
/* 328 */         if (startpos < 0) {
/* 329 */           return ErrorEval.VALUE_INVALID;
/*     */         }
/* 331 */         return eval(haystack, needle, startpos);
/*     */       } catch (EvaluationException e) {
/* 333 */         return e.getErrorEval();
/*     */       } }
/*     */     
/*     */     private ValueEval eval(String haystack, String needle, int startIndex) { int result;
/*     */       int result;
/* 338 */       if (this._isCaseSensitive) {
/* 339 */         result = haystack.indexOf(needle, startIndex);
/*     */       } else {
/* 341 */         result = haystack.toUpperCase().indexOf(needle.toUpperCase(), startIndex);
/*     */       }
/* 343 */       if (result == -1) {
/* 344 */         return ErrorEval.VALUE_INVALID;
/*     */       }
/* 346 */       return new NumberEval(result + 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 362 */   public static final Function FIND = new SearchFind(true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 371 */   public static final Function SEARCH = new SearchFind(false);
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\TextFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */