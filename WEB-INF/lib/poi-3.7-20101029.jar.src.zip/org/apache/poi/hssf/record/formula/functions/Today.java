/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.GregorianCalendar;
/*    */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.hssf.usermodel.HSSFDateUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Today
/*    */   extends Fixed0ArgFunction
/*    */ {
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 36 */     Calendar now = new GregorianCalendar();
/* 37 */     now.set(now.get(1), now.get(2), now.get(5), 0, 0, 0);
/* 38 */     now.set(14, 0);
/* 39 */     return new NumberEval(HSSFDateUtil.getExcelDate(now.getTime()));
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Today.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */