/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Value
/*     */   extends Fixed1ArgFunction
/*     */ {
/*     */   private static final int MIN_DISTANCE_BETWEEN_THOUSANDS_SEPARATOR = 4;
/*  42 */   private static final Double ZERO = new Double(0.0D);
/*     */   
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0) {
/*     */     ValueEval veText;
/*     */     try {
/*  47 */       veText = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/*     */     } catch (EvaluationException e) {
/*  49 */       return e.getErrorEval();
/*     */     }
/*  51 */     String strText = OperandResolver.coerceValueToString(veText);
/*  52 */     Double result = convertTextToNumber(strText);
/*  53 */     if (result == null) {
/*  54 */       return ErrorEval.VALUE_INVALID;
/*     */     }
/*  56 */     return new NumberEval(result.doubleValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Double convertTextToNumber(String strText)
/*     */   {
/*  65 */     boolean foundCurrency = false;
/*  66 */     boolean foundUnaryPlus = false;
/*  67 */     boolean foundUnaryMinus = false;
/*     */     
/*  69 */     int len = strText.length();
/*     */     
/*  71 */     for (int i = 0; i < len; i++) {
/*  72 */       char ch = strText.charAt(i);
/*  73 */       if ((Character.isDigit(ch)) || (ch == '.')) {
/*     */         break;
/*     */       }
/*  76 */       switch (ch)
/*     */       {
/*     */       case ' ': 
/*     */         break;
/*     */       case '$': 
/*  81 */         if (foundCurrency)
/*     */         {
/*  83 */           return null;
/*     */         }
/*  85 */         foundCurrency = true;
/*  86 */         break;
/*     */       case '+': 
/*  88 */         if ((foundUnaryMinus) || (foundUnaryPlus)) {
/*  89 */           return null;
/*     */         }
/*  91 */         foundUnaryPlus = true;
/*  92 */         break;
/*     */       case '-': 
/*  94 */         if ((foundUnaryMinus) || (foundUnaryPlus)) {
/*  95 */           return null;
/*     */         }
/*  97 */         foundUnaryMinus = true;
/*  98 */         break;
/*     */       
/*     */       default: 
/* 101 */         return null;
/*     */       }
/*     */     }
/* 104 */     if (i >= len)
/*     */     {
/* 106 */       if ((foundCurrency) || (foundUnaryMinus) || (foundUnaryPlus)) {
/* 107 */         return null;
/*     */       }
/* 109 */       return ZERO;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 114 */     boolean foundDecimalPoint = false;
/* 115 */     int lastThousandsSeparatorIndex = 32768;
/*     */     
/* 117 */     StringBuffer sb = new StringBuffer(len);
/* 118 */     for (; i < len; i++) {
/* 119 */       char ch = strText.charAt(i);
/* 120 */       if (Character.isDigit(ch)) {
/* 121 */         sb.append(ch);
/*     */       }
/*     */       else
/* 124 */         switch (ch) {
/*     */         case ' ': 
/* 126 */           String remainingText = strText.substring(i);
/* 127 */           if (remainingText.trim().length() > 0)
/*     */           {
/* 129 */             return null;
/*     */           }
/*     */           break;
/*     */         case '.': 
/* 133 */           if (foundDecimalPoint) {
/* 134 */             return null;
/*     */           }
/* 136 */           if (i - lastThousandsSeparatorIndex < 4) {
/* 137 */             return null;
/*     */           }
/* 139 */           foundDecimalPoint = true;
/* 140 */           sb.append('.');
/* 141 */           break;
/*     */         case ',': 
/* 143 */           if (foundDecimalPoint)
/*     */           {
/* 145 */             return null;
/*     */           }
/* 147 */           int distanceBetweenThousandsSeparators = i - lastThousandsSeparatorIndex;
/*     */           
/* 149 */           if (distanceBetweenThousandsSeparators < 4) {
/* 150 */             return null;
/*     */           }
/* 152 */           lastThousandsSeparatorIndex = i;
/*     */           
/* 154 */           break;
/*     */         
/*     */         case 'E': 
/*     */         case 'e': 
/* 158 */           if (i - lastThousandsSeparatorIndex < 4) {
/* 159 */             return null;
/*     */           }
/*     */           
/* 162 */           sb.append(strText.substring(i));
/* 163 */           i = len;
/* 164 */           break;
/*     */         
/*     */         default: 
/* 167 */           return null;
/*     */         }
/*     */     }
/* 170 */     if ((!foundDecimalPoint) && 
/* 171 */       (i - lastThousandsSeparatorIndex < 4)) {
/* 172 */       return null;
/*     */     }
/*     */     double d;
/*     */     try
/*     */     {
/* 177 */       d = Double.parseDouble(sb.toString());
/*     */     }
/*     */     catch (NumberFormatException e) {
/* 180 */       return null;
/*     */     }
/* 182 */     return new Double(foundUnaryMinus ? -d : d);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Value.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */