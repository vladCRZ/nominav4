/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Var1or2ArgFunction
/*    */   implements Function1Arg, Function2Arg
/*    */ {
/*    */   public final ValueEval evaluate(ValueEval[] args, int srcRowIndex, int srcColumnIndex)
/*    */   {
/* 32 */     switch (args.length) {
/*    */     case 1: 
/* 34 */       return evaluate(srcRowIndex, srcColumnIndex, args[0]);
/*    */     case 2: 
/* 36 */       return evaluate(srcRowIndex, srcColumnIndex, args[0], args[1]);
/*    */     }
/* 38 */     return ErrorEval.VALUE_INVALID;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Var1or2ArgFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */