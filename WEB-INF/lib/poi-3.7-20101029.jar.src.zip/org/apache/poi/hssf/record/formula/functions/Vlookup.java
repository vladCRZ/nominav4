/*    */ package org.apache.poi.hssf.record.formula.functions;
/*    */ 
/*    */ import org.apache.poi.hssf.record.formula.eval.BoolEval;
/*    */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*    */ import org.apache.poi.hssf.record.formula.eval.OperandResolver;
/*    */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*    */ import org.apache.poi.ss.formula.TwoDEval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Vlookup
/*    */   extends Var3or4ArgFunction
/*    */ {
/* 43 */   private static final ValueEval DEFAULT_ARG3 = BoolEval.TRUE;
/*    */   
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2)
/*    */   {
/* 47 */     return evaluate(srcRowIndex, srcColumnIndex, arg0, arg1, arg2, DEFAULT_ARG3);
/*    */   }
/*    */   
/*    */ 
/*    */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1, ValueEval arg2, ValueEval arg3)
/*    */   {
/*    */     try
/*    */     {
/* 55 */       ValueEval lookupValue = OperandResolver.getSingleValue(arg0, srcRowIndex, srcColumnIndex);
/* 56 */       TwoDEval tableArray = LookupUtils.resolveTableArrayArg(arg1);
/* 57 */       boolean isRangeLookup = LookupUtils.resolveRangeLookupArg(arg3, srcRowIndex, srcColumnIndex);
/* 58 */       int rowIndex = LookupUtils.lookupIndexOfValue(lookupValue, LookupUtils.createColumnVector(tableArray, 0), isRangeLookup);
/* 59 */       int colIndex = LookupUtils.resolveRowOrColIndexArg(arg2, srcRowIndex, srcColumnIndex);
/* 60 */       LookupUtils.ValueVector resultCol = createResultColumnVector(tableArray, colIndex);
/* 61 */       return resultCol.getItem(rowIndex);
/*    */     } catch (EvaluationException e) {
/* 63 */       return e.getErrorEval();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private LookupUtils.ValueVector createResultColumnVector(TwoDEval tableArray, int colIndex)
/*    */     throws EvaluationException
/*    */   {
/* 76 */     if (colIndex >= tableArray.getWidth()) {
/* 77 */       throw EvaluationException.invalidRef();
/*    */     }
/* 79 */     return LookupUtils.createColumnVector(tableArray, colIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\Vlookup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */