/*     */ package org.apache.poi.hssf.record.formula.functions;
/*     */ 
/*     */ import org.apache.poi.hssf.record.formula.eval.ErrorEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.EvaluationException;
/*     */ import org.apache.poi.hssf.record.formula.eval.NumberEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.RefEval;
/*     */ import org.apache.poi.hssf.record.formula.eval.ValueEval;
/*     */ import org.apache.poi.ss.formula.TwoDEval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XYNumericFunction
/*     */   extends Fixed2ArgFunction
/*     */ {
/*     */   protected abstract Accumulator createAccumulator();
/*     */   
/*     */   private static abstract class ValueArray
/*     */     implements LookupUtils.ValueVector
/*     */   {
/*     */     private final int _size;
/*     */     
/*  36 */     protected ValueArray(int size) { this._size = size; }
/*     */     
/*     */     public ValueEval getItem(int index) {
/*  39 */       if ((index < 0) || (index > this._size)) {
/*  40 */         throw new IllegalArgumentException("Specified index " + index + " is outside range (0.." + (this._size - 1) + ")");
/*     */       }
/*     */       
/*  43 */       return getItemInternal(index); }
/*     */     
/*     */     protected abstract ValueEval getItemInternal(int paramInt);
/*     */     
/*  47 */     public final int getSize() { return this._size; }
/*     */   }
/*     */   
/*     */   private static final class SingleCellValueArray extends XYNumericFunction.ValueArray {
/*     */     private final ValueEval _value;
/*     */     
/*     */     public SingleCellValueArray(ValueEval value) {
/*  54 */       super();
/*  55 */       this._value = value;
/*     */     }
/*     */     
/*  58 */     protected ValueEval getItemInternal(int index) { return this._value; }
/*     */   }
/*     */   
/*     */   private static final class RefValueArray extends XYNumericFunction.ValueArray {
/*     */     private final RefEval _ref;
/*     */     
/*     */     public RefValueArray(RefEval ref) {
/*  65 */       super();
/*  66 */       this._ref = ref;
/*     */     }
/*     */     
/*  69 */     protected ValueEval getItemInternal(int index) { return this._ref.getInnerValueEval(); }
/*     */   }
/*     */   
/*     */   private static final class AreaValueArray extends XYNumericFunction.ValueArray
/*     */   {
/*     */     private final TwoDEval _ae;
/*     */     private final int _width;
/*     */     
/*     */     public AreaValueArray(TwoDEval ae) {
/*  78 */       super();
/*  79 */       this._ae = ae;
/*  80 */       this._width = ae.getWidth();
/*     */     }
/*     */     
/*  83 */     protected ValueEval getItemInternal(int index) { int rowIx = index / this._width;
/*  84 */       int colIx = index % this._width;
/*  85 */       return this._ae.getValue(rowIx, colIx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueEval evaluate(int srcRowIndex, int srcColumnIndex, ValueEval arg0, ValueEval arg1)
/*     */   {
/*     */     double result;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 102 */       LookupUtils.ValueVector vvX = createValueVector(arg0);
/* 103 */       LookupUtils.ValueVector vvY = createValueVector(arg1);
/* 104 */       int size = vvX.getSize();
/* 105 */       if ((size == 0) || (vvY.getSize() != size)) {
/* 106 */         return ErrorEval.NA;
/*     */       }
/* 108 */       result = evaluateInternal(vvX, vvY, size);
/*     */     } catch (EvaluationException e) {
/* 110 */       return e.getErrorEval();
/*     */     }
/* 112 */     if ((Double.isNaN(result)) || (Double.isInfinite(result))) {
/* 113 */       return ErrorEval.NUM_ERROR;
/*     */     }
/* 115 */     return new NumberEval(result);
/*     */   }
/*     */   
/*     */   private double evaluateInternal(LookupUtils.ValueVector x, LookupUtils.ValueVector y, int size) throws EvaluationException
/*     */   {
/* 120 */     Accumulator acc = createAccumulator();
/*     */     
/*     */ 
/* 123 */     ErrorEval firstXerr = null;
/* 124 */     ErrorEval firstYerr = null;
/* 125 */     boolean accumlatedSome = false;
/* 126 */     double result = 0.0D;
/*     */     
/* 128 */     for (int i = 0; i < size; i++) {
/* 129 */       ValueEval vx = x.getItem(i);
/* 130 */       ValueEval vy = y.getItem(i);
/* 131 */       if (((vx instanceof ErrorEval)) && 
/* 132 */         (firstXerr == null)) {
/* 133 */         firstXerr = (ErrorEval)vx;
/*     */ 
/*     */ 
/*     */       }
/* 137 */       else if (((vy instanceof ErrorEval)) && 
/* 138 */         (firstYerr == null)) {
/* 139 */         firstYerr = (ErrorEval)vy;
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 144 */       else if (((vx instanceof NumberEval)) && ((vy instanceof NumberEval))) {
/* 145 */         accumlatedSome = true;
/* 146 */         NumberEval nx = (NumberEval)vx;
/* 147 */         NumberEval ny = (NumberEval)vy;
/* 148 */         result += acc.accumulate(nx.getNumberValue(), ny.getNumberValue());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 153 */     if (firstXerr != null) {
/* 154 */       throw new EvaluationException(firstXerr);
/*     */     }
/* 156 */     if (firstYerr != null) {
/* 157 */       throw new EvaluationException(firstYerr);
/*     */     }
/* 159 */     if (!accumlatedSome) {
/* 160 */       throw new EvaluationException(ErrorEval.DIV_ZERO);
/*     */     }
/* 162 */     return result;
/*     */   }
/*     */   
/*     */   private static LookupUtils.ValueVector createValueVector(ValueEval arg) throws EvaluationException {
/* 166 */     if ((arg instanceof ErrorEval)) {
/* 167 */       throw new EvaluationException((ErrorEval)arg);
/*     */     }
/* 169 */     if ((arg instanceof TwoDEval)) {
/* 170 */       return new AreaValueArray((TwoDEval)arg);
/*     */     }
/* 172 */     if ((arg instanceof RefEval)) {
/* 173 */       return new RefValueArray((RefEval)arg);
/*     */     }
/* 175 */     return new SingleCellValueArray(arg);
/*     */   }
/*     */   
/*     */   protected static abstract interface Accumulator
/*     */   {
/*     */     public abstract double accumulate(double paramDouble1, double paramDouble2);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formula\functions\XYNumericFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */