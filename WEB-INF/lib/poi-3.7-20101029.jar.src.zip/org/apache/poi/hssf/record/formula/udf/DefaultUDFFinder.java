/*    */ package org.apache.poi.hssf.record.formula.udf;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.poi.hssf.record.formula.functions.FreeRefFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultUDFFinder
/*    */   implements UDFFinder
/*    */ {
/*    */   private final Map<String, FreeRefFunction> _functionsByName;
/*    */   
/*    */   public DefaultUDFFinder(String[] functionNames, FreeRefFunction[] functionImpls)
/*    */   {
/* 34 */     int nFuncs = functionNames.length;
/* 35 */     if (functionImpls.length != nFuncs) {
/* 36 */       throw new IllegalArgumentException("Mismatch in number of function names and implementations");
/*    */     }
/*    */     
/* 39 */     HashMap<String, FreeRefFunction> m = new HashMap(nFuncs * 3 / 2);
/* 40 */     for (int i = 0; i < functionImpls.length; i++) {
/* 41 */       m.put(functionNames[i], functionImpls[i]);
/*    */     }
/* 43 */     this._functionsByName = m;
/*    */   }
/*    */   
/*    */   public FreeRefFunction findFunction(String name) {
/* 47 */     return (FreeRefFunction)this._functionsByName.get(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\formul\\udf\DefaultUDFFinder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */