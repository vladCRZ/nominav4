/*    */ package org.apache.poi.hssf.record.pivottable;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ import org.apache.poi.util.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DataItemRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 197;
/*    */   private int isxvdData;
/*    */   private int iiftab;
/*    */   private int df;
/*    */   private int isxvd;
/*    */   private int isxvi;
/*    */   private int ifmt;
/*    */   private String name;
/*    */   
/*    */   public DataItemRecord(RecordInputStream in)
/*    */   {
/* 43 */     this.isxvdData = in.readUShort();
/* 44 */     this.iiftab = in.readUShort();
/* 45 */     this.df = in.readUShort();
/* 46 */     this.isxvd = in.readUShort();
/* 47 */     this.isxvi = in.readUShort();
/* 48 */     this.ifmt = in.readUShort();
/*    */     
/* 50 */     this.name = in.readString();
/*    */   }
/*    */   
/*    */ 
/*    */   protected void serialize(LittleEndianOutput out)
/*    */   {
/* 56 */     out.writeShort(this.isxvdData);
/* 57 */     out.writeShort(this.iiftab);
/* 58 */     out.writeShort(this.df);
/* 59 */     out.writeShort(this.isxvd);
/* 60 */     out.writeShort(this.isxvi);
/* 61 */     out.writeShort(this.ifmt);
/*    */     
/* 63 */     StringUtil.writeUnicodeString(out, this.name);
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 68 */     return 12 + StringUtil.getEncodedSize(this.name);
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 73 */     return 197;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 78 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 80 */     buffer.append("[SXDI]\n");
/* 81 */     buffer.append("  .isxvdData = ").append(HexDump.shortToHex(this.isxvdData)).append("\n");
/* 82 */     buffer.append("  .iiftab = ").append(HexDump.shortToHex(this.iiftab)).append("\n");
/* 83 */     buffer.append("  .df = ").append(HexDump.shortToHex(this.df)).append("\n");
/* 84 */     buffer.append("  .isxvd = ").append(HexDump.shortToHex(this.isxvd)).append("\n");
/* 85 */     buffer.append("  .isxvi = ").append(HexDump.shortToHex(this.isxvi)).append("\n");
/* 86 */     buffer.append("  .ifmt = ").append(HexDump.shortToHex(this.ifmt)).append("\n");
/* 87 */     buffer.append("[/SXDI]\n");
/* 88 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\pivottable\DataItemRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */