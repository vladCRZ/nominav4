/*     */ package org.apache.poi.hssf.record.pivottable;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordFormatException;
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PageItemRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 182;
/*     */   private final FieldInfo[] _fieldInfos;
/*     */   
/*     */   private static final class FieldInfo
/*     */   {
/*     */     public static final int ENCODED_SIZE = 6;
/*     */     private int _isxvi;
/*     */     private int _isxvd;
/*     */     private int _idObj;
/*     */     
/*     */     public FieldInfo(RecordInputStream in)
/*     */     {
/*  44 */       this._isxvi = in.readShort();
/*  45 */       this._isxvd = in.readShort();
/*  46 */       this._idObj = in.readShort();
/*     */     }
/*     */     
/*     */     protected void serialize(LittleEndianOutput out) {
/*  50 */       out.writeShort(this._isxvi);
/*  51 */       out.writeShort(this._isxvd);
/*  52 */       out.writeShort(this._idObj);
/*     */     }
/*     */     
/*     */     public void appendDebugInfo(StringBuffer sb) {
/*  56 */       sb.append('(');
/*  57 */       sb.append("isxvi=").append(HexDump.shortToHex(this._isxvi));
/*  58 */       sb.append(" isxvd=").append(HexDump.shortToHex(this._isxvd));
/*  59 */       sb.append(" idObj=").append(HexDump.shortToHex(this._idObj));
/*  60 */       sb.append(')');
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public PageItemRecord(RecordInputStream in)
/*     */   {
/*  67 */     int dataSize = in.remaining();
/*  68 */     if (dataSize % 6 != 0) {
/*  69 */       throw new RecordFormatException("Bad data size " + dataSize);
/*     */     }
/*     */     
/*  72 */     int nItems = dataSize / 6;
/*     */     
/*  74 */     FieldInfo[] fis = new FieldInfo[nItems];
/*  75 */     for (int i = 0; i < fis.length; i++) {
/*  76 */       fis[i] = new FieldInfo(in);
/*     */     }
/*  78 */     this._fieldInfos = fis;
/*     */   }
/*     */   
/*     */   protected void serialize(LittleEndianOutput out)
/*     */   {
/*  83 */     for (int i = 0; i < this._fieldInfos.length; i++) {
/*  84 */       this._fieldInfos[i].serialize(out);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/*  90 */     return this._fieldInfos.length * 6;
/*     */   }
/*     */   
/*     */   public short getSid()
/*     */   {
/*  95 */     return 182;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 100 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 102 */     sb.append("[SXPI]\n");
/* 103 */     for (int i = 0; i < this._fieldInfos.length; i++) {
/* 104 */       sb.append("    item[").append(i).append("]=");
/* 105 */       this._fieldInfos[i].appendDebugInfo(sb);
/* 106 */       sb.append('\n');
/*     */     }
/* 108 */     sb.append("[/SXPI]\n");
/* 109 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\pivottable\PageItemRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */