/*    */ package org.apache.poi.hssf.record.pivottable;
/*    */ 
/*    */ import org.apache.poi.hssf.record.RecordInputStream;
/*    */ import org.apache.poi.hssf.record.StandardRecord;
/*    */ import org.apache.poi.util.HexDump;
/*    */ import org.apache.poi.util.LittleEndianOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StreamIDRecord
/*    */   extends StandardRecord
/*    */ {
/*    */   public static final short sid = 213;
/*    */   private int idstm;
/*    */   
/*    */   public StreamIDRecord(RecordInputStream in)
/*    */   {
/* 36 */     this.idstm = in.readShort();
/*    */   }
/*    */   
/*    */   protected void serialize(LittleEndianOutput out)
/*    */   {
/* 41 */     out.writeShort(this.idstm);
/*    */   }
/*    */   
/*    */   protected int getDataSize()
/*    */   {
/* 46 */     return 2;
/*    */   }
/*    */   
/*    */   public short getSid()
/*    */   {
/* 51 */     return 213;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 56 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 58 */     buffer.append("[SXIDSTM]\n");
/* 59 */     buffer.append("    .idstm      =").append(HexDump.shortToHex(this.idstm)).append('\n');
/*    */     
/* 61 */     buffer.append("[/SXIDSTM]\n");
/* 62 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\pivottable\StreamIDRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */