/*     */ package org.apache.poi.hssf.record.pivottable;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ViewDefinitionRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 176;
/*     */   private int rwFirst;
/*     */   private int rwLast;
/*     */   private int colFirst;
/*     */   private int colLast;
/*     */   private int rwFirstHead;
/*     */   private int rwFirstData;
/*     */   private int colFirstData;
/*     */   private int iCache;
/*     */   private int reserved;
/*     */   private int sxaxis4Data;
/*     */   private int ipos4Data;
/*     */   private int cDim;
/*     */   private int cDimRw;
/*     */   private int cDimCol;
/*     */   private int cDimPg;
/*     */   private int cDimData;
/*     */   private int cRw;
/*     */   private int cCol;
/*     */   private int grbit;
/*     */   private int itblAutoFmt;
/*     */   private String dataField;
/*     */   private String name;
/*     */   
/*     */   public ViewDefinitionRecord(RecordInputStream in)
/*     */   {
/*  64 */     this.rwFirst = in.readUShort();
/*  65 */     this.rwLast = in.readUShort();
/*  66 */     this.colFirst = in.readUShort();
/*  67 */     this.colLast = in.readUShort();
/*  68 */     this.rwFirstHead = in.readUShort();
/*  69 */     this.rwFirstData = in.readUShort();
/*  70 */     this.colFirstData = in.readUShort();
/*  71 */     this.iCache = in.readUShort();
/*  72 */     this.reserved = in.readUShort();
/*  73 */     this.sxaxis4Data = in.readUShort();
/*  74 */     this.ipos4Data = in.readUShort();
/*  75 */     this.cDim = in.readUShort();
/*  76 */     this.cDimRw = in.readUShort();
/*  77 */     this.cDimCol = in.readUShort();
/*  78 */     this.cDimPg = in.readUShort();
/*  79 */     this.cDimData = in.readUShort();
/*  80 */     this.cRw = in.readUShort();
/*  81 */     this.cCol = in.readUShort();
/*  82 */     this.grbit = in.readUShort();
/*  83 */     this.itblAutoFmt = in.readUShort();
/*  84 */     int cchName = in.readUShort();
/*  85 */     int cchData = in.readUShort();
/*     */     
/*  87 */     this.name = StringUtil.readUnicodeString(in, cchName);
/*  88 */     this.dataField = StringUtil.readUnicodeString(in, cchData);
/*     */   }
/*     */   
/*     */   protected void serialize(LittleEndianOutput out)
/*     */   {
/*  93 */     out.writeShort(this.rwFirst);
/*  94 */     out.writeShort(this.rwLast);
/*  95 */     out.writeShort(this.colFirst);
/*  96 */     out.writeShort(this.colLast);
/*  97 */     out.writeShort(this.rwFirstHead);
/*  98 */     out.writeShort(this.rwFirstData);
/*  99 */     out.writeShort(this.colFirstData);
/* 100 */     out.writeShort(this.iCache);
/* 101 */     out.writeShort(this.reserved);
/* 102 */     out.writeShort(this.sxaxis4Data);
/* 103 */     out.writeShort(this.ipos4Data);
/* 104 */     out.writeShort(this.cDim);
/* 105 */     out.writeShort(this.cDimRw);
/* 106 */     out.writeShort(this.cDimCol);
/* 107 */     out.writeShort(this.cDimPg);
/* 108 */     out.writeShort(this.cDimData);
/* 109 */     out.writeShort(this.cRw);
/* 110 */     out.writeShort(this.cCol);
/* 111 */     out.writeShort(this.grbit);
/* 112 */     out.writeShort(this.itblAutoFmt);
/* 113 */     out.writeShort(this.name.length());
/* 114 */     out.writeShort(this.dataField.length());
/*     */     
/* 116 */     StringUtil.writeUnicodeStringFlagAndData(out, this.name);
/* 117 */     StringUtil.writeUnicodeStringFlagAndData(out, this.dataField);
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/* 122 */     return 40 + StringUtil.getEncodedSize(this.name) + StringUtil.getEncodedSize(this.dataField);
/*     */   }
/*     */   
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 128 */     return 176;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 133 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 135 */     buffer.append("[SXVIEW]\n");
/* 136 */     buffer.append("    .rwFirst      =").append(HexDump.shortToHex(this.rwFirst)).append('\n');
/* 137 */     buffer.append("    .rwLast       =").append(HexDump.shortToHex(this.rwLast)).append('\n');
/* 138 */     buffer.append("    .colFirst     =").append(HexDump.shortToHex(this.colFirst)).append('\n');
/* 139 */     buffer.append("    .colLast      =").append(HexDump.shortToHex(this.colLast)).append('\n');
/* 140 */     buffer.append("    .rwFirstHead  =").append(HexDump.shortToHex(this.rwFirstHead)).append('\n');
/* 141 */     buffer.append("    .rwFirstData  =").append(HexDump.shortToHex(this.rwFirstData)).append('\n');
/* 142 */     buffer.append("    .colFirstData =").append(HexDump.shortToHex(this.colFirstData)).append('\n');
/* 143 */     buffer.append("    .iCache       =").append(HexDump.shortToHex(this.iCache)).append('\n');
/* 144 */     buffer.append("    .reserved     =").append(HexDump.shortToHex(this.reserved)).append('\n');
/* 145 */     buffer.append("    .sxaxis4Data  =").append(HexDump.shortToHex(this.sxaxis4Data)).append('\n');
/* 146 */     buffer.append("    .ipos4Data    =").append(HexDump.shortToHex(this.ipos4Data)).append('\n');
/* 147 */     buffer.append("    .cDim         =").append(HexDump.shortToHex(this.cDim)).append('\n');
/* 148 */     buffer.append("    .cDimRw       =").append(HexDump.shortToHex(this.cDimRw)).append('\n');
/* 149 */     buffer.append("    .cDimCol      =").append(HexDump.shortToHex(this.cDimCol)).append('\n');
/* 150 */     buffer.append("    .cDimPg       =").append(HexDump.shortToHex(this.cDimPg)).append('\n');
/* 151 */     buffer.append("    .cDimData     =").append(HexDump.shortToHex(this.cDimData)).append('\n');
/* 152 */     buffer.append("    .cRw          =").append(HexDump.shortToHex(this.cRw)).append('\n');
/* 153 */     buffer.append("    .cCol         =").append(HexDump.shortToHex(this.cCol)).append('\n');
/* 154 */     buffer.append("    .grbit        =").append(HexDump.shortToHex(this.grbit)).append('\n');
/* 155 */     buffer.append("    .itblAutoFmt  =").append(HexDump.shortToHex(this.itblAutoFmt)).append('\n');
/* 156 */     buffer.append("    .name         =").append(this.name).append('\n');
/* 157 */     buffer.append("    .dataField    =").append(this.dataField).append('\n');
/*     */     
/* 159 */     buffer.append("[/SXVIEW]\n");
/* 160 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\pivottable\ViewDefinitionRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */