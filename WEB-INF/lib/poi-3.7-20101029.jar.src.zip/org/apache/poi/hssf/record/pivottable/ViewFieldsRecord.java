/*     */ package org.apache.poi.hssf.record.pivottable;
/*     */ 
/*     */ import org.apache.poi.hssf.record.RecordInputStream;
/*     */ import org.apache.poi.hssf.record.StandardRecord;
/*     */ import org.apache.poi.util.HexDump;
/*     */ import org.apache.poi.util.LittleEndianOutput;
/*     */ import org.apache.poi.util.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ViewFieldsRecord
/*     */   extends StandardRecord
/*     */ {
/*     */   public static final short sid = 177;
/*     */   private static final int STRING_NOT_PRESENT_LEN = 65535;
/*     */   private static final int BASE_SIZE = 10;
/*     */   private int _sxaxis;
/*     */   private int _cSub;
/*     */   private int _grbitSub;
/*     */   private int _cItm;
/*     */   private String _name;
/*     */   
/*     */   public ViewFieldsRecord(RecordInputStream in)
/*     */   {
/*  58 */     this._sxaxis = in.readShort();
/*  59 */     this._cSub = in.readShort();
/*  60 */     this._grbitSub = in.readShort();
/*  61 */     this._cItm = in.readShort();
/*     */     
/*  63 */     int cchName = in.readUShort();
/*  64 */     if (cchName != 65535) {
/*  65 */       int flag = in.readByte();
/*  66 */       if ((flag & 0x1) != 0) {
/*  67 */         this._name = in.readUnicodeLEString(cchName);
/*     */       } else {
/*  69 */         this._name = in.readCompressedUnicode(cchName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void serialize(LittleEndianOutput out)
/*     */   {
/*  77 */     out.writeShort(this._sxaxis);
/*  78 */     out.writeShort(this._cSub);
/*  79 */     out.writeShort(this._grbitSub);
/*  80 */     out.writeShort(this._cItm);
/*     */     
/*  82 */     if (this._name != null) {
/*  83 */       StringUtil.writeUnicodeString(out, this._name);
/*     */     } else {
/*  85 */       out.writeShort(65535);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getDataSize()
/*     */   {
/*  91 */     if (this._name == null) {
/*  92 */       return 10;
/*     */     }
/*  94 */     return 11 + this._name.length() * (StringUtil.hasMultibyte(this._name) ? 2 : 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public short getSid()
/*     */   {
/* 101 */     return 177;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 106 */     StringBuffer buffer = new StringBuffer();
/* 107 */     buffer.append("[SXVD]\n");
/* 108 */     buffer.append("    .sxaxis    = ").append(HexDump.shortToHex(this._sxaxis)).append('\n');
/* 109 */     buffer.append("    .cSub      = ").append(HexDump.shortToHex(this._cSub)).append('\n');
/* 110 */     buffer.append("    .grbitSub  = ").append(HexDump.shortToHex(this._grbitSub)).append('\n');
/* 111 */     buffer.append("    .cItm      = ").append(HexDump.shortToHex(this._cItm)).append('\n');
/* 112 */     buffer.append("    .name      = ").append(this._name).append('\n');
/*     */     
/* 114 */     buffer.append("[/SXVD]\n");
/* 115 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private static final class Axis
/*     */   {
/*     */     public static final int NO_AXIS = 0;
/*     */     public static final int ROW = 1;
/*     */     public static final int COLUMN = 2;
/*     */     public static final int PAGE = 4;
/*     */     public static final int DATA = 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\poi-3.7-20101029.jar!\org\apache\poi\hssf\record\pivottable\ViewFieldsRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */