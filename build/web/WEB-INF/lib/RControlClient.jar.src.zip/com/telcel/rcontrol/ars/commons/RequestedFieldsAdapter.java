/*    */ package com.telcel.rcontrol.ars.commons;
/*    */ 
/*    */ import com.infomedia.utils.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestedFieldsAdapter
/*    */ {
/*    */   public int[] parse(String fields)
/*    */   {
/* 21 */     String[] fieldArray = StringUtils.NVL(fields, "").split("[ ]+");
/* 22 */     int[] requestedFields = new int[fieldArray.length];
/* 23 */     int idx = 0;
/*    */     
/* 25 */     for (String field : fieldArray) {
/* 26 */       if (!"".equals(field)) {
/* 27 */         requestedFields[(idx++)] = Integer.parseInt(field);
/*    */       }
/*    */     }
/* 30 */     return requestedFields;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\ars\commons\RequestedFieldsAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */