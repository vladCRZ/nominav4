/*     */ package com.telcel.rcontrol.ars.commons;
/*     */ 
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WhereClauseAdapter
/*     */ {
/*     */   private String createElement(boolean first, boolean negateLike, String logical, String field, String operator, String value)
/*     */   {
/*  32 */     return (first ? "" : logical) + (negateLike ? " NOT " : "") + "'" + field.trim() + "'" + operator + (StringUtils.isNAN(value.trim()) ? "\"" : "") + value.trim() + (StringUtils.isNAN(value.trim()) ? "\"" : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   private boolean isMultiValue(String value) { return StringUtils.fncbMatches("[(](.*[,]?){1,}[)]", value.trim()); }
/*     */   
/*     */   private String parseMultiValue(String field, String value, String operator, String logical, boolean negateLike) {
/*  42 */     StringBuilder multi = new StringBuilder();
/*     */     
/*  44 */     multi.append("(");
/*  45 */     for (String val : value.trim().substring(1, value.length() - 1).split(",")) {
/*  46 */       multi.append(createElement(multi.toString().endsWith("("), negateLike, logical, field, operator, val));
/*     */     }
/*  48 */     multi.append(")");
/*     */     
/*  50 */     return multi.toString();
/*     */   }
/*     */   
/*  53 */   public String parseWhereClause(String where) { StringBuilder whereClause = new StringBuilder();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */     if (StringUtils.isNVL(where.trim())) {
/*  62 */       return "";
/*     */     }
/*     */     
/*  65 */     for (String orClauses : where.split("[|]")) {
/*  66 */       whereClause.append(0 == whereClause.length() ? "" : " OR ");
/*  67 */       whereClause.append("(");
/*  68 */       for (String andClause : orClauses.split("'[ ]+'")) {
/*  69 */         boolean negateLike = false;
/*  70 */         boolean negateOperator = false;
/*  71 */         String operator; String field; String operator; String value; if ((andClause.contains("<>")) && (andClause.contains("%"))) {
/*  72 */           String[] entry = andClause.split("<>");
/*  73 */           String field = entry[0].replaceAll("'", "").trim();
/*  74 */           String value = entry[1].replaceAll("'", "").trim();
/*  75 */           negateLike = true;
/*  76 */           negateOperator = true;
/*  77 */           operator = " LIKE "; } else { String operator;
/*  78 */           if (andClause.contains("<>")) {
/*  79 */             String[] entry = andClause.split("<>");
/*  80 */             String field = entry[0].replaceAll("'", "").trim();
/*  81 */             String value = entry[1].replaceAll("'", "").trim();
/*  82 */             negateOperator = true;
/*  83 */             operator = "!="; } else { String operator;
/*  84 */             if ((andClause.contains("!=")) && (andClause.contains("%"))) {
/*  85 */               String[] entry = andClause.split("!=");
/*  86 */               String field = entry[0].replaceAll("'", "").trim();
/*  87 */               String value = entry[1].replaceAll("'", "").trim();
/*  88 */               negateLike = true;
/*  89 */               negateOperator = true;
/*  90 */               operator = " LIKE "; } else { String operator;
/*  91 */               if (andClause.contains("!=")) {
/*  92 */                 String[] entry = andClause.split("!=");
/*  93 */                 String field = entry[0].replaceAll("'", "").trim();
/*  94 */                 String value = entry[1].replaceAll("'", "").trim();
/*  95 */                 negateOperator = true;
/*  96 */                 operator = "!="; } else { String operator;
/*  97 */                 if ((andClause.contains("'='")) && (andClause.contains("%"))) {
/*  98 */                   String[] entry = andClause.split("'='");
/*  99 */                   String field = entry[0].replaceAll("'", "").trim();
/* 100 */                   String value = entry[1].replaceAll("'", "").trim();
/* 101 */                   operator = " LIKE "; } else { String operator;
/* 102 */                   if (andClause.contains("'='")) {
/* 103 */                     String[] entry = andClause.split("'='");
/* 104 */                     String field = entry[0].replaceAll("'", "").trim();
/* 105 */                     String value = entry[1].replaceAll("'", "").trim();
/* 106 */                     operator = "="; } else { String operator;
/* 107 */                     if (andClause.contains("<=")) {
/* 108 */                       String[] entry = andClause.split("<=");
/* 109 */                       String field = entry[0].replaceAll("'", "").trim();
/* 110 */                       String value = entry[1].replaceAll("'", "").trim();
/* 111 */                       operator = "<="; } else { String operator;
/* 112 */                       if (andClause.contains(">=")) {
/* 113 */                         String[] entry = andClause.split(">=");
/* 114 */                         String field = entry[0].replaceAll("'", "").trim();
/* 115 */                         String value = entry[1].replaceAll("'", "").trim();
/* 116 */                         operator = ">="; } else { String operator;
/* 117 */                         if (andClause.contains("<")) {
/* 118 */                           String[] entry = andClause.split("<");
/* 119 */                           String field = entry[0].replaceAll("'", "").trim();
/* 120 */                           String value = entry[1].replaceAll("'", "").trim();
/* 121 */                           operator = "<"; } else { String operator;
/* 122 */                           if (andClause.contains(">")) {
/* 123 */                             String[] entry = andClause.split(">");
/* 124 */                             String field = entry[0].replaceAll("'", "").trim();
/* 125 */                             String value = entry[1].replaceAll("'", "").trim();
/* 126 */                             operator = ">";
/*     */                           } else {
/* 128 */                             field = "";
/* 129 */                             operator = "";
/* 130 */                             value = "";
/*     */                           } } } } } } } } } }
/* 132 */         if (isMultiValue(value)) {
/* 133 */           whereClause.append(whereClause.toString().endsWith("(") ? "" : " AND ").append(parseMultiValue(field, value, operator, negateOperator ? " AND " : " OR ", negateLike));
/*     */         }
/*     */         else {
/* 136 */           whereClause.append(createElement(whereClause.toString().endsWith("("), negateLike, " AND ", field, operator, value));
/*     */         }
/*     */       }
/* 139 */       whereClause.append(")");
/*     */     }
/* 141 */     return whereClause.toString();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 145 */     System.out.println(new WhereClauseAdapter().parseWhereClause("'7'='(0,1,2,3)' '1000000000'='Pruebas OOHP' '1000000151'='pruebas con OOHP'"));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\ars\commons\WhereClauseAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */