/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"integrationName", "affectedForm", "fieldID", "value"})
/*    */ @XmlRootElement(name="DecodeRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class DecodeRequest
/*    */ {
/*    */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String integrationName;
/*    */   @XmlElement(name="affectedForm", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String affectedForm;
/*    */   @XmlElement(name="fieldID", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String fieldID;
/*    */   @XmlElement(name="value", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String value;
/*    */   
/*    */   public String getIntegrationName()
/*    */   {
/* 30 */     return this.integrationName;
/*    */   }
/*    */   
/*    */   public void setIntegrationName(String value) {
/* 34 */     this.integrationName = value;
/*    */   }
/*    */   
/*    */   public String getAffectedForm() {
/* 38 */     return this.affectedForm;
/*    */   }
/*    */   
/*    */   public void setAffectedForm(String value) {
/* 42 */     this.affectedForm = value;
/*    */   }
/*    */   
/*    */   public String getFieldID() {
/* 46 */     return this.fieldID;
/*    */   }
/*    */   
/*    */   public void setFieldID(String fieldID) {
/* 50 */     this.fieldID = fieldID;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 54 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 58 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\DecodeRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */