/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"value", "description"})
/*    */ @XmlRootElement(name="DecodeResponse", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class DecodeResponse
/*    */ {
/*    */   @XmlElement(name="value", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String value;
/*    */   @XmlElement(name="description", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String description;
/*    */   
/*    */   public void setValue(String value)
/*    */   {
/* 27 */     this.value = value;
/*    */   }
/*    */   
/* 30 */   public String getValue() { return this.value; }
/*    */   
/*    */   public void setDescription(String description)
/*    */   {
/* 34 */     this.description = description;
/*    */   }
/*    */   
/* 37 */   public String getDescription() { return this.description; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\DecodeResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */