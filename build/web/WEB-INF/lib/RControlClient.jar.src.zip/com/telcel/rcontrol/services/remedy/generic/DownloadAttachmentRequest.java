/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"integrationName", "formName", "entryID", "fieldID"})
/*    */ @XmlRootElement(name="DownloadAttachmentRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class DownloadAttachmentRequest
/*    */ {
/*    */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String integrationName;
/*    */   @XmlElement(name="formName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String formName;
/*    */   @XmlElement(name="entryID", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String entryID;
/*    */   @XmlElement(name="fieldID", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected int fieldID;
/*    */   
/*    */   public String getIntegrationName()
/*    */   {
/* 30 */     return this.integrationName;
/*    */   }
/*    */   
/* 33 */   public void setIntegrationName(String value) { this.integrationName = value; }
/*    */   
/*    */   public String getFormName()
/*    */   {
/* 37 */     return this.formName;
/*    */   }
/*    */   
/* 40 */   public void setFormName(String formName) { this.formName = formName; }
/*    */   
/*    */   public String getEntryID()
/*    */   {
/* 44 */     return this.entryID;
/*    */   }
/*    */   
/* 47 */   public void setEntryID(String entryID) { this.entryID = entryID; }
/*    */   
/*    */   public int getFieldID()
/*    */   {
/* 51 */     return this.fieldID;
/*    */   }
/*    */   
/* 54 */   public void setFieldID(int fieldID) { this.fieldID = fieldID; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\DownloadAttachmentRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */