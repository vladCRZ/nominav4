/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"downloaded"})
/*    */ @XmlRootElement(name="DownloadAttachmentResponse", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class DownloadAttachmentResponse
/*    */ {
/*    */   @XmlElement(name="downloaded", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected boolean downloaded;
/*    */   
/*    */   public boolean downloaded()
/*    */   {
/* 21 */     return this.downloaded;
/*    */   }
/*    */   
/*    */   public void setDownloaded(boolean downloaded) {
/* 25 */     this.downloaded = downloaded;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\DownloadAttachmentResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */