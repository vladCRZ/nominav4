/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="Field", propOrder={"id", "value"})
/*    */ public class Field
/*    */ {
/*    */   @XmlElement(name="id")
/*    */   protected int id;
/*    */   @XmlElement(name="value")
/*    */   protected String value;
/*    */   
/*    */   public Field() {}
/*    */   
/*    */   public Field(int id, String value)
/*    */   {
/* 25 */     this.id = id;
/* 26 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 30 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int value) {
/* 34 */     this.id = value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 38 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 42 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 46 */     return this.id + "=" + this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\Field.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */