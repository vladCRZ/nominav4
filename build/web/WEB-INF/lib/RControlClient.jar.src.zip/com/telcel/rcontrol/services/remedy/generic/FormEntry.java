/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="FormEntry", propOrder={"entry"})
/*    */ public class FormEntry
/*    */ {
/*    */   @XmlElement(name="Entry")
/* 17 */   protected List<ListOfFields> entry = new ArrayList();
/*    */   
/*    */   public List<ListOfFields> getEntry()
/*    */   {
/* 21 */     return this.entry;
/*    */   }
/*    */   
/*    */   public void addEntry(ListOfFields entry) {
/* 25 */     this.entry.add(entry);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 29 */     StringBuilder sb = new StringBuilder();
/* 30 */     for (ListOfFields lof : this.entry) {
/* 31 */       sb.append("&").append(lof);
/*    */     }
/* 33 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\FormEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */