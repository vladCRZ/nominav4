/*     */ package com.telcel.rcontrol.services.remedy.generic;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"integrationName", "affectedForm", "insertedValues", "qualification"})
/*     */ @XmlRootElement(name="InsertRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */ public class InsertRequest
/*     */ {
/*     */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String integrationName;
/*     */   @XmlElement(name="affectedForm", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String affectedForm;
/*     */   @XmlElement(name="insertedValues", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected ListOfFields insertedValues;
/*     */   @XmlElement(name="qualification", required=false, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String qualification;
/*     */   
/*     */   public String getIntegrationName()
/*     */   {
/*  68 */     return this.integrationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIntegrationName(String value)
/*     */   {
/*  80 */     this.integrationName = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAffectedForm()
/*     */   {
/*  92 */     return this.affectedForm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAffectedForm(String value)
/*     */   {
/* 104 */     this.affectedForm = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ListOfFields getInsertedValues()
/*     */   {
/* 116 */     return this.insertedValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInsertedValues(ListOfFields value)
/*     */   {
/* 128 */     this.insertedValues = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQualification()
/*     */   {
/* 155 */     return this.qualification;
/*     */   }
/*     */   
/*     */   public void setQualification(String qualification) {
/* 159 */     this.qualification = qualification;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\InsertRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */