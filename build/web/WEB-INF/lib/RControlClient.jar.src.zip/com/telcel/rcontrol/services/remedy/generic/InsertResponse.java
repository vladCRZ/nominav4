/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"status"})
/*    */ @XmlRootElement(name="InsertResponse", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class InsertResponse
/*    */ {
/*    */   @XmlElement(name="status", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected InsertStatus status;
/*    */   
/*    */   public void setStatus(InsertStatus status)
/*    */   {
/* 25 */     this.status = status;
/*    */   }
/*    */   
/*    */   public InsertStatus getStatus() {
/* 29 */     return this.status;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\InsertResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */