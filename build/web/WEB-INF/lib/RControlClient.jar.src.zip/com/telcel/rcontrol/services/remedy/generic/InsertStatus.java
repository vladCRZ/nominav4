/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"status", "createdEntry"})
/*    */ @XmlRootElement(name="InsertStatus", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class InsertStatus
/*    */ {
/*    */   @XmlElement(name="status", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String status;
/*    */   @XmlElement(name="createdEntry", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String createdEntry;
/*    */   
/*    */   public String getStatus()
/*    */   {
/* 60 */     return this.status;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setStatus(String status)
/*    */   {
/* 72 */     this.status = status;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getCreatedEntry()
/*    */   {
/* 84 */     return this.createdEntry;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCreatedEntry(String createdEntry)
/*    */   {
/* 96 */     this.createdEntry = createdEntry;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\InsertStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */