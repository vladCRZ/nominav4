/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"integrationName", "formName", "fieldID"})
/*    */ @XmlRootElement(name="IsStringRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class IsStringRequest
/*    */ {
/*    */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String integrationName;
/*    */   @XmlElement(name="formName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String formName;
/*    */   @XmlElement(name="fieldID", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected int fieldID;
/*    */   
/*    */   public String getIntegrationName()
/*    */   {
/* 27 */     return this.integrationName;
/*    */   }
/*    */   
/* 30 */   public void setIntegrationName(String value) { this.integrationName = value; }
/*    */   
/*    */   public String getFormName()
/*    */   {
/* 34 */     return this.formName;
/*    */   }
/*    */   
/* 37 */   public void setFormName(String formName) { this.formName = formName; }
/*    */   
/*    */   public int getFieldID()
/*    */   {
/* 41 */     return this.fieldID;
/*    */   }
/*    */   
/* 44 */   public void setFieldID(int fieldID) { this.fieldID = fieldID; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\IsStringRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */