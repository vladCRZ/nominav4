/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"isString"})
/*    */ @XmlRootElement(name="IsStringResponse", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class IsStringResponse
/*    */ {
/*    */   @XmlElement(name="isString", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected boolean isString;
/*    */   
/*    */   public boolean isString()
/*    */   {
/* 21 */     return this.isString;
/*    */   }
/*    */   
/*    */   public void setIsString(boolean isString) {
/* 25 */     this.isString = isString;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\IsStringResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */