/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import javax.xml.soap.SOAPMessage;
/*    */ import javax.xml.ws.handler.MessageContext;
/*    */ import javax.xml.ws.handler.soap.SOAPHandler;
/*    */ import javax.xml.ws.handler.soap.SOAPMessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LatinHandler
/*    */   implements SOAPHandler<SOAPMessageContext>
/*    */ {
/*    */   public boolean handleMessage(SOAPMessageContext context)
/*    */   {
/* 29 */     Boolean outbound = (Boolean)context.get("javax.xml.ws.handler.message.outbound");
/* 30 */     if (outbound.booleanValue()) {
/*    */       try {
/* 32 */         context.getMessage().setProperty("javax.xml.soap.character-set-encoding", "ISO-8859-1");
/*    */       }
/*    */       catch (SOAPException e)
/*    */       {
/* 36 */         throw new RuntimeException(e);
/*    */       }
/*    */     }
/* 39 */     return true;
/*    */   }
/*    */   
/*    */   public Set<QName> getHeaders()
/*    */   {
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public boolean handleFault(SOAPMessageContext c)
/*    */   {
/* 49 */     return true;
/*    */   }
/*    */   
/*    */   public void close(MessageContext mc) {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\LatinHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */