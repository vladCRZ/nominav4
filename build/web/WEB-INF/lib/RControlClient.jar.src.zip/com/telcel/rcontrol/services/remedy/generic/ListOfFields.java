/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="EntryFields", propOrder={"field"})
/*    */ public class ListOfFields
/*    */ {
/*    */   @XmlElement(name="Field")
/* 17 */   protected List<Field> field = new ArrayList();
/*    */   
/*    */   public List<Field> getField()
/*    */   {
/* 21 */     return this.field;
/*    */   }
/*    */   
/*    */   public void addField(Field field) {
/* 25 */     this.field.add(field);
/*    */   }
/*    */   
/*    */   public String getValue(int id) {
/* 29 */     for (Field f : this.field) {
/* 30 */       if (id == f.getId()) {
/* 31 */         return f.getValue();
/*    */       }
/*    */     }
/* 34 */     return "";
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 39 */     StringBuilder sb = new StringBuilder();
/* 40 */     for (Field f : this.field) {
/* 41 */       sb.append(" ").append(f);
/*    */     }
/* 43 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\ListOfFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */