/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlRegistry
/*    */ public class ObjectFactory
/*    */ {
/*    */   public DecodeRequest createDecodeRequest()
/*    */   {
/* 14 */     return new DecodeRequest();
/*    */   }
/*    */   
/* 17 */   public DecodeResponse createDecodeResponse() { return new DecodeResponse(); }
/*    */   
/*    */   public SelectRequest createSelectRequest()
/*    */   {
/* 21 */     return new SelectRequest();
/*    */   }
/*    */   
/* 24 */   public SelectResultset createSelectResultset() { return new SelectResultset(); }
/*    */   
/*    */   public UpdateRequest createUpdateRequest()
/*    */   {
/* 28 */     return new UpdateRequest();
/*    */   }
/*    */   
/* 31 */   public UpdateStatus createUpdateStatus() { return new UpdateStatus(); }
/*    */   
/*    */   public InsertRequest createInsertRequest()
/*    */   {
/* 35 */     return new InsertRequest();
/*    */   }
/*    */   
/* 38 */   public InsertStatus createInsertStatus() { return new InsertStatus(); }
/*    */   
/*    */   public RemedyFault createRemedyFault()
/*    */   {
/* 42 */     return new RemedyFault();
/*    */   }
/*    */   
/*    */   public ListOfFields createListOfFields() {
/* 46 */     return new ListOfFields();
/*    */   }
/*    */   
/*    */   public FormEntry createFormEntry() {
/* 50 */     return new FormEntry();
/*    */   }
/*    */   
/*    */   public Field createField() {
/* 54 */     return new Field();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\ObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */