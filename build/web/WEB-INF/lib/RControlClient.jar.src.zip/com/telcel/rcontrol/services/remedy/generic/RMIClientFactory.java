/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.ws.Service;
/*    */ 
/*    */ 
/*    */ public class RMIClientFactory
/*    */ {
/*    */   private static final String namespace = "http://telcel.com/rcontrol/services/remedy/generic";
/*    */   private static final String serviceName = "RemedyService";
/*    */   private static final String portName = "RemedyPort";
/* 14 */   private static final QName Service_QName = new QName("http://telcel.com/rcontrol/services/remedy/generic", "RemedyService");
/* 15 */   private static final QName Port_QName = new QName("http://telcel.com/rcontrol/services/remedy/generic", "RemedyPort");
/*    */   
/*    */   public static RemedyPort getRemedyPort(String endpoint) throws MalformedURLException
/*    */   {
/* 19 */     Service service = Service.create(new URL(endpoint), Service_QName);
/* 20 */     return (RemedyPort)service.getPort(Port_QName, RemedyPort.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\RMIClientFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */