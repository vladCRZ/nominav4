/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.ws.Service;
/*    */ 
/*    */ 
/*    */ public class RMIUtilsFactory
/*    */ {
/*    */   private static final String namespace = "http://telcel.com/rcontrol/services/remedy/generic";
/*    */   private static final String serviceName = "RemedyUtilsService";
/*    */   private static final String portName = "RemedyUtilsPort";
/* 14 */   private static final QName Service_QName = new QName("http://telcel.com/rcontrol/services/remedy/generic", "RemedyUtilsService");
/* 15 */   private static final QName Port_QName = new QName("http://telcel.com/rcontrol/services/remedy/generic", "RemedyUtilsPort");
/*    */   
/*    */   public static RemedyUtilsPort getUtilsPort(String endpoint) throws MalformedURLException
/*    */   {
/* 19 */     Service service = Service.create(new URL(endpoint), Service_QName);
/* 20 */     return (RemedyUtilsPort)service.getPort(Port_QName, RemedyUtilsPort.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\RMIUtilsFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */