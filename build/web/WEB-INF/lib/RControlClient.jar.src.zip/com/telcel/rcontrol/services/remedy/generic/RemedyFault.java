/*     */ package com.telcel.rcontrol.services.remedy.generic;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"errorCode", "errorMessage", "errorDetail"})
/*     */ @XmlRootElement(name="RemedyFault")
/*     */ public class RemedyFault
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @XmlElement(name="ErrorCode")
/*     */   protected Integer errorCode;
/*     */   @XmlElement(name="ErrorMessage", required=true)
/*     */   protected String errorMessage;
/*     */   @XmlElement(name="ErrorDetail")
/*     */   protected String errorDetail;
/*     */   
/*     */   public RemedyFault() {}
/*     */   
/*     */   public RemedyFault(String errorMessage)
/*     */   {
/*  32 */     super(errorMessage);
/*  33 */     this.errorMessage = errorMessage;
/*  34 */     this.errorCode = Integer.valueOf(0);
/*     */   }
/*     */   
/*     */   public RemedyFault(int errorCode, String errorMessage, String errorDetail) {
/*  38 */     super(errorMessage);
/*  39 */     this.errorCode = Integer.valueOf(errorCode);
/*  40 */     this.errorMessage = errorMessage;
/*  41 */     this.errorDetail = errorDetail;
/*     */   }
/*     */   
/*     */   public RemedyFault(int code, Throwable cause, String detail) {
/*  45 */     super(cause.getMessage());
/*  46 */     this.errorCode = Integer.valueOf(code);
/*  47 */     this.errorMessage = cause.getMessage();
/*  48 */     this.errorDetail = detail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getErrorCode()
/*     */   {
/*  58 */     return this.errorCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorCode(Integer value)
/*     */   {
/*  68 */     this.errorCode = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getErrorMessage()
/*     */   {
/*  78 */     return this.errorMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorMessage(String value)
/*     */   {
/*  88 */     this.errorMessage = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getErrorDetail()
/*     */   {
/*  98 */     return this.errorDetail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorDetail(String value)
/*     */   {
/* 108 */     this.errorDetail = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\RemedyFault.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */