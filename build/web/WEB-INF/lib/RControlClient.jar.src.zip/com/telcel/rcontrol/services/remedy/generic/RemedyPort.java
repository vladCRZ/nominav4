package com.telcel.rcontrol.services.remedy.generic;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="RemedyService")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface RemedyPort
{
  public static final String _Remedy_WS_NAMESPACE = "http://telcel.com/rcontrol/services/remedy/generic";
  
  @WebMethod(operationName="RMDInsert", action="rmd:RMDInsert")
  @RequestWrapper(localName="InsertRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.InsertRequest")
  @ResponseWrapper(localName="InsertStatus", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.InsertResponse")
  @WebResult(name="status", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract InsertStatus rmdInsert(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="affectedForm", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="insertedValues", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") ListOfFields paramListOfFields, @WebParam(name="qualification", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString3)
    throws RemedyFault;
  
  @WebMethod(operationName="RMDUpdate", action="rmd:RMDUpdate")
  @RequestWrapper(localName="UpdateRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.UpdateRequest")
  @ResponseWrapper(localName="UpdateStatus", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.UpdateResponse")
  @WebResult(name="status", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract UpdateStatus rmdUpdate(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="affectedForm", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="affectedEntry", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString3, @WebParam(name="updatedValues", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") ListOfFields paramListOfFields)
    throws RemedyFault;
  
  @WebMethod(operationName="RMDSelect", action="rmd:RMDSelect")
  @RequestWrapper(localName="SelectRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.SelectRequest")
  @ResponseWrapper(localName="SelectResultset", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.SelectResultset")
  @WebResult(name="selectedItems", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract FormEntry rmdSelect(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="affectedForm", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="qualification", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString3, @WebParam(name="requestedFields", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int[] paramArrayOfInt1, @WebParam(name="orderBy", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int[] paramArrayOfInt2)
    throws RemedyFault;
  
  @WebMethod(operationName="RMDSelectSite", action="rmd:RMDSelectSite")
  @RequestWrapper(localName="SelectSiteRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.SelectSiteRequest")
  @ResponseWrapper(localName="SelectSiteResultset", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.SelectSiteResultset")
  @WebResult(name="selectedItems", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract FormEntry rmdSelectSite(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="affectedForm", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="qualification", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString3, @WebParam(name="requestedFields", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int[] paramArrayOfInt1, @WebParam(name="orderBy", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int[] paramArrayOfInt2)
    throws RemedyFault;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\RemedyPort.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */