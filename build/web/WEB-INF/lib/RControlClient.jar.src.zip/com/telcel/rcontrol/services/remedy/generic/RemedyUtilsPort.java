package com.telcel.rcontrol.services.remedy.generic;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name="RemedyUtilsService")
@XmlSeeAlso({ObjectFactory.class})
public abstract interface RemedyUtilsPort
{
  public static final String _Remedy_WS_NAMESPACE = "http://telcel.com/rcontrol/services/remedy/generic";
  
  @WebMethod(operationName="DecodeOptionValue", action="rmd:DecodeOptionValue")
  @RequestWrapper(localName="DecodeRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.DecodeRequest")
  @ResponseWrapper(localName="DecodeResponse", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.DecodeResponse")
  @WebResult(name="description", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract String rmdDecode(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="affectedForm", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="fieldID", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString3, @WebParam(name="value", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString4)
    throws RemedyFault;
  
  @WebMethod(operationName="SiteBelongsTo", action="rmd:SiteBelongsTo")
  @RequestWrapper(localName="SiteBelongsToRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.SiteBelongsToRequest")
  @ResponseWrapper(localName="SiteBelongsToResponse", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.SiteBelongsToResponse")
  @WebResult(name="belongsTo", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract ListOfFields rmdSiteBelongsTo(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString, @WebParam(name="ci", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") ListOfFields paramListOfFields, @WebParam(name="requestedFields", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int[] paramArrayOfInt)
    throws RemedyFault;
  
  @WebMethod(operationName="IsString", action="rmd:IsString")
  @RequestWrapper(localName="IsStringRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.IsStringRequest")
  @ResponseWrapper(localName="IsStringResponse", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.IsStringResponse")
  @WebResult(name="isString", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract boolean rmdIsString(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="formName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="fieldID", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int paramInt)
    throws RemedyFault;
  
  @WebMethod(operationName="DownloadAttachment", action="rmd:DownloadAttachment")
  @RequestWrapper(localName="DownloadAttachmentRequest", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.DownloadAttachmentRequest")
  @ResponseWrapper(localName="DownloadAttachmentResponse", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic", className="com.telcel.rcontrol.services.remedy.generic.DownloadAttachmentResponse")
  @WebResult(name="downloaded", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic")
  public abstract boolean rmdDownloadAttachment(@WebParam(name="integrationName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString1, @WebParam(name="formName", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString2, @WebParam(name="entryID", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") String paramString3, @WebParam(name="fieldID", targetNamespace="http://telcel.com/rcontrol/services/remedy/generic") int paramInt)
    throws RemedyFault;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\RemedyUtilsPort.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */