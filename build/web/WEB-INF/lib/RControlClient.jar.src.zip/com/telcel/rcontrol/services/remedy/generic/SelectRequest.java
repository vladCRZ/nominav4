/*     */ package com.telcel.rcontrol.services.remedy.generic;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"integrationName", "affectedForm", "qualification", "requestedFields", "orderBy"})
/*     */ @XmlRootElement(name="SelectRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */ public class SelectRequest
/*     */ {
/*     */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String integrationName;
/*     */   @XmlElement(name="affectedForm", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String affectedForm;
/*     */   @XmlElement(name="qualification", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String qualification;
/*     */   @XmlElement(name="requestedFields", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected int[] requestedFields;
/*     */   @XmlElement(name="orderBy", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected int[] orderBy;
/*     */   
/*     */   public String getIntegrationName()
/*     */   {
/*  72 */     return this.integrationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIntegrationName(String value)
/*     */   {
/*  84 */     this.integrationName = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAffectedForm()
/*     */   {
/*  96 */     return this.affectedForm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAffectedForm(String value)
/*     */   {
/* 108 */     this.affectedForm = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQualification()
/*     */   {
/* 135 */     return this.qualification;
/*     */   }
/*     */   
/*     */   public void setQualification(String qualification) {
/* 139 */     this.qualification = qualification;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getRequestedFields()
/*     */   {
/* 151 */     return this.requestedFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestedFields(int[] value)
/*     */   {
/* 163 */     this.requestedFields = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getOrderBy()
/*     */   {
/* 175 */     return this.orderBy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrderBy(int[] value)
/*     */   {
/* 187 */     this.orderBy = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\SelectRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */