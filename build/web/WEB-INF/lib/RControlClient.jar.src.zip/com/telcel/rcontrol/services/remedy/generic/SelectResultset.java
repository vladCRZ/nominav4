/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"selectedItems"})
/*    */ @XmlRootElement(name="SelectResultset", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class SelectResultset
/*    */ {
/*    */   @XmlElement(name="selectedItems", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected FormEntry selectedItems;
/*    */   
/*    */   public FormEntry getSelectedItems()
/*    */   {
/* 37 */     return this.selectedItems;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSelectedItems(FormEntry value)
/*    */   {
/* 49 */     this.selectedItems = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\SelectResultset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */