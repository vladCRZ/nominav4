/*    */ package com.telcel.rcontrol.services.remedy.generic;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import javax.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name="", propOrder={"integrationName", "ci", "requestedFields"})
/*    */ @XmlRootElement(name="SiteBelongsToRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */ public class SiteBelongsToRequest
/*    */ {
/*    */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected String integrationName;
/*    */   @XmlElement(name="ci", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected ListOfFields ci;
/*    */   @XmlElement(name="requestedFields", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*    */   protected int[] requestedFields;
/*    */   
/*    */   public String getIntegrationName()
/*    */   {
/* 27 */     return this.integrationName;
/*    */   }
/*    */   
/* 30 */   public void setIntegrationName(String value) { this.integrationName = value; }
/*    */   
/*    */   public ListOfFields getCi()
/*    */   {
/* 34 */     return this.ci;
/*    */   }
/*    */   
/* 37 */   public void setCi(ListOfFields ci) { this.ci = ci; }
/*    */   
/*    */   public int[] getRequestedFields()
/*    */   {
/* 41 */     return this.requestedFields;
/*    */   }
/*    */   
/* 44 */   public void setRequestedFields(int[] value) { this.requestedFields = value; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\SiteBelongsToRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */