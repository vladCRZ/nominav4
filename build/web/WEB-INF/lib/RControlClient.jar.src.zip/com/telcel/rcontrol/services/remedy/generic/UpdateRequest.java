/*     */ package com.telcel.rcontrol.services.remedy.generic;
/*     */ 
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name="", propOrder={"integrationName", "affectedForm", "affectedEntry", "updatedValues"})
/*     */ @XmlRootElement(name="UpdateRequest", namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */ public class UpdateRequest
/*     */ {
/*     */   @XmlElement(name="integrationName", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String integrationName;
/*     */   @XmlElement(name="affectedForm", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String affectedForm;
/*     */   @XmlElement(name="affectedEntry", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected String affectedEntry;
/*     */   @XmlElement(name="updatedValues", required=true, namespace="http://telcel.com/rcontrol/services/remedy/generic")
/*     */   protected ListOfFields updatedValues;
/*     */   
/*     */   public String getIntegrationName()
/*     */   {
/*  68 */     return this.integrationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIntegrationName(String value)
/*     */   {
/*  80 */     this.integrationName = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAffectedForm()
/*     */   {
/*  92 */     return this.affectedForm;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAffectedForm(String value)
/*     */   {
/* 104 */     this.affectedForm = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAffectedEntry()
/*     */   {
/* 112 */     return this.affectedEntry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAffectedEntry(String value)
/*     */   {
/* 120 */     this.affectedEntry = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ListOfFields getUpdatedValues()
/*     */   {
/* 132 */     return this.updatedValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUpdatedValues(ListOfFields value)
/*     */   {
/* 144 */     this.updatedValues = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\UpdateRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */