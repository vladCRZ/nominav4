/*    */ package com.telcel.rcontrol.services.remedy.generic.commons;
/*    */ 
/*    */ import com.telcel.rcontrol.ars.commons.EntryParser;
/*    */ import com.telcel.rcontrol.services.remedy.generic.Field;
/*    */ import com.telcel.rcontrol.services.remedy.generic.ListOfFields;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListOfFieldsParserHelper
/*    */   implements EntryParser<String>
/*    */ {
/* 23 */   private static final Logger log = Logger.getLogger(ListOfFieldsParserHelper.class);
/*    */   
/*    */   public static final String ATTACH_OPEN_TAG = "<FILE>";
/*    */   public static final String ATTACH_CLOSE_TAG = "</FILE>";
/*    */   
/*    */   public ListOfFields parse(String columnString)
/*    */   {
/* 30 */     ListOfFields lof = new ListOfFields();
/*    */     
/*    */ 
/*    */ 
/* 34 */     columnString = columnString.replaceAll("'='[ ]+'", "'=''");
/* 35 */     for (String column : columnString.split("'[ ]+'")) {
/* 36 */       String[] entry = column.split("'='");
/* 37 */       Field f = new Field();
/* 38 */       f.setValue(entry[1].replaceAll("'", "").trim());
/* 39 */       f.setId(Integer.parseInt(entry[0].replaceAll("'", "")));
/* 40 */       lof.addField(f);
/*    */     }
/*    */     
/* 43 */     return lof;
/*    */   }
/*    */   
/*    */   public boolean valid(String columnString) {
/*    */     try {
/* 48 */       parse(columnString);
/* 49 */       return true;
/*    */     } catch (IndexOutOfBoundsException IOOBE) {
/* 51 */       log.error(IOOBE); }
/* 52 */     return false;
/*    */   }
/*    */   
/*    */   public static final void main(String[] args)
/*    */   {
/* 57 */     new ListOfFieldsParserHelper().parse("'7'='2' '1000000218'=' '");
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\commons\ListOfFieldsParserHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */