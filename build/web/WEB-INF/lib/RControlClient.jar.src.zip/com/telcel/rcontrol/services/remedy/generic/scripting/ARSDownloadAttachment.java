/*    */ package com.telcel.rcontrol.services.remedy.generic.scripting;
/*    */ 
/*    */ import com.infomedia.utils.PropertyLoader;
/*    */ import com.infomedia.utils.StringUtils;
/*    */ import com.sun.xml.ws.fault.ServerSOAPFaultException;
/*    */ import com.telcel.rcontrol.services.remedy.generic.RMIUtilsFactory;
/*    */ import com.telcel.rcontrol.services.remedy.generic.RemedyFault;
/*    */ import com.telcel.rcontrol.services.remedy.generic.RemedyUtilsPort;
/*    */ import java.io.PrintStream;
/*    */ import java.net.MalformedURLException;
/*    */ import java.util.Properties;
/*    */ import javax.xml.soap.SOAPFault;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARSDownloadAttachment
/*    */ {
/*    */   public static void showHelp()
/*    */   {
/* 28 */     System.out.println("NMB: " + ARSDownloadAttachment.class.getName());
/* 29 */     System.out.println("DSC: Componente para descarga de adjunto en remedy");
/* 30 */     System.out.println("EJM: java " + ARSDownloadAttachment.class.getName() + " SISTEMA formulario entry field");
/* 31 */     System.out.println("PRM: OBLIGATORIO Sistema ID del sistema que esta accesando");
/* 32 */     System.out.println("PRM: OBLIGATORIO Forma Nombre del formulario");
/* 33 */     System.out.println("PRM: OBLIGATORIO Entry ID del registro en Remedy");
/* 34 */     System.out.println("PRM: OBLIGATORIO Field ID del adjunto en Remedy");
/* 35 */     System.out.println("VRS: 2.0 ");
/* 36 */     System.out.println("PRG: REV@Softcoatl");
/* 37 */     System.out.println("FCH: 17/07/2015-17/07/2015");
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws MalformedURLException {
/* 41 */     Properties prop = PropertyLoader.load("rcontrol.properties");
/* 42 */     RemedyUtilsPort utilsPort = RMIUtilsFactory.getUtilsPort(prop.getProperty("RControl.webservices.endpoint.util"));
/*    */     
/* 44 */     String integration = "";
/* 45 */     String form = "";
/* 46 */     String id = "";
/* 47 */     String field = "";
/*    */     
/* 49 */     System.out.println(ARSDownloadAttachment.class.getSimpleName());
/*    */     
/* 51 */     if ((null == args) || (args.length == 0)) {
/* 52 */       showHelp();
/* 53 */       return;
/*    */     }
/*    */     
/* 56 */     if (args.length > 0) {
/* 57 */       integration = args[0].trim();
/*    */     }
/* 59 */     if (args.length > 1) {
/* 60 */       form = args[1];
/*    */     }
/* 62 */     if (args.length > 2) {
/* 63 */       id = args[2];
/*    */     }
/* 65 */     if (args.length > 3) {
/* 66 */       field = args[3];
/*    */     }
/*    */     
/* 69 */     if ((StringUtils.isNVL(integration)) || (StringUtils.isNVL(form)) || (StringUtils.isNVL(id)) || (StringUtils.isNVL(field)))
/*    */     {
/*    */ 
/*    */ 
/* 73 */       showHelp();
/* 74 */       return;
/*    */     }
/*    */     try
/*    */     {
/* 78 */       if (utilsPort.rmdDownloadAttachment(integration, form, id, Integer.parseInt(field))) {
/* 79 */         System.out.println(field + " OK");
/*    */       } else {
/* 81 */         System.out.println("ARCHIVO NO DESCARGADO");
/*    */       }
/*    */     }
/*    */     catch (RemedyFault RF) {
/* 85 */       System.out.println(RF.getErrorMessage());
/*    */     }
/*    */     catch (ServerSOAPFaultException SSFE) {
/* 88 */       System.out.println(SSFE.getFault().getFaultString());
/*    */     }
/*    */     catch (Exception EX) {
/* 91 */       if ((EX instanceof RemedyFault)) {
/* 92 */         System.out.println(((RemedyFault)EX).getErrorMessage());
/*    */       } else {
/* 94 */         System.out.println(EX.getClass().getName() + ": " + EX.getMessage());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\scripting\ARSDownloadAttachment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */