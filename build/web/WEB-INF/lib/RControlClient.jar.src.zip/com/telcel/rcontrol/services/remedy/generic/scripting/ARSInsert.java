/*     */ package com.telcel.rcontrol.services.remedy.generic.scripting;
/*     */ 
/*     */ import com.infomedia.utils.PropertyLoader;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.sun.xml.ws.fault.ServerSOAPFaultException;
/*     */ import com.telcel.rcontrol.ars.commons.WhereClauseAdapter;
/*     */ import com.telcel.rcontrol.services.remedy.generic.InsertStatus;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RMIClientFactory;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyFault;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyPort;
/*     */ import com.telcel.rcontrol.services.remedy.generic.commons.ListOfFieldsParserHelper;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Properties;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARSInsert
/*     */ {
/*  31 */   private static final Logger log = Logger.getLogger(ARSInsert.class);
/*     */   public static final String soapInsert = "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body><ns2:InsertRequest xmlns:ns2=\"http://telcel.com/rcontrol/services/remedy/generic\" xmlns:ns3=\"http://telcel.com/rcontrol/services/remedy/generic/\" xmlns:ns4=\"http://generic.remedy.services.rcontrol.telcel.com/\"><ns2:integrationName>$SYS</ns2:integrationName><ns2:affectedForm>$FORM</ns2:affectedForm><ns2:insertedValues>$INSERTED</ns2:insertedValues><ns2:qualification>$QUALIFICATION</ns2:qualification></ns2:InsertRequest></S:Body></S:Envelope>";
/*     */   
/*     */   public static void showHelp()
/*     */   {
/*  36 */     System.out.println("NMB: " + ARSInsert.class.getName());
/*  37 */     System.out.println("DSC: Componente para creación de registros en Remedy");
/*  38 */     System.out.println("EJM: java " + ARSInsert.class.getName() + " \"SISTEMA\" \"formulario\" \"valores\" \"condiciones\"");
/*  39 */     System.out.println("EJM: java " + ARSInsert.class.getName() + " \"SISTEMA\" \"formulario\" \"valores\" \"condiciones\"");
/*  40 */     System.out.println("PRM: OBLIGATORIO Sistema ID del sistema que esta accesando");
/*  41 */     System.out.println("PRM: OBLIGATORIO Forma Nombre del formulario");
/*  42 */     System.out.println("PRM: OBLIGATORIO Columnas del registro que se creará 'columna1'='valor1' 'columna2'='valor2'");
/*  43 */     System.out.println("PRM: OPCIONAL    Condiciones para verificar el registro, formato: 'columna1'='valor1' 'columna2'<>'valor2'");
/*  44 */     System.out.println("VRS: 2.0 ");
/*  45 */     System.out.println("PRG: REV@Softcoatl");
/*  46 */     System.out.println("FCH: 03/03/2015-16/04/2015");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws MalformedURLException
/*     */   {
/*  51 */     Properties prop = PropertyLoader.load("rcontrol.properties");
/*  52 */     RemedyPort wsPort = RMIClientFactory.getRemedyPort(prop.getProperty("RControl.webservices.endpoint.crud"));
/*  53 */     ListOfFieldsParserHelper parserHelper = new ListOfFieldsParserHelper();
/*  54 */     String integration = "";
/*  55 */     String form = "";
/*  56 */     String fields = "";
/*  57 */     String qualificator = "";
/*     */     
/*  59 */     System.out.print(ARSInsert.class.getSimpleName() + " ");
/*     */     
/*  61 */     if ((null == args) || (args.length == 0)) {
/*  62 */       showHelp();
/*  63 */       return;
/*     */     }
/*     */     
/*  66 */     if (args.length > 0) {
/*  67 */       integration = args[0].trim();
/*     */     }
/*     */     
/*  70 */     if (args.length > 1) {
/*  71 */       form = args[1];
/*     */     }
/*     */     
/*  74 */     if (args.length > 2) {
/*  75 */       fields = args[2];
/*     */     }
/*     */     
/*  78 */     if (args.length > 3) {
/*  79 */       qualificator = args[3];
/*     */     }
/*     */     
/*  82 */     if ((StringUtils.isNVL(integration)) || (StringUtils.isNVL(form)) || (StringUtils.isNVL(fields)))
/*     */     {
/*     */ 
/*  85 */       showHelp();
/*  86 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  90 */       if (!parserHelper.valid(fields)) {
/*  91 */         showHelp();
/*  92 */         throw new Exception("Error de parámetros. Parámetro 3 (\"" + fields + "\").\n Se espera una cadena del tipo 'columna1'='valor1' 'columna2'='valor2' ... 'columnaN'='valorN'");
/*     */       }
/*  94 */       InsertStatus is = wsPort.rmdInsert(integration, form, new ListOfFieldsParserHelper().parse(fields), new WhereClauseAdapter().parseWhereClause(qualificator));
/*  95 */       if (is.getStatus().contains("CREATED")) {
/*  96 */         System.out.println("NVO:" + is.getCreatedEntry());
/*  97 */       } else if (is.getStatus().contains("EXISTS")) {
/*  98 */         System.out.print("REG:" + is.getCreatedEntry());
/*     */       } else {
/* 100 */         System.out.println(is.getStatus());
/*     */       }
/*     */     }
/*     */     catch (RemedyFault RF) {
/* 104 */       log.error("RF", RF);
/* 105 */       System.out.println(RF.getErrorMessage());
/*     */     } catch (ServerSOAPFaultException SSFE) {
/* 107 */       log.error("SSFE", SSFE);
/* 108 */       System.out.println(SSFE.getFault().getFaultString());
/*     */     } catch (Exception EX) {
/* 110 */       log.error("EX", EX);
/* 111 */       if ((EX instanceof RemedyFault)) {
/* 112 */         System.out.println(((RemedyFault)EX).getErrorMessage());
/*     */       } else {
/* 114 */         System.out.println(EX.getClass().getName() + ": " + EX.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\scripting\ARSInsert.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */