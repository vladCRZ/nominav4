/*     */ package com.telcel.rcontrol.services.remedy.generic.scripting;
/*     */ 
/*     */ import com.infomedia.utils.PropertyLoader;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.sun.xml.ws.fault.ServerSOAPFaultException;
/*     */ import com.telcel.rcontrol.ars.commons.RequestedFieldsAdapter;
/*     */ import com.telcel.rcontrol.ars.commons.WhereClauseAdapter;
/*     */ import com.telcel.rcontrol.services.remedy.generic.Field;
/*     */ import com.telcel.rcontrol.services.remedy.generic.FormEntry;
/*     */ import com.telcel.rcontrol.services.remedy.generic.ListOfFields;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RMIClientFactory;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RMIUtilsFactory;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyFault;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyPort;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyUtilsPort;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARSSelect
/*     */ {
/*     */   public static void showHelp()
/*     */   {
/*  36 */     System.out.println("NMB: " + ARSSelect.class.getName());
/*  37 */     System.out.println("DSC: Componente para consulta de registros en remedy");
/*  38 */     System.out.println("EJM: java " + ARSSelect.class.getName() + " SISTEMA formulario columnas condiciones orden separador delimitador");
/*  39 */     System.out.println("EJM: java " + ARSSelect.class.getName() + " SISTEMA formulario columnas condiciones");
/*  40 */     System.out.println("PRM: OBLIGATORIO Sistema ID del sistema que esta accesando");
/*  41 */     System.out.println("PRM: OBLIGATORIO Forma Nombre del formulario");
/*  42 */     System.out.println("PRM: OBLIGATORIO Columnas Columnas del formulario a recuperar, separadas por espacios, formato: 'columna1 columna2 columna3'");
/*  43 */     System.out.println("PRM: OBLIGATORIO Condiciones Condiciones para verificar el registro, formato: 'columna1'='valor1' 'columna2'<>'columna2'");
/*  44 */     System.out.println("PRM: OBLIGATORIO Orden Columnas de ordenamiento: 'columna1 columna2'");
/*  45 */     System.out.println("VRS: 2.0 ");
/*  46 */     System.out.println("PRG: REV@Softcoatl");
/*  47 */     System.out.println("FCH: 03/03/2015-03/03/2015");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws MalformedURLException {
/*  51 */     Properties prop = PropertyLoader.load("rcontrol.properties");
/*  52 */     RemedyPort wsPort = RMIClientFactory.getRemedyPort(prop.getProperty("RControl.webservices.endpoint.crud"));
/*  53 */     RemedyUtilsPort wsUtil = RMIUtilsFactory.getUtilsPort(prop.getProperty("RControl.webservices.endpoint.util"));
/*     */     
/*     */ 
/*  56 */     String integration = "";
/*  57 */     String form = "";
/*  58 */     String fields = "";
/*  59 */     String qualificator = "";
/*  60 */     String order = "";
/*  61 */     String separator = ",";
/*  62 */     String delimiter = ",";
/*  63 */     boolean showID = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  68 */     List<Integer> requestedList = new ArrayList();
/*     */     
/*  70 */     System.out.println(ARSSelect.class.getSimpleName());
/*     */     
/*  72 */     if ((null == args) || (args.length == 0)) {
/*  73 */       showHelp();
/*  74 */       return;
/*     */     }
/*     */     
/*  77 */     if (args.length > 0) {
/*  78 */       integration = args[0].trim();
/*     */     }
/*  80 */     if (args.length > 1) {
/*  81 */       form = args[1];
/*     */     }
/*  83 */     if (args.length > 2) {
/*  84 */       fields = args[2];
/*     */     }
/*  86 */     if (args.length > 3) {
/*  87 */       qualificator = args[3];
/*     */     }
/*  89 */     if ((args.length > 4) && (!StringUtils.isNVL(args[4]))) {
/*  90 */       order = args[4];
/*     */     }
/*  92 */     if ((args.length > 5) && (!StringUtils.isNVL(args[5]))) {
/*  93 */       separator = args[5];
/*     */     }
/*  95 */     if ((args.length > 6) && (!StringUtils.isNVL(args[6]))) {
/*  96 */       delimiter = args[6];
/*     */     }
/*  98 */     if ((args.length > 7) && (!StringUtils.isNVL(args[7]))) {
/*  99 */       showID = "S".equals(args[7].trim());
/*     */     }
/*     */     
/* 102 */     if ((StringUtils.isNVL(integration)) || (StringUtils.isNVL(form)) || (StringUtils.isNVL(fields)) || (StringUtils.isNVL(qualificator)))
/*     */     {
/*     */ 
/*     */ 
/* 106 */       showHelp();
/* 107 */       return;
/*     */     }
/*     */     
/* 110 */     int[] requested = new RequestedFieldsAdapter().parse(fields);
/* 111 */     for (int index = 0; index < requested.length; index++) {
/* 112 */       requestedList.add(Integer.valueOf(requested[index]));
/*     */     }
/*     */     try
/*     */     {
/* 116 */       List<ListOfFields> matches = wsPort.rmdSelect(integration, form, new WhereClauseAdapter().parseWhereClause(qualificator), requested, new RequestedFieldsAdapter().parse(order)).getEntry();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */       System.out.print("[");
/* 123 */       int iMatches = 1;
/* 124 */       for (ListOfFields lof : matches) {
/* 125 */         System.out.print("[");
/* 126 */         int iFields = 1;
/* 127 */         for (Iterator i$ = requestedList.iterator(); i$.hasNext();) { id = ((Integer)i$.next()).intValue();
/* 128 */           for (Field f : lof.getField())
/* 129 */             if (id == f.getId()) {
/* 130 */               if (showID) System.out.print(id + "=");
/* 131 */               System.out.print(f.getValue());
/* 132 */               if (iFields++ < requestedList.size()) System.out.print(separator);
/*     */             }
/*     */         }
/*     */         int id;
/* 136 */         System.out.print("]");
/* 137 */         if (iMatches++ < matches.size()) System.out.print(delimiter);
/*     */       }
/* 139 */       System.out.print("]");
/*     */     }
/*     */     catch (RemedyFault RF) {
/* 142 */       System.out.println(RF.getErrorMessage());
/*     */     }
/*     */     catch (ServerSOAPFaultException SSFE) {
/* 145 */       System.out.println(SSFE.getFault().getFaultString());
/*     */     }
/*     */     catch (Exception EX) {
/* 148 */       if ((EX instanceof RemedyFault)) {
/* 149 */         System.out.println(((RemedyFault)EX).getErrorMessage());
/*     */       } else {
/* 151 */         System.out.println(EX.getClass().getName() + ": " + EX.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\scripting\ARSSelect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */