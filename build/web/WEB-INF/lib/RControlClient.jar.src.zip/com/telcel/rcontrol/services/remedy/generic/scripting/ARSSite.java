/*     */ package com.telcel.rcontrol.services.remedy.generic.scripting;
/*     */ 
/*     */ import com.infomedia.utils.PropertyLoader;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.sun.xml.ws.fault.ServerSOAPFaultException;
/*     */ import com.telcel.rcontrol.services.remedy.generic.FormEntry;
/*     */ import com.telcel.rcontrol.services.remedy.generic.ListOfFields;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RMIClientFactory;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyFault;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyPort;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARSSite
/*     */ {
/*  32 */   private static final Logger log = Logger.getLogger(ARSSite.class);
/*     */   
/*     */   public static void showHelp() {
/*  35 */     System.out.println("NMB: " + ARSSelect.class.getName());
/*  36 */     System.out.println("DSC: Componente para consulta de registros en remedy");
/*  37 */     System.out.println("EJM: java " + ARSSelect.class.getName() + " SISTEMA formulario columnas condiciones orden separador delimitador");
/*  38 */     System.out.println("EJM: java " + ARSSelect.class.getName() + " SISTEMA formulario columnas condiciones");
/*  39 */     System.out.println("PRM: OBLIGATORIO Sistema ID del sistema que esta accesando");
/*  40 */     System.out.println("PRM: OBLIGATORIO CI Nemonico del Elemento");
/*  41 */     System.out.println("VRS: 2.0 ");
/*  42 */     System.out.println("PRG: REV@Softcoatl");
/*  43 */     System.out.println("FCH: 03/03/2015-03/03/2015");
/*     */   }
/*     */   
/*     */   public void count() {
/*  47 */     Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
/*  48 */     for (Thread thread : threadSet) {
/*  49 */       System.out.println(thread.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   public String getSoapSite(String integration, String cis) throws MalformedURLException {
/*  54 */     Properties prop = PropertyLoader.load("rcontrol.properties");
/*  55 */     RemedyPort wsPort = RMIClientFactory.getRemedyPort(prop.getProperty("RControl.webservices.endpoint.crud"));
/*  56 */     StringBuilder response = new StringBuilder();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */     int[] requested = { 536870925, 8, 536870914, 730000001, 536870974, 536870989, 536871003, 7 };
/*  63 */     int[] order = { 536870925 };
/*     */     
/*  65 */     int iMatches = 1;
/*     */     try
/*     */     {
/*     */       List<ListOfFields> matches;
/*  69 */       for (String ci : cis.split(",")) {
/*  70 */         matches = wsPort.rmdSelect(integration, "Site-EP", "'536870925'=\"" + ci + "\"", requested, order).getEntry();
/*  71 */         if (0 == matches.size()) {
/*  72 */           System.out.println("no rows selected");
/*     */         }
/*  74 */         for (ListOfFields lof : matches) {
/*  75 */           int status = Integer.valueOf(lof.getValue(7)).intValue();
/*  76 */           String decoded; switch (status) {
/*  77 */           case 0:  decoded = "SITIO NUEVO"; break;
/*  78 */           case 1:  decoded = "INTEGRADO POR EL PROVEEDOR"; break;
/*  79 */           case 2:  decoded = "PROTOCOLO APLICADO"; break;
/*  80 */           case 3:  decoded = "INTEGRADO POR CALIDAD"; break;
/*  81 */           case 4:  decoded = "OPRERANDO"; break;
/*  82 */           case 5:  decoded = "NO OPERANDO"; break;
/*  83 */           case 6:  decoded = "DESINSTALADO"; break;
/*  84 */           default:  decoded = "";
/*     */           }
/*  86 */           System.out.print("SITE:" + lof.getValue(536870925) + " ");
/*  87 */           System.out.print("NOMBRE:" + lof.getValue(8) + " ");
/*  88 */           System.out.print("REGION:" + lof.getValue(536870914) + " ");
/*  89 */           System.out.print("TECNOLOGIA:" + lof.getValue(730000001) + " ");
/*  90 */           System.out.print("TIPO:" + lof.getValue(536870974) + " ");
/*  91 */           System.out.print("BELONGSTO:" + lof.getValue(536870989) + " ");
/*  92 */           System.out.print("RESPONSABLEGROUP:" + lof.getValue(536871003) + " ");
/*  93 */           System.out.print("ESTATUS:" + lof.getValue(7) + " " + decoded + " ");
/*     */           
/*  95 */           if (iMatches++ < matches.size()) {
/*  96 */             System.out.println("|");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RemedyFault RF) {
/* 102 */       System.out.println(RF.getErrorMessage());
/*     */     }
/*     */     catch (ServerSOAPFaultException SSFE) {
/* 105 */       System.out.println(SSFE.getFault().getFaultString());
/*     */     }
/*     */     catch (Exception EX) {
/* 108 */       if ((EX instanceof RemedyFault)) {
/* 109 */         System.out.println(((RemedyFault)EX).getErrorMessage());
/*     */       } else {
/* 111 */         System.out.println(EX.getMessage());
/*     */       }
/*     */     }
/* 114 */     return response.toString();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws MalformedURLException {
/* 118 */     String integration = "";
/* 119 */     String cis = "";
/*     */     
/* 121 */     if ((null == args) || (args.length == 0)) {
/* 122 */       showHelp();
/* 123 */       return;
/*     */     }
/*     */     
/* 126 */     if (args.length > 0) {
/* 127 */       integration = args[0].trim();
/*     */     }
/* 129 */     if (args.length > 1) {
/* 130 */       cis = args[1];
/*     */     }
/*     */     
/* 133 */     if ((StringUtils.isNVL(integration)) || (StringUtils.isNVL(cis)))
/*     */     {
/* 135 */       showHelp();
/* 136 */       return;
/*     */     }
/*     */     
/* 139 */     System.out.println(new ARSSite().getSoapSite(integration, cis));
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\scripting\ARSSite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */