/*     */ package com.telcel.rcontrol.services.remedy.generic.scripting;
/*     */ 
/*     */ import com.infomedia.utils.PropertyLoader;
/*     */ import com.infomedia.utils.StringUtils;
/*     */ import com.sun.xml.ws.fault.ServerSOAPFaultException;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RMIClientFactory;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyFault;
/*     */ import com.telcel.rcontrol.services.remedy.generic.RemedyPort;
/*     */ import com.telcel.rcontrol.services.remedy.generic.UpdateStatus;
/*     */ import com.telcel.rcontrol.services.remedy.generic.commons.ListOfFieldsParserHelper;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Properties;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ARSUpdate
/*     */ {
/*     */   public static void showHelp()
/*     */   {
/*  30 */     System.out.println("NMB: " + ARSUpdate.class.getName());
/*  31 */     System.out.println("DSC: Componente para actualización de registros en remedy");
/*  32 */     System.out.println("EJM: java " + ARSUpdate.class.getName() + " SISTEMA formulario columnas condiciones orden separador delimitador");
/*  33 */     System.out.println("EJM: java " + ARSUpdate.class.getName() + " SISTEMA formulario columnas condiciones");
/*  34 */     System.out.println("PRM: OBLIGATORIO Sistema ID del sistema que esta accesando");
/*  35 */     System.out.println("PRM: OBLIGATORIO Forma Nombre del formulario");
/*  36 */     System.out.println("PRM: OBLIGATORIO Columnas Columnas del formulario a recuperar, separadas por espacios, formato: 'columna1 columna2 columna3'");
/*  37 */     System.out.println("PRM: Condiciones Condiciones para verificar el registro, formato: 'columna1'='valor1' 'columna2'<>'columna2'");
/*  38 */     System.out.println("VRS: 2.0 ");
/*  39 */     System.out.println("PRG: REV@Softcoatl");
/*  40 */     System.out.println("FCH: 03/03/2015-03/03/2015");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws MalformedURLException {
/*  44 */     Properties prop = PropertyLoader.load("rcontrol.properties");
/*  45 */     RemedyPort wsPort = RMIClientFactory.getRemedyPort(prop.getProperty("RControl.webservices.endpoint.crud"));
/*     */     
/*  47 */     String integration = "";
/*  48 */     String form = "";
/*  49 */     String ids = "";
/*  50 */     String fields = "";
/*     */     
/*  52 */     System.out.println(ARSUpdate.class.getSimpleName());
/*     */     
/*  54 */     if ((null == args) || (args.length == 0)) {
/*  55 */       showHelp();
/*  56 */       return;
/*     */     }
/*     */     
/*  59 */     if (args.length > 0) {
/*  60 */       integration = args[0].trim();
/*     */     }
/*  62 */     if (args.length > 1) {
/*  63 */       form = args[1];
/*     */     }
/*  65 */     if (args.length > 2) {
/*  66 */       ids = args[2];
/*     */     }
/*  68 */     if (args.length > 3) {
/*  69 */       fields = args[3];
/*     */     }
/*     */     
/*  72 */     if ((StringUtils.isNVL(integration)) || (StringUtils.isNVL(form)) || (StringUtils.isNVL(ids)) || (StringUtils.isNVL(fields)))
/*     */     {
/*     */ 
/*     */ 
/*  76 */       showHelp();
/*  77 */       return;
/*     */     }
/*     */     
/*  80 */     for (String id : ids.split(",")) {
/*     */       try {
/*  82 */         for (String updates : fields.split("[|]{2}")) {
/*  83 */           UpdateStatus us = wsPort.rmdUpdate(integration, form, id.trim(), new ListOfFieldsParserHelper().parse(updates.trim()));
/*  84 */           if (us.getStatus().contains("UPDATED")) {
/*  85 */             System.out.println(id + " OK");
/*     */           } else {
/*  87 */             System.out.println(id + " " + us.getStatus());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (RemedyFault RF) {
/*  92 */         System.out.println(RF.getErrorMessage());
/*     */       }
/*     */       catch (ServerSOAPFaultException SSFE) {
/*  95 */         System.out.println(SSFE.getFault().getFaultString());
/*     */       }
/*     */       catch (Exception EX) {
/*  98 */         if ((EX instanceof RemedyFault)) {
/*  99 */           System.out.println(((RemedyFault)EX).getErrorMessage());
/*     */         } else {
/* 101 */           System.out.println(EX.getClass().getName() + ": " + EX.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\RControlClient.jar!\com\telcel\rcontrol\services\remedy\generic\scripting\ARSUpdate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */