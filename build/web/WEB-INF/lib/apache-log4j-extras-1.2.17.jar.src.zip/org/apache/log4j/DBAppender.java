/*     */ package org.apache.log4j;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.receivers.db.ConnectionSource;
/*     */ import org.apache.log4j.receivers.db.DBHelper;
/*     */ import org.apache.log4j.receivers.db.dialect.SQLDialect;
/*     */ import org.apache.log4j.receivers.db.dialect.Util;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DBAppender
/*     */   extends AppenderSkeleton
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*     */   static final String insertPropertiesSQL = "INSERT INTO  logging_event_property (event_id, mapped_key, mapped_value) VALUES (?, ?, ?)";
/*     */   static final String insertExceptionSQL = "INSERT INTO  logging_event_exception (event_id, i, trace_line) VALUES (?, ?, ?)";
/*     */   static final String insertSQL;
/*     */   private static final Method GET_GENERATED_KEYS_METHOD;
/*     */   ConnectionSource connectionSource;
/*     */   
/*     */   static
/*     */   {
/* 130 */     StringBuffer sql = new StringBuffer();
/* 131 */     sql.append("INSERT INTO logging_event (");
/* 132 */     sql.append("sequence_number, ");
/* 133 */     sql.append("timestamp, ");
/* 134 */     sql.append("rendered_message, ");
/* 135 */     sql.append("logger_name, ");
/* 136 */     sql.append("level_string, ");
/* 137 */     sql.append("ndc, ");
/* 138 */     sql.append("thread_name, ");
/* 139 */     sql.append("reference_flag, ");
/* 140 */     sql.append("caller_filename, ");
/* 141 */     sql.append("caller_class, ");
/* 142 */     sql.append("caller_method, ");
/* 143 */     sql.append("caller_line) ");
/* 144 */     sql.append(" VALUES (?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?, ?)");
/* 145 */     insertSQL = sql.toString();
/*     */     
/*     */     Method getGeneratedKeysMethod;
/*     */     
/*     */     try
/*     */     {
/* 151 */       getGeneratedKeysMethod = PreparedStatement.class.getMethod("getGeneratedKeys", null);
/*     */     } catch (Exception ex) {
/* 153 */       getGeneratedKeysMethod = null;
/*     */     }
/* 155 */     GET_GENERATED_KEYS_METHOD = getGeneratedKeysMethod;
/*     */   }
/*     */   
/*     */ 
/* 159 */   boolean cnxSupportsGetGeneratedKeys = false;
/* 160 */   boolean cnxSupportsBatchUpdates = false;
/*     */   SQLDialect sqlDialect;
/* 162 */   boolean locationInfo = false;
/*     */   
/*     */   public DBAppender()
/*     */   {
/* 166 */     super(false);
/*     */   }
/*     */   
/*     */   public void activateOptions() {
/* 170 */     LogLog.debug("DBAppender.activateOptions called");
/*     */     
/* 172 */     if (this.connectionSource == null) {
/* 173 */       throw new IllegalStateException("DBAppender cannot function without a connection source");
/*     */     }
/*     */     
/*     */ 
/* 177 */     this.sqlDialect = Util.getDialectFromCode(this.connectionSource.getSQLDialectCode());
/* 178 */     if (GET_GENERATED_KEYS_METHOD != null) {
/* 179 */       this.cnxSupportsGetGeneratedKeys = this.connectionSource.supportsGetGeneratedKeys();
/*     */     } else {
/* 181 */       this.cnxSupportsGetGeneratedKeys = false;
/*     */     }
/* 183 */     this.cnxSupportsBatchUpdates = this.connectionSource.supportsBatchUpdates();
/* 184 */     if ((!this.cnxSupportsGetGeneratedKeys) && (this.sqlDialect == null)) {
/* 185 */       throw new IllegalStateException("DBAppender cannot function if the JDBC driver does not support getGeneratedKeys method *and* without a specific SQL dialect");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 190 */     super.activateOptions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ConnectionSource getConnectionSource()
/*     */   {
/* 197 */     return this.connectionSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionSource(ConnectionSource connectionSource)
/*     */   {
/* 205 */     LogLog.debug("setConnectionSource called for DBAppender");
/* 206 */     this.connectionSource = connectionSource;
/*     */   }
/*     */   
/*     */   protected void append(LoggingEvent event) {
/* 210 */     Connection connection = null;
/*     */     try {
/* 212 */       connection = this.connectionSource.getConnection();
/* 213 */       connection.setAutoCommit(false);
/*     */       PreparedStatement insertStatement;
/*     */       PreparedStatement insertStatement;
/* 216 */       if (this.cnxSupportsGetGeneratedKeys) {
/* 217 */         insertStatement = connection.prepareStatement(insertSQL, 1);
/*     */       } else {
/* 219 */         insertStatement = connection.prepareStatement(insertSQL);
/*     */       }
/*     */       
/*     */ 
/* 223 */       insertStatement.setLong(1, 0L);
/*     */       
/* 225 */       insertStatement.setLong(2, event.getTimeStamp());
/* 226 */       insertStatement.setString(3, event.getRenderedMessage());
/* 227 */       insertStatement.setString(4, event.getLoggerName());
/* 228 */       insertStatement.setString(5, event.getLevel().toString());
/* 229 */       insertStatement.setString(6, event.getNDC());
/* 230 */       insertStatement.setString(7, event.getThreadName());
/* 231 */       insertStatement.setShort(8, DBHelper.computeReferenceMask(event));
/*     */       
/*     */       LocationInfo li;
/*     */       LocationInfo li;
/* 235 */       if ((event.locationInformationExists()) || (this.locationInfo)) {
/* 236 */         li = event.getLocationInformation();
/*     */       } else {
/* 238 */         li = LocationInfo.NA_LOCATION_INFO;
/*     */       }
/*     */       
/* 241 */       insertStatement.setString(9, li.getFileName());
/* 242 */       insertStatement.setString(10, li.getClassName());
/* 243 */       insertStatement.setString(11, li.getMethodName());
/* 244 */       insertStatement.setString(12, li.getLineNumber());
/*     */       
/* 246 */       int updateCount = insertStatement.executeUpdate();
/* 247 */       if (updateCount != 1) {
/* 248 */         LogLog.warn("Failed to insert loggingEvent");
/*     */       }
/*     */       
/* 251 */       ResultSet rs = null;
/* 252 */       Statement idStatement = null;
/* 253 */       boolean gotGeneratedKeys = false;
/* 254 */       if (this.cnxSupportsGetGeneratedKeys) {
/*     */         try {
/* 256 */           rs = (ResultSet)GET_GENERATED_KEYS_METHOD.invoke(insertStatement, null);
/* 257 */           gotGeneratedKeys = true;
/*     */         } catch (InvocationTargetException ex) {
/* 259 */           Throwable target = ex.getTargetException();
/* 260 */           if ((target instanceof SQLException)) {
/* 261 */             throw ((SQLException)target);
/*     */           }
/* 263 */           throw ex;
/*     */         } catch (IllegalAccessException ex) {
/* 265 */           LogLog.warn("IllegalAccessException invoking PreparedStatement.getGeneratedKeys", ex);
/*     */         }
/*     */       }
/*     */       
/* 269 */       if (!gotGeneratedKeys) {
/* 270 */         insertStatement.close();
/* 271 */         insertStatement = null;
/*     */         
/* 273 */         idStatement = connection.createStatement();
/* 274 */         idStatement.setMaxRows(1);
/* 275 */         rs = idStatement.executeQuery(this.sqlDialect.getSelectInsertId());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 280 */       rs.next();
/* 281 */       int eventId = rs.getInt(1);
/*     */       
/* 283 */       rs.close();
/*     */       
/*     */ 
/* 286 */       if (insertStatement != null) {
/* 287 */         insertStatement.close();
/* 288 */         insertStatement = null;
/*     */       }
/*     */       
/* 291 */       if (idStatement != null) {
/* 292 */         idStatement.close();
/* 293 */         idStatement = null;
/*     */       }
/*     */       
/* 296 */       Set propertiesKeys = event.getPropertyKeySet();
/*     */       
/* 298 */       if (propertiesKeys.size() > 0) {
/* 299 */         PreparedStatement insertPropertiesStatement = connection.prepareStatement("INSERT INTO  logging_event_property (event_id, mapped_key, mapped_value) VALUES (?, ?, ?)");
/*     */         
/*     */ 
/* 302 */         for (Iterator i = propertiesKeys.iterator(); i.hasNext();) {
/* 303 */           String key = (String)i.next();
/* 304 */           String value = event.getProperty(key);
/*     */           
/*     */ 
/* 307 */           insertPropertiesStatement.setInt(1, eventId);
/* 308 */           insertPropertiesStatement.setString(2, key);
/* 309 */           insertPropertiesStatement.setString(3, value);
/*     */           
/* 311 */           if (this.cnxSupportsBatchUpdates) {
/* 312 */             insertPropertiesStatement.addBatch();
/*     */           } else {
/* 314 */             insertPropertiesStatement.execute();
/*     */           }
/*     */         }
/*     */         
/* 318 */         if (this.cnxSupportsBatchUpdates) {
/* 319 */           insertPropertiesStatement.executeBatch();
/*     */         }
/*     */         
/* 322 */         insertPropertiesStatement.close();
/* 323 */         insertPropertiesStatement = null;
/*     */       }
/*     */       
/* 326 */       String[] strRep = event.getThrowableStrRep();
/*     */       
/* 328 */       if (strRep != null) {
/* 329 */         LogLog.debug("Logging an exception");
/*     */         
/* 331 */         PreparedStatement insertExceptionStatement = connection.prepareStatement("INSERT INTO  logging_event_exception (event_id, i, trace_line) VALUES (?, ?, ?)");
/*     */         
/*     */ 
/* 334 */         for (short i = 0; i < strRep.length; i = (short)(i + 1)) {
/* 335 */           insertExceptionStatement.setInt(1, eventId);
/* 336 */           insertExceptionStatement.setShort(2, i);
/* 337 */           insertExceptionStatement.setString(3, strRep[i]);
/* 338 */           if (this.cnxSupportsBatchUpdates) {
/* 339 */             insertExceptionStatement.addBatch();
/*     */           } else {
/* 341 */             insertExceptionStatement.execute();
/*     */           }
/*     */         }
/* 344 */         if (this.cnxSupportsBatchUpdates) {
/* 345 */           insertExceptionStatement.executeBatch();
/*     */         }
/* 347 */         insertExceptionStatement.close();
/* 348 */         insertExceptionStatement = null;
/*     */       }
/*     */       
/* 351 */       connection.commit();
/*     */     } catch (Throwable sqle) {
/* 353 */       LogLog.error("problem appending event", sqle);
/*     */     } finally {
/* 355 */       DBHelper.closeConnection(connection);
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() {
/* 360 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getLocationInfo()
/*     */   {
/* 368 */     return this.locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocationInfo(boolean locationInfo)
/*     */   {
/* 377 */     this.locationInfo = locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean requiresLayout()
/*     */   {
/* 385 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 392 */     if ("connectionSource".equals(element.getNodeName())) {
/* 393 */       Object instance = DOMConfigurator.parseElement(element, props, ConnectionSource.class);
/*     */       
/* 395 */       if ((instance instanceof ConnectionSource)) {
/* 396 */         ConnectionSource source = (ConnectionSource)instance;
/* 397 */         source.activateOptions();
/* 398 */         setConnectionSource(source);
/*     */       }
/* 400 */       return true;
/*     */     }
/* 402 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\DBAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */