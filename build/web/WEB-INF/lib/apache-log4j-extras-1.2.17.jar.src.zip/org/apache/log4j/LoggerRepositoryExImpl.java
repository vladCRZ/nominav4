/*     */ package org.apache.log4j;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.component.plugins.Plugin;
/*     */ import org.apache.log4j.component.plugins.PluginRegistry;
/*     */ import org.apache.log4j.component.scheduler.Scheduler;
/*     */ import org.apache.log4j.component.spi.ErrorItem;
/*     */ import org.apache.log4j.component.spi.LoggerEventListener;
/*     */ import org.apache.log4j.component.spi.LoggerRepositoryEventListener;
/*     */ import org.apache.log4j.component.spi.LoggerRepositoryEx;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.or.ObjectRenderer;
/*     */ import org.apache.log4j.or.RendererMap;
/*     */ import org.apache.log4j.spi.HierarchyEventListener;
/*     */ import org.apache.log4j.spi.LoggerFactory;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ import org.apache.log4j.spi.RendererSupport;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LoggerRepositoryExImpl
/*     */   implements LoggerRepositoryEx, RendererSupport, UnrecognizedElementHandler
/*     */ {
/*     */   private final LoggerRepository repo;
/*     */   private LoggerFactory loggerFactory;
/*     */   private final RendererSupport rendererSupport;
/*  77 */   private final ArrayList repositoryEventListeners = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*  81 */   private final Map loggerEventListeners = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */ 
/*     */   private PluginRegistry pluginRegistry;
/*     */   
/*     */ 
/*     */ 
/*  93 */   private final Map properties = new Hashtable();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Scheduler scheduler;
/*     */   
/*     */ 
/*     */ 
/* 102 */   private Map objectMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private List errorList = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 113 */   private boolean pristine = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggerRepositoryExImpl(LoggerRepository repository)
/*     */   {
/* 123 */     if (repository == null) {
/* 124 */       throw new NullPointerException("repository");
/*     */     }
/* 126 */     this.repo = repository;
/* 127 */     if ((repository instanceof RendererSupport)) {
/* 128 */       this.rendererSupport = ((RendererSupport)repository);
/*     */     } else {
/* 130 */       this.rendererSupport = new RendererSupportImpl();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLoggerRepositoryEventListener(LoggerRepositoryEventListener listener)
/*     */   {
/* 142 */     synchronized (this.repositoryEventListeners) {
/* 143 */       if (this.repositoryEventListeners.contains(listener)) {
/* 144 */         LogLog.warn("Ignoring attempt to add a previously registered LoggerRepositoryEventListener.");
/*     */       }
/*     */       else
/*     */       {
/* 148 */         this.repositoryEventListeners.add(listener);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLoggerRepositoryEventListener(LoggerRepositoryEventListener listener)
/*     */   {
/* 160 */     synchronized (this.repositoryEventListeners) {
/* 161 */       if (!this.repositoryEventListeners.contains(listener)) {
/* 162 */         LogLog.warn("Ignoring attempt to remove a non-registered LoggerRepositoryEventListener.");
/*     */       }
/*     */       else
/*     */       {
/* 166 */         this.repositoryEventListeners.remove(listener);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLoggerEventListener(LoggerEventListener listener)
/*     */   {
/* 177 */     synchronized (this.loggerEventListeners) {
/* 178 */       if (this.loggerEventListeners.get(listener) != null) {
/* 179 */         LogLog.warn("Ignoring attempt to add a previously registerd LoggerEventListener.");
/*     */       }
/*     */       else {
/* 182 */         HierarchyEventListenerProxy proxy = new HierarchyEventListenerProxy(listener);
/*     */         
/* 184 */         this.loggerEventListeners.put(listener, proxy);
/* 185 */         this.repo.addHierarchyEventListener(proxy);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void addHierarchyEventListener(HierarchyEventListener listener)
/*     */   {
/* 198 */     this.repo.addHierarchyEventListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLoggerEventListener(LoggerEventListener listener)
/*     */   {
/* 207 */     synchronized (this.loggerEventListeners) {
/* 208 */       HierarchyEventListenerProxy proxy = (HierarchyEventListenerProxy)this.loggerEventListeners.get(listener);
/*     */       
/* 210 */       if (proxy == null) {
/* 211 */         LogLog.warn("Ignoring attempt to remove a non-registered LoggerEventListener.");
/*     */       }
/*     */       else {
/* 214 */         this.loggerEventListeners.remove(listener);
/* 215 */         proxy.disable();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void emitNoAppenderWarning(Category cat)
/*     */   {
/* 225 */     this.repo.emitNoAppenderWarning(cat);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Logger exists(String loggerName)
/*     */   {
/* 236 */     return this.repo.exists(loggerName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 244 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String repoName)
/*     */   {
/* 254 */     if (this.name == null) {
/* 255 */       this.name = repoName;
/* 256 */     } else if (!this.name.equals(repoName)) {
/* 257 */       throw new IllegalStateException("Repository [" + this.name + "] cannot be renamed as [" + repoName + "].");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map getProperties()
/*     */   {
/* 266 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 273 */     return (String)this.properties.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(String key, String value)
/*     */   {
/* 284 */     this.properties.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThreshold(String levelStr)
/*     */   {
/* 292 */     this.repo.setThreshold(levelStr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThreshold(Level l)
/*     */   {
/* 302 */     this.repo.setThreshold(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PluginRegistry getPluginRegistry()
/*     */   {
/* 309 */     if (this.pluginRegistry == null) {
/* 310 */       this.pluginRegistry = new PluginRegistry(this);
/*     */     }
/* 312 */     return this.pluginRegistry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireAddAppenderEvent(Category logger, Appender appender)
/*     */   {
/* 324 */     this.repo.fireAddAppenderEvent(logger, appender);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireRemoveAppenderEvent(Category logger, Appender appender)
/*     */   {
/* 336 */     if ((this.repo instanceof Hierarchy)) {
/* 337 */       ((Hierarchy)this.repo).fireRemoveAppenderEvent(logger, appender);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireLevelChangedEvent(Logger logger) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireConfigurationChangedEvent() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Level getThreshold()
/*     */   {
/* 366 */     return this.repo.getThreshold();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Logger getLogger(String loggerName)
/*     */   {
/* 383 */     return this.repo.getLogger(loggerName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Logger getLogger(String loggerName, LoggerFactory factory)
/*     */   {
/* 402 */     return this.repo.getLogger(loggerName, factory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration getCurrentLoggers()
/*     */   {
/* 414 */     return this.repo.getCurrentLoggers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getErrorList()
/*     */   {
/* 422 */     return this.errorList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addErrorItem(ErrorItem errorItem)
/*     */   {
/* 430 */     getErrorList().add(errorItem);
/*     */   }
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Enumeration getCurrentCategories()
/*     */   {
/* 439 */     return this.repo.getCurrentCategories();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RendererMap getRendererMap()
/*     */   {
/* 447 */     return this.rendererSupport.getRendererMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Logger getRootLogger()
/*     */   {
/* 457 */     return this.repo.getRootLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisabled(int level)
/*     */   {
/* 469 */     return this.repo.isDisabled(level);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetConfiguration()
/*     */   {
/* 487 */     this.repo.resetConfiguration();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRenderer(Class renderedClass, ObjectRenderer renderer)
/*     */   {
/* 497 */     this.rendererSupport.setRenderer(renderedClass, renderer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPristine()
/*     */   {
/* 504 */     return this.pristine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPristine(boolean state)
/*     */   {
/* 511 */     this.pristine = state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 530 */     this.repo.shutdown();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Scheduler getScheduler()
/*     */   {
/* 540 */     if (this.scheduler == null) {
/* 541 */       this.scheduler = new Scheduler();
/* 542 */       this.scheduler.setDaemon(true);
/* 543 */       this.scheduler.start();
/*     */     }
/* 545 */     return this.scheduler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putObject(String key, Object value)
/*     */   {
/* 555 */     this.objectMap.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getObject(String key)
/*     */   {
/* 564 */     return this.objectMap.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoggerFactory(LoggerFactory factory)
/*     */   {
/* 572 */     if (factory == null) {
/* 573 */       throw new NullPointerException();
/*     */     }
/* 575 */     this.loggerFactory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggerFactory getLoggerFactory()
/*     */   {
/* 583 */     return this.loggerFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 590 */     if ("plugin".equals(element.getNodeName())) {
/* 591 */       Object instance = DOMConfigurator.parseElement(element, props, Plugin.class);
/*     */       
/* 593 */       if ((instance instanceof Plugin)) {
/* 594 */         Plugin plugin = (Plugin)instance;
/* 595 */         String pluginName = DOMConfigurator.subst(element.getAttribute("name"), props);
/* 596 */         if (pluginName.length() > 0) {
/* 597 */           plugin.setName(pluginName);
/*     */         }
/* 599 */         getPluginRegistry().addPlugin(plugin);
/* 600 */         plugin.setLoggerRepository(this);
/*     */         
/* 602 */         LogLog.debug("Pushing plugin on to the object stack.");
/* 603 */         plugin.activateOptions();
/* 604 */         return true;
/*     */       }
/*     */     }
/* 607 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class RendererSupportImpl
/*     */     implements RendererSupport
/*     */   {
/* 620 */     private final RendererMap renderers = new RendererMap();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public RendererMap getRendererMap()
/*     */     {
/* 631 */       return this.renderers;
/*     */     }
/*     */     
/*     */ 
/*     */     public void setRenderer(Class renderedClass, ObjectRenderer renderer)
/*     */     {
/* 637 */       this.renderers.put(renderedClass, renderer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class HierarchyEventListenerProxy
/*     */     implements HierarchyEventListener
/*     */   {
/*     */     private LoggerEventListener listener;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public HierarchyEventListenerProxy(LoggerEventListener l)
/*     */     {
/* 658 */       if (l == null) {
/* 659 */         throw new NullPointerException("l");
/*     */       }
/* 661 */       this.listener = l;
/*     */     }
/*     */     
/*     */ 
/*     */     public void addAppenderEvent(Category cat, Appender appender)
/*     */     {
/* 667 */       if ((isEnabled()) && ((cat instanceof Logger))) {
/* 668 */         this.listener.appenderAddedEvent((Logger)cat, appender);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void removeAppenderEvent(Category cat, Appender appender)
/*     */     {
/* 675 */       if ((isEnabled()) && ((cat instanceof Logger))) {
/* 676 */         this.listener.appenderRemovedEvent((Logger)cat, appender);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized void disable()
/*     */     {
/* 685 */       this.listener = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private synchronized boolean isEnabled()
/*     */     {
/* 693 */       return this.listener != null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\LoggerRepositoryExImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */