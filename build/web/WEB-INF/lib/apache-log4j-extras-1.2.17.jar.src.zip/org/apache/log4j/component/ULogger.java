package org.apache.log4j.component;

public abstract interface ULogger
{
  public abstract boolean isDebugEnabled();
  
  public abstract void debug(Object paramObject);
  
  public abstract void debug(Object paramObject1, Object paramObject2);
  
  public abstract void debug(String paramString, Object paramObject1, Object paramObject2);
  
  public abstract void debug(Object paramObject, Throwable paramThrowable);
  
  public abstract boolean isInfoEnabled();
  
  public abstract void info(Object paramObject);
  
  public abstract void info(Object paramObject1, Object paramObject2);
  
  public abstract void info(String paramString, Object paramObject1, Object paramObject2);
  
  public abstract void info(Object paramObject, Throwable paramThrowable);
  
  public abstract boolean isWarnEnabled();
  
  public abstract void warn(Object paramObject);
  
  public abstract void warn(Object paramObject1, Object paramObject2);
  
  public abstract void warn(String paramString, Object paramObject1, Object paramObject2);
  
  public abstract void warn(Object paramObject, Throwable paramThrowable);
  
  public abstract boolean isErrorEnabled();
  
  public abstract void error(Object paramObject);
  
  public abstract void error(Object paramObject1, Object paramObject2);
  
  public abstract void error(String paramString, Object paramObject1, Object paramObject2);
  
  public abstract void error(Object paramObject, Throwable paramThrowable);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\ULogger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */