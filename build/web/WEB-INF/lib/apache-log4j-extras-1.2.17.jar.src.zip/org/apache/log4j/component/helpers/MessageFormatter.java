/*     */ package org.apache.log4j.component.helpers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MessageFormatter
/*     */ {
/*     */   private static final char DELIM_START = '{';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final char DELIM_STOP = '}';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format(String messagePattern, Object argument)
/*     */   {
/*  63 */     int j = messagePattern.indexOf('{');
/*  64 */     int len = messagePattern.length();
/*  65 */     char escape = 'x';
/*     */     
/*     */ 
/*     */ 
/*  69 */     if ((j == -1) || (j + 1 == len)) {
/*  70 */       return messagePattern;
/*     */     }
/*  72 */     char delimStop = messagePattern.charAt(j + 1);
/*  73 */     if (j > 0) {
/*  74 */       escape = messagePattern.charAt(j - 1);
/*     */     }
/*  76 */     if ((delimStop != '}') || (escape == '\\'))
/*     */     {
/*     */ 
/*  79 */       return messagePattern;
/*     */     }
/*  81 */     StringBuffer sbuf = new StringBuffer(len + 20);
/*  82 */     sbuf.append(messagePattern.substring(0, j));
/*  83 */     sbuf.append(argument);
/*  84 */     sbuf.append(messagePattern.substring(j + 2));
/*  85 */     return sbuf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format(String messagePattern, Object arg1, Object arg2)
/*     */   {
/* 114 */     int i = 0;
/* 115 */     int len = messagePattern.length();
/*     */     
/* 117 */     StringBuffer sbuf = new StringBuffer(messagePattern.length() + 50);
/*     */     
/* 119 */     for (int l = 0; l < 2; l++) {
/* 120 */       int j = messagePattern.indexOf('{', i);
/*     */       
/* 122 */       if ((j == -1) || (j + 1 == len))
/*     */       {
/* 124 */         if (i == 0) {
/* 125 */           return messagePattern;
/*     */         }
/*     */         
/*     */ 
/* 129 */         sbuf.append(messagePattern.substring(i, messagePattern.length()));
/*     */         
/* 131 */         return sbuf.toString();
/*     */       }
/*     */       
/* 134 */       char delimStop = messagePattern.charAt(j + 1);
/* 135 */       if (delimStop != '}')
/*     */       {
/* 137 */         sbuf.append(messagePattern.substring(i, messagePattern.length()));
/*     */         
/* 139 */         return sbuf.toString();
/*     */       }
/* 141 */       sbuf.append(messagePattern.substring(i, j));
/* 142 */       if (l == 0) {
/* 143 */         sbuf.append(arg1);
/*     */       } else {
/* 145 */         sbuf.append(arg2);
/*     */       }
/* 147 */       i = j + 2;
/*     */     }
/*     */     
/*     */ 
/* 151 */     sbuf.append(messagePattern.substring(i, messagePattern.length()));
/* 152 */     return sbuf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\helpers\MessageFormatter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */