package org.apache.log4j.component.plugins;

import java.beans.PropertyChangeListener;
import org.apache.log4j.spi.LoggerRepository;
import org.apache.log4j.spi.OptionHandler;

public abstract interface Plugin
  extends OptionHandler
{
  public abstract String getName();
  
  public abstract void setName(String paramString);
  
  public abstract LoggerRepository getLoggerRepository();
  
  public abstract void setLoggerRepository(LoggerRepository paramLoggerRepository);
  
  public abstract void addPropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
  
  public abstract void removePropertyChangeListener(String paramString, PropertyChangeListener paramPropertyChangeListener);
  
  public abstract boolean isActive();
  
  public abstract boolean isEquivalent(Plugin paramPlugin);
  
  public abstract void shutdown();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\plugins\Plugin.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */