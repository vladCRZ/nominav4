/*     */ package org.apache.log4j.component.plugins;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.component.spi.LoggerRepositoryEventListener;
/*     */ import org.apache.log4j.component.spi.LoggerRepositoryEx;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PluginRegistry
/*     */ {
/*     */   private final Map pluginMap;
/*     */   private final LoggerRepositoryEx loggerRepository;
/*  49 */   private final RepositoryListener listener = new RepositoryListener(null);
/*     */   
/*     */ 
/*     */ 
/*  53 */   private final List listenerList = Collections.synchronizedList(new ArrayList());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PluginRegistry(LoggerRepositoryEx repository)
/*     */   {
/*  62 */     this.pluginMap = new HashMap();
/*  63 */     this.loggerRepository = repository;
/*  64 */     this.loggerRepository.addLoggerRepositoryEventListener(this.listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggerRepositoryEx getLoggerRepository()
/*     */   {
/*  72 */     return this.loggerRepository;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean pluginNameExists(String name)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 11	org/apache/log4j/component/plugins/PluginRegistry:pluginMap	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 11	org/apache/log4j/component/plugins/PluginRegistry:pluginMap	Ljava/util/Map;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 14 2 0
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: ireturn
/*     */     //   20: astore_3
/*     */     //   21: aload_2
/*     */     //   22: monitorexit
/*     */     //   23: aload_3
/*     */     //   24: athrow
/*     */     // Line number table:
/*     */     //   Java source line #85	-> byte code offset #0
/*     */     //   Java source line #86	-> byte code offset #7
/*     */     //   Java source line #87	-> byte code offset #20
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	25	0	this	PluginRegistry
/*     */     //   0	25	1	name	String
/*     */     //   5	17	2	Ljava/lang/Object;	Object
/*     */     //   20	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	19	20	finally
/*     */     //   20	23	20	finally
/*     */   }
/*     */   
/*     */   public void addPlugin(Plugin plugin)
/*     */   {
/* 100 */     synchronized (this.pluginMap) {
/* 101 */       String name = plugin.getName();
/*     */       
/*     */ 
/* 104 */       plugin.setLoggerRepository(getLoggerRepository());
/*     */       
/* 106 */       Plugin existingPlugin = (Plugin)this.pluginMap.get(name);
/* 107 */       if (existingPlugin != null) {
/* 108 */         existingPlugin.shutdown();
/*     */       }
/*     */       
/*     */ 
/* 112 */       this.pluginMap.put(name, plugin);
/* 113 */       firePluginStarted(plugin);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void firePluginStarted(Plugin plugin)
/*     */   {
/* 124 */     PluginEvent e = null;
/* 125 */     Iterator iter; synchronized (this.listenerList) {
/* 126 */       for (iter = this.listenerList.iterator(); iter.hasNext();) {
/* 127 */         PluginListener l = (PluginListener)iter.next();
/* 128 */         if (e == null) {
/* 129 */           e = new PluginEvent(plugin);
/*     */         }
/* 131 */         l.pluginStarted(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void firePluginStopped(Plugin plugin)
/*     */   {
/* 143 */     PluginEvent e = null;
/* 144 */     Iterator iter; synchronized (this.listenerList) {
/* 145 */       for (iter = this.listenerList.iterator(); iter.hasNext();) {
/* 146 */         PluginListener l = (PluginListener)iter.next();
/* 147 */         if (e == null) {
/* 148 */           e = new PluginEvent(plugin);
/*     */         }
/* 150 */         l.pluginStopped(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getPlugins()
/*     */   {
/* 162 */     synchronized (this.pluginMap) {
/* 163 */       List pluginList = new ArrayList(this.pluginMap.size());
/* 164 */       Iterator iter = this.pluginMap.values().iterator();
/*     */       
/* 166 */       while (iter.hasNext()) {
/* 167 */         pluginList.add(iter.next());
/*     */       }
/* 169 */       return pluginList;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getPlugins(Class pluginClass)
/*     */   {
/* 182 */     synchronized (this.pluginMap) {
/* 183 */       List pluginList = new ArrayList(this.pluginMap.size());
/* 184 */       Iterator iter = this.pluginMap.values().iterator();
/*     */       
/* 186 */       while (iter.hasNext()) {
/* 187 */         Object plugin = iter.next();
/*     */         
/* 189 */         if (pluginClass.isInstance(plugin)) {
/* 190 */           pluginList.add(plugin);
/*     */         }
/*     */       }
/* 193 */       return pluginList;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Plugin stopPlugin(String pluginName)
/*     */   {
/* 206 */     synchronized (this.pluginMap) {
/* 207 */       Plugin plugin = (Plugin)this.pluginMap.get(pluginName);
/*     */       
/* 209 */       if (plugin == null) {
/* 210 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 214 */       plugin.shutdown();
/*     */       
/*     */ 
/* 217 */       this.pluginMap.remove(pluginName);
/* 218 */       firePluginStopped(plugin);
/*     */       
/*     */ 
/* 221 */       return plugin;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stopAllPlugins()
/*     */   {
/* 229 */     synchronized (this.pluginMap)
/*     */     {
/* 231 */       this.loggerRepository.removeLoggerRepositoryEventListener(this.listener);
/*     */       
/* 233 */       Iterator iter = this.pluginMap.values().iterator();
/*     */       
/* 235 */       while (iter.hasNext()) {
/* 236 */         Plugin plugin = (Plugin)iter.next();
/* 237 */         plugin.shutdown();
/* 238 */         firePluginStopped(plugin);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPluginListener(PluginListener l)
/*     */   {
/* 251 */     this.listenerList.add(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePluginListener(PluginListener l)
/*     */   {
/* 262 */     this.listenerList.remove(l);
/*     */   }
/*     */   
/*     */   private class RepositoryListener implements LoggerRepositoryEventListener
/*     */   {
/*     */     RepositoryListener(PluginRegistry.1 x1) {
/* 268 */       this();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void configurationResetEvent(LoggerRepository repository)
/*     */     {
/* 275 */       PluginRegistry.this.stopAllPlugins();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void shutdownEvent(LoggerRepository repository)
/*     */     {
/* 296 */       PluginRegistry.this.stopAllPlugins();
/*     */     }
/*     */     
/*     */     private RepositoryListener() {}
/*     */     
/*     */     public void configurationChangedEvent(LoggerRepository repository) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\plugins\PluginRegistry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */