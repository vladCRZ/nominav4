/*     */ package org.apache.log4j.component.plugins;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import org.apache.log4j.component.spi.ComponentBase;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PluginSkeleton
/*     */   extends ComponentBase
/*     */   implements Plugin
/*     */ {
/*  48 */   protected String name = "plugin";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean active;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private PropertyChangeSupport propertySupport = new PropertyChangeSupport(this);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  75 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String newName)
/*     */   {
/*  85 */     String oldName = this.name;
/*  86 */     this.name = newName;
/*  87 */     this.propertySupport.firePropertyChange("name", oldName, this.name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggerRepository getLoggerRepository()
/*     */   {
/*  96 */     return this.repository;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoggerRepository(LoggerRepository repository)
/*     */   {
/* 107 */     Object oldValue = this.repository;
/* 108 */     this.repository = repository;
/* 109 */     firePropertyChange("loggerRepository", oldValue, this.repository);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isActive()
/*     */   {
/* 118 */     return this.active;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquivalent(Plugin testPlugin)
/*     */   {
/* 129 */     return (this.repository == testPlugin.getLoggerRepository()) && (((this.name == null) && (testPlugin.getName() == null)) || ((this.name != null) && (this.name.equals(testPlugin.getName())) && (getClass().equals(testPlugin.getClass()))));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 142 */     this.propertySupport.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addPropertyChangeListener(String propertyName, PropertyChangeListener listener)
/*     */   {
/* 153 */     this.propertySupport.addPropertyChangeListener(propertyName, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removePropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 162 */     this.propertySupport.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removePropertyChangeListener(String propertyName, PropertyChangeListener listener)
/*     */   {
/* 173 */     this.propertySupport.removePropertyChangeListener(propertyName, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void firePropertyChange(PropertyChangeEvent evt)
/*     */   {
/* 182 */     this.propertySupport.firePropertyChange(evt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void firePropertyChange(String propertyName, boolean oldValue, boolean newValue)
/*     */   {
/* 195 */     this.propertySupport.firePropertyChange(propertyName, oldValue, newValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void firePropertyChange(String propertyName, int oldValue, int newValue)
/*     */   {
/* 207 */     this.propertySupport.firePropertyChange(propertyName, oldValue, newValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void firePropertyChange(String propertyName, Object oldValue, Object newValue)
/*     */   {
/* 220 */     this.propertySupport.firePropertyChange(propertyName, oldValue, newValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\plugins\PluginSkeleton.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */