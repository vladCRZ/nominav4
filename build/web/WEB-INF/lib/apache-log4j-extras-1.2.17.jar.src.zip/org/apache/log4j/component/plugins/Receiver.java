/*     */ package org.apache.log4j.component.plugins;
/*     */ 
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.spi.Thresholdable;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Receiver
/*     */   extends PluginSkeleton
/*     */   implements Thresholdable
/*     */ {
/*     */   protected Level thresholdLevel;
/*     */   
/*     */   public void setThreshold(Level level)
/*     */   {
/*  79 */     Level oldValue = this.thresholdLevel;
/*  80 */     this.thresholdLevel = level;
/*  81 */     firePropertyChange("threshold", oldValue, this.thresholdLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Level getThreshold()
/*     */   {
/*  90 */     return this.thresholdLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsSevereAsThreshold(Level level)
/*     */   {
/* 102 */     return (this.thresholdLevel == null) || (level.isGreaterOrEqual(this.thresholdLevel));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doPost(LoggingEvent event)
/*     */   {
/* 114 */     if (!isAsSevereAsThreshold(event.getLevel())) {
/* 115 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 120 */     Logger localLogger = getLoggerRepository().getLogger(event.getLoggerName());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 125 */     if (event.getLevel().isGreaterOrEqual(localLogger.getEffectiveLevel()))
/*     */     {
/*     */ 
/* 128 */       localLogger.callAppenders(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\plugins\Receiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */