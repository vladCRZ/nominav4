/*     */ package org.apache.log4j.component.scheduler;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scheduler
/*     */   extends Thread
/*     */ {
/*     */   List jobList;
/*  42 */   boolean shutdown = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Scheduler()
/*     */   {
/*  49 */     this.jobList = new Vector();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int findIndex(Job job)
/*     */   {
/*  58 */     int size = this.jobList.size();
/*  59 */     boolean found = false;
/*     */     
/*  61 */     for (int i = 0; 
/*  62 */         i < size; i++) {
/*  63 */       ScheduledJobEntry se = (ScheduledJobEntry)this.jobList.get(i);
/*  64 */       if (se.job == job) {
/*  65 */         found = true;
/*  66 */         break;
/*     */       }
/*     */     }
/*  69 */     if (found) {
/*  70 */       return i;
/*     */     }
/*  72 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean delete(Job job)
/*     */   {
/*  86 */     if (this.shutdown) {
/*  87 */       return false;
/*     */     }
/*  89 */     int i = findIndex(job);
/*  90 */     if (i != -1) {
/*  91 */       ScheduledJobEntry se = (ScheduledJobEntry)this.jobList.remove(i);
/*  92 */       if (se.job != job) {
/*  93 */         new IllegalStateException("Internal programming error");
/*     */       }
/*     */       
/*     */ 
/*  97 */       if (i == 0) {
/*  98 */         notifyAll();
/*     */       }
/* 100 */       return true;
/*     */     }
/* 102 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void schedule(Job job, long desiredTime)
/*     */   {
/* 115 */     schedule(new ScheduledJobEntry(job, desiredTime));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void schedule(Job job, long desiredTime, long period)
/*     */   {
/* 131 */     schedule(new ScheduledJobEntry(job, desiredTime, period));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean changePeriod(Job job, long newPeriod)
/*     */   {
/* 146 */     if (newPeriod <= 0L) {
/* 147 */       throw new IllegalArgumentException("Period must be an integer langer than zero");
/*     */     }
/*     */     
/*     */ 
/* 151 */     int i = findIndex(job);
/* 152 */     if (i == -1) {
/* 153 */       return false;
/*     */     }
/* 155 */     ScheduledJobEntry se = (ScheduledJobEntry)this.jobList.get(i);
/* 156 */     se.period = newPeriod;
/* 157 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void schedule(ScheduledJobEntry newSJE)
/*     */   {
/* 167 */     if (this.shutdown) {
/* 168 */       return;
/*     */     }
/* 170 */     int max = this.jobList.size();
/* 171 */     long desiredExecutionTime = newSJE.desiredExecutionTime;
/*     */     
/*     */ 
/* 174 */     for (int i = 0; 
/* 175 */         i < max; i++)
/*     */     {
/* 177 */       ScheduledJobEntry sje = (ScheduledJobEntry)this.jobList.get(i);
/*     */       
/* 179 */       if (desiredExecutionTime < sje.desiredExecutionTime) {
/*     */         break;
/*     */       }
/*     */     }
/* 183 */     this.jobList.add(i, newSJE);
/*     */     
/* 185 */     if (i == 0) {
/* 186 */       notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 194 */     this.shutdown = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void run()
/*     */   {
/* 201 */     while (!this.shutdown) {
/* 202 */       if (this.jobList.isEmpty()) {
/* 203 */         linger();
/*     */       } else {
/* 205 */         ScheduledJobEntry sje = (ScheduledJobEntry)this.jobList.get(0);
/* 206 */         long now = System.currentTimeMillis();
/* 207 */         if (now >= sje.desiredExecutionTime) {
/* 208 */           executeInABox(sje.job);
/* 209 */           this.jobList.remove(0);
/* 210 */           if (sje.period > 0L) {
/* 211 */             sje.desiredExecutionTime = (now + sje.period);
/* 212 */             schedule(sje);
/*     */           }
/*     */         } else {
/* 215 */           linger(sje.desiredExecutionTime - now);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 220 */     this.jobList.clear();
/* 221 */     this.jobList = null;
/* 222 */     System.out.println("Leaving scheduler run method");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void executeInABox(Job job)
/*     */   {
/*     */     try
/*     */     {
/* 231 */       job.execute();
/*     */     } catch (Exception e) {
/* 233 */       System.err.println("The execution of the job threw an exception");
/* 234 */       e.printStackTrace(System.err);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void linger()
/*     */   {
/*     */     try
/*     */     {
/* 243 */       while ((this.jobList.isEmpty()) && (!this.shutdown)) {
/* 244 */         wait();
/*     */       }
/*     */     } catch (InterruptedException ie) {
/* 247 */       this.shutdown = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void linger(long timeToLinger)
/*     */   {
/*     */     try
/*     */     {
/* 257 */       wait(timeToLinger);
/*     */     } catch (InterruptedException ie) {
/* 259 */       this.shutdown = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class ScheduledJobEntry
/*     */   {
/*     */     long desiredExecutionTime;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Job job;
/*     */     
/*     */ 
/*     */ 
/* 278 */     long period = 0L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     ScheduledJobEntry(Job job, long desiredTime)
/*     */     {
/* 286 */       this(job, desiredTime, 0L);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     ScheduledJobEntry(Job job, long desiredTime, long period)
/*     */     {
/* 299 */       this.desiredExecutionTime = desiredTime;
/* 300 */       this.job = job;
/* 301 */       this.period = period;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\scheduler\Scheduler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */