/*     */ package org.apache.log4j.component.spi;
/*     */ 
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentBase
/*     */   implements Component
/*     */ {
/*     */   private static final int ERROR_COUNT_LIMIT = 3;
/*     */   protected LoggerRepository repository;
/*     */   private ULogger logger;
/*  47 */   private int errorCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void resetErrorCount()
/*     */   {
/*  62 */     this.errorCount = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoggerRepository(LoggerRepository repository)
/*     */   {
/*  72 */     if (this.repository == null) {
/*  73 */       this.repository = repository;
/*  74 */     } else if (this.repository != repository) {
/*  75 */       throw new IllegalStateException("Repository has been already set");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LoggerRepository getLoggerRepository()
/*     */   {
/*  85 */     return this.repository;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ULogger getLogger()
/*     */   {
/*  99 */     if (this.logger == null) {
/* 100 */       if (this.repository != null) {
/* 101 */         Logger l = this.repository.getLogger(getClass().getName());
/* 102 */         if ((l instanceof ULogger)) {
/* 103 */           this.logger = ((ULogger)l);
/*     */         } else {
/* 105 */           this.logger = new Log4JULogger(l);
/*     */         }
/*     */       } else {
/* 108 */         this.logger = SimpleULogger.getLogger(getClass().getName());
/*     */       }
/*     */     }
/* 111 */     return this.logger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ULogger getNonFloodingLogger()
/*     */   {
/* 121 */     if (this.errorCount++ >= 3) {
/* 122 */       return NOPULogger.NOP_LOGGER;
/*     */     }
/* 124 */     return getLogger();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\spi\ComponentBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */