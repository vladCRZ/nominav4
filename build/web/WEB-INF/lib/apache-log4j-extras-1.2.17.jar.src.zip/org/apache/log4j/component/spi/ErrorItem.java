/*     */ package org.apache.log4j.component.spi;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorItem
/*     */ {
/*     */   String message;
/*  38 */   int colNumber = -1;
/*     */   
/*     */ 
/*     */ 
/*  42 */   int lineNumber = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Throwable exception;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ErrorItem(String message, Exception e)
/*     */   {
/*  55 */     this.message = message;
/*  56 */     this.exception = e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ErrorItem(String message)
/*     */   {
/*  64 */     this(message, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColNumber()
/*     */   {
/*  72 */     return this.colNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColNumber(int colNumber)
/*     */   {
/*  80 */     this.colNumber = colNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getException()
/*     */   {
/*  88 */     return this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setException(Throwable exception)
/*     */   {
/*  96 */     this.exception = exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineNumber()
/*     */   {
/* 104 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineNumber(int lineNumber)
/*     */   {
/* 112 */     this.lineNumber = lineNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 120 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(String message)
/*     */   {
/* 128 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 136 */     String str = "Reported error: \"" + this.message + "\"";
/*     */     
/*     */ 
/* 139 */     if (this.lineNumber != -1) {
/* 140 */       str = str + " at line " + this.lineNumber + " column " + this.colNumber;
/*     */     }
/* 142 */     if (this.exception != null) {
/* 143 */       str = str + " with exception " + this.exception;
/*     */     }
/* 145 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void dump()
/*     */   {
/* 152 */     dump(System.out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dump(PrintStream ps)
/*     */   {
/* 160 */     String str = "Reported error: \"" + this.message + "\"";
/*     */     
/*     */ 
/* 163 */     if (this.lineNumber != -1) {
/* 164 */       str = str + " at line " + this.lineNumber + " column " + this.colNumber;
/*     */     }
/* 166 */     ps.println(str);
/*     */     
/* 168 */     if (this.exception != null) {
/* 169 */       this.exception.printStackTrace(ps);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\spi\ErrorItem.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */