/*     */ package org.apache.log4j.component.spi;
/*     */ 
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.helpers.MessageFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Log4JULogger
/*     */   implements ULogger
/*     */ {
/*     */   private final Logger logger;
/*     */   
/*     */   public Log4JULogger(Logger l)
/*     */   {
/*  41 */     if (l == null) {
/*  42 */       throw new NullPointerException("l");
/*     */     }
/*  44 */     this.logger = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/*  51 */     return this.logger.isDebugEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void debug(Object msg)
/*     */   {
/*  58 */     this.logger.debug(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(Object parameterizedMsg, Object param1)
/*     */   {
/*  66 */     if (this.logger.isDebugEnabled()) {
/*  67 */       this.logger.debug(MessageFormatter.format(parameterizedMsg.toString(), param1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/*  78 */     if (this.logger.isDebugEnabled()) {
/*  79 */       this.logger.debug(MessageFormatter.format(parameterizedMsg.toString(), param1, param2));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(Object msg, Throwable t)
/*     */   {
/*  89 */     this.logger.debug(msg, t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInfoEnabled()
/*     */   {
/*  97 */     return this.logger.isInfoEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void info(Object msg)
/*     */   {
/* 104 */     this.logger.info(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void info(Object parameterizedMsg, Object param1)
/*     */   {
/* 113 */     if (this.logger.isInfoEnabled()) {
/* 114 */       this.logger.info(MessageFormatter.format(parameterizedMsg.toString(), param1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void info(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 125 */     if (this.logger.isInfoEnabled()) {
/* 126 */       this.logger.info(MessageFormatter.format(parameterizedMsg.toString(), param1, param2));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void info(Object msg, Throwable t)
/*     */   {
/* 137 */     this.logger.info(msg, t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isWarnEnabled()
/*     */   {
/* 144 */     return this.logger.isEnabledFor(Level.WARN);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void warn(Object msg)
/*     */   {
/* 151 */     this.logger.warn(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void warn(Object parameterizedMsg, Object param1)
/*     */   {
/* 159 */     if (this.logger.isEnabledFor(Level.WARN)) {
/* 160 */       this.logger.warn(MessageFormatter.format(parameterizedMsg.toString(), param1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void warn(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 171 */     if (this.logger.isEnabledFor(Level.WARN)) {
/* 172 */       this.logger.warn(MessageFormatter.format(parameterizedMsg.toString(), param1, param2));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void warn(Object msg, Throwable t)
/*     */   {
/* 181 */     this.logger.warn(msg, t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isErrorEnabled()
/*     */   {
/* 188 */     return this.logger.isEnabledFor(Level.ERROR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void error(Object msg)
/*     */   {
/* 195 */     this.logger.error(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(Object parameterizedMsg, Object param1)
/*     */   {
/* 203 */     if (this.logger.isEnabledFor(Level.ERROR)) {
/* 204 */       this.logger.error(MessageFormatter.format(parameterizedMsg.toString(), param1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 215 */     if (this.logger.isEnabledFor(Level.ERROR)) {
/* 216 */       this.logger.error(MessageFormatter.format(parameterizedMsg.toString(), param1, param2));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(Object msg, Throwable t)
/*     */   {
/* 225 */     this.logger.error(msg, t);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\spi\Log4JULogger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */