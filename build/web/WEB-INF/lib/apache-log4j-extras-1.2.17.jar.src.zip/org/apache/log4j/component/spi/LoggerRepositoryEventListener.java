package org.apache.log4j.component.spi;

import org.apache.log4j.spi.LoggerRepository;

public abstract interface LoggerRepositoryEventListener
{
  public abstract void configurationResetEvent(LoggerRepository paramLoggerRepository);
  
  public abstract void configurationChangedEvent(LoggerRepository paramLoggerRepository);
  
  public abstract void shutdownEvent(LoggerRepository paramLoggerRepository);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\spi\LoggerRepositoryEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */