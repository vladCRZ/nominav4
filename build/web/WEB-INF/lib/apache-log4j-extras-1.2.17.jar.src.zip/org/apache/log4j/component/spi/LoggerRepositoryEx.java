package org.apache.log4j.component.spi;

import java.util.List;
import java.util.Map;
import org.apache.log4j.Appender;
import org.apache.log4j.Category;
import org.apache.log4j.Logger;
import org.apache.log4j.component.plugins.PluginRegistry;
import org.apache.log4j.component.scheduler.Scheduler;
import org.apache.log4j.spi.LoggerFactory;
import org.apache.log4j.spi.LoggerRepository;

public abstract interface LoggerRepositoryEx
  extends LoggerRepository
{
  public abstract void addLoggerRepositoryEventListener(LoggerRepositoryEventListener paramLoggerRepositoryEventListener);
  
  public abstract void removeLoggerRepositoryEventListener(LoggerRepositoryEventListener paramLoggerRepositoryEventListener);
  
  public abstract void addLoggerEventListener(LoggerEventListener paramLoggerEventListener);
  
  public abstract void removeLoggerEventListener(LoggerEventListener paramLoggerEventListener);
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
  
  public abstract boolean isPristine();
  
  public abstract void setPristine(boolean paramBoolean);
  
  public abstract void fireRemoveAppenderEvent(Category paramCategory, Appender paramAppender);
  
  public abstract void fireLevelChangedEvent(Logger paramLogger);
  
  public abstract void fireConfigurationChangedEvent();
  
  public abstract PluginRegistry getPluginRegistry();
  
  public abstract Scheduler getScheduler();
  
  public abstract Map getProperties();
  
  public abstract String getProperty(String paramString);
  
  public abstract void setProperty(String paramString1, String paramString2);
  
  public abstract List getErrorList();
  
  public abstract void addErrorItem(ErrorItem paramErrorItem);
  
  public abstract Object getObject(String paramString);
  
  public abstract void putObject(String paramString, Object paramObject);
  
  public abstract void setLoggerFactory(LoggerFactory paramLoggerFactory);
  
  public abstract LoggerFactory getLoggerFactory();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\spi\LoggerRepositoryEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */