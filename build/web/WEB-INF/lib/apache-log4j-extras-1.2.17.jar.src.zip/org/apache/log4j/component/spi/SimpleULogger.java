/*     */ package org.apache.log4j.component.spi;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.helpers.MessageFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleULogger
/*     */   implements ULogger
/*     */ {
/*     */   private final String loggerName;
/*  56 */   private static long startTime = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   public static final String LINE_SEPARATOR = System.getProperty("line.separator");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String INFO_STR = "INFO";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String WARN_STR = "WARN";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String ERROR_STR = "ERROR";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SimpleULogger(String name)
/*     */   {
/*  83 */     this.loggerName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleULogger getLogger(String name)
/*     */   {
/*  93 */     return new SimpleULogger(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/* 100 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(Object msg) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(Object parameterizedMsg, Object param1) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(String parameterizedMsg, Object param1, Object param2) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void debug(Object msg, Throwable t) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void log(String level, String message, Throwable t)
/*     */   {
/* 144 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 146 */     long millis = System.currentTimeMillis();
/* 147 */     buf.append(millis - startTime);
/*     */     
/* 149 */     buf.append(" [");
/* 150 */     buf.append(Thread.currentThread().getName());
/* 151 */     buf.append("] ");
/*     */     
/* 153 */     buf.append(level);
/* 154 */     buf.append(" ");
/*     */     
/* 156 */     buf.append(this.loggerName);
/* 157 */     buf.append(" - ");
/*     */     
/* 159 */     buf.append(message);
/*     */     
/* 161 */     buf.append(LINE_SEPARATOR);
/*     */     
/* 163 */     System.out.print(buf.toString());
/* 164 */     if (t != null) {
/* 165 */       t.printStackTrace(System.out);
/*     */     }
/* 167 */     System.out.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parameterizedLog(String level, Object parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 181 */     if ((parameterizedMsg instanceof String)) {
/* 182 */       String msgStr = (String)parameterizedMsg;
/* 183 */       msgStr = MessageFormatter.format(msgStr, param1, param2);
/* 184 */       log(level, msgStr, null);
/*     */     }
/*     */     else
/*     */     {
/* 188 */       log(level, parameterizedMsg.toString(), null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isInfoEnabled()
/*     */   {
/* 196 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void info(Object msg)
/*     */   {
/* 203 */     log("INFO", msg.toString(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void info(Object parameterizedMsg, Object param1)
/*     */   {
/* 211 */     parameterizedLog("INFO", parameterizedMsg, param1, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void info(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 220 */     parameterizedLog("INFO", parameterizedMsg, param1, param2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void info(Object msg, Throwable t)
/*     */   {
/* 227 */     log("INFO", msg.toString(), t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isWarnEnabled()
/*     */   {
/* 234 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void warn(Object msg)
/*     */   {
/* 241 */     log("WARN", msg.toString(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void warn(Object parameterizedMsg, Object param1)
/*     */   {
/* 248 */     parameterizedLog("WARN", parameterizedMsg, param1, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void warn(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 257 */     parameterizedLog("WARN", parameterizedMsg, param1, param2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void warn(Object msg, Throwable t)
/*     */   {
/* 264 */     log("WARN", msg.toString(), t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isErrorEnabled()
/*     */   {
/* 271 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void error(Object msg)
/*     */   {
/* 278 */     log("ERROR", msg.toString(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(Object parameterizedMsg, Object param1)
/*     */   {
/* 286 */     parameterizedLog("ERROR", parameterizedMsg, param1, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void error(String parameterizedMsg, Object param1, Object param2)
/*     */   {
/* 295 */     parameterizedLog("ERROR", parameterizedMsg, param1, param2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void error(Object msg, Throwable t)
/*     */   {
/* 302 */     log("ERROR", msg.toString(), t);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\component\spi\SimpleULogger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */