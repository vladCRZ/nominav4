/*      */ package org.apache.log4j.extras;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URL;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.FactoryConfigurationError;
/*      */ import org.apache.log4j.Appender;
/*      */ import org.apache.log4j.Layout;
/*      */ import org.apache.log4j.Level;
/*      */ import org.apache.log4j.LogManager;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.apache.log4j.config.PropertySetter;
/*      */ import org.apache.log4j.helpers.FileWatchdog;
/*      */ import org.apache.log4j.helpers.Loader;
/*      */ import org.apache.log4j.helpers.LogLog;
/*      */ import org.apache.log4j.helpers.OptionConverter;
/*      */ import org.apache.log4j.or.RendererMap;
/*      */ import org.apache.log4j.spi.AppenderAttachable;
/*      */ import org.apache.log4j.spi.Configurator;
/*      */ import org.apache.log4j.spi.ErrorHandler;
/*      */ import org.apache.log4j.spi.Filter;
/*      */ import org.apache.log4j.spi.LoggerFactory;
/*      */ import org.apache.log4j.spi.LoggerRepository;
/*      */ import org.apache.log4j.spi.OptionHandler;
/*      */ import org.apache.log4j.spi.RendererSupport;
/*      */ import org.apache.log4j.xml.SAXErrorHandler;
/*      */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DOMConfigurator
/*      */   implements Configurator
/*      */ {
/*      */   static final String CONFIGURATION_TAG = "log4j:configuration";
/*      */   static final String OLD_CONFIGURATION_TAG = "configuration";
/*      */   static final String RENDERER_TAG = "renderer";
/*      */   static final String APPENDER_TAG = "appender";
/*      */   static final String APPENDER_REF_TAG = "appender-ref";
/*      */   static final String PARAM_TAG = "param";
/*      */   static final String LAYOUT_TAG = "layout";
/*      */   static final String CATEGORY = "category";
/*      */   static final String LOGGER = "logger";
/*      */   static final String LOGGER_REF = "logger-ref";
/*      */   static final String CATEGORY_FACTORY_TAG = "categoryFactory";
/*      */   static final String LOGGER_FACTORY_TAG = "loggerFactory";
/*      */   static final String NAME_ATTR = "name";
/*      */   static final String CLASS_ATTR = "class";
/*      */   static final String VALUE_ATTR = "value";
/*      */   static final String ROOT_TAG = "root";
/*      */   static final String ROOT_REF = "root-ref";
/*      */   static final String LEVEL_TAG = "level";
/*      */   static final String PRIORITY_TAG = "priority";
/*      */   static final String FILTER_TAG = "filter";
/*      */   static final String ERROR_HANDLER_TAG = "errorHandler";
/*      */   static final String REF_ATTR = "ref";
/*      */   static final String ADDITIVITY_ATTR = "additivity";
/*      */   static final String THRESHOLD_ATTR = "threshold";
/*      */   static final String CONFIG_DEBUG_ATTR = "configDebug";
/*      */   static final String INTERNAL_DEBUG_ATTR = "debug";
/*      */   private static final String RESET_ATTR = "reset";
/*      */   static final String RENDERING_CLASS_ATTR = "renderingClass";
/*      */   static final String RENDERED_CLASS_ATTR = "renderedClass";
/*      */   static final String EMPTY_STR = "";
/*  102 */   static final Class[] ONE_STRING_PARAM = { String.class };
/*      */   
/*      */ 
/*      */   static final String dbfKey = "javax.xml.parsers.DocumentBuilderFactory";
/*      */   
/*      */   private Hashtable appenderBag;
/*      */   
/*      */   private Properties props;
/*      */   
/*      */   private LoggerRepository repository;
/*      */   
/*  113 */   private LoggerFactory catFactory = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public DOMConfigurator()
/*      */   {
/*  119 */     this.appenderBag = new Hashtable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Appender findAppenderByName(Document doc, String appenderName)
/*      */   {
/*  127 */     Appender appender = (Appender)this.appenderBag.get(appenderName);
/*      */     
/*  129 */     if (appender != null) {
/*  130 */       return appender;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  136 */     Element element = null;
/*  137 */     NodeList list = doc.getElementsByTagName("appender");
/*  138 */     for (int t = 0; t < list.getLength(); t++) {
/*  139 */       Node node = list.item(t);
/*  140 */       NamedNodeMap map = node.getAttributes();
/*  141 */       Node attrNode = map.getNamedItem("name");
/*  142 */       if (appenderName.equals(attrNode.getNodeValue())) {
/*  143 */         element = (Element)node;
/*  144 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  149 */     if (element == null) {
/*  150 */       LogLog.error("No appender named [" + appenderName + "] could be found.");
/*  151 */       return null;
/*      */     }
/*  153 */     appender = parseAppender(element);
/*  154 */     if (appender != null) {
/*  155 */       this.appenderBag.put(appenderName, appender);
/*      */     }
/*  157 */     return appender;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Appender findAppenderByReference(Element appenderRef)
/*      */   {
/*  166 */     String appenderName = subst(appenderRef.getAttribute("ref"));
/*  167 */     Document doc = appenderRef.getOwnerDocument();
/*  168 */     return findAppenderByName(doc, appenderName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void parseUnrecognizedElement(Object instance, Element element, Properties props)
/*      */     throws Exception
/*      */   {
/*  184 */     boolean recognized = false;
/*  185 */     if ((instance instanceof UnrecognizedElementHandler)) {
/*  186 */       recognized = ((UnrecognizedElementHandler)instance).parseUnrecognizedElement(element, props);
/*      */     }
/*      */     
/*  189 */     if (!recognized) {
/*  190 */       LogLog.warn("Unrecognized element " + element.getNodeName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void quietParseUnrecognizedElement(Object instance, Element element, Properties props)
/*      */   {
/*      */     try
/*      */     {
/*  207 */       parseUnrecognizedElement(instance, element, props);
/*      */     } catch (Exception ex) {
/*  209 */       LogLog.error("Error in extension content: ", ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Appender parseAppender(Element appenderElement)
/*      */   {
/*  218 */     String className = subst(appenderElement.getAttribute("class"));
/*  219 */     LogLog.debug("Class name: [" + className + ']');
/*      */     try {
/*  221 */       Object instance = Loader.loadClass(className).newInstance();
/*  222 */       Appender appender = (Appender)instance;
/*  223 */       PropertySetter propSetter = new PropertySetter(appender);
/*      */       
/*  225 */       appender.setName(subst(appenderElement.getAttribute("name")));
/*      */       
/*  227 */       NodeList children = appenderElement.getChildNodes();
/*  228 */       int length = children.getLength();
/*      */       
/*  230 */       for (int loop = 0; loop < length; loop++) {
/*  231 */         Node currentNode = children.item(loop);
/*      */         
/*      */ 
/*  234 */         if (currentNode.getNodeType() == 1) {
/*  235 */           Element currentElement = (Element)currentNode;
/*      */           
/*      */ 
/*  238 */           if (currentElement.getTagName().equals("param")) {
/*  239 */             setParameter(currentElement, propSetter);
/*      */ 
/*      */           }
/*  242 */           else if (currentElement.getTagName().equals("layout")) {
/*  243 */             appender.setLayout(parseLayout(currentElement));
/*      */ 
/*      */           }
/*  246 */           else if (currentElement.getTagName().equals("filter")) {
/*  247 */             parseFilters(currentElement, appender);
/*      */           }
/*  249 */           else if (currentElement.getTagName().equals("errorHandler")) {
/*  250 */             parseErrorHandler(currentElement, appender);
/*      */           }
/*  252 */           else if (currentElement.getTagName().equals("appender-ref")) {
/*  253 */             String refName = subst(currentElement.getAttribute("ref"));
/*  254 */             if ((appender instanceof AppenderAttachable)) {
/*  255 */               AppenderAttachable aa = (AppenderAttachable)appender;
/*  256 */               LogLog.debug("Attaching appender named [" + refName + "] to appender named [" + appender.getName() + "].");
/*      */               
/*  258 */               aa.addAppender(findAppenderByReference(currentElement));
/*      */             } else {
/*  260 */               LogLog.error("Requesting attachment of appender named [" + refName + "] to appender named [" + appender.getName() + "] which does not implement org.apache.log4j.spi.AppenderAttachable.");
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  265 */             parseUnrecognizedElement(instance, currentElement, this.props);
/*      */           }
/*      */         }
/*      */       }
/*  269 */       propSetter.activate();
/*  270 */       return appender;
/*      */ 
/*      */     }
/*      */     catch (Exception oops)
/*      */     {
/*  275 */       LogLog.error("Could not create an Appender. Reported error follows.", oops);
/*      */     }
/*  277 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseErrorHandler(Element element, Appender appender)
/*      */   {
/*  286 */     ErrorHandler eh = (ErrorHandler)OptionConverter.instantiateByClassName(subst(element.getAttribute("class")), ErrorHandler.class, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  291 */     if (eh != null) {
/*  292 */       eh.setAppender(appender);
/*      */       
/*  294 */       PropertySetter propSetter = new PropertySetter(eh);
/*  295 */       NodeList children = element.getChildNodes();
/*  296 */       int length = children.getLength();
/*      */       
/*  298 */       for (int loop = 0; loop < length; loop++) {
/*  299 */         Node currentNode = children.item(loop);
/*  300 */         if (currentNode.getNodeType() == 1) {
/*  301 */           Element currentElement = (Element)currentNode;
/*  302 */           String tagName = currentElement.getTagName();
/*  303 */           if (tagName.equals("param")) {
/*  304 */             setParameter(currentElement, propSetter);
/*  305 */           } else if (tagName.equals("appender-ref")) {
/*  306 */             eh.setBackupAppender(findAppenderByReference(currentElement));
/*  307 */           } else if (tagName.equals("logger-ref")) {
/*  308 */             String loggerName = currentElement.getAttribute("ref");
/*  309 */             Logger logger = this.catFactory == null ? this.repository.getLogger(loggerName) : this.repository.getLogger(loggerName, this.catFactory);
/*      */             
/*  311 */             eh.setLogger(logger);
/*  312 */           } else if (tagName.equals("root-ref")) {
/*  313 */             Logger root = this.repository.getRootLogger();
/*  314 */             eh.setLogger(root);
/*      */           } else {
/*  316 */             quietParseUnrecognizedElement(eh, currentElement, this.props);
/*      */           }
/*      */         }
/*      */       }
/*  320 */       propSetter.activate();
/*  321 */       appender.setErrorHandler(eh);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseFilters(Element element, Appender appender)
/*      */   {
/*  330 */     String clazz = subst(element.getAttribute("class"));
/*  331 */     Filter filter = (Filter)OptionConverter.instantiateByClassName(clazz, Filter.class, null);
/*      */     
/*      */ 
/*  334 */     if (filter != null) {
/*  335 */       PropertySetter propSetter = new PropertySetter(filter);
/*  336 */       NodeList children = element.getChildNodes();
/*  337 */       int length = children.getLength();
/*      */       
/*  339 */       for (int loop = 0; loop < length; loop++) {
/*  340 */         Node currentNode = children.item(loop);
/*  341 */         if (currentNode.getNodeType() == 1) {
/*  342 */           Element currentElement = (Element)currentNode;
/*  343 */           String tagName = currentElement.getTagName();
/*  344 */           if (tagName.equals("param")) {
/*  345 */             setParameter(currentElement, propSetter);
/*      */           } else {
/*  347 */             quietParseUnrecognizedElement(filter, currentElement, this.props);
/*      */           }
/*      */         }
/*      */       }
/*  351 */       propSetter.activate();
/*  352 */       LogLog.debug("Adding filter of type [" + filter.getClass() + "] to appender named [" + appender.getName() + "].");
/*      */       
/*  354 */       appender.addFilter(filter);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseCategory(Element loggerElement)
/*      */   {
/*  364 */     String catName = subst(loggerElement.getAttribute("name"));
/*      */     
/*      */ 
/*      */ 
/*  368 */     String className = subst(loggerElement.getAttribute("class"));
/*      */     Logger cat;
/*      */     Logger cat;
/*  371 */     if ("".equals(className)) {
/*  372 */       LogLog.debug("Retreiving an instance of org.apache.log4j.Logger.");
/*  373 */       cat = this.catFactory == null ? this.repository.getLogger(catName) : this.repository.getLogger(catName, this.catFactory);
/*      */     }
/*      */     else {
/*  376 */       LogLog.debug("Desired logger sub-class: [" + className + ']');
/*      */       try {
/*  378 */         Class clazz = Loader.loadClass(className);
/*  379 */         Method getInstanceMethod = clazz.getMethod("getLogger", ONE_STRING_PARAM);
/*      */         
/*  381 */         cat = (Logger)getInstanceMethod.invoke(null, new Object[] { catName });
/*      */       } catch (Exception oops) {
/*  383 */         LogLog.error("Could not retrieve category [" + catName + "]. Reported error follows.", oops);
/*      */         
/*  385 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  392 */     synchronized (cat) {
/*  393 */       boolean additivity = OptionConverter.toBoolean(subst(loggerElement.getAttribute("additivity")), true);
/*      */       
/*      */ 
/*      */ 
/*  397 */       LogLog.debug("Setting [" + cat.getName() + "] additivity to [" + additivity + "].");
/*  398 */       cat.setAdditivity(additivity);
/*  399 */       parseChildrenOfLoggerElement(loggerElement, cat, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseCategoryFactory(Element factoryElement)
/*      */   {
/*  409 */     String className = subst(factoryElement.getAttribute("class"));
/*      */     
/*  411 */     if ("".equals(className)) {
/*  412 */       LogLog.error("Category Factory tag class attribute not found.");
/*  413 */       LogLog.debug("No Category Factory configured.");
/*      */     }
/*      */     else {
/*  416 */       LogLog.debug("Desired category factory: [" + className + ']');
/*  417 */       Object factory = OptionConverter.instantiateByClassName(className, LoggerFactory.class, null);
/*      */       
/*      */ 
/*  420 */       if ((factory instanceof LoggerFactory)) {
/*  421 */         this.catFactory = ((LoggerFactory)factory);
/*      */       } else {
/*  423 */         LogLog.error("Category Factory class " + className + " does not implement org.apache.log4j.LoggerFactory");
/*      */       }
/*  425 */       PropertySetter propSetter = new PropertySetter(factory);
/*      */       
/*  427 */       Element currentElement = null;
/*  428 */       Node currentNode = null;
/*  429 */       NodeList children = factoryElement.getChildNodes();
/*  430 */       int length = children.getLength();
/*      */       
/*  432 */       for (int loop = 0; loop < length; loop++) {
/*  433 */         currentNode = children.item(loop);
/*  434 */         if (currentNode.getNodeType() == 1) {
/*  435 */           currentElement = (Element)currentNode;
/*  436 */           if (currentElement.getTagName().equals("param")) {
/*  437 */             setParameter(currentElement, propSetter);
/*      */           } else {
/*  439 */             quietParseUnrecognizedElement(factory, currentElement, this.props);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseRoot(Element rootElement)
/*      */   {
/*  452 */     Logger root = this.repository.getRootLogger();
/*      */     
/*  454 */     synchronized (root) {
/*  455 */       parseChildrenOfLoggerElement(rootElement, root, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseChildrenOfLoggerElement(Element catElement, Logger cat, boolean isRoot)
/*      */   {
/*  467 */     PropertySetter propSetter = new PropertySetter(cat);
/*      */     
/*      */ 
/*      */ 
/*  471 */     cat.removeAllAppenders();
/*      */     
/*      */ 
/*  474 */     NodeList children = catElement.getChildNodes();
/*  475 */     int length = children.getLength();
/*      */     
/*  477 */     for (int loop = 0; loop < length; loop++) {
/*  478 */       Node currentNode = children.item(loop);
/*      */       
/*  480 */       if (currentNode.getNodeType() == 1) {
/*  481 */         Element currentElement = (Element)currentNode;
/*  482 */         String tagName = currentElement.getTagName();
/*      */         
/*  484 */         if (tagName.equals("appender-ref")) {
/*  485 */           Element appenderRef = (Element)currentNode;
/*  486 */           Appender appender = findAppenderByReference(appenderRef);
/*  487 */           String refName = subst(appenderRef.getAttribute("ref"));
/*  488 */           if (appender != null) {
/*  489 */             LogLog.debug("Adding appender named [" + refName + "] to category [" + cat.getName() + "].");
/*      */           }
/*      */           else {
/*  492 */             LogLog.debug("Appender named [" + refName + "] not found.");
/*      */           }
/*  494 */           cat.addAppender(appender);
/*      */         }
/*  496 */         else if (tagName.equals("level")) {
/*  497 */           parseLevel(currentElement, cat, isRoot);
/*  498 */         } else if (tagName.equals("priority")) {
/*  499 */           parseLevel(currentElement, cat, isRoot);
/*  500 */         } else if (tagName.equals("param")) {
/*  501 */           setParameter(currentElement, propSetter);
/*      */         } else {
/*  503 */           quietParseUnrecognizedElement(cat, currentElement, this.props);
/*      */         }
/*      */       }
/*      */     }
/*  507 */     propSetter.activate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Layout parseLayout(Element layout_element)
/*      */   {
/*  515 */     String className = subst(layout_element.getAttribute("class"));
/*  516 */     LogLog.debug("Parsing layout of class: \"" + className + "\"");
/*      */     try {
/*  518 */       Object instance = Loader.loadClass(className).newInstance();
/*  519 */       Layout layout = (Layout)instance;
/*  520 */       PropertySetter propSetter = new PropertySetter(layout);
/*      */       
/*  522 */       NodeList params = layout_element.getChildNodes();
/*  523 */       int length = params.getLength();
/*      */       
/*  525 */       for (int loop = 0; loop < length; loop++) {
/*  526 */         Node currentNode = params.item(loop);
/*  527 */         if (currentNode.getNodeType() == 1) {
/*  528 */           Element currentElement = (Element)currentNode;
/*  529 */           String tagName = currentElement.getTagName();
/*  530 */           if (tagName.equals("param")) {
/*  531 */             setParameter(currentElement, propSetter);
/*      */           } else {
/*  533 */             parseUnrecognizedElement(instance, currentElement, this.props);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  538 */       propSetter.activate();
/*  539 */       return layout;
/*      */     }
/*      */     catch (Exception oops) {
/*  542 */       LogLog.error("Could not create the Layout. Reported error follows.", oops);
/*      */     }
/*  544 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void parseRenderer(Element element)
/*      */   {
/*  550 */     String renderingClass = subst(element.getAttribute("renderingClass"));
/*  551 */     String renderedClass = subst(element.getAttribute("renderedClass"));
/*  552 */     if ((this.repository instanceof RendererSupport)) {
/*  553 */       RendererMap.addRenderer((RendererSupport)this.repository, renderedClass, renderingClass);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseLevel(Element element, Logger logger, boolean isRoot)
/*      */   {
/*  563 */     String catName = logger.getName();
/*  564 */     if (isRoot) {
/*  565 */       catName = "root";
/*      */     }
/*      */     
/*  568 */     String priStr = subst(element.getAttribute("value"));
/*  569 */     LogLog.debug("Level value for " + catName + " is  [" + priStr + "].");
/*      */     
/*  571 */     if (("inherited".equalsIgnoreCase(priStr)) || ("null".equalsIgnoreCase(priStr))) {
/*  572 */       if (isRoot) {
/*  573 */         LogLog.error("Root level cannot be inherited. Ignoring directive.");
/*      */       } else {
/*  575 */         logger.setLevel(null);
/*      */       }
/*      */     } else {
/*  578 */       String className = subst(element.getAttribute("class"));
/*  579 */       if ("".equals(className)) {
/*  580 */         logger.setLevel(OptionConverter.toLevel(priStr, Level.DEBUG));
/*      */       } else {
/*  582 */         LogLog.debug("Desired Level sub-class: [" + className + ']');
/*      */         try {
/*  584 */           Class clazz = Loader.loadClass(className);
/*  585 */           Method toLevelMethod = clazz.getMethod("toLevel", ONE_STRING_PARAM);
/*      */           
/*  587 */           Level pri = (Level)toLevelMethod.invoke(null, new Object[] { priStr });
/*      */           
/*  589 */           logger.setLevel(pri);
/*      */         } catch (Exception oops) {
/*  591 */           LogLog.error("Could not create level [" + priStr + "]. Reported error follows.", oops);
/*      */           
/*  593 */           return;
/*      */         }
/*      */       }
/*      */     }
/*  597 */     LogLog.debug(catName + " level set to " + logger.getLevel());
/*      */   }
/*      */   
/*      */   protected void setParameter(Element elem, PropertySetter propSetter)
/*      */   {
/*  602 */     setParameter(elem, propSetter, this.props);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void configure(Element element)
/*      */   {
/*  614 */     DOMConfigurator configurator = new DOMConfigurator();
/*  615 */     configurator.doConfigure(element, LogManager.getLoggerRepository());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void configureAndWatch(String configFilename)
/*      */   {
/*  629 */     configureAndWatch(configFilename, 60000L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void configureAndWatch(String configFilename, long delay)
/*      */   {
/*  646 */     XMLWatchdog xdog = new XMLWatchdog(configFilename);
/*  647 */     xdog.setDelay(delay);
/*  648 */     xdog.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doConfigure(final String filename, LoggerRepository repository)
/*      */   {
/*  658 */     ParseAction action = new ParseAction() {
/*      */       public Document parse(DocumentBuilder parser) throws SAXException, IOException {
/*  660 */         return parser.parse(new File(filename));
/*      */       }
/*      */       
/*  663 */       public String toString() { return "file [" + filename + "]";
/*      */       }
/*  665 */     };
/*  666 */     doConfigure(action, repository);
/*      */   }
/*      */   
/*      */ 
/*      */   public void doConfigure(final URL url, LoggerRepository repository)
/*      */   {
/*  672 */     ParseAction action = new ParseAction() {
/*      */       public Document parse(DocumentBuilder parser) throws SAXException, IOException {
/*  674 */         InputStream stream = url.openStream();
/*      */         try {
/*  676 */           InputSource src = new InputSource(stream);
/*  677 */           src.setSystemId(url.toString());
/*  678 */           return parser.parse(src);
/*      */         } finally {
/*  680 */           stream.close();
/*      */         }
/*      */       }
/*      */       
/*  684 */       public String toString() { return "url [" + url.toString() + "]";
/*      */       }
/*  686 */     };
/*  687 */     doConfigure(action, repository);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doConfigure(final InputStream inputStream, LoggerRepository repository)
/*      */     throws FactoryConfigurationError
/*      */   {
/*  698 */     ParseAction action = new ParseAction() {
/*      */       public Document parse(DocumentBuilder parser) throws SAXException, IOException {
/*  700 */         InputSource inputSource = new InputSource(inputStream);
/*  701 */         inputSource.setSystemId("dummy://log4j.dtd");
/*  702 */         return parser.parse(inputSource);
/*      */       }
/*      */       
/*  705 */       public String toString() { return "input stream [" + inputStream.toString() + "]";
/*      */       }
/*  707 */     };
/*  708 */     doConfigure(action, repository);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doConfigure(final Reader reader, LoggerRepository repository)
/*      */     throws FactoryConfigurationError
/*      */   {
/*  719 */     ParseAction action = new ParseAction() {
/*      */       public Document parse(DocumentBuilder parser) throws SAXException, IOException {
/*  721 */         InputSource inputSource = new InputSource(reader);
/*  722 */         inputSource.setSystemId("dummy://log4j.dtd");
/*  723 */         return parser.parse(inputSource);
/*      */       }
/*      */       
/*  726 */       public String toString() { return "reader [" + reader.toString() + "]";
/*      */       }
/*  728 */     };
/*  729 */     doConfigure(action, repository);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doConfigure(final InputSource inputSource, LoggerRepository repository)
/*      */     throws FactoryConfigurationError
/*      */   {
/*  740 */     if (inputSource.getSystemId() == null) {
/*  741 */       inputSource.setSystemId("dummy://log4j.dtd");
/*      */     }
/*  743 */     ParseAction action = new ParseAction() {
/*      */       public Document parse(DocumentBuilder parser) throws SAXException, IOException {
/*  745 */         return parser.parse(inputSource);
/*      */       }
/*      */       
/*  748 */       public String toString() { return "input source [" + inputSource.toString() + "]";
/*      */       }
/*  750 */     };
/*  751 */     doConfigure(action, repository);
/*      */   }
/*      */   
/*      */   private final void doConfigure(ParseAction action, LoggerRepository repository)
/*      */     throws FactoryConfigurationError
/*      */   {
/*  757 */     DocumentBuilderFactory dbf = null;
/*  758 */     this.repository = repository;
/*      */     try {
/*  760 */       LogLog.debug("System property is :" + OptionConverter.getSystemProperty("javax.xml.parsers.DocumentBuilderFactory", null));
/*      */       
/*      */ 
/*  763 */       dbf = DocumentBuilderFactory.newInstance();
/*  764 */       LogLog.debug("Standard DocumentBuilderFactory search succeded.");
/*  765 */       LogLog.debug("DocumentBuilderFactory is: " + dbf.getClass().getName());
/*      */     } catch (FactoryConfigurationError fce) {
/*  767 */       Exception e = fce.getException();
/*  768 */       LogLog.debug("Could not instantiate a DocumentBuilderFactory.", e);
/*  769 */       throw fce;
/*      */     }
/*      */     try
/*      */     {
/*  773 */       dbf.setValidating(true);
/*      */       
/*  775 */       DocumentBuilder docBuilder = dbf.newDocumentBuilder();
/*      */       
/*  777 */       docBuilder.setErrorHandler(new SAXErrorHandler());
/*  778 */       docBuilder.setEntityResolver(new Log4jEntityResolver(null));
/*      */       
/*  780 */       Document doc = action.parse(docBuilder);
/*  781 */       parse(doc.getDocumentElement());
/*      */     }
/*      */     catch (Exception e) {
/*  784 */       LogLog.error("Could not parse " + action.toString() + ".", e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void doConfigure(Element element, LoggerRepository repository)
/*      */   {
/*  792 */     this.repository = repository;
/*  793 */     parse(element);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void configure(String filename)
/*      */     throws FactoryConfigurationError
/*      */   {
/*  802 */     new DOMConfigurator().doConfigure(filename, LogManager.getLoggerRepository());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void configure(URL url)
/*      */     throws FactoryConfigurationError
/*      */   {
/*  812 */     new DOMConfigurator().doConfigure(url, LogManager.getLoggerRepository());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parse(Element element)
/*      */   {
/*  824 */     String rootElementName = element.getTagName();
/*      */     
/*  826 */     if (!rootElementName.equals("log4j:configuration")) {
/*  827 */       if (rootElementName.equals("configuration")) {
/*  828 */         LogLog.warn("The <configuration> element has been deprecated.");
/*      */         
/*  830 */         LogLog.warn("Use the <log4j:configuration> element instead.");
/*      */       } else {
/*  832 */         LogLog.error("DOM element is - not a <log4j:configuration> element.");
/*  833 */         return;
/*      */       }
/*      */     }
/*      */     
/*  837 */     String debugAttrib = subst(element.getAttribute("debug"));
/*      */     
/*  839 */     LogLog.debug("debug attribute= \"" + debugAttrib + "\".");
/*      */     
/*      */ 
/*  842 */     if ((!debugAttrib.equals("")) && (!debugAttrib.equals("null"))) {
/*  843 */       LogLog.setInternalDebugging(OptionConverter.toBoolean(debugAttrib, true));
/*      */     } else {
/*  845 */       LogLog.debug("Ignoring debug attribute.");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  852 */     String resetAttrib = subst(element.getAttribute("reset"));
/*  853 */     LogLog.debug("reset attribute= \"" + resetAttrib + "\".");
/*  854 */     if ((!"".equals(resetAttrib)) && (OptionConverter.toBoolean(resetAttrib, false)))
/*      */     {
/*  856 */       this.repository.resetConfiguration();
/*      */     }
/*      */     
/*      */ 
/*  860 */     String confDebug = subst(element.getAttribute("configDebug"));
/*  861 */     if ((!confDebug.equals("")) && (!confDebug.equals("null"))) {
/*  862 */       LogLog.warn("The \"configDebug\" attribute is deprecated.");
/*  863 */       LogLog.warn("Use the \"debug\" attribute instead.");
/*  864 */       LogLog.setInternalDebugging(OptionConverter.toBoolean(confDebug, true));
/*      */     }
/*      */     
/*  867 */     String thresholdStr = subst(element.getAttribute("threshold"));
/*  868 */     LogLog.debug("Threshold =\"" + thresholdStr + "\".");
/*  869 */     if ((!"".equals(thresholdStr)) && (!"null".equals(thresholdStr))) {
/*  870 */       this.repository.setThreshold(thresholdStr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  882 */     String tagName = null;
/*  883 */     Element currentElement = null;
/*  884 */     Node currentNode = null;
/*  885 */     NodeList children = element.getChildNodes();
/*  886 */     int length = children.getLength();
/*      */     
/*  888 */     for (int loop = 0; loop < length; loop++) {
/*  889 */       currentNode = children.item(loop);
/*  890 */       if (currentNode.getNodeType() == 1) {
/*  891 */         currentElement = (Element)currentNode;
/*  892 */         tagName = currentElement.getTagName();
/*      */         
/*  894 */         if ((tagName.equals("categoryFactory")) || (tagName.equals("loggerFactory"))) {
/*  895 */           parseCategoryFactory(currentElement);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  900 */     for (int loop = 0; loop < length; loop++) {
/*  901 */       currentNode = children.item(loop);
/*  902 */       if (currentNode.getNodeType() == 1) {
/*  903 */         currentElement = (Element)currentNode;
/*  904 */         tagName = currentElement.getTagName();
/*      */         
/*  906 */         if ((tagName.equals("category")) || (tagName.equals("logger"))) {
/*  907 */           parseCategory(currentElement);
/*  908 */         } else if (tagName.equals("root")) {
/*  909 */           parseRoot(currentElement);
/*  910 */         } else if (tagName.equals("renderer")) {
/*  911 */           parseRenderer(currentElement);
/*  912 */         } else if ((!tagName.equals("appender")) && (!tagName.equals("categoryFactory")) && (!tagName.equals("loggerFactory")))
/*      */         {
/*      */ 
/*  915 */           quietParseUnrecognizedElement(this.repository, currentElement, this.props);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected String subst(String value)
/*      */   {
/*  924 */     return subst(value, this.props);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String subst(String value, Properties props)
/*      */   {
/*      */     try
/*      */     {
/*  939 */       return OptionConverter.substVars(value, props);
/*      */     } catch (IllegalArgumentException e) {
/*  941 */       LogLog.warn("Could not perform variable substitution.", e); }
/*  942 */     return value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void setParameter(Element elem, PropertySetter propSetter, Properties props)
/*      */   {
/*  958 */     String name = subst(elem.getAttribute("name"), props);
/*  959 */     String value = elem.getAttribute("value");
/*  960 */     value = subst(OptionConverter.convertSpecialChars(value), props);
/*  961 */     propSetter.setProperty(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static OptionHandler parseElement(Element element, Properties props, Class expectedClass)
/*      */     throws Exception
/*      */   {
/*  982 */     String clazz = subst(element.getAttribute("class"), props);
/*  983 */     Object instance = OptionConverter.instantiateByClassName(clazz, expectedClass, null);
/*      */     
/*      */ 
/*  986 */     if ((instance instanceof OptionHandler)) {
/*  987 */       OptionHandler optionHandler = (OptionHandler)instance;
/*  988 */       PropertySetter propSetter = new PropertySetter(optionHandler);
/*  989 */       NodeList children = element.getChildNodes();
/*  990 */       int length = children.getLength();
/*      */       
/*  992 */       for (int loop = 0; loop < length; loop++) {
/*  993 */         Node currentNode = children.item(loop);
/*  994 */         if (currentNode.getNodeType() == 1) {
/*  995 */           Element currentElement = (Element)currentNode;
/*  996 */           String tagName = currentElement.getTagName();
/*  997 */           if (tagName.equals("param")) {
/*  998 */             setParameter(currentElement, propSetter, props);
/*      */           } else {
/* 1000 */             parseUnrecognizedElement(instance, currentElement, props);
/*      */           }
/*      */         }
/*      */       }
/* 1004 */       return optionHandler;
/*      */     }
/* 1006 */     return null;
/*      */   }
/*      */   
/*      */   private static abstract interface ParseAction { public abstract Document parse(DocumentBuilder paramDocumentBuilder) throws SAXException, IOException;
/*      */   }
/*      */   
/* 1012 */   private static class XMLWatchdog extends FileWatchdog { XMLWatchdog(String filename) { super(); }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void doOnChange()
/*      */     {
/* 1020 */       new DOMConfigurator().doConfigure(this.filename, LogManager.getLoggerRepository());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class Log4jEntityResolver
/*      */     implements EntityResolver
/*      */   {
/* 1033 */     Log4jEntityResolver(DOMConfigurator.1 x0) { this(); }
/*      */     
/*      */     public InputSource resolveEntity(String publicId, String systemId) {
/* 1036 */       if (systemId.endsWith("log4j.dtd")) {
/* 1037 */         InputStream in = Log4jEntityResolver.class.getResourceAsStream("log4j.dtd");
/* 1038 */         if (in == null) {
/* 1039 */           LogLog.warn("Could not find [log4j.dtd] using [" + Log4jEntityResolver.class.getClassLoader() + "] class loader, parsed without DTD.");
/*      */           
/*      */ 
/* 1042 */           in = new ByteArrayInputStream(new byte[0]);
/*      */         }
/* 1044 */         return new InputSource(in);
/*      */       }
/* 1046 */       return null;
/*      */     }
/*      */     
/*      */     private Log4jEntityResolver() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\extras\DOMConfigurator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */