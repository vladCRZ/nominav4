/*     */ package org.apache.log4j.extras;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilLoggingLevel
/*     */   extends Level
/*     */ {
/*     */   private static final long serialVersionUID = 909301162611820211L;
/*     */   public static final int SEVERE_INT = 17000;
/*     */   public static final int WARNING_INT = 16000;
/*     */   public static final int INFO_INT = 15000;
/*     */   public static final int CONFIG_INT = 14000;
/*     */   public static final int FINE_INT = 13000;
/*     */   public static final int FINER_INT = 12000;
/*     */   public static final int FINEST_INT = 11000;
/*     */   public static final int UNKNOWN_INT = 10000;
/*  78 */   public static final UtilLoggingLevel SEVERE = new UtilLoggingLevel(17000, "SEVERE", 0);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  83 */   public static final UtilLoggingLevel WARNING = new UtilLoggingLevel(16000, "WARNING", 4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  88 */   public static final UtilLoggingLevel INFO = new UtilLoggingLevel(15000, "INFO", 5);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  93 */   public static final UtilLoggingLevel CONFIG = new UtilLoggingLevel(14000, "CONFIG", 6);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  98 */   public static final UtilLoggingLevel FINE = new UtilLoggingLevel(13000, "FINE", 7);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 103 */   public static final UtilLoggingLevel FINER = new UtilLoggingLevel(12000, "FINER", 8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   public static final UtilLoggingLevel FINEST = new UtilLoggingLevel(11000, "FINEST", 9);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UtilLoggingLevel(int level, String levelStr, int syslogEquivalent)
/*     */   {
/* 120 */     super(level, levelStr, syslogEquivalent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UtilLoggingLevel toLevel(int val, UtilLoggingLevel defaultLevel)
/*     */   {
/* 133 */     switch (val) {
/*     */     case 17000: 
/* 135 */       return SEVERE;
/*     */     
/*     */     case 16000: 
/* 138 */       return WARNING;
/*     */     
/*     */     case 15000: 
/* 141 */       return INFO;
/*     */     
/*     */     case 14000: 
/* 144 */       return CONFIG;
/*     */     
/*     */     case 13000: 
/* 147 */       return FINE;
/*     */     
/*     */     case 12000: 
/* 150 */       return FINER;
/*     */     
/*     */     case 11000: 
/* 153 */       return FINEST;
/*     */     }
/*     */     
/* 156 */     return defaultLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Level toLevel(int val)
/*     */   {
/* 166 */     return toLevel(val, FINEST);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List getAllPossibleLevels()
/*     */   {
/* 174 */     ArrayList list = new ArrayList();
/* 175 */     list.add(FINE);
/* 176 */     list.add(FINER);
/* 177 */     list.add(FINEST);
/* 178 */     list.add(INFO);
/* 179 */     list.add(CONFIG);
/* 180 */     list.add(WARNING);
/* 181 */     list.add(SEVERE);
/* 182 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Level toLevel(String s)
/*     */   {
/* 191 */     return toLevel(s, Level.DEBUG);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Level toLevel(String sArg, Level defaultLevel)
/*     */   {
/* 203 */     if (sArg == null) {
/* 204 */       return defaultLevel;
/*     */     }
/*     */     
/* 207 */     String s = sArg.toUpperCase();
/*     */     
/* 209 */     if (s.equals("SEVERE")) {
/* 210 */       return SEVERE;
/*     */     }
/*     */     
/*     */ 
/* 214 */     if (s.equals("WARNING")) {
/* 215 */       return WARNING;
/*     */     }
/*     */     
/* 218 */     if (s.equals("INFO")) {
/* 219 */       return INFO;
/*     */     }
/*     */     
/* 222 */     if (s.equals("CONFI")) {
/* 223 */       return CONFIG;
/*     */     }
/*     */     
/* 226 */     if (s.equals("FINE")) {
/* 227 */       return FINE;
/*     */     }
/*     */     
/* 230 */     if (s.equals("FINER")) {
/* 231 */       return FINER;
/*     */     }
/*     */     
/* 234 */     if (s.equals("FINEST")) {
/* 235 */       return FINEST;
/*     */     }
/* 237 */     return defaultLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\extras\UtilLoggingLevel.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */