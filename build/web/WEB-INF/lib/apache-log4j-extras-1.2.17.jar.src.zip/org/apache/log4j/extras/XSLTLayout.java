/*     */ package org.apache.log4j.extras;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.log4j.Layout;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.helpers.MDCKeySetExtractor;
/*     */ import org.apache.log4j.pattern.CachedDateFormat;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XSLTLayout
/*     */   extends Layout
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*     */   private static final String XSLT_NS = "http://www.w3.org/1999/XSL/Transform";
/*     */   private static final String LOG4J_NS = "http://jakarta.apache.org/log4j/";
/* 112 */   private boolean locationInfo = false;
/*     */   
/*     */ 
/*     */ 
/* 116 */   private String mediaType = "text/plain";
/*     */   
/*     */ 
/*     */ 
/*     */   private Charset encoding;
/*     */   
/*     */ 
/*     */ 
/*     */   private SAXTransformerFactory transformerFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   private Templates templates;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ByteArrayOutputStream outputStream;
/*     */   
/*     */ 
/*     */ 
/* 136 */   private boolean ignoresThrowable = false;
/*     */   
/*     */ 
/*     */ 
/* 140 */   private boolean properties = true;
/*     */   
/*     */ 
/*     */ 
/* 144 */   private boolean activated = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final CachedDateFormat utcDateFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XSLTLayout()
/*     */   {
/* 156 */     this.outputStream = new ByteArrayOutputStream();
/* 157 */     this.transformerFactory = ((SAXTransformerFactory)TransformerFactory.newInstance());
/*     */     
/*     */ 
/* 160 */     SimpleDateFormat zdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
/* 161 */     zdf.setTimeZone(TimeZone.getTimeZone("UTC"));
/* 162 */     this.utcDateFormat = new CachedDateFormat(zdf, 1000);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized String getContentType()
/*     */   {
/* 169 */     return this.mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setLocationInfo(boolean flag)
/*     */   {
/* 186 */     this.locationInfo = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean getLocationInfo()
/*     */   {
/* 194 */     return this.locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setProperties(boolean flag)
/*     */   {
/* 202 */     this.properties = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean getProperties()
/*     */   {
/* 210 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void activateOptions()
/*     */   {
/* 216 */     if (this.templates == null) {
/*     */       try {
/* 218 */         InputStream is = XSLTLayout.class.getResourceAsStream("default.xslt");
/* 219 */         StreamSource ss = new StreamSource(is);
/* 220 */         this.templates = this.transformerFactory.newTemplates(ss);
/* 221 */         this.encoding = Charset.forName("US-ASCII");
/* 222 */         this.mediaType = "text/plain";
/*     */       } catch (Exception ex) {
/* 224 */         LogLog.error("Error loading default.xslt", ex);
/*     */       }
/*     */     }
/* 227 */     this.activated = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean ignoresThrowable()
/*     */   {
/* 235 */     return this.ignoresThrowable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setIgnoresThrowable(boolean ignoresThrowable)
/*     */   {
/* 243 */     this.ignoresThrowable = ignoresThrowable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String format(LoggingEvent event)
/*     */   {
/* 252 */     if (!this.activated) {
/* 253 */       activateOptions();
/*     */     }
/* 255 */     if ((this.templates != null) && (this.encoding != null)) {
/* 256 */       this.outputStream.reset();
/*     */       try
/*     */       {
/* 259 */         TransformerHandler transformer = this.transformerFactory.newTransformerHandler(this.templates);
/*     */         
/*     */ 
/* 262 */         transformer.setResult(new StreamResult(this.outputStream));
/* 263 */         transformer.startDocument();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 268 */         AttributesImpl attrs = new AttributesImpl();
/* 269 */         attrs.addAttribute(null, "logger", "logger", "CDATA", event.getLoggerName());
/*     */         
/* 271 */         attrs.addAttribute(null, "timestamp", "timestamp", "CDATA", Long.toString(event.timeStamp));
/*     */         
/* 273 */         attrs.addAttribute(null, "level", "level", "CDATA", event.getLevel().toString());
/*     */         
/* 275 */         attrs.addAttribute(null, "thread", "thread", "CDATA", event.getThreadName());
/*     */         
/* 277 */         StringBuffer buf = new StringBuffer();
/* 278 */         this.utcDateFormat.format(event.timeStamp, buf);
/* 279 */         attrs.addAttribute(null, "time", "time", "CDATA", buf.toString());
/*     */         
/*     */ 
/* 282 */         transformer.startElement("http://jakarta.apache.org/log4j/", "event", "event", attrs);
/* 283 */         attrs.clear();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 288 */         transformer.startElement("http://jakarta.apache.org/log4j/", "message", "message", attrs);
/* 289 */         String msg = event.getRenderedMessage();
/* 290 */         if ((msg != null) && (msg.length() > 0)) {
/* 291 */           transformer.characters(msg.toCharArray(), 0, msg.length());
/*     */         }
/* 293 */         transformer.endElement("http://jakarta.apache.org/log4j/", "message", "message");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 298 */         String ndc = event.getNDC();
/* 299 */         if (ndc != null) {
/* 300 */           transformer.startElement("http://jakarta.apache.org/log4j/", "NDC", "NDC", attrs);
/* 301 */           char[] ndcChars = ndc.toCharArray();
/* 302 */           transformer.characters(ndcChars, 0, ndcChars.length);
/* 303 */           transformer.endElement("http://jakarta.apache.org/log4j/", "NDC", "NDC");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 309 */         if (!this.ignoresThrowable) {
/* 310 */           String[] s = event.getThrowableStrRep();
/* 311 */           if (s != null) {
/* 312 */             transformer.startElement("http://jakarta.apache.org/log4j/", "throwable", "throwable", attrs);
/*     */             
/* 314 */             char[] nl = { '\n' };
/* 315 */             for (int i = 0; i < s.length; i++) {
/* 316 */               char[] line = s[i].toCharArray();
/* 317 */               transformer.characters(line, 0, line.length);
/* 318 */               transformer.characters(nl, 0, nl.length);
/*     */             }
/* 320 */             transformer.endElement("http://jakarta.apache.org/log4j/", "throwable", "throwable");
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 328 */         if (this.locationInfo) {
/* 329 */           LocationInfo locationInfo = event.getLocationInformation();
/* 330 */           attrs.addAttribute(null, "class", "class", "CDATA", locationInfo.getClassName());
/*     */           
/* 332 */           attrs.addAttribute(null, "method", "method", "CDATA", locationInfo.getMethodName());
/*     */           
/* 334 */           attrs.addAttribute(null, "file", "file", "CDATA", locationInfo.getFileName());
/*     */           
/* 336 */           attrs.addAttribute(null, "line", "line", "CDATA", locationInfo.getLineNumber());
/*     */           
/* 338 */           transformer.startElement("http://jakarta.apache.org/log4j/", "locationInfo", "locationInfo", attrs);
/*     */           
/* 340 */           transformer.endElement("http://jakarta.apache.org/log4j/", "locationInfo", "locationInfo");
/*     */         }
/*     */         
/*     */ 
/* 344 */         if (this.properties)
/*     */         {
/*     */ 
/*     */ 
/* 348 */           Set mdcKeySet = MDCKeySetExtractor.INSTANCE.getPropertyKeySet(event);
/*     */           
/* 350 */           if ((mdcKeySet != null) && (mdcKeySet.size() > 0)) {
/* 351 */             attrs.clear();
/* 352 */             transformer.startElement("http://jakarta.apache.org/log4j/", "properties", "properties", attrs);
/*     */             
/* 354 */             Object[] keys = mdcKeySet.toArray();
/* 355 */             Arrays.sort(keys);
/* 356 */             for (int i = 0; i < keys.length; i++) {
/* 357 */               String key = keys[i].toString();
/* 358 */               Object val = event.getMDC(key);
/* 359 */               attrs.clear();
/* 360 */               attrs.addAttribute(null, "name", "name", "CDATA", key);
/* 361 */               attrs.addAttribute(null, "value", "value", "CDATA", val.toString());
/*     */               
/* 363 */               transformer.startElement("http://jakarta.apache.org/log4j/", "data", "data", attrs);
/*     */               
/* 365 */               transformer.endElement("http://jakarta.apache.org/log4j/", "data", "data");
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 371 */         transformer.endElement("http://jakarta.apache.org/log4j/", "event", "event");
/* 372 */         transformer.endDocument();
/*     */         
/* 374 */         String body = this.encoding.decode(ByteBuffer.wrap(this.outputStream.toByteArray())).toString();
/*     */         
/* 376 */         this.outputStream.reset();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 381 */         if (body.startsWith("<?xml ")) {
/* 382 */           int endDecl = body.indexOf("?>");
/* 383 */           if (endDecl != -1) {
/* 384 */             endDecl += 2;
/* 385 */             while ((endDecl < body.length()) && ((body.charAt(endDecl) == '\n') || (body.charAt(endDecl) == '\r')))
/*     */             {
/* 387 */               endDecl++; }
/* 388 */             return body.substring(endDecl);
/*     */           }
/*     */         }
/* 391 */         return body;
/*     */       } catch (Exception ex) {
/* 393 */         LogLog.error("Error during transformation", ex);
/* 394 */         return ex.toString();
/*     */       }
/*     */     }
/* 397 */     return "No valid transform or encoding specified.";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransform(Document xsltdoc)
/*     */     throws TransformerConfigurationException
/*     */   {
/* 413 */     String encodingName = null;
/* 414 */     this.mediaType = null;
/* 415 */     String method = null;
/* 416 */     NodeList nodes = xsltdoc.getElementsByTagNameNS("http://www.w3.org/1999/XSL/Transform", "output");
/*     */     
/*     */ 
/* 419 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 420 */       Element outputElement = (Element)nodes.item(i);
/* 421 */       if ((method == null) || (method.length() == 0)) {
/* 422 */         method = outputElement.getAttributeNS(null, "method");
/*     */       }
/* 424 */       if ((encodingName == null) || (encodingName.length() == 0)) {
/* 425 */         encodingName = outputElement.getAttributeNS(null, "encoding");
/*     */       }
/* 427 */       if ((this.mediaType == null) || (this.mediaType.length() == 0)) {
/* 428 */         this.mediaType = outputElement.getAttributeNS(null, "media-type");
/*     */       }
/*     */     }
/*     */     
/* 432 */     if ((this.mediaType == null) || (this.mediaType.length() == 0)) {
/* 433 */       if ("html".equals(method)) {
/* 434 */         this.mediaType = "text/html";
/* 435 */       } else if ("xml".equals(method)) {
/* 436 */         this.mediaType = "text/xml";
/*     */       } else {
/* 438 */         this.mediaType = "text/plain";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 446 */     if ((encodingName == null) || (encodingName.length() == 0)) {
/* 447 */       Element transformElement = xsltdoc.getDocumentElement();
/* 448 */       Element outputElement = xsltdoc.createElementNS("http://www.w3.org/1999/XSL/Transform", "output");
/*     */       
/* 450 */       outputElement.setAttributeNS(null, "encoding", "US-ASCII");
/* 451 */       transformElement.insertBefore(outputElement, transformElement.getFirstChild());
/* 452 */       this.encoding = Charset.forName("US-ASCII");
/*     */     } else {
/* 454 */       this.encoding = Charset.forName(encodingName);
/*     */     }
/*     */     
/* 457 */     DOMSource transformSource = new DOMSource(xsltdoc);
/*     */     
/* 459 */     this.templates = this.transformerFactory.newTemplates(transformSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 469 */     if (("http://www.w3.org/1999/XSL/Transform".equals(element.getNamespaceURI())) || (element.getNodeName().indexOf("transform") != -1) || (element.getNodeName().indexOf("stylesheet") != -1))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 475 */       ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 476 */       DOMSource source = new DOMSource(element);
/* 477 */       TransformerFactory transformerFactory = TransformerFactory.newInstance();
/* 478 */       Transformer transformer = transformerFactory.newTransformer();
/* 479 */       transformer.transform(source, new StreamResult(os));
/*     */       
/* 481 */       ByteArrayInputStream is = new ByteArrayInputStream(os.toByteArray());
/* 482 */       DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
/* 483 */       domFactory.setNamespaceAware(true);
/* 484 */       Document xsltdoc = domFactory.newDocumentBuilder().parse(is);
/* 485 */       setTransform(xsltdoc);
/* 486 */       return true;
/*     */     }
/* 488 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\extras\XSLTLayout.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */