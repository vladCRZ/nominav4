/*     */ package org.apache.log4j.filter;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.extras.DOMConfigurator;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.OptionHandler;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndFilter
/*     */   extends Filter
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*  76 */   Filter headFilter = null;
/*  77 */   Filter tailFilter = null;
/*  78 */   boolean acceptOnMatch = true;
/*     */   
/*     */   public void activateOptions() {}
/*     */   
/*     */   public void addFilter(Filter filter)
/*     */   {
/*  84 */     if (this.headFilter == null) {
/*  85 */       this.headFilter = filter;
/*  86 */       this.tailFilter = filter;
/*     */     } else {
/*  88 */       this.tailFilter.next = filter;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAcceptOnMatch(boolean acceptOnMatch) {
/*  93 */     this.acceptOnMatch = acceptOnMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int decide(LoggingEvent event)
/*     */   {
/* 105 */     boolean accepted = true;
/* 106 */     Filter f = this.headFilter;
/* 107 */     while (f != null) {
/* 108 */       accepted = (accepted) && (1 == f.decide(event));
/* 109 */       f = f.next;
/*     */     }
/* 111 */     if (accepted) {
/* 112 */       if (this.acceptOnMatch) {
/* 113 */         return 1;
/*     */       }
/* 115 */       return -1;
/*     */     }
/* 117 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 125 */     String nodeName = element.getNodeName();
/* 126 */     if ("filter".equals(nodeName)) {
/* 127 */       OptionHandler filter = DOMConfigurator.parseElement(element, props, Filter.class);
/*     */       
/*     */ 
/* 130 */       if ((filter instanceof Filter)) {
/* 131 */         filter.activateOptions();
/* 132 */         addFilter((Filter)filter);
/*     */       }
/* 134 */       return true;
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\filter\AndFilter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */