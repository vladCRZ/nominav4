/*     */ package org.apache.log4j.filter;
/*     */ 
/*     */ import org.apache.log4j.rule.ExpressionRule;
/*     */ import org.apache.log4j.rule.Rule;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionFilter
/*     */   extends Filter
/*     */ {
/*  77 */   boolean acceptOnMatch = true;
/*     */   
/*     */ 
/*     */ 
/*  81 */   boolean convertInFixToPostFix = true;
/*     */   
/*     */ 
/*     */ 
/*     */   String expression;
/*     */   
/*     */ 
/*     */ 
/*     */   Rule expressionRule;
/*     */   
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/*  95 */     this.expressionRule = ExpressionRule.getRule(this.expression, !this.convertInFixToPostFix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExpression(String exp)
/*     */   {
/* 104 */     this.expression = exp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpression()
/*     */   {
/* 112 */     return this.expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConvertInFixToPostFix(boolean newValue)
/*     */   {
/* 120 */     this.convertInFixToPostFix = newValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getConvertInFixToPostFix()
/*     */   {
/* 128 */     return this.convertInFixToPostFix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAcceptOnMatch(boolean newValue)
/*     */   {
/* 136 */     this.acceptOnMatch = newValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAcceptOnMatch()
/*     */   {
/* 144 */     return this.acceptOnMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int decide(LoggingEvent event)
/*     */   {
/* 153 */     if (this.expressionRule.evaluate(event, null)) {
/* 154 */       if (this.acceptOnMatch) {
/* 155 */         return 1;
/*     */       }
/* 157 */       return -1;
/*     */     }
/*     */     
/* 160 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\filter\ExpressionFilter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */