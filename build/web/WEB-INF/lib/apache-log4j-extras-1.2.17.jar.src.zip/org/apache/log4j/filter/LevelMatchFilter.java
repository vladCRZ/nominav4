/*    */ package org.apache.log4j.filter;
/*    */ 
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.helpers.OptionConverter;
/*    */ import org.apache.log4j.spi.Filter;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LevelMatchFilter
/*    */   extends Filter
/*    */ {
/* 45 */   boolean acceptOnMatch = true;
/*    */   
/*    */   Level levelToMatch;
/*    */   
/*    */ 
/*    */   public void setLevelToMatch(String level)
/*    */   {
/* 52 */     this.levelToMatch = OptionConverter.toLevel(level, null);
/*    */   }
/*    */   
/*    */   public String getLevelToMatch() {
/* 56 */     return this.levelToMatch == null ? null : this.levelToMatch.toString();
/*    */   }
/*    */   
/*    */   public void setAcceptOnMatch(boolean acceptOnMatch) {
/* 60 */     this.acceptOnMatch = acceptOnMatch;
/*    */   }
/*    */   
/*    */   public boolean getAcceptOnMatch() {
/* 64 */     return this.acceptOnMatch;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int decide(LoggingEvent event)
/*    */   {
/* 80 */     if (this.levelToMatch == null) {
/* 81 */       return 0;
/*    */     }
/*    */     
/* 84 */     boolean matchOccured = false;
/*    */     
/* 86 */     if (this.levelToMatch.equals(event.getLevel())) {
/* 87 */       matchOccured = true;
/*    */     }
/*    */     
/* 90 */     if (matchOccured) {
/* 91 */       if (this.acceptOnMatch) {
/* 92 */         return 1;
/*    */       }
/* 94 */       return -1;
/*    */     }
/*    */     
/* 97 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\filter\LevelMatchFilter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */