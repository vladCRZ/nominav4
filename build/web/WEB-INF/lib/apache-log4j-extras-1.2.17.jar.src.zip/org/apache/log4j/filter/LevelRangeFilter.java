/*     */ package org.apache.log4j.filter;
/*     */ 
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LevelRangeFilter
/*     */   extends Filter
/*     */ {
/*  58 */   boolean acceptOnMatch = false;
/*     */   
/*     */ 
/*     */   Level levelMin;
/*     */   
/*     */ 
/*     */   Level levelMax;
/*     */   
/*     */ 
/*     */   public int decide(LoggingEvent event)
/*     */   {
/*  69 */     if ((this.levelMin != null) && (!event.getLevel().isGreaterOrEqual(this.levelMin)))
/*     */     {
/*     */ 
/*  72 */       return -1;
/*     */     }
/*     */     
/*  75 */     if ((this.levelMax != null) && (event.getLevel().toInt() > this.levelMax.toInt()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */       return -1;
/*     */     }
/*     */     
/*  84 */     if (this.acceptOnMatch)
/*     */     {
/*     */ 
/*  87 */       return 1;
/*     */     }
/*     */     
/*     */ 
/*  91 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Level getLevelMax()
/*     */   {
/*  99 */     return this.levelMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Level getLevelMin()
/*     */   {
/* 107 */     return this.levelMin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAcceptOnMatch()
/*     */   {
/* 115 */     return this.acceptOnMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLevelMax(Level levelMax)
/*     */   {
/* 123 */     this.levelMax = levelMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLevelMin(Level levelMin)
/*     */   {
/* 131 */     this.levelMin = levelMin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAcceptOnMatch(boolean acceptOnMatch)
/*     */   {
/* 139 */     this.acceptOnMatch = acceptOnMatch;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\filter\LevelRangeFilter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */