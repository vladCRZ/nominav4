/*     */ package org.apache.log4j.filter;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TimeFilter
/*     */   extends Filter
/*     */ {
/*     */   private boolean acceptOnMatch;
/*     */   private long start;
/*     */   private long end;
/*     */   private Calendar calendar;
/*     */   private static final long HOUR_MS = 3600000L;
/*     */   private static final long MINUTE_MS = 60000L;
/*     */   private static final long SECOND_MS = 1000L;
/*     */   
/*     */   public TimeFilter()
/*     */   {
/*  70 */     this.acceptOnMatch = true;
/*  71 */     this.start = 0L;
/*  72 */     this.end = Long.MAX_VALUE;
/*  73 */     this.calendar = Calendar.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStart(String s)
/*     */   {
/*  81 */     SimpleDateFormat stf = new SimpleDateFormat("HH:mm:ss");
/*  82 */     stf.setTimeZone(TimeZone.getTimeZone("UTC"));
/*     */     try {
/*  84 */       this.start = stf.parse(s).getTime();
/*     */     } catch (ParseException ex) {
/*  86 */       LogLog.warn("Error parsing start value " + s, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnd(String s)
/*     */   {
/*  95 */     SimpleDateFormat stf = new SimpleDateFormat("HH:mm:ss");
/*  96 */     stf.setTimeZone(TimeZone.getTimeZone("UTC"));
/*     */     try {
/*  98 */       this.end = stf.parse(s).getTime();
/*     */     } catch (ParseException ex) {
/* 100 */       LogLog.warn("Error parsing end value " + s, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeZone(String s)
/*     */   {
/* 109 */     if (s == null) {
/* 110 */       this.calendar = Calendar.getInstance();
/*     */     } else {
/* 112 */       this.calendar = Calendar.getInstance(TimeZone.getTimeZone(s));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setAcceptOnMatch(boolean acceptOnMatch)
/*     */   {
/* 121 */     this.acceptOnMatch = acceptOnMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean getAcceptOnMatch()
/*     */   {
/* 129 */     return this.acceptOnMatch;
/*     */   }
/*     */   
/*     */   public int decide(LoggingEvent event)
/*     */   {
/* 134 */     this.calendar.setTimeInMillis(event.timeStamp);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 139 */     long apparentOffset = this.calendar.get(11) * 3600000L + this.calendar.get(12) * 60000L + this.calendar.get(13) * 1000L + this.calendar.get(14);
/*     */     
/*     */ 
/*     */ 
/* 143 */     if ((apparentOffset >= this.start) && (apparentOffset < this.end)) {
/* 144 */       if (this.acceptOnMatch) {
/* 145 */         return 1;
/*     */       }
/* 147 */       return -1;
/*     */     }
/*     */     
/* 150 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\filter\TimeFilter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */