/*     */ package org.apache.log4j.pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtrasFormattingInfo
/*     */ {
/*  35 */   private static final char[] SPACES = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  41 */   private static final ExtrasFormattingInfo DEFAULT = new ExtrasFormattingInfo(false, 0, Integer.MAX_VALUE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int minLength;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int maxLength;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean leftAlign;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean rightTruncate;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public ExtrasFormattingInfo(boolean leftAlign, int minLength, int maxLength)
/*     */   {
/*  76 */     this.leftAlign = leftAlign;
/*  77 */     this.minLength = minLength;
/*  78 */     this.maxLength = maxLength;
/*  79 */     this.rightTruncate = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtrasFormattingInfo(boolean leftAlign, boolean rightTruncate, int minLength, int maxLength)
/*     */   {
/*  95 */     this.leftAlign = leftAlign;
/*  96 */     this.minLength = minLength;
/*  97 */     this.maxLength = maxLength;
/*  98 */     this.rightTruncate = rightTruncate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExtrasFormattingInfo getDefault()
/*     */   {
/* 106 */     return DEFAULT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeftAligned()
/*     */   {
/* 114 */     return this.leftAlign;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRightTruncated()
/*     */   {
/* 123 */     return this.rightTruncate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinLength()
/*     */   {
/* 131 */     return this.minLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxLength()
/*     */   {
/* 139 */     return this.maxLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void format(int fieldStart, StringBuffer buffer)
/*     */   {
/* 149 */     int rawLength = buffer.length() - fieldStart;
/*     */     
/* 151 */     if (rawLength > this.maxLength) {
/* 152 */       if (this.rightTruncate) {
/* 153 */         buffer.setLength(fieldStart + this.maxLength);
/*     */       } else {
/* 155 */         buffer.delete(fieldStart, buffer.length() - this.maxLength);
/*     */       }
/* 157 */     } else if (rawLength < this.minLength) {
/* 158 */       if (this.leftAlign) {
/* 159 */         int fieldEnd = buffer.length();
/* 160 */         buffer.setLength(fieldStart + this.minLength);
/*     */         
/* 162 */         for (int i = fieldEnd; i < buffer.length(); i++) {
/* 163 */           buffer.setCharAt(i, ' ');
/*     */         }
/*     */       } else {
/* 166 */         for (int padLength = this.minLength - rawLength; 
/*     */             
/* 168 */             padLength > 8; padLength -= 8) {
/* 169 */           buffer.insert(fieldStart, SPACES);
/*     */         }
/*     */         
/* 172 */         buffer.insert(fieldStart, SPACES, 0, padLength);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\pattern\ExtrasFormattingInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */