/*     */ package org.apache.log4j.pattern;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.helpers.Loader;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtrasPatternParser
/*     */ {
/*     */   private static final char ESCAPE_CHAR = '%';
/*     */   private static final int LITERAL_STATE = 0;
/*     */   private static final int CONVERTER_STATE = 1;
/*     */   private static final int DOT_STATE = 3;
/*     */   private static final int MIN_STATE = 4;
/*     */   private static final int MAX_STATE = 5;
/*     */   private static final Map PATTERN_LAYOUT_RULES;
/*     */   private static final Map FILENAME_PATTERN_RULES;
/*     */   
/*     */   static
/*     */   {
/*  91 */     Map rules = new HashMap(17);
/*  92 */     rules.put("c", LoggerPatternConverter.class);
/*  93 */     rules.put("logger", LoggerPatternConverter.class);
/*     */     
/*  95 */     rules.put("C", ClassNamePatternConverter.class);
/*  96 */     rules.put("class", ClassNamePatternConverter.class);
/*     */     
/*  98 */     rules.put("d", DatePatternConverter.class);
/*  99 */     rules.put("date", DatePatternConverter.class);
/*     */     
/* 101 */     rules.put("F", FileLocationPatternConverter.class);
/* 102 */     rules.put("file", FileLocationPatternConverter.class);
/*     */     
/* 104 */     rules.put("l", FullLocationPatternConverter.class);
/*     */     
/* 106 */     rules.put("L", LineLocationPatternConverter.class);
/* 107 */     rules.put("line", LineLocationPatternConverter.class);
/*     */     
/* 109 */     rules.put("m", MessagePatternConverter.class);
/* 110 */     rules.put("message", MessagePatternConverter.class);
/*     */     
/* 112 */     rules.put("n", LineSeparatorPatternConverter.class);
/*     */     
/* 114 */     rules.put("M", MethodLocationPatternConverter.class);
/* 115 */     rules.put("method", MethodLocationPatternConverter.class);
/*     */     
/* 117 */     rules.put("p", LevelPatternConverter.class);
/* 118 */     rules.put("level", LevelPatternConverter.class);
/*     */     
/* 120 */     rules.put("r", RelativeTimePatternConverter.class);
/* 121 */     rules.put("relative", RelativeTimePatternConverter.class);
/*     */     
/* 123 */     rules.put("t", ThreadPatternConverter.class);
/* 124 */     rules.put("thread", ThreadPatternConverter.class);
/*     */     
/* 126 */     rules.put("x", NDCPatternConverter.class);
/* 127 */     rules.put("ndc", NDCPatternConverter.class);
/*     */     
/* 129 */     rules.put("X", PropertiesPatternConverter.class);
/* 130 */     rules.put("properties", PropertiesPatternConverter.class);
/*     */     
/* 132 */     rules.put("sn", SequenceNumberPatternConverter.class);
/* 133 */     rules.put("sequenceNumber", SequenceNumberPatternConverter.class);
/*     */     
/* 135 */     rules.put("throwable", ThrowableInformationPatternConverter.class);
/* 136 */     PATTERN_LAYOUT_RULES = new ReadOnlyMap(rules);
/*     */     
/* 138 */     Map fnameRules = new HashMap(4);
/* 139 */     fnameRules.put("d", FileDatePatternConverter.class);
/* 140 */     fnameRules.put("date", FileDatePatternConverter.class);
/* 141 */     fnameRules.put("i", IntegerPatternConverter.class);
/* 142 */     fnameRules.put("index", IntegerPatternConverter.class);
/*     */     
/* 144 */     FILENAME_PATTERN_RULES = new ReadOnlyMap(fnameRules);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map getPatternLayoutRules()
/*     */   {
/* 158 */     return PATTERN_LAYOUT_RULES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map getFileNamePatternRules()
/*     */   {
/* 166 */     return FILENAME_PATTERN_RULES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int extractConverter(char lastChar, String pattern, int i, StringBuffer convBuf, StringBuffer currentLiteral)
/*     */   {
/* 187 */     convBuf.setLength(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */     if (!Character.isUnicodeIdentifierStart(lastChar)) {
/* 195 */       return i;
/*     */     }
/*     */     
/* 198 */     convBuf.append(lastChar);
/*     */     
/*     */ 
/*     */ 
/* 202 */     while ((i < pattern.length()) && (Character.isUnicodeIdentifierPart(pattern.charAt(i)))) {
/* 203 */       convBuf.append(pattern.charAt(i));
/* 204 */       currentLiteral.append(pattern.charAt(i));
/*     */       
/*     */ 
/* 207 */       i++;
/*     */     }
/*     */     
/* 210 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int extractOptions(String pattern, int i, List options)
/*     */   {
/* 221 */     while ((i < pattern.length()) && (pattern.charAt(i) == '{')) {
/* 222 */       int end = pattern.indexOf('}', i);
/*     */       
/* 224 */       if (end == -1) {
/*     */         break;
/*     */       }
/*     */       
/* 228 */       String r = pattern.substring(i + 1, end);
/* 229 */       options.add(r);
/* 230 */       i = end + 1;
/*     */     }
/*     */     
/* 233 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parse(String pattern, List patternConverters, List formattingInfos, Map converterRegistry, Map rules)
/*     */   {
/* 247 */     if (pattern == null) {
/* 248 */       throw new NullPointerException("pattern");
/*     */     }
/*     */     
/* 251 */     StringBuffer currentLiteral = new StringBuffer(32);
/*     */     
/* 253 */     int patternLength = pattern.length();
/* 254 */     int state = 0;
/*     */     
/* 256 */     int i = 0;
/* 257 */     ExtrasFormattingInfo formattingInfo = ExtrasFormattingInfo.getDefault();
/*     */     
/* 259 */     while (i < patternLength) {
/* 260 */       char c = pattern.charAt(i++);
/*     */       
/* 262 */       switch (state)
/*     */       {
/*     */ 
/*     */       case 0: 
/* 266 */         if (i == patternLength) {
/* 267 */           currentLiteral.append(c);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 272 */         else if (c == '%')
/*     */         {
/* 274 */           switch (pattern.charAt(i)) {
/*     */           case '%': 
/* 276 */             currentLiteral.append(c);
/* 277 */             i++;
/*     */             
/* 279 */             break;
/*     */           
/*     */ 
/*     */           default: 
/* 283 */             if (currentLiteral.length() != 0) {
/* 284 */               patternConverters.add(new LiteralPatternConverter(currentLiteral.toString()));
/*     */               
/* 286 */               formattingInfos.add(ExtrasFormattingInfo.getDefault());
/*     */             }
/*     */             
/* 289 */             currentLiteral.setLength(0);
/* 290 */             currentLiteral.append(c);
/* 291 */             state = 1;
/* 292 */             formattingInfo = ExtrasFormattingInfo.getDefault();break;
/*     */           }
/*     */         } else {
/* 295 */           currentLiteral.append(c);
/*     */         }
/*     */         
/* 298 */         break;
/*     */       
/*     */       case 1: 
/* 301 */         currentLiteral.append(c);
/*     */         
/* 303 */         switch (c) {
/*     */         case '-': 
/* 305 */           formattingInfo = new ExtrasFormattingInfo(true, formattingInfo.isRightTruncated(), formattingInfo.getMinLength(), formattingInfo.getMaxLength());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 311 */           break;
/*     */         
/*     */         case '!': 
/* 314 */           formattingInfo = new ExtrasFormattingInfo(formattingInfo.isLeftAligned(), true, formattingInfo.getMinLength(), formattingInfo.getMaxLength());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 320 */           break;
/*     */         
/*     */ 
/*     */         case '.': 
/* 324 */           state = 3;
/*     */           
/* 326 */           break;
/*     */         
/*     */ 
/*     */         default: 
/* 330 */           if ((c >= '0') && (c <= '9')) {
/* 331 */             formattingInfo = new ExtrasFormattingInfo(formattingInfo.isLeftAligned(), formattingInfo.isRightTruncated(), c - '0', formattingInfo.getMaxLength());
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 337 */             state = 4;
/*     */           } else {
/* 339 */             i = finalizeConverter(c, pattern, i, currentLiteral, formattingInfo, converterRegistry, rules, patternConverters, formattingInfos);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 344 */             state = 0;
/* 345 */             formattingInfo = ExtrasFormattingInfo.getDefault();
/* 346 */             currentLiteral.setLength(0);
/*     */           }
/*     */           break;
/*     */         }
/* 350 */         break;
/*     */       
/*     */       case 4: 
/* 353 */         currentLiteral.append(c);
/*     */         
/* 355 */         if ((c >= '0') && (c <= '9')) {
/* 356 */           formattingInfo = new ExtrasFormattingInfo(formattingInfo.isLeftAligned(), formattingInfo.isRightTruncated(), formattingInfo.getMinLength() * 10 + (c - '0'), formattingInfo.getMaxLength());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 362 */         else if (c == '.') {
/* 363 */           state = 3;
/*     */         } else {
/* 365 */           i = finalizeConverter(c, pattern, i, currentLiteral, formattingInfo, converterRegistry, rules, patternConverters, formattingInfos);
/*     */           
/*     */ 
/* 368 */           state = 0;
/* 369 */           formattingInfo = ExtrasFormattingInfo.getDefault();
/* 370 */           currentLiteral.setLength(0);
/*     */         }
/*     */         
/* 373 */         break;
/*     */       
/*     */       case 3: 
/* 376 */         currentLiteral.append(c);
/*     */         
/* 378 */         if ((c >= '0') && (c <= '9')) {
/* 379 */           formattingInfo = new ExtrasFormattingInfo(formattingInfo.isLeftAligned(), formattingInfo.isRightTruncated(), formattingInfo.getMinLength(), c - '0');
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 385 */           state = 5;
/*     */         } else {
/* 387 */           LogLog.error("Error occured in position " + i + ".\n Was expecting digit, instead got char \"" + c + "\".");
/*     */           
/*     */ 
/*     */ 
/* 391 */           state = 0;
/*     */         }
/*     */         
/* 394 */         break;
/*     */       
/*     */       case 5: 
/* 397 */         currentLiteral.append(c);
/*     */         
/* 399 */         if ((c >= '0') && (c <= '9')) {
/* 400 */           formattingInfo = new ExtrasFormattingInfo(formattingInfo.isLeftAligned(), formattingInfo.isRightTruncated(), formattingInfo.getMinLength(), formattingInfo.getMaxLength() * 10 + (c - '0'));
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 407 */           i = finalizeConverter(c, pattern, i, currentLiteral, formattingInfo, converterRegistry, rules, patternConverters, formattingInfos);
/*     */           
/*     */ 
/* 410 */           state = 0;
/* 411 */           formattingInfo = ExtrasFormattingInfo.getDefault();
/* 412 */           currentLiteral.setLength(0);
/*     */         }
/*     */         
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 420 */     if (currentLiteral.length() != 0) {
/* 421 */       patternConverters.add(new LiteralPatternConverter(currentLiteral.toString()));
/*     */       
/* 423 */       formattingInfos.add(ExtrasFormattingInfo.getDefault());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static PatternConverter createConverter(String converterId, StringBuffer currentLiteral, Map converterRegistry, Map rules, List options)
/*     */   {
/* 442 */     String converterName = converterId;
/* 443 */     Object converterObj = null;
/*     */     
/* 445 */     for (int i = converterId.length(); (i > 0) && (converterObj == null); 
/* 446 */         i--) {
/* 447 */       converterName = converterName.substring(0, i);
/*     */       
/* 449 */       if (converterRegistry != null) {
/* 450 */         converterObj = converterRegistry.get(converterName);
/*     */       }
/*     */       
/* 453 */       if ((converterObj == null) && (rules != null)) {
/* 454 */         converterObj = rules.get(converterName);
/*     */       }
/*     */     }
/*     */     
/* 458 */     if (converterObj == null) {
/* 459 */       LogLog.error("Unrecognized format specifier [" + converterId + "]");
/*     */       
/* 461 */       return null;
/*     */     }
/*     */     
/*     */     Class converterClass;
/*     */     Class converterClass;
/* 466 */     if ((converterObj instanceof Class)) {
/* 467 */       converterClass = (Class)converterObj;
/*     */     }
/* 469 */     else if ((converterObj instanceof String)) {
/*     */       try {
/* 471 */         converterClass = Loader.loadClass((String)converterObj);
/*     */       } catch (ClassNotFoundException ex) {
/* 473 */         LogLog.warn("Class for conversion pattern %" + converterName + " not found", ex);
/*     */         
/*     */ 
/*     */ 
/* 477 */         return null;
/*     */       }
/*     */     } else {
/* 480 */       LogLog.warn("Bad map entry for conversion pattern %" + converterName + ".");
/*     */       
/*     */ 
/* 483 */       return null;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 488 */       Method factory = converterClass.getMethod("newInstance", new Class[] { Class.forName("[Ljava.lang.String;") });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 494 */       String[] optionsArray = new String[options.size()];
/* 495 */       optionsArray = (String[])options.toArray(optionsArray);
/*     */       
/* 497 */       Object newObj = factory.invoke(null, new Object[] { optionsArray });
/*     */       
/*     */ 
/* 500 */       if ((newObj instanceof PatternConverter)) {
/* 501 */         currentLiteral.delete(0, currentLiteral.length() - (converterId.length() - converterName.length()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 506 */         return (PatternConverter)newObj;
/*     */       }
/* 508 */       LogLog.warn("Class " + converterClass.getName() + " does not extend PatternConverter.");
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 513 */       LogLog.error("Error creating converter for " + converterId, ex);
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 518 */         PatternConverter pc = (PatternConverter)converterClass.newInstance();
/* 519 */         currentLiteral.delete(0, currentLiteral.length() - (converterId.length() - converterName.length()));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 524 */         return pc;
/*     */       } catch (Exception ex2) {
/* 526 */         LogLog.error("Error creating converter for " + converterId, ex2);
/*     */       }
/*     */     }
/*     */     
/* 530 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int finalizeConverter(char c, String pattern, int i, StringBuffer currentLiteral, ExtrasFormattingInfo formattingInfo, Map converterRegistry, Map rules, List patternConverters, List formattingInfos)
/*     */   {
/* 552 */     StringBuffer convBuf = new StringBuffer();
/* 553 */     i = extractConverter(c, pattern, i, convBuf, currentLiteral);
/*     */     
/* 555 */     String converterId = convBuf.toString();
/*     */     
/* 557 */     List options = new ArrayList();
/* 558 */     i = extractOptions(pattern, i, options);
/*     */     
/* 560 */     PatternConverter pc = createConverter(converterId, currentLiteral, converterRegistry, rules, options);
/*     */     
/*     */ 
/*     */ 
/* 564 */     if (pc == null) {
/*     */       StringBuffer msg;
/*     */       StringBuffer msg;
/* 567 */       if (converterId.length() == 0) {
/* 568 */         msg = new StringBuffer("Empty conversion specifier starting at position ");
/*     */       }
/*     */       else {
/* 571 */         msg = new StringBuffer("Unrecognized conversion specifier [");
/* 572 */         msg.append(converterId);
/* 573 */         msg.append("] starting at position ");
/*     */       }
/*     */       
/* 576 */       msg.append(Integer.toString(i));
/* 577 */       msg.append(" in conversion pattern.");
/*     */       
/* 579 */       LogLog.error(msg.toString());
/*     */       
/* 581 */       patternConverters.add(new LiteralPatternConverter(currentLiteral.toString()));
/*     */       
/* 583 */       formattingInfos.add(ExtrasFormattingInfo.getDefault());
/*     */     } else {
/* 585 */       patternConverters.add(pc);
/* 586 */       formattingInfos.add(formattingInfo);
/*     */       
/* 588 */       if (currentLiteral.length() > 0) {
/* 589 */         patternConverters.add(new LiteralPatternConverter(currentLiteral.toString()));
/*     */         
/* 591 */         formattingInfos.add(ExtrasFormattingInfo.getDefault());
/*     */       }
/*     */     }
/*     */     
/* 595 */     currentLiteral.setLength(0);
/*     */     
/* 597 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ReadOnlyMap
/*     */     implements Map
/*     */   {
/*     */     private final Map map;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public ReadOnlyMap(Map src)
/*     */     {
/* 614 */       this.map = src;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void clear()
/*     */     {
/* 621 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean containsKey(Object key)
/*     */     {
/* 628 */       return this.map.containsKey(key);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean containsValue(Object value)
/*     */     {
/* 635 */       return this.map.containsValue(value);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Set entrySet()
/*     */     {
/* 642 */       return this.map.entrySet();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object get(Object key)
/*     */     {
/* 649 */       return this.map.get(key);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 656 */       return this.map.isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Set keySet()
/*     */     {
/* 663 */       return this.map.keySet();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object put(Object key, Object value)
/*     */     {
/* 670 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void putAll(Map t)
/*     */     {
/* 677 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object remove(Object key)
/*     */     {
/* 684 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int size()
/*     */     {
/* 691 */       return this.map.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Collection values()
/*     */     {
/* 698 */       return this.map.values();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\pattern\ExtrasPatternParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */