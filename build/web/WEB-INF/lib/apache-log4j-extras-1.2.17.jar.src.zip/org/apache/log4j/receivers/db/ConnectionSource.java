package org.apache.log4j.receivers.db;

import java.sql.Connection;
import java.sql.SQLException;
import org.apache.log4j.component.spi.Component;
import org.apache.log4j.spi.OptionHandler;

public abstract interface ConnectionSource
  extends Component, OptionHandler
{
  public static final int UNKNOWN_DIALECT = 0;
  public static final int POSTGRES_DIALECT = 1;
  public static final int MYSQL_DIALECT = 2;
  public static final int ORACLE_DIALECT = 3;
  public static final int MSSQL_DIALECT = 4;
  public static final int HSQL_DIALECT = 5;
  
  public abstract Connection getConnection()
    throws SQLException;
  
  public abstract int getSQLDialectCode();
  
  public abstract boolean supportsGetGeneratedKeys();
  
  public abstract boolean supportsBatchUpdates();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\ConnectionSource.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */