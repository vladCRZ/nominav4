/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.spi.ComponentBase;
/*     */ import org.apache.log4j.receivers.db.dialect.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConnectionSourceSkeleton
/*     */   extends ComponentBase
/*     */   implements ConnectionSource
/*     */ {
/*  34 */   private Boolean overriddenSupportsGetGeneratedKeys = null;
/*     */   
/*  36 */   private String user = null;
/*  37 */   private String password = null;
/*     */   
/*     */ 
/*  40 */   private int dialectCode = 0;
/*  41 */   private boolean supportsGetGeneratedKeys = false;
/*  42 */   private boolean supportsBatchUpdates = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void discoverConnnectionProperties()
/*     */   {
/*  50 */     Connection connection = null;
/*     */     try {
/*  52 */       connection = getConnection();
/*  53 */       if (connection == null) {
/*  54 */         getLogger().warn("Could not get a conneciton");
/*     */       }
/*     */       else {
/*  57 */         DatabaseMetaData meta = connection.getMetaData();
/*  58 */         Util util = new Util();
/*  59 */         util.setLoggerRepository(this.repository);
/*  60 */         if (this.overriddenSupportsGetGeneratedKeys != null) {
/*  61 */           this.supportsGetGeneratedKeys = this.overriddenSupportsGetGeneratedKeys.booleanValue();
/*     */         }
/*     */         else {
/*  64 */           this.supportsGetGeneratedKeys = util.supportsGetGeneratedKeys(meta);
/*     */         }
/*  66 */         this.supportsBatchUpdates = util.supportsBatchUpdates(meta);
/*  67 */         this.dialectCode = Util.discoverSQLDialect(meta);
/*     */       }
/*  69 */     } catch (SQLException se) { getLogger().warn("Could not discover the dialect to use.", se);
/*     */     } finally {
/*  71 */       DBHelper.closeConnection(connection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean supportsGetGeneratedKeys()
/*     */   {
/*  79 */     return this.supportsGetGeneratedKeys;
/*     */   }
/*     */   
/*     */   public final int getSQLDialectCode() {
/*  83 */     return this.dialectCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getPassword()
/*     */   {
/*  90 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setPassword(String password)
/*     */   {
/*  98 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getUser()
/*     */   {
/* 105 */     return this.user;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setUser(String username)
/*     */   {
/* 113 */     this.user = username;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOverriddenSupportsGetGeneratedKeys()
/*     */   {
/* 125 */     return this.overriddenSupportsGetGeneratedKeys != null ? this.overriddenSupportsGetGeneratedKeys.toString() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOverriddenSupportsGetGeneratedKeys(String overriddenSupportsGetGeneratedKeys)
/*     */   {
/* 141 */     this.overriddenSupportsGetGeneratedKeys = Boolean.valueOf(overriddenSupportsGetGeneratedKeys);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean supportsBatchUpdates()
/*     */   {
/* 149 */     return this.supportsBatchUpdates;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\ConnectionSourceSkeleton.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */