/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.component.scheduler.Job;
/*     */ import org.apache.log4j.component.scheduler.Scheduler;
/*     */ import org.apache.log4j.component.spi.LoggerRepositoryEx;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.ThrowableInformation;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomSQLDBReceiver
/*     */   extends Receiver
/*     */   implements Pauseable, UnrecognizedElementHandler
/*     */ {
/*     */   protected volatile Connection connection;
/*     */   protected String sqlStatement;
/* 146 */   static int DEFAULT_REFRESH_MILLIS = 1000;
/*     */   int refreshMillis;
/*     */   protected String idField;
/*     */   int lastID;
/*     */   private static final String WHERE_CLAUSE = " WHERE ";
/*     */   private static final String AND_CLAUSE = " AND ";
/*     */   private boolean whereExists;
/*     */   private boolean paused;
/*     */   private ConnectionSource connectionSource;
/*     */   public static final String LOG4J_ID_KEY = "log4jid";
/*     */   private CustomReceiverJob customReceiverJob;
/*     */   
/*     */   public CustomSQLDBReceiver()
/*     */   {
/* 137 */     this.connection = null;
/*     */     
/* 139 */     this.sqlStatement = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */     this.refreshMillis = DEFAULT_REFRESH_MILLIS;
/*     */     
/* 150 */     this.idField = null;
/*     */     
/* 152 */     this.lastID = -1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */     this.whereExists = false;
/*     */     
/* 160 */     this.paused = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 170 */     if (this.connectionSource == null) {
/* 171 */       throw new IllegalStateException("CustomSQLDBReceiver cannot function without a connection source");
/*     */     }
/*     */     
/* 174 */     this.whereExists = (this.sqlStatement.toUpperCase().indexOf(" WHERE ") > -1);
/*     */     
/* 176 */     this.customReceiverJob = new CustomReceiverJob();
/*     */     
/* 178 */     if (this.repository == null) {
/* 179 */       throw new IllegalStateException("CustomSQLDBReceiver cannot function without a reference to its owning repository");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 185 */     if ((this.repository instanceof LoggerRepositoryEx)) {
/* 186 */       Scheduler scheduler = ((LoggerRepositoryEx)this.repository).getScheduler();
/*     */       
/* 188 */       scheduler.schedule(this.customReceiverJob, System.currentTimeMillis() + 500L, this.refreshMillis);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void closeConnection()
/*     */   {
/* 195 */     if (this.connection != null) {
/*     */       try
/*     */       {
/* 198 */         this.connection.close();
/*     */       }
/*     */       catch (SQLException sqle) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRefreshMillis(int refreshMillis)
/*     */   {
/* 206 */     this.refreshMillis = refreshMillis;
/*     */   }
/*     */   
/*     */   public int getRefreshMillis() {
/* 210 */     return this.refreshMillis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ConnectionSource getConnectionSource()
/*     */   {
/* 217 */     return this.connectionSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionSource(ConnectionSource connectionSource)
/*     */   {
/* 225 */     this.connectionSource = connectionSource;
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 230 */       if ((this.connection != null) && (!this.connection.isClosed())) {
/* 231 */         this.connection.close();
/*     */       }
/*     */     } catch (SQLException e) {
/* 234 */       e.printStackTrace();
/*     */     } finally {
/* 236 */       this.connection = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void finalize() throws Throwable {
/* 241 */     super.finalize();
/* 242 */     close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 251 */     getLogger().info("removing receiverJob from the Scheduler.");
/*     */     
/* 253 */     if ((this.repository instanceof LoggerRepositoryEx)) {
/* 254 */       Scheduler scheduler = ((LoggerRepositoryEx)this.repository).getScheduler();
/* 255 */       scheduler.delete(this.customReceiverJob);
/*     */     }
/*     */     
/* 258 */     this.lastID = -1;
/*     */   }
/*     */   
/*     */   public void setSql(String s) {
/* 262 */     this.sqlStatement = s;
/*     */   }
/*     */   
/*     */   public String getSql() {
/* 266 */     return this.sqlStatement;
/*     */   }
/*     */   
/*     */   public void setIDField(String id) {
/* 270 */     this.idField = id;
/*     */   }
/*     */   
/*     */   public String getIDField() {
/* 274 */     return this.idField;
/*     */   }
/*     */   
/*     */   public synchronized void setPaused(boolean p) {
/* 278 */     this.paused = p;
/*     */   }
/*     */   
/*     */ 
/* 282 */   public synchronized boolean isPaused() { return this.paused; }
/*     */   
/*     */   class CustomReceiverJob implements Job {
/*     */     CustomReceiverJob() {}
/*     */     
/* 287 */     public void execute() { int oldLastID = CustomSQLDBReceiver.this.lastID;
/*     */       try {
/* 289 */         CustomSQLDBReceiver.this.connection = CustomSQLDBReceiver.this.connectionSource.getConnection();
/* 290 */         Statement statement = CustomSQLDBReceiver.this.connection.createStatement();
/*     */         
/* 292 */         Logger eventLogger = null;
/* 293 */         long timeStamp = 0L;
/* 294 */         String level = null;
/* 295 */         String threadName = null;
/* 296 */         Object message = null;
/* 297 */         String ndc = null;
/* 298 */         Hashtable mdc = null;
/* 299 */         String[] throwable = null;
/* 300 */         String className = null;
/* 301 */         String methodName = null;
/* 302 */         String fileName = null;
/* 303 */         String lineNumber = null;
/* 304 */         Hashtable properties = null;
/*     */         
/* 306 */         String currentSQLStatement = CustomSQLDBReceiver.this.sqlStatement;
/* 307 */         if (CustomSQLDBReceiver.this.whereExists) {
/* 308 */           currentSQLStatement = CustomSQLDBReceiver.this.sqlStatement + " AND " + CustomSQLDBReceiver.this.idField + " > " + CustomSQLDBReceiver.this.lastID;
/*     */         }
/*     */         else {
/* 311 */           currentSQLStatement = CustomSQLDBReceiver.this.sqlStatement + " WHERE " + CustomSQLDBReceiver.this.idField + " > " + CustomSQLDBReceiver.this.lastID;
/*     */         }
/*     */         
/*     */ 
/* 315 */         ResultSet rs = statement.executeQuery(currentSQLStatement);
/*     */         
/* 317 */         int i = 0;
/* 318 */         while (rs.next())
/*     */         {
/* 320 */           i++; if (i == 1000) {
/* 321 */             synchronized (this)
/*     */             {
/*     */               try {
/* 324 */                 wait(300L);
/*     */               }
/*     */               catch (InterruptedException ie) {}
/* 327 */               i = 0;
/*     */             }
/*     */           }
/* 330 */           eventLogger = Logger.getLogger(rs.getString("LOGGER"));
/* 331 */           timeStamp = rs.getTimestamp("TIMESTAMP").getTime();
/*     */           
/* 333 */           level = rs.getString("LEVEL");
/* 334 */           threadName = rs.getString("THREAD");
/* 335 */           message = rs.getString("MESSAGE");
/* 336 */           ndc = rs.getString("NDC");
/*     */           
/* 338 */           String mdcString = rs.getString("MDC");
/* 339 */           mdc = new Hashtable();
/*     */           
/* 341 */           if (mdcString != null)
/*     */           {
/*     */ 
/*     */ 
/* 345 */             if ((mdcString.indexOf("{{") > -1) && (mdcString.indexOf("}}") > -1))
/*     */             {
/* 347 */               mdcString = mdcString.substring(mdcString.indexOf("{{") + 2, mdcString.indexOf("}}"));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 352 */             StringTokenizer tok = new StringTokenizer(mdcString, ",");
/*     */             
/*     */ 
/* 355 */             while (tok.countTokens() > 1) {
/* 356 */               mdc.put(tok.nextToken(), tok.nextToken());
/*     */             }
/*     */           }
/*     */           
/* 360 */           throwable = new String[] { rs.getString("THROWABLE") };
/* 361 */           className = rs.getString("CLASS");
/* 362 */           methodName = rs.getString("METHOD");
/* 363 */           fileName = rs.getString("FILE");
/* 364 */           lineNumber = rs.getString("LINE");
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 372 */           String propertiesString = rs.getString("PROPERTIES");
/* 373 */           properties = new Hashtable();
/*     */           
/* 375 */           if (propertiesString != null)
/*     */           {
/*     */ 
/* 378 */             if ((propertiesString.indexOf("{{") > -1) && (propertiesString.indexOf("}}") > -1))
/*     */             {
/* 380 */               propertiesString = propertiesString.substring(propertiesString.indexOf("{{") + 2, propertiesString.indexOf("}}"));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 385 */             StringTokenizer tok2 = new StringTokenizer(propertiesString, ",");
/*     */             
/* 387 */             while (tok2.countTokens() > 1) {
/* 388 */               String tokenName = tok2.nextToken();
/* 389 */               String value = tok2.nextToken();
/* 390 */               if (tokenName.equals("log4jid")) {
/*     */                 try {
/* 392 */                   int thisInt = Integer.parseInt(value);
/* 393 */                   value = String.valueOf(thisInt);
/* 394 */                   if (thisInt > CustomSQLDBReceiver.this.lastID) {
/* 395 */                     CustomSQLDBReceiver.this.lastID = thisInt;
/*     */                   }
/*     */                 }
/*     */                 catch (Exception e) {}
/*     */               }
/* 400 */               properties.put(tokenName, value);
/*     */             }
/*     */           }
/*     */           
/* 404 */           Level levelImpl = Level.toLevel(level);
/*     */           
/*     */ 
/* 407 */           LocationInfo locationInfo = new LocationInfo(fileName, className, methodName, lineNumber);
/*     */           
/*     */ 
/* 410 */           ThrowableInformation throwableInfo = new ThrowableInformation(throwable);
/*     */           
/*     */ 
/* 413 */           properties.putAll(mdc);
/*     */           
/* 415 */           LoggingEvent event = new LoggingEvent(eventLogger.getName(), eventLogger, timeStamp, levelImpl, message, threadName, throwableInfo, ndc, locationInfo, properties);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 423 */           CustomSQLDBReceiver.this.doPost(event);
/*     */         }
/*     */         
/* 426 */         if (CustomSQLDBReceiver.this.lastID != oldLastID) {
/* 427 */           CustomSQLDBReceiver.this.getLogger().debug("lastID: " + CustomSQLDBReceiver.this.lastID);
/* 428 */           oldLastID = CustomSQLDBReceiver.this.lastID;
/*     */         }
/*     */         
/* 431 */         statement.close();
/* 432 */         statement = null;
/*     */       } catch (SQLException sqle) {
/* 434 */         CustomSQLDBReceiver.this.getLogger().error("*************Problem receiving events", sqle);
/*     */       }
/*     */       finally {
/* 437 */         CustomSQLDBReceiver.this.closeConnection();
/*     */       }
/*     */       
/*     */ 
/* 441 */       synchronized (this) {
/* 442 */         while (CustomSQLDBReceiver.this.isPaused()) {
/*     */           try {
/* 444 */             wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 456 */     if ("connectionSource".equals(element.getNodeName())) {
/* 457 */       Object instance = DOMConfigurator.parseElement(element, props, ConnectionSource.class);
/*     */       
/* 459 */       if ((instance instanceof ConnectionSource)) {
/* 460 */         ConnectionSource source = (ConnectionSource)instance;
/* 461 */         source.activateOptions();
/* 462 */         setConnectionSource(source);
/*     */       }
/* 464 */       return true;
/*     */     }
/* 466 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\CustomSQLDBReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */