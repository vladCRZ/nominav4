/*    */ package org.apache.log4j.receivers.db;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.Set;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DBHelper
/*    */ {
/*    */   public static final short PROPERTIES_EXIST = 1;
/*    */   public static final short EXCEPTION_EXISTS = 2;
/*    */   
/*    */   public static short computeReferenceMask(LoggingEvent event)
/*    */   {
/* 37 */     short mask = 0;
/* 38 */     Set propertiesKeys = event.getPropertyKeySet();
/* 39 */     if (propertiesKeys.size() > 0) {
/* 40 */       mask = 1;
/*    */     }
/* 42 */     String[] strRep = event.getThrowableStrRep();
/* 43 */     if (strRep != null) {
/* 44 */       mask = (short)(mask | 0x2);
/*    */     }
/* 46 */     return mask;
/*    */   }
/*    */   
/*    */   public static void closeConnection(Connection connection) {
/* 50 */     if (connection != null) {
/*    */       try {
/* 52 */         connection.close();
/*    */       }
/*    */       catch (SQLException sqle) {}
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public static void closeStatement(Statement statement)
/*    */   {
/* 61 */     if (statement != null) {
/*    */       try {
/* 63 */         statement.close();
/*    */       }
/*    */       catch (SQLException sqle) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\DBHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */