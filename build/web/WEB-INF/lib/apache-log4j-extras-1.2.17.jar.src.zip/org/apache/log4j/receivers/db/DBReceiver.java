/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.component.scheduler.Scheduler;
/*     */ import org.apache.log4j.component.spi.LoggerRepositoryEx;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DBReceiver
/*     */   extends Receiver
/*     */   implements Pauseable, UnrecognizedElementHandler
/*     */ {
/*  41 */   static int DEFAULT_REFRESH_MILLIS = 1000;
/*     */   ConnectionSource connectionSource;
/*  43 */   int refreshMillis = DEFAULT_REFRESH_MILLIS;
/*     */   DBReceiverJob receiverJob;
/*  45 */   boolean paused = false;
/*     */   
/*     */   public void activateOptions()
/*     */   {
/*  49 */     if (this.connectionSource == null) {
/*  50 */       throw new IllegalStateException("DBAppender cannot function without a connection source");
/*     */     }
/*     */     
/*     */ 
/*  54 */     this.receiverJob = new DBReceiverJob(this);
/*  55 */     this.receiverJob.setLoggerRepository(this.repository);
/*     */     
/*  57 */     if (this.repository == null) {
/*  58 */       throw new IllegalStateException("DBAppender cannot function without a reference to its owning repository");
/*     */     }
/*     */     
/*     */ 
/*  62 */     if ((this.repository instanceof LoggerRepositoryEx)) {
/*  63 */       Scheduler scheduler = ((LoggerRepositoryEx)this.repository).getScheduler();
/*     */       
/*  65 */       scheduler.schedule(this.receiverJob, System.currentTimeMillis() + 500L, this.refreshMillis);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setRefreshMillis(int refreshMillis)
/*     */   {
/*  72 */     this.refreshMillis = refreshMillis;
/*     */   }
/*     */   
/*     */   public int getRefreshMillis() {
/*  76 */     return this.refreshMillis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConnectionSource getConnectionSource()
/*     */   {
/*  84 */     return this.connectionSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionSource(ConnectionSource connectionSource)
/*     */   {
/*  92 */     this.connectionSource = connectionSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 100 */     getLogger().info("removing receiverJob from the Scheduler.");
/*     */     
/* 102 */     if ((this.repository instanceof LoggerRepositoryEx)) {
/* 103 */       Scheduler scheduler = ((LoggerRepositoryEx)this.repository).getScheduler();
/* 104 */       scheduler.delete(this.receiverJob);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaused(boolean paused)
/*     */   {
/* 113 */     this.paused = paused;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPaused()
/*     */   {
/* 120 */     return this.paused;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 127 */     if ("connectionSource".equals(element.getNodeName())) {
/* 128 */       Object instance = DOMConfigurator.parseElement(element, props, ConnectionSource.class);
/*     */       
/* 130 */       if ((instance instanceof ConnectionSource)) {
/* 131 */         ConnectionSource source = (ConnectionSource)instance;
/* 132 */         source.activateOptions();
/* 133 */         setConnectionSource(source);
/*     */       }
/* 135 */       return true;
/*     */     }
/* 137 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\DBReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */