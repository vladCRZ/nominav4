/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.scheduler.Job;
/*     */ import org.apache.log4j.component.spi.ComponentBase;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.ThrowableInformation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DBReceiverJob
/*     */   extends ComponentBase
/*     */   implements Job
/*     */ {
/*  43 */   String sqlException = "SELECT trace_line FROM logging_event_exception where event_id=? ORDER by i ASC";
/*  44 */   String sqlProperties = "SELECT mapped_key, mapped_value FROM logging_event_property WHERE event_id=?";
/*  45 */   String sqlSelect = "SELECT sequence_number, timestamp, rendered_message, logger_name, level_string, ndc, thread_name, reference_flag, caller_filename, caller_class, caller_method, caller_line, event_id FROM logging_event WHERE event_id > ?  ORDER BY event_id ASC";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   long lastId = -32768L;
/*     */   DBReceiver parentDBReceiver;
/*     */   
/*     */   DBReceiverJob(DBReceiver parent)
/*     */   {
/*  60 */     this.parentDBReceiver = parent;
/*     */   }
/*     */   
/*     */   public void execute() {
/*  64 */     Connection connection = null;
/*     */     try
/*     */     {
/*  67 */       connection = this.parentDBReceiver.connectionSource.getConnection();
/*  68 */       PreparedStatement statement = connection.prepareStatement(this.sqlSelect);
/*  69 */       statement.setLong(1, this.lastId);
/*  70 */       ResultSet rs = statement.executeQuery();
/*     */       
/*     */ 
/*  73 */       while (rs.next()) {
/*  74 */         Logger logger = null;
/*  75 */         long timeStamp = 0L;
/*  76 */         String level = null;
/*  77 */         String threadName = null;
/*  78 */         Object message = null;
/*  79 */         String ndc = null;
/*  80 */         String className = null;
/*  81 */         String methodName = null;
/*  82 */         String fileName = null;
/*  83 */         String lineNumber = null;
/*  84 */         Hashtable properties = new Hashtable();
/*     */         
/*     */ 
/*     */ 
/*  88 */         timeStamp = rs.getLong(2);
/*  89 */         message = rs.getString(3);
/*  90 */         logger = Logger.getLogger(rs.getString(4));
/*  91 */         level = rs.getString(5);
/*  92 */         Level levelImpl = Level.toLevel(level.trim());
/*     */         
/*  94 */         ndc = rs.getString(6);
/*  95 */         threadName = rs.getString(7);
/*     */         
/*  97 */         short mask = rs.getShort(8);
/*     */         
/*  99 */         fileName = rs.getString(9);
/* 100 */         className = rs.getString(10);
/* 101 */         methodName = rs.getString(11);
/* 102 */         lineNumber = rs.getString(12).trim();
/*     */         
/* 104 */         LocationInfo locationInfo = null;
/* 105 */         if (fileName.equals("?")) {
/* 106 */           locationInfo = LocationInfo.NA_LOCATION_INFO;
/*     */         } else {
/* 108 */           locationInfo = new LocationInfo(fileName, className, methodName, lineNumber);
/*     */         }
/*     */         
/*     */ 
/* 112 */         long id = rs.getLong(13);
/*     */         
/* 114 */         this.lastId = id;
/*     */         
/* 116 */         ThrowableInformation throwableInfo = null;
/* 117 */         if ((mask & 0x2) != 0) {
/* 118 */           throwableInfo = getException(connection, id);
/*     */         }
/*     */         
/* 121 */         LoggingEvent event = new LoggingEvent(logger.getName(), logger, timeStamp, levelImpl, message, threadName, throwableInfo, ndc, locationInfo, properties);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */         event.setProperty("log4jid", Long.toString(id));
/*     */         
/* 133 */         if ((mask & 0x1) != 0) {
/* 134 */           getProperties(connection, id, event);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 140 */         if (!this.parentDBReceiver.isPaused()) {
/* 141 */           this.parentDBReceiver.doPost(event);
/*     */         }
/*     */       }
/* 144 */       statement.close();
/* 145 */       statement = null;
/*     */     } catch (SQLException sqle) {
/* 147 */       getLogger().error("Problem receiving events", sqle);
/*     */     } finally {
/* 149 */       closeConnection(connection);
/*     */     }
/*     */   }
/*     */   
/*     */   void closeConnection(Connection connection) {
/* 154 */     if (connection != null) {
/*     */       try
/*     */       {
/* 157 */         connection.close();
/*     */       }
/*     */       catch (SQLException sqle) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void getProperties(Connection connection, long id, LoggingEvent event)
/*     */     throws SQLException
/*     */   {
/* 175 */     PreparedStatement statement = connection.prepareStatement(this.sqlProperties);
/*     */     try {
/* 177 */       statement.setLong(1, id);
/* 178 */       ResultSet rs = statement.executeQuery();
/*     */       
/* 180 */       while (rs.next()) {
/* 181 */         String key = rs.getString(1);
/* 182 */         String value = rs.getString(2);
/* 183 */         event.setProperty(key, value);
/*     */       }
/*     */     } finally {
/* 186 */       statement.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ThrowableInformation getException(Connection connection, long id)
/*     */     throws SQLException
/*     */   {
/* 201 */     PreparedStatement statement = null;
/*     */     try
/*     */     {
/* 204 */       statement = connection.prepareStatement(this.sqlException);
/* 205 */       statement.setLong(1, id);
/* 206 */       ResultSet rs = statement.executeQuery();
/*     */       
/* 208 */       Vector v = new Vector();
/*     */       
/* 210 */       while (rs.next())
/*     */       {
/* 212 */         v.add(rs.getString(1));
/*     */       }
/*     */       
/* 215 */       int len = v.size();
/* 216 */       String[] strRep = new String[len];
/* 217 */       for (int i = 0; i < len; i++) {
/* 218 */         strRep[i] = ((String)v.get(i));
/*     */       }
/*     */       
/* 221 */       return new ThrowableInformation(strRep);
/*     */     } finally {
/* 223 */       if (statement != null) {
/* 224 */         statement.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\DBReceiverJob.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */