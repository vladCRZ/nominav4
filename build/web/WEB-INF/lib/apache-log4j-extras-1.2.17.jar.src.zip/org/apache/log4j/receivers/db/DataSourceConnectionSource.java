/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceConnectionSource
/*     */   extends ConnectionSourceSkeleton
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*     */   private DataSource dataSource;
/*     */   
/*     */   public void activateOptions()
/*     */   {
/*  48 */     if (this.dataSource == null) {
/*  49 */       getLogger().warn("WARNING: No data source specified");
/*     */     } else {
/*  51 */       Connection connection = null;
/*     */       try {
/*  53 */         connection = getConnection();
/*     */       } catch (SQLException se) {
/*  55 */         getLogger().warn("Could not get a connection to discover the dialect to use.", se);
/*     */       }
/*  57 */       if (connection != null) {
/*  58 */         discoverConnnectionProperties();
/*     */       }
/*  60 */       if ((!supportsGetGeneratedKeys()) && (getSQLDialectCode() == 0)) {
/*  61 */         getLogger().warn("Connection does not support GetGeneratedKey method and could not discover the dialect.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  70 */     if (this.dataSource == null) {
/*  71 */       getLogger().error("WARNING: No data source specified");
/*  72 */       return null;
/*     */     }
/*     */     
/*  75 */     if (getUser() == null) {
/*  76 */       return this.dataSource.getConnection();
/*     */     }
/*  78 */     return this.dataSource.getConnection(getUser(), getPassword());
/*     */   }
/*     */   
/*     */   public DataSource getDataSource()
/*     */   {
/*  83 */     return this.dataSource;
/*     */   }
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/*  87 */     this.dataSource = dataSource;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/*  94 */     if ("dataSource".equals(element.getNodeName())) {
/*  95 */       Object instance = DOMConfigurator.parseElement(element, props, DataSource.class);
/*     */       
/*  97 */       if ((instance instanceof DataSource)) {
/*  98 */         setDataSource((DataSource)instance);
/*     */       }
/* 100 */       return true;
/*     */     }
/* 102 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\DataSourceConnectionSource.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */