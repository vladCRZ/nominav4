/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverManagerConnectionSource
/*     */   extends ConnectionSourceSkeleton
/*     */ {
/*  69 */   private String driverClass = null;
/*  70 */   private String url = null;
/*     */   
/*     */   public void activateOptions() {
/*     */     try {
/*  74 */       if (this.driverClass != null) {
/*  75 */         Class.forName(this.driverClass);
/*  76 */         discoverConnnectionProperties();
/*     */       } else {
/*  78 */         getLogger().error("WARNING: No JDBC driver specified for log4j DriverManagerConnectionSource.");
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException cnfe) {
/*  82 */       getLogger().error("Could not load JDBC driver class: " + this.driverClass, cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  91 */     if (getUser() == null) {
/*  92 */       return DriverManager.getConnection(this.url);
/*     */     }
/*  94 */     return DriverManager.getConnection(this.url, getUser(), getPassword());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 104 */     return this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrl(String url)
/*     */   {
/* 113 */     this.url = url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDriverClass()
/*     */   {
/* 122 */     return this.driverClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDriverClass(String driverClass)
/*     */   {
/* 131 */     this.driverClass = driverClass;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\DriverManagerConnectionSource.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */