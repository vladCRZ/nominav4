/*     */ package org.apache.log4j.receivers.db;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JNDIConnectionSource
/*     */   extends ConnectionSourceSkeleton
/*     */ {
/*  66 */   private String jndiLocation = null;
/*  67 */   private DataSource dataSource = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/*  73 */     if (this.jndiLocation == null) {
/*  74 */       getLogger().error("No JNDI location specified for JNDIConnectionSource.");
/*     */     }
/*     */     
/*  77 */     discoverConnnectionProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  86 */     Connection conn = null;
/*     */     try
/*     */     {
/*  89 */       if (this.dataSource == null) {
/*  90 */         this.dataSource = lookupDataSource();
/*     */       }
/*  92 */       if (getUser() == null) {
/*  93 */         conn = this.dataSource.getConnection();
/*     */       } else {
/*  95 */         conn = this.dataSource.getConnection(getUser(), getPassword());
/*     */       }
/*     */     } catch (NamingException ne) {
/*  98 */       getLogger().error("Error while getting data source", ne);
/*  99 */       throw new SQLException("NamingException while looking up DataSource: " + ne.getMessage());
/*     */     } catch (ClassCastException cce) {
/* 101 */       getLogger().error("ClassCastException while looking up DataSource.", cce);
/* 102 */       throw new SQLException("ClassCastException while looking up DataSource: " + cce.getMessage());
/*     */     }
/*     */     
/* 105 */     return conn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJndiLocation()
/*     */   {
/* 113 */     return this.jndiLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJndiLocation(String jndiLocation)
/*     */   {
/* 122 */     this.jndiLocation = jndiLocation;
/*     */   }
/*     */   
/*     */ 
/*     */   private DataSource lookupDataSource()
/*     */     throws NamingException, SQLException
/*     */   {
/* 129 */     Context ctx = new InitialContext();
/* 130 */     Object obj = ctx.lookup(this.jndiLocation);
/*     */     
/*     */ 
/*     */ 
/* 134 */     DataSource ds = (DataSource)obj;
/*     */     
/* 136 */     if (ds == null) {
/* 137 */       throw new SQLException("Failed to obtain data source from JNDI location " + this.jndiLocation);
/*     */     }
/* 139 */     return ds;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\JNDIConnectionSource.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */