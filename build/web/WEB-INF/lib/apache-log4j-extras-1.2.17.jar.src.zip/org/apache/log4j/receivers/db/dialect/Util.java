/*     */ package org.apache.log4j.receivers.db.dialect;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.spi.ComponentBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */   extends ComponentBase
/*     */ {
/*     */   private static final String POSTGRES_PART = "postgresql";
/*     */   private static final String MYSQL_PART = "mysql";
/*     */   private static final String ORACLE_PART = "oracle";
/*     */   private static final String MSSQL_PART = "microsoft";
/*     */   private static final String HSQL_PART = "hsql";
/*     */   
/*     */   public static int discoverSQLDialect(DatabaseMetaData meta)
/*     */   {
/*  41 */     int dialectCode = 0;
/*     */     
/*     */     try
/*     */     {
/*  45 */       String dbName = meta.getDatabaseProductName().toLowerCase();
/*     */       
/*  47 */       if (dbName.indexOf("postgresql") != -1)
/*  48 */         return 1;
/*  49 */       if (dbName.indexOf("mysql") != -1)
/*  50 */         return 2;
/*  51 */       if (dbName.indexOf("oracle") != -1)
/*  52 */         return 3;
/*  53 */       if (dbName.indexOf("microsoft") != -1)
/*  54 */         return 4;
/*  55 */       if (dbName.indexOf("hsql") != -1) {
/*  56 */         return 5;
/*     */       }
/*  58 */       return 0;
/*     */     }
/*     */     catch (SQLException sqle) {}
/*     */     
/*     */ 
/*     */ 
/*  64 */     return dialectCode;
/*     */   }
/*     */   
/*     */   public static SQLDialect getDialectFromCode(int dialectCode) {
/*  68 */     SQLDialect sqlDialect = null;
/*     */     
/*  70 */     switch (dialectCode) {
/*     */     case 1: 
/*  72 */       sqlDialect = new PostgreSQLDialect();
/*     */       
/*  74 */       break;
/*     */     case 2: 
/*  76 */       sqlDialect = new MySQLDialect();
/*     */       
/*  78 */       break;
/*     */     case 3: 
/*  80 */       sqlDialect = new OracleDialect();
/*     */       
/*  82 */       break;
/*     */     case 4: 
/*  84 */       sqlDialect = new MsSQLDialect();
/*     */       
/*  86 */       break;
/*     */     case 5: 
/*  88 */       sqlDialect = new HSQLDBDialect();
/*     */     }
/*     */     
/*     */     
/*  92 */     return sqlDialect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsGetGeneratedKeys(DatabaseMetaData meta)
/*     */   {
/*     */     try
/*     */     {
/* 105 */       return ((Boolean)DatabaseMetaData.class.getMethod("supportsGetGeneratedKeys", null).invoke(meta, null)).booleanValue();
/*     */     } catch (Throwable e) {
/* 107 */       getLogger().info("Could not call supportsGetGeneratedKeys method. This may be recoverable"); }
/* 108 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsBatchUpdates(DatabaseMetaData meta)
/*     */   {
/*     */     try
/*     */     {
/* 119 */       return meta.supportsBatchUpdates();
/*     */     } catch (Throwable e) {
/* 121 */       getLogger().info("Missing DatabaseMetaData.supportsBatchUpdates method."); }
/* 122 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\db\dialect\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */