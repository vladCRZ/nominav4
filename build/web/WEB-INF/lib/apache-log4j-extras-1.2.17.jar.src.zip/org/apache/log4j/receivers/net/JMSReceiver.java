/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.ObjectMessage;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.TopicConnectionFactory;
/*     */ import javax.jms.TopicSession;
/*     */ import javax.jms.TopicSubscriber;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NameNotFoundException;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Plugin;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSReceiver
/*     */   extends Receiver
/*     */   implements MessageListener
/*     */ {
/*  50 */   private boolean active = false;
/*     */   
/*     */   protected String topicFactoryName;
/*     */   
/*     */   protected String topicName;
/*     */   protected String userId;
/*     */   protected String password;
/*     */   protected TopicConnection topicConnection;
/*     */   protected String jndiPath;
/*     */   private String remoteInfo;
/*     */   private String providerUrl;
/*     */   
/*     */   public JMSReceiver() {}
/*     */   
/*     */   public JMSReceiver(String _topicFactoryName, String _topicName, String _userId, String _password, String _jndiPath)
/*     */   {
/*  66 */     this.topicFactoryName = _topicFactoryName;
/*  67 */     this.topicName = _topicName;
/*  68 */     this.userId = _userId;
/*  69 */     this.password = _password;
/*  70 */     this.jndiPath = _jndiPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJndiPath(String _jndiPath)
/*     */   {
/*  78 */     this.jndiPath = _jndiPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJndiPath()
/*     */   {
/*  86 */     return this.jndiPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTopicFactoryName(String _topicFactoryName)
/*     */   {
/*  93 */     this.topicFactoryName = _topicFactoryName;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getTopicFactoryName()
/*     */   {
/*  99 */     return this.topicFactoryName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTopicName(String _topicName)
/*     */   {
/* 107 */     this.topicName = _topicName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTopicName()
/*     */   {
/* 114 */     return this.topicName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUserId(String _userId)
/*     */   {
/* 121 */     this.userId = _userId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserId()
/*     */   {
/* 128 */     return this.userId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(String _password)
/*     */   {
/* 136 */     this.password = _password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 143 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquivalent(Plugin testPlugin)
/*     */   {
/* 157 */     if ((testPlugin instanceof JMSReceiver))
/*     */     {
/* 159 */       JMSReceiver receiver = (JMSReceiver)testPlugin;
/*     */       
/*     */ 
/* 162 */       return (this.topicFactoryName.equals(receiver.getTopicFactoryName())) && ((this.jndiPath == null) || (this.jndiPath.equals(receiver.getJndiPath()))) && (super.isEquivalent(testPlugin));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isActive()
/*     */   {
/* 175 */     return this.active;
/*     */   }
/*     */   
/*     */ 
/*     */   protected synchronized void setActive(boolean _active)
/*     */   {
/* 181 */     this.active = _active;
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 187 */     if (!isActive()) {
/*     */       try {
/* 189 */         this.remoteInfo = (this.topicFactoryName + ":" + this.topicName);
/*     */         
/* 191 */         Context ctx = null;
/* 192 */         if ((this.jndiPath == null) || (this.jndiPath.equals(""))) {
/* 193 */           ctx = new InitialContext();
/*     */         } else {
/* 195 */           FileInputStream is = new FileInputStream(this.jndiPath);
/* 196 */           Properties p = new Properties();
/* 197 */           p.load(is);
/* 198 */           is.close();
/* 199 */           ctx = new InitialContext(p);
/*     */         }
/*     */         
/*     */ 
/* 203 */         this.providerUrl = ((String)ctx.getEnvironment().get("java.naming.provider.url"));
/*     */         
/* 205 */         TopicConnectionFactory topicConnectionFactory = (TopicConnectionFactory)lookup(ctx, this.topicFactoryName);
/*     */         
/*     */ 
/* 208 */         if ((this.userId != null) && (this.password != null)) {
/* 209 */           this.topicConnection = topicConnectionFactory.createTopicConnection(this.userId, this.password);
/*     */         }
/*     */         else {
/* 212 */           this.topicConnection = topicConnectionFactory.createTopicConnection();
/*     */         }
/*     */         
/*     */ 
/* 216 */         TopicSession topicSession = this.topicConnection.createTopicSession(false, 1);
/*     */         
/*     */ 
/* 219 */         Topic topic = (Topic)ctx.lookup(this.topicName);
/*     */         
/* 221 */         TopicSubscriber topicSubscriber = topicSession.createSubscriber(topic);
/*     */         
/* 223 */         topicSubscriber.setMessageListener(this);
/*     */         
/* 225 */         this.topicConnection.start();
/*     */         
/* 227 */         setActive(true);
/*     */       } catch (Exception e) {
/* 229 */         setActive(false);
/* 230 */         if (this.topicConnection != null) {
/*     */           try {
/* 232 */             this.topicConnection.close();
/*     */           }
/*     */           catch (Exception e2) {}
/*     */           
/* 236 */           this.topicConnection = null;
/*     */         }
/* 238 */         getLogger().error("Could not start JMSReceiver.", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 246 */     if (isActive())
/*     */     {
/* 248 */       setActive(false);
/*     */       
/* 250 */       if (this.topicConnection != null) {
/*     */         try {
/* 252 */           this.topicConnection.close();
/*     */         }
/*     */         catch (Exception e) {}
/*     */         
/* 256 */         this.topicConnection = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onMessage(Message message) {
/*     */     try {
/* 263 */       if ((message instanceof ObjectMessage))
/*     */       {
/* 265 */         ObjectMessage objectMessage = (ObjectMessage)message;
/* 266 */         LoggingEvent event = (LoggingEvent)objectMessage.getObject();
/*     */         
/*     */ 
/* 269 */         event.setProperty("log4j.remoteSourceInfo", this.remoteInfo);
/* 270 */         event.setProperty("log4j.jmsProviderUrl", this.providerUrl);
/*     */         
/* 272 */         doPost(event);
/*     */       } else {
/* 274 */         getLogger().warn("Received message is of type " + message.getJMSType() + ", was expecting ObjectMessage.");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 278 */       getLogger().error("Exception thrown while processing incoming message.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object lookup(Context ctx, String name) throws NamingException {
/*     */     try {
/* 284 */       return ctx.lookup(name);
/*     */     } catch (NameNotFoundException e) {
/* 286 */       getLogger().error("Could not find name [" + name + "].");
/* 287 */       throw e;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\JMSReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */