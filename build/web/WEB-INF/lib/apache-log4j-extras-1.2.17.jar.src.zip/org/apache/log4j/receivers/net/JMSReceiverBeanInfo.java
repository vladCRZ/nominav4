/*    */ package org.apache.log4j.receivers.net;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMSReceiverBeanInfo
/*    */   extends SimpleBeanInfo
/*    */ {
/*    */   public PropertyDescriptor[] getPropertyDescriptors()
/*    */   {
/*    */     try
/*    */     {
/* 38 */       return new PropertyDescriptor[] { new PropertyDescriptor("name", JMSReceiver.class), new PropertyDescriptor("topicFactoryName", JMSReceiver.class), new PropertyDescriptor("topicName", JMSReceiver.class), new PropertyDescriptor("threshold", JMSReceiver.class), new PropertyDescriptor("jndiPath", JMSReceiver.class), new PropertyDescriptor("userId", JMSReceiver.class) };
/*    */     }
/*    */     catch (Exception e) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 50 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\JMSReceiverBeanInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */