/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.AppenderSkeleton;
/*     */ import org.apache.log4j.Layout;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.xml.XMLLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MulticastAppender
/*     */   extends AppenderSkeleton
/*     */   implements PortBased
/*     */ {
/*     */   static final int DEFAULT_PORT = 9991;
/*     */   public static final String ZONE = "_log4j_xml_mcast_appender.local.";
/*     */   String hostname;
/*     */   String remoteHost;
/*     */   String application;
/*     */   int timeToLive;
/*     */   InetAddress address;
/*  78 */   int port = 9991;
/*     */   
/*     */   MulticastSocket outSocket;
/*     */   private String encoding;
/*  82 */   private boolean locationInfo = false;
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   private ZeroConfSupport zeroConf;
/*     */   
/*     */   public MulticastAppender() {
/*  87 */     super(false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/*     */     try
/*     */     {
/*  95 */       this.hostname = InetAddress.getLocalHost().getHostName();
/*     */     } catch (UnknownHostException uhe) {
/*     */       try {
/*  98 */         this.hostname = InetAddress.getLocalHost().getHostAddress();
/*     */       } catch (UnknownHostException uhe2) {
/* 100 */         this.hostname = "unknown";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 105 */     if (this.application == null) {
/* 106 */       this.application = System.getProperty("application");
/*     */     }
/* 108 */     else if (System.getProperty("application") != null) {
/* 109 */       this.application = (this.application + "-" + System.getProperty("application"));
/*     */     }
/*     */     
/*     */ 
/* 113 */     if (this.remoteHost != null) {
/* 114 */       this.address = getAddressByName(this.remoteHost);
/*     */     } else {
/* 116 */       String err = "The RemoteHost property is required for MulticastAppender named " + this.name;
/* 117 */       LogLog.error(err);
/* 118 */       throw new IllegalStateException(err);
/*     */     }
/*     */     
/* 121 */     if (this.layout == null) {
/* 122 */       this.layout = new XMLLayout();
/*     */     }
/*     */     
/* 125 */     if (this.advertiseViaMulticastDNS) {
/* 126 */       Map properties = new HashMap();
/* 127 */       properties.put("multicastAddress", this.remoteHost);
/* 128 */       this.zeroConf = new ZeroConfSupport("_log4j_xml_mcast_appender.local.", this.port, getName(), properties);
/* 129 */       this.zeroConf.advertise();
/*     */     }
/* 131 */     connect();
/* 132 */     super.activateOptions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 141 */     if (this.closed) {
/* 142 */       return;
/*     */     }
/*     */     
/* 145 */     this.closed = true;
/* 146 */     if (this.advertiseViaMulticastDNS) {
/* 147 */       this.zeroConf.unadvertise();
/*     */     }
/* 149 */     cleanUp();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanUp()
/*     */   {
/* 157 */     if (this.outSocket != null) {
/*     */       try {
/* 159 */         this.outSocket.close();
/*     */       } catch (Exception e) {
/* 161 */         LogLog.error("Could not close outSocket.", e);
/*     */       }
/*     */       
/* 164 */       this.outSocket = null;
/*     */     }
/*     */   }
/*     */   
/*     */   void connect() {
/* 169 */     if (this.address == null) {
/* 170 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 175 */       cleanUp();
/* 176 */       this.outSocket = new MulticastSocket();
/* 177 */       this.outSocket.setTimeToLive(this.timeToLive);
/*     */     } catch (IOException e) {
/* 179 */       LogLog.error("Error in connect method of MulticastAppender named " + this.name, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void append(LoggingEvent event) {
/* 184 */     if (event == null) {
/* 185 */       return;
/*     */     }
/*     */     
/* 188 */     if (this.locationInfo) {
/* 189 */       event.getLocationInformation();
/*     */     }
/*     */     
/* 192 */     if (this.outSocket != null) {
/* 193 */       event.setProperty("hostname", this.hostname);
/*     */       
/* 195 */       if (this.application != null) {
/* 196 */         event.setProperty("application", this.application);
/*     */       }
/*     */       
/* 199 */       if (this.locationInfo) {
/* 200 */         event.getLocationInformation();
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 205 */         StringBuffer buf = new StringBuffer(this.layout.format(event));
/*     */         byte[] payload;
/*     */         byte[] payload;
/* 208 */         if (this.encoding == null) {
/* 209 */           payload = buf.toString().getBytes();
/*     */         } else {
/* 211 */           payload = buf.toString().getBytes(this.encoding);
/*     */         }
/*     */         
/* 214 */         DatagramPacket dp = new DatagramPacket(payload, payload.length, this.address, this.port);
/*     */         
/* 216 */         this.outSocket.send(dp);
/*     */       } catch (IOException e) {
/* 218 */         this.outSocket = null;
/* 219 */         LogLog.warn("Detected problem with Multicast connection: " + e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   InetAddress getAddressByName(String host) {
/*     */     try {
/* 226 */       return InetAddress.getByName(host);
/*     */     } catch (Exception e) {
/* 228 */       LogLog.error("Could not find address of [" + host + "].", e); }
/* 229 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteHost(String host)
/*     */   {
/* 238 */     this.remoteHost = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRemoteHost()
/*     */   {
/* 245 */     return this.remoteHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocationInfo(boolean locationInfo)
/*     */   {
/* 254 */     this.locationInfo = locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getLocationInfo()
/*     */   {
/* 261 */     return this.locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 269 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 276 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setApplication(String app)
/*     */   {
/* 283 */     this.application = app;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getApplication()
/*     */   {
/* 290 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeToLive(int timeToLive)
/*     */   {
/* 298 */     this.timeToLive = timeToLive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getTimeToLive()
/*     */   {
/* 305 */     return this.timeToLive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 313 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 320 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/* 328 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean requiresLayout()
/*     */   {
/* 336 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 340 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 344 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\MulticastAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */