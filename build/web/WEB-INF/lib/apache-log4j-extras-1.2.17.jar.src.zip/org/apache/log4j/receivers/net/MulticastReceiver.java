/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.receivers.spi.Decoder;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MulticastReceiver
/*     */   extends Receiver
/*     */   implements PortBased, AddressBased, Pauseable
/*     */ {
/*     */   private static final int PACKET_LENGTH = 16384;
/*     */   private int port;
/*     */   private String address;
/*     */   private String encoding;
/*     */   private MulticastSocket socket;
/*     */   private String decoder;
/*     */   private Decoder decoderImpl;
/*     */   private MulticastHandlerThread handlerThread;
/*     */   private MulticastReceiverThread receiverThread;
/*     */   private boolean paused;
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   private ZeroConfSupport zeroConf;
/*     */   public static final String ZONE = "_log4j_xml_mcast_receiver.local.";
/*     */   
/*     */   public MulticastReceiver()
/*     */   {
/*  48 */     this.socket = null;
/*     */     
/*     */ 
/*  51 */     this.decoder = "org.apache.log4j.xml.XMLDecoder";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDecoder()
/*     */   {
/*  65 */     return this.decoder;
/*     */   }
/*     */   
/*     */   public void setDecoder(String decoder) {
/*  69 */     this.decoder = decoder;
/*     */   }
/*     */   
/*     */   public int getPort() {
/*  73 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  77 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getAddress() {
/*  81 */     return this.address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/*  89 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/*  96 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public synchronized void shutdown() {
/* 100 */     this.active = false;
/* 101 */     if (this.advertiseViaMulticastDNS) {
/* 102 */       this.zeroConf.unadvertise();
/*     */     }
/* 104 */     if (this.handlerThread != null) {
/* 105 */       this.handlerThread.interrupt();
/*     */     }
/* 107 */     if (this.receiverThread != null) {
/* 108 */       this.receiverThread.interrupt();
/*     */     }
/* 110 */     if (this.socket != null) {
/* 111 */       this.socket.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAddress(String address) {
/* 116 */     this.address = address;
/*     */   }
/*     */   
/*     */   public boolean isPaused() {
/* 120 */     return this.paused;
/*     */   }
/*     */   
/*     */   public void setPaused(boolean b) {
/* 124 */     this.paused = b;
/*     */   }
/*     */   
/*     */   public void activateOptions() {
/* 128 */     InetAddress addr = null;
/*     */     try
/*     */     {
/* 131 */       Class c = Class.forName(this.decoder);
/* 132 */       Object o = c.newInstance();
/*     */       
/* 134 */       if ((o instanceof Decoder)) {
/* 135 */         this.decoderImpl = ((Decoder)o);
/*     */       }
/*     */     } catch (ClassNotFoundException cnfe) {
/* 138 */       getLogger().warn("Unable to find decoder", cnfe);
/*     */     } catch (IllegalAccessException iae) {
/* 140 */       getLogger().warn("Could not construct decoder", iae);
/*     */     } catch (InstantiationException ie) {
/* 142 */       getLogger().warn("Could not construct decoder", ie);
/*     */     }
/*     */     try
/*     */     {
/* 146 */       addr = InetAddress.getByName(this.address);
/*     */     } catch (UnknownHostException uhe) {
/* 148 */       uhe.printStackTrace();
/*     */     }
/*     */     try
/*     */     {
/* 152 */       this.active = true;
/* 153 */       this.socket = new MulticastSocket(this.port);
/* 154 */       this.socket.joinGroup(addr);
/* 155 */       this.receiverThread = new MulticastReceiverThread();
/* 156 */       this.receiverThread.start();
/* 157 */       this.handlerThread = new MulticastHandlerThread();
/* 158 */       this.handlerThread.start();
/* 159 */       if (this.advertiseViaMulticastDNS) {
/* 160 */         this.zeroConf = new ZeroConfSupport("_log4j_xml_mcast_receiver.local.", this.port, getName());
/* 161 */         this.zeroConf.advertise();
/*     */       }
/*     */     }
/*     */     catch (IOException ioe) {
/* 165 */       ioe.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 170 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 174 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   class MulticastHandlerThread extends Thread {
/* 178 */     private List list = new ArrayList();
/*     */     
/*     */     public MulticastHandlerThread() {
/* 181 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     public void append(String data) {
/* 185 */       synchronized (this.list) {
/* 186 */         this.list.add(data);
/* 187 */         this.list.notify();
/*     */       }
/*     */     }
/*     */     
/*     */     public void run() {
/* 192 */       ArrayList list2 = new ArrayList();
/*     */       
/* 194 */       while (isAlive()) {
/* 195 */         synchronized (this.list) {
/*     */           try {
/* 197 */             while (this.list.size() == 0) {
/* 198 */               this.list.wait();
/*     */             }
/*     */             
/* 201 */             if (this.list.size() > 0) {
/* 202 */               list2.addAll(this.list);
/* 203 */               this.list.clear();
/*     */             }
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */         
/* 209 */         if (list2.size() > 0) {
/* 210 */           Iterator iter = list2.iterator();
/*     */           
/* 212 */           while (iter.hasNext()) {
/* 213 */             String data = (String)iter.next();
/* 214 */             Object v = MulticastReceiver.this.decoderImpl.decodeEvents(data.trim());
/*     */             
/* 216 */             if (v != null) {
/* 217 */               Iterator eventIter = ((List)v).iterator();
/*     */               
/* 219 */               while (eventIter.hasNext()) {
/* 220 */                 if (!MulticastReceiver.this.isPaused()) {
/* 221 */                   MulticastReceiver.this.doPost((LoggingEvent)eventIter.next());
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 227 */           list2.clear();
/*     */         } else {
/*     */           try {
/* 230 */             synchronized (this) {
/* 231 */               wait(1000L);
/*     */             }
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   class MulticastReceiverThread extends Thread {
/*     */     public MulticastReceiverThread() {
/* 242 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     public void run() {
/* 246 */       MulticastReceiver.this.active = true;
/*     */       
/* 248 */       byte[] b = new byte['䀀'];
/* 249 */       DatagramPacket p = new DatagramPacket(b, b.length);
/*     */       
/* 251 */       while (MulticastReceiver.this.active) {
/*     */         try {
/* 253 */           MulticastReceiver.this.socket.receive(p);
/*     */           
/*     */ 
/*     */ 
/* 257 */           if (MulticastReceiver.this.encoding == null) {
/* 258 */             MulticastReceiver.this.handlerThread.append(new String(p.getData(), 0, p.getLength()));
/*     */           }
/*     */           else {
/* 261 */             MulticastReceiver.this.handlerThread.append(new String(p.getData(), 0, p.getLength(), MulticastReceiver.this.encoding));
/*     */           }
/*     */           
/*     */         }
/*     */         catch (SocketException se) {}catch (IOException ioe)
/*     */         {
/* 267 */           ioe.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 271 */       MulticastReceiver.this.getLogger().debug("{}'s thread is ending.", MulticastReceiver.this.getName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\MulticastReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */