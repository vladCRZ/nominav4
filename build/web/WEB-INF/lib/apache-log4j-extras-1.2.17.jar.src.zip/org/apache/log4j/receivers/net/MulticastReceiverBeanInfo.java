/*    */ package org.apache.log4j.receivers.net;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MulticastReceiverBeanInfo
/*    */   extends SimpleBeanInfo
/*    */ {
/*    */   public PropertyDescriptor[] getPropertyDescriptors()
/*    */   {
/*    */     try
/*    */     {
/* 38 */       return new PropertyDescriptor[] { new PropertyDescriptor("name", MulticastReceiver.class), new PropertyDescriptor("address", MulticastReceiver.class), new PropertyDescriptor("port", MulticastReceiver.class), new PropertyDescriptor("threshold", MulticastReceiver.class), new PropertyDescriptor("decoder", MulticastReceiver.class), new PropertyDescriptor("advertiseViaMulticastDNS", MulticastReceiver.class) };
/*    */     }
/*    */     catch (Exception e) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 49 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\MulticastReceiverBeanInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */