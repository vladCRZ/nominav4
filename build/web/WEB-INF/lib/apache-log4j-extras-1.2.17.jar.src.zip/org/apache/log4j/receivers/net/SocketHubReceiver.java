/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ConnectException;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Plugin;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketHubReceiver
/*     */   extends Receiver
/*     */   implements SocketNodeEventListener, PortBased
/*     */ {
/*     */   static final int DEFAULT_RECONNECTION_DELAY = 30000;
/*     */   protected String host;
/*     */   protected int port;
/*  66 */   protected int reconnectionDelay = 30000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String ZONE = "_log4j_obj_tcpconnect_receiver.local.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   protected boolean active = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connector connector;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SocketNode13 socketNode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  91 */   private List listenerList = Collections.synchronizedList(new ArrayList());
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   
/*     */ 
/*     */ 
/*     */   private ZeroConfSupport zeroConf;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SocketHubReceiver() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SocketHubReceiver(String h, int p)
/*     */   {
/* 111 */     this.host = h;
/* 112 */     this.port = p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SocketHubReceiver(String h, int p, LoggerRepository repo)
/*     */   {
/* 125 */     this.host = h;
/* 126 */     this.port = p;
/* 127 */     this.repository = repo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSocketNodeEventListener(SocketNodeEventListener l)
/*     */   {
/* 136 */     this.listenerList.add(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSocketNodeEventListener(SocketNodeEventListener l)
/*     */   {
/* 146 */     this.listenerList.remove(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 154 */     return this.host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHost(String remoteHost)
/*     */   {
/* 163 */     this.host = remoteHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(String remoteHost)
/*     */   {
/* 171 */     this.host = remoteHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 179 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int p)
/*     */   {
/* 187 */     this.port = p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReconnectionDelay(int delay)
/*     */   {
/* 201 */     int oldValue = this.reconnectionDelay;
/* 202 */     this.reconnectionDelay = delay;
/* 203 */     firePropertyChange("reconnectionDelay", oldValue, this.reconnectionDelay);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReconnectionDelay()
/*     */   {
/* 211 */     return this.reconnectionDelay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquivalent(Plugin testPlugin)
/*     */   {
/* 224 */     if ((testPlugin != null) && ((testPlugin instanceof SocketHubReceiver))) {
/* 225 */       SocketHubReceiver sReceiver = (SocketHubReceiver)testPlugin;
/*     */       
/* 227 */       return (this.port == sReceiver.getPort()) && (this.host.equals(sReceiver.getHost())) && (this.reconnectionDelay == sReceiver.getReconnectionDelay()) && (super.isEquivalent(testPlugin));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 232 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setActive(boolean b)
/*     */   {
/* 240 */     this.active = b;
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 246 */     if (!isActive()) {
/* 247 */       setActive(true);
/* 248 */       if (this.advertiseViaMulticastDNS) {
/* 249 */         this.zeroConf = new ZeroConfSupport("_log4j_obj_tcpconnect_receiver.local.", this.port, getName());
/* 250 */         this.zeroConf.advertise();
/*     */       }
/*     */       
/* 253 */       fireConnector(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 261 */     this.active = false;
/*     */     
/*     */     try
/*     */     {
/* 265 */       if (this.socketNode != null) {
/* 266 */         this.socketNode.close();
/* 267 */         this.socketNode = null;
/*     */       }
/*     */     } catch (Exception e) {
/* 270 */       getLogger().info("Excpetion closing socket", e);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 275 */     if (this.connector != null) {
/* 276 */       this.connector.interrupted = true;
/* 277 */       this.connector = null;
/*     */     }
/* 279 */     if (this.advertiseViaMulticastDNS) {
/* 280 */       this.zeroConf.unadvertise();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void socketClosedEvent(Exception e)
/*     */   {
/* 294 */     if (e != null) {
/* 295 */       this.connector = null;
/* 296 */       fireConnector(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void fireConnector(boolean isReconnect)
/*     */   {
/* 305 */     if ((this.active) && (this.connector == null)) {
/* 306 */       getLogger().debug("Starting a new connector thread.");
/* 307 */       this.connector = new Connector(isReconnect);
/* 308 */       this.connector.setDaemon(true);
/* 309 */       this.connector.setPriority(1);
/* 310 */       this.connector.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void setSocket(Socket newSocket)
/*     */   {
/* 319 */     this.connector = null;
/* 320 */     this.socketNode = new SocketNode13(newSocket, this);
/* 321 */     this.socketNode.addSocketNodeEventListener(this);
/*     */     Iterator iter;
/* 323 */     synchronized (this.listenerList) {
/* 324 */       for (iter = this.listenerList.iterator(); iter.hasNext();) {
/* 325 */         SocketNodeEventListener listener = (SocketNodeEventListener)iter.next();
/*     */         
/* 327 */         this.socketNode.addSocketNodeEventListener(listener);
/*     */       }
/*     */     }
/* 330 */     new Thread(this.socketNode).start();
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 334 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 338 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void socketOpened(String remoteInfo) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final class Connector
/*     */     extends Thread
/*     */   {
/* 357 */     boolean interrupted = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     boolean doDelay;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Connector(boolean isReconnect)
/*     */     {
/* 369 */       this.doDelay = isReconnect;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void run()
/*     */     {
/* 376 */       while (!this.interrupted) {
/*     */         try {
/* 378 */           if (this.doDelay) {
/* 379 */             SocketHubReceiver.this.getLogger().debug("waiting for " + SocketHubReceiver.this.reconnectionDelay + " milliseconds before reconnecting.");
/*     */             
/* 381 */             sleep(SocketHubReceiver.this.reconnectionDelay);
/*     */           }
/* 383 */           this.doDelay = true;
/* 384 */           SocketHubReceiver.this.getLogger().debug("Attempting connection to " + SocketHubReceiver.this.host);
/* 385 */           Socket s = new Socket(SocketHubReceiver.this.host, SocketHubReceiver.this.port);
/* 386 */           SocketHubReceiver.this.setSocket(s);
/* 387 */           SocketHubReceiver.this.getLogger().debug("Connection established. Exiting connector thread.");
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/* 391 */           SocketHubReceiver.this.getLogger().debug("Connector interrupted. Leaving loop.");
/* 392 */           return;
/*     */         } catch (ConnectException e) {
/* 394 */           SocketHubReceiver.this.getLogger().debug("Remote host {} refused connection.", SocketHubReceiver.this.host);
/*     */         } catch (IOException e) {
/* 396 */           SocketHubReceiver.this.getLogger().debug("Could not connect to {}. Exception is {}.", SocketHubReceiver.this.host, e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\SocketHubReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */