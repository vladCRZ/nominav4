/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.component.spi.ComponentBase;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketNode13
/*     */   extends ComponentBase
/*     */   implements Runnable, Pauseable
/*     */ {
/*     */   private boolean paused;
/*     */   private boolean closed;
/*     */   private Socket socket;
/*     */   private Receiver receiver;
/*  78 */   private List listenerList = Collections.synchronizedList(new ArrayList());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SocketNode13(Socket s, LoggerRepository hierarchy)
/*     */   {
/*  90 */     this.socket = s;
/*  91 */     this.repository = hierarchy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SocketNode13(Socket s, Receiver r)
/*     */   {
/* 101 */     this.socket = s;
/* 102 */     this.receiver = r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setListener(SocketNodeEventListener l)
/*     */   {
/* 114 */     removeSocketNodeEventListener(l);
/* 115 */     addSocketNodeEventListener(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSocketNodeEventListener(SocketNodeEventListener listener)
/*     */   {
/* 125 */     this.listenerList.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSocketNodeEventListener(SocketNodeEventListener listener)
/*     */   {
/* 137 */     this.listenerList.remove(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 147 */     Exception listenerException = null;
/* 148 */     ObjectInputStream ois = null;
/*     */     try
/*     */     {
/* 151 */       ois = new ObjectInputStream(new BufferedInputStream(this.socket.getInputStream()));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 155 */       ois = null;
/* 156 */       listenerException = e;
/* 157 */       getLogger().error("Exception opening ObjectInputStream to " + this.socket, e);
/*     */     }
/*     */     
/* 160 */     if (ois != null)
/*     */     {
/* 162 */       String hostName = this.socket.getInetAddress().getHostName();
/* 163 */       String remoteInfo = hostName + ":" + this.socket.getPort();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */       fireSocketOpened(remoteInfo);
/*     */       try
/*     */       {
/* 172 */         while (!isClosed())
/*     */         {
/* 174 */           LoggingEvent event = (LoggingEvent)ois.readObject();
/* 175 */           event.setProperty("hostname", hostName);
/*     */           
/* 177 */           event.setProperty("log4j.remoteSourceInfo", remoteInfo);
/*     */           
/*     */ 
/* 180 */           if ((!isPaused()) && (!isClosed())) {
/* 181 */             if (this.receiver != null) {
/* 182 */               this.receiver.doPost(event);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 188 */               Logger remoteLogger = this.repository.getLogger(event.getLoggerName());
/*     */               
/*     */ 
/*     */ 
/* 192 */               if (event.getLevel().isGreaterOrEqual(remoteLogger.getEffectiveLevel()))
/*     */               {
/*     */ 
/*     */ 
/* 196 */                 remoteLogger.callAppenders(event);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (EOFException e)
/*     */       {
/* 204 */         getLogger().info("Caught java.io.EOFException closing connection.");
/* 205 */         listenerException = e;
/*     */       } catch (SocketException e) {
/* 207 */         getLogger().info("Caught java.net.SocketException closing connection.");
/* 208 */         listenerException = e;
/*     */       } catch (IOException e) {
/* 210 */         getLogger().info("Caught java.io.IOException: " + e);
/* 211 */         getLogger().info("Closing connection.");
/* 212 */         listenerException = e;
/*     */       } catch (Exception e) {
/* 214 */         getLogger().error("Unexpected exception. Closing connection.", e);
/* 215 */         listenerException = e;
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 221 */       if (ois != null) {
/* 222 */         ois.close();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/*     */ 
/* 229 */     if ((this.listenerList.size() > 0) && (!isClosed())) {
/* 230 */       fireSocketClosedEvent(listenerException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void fireSocketClosedEvent(Exception listenerException)
/*     */   {
/*     */     Iterator iter;
/*     */     
/* 239 */     synchronized (this.listenerList) {
/* 240 */       for (iter = this.listenerList.iterator(); iter.hasNext();) {
/* 241 */         SocketNodeEventListener snel = (SocketNodeEventListener)iter.next();
/*     */         
/* 243 */         if (snel != null) {
/* 244 */           snel.socketClosedEvent(listenerException);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void fireSocketOpened(String remoteInfo)
/*     */   {
/*     */     Iterator iter;
/*     */     
/* 255 */     synchronized (this.listenerList) {
/* 256 */       for (iter = this.listenerList.iterator(); iter.hasNext();) {
/* 257 */         SocketNodeEventListener snel = (SocketNodeEventListener)iter.next();
/*     */         
/* 259 */         if (snel != null) {
/* 260 */           snel.socketOpened(remoteInfo);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaused(boolean b)
/*     */   {
/* 271 */     this.paused = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPaused()
/*     */   {
/* 279 */     return this.paused;
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 286 */     getLogger().debug("closing socket");
/* 287 */     this.closed = true;
/* 288 */     this.socket.close();
/* 289 */     fireSocketClosedEvent(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 297 */     return this.closed;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\SocketNode13.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */