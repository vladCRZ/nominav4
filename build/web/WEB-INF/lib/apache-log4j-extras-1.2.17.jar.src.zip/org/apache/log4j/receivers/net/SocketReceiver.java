/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Plugin;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketReceiver
/*     */   extends Receiver
/*     */   implements Runnable, PortBased, Pauseable
/*     */ {
/*  52 */   private Map socketMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean paused;
/*     */   
/*     */ 
/*     */ 
/*     */   private Thread rThread;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int port;
/*     */   
/*     */ 
/*     */ 
/*     */   private ServerSocket serverSocket;
/*     */   
/*     */ 
/*     */ 
/*  72 */   private Vector socketList = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String ZONE = "_log4j_obj_tcpaccept_receiver.local.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private SocketNodeEventListener listener = null;
/*     */   
/*     */ 
/*     */ 
/*  86 */   private List listenerList = Collections.synchronizedList(new ArrayList());
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   
/*     */ 
/*     */   private ZeroConfSupport zeroConf;
/*     */   
/*     */ 
/*     */ 
/*     */   public SocketReceiver() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public SocketReceiver(int p)
/*     */   {
/* 103 */     this.port = p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SocketReceiver(int p, LoggerRepository repo)
/*     */   {
/* 113 */     this.port = p;
/* 114 */     this.repository = repo;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 118 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int p) {
/* 122 */     this.port = p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquivalent(Plugin testPlugin)
/*     */   {
/* 135 */     if ((testPlugin != null) && ((testPlugin instanceof SocketReceiver))) {
/* 136 */       SocketReceiver sReceiver = (SocketReceiver)testPlugin;
/*     */       
/* 138 */       return (this.port == sReceiver.getPort()) && (super.isEquivalent(testPlugin));
/*     */     }
/*     */     
/* 141 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 147 */     if (!isActive())
/*     */     {
/* 149 */       this.rThread = new Thread(this);
/* 150 */       this.rThread.setDaemon(true);
/* 151 */       this.rThread.start();
/* 152 */       if (this.advertiseViaMulticastDNS) {
/* 153 */         this.zeroConf = new ZeroConfSupport("_log4j_obj_tcpaccept_receiver.local.", this.port, getName());
/* 154 */         this.zeroConf.advertise();
/*     */       }
/*     */       
/* 157 */       this.active = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 166 */     getLogger().debug(getName() + " received shutdown request");
/*     */     
/*     */ 
/* 169 */     this.active = false;
/*     */     
/* 171 */     if (this.rThread != null) {
/* 172 */       this.rThread.interrupt();
/* 173 */       this.rThread = null;
/*     */     }
/* 175 */     if (this.advertiseViaMulticastDNS) {
/* 176 */       this.zeroConf.unadvertise();
/*     */     }
/*     */     
/* 179 */     doShutdown();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void doShutdown()
/*     */   {
/* 187 */     this.active = false;
/*     */     
/* 189 */     getLogger().debug(getName() + " doShutdown called");
/*     */     
/*     */ 
/* 192 */     closeServerSocket();
/*     */     
/*     */ 
/* 195 */     closeAllAcceptedSockets();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void closeServerSocket()
/*     */   {
/* 202 */     getLogger().debug("{} closing server socket", getName());
/*     */     try
/*     */     {
/* 205 */       if (this.serverSocket != null) {
/* 206 */         this.serverSocket.close();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 212 */     this.serverSocket = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void closeAllAcceptedSockets()
/*     */   {
/* 219 */     for (int x = 0; x < this.socketList.size(); x++) {
/*     */       try {
/* 221 */         ((Socket)this.socketList.get(x)).close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 228 */     this.socketMap.clear();
/* 229 */     this.socketList.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setActive(boolean b)
/*     */   {
/* 237 */     this.active = b;
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 241 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 245 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 254 */     closeServerSocket();
/* 255 */     closeAllAcceptedSockets();
/*     */     
/*     */     try
/*     */     {
/* 259 */       this.serverSocket = new ServerSocket(this.port);
/*     */     } catch (Exception e) {
/* 261 */       getLogger().error("error starting SocketReceiver (" + getName() + "), receiver did not start", e);
/*     */       
/*     */ 
/* 264 */       this.active = false;
/*     */       
/* 266 */       return;
/*     */     }
/*     */     
/* 269 */     Socket socket = null;
/*     */     try
/*     */     {
/* 272 */       getLogger().debug("in run-about to enter while not interrupted loop");
/*     */       
/* 274 */       this.active = true;
/*     */       
/* 276 */       while (!this.rThread.isInterrupted())
/*     */       {
/* 278 */         if (socket != null) {
/* 279 */           getLogger().debug("socket not null - creating and starting socketnode");
/*     */           
/* 281 */           this.socketList.add(socket);
/*     */           
/* 283 */           SocketNode13 node = new SocketNode13(socket, this);
/* 284 */           synchronized (this.listenerList) {
/* 285 */             Iterator iter = this.listenerList.iterator();
/* 286 */             while (iter.hasNext()) {
/* 287 */               SocketNodeEventListener l = (SocketNodeEventListener)iter.next();
/*     */               
/* 289 */               node.addSocketNodeEventListener(l);
/*     */             }
/*     */           }
/* 292 */           this.socketMap.put(socket, node);
/* 293 */           new Thread(node).start();
/* 294 */           socket = null;
/*     */         }
/*     */         
/* 297 */         getLogger().debug("waiting to accept socket");
/*     */         
/*     */ 
/* 300 */         socket = this.serverSocket.accept();
/* 301 */         getLogger().debug("accepted socket");
/*     */       }
/*     */     } catch (Exception e) {
/* 304 */       getLogger().warn("exception while watching socket server in SocketReceiver (" + getName() + "), stopping");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 309 */     getLogger().debug("{} has exited the not interrupted loop", getName());
/*     */     
/*     */ 
/*     */ 
/* 313 */     if (socket != null) {
/*     */       try {
/* 315 */         socket.close();
/*     */       } catch (IOException e1) {
/* 317 */         getLogger().warn("socket exception caught - socket closed");
/*     */       }
/*     */     }
/*     */     
/* 321 */     getLogger().debug("{} is exiting main run loop", getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector getConnectedSocketDetails()
/*     */   {
/* 331 */     Vector details = new Vector(this.socketList.size());
/*     */     
/* 333 */     Enumeration enumeration = this.socketList.elements();
/* 334 */     while (enumeration.hasMoreElements())
/*     */     {
/* 336 */       Socket socket = (Socket)enumeration.nextElement();
/* 337 */       details.add(new SocketDetail(socket, (SocketNode13)this.socketMap.get(socket), null));
/*     */     }
/*     */     
/*     */ 
/* 341 */     return details;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public SocketNodeEventListener getListener()
/*     */   {
/* 352 */     return this.listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSocketNodeEventListener(SocketNodeEventListener l)
/*     */   {
/* 362 */     this.listenerList.add(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSocketNodeEventListener(SocketNodeEventListener l)
/*     */   {
/* 374 */     this.listenerList.remove(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setListener(SocketNodeEventListener l)
/*     */   {
/* 389 */     removeSocketNodeEventListener(l);
/* 390 */     addSocketNodeEventListener(l);
/* 391 */     this.listener = l;
/*     */   }
/*     */   
/*     */   public boolean isPaused()
/*     */   {
/* 396 */     return this.paused;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 401 */   public void setPaused(boolean b) { this.paused = b; }
/*     */   
/*     */   private static final class SocketDetail implements AddressBased, PortBased, Pauseable { private String address;
/*     */     private int port;
/*     */     private SocketNode13 socketNode;
/*     */     
/* 407 */     SocketDetail(Socket x0, SocketNode13 x1, SocketReceiver.1 x2) { this(x0, x1); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private SocketDetail(Socket socket, SocketNode13 node)
/*     */     {
/* 430 */       this.address = socket.getInetAddress().getHostName();
/* 431 */       this.port = socket.getPort();
/* 432 */       this.socketNode = node;
/*     */     }
/*     */     
/*     */     public String getAddress()
/*     */     {
/* 437 */       return this.address;
/*     */     }
/*     */     
/*     */     public int getPort()
/*     */     {
/* 442 */       return this.port;
/*     */     }
/*     */     
/*     */     public String getName()
/*     */     {
/* 447 */       return "Socket";
/*     */     }
/*     */     
/*     */     public boolean isActive()
/*     */     {
/* 452 */       return true;
/*     */     }
/*     */     
/*     */     public boolean isPaused()
/*     */     {
/* 457 */       return this.socketNode.isPaused();
/*     */     }
/*     */     
/*     */     public void setPaused(boolean b)
/*     */     {
/* 462 */       this.socketNode.setPaused(b);
/*     */     }
/*     */   }
/*     */   
/*     */   public void doPost(LoggingEvent event) {
/* 467 */     if (!isPaused()) {
/* 468 */       super.doPost(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\SocketReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */