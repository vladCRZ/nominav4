/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import org.apache.log4j.AppenderSkeleton;
/*     */ import org.apache.log4j.Layout;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.xml.XMLLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UDPAppender
/*     */   extends AppenderSkeleton
/*     */   implements PortBased
/*     */ {
/*     */   public static final int DEFAULT_PORT = 9991;
/*     */   String hostname;
/*     */   String remoteHost;
/*     */   String application;
/*     */   String encoding;
/*     */   InetAddress address;
/*  70 */   int port = 9991;
/*     */   
/*     */ 
/*     */ 
/*     */   DatagramSocket outSocket;
/*     */   
/*     */ 
/*     */   public static final String ZONE = "_log4j_xml_udp_appender.local.";
/*     */   
/*     */ 
/*  80 */   boolean inError = false;
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   private ZeroConfSupport zeroConf;
/*     */   
/*     */   public UDPAppender() {
/*  85 */     super(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UDPAppender(InetAddress address, int port)
/*     */   {
/*  92 */     super(false);
/*  93 */     this.address = address;
/*  94 */     this.remoteHost = address.getHostName();
/*  95 */     this.port = port;
/*  96 */     activateOptions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UDPAppender(String host, int port)
/*     */   {
/* 103 */     super(false);
/* 104 */     this.port = port;
/* 105 */     this.address = getAddressByName(host);
/* 106 */     this.remoteHost = host;
/* 107 */     activateOptions();
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/*     */     try
/*     */     {
/* 115 */       this.hostname = InetAddress.getLocalHost().getHostName();
/*     */     } catch (UnknownHostException uhe) {
/*     */       try {
/* 118 */         this.hostname = InetAddress.getLocalHost().getHostAddress();
/*     */       } catch (UnknownHostException uhe2) {
/* 120 */         this.hostname = "unknown";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 125 */     if (this.application == null) {
/* 126 */       this.application = System.getProperty("application");
/*     */     }
/* 128 */     else if (System.getProperty("application") != null) {
/* 129 */       this.application = (this.application + "-" + System.getProperty("application"));
/*     */     }
/*     */     
/*     */ 
/* 133 */     if (this.remoteHost != null) {
/* 134 */       this.address = getAddressByName(this.remoteHost);
/* 135 */       connect(this.address, this.port);
/*     */     } else {
/* 137 */       String err = "The RemoteHost property is required for SocketAppender named " + this.name;
/* 138 */       LogLog.error(err);
/* 139 */       throw new IllegalStateException(err);
/*     */     }
/*     */     
/* 142 */     if (this.layout == null) {
/* 143 */       this.layout = new XMLLayout();
/*     */     }
/*     */     
/* 146 */     if (this.advertiseViaMulticastDNS) {
/* 147 */       this.zeroConf = new ZeroConfSupport("_log4j_xml_udp_appender.local.", this.port, getName());
/* 148 */       this.zeroConf.advertise();
/*     */     }
/*     */     
/* 151 */     super.activateOptions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 160 */     if (this.closed) {
/* 161 */       return;
/*     */     }
/*     */     
/* 164 */     if (this.advertiseViaMulticastDNS) {
/* 165 */       this.zeroConf.unadvertise();
/*     */     }
/*     */     
/* 168 */     this.closed = true;
/* 169 */     cleanUp();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanUp()
/*     */   {
/* 177 */     if (this.outSocket != null) {
/*     */       try {
/* 179 */         this.outSocket.close();
/*     */       } catch (Exception e) {
/* 181 */         LogLog.error("Could not close outSocket.", e);
/*     */       }
/*     */       
/* 184 */       this.outSocket = null;
/*     */     }
/*     */   }
/*     */   
/*     */   void connect(InetAddress address, int port) {
/* 189 */     if (this.address == null) {
/* 190 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 195 */       cleanUp();
/* 196 */       this.outSocket = new DatagramSocket();
/* 197 */       this.outSocket.connect(address, port);
/*     */     } catch (IOException e) {
/* 199 */       LogLog.error("Could not open UDP Socket for sending.", e);
/*     */       
/* 201 */       this.inError = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void append(LoggingEvent event) {
/* 206 */     if (this.inError) {
/* 207 */       return;
/*     */     }
/*     */     
/* 210 */     if (event == null) {
/* 211 */       return;
/*     */     }
/*     */     
/* 214 */     if (this.address == null) {
/* 215 */       return;
/*     */     }
/*     */     
/* 218 */     if (this.outSocket != null) {
/* 219 */       event.setProperty("hostname", this.hostname);
/* 220 */       if (this.application != null) {
/* 221 */         event.setProperty("application", this.application);
/*     */       }
/*     */       try
/*     */       {
/* 225 */         StringBuffer buf = new StringBuffer(this.layout.format(event));
/*     */         byte[] payload;
/*     */         byte[] payload;
/* 228 */         if (this.encoding == null) {
/* 229 */           payload = buf.toString().getBytes();
/*     */         } else {
/* 231 */           payload = buf.toString().getBytes(this.encoding);
/*     */         }
/*     */         
/* 234 */         DatagramPacket dp = new DatagramPacket(payload, payload.length, this.address, this.port);
/*     */         
/* 236 */         this.outSocket.send(dp);
/*     */       } catch (IOException e) {
/* 238 */         this.outSocket = null;
/* 239 */         LogLog.warn("Detected problem with UDP connection: " + e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isActive() {
/* 245 */     return !this.inError;
/*     */   }
/*     */   
/*     */   InetAddress getAddressByName(String host) {
/*     */     try {
/* 250 */       return InetAddress.getByName(host);
/*     */     } catch (Exception e) {
/* 252 */       LogLog.error("Could not find address of [" + host + "].", e); }
/* 253 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean requiresLayout()
/*     */   {
/* 262 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteHost(String host)
/*     */   {
/* 270 */     this.remoteHost = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRemoteHost()
/*     */   {
/* 277 */     return this.remoteHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplication(String app)
/*     */   {
/* 285 */     this.application = app;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getApplication()
/*     */   {
/* 292 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 300 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 307 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 315 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 322 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 326 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 330 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\UDPAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */