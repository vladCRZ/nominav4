/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.SocketException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.receivers.spi.Decoder;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UDPReceiver
/*     */   extends Receiver
/*     */   implements PortBased, Pauseable
/*     */ {
/*     */   private static final int PACKET_LENGTH = 16384;
/*     */   private UDPReceiverThread receiverThread;
/*     */   private String encoding;
/*     */   private String decoder;
/*     */   private Decoder decoderImpl;
/*     */   protected boolean paused;
/*     */   private transient boolean closed;
/*     */   private int port;
/*     */   private DatagramSocket socket;
/*     */   UDPHandlerThread handlerThread;
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   private ZeroConfSupport zeroConf;
/*     */   public static final String ZONE = "_log4j_xml_udp_receiver.local.";
/*     */   
/*     */   public UDPReceiver()
/*     */   {
/*  48 */     this.decoder = "org.apache.log4j.xml.XMLDecoder";
/*     */     
/*     */ 
/*  51 */     this.closed = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/*  65 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  69 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/*  77 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/*  84 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public String getDecoder() {
/*  88 */     return this.decoder;
/*     */   }
/*     */   
/*     */   public void setDecoder(String decoder) {
/*  92 */     this.decoder = decoder;
/*     */   }
/*     */   
/*     */   public boolean isPaused() {
/*  96 */     return this.paused;
/*     */   }
/*     */   
/*     */   public void setPaused(boolean b) {
/* 100 */     this.paused = b;
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 104 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 108 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public synchronized void shutdown() {
/* 112 */     if (this.closed == true) {
/* 113 */       return;
/*     */     }
/* 115 */     this.closed = true;
/* 116 */     this.active = false;
/*     */     
/*     */ 
/* 119 */     if (this.socket != null) {
/* 120 */       this.socket.close();
/*     */     }
/*     */     
/* 123 */     if (this.advertiseViaMulticastDNS) {
/* 124 */       this.zeroConf.unadvertise();
/*     */     }
/*     */     try
/*     */     {
/* 128 */       if (this.handlerThread != null) {
/* 129 */         this.handlerThread.close();
/* 130 */         this.handlerThread.join();
/*     */       }
/* 132 */       if (this.receiverThread != null) {
/* 133 */         this.receiverThread.join();
/*     */       }
/*     */     }
/*     */     catch (InterruptedException ie) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/*     */     try
/*     */     {
/* 147 */       Class c = Class.forName(this.decoder);
/* 148 */       Object o = c.newInstance();
/*     */       
/* 150 */       if ((o instanceof Decoder)) {
/* 151 */         this.decoderImpl = ((Decoder)o);
/*     */       }
/*     */     } catch (ClassNotFoundException cnfe) {
/* 154 */       getLogger().warn("Unable to find decoder", cnfe);
/*     */     } catch (IllegalAccessException iae) {
/* 156 */       getLogger().warn("Could not construct decoder", iae);
/*     */     } catch (InstantiationException ie) {
/* 158 */       getLogger().warn("Could not construct decoder", ie);
/*     */     }
/*     */     try
/*     */     {
/* 162 */       this.socket = new DatagramSocket(this.port);
/* 163 */       this.receiverThread = new UDPReceiverThread();
/* 164 */       this.receiverThread.start();
/* 165 */       this.handlerThread = new UDPHandlerThread();
/* 166 */       this.handlerThread.start();
/* 167 */       if (this.advertiseViaMulticastDNS) {
/* 168 */         this.zeroConf = new ZeroConfSupport("_log4j_xml_udp_receiver.local.", this.port, getName());
/* 169 */         this.zeroConf.advertise();
/*     */       }
/* 171 */       this.active = true;
/*     */     } catch (IOException ioe) {
/* 173 */       ioe.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   class UDPHandlerThread extends Thread {
/* 178 */     private List list = new ArrayList();
/*     */     
/*     */     public UDPHandlerThread() {
/* 181 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     public void append(String data) {
/* 185 */       synchronized (this.list) {
/* 186 */         this.list.add(data);
/* 187 */         this.list.notify();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     void close()
/*     */     {
/* 195 */       synchronized (this.list) {
/* 196 */         this.list.notify();
/*     */       }
/*     */     }
/*     */     
/*     */     public void run() {
/* 201 */       ArrayList list2 = new ArrayList();
/*     */       
/* 203 */       while (!UDPReceiver.this.closed) {
/* 204 */         synchronized (this.list) {
/*     */           try {
/* 206 */             while ((!UDPReceiver.this.closed) && (this.list.size() == 0)) {
/* 207 */               this.list.wait(300L);
/*     */             }
/*     */             
/* 210 */             if (this.list.size() > 0) {
/* 211 */               list2.addAll(this.list);
/* 212 */               this.list.clear();
/*     */             }
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */         
/* 218 */         if (list2.size() > 0) {
/* 219 */           Iterator iter = list2.iterator();
/*     */           
/* 221 */           while (iter.hasNext()) {
/* 222 */             String data = (String)iter.next();
/* 223 */             Object v = UDPReceiver.this.decoderImpl.decodeEvents(data);
/*     */             
/* 225 */             if (v != null) {
/* 226 */               Iterator eventIter = ((List)v).iterator();
/*     */               
/* 228 */               while (eventIter.hasNext()) {
/* 229 */                 if (!UDPReceiver.this.isPaused()) {
/* 230 */                   UDPReceiver.this.doPost((LoggingEvent)eventIter.next());
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 236 */           list2.clear();
/*     */         } else {
/*     */           try {
/* 239 */             synchronized (this) {
/* 240 */               wait(1000L);
/*     */             }
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */       }
/* 246 */       UDPReceiver.this.getLogger().debug(UDPReceiver.this.getName() + "'s handler thread is exiting");
/*     */     }
/*     */   }
/*     */   
/*     */   class UDPReceiverThread extends Thread {
/*     */     public UDPReceiverThread() {
/* 252 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     public void run() {
/* 256 */       byte[] b = new byte['䀀'];
/* 257 */       DatagramPacket p = new DatagramPacket(b, b.length);
/*     */       
/* 259 */       while (!UDPReceiver.this.closed) {
/*     */         try {
/* 261 */           UDPReceiver.this.socket.receive(p);
/*     */           
/*     */ 
/*     */ 
/* 265 */           if (UDPReceiver.this.encoding == null) {
/* 266 */             UDPReceiver.this.handlerThread.append(new String(p.getData(), 0, p.getLength()));
/*     */           }
/*     */           else {
/* 269 */             UDPReceiver.this.handlerThread.append(new String(p.getData(), 0, p.getLength(), UDPReceiver.this.encoding));
/*     */           }
/*     */           
/*     */         }
/*     */         catch (SocketException se) {}catch (IOException ioe)
/*     */         {
/* 275 */           ioe.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\UDPReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */