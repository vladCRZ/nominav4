/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.component.spi.ComponentBase;
/*     */ import org.apache.log4j.receivers.spi.Decoder;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSocketNode
/*     */   extends ComponentBase
/*     */   implements Runnable
/*     */ {
/*     */   Socket socket;
/*     */   Receiver receiver;
/*     */   Decoder decoder;
/*     */   SocketNodeEventListener listener;
/*     */   
/*     */   public XMLSocketNode(String decoder, Socket socket, LoggerRepository hierarchy)
/*     */   {
/*  59 */     this.repository = hierarchy;
/*     */     try {
/*  61 */       Class c = Class.forName(decoder);
/*  62 */       Object o = c.newInstance();
/*     */       
/*  64 */       if ((o instanceof Decoder)) {
/*  65 */         this.decoder = ((Decoder)o);
/*     */       }
/*     */     } catch (ClassNotFoundException cnfe) {
/*  68 */       getLogger().warn("Unable to find decoder", cnfe);
/*     */     } catch (IllegalAccessException iae) {
/*  70 */       getLogger().warn("Unable to construct decoder", iae);
/*     */     } catch (InstantiationException ie) {
/*  72 */       getLogger().warn("Unable to construct decoder", ie);
/*     */     }
/*     */     
/*  75 */     this.socket = socket;
/*     */   }
/*     */   
/*     */   public XMLSocketNode(String decoder, Socket socket, Receiver receiver)
/*     */   {
/*     */     try
/*     */     {
/*  82 */       Class c = Class.forName(decoder);
/*  83 */       Object o = c.newInstance();
/*     */       
/*  85 */       if ((o instanceof Decoder)) {
/*  86 */         this.decoder = ((Decoder)o);
/*     */       }
/*     */     } catch (ClassNotFoundException cnfe) {
/*  89 */       getLogger().warn("Unable to find decoder", cnfe);
/*     */     } catch (IllegalAccessException iae) {
/*  91 */       getLogger().warn("Unable to construct decoder", iae);
/*     */     } catch (InstantiationException ie) {
/*  93 */       getLogger().warn("Unable to construct decoder", ie);
/*     */     }
/*     */     
/*  96 */     this.socket = socket;
/*  97 */     this.receiver = receiver;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setListener(SocketNodeEventListener _listener)
/*     */   {
/* 103 */     this.listener = _listener;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/* 108 */     Exception listenerException = null;
/* 109 */     InputStream is = null;
/*     */     
/* 111 */     if ((this.receiver == null) || (this.decoder == null)) {
/* 112 */       is = null;
/* 113 */       listenerException = new Exception("No receiver or decoder provided.  Cannot process xml socket events");
/*     */       
/*     */ 
/* 116 */       getLogger().error("Exception constructing XML Socket Receiver", listenerException);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 121 */       is = this.socket.getInputStream();
/*     */     } catch (Exception e) {
/* 123 */       is = null;
/* 124 */       listenerException = e;
/* 125 */       getLogger().error("Exception opening ObjectInputStream to " + this.socket, e);
/*     */     }
/*     */     
/* 128 */     if (is != null) {
/* 129 */       String hostName = this.socket.getInetAddress().getHostName();
/* 130 */       String remoteInfo = hostName + ":" + this.socket.getPort();
/*     */       
/*     */       try
/*     */       {
/*     */         for (;;)
/*     */         {
/* 136 */           byte[] b = new byte['Ѐ'];
/* 137 */           int length = is.read(b);
/* 138 */           if (length == -1) {
/* 139 */             getLogger().info("no bytes read from stream - closing connection.");
/*     */             
/* 141 */             break;
/*     */           }
/* 143 */           List v = this.decoder.decodeEvents(new String(b, 0, length));
/*     */           
/* 145 */           if (v != null) {
/* 146 */             Iterator iter = v.iterator();
/*     */             
/* 148 */             while (iter.hasNext()) {
/* 149 */               LoggingEvent e = (LoggingEvent)iter.next();
/* 150 */               e.setProperty("hostname", hostName);
/*     */               
/*     */ 
/* 153 */               e.setProperty("log4j.remoteSourceInfo", remoteInfo);
/*     */               
/*     */ 
/* 156 */               if (this.receiver != null) {
/* 157 */                 this.receiver.doPost(e);
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/*     */ 
/* 163 */                 Logger remoteLogger = this.repository.getLogger(e.getLoggerName());
/*     */                 
/*     */ 
/*     */ 
/* 167 */                 if (e.getLevel().isGreaterOrEqual(remoteLogger.getEffectiveLevel()))
/*     */                 {
/*     */ 
/*     */ 
/* 171 */                   remoteLogger.callAppenders(e);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (EOFException e) {
/* 178 */         getLogger().info("Caught java.io.EOFException closing connection.");
/* 179 */         listenerException = e;
/*     */       } catch (SocketException e) {
/* 181 */         getLogger().info("Caught java.net.SocketException closing connection.");
/*     */         
/* 183 */         listenerException = e;
/*     */       } catch (IOException e) {
/* 185 */         getLogger().info("Caught java.io.IOException: " + e);
/* 186 */         getLogger().info("Closing connection.");
/* 187 */         listenerException = e;
/*     */       } catch (Exception e) {
/* 189 */         getLogger().error("Unexpected exception. Closing connection.", e);
/* 190 */         listenerException = e;
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 196 */       if (is != null) {
/* 197 */         is.close();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/*     */ 
/* 204 */     if (this.listener != null) {
/* 205 */       this.listener.socketClosedEvent(listenerException);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\XMLSocketNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */