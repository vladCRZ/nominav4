/*     */ package org.apache.log4j.receivers.net;
/*     */ 
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Pauseable;
/*     */ import org.apache.log4j.component.plugins.Plugin;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.net.ZeroConfSupport;
/*     */ import org.apache.log4j.spi.LoggerRepository;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSocketReceiver
/*     */   extends Receiver
/*     */   implements Runnable, PortBased, Pauseable
/*     */ {
/*     */   private boolean paused;
/*  57 */   protected String decoder = "org.apache.log4j.xml.XMLDecoder";
/*     */   private ServerSocket serverSocket;
/*  59 */   private List socketList = new Vector();
/*     */   private Thread rThread;
/*     */   public static final int DEFAULT_PORT = 4448;
/*  62 */   protected int port = 4448;
/*     */   
/*     */ 
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   
/*     */ 
/*     */   private ZeroConfSupport zeroConf;
/*     */   
/*     */ 
/*     */   public static final String ZONE = "_log4j_xml_tcpaccept_receiver.local.";
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLSocketReceiver() {}
/*     */   
/*     */ 
/*     */   public XMLSocketReceiver(int _port)
/*     */   {
/*  80 */     this.port = _port;
/*     */   }
/*     */   
/*     */   public XMLSocketReceiver(int _port, LoggerRepository _repository) {
/*  84 */     this.port = _port;
/*  85 */     this.repository = _repository;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getPort()
/*     */   {
/*  91 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPort(int _port)
/*     */   {
/*  97 */     this.port = _port;
/*     */   }
/*     */   
/*     */   public String getDecoder() {
/* 101 */     return this.decoder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDecoder(String _decoder)
/*     */   {
/* 108 */     this.decoder = _decoder;
/*     */   }
/*     */   
/*     */   public boolean isPaused() {
/* 112 */     return this.paused;
/*     */   }
/*     */   
/*     */   public void setPaused(boolean b) {
/* 116 */     this.paused = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquivalent(Plugin testPlugin)
/*     */   {
/* 129 */     if ((testPlugin != null) && ((testPlugin instanceof XMLSocketReceiver))) {
/* 130 */       XMLSocketReceiver sReceiver = (XMLSocketReceiver)testPlugin;
/*     */       
/* 132 */       return (this.port == sReceiver.getPort()) && (super.isEquivalent(testPlugin));
/*     */     }
/*     */     
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 140 */     int result = 37 * (this.repository != null ? this.repository.hashCode() : 0);
/* 141 */     result = result * 37 + this.port;
/* 142 */     return result * 37 + (getName() != null ? getName().hashCode() : 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setActive(boolean b)
/*     */   {
/* 150 */     this.active = b;
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 156 */     if (!isActive()) {
/* 157 */       this.rThread = new Thread(this);
/* 158 */       this.rThread.setDaemon(true);
/* 159 */       this.rThread.start();
/*     */       
/* 161 */       if (this.advertiseViaMulticastDNS) {
/* 162 */         this.zeroConf = new ZeroConfSupport("_log4j_xml_tcpaccept_receiver.local.", this.port, getName());
/* 163 */         this.zeroConf.advertise();
/*     */       }
/*     */       
/* 166 */       this.active = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 171 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 175 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void shutdown()
/*     */   {
/* 183 */     this.active = false;
/*     */     
/* 185 */     if (this.rThread != null) {
/* 186 */       this.rThread.interrupt();
/* 187 */       this.rThread = null;
/*     */     }
/* 189 */     doShutdown();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void doShutdown()
/*     */   {
/* 197 */     this.active = false;
/*     */     
/* 199 */     getLogger().debug("{} doShutdown called", getName());
/*     */     
/*     */ 
/* 202 */     closeServerSocket();
/*     */     
/*     */ 
/* 205 */     closeAllAcceptedSockets();
/*     */     
/* 207 */     if (this.advertiseViaMulticastDNS) {
/* 208 */       this.zeroConf.unadvertise();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void closeServerSocket()
/*     */   {
/* 216 */     getLogger().debug("{} closing server socket", getName());
/*     */     try
/*     */     {
/* 219 */       if (this.serverSocket != null) {
/* 220 */         this.serverSocket.close();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 226 */     this.serverSocket = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private synchronized void closeAllAcceptedSockets()
/*     */   {
/* 233 */     for (int x = 0; x < this.socketList.size(); x++) {
/*     */       try {
/* 235 */         ((Socket)this.socketList.get(x)).close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 242 */     this.socketList.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 251 */     getLogger().debug("performing socket cleanup prior to entering loop for {}", this.name);
/* 252 */     closeServerSocket();
/* 253 */     closeAllAcceptedSockets();
/* 254 */     getLogger().debug("socket cleanup complete for {}", this.name);
/* 255 */     this.active = true;
/*     */     
/*     */     try
/*     */     {
/* 259 */       this.serverSocket = new ServerSocket(this.port);
/*     */     } catch (Exception e) {
/* 261 */       getLogger().error("error starting SocketReceiver (" + getName() + "), receiver did not start", e);
/*     */       
/*     */ 
/* 264 */       this.active = false;
/* 265 */       doShutdown();
/*     */       
/* 267 */       return;
/*     */     }
/*     */     
/* 270 */     Socket socket = null;
/*     */     try
/*     */     {
/* 273 */       getLogger().debug("in run-about to enter while isactiveloop");
/*     */       
/* 275 */       this.active = true;
/*     */       
/* 277 */       while (!this.rThread.isInterrupted())
/*     */       {
/* 279 */         if (socket != null) {
/* 280 */           getLogger().debug("socket not null - creating and starting socketnode");
/* 281 */           this.socketList.add(socket);
/*     */           
/* 283 */           XMLSocketNode node = new XMLSocketNode(this.decoder, socket, this);
/* 284 */           node.setLoggerRepository(this.repository);
/* 285 */           new Thread(node).start();
/* 286 */           socket = null;
/*     */         }
/*     */         
/* 289 */         getLogger().debug("waiting to accept socket");
/*     */         
/*     */ 
/* 292 */         socket = this.serverSocket.accept();
/* 293 */         getLogger().debug("accepted socket");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 298 */       if (socket != null) {
/* 299 */         socket.close();
/*     */       }
/*     */     } catch (Exception e) {
/* 302 */       getLogger().warn("socket server disconnected, stopping");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doPost(LoggingEvent event)
/*     */   {
/* 311 */     if (!isPaused()) {
/* 312 */       super.doPost(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\net\XMLSocketReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */