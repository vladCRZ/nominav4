/*    */ package org.apache.log4j.receivers.rewrite;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import java.util.StringTokenizer;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyRewritePolicy
/*    */   implements RewritePolicy
/*    */ {
/* 34 */   private Map properties = Collections.EMPTY_MAP;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setProperties(String props)
/*    */   {
/* 46 */     Map hashTable = new HashMap();
/* 47 */     StringTokenizer pairs = new StringTokenizer(props, ",");
/* 48 */     while (pairs.hasMoreTokens()) {
/* 49 */       StringTokenizer entry = new StringTokenizer(pairs.nextToken(), "=");
/* 50 */       hashTable.put(entry.nextElement().toString().trim(), entry.nextElement().toString().trim());
/*    */     }
/* 52 */     synchronized (this) {
/* 53 */       this.properties = hashTable;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public LoggingEvent rewrite(LoggingEvent source)
/*    */   {
/* 61 */     if (!this.properties.isEmpty()) {
/* 62 */       Map rewriteProps = new HashMap(source.getProperties());
/* 63 */       Iterator iter = this.properties.entrySet().iterator();
/* 64 */       while (iter.hasNext())
/*    */       {
/* 66 */         Map.Entry entry = (Map.Entry)iter.next();
/* 67 */         if (!rewriteProps.containsKey(entry.getKey())) {
/* 68 */           rewriteProps.put(entry.getKey(), entry.getValue());
/*    */         }
/*    */       }
/*    */       
/* 72 */       return new LoggingEvent(source.getFQNOfLoggerClass(), source.getLogger() != null ? source.getLogger() : Logger.getLogger(source.getLoggerName()), source.getTimeStamp(), source.getLevel(), source.getMessage(), source.getThreadName(), source.getThrowableInformation(), source.getNDC(), source.getLocationInformation(), rewriteProps);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 84 */     return source;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\rewrite\PropertyRewritePolicy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */