package org.apache.log4j.receivers.spi;

import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.Vector;
import org.apache.log4j.spi.LoggingEvent;

public abstract interface Decoder
{
  public abstract Vector decodeEvents(String paramString);
  
  public abstract LoggingEvent decode(String paramString);
  
  public abstract Vector decode(URL paramURL)
    throws IOException;
  
  public abstract void setAdditionalProperties(Map paramMap);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\spi\Decoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */