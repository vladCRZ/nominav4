/*    */ package org.apache.log4j.receivers.varia;
/*    */ 
/*    */ import javax.swing.DefaultListModel;
/*    */ import javax.swing.ListModel;
/*    */ import org.apache.log4j.AppenderSkeleton;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ListModelAppender
/*    */   extends AppenderSkeleton
/*    */ {
/* 38 */   private final DefaultListModel model = new DefaultListModel();
/*    */   
/*    */ 
/*    */ 
/*    */   public ListModelAppender()
/*    */   {
/* 44 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ListModel getModel()
/*    */   {
/* 53 */     return this.model;
/*    */   }
/*    */   
/*    */   protected void append(LoggingEvent event)
/*    */   {
/* 58 */     this.model.addElement(event);
/*    */   }
/*    */   
/*    */   public void close()
/*    */   {
/* 63 */     clearModel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void clearModel()
/*    */   {
/* 70 */     this.model.clear();
/*    */   }
/*    */   
/*    */   public boolean requiresLayout()
/*    */   {
/* 75 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\varia\ListModelAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */