/*      */ package org.apache.log4j.receivers.varia;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.regex.MatchResult;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import org.apache.log4j.Level;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.apache.log4j.component.ULogger;
/*      */ import org.apache.log4j.component.plugins.Receiver;
/*      */ import org.apache.log4j.rule.ExpressionRule;
/*      */ import org.apache.log4j.rule.Rule;
/*      */ import org.apache.log4j.spi.LocationInfo;
/*      */ import org.apache.log4j.spi.LoggingEvent;
/*      */ import org.apache.log4j.spi.ThrowableInformation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LogFilePatternReceiver
/*      */   extends Receiver
/*      */ {
/*  127 */   private final List keywords = new ArrayList();
/*      */   
/*      */   private static final String PROP_START = "PROP(";
/*      */   
/*      */   private static final String PROP_END = ")";
/*      */   
/*      */   private static final String LOGGER = "LOGGER";
/*      */   
/*      */   private static final String MESSAGE = "MESSAGE";
/*      */   
/*      */   private static final String TIMESTAMP = "TIMESTAMP";
/*      */   private static final String NDC = "NDC";
/*      */   private static final String LEVEL = "LEVEL";
/*      */   private static final String THREAD = "THREAD";
/*      */   private static final String CLASS = "CLASS";
/*      */   private static final String FILE = "FILE";
/*      */   private static final String LINE = "LINE";
/*      */   private static final String METHOD = "METHOD";
/*      */   private static final String DEFAULT_HOST = "file";
/*      */   private static final String EXCEPTION_PATTERN = "^\\s+at.*";
/*      */   private static final String REGEXP_DEFAULT_WILDCARD = ".*?";
/*      */   private static final String REGEXP_GREEDY_WILDCARD = ".*";
/*      */   private static final String PATTERN_WILDCARD = "*";
/*      */   private static final String NOSPACE_GROUP = "(\\S*\\s*?)";
/*      */   private static final String DEFAULT_GROUP = "(.*?)";
/*      */   private static final String GREEDY_GROUP = "(.*)";
/*      */   private static final String MULTIPLE_SPACES_REGEXP = "[ ]+";
/*  154 */   private final String newLine = System.getProperty("line.separator");
/*      */   
/*  156 */   private final String[] emptyException = { "" };
/*      */   
/*      */   private SimpleDateFormat dateFormat;
/*  159 */   private String timestampFormat = "yyyy-MM-d HH:mm:ss,SSS";
/*      */   private String logFormat;
/*      */   private String customLevelDefinitions;
/*      */   private String fileURL;
/*      */   private String host;
/*      */   private String path;
/*      */   private boolean tailing;
/*      */   private String filterExpression;
/*  167 */   private long waitMillis = 2000L;
/*      */   
/*      */   private static final String VALID_DATEFORMAT_CHARS = "GyMwWDdFEaHkKhmsSzZ";
/*      */   
/*      */   private static final String VALID_DATEFORMAT_CHAR_PATTERN = "[GyMwWDdFEaHkKhmsSzZ]";
/*      */   
/*      */   private Rule expressionRule;
/*      */   
/*      */   private Map currentMap;
/*      */   
/*      */   private List additionalLines;
/*      */   private List matchingKeywords;
/*      */   private String regexp;
/*      */   private Reader reader;
/*      */   private Pattern regexpPattern;
/*      */   private Pattern exceptionPattern;
/*      */   private String timestampPatternText;
/*      */   private boolean useCurrentThread;
/*      */   public static final int MISSING_FILE_RETRY_MILLIS = 10000;
/*      */   private boolean appendNonMatches;
/*  187 */   private final Map customLevelDefinitionMap = new HashMap();
/*      */   
/*      */   public LogFilePatternReceiver() {
/*  190 */     this.keywords.add("TIMESTAMP");
/*  191 */     this.keywords.add("LOGGER");
/*  192 */     this.keywords.add("LEVEL");
/*  193 */     this.keywords.add("THREAD");
/*  194 */     this.keywords.add("CLASS");
/*  195 */     this.keywords.add("FILE");
/*  196 */     this.keywords.add("LINE");
/*  197 */     this.keywords.add("METHOD");
/*  198 */     this.keywords.add("MESSAGE");
/*  199 */     this.keywords.add("NDC");
/*      */     try {
/*  201 */       this.exceptionPattern = Pattern.compile("^\\s+at.*");
/*      */     }
/*      */     catch (PatternSyntaxException pse) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFileURL()
/*      */   {
/*  213 */     return this.fileURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFileURL(String fileURL)
/*      */   {
/*  222 */     this.fileURL = fileURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCustomLevelDefinitions(String customLevelDefinitions)
/*      */   {
/*  232 */     this.customLevelDefinitions = customLevelDefinitions;
/*      */   }
/*      */   
/*      */   public String getCustomLevelDefinitions() {
/*  236 */     return this.customLevelDefinitions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAppendNonMatches()
/*      */   {
/*  244 */     return this.appendNonMatches;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAppendNonMatches(boolean appendNonMatches)
/*      */   {
/*  252 */     this.appendNonMatches = appendNonMatches;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFilterExpression()
/*      */   {
/*  261 */     return this.filterExpression;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFilterExpression(String filterExpression)
/*      */   {
/*  270 */     this.filterExpression = filterExpression;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTailing()
/*      */   {
/*  279 */     return this.tailing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTailing(boolean tailing)
/*      */   {
/*  288 */     this.tailing = tailing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isUseCurrentThread()
/*      */   {
/*  298 */     return this.useCurrentThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setUseCurrentThread(boolean useCurrentThread)
/*      */   {
/*  308 */     this.useCurrentThread = useCurrentThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLogFormat()
/*      */   {
/*  317 */     return this.logFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLogFormat(String logFormat)
/*      */   {
/*  327 */     this.logFormat = logFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestampFormat(String timestampFormat)
/*      */   {
/*  336 */     this.timestampFormat = timestampFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTimestampFormat()
/*      */   {
/*  345 */     return this.timestampFormat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getWaitMillis()
/*      */   {
/*  353 */     return this.waitMillis;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWaitMillis(long waitMillis)
/*      */   {
/*  361 */     this.waitMillis = waitMillis;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getExceptionLine()
/*      */   {
/*  379 */     for (int i = 0; i < this.additionalLines.size(); i++) {
/*  380 */       Matcher exceptionMatcher = this.exceptionPattern.matcher((String)this.additionalLines.get(i));
/*  381 */       if (exceptionMatcher.matches()) {
/*  382 */         return i;
/*      */       }
/*      */     }
/*  385 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String buildMessage(String firstMessageLine, int exceptionLine)
/*      */   {
/*  401 */     if (this.additionalLines.size() == 0) {
/*  402 */       return firstMessageLine;
/*      */     }
/*  404 */     StringBuffer message = new StringBuffer();
/*  405 */     if (firstMessageLine != null) {
/*  406 */       message.append(firstMessageLine);
/*      */     }
/*      */     
/*  409 */     int linesToProcess = exceptionLine == -1 ? this.additionalLines.size() : exceptionLine;
/*      */     
/*  411 */     for (int i = 0; i < linesToProcess; i++) {
/*  412 */       message.append(this.newLine);
/*  413 */       message.append(this.additionalLines.get(i));
/*      */     }
/*  415 */     return message.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] buildException(int exceptionLine)
/*      */   {
/*  428 */     if (exceptionLine == -1) {
/*  429 */       return this.emptyException;
/*      */     }
/*  431 */     String[] exception = new String[this.additionalLines.size() - exceptionLine - 1];
/*  432 */     for (int i = 0; i < exception.length; i++) {
/*  433 */       exception[i] = ((String)this.additionalLines.get(i + exceptionLine));
/*      */     }
/*  435 */     return exception;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private LoggingEvent buildEvent()
/*      */   {
/*  447 */     if (this.currentMap.size() == 0) { Iterator iter;
/*  448 */       if (this.additionalLines.size() > 0) {
/*  449 */         for (iter = this.additionalLines.iterator(); iter.hasNext();) {
/*  450 */           getLogger().info("found non-matching line: " + iter.next());
/*      */         }
/*      */       }
/*  453 */       this.additionalLines.clear();
/*  454 */       return null;
/*      */     }
/*      */     
/*  457 */     int exceptionLine = getExceptionLine();
/*  458 */     String[] exception = buildException(exceptionLine);
/*      */     
/*      */ 
/*  461 */     if ((this.additionalLines.size() > 0) && (exception.length > 0)) {
/*  462 */       this.currentMap.put("MESSAGE", buildMessage((String)this.currentMap.get("MESSAGE"), exceptionLine));
/*      */     }
/*      */     
/*  465 */     LoggingEvent event = convertToEvent(this.currentMap, exception);
/*  466 */     this.currentMap.clear();
/*  467 */     this.additionalLines.clear();
/*  468 */     return event;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void process(BufferedReader bufferedReader)
/*      */     throws IOException
/*      */   {
/*      */     String line;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  483 */     while ((line = bufferedReader.readLine()) != null)
/*      */     {
/*  485 */       Matcher eventMatcher = this.regexpPattern.matcher(line);
/*  486 */       if (!line.trim().equals("")) {
/*  487 */         Matcher exceptionMatcher = this.exceptionPattern.matcher(line);
/*  488 */         if (eventMatcher.matches())
/*      */         {
/*  490 */           LoggingEvent event = buildEvent();
/*  491 */           if ((event != null) && 
/*  492 */             (passesExpression(event))) {
/*  493 */             doPost(event);
/*      */           }
/*      */           
/*  496 */           this.currentMap.putAll(processEvent(eventMatcher.toMatchResult()));
/*  497 */         } else if (exceptionMatcher.matches())
/*      */         {
/*  499 */           this.additionalLines.add(line);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  505 */         else if (this.appendNonMatches)
/*      */         {
/*  507 */           String lastTime = (String)this.currentMap.get("TIMESTAMP");
/*      */           
/*  509 */           if (this.currentMap.size() > 0) {
/*  510 */             LoggingEvent event = buildEvent();
/*  511 */             if ((event != null) && 
/*  512 */               (passesExpression(event))) {
/*  513 */               doPost(event);
/*      */             }
/*      */           }
/*      */           
/*  517 */           if (lastTime != null) {
/*  518 */             this.currentMap.put("TIMESTAMP", lastTime);
/*      */           }
/*  520 */           this.currentMap.put("MESSAGE", line);
/*      */         } else {
/*  522 */           this.additionalLines.add(line);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  528 */     LoggingEvent event = buildEvent();
/*  529 */     if ((event != null) && 
/*  530 */       (passesExpression(event))) {
/*  531 */       doPost(event);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void createPattern()
/*      */   {
/*  537 */     this.regexpPattern = Pattern.compile(this.regexp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean passesExpression(LoggingEvent event)
/*      */   {
/*  547 */     if ((event != null) && 
/*  548 */       (this.expressionRule != null)) {
/*  549 */       return this.expressionRule.evaluate(event, null);
/*      */     }
/*      */     
/*  552 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Map processEvent(MatchResult result)
/*      */   {
/*  565 */     Map map = new HashMap();
/*      */     
/*  567 */     for (int i = 1; i < result.groupCount() + 1; i++) {
/*  568 */       Object key = this.matchingKeywords.get(i - 1);
/*  569 */       Object value = result.group(i);
/*  570 */       map.put(key, value);
/*      */     }
/*      */     
/*  573 */     return map;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String convertTimestamp()
/*      */   {
/*  585 */     String result = this.timestampFormat.replaceAll("[GyMwWDdFEaHkKhmsSzZ]+", "\\\\S+");
/*      */     
/*  587 */     result = result.replaceAll(Pattern.quote("."), "\\\\.");
/*  588 */     return result;
/*      */   }
/*      */   
/*      */   protected void setHost(String host) {
/*  592 */     this.host = host;
/*      */   }
/*      */   
/*      */   protected void setPath(String path) {
/*  596 */     this.path = path;
/*      */   }
/*      */   
/*      */   public String getPath() {
/*  600 */     return this.path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initialize()
/*      */   {
/*  608 */     if ((this.host == null) && (this.path == null)) {
/*      */       try {
/*  610 */         URL url = new URL(this.fileURL);
/*  611 */         this.host = url.getHost();
/*  612 */         this.path = url.getPath();
/*      */       }
/*      */       catch (MalformedURLException e1) {
/*  615 */         e1.printStackTrace();
/*      */       }
/*      */     }
/*  618 */     if ((this.host == null) || (this.host.trim().equals(""))) {
/*  619 */       this.host = "file";
/*      */     }
/*  621 */     if ((this.path == null) || (this.path.trim().equals(""))) {
/*  622 */       this.path = this.fileURL;
/*      */     }
/*      */     
/*  625 */     this.currentMap = new HashMap();
/*  626 */     this.additionalLines = new ArrayList();
/*  627 */     this.matchingKeywords = new ArrayList();
/*      */     
/*  629 */     if (this.timestampFormat != null) {
/*  630 */       this.dateFormat = new SimpleDateFormat(quoteTimeStampChars(this.timestampFormat));
/*  631 */       this.timestampPatternText = convertTimestamp();
/*      */     }
/*      */     
/*  634 */     updateCustomLevelDefinitionMap();
/*      */     try {
/*  636 */       if (this.filterExpression != null) {
/*  637 */         this.expressionRule = ExpressionRule.getRule(this.filterExpression);
/*      */       }
/*      */     } catch (Exception e) {
/*  640 */       getLogger().warn("Invalid filter expression: " + this.filterExpression, e);
/*      */     }
/*      */     
/*  643 */     List buildingKeywords = new ArrayList();
/*      */     
/*  645 */     String newPattern = this.logFormat;
/*      */     
/*  647 */     int index = 0;
/*  648 */     String current = newPattern;
/*      */     
/*      */ 
/*  651 */     List propertyNames = new ArrayList();
/*  652 */     while (index > -1) {
/*  653 */       if ((current.indexOf("PROP(") > -1) && (current.indexOf(")") > -1)) {
/*  654 */         index = current.indexOf("PROP(");
/*  655 */         String longPropertyName = current.substring(current.indexOf("PROP("), current.indexOf(")") + 1);
/*  656 */         String shortProp = getShortPropertyName(longPropertyName);
/*  657 */         buildingKeywords.add(shortProp);
/*  658 */         propertyNames.add(longPropertyName);
/*  659 */         current = current.substring(longPropertyName.length() + 1 + index);
/*  660 */         newPattern = singleReplace(newPattern, longPropertyName, new Integer(buildingKeywords.size() - 1).toString());
/*      */       }
/*      */       else {
/*  663 */         index = -1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  675 */     Iterator iter = this.keywords.iterator();
/*  676 */     while (iter.hasNext()) {
/*  677 */       String keyword = (String)iter.next();
/*  678 */       int index2 = newPattern.indexOf(keyword);
/*  679 */       if (index2 > -1) {
/*  680 */         buildingKeywords.add(keyword);
/*  681 */         newPattern = singleReplace(newPattern, keyword, new Integer(buildingKeywords.size() - 1).toString());
/*      */       }
/*      */     }
/*      */     
/*  685 */     String buildingInt = "";
/*      */     
/*  687 */     for (int i = 0; i < newPattern.length(); i++) {
/*  688 */       String thisValue = String.valueOf(newPattern.substring(i, i + 1));
/*  689 */       if (isInteger(thisValue)) {
/*  690 */         buildingInt = buildingInt + thisValue;
/*      */       } else {
/*  692 */         if (isInteger(buildingInt)) {
/*  693 */           this.matchingKeywords.add(buildingKeywords.get(Integer.parseInt(buildingInt)));
/*      */         }
/*      */         
/*  696 */         buildingInt = "";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  701 */     if (isInteger(buildingInt)) {
/*  702 */       this.matchingKeywords.add(buildingKeywords.get(Integer.parseInt(buildingInt)));
/*      */     }
/*      */     
/*  705 */     newPattern = replaceMetaChars(newPattern);
/*      */     
/*      */ 
/*      */ 
/*  709 */     newPattern = newPattern.replaceAll("[ ]+", "[ ]+");
/*  710 */     newPattern = newPattern.replaceAll(Pattern.quote("*"), ".*?");
/*      */     
/*  712 */     for (int i = 0; i < buildingKeywords.size(); i++) {
/*  713 */       String keyword = (String)buildingKeywords.get(i);
/*      */       
/*  715 */       if (i == buildingKeywords.size() - 1) {
/*  716 */         newPattern = singleReplace(newPattern, String.valueOf(i), "(.*)");
/*  717 */       } else if ("TIMESTAMP".equals(keyword)) {
/*  718 */         newPattern = singleReplace(newPattern, String.valueOf(i), "(" + this.timestampPatternText + ")");
/*  719 */       } else if (("LOGGER".equals(keyword)) || ("LEVEL".equals(keyword))) {
/*  720 */         newPattern = singleReplace(newPattern, String.valueOf(i), "(\\S*\\s*?)");
/*      */       } else {
/*  722 */         newPattern = singleReplace(newPattern, String.valueOf(i), "(.*?)");
/*      */       }
/*      */     }
/*      */     
/*  726 */     this.regexp = newPattern;
/*  727 */     getLogger().debug("regexp is " + this.regexp);
/*      */   }
/*      */   
/*      */   private void updateCustomLevelDefinitionMap() {
/*  731 */     if (this.customLevelDefinitions != null) {
/*  732 */       StringTokenizer entryTokenizer = new StringTokenizer(this.customLevelDefinitions, ",");
/*      */       
/*  734 */       this.customLevelDefinitionMap.clear();
/*  735 */       while (entryTokenizer.hasMoreTokens()) {
/*  736 */         StringTokenizer innerTokenizer = new StringTokenizer(entryTokenizer.nextToken(), "=");
/*  737 */         this.customLevelDefinitionMap.put(innerTokenizer.nextToken(), Level.toLevel(innerTokenizer.nextToken()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isInteger(String value) {
/*      */     try {
/*  744 */       Integer.parseInt(value);
/*  745 */       return true;
/*      */     } catch (NumberFormatException nfe) {}
/*  747 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private String quoteTimeStampChars(String input)
/*      */   {
/*  753 */     StringBuffer result = new StringBuffer();
/*      */     
/*  755 */     boolean lastCharIsDateFormat = false;
/*  756 */     for (int i = 0; i < input.length(); i++) {
/*  757 */       String thisVal = input.substring(i, i + 1);
/*  758 */       boolean thisCharIsDateFormat = "GyMwWDdFEaHkKhmsSzZ".contains(thisVal);
/*      */       
/*  760 */       if ((!thisCharIsDateFormat) && ((i == 0) || (lastCharIsDateFormat))) {
/*  761 */         result.append("'");
/*      */       }
/*      */       
/*  764 */       if ((thisCharIsDateFormat) && (i > 0) && (!lastCharIsDateFormat)) {
/*  765 */         result.append("'");
/*      */       }
/*  767 */       lastCharIsDateFormat = thisCharIsDateFormat;
/*  768 */       result.append(thisVal);
/*      */     }
/*      */     
/*  771 */     if (!lastCharIsDateFormat) {
/*  772 */       result.append("'");
/*      */     }
/*  774 */     return result.toString();
/*      */   }
/*      */   
/*      */   private String singleReplace(String inputString, String oldString, String newString)
/*      */   {
/*  779 */     int propLength = oldString.length();
/*  780 */     int startPos = inputString.indexOf(oldString);
/*  781 */     if (startPos == -1)
/*      */     {
/*  783 */       getLogger().info("string: " + oldString + " not found in input: " + inputString + " - returning input");
/*  784 */       return inputString;
/*      */     }
/*  786 */     if (startPos == 0)
/*      */     {
/*  788 */       inputString = inputString.substring(propLength);
/*  789 */       inputString = newString + inputString;
/*      */     } else {
/*  791 */       inputString = inputString.substring(0, startPos) + newString + inputString.substring(startPos + propLength);
/*      */     }
/*  793 */     return inputString;
/*      */   }
/*      */   
/*      */   private String getShortPropertyName(String longPropertyName)
/*      */   {
/*  798 */     String currentProp = longPropertyName.substring(longPropertyName.indexOf("PROP("));
/*  799 */     String prop = currentProp.substring(0, currentProp.indexOf(")") + 1);
/*  800 */     String shortProp = prop.substring("PROP(".length(), prop.length() - 1);
/*  801 */     return shortProp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String replaceMetaChars(String input)
/*      */   {
/*  813 */     input = input.replaceAll("\\\\", "\\\\\\");
/*      */     
/*      */ 
/*  816 */     input = input.replaceAll(Pattern.quote("]"), "\\\\]");
/*  817 */     input = input.replaceAll(Pattern.quote("["), "\\\\[");
/*  818 */     input = input.replaceAll(Pattern.quote("^"), "\\\\^");
/*  819 */     input = input.replaceAll(Pattern.quote("$"), "\\\\$");
/*  820 */     input = input.replaceAll(Pattern.quote("."), "\\\\.");
/*  821 */     input = input.replaceAll(Pattern.quote("|"), "\\\\|");
/*  822 */     input = input.replaceAll(Pattern.quote("?"), "\\\\?");
/*  823 */     input = input.replaceAll(Pattern.quote("+"), "\\\\+");
/*  824 */     input = input.replaceAll(Pattern.quote("("), "\\\\(");
/*  825 */     input = input.replaceAll(Pattern.quote(")"), "\\\\)");
/*  826 */     input = input.replaceAll(Pattern.quote("-"), "\\\\-");
/*  827 */     input = input.replaceAll(Pattern.quote("{"), "\\\\{");
/*  828 */     input = input.replaceAll(Pattern.quote("}"), "\\\\}");
/*  829 */     input = input.replaceAll(Pattern.quote("#"), "\\\\#");
/*  830 */     return input;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private LoggingEvent convertToEvent(Map fieldMap, String[] exception)
/*      */   {
/*  842 */     if (fieldMap == null) {
/*  843 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  847 */     if (!fieldMap.containsKey("LOGGER")) {
/*  848 */       fieldMap.put("LOGGER", "Unknown");
/*      */     }
/*  850 */     if (exception == null) {
/*  851 */       exception = this.emptyException;
/*      */     }
/*      */     
/*  854 */     Logger logger = null;
/*  855 */     long timeStamp = 0L;
/*  856 */     String level = null;
/*  857 */     String threadName = null;
/*  858 */     Object message = null;
/*  859 */     String ndc = null;
/*  860 */     String className = null;
/*  861 */     String methodName = null;
/*  862 */     String eventFileName = null;
/*  863 */     String lineNumber = null;
/*  864 */     Hashtable properties = new Hashtable();
/*      */     
/*  866 */     logger = Logger.getLogger((String)fieldMap.remove("LOGGER"));
/*      */     
/*  868 */     if ((this.dateFormat != null) && (fieldMap.containsKey("TIMESTAMP"))) {
/*      */       try {
/*  870 */         timeStamp = this.dateFormat.parse((String)fieldMap.remove("TIMESTAMP")).getTime();
/*      */       }
/*      */       catch (Exception e) {
/*  873 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */     
/*  877 */     if (timeStamp == 0L) {
/*  878 */       timeStamp = System.currentTimeMillis();
/*      */     }
/*      */     
/*  881 */     message = fieldMap.remove("MESSAGE");
/*  882 */     if (message == null) {
/*  883 */       message = "";
/*      */     }
/*      */     
/*  886 */     level = (String)fieldMap.remove("LEVEL");
/*      */     Level levelImpl;
/*  888 */     Level levelImpl; if (level == null) {
/*  889 */       levelImpl = Level.DEBUG;
/*      */     }
/*      */     else {
/*  892 */       levelImpl = (Level)this.customLevelDefinitionMap.get(level);
/*  893 */       if (levelImpl == null) {
/*  894 */         levelImpl = Level.toLevel(level.trim());
/*  895 */         if (!level.equals(levelImpl.toString()))
/*      */         {
/*  897 */           if (levelImpl == null) {
/*  898 */             levelImpl = Level.DEBUG;
/*  899 */             getLogger().debug("found unexpected level: " + level + ", logger: " + logger.getName() + ", msg: " + message);
/*      */             
/*  901 */             message = level + " " + message;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  907 */     threadName = (String)fieldMap.remove("THREAD");
/*      */     
/*  909 */     ndc = (String)fieldMap.remove("NDC");
/*      */     
/*  911 */     className = (String)fieldMap.remove("CLASS");
/*      */     
/*  913 */     methodName = (String)fieldMap.remove("METHOD");
/*      */     
/*  915 */     eventFileName = (String)fieldMap.remove("FILE");
/*      */     
/*  917 */     lineNumber = (String)fieldMap.remove("LINE");
/*      */     
/*  919 */     properties.put("hostname", this.host);
/*  920 */     properties.put("application", this.path);
/*  921 */     properties.put("receiver", getName());
/*      */     
/*      */ 
/*  924 */     properties.putAll(fieldMap);
/*      */     
/*  926 */     LocationInfo info = null;
/*      */     
/*  928 */     if ((eventFileName != null) || (className != null) || (methodName != null) || (lineNumber != null))
/*      */     {
/*  930 */       info = new LocationInfo(eventFileName, className, methodName, lineNumber);
/*      */     } else {
/*  932 */       info = LocationInfo.NA_LOCATION_INFO;
/*      */     }
/*      */     
/*  935 */     LoggingEvent event = new LoggingEvent(null, logger, timeStamp, levelImpl, message, threadName, new ThrowableInformation(exception), ndc, info, properties);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  943 */     return event;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void shutdown()
/*      */   {
/*  967 */     getLogger().info(getPath() + " shutdown");
/*  968 */     this.active = false;
/*      */     try {
/*  970 */       if (this.reader != null) {
/*  971 */         this.reader.close();
/*  972 */         this.reader = null;
/*      */       }
/*      */     } catch (IOException ioe) {
/*  975 */       ioe.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void activateOptions()
/*      */   {
/*  983 */     getLogger().info("activateOptions");
/*  984 */     this.active = true;
/*  985 */     Runnable runnable = new Runnable() {
/*      */       public void run() {
/*  987 */         LogFilePatternReceiver.this.initialize();
/*  988 */         while (LogFilePatternReceiver.this.reader == null) {
/*  989 */           LogFilePatternReceiver.this.getLogger().info("attempting to load file: " + LogFilePatternReceiver.this.getFileURL());
/*      */           try {
/*  991 */             LogFilePatternReceiver.this.reader = new InputStreamReader(new URL(LogFilePatternReceiver.this.getFileURL()).openStream());
/*      */           } catch (FileNotFoundException fnfe) {
/*  993 */             LogFilePatternReceiver.this.getLogger().info("file not available - will try again");
/*  994 */             synchronized (this) {
/*      */               try {
/*  996 */                 wait(10000L);
/*      */               } catch (InterruptedException ie) {}
/*      */             }
/*      */           } catch (IOException ioe) {
/* 1000 */             LogFilePatternReceiver.this.getLogger().warn("unable to load file", ioe);
/* 1001 */             return;
/*      */           }
/*      */         }
/*      */         try {
/* 1005 */           BufferedReader bufferedReader = new BufferedReader(LogFilePatternReceiver.this.reader);
/* 1006 */           LogFilePatternReceiver.this.createPattern();
/*      */           do {
/* 1008 */             LogFilePatternReceiver.this.process(bufferedReader);
/*      */             try {
/* 1010 */               synchronized (this) {
/* 1011 */                 wait(LogFilePatternReceiver.this.waitMillis);
/*      */               }
/*      */             } catch (InterruptedException ie) {}
/* 1014 */             if (LogFilePatternReceiver.this.tailing) {
/* 1015 */               LogFilePatternReceiver.this.getLogger().debug("tailing file");
/*      */             }
/* 1017 */           } while (LogFilePatternReceiver.this.tailing);
/*      */         }
/*      */         catch (IOException ioe)
/*      */         {
/* 1021 */           LogFilePatternReceiver.this.getLogger().info("stream closed");
/*      */         }
/* 1023 */         LogFilePatternReceiver.this.getLogger().debug("processing " + LogFilePatternReceiver.this.path + " complete");
/* 1024 */         LogFilePatternReceiver.this.shutdown();
/*      */       }
/*      */     };
/* 1027 */     if (this.useCurrentThread) {
/* 1028 */       runnable.run();
/*      */     } else {
/* 1030 */       new Thread(runnable, "LogFilePatternReceiver-" + getName()).start();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\varia\LogFilePatternReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */