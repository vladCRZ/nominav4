/*    */ package org.apache.log4j.receivers.varia;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogFilePatternReceiverBeanInfo
/*    */   extends SimpleBeanInfo
/*    */ {
/*    */   public PropertyDescriptor[] getPropertyDescriptors()
/*    */   {
/*    */     try
/*    */     {
/* 34 */       return new PropertyDescriptor[] { new PropertyDescriptor("fileURL", LogFilePatternReceiver.class), new PropertyDescriptor("timestampFormat", LogFilePatternReceiver.class), new PropertyDescriptor("logFormat", LogFilePatternReceiver.class), new PropertyDescriptor("name", LogFilePatternReceiver.class), new PropertyDescriptor("tailing", LogFilePatternReceiver.class), new PropertyDescriptor("filterExpression", LogFilePatternReceiver.class), new PropertyDescriptor("waitMillis", LogFilePatternReceiver.class), new PropertyDescriptor("appendNonMatches", LogFilePatternReceiver.class), new PropertyDescriptor("customLevelDefinitions", LogFilePatternReceiver.class), new PropertyDescriptor("useCurrentThread", LogFilePatternReceiver.class) };
/*    */     }
/*    */     catch (Exception e) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\varia\LogFilePatternReceiverBeanInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */