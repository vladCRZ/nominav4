/*     */ package org.apache.log4j.receivers.xml;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.apache.log4j.component.ULogger;
/*     */ import org.apache.log4j.component.plugins.Receiver;
/*     */ import org.apache.log4j.receivers.spi.Decoder;
/*     */ import org.apache.log4j.rule.ExpressionRule;
/*     */ import org.apache.log4j.rule.Rule;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogFileXMLReceiver
/*     */   extends Receiver
/*     */ {
/*     */   private String fileURL;
/*     */   private Rule expressionRule;
/*     */   private String filterExpression;
/*  63 */   private String decoder = "org.apache.log4j.xml.XMLDecoder";
/*  64 */   private boolean tailing = false;
/*     */   
/*     */   private Decoder decoderInstance;
/*     */   
/*     */   private Reader reader;
/*     */   
/*     */   private static final String FILE_KEY = "file";
/*     */   
/*     */   private String host;
/*     */   
/*     */   private String path;
/*     */   private boolean useCurrentThread;
/*     */   
/*     */   public String getFileURL()
/*     */   {
/*  79 */     return this.fileURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileURL(String fileURL)
/*     */   {
/*  88 */     this.fileURL = fileURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDecoder()
/*     */   {
/*  97 */     return this.decoder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDecoder(String _decoder)
/*     */   {
/* 106 */     this.decoder = _decoder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterExpression()
/*     */   {
/* 115 */     return this.filterExpression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTailing()
/*     */   {
/* 124 */     return this.tailing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTailing(boolean tailing)
/*     */   {
/* 134 */     this.tailing = tailing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterExpression(String filterExpression)
/*     */   {
/* 144 */     this.filterExpression = filterExpression;
/*     */   }
/*     */   
/*     */   private boolean passesExpression(LoggingEvent event) {
/* 148 */     if ((event != null) && 
/* 149 */       (this.expressionRule != null)) {
/* 150 */       return this.expressionRule.evaluate(event, null);
/*     */     }
/*     */     
/* 153 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shutdown()
/*     */   {
/*     */     try
/*     */     {
/* 169 */       if (this.reader != null) {
/* 170 */         this.reader.close();
/* 171 */         this.reader = null;
/*     */       }
/*     */     } catch (IOException ioe) {
/* 174 */       ioe.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 182 */     Runnable runnable = new Runnable() {
/*     */       public void run() {
/*     */         try {
/* 185 */           URL url = new URL(LogFileXMLReceiver.this.fileURL);
/* 186 */           LogFileXMLReceiver.this.host = url.getHost();
/* 187 */           if ((LogFileXMLReceiver.this.host != null) && (LogFileXMLReceiver.this.host.equals(""))) {
/* 188 */             LogFileXMLReceiver.this.host = "file";
/*     */           }
/* 190 */           LogFileXMLReceiver.this.path = url.getPath();
/*     */         }
/*     */         catch (MalformedURLException e1) {
/* 193 */           e1.printStackTrace();
/*     */         }
/*     */         try
/*     */         {
/* 197 */           if (LogFileXMLReceiver.this.filterExpression != null) {
/* 198 */             LogFileXMLReceiver.this.expressionRule = ExpressionRule.getRule(LogFileXMLReceiver.this.filterExpression);
/*     */           }
/*     */         } catch (Exception e) {
/* 201 */           LogFileXMLReceiver.this.getLogger().warn("Invalid filter expression: " + LogFileXMLReceiver.this.filterExpression, e);
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 206 */           Class c = Class.forName(LogFileXMLReceiver.this.decoder);
/* 207 */           Object o = c.newInstance();
/* 208 */           if ((o instanceof Decoder)) {
/* 209 */             LogFileXMLReceiver.this.decoderInstance = ((Decoder)o);
/*     */           }
/*     */         }
/*     */         catch (ClassNotFoundException e) {
/* 213 */           e.printStackTrace();
/*     */         }
/*     */         catch (InstantiationException e) {
/* 216 */           e.printStackTrace();
/*     */         }
/*     */         catch (IllegalAccessException e) {
/* 219 */           e.printStackTrace();
/*     */         }
/*     */         try
/*     */         {
/* 223 */           LogFileXMLReceiver.this.reader = new InputStreamReader(new URL(LogFileXMLReceiver.this.getFileURL()).openStream());
/* 224 */           LogFileXMLReceiver.this.process(LogFileXMLReceiver.this.reader);
/*     */         } catch (FileNotFoundException fnfe) {
/* 226 */           LogFileXMLReceiver.this.getLogger().info("file not available");
/*     */         } catch (IOException ioe) {
/* 228 */           LogFileXMLReceiver.this.getLogger().warn("unable to load file", ioe);
/* 229 */           return;
/*     */         }
/*     */       }
/*     */     };
/* 233 */     if (this.useCurrentThread) {
/* 234 */       runnable.run();
/*     */     } else {
/* 236 */       Thread thread = new Thread(runnable, "LogFileXMLReceiver-" + getName());
/*     */       
/* 238 */       thread.start();
/*     */     }
/*     */   }
/*     */   
/*     */   private void process(Reader unbufferedReader) throws IOException
/*     */   {
/* 244 */     BufferedReader bufferedReader = new BufferedReader(unbufferedReader);
/* 245 */     char[] content = new char['✐'];
/* 246 */     getLogger().debug("processing starting: " + this.fileURL);
/* 247 */     int length = 0;
/*     */     do {
/* 249 */       System.out.println("in do loop-about to process");
/* 250 */       while ((length = bufferedReader.read(content)) > -1) {
/* 251 */         processEvents(this.decoderInstance.decodeEvents(String.valueOf(content, 0, length)));
/*     */       }
/* 253 */       if (this.tailing) {
/*     */         try {
/* 255 */           Thread.sleep(5000L);
/*     */         }
/*     */         catch (InterruptedException e) {
/* 258 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 261 */     } while (this.tailing);
/* 262 */     getLogger().debug("processing complete: " + this.fileURL);
/*     */     
/* 264 */     shutdown();
/*     */   }
/*     */   
/*     */   private void processEvents(Collection c) {
/* 268 */     if (c == null) {
/* 269 */       return;
/*     */     }
/*     */     
/* 272 */     for (Iterator iter = c.iterator(); iter.hasNext();) {
/* 273 */       LoggingEvent evt = (LoggingEvent)iter.next();
/* 274 */       if (passesExpression(evt)) {
/* 275 */         if (evt.getProperty("hostname") != null) {
/* 276 */           evt.setProperty("hostname", this.host);
/*     */         }
/* 278 */         if (evt.getProperty("application") != null) {
/* 279 */           evt.setProperty("application", this.path);
/*     */         }
/* 281 */         doPost(evt);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isUseCurrentThread()
/*     */   {
/* 293 */     return this.useCurrentThread;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setUseCurrentThread(boolean useCurrentThread)
/*     */   {
/* 303 */     this.useCurrentThread = useCurrentThread;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\xml\LogFileXMLReceiver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */