/*     */ package org.apache.log4j.receivers.xml;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.LineNumberReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import javax.swing.ProgressMonitorInputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.helpers.UtilLoggingLevel;
/*     */ import org.apache.log4j.receivers.spi.Decoder;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.ThrowableInformation;
/*     */ import org.apache.log4j.xml.SAXErrorHandler;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilLoggingXMLDecoder
/*     */   implements Decoder
/*     */ {
/*     */   private static final String BEGIN_PART = "<log>";
/*     */   private static final String END_PART = "</log>";
/*     */   private DocumentBuilder docBuilder;
/*  72 */   private Map additionalProperties = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private String partialEvent;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String RECORD_END = "</record>";
/*     */   
/*     */ 
/*     */ 
/*  84 */   private Component owner = null;
/*     */   
/*     */ 
/*     */   private static final String ENCODING = "UTF-8";
/*     */   
/*     */ 
/*     */ 
/*     */   public UtilLoggingXMLDecoder(Component o)
/*     */   {
/*  93 */     this();
/*  94 */     this.owner = o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UtilLoggingXMLDecoder()
/*     */   {
/* 101 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 102 */     dbf.setValidating(false);
/*     */     try
/*     */     {
/* 105 */       this.docBuilder = dbf.newDocumentBuilder();
/* 106 */       this.docBuilder.setErrorHandler(new SAXErrorHandler());
/* 107 */       this.docBuilder.setEntityResolver(new UtilLoggingEntityResolver());
/*     */     } catch (ParserConfigurationException pce) {
/* 109 */       System.err.println("Unable to get document builder");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdditionalProperties(Map properties)
/*     */   {
/* 121 */     this.additionalProperties = properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Document parse(String data)
/*     */   {
/* 131 */     if ((this.docBuilder == null) || (data == null)) {
/* 132 */       return null;
/*     */     }
/*     */     
/* 135 */     Document document = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 147 */       StringBuffer buf = new StringBuffer(1024);
/*     */       
/* 149 */       if (!data.startsWith("<?xml")) {
/* 150 */         buf.append("<log>");
/*     */       }
/*     */       
/* 153 */       buf.append(data);
/*     */       
/* 155 */       if (!data.endsWith("</log>")) {
/* 156 */         buf.append("</log>");
/*     */       }
/*     */       
/* 159 */       InputSource inputSource = new InputSource(new StringReader(buf.toString()));
/*     */       
/* 161 */       document = this.docBuilder.parse(inputSource);
/*     */     } catch (Exception e) {
/* 163 */       e.printStackTrace();
/*     */     }
/*     */     
/* 166 */     return document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector decode(URL url)
/*     */     throws IOException
/*     */   {
/* 177 */     boolean isZipFile = url.getPath().toLowerCase().endsWith(".zip");
/*     */     InputStream inputStream;
/* 179 */     if (isZipFile) {
/* 180 */       InputStream inputStream = new ZipInputStream(url.openStream());
/*     */       
/* 182 */       ((ZipInputStream)inputStream).getNextEntry();
/*     */     } else {
/* 184 */       inputStream = url.openStream(); }
/*     */     LineNumberReader reader;
/* 186 */     LineNumberReader reader; if (this.owner != null) {
/* 187 */       reader = new LineNumberReader(new InputStreamReader(new ProgressMonitorInputStream(this.owner, "Loading " + url, inputStream), "UTF-8"));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 192 */       reader = new LineNumberReader(new InputStreamReader(inputStream, "UTF-8"));
/*     */     }
/* 194 */     v = new Vector();
/*     */     
/*     */     try
/*     */     {
/*     */       String line;
/* 199 */       while ((line = reader.readLine()) != null) {
/* 200 */         StringBuffer buffer = new StringBuffer(line);
/* 201 */         for (int i = 0; i < 1000; i++) {
/* 202 */           buffer.append(reader.readLine()).append("\n");
/*     */         }
/* 204 */         Vector events = decodeEvents(buffer.toString());
/* 205 */         if (events != null) {
/* 206 */           v.addAll(events);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */       return v;
/*     */     }
/*     */     finally
/*     */     {
/* 210 */       this.partialEvent = null;
/*     */       try {
/* 212 */         if (reader != null) {
/* 213 */           reader.close();
/*     */         }
/*     */       } catch (Exception e) {
/* 216 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector decodeEvents(String document)
/*     */   {
/* 230 */     if (document != null)
/*     */     {
/* 232 */       if (document.trim().equals("")) {
/* 233 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 237 */       String newPartialEvent = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */       if (document.lastIndexOf("</record>") == -1) {
/* 245 */         this.partialEvent += document;
/* 246 */         return null;
/*     */       }
/*     */       String newDoc;
/* 249 */       if (document.lastIndexOf("</record>") + "</record>".length() < document.length())
/*     */       {
/* 251 */         String newDoc = document.substring(0, document.lastIndexOf("</record>") + "</record>".length());
/*     */         
/* 253 */         newPartialEvent = document.substring(document.lastIndexOf("</record>") + "</record>".length());
/*     */       }
/*     */       else {
/* 256 */         newDoc = document;
/*     */       }
/* 258 */       if (this.partialEvent != null) {
/* 259 */         newDoc = this.partialEvent + newDoc;
/*     */       }
/* 261 */       this.partialEvent = newPartialEvent;
/*     */       
/* 263 */       Document doc = parse(newDoc);
/* 264 */       if (doc == null) {
/* 265 */         return null;
/*     */       }
/* 267 */       return decodeEvents(doc);
/*     */     }
/* 269 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggingEvent decode(String data)
/*     */   {
/* 280 */     Document document = parse(data);
/*     */     
/* 282 */     if (document == null) {
/* 283 */       return null;
/*     */     }
/*     */     
/* 286 */     Vector events = decodeEvents(document);
/*     */     
/* 288 */     if (events.size() > 0) {
/* 289 */       return (LoggingEvent)events.firstElement();
/*     */     }
/*     */     
/* 292 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Vector decodeEvents(Document document)
/*     */   {
/* 301 */     Vector events = new Vector();
/*     */     
/* 303 */     NodeList eventList = document.getElementsByTagName("record");
/*     */     
/* 305 */     for (int eventIndex = 0; eventIndex < eventList.getLength(); 
/* 306 */         eventIndex++) {
/* 307 */       Node eventNode = eventList.item(eventIndex);
/*     */       
/* 309 */       Logger logger = null;
/* 310 */       long timeStamp = 0L;
/* 311 */       Level level = null;
/* 312 */       String threadName = null;
/* 313 */       Object message = null;
/* 314 */       String ndc = null;
/* 315 */       String[] exception = null;
/* 316 */       String className = null;
/* 317 */       String methodName = null;
/* 318 */       String fileName = null;
/* 319 */       String lineNumber = null;
/* 320 */       Hashtable properties = new Hashtable();
/*     */       
/*     */ 
/*     */ 
/* 324 */       NodeList list = eventNode.getChildNodes();
/* 325 */       int listLength = list.getLength();
/*     */       
/* 327 */       if (listLength != 0)
/*     */       {
/*     */ 
/*     */ 
/* 331 */         for (int y = 0; y < listLength; y++) {
/* 332 */           String tagName = list.item(y).getNodeName();
/*     */           
/* 334 */           if (tagName.equalsIgnoreCase("logger")) {
/* 335 */             logger = Logger.getLogger(getCData(list.item(y)));
/*     */           }
/*     */           
/* 338 */           if (tagName.equalsIgnoreCase("millis")) {
/* 339 */             timeStamp = Long.parseLong(getCData(list.item(y)));
/*     */           }
/*     */           
/* 342 */           if (tagName.equalsIgnoreCase("level")) {
/* 343 */             level = UtilLoggingLevel.toLevel(getCData(list.item(y)));
/*     */           }
/*     */           
/* 346 */           if (tagName.equalsIgnoreCase("thread")) {
/* 347 */             threadName = getCData(list.item(y));
/*     */           }
/*     */           
/* 350 */           if (tagName.equalsIgnoreCase("sequence")) {
/* 351 */             properties.put("log4jid", getCData(list.item(y)));
/*     */           }
/*     */           
/* 354 */           if (tagName.equalsIgnoreCase("message")) {
/* 355 */             message = getCData(list.item(y));
/*     */           }
/*     */           
/* 358 */           if (tagName.equalsIgnoreCase("class")) {
/* 359 */             className = getCData(list.item(y));
/*     */           }
/*     */           
/* 362 */           if (tagName.equalsIgnoreCase("method")) {
/* 363 */             methodName = getCData(list.item(y));
/*     */           }
/*     */           
/* 366 */           if (tagName.equalsIgnoreCase("exception")) {
/* 367 */             ArrayList exceptionList = new ArrayList();
/* 368 */             NodeList exList = list.item(y).getChildNodes();
/* 369 */             int exlistLength = exList.getLength();
/*     */             
/* 371 */             for (int i2 = 0; i2 < exlistLength; i2++) {
/* 372 */               Node exNode = exList.item(i2);
/* 373 */               String exName = exList.item(i2).getNodeName();
/*     */               
/* 375 */               if (exName.equalsIgnoreCase("message")) {
/* 376 */                 exceptionList.add(getCData(exList.item(i2)));
/*     */               }
/*     */               
/* 379 */               if (exName.equalsIgnoreCase("frame")) {
/* 380 */                 NodeList exList2 = exNode.getChildNodes();
/* 381 */                 int exlist2Length = exList2.getLength();
/*     */                 
/* 383 */                 for (int i3 = 0; i3 < exlist2Length; i3++) {
/* 384 */                   exceptionList.add(getCData(exList2.item(i3)) + "\n");
/*     */                 }
/*     */               }
/*     */             }
/* 388 */             if (exceptionList.size() > 0) {
/* 389 */               exception = (String[])exceptionList.toArray(new String[exceptionList.size()]);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 399 */         if (this.additionalProperties.size() > 0) {
/* 400 */           if (properties == null) {
/* 401 */             properties = new Hashtable(this.additionalProperties);
/*     */           }
/* 403 */           Iterator i = this.additionalProperties.entrySet().iterator();
/* 404 */           while (i.hasNext()) {
/* 405 */             Map.Entry e = (Map.Entry)i.next();
/* 406 */             properties.put(e.getKey(), e.getValue());
/*     */           }
/*     */         }
/*     */         LocationInfo info;
/*     */         LocationInfo info;
/* 411 */         if ((fileName != null) || (className != null) || (methodName != null) || (lineNumber != null))
/*     */         {
/*     */ 
/*     */ 
/* 415 */           info = new LocationInfo(fileName, className, methodName, lineNumber);
/*     */         } else {
/* 417 */           info = LocationInfo.NA_LOCATION_INFO;
/*     */         }
/*     */         
/* 420 */         ThrowableInformation throwableInfo = null;
/* 421 */         if (exception != null) {
/* 422 */           throwableInfo = new ThrowableInformation(exception);
/*     */         }
/*     */         
/* 425 */         LoggingEvent loggingEvent = new LoggingEvent(null, logger, timeStamp, level, message, threadName, throwableInfo, ndc, info, properties);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 433 */         events.add(loggingEvent);
/*     */       }
/*     */     }
/* 436 */     return events;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCData(Node n)
/*     */   {
/* 445 */     StringBuffer buf = new StringBuffer();
/* 446 */     NodeList nl = n.getChildNodes();
/*     */     
/* 448 */     for (int x = 0; x < nl.getLength(); x++) {
/* 449 */       Node innerNode = nl.item(x);
/*     */       
/* 451 */       if ((innerNode.getNodeType() == 3) || (innerNode.getNodeType() == 4))
/*     */       {
/*     */ 
/* 454 */         buf.append(innerNode.getNodeValue());
/*     */       }
/*     */     }
/*     */     
/* 458 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\xml\UtilLoggingXMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */