/*     */ package org.apache.log4j.receivers.xml;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.LineNumberReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import javax.swing.ProgressMonitorInputStream;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.receivers.spi.Decoder;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.ThrowableInformation;
/*     */ import org.apache.log4j.xml.Log4jEntityResolver;
/*     */ import org.apache.log4j.xml.SAXErrorHandler;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLDecoder
/*     */   implements Decoder
/*     */ {
/*     */   private static final String ENCODING = "UTF-8";
/*     */   private static final String BEGINPART = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><!DOCTYPE log4j:eventSet SYSTEM \"http://localhost/log4j.dtd\"><log4j:eventSet version=\"1.2\" xmlns:log4j=\"http://jakarta.apache.org/log4j/\">";
/*     */   private static final String ENDPART = "</log4j:eventSet>";
/*     */   private static final String RECORD_END = "</log4j:event>";
/*     */   private DocumentBuilder docBuilder;
/*  90 */   private Map additionalProperties = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private String partialEvent;
/*     */   
/*     */ 
/*     */ 
/*  98 */   private Component owner = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLDecoder(Component o)
/*     */   {
/* 105 */     this();
/* 106 */     this.owner = o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XMLDecoder()
/*     */   {
/* 113 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 114 */     dbf.setValidating(false);
/*     */     try
/*     */     {
/* 117 */       this.docBuilder = dbf.newDocumentBuilder();
/* 118 */       this.docBuilder.setErrorHandler(new SAXErrorHandler());
/* 119 */       this.docBuilder.setEntityResolver(new Log4jEntityResolver());
/*     */     } catch (ParserConfigurationException pce) {
/* 121 */       System.err.println("Unable to get document builder");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdditionalProperties(Map properties)
/*     */   {
/* 133 */     this.additionalProperties = properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Document parse(String data)
/*     */   {
/* 143 */     if ((this.docBuilder == null) || (data == null)) {
/* 144 */       return null;
/*     */     }
/* 146 */     Document document = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 158 */       StringBuffer buf = new StringBuffer(1024);
/*     */       
/* 160 */       buf.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?><!DOCTYPE log4j:eventSet SYSTEM \"http://localhost/log4j.dtd\"><log4j:eventSet version=\"1.2\" xmlns:log4j=\"http://jakarta.apache.org/log4j/\">");
/* 161 */       buf.append(data);
/* 162 */       buf.append("</log4j:eventSet>");
/*     */       
/* 164 */       InputSource inputSource = new InputSource(new StringReader(buf.toString()));
/*     */       
/* 166 */       document = this.docBuilder.parse(inputSource);
/*     */     } catch (Exception e) {
/* 168 */       e.printStackTrace();
/*     */     }
/*     */     
/* 171 */     return document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector decode(URL url)
/*     */     throws IOException
/*     */   {
/* 182 */     boolean isZipFile = url.getPath().toLowerCase().endsWith(".zip");
/*     */     InputStream inputStream;
/* 184 */     if (isZipFile) {
/* 185 */       InputStream inputStream = new ZipInputStream(url.openStream());
/*     */       
/* 187 */       ((ZipInputStream)inputStream).getNextEntry();
/*     */     } else {
/* 189 */       inputStream = url.openStream(); }
/*     */     LineNumberReader reader;
/* 191 */     LineNumberReader reader; if (this.owner != null) {
/* 192 */       reader = new LineNumberReader(new InputStreamReader(new ProgressMonitorInputStream(this.owner, "Loading " + url, inputStream), "UTF-8"));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 197 */       reader = new LineNumberReader(new InputStreamReader(inputStream, "UTF-8"));
/*     */     }
/*     */     
/* 200 */     v = new Vector();
/*     */     
/*     */     try
/*     */     {
/*     */       String line;
/* 205 */       while ((line = reader.readLine()) != null) {
/* 206 */         StringBuffer buffer = new StringBuffer(line);
/* 207 */         for (int i = 0; i < 1000; i++) {
/* 208 */           buffer.append(reader.readLine()).append("\n");
/*     */         }
/* 210 */         Vector events = decodeEvents(buffer.toString());
/* 211 */         if (events != null) {
/* 212 */           v.addAll(events);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */       return v;
/*     */     }
/*     */     finally
/*     */     {
/* 216 */       this.partialEvent = null;
/*     */       try {
/* 218 */         if (reader != null) {
/* 219 */           reader.close();
/*     */         }
/*     */       } catch (Exception e) {
/* 222 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector decodeEvents(String document)
/*     */   {
/* 235 */     if (document != null) {
/* 236 */       if (document.trim().equals("")) {
/* 237 */         return null;
/*     */       }
/* 239 */       String newDoc = null;
/* 240 */       String newPartialEvent = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */       if (document.lastIndexOf("</log4j:event>") == -1) {
/* 249 */         this.partialEvent += document;
/* 250 */         return null;
/*     */       }
/*     */       
/* 253 */       if (document.lastIndexOf("</log4j:event>") + "</log4j:event>".length() < document.length())
/*     */       {
/* 255 */         newDoc = document.substring(0, document.lastIndexOf("</log4j:event>") + "</log4j:event>".length());
/*     */         
/* 257 */         newPartialEvent = document.substring(document.lastIndexOf("</log4j:event>") + "</log4j:event>".length());
/*     */       }
/*     */       else {
/* 260 */         newDoc = document;
/*     */       }
/* 262 */       if (this.partialEvent != null) {
/* 263 */         newDoc = this.partialEvent + newDoc;
/*     */       }
/* 265 */       this.partialEvent = newPartialEvent;
/* 266 */       Document doc = parse(newDoc);
/* 267 */       if (doc == null) {
/* 268 */         return null;
/*     */       }
/* 270 */       return decodeEvents(doc);
/*     */     }
/* 272 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggingEvent decode(String data)
/*     */   {
/* 283 */     Document document = parse(data);
/*     */     
/* 285 */     if (document == null) {
/* 286 */       return null;
/*     */     }
/*     */     
/* 289 */     Vector events = decodeEvents(document);
/*     */     
/* 291 */     if (events.size() > 0) {
/* 292 */       return (LoggingEvent)events.firstElement();
/*     */     }
/*     */     
/* 295 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Vector decodeEvents(Document document)
/*     */   {
/* 304 */     Vector events = new Vector();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */     Object message = null;
/* 311 */     String ndc = null;
/* 312 */     String[] exception = null;
/* 313 */     String className = null;
/* 314 */     String methodName = null;
/* 315 */     String fileName = null;
/* 316 */     String lineNumber = null;
/* 317 */     Hashtable properties = null;
/*     */     
/* 319 */     NodeList nl = document.getElementsByTagName("log4j:eventSet");
/* 320 */     Node eventSet = nl.item(0);
/*     */     
/* 322 */     NodeList eventList = eventSet.getChildNodes();
/*     */     
/* 324 */     for (int eventIndex = 0; eventIndex < eventList.getLength(); 
/* 325 */         eventIndex++) {
/* 326 */       Node eventNode = eventList.item(eventIndex);
/*     */       
/* 328 */       if (eventNode.getNodeType() == 1)
/*     */       {
/*     */ 
/* 331 */         Logger logger = Logger.getLogger(eventNode.getAttributes().getNamedItem("logger").getNodeValue());
/* 332 */         long timeStamp = Long.parseLong(eventNode.getAttributes().getNamedItem("timestamp").getNodeValue());
/* 333 */         Level level = Level.toLevel(eventNode.getAttributes().getNamedItem("level").getNodeValue());
/* 334 */         String threadName = eventNode.getAttributes().getNamedItem("thread").getNodeValue();
/*     */         
/* 336 */         NodeList list = eventNode.getChildNodes();
/* 337 */         int listLength = list.getLength();
/*     */         
/* 339 */         if (listLength != 0)
/*     */         {
/*     */ 
/*     */ 
/* 343 */           for (int y = 0; y < listLength; y++) {
/* 344 */             String tagName = list.item(y).getNodeName();
/*     */             
/* 346 */             if (tagName.equalsIgnoreCase("log4j:message")) {
/* 347 */               message = getCData(list.item(y));
/*     */             }
/*     */             
/* 350 */             if (tagName.equalsIgnoreCase("log4j:NDC")) {
/* 351 */               ndc = getCData(list.item(y));
/*     */             }
/*     */             
/* 354 */             if (tagName.equalsIgnoreCase("log4j:MDC")) {
/* 355 */               properties = new Hashtable();
/* 356 */               NodeList propertyList = list.item(y).getChildNodes();
/* 357 */               int propertyLength = propertyList.getLength();
/*     */               
/* 359 */               for (int i = 0; i < propertyLength; i++) {
/* 360 */                 String propertyTag = propertyList.item(i).getNodeName();
/*     */                 
/* 362 */                 if (propertyTag.equalsIgnoreCase("log4j:data")) {
/* 363 */                   Node property = propertyList.item(i);
/* 364 */                   String name = property.getAttributes().getNamedItem("name").getNodeValue();
/*     */                   
/* 366 */                   String value = property.getAttributes().getNamedItem("value").getNodeValue();
/*     */                   
/* 368 */                   properties.put(name, value);
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/* 373 */             if (tagName.equalsIgnoreCase("log4j:throwable")) {
/* 374 */               String exceptionString = getCData(list.item(y));
/* 375 */               if ((exceptionString != null) && (!exceptionString.trim().equals(""))) {
/* 376 */                 exception = new String[] { exceptionString.trim() };
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 381 */             if (tagName.equalsIgnoreCase("log4j:locationinfo")) {
/* 382 */               className = list.item(y).getAttributes().getNamedItem("class").getNodeValue();
/*     */               
/* 384 */               methodName = list.item(y).getAttributes().getNamedItem("method").getNodeValue();
/*     */               
/* 386 */               fileName = list.item(y).getAttributes().getNamedItem("file").getNodeValue();
/*     */               
/* 388 */               lineNumber = list.item(y).getAttributes().getNamedItem("line").getNodeValue();
/*     */             }
/*     */             
/*     */ 
/* 392 */             if (tagName.equalsIgnoreCase("log4j:properties")) {
/* 393 */               if (properties == null) {
/* 394 */                 properties = new Hashtable();
/*     */               }
/* 396 */               NodeList propertyList = list.item(y).getChildNodes();
/* 397 */               int propertyLength = propertyList.getLength();
/*     */               
/* 399 */               for (int i = 0; i < propertyLength; i++) {
/* 400 */                 String propertyTag = propertyList.item(i).getNodeName();
/*     */                 
/* 402 */                 if (propertyTag.equalsIgnoreCase("log4j:data")) {
/* 403 */                   Node property = propertyList.item(i);
/* 404 */                   String name = property.getAttributes().getNamedItem("name").getNodeValue();
/*     */                   
/* 406 */                   String value = property.getAttributes().getNamedItem("value").getNodeValue();
/*     */                   
/* 408 */                   properties.put(name, value);
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 417 */             if (this.additionalProperties.size() > 0) {
/* 418 */               if (properties == null) {
/* 419 */                 properties = new Hashtable(this.additionalProperties);
/*     */               }
/* 421 */               Iterator i = this.additionalProperties.entrySet().iterator();
/* 422 */               while (i.hasNext()) {
/* 423 */                 Map.Entry e = (Map.Entry)i.next();
/* 424 */                 properties.put(e.getKey(), e.getValue());
/*     */               }
/*     */             }
/*     */           }
/*     */           LocationInfo info;
/*     */           LocationInfo info;
/* 430 */           if ((fileName != null) || (className != null) || (methodName != null) || (lineNumber != null))
/*     */           {
/*     */ 
/*     */ 
/* 434 */             info = new LocationInfo(fileName, className, methodName, lineNumber);
/*     */           } else {
/* 436 */             info = LocationInfo.NA_LOCATION_INFO;
/*     */           }
/* 438 */           ThrowableInformation throwableInfo = null;
/* 439 */           if (exception != null) {
/* 440 */             throwableInfo = new ThrowableInformation(exception);
/*     */           }
/*     */           
/* 443 */           LoggingEvent loggingEvent = new LoggingEvent(null, logger, timeStamp, level, message, threadName, throwableInfo, ndc, info, properties);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 452 */           events.add(loggingEvent);
/*     */           
/* 454 */           message = null;
/* 455 */           ndc = null;
/* 456 */           exception = null;
/* 457 */           className = null;
/* 458 */           methodName = null;
/* 459 */           fileName = null;
/* 460 */           lineNumber = null;
/* 461 */           properties = null;
/*     */         }
/*     */       } }
/* 464 */     return events;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCData(Node n)
/*     */   {
/* 473 */     StringBuffer buf = new StringBuffer();
/* 474 */     NodeList nl = n.getChildNodes();
/*     */     
/* 476 */     for (int x = 0; x < nl.getLength(); x++) {
/* 477 */       Node innerNode = nl.item(x);
/*     */       
/* 479 */       if ((innerNode.getNodeType() == 3) || (innerNode.getNodeType() == 4))
/*     */       {
/*     */ 
/* 482 */         buf.append(innerNode.getNodeValue());
/*     */       }
/*     */     }
/*     */     
/* 486 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\receivers\xml\XMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */