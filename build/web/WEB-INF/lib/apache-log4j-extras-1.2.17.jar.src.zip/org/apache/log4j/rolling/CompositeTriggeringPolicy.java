/*    */ package org.apache.log4j.rolling;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import org.apache.log4j.Appender;
/*    */ import org.apache.log4j.extras.DOMConfigurator;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ import org.apache.log4j.spi.OptionHandler;
/*    */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompositeTriggeringPolicy
/*    */   implements TriggeringPolicy, UnrecognizedElementHandler
/*    */ {
/* 41 */   Set triggeringPolicies = new HashSet();
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isTriggeringEvent(Appender appender, LoggingEvent event, String file, long fileLength)
/*    */   {
/* 47 */     boolean isTriggered = false;
/* 48 */     for (Iterator iter = this.triggeringPolicies.iterator(); iter.hasNext();) {
/* 49 */       boolean result = ((TriggeringPolicy)iter.next()).isTriggeringEvent(appender, event, file, fileLength);
/* 50 */       isTriggered = (isTriggered) || (result);
/*    */     }
/* 52 */     return isTriggered;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addTriggeringPolicy(TriggeringPolicy policy)
/*    */   {
/* 61 */     this.triggeringPolicies.add(policy);
/*    */   }
/*    */   
/*    */   public void activateOptions() {
/* 65 */     for (Iterator iter = this.triggeringPolicies.iterator(); iter.hasNext();) {
/* 66 */       ((TriggeringPolicy)iter.next()).activateOptions();
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean parseUnrecognizedElement(Element element, Properties props) throws Exception {
/* 71 */     String nodeName = element.getNodeName();
/* 72 */     if ("triggeringPolicy".equals(nodeName)) {
/* 73 */       OptionHandler policy = DOMConfigurator.parseElement(element, props, TriggeringPolicy.class);
/* 74 */       if ((policy instanceof TriggeringPolicy)) {
/* 75 */         policy.activateOptions();
/* 76 */         addTriggeringPolicy((TriggeringPolicy)policy);
/*    */       }
/* 78 */       return true;
/*    */     }
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\CompositeTriggeringPolicy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */