/*     */ package org.apache.log4j.rolling;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Appender;
/*     */ import org.apache.log4j.extras.DOMConfigurator;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.OptionHandler;
/*     */ import org.apache.log4j.spi.TriggeringEventEvaluator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilterBasedTriggeringPolicy
/*     */   implements TriggeringPolicy, TriggeringEventEvaluator, UnrecognizedElementHandler
/*     */ {
/*     */   private Filter headFilter;
/*     */   private Filter tailFilter;
/*     */   
/*     */   public boolean isTriggeringEvent(LoggingEvent event)
/*     */   {
/*  65 */     if (this.headFilter == null) {
/*  66 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  72 */     for (Filter f = this.headFilter; f != null; f = f.next) {
/*  73 */       switch (f.decide(event)) {
/*     */       case -1: 
/*  75 */         return false;
/*     */       
/*     */       case 1: 
/*  78 */         return true;
/*     */       }
/*     */       
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTriggeringEvent(Appender appender, LoggingEvent event, String file, long fileLength)
/*     */   {
/*  93 */     return isTriggeringEvent(event);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFilter(Filter newFilter)
/*     */   {
/* 101 */     if (this.headFilter == null) {
/* 102 */       this.headFilter = newFilter;
/* 103 */       this.tailFilter = newFilter;
/*     */     } else {
/* 105 */       this.tailFilter.next = newFilter;
/* 106 */       this.tailFilter = newFilter;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearFilters()
/*     */   {
/* 115 */     this.headFilter = null;
/* 116 */     this.tailFilter = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter getFilter()
/*     */   {
/* 125 */     return this.headFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 132 */     for (Filter f = this.headFilter; f != null; f = f.next) {
/* 133 */       f.activateOptions();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 142 */     String nodeName = element.getNodeName();
/* 143 */     if ("filter".equals(nodeName)) {
/* 144 */       OptionHandler filter = DOMConfigurator.parseElement(element, props, Filter.class);
/*     */       
/*     */ 
/* 147 */       if ((filter instanceof Filter)) {
/* 148 */         filter.activateOptions();
/* 149 */         addFilter((Filter)filter);
/*     */       }
/* 151 */       return true;
/*     */     }
/* 153 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\FilterBasedTriggeringPolicy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */