/*     */ package org.apache.log4j.rolling;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.pattern.PatternConverter;
/*     */ import org.apache.log4j.rolling.helper.Action;
/*     */ import org.apache.log4j.rolling.helper.FileRenameAction;
/*     */ import org.apache.log4j.rolling.helper.GZCompressAction;
/*     */ import org.apache.log4j.rolling.helper.ZipCompressAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FixedWindowRollingPolicy
/*     */   extends RollingPolicyBase
/*     */ {
/*     */   private static final int MAX_WINDOW_SIZE = 12;
/*     */   private int maxIndex;
/*     */   private int minIndex;
/*     */   private boolean explicitActiveFile;
/*     */   
/*     */   public FixedWindowRollingPolicy()
/*     */   {
/*  92 */     this.minIndex = 1;
/*  93 */     this.maxIndex = 7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 100 */     super.activateOptions();
/*     */     
/* 102 */     if (this.maxIndex < this.minIndex) {
/* 103 */       LogLog.warn("MaxIndex (" + this.maxIndex + ") cannot be smaller than MinIndex (" + this.minIndex + ").");
/*     */       
/*     */ 
/* 106 */       LogLog.warn("Setting maxIndex to equal minIndex.");
/* 107 */       this.maxIndex = this.minIndex;
/*     */     }
/*     */     
/* 110 */     if (this.maxIndex - this.minIndex > 12) {
/* 111 */       LogLog.warn("Large window sizes are not allowed.");
/* 112 */       this.maxIndex = (this.minIndex + 12);
/* 113 */       LogLog.warn("MaxIndex reduced to " + String.valueOf(this.maxIndex) + ".");
/*     */     }
/*     */     
/* 116 */     PatternConverter itc = getIntegerPatternConverter();
/*     */     
/* 118 */     if (itc == null) {
/* 119 */       throw new IllegalStateException("FileNamePattern [" + getFileNamePattern() + "] does not contain a valid integer format specifier");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RolloverDescription initialize(String file, boolean append)
/*     */   {
/* 130 */     String newActiveFile = file;
/* 131 */     this.explicitActiveFile = false;
/*     */     
/* 133 */     if (this.activeFileName != null) {
/* 134 */       this.explicitActiveFile = true;
/* 135 */       newActiveFile = this.activeFileName;
/*     */     }
/*     */     
/* 138 */     if (file != null) {
/* 139 */       this.explicitActiveFile = true;
/* 140 */       newActiveFile = file;
/*     */     }
/*     */     
/* 143 */     if (!this.explicitActiveFile) {
/* 144 */       StringBuffer buf = new StringBuffer();
/* 145 */       formatFileName(new Integer(this.minIndex), buf);
/* 146 */       newActiveFile = buf.toString();
/*     */     }
/*     */     
/* 149 */     return new RolloverDescriptionImpl(newActiveFile, append, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RolloverDescription rollover(String currentFileName)
/*     */   {
/* 156 */     if (this.maxIndex >= 0) {
/* 157 */       int purgeStart = this.minIndex;
/*     */       
/* 159 */       if (!this.explicitActiveFile) {
/* 160 */         purgeStart++;
/*     */       }
/*     */       
/* 163 */       if (!purge(purgeStart, this.maxIndex)) {
/* 164 */         return null;
/*     */       }
/*     */       
/* 167 */       StringBuffer buf = new StringBuffer();
/* 168 */       formatFileName(new Integer(purgeStart), buf);
/*     */       
/* 170 */       String renameTo = buf.toString();
/* 171 */       String compressedName = renameTo;
/* 172 */       Action compressAction = null;
/*     */       
/* 174 */       if (renameTo.endsWith(".gz")) {
/* 175 */         renameTo = renameTo.substring(0, renameTo.length() - 3);
/* 176 */         compressAction = new GZCompressAction(new File(renameTo), new File(compressedName), true);
/*     */ 
/*     */       }
/* 179 */       else if (renameTo.endsWith(".zip")) {
/* 180 */         renameTo = renameTo.substring(0, renameTo.length() - 4);
/* 181 */         compressAction = new ZipCompressAction(new File(renameTo), new File(compressedName), true);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 186 */       FileRenameAction renameAction = new FileRenameAction(new File(currentFileName), new File(renameTo), false);
/*     */       
/*     */ 
/*     */ 
/* 190 */       return new RolloverDescriptionImpl(currentFileName, false, renameAction, compressAction);
/*     */     }
/*     */     
/*     */ 
/* 194 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxIndex()
/*     */   {
/* 202 */     return this.maxIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinIndex()
/*     */   {
/* 210 */     return this.minIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxIndex(int maxIndex)
/*     */   {
/* 218 */     this.maxIndex = maxIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinIndex(int minIndex)
/*     */   {
/* 226 */     this.minIndex = minIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean purge(int lowIndex, int highIndex)
/*     */   {
/* 237 */     int suffixLength = 0;
/*     */     
/* 239 */     List renames = new ArrayList();
/* 240 */     StringBuffer buf = new StringBuffer();
/* 241 */     formatFileName(new Integer(lowIndex), buf);
/*     */     
/* 243 */     String lowFilename = buf.toString();
/*     */     
/* 245 */     if (lowFilename.endsWith(".gz")) {
/* 246 */       suffixLength = 3;
/* 247 */     } else if (lowFilename.endsWith(".zip")) {
/* 248 */       suffixLength = 4;
/*     */     }
/*     */     
/* 251 */     for (int i = lowIndex; i <= highIndex; i++) {
/* 252 */       File toRename = new File(lowFilename);
/* 253 */       boolean isBase = false;
/*     */       
/* 255 */       if (suffixLength > 0) {
/* 256 */         File toRenameBase = new File(lowFilename.substring(0, lowFilename.length() - suffixLength));
/*     */         
/*     */ 
/*     */ 
/* 260 */         if (toRename.exists()) {
/* 261 */           if (toRenameBase.exists()) {
/* 262 */             toRenameBase.delete();
/*     */           }
/*     */         } else {
/* 265 */           toRename = toRenameBase;
/* 266 */           isBase = true;
/*     */         }
/*     */       }
/*     */       
/* 270 */       if (!toRename.exists()) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/* 275 */       if (i == highIndex) {
/* 276 */         if (toRename.delete()) break;
/* 277 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */       buf.setLength(0);
/* 287 */       formatFileName(new Integer(i + 1), buf);
/*     */       
/* 289 */       String highFilename = buf.toString();
/* 290 */       String renameTo = highFilename;
/*     */       
/* 292 */       if (isBase) {
/* 293 */         renameTo = highFilename.substring(0, highFilename.length() - suffixLength);
/*     */       }
/*     */       
/*     */ 
/* 297 */       renames.add(new FileRenameAction(toRename, new File(renameTo), true));
/* 298 */       lowFilename = highFilename;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */     for (int i = renames.size() - 1; i >= 0; i--) {
/* 308 */       Action action = (Action)renames.get(i);
/*     */       try
/*     */       {
/* 311 */         if (!action.execute()) {
/* 312 */           return false;
/*     */         }
/*     */       } catch (Exception ex) {
/* 315 */         LogLog.warn("Exception during purge in RollingFileAppender", ex);
/*     */         
/* 317 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 321 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\FixedWindowRollingPolicy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */