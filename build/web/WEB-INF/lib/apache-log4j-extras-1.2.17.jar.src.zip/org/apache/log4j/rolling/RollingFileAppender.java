/*     */ package org.apache.log4j.rolling;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Appender;
/*     */ import org.apache.log4j.FileAppender;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.extras.DOMConfigurator;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.helpers.QuietWriter;
/*     */ import org.apache.log4j.rolling.helper.Action;
/*     */ import org.apache.log4j.spi.ErrorHandler;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.OptionHandler;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RollingFileAppender
/*     */   extends FileAppender
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*     */   private TriggeringPolicy triggeringPolicy;
/*     */   private RollingPolicy rollingPolicy;
/* 103 */   private long fileLength = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private Action lastRolloverAsyncAction = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 121 */     if (this.rollingPolicy == null) {
/* 122 */       LogLog.warn("Please set a rolling policy for the RollingFileAppender named '" + getName() + "'");
/*     */       
/*     */ 
/*     */ 
/* 126 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 132 */     if ((this.triggeringPolicy == null) && ((this.rollingPolicy instanceof TriggeringPolicy)))
/*     */     {
/* 134 */       this.triggeringPolicy = ((TriggeringPolicy)this.rollingPolicy);
/*     */     }
/*     */     
/* 137 */     if (this.triggeringPolicy == null) {
/* 138 */       LogLog.warn("Please set a TriggeringPolicy for the RollingFileAppender named '" + getName() + "'");
/*     */       
/*     */ 
/*     */ 
/* 142 */       return;
/*     */     }
/*     */     
/* 145 */     Exception exception = null;
/*     */     
/* 147 */     synchronized (this) {
/* 148 */       this.triggeringPolicy.activateOptions();
/* 149 */       this.rollingPolicy.activateOptions();
/*     */       try
/*     */       {
/* 152 */         RolloverDescription rollover = this.rollingPolicy.initialize(getFile(), getAppend());
/*     */         
/*     */ 
/* 155 */         if (rollover != null) {
/* 156 */           Action syncAction = rollover.getSynchronous();
/*     */           
/* 158 */           if (syncAction != null) {
/* 159 */             syncAction.execute();
/*     */           }
/*     */           
/* 162 */           setFile(rollover.getActiveFileName());
/* 163 */           setAppend(rollover.getAppend());
/* 164 */           this.lastRolloverAsyncAction = rollover.getAsynchronous();
/*     */           
/* 166 */           if (this.lastRolloverAsyncAction != null) {
/* 167 */             Thread runner = new Thread(this.lastRolloverAsyncAction);
/* 168 */             runner.start();
/*     */           }
/*     */         }
/*     */         
/* 172 */         File activeFile = new File(getFile());
/*     */         
/* 174 */         if (getAppend()) {
/* 175 */           this.fileLength = activeFile.length();
/*     */         } else {
/* 177 */           this.fileLength = 0L;
/*     */         }
/*     */         
/* 180 */         super.activateOptions();
/*     */       } catch (Exception ex) {
/* 182 */         exception = ex;
/*     */       }
/*     */     }
/*     */     
/* 186 */     if (exception != null) {
/* 187 */       LogLog.warn("Exception while initializing RollingFileAppender named '" + getName() + "'", exception);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private QuietWriter createQuietWriter(Writer writer)
/*     */   {
/* 195 */     ErrorHandler handler = this.errorHandler;
/* 196 */     if (handler == null) {
/* 197 */       handler = new DefaultErrorHandler(this);
/*     */     }
/* 199 */     return new QuietWriter(writer, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean rollover()
/*     */   {
/* 222 */     if (this.rollingPolicy != null) {
/* 223 */       Exception exception = null;
/*     */       
/* 225 */       synchronized (this)
/*     */       {
/*     */ 
/*     */ 
/* 229 */         if (this.lastRolloverAsyncAction != null)
/*     */         {
/*     */ 
/*     */ 
/* 233 */           this.lastRolloverAsyncAction.close();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 242 */           RolloverDescription rollover = this.rollingPolicy.rollover(getFile());
/*     */           
/* 244 */           if (rollover != null) {
/* 245 */             if (rollover.getActiveFileName().equals(getFile())) {
/* 246 */               closeWriter();
/*     */               
/* 248 */               boolean success = true;
/*     */               
/* 250 */               if (rollover.getSynchronous() != null) {
/* 251 */                 success = false;
/*     */                 try
/*     */                 {
/* 254 */                   success = rollover.getSynchronous().execute();
/*     */                 } catch (Exception ex) {
/* 256 */                   exception = ex;
/*     */                 }
/*     */               }
/*     */               
/* 260 */               if (success) {
/* 261 */                 if (rollover.getAppend()) {
/* 262 */                   this.fileLength = new File(rollover.getActiveFileName()).length();
/*     */                 } else {
/* 264 */                   this.fileLength = 0L;
/*     */                 }
/*     */                 
/* 267 */                 if (rollover.getAsynchronous() != null) {
/* 268 */                   this.lastRolloverAsyncAction = rollover.getAsynchronous();
/* 269 */                   new Thread(this.lastRolloverAsyncAction).start();
/*     */                 }
/*     */                 
/* 272 */                 setFile(rollover.getActiveFileName(), rollover.getAppend(), this.bufferedIO, this.bufferSize);
/*     */               }
/*     */               else
/*     */               {
/* 276 */                 setFile(rollover.getActiveFileName(), true, this.bufferedIO, this.bufferSize);
/*     */                 
/*     */ 
/* 279 */                 if (exception == null) {
/* 280 */                   LogLog.warn("Failure in post-close rollover action");
/*     */                 } else {
/* 282 */                   LogLog.warn("Exception in post-close rollover action", exception);
/*     */                 }
/*     */               }
/*     */             }
/*     */             else {
/* 287 */               Writer newWriter = createWriter(createFileOutputStream(rollover.getActiveFileName(), rollover.getAppend()));
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 292 */               closeWriter();
/* 293 */               setFile(rollover.getActiveFileName());
/* 294 */               this.qw = createQuietWriter(newWriter);
/*     */               
/* 296 */               boolean success = true;
/*     */               
/* 298 */               if (rollover.getSynchronous() != null) {
/* 299 */                 success = false;
/*     */                 try
/*     */                 {
/* 302 */                   success = rollover.getSynchronous().execute();
/*     */                 } catch (Exception ex) {
/* 304 */                   exception = ex;
/*     */                 }
/*     */               }
/*     */               
/* 308 */               if (success) {
/* 309 */                 if (rollover.getAppend()) {
/* 310 */                   this.fileLength = new File(rollover.getActiveFileName()).length();
/*     */                 } else {
/* 312 */                   this.fileLength = 0L;
/*     */                 }
/*     */                 
/* 315 */                 if (rollover.getAsynchronous() != null) {
/* 316 */                   this.lastRolloverAsyncAction = rollover.getAsynchronous();
/* 317 */                   new Thread(this.lastRolloverAsyncAction).start();
/*     */                 }
/*     */               }
/*     */               
/* 321 */               writeHeader();
/*     */             }
/*     */             
/* 324 */             return true;
/*     */           }
/*     */         } catch (Exception ex) {
/* 327 */           exception = ex;
/*     */         }
/*     */       }
/*     */       
/* 331 */       if (exception != null) {
/* 332 */         LogLog.warn("Exception during rollover, rollover deferred.", exception);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 337 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FileOutputStream createFileOutputStream(String newFileName, boolean append)
/*     */     throws FileNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 354 */       return new FileOutputStream(newFileName, append);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (FileNotFoundException ex)
/*     */     {
/*     */ 
/* 361 */       String parentName = new File(newFileName).getParent();
/* 362 */       if (parentName != null) {
/* 363 */         File parentDir = new File(parentName);
/* 364 */         if ((!parentDir.exists()) && (parentDir.mkdirs())) {
/* 365 */           return new FileOutputStream(newFileName, append);
/*     */         }
/* 367 */         throw ex;
/*     */       }
/*     */       
/* 370 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void subAppend(LoggingEvent event)
/*     */   {
/* 381 */     if (this.triggeringPolicy.isTriggeringEvent(this, event, getFile(), getFileLength()))
/*     */     {
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 390 */         rollover();
/*     */       } catch (Exception ex) {
/* 392 */         LogLog.warn("Exception during rollover attempt.", ex);
/*     */       }
/*     */     }
/*     */     
/* 396 */     super.subAppend(event);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RollingPolicy getRollingPolicy()
/*     */   {
/* 404 */     return this.rollingPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TriggeringPolicy getTriggeringPolicy()
/*     */   {
/* 412 */     return this.triggeringPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRollingPolicy(RollingPolicy policy)
/*     */   {
/* 420 */     this.rollingPolicy = policy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTriggeringPolicy(TriggeringPolicy policy)
/*     */   {
/* 428 */     this.triggeringPolicy = policy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 435 */     synchronized (this) {
/* 436 */       if (this.lastRolloverAsyncAction != null) {
/* 437 */         this.lastRolloverAsyncAction.close();
/*     */       }
/*     */     }
/*     */     
/* 441 */     super.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OutputStreamWriter createWriter(OutputStream os)
/*     */   {
/* 454 */     return super.createWriter(new CountingOutputStream(os, this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getFileLength()
/*     */   {
/* 462 */     return this.fileLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void incrementFileLength(int increment)
/*     */   {
/* 470 */     this.fileLength += increment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 480 */     String nodeName = element.getNodeName();
/* 481 */     if ("rollingPolicy".equals(nodeName)) {
/* 482 */       OptionHandler rollingPolicy = DOMConfigurator.parseElement(element, props, RollingPolicy.class);
/*     */       
/*     */ 
/* 485 */       if (rollingPolicy != null) {
/* 486 */         rollingPolicy.activateOptions();
/* 487 */         setRollingPolicy((RollingPolicy)rollingPolicy);
/*     */       }
/* 489 */       return true;
/*     */     }
/* 491 */     if ("triggeringPolicy".equals(nodeName)) {
/* 492 */       OptionHandler triggerPolicy = DOMConfigurator.parseElement(element, props, TriggeringPolicy.class);
/*     */       
/*     */ 
/* 495 */       if (triggerPolicy != null) {
/* 496 */         triggerPolicy.activateOptions();
/* 497 */         setTriggeringPolicy((TriggeringPolicy)triggerPolicy);
/*     */       }
/* 499 */       return true;
/*     */     }
/* 501 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class CountingOutputStream
/*     */     extends OutputStream
/*     */   {
/*     */     private final OutputStream os;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final RollingFileAppender rfa;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CountingOutputStream(OutputStream os, RollingFileAppender rfa)
/*     */     {
/* 526 */       this.os = os;
/* 527 */       this.rfa = rfa;
/*     */     }
/*     */     
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 534 */       this.os.close();
/*     */     }
/*     */     
/*     */ 
/*     */     public void flush()
/*     */       throws IOException
/*     */     {
/* 541 */       this.os.flush();
/*     */     }
/*     */     
/*     */ 
/*     */     public void write(byte[] b)
/*     */       throws IOException
/*     */     {
/* 548 */       this.os.write(b);
/* 549 */       this.rfa.incrementFileLength(b.length);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void write(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 557 */       this.os.write(b, off, len);
/* 558 */       this.rfa.incrementFileLength(len);
/*     */     }
/*     */     
/*     */ 
/*     */     public void write(int b)
/*     */       throws IOException
/*     */     {
/* 565 */       this.os.write(b);
/* 566 */       this.rfa.incrementFileLength(1);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class DefaultErrorHandler implements ErrorHandler {
/*     */     private final RollingFileAppender appender;
/*     */     
/* 573 */     public DefaultErrorHandler(RollingFileAppender appender) { this.appender = appender; }
/*     */     
/*     */ 
/*     */     public void setLogger(Logger logger) {}
/*     */     
/*     */     public void error(String message, Exception ioe, int errorCode)
/*     */     {
/* 580 */       this.appender.close();
/* 581 */       LogLog.error("IO failure for appender named " + this.appender.getName(), ioe);
/*     */     }
/*     */     
/*     */     public void error(String message) {}
/*     */     
/*     */     public void error(String message, Exception e, int errorCode, LoggingEvent event) {}
/*     */     
/*     */     public void setAppender(Appender appender) {}
/*     */     
/*     */     public void setBackupAppender(Appender appender) {}
/*     */     
/*     */     public void activateOptions() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\RollingFileAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */