/*     */ package org.apache.log4j.rolling;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.pattern.DatePatternConverter;
/*     */ import org.apache.log4j.pattern.ExtrasFormattingInfo;
/*     */ import org.apache.log4j.pattern.ExtrasPatternParser;
/*     */ import org.apache.log4j.pattern.IntegerPatternConverter;
/*     */ import org.apache.log4j.pattern.PatternConverter;
/*     */ import org.apache.log4j.spi.OptionHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RollingPolicyBase
/*     */   implements RollingPolicy, OptionHandler
/*     */ {
/*     */   private static final String FNP_NOT_SET = "The FileNamePattern option must be set before using RollingPolicy. ";
/*     */   private static final String SEE_FNP_NOT_SET = "See also http://logging.apache.org/log4j/codes.html#tbr_fnp_not_set";
/*     */   private PatternConverter[] patternConverters;
/*     */   private ExtrasFormattingInfo[] patternFields;
/*     */   private String fileNamePatternStr;
/*     */   protected String activeFileName;
/*     */   
/*     */   public void activateOptions()
/*     */   {
/*  80 */     if (this.fileNamePatternStr != null) {
/*  81 */       parseFileNamePattern();
/*     */     } else {
/*  83 */       LogLog.warn("The FileNamePattern option must be set before using RollingPolicy. ");
/*  84 */       LogLog.warn("See also http://logging.apache.org/log4j/codes.html#tbr_fnp_not_set");
/*  85 */       throw new IllegalStateException("The FileNamePattern option must be set before using RollingPolicy. See also http://logging.apache.org/log4j/codes.html#tbr_fnp_not_set");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileNamePattern(String fnp)
/*     */   {
/*  95 */     this.fileNamePatternStr = fnp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileNamePattern()
/*     */   {
/* 103 */     return this.fileNamePatternStr;
/*     */   }
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setActiveFileName(String afn)
/*     */   {
/* 112 */     this.activeFileName = afn;
/*     */   }
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getActiveFileName()
/*     */   {
/* 121 */     return this.activeFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void parseFileNamePattern()
/*     */   {
/* 128 */     List converters = new ArrayList();
/* 129 */     List fields = new ArrayList();
/*     */     
/* 131 */     ExtrasPatternParser.parse(this.fileNamePatternStr, converters, fields, null, ExtrasPatternParser.getFileNamePatternRules());
/*     */     
/*     */ 
/* 134 */     this.patternConverters = new PatternConverter[converters.size()];
/* 135 */     this.patternConverters = ((PatternConverter[])converters.toArray(this.patternConverters));
/*     */     
/* 137 */     this.patternFields = new ExtrasFormattingInfo[converters.size()];
/* 138 */     this.patternFields = ((ExtrasFormattingInfo[])fields.toArray(this.patternFields));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void formatFileName(Object obj, StringBuffer buf)
/*     */   {
/* 149 */     for (int i = 0; i < this.patternConverters.length; i++) {
/* 150 */       int fieldStart = buf.length();
/* 151 */       this.patternConverters[i].format(obj, buf);
/*     */       
/* 153 */       if (this.patternFields[i] != null) {
/* 154 */         this.patternFields[i].format(fieldStart, buf);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected final PatternConverter getDatePatternConverter() {
/* 160 */     for (int i = 0; i < this.patternConverters.length; i++) {
/* 161 */       if ((this.patternConverters[i] instanceof DatePatternConverter)) {
/* 162 */         return this.patternConverters[i];
/*     */       }
/*     */     }
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   protected final PatternConverter getIntegerPatternConverter()
/*     */   {
/* 170 */     for (int i = 0; i < this.patternConverters.length; i++) {
/* 171 */       if ((this.patternConverters[i] instanceof IntegerPatternConverter)) {
/* 172 */         return this.patternConverters[i];
/*     */       }
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\RollingPolicyBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */