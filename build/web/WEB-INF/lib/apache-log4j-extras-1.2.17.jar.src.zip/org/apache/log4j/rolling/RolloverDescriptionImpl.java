/*     */ package org.apache.log4j.rolling;
/*     */ 
/*     */ import org.apache.log4j.rolling.helper.Action;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RolloverDescriptionImpl
/*     */   implements RolloverDescription
/*     */ {
/*     */   private final String activeFileName;
/*     */   private final boolean append;
/*     */   private final Action synchronous;
/*     */   private final Action asynchronous;
/*     */   
/*     */   public RolloverDescriptionImpl(String activeFileName, boolean append, Action synchronous, Action asynchronous)
/*     */   {
/*  63 */     if (activeFileName == null) {
/*  64 */       throw new NullPointerException("activeFileName");
/*     */     }
/*     */     
/*  67 */     this.append = append;
/*  68 */     this.activeFileName = activeFileName;
/*  69 */     this.synchronous = synchronous;
/*  70 */     this.asynchronous = asynchronous;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getActiveFileName()
/*     */   {
/*  78 */     return this.activeFileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getAppend()
/*     */   {
/*  85 */     return this.append;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Action getSynchronous()
/*     */   {
/*  95 */     return this.synchronous;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Action getAsynchronous()
/*     */   {
/* 105 */     return this.asynchronous;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\RolloverDescriptionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */