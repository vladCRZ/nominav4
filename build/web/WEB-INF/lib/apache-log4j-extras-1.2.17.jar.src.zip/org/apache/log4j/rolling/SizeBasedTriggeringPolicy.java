/*    */ package org.apache.log4j.rolling;
/*    */ 
/*    */ import org.apache.log4j.Appender;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ import org.apache.log4j.spi.OptionHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SizeBasedTriggeringPolicy
/*    */   implements TriggeringPolicy, OptionHandler
/*    */ {
/* 38 */   private long maxFileSize = 10485760L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SizeBasedTriggeringPolicy() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SizeBasedTriggeringPolicy(long maxFileSize)
/*    */   {
/* 51 */     this.maxFileSize = maxFileSize;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isTriggeringEvent(Appender appender, LoggingEvent event, String file, long fileLength)
/*    */   {
/* 61 */     return fileLength >= this.maxFileSize;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getMaxFileSize()
/*    */   {
/* 69 */     return this.maxFileSize;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMaxFileSize(long l)
/*    */   {
/* 77 */     this.maxFileSize = l;
/*    */   }
/*    */   
/*    */   public void activateOptions() {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\SizeBasedTriggeringPolicy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */