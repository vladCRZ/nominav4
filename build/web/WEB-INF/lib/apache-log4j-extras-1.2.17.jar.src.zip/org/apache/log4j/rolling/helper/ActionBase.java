/*    */ package org.apache.log4j.rolling.helper;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ActionBase
/*    */   implements Action
/*    */ {
/* 32 */   private boolean complete = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 37 */   private boolean interrupted = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract boolean execute()
/*    */     throws IOException;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized void run()
/*    */   {
/* 57 */     if (!this.interrupted) {
/*    */       try {
/* 59 */         execute();
/*    */       } catch (IOException ex) {
/* 61 */         reportException(ex);
/*    */       }
/*    */       
/* 64 */       this.complete = true;
/* 65 */       this.interrupted = true;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public synchronized void close()
/*    */   {
/* 73 */     this.interrupted = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isComplete()
/*    */   {
/* 81 */     return this.complete;
/*    */   }
/*    */   
/*    */   protected void reportException(Exception ex) {}
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\helper\ActionBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */