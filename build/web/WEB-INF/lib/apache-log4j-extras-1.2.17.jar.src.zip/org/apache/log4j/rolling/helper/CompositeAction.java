/*     */ package org.apache.log4j.rolling.helper;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeAction
/*     */   extends ActionBase
/*     */ {
/*     */   private final Action[] actions;
/*     */   private final boolean stopOnError;
/*     */   
/*     */   public CompositeAction(List actions, boolean stopOnError)
/*     */   {
/*  50 */     this.actions = new Action[actions.size()];
/*  51 */     actions.toArray(this.actions);
/*  52 */     this.stopOnError = stopOnError;
/*     */   }
/*     */   
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*  60 */       execute();
/*     */     } catch (IOException ex) {
/*  62 */       LogLog.warn("Exception during file rollover.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean execute()
/*     */     throws IOException
/*     */   {
/*  72 */     if (this.stopOnError) {
/*  73 */       for (int i = 0; i < this.actions.length; i++) {
/*  74 */         if (!this.actions[i].execute()) {
/*  75 */           return false;
/*     */         }
/*     */       }
/*     */       
/*  79 */       return true;
/*     */     }
/*  81 */     boolean status = true;
/*  82 */     IOException exception = null;
/*     */     
/*  84 */     for (int i = 0; i < this.actions.length; i++) {
/*     */       try {
/*  86 */         status &= this.actions[i].execute();
/*     */       } catch (IOException ex) {
/*  88 */         status = false;
/*     */         
/*  90 */         if (exception == null) {
/*  91 */           exception = ex;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  96 */     if (exception != null) {
/*  97 */       throw exception;
/*     */     }
/*     */     
/* 100 */     return status;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\helper\CompositeAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */