/*     */ package org.apache.log4j.rolling.helper;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GZCompressAction
/*     */   extends ActionBase
/*     */ {
/*     */   private final File source;
/*     */   private final File destination;
/*     */   private final boolean deleteSource;
/*     */   
/*     */   public GZCompressAction(File source, File destination, boolean deleteSource)
/*     */   {
/*  62 */     if (source == null) {
/*  63 */       throw new NullPointerException("source");
/*     */     }
/*     */     
/*  66 */     if (destination == null) {
/*  67 */       throw new NullPointerException("destination");
/*     */     }
/*     */     
/*  70 */     this.source = source;
/*  71 */     this.destination = destination;
/*  72 */     this.deleteSource = deleteSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean execute()
/*     */     throws IOException
/*     */   {
/*  81 */     return execute(this.source, this.destination, this.deleteSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean execute(File source, File destination, boolean deleteSource)
/*     */     throws IOException
/*     */   {
/*  97 */     if (source.exists()) {
/*  98 */       FileInputStream fis = new FileInputStream(source);
/*  99 */       FileOutputStream fos = new FileOutputStream(destination);
/* 100 */       GZIPOutputStream gzos = new GZIPOutputStream(fos);
/* 101 */       byte[] inbuf = new byte['ᾦ'];
/*     */       
/*     */       int n;
/* 104 */       while ((n = fis.read(inbuf)) != -1) {
/* 105 */         gzos.write(inbuf, 0, n);
/*     */       }
/*     */       
/* 108 */       gzos.close();
/* 109 */       fis.close();
/*     */       
/* 111 */       if ((deleteSource) && (!source.delete())) {
/* 112 */         LogLog.warn("Unable to delete " + source.toString() + ".");
/*     */       }
/*     */       
/* 115 */       return true;
/*     */     }
/*     */     
/* 118 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reportException(Exception ex)
/*     */   {
/* 128 */     LogLog.warn("Exception during compression of '" + this.source.toString() + "'.", ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\helper\GZCompressAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */