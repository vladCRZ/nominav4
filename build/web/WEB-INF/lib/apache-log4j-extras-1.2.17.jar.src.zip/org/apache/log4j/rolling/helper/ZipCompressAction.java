/*     */ package org.apache.log4j.rolling.helper;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ZipCompressAction
/*     */   extends ActionBase
/*     */ {
/*     */   private final File source;
/*     */   private final File destination;
/*     */   private final boolean deleteSource;
/*     */   
/*     */   public ZipCompressAction(File source, File destination, boolean deleteSource)
/*     */   {
/*  63 */     if (source == null) {
/*  64 */       throw new NullPointerException("source");
/*     */     }
/*     */     
/*  67 */     if (destination == null) {
/*  68 */       throw new NullPointerException("destination");
/*     */     }
/*     */     
/*  71 */     this.source = source;
/*  72 */     this.destination = destination;
/*  73 */     this.deleteSource = deleteSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean execute()
/*     */     throws IOException
/*     */   {
/*  82 */     return execute(this.source, this.destination, this.deleteSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean execute(File source, File destination, boolean deleteSource)
/*     */     throws IOException
/*     */   {
/*  98 */     if (source.exists()) {
/*  99 */       FileInputStream fis = new FileInputStream(source);
/* 100 */       FileOutputStream fos = new FileOutputStream(destination);
/* 101 */       ZipOutputStream zos = new ZipOutputStream(fos);
/*     */       
/* 103 */       ZipEntry zipEntry = new ZipEntry(source.getName());
/* 104 */       zos.putNextEntry(zipEntry);
/*     */       
/* 106 */       byte[] inbuf = new byte['ᾦ'];
/*     */       
/*     */       int n;
/* 109 */       while ((n = fis.read(inbuf)) != -1) {
/* 110 */         zos.write(inbuf, 0, n);
/*     */       }
/*     */       
/* 113 */       zos.close();
/* 114 */       fis.close();
/*     */       
/* 116 */       if ((deleteSource) && (!source.delete())) {
/* 117 */         LogLog.warn("Unable to delete " + source.toString() + ".");
/*     */       }
/*     */       
/* 120 */       return true;
/*     */     }
/*     */     
/* 123 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reportException(Exception ex)
/*     */   {
/* 132 */     LogLog.warn("Exception during compression of '" + this.source.toString() + "'.", ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rolling\helper\ZipCompressAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */