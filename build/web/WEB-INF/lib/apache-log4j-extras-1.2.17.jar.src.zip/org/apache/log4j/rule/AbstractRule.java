/*    */ package org.apache.log4j.rule;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import java.beans.PropertyChangeSupport;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRule
/*    */   implements Rule, Serializable
/*    */ {
/*    */   static final long serialVersionUID = -2844288145563025172L;
/* 41 */   private PropertyChangeSupport propertySupport = new PropertyChangeSupport(this);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addPropertyChangeListener(PropertyChangeListener l)
/*    */   {
/* 49 */     this.propertySupport.addPropertyChangeListener(l);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void removePropertyChangeListener(PropertyChangeListener l)
/*    */   {
/* 57 */     this.propertySupport.removePropertyChangeListener(l);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void firePropertyChange(String propertyName, Object oldVal, Object newVal)
/*    */   {
/* 70 */     this.propertySupport.firePropertyChange(propertyName, oldVal, newVal);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void firePropertyChange(PropertyChangeEvent evt)
/*    */   {
/* 78 */     this.propertySupport.firePropertyChange(evt);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\AbstractRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */