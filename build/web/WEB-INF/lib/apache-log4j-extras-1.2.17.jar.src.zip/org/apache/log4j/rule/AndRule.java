/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndRule
/*     */   extends AbstractRule
/*     */ {
/*     */   private final Rule firstRule;
/*     */   private final Rule secondRule;
/*     */   static final long serialVersionUID = -8233444426923854651L;
/*     */   
/*     */   private AndRule(Rule first, Rule second)
/*     */   {
/*  56 */     this.firstRule = first;
/*  57 */     this.secondRule = second;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  66 */     if (stack.size() < 2) {
/*  67 */       throw new IllegalArgumentException("Invalid AND rule - expected two rules but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*  71 */     Object o2 = stack.pop();
/*  72 */     Object o1 = stack.pop();
/*  73 */     if (((o2 instanceof Rule)) && ((o1 instanceof Rule))) {
/*  74 */       Rule p2 = (Rule)o2;
/*  75 */       Rule p1 = (Rule)o1;
/*  76 */       return new AndRule(p1, p2);
/*     */     }
/*  78 */     throw new IllegalArgumentException("Invalid AND rule: " + o2 + "..." + o1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Rule firstParam, Rule secondParam)
/*     */   {
/*  88 */     return new AndRule(firstParam, secondParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/*  95 */     if (matches == null) {
/*  96 */       return (this.firstRule.evaluate(event, null)) && (this.secondRule.evaluate(event, null));
/*     */     }
/*  98 */     Map tempMatches1 = new HashMap();
/*  99 */     Map tempMatches2 = new HashMap();
/* 100 */     boolean result = (this.firstRule.evaluate(event, tempMatches1)) && (this.secondRule.evaluate(event, tempMatches2));
/* 101 */     Iterator iter; if (result) {
/* 102 */       for (Iterator iter = tempMatches1.entrySet().iterator(); iter.hasNext();) {
/* 103 */         Map.Entry entry = (Map.Entry)iter.next();
/* 104 */         Object key = entry.getKey();
/* 105 */         Set value = (Set)entry.getValue();
/* 106 */         Set mainSet = (Set)matches.get(key);
/* 107 */         if (mainSet == null) {
/* 108 */           mainSet = new HashSet();
/* 109 */           matches.put(key, mainSet);
/*     */         }
/* 111 */         mainSet.addAll(value);
/*     */       }
/* 113 */       for (iter = tempMatches2.entrySet().iterator(); iter.hasNext();) {
/* 114 */         Map.Entry entry = (Map.Entry)iter.next();
/* 115 */         Object key = entry.getKey();
/* 116 */         Set value = (Set)entry.getValue();
/* 117 */         Set mainSet = (Set)matches.get(key);
/* 118 */         if (mainSet == null) {
/* 119 */           mainSet = new HashSet();
/* 120 */           matches.put(key, mainSet);
/*     */         }
/* 122 */         mainSet.addAll(value);
/*     */       }
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\AndRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */