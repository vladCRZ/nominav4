/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorRule
/*     */   extends AbstractRule
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -794434783372847773L;
/*     */   private final Rule rule;
/*     */   private final Color foregroundColor;
/*     */   private final Color backgroundColor;
/*     */   private final String expression;
/*     */   
/*     */   public ColorRule(String expression, Rule rule, Color backgroundColor, Color foregroundColor)
/*     */   {
/*  67 */     this.expression = expression;
/*  68 */     this.rule = rule;
/*  69 */     this.backgroundColor = backgroundColor;
/*  70 */     this.foregroundColor = foregroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rule getRule()
/*     */   {
/*  78 */     return this.rule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getForegroundColor()
/*     */   {
/*  86 */     return this.foregroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getBackgroundColor()
/*     */   {
/*  94 */     return this.backgroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpression()
/*     */   {
/* 102 */     return this.expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 110 */     return (this.rule != null) && (this.rule.evaluate(event, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 117 */     StringBuffer buf = new StringBuffer("color rule - expression: ");
/* 118 */     buf.append(this.expression);
/* 119 */     buf.append(", rule: ");
/* 120 */     buf.append(this.rule);
/* 121 */     buf.append(" bg: ");
/* 122 */     buf.append(this.backgroundColor);
/* 123 */     buf.append(" fg: ");
/* 124 */     buf.append(this.foregroundColor);
/* 125 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\ColorRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */