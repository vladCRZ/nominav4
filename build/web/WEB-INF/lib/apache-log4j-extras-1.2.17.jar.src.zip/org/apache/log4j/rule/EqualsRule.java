/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EqualsRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = 1712851553477517245L;
/*  43 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String field;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EqualsRule(String field, String value)
/*     */   {
/*  61 */     if (!RESOLVER.isField(field)) {
/*  62 */       throw new IllegalArgumentException("Invalid EQUALS rule - " + field + " is not a supported field");
/*     */     }
/*     */     
/*     */ 
/*  66 */     this.field = field;
/*  67 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  76 */     if (stack.size() < 2) {
/*  77 */       throw new IllegalArgumentException("Invalid EQUALS rule - expected two parameters but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  82 */     String p2 = stack.pop().toString();
/*  83 */     String p1 = stack.pop().toString();
/*     */     
/*  85 */     return getRule(p1, p2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String p1, String p2)
/*     */   {
/*  95 */     if (p1.equalsIgnoreCase("LEVEL"))
/*  96 */       return LevelEqualsRule.getRule(p2);
/*  97 */     if (p1.equalsIgnoreCase("TIMESTAMP")) {
/*  98 */       return TimestampEqualsRule.getRule(p2);
/*     */     }
/* 100 */     return new EqualsRule(p1, p2);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 106 */     Object p2 = RESOLVER.getValue(this.field, event);
/*     */     
/* 108 */     boolean result = (p2 != null) && (p2.toString().equals(this.value));
/* 109 */     if ((result) && (matches != null)) {
/* 110 */       Set entries = (Set)matches.get(this.field.toUpperCase());
/* 111 */       if (entries == null) {
/* 112 */         entries = new HashSet();
/* 113 */         matches.put(this.field.toUpperCase(), entries);
/*     */       }
/* 115 */       entries.add(this.value);
/*     */     }
/* 117 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\EqualsRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */