/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExistsRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -5386265224649967464L;
/*  42 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String field;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExistsRule(String fld)
/*     */   {
/*  55 */     if (!RESOLVER.isField(fld)) {
/*  56 */       throw new IllegalArgumentException("Invalid EXISTS rule - " + fld + " is not a supported field");
/*     */     }
/*     */     
/*     */ 
/*  60 */     this.field = fld;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String field)
/*     */   {
/*  69 */     return new ExistsRule(field);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  79 */     if (stack.size() < 1) {
/*  80 */       throw new IllegalArgumentException("Invalid EXISTS rule - expected one parameter but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  85 */     return new ExistsRule(stack.pop().toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/*  92 */     Object p2 = RESOLVER.getValue(this.field, event);
/*     */     
/*  94 */     boolean result = (p2 != null) && (!p2.toString().equals(""));
/*  95 */     if ((result) && (matches != null)) {
/*  96 */       Set entries = (Set)matches.get(this.field.toUpperCase());
/*  97 */       if (entries == null) {
/*  98 */         entries = new HashSet();
/*  99 */         matches.put(this.field.toUpperCase(), entries);
/*     */       }
/* 101 */       entries.add(p2);
/*     */     }
/* 103 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\ExistsRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */