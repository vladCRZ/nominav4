/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InFixToPostFix
/*     */ {
/*  59 */   private static final Map precedenceMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*  63 */   private static final List operators = new Vector();
/*     */   
/*     */ 
/*     */   static
/*     */   {
/*  68 */     operators.add("<=");
/*  69 */     operators.add(">=");
/*  70 */     operators.add("!=");
/*  71 */     operators.add("==");
/*  72 */     operators.add("~=");
/*  73 */     operators.add("||");
/*  74 */     operators.add("&&");
/*  75 */     operators.add("like");
/*  76 */     operators.add("exists");
/*  77 */     operators.add("!");
/*  78 */     operators.add("<");
/*  79 */     operators.add(">");
/*     */     
/*     */ 
/*  82 */     precedenceMap.put("<", new Integer(3));
/*  83 */     precedenceMap.put(">", new Integer(3));
/*  84 */     precedenceMap.put("<=", new Integer(3));
/*  85 */     precedenceMap.put(">=", new Integer(3));
/*     */     
/*  87 */     precedenceMap.put("!", new Integer(3));
/*  88 */     precedenceMap.put("!=", new Integer(3));
/*  89 */     precedenceMap.put("==", new Integer(3));
/*  90 */     precedenceMap.put("~=", new Integer(3));
/*  91 */     precedenceMap.put("like", new Integer(3));
/*  92 */     precedenceMap.put("exists", new Integer(3));
/*     */     
/*  94 */     precedenceMap.put("||", new Integer(2));
/*  95 */     precedenceMap.put("&&", new Integer(2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String convert(String expression)
/*     */   {
/* 103 */     return infixToPostFix(new CustomTokenizer(expression));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isOperand(String s)
/*     */   {
/* 112 */     String symbol = s.toLowerCase(Locale.ENGLISH);
/* 113 */     return !operators.contains(symbol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean precedes(String s1, String s2)
/*     */   {
/* 123 */     String symbol1 = s1.toLowerCase(Locale.ENGLISH);
/* 124 */     String symbol2 = s2.toLowerCase(Locale.ENGLISH);
/*     */     
/* 126 */     if (!precedenceMap.keySet().contains(symbol1)) {
/* 127 */       return false;
/*     */     }
/*     */     
/* 130 */     if (!precedenceMap.keySet().contains(symbol2)) {
/* 131 */       return false;
/*     */     }
/*     */     
/* 134 */     int index1 = ((Integer)precedenceMap.get(symbol1)).intValue();
/* 135 */     int index2 = ((Integer)precedenceMap.get(symbol2)).intValue();
/*     */     
/* 137 */     boolean precedesResult = index1 < index2;
/*     */     
/* 139 */     return precedesResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String infixToPostFix(CustomTokenizer tokenizer)
/*     */   {
/* 148 */     String space = " ";
/* 149 */     StringBuffer postfix = new StringBuffer();
/*     */     
/* 151 */     Stack stack = new Stack();
/*     */     
/* 153 */     while (tokenizer.hasMoreTokens()) {
/* 154 */       String token = tokenizer.nextToken();
/*     */       
/* 156 */       boolean inText = ((token.startsWith("'")) && (!token.endsWith("'"))) || ((token.startsWith("\"")) && (!token.endsWith("\"")));
/* 157 */       String quoteChar = token.substring(0, 1);
/* 158 */       if (inText) {
/* 159 */         while ((inText) && (tokenizer.hasMoreTokens())) {
/* 160 */           token = token + " " + tokenizer.nextToken();
/* 161 */           inText = !token.endsWith(quoteChar);
/*     */         }
/*     */       }
/*     */       
/* 165 */       if ("(".equals(token))
/*     */       {
/* 167 */         postfix.append(infixToPostFix(tokenizer));
/* 168 */         postfix.append(" ");
/* 169 */       } else { if (")".equals(token))
/*     */         {
/* 171 */           while (stack.size() > 0) {
/* 172 */             postfix.append(stack.pop().toString());
/* 173 */             postfix.append(" ");
/*     */           }
/*     */           
/* 176 */           return postfix.toString(); }
/* 177 */         if (isOperand(token)) {
/* 178 */           postfix.append(token);
/* 179 */           postfix.append(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 187 */         else if (stack.size() > 0)
/*     */         {
/* 189 */           String peek = stack.peek().toString();
/*     */           
/* 191 */           if (precedes(peek, token)) {
/* 192 */             stack.push(token);
/*     */           } else {
/* 194 */             boolean bypass = false;
/*     */             do
/*     */             {
/* 197 */               if ((stack.size() > 0) && (!precedes(stack.peek().toString(), token)))
/*     */               {
/*     */ 
/* 200 */                 postfix.append(stack.pop().toString());
/* 201 */                 postfix.append(" ");
/*     */               } else {
/* 203 */                 bypass = true;
/*     */               }
/* 205 */             } while (!bypass);
/*     */             
/* 207 */             stack.push(token);
/*     */           }
/*     */         } else {
/* 210 */           stack.push(token);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 215 */     while (stack.size() > 0) {
/* 216 */       postfix.append(stack.pop().toString());
/* 217 */       postfix.append(" ");
/*     */     }
/*     */     
/* 220 */     return postfix.toString();
/*     */   }
/*     */   
/*     */   public static class CustomTokenizer {
/* 224 */     private LinkedList linkedList = new LinkedList();
/*     */     
/*     */     public CustomTokenizer(String input) {
/* 227 */       parseInput(input, this.linkedList);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void parseInput(String input, LinkedList linkedList)
/*     */     {
/* 248 */       List keywords = LoggingEventFieldResolver.KEYWORD_LIST;
/*     */       
/* 250 */       keywords.remove("PROP.");
/* 251 */       int pos = 0;
/* 252 */       while (pos < input.length()) {
/* 253 */         if ((nextValueIs(input, pos, "'")) || (nextValueIs(input, pos, "\""))) {
/* 254 */           pos = handleQuotedString(input, pos, linkedList);
/*     */         }
/* 256 */         if (nextValueIs(input, pos, "PROP.")) {
/* 257 */           pos = handleProperty(input, pos, linkedList);
/*     */         }
/* 259 */         boolean operatorFound = false;
/* 260 */         for (Iterator iter = InFixToPostFix.operators.iterator(); iter.hasNext();) {
/* 261 */           String operator = (String)iter.next();
/* 262 */           if (nextValueIs(input, pos, operator)) {
/* 263 */             operatorFound = true;
/* 264 */             pos = handle(pos, linkedList, operator);
/*     */           }
/*     */         }
/* 267 */         boolean keywordFound = false;
/* 268 */         for (Iterator iter = keywords.iterator(); iter.hasNext();) {
/* 269 */           String keyword = (String)iter.next();
/* 270 */           if (nextValueIs(input, pos, keyword)) {
/* 271 */             keywordFound = true;
/* 272 */             pos = handle(pos, linkedList, keyword);
/*     */           }
/*     */         }
/* 275 */         if ((!operatorFound) && (!keywordFound))
/*     */         {
/*     */ 
/* 278 */           if (nextValueIs(input, pos, ")")) {
/* 279 */             pos = handle(pos, linkedList, ")");
/* 280 */           } else if (nextValueIs(input, pos, "(")) {
/* 281 */             pos = handle(pos, linkedList, "(");
/* 282 */           } else if (nextValueIs(input, pos, " ")) {
/* 283 */             pos++;
/*     */           } else
/* 285 */             pos = handleText(input, pos, linkedList);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean nextValueIs(String input, int pos, String value) {
/* 291 */       return (input.length() >= pos + value.length()) && (input.substring(pos, pos + value.length()).equalsIgnoreCase(value));
/*     */     }
/*     */     
/*     */     private int handle(int pos, LinkedList linkedList, String value) {
/* 295 */       linkedList.add(value);
/* 296 */       return pos + value.length();
/*     */     }
/*     */     
/*     */     private int handleQuotedString(String input, int pos, LinkedList linkedList) {
/* 300 */       String quoteChar = input.substring(pos, pos + 1);
/* 301 */       int nextSingleQuotePos = input.indexOf(quoteChar, pos + 1);
/* 302 */       if (nextSingleQuotePos < 0) {
/* 303 */         throw new IllegalArgumentException("Missing an end quote");
/*     */       }
/* 305 */       String result = input.substring(pos, nextSingleQuotePos + 1);
/* 306 */       linkedList.add(result);
/* 307 */       return nextSingleQuotePos + 1;
/*     */     }
/*     */     
/*     */     private int handleText(String input, int pos, LinkedList linkedList) {
/* 311 */       StringBuffer text = new StringBuffer("");
/* 312 */       int newPos = pos;
/* 313 */       while (newPos < input.length()) {
/* 314 */         if (nextValueIs(input, newPos, " ")) {
/* 315 */           linkedList.add(text);
/* 316 */           return newPos;
/*     */         }
/* 318 */         if (nextValueIs(input, newPos, "(")) {
/* 319 */           linkedList.add(text);
/* 320 */           return newPos;
/*     */         }
/* 322 */         if (nextValueIs(input, newPos, ")")) {
/* 323 */           linkedList.add(text);
/* 324 */           return newPos;
/*     */         }
/* 326 */         for (Iterator iter = InFixToPostFix.operators.iterator(); iter.hasNext();) {
/* 327 */           String operator = (String)iter.next();
/* 328 */           if (nextValueIs(input, newPos, operator)) {
/* 329 */             linkedList.add(text);
/* 330 */             return newPos;
/*     */           }
/*     */         }
/* 333 */         text.append(input.substring(newPos++, newPos));
/*     */       }
/*     */       
/* 336 */       if (!text.toString().trim().equals("")) {
/* 337 */         linkedList.add(text);
/*     */       }
/* 339 */       return newPos;
/*     */     }
/*     */     
/*     */     private int handleProperty(String input, int pos, LinkedList linkedList) {
/* 343 */       int propertyPos = pos + "PROP.".length();
/* 344 */       StringBuffer propertyName = new StringBuffer("PROP.");
/* 345 */       while (propertyPos < input.length()) {
/* 346 */         if (nextValueIs(input, propertyPos, " ")) {
/* 347 */           linkedList.add(propertyName);
/* 348 */           return propertyPos;
/*     */         }
/* 350 */         if (nextValueIs(input, propertyPos, "(")) {
/* 351 */           linkedList.add(propertyName);
/* 352 */           return propertyPos;
/*     */         }
/* 354 */         if (nextValueIs(input, propertyPos, ")")) {
/* 355 */           linkedList.add(propertyName);
/* 356 */           return propertyPos;
/*     */         }
/* 358 */         for (Iterator iter = InFixToPostFix.operators.iterator(); iter.hasNext();) {
/* 359 */           String operator = (String)iter.next();
/* 360 */           if (nextValueIs(input, propertyPos, operator)) {
/* 361 */             linkedList.add(propertyName);
/* 362 */             return propertyPos;
/*     */           }
/*     */         }
/* 365 */         propertyName.append(input.substring(propertyPos++, propertyPos));
/*     */       }
/* 367 */       linkedList.add(propertyName);
/* 368 */       return propertyPos;
/*     */     }
/*     */     
/*     */     public boolean hasMoreTokens() {
/* 372 */       return this.linkedList.size() > 0;
/*     */     }
/*     */     
/*     */     public String nextToken() {
/* 376 */       return this.linkedList.remove().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\InFixToPostFix.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */