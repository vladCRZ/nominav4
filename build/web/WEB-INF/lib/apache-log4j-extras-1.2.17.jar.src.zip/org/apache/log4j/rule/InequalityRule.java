/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InequalityRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -5592986598528885122L;
/*  47 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String field;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String inequalitySymbol;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private InequalityRule(String inequalitySymbol, String field, String value)
/*     */   {
/*  73 */     this.inequalitySymbol = inequalitySymbol;
/*  74 */     if (!RESOLVER.isField(field)) {
/*  75 */       throw new IllegalArgumentException("Invalid " + inequalitySymbol + " rule - " + field + " is not a supported field");
/*     */     }
/*     */     
/*     */ 
/*  79 */     this.field = field;
/*  80 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String inequalitySymbol, Stack stack)
/*     */   {
/*  91 */     if (stack.size() < 2) {
/*  92 */       throw new IllegalArgumentException("Invalid " + inequalitySymbol + " rule - expected two parameters but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  97 */     String p2 = stack.pop().toString();
/*  98 */     String p1 = stack.pop().toString();
/*  99 */     return getRule(inequalitySymbol, p1, p2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String inequalitySymbol, String field, String value)
/*     */   {
/* 112 */     if (field.equalsIgnoreCase("LEVEL"))
/*     */     {
/*     */ 
/* 115 */       return LevelInequalityRule.getRule(inequalitySymbol, value); }
/* 116 */     if (field.equalsIgnoreCase("TIMESTAMP"))
/*     */     {
/* 118 */       return TimestampInequalityRule.getRule(inequalitySymbol, value);
/*     */     }
/* 120 */     return new InequalityRule(inequalitySymbol, field, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 126 */     long first = 0L;
/*     */     try {
/* 128 */       first = new Long(RESOLVER.getValue(this.field, event).toString()).longValue();
/*     */     } catch (NumberFormatException nfe) {
/* 130 */       return false;
/*     */     }
/*     */     
/* 133 */     long second = 0L;
/*     */     try
/*     */     {
/* 136 */       second = new Long(this.value).longValue();
/*     */     } catch (NumberFormatException nfe) {
/* 138 */       return false;
/*     */     }
/*     */     
/* 141 */     boolean result = false;
/*     */     
/* 143 */     if ("<".equals(this.inequalitySymbol)) {
/* 144 */       result = first < second;
/* 145 */     } else if (">".equals(this.inequalitySymbol)) {
/* 146 */       result = first > second;
/* 147 */     } else if ("<=".equals(this.inequalitySymbol)) {
/* 148 */       result = first <= second;
/* 149 */     } else if (">=".equals(this.inequalitySymbol)) {
/* 150 */       result = first >= second;
/*     */     }
/* 152 */     if ((result) && (matches != null)) {
/* 153 */       Set entries = (Set)matches.get(this.field.toUpperCase());
/* 154 */       if (entries == null) {
/* 155 */         entries = new HashSet();
/* 156 */         matches.put(this.field.toUpperCase(), entries);
/*     */       }
/* 158 */       entries.add(String.valueOf(first));
/*     */     }
/* 160 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\InequalityRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */