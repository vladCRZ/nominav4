/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.helpers.UtilLoggingLevel;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LevelInequalityRule
/*     */ {
/*     */   private static List levelList;
/*     */   private static List utilLoggingLevelList;
/*     */   
/*     */   private static void populateLevels()
/*     */   {
/*  63 */     levelList = new LinkedList();
/*     */     
/*  65 */     levelList.add(Level.FATAL.toString());
/*  66 */     levelList.add(Level.ERROR.toString());
/*  67 */     levelList.add(Level.WARN.toString());
/*  68 */     levelList.add(Level.INFO.toString());
/*  69 */     levelList.add(Level.DEBUG.toString());
/*  70 */     Level trace = Level.toLevel(5000, null);
/*  71 */     if (trace != null) {
/*  72 */       levelList.add(trace.toString());
/*     */     }
/*     */     
/*  75 */     utilLoggingLevelList = new LinkedList();
/*     */     
/*  77 */     utilLoggingLevelList.add(UtilLoggingLevel.SEVERE.toString());
/*  78 */     utilLoggingLevelList.add(UtilLoggingLevel.WARNING.toString());
/*  79 */     utilLoggingLevelList.add(UtilLoggingLevel.INFO.toString());
/*  80 */     utilLoggingLevelList.add(UtilLoggingLevel.CONFIG.toString());
/*  81 */     utilLoggingLevelList.add(UtilLoggingLevel.FINE.toString());
/*  82 */     utilLoggingLevelList.add(UtilLoggingLevel.FINER.toString());
/*  83 */     utilLoggingLevelList.add(UtilLoggingLevel.FINEST.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String inequalitySymbol, String value)
/*     */   {
/*     */     Level thisLevel;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     if (levelList.contains(value.toUpperCase())) {
/* 106 */       thisLevel = Level.toLevel(value.toUpperCase()); } else { Level thisLevel;
/* 107 */       if (utilLoggingLevelList.contains(value.toUpperCase())) {
/* 108 */         thisLevel = UtilLoggingLevel.toLevel(value.toUpperCase());
/*     */       } else {
/* 110 */         throw new IllegalArgumentException("Invalid level inequality rule - " + value + " is not a supported level");
/*     */       }
/*     */     }
/*     */     
/*     */     Level thisLevel;
/* 115 */     if ("<".equals(inequalitySymbol)) {
/* 116 */       return new LessThanRule(thisLevel);
/*     */     }
/* 118 */     if (">".equals(inequalitySymbol)) {
/* 119 */       return new GreaterThanRule(thisLevel);
/*     */     }
/* 121 */     if ("<=".equals(inequalitySymbol)) {
/* 122 */       return new LessThanEqualsRule(thisLevel);
/*     */     }
/* 124 */     if (">=".equals(inequalitySymbol)) {
/* 125 */       return new GreaterThanEqualsRule(thisLevel);
/*     */     }
/*     */     
/* 128 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static {}
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class LessThanRule
/*     */     extends AbstractRule
/*     */   {
/*     */     private final int newLevelInt;
/*     */     
/*     */ 
/*     */ 
/*     */     public LessThanRule(Level level)
/*     */     {
/* 146 */       this.newLevelInt = level.toInt();
/*     */     }
/*     */     
/*     */     public boolean evaluate(LoggingEvent event, Map matches)
/*     */     {
/* 151 */       Level eventLevel = event.getLevel();
/* 152 */       boolean result = eventLevel.toInt() < this.newLevelInt;
/* 153 */       if ((result) && (matches != null)) {
/* 154 */         Set entries = (Set)matches.get("LEVEL");
/* 155 */         if (entries == null) {
/* 156 */           entries = new HashSet();
/* 157 */           matches.put("LEVEL", entries);
/*     */         }
/* 159 */         entries.add(eventLevel);
/*     */       }
/* 161 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class GreaterThanRule
/*     */     extends AbstractRule
/*     */   {
/*     */     private final int newLevelInt;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public GreaterThanRule(Level level)
/*     */     {
/* 180 */       this.newLevelInt = level.toInt();
/*     */     }
/*     */     
/*     */     public boolean evaluate(LoggingEvent event, Map matches)
/*     */     {
/* 185 */       Level eventLevel = event.getLevel();
/* 186 */       boolean result = eventLevel.toInt() > this.newLevelInt;
/* 187 */       if ((result) && (matches != null)) {
/* 188 */         Set entries = (Set)matches.get("LEVEL");
/* 189 */         if (entries == null) {
/* 190 */           entries = new HashSet();
/* 191 */           matches.put("LEVEL", entries);
/*     */         }
/* 193 */         entries.add(eventLevel);
/*     */       }
/* 195 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class GreaterThanEqualsRule
/*     */     extends AbstractRule
/*     */   {
/*     */     private final int newLevelInt;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public GreaterThanEqualsRule(Level level)
/*     */     {
/* 215 */       this.newLevelInt = level.toInt();
/*     */     }
/*     */     
/*     */     public boolean evaluate(LoggingEvent event, Map matches)
/*     */     {
/* 220 */       Level eventLevel = event.getLevel();
/* 221 */       boolean result = eventLevel.toInt() >= this.newLevelInt;
/* 222 */       if ((result) && (matches != null)) {
/* 223 */         Set entries = (Set)matches.get("LEVEL");
/* 224 */         if (entries == null) {
/* 225 */           entries = new HashSet();
/* 226 */           matches.put("LEVEL", entries);
/*     */         }
/* 228 */         entries.add(eventLevel);
/*     */       }
/* 230 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class LessThanEqualsRule
/*     */     extends AbstractRule
/*     */   {
/*     */     private final int newLevelInt;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public LessThanEqualsRule(Level level)
/*     */     {
/* 251 */       this.newLevelInt = level.toInt();
/*     */     }
/*     */     
/*     */     public boolean evaluate(LoggingEvent event, Map matches)
/*     */     {
/* 256 */       Level eventLevel = event.getLevel();
/* 257 */       boolean result = eventLevel.toInt() <= this.newLevelInt;
/* 258 */       if ((result) && (matches != null)) {
/* 259 */         Set entries = (Set)matches.get("LEVEL");
/* 260 */         if (entries == null) {
/* 261 */           entries = new HashSet();
/* 262 */           matches.put("LEVEL", entries);
/*     */         }
/* 264 */         entries.add(eventLevel);
/*     */       }
/*     */       
/* 267 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\LevelInequalityRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */