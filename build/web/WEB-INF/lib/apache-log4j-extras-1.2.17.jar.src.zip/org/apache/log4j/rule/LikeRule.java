/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LikeRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -3375458885595683156L;
/*  46 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient Pattern pattern;
/*     */   
/*     */ 
/*     */ 
/*  55 */   private transient Matcher matcher = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient String field;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LikeRule(String field, Pattern pattern)
/*     */   {
/*  68 */     if (!RESOLVER.isField(field)) {
/*  69 */       throw new IllegalArgumentException("Invalid LIKE rule - " + field + " is not a supported field");
/*     */     }
/*     */     
/*     */ 
/*  73 */     this.field = field;
/*  74 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  83 */     if (stack.size() < 2) {
/*  84 */       throw new IllegalArgumentException("Invalid LIKE rule - expected two parameters but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  89 */     String p2 = stack.pop().toString();
/*  90 */     String p1 = stack.pop().toString();
/*  91 */     return getRule(p1, p2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String field, String pattern)
/*     */   {
/*     */     try
/*     */     {
/* 102 */       return new LikeRule(field, Pattern.compile(pattern, 2));
/*     */     } catch (PatternSyntaxException e) {
/* 104 */       throw new IllegalArgumentException("Invalid LIKE rule - " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 112 */     Object input = RESOLVER.getValue(this.field, event);
/* 113 */     if ((input != null) && (this.pattern != null)) {
/* 114 */       if (this.matcher == null) {
/* 115 */         this.matcher = this.pattern.matcher(input.toString());
/*     */       } else {
/* 117 */         this.matcher.reset(input.toString());
/*     */       }
/* 119 */       boolean result = this.matcher.matches();
/* 120 */       if ((result) && (matches != null)) {
/* 121 */         Set entries = (Set)matches.get(this.field.toUpperCase());
/* 122 */         if (entries == null) {
/* 123 */           entries = new HashSet();
/* 124 */           matches.put(this.field.toUpperCase(), entries);
/*     */         }
/* 126 */         entries.add(input);
/*     */       }
/* 128 */       return result;
/*     */     }
/* 130 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       this.field = ((String)in.readObject());
/* 145 */       String patternString = (String)in.readObject();
/* 146 */       this.pattern = Pattern.compile(patternString, 2);
/*     */     } catch (PatternSyntaxException e) {
/* 148 */       throw new IOException("Invalid LIKE rule - " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 161 */     out.writeObject(this.field);
/* 162 */     out.writeObject(this.pattern.pattern());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\LikeRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */