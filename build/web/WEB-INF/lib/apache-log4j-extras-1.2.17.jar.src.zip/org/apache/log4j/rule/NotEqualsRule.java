/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotEqualsRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -1135478467213793211L;
/*  42 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String field;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NotEqualsRule(String field, String value)
/*     */   {
/*  60 */     if (!RESOLVER.isField(field)) {
/*  61 */       throw new IllegalArgumentException("Invalid NOT EQUALS rule - " + field + " is not a supported field");
/*     */     }
/*     */     
/*     */ 
/*  65 */     this.field = field;
/*  66 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String field, String value)
/*     */   {
/*  76 */     if (field.equalsIgnoreCase("LEVEL")) {
/*  77 */       return NotLevelEqualsRule.getRule(value);
/*     */     }
/*  79 */     return new NotEqualsRule(field, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  89 */     if (stack.size() < 2) {
/*  90 */       throw new IllegalArgumentException("Invalid NOT EQUALS rule - expected two parameters but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  95 */     String p2 = stack.pop().toString();
/*  96 */     String p1 = stack.pop().toString();
/*     */     
/*  98 */     if (p1.equalsIgnoreCase("LEVEL")) {
/*  99 */       return NotLevelEqualsRule.getRule(p2);
/*     */     }
/* 101 */     return new NotEqualsRule(p1, p2);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 107 */     Object p2 = RESOLVER.getValue(this.field, event);
/*     */     
/* 109 */     boolean result = (p2 != null) && (!p2.toString().equals(this.value));
/* 110 */     if ((result) && (matches != null))
/*     */     {
/* 112 */       Set entries = (Set)matches.get(this.field.toUpperCase());
/* 113 */       if (entries == null) {
/* 114 */         entries = new HashSet();
/* 115 */         matches.put(this.field.toUpperCase(), entries);
/*     */       }
/* 117 */       entries.add(this.value);
/*     */     }
/* 119 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\NotEqualsRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */