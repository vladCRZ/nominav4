/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.helpers.UtilLoggingLevel;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotLevelEqualsRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -3638386582899583994L;
/*     */   private transient Level level;
/*  51 */   private static List levelList = new LinkedList();
/*     */   
/*     */   static {
/*  54 */     populateLevels();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NotLevelEqualsRule(Level level)
/*     */   {
/*  63 */     this.level = level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void populateLevels()
/*     */   {
/*  70 */     levelList = new LinkedList();
/*     */     
/*  72 */     levelList.add(Level.FATAL.toString());
/*  73 */     levelList.add(Level.ERROR.toString());
/*  74 */     levelList.add(Level.WARN.toString());
/*  75 */     levelList.add(Level.INFO.toString());
/*  76 */     levelList.add(Level.DEBUG.toString());
/*  77 */     Level trace = Level.toLevel(5000, null);
/*  78 */     if (trace != null) {
/*  79 */       levelList.add(trace.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static Rule getRule(String value)
/*     */   {
/*     */     Level thisLevel;
/*     */     
/*     */     Level thisLevel;
/*     */     
/*  90 */     if (levelList.contains(value.toUpperCase())) {
/*  91 */       thisLevel = Level.toLevel(value.toUpperCase());
/*     */     } else {
/*  93 */       thisLevel = UtilLoggingLevel.toLevel(value.toUpperCase());
/*     */     }
/*     */     
/*  96 */     return new NotLevelEqualsRule(thisLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 105 */     Level eventLevel = event.getLevel();
/* 106 */     boolean result = this.level.toInt() != eventLevel.toInt();
/* 107 */     if ((result) && (matches != null)) {
/* 108 */       Set entries = (Set)matches.get("LEVEL");
/* 109 */       if (entries == null) {
/* 110 */         entries = new HashSet();
/* 111 */         matches.put("LEVEL", entries);
/*     */       }
/* 113 */       entries.add(eventLevel);
/*     */     }
/* 115 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException
/*     */   {
/* 127 */     populateLevels();
/* 128 */     boolean isUtilLogging = in.readBoolean();
/* 129 */     int levelInt = in.readInt();
/* 130 */     if (isUtilLogging) {
/* 131 */       this.level = UtilLoggingLevel.toLevel(levelInt);
/*     */     } else {
/* 133 */       this.level = Level.toLevel(levelInt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 146 */     out.writeBoolean(this.level instanceof UtilLoggingLevel);
/* 147 */     out.writeInt(this.level.toInt());
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\NotLevelEqualsRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */