/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -6827159473117969306L;
/*     */   private final Rule rule;
/*     */   
/*     */   private NotRule(Rule rule)
/*     */   {
/*  50 */     this.rule = rule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Rule rule)
/*     */   {
/*  59 */     return new NotRule(rule);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  68 */     if (stack.size() < 1) {
/*  69 */       throw new IllegalArgumentException("Invalid NOT rule - expected one rule but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*  73 */     Object o1 = stack.pop();
/*  74 */     if ((o1 instanceof Rule)) {
/*  75 */       Rule p1 = (Rule)o1;
/*  76 */       return new NotRule(p1);
/*     */     }
/*  78 */     throw new IllegalArgumentException("Invalid NOT rule: - expected rule but received " + o1);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/*  84 */     if (matches == null) {
/*  85 */       return !this.rule.evaluate(event, null);
/*     */     }
/*  87 */     Map tempMatches = new HashMap();
/*  88 */     boolean result = !this.rule.evaluate(event, tempMatches);
/*  89 */     Iterator iter; if (result) {
/*  90 */       for (iter = tempMatches.entrySet().iterator(); iter.hasNext();) {
/*  91 */         Map.Entry entry = (Map.Entry)iter.next();
/*  92 */         Object key = entry.getKey();
/*  93 */         Set value = (Set)entry.getValue();
/*  94 */         Set mainSet = (Set)matches.get(key);
/*  95 */         if (mainSet == null) {
/*  96 */           mainSet = new HashSet();
/*  97 */           matches.put(key, mainSet);
/*     */         }
/*  99 */         mainSet.addAll(value);
/*     */       }
/*     */     }
/* 102 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\NotRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */