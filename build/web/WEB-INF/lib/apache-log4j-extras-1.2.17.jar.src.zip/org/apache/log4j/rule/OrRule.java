/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = 2088765995061413165L;
/*     */   private final Rule rule1;
/*     */   private final Rule rule2;
/*     */   
/*     */   private OrRule(Rule firstParam, Rule secondParam)
/*     */   {
/*  55 */     this.rule1 = firstParam;
/*  56 */     this.rule2 = secondParam;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Rule firstParam, Rule secondParam)
/*     */   {
/*  66 */     return new OrRule(firstParam, secondParam);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  75 */     if (stack.size() < 2) {
/*  76 */       throw new IllegalArgumentException("Invalid OR rule - expected two rules but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*  80 */     Object o2 = stack.pop();
/*  81 */     Object o1 = stack.pop();
/*  82 */     if (((o2 instanceof Rule)) && ((o1 instanceof Rule))) {
/*  83 */       Rule p2 = (Rule)o2;
/*  84 */       Rule p1 = (Rule)o1;
/*  85 */       return new OrRule(p1, p2);
/*     */     }
/*  87 */     throw new IllegalArgumentException("Invalid OR rule: " + o2 + "..." + o1);
/*     */   }
/*     */   
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/*  92 */     if (matches == null) {
/*  93 */       return (this.rule1.evaluate(event, null)) || (this.rule2.evaluate(event, null));
/*     */     }
/*  95 */     Map tempMatches1 = new HashMap();
/*  96 */     Map tempMatches2 = new HashMap();
/*     */     
/*  98 */     boolean result1 = this.rule1.evaluate(event, tempMatches1);
/*  99 */     boolean result2 = this.rule2.evaluate(event, tempMatches2);
/* 100 */     boolean result = (result1) || (result2);
/* 101 */     Iterator iter; if (result) {
/* 102 */       for (Iterator iter = tempMatches1.entrySet().iterator(); iter.hasNext();) {
/* 103 */         Map.Entry entry = (Map.Entry)iter.next();
/* 104 */         Object key = entry.getKey();
/* 105 */         Set value = (Set)entry.getValue();
/* 106 */         Set mainSet = (Set)matches.get(key);
/* 107 */         if (mainSet == null) {
/* 108 */           mainSet = new HashSet();
/* 109 */           matches.put(key, mainSet);
/*     */         }
/* 111 */         mainSet.addAll(value);
/*     */       }
/* 113 */       for (iter = tempMatches2.entrySet().iterator(); iter.hasNext();) {
/* 114 */         Map.Entry entry = (Map.Entry)iter.next();
/* 115 */         Object key = entry.getKey();
/* 116 */         Set value = (Set)entry.getValue();
/* 117 */         Set mainSet = (Set)matches.get(key);
/* 118 */         if (mainSet == null) {
/* 119 */           mainSet = new HashSet();
/* 120 */           matches.put(key, mainSet);
/*     */         }
/* 122 */         mainSet.addAll(value);
/*     */       }
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\OrRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */