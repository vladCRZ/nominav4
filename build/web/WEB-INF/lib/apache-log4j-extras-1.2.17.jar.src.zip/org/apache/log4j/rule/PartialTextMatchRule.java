/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartialTextMatchRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = 6963284773637727558L;
/*  43 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String field;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PartialTextMatchRule(String field, String value)
/*     */   {
/*  61 */     if (!RESOLVER.isField(field)) {
/*  62 */       throw new IllegalArgumentException("Invalid partial text rule - " + field + " is not a supported field");
/*     */     }
/*     */     
/*     */ 
/*  66 */     this.field = field;
/*  67 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String field, String value)
/*     */   {
/*  77 */     return new PartialTextMatchRule(field, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(Stack stack)
/*     */   {
/*  86 */     if (stack.size() < 2) {
/*  87 */       throw new IllegalArgumentException("invalid partial text rule - expected two parameters but received " + stack.size());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  92 */     String p2 = stack.pop().toString();
/*  93 */     String p1 = stack.pop().toString();
/*     */     
/*  95 */     return new PartialTextMatchRule(p1, p2);
/*     */   }
/*     */   
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/* 100 */     Object p2 = RESOLVER.getValue(this.field, event);
/* 101 */     boolean result = (p2 != null) && (this.value != null) && (p2.toString().toLowerCase().indexOf(this.value.toLowerCase()) > -1);
/* 102 */     if ((result) && (matches != null)) {
/* 103 */       Set entries = (Set)matches.get(this.field.toUpperCase());
/* 104 */       if (entries == null) {
/* 105 */         entries = new HashSet();
/* 106 */         matches.put(this.field.toUpperCase(), entries);
/*     */       }
/* 108 */       entries.add(this.value);
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\PartialTextMatchRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */