/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Locale;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RuleFactory
/*     */ {
/*  38 */   private static final RuleFactory FACTORY = new RuleFactory();
/*     */   
/*     */ 
/*     */ 
/*  42 */   private static final Collection RULES = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String AND_RULE = "&&";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String OR_RULE = "||";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String NOT_RULE = "!";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String NOT_EQUALS_RULE = "!=";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String EQUALS_RULE = "==";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String PARTIAL_TEXT_MATCH_RULE = "~=";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String LIKE_RULE = "like";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String EXISTS_RULE = "exists";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String LESS_THAN_RULE = "<";
/*     */   
/*     */ 
/*     */   private static final String GREATER_THAN_RULE = ">";
/*     */   
/*     */ 
/*     */   private static final String LESS_THAN_EQUALS_RULE = "<=";
/*     */   
/*     */ 
/*     */   private static final String GREATER_THAN_EQUALS_RULE = ">=";
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  93 */     RULES.add("&&");
/*  94 */     RULES.add("||");
/*  95 */     RULES.add("!");
/*  96 */     RULES.add("!=");
/*  97 */     RULES.add("==");
/*  98 */     RULES.add("~=");
/*  99 */     RULES.add("like");
/* 100 */     RULES.add("exists");
/* 101 */     RULES.add("<");
/* 102 */     RULES.add(">");
/* 103 */     RULES.add("<=");
/* 104 */     RULES.add(">=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuleFactory getInstance()
/*     */   {
/* 119 */     return FACTORY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRule(String symbol)
/*     */   {
/* 128 */     return (symbol != null) && (RULES.contains(symbol.toLowerCase(Locale.ENGLISH)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rule getRule(String symbol, Stack stack)
/*     */   {
/* 138 */     if ("&&".equals(symbol)) {
/* 139 */       return AndRule.getRule(stack);
/*     */     }
/*     */     
/* 142 */     if ("||".equals(symbol)) {
/* 143 */       return OrRule.getRule(stack);
/*     */     }
/*     */     
/* 146 */     if ("!".equals(symbol)) {
/* 147 */       return NotRule.getRule(stack);
/*     */     }
/*     */     
/* 150 */     if ("!=".equals(symbol)) {
/* 151 */       return NotEqualsRule.getRule(stack);
/*     */     }
/*     */     
/* 154 */     if ("==".equals(symbol)) {
/* 155 */       return EqualsRule.getRule(stack);
/*     */     }
/*     */     
/* 158 */     if ("~=".equals(symbol)) {
/* 159 */       return PartialTextMatchRule.getRule(stack);
/*     */     }
/*     */     
/* 162 */     if ((RULES.contains("like")) && ("like".equalsIgnoreCase(symbol))) {
/* 163 */       return LikeRule.getRule(stack);
/*     */     }
/*     */     
/* 166 */     if ("exists".equalsIgnoreCase(symbol)) {
/* 167 */       return ExistsRule.getRule(stack);
/*     */     }
/*     */     
/* 170 */     if ("<".equals(symbol)) {
/* 171 */       return InequalityRule.getRule("<", stack);
/*     */     }
/*     */     
/* 174 */     if (">".equals(symbol)) {
/* 175 */       return InequalityRule.getRule(">", stack);
/*     */     }
/*     */     
/* 178 */     if ("<=".equals(symbol)) {
/* 179 */       return InequalityRule.getRule("<=", stack);
/*     */     }
/*     */     
/* 182 */     if (">=".equals(symbol)) {
/* 183 */       return InequalityRule.getRule(">=", stack);
/*     */     }
/* 185 */     throw new IllegalArgumentException("Invalid rule: " + symbol);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\RuleFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */