/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimestampEqualsRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = 1639079557187790321L;
/*  44 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private long timeStamp;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TimestampEqualsRule(String value)
/*     */   {
/*     */     try
/*     */     {
/*  65 */       this.timeStamp = DATE_FORMAT.parse(value).getTime();
/*     */     } catch (ParseException pe) {
/*  67 */       throw new IllegalArgumentException("Could not parse date: " + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String value)
/*     */   {
/*  77 */     return new TimestampEqualsRule(value);
/*     */   }
/*     */   
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/*  82 */     String eventTimeStampString = RESOLVER.getValue("TIMESTAMP", event).toString();
/*  83 */     long eventTimeStamp = Long.parseLong(eventTimeStampString) / 1000L * 1000L;
/*  84 */     boolean result = eventTimeStamp == this.timeStamp;
/*  85 */     if ((result) && (matches != null)) {
/*  86 */       Set entries = (Set)matches.get("TIMESTAMP");
/*  87 */       if (entries == null) {
/*  88 */         entries = new HashSet();
/*  89 */         matches.put("TIMESTAMP", entries);
/*     */       }
/*  91 */       entries.add(eventTimeStampString);
/*     */     }
/*  93 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 107 */     this.timeStamp = in.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 119 */     out.writeLong(this.timeStamp);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\TimestampEqualsRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */