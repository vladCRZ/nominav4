/*     */ package org.apache.log4j.rule;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.LoggingEventFieldResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimestampInequalityRule
/*     */   extends AbstractRule
/*     */ {
/*     */   static final long serialVersionUID = -4642641663914789241L;
/*  44 */   private static final LoggingEventFieldResolver RESOLVER = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient String inequalitySymbol;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long timeStamp;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TimestampInequalityRule(String inequalitySymbol, String value)
/*     */   {
/*  68 */     this.inequalitySymbol = inequalitySymbol;
/*     */     try {
/*  70 */       this.timeStamp = DATE_FORMAT.parse(value).getTime();
/*     */     } catch (ParseException pe) {
/*  72 */       throw new IllegalArgumentException("Could not parse date: " + value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Rule getRule(String inequalitySymbol, String value)
/*     */   {
/*  84 */     return new TimestampInequalityRule(inequalitySymbol, value);
/*     */   }
/*     */   
/*     */   public boolean evaluate(LoggingEvent event, Map matches)
/*     */   {
/*  89 */     String eventTimeStampString = RESOLVER.getValue("TIMESTAMP", event).toString();
/*  90 */     long eventTimeStamp = Long.parseLong(eventTimeStampString) / 1000L * 1000L;
/*     */     
/*  92 */     boolean result = false;
/*  93 */     long first = eventTimeStamp;
/*  94 */     long second = this.timeStamp;
/*     */     
/*  96 */     if ("<".equals(this.inequalitySymbol)) {
/*  97 */       result = first < second;
/*  98 */     } else if (">".equals(this.inequalitySymbol)) {
/*  99 */       result = first > second;
/* 100 */     } else if ("<=".equals(this.inequalitySymbol)) {
/* 101 */       result = first <= second;
/* 102 */     } else if (">=".equals(this.inequalitySymbol)) {
/* 103 */       result = first >= second;
/*     */     }
/* 105 */     if ((result) && (matches != null)) {
/* 106 */       Set entries = (Set)matches.get("TIMESTAMP");
/* 107 */       if (entries == null) {
/* 108 */         entries = new HashSet();
/* 109 */         matches.put("TIMESTAMP", entries);
/*     */       }
/* 111 */       entries.add(eventTimeStampString);
/*     */     }
/* 113 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 126 */     this.inequalitySymbol = ((String)in.readObject());
/* 127 */     this.timeStamp = in.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 139 */     out.writeObject(this.inequalitySymbol);
/* 140 */     out.writeLong(this.timeStamp);
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\rule\TimestampInequalityRule.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */