/*     */ package org.apache.log4j.spi;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.rule.InFixToPostFix.CustomTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LoggingEventFieldResolver
/*     */ {
/*  72 */   public static final List KEYWORD_LIST = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String LOGGER_FIELD = "LOGGER";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String LEVEL_FIELD = "LEVEL";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String CLASS_FIELD = "CLASS";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String FILE_FIELD = "FILE";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String LINE_FIELD = "LINE";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String METHOD_FIELD = "METHOD";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String MSG_FIELD = "MSG";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String NDC_FIELD = "NDC";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String EXCEPTION_FIELD = "EXCEPTION";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String TIMESTAMP_FIELD = "TIMESTAMP";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String THREAD_FIELD = "THREAD";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String PROP_FIELD = "PROP.";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String EMPTY_STRING = "";
/*     */   
/*     */ 
/*     */ 
/* 128 */   private static final LoggingEventFieldResolver RESOLVER = new LoggingEventFieldResolver();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LoggingEventFieldResolver()
/*     */   {
/* 136 */     KEYWORD_LIST.add("LOGGER");
/* 137 */     KEYWORD_LIST.add("LEVEL");
/* 138 */     KEYWORD_LIST.add("CLASS");
/* 139 */     KEYWORD_LIST.add("FILE");
/* 140 */     KEYWORD_LIST.add("LINE");
/* 141 */     KEYWORD_LIST.add("METHOD");
/* 142 */     KEYWORD_LIST.add("MSG");
/* 143 */     KEYWORD_LIST.add("NDC");
/* 144 */     KEYWORD_LIST.add("EXCEPTION");
/* 145 */     KEYWORD_LIST.add("TIMESTAMP");
/* 146 */     KEYWORD_LIST.add("THREAD");
/* 147 */     KEYWORD_LIST.add("PROP.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String applyFields(String replaceText, LoggingEvent event)
/*     */   {
/* 158 */     if (replaceText == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     InFixToPostFix.CustomTokenizer tokenizer = new InFixToPostFix.CustomTokenizer(replaceText);
/* 162 */     StringBuffer result = new StringBuffer();
/* 163 */     boolean found = false;
/*     */     
/* 165 */     while (tokenizer.hasMoreTokens()) {
/* 166 */       String token = tokenizer.nextToken();
/* 167 */       if ((isField(token)) || (token.toUpperCase(Locale.US).startsWith("PROP."))) {
/* 168 */         result.append(getValue(token, event).toString());
/* 169 */         found = true;
/*     */       } else {
/* 171 */         result.append(token);
/*     */       }
/*     */     }
/* 174 */     if (found) {
/* 175 */       return result.toString();
/*     */     }
/* 177 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LoggingEventFieldResolver getInstance()
/*     */   {
/* 185 */     return RESOLVER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isField(String fieldName)
/*     */   {
/* 194 */     if (fieldName != null) {
/* 195 */       return (KEYWORD_LIST.contains(fieldName.toUpperCase(Locale.US))) || (fieldName.toUpperCase().startsWith("PROP."));
/*     */     }
/*     */     
/*     */ 
/* 199 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue(String fieldName, LoggingEvent event)
/*     */   {
/* 210 */     String upperField = fieldName.toUpperCase(Locale.US);
/* 211 */     if ("LOGGER".equals(upperField))
/* 212 */       return event.getLoggerName();
/* 213 */     if ("LEVEL".equals(upperField))
/* 214 */       return event.getLevel();
/* 215 */     if ("MSG".equals(upperField))
/* 216 */       return event.getMessage();
/* 217 */     if ("NDC".equals(upperField)) {
/* 218 */       String ndcValue = event.getNDC();
/* 219 */       return ndcValue == null ? "" : ndcValue; }
/* 220 */     if ("EXCEPTION".equals(upperField)) {
/* 221 */       String[] throwableRep = event.getThrowableStrRep();
/* 222 */       if (throwableRep == null) {
/* 223 */         return "";
/*     */       }
/* 225 */       return getExceptionMessage(throwableRep);
/*     */     }
/* 227 */     if ("TIMESTAMP".equals(upperField))
/* 228 */       return new Long(event.timeStamp);
/* 229 */     if ("THREAD".equals(upperField))
/* 230 */       return event.getThreadName();
/* 231 */     if (upperField.startsWith("PROP."))
/*     */     {
/* 233 */       Object propValue = event.getMDC(fieldName.substring(5));
/* 234 */       String lowerPropKey; Iterator iter; if (propValue == null)
/*     */       {
/* 236 */         lowerPropKey = fieldName.substring(5).toLowerCase();
/* 237 */         Set entrySet = event.getProperties().entrySet();
/* 238 */         for (iter = entrySet.iterator(); iter.hasNext();) {
/* 239 */           Map.Entry thisEntry = (Map.Entry)iter.next();
/* 240 */           if (thisEntry.getKey().toString().equalsIgnoreCase(lowerPropKey)) {
/* 241 */             propValue = thisEntry.getValue();
/*     */           }
/*     */         }
/*     */       }
/* 245 */       return propValue == null ? "" : propValue.toString();
/*     */     }
/* 247 */     LocationInfo info = event.getLocationInformation();
/* 248 */     if ("CLASS".equals(upperField))
/* 249 */       return info == null ? "" : info.getClassName();
/* 250 */     if ("FILE".equals(upperField))
/* 251 */       return info == null ? "" : info.getFileName();
/* 252 */     if ("LINE".equals(upperField))
/* 253 */       return info == null ? "" : info.getLineNumber();
/* 254 */     if ("METHOD".equals(upperField)) {
/* 255 */       return info == null ? "" : info.getMethodName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 260 */     throw new IllegalArgumentException("Unsupported field name: " + fieldName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getExceptionMessage(String[] exception)
/*     */   {
/* 269 */     StringBuffer buff = new StringBuffer();
/* 270 */     for (int i = 0; i < exception.length; i++) {
/* 271 */       buff.append(exception[i]);
/*     */     }
/* 273 */     return buff.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\spi\LoggingEventFieldResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */