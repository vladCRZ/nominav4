/*     */ package org.apache.log4j.varia;
/*     */ 
/*     */ import java.applet.Applet;
/*     */ import java.applet.AudioClip;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import org.apache.log4j.AppenderSkeleton;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SoundAppender
/*     */   extends AppenderSkeleton
/*     */ {
/*     */   private AudioClip clip;
/*     */   private String audioURL;
/*     */   
/*     */   public void activateOptions()
/*     */   {
/*     */     try
/*     */     {
/*  65 */       this.clip = Applet.newAudioClip(new URL(this.audioURL));
/*     */     } catch (MalformedURLException mue) {
/*  67 */       LogLog.error("unable to initialize SoundAppender", mue); }
/*  68 */     if (this.clip == null) {
/*  69 */       LogLog.error("Unable to initialize SoundAppender");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAudioURL()
/*     */   {
/*  79 */     return this.audioURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAudioURL(String audioURL)
/*     */   {
/*  89 */     this.audioURL = audioURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void append(LoggingEvent event)
/*     */   {
/*  96 */     if (this.clip != null) {
/*  97 */       this.clip.play();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean requiresLayout()
/*     */   {
/* 110 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\varia\SoundAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */