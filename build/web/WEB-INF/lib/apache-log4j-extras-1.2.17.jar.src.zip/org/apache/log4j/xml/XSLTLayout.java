/*     */ package org.apache.log4j.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.log4j.Layout;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.helpers.MDCKeySetExtractor;
/*     */ import org.apache.log4j.pattern.CachedDateFormat;
/*     */ import org.apache.log4j.spi.LocationInfo;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XSLTLayout
/*     */   extends Layout
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*     */   private static final String XSLT_NS = "http://www.w3.org/1999/XSL/Transform";
/*     */   private static final String LOG4J_NS = "http://jakarta.apache.org/log4j/";
/* 108 */   private boolean locationInfo = false;
/*     */   
/*     */ 
/*     */ 
/* 112 */   private String mediaType = "text/plain";
/*     */   
/*     */ 
/*     */ 
/*     */   private Charset encoding;
/*     */   
/*     */ 
/*     */ 
/*     */   private SAXTransformerFactory transformerFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   private Templates templates;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ByteArrayOutputStream outputStream;
/*     */   
/*     */ 
/*     */ 
/* 132 */   private boolean ignoresThrowable = false;
/*     */   
/*     */ 
/*     */ 
/* 136 */   private boolean properties = true;
/*     */   
/*     */ 
/*     */ 
/* 140 */   private boolean activated = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final CachedDateFormat utcDateFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XSLTLayout()
/*     */   {
/* 152 */     this.outputStream = new ByteArrayOutputStream();
/* 153 */     this.transformerFactory = ((SAXTransformerFactory)TransformerFactory.newInstance());
/*     */     
/*     */ 
/* 156 */     SimpleDateFormat zdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
/* 157 */     zdf.setTimeZone(TimeZone.getTimeZone("UTC"));
/* 158 */     this.utcDateFormat = new CachedDateFormat(zdf, 1000);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized String getContentType()
/*     */   {
/* 165 */     return this.mediaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setLocationInfo(boolean flag)
/*     */   {
/* 182 */     this.locationInfo = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean getLocationInfo()
/*     */   {
/* 190 */     return this.locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setProperties(boolean flag)
/*     */   {
/* 198 */     this.properties = flag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean getProperties()
/*     */   {
/* 206 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void activateOptions()
/*     */   {
/* 212 */     if (this.templates == null) {
/*     */       try {
/* 214 */         InputStream is = XSLTLayout.class.getResourceAsStream("default.xslt");
/* 215 */         StreamSource ss = new StreamSource(is);
/* 216 */         this.templates = this.transformerFactory.newTemplates(ss);
/* 217 */         this.encoding = Charset.forName("US-ASCII");
/* 218 */         this.mediaType = "text/plain";
/*     */       } catch (Exception ex) {
/* 220 */         LogLog.error("Error loading default.xslt", ex);
/*     */       }
/*     */     }
/* 223 */     this.activated = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean ignoresThrowable()
/*     */   {
/* 231 */     return this.ignoresThrowable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setIgnoresThrowable(boolean ignoresThrowable)
/*     */   {
/* 239 */     this.ignoresThrowable = ignoresThrowable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized String format(LoggingEvent event)
/*     */   {
/* 248 */     if (!this.activated) {
/* 249 */       activateOptions();
/*     */     }
/* 251 */     if ((this.templates != null) && (this.encoding != null)) {
/* 252 */       this.outputStream.reset();
/*     */       try
/*     */       {
/* 255 */         TransformerHandler transformer = this.transformerFactory.newTransformerHandler(this.templates);
/*     */         
/*     */ 
/* 258 */         transformer.setResult(new StreamResult(this.outputStream));
/* 259 */         transformer.startDocument();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 264 */         AttributesImpl attrs = new AttributesImpl();
/* 265 */         attrs.addAttribute(null, "logger", "logger", "CDATA", event.getLoggerName());
/*     */         
/* 267 */         attrs.addAttribute(null, "timestamp", "timestamp", "CDATA", Long.toString(event.timeStamp));
/*     */         
/* 269 */         attrs.addAttribute(null, "level", "level", "CDATA", event.getLevel().toString());
/*     */         
/* 271 */         attrs.addAttribute(null, "thread", "thread", "CDATA", event.getThreadName());
/*     */         
/* 273 */         StringBuffer buf = new StringBuffer();
/* 274 */         this.utcDateFormat.format(event.timeStamp, buf);
/* 275 */         attrs.addAttribute(null, "time", "time", "CDATA", buf.toString());
/*     */         
/*     */ 
/* 278 */         transformer.startElement("http://jakarta.apache.org/log4j/", "event", "event", attrs);
/* 279 */         attrs.clear();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 284 */         transformer.startElement("http://jakarta.apache.org/log4j/", "message", "message", attrs);
/* 285 */         String msg = event.getRenderedMessage();
/* 286 */         if ((msg != null) && (msg.length() > 0)) {
/* 287 */           transformer.characters(msg.toCharArray(), 0, msg.length());
/*     */         }
/* 289 */         transformer.endElement("http://jakarta.apache.org/log4j/", "message", "message");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 294 */         String ndc = event.getNDC();
/* 295 */         if (ndc != null) {
/* 296 */           transformer.startElement("http://jakarta.apache.org/log4j/", "NDC", "NDC", attrs);
/* 297 */           char[] ndcChars = ndc.toCharArray();
/* 298 */           transformer.characters(ndcChars, 0, ndcChars.length);
/* 299 */           transformer.endElement("http://jakarta.apache.org/log4j/", "NDC", "NDC");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 305 */         if (!this.ignoresThrowable) {
/* 306 */           String[] s = event.getThrowableStrRep();
/* 307 */           if (s != null) {
/* 308 */             transformer.startElement("http://jakarta.apache.org/log4j/", "throwable", "throwable", attrs);
/*     */             
/* 310 */             char[] nl = { '\n' };
/* 311 */             for (int i = 0; i < s.length; i++) {
/* 312 */               char[] line = s[i].toCharArray();
/* 313 */               transformer.characters(line, 0, line.length);
/* 314 */               transformer.characters(nl, 0, nl.length);
/*     */             }
/* 316 */             transformer.endElement("http://jakarta.apache.org/log4j/", "throwable", "throwable");
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 324 */         if (this.locationInfo) {
/* 325 */           LocationInfo locationInfo = event.getLocationInformation();
/* 326 */           attrs.addAttribute(null, "class", "class", "CDATA", locationInfo.getClassName());
/*     */           
/* 328 */           attrs.addAttribute(null, "method", "method", "CDATA", locationInfo.getMethodName());
/*     */           
/* 330 */           attrs.addAttribute(null, "file", "file", "CDATA", locationInfo.getFileName());
/*     */           
/* 332 */           attrs.addAttribute(null, "line", "line", "CDATA", locationInfo.getLineNumber());
/*     */           
/* 334 */           transformer.startElement("http://jakarta.apache.org/log4j/", "locationInfo", "locationInfo", attrs);
/*     */           
/* 336 */           transformer.endElement("http://jakarta.apache.org/log4j/", "locationInfo", "locationInfo");
/*     */         }
/*     */         
/*     */ 
/* 340 */         if (this.properties)
/*     */         {
/*     */ 
/*     */ 
/* 344 */           Set mdcKeySet = MDCKeySetExtractor.INSTANCE.getPropertyKeySet(event);
/*     */           
/* 346 */           if ((mdcKeySet != null) && (mdcKeySet.size() > 0)) {
/* 347 */             attrs.clear();
/* 348 */             transformer.startElement("http://jakarta.apache.org/log4j/", "properties", "properties", attrs);
/*     */             
/* 350 */             Object[] keys = mdcKeySet.toArray();
/* 351 */             Arrays.sort(keys);
/* 352 */             for (int i = 0; i < keys.length; i++) {
/* 353 */               String key = keys[i].toString();
/* 354 */               Object val = event.getMDC(key);
/* 355 */               attrs.clear();
/* 356 */               attrs.addAttribute(null, "name", "name", "CDATA", key);
/* 357 */               attrs.addAttribute(null, "value", "value", "CDATA", val.toString());
/*     */               
/* 359 */               transformer.startElement("http://jakarta.apache.org/log4j/", "data", "data", attrs);
/*     */               
/* 361 */               transformer.endElement("http://jakarta.apache.org/log4j/", "data", "data");
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 367 */         transformer.endElement("http://jakarta.apache.org/log4j/", "event", "event");
/* 368 */         transformer.endDocument();
/*     */         
/* 370 */         String body = this.encoding.decode(ByteBuffer.wrap(this.outputStream.toByteArray())).toString();
/*     */         
/* 372 */         this.outputStream.reset();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 377 */         if (body.startsWith("<?xml ")) {
/* 378 */           int endDecl = body.indexOf("?>");
/* 379 */           if (endDecl != -1) {
/* 380 */             endDecl += 2;
/* 381 */             while ((endDecl < body.length()) && ((body.charAt(endDecl) == '\n') || (body.charAt(endDecl) == '\r')))
/*     */             {
/* 383 */               endDecl++; }
/* 384 */             return body.substring(endDecl);
/*     */           }
/*     */         }
/* 387 */         return body;
/*     */       } catch (Exception ex) {
/* 389 */         LogLog.error("Error during transformation", ex);
/* 390 */         return ex.toString();
/*     */       }
/*     */     }
/* 393 */     return "No valid transform or encoding specified.";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransform(Document xsltdoc)
/*     */     throws TransformerConfigurationException
/*     */   {
/* 409 */     String encodingName = null;
/* 410 */     this.mediaType = null;
/* 411 */     String method = null;
/* 412 */     NodeList nodes = xsltdoc.getElementsByTagNameNS("http://www.w3.org/1999/XSL/Transform", "output");
/*     */     
/*     */ 
/* 415 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 416 */       Element outputElement = (Element)nodes.item(i);
/* 417 */       if ((method == null) || (method.length() == 0)) {
/* 418 */         method = outputElement.getAttributeNS(null, "method");
/*     */       }
/* 420 */       if ((encodingName == null) || (encodingName.length() == 0)) {
/* 421 */         encodingName = outputElement.getAttributeNS(null, "encoding");
/*     */       }
/* 423 */       if ((this.mediaType == null) || (this.mediaType.length() == 0)) {
/* 424 */         this.mediaType = outputElement.getAttributeNS(null, "media-type");
/*     */       }
/*     */     }
/*     */     
/* 428 */     if ((this.mediaType == null) || (this.mediaType.length() == 0)) {
/* 429 */       if ("html".equals(method)) {
/* 430 */         this.mediaType = "text/html";
/* 431 */       } else if ("xml".equals(method)) {
/* 432 */         this.mediaType = "text/xml";
/*     */       } else {
/* 434 */         this.mediaType = "text/plain";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 442 */     if ((encodingName == null) || (encodingName.length() == 0)) {
/* 443 */       Element transformElement = xsltdoc.getDocumentElement();
/* 444 */       Element outputElement = xsltdoc.createElementNS("http://www.w3.org/1999/XSL/Transform", "output");
/*     */       
/* 446 */       outputElement.setAttributeNS(null, "encoding", "US-ASCII");
/* 447 */       transformElement.insertBefore(outputElement, transformElement.getFirstChild());
/* 448 */       this.encoding = Charset.forName("US-ASCII");
/*     */     } else {
/* 450 */       this.encoding = Charset.forName(encodingName);
/*     */     }
/*     */     
/* 453 */     DOMSource transformSource = new DOMSource(xsltdoc);
/*     */     
/* 455 */     this.templates = this.transformerFactory.newTemplates(transformSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props)
/*     */     throws Exception
/*     */   {
/* 465 */     if (("http://www.w3.org/1999/XSL/Transform".equals(element.getNamespaceURI())) || (element.getNodeName().indexOf("transform") != -1) || (element.getNodeName().indexOf("stylesheet") != -1))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 471 */       ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 472 */       DOMSource source = new DOMSource(element);
/* 473 */       TransformerFactory transformerFactory = TransformerFactory.newInstance();
/* 474 */       Transformer transformer = transformerFactory.newTransformer();
/* 475 */       transformer.transform(source, new StreamResult(os));
/*     */       
/* 477 */       ByteArrayInputStream is = new ByteArrayInputStream(os.toByteArray());
/* 478 */       DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
/* 479 */       domFactory.setNamespaceAware(true);
/* 480 */       Document xsltdoc = domFactory.newDocumentBuilder().parse(is);
/* 481 */       setTransform(xsltdoc);
/* 482 */       return true;
/*     */     }
/* 484 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\apache-log4j-extras-1.2.17.jar!\org\apache\log4j\xml\XSLTLayout.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */