package org.apache.commons.net.ftp;

public abstract interface FTPFileFilter
{
  public abstract boolean accept(FTPFile paramFTPFile);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\commons-net-3.5.jar!\org\apache\commons\net\ftp\FTPFileFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */