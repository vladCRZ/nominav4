package org.apache.commons.net.nntp;

@Deprecated
public final class ArticlePointer
{
  public int articleNumber;
  public String articleId;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\commons-net-3.5.jar!\org\apache\commons\net\nntp\ArticlePointer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */