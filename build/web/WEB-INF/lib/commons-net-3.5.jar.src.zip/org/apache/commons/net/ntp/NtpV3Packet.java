package org.apache.commons.net.ntp;

import java.net.DatagramPacket;

public abstract interface NtpV3Packet
{
  public static final int NTP_PORT = 123;
  public static final int LI_NO_WARNING = 0;
  public static final int LI_LAST_MINUTE_HAS_61_SECONDS = 1;
  public static final int LI_LAST_MINUTE_HAS_59_SECONDS = 2;
  public static final int LI_ALARM_CONDITION = 3;
  public static final int MODE_RESERVED = 0;
  public static final int MODE_SYMMETRIC_ACTIVE = 1;
  public static final int MODE_SYMMETRIC_PASSIVE = 2;
  public static final int MODE_CLIENT = 3;
  public static final int MODE_SERVER = 4;
  public static final int MODE_BROADCAST = 5;
  public static final int MODE_CONTROL_MESSAGE = 6;
  public static final int MODE_PRIVATE = 7;
  public static final int NTP_MINPOLL = 4;
  public static final int NTP_MAXPOLL = 14;
  public static final int NTP_MINCLOCK = 1;
  public static final int NTP_MAXCLOCK = 10;
  public static final int VERSION_3 = 3;
  public static final int VERSION_4 = 4;
  public static final String TYPE_NTP = "NTP";
  public static final String TYPE_ICMP = "ICMP";
  public static final String TYPE_TIME = "TIME";
  public static final String TYPE_DAYTIME = "DAYTIME";
  
  public abstract DatagramPacket getDatagramPacket();
  
  public abstract void setDatagramPacket(DatagramPacket paramDatagramPacket);
  
  public abstract int getLeapIndicator();
  
  public abstract void setLeapIndicator(int paramInt);
  
  public abstract int getMode();
  
  public abstract String getModeName();
  
  public abstract void setMode(int paramInt);
  
  public abstract int getPoll();
  
  public abstract void setPoll(int paramInt);
  
  public abstract int getPrecision();
  
  public abstract void setPrecision(int paramInt);
  
  public abstract int getRootDelay();
  
  public abstract void setRootDelay(int paramInt);
  
  public abstract double getRootDelayInMillisDouble();
  
  public abstract int getRootDispersion();
  
  public abstract void setRootDispersion(int paramInt);
  
  public abstract long getRootDispersionInMillis();
  
  public abstract double getRootDispersionInMillisDouble();
  
  public abstract int getVersion();
  
  public abstract void setVersion(int paramInt);
  
  public abstract int getStratum();
  
  public abstract void setStratum(int paramInt);
  
  public abstract String getReferenceIdString();
  
  public abstract int getReferenceId();
  
  public abstract void setReferenceId(int paramInt);
  
  public abstract TimeStamp getTransmitTimeStamp();
  
  public abstract TimeStamp getReferenceTimeStamp();
  
  public abstract TimeStamp getOriginateTimeStamp();
  
  public abstract TimeStamp getReceiveTimeStamp();
  
  public abstract void setTransmitTime(TimeStamp paramTimeStamp);
  
  public abstract void setReferenceTime(TimeStamp paramTimeStamp);
  
  public abstract void setOriginateTimeStamp(TimeStamp paramTimeStamp);
  
  public abstract void setReceiveTimeStamp(TimeStamp paramTimeStamp);
  
  public abstract String getType();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\commons-net-3.5.jar!\org\apache\commons\net\ntp\NtpV3Packet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */