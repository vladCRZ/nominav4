package org.apache.commons.net.pop3;

public final class POP3Reply
{
  public static final int OK = 0;
  public static final int ERROR = 1;
  public static final int OK_INT = 2;
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\commons-net-3.5.jar!\org\apache\commons\net\pop3\POP3Reply.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */