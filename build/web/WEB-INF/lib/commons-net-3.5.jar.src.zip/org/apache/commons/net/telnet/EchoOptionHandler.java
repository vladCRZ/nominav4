/*    */ package org.apache.commons.net.telnet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EchoOptionHandler
/*    */   extends TelnetOptionHandler
/*    */ {
/*    */   public EchoOptionHandler(boolean initlocal, boolean initremote, boolean acceptlocal, boolean acceptremote)
/*    */   {
/* 39 */     super(1, initlocal, initremote, acceptlocal, acceptremote);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EchoOptionHandler()
/*    */   {
/* 49 */     super(1, false, false, false, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\commons-net-3.5.jar!\org\apache\commons\net\telnet\EchoOptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */