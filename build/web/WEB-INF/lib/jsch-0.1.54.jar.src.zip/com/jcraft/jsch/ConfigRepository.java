/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ConfigRepository
/*    */ {
/* 44 */   public static final Config defaultConfig = new Config() {
/* 45 */     public String getHostname() { return null; }
/* 46 */     public String getUser() { return null; }
/* 47 */     public int getPort() { return -1; }
/* 48 */     public String getValue(String key) { return null; }
/* 49 */     public String[] getValues(String key) { return null; }
/*    */   };
/*    */   
/* 52 */   public static final ConfigRepository nullConfig = new ConfigRepository() {
/* 53 */     public ConfigRepository.Config getConfig(String host) { return defaultConfig; }
/*    */   };
/*    */   
/*    */   public abstract Config getConfig(String paramString);
/*    */   
/*    */   public static abstract interface Config
/*    */   {
/*    */     public abstract String getHostname();
/*    */     
/*    */     public abstract String getUser();
/*    */     
/*    */     public abstract int getPort();
/*    */     
/*    */     public abstract String getValue(String paramString);
/*    */     
/*    */     public abstract String[] getValues(String paramString);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\ConfigRepository.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */