package com.jcraft.jsch;

public abstract interface Identity
{
  public abstract boolean setPassphrase(byte[] paramArrayOfByte)
    throws JSchException;
  
  public abstract byte[] getPublicKeyBlob();
  
  public abstract byte[] getSignature(byte[] paramArrayOfByte);
  
  /**
   * @deprecated
   */
  public abstract boolean decrypt();
  
  public abstract String getAlgName();
  
  public abstract String getName();
  
  public abstract boolean isEncrypted();
  
  public abstract void clear();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\Identity.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */