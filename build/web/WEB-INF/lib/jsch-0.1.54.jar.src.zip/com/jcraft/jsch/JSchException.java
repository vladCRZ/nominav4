/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSchException
/*    */   extends Exception
/*    */ {
/* 34 */   private Throwable cause = null;
/*    */   
/*    */ 
/*    */   public JSchException() {}
/*    */   
/* 39 */   public JSchException(String s) { super(s); }
/*    */   
/*    */   public JSchException(String s, Throwable e) {
/* 42 */     super(s);
/* 43 */     this.cause = e;
/*    */   }
/*    */   
/* 46 */   public Throwable getCause() { return this.cause; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\JSchException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */