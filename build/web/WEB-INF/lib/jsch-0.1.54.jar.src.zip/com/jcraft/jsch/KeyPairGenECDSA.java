package com.jcraft.jsch;

public abstract interface KeyPairGenECDSA
{
  public abstract void init(int paramInt)
    throws Exception;
  
  public abstract byte[] getD();
  
  public abstract byte[] getR();
  
  public abstract byte[] getS();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\KeyPairGenECDSA.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */