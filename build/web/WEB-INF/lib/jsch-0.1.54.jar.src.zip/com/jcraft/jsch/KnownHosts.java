/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KnownHosts
/*     */   implements HostKeyRepository
/*     */ {
/*     */   private static final String _known_hosts = "known_hosts";
/*  38 */   private JSch jsch = null;
/*  39 */   private String known_hosts = null;
/*  40 */   private Vector pool = null;
/*     */   
/*  42 */   private MAC hmacsha1 = null;
/*     */   
/*     */   KnownHosts(JSch jsch)
/*     */   {
/*  46 */     this.jsch = jsch;
/*  47 */     this.hmacsha1 = getHMACSHA1();
/*  48 */     this.pool = new Vector();
/*     */   }
/*     */   
/*     */   void setKnownHosts(String filename) throws JSchException {
/*     */     try {
/*  53 */       this.known_hosts = filename;
/*  54 */       FileInputStream fis = new FileInputStream(Util.checkTilde(filename));
/*  55 */       setKnownHosts(fis);
/*     */     }
/*     */     catch (FileNotFoundException e) {}
/*     */   }
/*     */   
/*     */   void setKnownHosts(InputStream input) throws JSchException
/*     */   {
/*  62 */     this.pool.removeAllElements();
/*  63 */     StringBuffer sb = new StringBuffer();
/*     */     
/*     */ 
/*  66 */     boolean error = false;
/*     */     try {
/*  68 */       InputStream fis = input;
/*     */       
/*  70 */       String key = null;
/*     */       
/*  72 */       byte[] buf = new byte['Ѐ'];
/*  73 */       int bufl = 0;
/*     */       for (;;)
/*     */       {
/*  76 */         bufl = 0;
/*     */         for (;;) {
/*  78 */           j = fis.read();
/*  79 */           if (j == -1) {
/*  80 */             if (bufl != 0) break;
/*     */             break label826;
/*     */           }
/*  83 */           if (j != 13) {
/*  84 */             if (j == 10) break;
/*  85 */             if (buf.length <= bufl) {
/*  86 */               if (bufl > 10240) break;
/*  87 */               byte[] newbuf = new byte[buf.length * 2];
/*  88 */               System.arraycopy(buf, 0, newbuf, 0, buf.length);
/*  89 */               buf = newbuf;
/*     */             }
/*  91 */             buf[(bufl++)] = ((byte)j);
/*     */           }
/*     */         }
/*  94 */         int j = 0;
/*  95 */         for (;;) { if (j < bufl) {
/*  96 */             byte i = buf[j];
/*  97 */             if ((i == 32) || (i == 9)) { j++;
/*  98 */             } else if (i == 35) {
/*  99 */               addInvalidLine(Util.byte2str(buf, 0, bufl));
/* 100 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 104 */         if (j >= bufl) {
/* 105 */           addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */         }
/*     */         else
/*     */         {
/* 109 */           sb.setLength(0);
/* 110 */           while (j < bufl) {
/* 111 */             byte i = buf[(j++)];
/* 112 */             if ((i == 32) || (i == 9)) break;
/* 113 */             sb.append((char)i);
/*     */           }
/* 115 */           String host = sb.toString();
/* 116 */           if ((j >= bufl) || (host.length() == 0)) {
/* 117 */             addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */           }
/*     */           else
/*     */           {
/* 121 */             for (; j < bufl; 
/*     */                 
/* 123 */                 j++)
/*     */             {
/* 122 */               byte i = buf[j];
/* 123 */               if ((i != 32) && (i != 9)) {
/*     */                 break;
/*     */               }
/*     */             }
/* 127 */             String marker = "";
/* 128 */             if (host.charAt(0) == '@') {
/* 129 */               marker = host;
/*     */               
/* 131 */               sb.setLength(0);
/* 132 */               while (j < bufl) {
/* 133 */                 byte i = buf[(j++)];
/* 134 */                 if ((i == 32) || (i == 9)) break;
/* 135 */                 sb.append((char)i);
/*     */               }
/* 137 */               host = sb.toString();
/* 138 */               if ((j >= bufl) || (host.length() == 0)) {
/* 139 */                 addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */               } else {
/* 143 */                 for (; 
/*     */                     
/* 143 */                     j < bufl; 
/*     */                     
/* 145 */                     j++)
/*     */                 {
/* 144 */                   byte i = buf[j];
/* 145 */                   if ((i != 32) && (i != 9))
/*     */                     break;
/*     */                 }
/*     */               }
/*     */             } else {
/* 150 */               sb.setLength(0);
/* 151 */               int type = -1;
/* 152 */               while (j < bufl) {
/* 153 */                 byte i = buf[(j++)];
/* 154 */                 if ((i == 32) || (i == 9)) break;
/* 155 */                 sb.append((char)i);
/*     */               }
/* 157 */               String tmp = sb.toString();
/* 158 */               if (HostKey.name2type(tmp) != 6) {
/* 159 */                 type = HostKey.name2type(tmp);
/*     */               } else
/* 161 */                 j = bufl;
/* 162 */               if (j >= bufl) {
/* 163 */                 addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */               }
/*     */               else
/*     */               {
/* 167 */                 for (; j < bufl; 
/*     */                     
/* 169 */                     j++)
/*     */                 {
/* 168 */                   byte i = buf[j];
/* 169 */                   if ((i != 32) && (i != 9)) {
/*     */                     break;
/*     */                   }
/*     */                 }
/* 173 */                 sb.setLength(0);
/* 174 */                 while (j < bufl) {
/* 175 */                   byte i = buf[(j++)];
/* 176 */                   if (i != 13) {
/* 177 */                     if ((i == 10) || 
/* 178 */                       (i == 32) || (i == 9)) break;
/* 179 */                     sb.append((char)i);
/*     */                   } }
/* 181 */                 key = sb.toString();
/* 182 */                 if (key.length() == 0) {
/* 183 */                   addInvalidLine(Util.byte2str(buf, 0, bufl));
/*     */                 }
/*     */                 else
/*     */                 {
/* 187 */                   for (; j < bufl; 
/*     */                       
/* 189 */                       j++)
/*     */                   {
/* 188 */                     byte i = buf[j];
/* 189 */                     if ((i != 32) && (i != 9)) {
/*     */                       break;
/*     */                     }
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */                   String comment = null;
/* 204 */                   if (j < bufl) {
/* 205 */                     sb.setLength(0);
/* 206 */                     while (j < bufl) {
/* 207 */                       byte i = buf[(j++)];
/* 208 */                       if (i != 13) {
/* 209 */                         if (i == 10) break;
/* 210 */                         sb.append((char)i);
/*     */                       } }
/* 212 */                     comment = sb.toString();
/*     */                   }
/*     */                   
/*     */ 
/*     */ 
/*     */ 
/* 218 */                   HostKey hk = null;
/* 219 */                   hk = new HashedHostKey(marker, host, type, Util.fromBase64(Util.str2byte(key), 0, key.length()), comment);
/*     */                   
/*     */ 
/* 222 */                   this.pool.addElement(hk); } } } } } }
/*     */       label826:
/* 224 */       if (error) {
/* 225 */         throw new JSchException("KnownHosts: invalid format");
/*     */       }
/*     */       return;
/*     */     } catch (Exception e) {
/* 229 */       if ((e instanceof JSchException))
/* 230 */         throw ((JSchException)e);
/* 231 */       if ((e instanceof Throwable))
/* 232 */         throw new JSchException(e.toString(), e);
/* 233 */       throw new JSchException(e.toString());
/*     */     } finally {
/*     */       try {
/* 236 */         input.close();
/*     */       } catch (IOException e) {
/* 238 */         throw new JSchException(e.toString(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 243 */   private void addInvalidLine(String line) throws JSchException { HostKey hk = new HostKey(line, 6, null);
/* 244 */     this.pool.addElement(hk); }
/*     */   
/* 246 */   String getKnownHostsFile() { return this.known_hosts; }
/* 247 */   public String getKnownHostsRepositoryID() { return this.known_hosts; }
/*     */   
/*     */   public int check(String host, byte[] key) {
/* 250 */     int result = 1;
/* 251 */     if (host == null) {
/* 252 */       return result;
/*     */     }
/*     */     
/* 255 */     HostKey hk = null;
/*     */     try {
/* 257 */       hk = new HostKey(host, 0, key);
/*     */     }
/*     */     catch (JSchException e) {
/* 260 */       return result;
/*     */     }
/*     */     
/* 263 */     synchronized (this.pool) {
/* 264 */       for (int i = 0; i < this.pool.size(); i++) {
/* 265 */         HostKey _hk = (HostKey)this.pool.elementAt(i);
/* 266 */         if ((_hk.isMatched(host)) && (_hk.type == hk.type)) {
/* 267 */           if (Util.array_equals(_hk.key, key)) {
/* 268 */             return 0;
/*     */           }
/*     */           
/* 271 */           result = 2;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 277 */     if ((result == 1) && (host.startsWith("[")) && (host.indexOf("]:") > 1))
/*     */     {
/*     */ 
/*     */ 
/* 281 */       return check(host.substring(1, host.indexOf("]:")), key);
/*     */     }
/*     */     
/* 284 */     return result;
/*     */   }
/*     */   
/*     */   public void add(HostKey hostkey, UserInfo userinfo) {
/* 288 */     int type = hostkey.type;
/* 289 */     String host = hostkey.getHost();
/* 290 */     byte[] key = hostkey.key;
/*     */     
/* 292 */     HostKey hk = null;
/* 293 */     synchronized (this.pool) {
/* 294 */       for (int i = 0; i < this.pool.size(); i++) {
/* 295 */         hk = (HostKey)this.pool.elementAt(i);
/* 296 */         if ((!hk.isMatched(host)) || (hk.type != type)) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 312 */     hk = hostkey;
/*     */     
/* 314 */     this.pool.addElement(hk);
/*     */     
/* 316 */     String bar = getKnownHostsRepositoryID();
/* 317 */     if (bar != null) {
/* 318 */       boolean foo = true;
/* 319 */       File goo = new File(Util.checkTilde(bar));
/* 320 */       if (!goo.exists()) {
/* 321 */         foo = false;
/* 322 */         if (userinfo != null) {
/* 323 */           foo = userinfo.promptYesNo(bar + " does not exist.\n" + "Are you sure you want to create it?");
/*     */           
/*     */ 
/* 326 */           goo = goo.getParentFile();
/* 327 */           if ((foo) && (goo != null) && (!goo.exists())) {
/* 328 */             foo = userinfo.promptYesNo("The parent directory " + goo + " does not exist.\n" + "Are you sure you want to create it?");
/*     */             
/*     */ 
/* 331 */             if (foo) {
/* 332 */               if (!goo.mkdirs()) {
/* 333 */                 userinfo.showMessage(goo + " has not been created.");
/* 334 */                 foo = false;
/*     */               }
/*     */               else {
/* 337 */                 userinfo.showMessage(goo + " has been succesfully created.\nPlease check its access permission.");
/*     */               }
/*     */             }
/*     */           }
/* 341 */           if (goo == null) foo = false;
/*     */         }
/*     */       }
/* 344 */       if (foo) {
/*     */         try {
/* 346 */           sync(bar);
/*     */         } catch (Exception e) {
/* 348 */           System.err.println("sync known_hosts: " + e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 354 */   public HostKey[] getHostKey() { return getHostKey(null, (String)null); }
/*     */   
/*     */   public HostKey[] getHostKey(String host, String type) {
/* 357 */     synchronized (this.pool) {
/* 358 */       ArrayList v = new ArrayList();
/* 359 */       for (int i = 0; i < this.pool.size(); i++) {
/* 360 */         HostKey hk = (HostKey)this.pool.elementAt(i);
/* 361 */         if ((hk.type != 6) && (
/* 362 */           (host == null) || ((hk.isMatched(host)) && ((type == null) || (hk.getType().equals(type))))))
/*     */         {
/*     */ 
/* 365 */           v.add(hk);
/*     */         }
/*     */       }
/* 368 */       HostKey[] foo = new HostKey[v.size()];
/* 369 */       for (int i = 0; i < v.size(); i++) {
/* 370 */         foo[i] = ((HostKey)v.get(i));
/*     */       }
/* 372 */       if ((host != null) && (host.startsWith("[")) && (host.indexOf("]:") > 1)) {
/* 373 */         HostKey[] tmp = getHostKey(host.substring(1, host.indexOf("]:")), type);
/*     */         
/* 375 */         if (tmp.length > 0) {
/* 376 */           HostKey[] bar = new HostKey[foo.length + tmp.length];
/* 377 */           System.arraycopy(foo, 0, bar, 0, foo.length);
/* 378 */           System.arraycopy(tmp, 0, bar, foo.length, tmp.length);
/* 379 */           foo = bar;
/*     */         }
/*     */       }
/* 382 */       return foo;
/*     */     }
/*     */   }
/*     */   
/* 386 */   public void remove(String host, String type) { remove(host, type, null); }
/*     */   
/*     */   public void remove(String host, String type, byte[] key) {
/* 389 */     boolean sync = false;
/* 390 */     synchronized (this.pool) {
/* 391 */       for (int i = 0; i < this.pool.size(); i++) {
/* 392 */         HostKey hk = (HostKey)this.pool.elementAt(i);
/* 393 */         if ((host == null) || ((hk.isMatched(host)) && ((type == null) || ((hk.getType().equals(type)) && ((key == null) || (Util.array_equals(key, hk.key)))))))
/*     */         {
/*     */ 
/*     */ 
/* 397 */           String hosts = hk.getHost();
/* 398 */           if ((hosts.equals(host)) || (((hk instanceof HashedHostKey)) && (((HashedHostKey)hk).isHashed())))
/*     */           {
/*     */ 
/* 401 */             this.pool.removeElement(hk);
/*     */           }
/*     */           else {
/* 404 */             hk.host = deleteSubString(hosts, host);
/*     */           }
/* 406 */           sync = true;
/*     */         }
/*     */       }
/*     */     }
/* 410 */     if (sync)
/* 411 */       try { sync();
/*     */       } catch (Exception e) {}
/*     */   }
/*     */   
/*     */   protected void sync() throws IOException {
/* 416 */     if (this.known_hosts != null)
/* 417 */       sync(this.known_hosts);
/*     */   }
/*     */   
/* 420 */   protected synchronized void sync(String foo) throws IOException { if (foo == null) return;
/* 421 */     FileOutputStream fos = new FileOutputStream(Util.checkTilde(foo));
/* 422 */     dump(fos);
/* 423 */     fos.close();
/*     */   }
/*     */   
/* 426 */   private static final byte[] space = { 32 };
/* 427 */   private static final byte[] cr = Util.str2byte("\n");
/*     */   
/*     */   void dump(OutputStream out) throws IOException {
/*     */     try {
/* 431 */       synchronized (this.pool) {
/* 432 */         for (int i = 0; i < this.pool.size(); i++) {
/* 433 */           HostKey hk = (HostKey)this.pool.elementAt(i);
/*     */           
/* 435 */           String marker = hk.getMarker();
/* 436 */           String host = hk.getHost();
/* 437 */           String type = hk.getType();
/* 438 */           String comment = hk.getComment();
/* 439 */           if (type.equals("UNKNOWN")) {
/* 440 */             out.write(Util.str2byte(host));
/* 441 */             out.write(cr);
/*     */           }
/*     */           else {
/* 444 */             if (marker.length() != 0) {
/* 445 */               out.write(Util.str2byte(marker));
/* 446 */               out.write(space);
/*     */             }
/* 448 */             out.write(Util.str2byte(host));
/* 449 */             out.write(space);
/* 450 */             out.write(Util.str2byte(type));
/* 451 */             out.write(space);
/* 452 */             out.write(Util.str2byte(hk.getKey()));
/* 453 */             if (comment != null) {
/* 454 */               out.write(space);
/* 455 */               out.write(Util.str2byte(comment));
/*     */             }
/* 457 */             out.write(cr);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 462 */       System.err.println(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private String deleteSubString(String hosts, String host) {
/* 467 */     int i = 0;
/* 468 */     int hostlen = host.length();
/* 469 */     int hostslen = hosts.length();
/*     */     
/* 471 */     while (i < hostslen) {
/* 472 */       int j = hosts.indexOf(',', i);
/* 473 */       if (j != -1)
/* 474 */         if (!host.equals(hosts.substring(i, j))) {
/* 475 */           i = j + 1;
/*     */         }
/*     */         else
/* 478 */           return hosts.substring(0, i) + hosts.substring(j + 1);
/*     */     }
/* 480 */     if ((hosts.endsWith(host)) && (hostslen - i == hostlen)) {
/* 481 */       return hosts.substring(0, hostlen == hostslen ? 0 : hostslen - hostlen - 1);
/*     */     }
/* 483 */     return hosts;
/*     */   }
/*     */   
/*     */   private MAC getHMACSHA1() {
/* 487 */     if (this.hmacsha1 == null) {
/*     */       try {
/* 489 */         Class c = Class.forName(JSch.getConfig("hmac-sha1"));
/* 490 */         this.hmacsha1 = ((MAC)c.newInstance());
/*     */       }
/*     */       catch (Exception e) {
/* 493 */         System.err.println("hmacsha1: " + e);
/*     */       }
/*     */     }
/* 496 */     return this.hmacsha1;
/*     */   }
/*     */   
/*     */   HostKey createHashedHostKey(String host, byte[] key) throws JSchException {
/* 500 */     HashedHostKey hhk = new HashedHostKey(host, key);
/* 501 */     hhk.hash();
/* 502 */     return hhk;
/*     */   }
/*     */   
/*     */   class HashedHostKey extends HostKey {
/*     */     private static final String HASH_MAGIC = "|1|";
/*     */     private static final String HASH_DELIM = "|";
/* 508 */     private boolean hashed = false;
/* 509 */     byte[] salt = null;
/* 510 */     byte[] hash = null;
/*     */     
/*     */     HashedHostKey(String host, byte[] key) throws JSchException {
/* 513 */       this(host, 0, key);
/*     */     }
/*     */     
/* 516 */     HashedHostKey(String host, int type, byte[] key) throws JSchException { this("", host, type, key, null); }
/*     */     
/*     */     HashedHostKey(String marker, String host, int type, byte[] key, String comment) throws JSchException {
/* 519 */       super(host, type, key, comment);
/* 520 */       String data; if ((this.host.startsWith("|1|")) && (this.host.substring("|1|".length()).indexOf("|") > 0))
/*     */       {
/* 522 */         data = this.host.substring("|1|".length());
/* 523 */         String _salt = data.substring(0, data.indexOf("|"));
/* 524 */         String _hash = data.substring(data.indexOf("|") + 1);
/* 525 */         this.salt = Util.fromBase64(Util.str2byte(_salt), 0, _salt.length());
/* 526 */         this.hash = Util.fromBase64(Util.str2byte(_hash), 0, _hash.length());
/* 527 */         if ((this.salt.length != 20) || (this.hash.length != 20))
/*     */         {
/* 529 */           this.salt = null;
/* 530 */           this.hash = null;
/* 531 */           return;
/*     */         }
/* 533 */         this.hashed = true;
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isMatched(String _host) {
/* 538 */       if (!this.hashed) {
/* 539 */         return super.isMatched(_host);
/*     */       }
/* 541 */       MAC macsha1 = KnownHosts.this.getHMACSHA1();
/*     */       try {
/* 543 */         synchronized (macsha1) {
/* 544 */           macsha1.init(this.salt);
/* 545 */           byte[] foo = Util.str2byte(_host);
/* 546 */           macsha1.update(foo, 0, foo.length);
/* 547 */           byte[] bar = new byte[macsha1.getBlockSize()];
/* 548 */           macsha1.doFinal(bar, 0);
/* 549 */           return Util.array_equals(this.hash, bar);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 555 */         return false;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 553 */         System.out.println(e);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isHashed()
/*     */     {
/* 559 */       return this.hashed;
/*     */     }
/*     */     
/*     */     void hash() {
/* 563 */       if (this.hashed)
/* 564 */         return;
/* 565 */       MAC macsha1 = KnownHosts.this.getHMACSHA1();
/* 566 */       if (this.salt == null) {
/* 567 */         Random random = Session.random;
/* 568 */         synchronized (random) {
/* 569 */           this.salt = new byte[macsha1.getBlockSize()];
/* 570 */           random.fill(this.salt, 0, this.salt.length);
/*     */         }
/*     */       }
/*     */       try {
/* 574 */         synchronized (macsha1) {
/* 575 */           macsha1.init(this.salt);
/* 576 */           byte[] foo = Util.str2byte(this.host);
/* 577 */           macsha1.update(foo, 0, foo.length);
/* 578 */           this.hash = new byte[macsha1.getBlockSize()];
/* 579 */           macsha1.doFinal(this.hash, 0);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */       
/* 584 */       this.host = ("|1|" + Util.byte2str(Util.toBase64(this.salt, 0, this.salt.length)) + "|" + Util.byte2str(Util.toBase64(this.hash, 0, this.hash.length)));
/*     */       
/* 586 */       this.hashed = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\KnownHosts.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */