package com.jcraft.jsch;

public abstract interface Logger
{
  public static final int DEBUG = 0;
  public static final int INFO = 1;
  public static final int WARN = 2;
  public static final int ERROR = 3;
  public static final int FATAL = 4;
  
  public abstract boolean isEnabled(int paramInt);
  
  public abstract void log(int paramInt, String paramString);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\Logger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */