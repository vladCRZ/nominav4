package com.jcraft.jsch;

public abstract interface MAC
{
  public abstract String getName();
  
  public abstract int getBlockSize();
  
  public abstract void init(byte[] paramArrayOfByte)
    throws Exception;
  
  public abstract void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract void update(int paramInt);
  
  public abstract void doFinal(byte[] paramArrayOfByte, int paramInt);
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\MAC.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */