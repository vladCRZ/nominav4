/*      */ package com.jcraft.jsch;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.Socket;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Session
/*      */   implements Runnable
/*      */ {
/*      */   static final int SSH_MSG_DISCONNECT = 1;
/*      */   static final int SSH_MSG_IGNORE = 2;
/*      */   static final int SSH_MSG_UNIMPLEMENTED = 3;
/*      */   static final int SSH_MSG_DEBUG = 4;
/*      */   static final int SSH_MSG_SERVICE_REQUEST = 5;
/*      */   static final int SSH_MSG_SERVICE_ACCEPT = 6;
/*      */   static final int SSH_MSG_KEXINIT = 20;
/*      */   static final int SSH_MSG_NEWKEYS = 21;
/*      */   static final int SSH_MSG_KEXDH_INIT = 30;
/*      */   static final int SSH_MSG_KEXDH_REPLY = 31;
/*      */   static final int SSH_MSG_KEX_DH_GEX_GROUP = 31;
/*      */   static final int SSH_MSG_KEX_DH_GEX_INIT = 32;
/*      */   static final int SSH_MSG_KEX_DH_GEX_REPLY = 33;
/*      */   static final int SSH_MSG_KEX_DH_GEX_REQUEST = 34;
/*      */   static final int SSH_MSG_GLOBAL_REQUEST = 80;
/*      */   static final int SSH_MSG_REQUEST_SUCCESS = 81;
/*      */   static final int SSH_MSG_REQUEST_FAILURE = 82;
/*      */   static final int SSH_MSG_CHANNEL_OPEN = 90;
/*      */   static final int SSH_MSG_CHANNEL_OPEN_CONFIRMATION = 91;
/*      */   static final int SSH_MSG_CHANNEL_OPEN_FAILURE = 92;
/*      */   static final int SSH_MSG_CHANNEL_WINDOW_ADJUST = 93;
/*      */   static final int SSH_MSG_CHANNEL_DATA = 94;
/*      */   static final int SSH_MSG_CHANNEL_EXTENDED_DATA = 95;
/*      */   static final int SSH_MSG_CHANNEL_EOF = 96;
/*      */   static final int SSH_MSG_CHANNEL_CLOSE = 97;
/*      */   static final int SSH_MSG_CHANNEL_REQUEST = 98;
/*      */   static final int SSH_MSG_CHANNEL_SUCCESS = 99;
/*      */   static final int SSH_MSG_CHANNEL_FAILURE = 100;
/*      */   private static final int PACKET_MAX_SIZE = 262144;
/*      */   private byte[] V_S;
/*   71 */   private byte[] V_C = Util.str2byte("SSH-2.0-JSCH-0.1.54");
/*      */   
/*      */   private byte[] I_C;
/*      */   
/*      */   private byte[] I_S;
/*      */   
/*      */   private byte[] K_S;
/*      */   
/*      */   private byte[] session_id;
/*      */   private byte[] IVc2s;
/*      */   private byte[] IVs2c;
/*      */   private byte[] Ec2s;
/*      */   private byte[] Es2c;
/*      */   private byte[] MACc2s;
/*      */   private byte[] MACs2c;
/*   86 */   private int seqi = 0;
/*   87 */   private int seqo = 0;
/*      */   
/*   89 */   String[] guess = null;
/*      */   
/*      */   private Cipher s2ccipher;
/*      */   
/*      */   private Cipher c2scipher;
/*      */   
/*      */   private MAC s2cmac;
/*      */   private MAC c2smac;
/*      */   private byte[] s2cmac_result1;
/*      */   private byte[] s2cmac_result2;
/*      */   private Compression deflater;
/*      */   private Compression inflater;
/*      */   private IO io;
/*      */   private Socket socket;
/*  103 */   private int timeout = 0;
/*      */   
/*  105 */   private volatile boolean isConnected = false;
/*      */   
/*  107 */   private boolean isAuthed = false;
/*      */   
/*  109 */   private Thread connectThread = null;
/*  110 */   private Object lock = new Object();
/*      */   
/*  112 */   boolean x11_forwarding = false;
/*  113 */   boolean agent_forwarding = false;
/*      */   
/*  115 */   InputStream in = null;
/*  116 */   OutputStream out = null;
/*      */   
/*      */   static Random random;
/*      */   
/*      */   Buffer buf;
/*      */   
/*      */   Packet packet;
/*  123 */   SocketFactory socket_factory = null;
/*      */   
/*      */ 
/*      */   static final int buffer_margin = 128;
/*      */   
/*      */ 
/*  129 */   private Hashtable config = null;
/*      */   
/*  131 */   private Proxy proxy = null;
/*      */   
/*      */   private UserInfo userinfo;
/*  134 */   private String hostKeyAlias = null;
/*  135 */   private int serverAliveInterval = 0;
/*  136 */   private int serverAliveCountMax = 1;
/*      */   
/*  138 */   private IdentityRepository identityRepository = null;
/*  139 */   private HostKeyRepository hostkeyRepository = null;
/*      */   
/*  141 */   protected boolean daemon_thread = false;
/*      */   
/*  143 */   private long kex_start_time = 0L;
/*      */   
/*  145 */   int max_auth_tries = 6;
/*  146 */   int auth_failures = 0;
/*      */   
/*  148 */   String host = "127.0.0.1";
/*  149 */   String org_host = "127.0.0.1";
/*  150 */   int port = 22;
/*      */   
/*  152 */   String username = null;
/*  153 */   byte[] password = null;
/*      */   JSch jsch;
/*      */   
/*      */   Session(JSch jsch, String username, String host, int port)
/*      */     throws JSchException
/*      */   {
/*  159 */     this.jsch = jsch;
/*  160 */     this.buf = new Buffer();
/*  161 */     this.packet = new Packet(this.buf);
/*  162 */     this.username = username;
/*  163 */     this.org_host = (this.host = host);
/*  164 */     this.port = port;
/*      */     
/*  166 */     applyConfig();
/*      */     
/*  168 */     if (this.username == null) {
/*      */       try {
/*  170 */         this.username = ((String)System.getProperties().get("user.name"));
/*      */       }
/*      */       catch (SecurityException e) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  177 */     if (this.username == null) {
/*  178 */       throw new JSchException("username is not given.");
/*      */     }
/*      */   }
/*      */   
/*      */   public void connect() throws JSchException {
/*  183 */     connect(this.timeout);
/*      */   }
/*      */   
/*      */   public void connect(int connectTimeout) throws JSchException {
/*  187 */     if (this.isConnected) {
/*  188 */       throw new JSchException("session is already connected");
/*      */     }
/*      */     
/*  191 */     this.io = new IO();
/*  192 */     if (random == null) {
/*      */       try {
/*  194 */         Class c = Class.forName(getConfig("random"));
/*  195 */         random = (Random)c.newInstance();
/*      */       }
/*      */       catch (Exception e) {
/*  198 */         throw new JSchException(e.toString(), e);
/*      */       }
/*      */     }
/*  201 */     Packet.setRandom(random);
/*      */     
/*  203 */     if (JSch.getLogger().isEnabled(1)) {
/*  204 */       JSch.getLogger().log(1, "Connecting to " + this.host + " port " + this.port);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  211 */       if (this.proxy == null) { OutputStream out;
/*      */         InputStream in;
/*      */         OutputStream out;
/*  214 */         if (this.socket_factory == null) {
/*  215 */           this.socket = Util.createSocket(this.host, this.port, connectTimeout);
/*  216 */           InputStream in = this.socket.getInputStream();
/*  217 */           out = this.socket.getOutputStream();
/*      */         }
/*      */         else {
/*  220 */           this.socket = this.socket_factory.createSocket(this.host, this.port);
/*  221 */           in = this.socket_factory.getInputStream(this.socket);
/*  222 */           out = this.socket_factory.getOutputStream(this.socket);
/*      */         }
/*      */         
/*  225 */         this.socket.setTcpNoDelay(true);
/*  226 */         this.io.setInputStream(in);
/*  227 */         this.io.setOutputStream(out);
/*      */       }
/*      */       else {
/*  230 */         synchronized (this.proxy) {
/*  231 */           this.proxy.connect(this.socket_factory, this.host, this.port, connectTimeout);
/*  232 */           this.io.setInputStream(this.proxy.getInputStream());
/*  233 */           this.io.setOutputStream(this.proxy.getOutputStream());
/*  234 */           this.socket = this.proxy.getSocket();
/*      */         }
/*      */       }
/*      */       
/*  238 */       if ((connectTimeout > 0) && (this.socket != null)) {
/*  239 */         this.socket.setSoTimeout(connectTimeout);
/*      */       }
/*      */       
/*  242 */       this.isConnected = true;
/*      */       
/*  244 */       if (JSch.getLogger().isEnabled(1)) {
/*  245 */         JSch.getLogger().log(1, "Connection established");
/*      */       }
/*      */       
/*      */ 
/*  249 */       this.jsch.addSession(this);
/*      */       
/*      */ 
/*      */ 
/*  253 */       byte[] foo = new byte[this.V_C.length + 1];
/*  254 */       System.arraycopy(this.V_C, 0, foo, 0, this.V_C.length);
/*  255 */       foo[(foo.length - 1)] = 10;
/*  256 */       this.io.put(foo, 0, foo.length);
/*      */       int i;
/*      */       do
/*      */       {
/*  260 */         i = 0;
/*  261 */         int j = 0;
/*  262 */         while (i < this.buf.buffer.length) {
/*  263 */           j = this.io.getByte();
/*  264 */           if (j >= 0) {
/*  265 */             this.buf.buffer[i] = ((byte)j);i++;
/*  266 */             if (j == 10) break;
/*      */           } }
/*  268 */         if (j < 0) {
/*  269 */           throw new JSchException("connection is closed by foreign host");
/*      */         }
/*      */         
/*  272 */         if (this.buf.buffer[(i - 1)] == 10) {
/*  273 */           i--;
/*  274 */           if ((i > 0) && (this.buf.buffer[(i - 1)] == 13)) {
/*  275 */             i--;
/*      */           }
/*      */           
/*      */         }
/*  279 */       } while ((i <= 3) || ((i != this.buf.buffer.length) && ((this.buf.buffer[0] != 83) || (this.buf.buffer[1] != 83) || (this.buf.buffer[2] != 72) || (this.buf.buffer[3] != 45))));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  288 */       if ((i == this.buf.buffer.length) || (i < 7) || ((this.buf.buffer[4] == 49) && (this.buf.buffer[6] != 57)))
/*      */       {
/*      */ 
/*      */ 
/*  292 */         throw new JSchException("invalid server's version string");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  297 */       this.V_S = new byte[i];System.arraycopy(this.buf.buffer, 0, this.V_S, 0, i);
/*      */       
/*      */ 
/*  300 */       if (JSch.getLogger().isEnabled(1)) {
/*  301 */         JSch.getLogger().log(1, "Remote version string: " + Util.byte2str(this.V_S));
/*      */         
/*  303 */         JSch.getLogger().log(1, "Local version string: " + Util.byte2str(this.V_C));
/*      */       }
/*      */       
/*      */ 
/*  307 */       send_kexinit();
/*      */       
/*  309 */       this.buf = read(this.buf);
/*  310 */       if (this.buf.getCommand() != 20) {
/*  311 */         this.in_kex = false;
/*  312 */         throw new JSchException("invalid protocol: " + this.buf.getCommand());
/*      */       }
/*      */       
/*  315 */       if (JSch.getLogger().isEnabled(1)) {
/*  316 */         JSch.getLogger().log(1, "SSH_MSG_KEXINIT received");
/*      */       }
/*      */       
/*      */ 
/*  320 */       KeyExchange kex = receive_kexinit(this.buf);
/*      */       for (;;)
/*      */       {
/*  323 */         this.buf = read(this.buf);
/*  324 */         if (kex.getState() == this.buf.getCommand()) {
/*  325 */           this.kex_start_time = System.currentTimeMillis();
/*  326 */           boolean result = kex.next(this.buf);
/*  327 */           if (!result)
/*      */           {
/*  329 */             this.in_kex = false;
/*  330 */             throw new JSchException("verify: " + result);
/*      */           }
/*      */         }
/*      */         else {
/*  334 */           this.in_kex = false;
/*  335 */           throw new JSchException("invalid protocol(kex): " + this.buf.getCommand());
/*      */         }
/*  337 */         if (kex.getState() == 0) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/*  343 */         long tmp = System.currentTimeMillis();
/*  344 */         this.in_prompt = true;
/*  345 */         checkHost(this.host, this.port, kex);
/*  346 */         this.in_prompt = false;
/*  347 */         this.kex_start_time += System.currentTimeMillis() - tmp;
/*      */       }
/*      */       catch (JSchException ee) {
/*  350 */         this.in_kex = false;
/*  351 */         this.in_prompt = false;
/*  352 */         throw ee;
/*      */       }
/*      */       
/*  355 */       send_newkeys();
/*      */       
/*      */ 
/*  358 */       this.buf = read(this.buf);
/*      */       
/*  360 */       if (this.buf.getCommand() == 21)
/*      */       {
/*  362 */         if (JSch.getLogger().isEnabled(1)) {
/*  363 */           JSch.getLogger().log(1, "SSH_MSG_NEWKEYS received");
/*      */         }
/*      */         
/*      */ 
/*  367 */         receive_newkeys(this.buf, kex);
/*      */       }
/*      */       else {
/*  370 */         this.in_kex = false;
/*  371 */         throw new JSchException("invalid protocol(newkyes): " + this.buf.getCommand());
/*      */       }
/*      */       try
/*      */       {
/*  375 */         String s = getConfig("MaxAuthTries");
/*  376 */         if (s != null) {
/*  377 */           this.max_auth_tries = Integer.parseInt(s);
/*      */         }
/*      */       }
/*      */       catch (NumberFormatException e) {
/*  381 */         throw new JSchException("MaxAuthTries: " + getConfig("MaxAuthTries"), e);
/*      */       }
/*      */       
/*  384 */       boolean auth = false;
/*  385 */       boolean auth_cancel = false;
/*      */       
/*  387 */       UserAuth ua = null;
/*      */       try {
/*  389 */         Class c = Class.forName(getConfig("userauth.none"));
/*  390 */         ua = (UserAuth)c.newInstance();
/*      */       }
/*      */       catch (Exception e) {
/*  393 */         throw new JSchException(e.toString(), e);
/*      */       }
/*      */       
/*  396 */       auth = ua.start(this);
/*      */       
/*  398 */       String cmethods = getConfig("PreferredAuthentications");
/*      */       
/*  400 */       String[] cmethoda = Util.split(cmethods, ",");
/*      */       
/*  402 */       String smethods = null;
/*  403 */       if (!auth) {
/*  404 */         smethods = ((UserAuthNone)ua).getMethods();
/*  405 */         if (smethods != null) {
/*  406 */           smethods = smethods.toLowerCase();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  411 */           smethods = cmethods;
/*      */         }
/*      */       }
/*      */       
/*  415 */       String[] smethoda = Util.split(smethods, ",");
/*      */       
/*  417 */       int methodi = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  423 */       while ((!auth) && (cmethoda != null) && (methodi < cmethoda.length))
/*      */       {
/*  425 */         String method = cmethoda[(methodi++)];
/*  426 */         boolean acceptable = false;
/*  427 */         for (int k = 0; k < smethoda.length; k++) {
/*  428 */           if (smethoda[k].equals(method)) {
/*  429 */             acceptable = true;
/*  430 */             break;
/*      */           }
/*      */         }
/*  433 */         if (acceptable)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  439 */           if (JSch.getLogger().isEnabled(1)) {
/*  440 */             String str = "Authentications that can continue: ";
/*  441 */             for (int k = methodi - 1; k < cmethoda.length; k++) {
/*  442 */               str = str + cmethoda[k];
/*  443 */               if (k + 1 < cmethoda.length)
/*  444 */                 str = str + ",";
/*      */             }
/*  446 */             JSch.getLogger().log(1, str);
/*      */             
/*  448 */             JSch.getLogger().log(1, "Next authentication method: " + method);
/*      */           }
/*      */           
/*      */ 
/*  452 */           ua = null;
/*      */           try {
/*  454 */             Class c = null;
/*  455 */             if (getConfig("userauth." + method) != null) {
/*  456 */               c = Class.forName(getConfig("userauth." + method));
/*  457 */               ua = (UserAuth)c.newInstance();
/*      */             }
/*      */           }
/*      */           catch (Exception e) {
/*  461 */             if (JSch.getLogger().isEnabled(2)) {
/*  462 */               JSch.getLogger().log(2, "failed to load " + method + " method");
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  467 */           if (ua != null) {
/*  468 */             auth_cancel = false;
/*      */             try {
/*  470 */               auth = ua.start(this);
/*  471 */               if ((auth) && (JSch.getLogger().isEnabled(1)))
/*      */               {
/*  473 */                 JSch.getLogger().log(1, "Authentication succeeded (" + method + ").");
/*      */               }
/*      */             }
/*      */             catch (JSchAuthCancelException ee)
/*      */             {
/*  478 */               auth_cancel = true;
/*      */             }
/*      */             catch (JSchPartialAuthException ee) {
/*  481 */               String tmp = smethods;
/*  482 */               smethods = ee.getMethods();
/*  483 */               smethoda = Util.split(smethods, ",");
/*  484 */               if (!tmp.equals(smethods)) {
/*  485 */                 methodi = 0;
/*      */               }
/*      */               
/*  488 */               auth_cancel = false;
/*      */             }
/*      */             catch (RuntimeException ee)
/*      */             {
/*  492 */               throw ee;
/*      */             }
/*      */             catch (JSchException ee) {
/*  495 */               throw ee;
/*      */             }
/*      */             catch (Exception ee)
/*      */             {
/*  499 */               if (JSch.getLogger().isEnabled(2)) {
/*  500 */                 JSch.getLogger().log(2, "an exception during authentication\n" + ee.toString());
/*      */               }
/*      */               
/*  503 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  510 */       if (!auth) {
/*  511 */         if ((this.auth_failures >= this.max_auth_tries) && 
/*  512 */           (JSch.getLogger().isEnabled(1))) {
/*  513 */           JSch.getLogger().log(1, "Login trials exceeds " + this.max_auth_tries);
/*      */         }
/*      */         
/*      */ 
/*  517 */         if (auth_cancel)
/*  518 */           throw new JSchException("Auth cancel");
/*  519 */         throw new JSchException("Auth fail");
/*      */       }
/*      */       
/*  522 */       if ((this.socket != null) && ((connectTimeout > 0) || (this.timeout > 0))) {
/*  523 */         this.socket.setSoTimeout(this.timeout);
/*      */       }
/*      */       
/*  526 */       this.isAuthed = true;
/*      */       
/*  528 */       synchronized (this.lock) {
/*  529 */         if (this.isConnected) {
/*  530 */           this.connectThread = new Thread(this);
/*  531 */           this.connectThread.setName("Connect thread " + this.host + " session");
/*  532 */           if (this.daemon_thread) {
/*  533 */             this.connectThread.setDaemon(this.daemon_thread);
/*      */           }
/*  535 */           this.connectThread.start();
/*      */           
/*  537 */           requestPortForwarding();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  546 */       this.in_kex = false;
/*      */       try {
/*  548 */         if (this.isConnected) {
/*  549 */           String message = e.toString();
/*  550 */           this.packet.reset();
/*  551 */           this.buf.checkFreeSize(13 + message.length() + 2 + 128);
/*  552 */           this.buf.putByte((byte)1);
/*  553 */           this.buf.putInt(3);
/*  554 */           this.buf.putString(Util.str2byte(message));
/*  555 */           this.buf.putString(Util.str2byte("en"));
/*  556 */           write(this.packet);
/*      */         }
/*      */       } catch (Exception ee) {}
/*      */       try {
/*  560 */         disconnect(); } catch (Exception ee) {}
/*  561 */       this.isConnected = false;
/*      */       
/*  563 */       if ((e instanceof RuntimeException)) throw ((RuntimeException)e);
/*  564 */       if ((e instanceof JSchException)) throw ((JSchException)e);
/*  565 */       throw new JSchException("Session.connect: " + e);
/*      */     }
/*      */     finally {
/*  568 */       Util.bzero(this.password);
/*  569 */       this.password = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private KeyExchange receive_kexinit(Buffer buf) throws Exception {
/*  574 */     int j = buf.getInt();
/*  575 */     if (j != buf.getLength()) {
/*  576 */       buf.getByte();
/*  577 */       this.I_S = new byte[buf.index - 5];
/*      */     }
/*      */     else {
/*  580 */       this.I_S = new byte[j - 1 - buf.getByte()];
/*      */     }
/*  582 */     System.arraycopy(buf.buffer, buf.s, this.I_S, 0, this.I_S.length);
/*      */     
/*  584 */     if (!this.in_kex) {
/*  585 */       send_kexinit();
/*      */     }
/*      */     
/*  588 */     this.guess = KeyExchange.guess(this.I_S, this.I_C);
/*  589 */     if (this.guess == null) {
/*  590 */       throw new JSchException("Algorithm negotiation fail");
/*      */     }
/*      */     
/*  593 */     if ((!this.isAuthed) && ((this.guess[2].equals("none")) || (this.guess[3].equals("none"))))
/*      */     {
/*      */ 
/*  596 */       throw new JSchException("NONE Cipher should not be chosen before authentification is successed.");
/*      */     }
/*      */     
/*  599 */     KeyExchange kex = null;
/*      */     try {
/*  601 */       Class c = Class.forName(getConfig(this.guess[0]));
/*  602 */       kex = (KeyExchange)c.newInstance();
/*      */     }
/*      */     catch (Exception e) {
/*  605 */       throw new JSchException(e.toString(), e);
/*      */     }
/*      */     
/*  608 */     kex.init(this, this.V_S, this.V_C, this.I_S, this.I_C);
/*  609 */     return kex;
/*      */   }
/*      */   
/*  612 */   private volatile boolean in_kex = false;
/*  613 */   private volatile boolean in_prompt = false;
/*      */   
/*  615 */   public void rekey() throws Exception { send_kexinit(); }
/*      */   
/*      */   private void send_kexinit() throws Exception {
/*  618 */     if (this.in_kex) {
/*  619 */       return;
/*      */     }
/*  621 */     String cipherc2s = getConfig("cipher.c2s");
/*  622 */     String ciphers2c = getConfig("cipher.s2c");
/*      */     
/*  624 */     String[] not_available_ciphers = checkCiphers(getConfig("CheckCiphers"));
/*  625 */     if ((not_available_ciphers != null) && (not_available_ciphers.length > 0)) {
/*  626 */       cipherc2s = Util.diffString(cipherc2s, not_available_ciphers);
/*  627 */       ciphers2c = Util.diffString(ciphers2c, not_available_ciphers);
/*  628 */       if ((cipherc2s == null) || (ciphers2c == null)) {
/*  629 */         throw new JSchException("There are not any available ciphers.");
/*      */       }
/*      */     }
/*      */     
/*  633 */     String kex = getConfig("kex");
/*  634 */     String[] not_available_kexes = checkKexes(getConfig("CheckKexes"));
/*  635 */     if ((not_available_kexes != null) && (not_available_kexes.length > 0)) {
/*  636 */       kex = Util.diffString(kex, not_available_kexes);
/*  637 */       if (kex == null) {
/*  638 */         throw new JSchException("There are not any available kexes.");
/*      */       }
/*      */     }
/*      */     
/*  642 */     String server_host_key = getConfig("server_host_key");
/*  643 */     String[] not_available_shks = checkSignatures(getConfig("CheckSignatures"));
/*      */     
/*  645 */     if ((not_available_shks != null) && (not_available_shks.length > 0)) {
/*  646 */       server_host_key = Util.diffString(server_host_key, not_available_shks);
/*  647 */       if (server_host_key == null) {
/*  648 */         throw new JSchException("There are not any available sig algorithm.");
/*      */       }
/*      */     }
/*      */     
/*  652 */     this.in_kex = true;
/*  653 */     this.kex_start_time = System.currentTimeMillis();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  667 */     Buffer buf = new Buffer();
/*  668 */     Packet packet = new Packet(buf);
/*  669 */     packet.reset();
/*  670 */     buf.putByte((byte)20);
/*  671 */     synchronized (random) {
/*  672 */       random.fill(buf.buffer, buf.index, 16);buf.skip(16);
/*      */     }
/*  674 */     buf.putString(Util.str2byte(kex));
/*  675 */     buf.putString(Util.str2byte(server_host_key));
/*  676 */     buf.putString(Util.str2byte(cipherc2s));
/*  677 */     buf.putString(Util.str2byte(ciphers2c));
/*  678 */     buf.putString(Util.str2byte(getConfig("mac.c2s")));
/*  679 */     buf.putString(Util.str2byte(getConfig("mac.s2c")));
/*  680 */     buf.putString(Util.str2byte(getConfig("compression.c2s")));
/*  681 */     buf.putString(Util.str2byte(getConfig("compression.s2c")));
/*  682 */     buf.putString(Util.str2byte(getConfig("lang.c2s")));
/*  683 */     buf.putString(Util.str2byte(getConfig("lang.s2c")));
/*  684 */     buf.putByte((byte)0);
/*  685 */     buf.putInt(0);
/*      */     
/*  687 */     buf.setOffSet(5);
/*  688 */     this.I_C = new byte[buf.getLength()];
/*  689 */     buf.getByte(this.I_C);
/*      */     
/*  691 */     write(packet);
/*      */     
/*  693 */     if (JSch.getLogger().isEnabled(1)) {
/*  694 */       JSch.getLogger().log(1, "SSH_MSG_KEXINIT sent");
/*      */     }
/*      */   }
/*      */   
/*      */   private void send_newkeys()
/*      */     throws Exception
/*      */   {
/*  701 */     this.packet.reset();
/*  702 */     this.buf.putByte((byte)21);
/*  703 */     write(this.packet);
/*      */     
/*  705 */     if (JSch.getLogger().isEnabled(1)) {
/*  706 */       JSch.getLogger().log(1, "SSH_MSG_NEWKEYS sent");
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkHost(String chost, int port, KeyExchange kex) throws JSchException
/*      */   {
/*  712 */     String shkc = getConfig("StrictHostKeyChecking");
/*      */     
/*  714 */     if (this.hostKeyAlias != null) {
/*  715 */       chost = this.hostKeyAlias;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  720 */     byte[] K_S = kex.getHostKey();
/*  721 */     String key_type = kex.getKeyType();
/*  722 */     String key_fprint = kex.getFingerPrint();
/*      */     
/*  724 */     if ((this.hostKeyAlias == null) && (port != 22)) {
/*  725 */       chost = "[" + chost + "]:" + port;
/*      */     }
/*      */     
/*  728 */     HostKeyRepository hkr = getHostKeyRepository();
/*      */     
/*  730 */     String hkh = getConfig("HashKnownHosts");
/*  731 */     if ((hkh.equals("yes")) && ((hkr instanceof KnownHosts))) {
/*  732 */       this.hostkey = ((KnownHosts)hkr).createHashedHostKey(chost, K_S);
/*      */     }
/*      */     else {
/*  735 */       this.hostkey = new HostKey(chost, K_S);
/*      */     }
/*      */     
/*  738 */     int i = 0;
/*  739 */     synchronized (hkr) {
/*  740 */       i = hkr.check(chost, K_S);
/*      */     }
/*      */     
/*  743 */     boolean insert = false;
/*  744 */     if (((shkc.equals("ask")) || (shkc.equals("yes"))) && (i == 2))
/*      */     {
/*  746 */       String file = null;
/*  747 */       synchronized (hkr) {
/*  748 */         file = hkr.getKnownHostsRepositoryID();
/*      */       }
/*  750 */       if (file == null) { file = "known_hosts";
/*      */       }
/*  752 */       boolean b = false;
/*      */       
/*  754 */       if (this.userinfo != null) {
/*  755 */         String message = "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!\nIT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!\nSomeone could be eavesdropping on you right now (man-in-the-middle attack)!\nIt is also possible that the " + key_type + " host key has just been changed.\n" + "The fingerprint for the " + key_type + " key sent by the remote host " + chost + " is\n" + key_fprint + ".\n" + "Please contact your system administrator.\n" + "Add correct host key in " + file + " to get rid of this message.";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  765 */         if (shkc.equals("ask")) {
/*  766 */           b = this.userinfo.promptYesNo(message + "\nDo you want to delete the old key and insert the new key?");
/*      */         }
/*      */         else
/*      */         {
/*  770 */           this.userinfo.showMessage(message);
/*      */         }
/*      */       }
/*      */       
/*  774 */       if (!b) {
/*  775 */         throw new JSchException("HostKey has been changed: " + chost);
/*      */       }
/*      */       
/*  778 */       synchronized (hkr) {
/*  779 */         hkr.remove(chost, kex.getKeyAlgorithName(), null);
/*      */         
/*      */ 
/*  782 */         insert = true;
/*      */       }
/*      */     }
/*      */     
/*  786 */     if (((shkc.equals("ask")) || (shkc.equals("yes"))) && (i != 0) && (!insert))
/*      */     {
/*  788 */       if (shkc.equals("yes")) {
/*  789 */         throw new JSchException("reject HostKey: " + this.host);
/*      */       }
/*      */       
/*  792 */       if (this.userinfo != null) {
/*  793 */         boolean foo = this.userinfo.promptYesNo("The authenticity of host '" + this.host + "' can't be established.\n" + key_type + " key fingerprint is " + key_fprint + ".\n" + "Are you sure you want to continue connecting?");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  798 */         if (!foo) {
/*  799 */           throw new JSchException("reject HostKey: " + this.host);
/*      */         }
/*  801 */         insert = true;
/*      */       }
/*      */       else {
/*  804 */         if (i == 1) {
/*  805 */           throw new JSchException("UnknownHostKey: " + this.host + ". " + key_type + " key fingerprint is " + key_fprint);
/*      */         }
/*  807 */         throw new JSchException("HostKey has been changed: " + this.host);
/*      */       }
/*      */     }
/*      */     
/*  811 */     if ((shkc.equals("no")) && (1 == i))
/*      */     {
/*  813 */       insert = true;
/*      */     }
/*      */     
/*  816 */     if (i == 0) {
/*  817 */       HostKey[] keys = hkr.getHostKey(chost, kex.getKeyAlgorithName());
/*      */       
/*  819 */       String _key = Util.byte2str(Util.toBase64(K_S, 0, K_S.length));
/*  820 */       for (int j = 0; j < keys.length; j++) {
/*  821 */         if ((keys[i].getKey().equals(_key)) && (keys[j].getMarker().equals("@revoked")))
/*      */         {
/*  823 */           if (this.userinfo != null) {
/*  824 */             this.userinfo.showMessage("The " + key_type + " host key for " + this.host + " is marked as revoked.\n" + "This could mean that a stolen key is being used to " + "impersonate this host.");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  829 */           if (JSch.getLogger().isEnabled(1)) {
/*  830 */             JSch.getLogger().log(1, "Host '" + this.host + "' has provided revoked key.");
/*      */           }
/*      */           
/*  833 */           throw new JSchException("revoked HostKey: " + this.host);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  838 */     if ((i == 0) && (JSch.getLogger().isEnabled(1)))
/*      */     {
/*  840 */       JSch.getLogger().log(1, "Host '" + this.host + "' is known and matches the " + key_type + " host key");
/*      */     }
/*      */     
/*      */ 
/*  844 */     if ((insert) && (JSch.getLogger().isEnabled(2)))
/*      */     {
/*  846 */       JSch.getLogger().log(2, "Permanently added '" + this.host + "' (" + key_type + ") to the list of known hosts.");
/*      */     }
/*      */     
/*      */ 
/*  850 */     if (insert) {
/*  851 */       synchronized (hkr) {
/*  852 */         hkr.add(this.hostkey, this.userinfo);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Channel openChannel(String type)
/*      */     throws JSchException
/*      */   {
/*  860 */     if (!this.isConnected) {
/*  861 */       throw new JSchException("session is down");
/*      */     }
/*      */     try {
/*  864 */       Channel channel = Channel.getChannel(type);
/*  865 */       addChannel(channel);
/*  866 */       channel.init();
/*  867 */       if ((channel instanceof ChannelSession)) {
/*  868 */         applyConfigChannel((ChannelSession)channel);
/*      */       }
/*  870 */       return channel;
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/*  875 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void encode(Packet packet)
/*      */     throws Exception
/*      */   {
/*  885 */     if (this.deflater != null) {
/*  886 */       this.compress_len[0] = packet.buffer.index;
/*  887 */       packet.buffer.buffer = this.deflater.compress(packet.buffer.buffer, 5, this.compress_len);
/*      */       
/*  889 */       packet.buffer.index = this.compress_len[0];
/*      */     }
/*  891 */     if (this.c2scipher != null)
/*      */     {
/*  893 */       packet.padding(this.c2scipher_size);
/*  894 */       int pad = packet.buffer.buffer[4];
/*  895 */       synchronized (random) {
/*  896 */         random.fill(packet.buffer.buffer, packet.buffer.index - pad, pad);
/*      */       }
/*      */     }
/*      */     else {
/*  900 */       packet.padding(8);
/*      */     }
/*      */     
/*  903 */     if (this.c2smac != null) {
/*  904 */       this.c2smac.update(this.seqo);
/*  905 */       this.c2smac.update(packet.buffer.buffer, 0, packet.buffer.index);
/*  906 */       this.c2smac.doFinal(packet.buffer.buffer, packet.buffer.index);
/*      */     }
/*  908 */     if (this.c2scipher != null) {
/*  909 */       byte[] buf = packet.buffer.buffer;
/*  910 */       this.c2scipher.update(buf, 0, packet.buffer.index, buf, 0);
/*      */     }
/*  912 */     if (this.c2smac != null) {
/*  913 */       packet.buffer.skip(this.c2smac.getBlockSize());
/*      */     }
/*      */   }
/*      */   
/*  917 */   int[] uncompress_len = new int[1];
/*  918 */   int[] compress_len = new int[1];
/*      */   
/*  920 */   private int s2ccipher_size = 8;
/*  921 */   private int c2scipher_size = 8;
/*      */   
/*  923 */   public Buffer read(Buffer buf) throws Exception { int j = 0;
/*      */     for (;;) {
/*  925 */       buf.reset();
/*  926 */       this.io.getByte(buf.buffer, buf.index, this.s2ccipher_size);
/*  927 */       buf.index += this.s2ccipher_size;
/*  928 */       if (this.s2ccipher != null) {
/*  929 */         this.s2ccipher.update(buf.buffer, 0, this.s2ccipher_size, buf.buffer, 0);
/*      */       }
/*  931 */       j = buf.buffer[0] << 24 & 0xFF000000 | buf.buffer[1] << 16 & 0xFF0000 | buf.buffer[2] << 8 & 0xFF00 | buf.buffer[3] & 0xFF;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  936 */       if ((j < 5) || (j > 262144)) {
/*  937 */         start_discard(buf, this.s2ccipher, this.s2cmac, j, 262144);
/*      */       }
/*  939 */       int need = j + 4 - this.s2ccipher_size;
/*      */       
/*      */ 
/*      */ 
/*  943 */       if (buf.index + need > buf.buffer.length) {
/*  944 */         byte[] foo = new byte[buf.index + need];
/*  945 */         System.arraycopy(buf.buffer, 0, foo, 0, buf.index);
/*  946 */         buf.buffer = foo;
/*      */       }
/*      */       
/*  949 */       if (need % this.s2ccipher_size != 0) {
/*  950 */         String message = "Bad packet length " + need;
/*  951 */         if (JSch.getLogger().isEnabled(4)) {
/*  952 */           JSch.getLogger().log(4, message);
/*      */         }
/*  954 */         start_discard(buf, this.s2ccipher, this.s2cmac, j, 262144 - this.s2ccipher_size);
/*      */       }
/*      */       
/*  957 */       if (need > 0) {
/*  958 */         this.io.getByte(buf.buffer, buf.index, need);buf.index += need;
/*  959 */         if (this.s2ccipher != null) {
/*  960 */           this.s2ccipher.update(buf.buffer, this.s2ccipher_size, need, buf.buffer, this.s2ccipher_size);
/*      */         }
/*      */       }
/*      */       
/*  964 */       if (this.s2cmac != null) {
/*  965 */         this.s2cmac.update(this.seqi);
/*  966 */         this.s2cmac.update(buf.buffer, 0, buf.index);
/*      */         
/*  968 */         this.s2cmac.doFinal(this.s2cmac_result1, 0);
/*  969 */         this.io.getByte(this.s2cmac_result2, 0, this.s2cmac_result2.length);
/*  970 */         if (!Arrays.equals(this.s2cmac_result1, this.s2cmac_result2)) {
/*  971 */           if (need > 262144) {
/*  972 */             throw new IOException("MAC Error");
/*      */           }
/*  974 */           start_discard(buf, this.s2ccipher, this.s2cmac, j, 262144 - need);
/*  975 */           continue;
/*      */         }
/*      */       }
/*      */       
/*  979 */       this.seqi += 1;
/*      */       
/*  981 */       if (this.inflater != null)
/*      */       {
/*  983 */         int pad = buf.buffer[4];
/*  984 */         this.uncompress_len[0] = (buf.index - 5 - pad);
/*  985 */         byte[] foo = this.inflater.uncompress(buf.buffer, 5, this.uncompress_len);
/*  986 */         if (foo != null) {
/*  987 */           buf.buffer = foo;
/*  988 */           buf.index = (5 + this.uncompress_len[0]);
/*      */         }
/*      */         else {
/*  991 */           System.err.println("fail in inflater");
/*  992 */           break;
/*      */         }
/*      */       }
/*      */       
/*  996 */       int type = buf.getCommand() & 0xFF;
/*      */       
/*  998 */       if (type == 1) {
/*  999 */         buf.rewind();
/* 1000 */         buf.getInt();buf.getShort();
/* 1001 */         int reason_code = buf.getInt();
/* 1002 */         byte[] description = buf.getString();
/* 1003 */         byte[] language_tag = buf.getString();
/* 1004 */         throw new JSchException("SSH_MSG_DISCONNECT: " + reason_code + " " + Util.byte2str(description) + " " + Util.byte2str(language_tag));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1010 */       if (type != 2)
/*      */       {
/* 1012 */         if (type == 3) {
/* 1013 */           buf.rewind();
/* 1014 */           buf.getInt();buf.getShort();
/* 1015 */           int reason_id = buf.getInt();
/* 1016 */           if (JSch.getLogger().isEnabled(1)) {
/* 1017 */             JSch.getLogger().log(1, "Received SSH_MSG_UNIMPLEMENTED for " + reason_id);
/*      */           }
/*      */           
/*      */         }
/* 1021 */         else if (type == 4) {
/* 1022 */           buf.rewind();
/* 1023 */           buf.getInt();buf.getShort();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1033 */         else if (type == 93) {
/* 1034 */           buf.rewind();
/* 1035 */           buf.getInt();buf.getShort();
/* 1036 */           Channel c = Channel.getChannel(buf.getInt(), this);
/* 1037 */           if (c != null)
/*      */           {
/*      */ 
/* 1040 */             c.addRemoteWindowSize(buf.getUInt());
/*      */           }
/*      */         } else {
/* 1043 */           if (type != 52) break;
/* 1044 */           this.isAuthed = true;
/* 1045 */           if ((this.inflater != null) || (this.deflater != null))
/*      */             break;
/* 1047 */           String method = this.guess[6];
/* 1048 */           initDeflater(method);
/* 1049 */           method = this.guess[7];
/* 1050 */           initInflater(method);
/* 1051 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1058 */     buf.rewind();
/* 1059 */     return buf;
/*      */   }
/*      */   
/*      */   private void start_discard(Buffer buf, Cipher cipher, MAC mac, int packet_length, int discard) throws JSchException, IOException
/*      */   {
/* 1064 */     MAC discard_mac = null;
/*      */     
/* 1066 */     if (!cipher.isCBC()) {
/* 1067 */       throw new JSchException("Packet corrupt");
/*      */     }
/*      */     
/* 1070 */     if ((packet_length != 262144) && (mac != null)) {
/* 1071 */       discard_mac = mac;
/*      */     }
/*      */     
/* 1074 */     discard -= buf.index;
/*      */     
/* 1076 */     while (discard > 0) {
/* 1077 */       buf.reset();
/* 1078 */       int len = discard > buf.buffer.length ? buf.buffer.length : discard;
/* 1079 */       this.io.getByte(buf.buffer, 0, len);
/* 1080 */       if (discard_mac != null) {
/* 1081 */         discard_mac.update(buf.buffer, 0, len);
/*      */       }
/* 1083 */       discard -= len;
/*      */     }
/*      */     
/* 1086 */     if (discard_mac != null) {
/* 1087 */       discard_mac.doFinal(buf.buffer, 0);
/*      */     }
/*      */     
/* 1090 */     throw new JSchException("Packet corrupt");
/*      */   }
/*      */   
/*      */   byte[] getSessionId() {
/* 1094 */     return this.session_id;
/*      */   }
/*      */   
/*      */   private void receive_newkeys(Buffer buf, KeyExchange kex) throws Exception {
/* 1098 */     updateKeys(kex);
/* 1099 */     this.in_kex = false;
/*      */   }
/*      */   
/* 1102 */   private void updateKeys(KeyExchange kex) throws Exception { byte[] K = kex.getK();
/* 1103 */     byte[] H = kex.getH();
/* 1104 */     HASH hash = kex.getHash();
/*      */     
/* 1106 */     if (this.session_id == null) {
/* 1107 */       this.session_id = new byte[H.length];
/* 1108 */       System.arraycopy(H, 0, this.session_id, 0, H.length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1120 */     this.buf.reset();
/* 1121 */     this.buf.putMPInt(K);
/* 1122 */     this.buf.putByte(H);
/* 1123 */     this.buf.putByte((byte)65);
/* 1124 */     this.buf.putByte(this.session_id);
/* 1125 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1126 */     this.IVc2s = hash.digest();
/*      */     
/* 1128 */     int j = this.buf.index - this.session_id.length - 1; int 
/*      */     
/* 1130 */       tmp145_143 = j; byte[] tmp145_140 = this.buf.buffer;tmp145_140[tmp145_143] = ((byte)(tmp145_140[tmp145_143] + 1));
/* 1131 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1132 */     this.IVs2c = hash.digest(); int 
/*      */     
/* 1134 */       tmp193_191 = j; byte[] tmp193_188 = this.buf.buffer;tmp193_188[tmp193_191] = ((byte)(tmp193_188[tmp193_191] + 1));
/* 1135 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1136 */     this.Ec2s = hash.digest(); int 
/*      */     
/* 1138 */       tmp241_239 = j; byte[] tmp241_236 = this.buf.buffer;tmp241_236[tmp241_239] = ((byte)(tmp241_236[tmp241_239] + 1));
/* 1139 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1140 */     this.Es2c = hash.digest(); int 
/*      */     
/* 1142 */       tmp289_287 = j; byte[] tmp289_284 = this.buf.buffer;tmp289_284[tmp289_287] = ((byte)(tmp289_284[tmp289_287] + 1));
/* 1143 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1144 */     this.MACc2s = hash.digest(); int 
/*      */     
/* 1146 */       tmp337_335 = j; byte[] tmp337_332 = this.buf.buffer;tmp337_332[tmp337_335] = ((byte)(tmp337_332[tmp337_335] + 1));
/* 1147 */     hash.update(this.buf.buffer, 0, this.buf.index);
/* 1148 */     this.MACs2c = hash.digest();
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1154 */       String method = this.guess[3];
/* 1155 */       Class c = Class.forName(getConfig(method));
/* 1156 */       this.s2ccipher = ((Cipher)c.newInstance());
/* 1157 */       while (this.s2ccipher.getBlockSize() > this.Es2c.length) {
/* 1158 */         this.buf.reset();
/* 1159 */         this.buf.putMPInt(K);
/* 1160 */         this.buf.putByte(H);
/* 1161 */         this.buf.putByte(this.Es2c);
/* 1162 */         hash.update(this.buf.buffer, 0, this.buf.index);
/* 1163 */         byte[] foo = hash.digest();
/* 1164 */         byte[] bar = new byte[this.Es2c.length + foo.length];
/* 1165 */         System.arraycopy(this.Es2c, 0, bar, 0, this.Es2c.length);
/* 1166 */         System.arraycopy(foo, 0, bar, this.Es2c.length, foo.length);
/* 1167 */         this.Es2c = bar;
/*      */       }
/* 1169 */       this.s2ccipher.init(1, this.Es2c, this.IVs2c);
/* 1170 */       this.s2ccipher_size = this.s2ccipher.getIVSize();
/*      */       
/* 1172 */       method = this.guess[5];
/* 1173 */       c = Class.forName(getConfig(method));
/* 1174 */       this.s2cmac = ((MAC)c.newInstance());
/* 1175 */       this.MACs2c = expandKey(this.buf, K, H, this.MACs2c, hash, this.s2cmac.getBlockSize());
/* 1176 */       this.s2cmac.init(this.MACs2c);
/*      */       
/* 1178 */       this.s2cmac_result1 = new byte[this.s2cmac.getBlockSize()];
/* 1179 */       this.s2cmac_result2 = new byte[this.s2cmac.getBlockSize()];
/*      */       
/* 1181 */       method = this.guess[2];
/* 1182 */       c = Class.forName(getConfig(method));
/* 1183 */       this.c2scipher = ((Cipher)c.newInstance());
/* 1184 */       while (this.c2scipher.getBlockSize() > this.Ec2s.length) {
/* 1185 */         this.buf.reset();
/* 1186 */         this.buf.putMPInt(K);
/* 1187 */         this.buf.putByte(H);
/* 1188 */         this.buf.putByte(this.Ec2s);
/* 1189 */         hash.update(this.buf.buffer, 0, this.buf.index);
/* 1190 */         byte[] foo = hash.digest();
/* 1191 */         byte[] bar = new byte[this.Ec2s.length + foo.length];
/* 1192 */         System.arraycopy(this.Ec2s, 0, bar, 0, this.Ec2s.length);
/* 1193 */         System.arraycopy(foo, 0, bar, this.Ec2s.length, foo.length);
/* 1194 */         this.Ec2s = bar;
/*      */       }
/* 1196 */       this.c2scipher.init(0, this.Ec2s, this.IVc2s);
/* 1197 */       this.c2scipher_size = this.c2scipher.getIVSize();
/*      */       
/* 1199 */       method = this.guess[4];
/* 1200 */       c = Class.forName(getConfig(method));
/* 1201 */       this.c2smac = ((MAC)c.newInstance());
/* 1202 */       this.MACc2s = expandKey(this.buf, K, H, this.MACc2s, hash, this.c2smac.getBlockSize());
/* 1203 */       this.c2smac.init(this.MACc2s);
/*      */       
/* 1205 */       method = this.guess[6];
/* 1206 */       initDeflater(method);
/*      */       
/* 1208 */       method = this.guess[7];
/* 1209 */       initInflater(method);
/*      */     }
/*      */     catch (Exception e) {
/* 1212 */       if ((e instanceof JSchException))
/* 1213 */         throw e;
/* 1214 */       throw new JSchException(e.toString(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] expandKey(Buffer buf, byte[] K, byte[] H, byte[] key, HASH hash, int required_length)
/*      */     throws Exception
/*      */   {
/* 1236 */     byte[] result = key;
/* 1237 */     int size = hash.getBlockSize();
/* 1238 */     while (result.length < required_length) {
/* 1239 */       buf.reset();
/* 1240 */       buf.putMPInt(K);
/* 1241 */       buf.putByte(H);
/* 1242 */       buf.putByte(result);
/* 1243 */       hash.update(buf.buffer, 0, buf.index);
/* 1244 */       byte[] tmp = new byte[result.length + size];
/* 1245 */       System.arraycopy(result, 0, tmp, 0, result.length);
/* 1246 */       System.arraycopy(hash.digest(), 0, tmp, result.length, size);
/* 1247 */       Util.bzero(result);
/* 1248 */       result = tmp;
/*      */     }
/* 1250 */     return result;
/*      */   }
/*      */   
/*      */   void write(Packet packet, Channel c, int length) throws Exception {
/* 1254 */     long t = getTimeout();
/*      */     for (;;) {
/* 1256 */       if (this.in_kex) {
/* 1257 */         if ((t > 0L) && (System.currentTimeMillis() - this.kex_start_time > t))
/* 1258 */           throw new JSchException("timeout in waiting for rekeying process.");
/*      */         try {
/* 1260 */           Thread.sleep(10L);
/*      */         }
/*      */         catch (InterruptedException e) {}
/*      */       } else {
/* 1264 */         synchronized (c)
/*      */         {
/* 1266 */           if (c.rwsize < length) {
/*      */             try {
/* 1268 */               c.notifyme += 1;
/* 1269 */               c.wait(100L);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1274 */               c.notifyme -= 1; } catch (InterruptedException e) { c.notifyme -= 1; } finally { c.notifyme -= 1;
/*      */             }
/*      */           }
/*      */           
/* 1278 */           if (this.in_kex) {
/*      */             continue;
/*      */           }
/*      */           
/* 1282 */           if (c.rwsize >= length) {
/* 1283 */             c.rwsize -= length;
/* 1284 */             break;
/*      */           }
/*      */         }
/*      */         
/* 1288 */         if ((c.close) || (!c.isConnected())) {
/* 1289 */           throw new IOException("channel is broken");
/*      */         }
/*      */         
/* 1292 */         boolean sendit = false;
/* 1293 */         int s = 0;
/* 1294 */         byte command = 0;
/* 1295 */         int recipient = -1;
/* 1296 */         synchronized (c) {
/* 1297 */           if (c.rwsize > 0L) {
/* 1298 */             long len = c.rwsize;
/* 1299 */             if (len > length) {
/* 1300 */               len = length;
/*      */             }
/* 1302 */             if (len != length) {
/* 1303 */               s = packet.shift((int)len, this.c2scipher != null ? this.c2scipher_size : 8, this.c2smac != null ? this.c2smac.getBlockSize() : 0);
/*      */             }
/*      */             
/*      */ 
/* 1307 */             command = packet.buffer.getCommand();
/* 1308 */             recipient = c.getRecipient();
/* 1309 */             length = (int)(length - len);
/* 1310 */             c.rwsize -= len;
/* 1311 */             sendit = true;
/*      */           }
/*      */         }
/* 1314 */         if (sendit) {
/* 1315 */           _write(packet);
/* 1316 */           if (length == 0) {
/* 1317 */             return;
/*      */           }
/* 1319 */           packet.unshift(command, recipient, s, length);
/*      */         }
/*      */         
/* 1322 */         synchronized (c) {
/* 1323 */           if (!this.in_kex)
/*      */           {
/*      */ 
/* 1326 */             if (c.rwsize >= length) {
/* 1327 */               c.rwsize -= length;
/* 1328 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1343 */     _write(packet);
/*      */   }
/*      */   
/*      */   public void write(Packet packet) throws Exception
/*      */   {
/* 1348 */     long t = getTimeout();
/* 1349 */     while (this.in_kex) {
/* 1350 */       if ((t > 0L) && (System.currentTimeMillis() - this.kex_start_time > t) && (!this.in_prompt))
/*      */       {
/*      */ 
/*      */ 
/* 1354 */         throw new JSchException("timeout in waiting for rekeying process.");
/*      */       }
/* 1356 */       byte command = packet.buffer.getCommand();
/*      */       
/* 1358 */       if ((command == 20) || (command == 21) || (command == 30) || (command == 31) || (command == 31) || (command == 32) || (command == 33) || (command == 34) || (command == 1)) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1369 */         Thread.sleep(10L);
/*      */       } catch (InterruptedException e) {}
/*      */     }
/* 1372 */     _write(packet);
/*      */   }
/*      */   
/*      */   private void _write(Packet packet) throws Exception {
/* 1376 */     synchronized (this.lock) {
/* 1377 */       encode(packet);
/* 1378 */       if (this.io != null) {
/* 1379 */         this.io.put(packet);
/* 1380 */         this.seqo += 1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void run()
/*      */   {
/* 1387 */     this.thread = this;
/*      */     
/*      */ 
/* 1390 */     Buffer buf = new Buffer();
/* 1391 */     Packet packet = new Packet(buf);
/* 1392 */     int i = 0;
/*      */     
/* 1394 */     int[] start = new int[1];
/* 1395 */     int[] length = new int[1];
/* 1396 */     KeyExchange kex = null;
/*      */     
/* 1398 */     int stimeout = 0;
/*      */     try
/*      */     {
/* 1401 */       while ((this.isConnected) && (this.thread != null)) {
/*      */         try {
/* 1403 */           buf = read(buf);
/* 1404 */           stimeout = 0;
/*      */         }
/*      */         catch (InterruptedIOException ee) {
/* 1407 */           if ((!this.in_kex) && (stimeout < this.serverAliveCountMax)) {
/* 1408 */             sendKeepAliveMsg();
/* 1409 */             stimeout++;
/* 1410 */             continue;
/*      */           }
/* 1412 */           if ((this.in_kex) && (stimeout < this.serverAliveCountMax)) {
/* 1413 */             stimeout++;
/* 1414 */             continue;
/*      */           }
/* 1416 */           throw ee;
/*      */         }
/*      */         
/* 1419 */         int msgType = buf.getCommand() & 0xFF;
/*      */         
/* 1421 */         if ((kex != null) && (kex.getState() == msgType)) {
/* 1422 */           this.kex_start_time = System.currentTimeMillis();
/* 1423 */           boolean result = kex.next(buf);
/* 1424 */           if (!result)
/* 1425 */             throw new JSchException("verify: " + result);
/*      */         } else { Channel channel;
/*      */           byte[] foo;
/*      */           int len;
/*      */           boolean reply;
/* 1430 */           switch (msgType)
/*      */           {
/*      */           case 20: 
/* 1433 */             kex = receive_kexinit(buf);
/* 1434 */             break;
/*      */           
/*      */ 
/*      */           case 21: 
/* 1438 */             send_newkeys();
/* 1439 */             receive_newkeys(buf, kex);
/* 1440 */             kex = null;
/* 1441 */             break;
/*      */           
/*      */           case 94: 
/* 1444 */             buf.getInt();
/* 1445 */             buf.getByte();
/* 1446 */             buf.getByte();
/* 1447 */             i = buf.getInt();
/* 1448 */             channel = Channel.getChannel(i, this);
/* 1449 */             foo = buf.getString(start, length);
/* 1450 */             if (channel != null)
/*      */             {
/*      */ 
/*      */ 
/* 1454 */               if (length[0] != 0)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/* 1459 */                   channel.write(foo, start[0], length[0]);
/*      */                 }
/*      */                 catch (Exception e) {
/*      */                   try {
/* 1463 */                     channel.disconnect(); } catch (Exception ee) {}
/* 1464 */                   break;
/*      */                 }
/* 1466 */                 len = length[0];
/* 1467 */                 channel.setLocalWindowSize(channel.lwsize - len);
/* 1468 */                 if (channel.lwsize < channel.lwsize_max / 2) {
/* 1469 */                   packet.reset();
/* 1470 */                   buf.putByte((byte)93);
/* 1471 */                   buf.putInt(channel.getRecipient());
/* 1472 */                   buf.putInt(channel.lwsize_max - channel.lwsize);
/* 1473 */                   synchronized (channel) {
/* 1474 */                     if (!channel.close)
/* 1475 */                       write(packet);
/*      */                   }
/* 1477 */                   channel.setLocalWindowSize(channel.lwsize_max);
/*      */                 }
/*      */               } }
/*      */             break;
/*      */           case 95: 
/* 1482 */             buf.getInt();
/* 1483 */             buf.getShort();
/* 1484 */             i = buf.getInt();
/* 1485 */             channel = Channel.getChannel(i, this);
/* 1486 */             buf.getInt();
/* 1487 */             foo = buf.getString(start, length);
/*      */             
/* 1489 */             if (channel != null)
/*      */             {
/*      */ 
/*      */ 
/* 1493 */               if (length[0] != 0)
/*      */               {
/*      */ 
/*      */ 
/* 1497 */                 channel.write_ext(foo, start[0], length[0]);
/*      */                 
/* 1499 */                 len = length[0];
/* 1500 */                 channel.setLocalWindowSize(channel.lwsize - len);
/* 1501 */                 if (channel.lwsize < channel.lwsize_max / 2) {
/* 1502 */                   packet.reset();
/* 1503 */                   buf.putByte((byte)93);
/* 1504 */                   buf.putInt(channel.getRecipient());
/* 1505 */                   buf.putInt(channel.lwsize_max - channel.lwsize);
/* 1506 */                   synchronized (channel) {
/* 1507 */                     if (!channel.close)
/* 1508 */                       write(packet);
/*      */                   }
/* 1510 */                   channel.setLocalWindowSize(channel.lwsize_max);
/*      */                 }
/*      */               } }
/*      */             break;
/*      */           case 93: 
/* 1515 */             buf.getInt();
/* 1516 */             buf.getShort();
/* 1517 */             i = buf.getInt();
/* 1518 */             channel = Channel.getChannel(i, this);
/* 1519 */             if (channel != null)
/*      */             {
/*      */ 
/* 1522 */               channel.addRemoteWindowSize(buf.getUInt()); }
/* 1523 */             break;
/*      */           
/*      */           case 96: 
/* 1526 */             buf.getInt();
/* 1527 */             buf.getShort();
/* 1528 */             i = buf.getInt();
/* 1529 */             channel = Channel.getChannel(i, this);
/* 1530 */             if (channel != null)
/*      */             {
/*      */ 
/* 1533 */               channel.eof_remote();
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             break;
/*      */           case 97: 
/* 1543 */             buf.getInt();
/* 1544 */             buf.getShort();
/* 1545 */             i = buf.getInt();
/* 1546 */             channel = Channel.getChannel(i, this);
/* 1547 */             if (channel != null)
/*      */             {
/* 1549 */               channel.disconnect();
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             break;
/*      */           case 91: 
/* 1558 */             buf.getInt();
/* 1559 */             buf.getShort();
/* 1560 */             i = buf.getInt();
/* 1561 */             channel = Channel.getChannel(i, this);
/* 1562 */             int r = buf.getInt();
/* 1563 */             long rws = buf.getUInt();
/* 1564 */             int rps = buf.getInt();
/* 1565 */             if (channel != null) {
/* 1566 */               channel.setRemoteWindowSize(rws);
/* 1567 */               channel.setRemotePacketSize(rps);
/* 1568 */               channel.open_confirmation = true;
/* 1569 */               channel.setRecipient(r);
/*      */             }
/*      */             break;
/*      */           case 92: 
/* 1573 */             buf.getInt();
/* 1574 */             buf.getShort();
/* 1575 */             i = buf.getInt();
/* 1576 */             channel = Channel.getChannel(i, this);
/* 1577 */             if (channel != null) {
/* 1578 */               int reason_code = buf.getInt();
/*      */               
/*      */ 
/* 1581 */               channel.setExitStatus(reason_code);
/* 1582 */               channel.close = true;
/* 1583 */               channel.eof_remote = true;
/* 1584 */               channel.setRecipient(0); }
/* 1585 */             break;
/*      */           
/*      */           case 98: 
/* 1588 */             buf.getInt();
/* 1589 */             buf.getShort();
/* 1590 */             i = buf.getInt();
/* 1591 */             foo = buf.getString();
/* 1592 */             reply = buf.getByte() != 0;
/* 1593 */             channel = Channel.getChannel(i, this);
/* 1594 */             if (channel != null) {
/* 1595 */               byte reply_type = 100;
/* 1596 */               if (Util.byte2str(foo).equals("exit-status")) {
/* 1597 */                 i = buf.getInt();
/* 1598 */                 channel.setExitStatus(i);
/* 1599 */                 reply_type = 99;
/*      */               }
/* 1601 */               if (reply) {
/* 1602 */                 packet.reset();
/* 1603 */                 buf.putByte(reply_type);
/* 1604 */                 buf.putInt(channel.getRecipient());
/* 1605 */                 write(packet);
/*      */               } }
/* 1607 */             break;
/*      */           
/*      */ 
/*      */ 
/*      */           case 90: 
/* 1612 */             buf.getInt();
/* 1613 */             buf.getShort();
/* 1614 */             foo = buf.getString();
/* 1615 */             String ctyp = Util.byte2str(foo);
/* 1616 */             if ((!"forwarded-tcpip".equals(ctyp)) && ((!"x11".equals(ctyp)) || (!this.x11_forwarding)) && ((!"auth-agent@openssh.com".equals(ctyp)) || (!this.agent_forwarding)))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 1621 */               packet.reset();
/* 1622 */               buf.putByte((byte)92);
/* 1623 */               buf.putInt(buf.getInt());
/* 1624 */               buf.putInt(1);
/* 1625 */               buf.putString(Util.empty);
/* 1626 */               buf.putString(Util.empty);
/* 1627 */               write(packet);
/*      */             }
/*      */             else {
/* 1630 */               channel = Channel.getChannel(ctyp);
/* 1631 */               addChannel(channel);
/* 1632 */               channel.getData(buf);
/* 1633 */               channel.init();
/*      */               
/* 1635 */               Thread tmp = new Thread(channel);
/* 1636 */               tmp.setName("Channel " + ctyp + " " + this.host);
/* 1637 */               if (this.daemon_thread) {
/* 1638 */                 tmp.setDaemon(this.daemon_thread);
/*      */               }
/* 1640 */               tmp.start();
/*      */             }
/* 1642 */             break;
/*      */           case 99: 
/* 1644 */             buf.getInt();
/* 1645 */             buf.getShort();
/* 1646 */             i = buf.getInt();
/* 1647 */             channel = Channel.getChannel(i, this);
/* 1648 */             if (channel != null)
/*      */             {
/*      */ 
/* 1651 */               channel.reply = 1; }
/* 1652 */             break;
/*      */           case 100: 
/* 1654 */             buf.getInt();
/* 1655 */             buf.getShort();
/* 1656 */             i = buf.getInt();
/* 1657 */             channel = Channel.getChannel(i, this);
/* 1658 */             if (channel != null)
/*      */             {
/*      */ 
/* 1661 */               channel.reply = 0; }
/* 1662 */             break;
/*      */           case 80: 
/* 1664 */             buf.getInt();
/* 1665 */             buf.getShort();
/* 1666 */             foo = buf.getString();
/* 1667 */             reply = buf.getByte() != 0;
/* 1668 */             if (reply) {
/* 1669 */               packet.reset();
/* 1670 */               buf.putByte((byte)82);
/* 1671 */               write(packet);
/*      */             }
/*      */             break;
/*      */           case 81: 
/*      */           case 82: 
/* 1676 */             Thread t = this.grr.getThread();
/* 1677 */             if (t != null) {
/* 1678 */               this.grr.setReply(msgType == 81 ? 1 : 0);
/* 1679 */               if ((msgType == 81) && (this.grr.getPort() == 0)) {
/* 1680 */                 buf.getInt();
/* 1681 */                 buf.getShort();
/* 1682 */                 this.grr.setPort(buf.getInt());
/*      */               }
/* 1684 */               t.interrupt();
/*      */             }
/*      */             
/*      */             break;
/*      */           default: 
/* 1689 */             throw new IOException("Unknown SSH message type " + msgType);
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/* 1694 */       this.in_kex = false;
/* 1695 */       if (JSch.getLogger().isEnabled(1)) {
/* 1696 */         JSch.getLogger().log(1, "Caught an exception, leaving main loop due to " + e.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1703 */       disconnect();
/*      */     }
/*      */     catch (NullPointerException e) {}catch (Exception e) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1713 */     this.isConnected = false;
/*      */   }
/*      */   
/*      */   public void disconnect() {
/* 1717 */     if (!this.isConnected) { return;
/*      */     }
/*      */     
/* 1720 */     if (JSch.getLogger().isEnabled(1)) {
/* 1721 */       JSch.getLogger().log(1, "Disconnecting from " + this.host + " port " + this.port);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1735 */     Channel.disconnect(this);
/*      */     
/* 1737 */     this.isConnected = false;
/*      */     
/* 1739 */     PortWatcher.delPort(this);
/* 1740 */     ChannelForwardedTCPIP.delPort(this);
/* 1741 */     ChannelX11.removeFakedCookie(this);
/*      */     
/* 1743 */     synchronized (this.lock) {
/* 1744 */       if (this.connectThread != null) {
/* 1745 */         Thread.yield();
/* 1746 */         this.connectThread.interrupt();
/* 1747 */         this.connectThread = null;
/*      */       }
/*      */     }
/* 1750 */     this.thread = null;
/*      */     try {
/* 1752 */       if (this.io != null) {
/* 1753 */         if (this.io.in != null) this.io.in.close();
/* 1754 */         if (this.io.out != null) this.io.out.close();
/* 1755 */         if (this.io.out_ext != null) this.io.out_ext.close();
/*      */       }
/* 1757 */       if (this.proxy == null) {
/* 1758 */         if (this.socket != null) {
/* 1759 */           this.socket.close();
/*      */         }
/*      */       } else {
/* 1762 */         synchronized (this.proxy) {
/* 1763 */           this.proxy.close();
/*      */         }
/* 1765 */         this.proxy = null;
/*      */       }
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/* 1771 */     this.io = null;
/* 1772 */     this.socket = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1777 */     this.jsch.removeSession(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(int lport, String host, int rport)
/*      */     throws JSchException
/*      */   {
/* 1792 */     return setPortForwardingL("127.0.0.1", lport, host, rport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String bind_address, int lport, String host, int rport)
/*      */     throws JSchException
/*      */   {
/* 1809 */     return setPortForwardingL(bind_address, lport, host, rport, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String bind_address, int lport, String host, int rport, ServerSocketFactory ssf)
/*      */     throws JSchException
/*      */   {
/* 1828 */     return setPortForwardingL(bind_address, lport, host, rport, ssf, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String bind_address, int lport, String host, int rport, ServerSocketFactory ssf, int connectTimeout)
/*      */     throws JSchException
/*      */   {
/* 1847 */     PortWatcher pw = PortWatcher.addPort(this, bind_address, lport, host, rport, ssf);
/* 1848 */     pw.setConnectTimeout(connectTimeout);
/* 1849 */     Thread tmp = new Thread(pw);
/* 1850 */     tmp.setName("PortWatcher Thread for " + host);
/* 1851 */     if (this.daemon_thread) {
/* 1852 */       tmp.setDaemon(this.daemon_thread);
/*      */     }
/* 1854 */     tmp.start();
/* 1855 */     return pw.lport;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingL(int lport)
/*      */     throws JSchException
/*      */   {
/* 1865 */     delPortForwardingL("127.0.0.1", lport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingL(String bind_address, int lport)
/*      */     throws JSchException
/*      */   {
/* 1876 */     PortWatcher.delPort(this, bind_address, lport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getPortForwardingL()
/*      */     throws JSchException
/*      */   {
/* 1885 */     return PortWatcher.getPortForwarding(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String host, int lport)
/*      */     throws JSchException
/*      */   {
/* 1898 */     setPortForwardingR(null, rport, host, lport, (SocketFactory)null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(String bind_address, int rport, String host, int lport)
/*      */     throws JSchException
/*      */   {
/* 1917 */     setPortForwardingR(bind_address, rport, host, lport, (SocketFactory)null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String host, int lport, SocketFactory sf)
/*      */     throws JSchException
/*      */   {
/* 1931 */     setPortForwardingR(null, rport, host, lport, sf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(String bind_address, int rport, String host, int lport, SocketFactory sf)
/*      */     throws JSchException
/*      */   {
/* 1952 */     int allocated = _setPortForwardingR(bind_address, rport);
/* 1953 */     ChannelForwardedTCPIP.addPort(this, bind_address, rport, allocated, host, lport, sf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String daemon)
/*      */     throws JSchException
/*      */   {
/* 1970 */     setPortForwardingR(null, rport, daemon, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(int rport, String daemon, Object[] arg)
/*      */     throws JSchException
/*      */   {
/* 1987 */     setPortForwardingR(null, rport, daemon, arg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Runnable thread;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortForwardingR(String bind_address, int rport, String daemon, Object[] arg)
/*      */     throws JSchException
/*      */   {
/* 2010 */     int allocated = _setPortForwardingR(bind_address, rport);
/* 2011 */     ChannelForwardedTCPIP.addPort(this, bind_address, rport, allocated, daemon, arg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2021 */   public String[] getPortForwardingR()
/* 2021 */     throws JSchException { return ChannelForwardedTCPIP.getPortForwarding(this); }
/*      */   
/*      */   private class Forwarding { private Forwarding() {}
/* 2024 */     Forwarding(Session.1 x1) { this(); }
/* 2025 */     String bind_address = null;
/* 2026 */     int port = -1;
/* 2027 */     String host = null;
/* 2028 */     int hostport = -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Forwarding parseForwarding(String conf)
/*      */     throws JSchException
/*      */   {
/* 2037 */     String[] tmp = conf.split(" ");
/* 2038 */     if (tmp.length > 1) {
/* 2039 */       Vector foo = new Vector();
/* 2040 */       for (int i = 0; i < tmp.length; i++) {
/* 2041 */         if (tmp[i].length() != 0)
/* 2042 */           foo.addElement(tmp[i].trim());
/*      */       }
/* 2044 */       StringBuffer sb = new StringBuffer();
/* 2045 */       for (int i = 0; i < foo.size(); i++) {
/* 2046 */         sb.append((String)foo.elementAt(i));
/* 2047 */         if (i + 1 < foo.size())
/* 2048 */           sb.append(":");
/*      */       }
/* 2050 */       conf = sb.toString();
/*      */     }
/*      */     
/* 2053 */     String org = conf;
/* 2054 */     Forwarding f = new Forwarding(null);
/*      */     try {
/* 2056 */       if (conf.lastIndexOf(":") == -1)
/* 2057 */         throw new JSchException("parseForwarding: " + org);
/* 2058 */       f.hostport = Integer.parseInt(conf.substring(conf.lastIndexOf(":") + 1));
/* 2059 */       conf = conf.substring(0, conf.lastIndexOf(":"));
/* 2060 */       if (conf.lastIndexOf(":") == -1)
/* 2061 */         throw new JSchException("parseForwarding: " + org);
/* 2062 */       f.host = conf.substring(conf.lastIndexOf(":") + 1);
/* 2063 */       conf = conf.substring(0, conf.lastIndexOf(":"));
/* 2064 */       if (conf.lastIndexOf(":") != -1) {
/* 2065 */         f.port = Integer.parseInt(conf.substring(conf.lastIndexOf(":") + 1));
/* 2066 */         conf = conf.substring(0, conf.lastIndexOf(":"));
/* 2067 */         if ((conf.length() == 0) || (conf.equals("*"))) conf = "0.0.0.0";
/* 2068 */         if (conf.equals("localhost")) conf = "127.0.0.1";
/* 2069 */         f.bind_address = conf;
/*      */       }
/*      */       else {
/* 2072 */         f.port = Integer.parseInt(conf);
/* 2073 */         f.bind_address = "127.0.0.1";
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException e) {
/* 2077 */       throw new JSchException("parseForwarding: " + e.toString());
/*      */     }
/* 2079 */     return f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingL(String conf)
/*      */     throws JSchException
/*      */   {
/* 2095 */     Forwarding f = parseForwarding(conf);
/* 2096 */     return setPortForwardingL(f.bind_address, f.port, f.host, f.hostport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int setPortForwardingR(String conf)
/*      */     throws JSchException
/*      */   {
/* 2115 */     Forwarding f = parseForwarding(conf);
/* 2116 */     int allocated = _setPortForwardingR(f.bind_address, f.port);
/* 2117 */     ChannelForwardedTCPIP.addPort(this, f.bind_address, f.port, allocated, f.host, f.hostport, null);
/*      */     
/* 2119 */     return allocated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Channel getStreamForwarder(String host, int port)
/*      */     throws JSchException
/*      */   {
/* 2130 */     ChannelDirectTCPIP channel = new ChannelDirectTCPIP();
/* 2131 */     channel.init();
/* 2132 */     addChannel(channel);
/* 2133 */     channel.setHost(host);
/* 2134 */     channel.setPort(port);
/* 2135 */     return channel;
/*      */   }
/*      */   
/* 2138 */   private class GlobalRequestReply { GlobalRequestReply(Session.1 x1) { this(); }
/* 2139 */     private Thread thread = null;
/* 2140 */     private int reply = -1;
/* 2141 */     private int port = 0;
/*      */     
/* 2143 */     void setThread(Thread thread) { this.thread = thread;
/* 2144 */       this.reply = -1; }
/*      */     
/* 2146 */     Thread getThread() { return this.thread; }
/* 2147 */     void setReply(int reply) { this.reply = reply; }
/* 2148 */     int getReply() { return this.reply; }
/* 2149 */     int getPort() { return this.port; }
/* 2150 */     void setPort(int port) { this.port = port; }
/*      */     private GlobalRequestReply() {} }
/* 2152 */   private GlobalRequestReply grr = new GlobalRequestReply(null);
/*      */   
/* 2154 */   private int _setPortForwardingR(String bind_address, int rport) throws JSchException { synchronized (this.grr) {
/* 2155 */       Buffer buf = new Buffer(100);
/* 2156 */       Packet packet = new Packet(buf);
/*      */       
/* 2158 */       String address_to_bind = ChannelForwardedTCPIP.normalize(bind_address);
/*      */       
/* 2160 */       this.grr.setThread(Thread.currentThread());
/* 2161 */       this.grr.setPort(rport);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 2169 */         packet.reset();
/* 2170 */         buf.putByte((byte)80);
/* 2171 */         buf.putString(Util.str2byte("tcpip-forward"));
/* 2172 */         buf.putByte((byte)1);
/* 2173 */         buf.putString(Util.str2byte(address_to_bind));
/* 2174 */         buf.putInt(rport);
/* 2175 */         write(packet);
/*      */       }
/*      */       catch (Exception e) {
/* 2178 */         this.grr.setThread(null);
/* 2179 */         if ((e instanceof Throwable))
/* 2180 */           throw new JSchException(e.toString(), e);
/* 2181 */         throw new JSchException(e.toString());
/*      */       }
/*      */       
/* 2184 */       int count = 0;
/* 2185 */       int reply = this.grr.getReply();
/* 2186 */       while ((count < 10) && (reply == -1)) {
/* 2187 */         try { Thread.sleep(1000L);
/*      */         }
/*      */         catch (Exception e) {}
/* 2190 */         count++;
/* 2191 */         reply = this.grr.getReply();
/*      */       }
/* 2193 */       this.grr.setThread(null);
/* 2194 */       if (reply != 1) {
/* 2195 */         throw new JSchException("remote port forwarding failed for listen port " + rport);
/*      */       }
/* 2197 */       rport = this.grr.getPort();
/*      */     }
/* 2199 */     return rport;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingR(int rport)
/*      */     throws JSchException
/*      */   {
/* 2208 */     delPortForwardingR(null, rport);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delPortForwardingR(String bind_address, int rport)
/*      */     throws JSchException
/*      */   {
/* 2220 */     ChannelForwardedTCPIP.delPort(this, bind_address, rport);
/*      */   }
/*      */   
/*      */   private void initDeflater(String method) throws JSchException {
/* 2224 */     if (method.equals("none")) {
/* 2225 */       this.deflater = null;
/* 2226 */       return;
/*      */     }
/* 2228 */     String foo = getConfig(method);
/* 2229 */     if ((foo != null) && (
/* 2230 */       (method.equals("zlib")) || ((this.isAuthed) && (method.equals("zlib@openssh.com"))))) {
/*      */       try
/*      */       {
/* 2233 */         Class c = Class.forName(foo);
/* 2234 */         this.deflater = ((Compression)c.newInstance());
/* 2235 */         int level = 6;
/* 2236 */         try { level = Integer.parseInt(getConfig("compression_level"));
/*      */         } catch (Exception ee) {}
/* 2238 */         this.deflater.init(1, level);
/*      */       }
/*      */       catch (NoClassDefFoundError ee) {
/* 2241 */         throw new JSchException(ee.toString(), ee);
/*      */       }
/*      */       catch (Exception ee) {
/* 2244 */         throw new JSchException(ee.toString(), ee);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void initInflater(String method) throws JSchException
/*      */   {
/* 2251 */     if (method.equals("none")) {
/* 2252 */       this.inflater = null;
/* 2253 */       return;
/*      */     }
/* 2255 */     String foo = getConfig(method);
/* 2256 */     if ((foo != null) && (
/* 2257 */       (method.equals("zlib")) || ((this.isAuthed) && (method.equals("zlib@openssh.com"))))) {
/*      */       try
/*      */       {
/* 2260 */         Class c = Class.forName(foo);
/* 2261 */         this.inflater = ((Compression)c.newInstance());
/* 2262 */         this.inflater.init(0, 0);
/*      */       }
/*      */       catch (Exception ee) {
/* 2265 */         throw new JSchException(ee.toString(), ee);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void addChannel(Channel channel)
/*      */   {
/* 2273 */     channel.setSession(this);
/*      */   }
/*      */   
/* 2276 */   public void setProxy(Proxy proxy) { this.proxy = proxy; }
/* 2277 */   public void setHost(String host) { this.host = host; }
/* 2278 */   public void setPort(int port) { this.port = port; }
/* 2279 */   void setUserName(String username) { this.username = username; }
/* 2280 */   public void setUserInfo(UserInfo userinfo) { this.userinfo = userinfo; }
/* 2281 */   public UserInfo getUserInfo() { return this.userinfo; }
/* 2282 */   public void setInputStream(InputStream in) { this.in = in; }
/* 2283 */   public void setOutputStream(OutputStream out) { this.out = out; }
/* 2284 */   public void setX11Host(String host) { ChannelX11.setHost(host); }
/* 2285 */   public void setX11Port(int port) { ChannelX11.setPort(port); }
/* 2286 */   public void setX11Cookie(String cookie) { ChannelX11.setCookie(cookie); }
/*      */   
/* 2288 */   public void setPassword(String password) { if (password != null)
/* 2289 */       this.password = Util.str2byte(password);
/*      */   }
/*      */   
/* 2292 */   public void setPassword(byte[] password) { if (password != null) {
/* 2293 */       this.password = new byte[password.length];
/* 2294 */       System.arraycopy(password, 0, this.password, 0, password.length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 2299 */   public void setConfig(Properties newconf) { setConfig(newconf); }
/*      */   
/*      */   public void setConfig(Hashtable newconf) {
/*      */     Enumeration e;
/* 2303 */     synchronized (this.lock) {
/* 2304 */       if (this.config == null)
/* 2305 */         this.config = new Hashtable();
/* 2306 */       for (e = newconf.keys(); e.hasMoreElements();) {
/* 2307 */         String key = (String)e.nextElement();
/* 2308 */         this.config.put(key, (String)newconf.get(key));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setConfig(String key, String value) {
/* 2314 */     synchronized (this.lock) {
/* 2315 */       if (this.config == null) {
/* 2316 */         this.config = new Hashtable();
/*      */       }
/* 2318 */       this.config.put(key, value);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getConfig(String key) {
/* 2323 */     Object foo = null;
/* 2324 */     if (this.config != null) {
/* 2325 */       foo = this.config.get(key);
/* 2326 */       if ((foo instanceof String)) return (String)foo;
/*      */     }
/* 2328 */     foo = JSch.getConfig(key);
/* 2329 */     if ((foo instanceof String)) return (String)foo;
/* 2330 */     return null;
/*      */   }
/*      */   
/*      */ 
/* 2334 */   public void setSocketFactory(SocketFactory sfactory) { this.socket_factory = sfactory; }
/*      */   
/* 2336 */   public boolean isConnected() { return this.isConnected; }
/* 2337 */   public int getTimeout() { return this.timeout; }
/*      */   
/* 2339 */   public void setTimeout(int timeout) throws JSchException { if (this.socket == null) {
/* 2340 */       if (timeout < 0) {
/* 2341 */         throw new JSchException("invalid timeout value");
/*      */       }
/* 2343 */       this.timeout = timeout;
/* 2344 */       return;
/*      */     }
/*      */     try {
/* 2347 */       this.socket.setSoTimeout(timeout);
/* 2348 */       this.timeout = timeout;
/*      */     }
/*      */     catch (Exception e) {
/* 2351 */       if ((e instanceof Throwable))
/* 2352 */         throw new JSchException(e.toString(), e);
/* 2353 */       throw new JSchException(e.toString());
/*      */     }
/*      */   }
/*      */   
/* 2357 */   public String getServerVersion() { return Util.byte2str(this.V_S); }
/*      */   
/*      */   public String getClientVersion() {
/* 2360 */     return Util.byte2str(this.V_C);
/*      */   }
/*      */   
/* 2363 */   public void setClientVersion(String cv) { this.V_C = Util.str2byte(cv); }
/*      */   
/*      */   public void sendIgnore() throws Exception
/*      */   {
/* 2367 */     Buffer buf = new Buffer();
/* 2368 */     Packet packet = new Packet(buf);
/* 2369 */     packet.reset();
/* 2370 */     buf.putByte((byte)2);
/* 2371 */     write(packet);
/*      */   }
/*      */   
/* 2374 */   private static final byte[] keepalivemsg = Util.str2byte("keepalive@jcraft.com");
/*      */   
/* 2376 */   public void sendKeepAliveMsg() throws Exception { Buffer buf = new Buffer();
/* 2377 */     Packet packet = new Packet(buf);
/* 2378 */     packet.reset();
/* 2379 */     buf.putByte((byte)80);
/* 2380 */     buf.putString(keepalivemsg);
/* 2381 */     buf.putByte((byte)1);
/* 2382 */     write(packet);
/*      */   }
/*      */   
/* 2385 */   private static final byte[] nomoresessions = Util.str2byte("no-more-sessions@openssh.com");
/*      */   
/* 2387 */   public void noMoreSessionChannels() throws Exception { Buffer buf = new Buffer();
/* 2388 */     Packet packet = new Packet(buf);
/* 2389 */     packet.reset();
/* 2390 */     buf.putByte((byte)80);
/* 2391 */     buf.putString(nomoresessions);
/* 2392 */     buf.putByte((byte)0);
/* 2393 */     write(packet);
/*      */   }
/*      */   
/* 2396 */   private HostKey hostkey = null;
/* 2397 */   public HostKey getHostKey() { return this.hostkey; }
/* 2398 */   public String getHost() { return this.host; }
/* 2399 */   public String getUserName() { return this.username; }
/* 2400 */   public int getPort() { return this.port; }
/*      */   
/* 2402 */   public void setHostKeyAlias(String hostKeyAlias) { this.hostKeyAlias = hostKeyAlias; }
/*      */   
/*      */   public String getHostKeyAlias() {
/* 2405 */     return this.hostKeyAlias;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerAliveInterval(int interval)
/*      */     throws JSchException
/*      */   {
/* 2417 */     setTimeout(interval);
/* 2418 */     this.serverAliveInterval = interval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getServerAliveInterval()
/*      */   {
/* 2427 */     return this.serverAliveInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerAliveCountMax(int count)
/*      */   {
/* 2440 */     this.serverAliveCountMax = count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getServerAliveCountMax()
/*      */   {
/* 2449 */     return this.serverAliveCountMax;
/*      */   }
/*      */   
/*      */   public void setDaemonThread(boolean enable) {
/* 2453 */     this.daemon_thread = enable;
/*      */   }
/*      */   
/*      */   private String[] checkCiphers(String ciphers) {
/* 2457 */     if ((ciphers == null) || (ciphers.length() == 0)) {
/* 2458 */       return null;
/*      */     }
/* 2460 */     if (JSch.getLogger().isEnabled(1)) {
/* 2461 */       JSch.getLogger().log(1, "CheckCiphers: " + ciphers);
/*      */     }
/*      */     
/*      */ 
/* 2465 */     String cipherc2s = getConfig("cipher.c2s");
/* 2466 */     String ciphers2c = getConfig("cipher.s2c");
/*      */     
/* 2468 */     Vector result = new Vector();
/* 2469 */     String[] _ciphers = Util.split(ciphers, ",");
/* 2470 */     for (int i = 0; i < _ciphers.length; i++) {
/* 2471 */       String cipher = _ciphers[i];
/* 2472 */       if ((ciphers2c.indexOf(cipher) != -1) || (cipherc2s.indexOf(cipher) != -1))
/*      */       {
/* 2474 */         if (!checkCipher(getConfig(cipher)))
/* 2475 */           result.addElement(cipher);
/*      */       }
/*      */     }
/* 2478 */     if (result.size() == 0)
/* 2479 */       return null;
/* 2480 */     String[] foo = new String[result.size()];
/* 2481 */     System.arraycopy(result.toArray(), 0, foo, 0, result.size());
/*      */     
/* 2483 */     if (JSch.getLogger().isEnabled(1)) {
/* 2484 */       for (int i = 0; i < foo.length; i++) {
/* 2485 */         JSch.getLogger().log(1, foo[i] + " is not available.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2490 */     return foo;
/*      */   }
/*      */   
/*      */   static boolean checkCipher(String cipher) {
/*      */     try {
/* 2495 */       Class c = Class.forName(cipher);
/* 2496 */       Cipher _c = (Cipher)c.newInstance();
/* 2497 */       _c.init(0, new byte[_c.getBlockSize()], new byte[_c.getIVSize()]);
/*      */       
/*      */ 
/* 2500 */       return true;
/*      */     }
/*      */     catch (Exception e) {}
/* 2503 */     return false;
/*      */   }
/*      */   
/*      */   private String[] checkKexes(String kexes)
/*      */   {
/* 2508 */     if ((kexes == null) || (kexes.length() == 0)) {
/* 2509 */       return null;
/*      */     }
/* 2511 */     if (JSch.getLogger().isEnabled(1)) {
/* 2512 */       JSch.getLogger().log(1, "CheckKexes: " + kexes);
/*      */     }
/*      */     
/*      */ 
/* 2516 */     Vector result = new Vector();
/* 2517 */     String[] _kexes = Util.split(kexes, ",");
/* 2518 */     for (int i = 0; i < _kexes.length; i++) {
/* 2519 */       if (!checkKex(this, getConfig(_kexes[i]))) {
/* 2520 */         result.addElement(_kexes[i]);
/*      */       }
/*      */     }
/* 2523 */     if (result.size() == 0)
/* 2524 */       return null;
/* 2525 */     String[] foo = new String[result.size()];
/* 2526 */     System.arraycopy(result.toArray(), 0, foo, 0, result.size());
/*      */     
/* 2528 */     if (JSch.getLogger().isEnabled(1)) {
/* 2529 */       for (int i = 0; i < foo.length; i++) {
/* 2530 */         JSch.getLogger().log(1, foo[i] + " is not available.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2535 */     return foo;
/*      */   }
/*      */   
/*      */   static boolean checkKex(Session s, String kex) {
/*      */     try {
/* 2540 */       Class c = Class.forName(kex);
/* 2541 */       KeyExchange _c = (KeyExchange)c.newInstance();
/* 2542 */       _c.init(s, null, null, null, null);
/* 2543 */       return true;
/*      */     } catch (Exception e) {}
/* 2545 */     return false;
/*      */   }
/*      */   
/*      */   private String[] checkSignatures(String sigs) {
/* 2549 */     if ((sigs == null) || (sigs.length() == 0)) {
/* 2550 */       return null;
/*      */     }
/* 2552 */     if (JSch.getLogger().isEnabled(1)) {
/* 2553 */       JSch.getLogger().log(1, "CheckSignatures: " + sigs);
/*      */     }
/*      */     
/*      */ 
/* 2557 */     Vector result = new Vector();
/* 2558 */     String[] _sigs = Util.split(sigs, ",");
/* 2559 */     for (int i = 0; i < _sigs.length; i++) {
/*      */       try {
/* 2561 */         Class c = Class.forName(JSch.getConfig(_sigs[i]));
/* 2562 */         Signature sig = (Signature)c.newInstance();
/* 2563 */         sig.init();
/*      */       }
/*      */       catch (Exception e) {
/* 2566 */         result.addElement(_sigs[i]);
/*      */       }
/*      */     }
/* 2569 */     if (result.size() == 0)
/* 2570 */       return null;
/* 2571 */     String[] foo = new String[result.size()];
/* 2572 */     System.arraycopy(result.toArray(), 0, foo, 0, result.size());
/* 2573 */     if (JSch.getLogger().isEnabled(1)) {
/* 2574 */       for (int i = 0; i < foo.length; i++) {
/* 2575 */         JSch.getLogger().log(1, foo[i] + " is not available.");
/*      */       }
/*      */     }
/*      */     
/* 2579 */     return foo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIdentityRepository(IdentityRepository identityRepository)
/*      */   {
/* 2590 */     this.identityRepository = identityRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   IdentityRepository getIdentityRepository()
/*      */   {
/* 2601 */     if (this.identityRepository == null)
/* 2602 */       return this.jsch.getIdentityRepository();
/* 2603 */     return this.identityRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostKeyRepository(HostKeyRepository hostkeyRepository)
/*      */   {
/* 2613 */     this.hostkeyRepository = hostkeyRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HostKeyRepository getHostKeyRepository()
/*      */   {
/* 2624 */     if (this.hostkeyRepository == null)
/* 2625 */       return this.jsch.getHostKeyRepository();
/* 2626 */     return this.hostkeyRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void applyConfig()
/*      */     throws JSchException
/*      */   {
/* 2670 */     ConfigRepository configRepository = this.jsch.getConfigRepository();
/* 2671 */     if (configRepository == null) {
/* 2672 */       return;
/*      */     }
/*      */     
/* 2675 */     ConfigRepository.Config config = configRepository.getConfig(this.org_host);
/*      */     
/*      */ 
/* 2678 */     String value = null;
/*      */     
/* 2680 */     value = config.getUser();
/* 2681 */     if (value != null) {
/* 2682 */       this.username = value;
/*      */     }
/* 2684 */     value = config.getHostname();
/* 2685 */     if (value != null) {
/* 2686 */       this.host = value;
/*      */     }
/* 2688 */     int port = config.getPort();
/* 2689 */     if (port != -1) {
/* 2690 */       this.port = port;
/*      */     }
/* 2692 */     checkConfig(config, "kex");
/* 2693 */     checkConfig(config, "server_host_key");
/*      */     
/* 2695 */     checkConfig(config, "cipher.c2s");
/* 2696 */     checkConfig(config, "cipher.s2c");
/* 2697 */     checkConfig(config, "mac.c2s");
/* 2698 */     checkConfig(config, "mac.s2c");
/* 2699 */     checkConfig(config, "compression.c2s");
/* 2700 */     checkConfig(config, "compression.s2c");
/* 2701 */     checkConfig(config, "compression_level");
/*      */     
/* 2703 */     checkConfig(config, "StrictHostKeyChecking");
/* 2704 */     checkConfig(config, "HashKnownHosts");
/* 2705 */     checkConfig(config, "PreferredAuthentications");
/* 2706 */     checkConfig(config, "MaxAuthTries");
/* 2707 */     checkConfig(config, "ClearAllForwardings");
/*      */     
/* 2709 */     value = config.getValue("HostKeyAlias");
/* 2710 */     if (value != null) {
/* 2711 */       setHostKeyAlias(value);
/*      */     }
/* 2713 */     value = config.getValue("UserKnownHostsFile");
/* 2714 */     if (value != null) {
/* 2715 */       KnownHosts kh = new KnownHosts(this.jsch);
/* 2716 */       kh.setKnownHosts(value);
/* 2717 */       setHostKeyRepository(kh);
/*      */     }
/*      */     
/* 2720 */     String[] values = config.getValues("IdentityFile");
/* 2721 */     if (values != null) {
/* 2722 */       String[] global = configRepository.getConfig("").getValues("IdentityFile");
/*      */       
/* 2724 */       if (global != null) {
/* 2725 */         for (int i = 0; i < global.length; i++) {
/* 2726 */           this.jsch.addIdentity(global[i]);
/*      */         }
/*      */         
/*      */       } else {
/* 2730 */         global = new String[0];
/*      */       }
/* 2732 */       if (values.length - global.length > 0) {
/* 2733 */         IdentityRepository.Wrapper ir = new IdentityRepository.Wrapper(this.jsch.getIdentityRepository(), true);
/*      */         
/* 2735 */         for (int i = 0; i < values.length; i++) {
/* 2736 */           String ifile = values[i];
/* 2737 */           for (int j = 0; j < global.length; j++)
/* 2738 */             if (ifile.equals(global[j]))
/*      */             {
/* 2740 */               ifile = null;
/* 2741 */               break;
/*      */             }
/* 2743 */           if (ifile != null)
/*      */           {
/* 2745 */             Identity identity = IdentityFile.newInstance(ifile, null, this.jsch);
/*      */             
/* 2747 */             ir.add(identity);
/*      */           } }
/* 2749 */         setIdentityRepository(ir);
/*      */       }
/*      */     }
/*      */     
/* 2753 */     value = config.getValue("ServerAliveInterval");
/* 2754 */     if (value != null) {
/*      */       try {
/* 2756 */         setServerAliveInterval(Integer.parseInt(value));
/*      */       }
/*      */       catch (NumberFormatException e) {}
/*      */     }
/*      */     
/*      */ 
/* 2762 */     value = config.getValue("ConnectTimeout");
/* 2763 */     if (value != null) {
/*      */       try {
/* 2765 */         setTimeout(Integer.parseInt(value));
/*      */       }
/*      */       catch (NumberFormatException e) {}
/*      */     }
/*      */     
/*      */ 
/* 2771 */     value = config.getValue("MaxAuthTries");
/* 2772 */     if (value != null) {
/* 2773 */       setConfig("MaxAuthTries", value);
/*      */     }
/*      */     
/* 2776 */     value = config.getValue("ClearAllForwardings");
/* 2777 */     if (value != null) {
/* 2778 */       setConfig("ClearAllForwardings", value);
/*      */     }
/*      */   }
/*      */   
/*      */   private void applyConfigChannel(ChannelSession channel) throws JSchException
/*      */   {
/* 2784 */     ConfigRepository configRepository = this.jsch.getConfigRepository();
/* 2785 */     if (configRepository == null) {
/* 2786 */       return;
/*      */     }
/*      */     
/* 2789 */     ConfigRepository.Config config = configRepository.getConfig(this.org_host);
/*      */     
/*      */ 
/* 2792 */     String value = null;
/*      */     
/* 2794 */     value = config.getValue("ForwardAgent");
/* 2795 */     if (value != null) {
/* 2796 */       channel.setAgentForwarding(value.equals("yes"));
/*      */     }
/*      */     
/* 2799 */     value = config.getValue("RequestTTY");
/* 2800 */     if (value != null) {
/* 2801 */       channel.setPty(value.equals("yes"));
/*      */     }
/*      */   }
/*      */   
/*      */   private void requestPortForwarding() throws JSchException
/*      */   {
/* 2807 */     if (getConfig("ClearAllForwardings").equals("yes")) {
/* 2808 */       return;
/*      */     }
/* 2810 */     ConfigRepository configRepository = this.jsch.getConfigRepository();
/* 2811 */     if (configRepository == null) {
/* 2812 */       return;
/*      */     }
/*      */     
/* 2815 */     ConfigRepository.Config config = configRepository.getConfig(this.org_host);
/*      */     
/*      */ 
/* 2818 */     String[] values = config.getValues("LocalForward");
/* 2819 */     if (values != null) {
/* 2820 */       for (int i = 0; i < values.length; i++) {
/* 2821 */         setPortForwardingL(values[i]);
/*      */       }
/*      */     }
/*      */     
/* 2825 */     values = config.getValues("RemoteForward");
/* 2826 */     if (values != null) {
/* 2827 */       for (int i = 0; i < values.length; i++) {
/* 2828 */         setPortForwardingR(values[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkConfig(ConfigRepository.Config config, String key) {
/* 2834 */     String value = config.getValue(key);
/* 2835 */     if (value != null) {
/* 2836 */       setConfig(key, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\Session.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */