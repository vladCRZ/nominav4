package com.jcraft.jsch;

public abstract interface SftpProgressMonitor
{
  public static final int PUT = 0;
  public static final int GET = 1;
  public static final long UNKNOWN_SIZE = -1L;
  
  public abstract void init(int paramInt, String paramString1, String paramString2, long paramLong);
  
  public abstract boolean count(long paramLong);
  
  public abstract void end();
}


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\SftpProgressMonitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */