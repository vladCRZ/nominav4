/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARCFOUR256
/*    */   implements com.jcraft.jsch.Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   private static final int bsize = 32;
/*    */   private static final int skip = 1536;
/*    */   private javax.crypto.Cipher cipher;
/*    */   
/* 41 */   public int getIVSize() { return 8; }
/* 42 */   public int getBlockSize() { return 32; }
/*    */   
/*    */   public void init(int mode, byte[] key, byte[] iv) throws Exception {
/* 45 */     if (key.length > 32) {
/* 46 */       byte[] tmp = new byte[32];
/* 47 */       System.arraycopy(key, 0, tmp, 0, tmp.length);
/* 48 */       key = tmp;
/*    */     }
/*    */     try {
/* 51 */       this.cipher = javax.crypto.Cipher.getInstance("RC4");
/* 52 */       SecretKeySpec _key = new SecretKeySpec(key, "RC4");
/* 53 */       synchronized (javax.crypto.Cipher.class) {
/* 54 */         this.cipher.init(mode == 0 ? 1 : 2, _key);
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 59 */       byte[] foo = new byte[1];
/* 60 */       for (int i = 0; i < 1536; i++) {
/* 61 */         this.cipher.update(foo, 0, 1, foo, 0);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 65 */       this.cipher = null;
/* 66 */       throw e;
/*    */     }
/*    */   }
/*    */   
/* 70 */   public void update(byte[] foo, int s1, int len, byte[] bar, int s2) throws Exception { this.cipher.update(foo, s1, len, bar, s2); }
/*    */   
/* 72 */   public boolean isCBC() { return false; }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jce\ARCFOUR256.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */