/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.ECDH;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ECDH521
/*    */   extends ECDHN
/*    */   implements ECDH
/*    */ {
/*    */   public void init()
/*    */     throws Exception
/*    */   {
/* 34 */     super.init(521);
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jce\ECDH521.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */