/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACMD5
/*    */   extends HMAC
/*    */ {
/*    */   public HMACMD5()
/*    */   {
/* 38 */     this.name = "hmac-md5";
/* 39 */     this.bsize = 16;
/* 40 */     this.algorithm = "HmacMD5";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jce\HMACMD5.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */