/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.spec.InvalidKeySpecException;
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.crypto.SecretKeyFactory;
/*    */ import javax.crypto.spec.PBEKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PBKDF
/*    */   implements com.jcraft.jsch.PBKDF
/*    */ {
/*    */   public byte[] getKey(byte[] _pass, byte[] salt, int iterations, int size)
/*    */   {
/* 41 */     char[] pass = new char[_pass.length];
/* 42 */     for (int i = 0; i < _pass.length; i++) {
/* 43 */       pass[i] = ((char)(_pass[i] & 0xFF));
/*    */     }
/*    */     try {
/* 46 */       PBEKeySpec spec = new PBEKeySpec(pass, salt, iterations, size * 8);
/*    */       
/* 48 */       SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
/*    */       
/* 50 */       return skf.generateSecret(spec).getEncoded();
/*    */     }
/*    */     catch (InvalidKeySpecException e) {}catch (NoSuchAlgorithmException e) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 57 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jce\PBKDF.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */