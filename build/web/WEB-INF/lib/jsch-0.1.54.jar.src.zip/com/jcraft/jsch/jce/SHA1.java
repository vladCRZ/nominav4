/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.HASH;
/*    */ import java.io.PrintStream;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SHA1
/*    */   implements HASH
/*    */ {
/*    */   MessageDigest md;
/*    */   
/* 38 */   public int getBlockSize() { return 20; }
/*    */   
/* 40 */   public void init() throws Exception { try { this.md = MessageDigest.getInstance("SHA-1");
/*    */     } catch (Exception e) {
/* 42 */       System.err.println(e);
/*    */     }
/*    */   }
/*    */   
/* 46 */   public void update(byte[] foo, int start, int len) throws Exception { this.md.update(foo, start, len); }
/*    */   
/*    */   public byte[] digest() throws Exception {
/* 49 */     return this.md.digest();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jce\SHA1.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */