/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.HASH;
/*    */ import java.io.PrintStream;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SHA384
/*    */   implements HASH
/*    */ {
/*    */   MessageDigest md;
/*    */   
/* 36 */   public int getBlockSize() { return 48; }
/*    */   
/* 38 */   public void init() throws Exception { try { this.md = MessageDigest.getInstance("SHA-384");
/*    */     } catch (Exception e) {
/* 40 */       System.err.println(e);
/*    */     }
/*    */   }
/*    */   
/* 44 */   public void update(byte[] foo, int start, int len) throws Exception { this.md.update(foo, start, len); }
/*    */   
/*    */   public byte[] digest() throws Exception {
/* 47 */     return this.md.digest();
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jce\SHA384.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */