/*    */ package com.jcraft.jsch.jcraft;
/*    */ 
/*    */ import com.jcraft.jsch.MAC;
/*    */ import java.io.PrintStream;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACMD5
/*    */   extends HMAC
/*    */   implements MAC
/*    */ {
/*    */   private static final String name = "hmac-md5";
/*    */   
/*    */   public HMACMD5()
/*    */   {
/* 40 */     MessageDigest md = null;
/* 41 */     try { md = MessageDigest.getInstance("MD5");
/*    */     } catch (Exception e) {
/* 43 */       System.err.println(e);
/*    */     }
/* 45 */     setH(md);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 49 */     return "hmac-md5";
/*    */   }
/*    */ }


/* Location:              C:\Users\VSCruz\Documents\nominaD\Nominav2.zip!\Nominav2\WEB-INF\lib\jsch-0.1.54.jar!\com\jcraft\jsch\jcraft\HMACMD5.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */